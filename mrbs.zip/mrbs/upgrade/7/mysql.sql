# $Id: mysql.sql 1225 2009-10-21 20:43:03Z cimorrison $
