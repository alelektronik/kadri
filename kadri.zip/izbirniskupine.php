<?php
/*
Program za urejanje izbirnih predmetov in heterogenih oz. nivojskih skupin

1. izbor razreda za vnos izbirnih predmetov
2. dodajanje izbirnih predmetov razredu
3. vpis izbranih izb. predmetov razredu
4. dodajanje izbirnih predmetov po učencih
5. vpis izbirnega predmeta učencu
6. izpis izbirnih predmetov (učitelji po predmetih, učencev po predmetih, razredov po predmetih, izbor predmetov po učencih, možni istočasni predmeti)
6a. izpis izbirnih predmetov po razredih
7. izpis zgodovine izbirnih predmetov po učencih
8. brisanje izbirnega predmeta
9. izpis v PDF po izbirnih predmetih (spiski učenecv pri predmetu)
10. izbor razreda za vpis nivojskih skupin
11. dodajanje nivojskih skupin za razred
12. vpis podatkov o nivojskih skupinah
13. izpis nivojskih skupin
14. PDF izpis nivojskih skupin
20. izbor izbirnih predmetov
21. izbor izbirnih predmetov za razred
22. vpis izbora predmetov za razred
23. izpis izbirnih predmetov in nastavljanje njihovih lastnosti ter določanje v nabor
24. vpis podatkov o predmetih in vključitev v nabor
25. obrazci za izbiro predmetov
26. izbor izbirnih predmetov z izračuni skupin in prikazom števila učencev
27. izpis izbora izbirnih predmetov po razredih
28. izpis izbora izbirnih predmetov po predmetih
29. prenos izbora izbirnih predmetov učencem

Uporablja tabele:
tabucenci
tabrazred
tabrazdat
tabpredmeti
tabizbirni
tabnivoji
tabnaborizb
tabizbirniizbor
 
*/
require("const.php");
require("ucenci.php");
require('fpdf.php');

function ToNivojski($x){
    switch ($x){
        case 1:
            return "MAT";
        case 2:
            return "MAT1";
        case 3:
            return "MAT2";
        case 4:
            return "MAT3";
        case 13:
            return "MAT4";
        case 14:
            return "MAT5";
        case 15:
            return "MAT6";
        case 5:
            return "SLO";
        case 6:
            return "SLO1";
        case 7:
            return "SLO2";
        case 8:
            return "SLO3";
        case 16:
            return "SLO4";
        case 17:
            return "SLO5";
        case 18:
            return "SLO6";
        case 9:
            return "TJA";
        case 10:
            return "TJA1";
        case 11:
            return "TJA2";
        case 12:
            return "TJA3";
        case 19:
            return "TJA4";
        case 20:
            return "TJA5";
        case 21:
            return "TJA6";
        default:
            return "";
    }
}
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function vsebuje($s,$a){
    //ali niz števil ločenih z vejico $s vsebuje število $a
    $sarr=explode(",",$s);
    for ($i=0;$i < count($sarr);$i++){
        if (intval($a)==intval($sarr[$i])){
            return true;
        }
    }
    return false;
}

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    //echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

switch ($Vid){
	case "3":
	case "5":
	case "9":
    case "12";
	case "14":
    case "22":
    case "24":
    case "3a":
    case "5a":
    case "9a":
    case "12a";
    case "14a":
    case "22a":
    case "24a":
		break;
	default:
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Izbrani izbirni predmeti";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
		$n=$VLevel;
		include('menu_func.inc');
		include ('menu.inc');
}
	
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}

switch ($Vid){
    case "1": //izbor razreda - izbirni
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto </td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM TabRazDat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        echo "<option value='0'>Ni izbran</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "<input name='id' type='hidden' value='2'>";
        echo "<input name='submitform' type='button' value='Pošlji' onclick='this.form.submit()'>";
        //echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "1a": //izbor razreda - neobvezni izbirni
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto </td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM TabRazDat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        echo "<option value='0'>Ni izbran</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "<input name='id' type='hidden' value='2a'>";
        echo "<input name='submitform' type='button' value='Pošlji' onclick='this.form.submit()'>";
        //echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "2": //dodaj izbirne - razred
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM TabRazDat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<select name='razred' onchange='this.form.submit()'>";
        echo "<option value='0'>Ni izbran</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "<input name='id' type='hidden' value='2'>";
        //echo "<input name='submitform' type='button' value='Pošlji' onclick='this.form.submit()'>";
        //echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";

        $SQL = "SELECT tabrazred.*, tabucenci.*,TabRazDat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred;
        $SQL = $SQL ." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        //izpis razrednih podatkov
        $Indx=0;
        $VRazred1=0;
        $VParalelka="";
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx][0] = $R["IdUcenec"];
            $Ucenci[$Indx][1] = $R["Priimek"]." ".$R["Ime"];
            $Ucenci[$Indx][2] = $R["razred"];
            $Ucenci[$Indx][3] = $R["oznaka"];
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
            $Indx = $Indx+1;
        } 
        $StUcencev=$Indx-1;

        echo "<h2>Vpis izbirnih predmetov učencem ".$VRazred1.". ".$VParalelka."</h2>";
        echo "<form  name='DodajIzbirni' method='post' action='izbirniskupine.php'>";
        echo "<input name='id' type='hidden' value='3'>";
        echo "<table border='1'>";
        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";

        for ($Indx0=0;$Indx0 <= $StUcencev;$Indx0++){
            echo "<tr><td>".($Indx0+1)."</td>";
            echo "<td>".$VLeto."/".($VLeto+1)."</td>";
            echo "<td><input type='hidden' name='ime".$Indx0."' value='".$Ucenci[$Indx0][0]."'>".$Ucenci[$Indx0][1]."</td>";

            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $SQL = "SELECT tabpredmeti.id FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni ";
            $SQL = $SQL . "WHERE tabizbirni.Ucenec=" .$Ucenci[$Indx0][0] . " AND leto=".$VLeto." AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY leto DESC";
            $result = mysqli_query($link,$SQL);

            $IndxIzb=0;
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $IzbraniPredmet[$IndxIzb]=$R["id"];
                $IndxIzb=$IndxIzb+1;
                $Indx = $Indx+1;
            } 

            //if ($VRazred1 > 6){
                $SQL = "SELECT * FROM tabpredmeti WHERE Prioriteta = 1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY Opis";
            //}
            /*
            else{
                $SQL = "SELECT * FROM tabpredmeti WHERE Prioriteta = 1 AND OpisMSS LIKE '%/ni/%' ORDER BY Opis";
            }
            */
            $result = mysqli_query($link,$SQL);

            echo "<td>1. <select name='izbirni1_".$Indx0."'>";
            $Indx=0;
            if ($IzbraniPredmet[0]==0 ){
                echo "<option value=0 selected>Ni izbran</option>";
            }else{
                echo "<option value=0>Ni izbran</option>";
            }
            while ($R = mysqli_fetch_array($result)){
                if ($R["Id"]==$IzbraniPredmet[0] ){
                    echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }else{
                    echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }
                $Indx=$Indx+1;
            }
            echo "</select></td>";

            $result = mysqli_query($link,$SQL);
            echo "<td>2. <select name='izbirni2_".$Indx0."'>";
            $Indx=0;
            if ($IzbraniPredmet[1]==0 ){
                echo "<option value=0 selected='selected'>Ni izbran</option>";
            }else{
                echo "<option value=0>Ni izbran</option>";
            }
            while ($R = mysqli_fetch_array($result)){
                if ($R["Id"]==$IzbraniPredmet[1] ){
                    echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }else{
                    echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }
                $Indx=$Indx+1;
            }
            echo "</select></td>";

            $result = mysqli_query($link,$SQL);
            echo "<td>3. <select name='izbirni3_".$Indx0."'>";
            $Indx=0;
            if ($IzbraniPredmet[2]==0 ){
                echo "<option value=0 selected='selected'>Ni izbran</option>";
            }else{
                echo "<option value=0>Ni izbran</option>";
            }
            while ($R = mysqli_fetch_array($result)){
                if ($R["Id"]==$IzbraniPredmet[2] ){
                    echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }else{
                    echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }
                $Indx=$Indx+1;
            }
            echo "</select></td></tr>";
        }
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";

        echo "<br /><a href='izbirniskupine.php?id=1&solskoleto=".$VLeto."'>Na izbor razreda</a><br />";
        echo "<br /><a href='prijava.php'>Na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "2a": //dodaj neobvezne izbirne - razred
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM TabRazDat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<select name='razred' onchange='this.form.submit()'>";
        echo "<option value='0'>Ni izbran</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "<input name='id' type='hidden' value='2a'>";
        //echo "<input name='submitform' type='button' value='Pošlji' onclick='this.form.submit()'>";
        //echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";

        $SQL = "SELECT tabrazred.*, tabucenci.*,TabRazDat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred;
        $SQL = $SQL ." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        //izpis razrednih podatkov
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx][0] = $R["IdUcenec"];
            $Ucenci[$Indx][1] = $R["Priimek"]." ".$R["Ime"];
            $Ucenci[$Indx][2] = $R["razred"];
            $Ucenci[$Indx][3] = $R["oznaka"];
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
            $Indx = $Indx+1;
        } 
        $StUcencev=$Indx-1;

        echo "<h2>Vpis neobveznih izbirnih predmetov učencem ".$VRazred1.". ".$VParalelka."</h2>";
        echo "<form  name='DodajIzbirni' method='post' action='izbirniskupine.php'>";
        echo "<input name='id' type='hidden' value='3a'>";
        echo "<table border='1'>";
        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";

        for ($Indx0=0;$Indx0 <= $StUcencev;$Indx0++){
            echo "<tr><td>".($Indx0+1)."</td>";
            echo "<td>".$VLeto."/".($VLeto+1)."</td>";
            echo "<td><input type='hidden' name='ime".$Indx0."' value='".$Ucenci[$Indx0][0]."'>".$Ucenci[$Indx0][1]."</td>";

            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $SQL = "SELECT tabpredmeti.id FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni ";
            $SQL = $SQL . "WHERE tabizbirni.Ucenec=" .$Ucenci[$Indx0][0] . " AND leto=".$VLeto." AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY leto DESC";
            $result = mysqli_query($link,$SQL);

            $IndxIzb=0;
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $IzbraniPredmet[$IndxIzb]=$R["id"];
                $IndxIzb=$IndxIzb+1;
                $Indx = $Indx+1;
            } 

            $SQL = "SELECT * FROM tabpredmeti WHERE Prioriteta = 1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY Opis";
            $result = mysqli_query($link,$SQL);

            echo "<td>1. <select name='izbirni1_".$Indx0."'>";
            $Indx=0;
            if ($IzbraniPredmet[0]==0 ){
                echo "<option value=0 selected>Ni izbran</option>";
            }else{
                echo "<option value=0>Ni izbran</option>";
            }
            while ($R = mysqli_fetch_array($result)){
                if ($R["Id"]==$IzbraniPredmet[0] ){
                    echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }else{
                    echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                }
                $Indx=$Indx+1;
            }
            echo "</select></td>";
            
            if ($StNeobveznihIzbirnih > 1){
                $result = mysqli_query($link,$SQL);
                echo "<td>2. <select name='izbirni2_".$Indx0."'>";
                $Indx=0;
                if ($IzbraniPredmet[1]==0 ){
                    echo "<option value=0 selected='selected'>Ni izbran</option>";
                }else{
                    echo "<option value=0>Ni izbran</option>";
                }
                while ($R = mysqli_fetch_array($result)){
                    if ($R["Id"]==$IzbraniPredmet[1] ){
                        echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                    }else{
                        echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
                echo "</select></td>";
            }
            
            if ($StNeobveznihIzbirnih > 2){
                $result = mysqli_query($link,$SQL);
                echo "<td>3. <select name='izbirni3_".$Indx0."'>";
                $Indx=0;
                if ($IzbraniPredmet[2]==0 ){
                    echo "<option value=0 selected='selected'>Ni izbran</option>";
                }else{
                    echo "<option value=0>Ni izbran</option>";
                }
                while ($R = mysqli_fetch_array($result)){
                    if ($R["Id"]==$IzbraniPredmet[2] ){
                        echo "<option value=".$R["Id"]." selected='selected'>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                    }else{
                        echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
                echo "</select></td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";

        echo "<br /><a href='izbirniskupine.php?id=1a&solskoleto=".$VLeto."'>Na izbor razreda</a><br />";
        echo "<br /><a href='prijava.php'>Na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "3": // vpis izbirnega - razred
        $StUcencev=$_POST["stucencev"];
        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $Ucenci[$Indx]= $_POST["ime".$Indx];
            $VIzbirni[$Indx][0]= $_POST["izbirni1_".$Indx];
            $VIzbirni[$Indx][1]= $_POST["izbirni2_".$Indx];
            $VIzbirni[$Indx][2]= $_POST["izbirni3_".$Indx];
        }

        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $SQL = "SELECT tabizbirni.id FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE tabizbirni.leto=".$VLeto." AND tabizbirni.Ucenec=".$Ucenci[$Indx]." AND tabpredmeti.OpisMSS LIKE '%/i/%'";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                $SQL = "DELETE FROM tabizbirni WHERE id=".$R["id"];
                $result1 = mysqli_query($link,$SQL);
            }

            if ($VIzbirni[$Indx][0] > 0 ){
                $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][0] .")";
                $result = mysqli_query($link,$SQL);
            }
            if ($VIzbirni[$Indx][1] > 0 ){
                $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][1] .")";
                $result = mysqli_query($link,$SQL);
            }
            if ($VIzbirni[$Indx][2] > 0 ){
                $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][2] .")";
                $result = mysqli_query($link,$SQL);
            }
        }
        header ("Location: izbirniskupine.php?id=2&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "3a": // vpis izbirnega - razred
        $StUcencev=$_POST["stucencev"];
        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $Ucenci[$Indx]= $_POST["ime".$Indx];
            $VIzbirni[$Indx][0]= $_POST["izbirni1_".$Indx];
            if ($StNeobveznihIzbirnih > 1){
                $VIzbirni[$Indx][1]= $_POST["izbirni2_".$Indx];
            }
            if ($StNeobveznihIzbirnih > 2){
                $VIzbirni[$Indx][2]= $_POST["izbirni3_".$Indx];
            }
        }

        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $SQL = "SELECT tabizbirni.id FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE tabizbirni.leto=".$VLeto." AND tabizbirni.Ucenec=".$Ucenci[$Indx]." AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                $SQL = "DELETE FROM tabizbirni WHERE id=".$R["id"];
                $result1 = mysqli_query($link,$SQL);
            }

            if ($VIzbirni[$Indx][0] > 0 ){
                $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][0] .")";
                $result = mysqli_query($link,$SQL);
            }
            if ($StNeobveznihIzbirnih > 1){
                if ($VIzbirni[$Indx][1] > 0 ){
                    $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][1] .")";
                    $result = mysqli_query($link,$SQL);
                }
            }
            if ($StNeobveznihIzbirnih > 2){
                if ($VIzbirni[$Indx][2] > 0 ){
                    $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $Ucenci[$Indx] .",". $VIzbirni[$Indx][2] .")";
                    $result = mysqli_query($link,$SQL);
                }
            }
        }
        header ("Location: izbirniskupine.php?id=2a&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "4": //dodaj izbirne - posamično
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "<h2>Vpis izbirnih predmetov učencem</h2>";
        echo "<form  name='DodajIzbirni' method=post action='izbirniskupine.php'>";
        echo "<input name='id' type='hidden' value='5'>";
        echo "<table>";

        if (isset($_POST["ucenec"])){
            $ZaObdelavo = $_POST["ucenec"];
        }else{
            if (isset($_GET["ucenec"])){
                $ZaObdelavo=$_GET["ucenec"];
            }else{
                $VZaObdelavo = 0;
            }
        }
        
        if ($ZaObdelavo > 0 ){
            $SQL = "SELECT tabrazred.*, tabucenci.*,tabrazdat.*,tabsola.solakratko FROM ";
            $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL = $SQL . "WHERE tabucenci.IdUcenec=".$ZaObdelavo." AND tabrazdat.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        }else{
            $SQL = "SELECT tabrazred.*, tabucenci.*,tabrazdat.* FROM ";
            $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL = $SQL . "WHERE tabrazdat.razred >=7 AND tabrazdat.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        }
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Leto:</td><td><input name='leto' type='hidden' value='".$VLeto."'>".$VLeto."/".($VLeto+1)."</td></tr>";
        echo "<tr><td>Učenec:</td><td><select name='ime'>";
        if ($ZaObdelavo==0 ){
            echo "<option selected value=0>Ni izbran</option>";    
        }
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ZaObdelavo ){
                    echo "<option selected='selected' value=".$R["IdUcenec"].">".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ". $R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value=".$R["IdUcenec"].">".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ". $R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
            } 
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ZaObdelavo ){
                    echo "<option selected='selected' value=".$R["IdUcenec"].">".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ". $R["oznaka"]."</option>";
                }else{
                    echo "<option value=".$R["IdUcenec"].">".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ". $R["oznaka"]."</option>";
                }
            } 
        }
        echo "</select></td></tr>";

        if ($ZaObdelavo==0 ){
            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
        }else{
            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $SQL = "SELECT tabpredmeti.id FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni ";
            $SQL = $SQL . "WHERE tabizbirni.Ucenec=" .$ZaObdelavo . " AND leto=".$VLeto." AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY leto DESC";
            $result = mysqli_query($link,$SQL);

            $IndxIzb=0;
            while ($R = mysqli_fetch_array($result)){
                $IzbraniPredmet[$IndxIzb]=$R["id"];
                $IndxIzb=$IndxIzb+1;
            } 
        }
        //echo "Izbirni predmeti: ";
        $SQL = "SELECT * FROM tabpredmeti WHERE Prioriteta = 1 ORDER BY Opis";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>1. </td><td><select name='izbirni1'>";
        $Indx=0;
        if ($IzbraniPredmet[0]==0 ){
            echo "<option value=0 selected='selected'>Ni izbran</option>";
        }else{
            echo "<option value=0>Ni izbran</option>";
        }
        while ($R = mysqli_fetch_array($result)){
            if ($R["Id"]==$IzbraniPredmet[0] ){
                echo "<option value=".$R["Id"]." selected>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }else{
                echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }
            $Indx=$Indx+1;
        }
        echo "</select></td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>2. </td><td><select name='izbirni2'>";
        $Indx=0;
        if ($IzbraniPredmet[1]==0 ){
            echo "<option value=0 selected='selected'>Ni izbran</option>";
        }else{
            echo "<option value=0>Ni izbran</option>";
        }
        while ($R = mysqli_fetch_array($result)){
            if ($R["Id"]==$IzbraniPredmet[1] ){
                echo "<option value=".$R["Id"]." selected>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }else{
                echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }
            $Indx=$Indx+1;
        }
        echo "</select></td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>3. </td><td><select name='izbirni3'>";
        $Indx=0;
        if ($IzbraniPredmet[2]==0 ){
            echo "<option value=0 selected='selected'>Ni izbran</option>";
        }else{
            echo "<option value=0>Ni izbran</option>";
        }
        while ($R = mysqli_fetch_array($result)){
            if ($R["Id"]==$IzbraniPredmet[2] ){
                echo "<option value=".$R["Id"]." selected>".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }else{
                echo "<option value=".$R["Id"].">".$R["Oznaka"]." - ".$R["Opis"]."</option>";
            }
            $Indx=$Indx+1;
        }
        echo "</select></td></tr>";
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";

        if ($ZaObdelavo > 0 ){
            echo "<br /><a href='ucenec_pregled.php?ucenec=".$ZaObdelavo."&solskoleto=".$VLeto."'>Na pregled učenca</a><br />";
        }
        echo "<br /><a href='izbirniskupine.php?id=6&solskoleto=".$VLeto."'>Izpis izbirnih</a><br />";
        echo "<br /><a href='prijava.php'>Na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
    
        break;
    case "5": //vpis izbirnega
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        $VIme= $_POST["ime"];
        $VIzbirni[0]= $_POST["izbirni1"];
        $VIzbirni[1]= $_POST["izbirni2"];
        $VIzbirni[2]= $_POST["izbirni3"];

        if ($VIme==0 ){
            header ("Location: izbirniskupine.php?id=1&solskoleto=".$VLeto."&razred=".$VRazred);
        }

        $SQL = "SELECT tabizbirni.id FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE tabizbirni.leto=".$VLeto." AND tabizbirni.Ucenec=".$VIme." AND tabpredmeti.OpisMSS LIKE '%/i/%'";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            $SQL = "DELETE FROM tabizbirni WHERE id=".$R["id"];
            if (!($result1 = mysqli_query($link,$SQL))){
                die("Napaka pri brisanju izbirnih predmetov! <br />$SQL<br />");
            }
        }

        if ($VIzbirni[0] > 0 ){
            $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $VIme .",". $VIzbirni[0] .")";
            $result = mysqli_query($link,$SQL);
        }
        if ($VIzbirni[1] > 0 ){
            $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $VIme .",". $VIzbirni[1] .")";
            $result = mysqli_query($link,$SQL);
        }
        if ($VIzbirni[2] > 0 ){
            $SQL = "INSERT INTO tabizbirni (Leto,Ucenec,Izbirni) values (" . $VLeto . "," . $VIme .",". $VIzbirni[2] .")";
            $result = mysqli_query($link,$SQL);
        }

        header ("Location: ucenec_pregled.php?ucenec=".$VIme."&solskoleto=".$VLeto);
        echo "</body>";
        echo "</html>";
        break;
    case "6": //izpis izbirnih
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "<a href='#izbirni'>Izbirni predmeti</a><br />";
        echo "<a href='#razredi'>Izbirni predmeti - rezredi</a><br />";
        echo "<a href='#poucencih'>Izbirni predmeti - po učencih</a><br />";
        //echo "<a href='#niistocasni'>Predmeti, ki ne morejo biti istočasno</a><br />";
        //echo "<a href='#mozniistocasni'>Možni istočasni predmeti</a><br />";

        echo "<a name='ucitelji'><h2>Učitelji izbirnih predmetov - ".$VLeto."/".($VLeto+1)."</h2></a>";

        for ($Indx=0;$Indx <= 100;$Indx++){
            $Izbirni[$Indx][0]="";
            $Izbirni[$Indx][1]="";
            $Izbirni[$Indx][2]="";
        }

        $SQL = "SELECT DISTINCT tabucenje.Predmet,tabucenje.IdUcitelj,tabucenje.Planirano, tabucenje.leto, tabucitelji.Priimek,tabucitelji.Ime,tabpredmeti.Oznaka,tabpredmeti.Opis FROM ";
        $SQL = $SQL . "(tabucenje INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.Id ";
        $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabpredmeti.Oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=lightcyan><th>N</th><th>Leto</th><th>Predmet</th><th>Ucitelj</th><th>Ure</th></tr>";

        $ColorChange=true;
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($ColorChange ){
                echo "<tr bgcolor=lightyellow>";
            }else{
                echo "<tr bgcolor=#FFFFCC>";
            }
            $ColorChange=!$ColorChange;
            echo "<td>".$Indx."</td><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td><td><font color=darkblue>".$R["Priimek"].", ".$R["Ime"]."</font></td><td>".$R["Planirano"]."</td>";
            echo "</tr>";
            $Izbirni[$Indx][0]=$R["Oznaka"];
            $Izbirni[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
            $Indx=$Indx+1;
        }
        $StIzbirnih=$Indx-1;

        echo "</table>";

        $SQL = "SELECT DISTINCT tabucenje.Predmet,tabucenje.IdUcitelj,tabucenje.Planirano, tabizbirni.leto, tabucitelji.Priimek,tabucitelji.Ime,tabpredmeti.Oznaka FROM ";
        $SQL = $SQL . "(((tabucenje INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabizbirni ON tabucenje.leto=tabizbirni.leto) ";
//        $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id) ";
//        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabucitelji.Id";
        $result = mysqli_query($link,$SQL);

        $Indx1=0;
        $Indx0=0;
        $PoUciteljih="";
        while ($R = mysqli_fetch_array($result)){
            if ($PoUciteljih != $R["Priimek"].", ".$R["Ime"] ){
                $PoUciteljih=$R["Priimek"].", ".$R["Ime"];
                $Indx1=$Indx1+1;
                $Indx0=1;
                $IzbirniPoUciteljih[$Indx1][0]=$R["Priimek"].", ".$R["Ime"];
                $IzbirniPoUciteljih[$Indx1][$Indx0]=$R["Oznaka"];
            }else{
                $IzbirniPoUciteljih[$Indx1][$Indx0]=$R["Oznaka"];
            }
            $Indx0=$Indx0+1;
        }
        $StUciteljev=$Indx1;

        echo "<a name='izbirni'><h2>Izbirni predmeti</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis, tabucenci.priimek,tabucenci.ime,tabrazdat.leto,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1  AND tabpredmeti.OpisMSS LIKE '%/i/%' ";
        $SQL = $SQL . " ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Predmet</th><th>N</th><th>Ucenec</th></tr>";
        $ColorChange=true;
        $PredmetIzbirni="";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"]){
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                    }
                    $ColorChange=!$ColorChange;
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td><td></td>";
                    $ColorChange=false;
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"]){
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                    }
                    $ColorChange=!$ColorChange;
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td><td></td>";
                    $ColorChange=false;
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov z razredi - zacetek

        echo "<a name='razredi'><h2>Izbirni predmeti - razredi</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis, tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ";
        $SQL = $SQL . " ORDER BY tabpredmeti.Oznaka,tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Predmet</th><th>Razred</th></tr>";

        $ColorChange=true;
        $PredmetIzbirni="";
        $RazredComp=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"] ){
                    if ($RazredComp != $R["id"]){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $RazredComp=$R["id"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"] ){
                    if ($RazredComp != $R["id"]){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $RazredComp=$R["id"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov z razredi - konec

        //'Izpis izbirnih predmetov po razredih - zacetek

        echo "<a name='porazredih'><h2>Izbirni predmeti po razredih</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis, tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ";
        $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.Oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Razred</th><th>Predmet</th></tr>";
        $ColorChange=true;
        $PredmetIzbirni="";
        $RazredComp=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp == $R["id"]){
                    if ($PredmetIzbirni != $R["Oznaka"]." - ".$R["Opis"] ){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp == $R["id"]){
                    if ($PredmetIzbirni != $R["Oznaka"]." - ".$R["Opis"] ){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["razred"].". ".$R["oznaka"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov po razredih - konec

        for ($Indx=0;$Indx <= 1000;$Indx++){
            $UcIzbirni[$Indx][0]=0;
            $UcIzbirni[$Indx][1]="";
            $UcIzbirni[$Indx][2]="";
            $UcIzbirni[$Indx][4]="";
            $UcIzbirni[$Indx][5]="";
            $UcIzbirni[$Indx][6]="";
            $UcIzbirni[$Indx][7]="";
            $UcIzbirni[$Indx][8]="";
            $UcIzbirni[$Indx][9]="";
            $UcIzbirni[$Indx][10]="";
        }

        echo "<a name='poucencih'><h2>Izbirni predmeti po učencih</h2></a>";

        $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime, tabpredmeti.Oznaka,tabpredmeti.Opis,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
        $SQL = $SQL . "LEFT JOIN tabizbirni ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "LEFT JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id) ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/i/%' ";
        $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazdat.Razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>N</th><th>Leto</th><th>Ucenec</th><th>Predmet 1</th><th>Predmet 2</th><th>Predmet 3</th></tr><tr bgcolor=lightyellow>";

        $ColorChange=true;
        $UcenecIzbirni="";
        $IndxUcIzb=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $IndxIzb=$IndxIzb+1;
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }else{
                    echo "</tr>";
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td>".$Indx."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td>".$Indx."</td>";
                    }
                    $ColorChange=!$ColorChange;
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izbirniskupine.php?id=4&ucenec=".$R["IdUcenec"]."&razred=".$R["id"]."&solskoleto=".$VLeto."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</a></td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                    $IndxUcIzb=$IndxUcIzb+1;
                    $IndxIzb=1;
                    $UcIzbirni[$IndxUcIzb][0]=$R["IdUcenec"];
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $IndxIzb=$IndxIzb+1;
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }else{
                    echo "</tr>";
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td>".$Indx."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td>".$Indx."</td>";
                    }
                    $ColorChange=!$ColorChange;
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izbirniskupine.php?id=4&ucenec=".$R["IdUcenec"]."&razred=".$R["id"]."&solskoleto=".$VLeto."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</a></td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                    $IndxUcIzb=$IndxUcIzb+1;
                    $IndxIzb=1;
                    $UcIzbirni[$IndxUcIzb][0]=$R["IdUcenec"];
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }
            }
        }
        $StUcencev=$IndxUcIzb;
        echo "</table><br />";

        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
 case "6ni": //izpis neobveznih izbirnih

        echo "<a href='#izbirni'>Neobvezni izbirni predmeti</a><br />";
        echo "<a href='#razredi'>Neobvezni izbirni predmeti - rezredi</a><br />";
        echo "<a href='#poucencih'>Neobvezni izbirni predmeti - po učencih</a><br />";
        //echo "<a href='#niistocasni'>Predmeti, ki ne morejo biti istočasno</a><br />";
        //echo "<a href='#mozniistocasni'>Možni istočasni predmeti</a><br />";

        echo "<a name='ucitelji'><h2>Učitelji neobveznih izbirnih predmetov - ".$VLeto."/".($VLeto+1)."</h2></a>";

        for ($Indx=0;$Indx <= 100;$Indx++){
            $Izbirni[$Indx][0]="";
            $Izbirni[$Indx][1]="";
            $Izbirni[$Indx][2]="";
        }

        $SQL = "SELECT DISTINCT tabucenje.Predmet,tabucenje.IdUcitelj,tabucenje.Planirano, tabucenje.leto, tabucitelji.Priimek,tabucitelji.Ime,tabpredmeti.Oznaka,tabpredmeti.Opis FROM ";
        $SQL = $SQL . "(tabucenje INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.Id ";
        $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabpredmeti.Oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=lightcyan><th>N</th><th>Leto</th><th>Predmet</th><th>Ucitelj</th><th>Ure</th></tr>";

        $ColorChange=true;
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($ColorChange ){
                echo "<tr bgcolor=lightyellow>";
            }else{
                echo "<tr bgcolor=#FFFFCC>";
            }
            $ColorChange=!$ColorChange;
            echo "<td>".$Indx."</td><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td><td><font color=darkblue>".$R["Priimek"].", ".$R["Ime"]."</font></td><td>".$R["Planirano"]."</td>";
            echo "</tr>";
            $Izbirni[$Indx][0]=$R["Oznaka"];
            $Izbirni[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
            $Indx=$Indx+1;
        }
        $StIzbirnih=$Indx-1;

        echo "</table>";

        $SQL = "SELECT DISTINCT tabucenje.Predmet,tabucenje.IdUcitelj,tabucenje.Planirano, tabizbirni.leto, tabucitelji.Priimek,tabucitelji.Ime,tabpredmeti.Oznaka FROM ";
        $SQL = $SQL . "(((tabucenje INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabizbirni ON tabucenje.leto=tabizbirni.leto) ";
//        $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id) ";
//        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabucitelji.Id";
        $result = mysqli_query($link,$SQL);

        $Indx1=0;
        $Indx0=0;
        $PoUciteljih="";
        while ($R = mysqli_fetch_array($result)){
            if ($PoUciteljih != $R["Priimek"].", ".$R["Ime"] ){
                $PoUciteljih=$R["Priimek"].", ".$R["Ime"];
                $Indx1=$Indx1+1;
                $Indx0=1;
                $IzbirniPoUciteljih[$Indx1][0]=$R["Priimek"].", ".$R["Ime"];
                $IzbirniPoUciteljih[$Indx1][$Indx0]=$R["Oznaka"];
            }else{
                $IzbirniPoUciteljih[$Indx1][$Indx0]=$R["Oznaka"];
            }
            $Indx0=$Indx0+1;
        }
        $StUciteljev=$Indx1;

        echo "<a name='izbirni'><h2>Neobvezni izbirni predmeti</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.leto,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1  AND tabpredmeti.OpisMSS LIKE '%/ni/%' ";
        $SQL = $SQL . " ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Predmet</th><th>N</th><th>Učenec</th><th>PB</th></tr>";
        $ColorChange=true;
        $PredmetIzbirni="";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"]){
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                    }
                    $SQL = "SELECT * FROM tabopb WHERE leto=$VLeto AND iducenec=".$R["iducenec"];
                    $result1 = mysqli_query($link,$SQL);
                    echo "<td>";
                    if ($R1 = mysqli_fetch_array($result1)){
                        for ($i=1;$i <= 15;$i++){
                            if ($R1["pb$i"]){
                                echo "PB$i";
                            }
                        }
                    }
                    echo "</td>";
                    $ColorChange=!$ColorChange;
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td><td></td><td></td></tr>";
                    $ColorChange=false;
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";

                    $SQL = "SELECT * FROM tabopb WHERE leto=$VLeto AND iducenec=".$R["iducenec"];
                    $result1 = mysqli_query($link,$SQL);
                    echo "<td>";
                    if ($R1 = mysqli_fetch_array($result1)){
                        for ($i=1;$i <= 15;$i++){
                            if ($R1["pb$i"]){
                                echo "PB$i";
                            }
                        }
                    }
                    echo "</td>";

                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"]){
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    }
                    $SQL = "SELECT * FROM tabopb WHERE leto=$VLeto AND iducenec=".$R["iducenec"];
                    $result1 = mysqli_query($link,$SQL);
                    echo "<td>";
                    if ($R1 = mysqli_fetch_array($result1)){
                        for ($i=1;$i <= 15;$i++){
                            if ($R1["pb$i"]){
                                echo "PB$i";
                            }
                        }
                    }
                    echo "</td>";

                    $ColorChange=!$ColorChange;
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td><td></td><td></td></tr>";
                    $ColorChange=false;
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td></td><td></td><td>".$Indx."</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    $SQL = "SELECT * FROM tabopb WHERE leto=$VLeto AND iducenec=".$R["iducenec"];
                    $result1 = mysqli_query($link,$SQL);
                    echo "<td>";
                    if ($R1 = mysqli_fetch_array($result1)){
                        for ($i=1;$i <= 15;$i++){
                            if ($R1["pb$i"]){
                                echo "PB$i";
                            }
                        }
                    }
                    echo "</td>";

                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov z razredi - zacetek

        echo "<a name='razredi'><h2>Neobvezni izbirni predmeti - razredi</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis, tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ";
        $SQL = $SQL . " ORDER BY tabpredmeti.Oznaka,tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Predmet</th><th>Razred</th></tr>";

        $ColorChange=true;
        $PredmetIzbirni="";
        $RazredComp=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"] ){
                    if ($RazredComp != $R["id"]){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $RazredComp=$R["id"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == $R["Oznaka"]." - ".$R["Opis"] ){
                    if ($RazredComp != $R["id"]){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $RazredComp=$R["id"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov z razredi - konec

        //'Izpis izbirnih predmetov po razredih - zacetek

        echo "<a name='porazredih'><h2>Neobvezni izbirni predmeti po razredih</h2></a>";

        $SQL = "SELECT tabpredmeti.Oznaka,tabpredmeti.Opis, tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "((((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ";
        $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.Oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>Leto</th><th>Razred</th><th>Predmet</th></tr>";
        $ColorChange=true;
        $PredmetIzbirni="";
        $RazredComp=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp == $R["id"]){
                    if ($PredmetIzbirni != $R["Oznaka"]." - ".$R["Opis"] ){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp == $R["id"]){
                    if ($PredmetIzbirni != $R["Oznaka"]." - ".$R["Opis"] ){
                        if ($ColorChange ){
                            echo "<tr bgcolor=lightyellow><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC><td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                        }
                        $ColorChange=!$ColorChange;
                        $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                    }
                }else{
                    $Indx=1;
                    echo "<tr bgcolor=lightcyan>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["razred"].". ".$R["oznaka"]."</td><td></td>";
                    echo "<tr bgcolor=lightyellow>";
                    $ColorChange=false;
                    echo "<td></td><td></td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                    $RazredComp=$R["id"];
                    $PredmetIzbirni = $R["Oznaka"]." - ".$R["Opis"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";

        //'Izpis izbirnih predmetov po razredih - konec

        for ($Indx=0;$Indx <= 1000;$Indx++){
            $UcIzbirni[$Indx][0]=0;
            $UcIzbirni[$Indx][1]="";
            $UcIzbirni[$Indx][2]="";
            $UcIzbirni[$Indx][4]="";
            $UcIzbirni[$Indx][5]="";
            $UcIzbirni[$Indx][6]="";
            $UcIzbirni[$Indx][7]="";
            $UcIzbirni[$Indx][8]="";
            $UcIzbirni[$Indx][9]="";
            $UcIzbirni[$Indx][10]="";
        }

        echo "<a name='poucencih'><h2>Neobvezni izbirni predmeti po učencih</h2></a>";

        $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime, tabpredmeti.Oznaka,tabpredmeti.Opis,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
        $SQL = $SQL . "LEFT JOIN tabizbirni ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "LEFT JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id) ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.OpisMSS LIKE '%/ni/%' ";
        $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazdat.Razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>N</th><th>Leto</th><th>Ucenec</th><th>Predmet 1</th></tr><tr bgcolor=lightyellow>";

        $ColorChange=true;
        $UcenecIzbirni="";
        $IndxUcIzb=0;
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $IndxIzb=$IndxIzb+1;
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }else{
                    echo "</tr>";
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td>".$Indx."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td>".$Indx."</td>";
                    }
                    $ColorChange=!$ColorChange;
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izbirniskupine.php?id=4&ucenec=".$R["IdUcenec"]."&razred=".$R["id"]."&solskoleto=".$VLeto."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</a></td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                    $IndxUcIzb=$IndxUcIzb+1;
                    $IndxIzb=1;
                    $UcIzbirni[$IndxUcIzb][0]=$R["IdUcenec"];
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $IndxIzb=$IndxIzb+1;
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }else{
                    echo "</tr>";
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td>".$Indx."</td>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td>".$Indx."</td>";
                    }
                    $ColorChange=!$ColorChange;
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izbirniskupine.php?id=4&ucenec=".$R["IdUcenec"]."&razred=".$R["id"]."&solskoleto=".$VLeto."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</a></td><td><font color=red>".$R["Oznaka"]."</font> - ".$R["Opis"]."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                    $IndxUcIzb=$IndxUcIzb+1;
                    $IndxIzb=1;
                    $UcIzbirni[$IndxUcIzb][0]=$R["IdUcenec"];
                    $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
                }
            }
        }
        $StUcencev=$IndxUcIzb;
        echo "</table><br />";

        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
           
    case "6a": //izpis izbirnih
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        //echo "<h2>Izbirni predmeti po razredih in učencih</h2></a>";
        
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 6 ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Razred[$Indx][0]=$R["id"];
            $Razred[$Indx][1]=$R["razred"].". ".$R["oznaka"];
            $Razred[$Indx][2]=$R["solakratko"];
            $Indx=$Indx+1;
        }
        $StRazredov=$Indx-1;
        
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            if ($VecSol > 0){
                echo "<h2>Izbirni predmeti za šolsko leto ".$VLeto."/".($VLeto+1).": ".$Razred[$Indx][1]." - ".$Razred[$Indx][2]."</h2>";
            }else{
                echo "<h2>Izbirni predmeti za šolsko leto ".$VLeto."/".($VLeto+1).": ".$Razred[$Indx][1]."</h2>";
            }
            echo "<table border='0' cellspacing='0' cellpadding='3'>";
            echo "<tr><th>Št.</th><th width='200'>Ime</th><th width='170'>Izbirni 1</th><th width='170'>Izbirni 2</th><th width='170'>Izbirni 3</th></tr>";
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
            $SQL = $SQL . "WHERE idrazred=".$Razred[$Indx][0]." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx1=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx1."</td><td>".$R["ime"]." ".$R["priimek"]."</td>";
                $SQL = "SELECT tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                $SQL = $SQL . "WHERE tabizbirni.ucenec=".$R["iducenec"]." AND leto=".$VLeto." ORDER BY tabpredmeti.vrstnired";
                $result1 = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result1) > 0){
                    while ($R1 = mysqli_fetch_array($result1)){
                        switch ($R1["oznaka"]){
                            case "GLŠ":
                            case "MPZ":
                            case "OPZ":
                                echo "<td bgcolor='orange'>".$R1["oznaka"]." - ".$R1["opis"]."</td>";
                                break;
                            default:
                                echo "<td bgcolor='lightgreen'>".$R1["oznaka"]." - ".$R1["opis"]."</td>";
                        }
                    }
                }
                echo "</tr>";
                $Indx1=$Indx1+1;
            }
            echo "</table>";
            echo "<p class='break'>&nbsp;</p>";
        }
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "7": //izpis izbirnih - zgodovina
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        for ($Indx=0;$Indx <= 1000;$Indx++){
            $UcIzbirni[$Indx][0]=0;
            $UcIzbirni[$Indx][1]="";
            $UcIzbirni[$Indx][2]="";
            $UcIzbirni[$Indx][4]="";
            $UcIzbirni[$Indx][5]="";
            $UcIzbirni[$Indx][6]="";
            $UcIzbirni[$Indx][7]="";
            $UcIzbirni[$Indx][8]="";
            $UcIzbirni[$Indx][9]="";
            $UcIzbirni[$Indx][10]="";
        }

        echo "<a name='poucencih'><h2>Izbirni predmeti po učencih - zadnja tri šolska leta</h2></a>";

        $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime, tabpredmeti.Oznaka,tabpredmeti.Opis,tabizbirni.leto FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabucenci.idUcenec=tabizbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.Izbirni=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabizbirni.leto > ".($VLeto-2);
        $SQL = $SQL . " ORDER BY priimek,ime,tabizbirni.leto";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=cyan><th>N</th><th>Ucenec</th><th>P1</th><th>P2</th><th>P3</th><th>P4</th><th>P5</th><th>P6</th><th>P7</th><th>P8</th><th>P9</th></tr><tr bgcolor=lightyellow>";

        $ColorChange=true;
        $UcenecIzbirni="";
        $IndxUcIzb=0;
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                echo "<td>".$R["Oznaka"]."(".substr($R["leto"],2,2).")</td>";
                $IndxIzb=$IndxIzb+1;
                $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
            }else{
                echo "</tr>";
                if ($ColorChange ){
                    echo "<tr bgcolor=lightyellow><td>".$Indx."</td>";
                }else{
                    echo "<tr bgcolor=#FFFFCC><td>".$Indx."</td>";
                }
                $ColorChange=!$ColorChange;
                $Indx=$Indx+1;
                echo "<td><a href='izbirniskupine.php?id=4&ucenec=".$R["IdUcenec"]."'>".$R["Priimek"].", ".$R["Ime"]."</a></td><td>".$R["Oznaka"]."(".substr($R["leto"],2,2).")</td>";
                $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                $IndxUcIzb=$IndxUcIzb+1;
                $IndxIzb=1;
                $UcIzbirni[$IndxUcIzb][0]=$R["IdUcenec"];
                $UcIzbirni[$IndxUcIzb][$IndxIzb]=$R["Oznaka"];
            }
        }
        $StUcencev=$IndxUcIzb;
        echo "</table><br />";

        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "8": //briši izbirni

        $VZapis = $_GET["zapis"];
        $ucenec = $_GET["ucenec"];

        $SQL = "DELETE FROM tabizbirni WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        echo "<br />Izbirni predmet je bil izbrisan!<br />";

        $SQL = "SELECT tabizbirni.*,tabucenci.Priimek,tabucenci.Ime,tabpredmeti.Oznaka,tabpredmeti.Opis FROM (tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni WHERE tabizbirni.Ucenec=" .$ucenec . " ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br />Izbirni predmeti: ";
        echo "<br /><a href='izbirniskupine.php?id=4&ucenec=".$ucenec."&razred=".$VRazred."&solskoleto=".$VLeto."'>Dodaj izbirne predmete</a>";
        echo "<br /><table border=1>";
        echo "<th>Leto</th><th>Učenec</th><th>Izbirni predmet</th><th>Briši</th>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td><td>".$R["Priimek"].", ".$R["Ime"]."</td><td>".$R["Oznaka"]." - ".$R["Opis"]."</td><td><a href='izbirniskupine.php?id=8&zapis=".$R["Id"]."&ucenec=".$R["Ucenec"]."'>Briši</a></td></tr>";
            $Indx = $Indx+1;
        } 
        echo "</table><br />";

        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "9": //spiski izbirni PDF
        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        //$pdf->AddPage("P","A4");

        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
        
        for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
            
            $SQL = "SELECT * FROM TabSola WHERE id=".$sole[$IndxSola][0];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VNaslov=$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola="";
                $VNaslov="";
                $VRavnatelj="";
                $VKraj="";
            }

            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }

            $SQL = "SELECT DISTINCT tabucitelji.Priimek,tabucitelji.Ime,tabpredmeti.id FROM ";
            $SQL = $SQL . "(((tabucenje INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.Id) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id) ";
            $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabrazdat.idsola=".$sole[$IndxSola][0]." ORDER BY tabpredmeti.Oznaka";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                $IzbirniPredmet[$R["id"]]=$R["Priimek"]." ".$R["Ime"];
            }

            $SQL = "SELECT tabpredmeti.*, tabucenci.Priimek,tabucenci.Ime,tabrazdat.razred,tabrazdat.oznaka FROM ";
            $SQL = $SQL."(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
            $SQL = $SQL."INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL."INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL."WHERE tabizbirni.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabrazdat.idsola=".$sole[$IndxSola][0];
            $SQL = $SQL." ORDER BY tabpredmeti.Oznaka,tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            $CompPredmet=0;
            $VStran=0;
            $Indx1=0;
            $Indx=1;
            $XPoz[1]=15;
            $XPoz[2]=125;
            $YPoz=90;
            while ($R = mysqli_fetch_array($result)){
                if ($CompPredmet != $R["Id"] ){
                    $CompPredmet=$R["Id"];
                    $Indx1=0;
                    $Indx=1;
                    $CountUc=1;
                    
                    if ($VStran > 0 ){
                        //'noga
                        $pdf->SetFontSize(12);
                        $pdf->SetFont('arial_CE','',12);
                        $txt=ToWin("Ravnatelj/-ica:");
                        $pdf->SetXY(160,267);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY(160,273);
                        $pdf->Cell(0,0,$txt,0,2,"L");

                        $txt=ToWin($VKraj.", ". $PrintDay);
                        $pdf->SetXY(15,273);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }
                    
                    $VStran=$VStran+1;
                    $pdf->AddPage("P","A4");

                    $pdf->Image("logo1.gif",15,10,30);
                    
                    $pdf->SetFont('arialbd_CE','',16);
                    $txt=ToWin($VSola);
                    $pdf->SetXY(55,15);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VNaslov);
                    $pdf->SetXY(55,23);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Izbirni predmeti");
                    $pdf->SetXY(15,50);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                    $pdf->SetXY(15,58);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    
                    $pdf->SetFont('arialbd_CE','',14);
                    $txt=ToWin("Predmet: ".$R["Oznaka"]." - ".$R["Opis"]);
                    $pdf->SetXY(15,70);


                    $pdf->Cell(0,0,$txt,0,2,"L");
				    if (isset($IzbirniPredmet[$R["Id"]])){
					    $txt=ToWin("Učitelj: ".$IzbirniPredmet[$R["Id"]]);
				    }else{
					    $txt=ToWin("Učitelj: ");
				    }
                    $pdf->SetXY(15,77);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin("Učenec/učenka");
                    $pdf->SetXY($XPoz[1],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    $txt=ToWin("Razred");
                    $pdf->SetXY($XPoz[2],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin($CountUc.". ".$R["Priimek"]." ".$R["Ime"]);
                $pdf->SetXY($XPoz[1],$YPoz+$Indx*6);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin($R["razred"].". ".$R["oznaka"]);
                $pdf->SetXY($XPoz[2],$YPoz+$Indx*6);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $CountUc=$CountUc+1;
                $Indx=$Indx+1;
            }
            $pdf->SetFontSize(12);
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Ravnatelj/-ica:");
            $pdf->SetXY(160,267);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(160,273);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($VKraj.", ". $PrintDay);
            $pdf->SetXY(15,273);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }        
        $pdf->Output("izbirni.pdf","D");
        break;
    case "10": //izbor razreda nivoji

        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto </td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "        <input name='vrstaos' type='hidden' value='9'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred'  onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='11'>";
        echo "        <input name='submit1' type='button' value='Pošlji' onclick='this.form.submit()'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "11": //dodaj nivoje - razred
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto </td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "        <input name='vrstaos' type='hidden' value='9'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred DESC,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred == $R["id"]){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred == $R["id"]){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='11'>";
        echo "        <input name='submit1' type='button' value='Izberi' onclick='this.form.submit()'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";

        $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime,tabrazdat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred;
        $SQL = $SQL ." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        //'Izpis razrednih podatkov
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx][0] = $R["IdUcenec"];
            $Ucenci[$Indx][1] = $R["Priimek"]." ".$R["Ime"];
            $Ucenci[$Indx][2] = $R["razred"];
            $Ucenci[$Indx][3] = $R["oznaka"];
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
            $Indx = $Indx+1;
        } 
        $StUcencev=$Indx-1;

        echo "<h2>Vpis izbirnih predmetov učencem ".$VRazred1.". ".$VParalelka."</h2>";
        echo "<form  name='DodajIzbirni' method=post action='izbirniskupine.php'>";
        echo "<table border='1'>";
        echo "<tr><th>Št.</th><th>Leto</th><th>Ime</th><th>MAT <br />1  2  3  4  5  6</th><th>SLO<br />1  2  3  4  5  6</th><th>TJA <br />1  2  3  4  5  6</th></tr>";
        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";

        for ($Indx0=0;$Indx0 <= $StUcencev;$Indx0++){
            echo "<tr><td>".($Indx0+1)."</td>";
            echo "<td>".$VLeto."/".($VLeto+1)."</td>";
            echo "<td><input type='hidden' name='ime".$Indx0."' value='".$Ucenci[$Indx0][0]."'>".$Ucenci[$Indx0][1]."</td>";

            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $SQL = "SELECT tabnivoji.*,tabucenci.* FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabnivoji ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "WHERE tabnivoji.Ucenec=" .$Ucenci[$Indx0][0] . " AND leto=".$VLeto." ORDER BY ucenec,nivoji";
            $result = mysqli_query($link,$SQL);

            $IndxIzb=0;
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                switch ( $R["Nivoji"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 13:
                    case 14:
                    case 15:
                        $IzbraniPredmet[0]=$R["Nivoji"];
                        break;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 16:
                    case 17:
                    case 18:
                        $IzbraniPredmet[1]=$R["Nivoji"];
                        break;
                    case 9:
                    case 10:
                    case 11:
                    case 12:
                    case 19:
                    case 20:
                    case 21:
                        $IzbraniPredmet[2]=$R["Nivoji"];
                }
                $Indx = $Indx+1;
            } 

            switch ( $IzbraniPredmet[0]){
                case 0:
                case 1:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 2:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1' checked><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 3:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2' checked><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 4:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3' checked><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 13:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4' checked><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 14:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5' checked><input name='npr".$Indx0."_1' type='radio' value='6'></td>";
                    break;
                case 15:
                    echo "<td><input name='npr".$Indx0."_1' type='radio' value='1'><input name='npr".$Indx0."_1' type='radio' value='2'><input name='npr".$Indx0."_1' type='radio' value='3'><input name='npr".$Indx0."_1' type='radio' value='4'><input name='npr".$Indx0."_1' type='radio' value='5'><input name='npr".$Indx0."_1' type='radio' value='6' checked></td>";
            }
            switch ( $IzbraniPredmet[1]){
                case 0:
                case 5:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 6:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1' checked><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 7:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2' checked><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 8:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3' checked><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 16:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4' checked><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 17:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5' checked><input name='npr".$Indx0."_2' type='radio' value='6'></td>";
                    break;
                case 18:
                    echo "<td><input name='npr".$Indx0."_2' type='radio' value='1'><input name='npr".$Indx0."_2' type='radio' value='2'><input name='npr".$Indx0."_2' type='radio' value='3'><input name='npr".$Indx0."_2' type='radio' value='4'><input name='npr".$Indx0."_2' type='radio' value='5'><input name='npr".$Indx0."_2' type='radio' value='6' checked></td>";
            }
            switch ( $IzbraniPredmet[2]){
                case 0:
                case 9:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 10:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1' checked><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 11:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2' checked><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 12:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3' checked><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 19:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4' checked><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 20:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5' checked><input name='npr".$Indx0."_3' type='radio' value='6'></td>";
                    break;
                case 21:
                    echo "<td><input name='npr".$Indx0."_3' type='radio' value='1'><input name='npr".$Indx0."_3' type='radio' value='2'><input name='npr".$Indx0."_3' type='radio' value='3'><input name='npr".$Indx0."_3' type='radio' value='4'><input name='npr".$Indx0."_3' type='radio' value='5'><input name='npr".$Indx0."_3' type='radio' value='6' checked></td>";
            }
            
        }
        echo "</table>";
        echo "<input name='id' type='hidden' value='12'>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";

        //echo "<br /><a href='prijava.php'>Na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "12": //vpis nivojev - razred
        $StUcencev=$_POST["stucencev"];
        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $Ucenci[$Indx]= $_POST["ime".$Indx];
            if (isset($_POST["npr".$Indx."_1"])){
                $VIzbirni[$Indx][0]= $_POST["npr".$Indx."_1"];
            }else{
                $VIzbirni[$Indx][0]="0";
            }
            if (isset($_POST["npr".$Indx."_2"])){
                $VIzbirni[$Indx][1]= $_POST["npr".$Indx."_2"];
            }else{
                $VIzbirni[$Indx][1]="0";
            }
            if (isset($_POST["npr".$Indx."_3"])){
                $VIzbirni[$Indx][2]= $_POST["npr".$Indx."_3"];
            }else{
                $VIzbirni[$Indx][2]="0";
            }
        }

        for ($Indx=0;$Indx <= $StUcencev;$Indx++){
            $SQL = "SELECT * FROM tabnivoji WHERE leto=".$VLeto." AND Ucenec=".$Ucenci[$Indx];
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $SQL = "DELETE FROM tabnivoji WHERE leto=".$VLeto." AND Ucenec=".$Ucenci[$Indx];
                $result = mysqli_query($link,$SQL);
            }

            switch ( $VIzbirni[$Indx][0]){
                case "1":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",2,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "2":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",3,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "3":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",4,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "4":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",13,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "5":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",14,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "6":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",15,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                default:
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",1,'".$Danes->format('Y-m-d H:i:s')."')";
            }
            $result = mysqli_query($link,$SQL);
            switch ( $VIzbirni[$Indx][1]){
                case "1":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",6,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "2":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",7,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "3":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",8,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "4":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",16,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "5":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",17,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "6":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",18,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                default:
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",5,'".$Danes->format('Y-m-d H:i:s')."')";
            }
            $result = mysqli_query($link,$SQL);
            switch ( $VIzbirni[$Indx][2]){
                case "1":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",10,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "2":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",11,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "3":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",12,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "4":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",19,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "5":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",20,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                case "6":
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",21,'".$Danes->format('Y-m-d H:i:s')."')";
                    break;
                default:
                    $SQL = "INSERT INTO tabnivoji (Leto,Ucenec,Nivoji,datum) values (" . $VLeto . "," . $Ucenci[$Indx] .",9,'".$Danes->format('Y-m-d H:i:s')."')";
            }
            $result = mysqli_query($link,$SQL);
        }
        header ("Location: izbirniskupine.php?id=11&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "13": //izpis nivojev
        echo "<h2>Nivojski predmeti/skupine</h2>";

        $SQL = "SELECT tabnivoji.Nivoji,tabucenci.Priimek,tabucenci.Ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "(((tabnivoji INNER JOIN tabucenci ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabnivoji.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabnivoji.leto=".$VLeto." AND tabrazdat.leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tabrazdat.idsola,tabrazdat.Razred,nivoji,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1>";

        $PredmetIzbirni="";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == ToNivojski($R["Nivoji"]).$R["razred"]){
                    echo "<tr><td align='center'>".$Indx."</td><td>".$R["Priimek"]." ".$R["Ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                }else{
                    $Indx=1;
                    echo "</table>";
                    echo "<h2>".$R["leto"]."/".($R["leto"]+1).", ".ToNivojski($R["Nivoji"])."</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='25'>Št.</th><th width='200'>Učenec</th><th width='200'></th></tr>";
                    echo "<tr><td align='center'>".$Indx."</td><td>".$R["Priimek"]." ".$R["Ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td></tr>";
                    $PredmetIzbirni = ToNivojski($R["Nivoji"]).$R["razred"];
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($PredmetIzbirni == ToNivojski($R["Nivoji"]).$R["razred"]){
                    echo "<tr><td align='center'>".$Indx."</td><td>".$R["Priimek"]." ".$R["Ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                }else{
                    $Indx=1;
                    echo "</table>";
                    echo "<h2>".$R["leto"]."/".($R["leto"]+1).", ".ToNivojski($R["Nivoji"])."</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='25'>Št.</th><th width='200'>Učenec</th><th width='25'></th></tr>";
                    echo "<tr><td align='center'>".$Indx."</td><td>".$R["Priimek"]." ".$R["Ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td></tr>";
                    $PredmetIzbirni = ToNivojski($R["Nivoji"]).$R["razred"];
                }
                $Indx=$Indx+1;
            }
        }

        echo "</table>";


        echo "<h2>Nivojski predmeti/skupine po učencih</h2>";

        $SQL = "SELECT tabnivoji.Nivoji,tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "(((tabnivoji INNER JOIN tabucenci ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabnivoji.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabnivoji.leto=".$VLeto." AND tabrazdat.leto=".$VLeto;
        $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazdat.Razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime,nivoji";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1>";
        echo "<th>N</th><th>Leto</th><th>Ucenec</th><th>Predmet 1</th><th>Predmet 2</th><th>Predmet 3</th><tr>";
        $UcenecIzbirni="";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td>".ToNivojski($R["Nivoji"])."</td>";
                }else{
                    echo "</tr><tr><td>".$Indx."</td>";
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"]."#nivoji'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</a></td><td>".ToNivojski($R["Nivoji"])."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                }
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["Priimek"]." ".$R["Ime"] ){
                    echo "<td>".ToNivojski($R["Nivoji"])."</td>";
                }else{
                    echo "</tr><tr><td>".$Indx."</td>";
                    $Indx=$Indx+1;
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"]."#nivoji'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</a></td><td>".ToNivojski($R["Nivoji"])."</td>";
                    $UcenecIzbirni = $R["Priimek"]." ".$R["Ime"];
                }
            }
        }

        echo "</table>";
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "14": //spiski nivoji PDF
        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->SetAutoPageBreak(false);
        //$pdf->AddPage("P","A4");

        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
        
        for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
            $SQL = "SELECT * FROM TabSola WHERE id=".$sole[$IndxSola][0];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VNaslov=$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola="";
                $VNaslov="";
                $VRavnatelj="";
                $VKraj="";
            }

            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }

            $SQL = "SELECT tabnivoji.Nivoji,tabucenci.Priimek,tabucenci.Ime,tabrazdat.* FROM ";
            $SQL = $SQL . "((tabnivoji INNER JOIN tabucenci ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabnivoji.Ucenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabnivoji.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]." ORDER BY nivoji,tabrazdat.Razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            $CompPredmet="";
            $VStran=0;
            $Indx1=0;
            $Indx=1;
            $XPoz[1]=15;
            $XPoz[2]=125;
            $YPoz=90;
            while ($R = mysqli_fetch_array($result)){
                if ($CompPredmet != ToNivojski($R["Nivoji"]).$R["razred"]) {
                    $CompPredmet=ToNivojski($R["Nivoji"]).$R["razred"];
                    $Indx1=0;
                    $Indx=1;
                    $CountUc=1;
                    
                    if ($VStran > 0 ){
                        //'noga
                        $pdf->SetFontSize(12);
                        $pdf->SetFont('arial_CE','',12);
                        $txt=ToWin("Ravnatelj/-ica:");
                        $pdf->SetXY(160,272);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY(160,278);
                        $pdf->Cell(0,0,$txt,0,2,"L");

                        $txt=ToWin($VKraj.", ". $PrintDay);
                        $pdf->SetXY(15,278);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }
                    
                    $VStran=$VStran+1;
                    $pdf->AddPage("P","A4");

                    $pdf->Image("logo1.gif",15,10,30);
                    
                    $pdf->SetFont('arialbd_CE','',16);
                    $txt=ToWin($VSola);
                    $pdf->SetXY(55,15);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VNaslov);
                    $pdf->SetXY(55,23);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Nivojski predmeti/skupine");
                    $pdf->SetXY(15,50);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                    $pdf->SetXY(15,57);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    
                    $pdf->SetFont('arialbd_CE','',14);
                    $txt=ToWin("Predmet: ".ToNivojski($R["Nivoji"])." - ".$R["razred"].". razred");
                    $pdf->SetXY(15,70);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin("Učenec/učenka");
                    $pdf->SetXY($XPoz[1],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    $txt=ToWin("Razred");
                    $pdf->SetXY($XPoz[2],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin($CountUc.". ".$R["Priimek"]." ".$R["Ime"]);
                $pdf->SetXY($XPoz[1],$YPoz+$Indx*6);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin($R["razred"].". ".$R["oznaka"]);
                $pdf->SetXY($XPoz[2],$YPoz+$Indx*6);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($Indx % 30 == 0){
                    $Indx=0;
                    
                    if ($VStran > 0 ){
                        //'noga
                        $pdf->SetFontSize(12);
                        $pdf->SetFont('arial_CE','',12);
                        $txt=ToWin("Ravnatelj/-ica:");
                        $pdf->SetXY(160,272);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY(160,278);
                        $pdf->Cell(0,0,$txt,0,2,"L");

                        $txt=ToWin($VKraj.", ". $PrintDay);
                        $pdf->SetXY(15,278);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }
                    
                    $VStran=$VStran+1;
                    $pdf->AddPage("P","A4");

                    $pdf->Image("logo1.gif",15,10,30);
                    
                    $pdf->SetFont('arialbd_CE','',16);
                    $txt=ToWin($VSola);
                    $pdf->SetXY(55,15);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VNaslov);
                    $pdf->SetXY(55,23);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Nivojski predmeti/skupine");
                    $pdf->SetXY(15,50);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                    $pdf->SetXY(15,57);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    
                    $pdf->SetFont('arialbd_CE','',14);
                    $txt=ToWin("Predmet: ".ToNivojski($R["Nivoji"])." - ".$R["razred"].". razred");
                    $pdf->SetXY(15,70);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin("Učenec/učenka");
                    $pdf->SetXY($XPoz[1],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    $txt=ToWin("Razred");
                    $pdf->SetXY($XPoz[2],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $CountUc=$CountUc+1;
                $Indx=$Indx+1;
            }
            $pdf->SetFontSize(12);
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Ravnatelj/-ica:");
            $pdf->SetXY(160,272);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(160,278);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($VKraj.", ". $PrintDay);
            $pdf->SetXY(15,278);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }
        $pdf->Output("skupine.pdf","D");
        break;
    //načrtovanje izbirnih predmetov za naslednje šolsko leto    
    case "20": //izbor razreda za vnos želenih izbirnih predmetov
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Načrtovanje za šolsko leto </td><td>".($VLeto+1)."/".($VLeto+2)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 AND tabrazdat.razred < 9 ORDER BY tabrazdat.idsola,tabrazdat.razred DESC,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='21'>";
        //echo "        <input name='submit' type='submit' value='Pošlji'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "20a": //izbor razreda za vnos želenih neobveznih izbirnih predmetov
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Načrtovanje za šolsko leto </td><td>".($VLeto+1)."/".($VLeto+2)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred < 9 AND tabrazdat.razred > 0 ORDER BY tabrazdat.idsola,tabrazdat.razred DESC,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='21a'>";
        //echo "        <input name='submit' type='submit' value='Pošlji'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "21": //izbor izbirnih predmetov za razred
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Načrtovanje za šolsko leto </td><td>".($VLeto+1)."/".($VLeto+2)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 AND tabrazdat.razred < 9 ORDER BY tabrazdat.idsola,tabrazdat.razred DESC,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='21'>";
        //echo "        <input name='submit' type='submit' value='Pošlji'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";

		echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Vnos izbirnih predmetov za razred</h2><br />";
        echo "<table border=1>";
        echo "<tr><th>Št.</th><th>Ime</th><th>Razred</th><th>1. izbirni</th><th>2. izbirni</th><th>3. izbirni</th></tr>";
        
        $SQL = "SELECT razred,idsola FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $Letnik=$R["razred"];
            $VSola=$R["idsola"];
        }
        
        $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
        $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
        //$SQL = $SQL . "WHERE tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true ORDER BY tabpredmeti.opis";
        $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.nabor=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/i/%' AND tabnaborizb.idsola=".$VSola." ORDER BY tabpredmeti.opis";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        $Predmeti[$Indx]["id"]=0;
        $Predmeti[$Indx]["opis"]="Ni izbran";
        $Predmeti[$Indx]["oznaka"]="";
        $Indx=$Indx+1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx]["id"]=$R["id"];
            $Predmeti[$Indx]["opis"]=$R["opis"];
            $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
            $Indx=$Indx+1;
        }
        $StPredmetov=$Indx-1;
                
        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                $barva= " style='background-color:white;'";
                echo "<tr>";
            }else{
                $barva= " style='background-color:lightyellow;'";
                echo "<tr style='background-color:lightyellow;'>";
            }
            echo "<td rowspan='3'>".$Indx."</td>";
            echo "<td rowspan='3'><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><b>".$R["priimek"]." ".$R["ime"]."</b></td>";
            echo "<td rowspan='3'>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
            
            $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND ucenec=".$R["iducenec"]." AND tip=0";
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                echo "<td><select name='p11_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p11"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p21_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p21"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p31_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p31"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p12_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p12"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p22_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p22"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p32_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p32"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p13_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p13"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p23_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p23"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";


                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                echo "<td><select name='p33_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p33"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
            }else{
                echo "<td><select name='p11_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p21_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p31_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p12_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p22_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p32_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p13_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p23_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='p33_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;
        echo "</table>";
        echo "<input name='id' type='hidden' value='22'>";
        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='idsola' type='hidden' value='".$VSola."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "21a": //izbor neobveznih izbirnih predmetov za razred
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izberite razred</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Načrtovanje za šolsko leto </td><td>".($VLeto+1)."/".($VLeto+2)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "    </td>";
        echo "</tr>";
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred < 9 AND tabrazdat.razred > 0 ORDER BY tabrazdat.idsola,tabrazdat.razred DESC,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";

        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='id' type='hidden' value='21a'>";
        //echo "        <input name='submit' type='submit' value='Pošlji'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";

        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Vnos neobveznih izbirnih predmetov za razred</h2><br />";
        echo "<table border=1>";
        echo "<tr><th>Št.</th><th>Ime</th><th>Razred</th><th>1. izbirni</th>";
        if ($StNeobveznihIzbirnih > 1){
            echo "<th>2. izbirni</th>";
        }
        if ($StNeobveznihIzbirnih == 3){
            echo "<th>3. izbirni</th>";
        }
        echo "</tr>";
        
        $SQL = "SELECT razred,idsola FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $Letnik=$R["razred"];
            $VSola=$R["idsola"];
        }
        
        $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
        $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
        //$SQL = $SQL . "WHERE tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true ORDER BY tabpredmeti.opis";
        $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.nabor=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/ni/%' AND tabnaborizb.idsola=".$VSola." ORDER BY tabpredmeti.opis";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        $Predmeti[$Indx]["id"]=0;
        $Predmeti[$Indx]["opis"]="Ni izbran";
        $Predmeti[$Indx]["oznaka"]="";
        $Indx=$Indx+1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx]["id"]=$R["id"];
            $Predmeti[$Indx]["opis"]=$R["opis"];
            $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
            $Indx=$Indx+1;
        }
        $StPredmetov=$Indx-1;
                
        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                $barva= " style='background-color:white;'";
                echo "<tr>";
            }else{
                $barva= " style='background-color:lightyellow;'";
                echo "<tr style='background-color:lightyellow;'>";
            }
            echo "<td rowspan='3'>".$Indx."</td>";
            echo "<td rowspan='3'><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><b>".$R["priimek"]." ".$R["ime"]."</b></td>";
            echo "<td rowspan='3'>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
            
            $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND ucenec=".$R["iducenec"]." AND tip=1";
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                echo "<td><select name='p11_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p11"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p21_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        if ($R1["p21"]==$Predmeti[$i]["id"]){
                            echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                    echo "<td><select name='p31_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        if ($R1["p31"]==$Predmeti[$i]["id"]){
                            echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";
                }
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p12_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p12"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p22_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        if ($R1["p22"]==$Predmeti[$i]["id"]){
                            echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                    echo "<td><select name='p32_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        if ($R1["p32"]==$Predmeti[$i]["id"]){
                            echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";
                }
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p13_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p13"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p23_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        if ($R1["p23"]==$Predmeti[$i]["id"]){
                            echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                echo "<td><select name='p33_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    if ($R1["p33"]==$Predmeti[$i]["id"]){
                        echo "<option value='".$Predmeti[$i]["id"]."' selected='selected'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                }
                echo "</select></td>";
                }
            }else{
                echo "<td><select name='p11_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p21_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                    echo "<td><select name='p31_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p12_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p22_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                    echo "<td><select name='p32_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><select name='p13_".$Indx."'".$barva.">";
                for ($i=1;$i <= $StPredmetov;$i++){
                    echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                }
                echo "</select></td>";
                if ($StNeobveznihIzbirnih > 1){
                    echo "<td><select name='p23_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
                if ($StNeobveznihIzbirnih == 3){
                    echo "<td><select name='p33_".$Indx."'".$barva.">";
                    for ($i=1;$i <= $StPredmetov;$i++){
                        echo "<option value='".$Predmeti[$i]["id"]."'>".$Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"]."</option>";
                    }
                    echo "</select></td>";
                }
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;
        echo "</table>";
        echo "<input name='id' type='hidden' value='22a'>";
        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='idsola' type='hidden' value='".$VSola."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "22": //vpis izbora predmetov za razred
        if (isset($_POST["stucencev"])){
            for ($Indx=1;$Indx <= intval($_POST["stucencev"]);$Indx++){
                $SQL = "SELECT id FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND ucenec=".$_POST["uc_".$Indx]." AND tip=0";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabizbirniizbor SET ";
                    $SQL = $SQL . "p11=".$_POST["p11_".$Indx].",";
                    $SQL = $SQL . "p12=".$_POST["p12_".$Indx].",";
                    $SQL = $SQL . "p13=".$_POST["p13_".$Indx].",";
                    $SQL = $SQL . "p21=".$_POST["p21_".$Indx].",";
                    $SQL = $SQL . "p22=".$_POST["p22_".$Indx].",";
                    $SQL = $SQL . "p23=".$_POST["p23_".$Indx].",";
                    $SQL = $SQL . "p31=".$_POST["p31_".$Indx].",";
                    $SQL = $SQL . "p32=".$_POST["p32_".$Indx].",";
                    $SQL = $SQL . "p33=".$_POST["p33_".$Indx];
                    $SQL = $SQL . ",tip=0";
                    $SQL = $SQL . " WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabizbirniizbor (leto,ucenec,p11,p12,p13,p21,p22,p23,p31,p32,p33,tip) VALUES (";
                    $SQL = $SQL . ($VLeto+1).",";
                    $SQL = $SQL . $_POST["uc_".$Indx].",";
                    $SQL = $SQL . $_POST["p11_".$Indx].",";
                    $SQL = $SQL . $_POST["p12_".$Indx].",";
                    $SQL = $SQL . $_POST["p13_".$Indx].",";
                    $SQL = $SQL . $_POST["p21_".$Indx].",";
                    $SQL = $SQL . $_POST["p22_".$Indx].",";
                    $SQL = $SQL . $_POST["p23_".$Indx].",";
                    $SQL = $SQL . $_POST["p31_".$Indx].",";
                    $SQL = $SQL . $_POST["p32_".$Indx].",";
                    $SQL = $SQL . $_POST["p33_".$Indx].",0)";
                }
                $result1 = mysqli_query($link,$SQL);
            }
        }
        header ("Location: izbirniskupine.php?id=21&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "22a": //vpis izbora predmetov za razred
        if (isset($_POST["stucencev"])){
            for ($Indx=1;$Indx <= intval($_POST["stucencev"]);$Indx++){
                $SQL = "SELECT id FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND ucenec=".$_POST["uc_".$Indx]." AND tip=1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabizbirniizbor SET ";


                    $SQL = $SQL . "p11=".$_POST["p11_".$Indx].",";
                    $SQL = $SQL . "p12=".$_POST["p12_".$Indx].",";
                    $SQL = $SQL . "p13=".$_POST["p13_".$Indx];
                    if ($StNeobveznihIzbirnih > 1){
                        $SQL = $SQL . ",p21=".$_POST["p21_".$Indx].",";
                        $SQL = $SQL . "p22=".$_POST["p22_".$Indx].",";
                        $SQL = $SQL . "p23=".$_POST["p23_".$Indx];
                    }
                    if ($StNeobveznihIzbirnih == 3){
                        $SQL = $SQL . ",p31=".$_POST["p31_".$Indx].",";
                        $SQL = $SQL . "p32=".$_POST["p32_".$Indx].",";
                        $SQL = $SQL . "p33=".$_POST["p33_".$Indx];
                    }
                    $SQL = $SQL . ",tip=1 WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabizbirniizbor (leto,ucenec,p11,p12,p13,p21,p22,p23,p31,p32,p33,tip) VALUES (";
                    $SQL = $SQL . ($VLeto+1).",";
                    $SQL = $SQL . $_POST["uc_".$Indx].",";
                    $SQL = $SQL . $_POST["p11_".$Indx].",";
                    $SQL = $SQL . $_POST["p12_".$Indx].",";
                    $SQL = $SQL . $_POST["p13_".$Indx].",";
                    if ($StNeobveznihIzbirnih > 1){
                        $SQL = $SQL . $_POST["p21_".$Indx].",";
                        $SQL = $SQL . $_POST["p22_".$Indx].",";
                        $SQL = $SQL . $_POST["p23_".$Indx].",";
                    }else{
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "0,";
                    }
                    if ($StNeobveznihIzbirnih == 3){
                        $SQL = $SQL . $_POST["p21_".$Indx].",";
                        $SQL = $SQL . $_POST["p22_".$Indx].",";
                        $SQL = $SQL . $_POST["p23_".$Indx].",1)";
                    }else{
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "0,1)";
                    }
                }
                $result1 = mysqli_query($link,$SQL);
            }
        }
        header ("Location: izbirniskupine.php?id=21a&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "23": //izpis izbirnih predmetov in nastavljanje njihovih lastnosti ter določanje v nabor
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='23'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;

        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izbira predmetov za naslednje šolsko leto</h2><br />";
        echo "<table border=1>";
        
        $SQL = "SELECT id,oznaka,opis FROM tabpredmeti WHERE prioriteta=1 AND OpisMSS LIKE '%/i/%' ORDER BY opis,oznaka";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        //v spisku navede tudi druge skupine predmetov
        while ($R = mysqli_fetch_array($result)){
            $Predmet[$Indx]["id"]=$R["id"];
            $Predmet[$Indx]["oznaka"]=$R["oznaka"];
            $Predmet[$Indx]["opis"]=$R["opis"];
            $Indx=$Indx+1;
        }
        $StPredmetov=$Indx-1;

        echo "<tr><th>Št.</th><th>Predmet</th><th>ŠL</th><th>Razredi<br />1 2 3 4 5 6 7 8 9</th><th>Delitev pri</th><th>ur</th><th>v naboru</th></tr>";
        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
            $SQL = "SELECT * FROM tabnaborizb WHERE predmet=".$Predmet[$Indx]["id"]." AND leto=".($VLeto+1)." AND idsola=".$VSola;
            $result = mysqli_query($link,$SQL);
            if (mysqli_num_rows($result) > 0){
                while ($R = mysqli_fetch_array($result)){
                    if ($Indx % 2 == 0){
                        echo "<tr>";
                    }else{
                        echo "<tr style='background-color:lightgrey;'>";
                    }
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='predmet_".$Indx."' type='hidden' value='".$Predmet[$Indx]["id"]."'>".$Predmet[$Indx]["opis"]." - ".$Predmet[$Indx]["oznaka"]."</td>";
                    echo "<td>".($VLeto+1)."/".($VLeto+2)."</td>";
                    echo "<td>";
                    for ($i=1;$i <= 9;$i++){
                        if ($R["r".$i]){
                            echo "<input name='r".$i."_".$Indx."' type='checkbox' checked='checked'>";
                        }else{
                            echo "<input name='r".$i."_".$Indx."' type='checkbox'>";
                        }
                    }
                    echo "</td>";
                    echo "<td><input name='delitev_".$Indx."' type='text' value='".$R["delitev"]."' size='2'></td>";
                    echo "<td><input name='ur_".$Indx."' type='text' value='".$R["ur"]."' size='2'></td>";
                    if ($R["nabor"]){
                        echo "<td><input name='nabor_".$Indx."' type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td><input name='nabor_".$Indx."' type='checkbox'></td>";
                    }
                    echo "</tr>";
                }
            }else{
                if ($Indx % 2 == 0){
                    echo "<tr>";
                }else{
                    echo "<tr style='background-color:lightgrey;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td><input name='predmet_".$Indx."' type='hidden' value='".$Predmet[$Indx]["id"]."'>".$Predmet[$Indx]["opis"]." - ".$Predmet[$Indx]["oznaka"]."</td>";
                echo "<td>".($VLeto+1)."/".($VLeto+2)."</td>";
                echo "<td>";
                for ($i=1;$i <= 9;$i++){
                    echo "<input name='r".$i."_".$Indx."' type='checkbox'>";
                }
                echo "</td>";
                echo "<td><input name='delitev_".$Indx."' type='text' value='28' size='2'></td>";
                echo "<td><input name='ur_".$Indx."' type='text' value='1' size='2'></td>";
                echo "<td><input name='nabor_".$Indx."' type='checkbox'></td>";
                echo "</tr>";
            }
             
        }
        
        echo "</table>";
        echo "<input name='id' type='hidden' value='24'>";
        echo "<input name='idsola' type='hidden' value='".$VSola."'>";
        echo "<input name='stpredmetov' type='hidden' value='".$StPredmetov."'>";
        echo "<input name='letoizb' type='hidden' value='".($VLeto+1)."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        
        break;
    case "23a": //izpis neobveznih izbirnih predmetov in nastavljanje njihovih lastnosti ter določanje v nabor
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='23a'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;
        
        echo "<form name='rezultati' method='post' action='izbirniskupine.php'>";
        echo "<h2>Izbira predmetov za naslednje šolsko leto</h2><br />";
        echo "<table border=1>";
        
        $SQL = "SELECT id,oznaka,opis FROM tabpredmeti WHERE prioriteta=1 AND OpisMSS LIKE '%/ni/%' ORDER BY opis,oznaka";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        //v spisku navede tudi druge skupine predmetov
        while ($R = mysqli_fetch_array($result)){
            $Predmet[$Indx]["id"]=$R["id"];
            $Predmet[$Indx]["oznaka"]=$R["oznaka"];
            $Predmet[$Indx]["opis"]=$R["opis"];
            $Indx=$Indx+1;
        }
        $StPredmetov=$Indx-1;

        echo "<tr><th>Št.</th><th>Predmet</th><th>ŠL</th><th>Razredi<br />1 2 3 4 5 6 7 8 9</th><th>Delitev pri</th><th>ur</th><th>v naboru</th></tr>";
        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
            $SQL = "SELECT * FROM tabnaborizb WHERE predmet=".$Predmet[$Indx]["id"]." AND leto=".($VLeto+1)." AND idsola=".$VSola;
            $result = mysqli_query($link,$SQL);
            if (mysqli_num_rows($result) > 0){
                while ($R = mysqli_fetch_array($result)){
                    if ($Indx % 2 == 0){
                        echo "<tr>";
                    }else{
                        echo "<tr style='background-color:lightgrey;'>";
                    }
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='predmet_".$Indx."' type='hidden' value='".$Predmet[$Indx]["id"]."'>".$Predmet[$Indx]["opis"]." - ".$Predmet[$Indx]["oznaka"]."</td>";
                    echo "<td>".($VLeto+1)."/".($VLeto+2)."</td>";
                    echo "<td>";
                    for ($i=1;$i <= 9;$i++){
                        if ($R["r".$i]){
                            echo "<input name='r".$i."_".$Indx."' type='checkbox' checked='checked'>";
                        }else{
                            echo "<input name='r".$i."_".$Indx."' type='checkbox'>";
                        }
                    }
                    echo "</td>";
                    echo "<td><input name='delitev_".$Indx."' type='text' value='".$R["delitev"]."' size='2'></td>";
                    echo "<td><input name='ur_".$Indx."' type='text' value='".$R["ur"]."' size='2'></td>";
                    if ($R["nabor"]){
                        echo "<td><input name='nabor_".$Indx."' type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td><input name='nabor_".$Indx."' type='checkbox'></td>";
                    }
                    echo "</tr>";
                }
            }else{
                if ($Indx % 2 == 0){
                    echo "<tr>";
                }else{
                    echo "<tr style='background-color:lightgrey;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td><input name='predmet_".$Indx."' type='hidden' value='".$Predmet[$Indx]["id"]."'>".$Predmet[$Indx]["opis"]." - ".$Predmet[$Indx]["oznaka"]."</td>";
                echo "<td>".($VLeto+1)."/".($VLeto+2)."</td>";
                echo "<td>";
                for ($i=1;$i <= 9;$i++){
                    echo "<input name='r".$i."_".$Indx."' type='checkbox'>";
                }
                echo "</td>";
                echo "<td><input name='delitev_".$Indx."' type='text' value='28' size='2'></td>";
                echo "<td><input name='ur_".$Indx."' type='text' value='1' size='2'></td>";
                echo "<td><input name='nabor_".$Indx."' type='checkbox'></td>";
                echo "</tr>";
            }
             
        }
        
        echo "</table>";
        echo "<input name='id' type='hidden' value='24a'>";
        echo "<input name='idsola' type='hidden' value='".$VSola."'>";
        echo "<input name='stpredmetov' type='hidden' value='".$StPredmetov."'>";
        echo "<input name='letoizb' type='hidden' value='".($VLeto+1)."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        
        break;
    case "24": //vpis podatkov o predmetih in vključitev v nabor
        if (isset($_POST["stpredmetov"])){
            for ($Indx=1;$Indx <= intval($_POST["stpredmetov"]);$Indx++){
                $SQL = "SELECT * FROM tabnaborizb WHERE leto=".$_POST["letoizb"]." AND predmet=".$_POST["predmet_".$Indx]." AND idsola=".$_POST["idsola"];
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnaborizb SET ";
                        for ($i=1;$i <= 9;$i++){
                            if (isset($_POST["r".$i."_".$Indx])){
                                $SQL = $SQL . "r".$i."=true,";
                            }else{
                                $SQL = $SQL . "r".$i."=false,";
                            }
                        }
                        $SQL = $SQL . "delitev=".intval($_POST["delitev_".$Indx]).",";
                        $SQL = $SQL . "ur=".intval($_POST["ur_".$Indx]).",";
                        if (isset($_POST["nabor_".$Indx])){
                            $SQL = $SQL . "nabor=true,izbran=true WHERE id=".$R["id"];
                        }else{
                            $SQL = $SQL . "nabor=false,izbran=false WHERE id=".$R["id"];
                        }
                        //$SQL = $SQL . "izbran=false WHERE id=".$R["id"];
                    }
                }else{
                    $SQL = "INSERT INTO tabnaborizb (leto,predmet,r1,r2,r3,r4,r5,r6,r7,r8,r9,delitev,ur,nabor,izbran,idsola) VALUES (";
                    $SQL = $SQL . $_POST["letoizb"].",";
                    $SQL = $SQL . $_POST["predmet_".$Indx].",";
                    for ($i=1;$i <= 9;$i++){
                        if (isset($_POST["r".$i."_".$Indx])){
                            $SQL = $SQL . "true,";
                        }else{
                            $SQL = $SQL . "false,";
                        }
                    }
                    $SQL = $SQL . intval($_POST["delitev_".$Indx]).",";
                    $SQL = $SQL . intval($_POST["ur_".$Indx]).",";
                    if (isset($_POST["nabor_".$Indx])){
                        $SQL = $SQL . "true,true,".$_POST["idsola"].")";
                    }else{
                        $SQL = $SQL . "false,false,".$_POST["idsola"].")";
                    }
                    //$SQL = $SQL . "false)";
                }
                $result1 = mysqli_query($link,$SQL);
            }
        }
        header ("Location: izbirniskupine.php?id=23&solskoleto=".$VLeto);
        break;
    case "24a": //vpis podatkov o predmetih in vključitev v nabor
        if (isset($_POST["stpredmetov"])){
            for ($Indx=1;$Indx <= intval($_POST["stpredmetov"]);$Indx++){
                $SQL = "SELECT * FROM tabnaborizb WHERE leto=".$_POST["letoizb"]." AND predmet=".$_POST["predmet_".$Indx]." AND idsola=".$_POST["idsola"];
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnaborizb SET ";
                        for ($i=1;$i <= 9;$i++){
                            if (isset($_POST["r".$i."_".$Indx])){
                                $SQL = $SQL . "r".$i."=true,";
                            }else{
                                $SQL = $SQL . "r".$i."=false,";
                            }
                        }
                        $SQL = $SQL . "delitev=".intval($_POST["delitev_".$Indx]).",";
                        $SQL = $SQL . "ur=".intval($_POST["ur_".$Indx]).",";
                        if (isset($_POST["nabor_".$Indx])){
                            $SQL = $SQL . "nabor=true,izbran=true WHERE id=".$R["id"];
                        }else{
                            $SQL = $SQL . "nabor=false,izbran=false WHERE id=".$R["id"];
                        }
                        //$SQL = $SQL . "izbran=false WHERE id=".$R["id"];
                    }
                }else{
                    $SQL = "INSERT INTO tabnaborizb (leto,predmet,r1,r2,r3,r4,r5,r6,r7,r8,r9,delitev,ur,nabor,izbran,idsola) VALUES (";
                    $SQL = $SQL . $_POST["letoizb"].",";
                    $SQL = $SQL . $_POST["predmet_".$Indx].",";
                    for ($i=1;$i <= 9;$i++){
                        if (isset($_POST["r".$i."_".$Indx])){
                            $SQL = $SQL . "true,";
                        }else{
                            $SQL = $SQL . "false,";
                        }
                    }
                    $SQL = $SQL . intval($_POST["delitev_".$Indx]).",";
                    $SQL = $SQL . intval($_POST["ur_".$Indx]).",";
                    if (isset($_POST["nabor_".$Indx])){
                        $SQL = $SQL . "true,true,".$_POST["idsola"].")";
                    }else{
                        $SQL = $SQL . "false,false,".$_POST["idsola"].")";
                    }
                    //$SQL = $SQL . "false)";
                }
                $result1 = mysqli_query($link,$SQL);
            }
        }
        header ("Location: izbirniskupine.php?id=23a&solskoleto=".$VLeto);
        break;
    case "25": //obrazci za izbiro predmetov
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='25'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;
        for ($Indx=1;$Indx <= 8;$Indx++){
            //preveri, če ima za ta letnik kaj predmetov
            $SQL = "SELECT tabnaborizb.ur,tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabnaborizb ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE r".($Indx+1)."=true AND nabor=true AND leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/i/%' AND tabnaborizb.idsola=".$VSola;
            $SQL = $SQL . " ORDER BY opis,oznaka";
            $result2 = mysqli_query($link,$SQL);
            if (mysqli_num_rows($result2) > 0){
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL = $SQL . "WHERE tabrazdat.idsola=".$VSola." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred=".$Indx." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<div class='break'></div>";
                    echo "<b>Izbor izbirnih predmetov za šolsko leto: ".($VLeto+1)."/".($VLeto+2)."</b><br />";
                    if ($VecSol > 0){
                        echo "<h2>".$R["priimek"]." ".$R["ime"].", ".($R["razred"]+1).". ".$R["oznaka"]." - ".$R["solakratko"]."</h2>";
                    }else{
                        echo "<h2>".$R["priimek"]." ".$R["ime"].", ".($R["razred"]+1).". ".$R["oznaka"]."</h2>";
                    }
                    for ($i=1;$i <= 6;$i++){
                        $ucenec[$i]=0;
                    }
                    $i=0;
                    //spisek izbirnih predmetov učenca za trenutno šolsko leto
					echo "<p class='manjsi'>";
                    if ($R["razred"] > 6){
                        echo "<b><i>Izbirni predmeti v preteklih šolskih letih:</i></b><br />";
                        $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE ucenec=".$R["iducenec"]." AND leto=".$VLeto." AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabpredmeti.vrstnired";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            $i=$i+1;
                            $ucenec[$i]=$R1["izbirni"];
                            echo "<i>".$R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."</i>, ";
                        }
						echo "<br />";
                    }
                    //spisek izbirnih predmetov učenca za preteklo šolsko leto
                    if ($R["razred"] > 7){
                        $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE ucenec=".$R["iducenec"]." AND leto=".($VLeto-1)." AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabpredmeti.vrstnired";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            $i=$i+1;
                            $ucenec[$i]=$R1["izbirni"];
                            echo "<i>".$R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."</i>, ";
                        }
                    }
                    $StPredmetov=$i;
					echo "</p>";
                    
                    //izpis ponujenih predmetov brez že izbranih
                    
                    if ($R["razred"] < 6){
						echo "<b>Spisek ponujenih neobveznih izbirnih predmetov za šolsko leto ".($VLeto+1)."/".($VLeto+2)."</b><br />";
                        echo "<p><b>Spoštovani starši in učenci!</b> <br />Prosimo, da v stolpcu poleg predmeta, s številko 1 označite vašo glavno izbiro, z R pa rezervo.<br />";
                        echo "Otrok lahko obiskuje le 1 predmet.<br />";
                        echo "Tuj jezik poteka 2 uri tedensko, ostali predmeti po 1 uro.</p>";
                    }else{
						//echo "<b>Spisek ponujenih izbirnih predmetov za šolsko leto ".($VLeto+1)."/".($VLeto+2)."</b><br />";
                        echo "<p class='manjsi'><b>Spoštovani starši in učenci!</b> <br /><br />Prosimo, da obkrožite število izbirnih predmetov, ki jih bo učenec obiskoval: <b>&nbsp;&nbsp;&nbsp;1&nbsp;&nbsp;&nbsp;2&nbsp;&nbsp;&nbsp;3</b><br />";
                        echo "Skupaj morate izbrati najmanj 2 uri izbirnih predmetov, lahko pa se ob soglasju staršev izbere do največ 3 ure.</p>";
						echo "<p class='manjsi'>Uveljavljam glasbeno šolo (označi):&nbsp;&nbsp;<b>DA</b> (<small>v celoti</small>)&nbsp;&nbsp;&nbsp;&nbsp;<b>DA</b> (<small>delno</small>)&nbsp;&nbsp;&nbsp;&nbsp;<b>NE</b></p>"; 
						//echo "Za prvi izbirni predmet v prvi stolpec vpišite 1 za prvo izbiro in 2 za rezervo. Za drugi izbirni predmet v drugi stolpec vpišite 1 za prvo izbiro in 2 za rezervo. Podobno storite v tretjem stolpcu za tretji izbirni predmet.<br />";
						echo "<p class='manjsi'>V ustrezen stolpec poleg predmeta, s številko <b>1</b> označite glavno izbiro, z <b>R</b> pa rezervo.<br />";
                        //echo "V prvem stolpcu poleg predmeta s številko 1 označite vaš prvi izbor za prvi izbirni predmet in z 2 rezervni predmet.<br />";
                        //echo "Če izbirate 2 predmeta, v drugem stolpcu s številko 1 označite vaš prvi izbor za drugi izbirni predmet in z 2 rezervni predmet.<br />";
                        //echo "Če izbirate 3 predmete, v tretjem stolpcu s številko 1 označite vaš prvi izbor za tretji izbirni predmet in z 2 rezervni predmet.<br />";
						echo "</p>";
                    }
                    
                    if ($R["razred"] < 6){
                        echo "<table border='1' cellspacing='0'>";
                        echo "<tr><th>Koda</th><th>Predmet</th><th>Ur na<br />teden</th><th>Izbor</th></tr>";
                        $SQL = "SELECT tabnaborizb.ur,tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabnaborizb ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE r".($R["razred"]+1)."=true AND nabor=true AND leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/i/%'";
                        $SQL = $SQL . " ORDER BY opis,oznaka";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo "<tr height='25'>";
                            echo "<td align='center'>".$R1["id"]."</td>";
                            echo "<td>".$R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."</td>";
                            echo "<td align='center'>".$R1["ur"]."</td>";
                            echo "<td>&nbsp;</td>";
                            echo "</tr>";
                        }
                        echo "</table><br />";
                        echo "<br />";
                        echo "<table class='hide' width='100%'>";
                        echo "<tr class='hide'><td class='hide' align='left'>_____________________<br />Datum </td>";
                        echo "<td class='hide'  align='left'>_____________________<br />Podpis učenca </td>";
                        echo "<td class='hide'  align='left'>_____________________<br />Podpis staršev </td></tr>";
                        echo "</table><br />";
                    }else{
                        echo "<table border='1' cellspacing='0'>";
                        echo "<tr><th>Koda</th><th>Predmet</th><th>Ur na<br />teden</th><th>1.<br />predmet</th><th>2.<br />predmet</th><th>3.<br />predmet</th></tr>";
                        $SQL = "SELECT tabnaborizb.ur,tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabnaborizb ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE r".($R["razred"]+1)."=true AND nabor=true AND leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/i/%'";
                        $SQL = $SQL . " ORDER BY opis,oznaka";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo "<tr height='20'>";
                            echo "<td align='center'>".$R1["id"]."</td>";
                            echo "<td>".$R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."</td>";
                            echo "<td align='center'>".$R1["ur"]."</td>";
                            echo "<td>&nbsp;</td>";
                            echo "<td>&nbsp;</td>";
                            echo "<td>&nbsp;</td>";
                            echo "</tr>";
                        }
                        echo "</table><br />";
                        echo "<br />";
                        echo "<table class='hide' width='100%'>";
                        echo "<tr class='hide'><td class='hide' align='left'>_____________________<br />Datum </td>";
                        echo "<td class='hide'  align='left'>_____________________<br />Podpis učenca </td>";
                        echo "<td class='hide'  align='left'>_____________________<br />Podpis staršev </td></tr>";
                        echo "</table><br />";
                    }
                }
                //echo "<p class='break'></p>";
            }
        }
        echo "</body>";
        echo "</html>";
        
        break;
    case "25a": //obrazci za izbiro neobveznih predmetov
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='25a'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;
        for ($Indx=1;$Indx <= 8;$Indx++){
            //preveri, če ima za ta letnik kaj predmetov
            $SQL = "SELECT tabnaborizb.ur,tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabnaborizb ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE r".($Indx+1)."=true AND nabor=true AND leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/ni/%' AND tabnaborizb.idsola=".$VSola;
            $SQL = $SQL . " ORDER BY opis,oznaka";
            $result2 = mysqli_query($link,$SQL);
            if (mysqli_num_rows($result2) > 0){
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL = $SQL . "WHERE tabrazdat.idsola=".$VSola." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred=".$Indx." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<div class='break'></div>";
                    echo "<b>Izbor neobveznih izbirnih predmetov za šolsko leto: ".($VLeto+1)."/".($VLeto+2)."</b><br />";
                    if ($VecSol > 0){
                        echo "<h2>".$R["priimek"]." ".$R["ime"].", ".($R["razred"]+1).". ".$R["oznaka"]." - ".$R["solakratko"]."</h2>";
                    }else{
                        echo "<h2>".$R["priimek"]." ".$R["ime"].", ".($R["razred"]+1).". ".$R["oznaka"]."</h2>";
                    }
                    for ($i=1;$i <= 6;$i++){
                        $ucenec[$i]=0;
                    }
                    $i=0;
                    //spisek izbirnih predmetov učenca za trenutno šolsko leto
					echo "<i>";
                    if ($R["razred"] > 3){
                        echo "<b>Neobvezni izbirni predmeti v preteklih šolskih letih:</b><br />";
                        $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE ucenec=".$R["iducenec"]." AND leto=".$VLeto." AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabpredmeti.vrstnired";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            $i=$i+1;
                            $ucenec[$i]=$R1["izbirni"];
                            echo $R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."<br />";
                        }
                    }
                    //spisek izbirnih predmetov učenca za preteklo šolsko leto
                    if ($R["razred"] > 3){
                        $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                        $SQL = $SQL . "WHERE ucenec=".$R["iducenec"]." AND leto <=".($VLeto-1)." AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabpredmeti.vrstnired";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            $i=$i+1;
                            $ucenec[$i]=$R1["izbirni"];
                            echo $R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."<br />";
                        }
                    }
					if (($i == 0) && ($R["razred"]+1 > 4)){
						echo "- ni bilo izbranih neobveznih izbirnih predmetov<br />";
					}
					echo "</i>";
                    $StPredmetov=$i;
                    
                    //izpis ponujenih predmetov brez že izbranih
                    //echo "<br /><b>Spisek ponujenih neobveznih izbirnih predmetov za šolsko leto ".($VLeto+1)."/".($VLeto+2)."</b><br />";
                    
					echo "<p>";
					echo "<b>Spoštovani starši in učenci!</b><br /><br />Neobvezni izbirni predmeti so pri ocenjevanju izenačeni z obveznimi izbirnimi predmeti. ";
					echo "Zaključne ocene se vpišejo v spričevalo. ";
					echo "Prisotnost učenca pri neobveznih izbirnih predmetih se obravnava enako kot pri obveznih predmetih, vsako odsotnost morajo starši opravičiti. ";
					echo "Neobvezni izbirni predmet se bo lahko izvajal za najmanj 12 učencev. ";
					echo "</p>";
                    if ($R["razred"] < 6){
                        if ($StNeobveznihIzbirnih == 1){
                            echo "<p><b>Izberete lahko en (1) tuj jezik ali enega (1) od preostalih predmetov.</b><br />";
                            echo "V primeru izbire tujega jezika ima učenec/-ka 2 uri neobveznih izbirnih predmetov, sicer pa 1 uro.</p>";
                            echo "<p>V stolpcu poleg predmeta s kljukico označite vašo izbiro.<br />";
                            echo "V drugem stolpcu označite morebitno rezervno izbiro.<br />";
                        }
                        if ($StNeobveznihIzbirnih == 2){
                            echo "<p><b>Izberete lahko en (1) tuj jezik ali dva (2) enourna predmeta.</b><br />";
                            echo "V primeru izbire tujega jezika ima učenec/-ka 2 uri neobveznih izbirnih predmetov.</p>";
                            echo "<p>V stolpcu poleg predmeta s številko označite vašo izbiro.<br />";
                            echo "V drugem stolpcu označite rezervni predmet.<br />";
                        }
                    }else{
                        echo "<p>V stolpcu poleg predmeta, s kljukico označite vašo izbiro.<br />";
                        echo "Izberete lahko en (1) tuj jezik.</p>";
                    }
                    
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr><th>Koda</th><th>Predmet</th><th>Ur na<br />teden</th><th width='100'>Izbor</th>";
					if ($R["razred"] < 6){
						echo "<th width='100'>Rezerva</th>";
					}
					echo "</tr>";
                    $SQL = "SELECT tabnaborizb.ur,tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabnaborizb ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                    $SQL = $SQL . "WHERE r".($R["razred"]+1)."=true AND nabor=true AND leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
                    $SQL = $SQL . " ORDER BY opis,oznaka";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo "<tr height='25'>";
                        echo "<td align='center'>".$R1["id"]."</td>";
                        echo "<td>".$R1["opis"]." - ".mb_substr($R1["oznaka"],0,3,$encoding)."</td>";
                        echo "<td align='center'>".$R1["ur"]."</td>";
                        echo "<td>&nbsp;</td>";
						if ($R["razred"] < 6){
							echo "<td>&nbsp;</td>";
						}
                        echo "</tr>";
                    }
                    echo "</table><br />";
                    echo "<br />";
                    echo "<table class='hide' width='100%'>";
                    //echo "<table border='0' width='100%'>";
                    echo "<tr class='hide'><td class='hide' align='left'>_____________________<br />Datum</td>";
                    echo "<td class='hide' align='left' height='40'>_____________________<br />Podpis učenca</td>";
                    echo "<td class='hide' align='left' height='40'>_____________________<br />Podpis staršev</td></tr>";
                    echo "</table><br />";
					/*
					echo "<p>";
					echo "Spoštovani starši!<br /><br />Pri našem tolmačenju kreiranja neobveznih izbirnih predmetov je prišlo do nesporazuma. ";
					echo "Obveščamo vas, da učenci lahko izberejo le en (1) neobvezen izbirni predmet.<br /><br />Za nastalo neprijetnost se opravičujemo.";
					echo "</p>";
					*/
                }
                //echo "<p class='break'></p>";
            }
        }
        echo "</body>";
        echo "</html>";
        
        break;
    case "26": //izbor izbirnih predmetov z izračuni skupin in prikazom števila učencev
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='26'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;
        if (isset($_POST["vpisano"])){
            //vpiše izbire
            for ($Indx=1;$Indx <= intval($_POST["zapisov"]);$Indx++){
                if (isset($_POST["izbran_".$Indx])){
                    $SQL = "UPDATE tabnaborizb SET izbran=true WHERE id=".$_POST["zapis_".$Indx];
                }else{
                    $SQL = "UPDATE tabnaborizb SET izbran=false WHERE id=".$_POST["zapis_".$Indx];
                }
                $result = mysqli_query($link,$SQL);
            }
        }
        $SQL = "SELECT tabucenci.id FROM (tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.idsola=".$VSola." AND tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred IN (6,7,8)";
        $result = mysqli_query($link,$SQL);
        $Ucencev=mysqli_num_rows($result);
        
        $SQL = "SELECT id FROM tabrazdat WHERE leto=".$VLeto." AND razred IN (6,7,8) AND idsola=".$VSola;
        $result = mysqli_query($link,$SQL);
        $Razredov=mysqli_num_rows($result);
        
        echo "<br />Oblikujete lahko ".$Ucencev."/23 + 2 x ".$Razredov." = ".number_format($Ucencev/23+2*$Razredov,2)." skupin.<br />";
        
        echo "<form name='izbirni' method='post' action='izbirniskupine.php'>";
        echo "<br /><table border=0>";
        echo "<tr><th>Št.</th><th>Predmet</th><th>Ur</th><th>Učencev</th><th>Skupin za<br />izvajanje</th><th>Skupin</th><th>Izbran</th></tr>";
        $SQL = "SELECT tabnaborizb.id AS nid,tabnaborizb.delitev,tabnaborizb.ur,tabnaborizb.nabor,tabnaborizb.izbran,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.id FROM tabnaborizb ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabnaborizb.idsola=".$VSola." AND tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.nabor=true AND tabpredmeti.OpisMSS LIKE '%/i/%' ";
        $SQL = $SQL . "ORDER BY tabnaborizb.izbran DESC, tabpredmeti.opis";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        $VsehSkupin=0;
        $VsehUcencev=0;
        $VsehUr=0;
        $VsehSkupin2=0;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                echo "<tr>";
            }else{
                echo "<tr style='background-color:lightgrey;'>";
            }
            echo "<td align='center'>".$Indx."</td>";
            echo "<td>".$R["opis"]." - ".$R["oznaka"]."</td>";
            echo "<td align='center'>".$R["ur"]."</td>";
            
            //pregleda število učencev prijavljenih za predmet
            //spisek izbranih predmetov
            $SQL = "SELECT tabnaborizb.predmet FROM tabnaborizb INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id  WHERE tabnaborizb.idsola=".$VSola." AND tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabpredmeti.OpisMSS LIKE '%/i/%'";
            $result1 = mysqli_query($link,$SQL);
            $predmeti="";
            while ($R1 = mysqli_fetch_array($result1)){
                if (strlen($predmeti)==0){
                    $predmeti=$R1["predmet"];
                }else{
                    $predmeti=$predmeti.",".$R1["predmet"];
                }
            }
            
            //po učencih prešteje, koliko je prijavljenih na ta predmet
            if ($R["izbran"]){
                $SQL = "SELECT tabizbirniizbor.* FROM ((tabizbirniizbor ";
                $SQL .= "INNER JOIN tabrazred ON tabrazred.iducenec=tabizbirniizbor.ucenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "WHERE tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=0 AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$VSola;
                $result1 = mysqli_query($link,$SQL);
                $i=0;
                if (mysqli_num_rows($result1) > 0){
                    while ($R1 = mysqli_fetch_array($result1)){
                        $nasel=false;
                        //pogleda prvi predmet
                        if (vsebuje($predmeti,$R1["p11"])){
                            if ($R["id"] == $R1["p11"]){
                                $i=$i+1;
                                $nasel=true;
                            }
                        }else{
                            if (vsebuje($predmeti,$R1["p12"])){
                                if ($R["id"] == $R1["p12"]){
                                    $i=$i+1;
                                    $nasel=true;
                                }
                            }else{
                                if (vsebuje($predmeti,$R1["p13"])){
                                    if ($R["id"] == $R1["p13"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }
                            }
                        }
                        if (!$nasel){
                            //pogleda drugi predmet
                            if (vsebuje($predmeti,$R1["p21"])){
                                if ($R["id"] == $R1["p21"]){
                                    $i=$i+1;
                                    $nasel=true;
                                }
                            }else{
                                if (vsebuje($predmeti,$R1["p22"])){
                                    if ($R["id"] == $R1["p22"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }else{
                                    if (vsebuje($predmeti,$R1["p23"])){
                                        if ($R["id"] == $R1["p23"]){
                                            $i=$i+1;
                                            $nasel=true;
                                        }
                                    }
                                }
                            }
                        }
                        if (!$nasel){
                            //pogleda tretji predmet
                            if (vsebuje($predmeti,$R1["p31"])){
                                if ($R["id"] == $R1["p31"]){
                                    $i=$i+1;
                                    $nasel=true;
                                }
                            }else{
                                if (vsebuje($predmeti,$R1["p32"])){
                                    if ($R["id"] == $R1["p32"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }else{
                                    if (vsebuje($predmeti,$R1["p33"])){
                                        if ($R["id"] == $R1["p33"]){
                                            $i=$i+1;
                                            $nasel=true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    echo "<td align='center'>".$i."</td>";
                    $VsehUcencev=$VsehUcencev+$i;
                    if ($i % $R["delitev"] == 0){
                        $skupin=intval($i/$R["delitev"]);
                    }else{
                        $skupin=intval($i/$R["delitev"])+1;
                    }
                    echo "<td align='center'>".$skupin."</td>";
                    $VsehUr=$VsehUr+$R["ur"]*$skupin;
                    $VsehSkupin=$VsehSkupin+$skupin;

                    if ($i % 28 == 0){
                        $skupin2=intval($i/28);
                    }else{
                        $skupin2=intval($i/28)+1;
                    }
                    echo "<td align='center'>".$skupin2."</td>";
                    $VsehSkupin2=$VsehSkupin2+$skupin2;
                }else{
                    echo "<td align='center'>0</td><td align='center'>0</td><td align='center'>0</td>";
                }
            }else{
                //neizbran predmet ima vrednosti skupin in učencev 0
                echo "<td align='center'>0</td><td align='center'>0</td><td align='center'>0</td>";
            }
            
            if ($R["izbran"]){
                echo "<td><input name='zapis_".$Indx."' type='hidden' value='".$R["nid"]."'><input name='izbran_".$Indx."' type='checkbox' checked='checked' onchange='this.form.submit()'></td>";
            }else{
                echo "<td><input name='zapis_".$Indx."' type='hidden' value='".$R["nid"]."'><input name='izbran_".$Indx."' type='checkbox' onchange='this.form.submit()'></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "<tr><td></td><td></td><td align='center'>".$VsehUr."</td><td align='center'>".$VsehUcencev."</td><td align='center'>".$VsehSkupin."</td><td align='center'>".$VsehSkupin2."</td></tr>";
        echo "</table>";
        
        $Zapisov=$Indx-1;
        echo "<input name='id' type='hidden' value='26'>";
        echo "<input name='zapisov' type='hidden' value='".$Zapisov."'>";
        echo "<input name='vpisano' type='hidden' value='1'>";
        //echo "<input name='submit' type='submit' value='Obračunaj'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "26a": //izbor izbirnih predmetov z izračuni skupin in prikazom števila učencev
        if (isset($_SESSION["idsola"])){
            $VSola=intval($_SESSION["idsola"]);
        }else{
            $VSola=1;
        }
        if (isset($_POST["idsola"])){
            $VSola=intval($_POST["idsola"]);
        }
        if ($VecSol > 0){
            echo "<br /><form name='rezultati' method='post' action='izbirniskupine.php'>";
            echo "Šola/enota šole: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VSola){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["solakratko"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='26a'>";
            echo "<input name='submit' type='submit' value='Izberi'>";
            echo "</form>";
        }else{
            $VSola=1;
        }
        $_SESSION["idsola"]=$VSola;
        if (isset($_POST["vpisano"])){
            //vpiše izbire
            for ($Indx=1;$Indx <= intval($_POST["zapisov"]);$Indx++){
                if (isset($_POST["izbran_".$Indx])){
                    $SQL = "UPDATE tabnaborizb SET izbran=true WHERE id=".$_POST["zapis_".$Indx];
                }else{
                    $SQL = "UPDATE tabnaborizb SET izbran=false WHERE id=".$_POST["zapis_".$Indx];
                }
                $result = mysqli_query($link,$SQL);
            }
        }
        $SkupajSk=0;
        echo "<br />";
        for ($i=0;$i <=8;$i++){
            $SQL = "SELECT tabucenci.id FROM (tabucenci ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.idsola=".$VSola." AND tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred = $i";
            $result = mysqli_query($link,$SQL);
            $Ucencev[($i+1)]=mysqli_num_rows($result);
            
            $SQL = "SELECT id FROM tabrazdat WHERE leto=".$VLeto." AND razred = $i AND idsola=".$VSola;
            $result = mysqli_query($link,$SQL);
            $Razredov=mysqli_num_rows($result);
        }
        if (($VLeto+1) == 2015){
            echo "Za bodoče razrede 2. triade lahko oblikujete ".($Ucencev[4]+$Ucencev[5])."/24 = ".number_format(($Ucencev[4]+$Ucencev[5])/24,2)." skupin.<br />";
            echo "Za bodoče razrede 3. triade lahko oblikujete ".($Ucencev[7]+$Ucencev[8])."/24 = ".number_format(($Ucencev[7]+$Ucencev[8])/24,2)." skupin.<br />";
        }
        if (($VLeto+1) > 2015){
            echo "Za bodoče razrede 2. triade lahko oblikujete ".($Ucencev[4]+$Ucencev[5]+$Ucencev[6])."/24 = ".number_format(($Ucencev[4]+$Ucencev[5]+$Ucencev[6])/24,2)." skupin.<br />";
            echo "Za bodoče razrede 3. triade lahko oblikujete ".($Ucencev[7]+$Ucencev[8]+$Ucencev[9])."/24 = ".number_format(($Ucencev[7]+$Ucencev[8]+$Ucencev[9])/24,2)." skupin.<br />";
        }
        //$SkupajSk=$SkupajSk+number_format($Ucencev/24,2);
        //echo "Skupaj lahko oblikujete: ".$SkupajSk."<br />";
        
        echo "<form name='izbirni' method='post' action='izbirniskupine.php'>";
        echo "<br /><table border=0>";
        echo "<tr><th>Št.</th><th>Predmet</th><th>Ur</th><th>Učencev</th><th>Skupin za<br />izvajanje</th><th>Skupin</th><th>Izbran</th></tr>";
        $SQL = "SELECT tabnaborizb.id AS nid,tabnaborizb.delitev,tabnaborizb.ur,tabnaborizb.nabor,tabnaborizb.izbran,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.id FROM tabnaborizb ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabnaborizb.idsola=".$VSola." AND tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.nabor=true AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
        $SQL = $SQL . " ORDER BY tabnaborizb.izbran DESC, tabpredmeti.opis";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        $VsehSkupin=0;
        $VsehUcencev=0;
        $VsehUr=0;
        $VsehSkupin2=0;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                echo "<tr>";
            }else{
                echo "<tr style='background-color:lightgrey;'>";
            }
            echo "<td align='center'>".$Indx."</td>";
            echo "<td>".$R["opis"]." - ".$R["oznaka"]."</td>";
            echo "<td align='center'>".$R["ur"]."</td>";
            
            //pregleda število učencev prijavljenih za predmet
            //spisek izbranih predmetov
            $SQL = "SELECT tabnaborizb.predmet FROM tabnaborizb INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id  WHERE tabnaborizb.idsola=".$VSola." AND tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
            $result1 = mysqli_query($link,$SQL);
            $predmeti="";
            while ($R1 = mysqli_fetch_array($result1)){
                if (strlen($predmeti)==0){
                    $predmeti=$R1["predmet"];
                }else{
                    $predmeti=$predmeti.",".$R1["predmet"];
                }
            }
            
            //po učencih prešteje, koliko je prijavljenih na ta predmet
            if ($R["izbran"]){
                $SQL = "SELECT tabizbirniizbor.* FROM ((tabizbirniizbor ";
                $SQL .= "INNER JOIN tabrazred ON tabrazred.iducenec=tabizbirniizbor.ucenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "WHERE tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=1 AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$VSola;
                $result1 = mysqli_query($link,$SQL);
                $i=0;
                if (mysqli_num_rows($result1) > 0){
                    while ($R1 = mysqli_fetch_array($result1)){
                        $nasel=false;
                        //pogleda prvi predmet
                        if (vsebuje($predmeti,$R1["p11"])){
                            if ($R["id"] == $R1["p11"]){
                                $i=$i+1;
                                $nasel=true;
                            }
                        }else{
                            if (vsebuje($predmeti,$R1["p12"])){
                                if ($R["id"] == $R1["p12"]){
                                    $i=$i+1;
                                    $nasel=true;
                                }
                            }else{
                                if (vsebuje($predmeti,$R1["p13"])){
                                    if ($R["id"] == $R1["p13"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }
                            }
                        }
                        if ($StNeobveznihIzbirnih > 1){
                            if (!$nasel){
                                //pogleda drugi predmet
                                if (vsebuje($predmeti,$R1["p21"])){
                                    if ($R["id"] == $R1["p21"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }else{
                                    if (vsebuje($predmeti,$R1["p22"])){
                                        if ($R["id"] == $R1["p22"]){
                                            $i=$i+1;
                                            $nasel=true;
                                        }
                                    }else{
                                        if (vsebuje($predmeti,$R1["p23"])){
                                            if ($R["id"] == $R1["p23"]){
                                                $i=$i+1;
                                                $nasel=true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if ($StNeobveznihIzbirnih > 2){
                            if (!$nasel){
                                //pogleda tretji predmet
                                if (vsebuje($predmeti,$R1["p31"])){
                                    if ($R["id"] == $R1["p31"]){
                                        $i=$i+1;
                                        $nasel=true;
                                    }
                                }else{
                                    if (vsebuje($predmeti,$R1["p32"])){
                                        if ($R["id"] == $R1["p32"]){
                                            $i=$i+1;
                                            $nasel=true;
                                        }
                                    }else{
                                        if (vsebuje($predmeti,$R1["p33"])){
                                            if ($R["id"] == $R1["p33"]){
                                                $i=$i+1;
                                                $nasel=true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    echo "<td align='center'>".$i."</td>";
                    $VsehUcencev=$VsehUcencev+$i;
                    if ($i % $R["delitev"] == 0){
                        $skupin=intval($i/$R["delitev"]);
                    }else{
                        $skupin=intval($i/$R["delitev"])+1;
                    }
                    echo "<td align='center'>".$skupin."</td>";
                    $VsehUr=$VsehUr+$R["ur"]*$skupin;
                    $VsehSkupin=$VsehSkupin+$skupin;

                    if ($i % 28 == 0){
                        $skupin2=intval($i/28);
                    }else{
                        $skupin2=intval($i/28)+1;
                    }
                    echo "<td align='center'>".$skupin2."</td>";
                    $VsehSkupin2=$VsehSkupin2+$skupin2;
                }else{
                    echo "<td align='center'>0</td><td align='center'>0</td><td align='center'>0</td>";
                }
            }else{
                //neizbran predmet ima vrednosti skupin in učencev 0
                echo "<td align='center'>0</td><td align='center'>0</td><td align='center'>0</td>";
            }
            
            if ($R["izbran"]){
                echo "<td><input name='zapis_".$Indx."' type='hidden' value='".$R["nid"]."'><input name='izbran_".$Indx."' type='checkbox' checked='checked' onchange='this.form.submit()'></td>";
            }else{
                echo "<td><input name='zapis_".$Indx."' type='hidden' value='".$R["nid"]."'><input name='izbran_".$Indx."' type='checkbox' onchange='this.form.submit()'></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "<tr><td></td><td></td><td align='center'>".$VsehUr."</td><td align='center'>".$VsehUcencev."</td><td align='center'>".$VsehSkupin."</td><td align='center'>".$VsehSkupin2."</td></tr>";
        echo "</table>";
        
        $Zapisov=$Indx-1;
        echo "<input name='id' type='hidden' value='26a'>";
        echo "<input name='zapisov' type='hidden' value='".$Zapisov."'>";
        echo "<input name='vpisano' type='hidden' value='1'>";
        //echo "<input name='submit' type='submit' value='Obračunaj'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "27": //izpis izbora izbirnih predmetov po razredih
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL .= "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred IN (6,7,8)";
        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VRazred=$R2["id"];
            $VSola=$R2["idsola"];
            if ($VecSol > 0){
                echo "<h2>Izbrani izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{
                echo "<h2>Izbrani izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>1. izbirni</th><th>2. izbirni</th><th>3. izbirni</th></tr>";
            
            $Letnik=$R2["razred"];
            

            $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
            $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
            $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.idsola=".$VSola." AND tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabpredmeti.opis";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            $Predmeti[$Indx]["id"]=0;
            $Predmeti[$Indx]["opis"]="Ni izbran";
            $Predmeti[$Indx]["oznaka"]="";
            $Indx=$Indx+1;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$Indx]["id"]=$R["id"];
                $Predmeti[$Indx]["opis"]=$R["opis"];
                $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
                    
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($Indx % 2 == 0){
                    $barva= " style='background-color:white;'";
                    echo "<tr>";
                }else{
                    $barva= " style='background-color:lightyellow;'";
                    echo "<tr style='background-color:lightyellow;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                //echo "<td>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
                
                $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND tip=0 AND ucenec=".$R["iducenec"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td>";
                    $izbran[1]["id"]=0;
                    $izbran[1]["opis"]="";
                    $izbran[1]["oznaka"]="";
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p11"]==$Predmeti[$i]["id"]){
                            $izbran[1]["id"]=$Predmeti[$i]["id"];
                            $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                            $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                            echo "<b>";
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            echo "</b>";
                            break;
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p12"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p13"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        echo "-";
                    }
                    echo "</td><td>";
                    
                    $izbran[2]["id"]=0;
                    $izbran[2]["opis"]="";
                    $izbran[2]["oznaka"]="";
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p21"]==$Predmeti[$i]["id"]){
                            $izbran[2]["id"]=$Predmeti[$i]["id"];
                            $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                            $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                            echo "<b>";
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            echo "</b>";
                            break;
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p22"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p23"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        echo "-";
                    }
                    echo "</td><td>";
                    $izbran[3]["id"]=0;
                    $izbran[3]["opis"]="";
                    $izbran[3]["oznaka"]="";
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p31"]==$Predmeti[$i]["id"]){
                            $izbran[3]["id"]=$Predmeti[$i]["id"];
                            $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                            $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                            echo "<b>";
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            echo "</b>";
                            break;
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p32"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p33"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        echo "-";
                    }
                    echo "</td>";
                }else{
                    echo "<td>-</td><td>-</td><td>-</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<div class='break'></div>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "27a": //izpis izbora neobveznih izbirnih predmetov po razredih
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL .= "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred < 9";
        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VRazred=$R2["id"];
            $VSola=$R2["idsola"];
            if ($VecSol > 0){
                echo "<h2>Izbrani neobvezni izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{
                echo "<h2>Izbrani neobvezni izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th width='200'>Ime</th><th width='150'>Neobvezni<br />izbirni predmet</th></tr>";
            
            $Letnik=$R2["razred"];
            
            $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
            $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
            $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.idsola=".$VSola." AND tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabpredmeti.opis";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            $Predmeti[$Indx]["id"]=0;
            $Predmeti[$Indx]["opis"]="Ni izbran";
            $Predmeti[$Indx]["oznaka"]="";
            $Indx=$Indx+1;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$Indx]["id"]=$R["id"];
                $Predmeti[$Indx]["opis"]=$R["opis"];
                $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
                    
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($Indx % 2 == 0){
                    $barva= " style='background-color:white;'";
                    echo "<tr>";
                }else{
                    $barva= " style='background-color:lightyellow;'";
                    echo "<tr style='background-color:lightyellow;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                //echo "<td>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
                
                $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND tip=1 AND ucenec=".$R["iducenec"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td>";
                    $izbran[1]["id"]=0;
                    $izbran[1]["opis"]="";
                    $izbran[1]["oznaka"]="";
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p11"]==$Predmeti[$i]["id"]){
                            $izbran[1]["id"]=$Predmeti[$i]["id"];
                            $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                            $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                            echo "<b>";
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            echo "</b>";
                            break;
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p12"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p13"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                $izbran[1]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[1]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
						if ($R1["p11"]==0 && $R1["p12"] == 0 && $R1["p13"] == 0){
							echo "- (ni izbral/-a nobenega)";
						}else{
							echo "-";
						}
                    }
                    if ($StNeobveznihIzbirnih > 1){
                        echo "</td><td>";
                        
                        $izbran[2]["id"]=0;
                        $izbran[2]["opis"]="";
                        $izbran[2]["oznaka"]="";
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p21"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p22"]==$Predmeti[$i]["id"]){
                                    $izbran[2]["id"]=$Predmeti[$i]["id"];
                                    $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                                    $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                                    echo "<b>";
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    echo "</b>";
                                    break;
                                }
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p23"]==$Predmeti[$i]["id"]){
                                    $izbran[2]["id"]=$Predmeti[$i]["id"];
                                    $izbran[2]["opis"]=$Predmeti[$i]["opis"];
                                    $izbran[2]["oznaka"]=$Predmeti[$i]["oznaka"];
                                    echo "<b>";
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    echo "</b>";
                                    break;
                                }
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            echo "-";
                        }
                    }
                    if ($StNeobveznihIzbirnih > 2){
                        echo "</td><td>";
                        $izbran[3]["id"]=0;
                        $izbran[3]["opis"]="";
                        $izbran[3]["oznaka"]="";
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p31"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                                $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                                echo "<b>";
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                echo "</b>";
                                break;
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p32"]==$Predmeti[$i]["id"]){
                                    $izbran[3]["id"]=$Predmeti[$i]["id"];
                                    $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                                    $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                                    echo "<b>";
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    echo "</b>";
                                    break;
                                }
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p33"]==$Predmeti[$i]["id"]){
                                    $izbran[3]["id"]=$Predmeti[$i]["id"];
                                    $izbran[3]["opis"]=$Predmeti[$i]["opis"];
                                    $izbran[3]["oznaka"]=$Predmeti[$i]["oznaka"];
                                    echo "<b>";
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    echo "</b>";
                                    break;
                                }
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            echo "-";
                        }
                    }
                    echo "</td>";
                }else{
                    if ($StNeobveznihIzbirnih > 1){
                        echo "<td>-</td>";
                    }
                    if ($StNeobveznihIzbirnih > 2){
                        echo "<td>-</td>";
                    }
                    echo "<td>-</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<div class='break'></div>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "28": //izpis izbora izbirnih predmetov po predmetih
        //spisek izbranih predmetov
        $SQL = "SELECT tabnaborizb.predmet FROM tabnaborizb INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id  WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabpredmeti.OpisMSS LIKE '%/i/%' ORDER BY tabnaborizb.idsola,tabpredmeti.opis";
        $result1 = mysqli_query($link,$SQL);
        $predmeti="";
        while ($R1 = mysqli_fetch_array($result1)){
            if (strlen($predmeti)==0){
                $predmeti=$R1["predmet"];
            }else{
                $predmeti=$predmeti.",".$R1["predmet"];
            }
        }

        $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabnaborizb.idsola,tabsola.solakratko FROM (tabnaborizb ";
        $SQL .= "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id) ";
        $SQL .= "INNER JOIN tabsola ON tabnaborizb.idsola=tabsola.id ";
        $SQL .= "WHERE leto=".($VLeto+1)." AND izbran=true AND tabpredmeti.OpisMSS LIKE '%/i/%'";
        $SQL .= " ORDER BY tabnaborizb.idsola,tabpredmeti.opis,tabpredmeti.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VPredmet=$R2["id"];
            echo "<div class='break'></div>";
            if ($VecSol > 0){
                echo "<h2>".$R2["opis"]." - ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{
                echo "<h2>".$R2["opis"]." - ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th width='250'>Ime</th><th>Razred</th></tr>";

            $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabizbirniizbor.* FROM ((tabucenci ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL = $SQL . "INNER JOIN tabizbirniizbor ON tabucenci.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred IN (6,7,8) AND tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=0 AND ";
            $SQL = $SQL . "(p11=".$VPredmet." OR p12=".$VPredmet." OR p13=".$VPredmet." OR p21=".$VPredmet." OR p22=".$VPredmet." OR p23=".$VPredmet." OR p31=".$VPredmet." OR p32=".$VPredmet." OR p33=".$VPredmet.") AND tabrazdat.idsola=".$R2["idsola"];
            $SQL = $SQL . " ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $nasel=false;
                if ($R["p11"]==$VPredmet){
                    if ($Indx % 2 == 0){
                        $barva= " style='background-color:white;'";
                        echo "<tr>";
                    }else{
                        $barva= " style='background-color:lightyellow;'";
                        echo "<tr style='background-color:lightyellow;'>";
                    }
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "</tr>";
                    $nasel=true;
                    $Indx=$Indx+1;
                }
                if (!$nasel){
                    if ($R["p21"]==$VPredmet){
                        if ($Indx % 2 == 0){
                            $barva= " style='background-color:white;'";
                            echo "<tr>";
                        }else{
                            $barva= " style='background-color:lightyellow;'";
                            echo "<tr style='background-color:lightyellow;'>";
                        }
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "</tr>";
                        $nasel=true;
                        $Indx=$Indx+1;
                    }
                }
                if (!$nasel){
                    if ($R["p31"]==$VPredmet){
                        if ($Indx % 2 == 0){
                            $barva= " style='background-color:white;'";
                            echo "<tr>";
                        }else{
                            $barva= " style='background-color:lightyellow;'";
                            echo "<tr style='background-color:lightyellow;'>";
                        }
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "</tr>";
                        $nasel=true;
                        $Indx=$Indx+1;
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p11"])){
                        if ($R["p12"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                       }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p12"])){
                        if ($R["p13"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p21"])){
                        if ($R["p22"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p22"])){
                        if ($R["p23"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p31"])){
                        if ($R["p32"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p32"])){
                        if ($R["p33"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
            }
            echo "</table><br />";
        }

        //tisti, ki nimajo izbranih nobenih predmetov
        echo "<div class='break'></div>";
        echo "<h2>Učenci, ki nimajo izbranega nobenega predmeta</h2>";
        echo "<table border=1>";
        echo "<tr><th>Št.</th><th width='250'>Ime</th><th>Razred</th></tr>";

        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabizbirniizbor.* FROM ((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
        $SQL = $SQL . "INNER JOIN tabizbirniizbor ON tabucenci.iducenec=tabizbirniizbor.ucenec ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred IN (6,7,8) AND tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=0 AND ";
        $SQL = $SQL . "(NOT (p11 IN (".$predmeti.")) AND NOT (p12 IN (".$predmeti.")) AND NOT (p13 IN (".$predmeti.")) AND NOT (p21 IN (".$predmeti.")) AND NOT (p22 IN (".$predmeti.")) AND NOT (p23 IN (".$predmeti.")) AND NOT (p31 IN (".$predmeti.")) AND NOT (p32 IN (".$predmeti.")) AND NOT (p33 IN (".$predmeti."))) ";
        $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                $barva= " style='background-color:white;'";
                echo "<tr>";
            }else{
                $barva= " style='background-color:lightyellow;'";
                echo "<tr style='background-color:lightyellow;'>";
            }
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        
        echo "</body>";
        echo "</html>";
        break;
    case "28a": //izpis izbora neobveznih izbirnih predmetov po predmetih
        //spisek izbranih predmetov
        $SQL = "SELECT tabnaborizb.predmet FROM tabnaborizb INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id  WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabpredmeti.OpisMSS LIKE '%/ni/%' ORDER BY tabnaborizb.idsola,tabpredmeti.opis";
        $result1 = mysqli_query($link,$SQL);
        $predmeti="";
        while ($R1 = mysqli_fetch_array($result1)){
            if (strlen($predmeti)==0){
                $predmeti=$R1["predmet"];
            }else{
                $predmeti=$predmeti.",".$R1["predmet"];
            }
        }

        $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabnaborizb.idsola,tabsola.solakratko FROM (tabnaborizb ";
        $SQL .= "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id) ";
        $SQL .= "INNER JOIN tabsola ON tabnaborizb.idsola=tabsola.id ";
        $SQL .= "WHERE leto=".($VLeto+1)." AND izbran=true AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
        $SQL .= " ORDER BY tabnaborizb.idsola,tabpredmeti.opis,tabpredmeti.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VPredmet=$R2["id"];
            echo "<div class='break'></div>";
            if ($VecSol > 0){
                echo "<h2>".$R2["opis"]." - ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{
                echo "<h2>".$R2["opis"]." - ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th width='250'>Ime</th><th>Razred</th></tr>";

            $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabizbirniizbor.* FROM ((tabucenci ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL = $SQL . "INNER JOIN tabizbirniizbor ON tabucenci.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred < 9 AND tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=1 AND ";
            $SQL = $SQL . "(p11=".$VPredmet." OR p12=".$VPredmet." OR p13=".$VPredmet." OR p21=".$VPredmet." OR p22=".$VPredmet." OR p23=".$VPredmet." ) AND tabrazdat.idsola=".$R2["idsola"];
            $SQL = $SQL . " ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $nasel=false;
                if ($R["p11"]==$VPredmet){
                    if ($Indx % 2 == 0){
                        $barva= " style='background-color:white;'";
                        echo "<tr>";
                    }else{
                        $barva= " style='background-color:lightyellow;'";
                        echo "<tr style='background-color:lightyellow;'>";
                    }
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "</tr>";
                    $nasel=true;
                    $Indx=$Indx+1;
                }
                if ($StNeobveznihIzbirnih > 1){
                    if (!$nasel){
                        if ($R["p21"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if ($StNeobveznihIzbirnih > 2){
                    if (!$nasel){
                        if ($R["p31"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p11"])){
                        if ($R["p12"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                       }
                    }
                }
                if (!$nasel){
                    if (!vsebuje($predmeti,$R["p12"])){
                        if ($R["p13"]==$VPredmet){
                            if ($Indx % 2 == 0){
                                $barva= " style='background-color:white;'";
                                echo "<tr>";
                            }else{
                                $barva= " style='background-color:lightyellow;'";
                                echo "<tr style='background-color:lightyellow;'>";
                            }
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "</tr>";
                            $nasel=true;
                            $Indx=$Indx+1;
                        }
                    }
                }
                if ($StNeobveznihIzbirnih > 1){
                    if (!$nasel){
                        if (!vsebuje($predmeti,$R["p21"])){
                            if ($R["p22"]==$VPredmet){
                                if ($Indx % 2 == 0){
                                    $barva= " style='background-color:white;'";
                                    echo "<tr>";
                                }else{
                                    $barva= " style='background-color:lightyellow;'";
                                    echo "<tr style='background-color:lightyellow;'>";
                                }
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                                echo "</tr>";
                                $nasel=true;
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    if (!$nasel){
                        if (!vsebuje($predmeti,$R["p22"])){
                            if ($R["p23"]==$VPredmet){
                                if ($Indx % 2 == 0){
                                    $barva= " style='background-color:white;'";
                                    echo "<tr>";
                                }else{
                                    $barva= " style='background-color:lightyellow;'";
                                    echo "<tr style='background-color:lightyellow;'>";
                                }
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                                echo "</tr>";
                                $nasel=true;
                                $Indx=$Indx+1;
                            }
                        }
                    }
                }
                if ($StNeobveznihIzbirnih > 2){
                    if (!$nasel){
                        if (!vsebuje($predmeti,$R["p31"])){
                            if ($R["p32"]==$VPredmet){
                                if ($Indx % 2 == 0){
                                    $barva= " style='background-color:white;'";
                                    echo "<tr>";
                                }else{
                                    $barva= " style='background-color:lightyellow;'";
                                    echo "<tr style='background-color:lightyellow;'>";
                                }
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                                echo "</tr>";
                                $nasel=true;
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    if (!$nasel){
                        if (!vsebuje($predmeti,$R["p32"])){
                            if ($R["p33"]==$VPredmet){
                                if ($Indx % 2 == 0){
                                    $barva= " style='background-color:white;'";
                                    echo "<tr>";
                                }else{
                                    $barva= " style='background-color:lightyellow;'";
                                    echo "<tr style='background-color:lightyellow;'>";
                                }
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                                echo "</tr>";
                                $nasel=true;
                                $Indx=$Indx+1;
                            }
                        }
                    }
                }
            }
            echo "</table><br />";
        }
        //tisti, ki nimajo izbranih nobenih predmetov
        echo "<div class='break'></div>";
        echo "<h2>Učenci, ki nimajo izbranega nobenega predmeta</h2>";
        echo "<table border=1>";
        echo "<tr><th>Št.</th><th width='250'>Ime</th><th>Razred</th></tr>";

        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabizbirniizbor.* FROM ((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
        $SQL = $SQL . "INNER JOIN tabizbirniizbor ON tabucenci.iducenec=tabizbirniizbor.ucenec ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.razred IN (3,4,5) AND tabizbirniizbor.leto=".($VLeto+1)." AND tabizbirniizbor.tip=1 AND ";
        $SQL = $SQL . "(NOT (p11 IN (".$predmeti.")) AND NOT (p12 IN (".$predmeti.")) AND NOT (p13 IN (".$predmeti.")) AND NOT (p21 IN (".$predmeti.")) AND NOT (p22 IN (".$predmeti.")) AND NOT (p23 IN (".$predmeti.")) AND NOT (p31 IN (".$predmeti."))) ";
        $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx % 2 == 0){
                $barva= " style='background-color:white;'";
                echo "<tr>";
            }else{
                $barva= " style='background-color:lightyellow;'";
                echo "<tr style='background-color:lightyellow;'>";
            }
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "29": //prenos izbora izbirnih predmetov učencem
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        //najprej pobriše dodeljene izbirne predmete za naslednje šolsko leto, če slučajno že obstajajo
        $SQL = "SELECT tabizbirni.id FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE tabizbirni.leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/i/%'";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $SQL = "DELETE FROM tabizbirni WHERE id=".$R["id"];
            if ($result1 = mysqli_query($link,$SQL)){
                echo "Dodeljeni izbirni predmet za ŠL ".($VLeto+1)." je pobrisan! (".$R["id"].")<br />";
            }else{
                echo "Napaka pri brisanju izbirnih predmetov za ŠL ".($VLeto+1)."! (".$R["id"].")<br />";
            }
        }
        
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL .= "WHERE leto=".$VLeto." AND razred IN (6,7,8)";
        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VRazred=$R2["id"];
            if ($VecSol > 0){
                echo "<h2>Izbrani izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{
                echo "<h2>Izbrani izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>1. izbirni</th><th>2. izbirni</th><th>3. izbirni</th></tr>";
            
            $Letnik=$R2["razred"];
            
            $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
            $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
            $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/i/%' AND tabnaborizb.idsola=".$R2["idsola"]." ORDER BY tabpredmeti.opis";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            $Predmeti[$Indx]["id"]=0;
            $Predmeti[$Indx]["opis"]="Ni izbran";
            $Predmeti[$Indx]["oznaka"]="";
            $Indx=$Indx+1;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$Indx]["id"]=$R["id"];
                $Predmeti[$Indx]["opis"]=$R["opis"];
                $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
                    
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($Indx % 2 == 0){
                    $barva= " style='background-color:white;'";
                    echo "<tr>";
                }else{
                    $barva= " style='background-color:lightyellow;'";
                    echo "<tr style='background-color:lightyellow;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                //echo "<td>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
                
                $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND tip=0 AND ucenec=".$R["iducenec"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td>";
                    $izbran[1]["id"]=0;
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p11"]==$Predmeti[$i]["id"]){
                            $izbran[1]["id"]=$Predmeti[$i]["id"];
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            if ($Predmeti[$i]["id"] > 0){
                                $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                if (!$result3 = mysqli_query($link,$SQL)){
                                    echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                }
                            }
                            break;
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p12"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p13"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        echo "Ni izbran";
                    }
                    echo "</td><td>";
                    
                    $izbran[2]["id"]=0;
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p21"]==$Predmeti[$i]["id"]){
                            $izbran[2]["id"]=$Predmeti[$i]["id"];
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            if ($Predmeti[$i]["id"] > 0){
                                $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                if (!$result3 = mysqli_query($link,$SQL)){
                                    echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                }
                            }
                            break;
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p22"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p23"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[2]["id"] == 0){
                        echo "Ni izbran";
                    }
                    echo "</td><td>";
                    $izbran[3]["id"]=0;
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p31"]==$Predmeti[$i]["id"]){
                            $izbran[3]["id"]=$Predmeti[$i]["id"];
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            if ($Predmeti[$i]["id"] > 0){
                                $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                if (!$result3 = mysqli_query($link,$SQL)){
                                    echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                }
                            }
                            break;
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p32"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p33"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[3]["id"] == 0){
                        echo "Ni izbran";
                    }
                    echo "</td>";
                }else{
                    echo "<td>Ni izbran</td><td>Ni izbran</td><td>Ni izbran</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<div class='break'></div>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "29a": //prenos izbora izbirnih predmetov učencem
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        //najprej pobriše dodeljene izbirne predmete za naslednje šolsko leto, če slučajno že obstajajo
        $SQL = "SELECT tabizbirni.id FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE tabizbirni.leto=".($VLeto+1)." AND tabpredmeti.OpisMSS LIKE '%/ni/%'";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $SQL = "DELETE FROM tabizbirni WHERE id=".$R["id"];
            if ($result1 = mysqli_query($link,$SQL)){
                echo "Dodeljeni neobvezni izbirni predmet za ŠL ".($VLeto+1)." je pobrisan! (".$R["id"].")<br />";
            }else{
                echo "Napaka pri brisanju neobveznih izbirnih predmetov za ŠL ".($VLeto+1)."! (".$R["id"].")<br />";
            }
        }
        
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL .= "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred < 9";
        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result2 = mysqli_query($link,$SQL);
        while ($R2 = mysqli_fetch_array($result2)){
            $VRazred=$R2["id"];
            if ($VecSol > 0){
                echo "<h2>Izbrani neobvezni izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]." - ".$R2["solakratko"]."</h2>";
            }else{                
                echo "<h2>Izbrani neobvezni izbirni predmeti za razred ".($R2["razred"]+1).". ".$R2["oznaka"]."</h2>";
            }
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>1. izbirni</th><th>2. izbirni</th></tr>";
            
            $Letnik=$R2["razred"];
            
            $SQL = "SELECT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabpredmeti ";
            $SQL = $SQL . "INNER JOIN tabnaborizb ON tabpredmeti.id=tabnaborizb.predmet ";
            $SQL = $SQL . "WHERE tabnaborizb.leto=".($VLeto+1)." AND tabnaborizb.izbran=true AND tabnaborizb.r".($Letnik+1)."=true AND tabpredmeti.OpisMSS LIKE '%/ni/%' AND tabnaborizb.idsola=".$R2["idsola"]." ORDER BY tabpredmeti.opis";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            $Predmeti[$Indx]["id"]=0;
            $Predmeti[$Indx]["opis"]="Ni izbran";
            $Predmeti[$Indx]["oznaka"]="";
            $Indx=$Indx+1;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$Indx]["id"]=$R["id"];
                $Predmeti[$Indx]["opis"]=$R["opis"];
                $Predmeti[$Indx]["oznaka"]=$R["oznaka"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
                    
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM (tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            //$SQL = $SQL . "LEFT JOIN tabizbirniizbor ON tabrazred.iducenec=tabizbirniizbor.ucenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazdat.id=".$VRazred." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($Indx % 2 == 0){
                    $barva= " style='background-color:white;'";
                    echo "<tr>";
                }else{
                    $barva= " style='background-color:lightyellow;'";
                    echo "<tr style='background-color:lightyellow;'>";
                }
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                //echo "<td>".($R["razred"]+1).". ".$R["oznaka"]."</td>";
                
                $SQL = "SELECT * FROM tabizbirniizbor WHERE leto=".($VLeto+1)." AND tip=1 AND ucenec=".$R["iducenec"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td>";
                    $izbran[1]["id"]=0;
                    for ($i=2;$i <= $StPredmetov;$i++){
                        if ($R1["p11"]==$Predmeti[$i]["id"]){
                            $izbran[1]["id"]=$Predmeti[$i]["id"];
                            echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                            if ($Predmeti[$i]["id"] > 0){
                                $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                if (!$result3 = mysqli_query($link,$SQL)){
                                    echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                }
                            }
                            break;
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p12"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p13"]==$Predmeti[$i]["id"]){
                                $izbran[1]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if ($izbran[1]["id"] == 0){
                        echo "Ni izbran";
                    }
                    if ($StNeobveznihIzbirnih > 1){
                        echo "</td><td>";
                        
                        $izbran[2]["id"]=0;
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p21"]==$Predmeti[$i]["id"]){
                                $izbran[2]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";

                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p22"]==$Predmeti[$i]["id"]){
                                    $izbran[2]["id"]=$Predmeti[$i]["id"];
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    if ($Predmeti[$i]["id"] > 0){
                                        $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                        if (!$result3 = mysqli_query($link,$SQL)){
                                            echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p23"]==$Predmeti[$i]["id"]){
                                    $izbran[2]["id"]=$Predmeti[$i]["id"];
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    if ($Predmeti[$i]["id"] > 0){
                                        $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                        if (!$result3 = mysqli_query($link,$SQL)){
                                            echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if ($izbran[2]["id"] == 0){
                            echo "Ni izbran";
                        }
                    }
                    if ($StNeobveznihIzbirnih > 2){
                        echo "</td><td>";
                        $izbran[3]["id"]=0;
                        for ($i=2;$i <= $StPredmetov;$i++){
                            if ($R1["p31"]==$Predmeti[$i]["id"]){
                                $izbran[3]["id"]=$Predmeti[$i]["id"];
                                echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                if ($Predmeti[$i]["id"] > 0){
                                    $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                    if (!$result3 = mysqli_query($link,$SQL)){
                                        echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                    }
                                }
                                break;
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p32"]==$Predmeti[$i]["id"]){
                                    $izbran[3]["id"]=$Predmeti[$i]["id"];
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    if ($Predmeti[$i]["id"] > 0){
                                        $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                        if (!$result3 = mysqli_query($link,$SQL)){
                                            echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            for ($i=2;$i <= $StPredmetov;$i++){
                                if ($R1["p33"]==$Predmeti[$i]["id"]){
                                    $izbran[3]["id"]=$Predmeti[$i]["id"];
                                    echo $Predmeti[$i]["opis"]." - ".$Predmeti[$i]["oznaka"];
                                    if ($Predmeti[$i]["id"] > 0){
                                        $SQL = "INSERT INTO tabizbirni (ucenec,leto,izbirni) VALUES (".$R["iducenec"].",".($VLeto+1).",".$Predmeti[$i]["id"].")";
                                        if (!$result3 = mysqli_query($link,$SQL)){
                                            echo "<br />Predmet ni vpisan: ".$R["priimek"]." ".$R["ime"]." ".$Predmeti[$i]["oznaka"]."<br />";
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if ($izbran[3]["id"] == 0){
                            echo "Ni izbran";
                        }
                    }
                    echo "</td>";
                }else{
                    if ($StNeobveznihIzbirnih > 1){
                        echo "<td>Ni izbran</td>";
                    }
                    if ($StNeobveznihIzbirnih > 2){
                        echo "<td>Ni izbran</td>";
                    }
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<div class='break'></div>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "30":
        //obvestila učencem o izbranih izbirnih predmetih
        
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
        for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
            $SQL = "SELECT * FROM TabSola WHERE id=".$sole[$IndxSola][0];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["SolaKratko"];
                $VNaslov=$R["Naslov"];
                $VPosta=$R["Posta"]." ".$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $VRavnateljID=$R["ravnatelj_ID"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola="";
                $VNaslov="";
                $VPosta="";
                $VRavnatelj="";
                $VRavnateljID=0;
                $VKraj="";
            }
            
            $SQL = "SELECT spol FROM tabucitelji WHERE iducitelj=$VRavnateljID";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $RavnateljSpol=$R["spol"];
            }

            $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL .= "WHERE leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]." AND razred IN (6,7,8)";
            $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
            $result2 = mysqli_query($link,$SQL);
            while ($R2 = mysqli_fetch_array($result2)){
                $VRazred=$R2["id"];
                
                $SQL = "SELECT tabucenci.ime,tabucenci.priimek,tabucenci.iducenec,tabucenci.spol FROM tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                $SQL .= "WHERE tabrazred.idrazred=$VRazred ";
                $SQL .= "ORDER BY tabucenci.priimek,tabucenci.ime";
                $result3 = mysqli_query($link,$SQL);
                while ($R3 = mysqli_fetch_array($result3)){
                    echo "<p class='break'>";
                    echo $VSola."<br />";
                    echo $VNaslov."<br />";
                    echo $VPosta."<br />";
                    echo "</p>";
                    echo "<p>Datum: ".$Danes->format('j.n.Y')."</p>";
                    echo "<p>Zadeva: <b>Obvestilo o izbirnih predmetih</b></p>";
                    echo "<p>Spoštovani!</p>";
                    echo "<p>";
                    echo "Na osnovi predlaganih in izbranih izbirnih predmetov, ki se bodo na $VSola izvajali v šolskem letu ".($VLeto+1)."/".($VLeto+2)." bo ";
                    if ($R3["spol"]=="M"){
                        echo "učenec <b>".$R3["ime"]." ".$R3["priimek"].", ".$R2["razred"].". ".$R2["oznaka"]."</b> obiskoval ";
                    }else{
                        echo "učenka <b>".$R3["ime"]." ".$R3["priimek"].", ".$R2["razred"].". ".$R2["oznaka"]."</b> obiskovala ";
                    }
                    echo "naslednje izbirne predmete:";
                    echo "</p>";
                    echo "<p>";
                    $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                    $SQL .= "WHERE tabizbirni.ucenec=".$R3["iducenec"]." AND leto=".($VLeto+1);
                    $result4 = mysqli_query($link,$SQL);
                    if (isset($result4)){
                        if (mysqli_num_rows($result4) > 0){
                            while ($R4 = mysqli_fetch_array($result4)){
                                echo "<b>".$R4["opis"]."</b><br />";
                            }
                        }else{
                            echo "Nima izbranih izbirnih predmetov";
                        }
                    }else{
                        echo "Nima izbranih izbirnih predmetov";
                    }
                    echo "</p>";
                    //izbrani izbirni predmeti
                    echo "<p>V šolskem letu ".($VLeto+1)."/".($VLeto+2)." bomo v ".($R2["razred"]+1).". razredu izvajali naslednje izbirne predmete:<br />";
                    $SQL = "SELECT tabnaborizb.predmet,tabpredmeti.opis FROM tabnaborizb ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                    $SQL .= "WHERE tabnaborizb.leto=".($VLeto+1)." AND izbran=true AND idsola=".$sole[$IndxSola][0];
                    switch ($R2["razred"]+1){
                        case 9:
                            $SQL .= " AND tabnaborizb.r9=true ";
                            break;
                        case 8:
                            $SQL .= " AND tabnaborizb.r8=true ";
                            break;
                        case 7:
                            $SQL .= " AND tabnaborizb.r7=true ";
                            break;
                    }
                    $SQL .= " ORDER BY tabpredmeti.opis";
                    $result4 = mysqli_query($link,$SQL);
                    while ($R4 = mysqli_fetch_array($result4)){
                        if ($R4["predmet"] != 189){
                            echo $R4["opis"]."<br />";
                        }
                    }
                    echo "</p>";
                    
                    echo "<p>S spoštovanjem in lep pozdrav,<br /></p>";
                    echo "<p>";
                    echo "<table class='normal' width='100%'>";
                    echo "<tr class='hide'>";
                    echo "<td class='hide' width='50%'>&nbsp;</td>";
                    if ($RavnateljSpol == "M"){
                        echo "<td class='hide' width='50%' align='center'>Ravnatelj:<br />$VRavnatelj</td>";
                    }else{
                        echo "<td class='hide' width='50%' align='center'>Ravnateljica:<br />$VRavnatelj</td>";
                    }
                    echo "</tr>";
                    echo "</table>";
                    echo "</p>";
                }
            }
        }
        break;
    case "30a":
        //obvestila učencem o izbranih neobveznih izbirnih predmetih
        
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
        for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
            $SQL = "SELECT * FROM TabSola WHERE id=".$sole[$IndxSola][0];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["SolaKratko"];
                $VNaslov=$R["Naslov"];
                $VPosta=$R["Posta"]." ".$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $VRavnateljID=$R["ravnatelj_ID"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola="";
                $VNaslov="";
                $VPosta="";
                $VRavnatelj="";
                $VRavnateljID=0;
                $VKraj="";
            }
            
            $SQL = "SELECT spol FROM tabucitelji WHERE iducitelj=$VRavnateljID";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $RavnateljSpol=$R["spol"];
            }

            $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL .= "WHERE leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]." AND razred IN (3,4,5)";
            $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
            $result2 = mysqli_query($link,$SQL);
            while ($R2 = mysqli_fetch_array($result2)){
                $VRazred=$R2["id"];
                
                $SQL = "SELECT tabucenci.ime,tabucenci.priimek,tabucenci.iducenec,tabucenci.spol FROM tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                $SQL .= "WHERE tabrazred.idrazred=$VRazred ";
                $SQL .= "ORDER BY tabucenci.priimek,tabucenci.ime";
                $result3 = mysqli_query($link,$SQL);
                while ($R3 = mysqli_fetch_array($result3)){
                    echo "<p class='break'>";
                    echo $VSola."<br />";
                    echo $VNaslov."<br />";
                    echo $VPosta."<br />";
                    echo "</p>";
                    echo "<p>Datum: ".$Danes->format('j.n.Y')."</p>";
                    echo "<p>Zadeva: <b>Obvestilo o neobveznih izbirnih predmetih</b></p>";
                    echo "<p>Spoštovani!</p>";
                    echo "<p>";
                    echo "Na osnovi predlaganih in izbranih neobveznih izbirnih predmetov, ki se bodo na $VSola izvajali v šolskem letu ".($VLeto+1)."/".($VLeto+2)." bo ";
                    if ($R3["spol"]=="M"){
                        echo "učenec <b>".$R3["ime"]." ".$R3["priimek"].", ".$R2["razred"].". ".$R2["oznaka"]."</b> obiskoval ";
                    }else{
                        echo "učenka <b>".$R3["ime"]." ".$R3["priimek"].", ".$R2["razred"].". ".$R2["oznaka"]."</b> obiskovala ";
                    }
                    $SQL = "SELECT tabizbirni.izbirni,tabpredmeti.oznaka,tabpredmeti.opis FROM tabizbirni ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id ";
                    $SQL .= "WHERE tabizbirni.ucenec=".$R3["iducenec"]." AND leto=".($VLeto+1);
                    $result4 = mysqli_query($link,$SQL);
                    if (isset($result4)){
                        if (mysqli_num_rows($result4) > 0){
                            if (mysqli_num_rows($result4) > 1){
                                echo "naslednje neobvezne izbirne predmete:";
                            }else{
                                echo "naslednji neobvezni izbirni predmet:";
                            }
                            echo "</p>";
                            echo "<p>";
                            while ($R4 = mysqli_fetch_array($result4)){
                                echo "<b>".$R4["opis"]."</b><br />";
                            }
                        }else{
                            echo "naslednji neobvezni izbirni predmeti:";
                            echo "</p>";
                            echo "<p>";
                            echo "Nima izbranih neobveznih izbirnih predmetov";
                        }
                    }else{
                        echo "naslednji neobvezni izbirni predmeti:";
                        echo "</p>";
                        echo "<p>";
                        echo "Nima izbranih neobveznih izbirnih predmetov";
                    }
                    echo "</p>";
                    //izbrani izbirni predmeti
                    echo "<p>V šolskem letu ".($VLeto+1)."/".($VLeto+2)." bomo v ".($R2["razred"]+1).". razredu izvajali naslednje neobvezne izbirne predmete:<br />";
                    $SQL = "SELECT tabnaborizb.predmet,tabpredmeti.opis FROM tabnaborizb ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                    $SQL .= "WHERE tabnaborizb.leto=".($VLeto+1)." AND izbran=true AND idsola=".$sole[$IndxSola][0];
                    switch ($R2["razred"]+1){
                        case 4:
                            $SQL .= " AND tabnaborizb.r4=true ";
                            break;
                        case 5:
                            $SQL .= " AND tabnaborizb.r5=true ";
                            break;
                        case 6:
                            $SQL .= " AND tabnaborizb.r6=true ";
                            break;
                    }
                    $SQL .= " ORDER BY tabpredmeti.opis";
                    $result4 = mysqli_query($link,$SQL);
                    while ($R4 = mysqli_fetch_array($result4)){
                        echo $R4["opis"]."<br />";
                    }
                    echo "</p>";

                    echo "<p>S spoštovanjem in lep pozdrav,<br /></p>";
                    echo "<p>";
                    echo "<table class='normal' width='100%'>";
                    echo "<tr class='hide'>";
                    echo "<td class='hide' width='50%'>&nbsp;</td>";
                    if ($RavnateljSpol == "M"){
                        echo "<td class='hide' width='50%' align='center'>Ravnatelj:<br />$VRavnatelj</td>";
                    }else{
                        echo "<td class='hide' width='50%' align='center'>Ravnateljica:<br />$VRavnatelj</td>";
                    }
                    echo "</tr>";
                    echo "</table>";
                    echo "</p>";
                }
            }
        }
        break;
}

?>
