<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo5",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');
    
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    echo "<h2>Izbor delavcev za vnos potnega naloga</h2>";
    echo "<form name='ucitelji' method='post' action='VnosPotniNalogi.php'>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "<table border='0'>";
    echo "<tr><th>Ime</th><th>Delovno mesto</th></tr>";
    //echo "<tr><th>Ime</th></tr>"

    //'SQL = "SELECT tabucitelji.*,TabVzgDelo.* FROM tabucitelji INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.IdVzgojnoDelo WHERE status > 0 ORDER BY priimek,ime"
    $SQL = "SELECT tabucitelji.* FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
    //echo "<br>" & $SQL & "<br>"
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $oUcitelj=new RUcitelj;
        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$Danes->format('Y'),$VLeto);
	    echo "<tr>";
	    echo "<td><input name='pn".$Indx."' type='checkbox'><input type='hidden' name='uc".$Indx."' value='".$oUcitelj->getIdUcitelj()."'> " .$oUcitelj->getPriimek() . " " .$oUcitelj->getIme(). "</td>";
	    echo "<td>".$oUcitelj->getDelMesto()."</td>";
	    echo "</tr>";
        $oUcitelj=null;
	    $Indx=$Indx+1;
    }
    echo "</table>";
    $StUciteljev=$Indx-1;

    echo "<input name='StUciteljev' type='hidden' value='".$StUciteljev."'>";
    echo "<input name='id' type='hidden' value='1'>";

    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";

    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
}
?>

</body>
</html>
