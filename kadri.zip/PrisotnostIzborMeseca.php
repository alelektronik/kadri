<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prisotnost
</title>
</head>
<body>

<?php
$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}


$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

/*
if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

$VLeto=$Danes->format('Y');
switch ($Vid){
    case "1":
        echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrisotnostMesec5.php'>";
        break;
    case "2":
        echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrisotnostMesec5.php'>";
        break;
    case "3":
        echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrisotnostMesec5.php'>";
        break;
    case "4":
        echo "<form accept-charset='utf-8' name='rezultati' method='post' action='IzpisOdsotnosti.php'>";
        break;
    case "5":
        echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrisotnostMesec.php'>";
        break;
}

echo "<h2>Izberite leto in mesec</h2><br>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>";
echo "        Leto: <select name='leto'>";

$SQL = "SELECT DISTINCT tabprihodi.letopr FROM tabprihodi ORDER BY tabprihodi.letopr DESC";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    if ($R["letopr"] > 0){
        if ($R["letopr"] == $VLeto){
            echo "<option value='" .  $R["letopr"]  . "' selected='selected'>" . $R["letopr"] . "</option>";
        }else{
            echo "<option value='" .  $R["letopr"]  . "'>" . $R["letopr"] . "</option>";
        }
    }
}
echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "<tr>";
echo "    <td>";
echo "        Mesec:<select name='mesec'>";
echo "<option selected>" . $Danes->format('n') . "</option>";
for ($i=1;$i <= 12;$i++){
    echo "<option>".$i."</option>";
}
echo "        </select>";
echo "    </td>";
echo "</tr>";

if ($Vid=="1"){
    echo "<tr>";
    echo "    <td>";
    echo "        Delavec:<select name='delavec'>";
    echo "<option value='0'>Ni izbran</option>";
    if ($VLevel < 2){
        $SQL = "SELECT stdelavca,priimime FROM kadrovi WHERE EMSO='".$Ucitelj."' ORDER BY priimime";
    }else{
        if (!CheckDostop("Prisotnost",$VUporabnik) ) {
            $SQL = "SELECT stdelavca,priimime FROM kadrovi WHERE EMSO='".$Ucitelj."' ORDER BY priimime";
        }else{
            $SQL = "SELECT stdelavca,priimime FROM kadrovi ORDER BY priimime";
        }
    }
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        if (strlen($R["priimime"]) > 0){
            echo "<option value=".$R["stdelavca"].">".$R["priimime"]."</option>";
        }
    }
    echo "        </select>";
    echo "    </td>";
    echo "</tr>";
}
if ($Vid=="3"){
    echo "<input name='izpisur' type='hidden' value='1'>";
}
echo "<tr>";
echo "    <td>";
echo "        <input name='submit' type='submit' value='Pošlji'>";
echo "    </td>";
echo "</tr>";
echo "</table>";
echo "</form>";
echo "</body>";
echo "</html>";

?>

