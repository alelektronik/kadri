<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

class PDF extends FPDF {
    var $B;
    var $I;
    var $U;
    var $HREF;

    function PDF($orientation='P', $unit='mm', $size='A4')
    {
        // Call parent constructor
        $this->FPDF($orientation,$unit,$size);
        // Initialization
        $this->B = 0;
        $this->I = 0;
        $this->U = 0;
        $this->HREF = '';
    }

    function WriteHTML($h,$html)
    {
        // HTML parser
        $html = str_replace("\n",' ',$html);
        $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
        foreach($a as $i=>$e)
        {
            if($i%2==0)
            {
                // Text
                if($this->HREF)
                    $this->PutLink($this->HREF,$h,$e);
                else
                    $this->Write($h,$e);
            }
            else
            {
                // Tag
                if($e[0]=='/')
                    $this->CloseTag(strtoupper(substr($e,1)));
                else
                {
                    // Extract attributes
                    $a2 = explode(' ',$e);
                    $tag = strtoupper(array_shift($a2));
                    $attr = array();
                    foreach($a2 as $v)
                    {
                        if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                            $attr[strtoupper($a3[1])] = $a3[2];
                    }
                    $this->OpenTag($tag,$attr,$h);
                }
            }
        }
    }

    function OpenTag($tag, $attr,$h)
    {
        // Opening tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,true);
        if($tag=='A')
            $this->HREF = $attr['HREF'];
        if($tag=='BR')
            $this->Ln($h);
    }

    function CloseTag($tag)
    {
        // Closing tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,false);
        if($tag=='A')
            $this->HREF = '';
    }

    function SetStyle($tag, $enable)
    {
        // Modify style and select corresponding font
        $this->$tag += ($enable ? 1 : -1);
        $style = '';
        foreach(array('B', 'I', 'U') as $s)
        {
            if($this->$s>0)
                $style .= $s;
        }
        $this->SetFont('',$style);
    }

    function PutLink($URL,$h, $txt)
    {
        // Put a hyperlink
        $this->SetTextColor(0,0,255);
        $this->SetStyle('U',true);
        $this->Write($h,$txt,$URL);
        $this->SetStyle('U',false);
        $this->SetTextColor(0);
    }
}

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function PreveriOcene($txt){
    $prej="";
    if (strlen($txt) > 0){
        $txt=str_replace(","," ",$txt);
        $txt=str_replace("  "," ",$txt);
        $i=0;
        while ($i < strlen($txt)){
            if ((is_numeric(substr($txt,$i,1))) && ($prej != " ")) {
                $txt=substr($txt,0,$i)." ".substr($txt,$i,strlen($txt)-$i);
                $i=$i+1;
            }
            $prej=substr($txt,$i,1);
            $i=$i+1;
        }
    }
    return $txt;
}
function MonthName($x){
    switch ($x){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }       
}

function ToPredmetUspeh($ocena){
    switch ($ocena){
        case "5":
            return "odlično (5)";
            break;
        case "4":
            return "prav dobro (4)";
            break;
        case "3":
            return "dobro (3)";
            break;
        case "2":
            return "zadostno (2)";
            break;
        case "1":
        case "Ni opravil":
            return "nezadostno (1)";
        default:
            return "     / ";
    }
}
function ToNPredmet($txt){
    global $Ocene;
    
    for ($i=0;$i < count($Ocene);$i++){
        if (is_numeric(strpos($Ocene[$i]["oznaka"],$txt))){
            return $i;  //na i-tem mestu je ta ocena
        }
    }
    return -1;  //ne vsebuje te ocene
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

if (isset($_POST["ucenec"])){
    $ucenec = $_POST["ucenec"];
}else{
    if (isset($_GET["ucenec"])){
        $ucenec=$_GET["ucenec"];
    }else{
        $ucenec = 0;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}
if (isset($_SESSION["posx"])){
    $KorX = $_SESSION["posx"];
}else{
    $KorX = 0;
}
if (isset($_SESSION["posy"])){
    $KorY = $_SESSION["posy"];
}else{
    $KorY = 0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay = $_SESSION["DayToPrint"];
}else{
    $PrintDay = $Danes->format('j. n. Y');
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe="";
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix=$_SESSION["RefStFix"];
}else{
    $RefStFix="";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar=$_SESSION["RefStVar"];
}else{
    $RefStVar=1;
}
if (!is_numeric($RefStVar)){
    $RefStVar=1;
}
$_SESSION["leto"] = $VLeto;
$_SESSION["posx"] = $KorX;
$_SESSION["posy"] = $KorY;
$_SESSION["DayToPrint"]=$PrintDay;
$_SESSION["KorOpombe"]=$KorOpombe;
$_SESSION["RefStFix"]=$RefStFix;
$_SESSION["RefStVar"]=$RefStVar;

if ($VecSol > 0){
    $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $idsola=$R["idsola"];
    }else{
        $idsola=1;
    }
    
    $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VSola=$R["Sola"];
        $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
        $VSolaKraj=$R["Kraj"];
        $VRavnatelj=$R["Ravnatelj"];
        $TipSole=$R["TipSole"];
        $RavnateljID=$R["ravnatelj_ID"];
    }else{
        $VSola=" ";
        $VRavnatelj=" ";
        $RavnateljID=0;
        $VSolaNaslov="";
        $VSolaKraj="";
        $TipSole=0;
    }
}else{
    $SQL = "SELECT * FROM tabsola";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VSola=$R["Sola"];
        $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
        $VSolaKraj=$R["Kraj"];
        $VRavnatelj=$R["Ravnatelj"];
        $TipSole=$R["TipSole"];
        $RavnateljID=$R["ravnatelj_ID"];
    }else{
        $VSola=" ";
        $VRavnatelj=" ";
        $RavnateljID=0;
        $VSolaNaslov="";
        $VSolaKraj="";
        $TipSole=0;
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $SpolRavnatelj=$R["Spol"];
}else{
    $SpolRavnatelj="M";
}

switch ($Vid){
    case "1": //ObvestiloOUspehuPDF, ObvestiloOUspehuRazredPDF   - prvo polletje
        $pdf = new PDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        if ($ucenec==0){
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx;
        }else{
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ucenec){
                    $ucenci[$Indx]=$R["IdUcenec"];
                }
            }
            $StUcencev=1;
        }
        /*    
        if (strlen($RefStFix) == 0){
            $RefStFix="60302-2/".$Danes->format('Y')."-".$VRazred."-";
        }
        */
        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            $Predmeti=$oUcenec->getPredmeti($VLeto);
            $StPredmetov=count($Predmeti);
            $Ocene=$oUcenec->getOcene($VLeto);
            $StOcen=count($Ocene);
            
            //' Create a graphic incuding all the rectangles and lines to be used in the document
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            $pdf->Line(10.0, 297-213.0, 194.0, 297-213.0);
            $pdf->Line(10.0,  297-63.0, 194.0,  297-63.0);
            $pdf->SetFillColor(222,222,222);
            $pdf->Rect( 10.0, 297-273.0, 184, 11,"DF");
            
            $YPoz=297-200;
            $ColorChange=false;
            for ($Indx=0;$Indx <= $StPredmetov;$Indx++){
                if ($ColorChange ){
                    $pdf->SetFillColor(222,222,222); //siva
                }else{
                    $pdf->SetFillColor(255,255,255);       //bela
                }
                $ColorChange=!$ColorChange;
                $pdf->Rect( 39.0, $YPoz+$Indx*7+0.5,156,7,"F");
            }

            //' Read the logo image from a file and draw it on the page.  Position the logo using the Locate and ScaleObject commands
            $pdf->Image("slogrb.gif",13.0, 297-271.0);
            $pdf->Image("republika-slovenija-slo.gif",23.0, 297-269.0);
            
            //'izpiše zakonsko podlago
            $pdf->SetLeftMargin(80);
            $pdf->SetFont('arial_CE','',6);
            $pdf->SetXY(80,297-272);
            $txt=ToWin("Na podlagi 63. člena Zakona o osnovni šoli (Uradni list RS, št. 12/96 in spremembe) in v skladu<br>z 2. točko 13. člena Pravilnika o dokumentaciji v 9-letni osnovni šoli (Uradni list RS,<br>št. 64/99 in spremembe) izdaja");
            $pdf->WriteHTML(3,$txt);
            $pdf->SetLeftMargin(10);
            
            //'izpiše podatke o šoli
            if (strlen($VSola) > 48 ){
                if (strlen($VSola) > 60 ){
                    $pdf->SetFontSize(11);
                    $LineHigh=5.5;
                }else{    
                    $pdf->SetFontSize(12);
                    $LineHigh=6;
                }
            }else{
                $pdf->SetFontSize(18);
                $LineHigh=9;
            }
            
            $pdf->SetXY(10,297-260+3);
            $txt=ToWin($VSola);
            $pdf->Cell(0,0,$txt,0,2,"C");
             
            //'naslov dokumenta
            $LineHigh=9;
            $pdf->SetFont('arialbd_CE','',18);
            $txt=ToWin("OBVESTILO o učnem uspehu");
            $pdf->SetXY(10,297-250+3);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov dokumenta
            $pdf->SetFontSize(12);
            $LineHigh=6;
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("v prvem vzgojno izobraževalnem obdobju v devetletni osnovni šoli");
            $pdf->SetXY(10,297-239+3);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',18);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10,297-230+3);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Datum rojstva: ");
            $pdf->SetXY(10,297-220+3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(30,297-222+4);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //izpis razrednih podatkov
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Razred, oddelek: ");
            $pdf->SetXY(104,297-220+3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(140,297-222+4);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Šolsko leto: ");
            $pdf->SetXY(10,297-210+2);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(30,297-212+3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Ocenjevalno obdobje: ");
            $pdf->SetXY(104,297-210+2);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin("1.");
            $pdf->SetXY(140,297-212+3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //izpis predmetov in ocen
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Ocene pri posameznih predmetih: ");
            $pdf->SetXY(10,297-203+2);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $YPoz=297-200.0+4;

            $pdf->SetFont('arialbd_CE','',10);
            $txt=ToWin("Predmet");
            $pdf->SetXY(40,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");
                
            $txt=ToWin("Pisne ocene");
            $pdf->SetXY(110,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Ustne ocene");
            $pdf->SetXY(140,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Zaključna ocena");
            $pdf->SetXY(167,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',10);
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                //izpis predmeta
                $j=-1; //index ocen
                for ($i=0;$i < $StOcen;$i++){
                    if ($Predmeti[$Indx]["id"]==$Ocene[$i]["id"]){
                        $j=$i;
                        break;
                    }
                }
                
                if ($j < 0){
                    $txt=ToWin($Predmeti[$Indx]["oznaka"]." - ".$Predmeti[$Indx]["opis"]);
                    $pdf->SetXY(40,$YPoz+($Indx+1)*7);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt=ToWin($Ocene[$j]["oznaka"]." - ".$Predmeti[$Indx]["opis"]);
                    $pdf->SetXY(40,$YPoz+($Indx+1)*7);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    switch ($Ocene[$j]["neocenjen"]){
                        case 0: //ocene
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(110,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(140,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin($Ocene[$j]["koncna"]);
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                        case 1: //neocenjen
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(110,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(140,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin("neocenjeno");
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                        case 2: //opravičen
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(110,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(140,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin("oproščeno");
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                    }
                }
            }
            $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$oUcenec->getIdUcenec() . " AND leto=".$VLeto." ORDER BY leto,mesec DESC";
            $result = mysqli_query($link,$SQL);

            for ($Indx=0;$Indx <= 10;$Indx++){
                $VIzostanki[$Indx][0]=0;
                $VIzostanki[$Indx][1]=0;
            }

            while ($R = mysqli_fetch_array($result)){
                if ($R["Mesec"] > 0 ){
                    $VIzostanki[0][0]=$VIzostanki[0][0]+$R["Opraviceno"];
                    $VIzostanki[0][1]=$VIzostanki[0][1]+$R["Neopraviceno"];
                }else{
                    $VIzostanki[1][0]=$VIzostanki[1][0]+$R["Opraviceno"];
                    $VIzostanki[1][1]=$VIzostanki[1][1]+$R["Neopraviceno"];
                }
            } 
            
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Izostanki:");
            $pdf->SetXY(110,297-74+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if ($VLeto > 2006){
                $txt=ToWin("Opravičene ure: ".$VIzostanki[0][0]." Neopravičene ure: ".$VIzostanki[0][1]);
            }else{
                $txt=ToWin("Opravičene ure: ".$VIzostanki[1][0]." Neopravičene ure: ".$VIzostanki[1][1]);
            }    
            $pdf->SetXY(110,297-68+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if ($Razred["spolr"]=="M"){
                $txt=ToWin("Razrednik:");
            }else{
                $txt=ToWin("Razredničarka:");
            }
            $pdf->SetXY(10,297-61+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Podpis staršev oz. zakonitega zastopnika:");
            $pdf->SetXY(100,297-61+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(10,297-56+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',12);
            $datum=null;
            if (strlen($RefStFix) > 0){
                $txt=ToWin("Evid. št.: ".$RefStFix.$RefStVar);
                $RefStVar += 1;
            }else{
                $SQL = "SELECT evstev,datum FROM tabevstevilkeu WHERE iducenec=".$oUcenec->getIdUcenec()." AND leto=$VLeto AND dokument=2";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $txt=ToWin("Evid. št.: ".$R["evstev"]);
                    $datum=new DateTime($R["datum"]);
                }else{
                    $txt=ToWin("Evid. št.: ");
                }
            }
            $pdf->SetXY(10,297-43+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Kraj in datum:");
            $pdf->SetXY(10,297-36+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',12);
            if (isset($datum)){
                $txt=ToWin($VSolaKraj.", ".$datum->format('j. n. Y'));
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(10,297-32+1);
            $pdf->Cell(0,0,$txt,0,2,"L");

        }    
        $pdf->Output("ObvestiloOUspehu.pdf","D");
        break;
    case "2": //  SpričevalaRazredPDF
        $pdf = new PDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        if ($ucenec==0){
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx;
        }else{
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ucenec){
                    $ucenci[$Indx]=$R["IdUcenec"];
                }
            }
            $StUcencev=1;
        }    
        $FontSize=11;
        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            $Predmeti=$oUcenec->getPredmeti($VLeto);
            $StPredmetov=count($Predmeti);
            $Ocene=$oUcenec->getOcene($VLeto);
            $StOcen=count($Ocene);
            $Izbirni=$oUcenec->getIzbirni($VLeto);
            $StIzbirnih=count($Izbirni);
            
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,98.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,110-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,110-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis redovalnice
            //'slovenscina
            $NPredmet=ToNPredmet("SLJ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,141-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,141-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'matematika
            $NPredmet=ToNPredmet("MAT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,147.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,147.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            //'Anglescina
            $NPredmet=ToNPredmet("TJA");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,154-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                //'Anglescina - napis predmeta
                $txt=ToWin("angleščina");
                $pdf->SetXY(15+$KorX,154-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                //'Nemščina
                $NPredmet=ToNPredmet("TJN");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(65+$KorX,154-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'Nemščina - napis predmeta
                    $txt=ToWin("nemščina");
                    $pdf->SetXY(15+$KorX,154-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(65+$KorX,154-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
            }
            
            //'Likovna vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("LVZ");
            }else{
                $NPredmet=ToNPredmet("LUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,160.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,160.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Glasbena vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("GVZ");
            }else{
                $NPredmet=ToNPredmet("GUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Druzba
            if (!is_numeric(strpos($TipSole,"prilagojenim"))){  //ne gre za OŠPP
                $NPredmet=ToNPredmet("DRU");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(65+$KorX,173-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(65+$KorX,173-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }

            //'Geografija
            $NPredmet=ToNPredmet("GEO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,179.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,179.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Zgodovina
            $NPredmet=ToNPredmet("ZGO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Drzavljanska vzgoja in etika
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("DDE");
            }else{
                $NPredmet=ToNPredmet("DKE");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,196-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,196-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Fizika
            $NPredmet=ToNPredmet("FIZ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,205.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,205.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
//'drugi stolpec
            //'Kemija
            $NPredmet=ToNPredmet("KEM");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,141-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,141-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Biologija
            $NPredmet=ToNPredmet("BIO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,147.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,147.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Naravoslovje
            $NPredmet=ToNPredmet("NAR");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,154-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,154-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Naravoslovje in tehnika
            $NPredmet=ToNPredmet("NIT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,160.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,160.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Tehnika in tehnologija
            $NPredmet=ToNPredmet("TIT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Gospodinjstvo
            $NPredmet=ToNPredmet("GOS");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,173-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,173-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Sportna vzgoja
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("ŠVZ");
            }else{
                $NPredmet=ToNPredmet("ŠPO");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,179.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,179.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'izbirni predmeti    
            //'1. izbirni predmet
            if (isset($Izbirni[0]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'OSPP
            if (is_numeric(strpos($TipSole,"prilagojenim"))){
                //'družboslovje
                $NPredmet=ToNPredmet("DRU");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,193-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    //'napis predmeta
                    $txt=ToWin("Družboslovje");
                    $pdf->SetXY(110+$KorX,193-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,193-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                //'2. izbirni predmet
                if (isset($Izbirni[1]["oznaka"])){
                    $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                    if ($NPredmet >= 0){
                        switch ($Ocene[$NPredmet]["neocenjen"]){
                            case 0: //ocena
                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                break;
                            case 1: //neocenjeno
                                $txt="neocenjeno";
                                break;
                            case 2: //oproščeno
                                $txt=ToWin("oproščeno");
                        }
                        $pdf->SetXY(161+$KorX,193-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        //'napis predmeta
                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                        $pdf->SetXY(110+$KorX,193-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }else{
                        $txt="  /  ";
                        $pdf->SetXY(161+$KorX,193-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }    
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,193-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }
            //'3. izbirni predmet
            if (isset($Izbirni[2]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,199-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,199-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,199-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,199-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'4. izbirni predmet
            if (isset($Izbirni[3]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,205.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,205.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,205.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,205.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(68.0+$KorX, 226-$KorY, 117+$KorX, 226-$KorY);
            }else{
                $pdf->Line(120.0+$KorX, 226-$KorY, 143+$KorX, 226-$KorY);
            }
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 280.8-$KorY, 44+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 280.8-$KorY, 31+$KorX, 280.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 280.8-$KorY, 164+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 280.8-$KorY, 151+$KorX, 280.8-$KorY);
            }

            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,240-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,275.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,275.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,259.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,259.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
        }    
        $pdf->Output("spricevala.pdf","D");
        break;
        
    case "21": //  SpričevalaRazredPDF - položaje rubrik prebere iz tabspricevalo
        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        if (isset($_POST["zapis"])){
            $VZapis=$_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                if ($ucenec > 0){
                    $SQL = "SELECT id FROM tabspricevalo WHERE tip=21 AND oznaka LIKE '%".$VLeto."/".($VLeto+1)."%' ORDER BY id DESC";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VZapis=intval($R["id"]);
                    }else{
                        $VZapis=0;
                    }
                }else{
                    $VZapis=0;
                }
            }
        }
        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=1;
        }
        if ($VZapis > 0){
            $SQL = "SELECT * FROM tabspricevalo WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($RS = mysqli_fetch_array($result)){
                //$pdf->AddFont('EAN_b','','EAN_b.php');
                $pdf->AddFont('arial_CE','','arial_CE.php');
                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                $pdf->AddPage("P","A4");

                $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
                $SQL = $SQL . "(tabrazred ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);
                    
                if ($ucenec==0){
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenci[$Indx]=$R["IdUcenec"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx;
                }else{
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["IdUcenec"]==$ucenec){
                            $ucenci[$Indx]=$R["IdUcenec"];
                        }
                    }
                    $StUcencev=1;
                }    
                $FontSize=11;
                for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
                    if ($IndxRazred > 0){
                        $pdf->AddPage("P","A4");
                    }
                    $oUcenec=new RUcenec();
                    $oUcenec->getUcenec($ucenci[$IndxRazred]);
                    $Razred=$oUcenec->getRazred($VLeto);
                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                    $StPredmetov=count($Predmeti);
                    $Ocene=$oUcenec->getOcene($VLeto);
                    $StOcen=count($Ocene);
                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                    $StIzbirnih=count($Izbirni);
                    
                    //vstavi sliko
                    if ($Predogled==1){
                        switch ($VLeto){
                            case 2013:
                            case 2014:
                            case 2015:
                                $pdf->Image("img/SpricevaloOKoncanemRazredu2013.jpg",0,0,210);
                                break;
                            default:
                                $pdf->Image("img/SpricevaloOKoncanemRazredu2016.jpg",0,0,210);
                                break;
                        }
                    }

                    //'izpiše podatke o šoli
                    $poz=explode(",",$RS["sola"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($VSola);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'naslov šole
                    $poz=explode(",",$RS["naslov"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VSolaNaslov);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis osebnih podatkov
                    $poz=explode(",",$RS["ucenec"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'datum rojstva
                    $poz=explode(",",$RS["datroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getDatRoj());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["krajroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["matknj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
                        //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
                        //}else{
                            $txt=ToWin($oUcenec->getMaticniList());
                        //}
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis razrednih podatkov
                    $poz=explode(",",$RS["razred"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["solleto"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["solskoleto"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis redovalnice
                    //'slovenscina
                    $poz=explode(",",$RS["slj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("SLJ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                    }

                    //'matematika
                    $poz=explode(",",$RS["mat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("MAT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
                    //'Anglescina
                    $poz=explode(",",$RS["tuj1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("TJA");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj1n"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("angleščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            //'Nemščina
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("TJN");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj1n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("nemščina");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }
                    
                    //'drug tuj jezik
                    $poz=explode(",",$RS["tuj2"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("AN2");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj2n"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("angleščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            //'Nemščina
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("NE2");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj2n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("nemščina");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }
                    
                    //'Likovna vzgoja/umetnost
                    $poz=explode(",",$RS["lum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("LVZ");
                        }else{
                            $NPredmet=ToNPredmet("LUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Glasbena vzgoja/umetnost
                    $poz=explode(",",$RS["gum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("GVZ");
                        }else{
                            $NPredmet=ToNPredmet("GUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Druzba
                    if (!is_numeric(strpos($TipSole,"prilagojenim"))){  //ne gre za OŠPP
                        $poz=explode(",",$RS["dru"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("DRU");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
                        $poz=explode(",",$RS["dru"]);
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt="  /  ";
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'Spoznavanje okolja
                    $poz=explode(",",$RS["spo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("SPO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Geografija
                    $poz=explode(",",$RS["geo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("GEO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Zgodovina
                    $poz=explode(",",$RS["zgo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("ZGO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Drzavljanska vzgoja in etika
                    $poz=explode(",",$RS["dke"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("DDE");
                        }else{
                            $NPredmet=ToNPredmet("DKE");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Fizika
                    $poz=explode(",",$RS["fiz"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("FIZ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
        //'drugi stolpec
                    //'Kemija
                    $poz=explode(",",$RS["kem"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("KEM");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Biologija
                    $poz=explode(",",$RS["bio"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("BIO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Naravoslovje
                    $poz=explode(",",$RS["nar"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("NAR");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Naravoslovje in tehnika
                    $poz=explode(",",$RS["nit"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("NIT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Tehnika in tehnologija
                    $poz=explode(",",$RS["tit"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("TIT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Gospodinjstvo
                    $poz=explode(",",$RS["gos"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("GOS");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Sportna vzgoja
                    $poz=explode(",",$RS["sport"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("ŠVZ");
                        }else{
                            $NPredmet=ToNPredmet("ŠPO");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'izbirni predmeti    
                    //'1. izbirni predmet
                    $poz=explode(",",$RS["izb1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[0]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb1n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb1n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        $poz=explode(",",$RS["drusl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            //'družboslovje
                            $NPredmet=ToNPredmet("DRU");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["drusln"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("družboslovje");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
                        //'2. izbirni predmet
                        $poz=explode(",",$RS["izb2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            if (isset($Izbirni[1]["oznaka"])){
                                $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){
                                        case 0: //ocena
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1: //neocenjeno
                                            $txt="neocenjeno";
                                            break;
                                        case 2: //oproščeno
                                            $txt=ToWin("oproščeno");
                                    }
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    
                                    //'napis predmeta
                                    $poz=explode(",",$RS["izb2n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }else{
                                    $txt="  /  ";
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }    
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                $poz=explode(",",$RS["izb2n"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }
                    //'3. izbirni predmet
                    $poz=explode(",",$RS["izb3"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[2]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb3n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb3n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'4. izbirni predmet
                    $poz=explode(",",$RS["izb4"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[3]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb4n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb4n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    //spodnji prostor za predmet v drugem stolpcu
                    $txt="  /  ";
                    $poz=explode(",",$RS["izb4"]);
                    $pdf->SetXY($poz[0]+$KorX,$poz[1]+6.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    $poz=explode(",",$RS["izb4n"]);
                    $pdf->SetXY($poz[0]+$KorX,$poz[1]+6.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    
                    $pdf->SetDrawColor(0,0,0); //črna
                    $pdf->SetLineWidth(0.2);
                    if ($Razred["napredovanje"] < 2){
                        $poz=explode(",",$RS["napreduje_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+49+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["napreduje_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+23+$KorX, $poz[1]-$KorY);
                        }
                    }
                    
                    if ($Razred["spolr"]=="M" ){
                        $poz=explode(",",$RS["razr_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["razr_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+15+$KorX, $poz[1]-$KorY);
                        }
                    }

                    if ($SpolRavnatelj=="M" ){
                        $poz=explode(",",$RS["ravn_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["ravn_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+13+$KorX, $poz[1]-$KorY);
                        }
                    }

                    //opombe
                    $poz=explode(",",$RS["op1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);

                        switch ($VLeto){
                            case 2013:
                            case 2014:
                            case 2015:
                                $datizdaje= new DateTime(isDate($Razred["datumizdaje"]));
                                if ($datizdaje->format('Ymd') < "20160712"){
                                    if (strlen($Razred["opomba"]) == 0){
                                        $txt="  /  ";
                                    }else{
                                        $txt=ToWin($Razred["opomba"]);
                                    }
                                }else{
                                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                                        if (strlen($Razred["opomba"]) == 0){
                                            $txt="  /  ";
                                        }else{
                                            $txt=ToWin($Razred["opomba"]);
                                        }
                                    }else{
                                        if ($Razred["razred"] > 6){
                                            if (strlen($Razred["opomba"]) == 0){
                                                $txt="  SOK 1, EOK 1  ";
                                            }else{
                                                $txt=ToWin("  SOK 1, EOK 1  ".$Razred["opomba"]);
                                            }
                                        }else{
                                            if (strlen($Razred["opomba"]) == 0){
                                                $txt="  /  ";
                                            }else{
                                                $txt=ToWin($Razred["opomba"]);
                                            }
                                        }
                                    }
                                }
                                break;
                            default:
                                if (strlen($Razred["opomba"]) == 0){
                                    $txt="  /  ";
                                }else{
                                    $txt=ToWin($Razred["opomba"]);
                                }
                                break;
                        }
                        /*
                        if (strlen($Razred["opomba"]) == 0){
                            $txt="  /  ";
                        }else{
                            $txt=ToWin($Razred["opomba"]);
                        }
                        */
                        if (strlen($txt) < 100){
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt1=substr($txt,0,strpos($txt," ",90));
                            $txt2=substr($txt,strpos($txt," ",90),strlen($txt)-strpos($txt," ",90));
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt1,0,2,$poz[2]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY+6);
                            $pdf->Cell(0,0,$txt2,0,2,$poz[2]);
                        }
                    }

                    //SOK 2, EOK 2
                    $poz=explode(",",$RS["op1"]);
                    if ($poz[0] > 0){
                        if ($VLeto > 2015){
                            if (is_numeric(strpos($TipSole,"prilagojenim"))){
                                $txt="        /                     /";
                            }else{
                                switch($Razred["razred"]){
                                    case 7:
                                    case 8:
                                        $txt="        1                     1";
                                        break;
                                    default:
                                        $txt="        /                     /";
                                        break;
                                }
                            }
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-10-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                    }

                    //razrednik
                    $poz=explode(",",$RS["razr"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razrednik"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //ravnatelj
                    $poz=explode(",",$RS["ravn"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //kraj in datum
                    $poz=explode(",",$RS["krajdat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["datumizdaje"]) > 0){
                            $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
                        }else{
                            $txt=ToWin($VSolaKraj.", ".$PrintDay);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'evid. št.
                    $poz=explode(",",$RS["evst"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["evidst"]) > 0){
                            $txt=ToWin($Razred["evidst"]);
                        }else{
                            $txt=ToWin($RefStFix.$RefStVar);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        $RefStVar=$RefStVar+1;
                    }
                }
            }
            $pdf->Output("spricevala.pdf","D");
        }else{
            header("Location: izpisredovalnice.php");
        }
        break;
        
    case "4": // Zaključna spričevala
        $pdf = new PDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        if ($ucenec==0){
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx;
        }else{
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ucenec){
                    $ucenci[$Indx]=$R["IdUcenec"];
                }
            }
            $StUcencev=1;
        }    
        $FontSize=11;
        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            $Predmeti=$oUcenec->getPredmeti($VLeto);
            $StPredmetov=count($Predmeti);
            $Ocene=$oUcenec->getOcene($VLeto);
            $StOcen=count($Ocene);
            $Izbirni=$oUcenec->getIzbirni($VLeto);
            $StIzbirnih=count($Izbirni);
            $Npz=$oUcenec->getNPZ($VLeto);
            
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,98.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,110-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,110-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,121-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis redovalnice
            //'slovenscina
            $NPredmet=ToNPredmet("SLJ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,141.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,141.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'matematika
            $NPredmet=ToNPredmet("MAT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,148-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,147.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            //'Anglescina
            $NPredmet=ToNPredmet("TJA");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,154.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                //'Anglescina - napis predmeta
                $txt=ToWin("angleščina");
                $pdf->SetXY(15+$KorX,154.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                //'Nemščina
                $NPredmet=ToNPredmet("TJN");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(65+$KorX,154.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'Nemščina - napis predmeta
                    $txt=ToWin("nemščina");
                    $pdf->SetXY(15+$KorX,154.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(65+$KorX,154.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
            }
            
            //'Likovna vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("LVZ");
            }else{
                $NPredmet=ToNPredmet("LUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,161-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,161-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Glasbena vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("GVZ");
            }else{
                $NPredmet=ToNPredmet("GUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Geografija
            $NPredmet=ToNPredmet("GEO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,173.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,173.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Zgodovina
            $NPredmet=ToNPredmet("ZGO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,180-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,180-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Fizika
            $NPredmet=ToNPredmet("FIZ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
//'drugi stolpec
            //'Kemija
            $NPredmet=ToNPredmet("KEM");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,141.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,141.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Biologija
            $NPredmet=ToNPredmet("BIO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,148-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,148-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Gospodinjstvo
            $NPredmet=ToNPredmet("GOS");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,154.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,154.5-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Sportna vzgoja
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("ŠVZ");
            }else{
                $NPredmet=ToNPredmet("ŠPO");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,161-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,161-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'izbirni predmeti    
            //'1. izbirni predmet
            if (isset($Izbirni[0]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,167-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,167-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,167-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,167-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'OSPP
            if (is_numeric(strpos($TipSole,"prilagojenim"))){
                //'družboslovje
                $NPredmet=ToNPredmet("DRU");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,173.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    //'napis predmeta
                    $txt=ToWin("Družboslovje");
                    $pdf->SetXY(110+$KorX,173.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,173.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                //'2. izbirni predmet
                if (isset($Izbirni[1]["oznaka"])){
                    $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                    if ($NPredmet >= 0){
                        switch ($Ocene[$NPredmet]["neocenjen"]){
                            case 0: //ocena
                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                break;
                            case 1: //neocenjeno
                                $txt="neocenjeno";
                                break;
                            case 2: //oproščeno
                                $txt=ToWin("oproščeno");
                        }
                        $pdf->SetXY(161+$KorX,173.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        //'napis predmeta
                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                        $pdf->SetXY(110+$KorX,173.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }else{
                        $txt="  /  ";
                        $pdf->SetXY(161+$KorX,173.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }    
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,173.5-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }
            //'3. izbirni predmet
            if (isset($Izbirni[2]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,180-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,180-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,180-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,180-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'4. izbirni predmet
            if (isset($Izbirni[3]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,186-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,186-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
            //NPZ rezultati
            if (isset($Npz[0]["oznaka"])){        //prvi je SLJ
                if ($Npz[0]["tock"] > 0){
                    $txt=$Npz[0]["tock"];
                    $pdf->SetXY(90+$KorX,215-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                    $txt=$Npz[0]["procent"];
                    $pdf->SetXY(109+$KorX,215-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(90+$KorX,215-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $pdf->SetXY(109+$KorX,215-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(90+$KorX,215-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $pdf->SetXY(109+$KorX,215-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
            if (isset($Npz[1]["oznaka"])){        //drugi je MAT
                if ($Npz[1]["tock"] > 0){
                    $txt=$Npz[1]["tock"];
                    $pdf->SetXY(90+$KorX,221-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                    $txt=$Npz[1]["procent"];
                    $pdf->SetXY(109+$KorX,221-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(90+$KorX,221-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $pdf->SetXY(109+$KorX,221-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(90+$KorX,221-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $pdf->SetXY(109+$KorX,221-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
            if (isset($Npz[2]["oznaka"])){        //tretji
                if ($Npz[2]["tock"] > 0){
                    $txt=$Npz[2]["tock"];
                    $pdf->SetXY(90+$KorX,228-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                    $txt=$Npz[2]["procent"];
                    $pdf->SetXY(109+$KorX,228-$KorY);
                    $pdf->Cell(10,0,$txt,0,2,"R");
                    
                    $txt=ToWin($Npz[2]["opis"]);
                    $pdf->SetXY(34+$KorX,228-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(90+$KorX,228-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $pdf->SetXY(109+$KorX,228-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin($Npz[2]["opis"]);
                    $pdf->SetXY(34+$KorX,228-$KorY);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(90+$KorX,228-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $pdf->SetXY(109+$KorX,228-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $pdf->SetXY(34+$KorX,228-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            // OŠ obveza
            if (strlen($oUcenec->getOSObveza()) > 0){
                $txt=$oUcenec->getOSObveza();
            }else{
                $txt=$Razred["solskoleto"];
            }
            $pdf->SetXY(160+$KorX,231-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);

            if ($oUcenec->getSpol()=="M"){
                $pdf->Line(62.0+$KorX, 201-$KorY, 75+$KorX, 201-$KorY);
                $pdf->Line(111.0+$KorX, 201-$KorY, 123+$KorX, 201-$KorY);
                $pdf->Line(188.0+$KorX, 226.5-$KorY, 198+$KorX, 226.5-$KorY);
            }else{
                $pdf->Line(45.0+$KorX, 201-$KorY, 59+$KorX, 201-$KorY);
                $pdf->Line(94.0+$KorX, 201-$KorY, 107+$KorX, 201-$KorY);
                $pdf->Line(174.0+$KorX, 226.5-$KorY, 185+$KorX, 226.5-$KorY);
            }
            
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(150.0+$KorX, 201-$KorY, 158+$KorX, 201-$KorY);
            }else{
                $pdf->Line(160.0+$KorX, 201-$KorY, 167+$KorX, 201-$KorY);
            }
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 280.8-$KorY, 44+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 280.8-$KorY, 31+$KorX, 280.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 280.8-$KorY, 164+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 280.8-$KorY, 151+$KorX, 280.8-$KorY);
            }

            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,240.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,276-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,276-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,261-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,261-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
        }    
        $pdf->Output("ZakljucnaSpricevala.pdf","D");
        break;
       
    case "22": // Zaključna spričevala - s koordinatami rubrik iz tabspricevalo
        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        if (isset($_POST["zapis"])){
            $VZapis=$_POST["zapis"];
        }else{

            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                $VZapis=0;
            }
        }
        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=1;
        }
        $raz=0;
        $SQL = "SELECT tabrazdat.razred FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $raz=$R["razred"];
        }
        if (($VZapis > 0) && ($raz==9)){
            $SQL = "SELECT * FROM tabspricevalo WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($RS = mysqli_fetch_array($result)){
                //$pdf->AddFont('EAN_b','','EAN_b.php');
                $pdf->AddFont('arial_CE','','arial_CE.php');

                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                $pdf->AddPage("P","A4");

                $SQL = "SELECT tabrazdat.razred, tabucenci.iducenec FROM ";
                $SQL = $SQL . "(tabrazred ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                if ($ucenec==0){
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenci[$Indx]=$R["iducenec"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx;
                }else{
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $raz=$R["razred"];
                        if ($R["iducenec"]==$ucenec){
                            $ucenci[$Indx]=$R["iducenec"];
                        }
                    }
                    $StUcencev=1;
                } 
                $FontSize=11;
                for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
                    if ($IndxRazred > 0){
                        $pdf->AddPage("P","A4");
                    }
                    $oUcenec=new RUcenec();
                    $oUcenec->getUcenec($ucenci[$IndxRazred]);
                    $Razred=$oUcenec->getRazred($VLeto);
                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                    $StPredmetov=count($Predmeti);
                    $Ocene=$oUcenec->getOcene($VLeto);
                    $StOcen=count($Ocene);
                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                    $StIzbirnih=count($Izbirni);
                    $Npz=$oUcenec->getNPZ($VLeto);
                    
                    //vstavi sliko
                    if ($Predogled==1){
                        switch ($VLeto){
                            case 2013:
                            case 2014:
                            case 2015:
                                $pdf->Image("img/ZakljucnoSpricevalo2013.jpg",0,0,210);
                                break;
                            default:
                                $pdf->Image("img/ZakljucnoSpricevalo2016.jpg",0,0,210);
                                break;
                        }
                    }
                    
                    //'izpiše podatke o šoli
                    $poz=explode(",",$RS["sola"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($VSola);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'naslov šole
                    $poz=explode(",",$RS["naslov"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VSolaNaslov);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis osebnih podatkov
                    $poz=explode(",",$RS["ucenec"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'datum rojstva
                    $poz=explode(",",$RS["datroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getDatRoj());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["krajroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                        $pdf->SetXY(78+$KorX,110-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }

                    $poz=explode(",",$RS["matknj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
                        //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
                        //}else{
                            $txt=ToWin($oUcenec->getMaticniList());
                        //}
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis razrednih podatkov
                    $poz=explode(",",$RS["razred"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["solleto"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["solskoleto"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis redovalnice
                    //'slovenscina
                    $poz=explode(",",$RS["slj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("SLJ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'matematika
                    $poz=explode(",",$RS["mat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("MAT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    //'Anglescina
                    $poz=explode(",",$RS["tuj1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("TJA");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj1n"]);
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin("angleščina");
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            //'Nemščina
                            $NPredmet=ToNPredmet("TJN");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj1n"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("nemščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }
                    
                    //'Drug tuj jezik
                    $poz=explode(",",$RS["tuj2"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("AN2");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj2n"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("angleščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            //'Nemščina
                            $NPredmet=ToNPredmet("NE2");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj2n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("nemščina");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }

                    //'Likovna vzgoja/umetnost
                    $poz=explode(",",$RS["lum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("LVZ");
                        }else{
                            $NPredmet=ToNPredmet("LUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Glasbena vzgoja/umetnost
                    $poz=explode(",",$RS["gum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("GVZ");
                        }else{
                            $NPredmet=ToNPredmet("GUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Geografija
                    $poz=explode(",",$RS["geo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("GEO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Zgodovina
                    $poz=explode(",",$RS["zgo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("ZGO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Fizika
                    $poz=explode(",",$RS["fiz"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("FIZ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
        //'drugi stolpec
                    //'Kemija
                    $poz=explode(",",$RS["kem"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("KEM");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Biologija
                    $poz=explode(",",$RS["bio"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("BIO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

					/*
                    //'Gospodinjstvo
                    $poz=explode(",",$RS["gos"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         $NPredmet=ToNPredmet("GOS");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
*/
                    //'Sportna vzgoja
                    $poz=explode(",",$RS["sport"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("ŠVZ");
                        }else{
                            $NPredmet=ToNPredmet("ŠPO");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'izbirni predmeti    
                    //'1. izbirni predmet
                    $poz=explode(",",$RS["izb1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[0]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb1n"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{ //nima ne predmeta in ne ocene
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb1n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        //'družboslovje
                        $poz=explode(",",$RS["drusl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("DRU");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["drusln"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("družboslovje");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
                        //'2. izbirni predmet
                        $poz=explode(",",$RS["izb2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            if (isset($Izbirni[1]["oznaka"])){
                                $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){
                                        case 0: //ocena
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1: //neocenjeno
                                            $txt="neocenjeno";
                                            break;
                                        case 2: //oproščeno
                                            $txt=ToWin("oproščeno");
                                    }
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    
                                    //'napis predmeta
                                    $poz=explode(",",$RS["izb2n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }else{
                                    $txt="  /  ";
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }    
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                $poz=explode(",",$RS["izb2n"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }

        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        //'tehnika in tehnologija
                        $poz=explode(",",$RS["titsl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("TIT");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["titsln"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("tehnika in tehnologija");
                                $pdf->SetXY(110+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
						//'3. izbirni predmet
						$poz=explode(",",$RS["izb3"]);
						if ($poz[0] > 0){
							$pdf->SetFont('arial_CE','',$poz[3]);
							if (isset($Izbirni[2]["oznaka"])){
								$NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
								if ($NPredmet >= 0){
									switch ($Ocene[$NPredmet]["neocenjen"]){
										case 0: //ocena
											$txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
											break;
										case 1: //neocenjeno
											$txt="neocenjeno";
											break;
										case 2: //oproščeno
											$txt=ToWin("oproščeno");
									}
									$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
									$pdf->Cell(0,0,$txt,0,2,$poz[2]);
									
									//'napis predmeta
									$poz=explode(",",$RS["izb3n"]);
									if ($poz[0] > 0){
										$pdf->SetFont('arial_CE','',$poz[3]);
										$txt=ToWin($Ocene[$NPredmet]["opis"]);
										$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
										$pdf->Cell(0,0,$txt,0,2,$poz[2]);
									}
								}else{
									$txt="  /  ";
									$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
									$pdf->Cell(0,0,$txt,0,2,$poz[2]);
								}    
							}else{
								$txt="  /  ";
								$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
								$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                $poz=explode(",",$RS["izb3n"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
							}    
						}
                    }

        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        //'gospodinjstvo
                        $poz=explode(",",$RS["gossl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("GOS");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["gossln"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("gospodinjstvo");
                                $pdf->SetXY(110+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
						//'4. izbirni predmet
						$poz=explode(",",$RS["izb4"]);
						if ($poz[0] > 0){
							$pdf->SetFont('arial_CE','',$poz[3]);
							if (isset($Izbirni[3]["oznaka"])){
								$NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
								if ($NPredmet >= 0){
									switch ($Ocene[$NPredmet]["neocenjen"]){
										case 0: //ocena
											$txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
											break;
										case 1: //neocenjeno
											$txt="neocenjeno";
											break;
										case 2: //oproščeno
											$txt=ToWin("oproščeno");
									}
									$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
									$pdf->Cell(0,0,$txt,0,2,$poz[2]);
									
									//'napis predmeta
									$poz=explode(",",$RS["izb4n"]);
									if ($poz[0] > 0){
										$pdf->SetFont('arial_CE','',$poz[3]);
										$txt=ToWin($Ocene[$NPredmet]["opis"]);
										$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
										$pdf->Cell(0,0,$txt,0,2,$poz[2]);
									}
								}else{
									$txt="  /  ";
									$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
									$pdf->Cell(0,0,$txt,0,2,$poz[2]);
								}    
							}else{
								$txt="  /  ";
								$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
								$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                $poz=explode(",",$RS["izb4n"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
							}    
						}
					}
                    
        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        //'naravoslovje
                        $poz=explode(",",$RS["narsl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("NAR");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["narsln"]);
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("naravoslovje");
                                $pdf->SetXY(110+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
                        $txt="  /  ";
                        $poz=explode(",",$RS["izb4"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]+6.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        $poz=explode(",",$RS["izb4n"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]+6.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }
                    //NPZ rezultati
                    if (isset($Npz[0]["oznaka"])){        //prvi je SLJ
                        if ($Npz[0]["tock"] > 0){
                            $txt=$Npz[0]["tock"];
                            $poz=explode(",",$RS["npzsljt"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                                $txt=$Npz[0]["procent"];
                            }
                            $poz=explode(",",$RS["npzsljp"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            $txt="  /  ";
                            $poz=explode(",",$RS["npzsljt"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                            $poz=explode(",",$RS["npzsljp"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                        }    
                    }else{
                        $txt="  /  ";
                        $poz=explode(",",$RS["npzsljt"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                        $poz=explode(",",$RS["npzsljp"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                    }    
                    
                    if (isset($Npz[1]["oznaka"])){        //drugi je MAT
                        if ($Npz[1]["tock"] > 0){
                            $txt=$Npz[1]["tock"];
                            $poz=explode(",",$RS["npzmatt"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                                $txt=$Npz[1]["procent"];
                            }
                            $poz=explode(",",$RS["npzmatp"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            $txt="  /  ";
                            $poz=explode(",",$RS["npzmatt"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                            $poz=explode(",",$RS["npzmatp"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                        }    
                    }else{
                        $txt="  /  ";
                        $poz=explode(",",$RS["npzmatt"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                        $poz=explode(",",$RS["npzmatp"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                    }    
                    
                    if (isset($Npz[2]["oznaka"])){        //tretji
                        if ($Npz[2]["tock"] > 0){
                            $txt=$Npz[2]["tock"];
                            $poz=explode(",",$RS["npz3t"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                                $txt=$Npz[2]["procent"];
                            }
                            $poz=explode(",",$RS["npz3p"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(10,0,$txt,0,2,$poz[2]);
                            }
                            
                            $poz=explode(",",$RS["npz3"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin($Npz[2]["opis"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            $txt="  /  ";
                            $poz=explode(",",$RS["npz3t"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                            $poz=explode(",",$RS["npz3p"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                            }
                            
                            $txt=ToWin($Npz[2]["opis"]);
                            $poz=explode(",",$RS["npz3"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }    
                    }else{
                        $txt="  /  ";
                        $poz=explode(",",$RS["npz3t"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                        $poz=explode(",",$RS["npz3p"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                        
                        if (isset($Npz[2]["opis"])){
                            $txt=ToWin($Npz[2]["opis"]);
                        }
                        $poz=explode(",",$RS["npz3"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                    }    
                    // OŠ obveza
                    $poz=explode(",",$RS["sosl"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                         if (strlen($oUcenec->getOSObveza()) > 0){
                            $txt=$oUcenec->getOSObveza();
                        }else{
                            $txt=$Razred["solskoleto"];
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }
                    
                    $pdf->SetDrawColor(0,0,0); //črna
                    $pdf->SetLineWidth(0.2);

                    if ($oUcenec->getSpol()=="M"){
                        $poz=explode(",",$RS["ucenec_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+13+$KorX, $poz[1]-$KorY);
                        }
                        $poz=explode(",",$RS["koncal_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+12+$KorX, $poz[1]-$KorY);
                        }
                        $poz=explode(",",$RS["so2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+20+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["ucenec_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+14+$KorX, $poz[1]-$KorY);
                        }
                        $poz=explode(",",$RS["koncal_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+13+$KorX, $poz[1]-$KorY);
                        }
                        $poz=explode(",",$RS["so1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+11+$KorX, $poz[1]-$KorY);
                        }
                    }
                    
                    if ($Razred["napredovanje"] < 2){
                        $poz=explode(",",$RS["da_1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+8+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["da_2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+7+$KorX, $poz[1]-$KorY);
                        }
                    }
                    
                    if ($Razred["spolr"]=="M" ){
                        $poz=explode(",",$RS["razr_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["razr_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+15+$KorX, $poz[1]-$KorY);
                        }
                    }

                    if ($SpolRavnatelj=="M" ){
                        $poz=explode(",",$RS["ravn_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["ravn_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+13+$KorX, $poz[1]-$KorY);
                        }
                    }

                    //opombe
                    $poz=explode(",",$RS["op1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        
                        if (is_numeric(strpos($TipSole,"prilagojenim"))){
                            switch ($VLeto){
                                case 2013:
                                case 2014:
                                case 2015:
                                    $datizdaje= new DateTime(isDate($Razred["datumizdaje"]));
                                    if ($datizdaje->format('Ymd') < "20160712"){
                                        if (strlen($Razred["opomba"]) == 0){
                                            $txt="  /  ";
                                        }else{
                                            $txt=ToWin($Razred["opomba"]);
                                        }
                                    }else{
                                        if (strlen($Razred["opomba"]) == 0){
                                            $txt="  SOK 1, EOK 1  ";
                                        }else{
                                            $txt=ToWin("  SOK 1, EOK 1  ".$Razred["opomba"]);
                                        }
                                    }
                                    break;
                                default:
                                    if (strlen($Razred["opomba"]) == 0){
                                        $txt="  /  ";
                                    }else{
                                        $txt=ToWin($Razred["opomba"]);
                                    }
                                    break;
                                
                            }
                        }else{
                            switch ($VLeto){
                                case 2013:
                                case 2014:
                                case 2015:
                                    $datizdaje= new DateTime(isDate($Razred["datumizdaje"]));
                                    if ($datizdaje->format('Ymd') < "20160712"){
                                        if (strlen($Razred["opomba"]) == 0){
                                            $txt="  /  ";
                                        }else{
                                            $txt=ToWin($Razred["opomba"]);
                                        }
                                    }else{
                                        if (strlen($Razred["opomba"]) == 0){
                                            $txt="  SOK 2, EOK 2  ";
                                        }else{
                                            $txt=ToWin("  SOK 2, EOK 2  ".$Razred["opomba"]);
                                        }
                                    }
                                    break;
                                default:
                                    if (strlen($Razred["opomba"]) == 0){
                                        $txt="  /  ";
                                    }else{
                                        $txt=ToWin($Razred["opomba"]);
                                    }
                                    break;
                                
                            }
                        }
                        
                        if (strlen($txt) < 100){
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt1=substr($txt,0,strpos($txt," ",90));
                            $txt2=substr($txt,strpos($txt," ",90),strlen($txt)-strpos($txt," ",90));
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt1,0,2,$poz[2]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY+6);
                            $pdf->Cell(0,0,$txt2,0,2,$poz[2]);
                        }
                        //$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        //$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //SOK 2, EOK 2
                    $poz=explode(",",$RS["op1"]);
                    if ($poz[0] > 0){
                        if ($VLeto > 2015){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            if (is_numeric(strpos($TipSole,"prilagojenim"))){
                                $txt="        1                     1";
                            }else{
                                $txt="        2                     2";
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-10-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                    }
                    //razrednik
                    $poz=explode(",",$RS["razr"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razrednik"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //ravnatelj
                    $poz=explode(",",$RS["ravn"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //kraj in datum
                    $poz=explode(",",$RS["krajdat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["datumizdaje"]) > 0){
                            $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
                        }else{
                            $txt=ToWin($VSolaKraj.", ".$PrintDay);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'evid. št.
                    $poz=explode(",",$RS["evst"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["evidst"]) > 0){
                            $txt=ToWin($Razred["evidst"]);
                        }else{
                            $txt=ToWin($RefStFix.$RefStVar);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        $RefStVar=$RefStVar+1;
                    }
                }    
                $pdf->Output("ZakljucnaSpricevala.pdf","D");
            }
        }else{
            header("Location: obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto);
        }
        break;
       
    case "3": //Obvestilo o zaključnih ocenah
        $pdf = new PDF();
        $KorX=0;
        $KorY=0;
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->SetAutoPageBreak(false);
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        if ($ucenec==0){
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx;
        }else{
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ucenec){
                    $ucenci[$Indx]=$R["IdUcenec"];
                }
            }
            $StUcencev=1;
        }    
        $FontSize=11;
        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            $Predmeti=$oUcenec->getPredmeti($VLeto);
            $StPredmetov=count($Predmeti);
            $Ocene=$oUcenec->getOcene($VLeto);
            $StOcen=count($Ocene);
            $Izbirni=$oUcenec->getIzbirni($VLeto);
            $StIzbirnih=count($Izbirni);
            
            //vstavi sliko
            $pdf->Image("img/ObvestiloOZakljucnihOcenah.jpg",0,0,210);
            
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,98.5-$KorY+6.5);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,110-$KorY+6);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,110-$KorY+6);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,121-$KorY+6);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,121-$KorY+6);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,121-$KorY+6);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis redovalnice
            //'slovenscina
            $NPredmet=ToNPredmet("SLJ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,141-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,141-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'matematika
            $NPredmet=ToNPredmet("MAT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,147.5-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,147.5-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            //'Anglescina
            $NPredmet=ToNPredmet("TJA");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,154-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                //'Anglescina - napis predmeta
                $txt=ToWin("angleščina");
                $pdf->SetXY(15+$KorX,154-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                //'Nemščina
                $NPredmet=ToNPredmet("TJN");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(65+$KorX,154-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'Nemščina - napis predmeta
                    $txt=ToWin("nemščina");
                    $pdf->SetXY(15+$KorX,154-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(65+$KorX,154-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
            }
            
            //'Likovna vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("LVZ");
            }else{
                $NPredmet=ToNPredmet("LUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,160.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,160.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Glasbena vzgoja/umetnost
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("GVZ");
            }else{
                $NPredmet=ToNPredmet("GUM");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,167-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,167-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Druzba
            if (!is_numeric(strpos($TipSole,"prilagojenim"))){  //ne gre za OŠPP
                $NPredmet=ToNPredmet("DRU");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(65+$KorX,173-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(65+$KorX,173-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }

            //'Geografija
            $NPredmet=ToNPredmet("GEO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,179.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,179.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Zgodovina
            $NPredmet=ToNPredmet("ZGO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,186-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,186-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Drzavljanska vzgoja in etika
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("DDE");
            }else{
                $NPredmet=ToNPredmet("DKE");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,196-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,196-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Fizika
            $NPredmet=ToNPredmet("FIZ");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(65+$KorX,205.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(65+$KorX,205.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
//'drugi stolpec
            //'Kemija
            $NPredmet=ToNPredmet("KEM");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,141-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,141-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Biologija
            $NPredmet=ToNPredmet("BIO");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,147.5-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,147.5-$KorY+14);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Naravoslovje
            $NPredmet=ToNPredmet("NAR");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,154-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,154-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Naravoslovje in tehnika
            $NPredmet=ToNPredmet("NIT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,160.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,160.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Tehnika in tehnologija
            $NPredmet=ToNPredmet("TIT");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,167-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,167-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Gospodinjstvo
            $NPredmet=ToNPredmet("GOS");
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,173-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,173-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'Sportna vzgoja
            if ($VLeto < 2013){
                $NPredmet=ToNPredmet("ŠVZ");
            }else{
                $NPredmet=ToNPredmet("ŠPO");
            }
            if ($NPredmet >= 0){
                switch ($Ocene[$NPredmet]["neocenjen"]){
                    case 0: //ocena
                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                        break;
                    case 1: //neocenjeno
                        $txt="neocenjeno";
                        break;
                    case 2: //oproščeno
                        $txt=ToWin("oproščeno");
                }
                $pdf->SetXY(161+$KorX,179.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,179.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'izbirni predmeti    
            //'1. izbirni predmet
            if (isset($Izbirni[0]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,186-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,186-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,186-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,186-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

//'OSPP
            if (is_numeric(strpos($TipSole,"prilagojenim"))){
                //'družboslovje
                $NPredmet=ToNPredmet("DRU");
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,193-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    //'napis predmeta
                    $txt=ToWin("Družboslovje");
                    $pdf->SetXY(110+$KorX,193-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,193-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                //'2. izbirni predmet
                if (isset($Izbirni[1]["oznaka"])){
                    $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                    if ($NPredmet >= 0){
                        switch ($Ocene[$NPredmet]["neocenjen"]){
                            case 0: //ocena
                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                break;
                            case 1: //neocenjeno
                                $txt="neocenjeno";
                                break;
                            case 2: //oproščeno
                                $txt=ToWin("oproščeno");
                        }
                        $pdf->SetXY(161+$KorX,193-$KorY+13);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        //'napis predmeta
                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                        $pdf->SetXY(110+$KorX,193-$KorY+13);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }else{
                        $txt="  /  ";
                        $pdf->SetXY(161+$KorX,193-$KorY+13);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }    
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,193-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }
            //'3. izbirni predmet
            if (isset($Izbirni[2]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,199-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,199-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,199-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,199-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            //'4. izbirni predmet
            if (isset($Izbirni[3]["oznaka"])){
                $NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
                if ($NPredmet >= 0){
                    switch ($Ocene[$NPredmet]["neocenjen"]){
                        case 0: //ocena
                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                            break;
                        case 1: //neocenjeno
                            $txt="neocenjeno";
                            break;
                        case 2: //oproščeno
                            $txt=ToWin("oproščeno");
                    }
                    $pdf->SetXY(161+$KorX,205.5-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    //'napis predmeta
                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                    $pdf->SetXY(110+$KorX,205.5-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt="  /  ";
                    $pdf->SetXY(161+$KorX,205.5-$KorY+13);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }    
            }else{
                $txt="  /  ";
                $pdf->SetXY(161+$KorX,205.5-$KorY+13);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    
            
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 280.8-$KorY, 44+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 280.8-$KorY, 31+$KorX, 280.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 280.8-$KorY, 164+$KorX, 280.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 280.8-$KorY, 151+$KorX, 280.8-$KorY);
            }

            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,240-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,275.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,275.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,259.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,259.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
        }    
        $pdf->Output("ObvestiloOZakljucnihOcenah.pdf","D");
        break;

    case "23": //Obvestilo o zaključnih ocenah  - pozicije rubrik v tabspricevalo
        $pdf = new PDF();
        
        $pdf->SetAutoPageBreak(false);

        $KorX=0;
        $KorY=0;
        if (isset($_POST["zapis"])){
            $VZapis=$_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                if ($ucenec > 0){
                    $SQL = "SELECT id FROM tabspricevalo WHERE tip=23 AND oznaka LIKE '%".$VLeto."/".($VLeto+1)."%' ORDER BY id DESC";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VZapis=intval($R["id"]);
                    }else{
                        $VZapis=0;
                    }
                }else{
                    $VZapis=0;
                }
            }
        }
        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=1;
        }
        if ($VZapis > 0){
            $SQL = "SELECT * FROM tabspricevalo WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($RS = mysqli_fetch_array($result)){
                //$pdf->AddFont('EAN_b','','EAN_b.php');
                $pdf->AddFont('arial_CE','','arial_CE.php');
                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                $pdf->AddPage("P","A4");

                $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
                $SQL = $SQL . "(tabrazred ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                if ($ucenec==0){
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenci[$Indx]=$R["IdUcenec"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx;
                }else{
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["IdUcenec"]==$ucenec){
                            $ucenci[$Indx]=$R["IdUcenec"];
                        }
                    }
                    $StUcencev=1;
                }    
                $FontSize=11;
                for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
                    if ($IndxRazred > 0){
                        $pdf->AddPage("P","A4");
                    }
                    $oUcenec=new RUcenec();
                    $oUcenec->getUcenec($ucenci[$IndxRazred]);
                    $Razred=$oUcenec->getRazred($VLeto);
                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                    $StPredmetov=count($Predmeti);
                    $Ocene=$oUcenec->getOcene($VLeto);
                    $StOcen=count($Ocene);
                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                    $StIzbirnih=count($Izbirni);
                    
                    //vstavi sliko
                    //if ($Predogled==1){
                        $pdf->Image("img/ObvestiloOZakljucnihOcenah.jpg",0,0,210);
                    //}
                    
                    //'izpiše podatke o šoli
                    $poz=explode(",",$RS["sola"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($VSola);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'naslov šole
                    $poz=explode(",",$RS["naslov"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VSolaNaslov);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis osebnih podatkov
                    $poz=explode(",",$RS["ucenec"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arialbd_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["datroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getDatRoj());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["krajroj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["matknj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
                        //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
                        //}else{
                            $txt=ToWin($oUcenec->getMaticniList());
                        //}
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis razrednih podatkov
                    $poz=explode(",",$RS["razred"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    $poz=explode(",",$RS["solleto"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["solskoleto"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //Izpis redovalnice
                    //'slovenscina
                    $poz=explode(",",$RS["slj"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("SLJ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'matematika
                    $poz=explode(",",$RS["mat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("MAT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
                    //'Anglescina
                    $poz=explode(",",$RS["tuj1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("TJA");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj1n"]);
                            if ($poz[0] > 0){

                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("angleščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            //'Nemščina
                            $NPredmet=ToNPredmet("TJN");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);






                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj1n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("nemščina");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }
                    
                    //'Drug tuj jezik
                    $poz=explode(",",$RS["tuj2"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("AN2");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            
                            //'Anglescina - napis predmeta
                            $poz=explode(",",$RS["tujj2n"]);
                            if ($poz[0] > 0){
                                $pdf->SetFont('arial_CE','',$poz[3]);
                                $txt=ToWin("angleščina");
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }else{
                            //'Nemščina
                            $NPredmet=ToNPredmet("NE2");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'Nemščina - napis predmeta
                                $poz=explode(",",$RS["tujj2n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("nemščina");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }
                        }
                    }
                    
                    //'Likovna vzgoja/umetnost
                    $poz=explode(",",$RS["lum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("LVZ");
                        }else{
                            $NPredmet=ToNPredmet("LUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Glasbena vzgoja/umetnost
                    $poz=explode(",",$RS["gum"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("GVZ");
                        }else{
                            $NPredmet=ToNPredmet("GUM");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Druzba
                    if (!is_numeric(strpos($TipSole,"prilagojenim"))){  //ne gre za OŠPP
                        $poz=explode(",",$RS["dru"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $NPredmet=ToNPredmet("DRU");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }

                    //'Geografija
                    $poz=explode(",",$RS["geo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("GEO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Spoznavanje okolja
                    $poz=explode(",",$RS["spo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("SPO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Zgodovina
                    $poz=explode(",",$RS["zgo"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("ZGO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Drzavljanska vzgoja in etika
                    $poz=explode(",",$RS["dke"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("DDE");
                        }else{
                            $NPredmet=ToNPredmet("DKE");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Fizika
                    $poz=explode(",",$RS["fiz"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("FIZ");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
        //'drugi stolpec
                    //'Kemija
                    $poz=explode(",",$RS["kem"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("KEM");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Biologija
                    $poz=explode(",",$RS["bio"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("BIO");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Naravoslovje
                    $poz=explode(",",$RS["nar"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("NAR");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Naravoslovje in tehnika
                    $poz=explode(",",$RS["nit"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("NIT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Tehnika in tehnologija
                    $poz=explode(",",$RS["tit"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("TIT");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Gospodinjstvo
                    $poz=explode(",",$RS["gos"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $NPredmet=ToNPredmet("GOS");
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'Sportna vzgoja
                    $poz=explode(",",$RS["sport"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if ($VLeto < 2013){
                            $NPredmet=ToNPredmet("ŠVZ");
                        }else{
                            $NPredmet=ToNPredmet("ŠPO");
                        }
                        if ($NPredmet >= 0){
                            switch ($Ocene[$NPredmet]["neocenjen"]){
                                case 0: //ocena
                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                    break;
                                case 1: //neocenjeno
                                    $txt="neocenjeno";
                                    break;
                                case 2: //oproščeno
                                    $txt=ToWin("oproščeno");
                            }
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'izbirni predmeti    
                    //'1. izbirni predmet
                    $poz=explode(",",$RS["izb1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[0]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb1n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb1n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

        //'OSPP
                    if (is_numeric(strpos($TipSole,"prilagojenim"))){
                        $poz=explode(",",$RS["drusl"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            //'družboslovje
                            $NPredmet=ToNPredmet("DRU");
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                //'napis predmeta
                                $poz=explode(",",$RS["drusln"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin("družboslovje");
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }else{
                        //'2. izbirni predmet
                        $poz=explode(",",$RS["izb2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            if (isset($Izbirni[1]["oznaka"])){
                                $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){
                                        case 0: //ocena
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1: //neocenjeno
                                            $txt="neocenjeno";
                                            break;
                                        case 2: //oproščeno
                                            $txt=ToWin("oproščeno");
                                    }
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    
                                    //'napis predmeta
                                    $poz=explode(",",$RS["izb2n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }else{
                                    $txt="  /  ";
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }    
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                $poz=explode(",",$RS["izb2n"]);
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }
                    }
                    //'3. izbirni predmet
                    $poz=explode(",",$RS["izb3"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[2]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb3n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb3n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }

                    //'4. izbirni predmet
                    $poz=explode(",",$RS["izb4"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (isset($Izbirni[3]["oznaka"])){
                            $NPredmet=ToNPredmet($Izbirni[3]["oznaka"]);
                            if ($NPredmet >= 0){
                                switch ($Ocene[$NPredmet]["neocenjen"]){
                                    case 0: //ocena
                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                        break;
                                    case 1: //neocenjeno
                                        $txt="neocenjeno";
                                        break;
                                    case 2: //oproščeno
                                        $txt=ToWin("oproščeno");
                                }
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                
                                //'napis predmeta
                                $poz=explode(",",$RS["izb4n"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                            }else{
                                $txt="  /  ";
                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            }    
                        }else{
                            $txt="  /  ";
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $poz=explode(",",$RS["izb4n"]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }    
                    }
                    
                    $pdf->SetDrawColor(0,0,0); //črna
                    $pdf->SetLineWidth(0.2);
                    
                    if ($Razred["spolr"]=="M" ){
                        $poz=explode(",",$RS["razr_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["razr_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+15+$KorX, $poz[1]-$KorY);
                        }
                    }

                    if ($SpolRavnatelj=="M" ){
                        $poz=explode(",",$RS["ravn_p2"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+10+$KorX, $poz[1]-$KorY);
                        }
                    }else{
                        $poz=explode(",",$RS["ravn_p1"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->Line($poz[0]+$KorX, $poz[1]-$KorY, $poz[0]+15+$KorX, $poz[1]-$KorY);
                        }
                    }

                    //opombe
                    $poz=explode(",",$RS["op1"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["opomba"]) == 0){
                            $txt="  /  ";
                        }else{
                            $txt=ToWin($Razred["opomba"]);
                        }
                        if (strlen($txt) < 100){
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }else{
                            $txt1=substr($txt,0,strpos($txt," ",90));
                            $txt2=substr($txt,strpos($txt," ",90),strlen($txt)-strpos($txt," ",90));
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt1,0,2,$poz[2]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY+6);
                            $pdf->Cell(0,0,$txt2,0,2,$poz[2]);
                        }
                        //$pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        //$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //razrednik
                    $poz=explode(",",$RS["razr"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($Razred["razrednik"]);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //ravnatelj
                    $poz=explode(",",$RS["ravn"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        $txt=ToWin($VRavnatelj);
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //kraj in datum
                    $poz=explode(",",$RS["krajdat"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["datumizdaje"]) > 0){
                            $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
                        }else{
                            $txt=ToWin($VSolaKraj.", ".$PrintDay);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                    }

                    //'evid. št.
                    $poz=explode(",",$RS["evst"]);
                    if ($poz[0] > 0){
                        $pdf->SetFont('arial_CE','',$poz[3]);
                        if (strlen($Razred["evidst"]) > 0){
                            $txt=ToWin($Razred["evidst"]);
                        }else{
                            $txt=ToWin($RefStFix.$RefStVar);
                        }
                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        $RefStVar=$RefStVar+1;
                    }
                }    
                $pdf->Output("ObvestiloOZakljucnihOcenah.pdf","D");
            }
        }
        break;

    case "5": //obvestiloOOcenahPDF - izpis iz redovalnice
        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.* FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        if ($ucenec==0){
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx;
        }else{
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["IdUcenec"]==$ucenec){
                    $ucenci[$Indx]=$R["IdUcenec"];
                }
            }
            $StUcencev=1;
        }    

        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            //vstavi sliko
            $pdf->Image("logo.gif",10,10,30);
            
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            $Predmeti=$oUcenec->getPredmeti($VLeto);
            $StPredmetov=count($Predmeti);
            $Ocene=$oUcenec->getOcene($VLeto);
            $StOcen=count($Ocene);
            
            //' Create a graphic incuding all the rectangles and lines to be used in the document
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            $pdf->Line(10.0, 53, 194.0, 53);
            $pdf->Line(10.0,  200, 194.0,  200);
            
            $YPoz=66.5;
            $ColorChange=false;
            for ($Indx=0;$Indx <= $StPredmetov;$Indx++){
                if ($ColorChange ){
                    $pdf->SetFillColor(222,222,222); //siva
                }else{
                    $pdf->SetFillColor(255,255,255);       //bela
                }
                $ColorChange=!$ColorChange;
                $pdf->Rect( 10.0, $YPoz+$Indx*7+0.5,190,7,"F");
            }

            //'izpiše podatke o šoli
            if (strlen($VSola) > 48 ){
                if (strlen($VSola) > 60 ){
                    $pdf->SetFontSize(11);
                }else{    
                    $pdf->SetFontSize(12);
                }
            }else{
                $pdf->SetFontSize(18);
            }
            
            $pdf->SetFont('arialbd_CE','',18);
            $pdf->SetXY(45,14);
            $txt=ToWin($VSola);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(45,22);
            $pdf->Cell(0,0,$txt,0,2,"C");
             
            //'naslov dokumenta
            $pdf->SetFont('arialbd_CE','',18);
            $txt=ToWin("Izpisek iz redovalnice");
            $pdf->SetXY(10,32);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',18);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10,42);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Datum rojstva: ");
            $pdf->SetXY(10,50);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(30,49.5);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //izpis razrednih podatkov
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Razred, oddelek: ");
            $pdf->SetXY(104,50);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(140,49.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Šolsko leto: ");
            $pdf->SetXY(10,59);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(30,58.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //izpis predmetov in ocen
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Ocene pri posameznih predmetih: ");
            $pdf->SetXY(10,65);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $YPoz=70;

            $pdf->SetFont('arialbd_CE','',10);
            $txt=ToWin("Predmet");
            $pdf->SetXY(13,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");
                
            $txt=ToWin("Pisne 1");
            $pdf->SetXY(83,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Ustne 1");
            $pdf->SetXY(103,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Pisne 2");
            $pdf->SetXY(135,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Ustne 2");
            $pdf->SetXY(155,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin("Zaklj.");
            $pdf->SetXY(180,$YPoz);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',10);
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                //izpis predmeta
                $j=-1; //index ocen
                for ($i=0;$i < $StOcen;$i++){
                    if ($Predmeti[$Indx]["id"]==$Ocene[$i]["id"]){
                        $j=$i;
                        break;
                    }
                }
                
                if ($j < 0){
                    $txt=ToWin($Predmeti[$Indx]["oznaka"]." - ".$Predmeti[$Indx]["opis"]);
                    $pdf->SetXY(13,$YPoz+($Indx+1)*7);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }else{
                    $txt=ToWin($Ocene[$j]["oznaka"]." - ".$Predmeti[$Indx]["opis"]);
                    $pdf->SetXY(13,$YPoz+($Indx+1)*7);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    switch ($Ocene[$j]["neocenjen"]){
                        case 0: //ocene
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(83,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(103,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin($Ocene[$j]["S2P"]);
                            $pdf->SetXY(135,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S2U"]);
                            $pdf->SetXY(155,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin($Ocene[$j]["koncna"]);
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                        case 1: //neocenjen
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(83,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(103,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin($Ocene[$j]["S2P"]);
                            $pdf->SetXY(135,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S2U"]);
                            $pdf->SetXY(155,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin("neocenjeno");
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                        case 2: //opravičen
                            $txt=ToWin($Ocene[$j]["S1P"]);
                            $pdf->SetXY(83,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S1U"]);
                            $pdf->SetXY(103,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin($Ocene[$j]["S2P"]);
                            $pdf->SetXY(135,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($Ocene[$j]["S2U"]);
                            $pdf->SetXY(155,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $txt=ToWin("oproščeno");
                            $pdf->SetXY(180,$YPoz+($Indx+1)*7);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            break;
                    }
                }
            }
            $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$oUcenec->getIdUcenec() . " AND leto=".$VLeto." ORDER BY leto,mesec DESC";
            $result = mysqli_query($link,$SQL);

            for ($Indx=0;$Indx <= 10;$Indx++){
                $VIzostanki[$Indx][0]=0;
                $VIzostanki[$Indx][1]=0;
            }

            while ($R = mysqli_fetch_array($result)){
                if ($R["Mesec"] > 0 ){
                    $VIzostanki[0][0]=$VIzostanki[0][0]+$R["Opraviceno"];
                    $VIzostanki[0][1]=$VIzostanki[0][1]+$R["Neopraviceno"];
                    $VIzostanki[$R["Mesec"]][0]=$R["Opraviceno"];
                    $VIzostanki[$R["Mesec"]][1]=$R["Neopraviceno"];
                }else{
                    $VIzostanki[1][0]=$VIzostanki[1][0]+$R["Opraviceno"];
                    $VIzostanki[1][1]=$VIzostanki[1][1]+$R["Neopraviceno"];
                }
            } 
            
            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Izostanki:");
            $pdf->SetXY(20,206);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if ($VLeto > 2006){
                $txt=ToWin("Opravičene ure: ");
                $pdf->SetXY(20,212);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=$VIzostanki[0][0];
                $pdf->SetXY(45,212);
                $pdf->Cell(15,0,$txt,0,2,"C");
                
                $txt=ToWin(" Neopravičene ure: ");
                $pdf->SetXY(68,212);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=$VIzostanki[0][1];
                $pdf->SetXY(95,212);
                $pdf->Cell(15,0,$txt,0,2,"C");
            }else{
                $txt=ToWin("Opravičene ure: ".$VIzostanki[1][0]." Neopravičene ure: ".$VIzostanki[1][1]);
                $pdf->SetXY(20,212);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }    

            $YPoz=217;
            for ($Indx=9;$Indx <= 12;$Indx++){
                $txt=ToWin(MonthName($Indx).":");
                $pdf->SetXY(20,$YPoz+($Indx-9)*4.5);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=$VIzostanki[$Indx][0];
                $pdf->SetXY(45,$YPoz+($Indx-9)*4.5);
                $pdf->Cell(15,0,$txt,0,2,"C");
                
                $txt=$VIzostanki[$Indx][1];
                $pdf->SetXY(95,$YPoz+($Indx-9)*4.5);
                $pdf->Cell(15,0,$txt,0,2,"C");
            }
            for ($Indx=1;$Indx <= 6;$Indx++){
                $txt=ToWin(MonthName($Indx).":");
                $pdf->SetXY(20,$YPoz+($Indx+3)*4.5);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=$VIzostanki[$Indx][0];
                $pdf->SetXY(45,$YPoz+($Indx+3)*4.5);
                $pdf->Cell(15,0,$txt,0,2,"C");
                
                $txt=$VIzostanki[$Indx][1];
                $pdf->SetXY(95,$YPoz+($Indx+3)*4.5);
                $pdf->Cell(15,0,$txt,0,2,"C");
            }
            
            if ($Razred["spolr"]=="M"){
                $txt=ToWin("Razrednik:");
            }else{
                $txt=ToWin("Razredničarka:");
            }
            $pdf->SetXY(10,265);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(10,271);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',8);
            $txt=ToWin("Kraj in datum:");
            $pdf->SetXY(120,265);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(120,271);
            $pdf->Cell(0,0,$txt,0,2,"L");

        }    
        $pdf->Output("ObvestiloOOcenah.pdf","D");
        break;
    case "10": //izbor spričeval, ki imajo koordinate vnesene v tabspricevalo
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Spričevala po meri";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');

        if (isset($_POST["id1"])){
            $Vid1=$_POST["id1"];
        }else{
            $Vid1=0;
        }
        //Korekcija tiska
        if (isset($_SESSION["posx"])) {
            $KorX=$_SESSION["posx"];
        }else{
            $KorX=0;
        }
        if (isset($_SESSION["posy"])){
            $KorY=$_SESSION["posy"];
        }else{
            $KorY=0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay=$_SESSION["DayToPrint"];
        }else{
            $PrintDay=$Danes->format('j.n.Y');
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix = $_SESSION["RefStFix"];
        }else{
            $RefStFix = "";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar = $_SESSION["RefStVar"];
        }else{
            $RefStVar = "";
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe = "";
        }
        switch ($Vid1){
            case "1":
                $KorX=$_POST["koordinatax"];
                $KorY=$_POST["koordinatay"];
                if (isset($_POST["RefStFix"])){
                    $RefStFix=$_POST["RefStFix"];
                }
                if (isset($_POST["RefStVar"])){
                    $RefStVar=$_POST["RefStVar"];
                }
                if (isset($_POST["datum"])){
                    $PrintDay=$_POST["datum"];
                }
                if (isset($_POST["KorOpombe"])){
                    $KorOpombe=$_POST["KorOpombe"];
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
                echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
                break;
            default:    
                if ($KorX==""){
                    $KorX=0;
                }
                if ($KorY==""){
                    $KorY=0;
                }
                if ($PrintDay=="") {
                    $PrintDay=$Danes->format('j.n.Y');
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
        }
                
        echo "<form name='rezultati' method=post action='obvestilaouspehu.php'>";
        echo "<input name='id' type='hidden' value='10'>";
        echo "<h3>Korekcija tiskanja</h3>";
        echo "<table border='0'>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis višje(+)/nižje(-) mm:";
        echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis bolj desno(+)/levo(-) mm:";
        echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        /*
        if (strstr($PrintDay,".")) { 
            $astr=explode(".",$PrintDay);
            $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
        }else{
            $Datum  = new DateTime($Danes->format('Y-m-d'));
        }
        echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
        echo "</tr>";
        */
        echo "</table>";
        echo "<input name='id1' type='hidden' value='1'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        // konec korekcije tiskanja
        
        echo "<form name='spricevalo' method='post' action='obvestilaouspehu.php'>";
        echo "<input name='id' type='hidden' value='11'>";
        echo "<h2>Spričevala po meri</h2>";
        echo "<a href='tiskanje_navodilo.htm'>Navodilo za tiskanje PDF dokumentov</a><br />";
        //echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika in <b>sprememba datuma tiskanja</b></a><br /><br />";
        echo "<table border=1>";
        if ($VLevel > 1){
            echo "<tr><th>Št.</th><th>Oznaka</th><th>Tip</th><th>Nastanek</th><th>Izpis na obrazec</th><th>Predogled</th><th>Popravi</th><th>Briši</th></tr>";
        }else{
            echo "<tr><th>Št.</th><th>Oznaka</th><th>Tip</th><th>Nastanek</th><th>Izpis na obrazec</th><th>Predogled</th></tr>";
        }
        
        $SQL = "SELECT id,oznaka,tip,cas FROM tabspricevalo ORDER BY id DESC";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            if (strpos($R["oznaka"],$VLeto."/".($VLeto+1)) > 0){
                echo "<tr bgcolor='lightgreen'>";
            }else{
                echo "<tr>";
            }
            echo "<td>".$i."</td>";
            echo "<td>".$R["oznaka"]."</td>";
            switch ($R["tip"]){
                case "21":
                    echo "<td>Spričevalo o končanem razredu OŠ</td>";
                    break;
                case "22":
                    echo "<td>Zaključno spričevalo OŠ</td>";
                    break;
                case "23":
                    echo "<td>Obvestilo o zaključnih ocenah</td>";
                    break;
            }
            echo "<td>".$R["cas"]."</td>";
            echo "<td><a href='obvestilaouspehu.php?id=".$R["tip"]."&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=0'>Izpis na obrazec</a></td>";
            echo "<td><a href='obvestilaouspehu.php?id=".$R["tip"]."&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=1'>Predogled</a></td>";
            if ($VLevel > 1){
                echo "<td><a href='obvestilaouspehu.php?id=11&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."'>Popravi/Kopiraj</a></td>";
                echo "<td><a href='obvestilaouspehu.php?id=18&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."'>Briši</a></td>";
            }
            $i=$i+1;
        }
        echo "</table>";
        //echo "<input name='submit' type='submit' value='Dodaj novo'>";
        echo "</form>";
        echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."'>Na redovalnico</a><br />";
        echo "</body>";
        echo "</html>";
        break;
        
    case "11": //izbor spričeval, ki imajo koordinate vnesene v tabspricevalo
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Spričevala po meri";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');

        $SQL = "SELECT * FROM tabspricevalo WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){

            echo "<form name='spricevalo' method='post' action='obvestilaouspehu.php'>";
            echo "<input name='id' type='hidden' value='12'>";
            echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<h2>Spričevala po meri</h2><br />";
            echo "Oznaka dokumenta: <input name='oznaka' type='text' size='40' value='".$R["oznaka"]."'><br />";
            echo "Tip dokumenta: <select name='tip'>";
            switch ($R["tip"]){
                case "21":
                    echo "<option value='21' selected='selected'>Spričevalo o končanem razredu OŠ</option><option value='22'>Zaključno spričevalo OŠ</option><option value='23'>Obvestilo o zaključnih ocenah</option>";
                    break;
                case "22":
                    echo "<option value='21'>Spričevalo o končanem razredu OŠ</option><option value='22' selected='selected'>Zaključno spričevalo OŠ</option><option value='23'>Obvestilo o zaključnih ocenah</option>";
                    break;
                case "23":
                    echo "<option value='21'>Spričevalo o končanem razredu OŠ</option><option value='22'>Zaključno spričevalo OŠ</option><option value='23' selected='selected'>Obvestilo o zaključnih ocenah</option>";
                    break;
            }
            echo "</select><br />";
            echo "Čas nastanka dokumenta: ".$R["cas"]."<br />";
            echo "<table border='1'>";
            echo "<tr><th>Pozicija</th><th>Odmik od levega<br /> roba lista (X) [mm]</th><th>Odmik od zg.<br />roba lista (Y) [mm]</th><th>Poravnava<br />besedila</th><th>Velikost<br />pisave (pt)</th></tr>";
            $poz=explode(",",$R["sola"]);
            echo "<tr><td>Naziv šole</td><td><input name='sola_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='sola_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='sola_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='sola_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["naslov"]);
            echo "<tr><td>Naslov šole</td><td><input name='naslov_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='naslov_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='naslov_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='naslov_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ucenec"]);
            echo "<tr><td>Učenec</td><td><input name='ucenec_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenec_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenec_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenec_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["datroj"]);
            echo "<tr><td>Dat.roj.</td><td><input name='datroj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='datroj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='datroj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='datroj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["krajroj"]);
            echo "<tr><td>Kraj in država roj.</td><td><input name='krajroj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='krajroj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='krajroj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo"<td><input name='krajroj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["matknj"]);
            echo "<tr><td>Mat. knjiga</td><td><input name='matknj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='matknj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='matknj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='matknj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["razred"]);
            echo "<tr><td>Razred in paralelka</td><td><input name='razred_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razred_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razred_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razred_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["solleto"]);
            echo "<tr><td>Šolsko leto</td><td><input name='solleto_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='solleto_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='solleto_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='solleto_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["slj"]);
            echo "<tr><td>SLJ</td><td><input name='slj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='slj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='slj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='slj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["mat"]);
            echo "<tr><td>MAT</td><td><input name='mat_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='mat_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='mat_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='mat_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["tuj1"]);
            echo "<tr><td>1. tuj jezik</td><td><input name='tuj1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tuj1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tuj1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tuj1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["tujj1n"]);
            echo "<tr><td>Naziv 1. tuj. jezika</td><td><input name='tujj1n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tujj1n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tujj1n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;




                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tujj1n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["tuj2"]);
            echo "<tr><td>2. tuj jezik</td><td><input name='tuj2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tuj2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tuj2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tuj2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["tujj2n"]);
            echo "<tr><td>Naziv 2. tuj. jezika</td><td><input name='tujj2n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tujj2n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tujj2n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tujj2n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["lum"]);
            echo "<tr><td>LUM</td><td><input name='lum_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='lum_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='lum_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='lum_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["gum"]);
            echo "<tr><td>GUM</td><td><input name='gum_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gum_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gum_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gum_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["dru"]);
            echo "<tr><td>DRU</td><td><input name='dru_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='dru_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='dru_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='dru_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["geo"]);
            echo "<tr><td>GEO</td><td><input name='geo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='geo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='geo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='geo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["zgo"]);
            echo "<tr><td>ZGO</td><td><input name='zgo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='zgo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='zgo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='zgo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["dke"]);
            echo "<tr><td>DKE</td><td><input name='dke_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='dke_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='dke_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='dke_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["fiz"]);
            echo "<tr><td>FIZ</td><td><input name='fiz_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='fiz_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='fiz_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='fiz_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["kem"]);
            echo "<tr><td>KEM</td><td><input name='kem_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='kem_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='kem_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='kem_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["bio"]);
            echo "<tr><td>BIO</td><td><input name='bio_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='bio_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='bio_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='bio_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["nar"]);
            echo "<tr><td>NAR</td><td><input name='nar_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='nar_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='nar_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='nar_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["nit"]);
            echo "<tr><td>NIT</td><td><input name='nit_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='nit_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='nit_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='nit_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["tit"]);
            echo "<tr><td>TIT</td><td><input name='tit_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tit_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tit_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tit_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["gos"]);
            echo "<tr><td>GOS</td><td><input name='gos_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gos_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gos_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gos_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["sport"]);
            echo "<tr><td>Šport</td><td><input name='sport_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='sport_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='sport_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='sport_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["spo"]);
            echo "<tr><td>SPO</td><td><input name='spo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='spo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='spo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='spo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb1"]);
            echo "<tr><td>Izbirni 1</td><td><input name='izb1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb1n"]);
            echo "<tr><td>Naziv 1. izb. pr.</td><td><input name='izb1n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb1n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb1n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb1n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb2"]);
            echo "<tr><td>Izbirni 2</td><td><input name='izb2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb2n"]);
            echo "<tr><td>Naziv 2. izb. pr.</td><td><input name='izb2n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb2n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb2n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb2n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb3"]);
            echo "<tr><td>Izbirni 3</td><td><input name='izb3_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb3_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb3_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb3_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb3n"]);
            echo "<tr><td>Naziv 3. izb. pr.</td><td><input name='izb3n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb3n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb3n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb3n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb4"]);
            echo "<tr><td>Izbirni 4</td><td><input name='izb4_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb4_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb4_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb4_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["izb4n"]);
            echo "<tr><td>Naziv 4. izb. pr.</td><td><input name='izb4n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb4n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb4n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb4n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["drusl"]);
            echo "<tr><td>družboslovje (OŠPP)</td><td><input name='drusl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='drusl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='drusl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='drusl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["drusln"]);
            echo "<tr><td>Naziv družboslovje (OŠPP)</td><td><input name='drusln_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='drusln_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='drusln_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='drusln_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["narsl"]);
            echo "<tr><td>naravoslovje (OŠPP)</td><td><input name='narsl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='narsl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='narsl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='narsl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["narsln"]);
            echo "<tr><td>Naziv naravoslovje (OŠPP)</td><td><input name='narsln_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='narsln_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='narsln_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='narsln_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["titsl"]);
            echo "<tr><td>tehnika in tehnologija (OŠPP)</td><td><input name='titsl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='titsl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='titsl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='titsl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["titsln"]);
            echo "<tr><td>Naziv tehnika in tehnologija (OŠPP)</td><td><input name='titsln_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='titsln_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='titsln_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='titsln_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["gossl"]);
            echo "<tr><td>gospodinjstvo (OŠPP)</td><td><input name='gossl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gossl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gossl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gossl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["gossln"]);
            echo "<tr><td>Naziv gospodinjstvo (OŠPP)</td><td><input name='gossln_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gossln_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gossln_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gossln_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["napreduje_p1"]);
            echo "<tr><td>Napreduje (črta)</td><td><input name='napreduje_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='napreduje_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='napreduje_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }

            echo "<td><input name='napreduje_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["napreduje_p2"]);
            echo "<tr><td>Ne napreduje (črta)</td><td><input name='napreduje_p2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='napreduje_p2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='napreduje_p2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='napreduje_p2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["op1"]);
            echo "<tr><td>Opomba 1</td><td><input name='op1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='op1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='op1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='op1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["op2"]);
            echo "<tr><td>Opomba 2</td><td><input name='op2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='op2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='op2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='op2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["krajdat"]);
            echo "<tr><td>Kraj in datum</td><td><input name='krajdat_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='krajdat_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='krajdat_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='krajdat_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["evst"]);
            echo "<tr><td>Ev. št.</td><td><input name='evst_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='evst_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='evst_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='evst_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["razr"]);
            echo "<tr><td>Razrednik</td><td><input name='razr_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razr_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razr_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razr_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ravn"]);
            echo "<tr><td>Ravnatelj</td><td><input name='ravn_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ravn_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ravn_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ravn_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["razr_p1"]);
            echo "<tr><td>Razredničarka (črta)</td><td><input name='razr_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razr_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razr_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razr_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["razr_p2"]);
            echo "<tr><td>Razrednik (črta)</td><td><input name='razr_p2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razr_p2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razr_p2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razr_p2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ravn_p1"]);
            echo "<tr><td>Ravnateljica (črta)</td><td><input name='ravn_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ravn_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ravn_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ravn_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ravn_p2"]);
            echo "<tr><td>Ravnatelj (črta)</td><td><input name='ravn_p2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ravn_p2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ravn_p2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ravn_p2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ucenec_p1"]);
            echo "<tr><td>Učenka (črta)</td><td><input name='ucenec_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenec_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenec_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenec_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["ucenec_p2"]);
            echo "<tr><td>Učenec (črta)</td><td><input name='ucenec_p2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenec_p2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenec_p2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenec_p2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["koncal_p1"]);
            echo "<tr><td>Končala (črta)</td><td><input name='koncal_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='koncal_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='koncal_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='koncal_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["koncal_p2"]);
            echo "<tr><td>Končal (črta)</td><td><input name='koncal_p2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='koncal_p2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='koncal_p2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='koncal_p2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["da_1"]);
            echo "<tr><td>DA (črta)</td><td><input name='da_1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='da_1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='da_1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='da_1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["da_2"]);
            echo "<tr><td>NE (črta)</td><td><input name='da_2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='da_2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='da_2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='da_2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npzsljt"]);
            echo "<tr><td>NPZ SLJ točke</td><td><input name='npzsljt_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzsljt_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzsljt_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzsljt_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npzsljp"]);
            echo "<tr><td>NPZ SLJ procent</td><td><input name='npzsljp_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzsljp_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzsljp_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzsljp_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npzmatt"]);
            echo "<tr><td>NPZ MAT točke</td><td><input name='npzmatt_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzmatt_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzmatt_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzmatt_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npzmatp"]);
            echo "<tr><td>NPZ MAT procent</td><td><input name='npzmatp_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzmatp_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzmatp_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzmatp_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npz3"]);
            echo "<tr><td>NPZ 3. predmet</td><td><input name='npz3_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npz3_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npz3_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npz3_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npz3t"]);
            echo "<tr><td>NPZ 3. predmet točke</td><td><input name='npz3t_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npz3t_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npz3t_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npz3t_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["npz3p"]);
            echo "<tr><td>NPZ 3. predmet procent</td><td><input name='npz3p_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npz3p_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npz3p_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npz3p_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["so1"]);
            echo "<tr><td>Izpolnila (črta)</td><td><input name='so1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='so1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='so1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='so1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["so2"]);
            echo "<tr><td>Izpolnil (črta)</td><td><input name='so2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='so2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='so2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='so2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            $poz=explode(",",$R["sosl"]);
            echo "<tr><td>OŠ obveznost v ŠL</td><td><input name='sosl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='sosl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='sosl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='sosl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            echo "</table>";
            echo "<input name='submit' type='submit' value='Popravi'><input name='submit' type='submit' value='Dodaj'>";
            echo "</form>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "12":
        if (isset($_POST["submit"])){
            $nacin=$_POST["submit"];
            if (intval($_POST["zapis"]) < 4){
                $nacin="Dodaj";
            }
            switch ($nacin){
                case "Popravi":
                    $SQL = "UPDATE tabspricevalo SET ";
                    $SQL = $SQL . "oznaka='".$_POST["oznaka"]."'";
                    $SQL = $SQL . ",sola='".str_replace(",",".",$_POST["sola_x"]).",".str_replace(",",".",$_POST["sola_y"]).",".$_POST["sola_j"].",".str_replace(",",".",$_POST["sola_fs"])."'";
                    $SQL = $SQL . ",naslov='".str_replace(",",".",$_POST["naslov_x"]).",".str_replace(",",".",$_POST["naslov_y"]).",".$_POST["naslov_j"].",".str_replace(",",".",$_POST["naslov_fs"])."'";
                    $SQL = $SQL . ",ucenec='".str_replace(",",".",$_POST["ucenec_x"]).",".str_replace(",",".",$_POST["ucenec_y"]).",".$_POST["ucenec_j"].",".str_replace(",",".",$_POST["ucenec_fs"])."'";
                    $SQL = $SQL . ",datroj='".str_replace(",",".",$_POST["datroj_x"]).",".str_replace(",",".",$_POST["datroj_y"]).",".$_POST["datroj_j"].",".str_replace(",",".",$_POST["datroj_fs"])."'";
                    $SQL = $SQL . ",krajroj='".str_replace(",",".",$_POST["krajroj_x"]).",".str_replace(",",".",$_POST["krajroj_y"]).",".$_POST["krajroj_j"].",".str_replace(",",".",$_POST["krajroj_fs"])."'";
                    $SQL = $SQL . ",matknj='".str_replace(",",".",$_POST["matknj_x"]).",".str_replace(",",".",$_POST["matknj_y"]).",".$_POST["matknj_j"].",".str_replace(",",".",$_POST["matknj_fs"])."'";
                    $SQL = $SQL . ",razred='".str_replace(",",".",$_POST["razred_x"]).",".str_replace(",",".",$_POST["razred_y"]).",".$_POST["razred_j"].",".str_replace(",",".",$_POST["razred_fs"])."'";
                    $SQL = $SQL . ",solleto='".str_replace(",",".",$_POST["solleto_x"]).",".str_replace(",",".",$_POST["solleto_y"]).",".$_POST["solleto_j"].",".str_replace(",",".",$_POST["solleto_fs"])."'";
                    $SQL = $SQL . ",slj='".str_replace(",",".",$_POST["slj_x"]).",".str_replace(",",".",$_POST["slj_y"]).",".$_POST["slj_j"].",".str_replace(",",".",$_POST["slj_fs"])."'";
                    $SQL = $SQL . ",mat='".str_replace(",",".",$_POST["mat_x"]).",".str_replace(",",".",$_POST["mat_y"]).",".$_POST["mat_j"].",".str_replace(",",".",$_POST["mat_fs"])."'";
                    $SQL = $SQL . ",tuj1='".str_replace(",",".",$_POST["tuj1_x"]).",".str_replace(",",".",$_POST["tuj1_y"]).",".$_POST["tuj1_j"].",".str_replace(",",".",$_POST["tuj1_fs"])."'";
                    $SQL = $SQL . ",tuj2='".str_replace(",",".",$_POST["tuj2_x"]).",".str_replace(",",".",$_POST["tuj2_y"]).",".$_POST["tuj2_j"].",".str_replace(",",".",$_POST["tuj2_fs"])."'";
                    $SQL = $SQL . ",lum='".str_replace(",",".",$_POST["lum_x"]).",".str_replace(",",".",$_POST["lum_y"]).",".$_POST["lum_j"].",".str_replace(",",".",$_POST["lum_fs"])."'";
                    $SQL = $SQL . ",gum='".str_replace(",",".",$_POST["gum_x"]).",".str_replace(",",".",$_POST["gum_y"]).",".$_POST["gum_j"].",".str_replace(",",".",$_POST["gum_fs"])."'";
                    $SQL = $SQL . ",dru='".str_replace(",",".",$_POST["dru_x"]).",".str_replace(",",".",$_POST["dru_y"]).",".$_POST["dru_j"].",".str_replace(",",".",$_POST["dru_fs"])."'";
                    $SQL = $SQL . ",geo='".str_replace(",",".",$_POST["geo_x"]).",".str_replace(",",".",$_POST["geo_y"]).",".$_POST["geo_j"].",".str_replace(",",".",$_POST["geo_fs"])."'";
                    $SQL = $SQL . ",zgo='".str_replace(",",".",$_POST["zgo_x"]).",".str_replace(",",".",$_POST["zgo_y"]).",".$_POST["zgo_j"].",".str_replace(",",".",$_POST["zgo_fs"])."'";
                    $SQL = $SQL . ",dke='".str_replace(",",".",$_POST["dke_x"]).",".str_replace(",",".",$_POST["dke_y"]).",".$_POST["dke_j"].",".str_replace(",",".",$_POST["dke_fs"])."'";
                    $SQL = $SQL . ",fiz='".str_replace(",",".",$_POST["fiz_x"]).",".str_replace(",",".",$_POST["fiz_y"]).",".$_POST["fiz_j"].",".str_replace(",",".",$_POST["fiz_fs"])."'";
                    $SQL = $SQL . ",kem='".str_replace(",",".",$_POST["kem_x"]).",".str_replace(",",".",$_POST["kem_y"]).",".$_POST["kem_j"].",".str_replace(",",".",$_POST["kem_fs"])."'";
                    $SQL = $SQL . ",bio='".str_replace(",",".",$_POST["bio_x"]).",".str_replace(",",".",$_POST["bio_y"]).",".$_POST["bio_j"].",".str_replace(",",".",$_POST["bio_fs"])."'";
                    $SQL = $SQL . ",nar='".str_replace(",",".",$_POST["nar_x"]).",".str_replace(",",".",$_POST["nar_y"]).",".$_POST["nar_j"].",".str_replace(",",".",$_POST["nar_fs"])."'";
                    $SQL = $SQL . ",nit='".str_replace(",",".",$_POST["nit_x"]).",".str_replace(",",".",$_POST["nit_y"]).",".$_POST["nit_j"].",".str_replace(",",".",$_POST["nit_fs"])."'";
                    $SQL = $SQL . ",tit='".str_replace(",",".",$_POST["tit_x"]).",".str_replace(",",".",$_POST["tit_y"]).",".$_POST["tit_j"].",".str_replace(",",".",$_POST["tit_fs"])."'";
                    $SQL = $SQL . ",gos='".str_replace(",",".",$_POST["gos_x"]).",".str_replace(",",".",$_POST["gos_y"]).",".$_POST["gos_j"].",".str_replace(",",".",$_POST["gos_fs"])."'";
                    $SQL = $SQL . ",sport='".str_replace(",",".",$_POST["sport_x"]).",".str_replace(",",".",$_POST["sport_y"]).",".$_POST["sport_j"].",".str_replace(",",".",$_POST["sport_fs"])."'";
                    $SQL = $SQL . ",spo='".str_replace(",",".",$_POST["spo_x"]).",".str_replace(",",".",$_POST["spo_y"]).",".$_POST["spo_j"].",".str_replace(",",".",$_POST["spo_fs"])."'";
                    $SQL = $SQL . ",izb1='".str_replace(",",".",$_POST["izb1_x"]).",".str_replace(",",".",$_POST["izb1_y"]).",".$_POST["izb1_j"].",".str_replace(",",".",$_POST["izb1_fs"])."'";
                    $SQL = $SQL . ",izb2='".str_replace(",",".",$_POST["izb2_x"]).",".str_replace(",",".",$_POST["izb2_y"]).",".$_POST["izb2_j"].",".str_replace(",",".",$_POST["izb2_fs"])."'";
                    $SQL = $SQL . ",izb3='".str_replace(",",".",$_POST["izb3_x"]).",".str_replace(",",".",$_POST["izb3_y"]).",".$_POST["izb3_j"].",".str_replace(",",".",$_POST["izb3_fs"])."'";
                    $SQL = $SQL . ",izb4='".str_replace(",",".",$_POST["izb4_x"]).",".str_replace(",",".",$_POST["izb4_y"]).",".$_POST["izb4_j"].",".str_replace(",",".",$_POST["izb4_fs"])."'";
                    $SQL = $SQL . ",napreduje_p1='".str_replace(",",".",$_POST["napreduje_p1_x"]).",".str_replace(",",".",$_POST["napreduje_p1_y"]).",".$_POST["napreduje_p1_j"].",".str_replace(",",".",$_POST["napreduje_p1_fs"])."'";
                    $SQL = $SQL . ",napreduje_p2='".str_replace(",",".",$_POST["napreduje_p2_x"]).",".str_replace(",",".",$_POST["napreduje_p2_y"]).",".$_POST["napreduje_p2_j"].",".str_replace(",",".",$_POST["napreduje_p2_fs"])."'";
                    $SQL = $SQL . ",op1='".str_replace(",",".",$_POST["op1_x"]).",".str_replace(",",".",$_POST["op1_y"]).",".$_POST["op1_j"].",".str_replace(",",".",$_POST["op1_fs"])."'";
                    $SQL = $SQL . ",op2='".str_replace(",",".",$_POST["op2_x"]).",".str_replace(",",".",$_POST["op2_y"]).",".$_POST["op2_j"].",".str_replace(",",".",$_POST["op2_fs"])."'";
                    $SQL = $SQL . ",krajdat='".str_replace(",",".",$_POST["krajdat_x"]).",".str_replace(",",".",$_POST["krajdat_y"]).",".$_POST["krajdat_j"].",".str_replace(",",".",$_POST["krajdat_fs"])."'";
                    $SQL = $SQL . ",evst='".str_replace(",",".",$_POST["evst_x"]).",".str_replace(",",".",$_POST["evst_y"]).",".$_POST["evst_j"].",".str_replace(",",".",$_POST["evst_fs"])."'";
                    $SQL = $SQL . ",razr='".str_replace(",",".",$_POST["razr_x"]).",".str_replace(",",".",$_POST["razr_y"]).",".$_POST["razr_j"].",".str_replace(",",".",$_POST["razr_fs"])."'";
                    $SQL = $SQL . ",ravn='".str_replace(",",".",$_POST["ravn_x"]).",".str_replace(",",".",$_POST["ravn_y"]).",".$_POST["ravn_j"].",".str_replace(",",".",$_POST["ravn_fs"])."'";
                    $SQL = $SQL . ",razr_p1='".str_replace(",",".",$_POST["razr_p1_x"]).",".str_replace(",",".",$_POST["razr_p1_y"]).",".$_POST["razr_p1_j"].",".str_replace(",",".",$_POST["razr_p1_fs"])."'";
                    $SQL = $SQL . ",razr_p2='".str_replace(",",".",$_POST["razr_p2_x"]).",".str_replace(",",".",$_POST["razr_p2_y"]).",".$_POST["razr_p2_j"].",".str_replace(",",".",$_POST["razr_p2_fs"])."'";
                    $SQL = $SQL . ",ravn_p1='".str_replace(",",".",$_POST["ravn_p1_x"]).",".str_replace(",",".",$_POST["ravn_p1_y"]).",".$_POST["ravn_p1_j"].",".str_replace(",",".",$_POST["ravn_p1_fs"])."'";
                    $SQL = $SQL . ",ravn_p2='".str_replace(",",".",$_POST["ravn_p2_x"]).",".str_replace(",",".",$_POST["ravn_p2_y"]).",".$_POST["ravn_p2_j"].",".str_replace(",",".",$_POST["ravn_p2_fs"])."'";
                    $SQL = $SQL . ",ucenec_p1='".str_replace(",",".",$_POST["ucenec_p1_x"]).",".str_replace(",",".",$_POST["ucenec_p1_y"]).",".$_POST["ucenec_p1_j"].",".str_replace(",",".",$_POST["ucenec_p1_fs"])."'";
                    $SQL = $SQL . ",ucenec_p2='".str_replace(",",".",$_POST["ucenec_p2_x"]).",".str_replace(",",".",$_POST["ucenec_p2_y"]).",".$_POST["ucenec_p2_j"].",".str_replace(",",".",$_POST["ucenec_p2_fs"])."'";
                    $SQL = $SQL . ",koncal_p1='".str_replace(",",".",$_POST["koncal_p1_x"]).",".str_replace(",",".",$_POST["koncal_p1_y"]).",".$_POST["koncal_p1_j"].",".str_replace(",",".",$_POST["koncal_p1_fs"])."'";
                    $SQL = $SQL . ",koncal_p2='".str_replace(",",".",$_POST["koncal_p2_x"]).",".str_replace(",",".",$_POST["koncal_p2_y"]).",".$_POST["koncal_p2_j"].",".str_replace(",",".",$_POST["koncal_p2_fs"])."'";
                    $SQL = $SQL . ",da_1='".str_replace(",",".",$_POST["da_1_x"]).",".str_replace(",",".",$_POST["da_1_y"]).",".$_POST["da_1_j"].",".str_replace(",",".",$_POST["da_1_fs"])."'";
                    $SQL = $SQL . ",da_2='".str_replace(",",".",$_POST["da_2_x"]).",".str_replace(",",".",$_POST["da_2_y"]).",".$_POST["da_2_j"].",".str_replace(",",".",$_POST["da_2_fs"])."'";
                    $SQL = $SQL . ",npzsljt='".str_replace(",",".",$_POST["npzsljt_x"]).",".str_replace(",",".",$_POST["npzsljt_y"]).",".$_POST["npzsljt_j"].",".str_replace(",",".",$_POST["npzsljt_fs"])."'";
                    $SQL = $SQL . ",npzsljp='".str_replace(",",".",$_POST["npzsljp_x"]).",".str_replace(",",".",$_POST["npzsljp_y"]).",".$_POST["npzsljp_j"].",".str_replace(",",".",$_POST["npzsljp_fs"])."'";
                    $SQL = $SQL . ",npzmatt='".str_replace(",",".",$_POST["npzmatt_x"]).",".str_replace(",",".",$_POST["npzmatt_y"]).",".$_POST["npzmatt_j"].",".str_replace(",",".",$_POST["npzmatt_fs"])."'";
                    $SQL = $SQL . ",npzmatp='".str_replace(",",".",$_POST["npzmatp_x"]).",".str_replace(",",".",$_POST["npzmatp_y"]).",".$_POST["npzmatp_j"].",".str_replace(",",".",$_POST["npzmatp_fs"])."'";
                    $SQL = $SQL . ",npz3='".str_replace(",",".",$_POST["npz3_x"]).",".str_replace(",",".",$_POST["npz3_y"]).",".$_POST["npz3_j"].",".str_replace(",",".",$_POST["npz3_fs"])."'";
                    $SQL = $SQL . ",npz3t='".str_replace(",",".",$_POST["npz3t_x"]).",".str_replace(",",".",$_POST["npz3t_y"]).",".$_POST["npz3t_j"].",".str_replace(",",".",$_POST["npz3t_fs"])."'";
                    $SQL = $SQL . ",npz3p='".str_replace(",",".",$_POST["npz3p_x"]).",".str_replace(",",".",$_POST["npz3p_y"]).",".$_POST["npz3p_j"].",".str_replace(",",".",$_POST["npz3p_fs"])."'";
                    $SQL = $SQL . ",so1='".str_replace(",",".",$_POST["so1_x"]).",".str_replace(",",".",$_POST["so1_y"]).",".$_POST["so1_j"].",".str_replace(",",".",$_POST["so1_fs"])."'";
                    $SQL = $SQL . ",so2='".str_replace(",",".",$_POST["so2_x"]).",".str_replace(",",".",$_POST["so2_y"]).",".$_POST["so2_j"].",".str_replace(",",".",$_POST["so2_fs"])."'";
                    $SQL = $SQL . ",sosl='".str_replace(",",".",$_POST["sosl_x"]).",".str_replace(",",".",$_POST["sosl_y"]).",".$_POST["sosl_j"].",".str_replace(",",".",$_POST["sosl_fs"])."'";
                    $SQL = $SQL . ",tujj1n='".str_replace(",",".",$_POST["tujj1n_x"]).",".str_replace(",",".",$_POST["tujj1n_y"]).",".$_POST["tujj1n_j"].",".str_replace(",",".",$_POST["tujj1n_fs"])."'";
                    $SQL = $SQL . ",tujj2n='".str_replace(",",".",$_POST["tujj2n_x"]).",".str_replace(",",".",$_POST["tujj2n_y"]).",".$_POST["tujj2n_j"].",".str_replace(",",".",$_POST["tujj2n_fs"])."'";
                    $SQL = $SQL . ",izb1n='".str_replace(",",".",$_POST["izb1n_x"]).",".str_replace(",",".",$_POST["izb1n_y"]).",".$_POST["izb1n_j"].",".str_replace(",",".",$_POST["izb1n_fs"])."'";
                    $SQL = $SQL . ",izb2n='".str_replace(",",".",$_POST["izb2n_x"]).",".str_replace(",",".",$_POST["izb2n_y"]).",".$_POST["izb2n_j"].",".str_replace(",",".",$_POST["izb2n_fs"])."'";
                    $SQL = $SQL . ",izb3n='".str_replace(",",".",$_POST["izb3n_x"]).",".str_replace(",",".",$_POST["izb3n_y"]).",".$_POST["izb3n_j"].",".str_replace(",",".",$_POST["izb3n_fs"])."'";
                    $SQL = $SQL . ",izb4n='".str_replace(",",".",$_POST["izb4n_x"]).",".str_replace(",",".",$_POST["izb4n_y"]).",".$_POST["izb4n_j"].",".str_replace(",",".",$_POST["izb4n_fs"])."'";
                    $SQL = $SQL . ",drusl='".str_replace(",",".",$_POST["drusl_x"]).",".str_replace(",",".",$_POST["drusl_y"]).",".$_POST["drusl_j"].",".str_replace(",",".",$_POST["drusl_fs"])."'";
                    $SQL = $SQL . ",drusln='".str_replace(",",".",$_POST["drusln_x"]).",".str_replace(",",".",$_POST["drusln_y"]).",".$_POST["drusln_j"].",".str_replace(",",".",$_POST["drusln_fs"])."'";
                    $SQL = $SQL . ",narsl='".str_replace(",",".",$_POST["narsl_x"]).",".str_replace(",",".",$_POST["narsl_y"]).",".$_POST["narsl_j"].",".str_replace(",",".",$_POST["narsl_fs"])."'";
                    $SQL = $SQL . ",narsln='".str_replace(",",".",$_POST["narsln_x"]).",".str_replace(",",".",$_POST["narsln_y"]).",".$_POST["narsln_j"].",".str_replace(",",".",$_POST["narsln_fs"])."'";
                    $SQL = $SQL . ",titsl='".str_replace(",",".",$_POST["titsl_x"]).",".str_replace(",",".",$_POST["titsl_y"]).",".$_POST["titsl_j"].",".str_replace(",",".",$_POST["titsl_fs"])."'";
                    $SQL = $SQL . ",titsln='".str_replace(",",".",$_POST["titsln_x"]).",".str_replace(",",".",$_POST["titsln_y"]).",".$_POST["titsln_j"].",".str_replace(",",".",$_POST["titsln_fs"])."'";
                    $SQL = $SQL . ",gossl='".str_replace(",",".",$_POST["gossl_x"]).",".str_replace(",",".",$_POST["gossl_y"]).",".$_POST["gossl_j"].",".str_replace(",",".",$_POST["gossl_fs"])."'";
                    $SQL = $SQL . ",gossln='".str_replace(",",".",$_POST["gossln_x"]).",".str_replace(",",".",$_POST["gossln_y"]).",".$_POST["gossln_j"].",".str_replace(",",".",$_POST["gossln_fs"])."'";
                    $SQL = $SQL . ",tip='".$_POST["tip"]."',cas='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$_POST["zapis"];
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu popravka za spričevalo!<br />");
                    }
                    break;
                case "Dodaj":
                    $SQL = "INSERT INTO tabspricevalo (";
                    $SQL = $SQL . "oznaka";
                    $SQL = $SQL . ",sola";
                    $SQL = $SQL . ",naslov";
                    $SQL = $SQL . ",ucenec";
                    $SQL = $SQL . ",datroj";
                    $SQL = $SQL . ",krajroj";
                    $SQL = $SQL . ",matknj";
                    $SQL = $SQL . ",razred";
                    $SQL = $SQL . ",solleto";
                    $SQL = $SQL . ",slj";
                    $SQL = $SQL . ",mat";
                    $SQL = $SQL . ",tuj1";
                    $SQL = $SQL . ",tuj2";
                    $SQL = $SQL . ",lum";
                    $SQL = $SQL . ",gum";
                    $SQL = $SQL . ",dru";
                    $SQL = $SQL . ",geo";
                    $SQL = $SQL . ",zgo";
                    $SQL = $SQL . ",dke";
                    $SQL = $SQL . ",fiz";
                    $SQL = $SQL . ",kem";
                    $SQL = $SQL . ",bio";
                    $SQL = $SQL . ",nar";
                    $SQL = $SQL . ",nit";
                    $SQL = $SQL . ",tit";
                    $SQL = $SQL . ",gos";
                    $SQL = $SQL . ",sport";
                    $SQL = $SQL . ",spo";
                    $SQL = $SQL . ",izb1";
                    $SQL = $SQL . ",izb2";
                    $SQL = $SQL . ",izb3";
                    $SQL = $SQL . ",izb4";
                    $SQL = $SQL . ",napreduje_p1";
                    $SQL = $SQL . ",napreduje_p2";
                    $SQL = $SQL . ",op1";
                    $SQL = $SQL . ",op2";
                    $SQL = $SQL . ",krajdat";
                    $SQL = $SQL . ",evst";
                    $SQL = $SQL . ",razr";
                    $SQL = $SQL . ",ravn";
                    $SQL = $SQL . ",razr_p1";
                    $SQL = $SQL . ",razr_p2";
                    $SQL = $SQL . ",ravn_p1";
                    $SQL = $SQL . ",ravn_p2";
                    $SQL = $SQL . ",ucenec_p1";
                    $SQL = $SQL . ",ucenec_p2";
                    $SQL = $SQL . ",koncal_p1";
                    $SQL = $SQL . ",koncal_p2";
                    $SQL = $SQL . ",da_1";
                    $SQL = $SQL . ",da_2";
                    $SQL = $SQL . ",npzsljt";
                    $SQL = $SQL . ",npzsljp";
                    $SQL = $SQL . ",npzmatt";
                    $SQL = $SQL . ",npzmatp";
                    $SQL = $SQL . ",npz3";
                    $SQL = $SQL . ",npz3t";
                    $SQL = $SQL . ",npz3p";
                    $SQL = $SQL . ",so1";
                    $SQL = $SQL . ",so2";
                    $SQL = $SQL . ",sosl";
                    $SQL = $SQL . ",tujj1n";
                    $SQL = $SQL . ",tujj2n";
                    $SQL = $SQL . ",izb1n";
                    $SQL = $SQL . ",izb2n";
                    $SQL = $SQL . ",izb3n";
                    $SQL = $SQL . ",izb4n";
                    $SQL = $SQL . ",drusl";
                    $SQL = $SQL . ",drusln";
                    $SQL = $SQL . ",narsl";
                    $SQL = $SQL . ",narsln";
                    $SQL = $SQL . ",titsl";
                    $SQL = $SQL . ",titsln";
                    $SQL = $SQL . ",gossl";
                    $SQL = $SQL . ",gossln";
                    $SQL = $SQL . ",tip,cas) VALUES (";
                    $SQL = $SQL . "'".$_POST["oznaka"]."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["sola_x"]).",".str_replace(",",".",$_POST["sola_y"]).",".$_POST["sola_j"].",".str_replace(",",".",$_POST["sola_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["naslov_x"]).",".str_replace(",",".",$_POST["naslov_y"]).",".$_POST["naslov_j"].",".str_replace(",",".",$_POST["naslov_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenec_x"]).",".str_replace(",",".",$_POST["ucenec_y"]).",".$_POST["ucenec_j"].",".str_replace(",",".",$_POST["ucenec_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["datroj_x"]).",".str_replace(",",".",$_POST["datroj_y"]).",".$_POST["datroj_j"].",".str_replace(",",".",$_POST["datroj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["krajroj_x"]).",".str_replace(",",".",$_POST["krajroj_y"]).",".$_POST["krajroj_j"].",".str_replace(",",".",$_POST["krajroj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["matknj_x"]).",".str_replace(",",".",$_POST["matknj_y"]).",".$_POST["matknj_j"].",".str_replace(",",".",$_POST["matknj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razred_x"]).",".str_replace(",",".",$_POST["razred_y"]).",".$_POST["razred_j"].",".str_replace(",",".",$_POST["razred_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["solleto_x"]).",".str_replace(",",".",$_POST["solleto_y"]).",".$_POST["solleto_j"].",".str_replace(",",".",$_POST["solleto_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["slj_x"]).",".str_replace(",",".",$_POST["slj_y"]).",".$_POST["slj_j"].",".str_replace(",",".",$_POST["slj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["mat_x"]).",".str_replace(",",".",$_POST["mat_y"]).",".$_POST["mat_j"].",".str_replace(",",".",$_POST["mat_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tuj1_x"]).",".str_replace(",",".",$_POST["tuj1_y"]).",".$_POST["tuj1_j"].",".str_replace(",",".",$_POST["tuj1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tuj2_x"]).",".str_replace(",",".",$_POST["tuj2_y"]).",".$_POST["tuj2_j"].",".str_replace(",",".",$_POST["tuj2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["lum_x"]).",".str_replace(",",".",$_POST["lum_y"]).",".$_POST["lum_j"].",".str_replace(",",".",$_POST["lum_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gum_x"]).",".str_replace(",",".",$_POST["gum_y"]).",".$_POST["gum_j"].",".str_replace(",",".",$_POST["gum_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["dru_x"]).",".str_replace(",",".",$_POST["dru_y"]).",".$_POST["dru_j"].",".str_replace(",",".",$_POST["dru_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["geo_x"]).",".str_replace(",",".",$_POST["geo_y"]).",".$_POST["geo_j"].",".str_replace(",",".",$_POST["geo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["zgo_x"]).",".str_replace(",",".",$_POST["zgo_y"]).",".$_POST["zgo_j"].",".str_replace(",",".",$_POST["zgo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["dke_x"]).",".str_replace(",",".",$_POST["dke_y"]).",".$_POST["dke_j"].",".str_replace(",",".",$_POST["dke_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["fiz_x"]).",".str_replace(",",".",$_POST["fiz_y"]).",".$_POST["fiz_j"].",".str_replace(",",".",$_POST["fiz_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["kem_x"]).",".str_replace(",",".",$_POST["kem_y"]).",".$_POST["kem_j"].",".str_replace(",",".",$_POST["kem_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["bio_x"]).",".str_replace(",",".",$_POST["bio_y"]).",".$_POST["bio_j"].",".str_replace(",",".",$_POST["bio_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["nar_x"]).",".str_replace(",",".",$_POST["nar_y"]).",".$_POST["nar_j"].",".str_replace(",",".",$_POST["nar_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["nit_x"]).",".str_replace(",",".",$_POST["nit_y"]).",".$_POST["nit_j"].",".str_replace(",",".",$_POST["nit_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tit_x"]).",".str_replace(",",".",$_POST["tit_y"]).",".$_POST["tit_j"].",".str_replace(",",".",$_POST["tit_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gos_x"]).",".str_replace(",",".",$_POST["gos_y"]).",".$_POST["gos_j"].",".str_replace(",",".",$_POST["gos_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["sport_x"]).",".str_replace(",",".",$_POST["sport_y"]).",".$_POST["sport_j"].",".str_replace(",",".",$_POST["sport_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["spo_x"]).",".str_replace(",",".",$_POST["spo_y"]).",".$_POST["spo_j"].",".str_replace(",",".",$_POST["spo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb1_x"]).",".str_replace(",",".",$_POST["izb1_y"]).",".$_POST["izb1_j"].",".str_replace(",",".",$_POST["izb1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb2_x"]).",".str_replace(",",".",$_POST["izb2_y"]).",".$_POST["izb2_j"].",".str_replace(",",".",$_POST["izb2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb3_x"]).",".str_replace(",",".",$_POST["izb3_y"]).",".$_POST["izb3_j"].",".str_replace(",",".",$_POST["izb3_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb4_x"]).",".str_replace(",",".",$_POST["izb4_y"]).",".$_POST["izb4_j"].",".str_replace(",",".",$_POST["izb4_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["napreduje_p1_x"]).",".str_replace(",",".",$_POST["napreduje_p1_y"]).",".$_POST["napreduje_p1_j"].",".str_replace(",",".",$_POST["napreduje_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["napreduje_p2_x"]).",".str_replace(",",".",$_POST["napreduje_p2_y"]).",".$_POST["napreduje_p2_j"].",".str_replace(",",".",$_POST["napreduje_p2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["op1_x"]).",".str_replace(",",".",$_POST["op1_y"]).",".$_POST["op1_j"].",".str_replace(",",".",$_POST["op1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["op2_x"]).",".str_replace(",",".",$_POST["op2_y"]).",".$_POST["op2_j"].",".str_replace(",",".",$_POST["op2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["krajdat_x"]).",".str_replace(",",".",$_POST["krajdat_y"]).",".$_POST["krajdat_j"].",".str_replace(",",".",$_POST["krajdat_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["evst_x"]).",".str_replace(",",".",$_POST["evst_y"]).",".$_POST["evst_j"].",".str_replace(",",".",$_POST["evst_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razr_x"]).",".str_replace(",",".",$_POST["razr_y"]).",".$_POST["razr_j"].",".str_replace(",",".",$_POST["razr_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ravn_x"]).",".str_replace(",",".",$_POST["ravn_y"]).",".$_POST["ravn_j"].",".str_replace(",",".",$_POST["ravn_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razr_p1_x"]).",".str_replace(",",".",$_POST["razr_p1_y"]).",".$_POST["razr_p1_j"].",".str_replace(",",".",$_POST["razr_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razr_p2_x"]).",".str_replace(",",".",$_POST["razr_p2_y"]).",".$_POST["razr_p2_j"].",".str_replace(",",".",$_POST["razr_p2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ravn_p1_x"]).",".str_replace(",",".",$_POST["ravn_p1_y"]).",".$_POST["ravn_p1_j"].",".str_replace(",",".",$_POST["ravn_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ravn_p2_x"]).",".str_replace(",",".",$_POST["ravn_p2_y"]).",".$_POST["ravn_p2_j"].",".str_replace(",",".",$_POST["ravn_p2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenec_p1_x"]).",".str_replace(",",".",$_POST["ucenec_p1_y"]).",".$_POST["ucenec_p1_j"].",".str_replace(",",".",$_POST["ucenec_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenec_p2_x"]).",".str_replace(",",".",$_POST["ucenec_p2_y"]).",".$_POST["ucenec_p2_j"].",".str_replace(",",".",$_POST["ucenec_p2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["koncal_p1_x"]).",".str_replace(",",".",$_POST["koncal_p1_y"]).",".$_POST["koncal_p1_j"].",".str_replace(",",".",$_POST["koncal_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["koncal_p2_x"]).",".str_replace(",",".",$_POST["koncal_p2_y"]).",".$_POST["koncal_p2_j"].",".str_replace(",",".",$_POST["koncal_p2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["da_1_x"]).",".str_replace(",",".",$_POST["da_1_y"]).",".$_POST["da_1_j"].",".str_replace(",",".",$_POST["da_1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["da_2_x"]).",".str_replace(",",".",$_POST["da_2_y"]).",".$_POST["da_2_j"].",".str_replace(",",".",$_POST["da_2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzsljt_x"]).",".str_replace(",",".",$_POST["npzsljt_y"]).",".$_POST["npzsljt_j"].",".str_replace(",",".",$_POST["npzsljt_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzsljp_x"]).",".str_replace(",",".",$_POST["npzsljp_y"]).",".$_POST["npzsljp_j"].",".str_replace(",",".",$_POST["npzsljp_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzmatt_x"]).",".str_replace(",",".",$_POST["npzmatt_y"]).",".$_POST["npzmatt_j"].",".str_replace(",",".",$_POST["npzmatt_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzmatp_x"]).",".str_replace(",",".",$_POST["npzmatp_y"]).",".$_POST["npzmatp_j"].",".str_replace(",",".",$_POST["npzmatp_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npz3_x"]).",".str_replace(",",".",$_POST["npz3_y"]).",".$_POST["npz3_j"].",".str_replace(",",".",$_POST["npz3_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npz3t_x"]).",".str_replace(",",".",$_POST["npz3t_y"]).",".$_POST["npz3t_j"].",".str_replace(",",".",$_POST["npz3t_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npz3p_x"]).",".str_replace(",",".",$_POST["npz3p_y"]).",".$_POST["npz3p_j"].",".str_replace(",",".",$_POST["npz3p_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["so1_x"]).",".str_replace(",",".",$_POST["so1_y"]).",".$_POST["so1_j"].",".str_replace(",",".",$_POST["so1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["so2_x"]).",".str_replace(",",".",$_POST["so2_y"]).",".$_POST["so2_j"].",".str_replace(",",".",$_POST["so2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["sosl_x"]).",".str_replace(",",".",$_POST["sosl_y"]).",".$_POST["sosl_j"].",".str_replace(",",".",$_POST["sosl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tujj1n_x"]).",".str_replace(",",".",$_POST["tujj1n_y"]).",".$_POST["tujj1n_j"].",".str_replace(",",".",$_POST["tujj1n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tujj2n_x"]).",".str_replace(",",".",$_POST["tujj2n_y"]).",".$_POST["tujj2n_j"].",".str_replace(",",".",$_POST["tujj2n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb1n_x"]).",".str_replace(",",".",$_POST["izb1n_y"]).",".$_POST["izb1n_j"].",".str_replace(",",".",$_POST["izb1n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb2n_x"]).",".str_replace(",",".",$_POST["izb2n_y"]).",".$_POST["izb2n_j"].",".str_replace(",",".",$_POST["izb2n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb3n_x"]).",".str_replace(",",".",$_POST["izb3n_y"]).",".$_POST["izb3n_j"].",".str_replace(",",".",$_POST["izb3n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb4n_x"]).",".str_replace(",",".",$_POST["izb4n_y"]).",".$_POST["izb4n_j"].",".str_replace(",",".",$_POST["izb4n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["drusl_x"]).",".str_replace(",",".",$_POST["drusl_y"]).",".$_POST["drusl_j"].",".str_replace(",",".",$_POST["drusl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["drusln_x"]).",".str_replace(",",".",$_POST["drusln_y"]).",".$_POST["drusln_j"].",".str_replace(",",".",$_POST["drusln_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["narsl_x"]).",".str_replace(",",".",$_POST["narsl_y"]).",".$_POST["narsl_j"].",".str_replace(",",".",$_POST["narsl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["narsln_x"]).",".str_replace(",",".",$_POST["narsln_y"]).",".$_POST["narsln_j"].",".str_replace(",",".",$_POST["narsln_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["titsl_x"]).",".str_replace(",",".",$_POST["titsl_y"]).",".$_POST["titsl_j"].",".str_replace(",",".",$_POST["titsl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["titsln_x"]).",".str_replace(",",".",$_POST["titsln_y"]).",".$_POST["titsln_j"].",".str_replace(",",".",$_POST["titsln_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gossl_x"]).",".str_replace(",",".",$_POST["gossl_y"]).",".$_POST["gossl_j"].",".str_replace(",",".",$_POST["gossl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gossln_x"]).",".str_replace(",",".",$_POST["gossln_y"]).",".$_POST["gossln_j"].",".str_replace(",",".",$_POST["gossln_fs"])."'";
                    $SQL = $SQL . ",'".$_POST["tip"]."','".$Danes->format('Y-m-d H:i:s')."')";
                    
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu podatkov za spričevalo!<br />$SQL<br />");
                    }
                    break;
            }
        }
        header("Location: obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "18":
        switch ($_GET["zapis"]){
            case "1":
            case "2":
            case "3":
                break;
            default:
                $SQL = "DELETE FROM tabspricevalo WHERE id=".$_GET["zapis"];
                if (!($result = mysqli_query($link,$SQL))){
                    die("Ne morem zbrisati podatkov!<br />");
                }
        }
        header("Location: obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "19": //izpis obrazca za popravne izpite
        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $FontSize=11;
        $oUcenec=new RUcenec();
        $oUcenec->getUcenec($ucenec);
        $Razred=$oUcenec->getRazred($VLeto);
        
        //vstavi sliko
        $pdf->Image("img/PopravniIzpit1.jpg",0,0,210);

        //'izpiše podatke o šoli
        $poz=explode(",","85,24,L,11");
        if ($poz[0] > 0){
            $pdf->SetFont('arialbd_CE','',$poz[3]);
            $txt=ToWin($VSola);
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        //'naslov šole
        $poz=explode(",","85,29,L,11");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        //Izpis osebnih podatkov
        $poz=explode(",","55,90,C,14");
        if ($poz[0] > 0){
            $pdf->SetFont('arialbd_CE','',$poz[3]);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(100,0,$txt,0,2,$poz[2]);
        }

        //'datum rojstva
        $poz=explode(",","10,84,L,12");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        $poz=explode(",","10,95.5,L,10");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        //Izpis razrednih podatkov
        $poz=explode(",","67,104.5,L,14");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($Razred["razred"].".");
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        $poz=explode(",","158,84,L,12");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        //2. stran
        $pdf->AddPage("P","A4");
        //vstavi sliko
        $pdf->Image("img/PopravniIzpit2.jpg",0,0,210);
        
        //Izpis osebnih podatkov
        $poz=explode(",","10,31,C,16");
        if ($poz[0] > 0){
            $pdf->SetFont('arialbd_CE','',$poz[3]);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(110,0,$txt,0,2,$poz[2]);
        }

        //matični list
        $poz=explode(",","120,180,L,14");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
        }

        //ravnatelj
        $poz=explode(",","130,201,C,12");
        if ($poz[0] > 0){
            $pdf->SetFont('arial_CE','',$poz[3]);
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
            $pdf->Cell(70,0,$txt,0,2,$poz[2]);
        }

        $pdf->Output("PopravniIzpit.pdf","D");
        break;
}        

?>

