<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prakse
</title>
</head>
<body>
<?php

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $IdUcitelj=$R["IdUcitelj"];
    $Ucitelj=$R["Ime"]." ".$R["Priimek"];
    $VIdRazrednik=$R["IdUcitelj"];
    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    function vsebuje($s,$x){
        $a=explode(",",$x);
        $vsebuje=array_search($s,$a);
        if (!is_numeric($vsebuje)){
            return -1;
        }else{
            return $vsebuje;
        }
    } 

    if ($Vid != "1"){
        echo "<a href='prijava.asp'>Nazaj na glavni meni</a><br />";
        echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
        echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";
    }


    switch ($Vid){
        case "1": //'izpis prakse
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VNaslovSole=$R["Naslov"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola=" ";
                $VNaslovSole=" ";
                $VKraj=" ";
            }
            
            $SQL = "SELECT TabPraksa.* FROM TabPraksa INNER JOIN tabucitelji ON TabPraksa.mentor=tabucitelji.idUcitelj WHERE TabPraksa.id=".$_GET["praksa"];
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $VLeto=$R["Leto"];
                $VMentor=$R["Mentor"];
                $VPraksa=$R["Praksa"];
                $VPredmeti=$R["Predmeti"];
                $VStudentov=$R["studentov"];
                $VUstanova=$R["ustanova"];
                $VHospitacije=$R["hospitacije"];
                $VNastopi=$R["nastopi"];
                $VDrugo=$R["drugo"];
            }
            
            echo "<table border='0' width='700'>";
            echo "<tr><td>";
            echo "<table border='0'>";
            echo "<tr><td width='250'><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
            echo "</table>";

            echo "<h1>".$VPraksa."</h1>";
            
            echo "<h3>Mentor: ";
            $SQL="SELECT * FROM tabucitelji WHERE idUcitelj=".$VMentor;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo $R["Ime"]." ".$R["Priimek"];
            }
            echo "&nbsp;</h3>";
            echo "<p>V sodelovanju z ".$VUstanova."</p>";
            echo "<p><b>Predmeti:</b><br />";
            if (strlen($VPredmeti) > 0 ){
                $SQL="SELECT * FROM tabpredmeti WHERE id IN (".$VPredmeti.") ORDER BY opis";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo $R["Oznaka"]." - ".$R["Opis"]."<br />";
                }
            }
            echo "</p>";
            
            echo "<p><b>Vključenih študentov:</b> ".$VStudentov."<br />";
            echo "<p><b>Opazovalna praksa - hospitacije:</b><br />";
            echo $VHospitacije."</p>";
            echo "<p><b>Nastopi študentov:</b><br />";
            echo $VNastopi."</p>";
            echo "<p><b>Druge oblike dela s študenti:</b><br />";
            echo $VDrugo."</p>";
            
            echo "</td></tr></table><br />";
            break;
        case "2": //'briši
            $SQL = "SELECT * FROM TabPraksa WHERE id=".$_GET["praksa"];
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                if (($VLevel > 1) or ($R["Mentor"]==$IdUcitelj) ){
                    $SQL = "DELETE FROM TabPraksa WHERE id=".$_GET["praksa"];
                    $result = mysqli_query($link,$SQL);
                }
            }
            header("Location: Prakse.php");
            break;
        case "3": //'vpis nove prakse
            $VLeto=$_POST["solskoleto"];
            $VMentor=$_POST["mentor"];
            $VPraksa=$_POST["praksa"];
            $VPredmeti=$_POST["predmeti"];
            $VStudentov=$_POST["studentov"];
            $VUstanova=$_POST["ustanova"];
            $VHospitacije=$_POST["hospitacije"];
            if (strlen($VHospitacije) > 0){
                $VHospitacije=str_replace("'","",$VHospitacije);
            }
            $VNastopi=$_POST["nastopi"];
            if (strlen($VNastopi) > 0){
                $VNastopi=str_replace("'","",$VNastopi);
            }
            $VDrugo=$_POST["drugo"];
            if (strlen($VDrugo) > 0){
                $VDrugo=str_replace("'","",$VDrugo);
            }
            
            $SQL = "INSERT INTO TabPraksa (leto,mentor,praksa,predmeti,studentov,ustanova,hospitacije,nastopi,drugo,cas,vpisal) VALUES (";
            $SQL = $SQL . $VLeto;
            $SQL = $SQL . ",".$VMentor;
            $SQL = $SQL . ",'".$VPraksa."'";
            $SQL = $SQL . ",'".$VPredmeti."'";
            $SQL = $SQL . ",".$VStudentov;
            $SQL = $SQL . ",'".$VUstanova."'";
            $SQL = $SQL . ",'".$VHospitacije."'";
            $SQL = $SQL . ",'".$VNastopi."'";
            $SQL = $SQL . ",'".$VDrugo."'";
            $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
            $SQL = $SQL . ",'".$VUporabnik."'";
            $SQL = $SQL .")";
            $result = mysqli_query($link,$SQL);

            header("Location: Prakse.php");
            break;
        case "4": //'popravi praksa
            $SQL="SELECT * FROM TabPraksa WHERE id=".$_POST["praksa"];
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $VLeto=$R["Leto"];
                $VMentor=$R["Mentor"];
                $VPraksa=$R["Praksa"];
                $VPredmeti=$R["Predmeti"];
                $VStudentov=$R["studentov"];
                $VUstanova=$R["ustanova"];
                $VHospitacije=$R["hospitacije"];
                $VNastopi=$R["nastopi"];
                $VDrugo=$R["drugo"];
            }
            
            $SQL="SELECT * FROM tabucitelji WHERE idUcitelj=".$VMentor;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $Ucitelj=$R["Priimek"]." ".$R["Ime"];
            }else{
                $Ucitelj="Napaka!!!";
            }
            
            echo "<h2>Popravi prakso - ".$Ucitelj.":</h2>";
            echo "<form accept-charset='utf-8' name='form_novapraksa' method=post action='Prakse.php'>";
            echo "<input type='hidden' name='praksaID' value='".$_POST["praksa"]."'>";
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "<input type='hidden' name='id' value='5'>";

            echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60' value='".$VPraksa."'><br /><br />";
            
            echo "<b>Mentor:</b> ";
            if ($VLevel > 1 ){
                $SQL="SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                echo "<select name='mentor'>";
                echo "<option value='0'>Ni izbran</option>";
                while ($R = mysqli_fetch_array($result)){
                    if ($R["IdUcitelj"]==$VMentor ){
                        echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
                    }else{
                        echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
                    }
                }
                echo "</select><br /><br />";
            }else{
                echo "<select name='mentor'>";
                echo "<option value='".$VMentor."' selected='selected'>".$Ucitelj."</option>";
                echo "</select><br /><br />";
            }
            
            echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' value='".$VUstanova."'><br /><br />";
            
            $SQL="SELECT * FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
            $result = mysqli_query($link,$SQL);
            echo "Predmeti:<br /><select name='predmeti' size='15' multiple>";
            while ($R = mysqli_fetch_array($result)){
                if (vsebuje($R["Id"],$VPredmeti) > -1 ){
                    echo "<option value='".$R["Id"]."' selected='selected'>".$R["Opis"]." (".$R["Oznaka"].")</option>";
                }else{
                    echo "<option value='".$R["Id"]."'>".$R["Opis"]."(".$R["Oznaka"].")</option>";
                }
            }
            echo "</select><br /><br/ >";
            
            echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' value='".$VStudentov."'><br /><br />";
            
            echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'>".$VHospitacije."</textarea><br />";
            echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'>".$VNastopi."</textarea><br />";
            echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'>".$VDrugo."</textarea><br />";

            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='submit' type='submit' value='Pošlji popravek'>";
            echo "</form>";
            break;
        case "5": //'vpis popravljenih podatkov
            $VLeto=$_POST["solskoleto"];
            $VMentor=$_POST["mentor"];
            $VPraksa=$_POST["praksa"];
            $VPredmeti=$_POST["predmeti"];
            $VStudentov=$_POST["studentov"];
            $VUstanova=$_POST["ustanova"];
            $VHospitacije=$_POST["hospitacije"];
            if (strlen($VHospitacije) > 0){
                $VHospitacije=str_replace("'","",$VHospitacije);
            }
            $VNastopi=$_POST["nastopi"];
            if (strlen($VNastopi) > 0){
                $VNastopi=str_replace("'","",$VNastopi);
            }
            $VDrugo=$_POST["drugo"];
            if (strlen($VDrugo) > 0){
                $VDrugo=str_replace("'","",$VDrugo);
            }
        
            $SQL = "SELECT * FROM TabPraksa WHERE id=".$_POST["praksaID"];
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $SQL = "UPDATE TabPraksa SET ";
                $SQL = $SQL . "mentor=".$VMentor;
                $SQL = $SQL . ",praksa='".$VPraksa."'";
                $SQL = $SQL . ",predmeti='".$VPredmeti."'";
                $SQL = $SQL . ",studentov=".$VStudentov;
                $SQL = $SQL . ",ustanova='".$VUstanova."'";
                $SQL = $SQL . ",hospitacije='".$VHospitacije."'";
                $SQL = $SQL . ",nastopi='".$VNastopi."'";
                $SQL = $SQL . ",drugo='".$VDrugo."'";
                $SQL = $SQL . ",cas='".$Danes->format('Y-m-d H:i:s')."'";
                $SQL = $SQL . ",vpisal='".$VUporabnik."'";
                $SQL = $SQL . " WHERE id=".$R["Id"];
                $result = mysqli_query($link,$SQL);
            }
            header("Location: Prakse.php");
            break;
        default:
            $SQL = "SELECT TabPraksa.*,tabucitelji.priimek,tabucitelji.ime FROM TabPraksa INNER JOIN tabucitelji ON TabPraksa.Mentor=tabucitelji.idUcitelj WHERE TabPraksa.leto=".$VLeto." ORDER BY TabPraksa.praksa";
            $result = mysqli_query($link,$SQL);

            if (mysqli_num_rows($result) > 0){
                echo "<form accept-charset='utf-8' name='form_praksa' method=post action='Prakse.php'>";
                echo "<h2>Izbor prakse za popravljanje</h2>";
                echo "<select name='praksa'>";
                while ($R = mysqli_fetch_array($result)){
                    if (($R["Mentor"]==$IdUcitelj) or ($VLevel > 1) ){
                        echo "<option value='".$R["Id"]."'>".$R["Praksa"]." - ".$R["priimek"]." ".$R["ime"]."</option>";
                    }
                }
                echo "</select>";
                echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                echo "<input name='level' type='hidden' value='".$VLevel."'>";
                echo "<input type='hidden' name='id' value='4'>";
                echo "<input name='submit' type='submit' value='Izberi prakso'>";
                echo "</form>";
                
                $result = mysqli_query($link,$SQL);
                echo "<h2>Pregled praks</h2>";
                echo "<table border=1>";
                echo "<tr><th>Praksa</th><th>Mentor</th><th>Predmet</th><th>Študentov</th><th>Briši</th></tr>";
                $VSumStudentov=0;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td><a href='Prakse.php?praksa=".$R["Id"]."&id=1'>".$R["Praksa"]."</a></td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                    
                    echo "<td>";
                    if (isset($R["Predmeti"])){
                        if (strlen($R["Predmeti"] > 0)){
                            $SQL="SELECT * FROM tabpredmeti WHERE id IN (".$R["Predmeti"].") ORDER BY opis";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["Oznaka"]." - ".$R1["Opis"]."<br />";
                            }
                        }
                    }
                    echo "</td>";
                    echo "<td align='center'>".$R["studentov"]."</td>";
                    $VSumStudentov=$VSumStudentov+$R["studentov"];
                    echo "<td><a href='Prakse.php?praksa=".$R["Id"]."&id=2'>Briši</a></td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "Skupaj je bilo udeleženih ".$VSumStudentov." študentov.";
                echo "<hr>";
                
                echo "<h2>Nova praksa - ".$Ucitelj.":</h2>";
                echo "<form accept-charset='utf-8' name='form_novapraksa' method=post action='Prakse.php'>";
                echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<input type='hidden' name='id' value='3'>";

                echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60'><br /><br />";
                
                echo "<b>Mentor:</b> ";
                if ($VLevel > 1 ){
                    $SQL="SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    echo "<select name='mentor'>";
                    echo "<option value='0'>Ni izbran</option>";
                    while ($R = mysqli_fetch_array($result)){
                        echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
                    }
                    echo "</select><br /><br />";
                }else{
                    echo "<select name='mentor'>";
                    echo "<option value='".$IdUcitelj."' selected='selected'>".$Ucitelj."</option>";
                    echo "</select><br /><br />";
                }
                
                echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' ><br /><br />";
                
                $SQL="SELECT * FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
                $result = mysqli_query($link,$SQL);
                echo "Predmeti:<br /><select name='predmeti' size='15' multiple>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["Id"]."'>".$R["Opis"]." (".$R["Oznaka"].")</option>";
                }
                echo "</select><br /><br/ >";
                
                echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' ><br /><br />";
                
                echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'></textarea><br />";
                echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'></textarea><br />";
                echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'></textarea><br />";

                echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                echo "<input name='level' type='hidden' value='".$VLevel."'>";
                echo "<input name='submit' type='submit' value='Pošlji novo prakso'>";
                echo "</form>";
            }else{
                echo "<h2>Nova praksa - ".$Ucitelj.":</h2>";
                echo "<form accept-charset='utf-8' name='form_novapraksa' method=post action='Prakse.php'>";
                echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<input type='hidden' name='id' value='3'>";

                echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60'><br /><br />";
                
                echo "<b>Mentor:</b> ";
                if ($VLevel > 1 ){
                    $SQL="SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    echo "<select name='mentor'>";
                    echo "<option value='0'>Ni izbran</option>";
                    while ($R = mysqli_fetch_array($result)){
                        echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
                    }
                    echo "</select><br /><br />";
                }else{
                    echo "<select name='mentor'>";
                    echo "<option value='".$IdUcitelj."' selected='selected'>".$Ucitelj."</option>";
                    echo "</select><br /><br />";
                }
                
                echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' ><br /><br />";
                
                $SQL="SELECT * FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
                $result = mysqli_query($link,$SQL);
                echo "Predmeti:<br /><select name='predmeti' size='15' multiple>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["Id"]."'>".$R["Opis"]." (".$R["Oznaka"].")</option>";
                }
                echo "</select><br /><br/ >";
                
                echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' ><br /><br />";
                
                echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'></textarea><br />";
                echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'></textarea><br />";
                echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'></textarea><br />";

                echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                echo "<input name='level' type='hidden' value='".$VLevel."'>";
                echo "<input name='submit' type='submit' value='Pošlji novo prakso'>";
                echo "</form>";
            }

    }
}
?>

</body>
</html>
