<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Mesečni pregledi
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }
        if (isset($_POST["iducitelj"])){
            $ucitelj=$_POST["iducitelj"];
        }else{
            if (isset($_GET["iducitelj"])){
                $ucitelj=$_GET["iducitelj"];
            }else{
                $ucitelj=0;
            }
        }

        $VLetoPregled=$VLeto;

        if (isset($_POST["mesec"])){
            $VMesec=$_POST["mesec"];
        }else{
            if (isset($_GET["mesec"])){
                $VMesec=$_GET["mesec"];
            }else{
                $VMesec=$Danes->format('m');
            }
        }
        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        echo "<h2>Zbirnik za mesec ".$VMesec."/".$VLetoPregled." - ".$Danes->format('d.m.Y')."</h2>";
        echo "<table border='1'>";
        echo "<tr><th></th>";
        for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
	        echo "<th>".$Indx."</th>";
        }
        echo "</tr>";


        $SQL = "SELECT tabucitelji.IdUcitelj FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
	        $oUcitelj=new RUcitelj();
	        $oUcitelj->PreberiSe($R["IdUcitelj"],$VLetoPregled,$VLeto);

	        $oUcitelj->IzracunPrisotnostiMesec($VLetoPregled,$VMesec,2);
	        $oUcitelj->IzpisMesecaPrisotnosti($VLetoPregled,$VMesec,1);
	        $oUcitelj=null;
        }
        echo "</table><br>";

        echo "<h3>Legenda:</h3>";
        $SQL = "SELECT * FROM TabDoprinos WHERE aktivno > 2 ORDER BY aktivno";
        $result = mysqli_query($link,$SQL);

        echo "<table border='0'>";
        echo "<tr><th>Oznaka</th><th>Pomen</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["OblikaDelaOznaka"]."</td>";
            echo "<td> - ".$R["OblikaDela"]."</td>";
            echo "</tr>";
        }
        echo "<tr><td bgcolor='lightsalmon'>&nbsp;</td><td> - sobote in nedelje</td></tr>";
        echo "<tr><td bgcolor='lightgreen'>&nbsp;</td><td> - prazniki</td></tr>";
        echo "<tr><td bgcolor='lightblue'>&nbsp;</td><td> - počitnice brez delovne obveznosti</td></tr>";
        echo "<tr><td bgcolor='lightgrey'>&nbsp;</td><td> - počitnice z delovno obveznostjo</td></tr>";
        echo "<tr><td bgcolor='lightcyan'>&nbsp;</td><td> - dopust na običajen delovni dan</td></tr>";
        echo "<tr><td bgcolor='lightyellow'>&nbsp;</td><td> - bolniška odsotnost</td></tr>";
        echo "<tr><td bgcolor='lime'>&nbsp;</td><td> - spremstvo (dnevi dejavnosti, tabori, šola v naravi)</td></tr>";
        echo "<tr><td bgcolor='lightpink'>&nbsp;</td><td> - tečaj, izobraževanje</td></tr>";
        echo "<tr><td bgcolor='blue'>&nbsp;</td><td> - neopravičena odsotnost</td></tr>";
        echo "</table><br>";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
    
?>
<br>
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
