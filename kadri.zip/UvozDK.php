<?php
require ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Uvoz
</title>
</head>
<body>
<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}
if ($id=="1") {
    $VFile="kadriucitelji.csv";
    $MyFile = "dato".$FileSep.$VFile;
    $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");
    
    fwrite ($fh, chr(34)."Priimek".chr(34).";".chr(34)."Ime".chr(34).";".chr(34)."Dekliski".chr(34).";".chr(34)."Spol".chr(34).";".chr(34)."DatRoj".chr(34).";".chr(34)."EMSO".chr(34).";".chr(34)."Naslov".chr(34).";".chr(34)."Posta".chr(34).";".chr(34)."Kraj".chr(34).";".chr(34)."Izobrazba".chr(34).";".chr(34)."IzobOpis".chr(34).";".chr(34)."Uporabnik".chr(34).";".chr(34)."Geslo".chr(34).";".chr(34)."NivoDostopa".chr(34).";".chr(34)."Status".chr(34).";".chr(34)."PedIzobr".chr(34).";");
    fwrite ($fh, chr(34)."StrokIzpit".chr(34).";".chr(34)."Mentor".chr(34).";".chr(34)."Svetovalec".chr(34).";".chr(34)."Svetnik".chr(34).";".chr(34)."Davcna".chr(34).";".chr(34)."Obcina".chr(34).";".chr(34)."Drzava".chr(34).";".chr(34)."drzavljanstvo".chr(34).";".chr(34)."KrajRoj".chr(34).";".chr(34)."DrzavaRoj".chr(34).";".chr(34)."NaslovZac".chr(34).";".chr(34)."PostaZac".chr(34).";".chr(34)."KrajZac".chr(34).";");
    fwrite ($fh, chr(34)."ObcinaZac".chr(34).";".chr(34)."DrzavaZac".chr(34).";".chr(34)."Invalid".chr(34).";".chr(34)."KatInvalid".chr(34).";".chr(34)."DelnoUpokojen".chr(34).";".chr(34)."Starejsi".chr(34).";".chr(34)."DojecaMati".chr(34).";");
    fwrite ($fh, chr(34)."IzobUstr".chr(34).";".chr(34)."IdDelo".chr(34).";".chr(34)."IdVzgojnoDelo".chr(34).";".chr(34)."DatumStart".chr(34).";".chr(34)."DatumEnd".chr(34).";");
    fwrite ($fh, chr(34)."DopDelo".chr(34).";".chr(34)."Delodaj1".chr(34).";".chr(34)."Delodaj1mat".chr(34).";".chr(34)."Delodaj1naslov".chr(34).";".chr(34)."Delodaj2".chr(34).";".chr(34)."Delodaj2mat".chr(34).";".chr(34)."Delodaj2naslov".chr(34).";".chr(34)."Delodaj3".chr(34).";".chr(34)."Delodaj3mat".chr(34).";".chr(34)."Delodaj3naslov".chr(34).";");
    fwrite ($fh, chr(34)."DatumPogodbe".chr(34).";".chr(34)."PolniDelCas".chr(34).";".chr(34)."RazlogDolCas".chr(34).";".chr(34)."PotrStrokUsp".chr(34).";".chr(34)."NazivDelMesta".chr(34).";".chr(34)."UrTeden".chr(34).";".chr(34)."Izmensko".chr(34).";".chr(34)."KrajDela".chr(34).";".chr(34)."KonkKlavz".chr(34).";".chr(34)."NacinPrenehanja".chr(34).";");
    fwrite ($fh, chr(34)."StPogodbe".chr(34).";".chr(34)."Obremen1".chr(34).";".chr(34)."Obremen2".chr(34).";".chr(34)."Obremen3".chr(34).";".chr(34)."Obremen4".chr(34).";".chr(34)."Obremen5".chr(34).";");
    fwrite ($fh, chr(34)."DelDobaLet".chr(34).";".chr(34)."DopustNaDD".chr(34).";".chr(34)."DopustNaIz".chr(34).";".chr(34)."DopustNaOt".chr(34).";".chr(34)."DopustNaSta".chr(34).";".chr(34)."DopustNaInv".chr(34).";".chr(34)."DopustNaVod".chr(34).";".chr(34)."DopustStari".chr(34).";".chr(34)."DopustVzgoja".chr(34).";".chr(34)."DopustDelInv".chr(34).";".chr(34)."DopustPP".chr(34).";".chr(34)."Drugo".chr(34).";");
    fwrite ($fh, chr(34)."Telefon".chr(34).";".chr(34)."email".chr(34).chr(13).chr(10));
    
    $SQL = "SELECT * FROM tabucitelji ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        fwrite ($fh, chr(34).$R["Priimek"].chr(34).";");
        fwrite ($fh, chr(34).$R["Ime"].chr(34).";");
        fwrite ($fh, chr(34).$R["Dekliski"].chr(34).";");
        fwrite ($fh, chr(34).$R["Spol"].chr(34).";");
        fwrite ($fh, chr(34).$R["DatRoj"].chr(34).";");
        fwrite ($fh, chr(34).$R["EMSO"].chr(34).";");
        fwrite ($fh, chr(34).$R["Naslov"].chr(34).";");
        fwrite ($fh, $R["Posta"].";");
        fwrite ($fh, chr(34).$R["Kraj"].chr(34).";");
        fwrite ($fh, $R["Izobrazba"].";");
        fwrite ($fh, chr(34).$R["IzobOpis"].chr(34).";");
        fwrite ($fh, chr(34).$R["Uporabnik"].chr(34).";");
        fwrite ($fh, chr(34).$R["Geslo"].chr(34).";");
        fwrite ($fh, $R["NivoDostopa"].";");
        fwrite ($fh, $R["Status"].";");
        fwrite ($fh, chr(34).$R["PedIzobr"].chr(34).";");
        fwrite ($fh, chr(34).$R["StrokIzpit"].chr(34).";");
        fwrite ($fh, chr(34).$R["Mentor"].chr(34).";");
        fwrite ($fh, chr(34).$R["Svetovalec"].chr(34).";");
        fwrite ($fh, chr(34).$R["Svetnik"].chr(34).";");
        fwrite ($fh, chr(34).$R["Davcna"].chr(34).";");
        fwrite ($fh, $R["Obcina"].";");
        fwrite ($fh, $R["Drzava"].";");
        fwrite ($fh, chr(34).$R["drzavljanstvo"].chr(34).";");
        fwrite ($fh, chr(34).$R["KrajRoj"].chr(34).";");
        fwrite ($fh, chr(34).$R["DrzavaRoj"].chr(34).";");
        fwrite ($fh, chr(34).$R["NaslovZac"].chr(34).";");
        fwrite ($fh, $R["PostaZac"].";");
        fwrite ($fh, chr(34).$R["KrajZac"].chr(34).";");
        fwrite ($fh, $R["ObcinaZac"].";");
        fwrite ($fh, $R["DrzavaZac"].";");
        fwrite ($fh, $R["Invalid"].";");
        fwrite ($fh, chr(34).$R["KatInvalid"].chr(34).";");
        fwrite ($fh, chr(34).$R["DelnoUpokojen"].chr(34).";");
        fwrite ($fh, $R["Starejsi"].";");
        fwrite ($fh, $R["DojecaMati"].";");
        
        $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$R["IdUcitelj"]." ORDER BY id DESC";
        $result1 = mysqli_query($link,$SQL);
        if ($R1 = mysqli_fetch_array($result1)){
            fwrite ($fh, $R1["IzobUstr"].";");
            fwrite ($fh, $R1["IdDelo"].";");
            fwrite ($fh, $R1["IdVzgojnoDelo"].";");
            fwrite ($fh, chr(34).$R1["DatumStart"].chr(34).";");
            fwrite ($fh, chr(34).$R1["DatumEnd"].chr(34).";");
            fwrite ($fh, $R1["DopDelo"].";");
            fwrite ($fh, chr(34).$R1["Delodaj1"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj1mat"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj1naslov"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj2"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj2mat"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj2naslov"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj3"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj3mat"].chr(34).";");
            fwrite ($fh, chr(34).$R1["Delodaj3naslov"].chr(34).";");
            fwrite ($fh, chr(34).$R1["DatumPogodbe"].chr(34).";");
            fwrite ($fh, chr(34).$R1["PolniDelCas"].chr(34).";");
            fwrite ($fh, chr(34).$R1["RazlogDolCas"].chr(34).";");
            fwrite ($fh, chr(34).$R1["PotrStrokUsp"].chr(34).";");
            fwrite ($fh, chr(34).$R1["NazivDelMesta"].chr(34).";");
            fwrite ($fh, $R1["UrTeden"].";");
            fwrite ($fh, $R1["Izmensko"].";");
            fwrite ($fh, chr(34).$R1["KrajDela"].chr(34).";");
            fwrite ($fh, $R1["KonkKlavz"].";");
            fwrite ($fh, chr(34).$R1["NacinPrenehanja"].chr(34).";");
            fwrite ($fh, chr(34).$R1["StPogodbe"].chr(34).";");
            fwrite ($fh, $R1["Obremen1"].";");
            fwrite ($fh, $R1["Obremen2"].";");
            fwrite ($fh, $R1["Obremen3"].";");
            fwrite ($fh, $R1["Obremen4"].";");
            fwrite ($fh, $R1["Obremen5"].";");
        }else{
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, ";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, ";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, chr(34).chr(34).";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
        }
        
        $SQL = "SELECT * FROM tabdopust WHERE idUcitelj=".$R["IdUcitelj"]." ORDER BY id DESC";
        $result1 = mysqli_query($link,$SQL);
        if ($R1 = mysqli_fetch_array($result1)){
            fwrite ($fh, $R1["DelDobaLet"].";");
            fwrite ($fh, $R1["DopustNaDD"].";");
            fwrite ($fh, $R1["DopustNaIz"].";");
            fwrite ($fh, $R1["DopustNaOt"].";");
            fwrite ($fh, $R1["DopustNaSta"].";");
            fwrite ($fh, $R1["DopustNaInv"].";");
            fwrite ($fh, $R1["DopustNaVod"].";");
            fwrite ($fh, $R1["DopustStari"].";");
            fwrite ($fh, $R1["DopustVzgoja"].";");
            fwrite ($fh, $R1["DopustDelInv"].";");
            fwrite ($fh, $R1["DopustPP"].";");
            fwrite ($fh, $R1["Drugo"].";");
        }else{
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
            fwrite ($fh, ";");
        }
        
        $SQL = "SELECT * FROM tabkontakti WHERE idUcitelj=".$R["IdUcitelj"];
        $result1 = mysqli_query($link,$SQL);
        if ($R1 = mysqli_fetch_array($result1)){
            fwrite ($fh, chr(34).$R1["Telefon"].chr(34).";");
            fwrite ($fh, chr(34).$R1["email"].chr(34).chr(13).chr(10));
        }else{
            fwrite ($fh, chr(34).chr(34).";".chr(34).chr(34).chr(13).chr(10));
        }
    }
    fclose($fh);

    echo "Za prenos CSV datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br>";
    echo "<h3><a href='".$MyFile."'>Shrani datoteko ".$VFile."</a></h3>";
    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";
}else{
    echo "<form accept-charset='utf-8' name='uvoz' method='post' ENCTYPE='multipart/form-data' action='ImportDK.php'>";
    echo "<h2>Uvoz podatkov v Kadre (csv - polja ločena s podpičji)</h2>";
   // echo "<input name='servaddr' type='hidden' value='".$_SERVER["LOCAL_ADDR"]."'>";
    echo "<table border=0><tr>";
    echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
    echo "<input name='povezava' type='hidden' value='/'>";
    echo "</table>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";
}
?>
</body>
</html>
