<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izobraževanja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    /*
    if ($Vid != "5"){
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    }
    */
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (isset($_POST["ucitelj"])){
        $Ucitelj = $_POST["ucitelj"];
    }else{
        if (isset($_GET["ucitelj"])){
            $Ucitelj = $_GET["ucitelj"];
        }else{
            if (isset($_SESSION["ucitelj"])){ 
                $Ucitelj = $_SESSION["ucitelj"];
            }else{
                $Ucitelj = 0;
            }
        }
    }

    switch ( $Vid ){
	    case "1": //vpis novega izobraževanja
		    $VIzobrazevanje=$_POST["Izobrazevanje"];
		    $VKraj=$_POST["Kraj"];
		    $VDatumOd=$_POST["DatumOd"];
            if (!isDate($VDatumOd)){
                $VDatumOd=$Danes->format('j.n.Y');
            }                        
		    $VDatumDo=$_POST["DatumDo"];
            if (!isDate($VDatumDo)){
                $VDatumDo=$Danes->format('j.n.Y');
            }                        
		    $VIzvajalec=$_POST["Izvajalec"];
		    $VNaslov=$_POST["Naslov"];
		    $VTrajanje=$_POST["Trajanje"];
		    $VTocke=$_POST["Tocke"];
		    $VKotizacija=$_POST["Kotizacija"];
            if (strlen($VKotizacija) > 0){
                $VKotizacija=str_replace(",",".",$VKotizacija);
            }
		    if (!is_numeric($VKotizacija)){
                $VKotizacija=0;
            }
		    $VOstStroski=str_replace(",",".",$_POST["OstStroski"]);
		    if (!is_numeric($VOstStroski)){
                $VOstStroski=0;
            }
		    if ($VLevel > 1 ){  //potrjeno
			    if (isset($_POST["Priporocam"])){
				    $VPriporocam="true";
			    }else{
				    $VPriporocam="false";
			    }
		    }else{
			    $VPriporocam="false";
		    }
		    if (isset($_POST["Porocilo"])){
                $VPorocilo=$_POST["Porocilo"];
            }else{
                $VPorocilo="";
            }
		    
		    $SQL = "SELECT tabizobrazevanje.*,tabucitelji.priimek,tabucitelji.ime FROM tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.idUcitelj=tabucitelji.idUcitelj ";
		    $SQL = $SQL . " WHERE leto=".$VLeto;
		    $SQL = $SQL ." AND tabizobrazevanje.idUcitelj=".$Ucitelj;
		    $SQL = $SQL ." AND Izobrazevanje='".$VIzobrazevanje."'";
		    $SQL = $SQL ." AND tabizobrazevanje.Kraj='".$VKraj."'";
		    $SQL = $SQL ." AND DatumOd='".$VDatumOd."'";
		    $SQL = $SQL ." AND DatumDo='".$VDatumDo."'";
		    $SQL = $SQL ." AND Izvajalec='".$VIzvajalec."'";
		    $SQL = $SQL ." AND tabizobrazevanje.Naslov='".$VNaslov."'";
		    $SQL = $SQL ." AND Trajanje='".$VTrajanje."'";
		    $SQL = $SQL ." AND Tocke='".$VTocke."'";
		    
    //'		response.write $SQL."<br>"
		    $result = mysqli_query($link,$SQL);
		    
		    if (mysqli_num_rows($result) > 0){
			    echo "<h2>Podatki so bili že vpisani!</h2>";
		    }else{
			    $SQL="INSERT INTO tabizobrazevanje (leto,idUcitelj,Izobrazevanje,Kraj,DatumOd,DatumDo,Izvajalec,Naslov,Trajanje,Tocke,Kotizacija,OstStroski,priporocam,porocilo,vpisal,cas) ";
			    $SQL = $SQL . "VALUES (";
			    $SQL = $SQL .$VLeto.",".$Ucitelj.",";
			    $SQL = $SQL ."'".$VIzobrazevanje."',";
			    $SQL = $SQL ."'".$VKraj."',";
			    $SQL = $SQL ."'".$VDatumOd."',";
			    $SQL = $SQL ."'".$VDatumDo."',";
			    $SQL = $SQL ."'".$VIzvajalec."',";
			    $SQL = $SQL ."'".$VNaslov."',";
			    $SQL = $SQL ."'".$VTrajanje."',";
			    $SQL = $SQL ."'".$VTocke."',";
			    $SQL = $SQL .$VKotizacija.",";
			    $SQL = $SQL .$VOstStroski.",";
			    $SQL = $SQL .$VPriporocam.",";
			    $SQL = $SQL ."'".$VPorocilo."',";
			    $SQL = $SQL ."'".$VUporabnik."',";
			    $SQL = $SQL ."'".$Danes->format('Y-m-d H:i:s')."'";
			    $SQL = $SQL .")";
			    $result = mysqli_query($link,$SQL);

			    echo "<h2>Podatki so vpisani!</h2>";
			    
			    $VTipID=17;
			    $SQL = "SELECT * FROM tabzapisniktip WHERE id=".$VTipID;
			    $result = mysqli_query($link,$SQL);
			    if ($R = mysqli_fetch_array($result)){
				    $VTipNaslov=$R["tip"];
			    }
			    
			    if ($Opravila==1 ){
				    $SQL = "SELECT tabdeldogodek.id FROM ";
				    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
				    $SQL = $SQL . "WHERE tabdogodek.Dogodek='".$VTipNaslov."' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
				    $result = mysqli_query($link,$SQL);

				    $Indx=1;
				    while ($R = mysqli_fetch_array($result)){
					    $VDogodki[$Indx]=$R["id"];
					    $Indx=$Indx+1;
				    }
				    $StDogodkov=$Indx-1;

				    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
					    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
					    $result = mysqli_query($link,$SQL);
				    }
			    }
		    }
            break;
	    case "2": //popravi oz. dopolni zapis
		    echo "<h3>Če je izobraževanje odpadlo v poročilo vpišite ODPADLO (z velikimi tiskanimi in samo to!!!)</h3>";
		    $SQL = "SELECT * FROM tabizobrazevanje WHERE id=".$_GET["popravi"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $Ucitelj=$R["idUcitelj"];
			    $VIzobrazevanje=$R["Izobrazevanje"];
			    $VKraj=$R["Kraj"];
			    $VDatumOd=$R["DatumOd"];
			    $VDatumDo=$R["DatumDo"];
			    $VIzvajalec=$R["Izvajalec"];
			    $VNaslov=$R["Naslov"];
			    $VTrajanje=$R["Trajanje"];
			    $VTocke=$R["Tocke"];
			    $VKotizacija=$R["Kotizacija"];
			    $VOstStroski=$R["OstStroski"];
			    $VPriporocam=$R["priporocam"];
			    $VPorocilo=$R["porocilo"];
			    $VidIzobrazevanje=$R["id"];
		    }
		    echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='VnosIzobrazevanje.php'>";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr>";
		    echo "<th>Leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";
		    echo "<tr><th>Ime</th><td><select name='ucitelj'>";

		    $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if ($Ucitelj==$R["IdUcitelj"] ){
				    echo "<option value=".$R["IdUcitelj"]." selected>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }else{
				    echo "<option value=".$R["IdUcitelj"].">".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }
		    }
		    echo "</select></td></tr>";

		    echo "<tr><th>Izobraževanje</th><td><input name='Izobrazevanje' type='text' size='30' value='".$VIzobrazevanje."'></td></tr>";
		    echo "<tr><th>Izvajalec</th><td><input name='Izvajalec' type='text' size='20' value='".$VIzvajalec."'></td></tr>";
		    echo "<tr><th>Naslov izvajalca</th><td><input name='Naslov' type='text' size='30' value='".$VNaslov."'></td></tr>";
		    echo "<tr><th>Kraj izvedbe</th><td><input name='Kraj' type='text' size='20' value='".$VKraj."'></td></tr>";
		    echo "<tr><th>Datum in čas od</th><td><input name='DatumOd' type='text' size='10' value='".$VDatumOd."'></td></tr>";
		    echo "<tr><th>Datum in čas do</th><td><input name='DatumDo' type='text' size='10' value='".$VDatumDo."'></td></tr>";
		    echo "<tr><th>Trajanje</th><td><input name='Trajanje' type='text' size='5' value='".$VTrajanje."'></td></tr>";
		    echo "<tr><th>Točke</th><td><input name='Tocke' type='text' size='3' value='".$VTocke."'></td></tr>";
		    echo "<tr><th>Kotizacija EUR</th><td><input name='Kotizacija' type='text' size='6' value='".$VKotizacija."'></td></tr>";
		    echo "<tr><th>Ostali stroški EUR</th><td><input name='OstStroski' type='text' size='6' value='".$VOstStroski."'></td></tr>";
		    echo "<tr><th>Poročilo</th><td><textarea name='Porocilo' rows='4' cols='40'>".$VPorocilo."</textarea></td></tr>";
		    if ($VPriporocam ){
			    echo "<tr><th>Odobreno</th><td><input name='Priporocam' type='checkbox' checked></td></tr>";
		    }else{
			    echo "<tr><th>Odobreno</th><td><input name='Priporocam' type='checkbox'></td></tr>";
		    }

		    echo "</table>";
		    echo "<input name='SolskoLeto' type='hidden' value='".$VLeto."'>";
		    echo "<input name='id' type='hidden' value='4'>";
		    echo "<input name='idizobrazevanje' type='hidden' value='".$VidIzobrazevanje."'>";
		    echo "<input name='submit' type='submit' value='Pošlji'>";
		    echo "</form>";
            break;
	    case "3": //brisanje poročila
		    $SQL = "SELECT * FROM tabizobrazevanje WHERE id=".$_GET["brisi"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    if ((($VLevel < 2) && ($UciteljComp==$R["idUcitelj"])) or ($VLevel > 1) ){
				    $SQL = "DELETE FROM tabizobrazevanje WHERE id=".$_GET["brisi"];
				    $result = mysqli_query($link,$SQL);
			    }else{
				    echo "Nimate pooblastil za brisanje teh podatkov!<br />";
			    }
		    }
            break;
	    case "4":  //vpis popravka oz. vsebine poročila
		    $VTipID=17;
		    $SQL = "SELECT * FROM tabzapisniktip WHERE id=".$VTipID;
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $VTipNaslov=$R["tip"];
		    }

		    $VIzobrazevanje=$_POST["Izobrazevanje"];
		    $VKraj=$_POST["Kraj"];
		    $VDatumOd=$_POST["DatumOd"];
		    if (!isDate($VDatumOd)){ 
                $VDatumOd=$Danes->format('j.n.Y');
            }
		    $VDatumDo=$_POST["DatumDo"];
		    if (!isDate($VDatumDo) ){ 
                $VDatumDo=$Danes->format('j.n.Y');
            }
		    $VIzvajalec=$_POST["Izvajalec"];
		    $VNaslov=$_POST["Naslov"];
		    $VTrajanje=$_POST["Trajanje"];
		    $VTocke=$_POST["Tocke"];
		    $VKotizacija=$_POST["Kotizacija"];
            if (strlen($VKotizacija) > 0){
                $VKotizacija=str_replace(",",".",$VKotizacija);
            }
            if (!is_numeric($VKotizacija)){
                $VKotizacija=0;
            }
            $VOstStroski=str_replace(",",".",$_POST["OstStroski"]);
            if (!is_numeric($VOstStroski)){
                $VOstStroski=0;
            }
            if ($VLevel > 1 ){  //potrjeno
                if (isset($_POST["Priporocam"])){
                    $VPriporocam="true";
                }else{
                    $VPriporocam="false";
                }
            }else{
                $VPriporocam="false";
            }
		    
		    $SQL = "SELECT * FROM tabizobrazevanje WHERE id =".$_POST["idizobrazevanje"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
                if ($VLevel < 2){
				    if ($R["priporocam"] ){
					    $VPriporocam="true";
				    }else{
					    $VPriporocam="false";
				    }
			    }
			    $VPorocilo=$R["porocilo"];
		    }
		    if ($VPorocilo != $_POST["Porocilo"] ){
			    $VPorocilo=$_POST["Porocilo"];
		    }
		    switch ($VPorocilo){
			    case "":
                case "ODPADLO":
				    $VPorocilo=$VPorocilo;
                    break;
			    default:
				    $VPorocilo=$VPorocilo." (".$Danes->format('d.m.Y').")";
		    }
		    
		    $SQL="UPDATE tabizobrazevanje SET ";
		    $SQL = $SQL . "idUcitelj=".$Ucitelj.",";
		    $SQL = $SQL . "izobrazevanje='".$VIzobrazevanje."',";
		    $SQL = $SQL . "kraj='".$VKraj."',";
		    $SQL = $SQL . "datumOd='".$VDatumOd."',";
		    $SQL = $SQL . "datumDo='".$VDatumDo."',";
		    $SQL = $SQL . "izvajalec='".$VIzvajalec."',";
		    $SQL = $SQL . "naslov='".$VNaslov."',";
		    $SQL = $SQL . "trajanje='".$VTrajanje."',";
		    $SQL = $SQL . "tocke='".$VTocke."',";
		    $SQL = $SQL . "kotizacija=".$VKotizacija.",";
		    $SQL = $SQL . "OstStroski=".$VOstStroski.",";
		    $SQL = $SQL . "Priporocam=".$VPriporocam.",";
		    $SQL = $SQL . "porocilo='".$VPorocilo."',";
		    $SQL = $SQL . "vpisal='".$VUporabnik."'";
		    $SQL = $SQL ." WHERE id=".$_POST["idizobrazevanje"];
		    $result = mysqli_query($link,$SQL);

		    if ($Opravila==1 ){
			    $SQL = "SELECT tabdeldogodek.* FROM ";
			    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
			    $SQL = $SQL . "WHERE tabdogodek.Dogodek='".$VTipNaslov."' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
			    $result = mysqli_query($link,$SQL);

			    $Indx=1;
			    while ($R = mysqli_fetch_array($result)){
				    $VDogodki[$Indx]=$R["id"];
				    $Indx=$Indx+1;
			    }
			    $StDogodkov=$Indx-1;

			    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
				    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
				    $result = mysqli_query($link,$SQL);
			    }
		    }
		    break;
	    case "5":  //ogled poročila
		    $SQL = "SELECT * FROM tabizobrazevanje WHERE id=".$_GET["poglej"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $Ucitelj=$R["idUcitelj"];
			    $VIzobrazevanje=$R["Izobrazevanje"];
			    $VKraj=$R["Kraj"];
			    $VDatumOd=$R["DatumOd"];
			    $VDatumDo=$R["DatumDo"];
			    $VIzvajalec=$R["Izvajalec"];
			    $VNaslov=$R["Naslov"];
			    $VTrajanje=$R["Trajanje"];
			    $VTocke=$R["Tocke"];
			    $VKotizacija=$R["Kotizacija"];
			    $VOstStroski=$R["OstStroski"];
			    $VPriporocam=$R["priporocam"];
			    $VPorocilo=$R["porocilo"];
			    $VidIzobrazevanje=$R["id"];
		    }
		    echo "<img src='logo.gif' width='200'><br />";
		    echo "<h2>Poročilo o izobraževanju</h2>";
		    echo "Datum: ".$Danes->format('j.n.Y')."<br /><br />";
		    echo "<table border=0 cellspacing=0>";
		    echo "<tr>";
		    echo "<th>Leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";
		    echo "<tr><th>Ime</th><td>";

		    $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $VUcitelj=$R["Priimek"]." ".$R["Ime"];
			    echo $R["Priimek"]." ".$R["Ime"];
		    }
		    echo "</td></tr>";

		    echo "<tr><th>Izobraževanje</th><td>".$VIzobrazevanje."</td></tr>";
		    echo "<tr><th>Izvajalec</th><td>".$VIzvajalec."</td></tr>";
		    echo "<tr><th>Naslov izvajalca</th><td>".$VNaslov."</td></tr>";
		    echo "<tr><th>Kraj izvedbe</th><td>".$VKraj."</td></tr>";
		    echo "<tr><th>Datum in čas od</th><td>".$VDatumOd."</td></tr>";
		    echo "<tr><th>Datum in čas do</th><td>".$VDatumDo."</td></tr>";
		    echo "<tr><th>Trajanje</th><td>".$VTrajanje."</td></tr>";
		    echo "<tr><th>Točke</th><td>".$VTocke."</td></tr>";
		    echo "<tr><th>Kotizacija EUR</th><td>".$VKotizacija."</td></tr>";
		    echo "<tr><th>Ostali stroški EUR</th><td>".$VOstStroski."</td></tr>";
		    if ($VPriporocam ){
			    echo "<tr><th>Odobreno</th><td><input  type='checkbox' checked></td></tr>";
		    }else{
			    echo "<tr><th>Odobreno</th><td><input  type='checkbox'></td></tr>";
		    }
		    echo "</table><br />";
		    echo "<b>Poročilo</b><br />".str_replace("\r\n","<br />",$VPorocilo,$enco)."<br />";
		    echo "<br />Pripravil: ".$VUcitelj."<br />";
            break;
	    case "6": //odobritev izobraĹľevanja
		    if ($VLevel > 1 ){
			    $VZapisov=$_POST["zapisov"];
			    for ($Indx=1;$Indx <= $VZapisov;$Indx++){
				    if (isset($_POST["odobr_".$Indx])){
					    $SQL = "UPDATE tabizobrazevanje SET priporocam=true WHERE id=".$_POST["iz_".$Indx];
				    }else{
					    $SQL = "UPDATE tabizobrazevanje SET priporocam=false WHERE id=".$_POST["iz_".$Indx];
				    }
				    $result = mysqli_query($link,$SQL);
			    }
		    }
            break;
	    case "7": //poroÄŤila
		    echo "<h2>Poročila o izvedenih strokovnih izobraževanjih</h2>";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr><th>Leto</th><th>Ime</th><th>Izobraževanje</th><th>Izvajalec</th><th>Naslov izv.</th><th>Kraj</th><th>Datum od</th><th>Datum do</th><th>Trajanje</th><th>Točke</th><th>Kotizacija EUR</th><th>Ostali<br />stroški EUR</th><th>Poročilo</th></tr>";
		    $SQL = "SELECT tabizobrazevanje.*,tabucitelji.priimek,tabucitelji.ime FROM ";
		    $SQL = $SQL."tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.IdUcitelj=tabucitelji.IdUcitelj ";
		    $SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto." AND priporocam=true ";
		    $SQL = $SQL." ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

		    $Indx=1;
		    while ($R = mysqli_fetch_array($result)){
			    switch ($R["porocilo"]){
				    case "":
                    case "ODPADLO";
					    $Indx=$Indx;
                        break;
				    default:
					    echo "<tr>";
					    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
					    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
					    echo "<td>".$R["Izobrazevanje"]."</td>";
					    echo "<td>".$R["Izvajalec"]."</td>";
					    echo "<td>".$R["Naslov"]."</td>";
					    echo "<td>".$R["Kraj"]."</td>";
					    echo "<td>".$R["DatumOd"]."</td>";
					    echo "<td>".$R["DatumDo"]."</td>";
					    echo "<td>".$R["Trajanje"]."</td>";
					    echo "<td>".$R["Tocke"]."</td>";
					    echo "<td>".$R["Kotizacija"]."</td>";
					    echo "<td>".$R["OstStroski"]."</td>";
					    echo "<td>".$R["porocilo"]."</td>";
					    echo "</tr>";
			    }
			    $Indx = $Indx+1;
		    }
		    echo "</table>";
            break;
	    case "8": //spisek različnih izobraževanj
		    echo "<h2>Spisek izvedenih strokovnih izobraževanj</h2>";
            echo "<a href='VnosIzobrazevanje.php?id=8&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | <a href='VnosIzobrazevanje.php?id=8&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr><th>Leto</th><th>Izobraževanje</th><th>Izvajalec</th><th>Kraj</th><th>Datum od</th><th>Datum do</th><th>Število</th></tr>";
		    $SQL = "SELECT leto,izobrazevanje,izvajalec,kraj,datumod,datumdo,count(*) AS ci FROM tabizobrazevanje ";
		    $SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto." GROUP BY leto,izobrazevanje";
		    $result = mysqli_query($link,$SQL);

		    $Indx=1;
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
			    echo "<td>".$R["izobrazevanje"]."</td>";
			    echo "<td>".$R["izvajalec"]."</td>";
			    echo "<td>".$R["kraj"]."</td>";
			    echo "<td>".$R["datumod"]."</td>";
			    echo "<td>".$R["datumdo"]."</td>";
			    echo "<td>".$R["ci"]."</td>";
			    echo "</tr>";
			    $Indx = $Indx+1;
		    }
		    echo "</table>";
            break;
    }

    switch ( $Vid){ 
	    case "2":
        case "5":
        case "7":
	    case "8":
		    echo "<br />";
            break;
	    default:
		    echo "<a href='VnosIzobrazevanje.php?id=7'>Spisek poročil o izvedenih izobraževanjih</a><br />";
		    echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='VnosIzobrazevanje.php'>";
		    echo "<h2>Napoved strokovnega izobraževanja delavcev</h2>";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr>";
		    echo "<th>Leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";
		    echo "<tr><th>Ime</th><td><select name='ucitelj'>";
		    echo "<option value='0'>Ni izbran</option>";

		    $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if ($R["IdUcitelj"]==$CompUcitelj ){
				    echo "<option value='".$R["IdUcitelj"]."' selected>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }else{
				    echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }
		    }
		    echo "</select></td></tr>";

		    echo "<tr><th>Izobraževanje</th><td><input name='Izobrazevanje' type='text' size='30'></td></tr>";
		    echo "<tr><th>Izvajalec</th><td><input name='Izvajalec' type='text' size='20'></td></tr>";
		    echo "<tr><th>Naslov izvajalca</th><td><input name='Naslov' type='text' size='30'></td></tr>";
		    echo "<tr><th>Kraj izvedbe</th><td><input name='Kraj' type='text' size='20' ></td></tr>";
		    echo "<tr><th>Datum in čas od</th><td><input name='DatumOd' type='text' size='10'></td></tr>";
		    echo "<tr><th>Datum in čas do</th><td><input name='DatumDo' type='text' size='10'></td></tr>";
		    echo "<tr><th>Trajanje</th><td><input name='Trajanje' type='text' size='5'></td></tr>";
		    echo "<tr><th>Točke</th><td><input name='Tocke' type='text' size='3' ></td></tr>";
		    echo "<tr><th>Kotizacija EUR</th><td><input name='Kotizacija' type='text' size='6' ></td></tr>";
		    echo "<tr><th>Ostali<br />stroški EUR</th><td><input name='OstStroski' type='text' size='6'></td></tr>";
		    echo "<tr><th>Odobreno</th><td><input name='Priporocam' type='checkbox'></td></tr>";
		    echo "</table>";

		    echo "<input name='SolskoLeto' type='hidden' value='".$VLeto."'>";
		    echo "<input name='id' type='hidden' value='1'>";
		    echo "<input name='submit' type='submit' value='Pošlji'>";
		    echo "</form>";
		    echo "<br />";

		    echo "<h3><a href='VnosSkupIzobrazevanje.php'>Vnos skupinskega izobraževanja v organizaciji naše šole</a></h3>";
		    
		    echo "<font color='red'>Za odpadla izobraževanja v poročilo vpišite ODPADLO.</font><br />";
		    
		    echo "<h2>Spisek najavljenih izobraževanj</h2>";
		    echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='VnosIzobrazevanje.php'>";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr bgcolor='lightcyan'><th>Leto</th><th>Ime</th><th>Izobraževanje</th><th>Izvajalec</th><th>Naslov izv.</th><th>Kraj</th><th>Datum od</th><th>Datum do</th><th>Trajanje</th><th>Točke</th><th>Kotizacija EUR</th><th>Ostali<br />stroški EUR</th><th><img src='img/m_edit1.gif'></th><th><img src='img/m_delete.gif'></th><th><img src='img/m_poglej1.gif'></th><th>Odobreno</th></tr>";
		    $SQL = "SELECT tabizobrazevanje.*,tabucitelji.priimek,tabucitelji.ime FROM ";
		    $SQL = $SQL."tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.IdUcitelj=tabucitelji.IdUcitelj ";
		    $SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto;
		    $SQL = $SQL." ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

		    $Indx=1;
            $CompDate=new DateTime($VLeto."-10-31");
		    while ($R = mysqli_fetch_array($result)){
                $Datum=new DateTime($R["cas"]);
                $Interval=$Datum->diff($CompDate);
                
			    if ($Interval->invert == 0){
				    switch ( $R["porocilo"]){
					    case "":
						    echo "<tr bgcolor='lightyellow'>";
                            break;
					    case "ODPADLO":
						    echo "<tr bgcolor='lightsalmon'>";
                            break;
					    default:
						    echo "<tr bgcolor='lightgreen'>";
				    }
				    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
				    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
				    echo "<td>".$R["Izobrazevanje"]."</td>";
				    echo "<td>".$R["Izvajalec"]."</td>";
				    echo "<td>".$R["Naslov"]."</td>";
				    echo "<td>".$R["Kraj"]."</td>";
				    echo "<td>".$R["DatumOd"]."</td>";
				    echo "<td>".$R["DatumDo"]."</td>";
				    echo "<td>".$R["Trajanje"]."</td>";
				    echo "<td>".$R["Tocke"]."</td>";
				    echo "<td align='center'>".$R["Kotizacija"]."</td>";
				    echo "<td align='center'>".$R["OstStroski"]."</td>";
				    echo "<td><a href='VnosIzobrazevanje.php?id=2&popravi=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_edit1.gif' border='0' alt='Vnesi/Popravi'></a></td>";
				    echo "<td><a href='VnosIzobrazevanje.php?id=3&brisi=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
				    echo "<td><a href='VnosIzobrazevanje.php?id=5&poglej=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'></a></td>";
				    if ($R["priporocam"] ){
					    echo "<td align='center'><input name='iz_".$Indx."' type='hidden' value='".$R["id"]."'><input name='odobr_".$Indx."' type='checkbox' checked></td>";
				    }else{
					    echo "<td align='center'><input name='iz_".$Indx."' type='hidden' value='".$R["id"]."'><input name='odobr_".$Indx."' type='checkbox'></td>";
				    }
				    echo "</tr>";
				    $Indx = $Indx+1;
			    }
		    }
		    echo "</table>";

		    echo "<h2>Spisek naknadno prijavljenih izobraževanj (po 31.10.".$VLeto.")</h2>";
		    echo "<table border=1 cellspacing=0>";
		    echo "<tr bgcolor='lightcyan'><th>Leto</th><th>Ime</th><th>Izobraževanje</th><th>Izvajalec</th><th>Naslov izv.</th><th>Kraj</th><th>Datum od</th><th>Datum do</th><th>Trajanje</th><th>Točke</th><th>Kotizacija EUR</th><th>Ostali<br />stroški EUR</th><th><img src='img/m_edit1.gif'></th><th><img src='img/m_delete.gif'></th><th><img src='img/m_poglej1.gif'></th><th>Odobreno</th></tr>";
		    $SQL = "SELECT tabizobrazevanje.*,tabucitelji.priimek,tabucitelji.ime FROM ";
		    $SQL = $SQL."tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.IdUcitelj=tabucitelji.IdUcitelj ";
		    $SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto;
		    $SQL = $SQL." ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

		    while ($R = mysqli_fetch_array($result)){
                $Datum=new DateTime($R["cas"]);
                $Interval=$Datum->diff($CompDate);
                
                if ($Interval->invert > 0){
				    switch ( $R["porocilo"]){
					    case "":
						    echo "<tr bgcolor='lightyellow'>";
                            break;
					    case "ODPADLO":
						    echo "<tr bgcolor='lightsalmon'>";
                            break;
					    default:
						    echo "<tr bgcolor='lightgreen'>";
				    }
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                    echo "<td>".$R["Izobrazevanje"]."</td>";
                    echo "<td>".$R["Izvajalec"]."</td>";
                    echo "<td>".$R["Naslov"]."</td>";
                    echo "<td>".$R["Kraj"]."</td>";
                    echo "<td>".$R["DatumOd"]."</td>";
                    echo "<td>".$R["DatumDo"]."</td>";
                    echo "<td>".$R["Trajanje"]."</td>";
                    echo "<td>".$R["Tocke"]."</td>";
                    echo "<td align='center'>".$R["Kotizacija"]."</td>";
                    echo "<td align='center'>".$R["OstStroski"]."</td>";
                    echo "<td><a href='VnosIzobrazevanje.php?id=2&popravi=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_edit1.gif' border='0' alt='Vnesi/Popravi'></a></td>";
                    echo "<td><a href='VnosIzobrazevanje.php?id=3&brisi=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "<td><a href='VnosIzobrazevanje.php?id=5&poglej=".$R["id"]."&SolskoLeto=".$VLeto."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'></a></td>";
                    if ($R["priporocam"] ){
                        echo "<td align='center'><input name='iz_".$Indx."' type='hidden' value='".$R["id"]."'><input name='odobr_".$Indx."' type='checkbox' checked></td>";
                    }else{
                        echo "<td align='center'><input name='iz_".$Indx."' type='hidden' value='".$R["id"]."'><input name='odobr_".$Indx."' type='checkbox'></td>";
                    }
                    echo "</tr>";
                    $Indx = $Indx+1;
			    }
		    }
		    echo "</table>";

		    echo "<input name='SolskoLeto' type='hidden' value='".$VLeto."'>";
		    echo "<input name='zapisov' type='hidden' value='".($Indx-1)."'>";
		    echo "<input name='id' type='hidden' value='6'>";
		    if ($VLevel > 1 ){
			    echo "<input name='submit' type='submit' value='Odobri'>";
		    }
		    echo "</form>";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>

</body>
</html>
