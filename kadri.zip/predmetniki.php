<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Učenec
</title>
<style type='text/css'>
.break { page-break-before: always; }
input.groovybutton
{
   font-size:8px;
   font-weight:bold;
   width:18px;
}
</style>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }

    function ToTip($x){
        switch ($x){
            case 0:
                return "Končno spričevalo";
            case 1:
                return "Polletno obvestilo";
            case 2:
                return "Redovalnica 1. semester";
            case 3:
                return "Redovalnica 2. semester";
        }
    }
    function ToNivojski($x){
        switch ($x){
            case 1:
                return "MAT";
            case 2:
                return "MAT1";
            case 3:
                return "MAT2";
            case 4:
                return "MAT3";
            case 13:
                return "MAT4";
            case 14:
                return "MAT5";
            case 15:
                return "MAT6";
            case 5:
                return "SLO";
            case 6:
                return "SLO1";
            case 7:
                return "SLO2";
            case 8:
                return "SLO3";
            case 16:
                return "SLO4";
            case 17:
                return "SLO5";
            case 18:
                return "SLO6";
            case 9:
                return "TJA";
            case 10:
                return "TJA1";
            case 11:
                return "TJA2";
            case 12:
                return "TJA3";
            case 19:
                return "TJA4";
            case 20:
                return "TJA5";
            case 21:
                return "TJA6";
        }
    }

    function MonthName($x){
        switch ($x){
            case 1:
                return "januar";
            case 2:
                return "februar";
            case 3:
                return "marec";
            case 4:
                return "april";
            case 5:
                return "maj";
            case 6:
                return "junij";
            case 7:
                return "julij";
            case 8:
                return "avgust";
            case 9:
                return "september";
            case 10:
                return "oktober";
            case 11:
                return "november";
            case 12:
                return "december";
        }       
    }

    //Izpis osebnih podatkov

    $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
    $result1 = mysqli_query($link,$SQL);
    while ($R1 = mysqli_fetch_array($result1)){
        //Predmetnik
        $SQL = "SELECT tabucenje.*, tabucitelji.priimek, tabucitelji.ime, tabpredmeti.oznaka, tabpredmeti.opis FROM (tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet)  INNER JOIN tabucitelji ON tabucitelji.iducitelj = tabucenje.iducitelj WHERE tabucenje.idrazred=" . $R1["id"] ."  ORDER BY tabpredmeti.VrstniRed";
        $result = mysqli_query($link,$SQL);

        echo "<br /><b>Predmetnik ".$VLeto."/".($VLeto+1).", ".$R1["razred"].". ".$R1["oznaka"]."</b>: ";
        echo "<br /><table border=1>";
        echo "<th>Leto</th><th>Razred</th><th width='200'>Predmet</th><th>Ure</th><th width='120'>Posebnosti</th><th>Skupina</th><th width='150'>Učitelj</th>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $VZdruzeno = "";
            if ($R["Zdruzeno"] == 1 ){
                $VZdruzeno = "Združeni/skupine";
            }    
            if ($R["Zdruzeno"] == 2 ){
                $VZdruzeno = "Izbirni/skupine";
            }    
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td><td>".$R["Razred"].". ". $R["Paralelka"]."</td><td>".$R["oznaka"]." - ".$R["opis"]."</td><td>".$R["Planirano"]."</td><td>". $VZdruzeno ."</td><td>".$R["Realizirano"]."</td><td>".$R["priimek"]." " .$R["ime"]."</td></tr>";
            $Indx = $Indx+1;
        } 
        echo "</table>";
        echo "<p class='break'></p>";
    }
}
?>

</body>
</html>
