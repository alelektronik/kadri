<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Izhod
</title>
</head>
<body>

<?php
$_SESSION["Uporabnik"]="";
$_SESSION["Geslo"]="";
$_SESSION["Level"]=0;
session_destroy();
?>
<p>Hvala za obisk!</p>
<p>Za zanesljivo odjavo zaprite še brskalnik!</p>
</body>
</html>
