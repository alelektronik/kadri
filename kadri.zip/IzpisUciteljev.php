<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis učiteljev
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji ";
$SQL = $SQL . " WHERE tabucitelji.Status > 0 ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
$result = mysqli_query($link,$SQL);

$indx=1;

//'0-idUcitelj, 1-Priimek in ime, 2-delovno mesto (VzgDelo) 3-datum rojstva, 4-OpisDela, 5-SkupinaDela, 6-Delo, 7-DelDobaLet

echo "<br>Spisek zaposlenih:<br />";
echo "<table border=1 cellspacing=0>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th><th>Leto<br>roj.</th><th>Kraj</th><th>St.<br>izobr.</th><th>Izobrazba</th><th>Opis<br>dela</th><th>Skupina<br>dela</th><th>Delo</th><th>Del.<br>mesto</th><th>Del.<br>doba</th><th>Status</th>";
echo "<th>Datum<br>nastopa</th><th>Del.doba<br>v šol.</th><th>PAI</th><th>Str.Izp.</th><th>Mentor</th><th>Svetovalec</th><th>Svetnik</th></tr>";
$ColorChange=true;

while ($R = mysqli_fetch_array($result)){
	if ($ColorChange ){
		echo "<tr bgcolor=lightyellow>";
	}else{
		echo "<tr bgcolor=#FFFFCC>";
	}
	$ColorChange=!$ColorChange;
    $oUcitelj=new RUcitelj;
    $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
	echo "<td>".$indx."</td>";
	echo "<td><a href='PopraviUcitelja.php?idUcitelj=".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
    $Datum=$oUcitelj->getDatRoj();
	echo "<td>".$Datum->format('Y')."</td>";
	echo "<td>".$oUcitelj->getKraj()."</td>";
	
	echo "<td align=center>".$oUcitelj->getIzobrazba()."</td>";	//'opis stopnje izobrazbe
	echo "<td>".$oUcitelj->getIzobOpis()."</td>";
	echo "<td>".$oUcitelj->getOpisDela()."</td>";
	echo "<td>".$oUcitelj->getSkupinaDela()."</td>";
	echo "<td>".$oUcitelj->getVzgojnoDelo()."</td>";
	echo "<td>".$oUcitelj->getDelMesto()."</td>";
	
	echo "<td align=right>".$oUcitelj->getDelDobaLet()."</td>";
	
	switch ($oUcitelj->getStatus()){
		case 1:
        case 2:
			echo "<td>NDČ</td>";
            break;
		case 3:
        case 4:
        case 5:
        case 6:
        case 10:
			echo "<td>DČ</td>";
            break;
		default:
			echo "<td>&nbsp;</td>";
	}

	echo "<td align=right>".$oUcitelj->getDatumStart()->format('d.m.Y')."</td>";
	echo "<td align=center>".$oUcitelj->getDelDobaSol()."</td>";
	echo "<td>".$oUcitelj->getPedIzobr()."</td>";
	echo "<td>".$oUcitelj->getStrokIzpit()."</td>";
	echo "<td>".$oUcitelj->getMentor()."</td>";
	echo "<td>".$oUcitelj->getSvetovalec()."</td>";
	echo "<td>".$oUcitelj->getSvetnik()."</td>";
	echo "</tr>";
 	if ($indx % 15 == 0 ){
		echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th><th>Leto<br>roj.</th><th>Kraj</th><th>St.<br>izobr.</th><th>Izobrazba</th><th>Opis<br>dela</th><th>Skupina<br>dela</th><th>Delo</th><th>Del.<br>mesto</th><th>Del.<br>doba</th><th>Status</th>";
		echo "<th>Datum<br>nastopa</th><th>Del.doba<br>v šol.</th><th>PAI</th><th>Str.Izp.</th><th>Mentor</th><th>Svetovalec</th><th>Svetnik</th></tr>";
	}
	$indx=$indx+1;
}
echo "</table>";

?>

</body>
</html>
