<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("ucenci.php");
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}
function ToPredmetUspeh($ocena){
    switch ($ocena){
        case "5":
            return "odlično (5)";
            break;
        case "4":
            return "prav dobro (4)";
            break;
        case "3":
            return "dobro (3)";
            break;
        case "2":
            return "zadostno (2)";
            break;
        case "1":
        case "Ni opravil":
            return "nezadostno (1)";
            break;
        default:
            return "--------------";
    }
}
function ToNPredmet($txt){
    global $Ocene;
    
    for ($i=0;$i < count($Ocene);$i++){
        if (is_numeric(strpos($Ocene[$i]["oznaka"],$txt))){
            return $i;  //na i-tem mestu je ta ocena
        }
    }
    return -1;  //ne vsebuje te ocene
}

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    //echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["idd"])){
    $VNacin = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VNacin=$_GET["idd"];
    }else{
        $VNacin = 0;
    }
}

if (isset($_POST["nazivpredmeta"])){
    $_SESSION["nazivpredmeta"]=$_POST["nazivpredmeta"];
}

if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}

switch ($VNacin){
    case "100": //maticni listi PDF
        if ($_POST["maticnilist"] == "8"){
             header("Location: maticnilisti.php?idd=200&razred=".$VRazred."&solskoleto=".$VLeto);
        }else{
            if (isset($_SESSION["posx"])){
                $KorX = $_SESSION["posx"];
            }else{
                $KorX = 0;
            }
            if (isset($_SESSION["posy"])){
                $KorY = $_SESSION["posy"];
            }else{
                $KorY = 0;
            }
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }
            if (isset($_SESSION["KorOpombe"])){
                $KorOpombe = $_SESSION["KorOpombe"];
            }else{
                $KorOpombe="";
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix=$_SESSION["RefStFix"];
            }else{
                $RefStFix="";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar=$_SESSION["RefStVar"];
            }else{
                $RefStVar=0;
            }
            $_SESSION["leto"] = $VLeto;
            $_SESSION["posx"] = $KorX;
            $_SESSION["posy"] = $KorY;
            $_SESSION["DayToPrint"]=$PrintDay;
            $_SESSION["KorOpombe"]=$KorOpombe;
            $_SESSION["RefStFix"]=$RefStFix;
            $_SESSION["RefStVar"]=$RefStVar;

            if ($VecSol > 0){
                $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $idsola=$R["idsola"];
                }else{
                    $idsola=1;
                }
                
                $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VSola=$R["Sola"];
                    $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                    $VSolaKraj=$R["Kraj"];
                    $VRavnatelj=$R["Ravnatelj"];
                    $TipSole=$R["TipSole"];
                    $RavnateljID=$R["ravnatelj_ID"];
                    $VObcina=$R["Obcina"];
                }else{
                    $VSola=" ";
                    $VRavnatelj=" ";
                    $RavnateljID=0;
                    $VSolaNaslov="";
                    $VSolaKraj="";
                    $TipSole=0;
                    $VObcina="999";
                }
            }else{
                $SQL = "SELECT * FROM tabsola";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VSola=$R["Sola"];
                    $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                    $VSolaKraj=$R["Kraj"];
                    $VRavnatelj=$R["Ravnatelj"];
                    $TipSole=$R["TipSole"];
                    $RavnateljID=$R["ravnatelj_ID"];
                    $VObcina=$R["Obcina"];
                }else{
                    $VSola=" ";
                    $VRavnatelj=" ";
                    $RavnateljID=0;
                    $VSolaNaslov="";
                    $VSolaKraj="";
                    $TipSole=0;
                    $VObcina="999";
                }
            }

            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }

            //'0-idUcenec, 1-Priimek in ime, 2-datum rojstva, 3-KrajRoj, 4-DrzavaRoj, 5-emso, 6-MaticniList, 7-Naslov, 8-Posta Kraj, 9-oce, 10-mati, 11-Spol,12-državljanstvo,13-naslov oče, 14-naslov mati,15-skrbniki,16-naslov skrbniki,17-Zač. šolanja na šoli,18-konec šolanja na šoli
            if (isset($_POST["glava"])){
                $VGlava = false;
            }else{
                $VGlava = true;
            }
            $VMaticniList = $_POST["maticnilist"];

            $pdf = new FPDF();

            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            $pdf->AddPage("P","A4");
            $pdf->SetAutoPageBreak(0);

            $SQL = "SELECT * FROM tabsifreobcin WHERE sifra='".$VObcina."'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VObcina=$R["obcina"];
            }

            $SQL = "SELECT tabucenci.iducenec FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
            $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["iducenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx-1;

            $FontSize=8;
            $FontSize1=8;
            $FontSize2=12;

            for ($IndxRazred=0;$IndxRazred <= $StUcencev;$IndxRazred++){
                if ($IndxRazred > 0){
                    $pdf->AddPage("P","A4");
                }
                $oUcenec=new RUcenec();
                $oUcenec->getUcenec($ucenci[$IndxRazred]);
                $Razred=$oUcenec->getRazred($VLeto);

                $VRazred1 = $Razred["razred"];
                switch ($VMaticniList){
                    case "3":
                    case "4": //    '1.931 2005,2006
                        if ($VGlava){
                            //'izpiše podatke o šoli
                            $pdf->SetFont('arialbd_CE','',$FontSize1);
                            $txt=ToWin($VSola.", ".$VSolaNaslov);
                            $pdf->SetLeftMargin(12);
                            $pdf->SetRightMargin(130);
                            $pdf->SetXY(12+$KorX,99-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            $pdf->SetLeftMargin(10);
                            $pdf->SetRightMargin(10);
                            
                            //'občina
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($VObcina);
                            $pdf->SetXY(110+$KorX,103-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'Začetek na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getZacSolanjaSola());
                            $pdf->SetXY(163+$KorX,103-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'Konec na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getKonSolanjaSola());
                            $pdf->SetXY(183+$KorX,103-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //' ime in priimek
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                            $pdf->SetXY(61+$KorX,52.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'datum rojstva
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDatRoj());
                            $pdf->SetXY(15+$KorX,52.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'matični list
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getMaticniList());
                            $pdf->SetXY(159+$KorX,52.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'spol
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            if ($oUcenec->getSpol()=="M"){
                                $txt=ToWin("M");
                            }else{
                                $txt=ToWin("Ž");
                            }
                            $pdf->SetXY(15+$KorX,61.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'emšo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getemso());
                            $pdf->SetXY(25+$KorX,61.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'kraj roj.
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                            $pdf->SetXY(60+$KorX,61.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'državljanstvo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDrzavljanstvo());
                            $pdf->SetXY(159+$KorX,61.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'naslov
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj());
                            $pdf->SetXY(25+$KorX,70-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'oče
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getoce()."\n".$oUcenec->getocenaslov());
                            $pdf->SetXY(15+$KorX,79-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'mati
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getmati()."\n".$oUcenec->getmatinaslov());
                            $pdf->SetXY(83+$KorX,79-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'skrbniki
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getSkrbniki()."\n".$oUcenec->getSkrbnikiNaslov());
                            $pdf->SetXY(148+$KorX,79-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }
                        //glava - konec

                        //podatki o šolskem letu
                        switch ($VRazred1){
                            case 1:
                            case 2:
                            case 3:
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["paralelka"]);
                                $pdf->SetXY(65+$KorX+($VRazred1-1)*25,148-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,135.5-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["letosolanja"]);
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,141-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("Napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,254-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                        break;
                                    case 2:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("ne napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,254-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,248-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["razrednik"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,277-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($VRavnatelj);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,284-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'delovodnik
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["evidst"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,272-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'datum spričevala
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["datumizdaje"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,266-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt="--------------";
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,164-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");
                                break;
                            case 4:
                            case 5:
                            case 6:
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["paralelka"]);
                                $pdf->SetXY(65+$KorX+($VRazred1-1)*25,148-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,134.5-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["letosolanja"]);
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,141-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("Napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,254-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                        break;
                                    case 2:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("ne napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,254-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,248-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["razrednik"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,277-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($VRavnatelj);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,284-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'delovodnik
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["evidst"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,272-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'datum spričevala
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["datumizdaje"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,266-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $Ocene=$oUcenec->getOcene($VLeto);
                                $Predmeti=$oUcenec->getPredmeti($VLeto);
                                $Izbirni=$oUcenec->getIzbirni($VLeto);
                                
                                //Izpis redovalnice
                                //'slovenscina
                                $NPredmet=ToNPredmet("SLJ");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,158-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $txt="--------------";
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,164-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");
                                
                                //'matematika
                                $NPredmet=ToNPredmet("MAT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,170-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Anglescina
                                $NPredmet=ToNPredmet("TJA");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,176-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Anglescina - napis
                                if ($VRazred1==4){
                                    $txt=ToWin("Angleščina");
                                    $pdf->SetXY(25+$KorX+($VRazred1-1)*25,176-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                }
                                
                                //'Likovna vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("LUM");
                                }else{
                                    $NPredmet=ToNPredmet("LVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,183-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Glasbena vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("GUM");
                                }else{
                                    $NPredmet=ToNPredmet("GVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,189-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Druzba
                                $NPredmet=ToNPredmet("DRU");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,194.5-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Geografija
                                $NPredmet=ToNPredmet("GEO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,200-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Zgodovina
                                $NPredmet=ToNPredmet("ZGO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,206-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Spoznavanje okolja
                                $NPredmet=ToNPredmet("SPO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,212-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Naravoslovje
                                $NPredmet=ToNPredmet("NAR");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,218-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Naravoslovje in tehnika
                                $NPredmet=ToNPredmet("NIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,224-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Tehnika in tehnologija
                                $NPredmet=ToNPredmet("TIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,230-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Gospodinjstvo
                                $NPredmet=ToNPredmet("GOS");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,236-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Sportna vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("ŠPO");
                                }else{
                                    $NPredmet=ToNPredmet("ŠVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,241-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'splosni uspeh
                                if ($VLeto < 2008){
                                    switch ($Razred["uspeh"]){
                                        case 5:
                                            $txt=ToWin("odličen (5)");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 4:
                                            $txt=ToWin("prav dober (4)");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 3:
                                            $txt=ToWin("dober (4)");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $txt=ToWin("zadosten (2)");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 1:
                                            $txt=ToWin("nezadosten (1)");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                    }
                                }else{
                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*25,260-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                break;    
                            case 7:
                            case 8:
                            case 9:
                                if (!$VGlava){
                                    //' ime in priimek na vrhu lista
                                    $pdf->SetFont('arial_CE','',6);
                                    $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                    $pdf->SetXY(1,3);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    //paralelka
                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["paralelka"]);
                                    $pdf->SetXY(65+$KorX+($VRazred1-7)*25,37-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                    $pdf->SetXY(58+$KorX+($VRazred1-7)*25,25-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["letosolanja"]);
                                    $pdf->SetXY(60+$KorX+($VRazred1-7)*25,31-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    
                                    switch ($Razred["napredovanje"]){
                                        case 0:
                                        case 1:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            if ($VRazred1==9){
                                                $txt=ToWin("Zaključuje");
                                            }else{
                                                $txt=ToWin("Napreduje");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,204-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("ne napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,204-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,198-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["razrednik"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,228-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,233-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'delovodnik
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["evidst"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,222-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'datum spričevala
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["datumizdaje"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,216-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $Ocene=$oUcenec->getOcene($VLeto);
                                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                                    
                                    //Izpis redovalnice
                                    //'slovenscina
                                    $NPredmet=ToNPredmet("SLJ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,48-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $txt="--------------";
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,54-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    
                                    //'matematika
                                    $NPredmet=ToNPredmet("MAT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,60-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,66-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina - napis
                                    if ($VRazred1==7){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-7)*25,66-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    
                                    //'Likovna vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("LUM");
                                    }else{
                                        $NPredmet=ToNPredmet("LVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,72-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Glasbena vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("GUM");
                                    }else{
                                        $NPredmet=ToNPredmet("GVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,78-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Geografija
                                    $NPredmet=ToNPredmet("GEO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,84-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Zgodovina
                                    $NPredmet=ToNPredmet("ZGO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,90-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Etika
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("DKE");
                                    }else{
                                        $NPredmet=ToNPredmet("DDE");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,96-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Fizika
                                    $NPredmet=ToNPredmet("FIZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,102-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Kemija
                                    $NPredmet=ToNPredmet("KEM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,107.5-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Biologija
                                    $NPredmet=ToNPredmet("BIO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,114-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Naravoslovje
                                    $NPredmet=ToNPredmet("NAR");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,120-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Tehnika in tehnologija
                                    $NPredmet=ToNPredmet("TIT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,126-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Sportna vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("ŠPO");
                                    }else{
                                        $NPredmet=ToNPredmet("ŠVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,132-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    // 1. izbirni predmeti
                                    if (isset($Izbirni[0]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,144-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,138-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,144-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,138-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,144-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,138-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    // 2. izbirni predmeti
                                    if (isset($Izbirni[1]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,156-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,150-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,156-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,150-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,156-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,150-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    // 3. izbirni predmeti
                                    if (isset($Izbirni[2]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,168-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,162-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,168-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,162-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,168-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,162-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    //'splosni uspeh
                                    if ($VLeto < 2008){
                                        switch ($Razred["uspeh"]){
                                            case 5:
                                                $txt=ToWin("odličen (5)");
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                break;
                                            case 4:
                                                $txt=ToWin("prav dober (4)");
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                break;
                                            case 3:
                                                $txt=ToWin("dober (4)");
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                break;
                                            case 2:
                                                $txt=ToWin("zadosten (2)");
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                break;
                                            case 1:
                                                $txt=ToWin("nezadosten (1)");
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                break;
                                        }
                                    }else{
                                        $txt=ToWin("--------------");
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    //štiri prazne vrstice pod izbirnimi predmeti
                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,174-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,180-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,186-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,192-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'vpis podatkov o NPZ
                                    if ($VRazred1==9){
                                        $Npz=$oUcenec->getNPZ($VLeto);
                                        // SLJ
                                        if (isset($Npz[0]["oznaka"])){        
                                            if ($Npz[0]["tock"] > 0){
                                                $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,48-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(90+$KorX,48-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"L");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,48-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"L");
                                        }    
                                        
                                        //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                        $txt="--------------";
                                        $pdf->SetXY(125+$KorX,54-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,"C");
                                        
                                        // MAT
                                        if (isset($Npz[1]["oznaka"])){        
                                            if ($Npz[1]["tock"] > 0){
                                                $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,60-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,60-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,60-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //angleščina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,66-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,66-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,66-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //likovna
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="LVZ")or ($Npz[2]["oznaka"]=="LUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,72-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,72-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,72-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Glasbena vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="GVZ")or ($Npz[2]["oznaka"]=="GUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,78-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,78-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,78-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    

                                        //'Geografija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="GEO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,84-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,84-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,84-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Zgodovina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="ZGO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,90-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,90-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,90-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Drzavljanska vzgoja in etika
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="DDE")or ($Npz[2]["oznaka"]=="DKE"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,96-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,96-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,96-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Fizika
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="FIZ")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,102-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,102-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,102-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Kemija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="KEM")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,108-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,108-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,108-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Biologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="BIO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,114-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,114-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,114-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Naravoslovje
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="NAR")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,120-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,120-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,120-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Tehnika in tehnologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TIT")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,126-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,126-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,126-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Sportna vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="ŠVZ")or ($Npz[2]["oznaka"]=="ŠPO"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,132-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,132-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,132-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        } 
                                    }   
                                }
                        }
                        break;
                    case "6": // '1.931 2008
                        if ($VGlava){
                            //'izpiše podatke o šoli
                            $pdf->SetFont('arialbd_CE','',$FontSize1);
                            $txt=ToWin($VSola.", ".$VSolaNaslov);
                            $pdf->SetLeftMargin(12);
                            $pdf->SetRightMargin(130);
                            $pdf->SetXY(12+$KorX,102-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            $pdf->SetLeftMargin(10);
                            $pdf->SetRightMargin(10);
                            
                            //'občina
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($VObcina);
                            $pdf->SetXY(110+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'Začetek na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getZacSolanjaSola());
                            $pdf->SetXY(163+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'Konec na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getKonSolanjaSola());
                            $pdf->SetXY(183+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //' ime in priimek
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                            $pdf->SetXY(61+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'datum rojstva
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDatRoj());
                            $pdf->SetXY(15+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'matični list
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getMaticniList());
                            $pdf->SetXY(159+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'spol
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            if ($oUcenec->getSpol()=="M"){
                                $txt=ToWin("M");
                            }else{
                                $txt=ToWin("Ž");
                            }
                            $pdf->SetXY(15+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'emšo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getemso());
                            $pdf->SetXY(25+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'kraj roj.
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                            $pdf->SetXY(60+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'državljanstvo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDrzavljanstvo());
                            $pdf->SetXY(159+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'naslov
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj());
                            $pdf->SetXY(25+$KorX,73-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'oče
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getoce()."\n".$oUcenec->getocenaslov());
                            $pdf->SetXY(15+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'mati
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getmati()."\n".$oUcenec->getmatinaslov());
                            $pdf->SetXY(83+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'skrbniki
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getSkrbniki()."\n".$oUcenec->getSkrbnikiNaslov());
                            $pdf->SetXY(148+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }
                        //glava - konec

                        //podatki o šolskem letu
                        switch ($VRazred1){
                            case 1:
                            case 2:
                            case 3:
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["paralelka"]);
                                $pdf->SetXY(65+$KorX+($VRazred1-1)*25,151-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,138.5-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["letosolanja"]);
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,144-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("Napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,257-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                        break;
                                    case 2:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("ne napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,257-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,251-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["razrednik"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,274-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($VRavnatelj);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,281-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'delovodnik
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["evidst"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,269-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'datum spričevala
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["datumizdaje"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,263-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt="--------------";
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,167-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");
                                break;
                            case 4:
                            case 5:
                            case 6:
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["paralelka"]);
                                $pdf->SetXY(65+$KorX+($VRazred1-1)*25,151-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,137.5-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                $pdf->SetFont('arial_CE','',$FontSize1);
                                $txt=ToWin($Razred["letosolanja"]);
                                $pdf->SetXY(60+$KorX+($VRazred1-1)*25,144-$KorY);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("Napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,257-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                        break;
                                    case 2:
                                        $pdf->SetFont('arial_CE','',$FontSize1);
                                        $txt=ToWin("ne napreduje");
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*25,257-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,251-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["razrednik"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,276-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($VRavnatelj);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,281-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'delovodnik
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["evidst"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,269-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'datum spričevala
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $txt=ToWin($Razred["datumizdaje"]);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,263-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $Ocene=$oUcenec->getOcene($VLeto);
                                $Predmeti=$oUcenec->getPredmeti($VLeto);
                                $Izbirni=$oUcenec->getIzbirni($VLeto);
                                
                                //Izpis redovalnice
                                //'slovenscina
                                $NPredmet=ToNPredmet("SLJ");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetFont('arial_CE','',$FontSize);
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,161-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $txt="--------------";
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,167-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");
                                
                                //'matematika
                                $NPredmet=ToNPredmet("MAT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,173-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Anglescina
                                $NPredmet=ToNPredmet("TJA");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,179-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Anglescina - napis
                                if ($VRazred1==4){
                                    $txt=ToWin("Angleščina");
                                    $pdf->SetXY(25+$KorX+($VRazred1-1)*25,179-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                }
                                
                                //'Likovna vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("LUM");
                                }else{
                                    $NPredmet=ToNPredmet("LVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,186-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Glasbena vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("GUM");
                                }else{
                                    $NPredmet=ToNPredmet("GVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,192-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Druzba
                                $NPredmet=ToNPredmet("DRU");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,197.5-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Geografija
                                $NPredmet=ToNPredmet("GEO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,203-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Zgodovina
                                $NPredmet=ToNPredmet("ZGO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,209-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Spoznavanje okolja
                                $NPredmet=ToNPredmet("SPO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,215-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Naravoslovje
                                $NPredmet=ToNPredmet("NAR");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,221-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Naravoslovje in tehnika
                                $NPredmet=ToNPredmet("NIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,227-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Tehnika in tehnologija
                                $NPredmet=ToNPredmet("TIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,233-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Gospodinjstvo
                                $NPredmet=ToNPredmet("GOS");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,239-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'Sportna vzgoja
                                if ($VLeto > 2012){
                                    $NPredmet=ToNPredmet("ŠPO");
                                }else{
                                    $NPredmet=ToNPredmet("ŠVZ");
                                }
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $pdf->SetXY(48+$KorX+($VRazred1-1)*25,245-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                break;    
                            case 7:
                            case 8:
                            case 9:
                                if (!$VGlava){
                                    //' ime in priimek na vrhu lista
                                    $pdf->SetFont('arial_CE','',6);
                                    $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                    $pdf->SetXY(1,3);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    //paralelka
                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["paralelka"]);
                                    $pdf->SetXY(65+$KorX+($VRazred1-7)*25,36-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                    $pdf->SetXY(58+$KorX+($VRazred1-7)*25,24-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["letosolanja"]);
                                    $pdf->SetXY(60+$KorX+($VRazred1-7)*25,30-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    
                                    switch ($Razred["napredovanje"]){
                                        case 0:
                                        case 1:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            if ($VRazred1==9){
                                                $txt=ToWin("Zaključuje");
                                            }else{
                                                $txt=ToWin("Napreduje");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("ne napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,203-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["razrednik"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,227-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,232-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'delovodnik
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["evidst"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,221-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'datum spričevala
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["datumizdaje"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,215-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $Ocene=$oUcenec->getOcene($VLeto);
                                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                                    
                                    //Izpis redovalnice
                                    //'slovenscina
                                    $NPredmet=ToNPredmet("SLJ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,47-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $txt="--------------";
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,53-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    
                                    //'matematika
                                    $NPredmet=ToNPredmet("MAT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,59-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,65-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina - napis
                                    if ($VRazred1==7){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-7)*25,65-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    /*
                                    //'drugi tuji jezik
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,65-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'drugi tuji jezik - napis
                                    if ($VRazred1==7){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-7)*25,65-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    */
                                    
                                    //'Likovna vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("LUM");
                                    }else{
                                        $NPredmet=ToNPredmet("LVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,77-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Glasbena vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("GUM");
                                    }else{
                                        $NPredmet=ToNPredmet("GVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,83-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Geografija
                                    $NPredmet=ToNPredmet("GEO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,89-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Zgodovina
                                    $NPredmet=ToNPredmet("ZGO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,95-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Etika
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("DKE");
                                    }else{
                                        $NPredmet=ToNPredmet("DDE");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,101-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Fizika
                                    $NPredmet=ToNPredmet("FIZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,107-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Kemija
                                    $NPredmet=ToNPredmet("KEM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,112.5-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Biologija
                                    $NPredmet=ToNPredmet("BIO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,119-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Naravoslovje
                                    $NPredmet=ToNPredmet("NAR");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,125-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Tehnika in tehnologija
                                    $NPredmet=ToNPredmet("TIT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,131-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Sportna vzgoja
                                    if ($VLeto > 2012){
                                        $NPredmet=ToNPredmet("ŠPO");
                                    }else{
                                        $NPredmet=ToNPredmet("ŠVZ");
                                    }
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,137-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    // 1. izbirni predmeti
                                    if (isset($Izbirni[0]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,143-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    // 2. izbirni predmeti
                                    if (isset($Izbirni[1]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,155-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    // 3. izbirni predmeti
                                    if (isset($Izbirni[2]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,167-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    //štiri prazne vrstice pod izbirnimi predmeti
                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,179-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,185-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,191-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,197-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'vpis podatkov o NPZ
                                    if ($VRazred1==9){
                                        $Npz=$oUcenec->getNPZ($VLeto);
                                        // SLJ
                                        if (isset($Npz[0]["oznaka"])){        
                                            if ($Npz[0]["tock"] > 0){
                                                $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,47-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(90+$KorX,47-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"L");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,47-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"L");
                                        }    
                                        
                                        //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                        $txt="--------------";
                                        $pdf->SetXY(125+$KorX,53-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,"C");
                                        
                                        // MAT
                                        if (isset($Npz[1]["oznaka"])){        
                                            if ($Npz[1]["tock"] > 0){
                                                $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,59-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,59-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,59-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //angleščina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,65-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,65-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,65-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //prazna vrstica za drugi tuji jezik
                                        $txt="--------------";
                                        $pdf->SetXY(125+$KorX,71-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,"C");
                                        
                                        //likovna
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="LVZ")or ($Npz[2]["oznaka"]=="LUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,77-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,77-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,77-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Glasbena vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="GVZ")or ($Npz[2]["oznaka"]=="GUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,83-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,83-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,83-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    

                                        //'Geografija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="GEO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,89-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,89-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,89-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Zgodovina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="ZGO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,95-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,95-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,95-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Drzavljanska vzgoja in etika
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="DDE")or ($Npz[2]["oznaka"]=="DKE"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,101-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,101-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,101-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Fizika
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="FIZ")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,107-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,107-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,107-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Kemija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="KEM")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,113-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,113-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,113-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Biologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="BIO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,119-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,119-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,119-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Naravoslovje
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="NAR")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,125-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,125-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,125-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Tehnika in tehnologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TIT")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,131-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,131-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,131-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Sportna vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="ŠVZ")or ($Npz[2]["oznaka"]=="ŠPO"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,137-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,137-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,137-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        } 
                                    }   
                                }
                        }
                        break;
                    case "7": // '1.931 2013
                        if ($VGlava){
                            //'izpiše podatke o šoli
                            $pdf->SetFont('arialbd_CE','',$FontSize1);
                            $txt=ToWin($VSola.", ".$VSolaNaslov);
                            $pdf->SetLeftMargin(12);
                            $pdf->SetRightMargin(130);
                            $pdf->SetXY(12+$KorX,102-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            $pdf->SetLeftMargin(10);
                            $pdf->SetRightMargin(10);
                            
                            //'občina
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($VObcina);
                            $pdf->SetXY(110+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'Začetek na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getZacSolanjaSola());
                            $pdf->SetXY(163+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'Konec na šoli
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getKonSolanjaSola());
                            $pdf->SetXY(183+$KorX,106-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //' ime in priimek
                            $pdf->SetFont('arialbd_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                            $pdf->SetXY(59+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'datum rojstva
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDatRoj());
                            $pdf->SetXY(12+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'matični list
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getMaticniList());
                            $pdf->SetXY(158+$KorX,55.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'spol
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            if ($oUcenec->getSpol()=="M"){
                                $txt=ToWin("M");
                            }else{
                                $txt=ToWin("Ž");
                            }
                            $pdf->SetXY(12+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            //'emšo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getemso());
                            $pdf->SetXY(22+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'kraj roj.
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                            $pdf->SetXY(59+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'državljanstvo
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getDrzavljanstvo());
                            $pdf->SetXY(158+$KorX,64.5-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'naslov
                            $pdf->SetFont('arial_CE','',$FontSize2);
                            $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj());
                            $pdf->SetXY(12+$KorX,73-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            //'oče
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getoce()."\n".$oUcenec->getocenaslov());
                            $pdf->SetXY(12+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'mati
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getmati()."\n".$oUcenec->getmatinaslov());
                            $pdf->SetXY(79+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");

                            //'skrbniki
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $txt=ToWin($oUcenec->getSkrbniki()."\n".$oUcenec->getSkrbnikiNaslov());
                            $pdf->SetXY(142+$KorX,82-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }
                        //glava - konec

                        //podatki o šolskem letu
                        switch ($VRazred1){
                            case 1:
                            case 2:
                            //case 3:
                                if (!$VGlava){
                                    //' ime in priimek na vrhu lista
                                    $pdf->SetFont('arial_CE','',6);
                                    $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                    $pdf->SetXY(1,3);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    //paralelka
                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["paralelka"]);
                                    $pdf->SetXY(65+$KorX+($VRazred1-1)*21,151-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                    $pdf->SetXY(60+$KorX+($VRazred1-1)*21,138.5-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["letosolanja"]);
                                    $pdf->SetXY(60+$KorX+($VRazred1-1)*21,144-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    
                                    switch ($Razred["napredovanje"]){
                                        case 0:
                                        case 1:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("Napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*21,262-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("ne napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*21,262-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,257-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["razrednik"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,278-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,282-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'delovodnik
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["evidst"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,273-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'datum spričevala
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["datumizdaje"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,267-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt="--------------";
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,167-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                }
                                break;
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                if (!$VGlava){
                                    //' ime in priimek na vrhu lista
                                    $pdf->SetFont('arial_CE','',6);
                                    $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                    $pdf->SetXY(1,3);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    //paralelka
                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["paralelka"]);
                                    $pdf->SetXY(65+$KorX+($VRazred1-1)*21,151-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                    $pdf->SetXY(60+$KorX+($VRazred1-1)*21,137.5-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["letosolanja"]);
                                    $pdf->SetXY(60+$KorX+($VRazred1-1)*21,144-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    
                                    switch ($Razred["napredovanje"]){
                                        case 0:
                                        case 1:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("Napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*21,262-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("ne napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-1)*21,262-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,257-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["razrednik"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,278-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,282-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'delovodnik
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["evidst"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,273-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'datum spričevala
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["datumizdaje"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,267-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $Ocene=$oUcenec->getOcene($VLeto);
                                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                                    
                                    //Izpis redovalnice
                                    //'slovenscina
                                    $NPredmet=ToNPredmet("SLJ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,161-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $txt="--------------";
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,167-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    
                                    //'matematika
                                    $NPredmet=ToNPredmet("MAT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,173-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    /*
                                    if ($VRazred1 > 3){
                                        //'neobvezni izbirni predmet - tuji jezik (AN2, NE2, IT2, FR2, MA2, HR2)
                                        $NPredmet=ToNPredmet("NE2");
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                        }else{
                                            $txt="--------------";
                                        }
                                        $pdf->SetXY(48+$KorX+($VRazred1-1)*21,184-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    */
                                    //'Anglescina
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,184-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina - napis
                                    if ($VRazred1==4){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-1)*25,184-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    
                                    //'Likovna umetnost
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("LUM");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("LVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,189-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Glasbena umetnost
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("GUM");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("GVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,194-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Druzba
                                    $NPredmet=ToNPredmet("DRU");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,199-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Geografija
                                    $NPredmet=ToNPredmet("GEO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,205-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Zgodovina
                                    $NPredmet=ToNPredmet("ZGO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,201-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Spoznavanje okolja
                                    $NPredmet=ToNPredmet("SPO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,214-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Naravoslovje
                                    $NPredmet=ToNPredmet("NAR");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,221-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Naravoslovje in tehnika
                                    $NPredmet=ToNPredmet("NIT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,226-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Tehnika in tehnologija
                                    $NPredmet=ToNPredmet("TIT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,231-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Gospodinjstvo
                                    $NPredmet=ToNPredmet("GOS");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*21,236.5-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Šport
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("ŠPO");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("ŠVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-1)*25,241.5-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    /*
                                        // 1. izbirni predmeti
                                        if (isset($Izbirni[0]["oznaka"])){
                                            $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                            if ($NPredmet >= 0){
                                                switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                    case 0:
                                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                        break;
                                                    case 1:
                                                        $txt=ToWin("neocenjeno");
                                                        break;
                                                    case 2:
                                                        $txt=ToWin("oproščeno");
                                                }
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                $pdf->SetXY(55+$KorX+($VRazred1-7)*25,143-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,"C");
                                           }else{
                                                $txt="--------------";
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                            }
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                        
                                        // 2. izbirni predmeti
                                        if (isset($Izbirni[1]["oznaka"])){
                                            $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                            if ($NPredmet >= 0){
                                                switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                    case 0:
                                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                        break;
                                                    case 1:
                                                        $txt=ToWin("neocenjeno");
                                                        break;
                                                    case 2:
                                                        $txt=ToWin("oproščeno");
                                                }
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                $pdf->SetXY(55+$KorX+($VRazred1-7)*25,155-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,"C");
                                           }else{
                                                $txt="--------------";
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                            }
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                        // 3. izbirni predmeti
                                        if (isset($Izbirni[2]["oznaka"])){
                                            $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                                            if ($NPredmet >= 0){
                                                switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                    case 0:
                                                        $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                        break;
                                                    case 1:
                                                        $txt=ToWin("neocenjeno");
                                                        break;
                                                    case 2:
                                                        $txt=ToWin("oproščeno");
                                                }
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                $pdf->SetXY(55+$KorX+($VRazred1-7)*25,167-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,"C");
                                           }else{
                                                $txt="--------------";
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                                 //'napis predmeta
                                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                                $pdf->Cell(30,0,$txt,0,2,"C");
                                            }
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                        */
                                        
                                        /* rezultati NPZ - 2. triada (6. razred) */
                                        //'vpis podatkov o NPZ
                                        if ($VRazred1==6){
                                            $Npz=$oUcenec->getNPZ($VLeto);
                                            // SLJ
                                            if (isset($Npz[0]["oznaka"])){        
                                                if ($Npz[0]["tock"] > 0){
                                                    $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                                    $pdf->SetXY(180+$KorX,163-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }else{
                                                    $txt="--------------";
                                                    $pdf->SetXY(180+$KorX,163-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }    
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(180+$KorX,163-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,"C");
                                            }    
                                            
                                            //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,168-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            // MAT
                                            if (isset($Npz[1]["oznaka"])){        
                                                if ($Npz[1]["tock"] > 0){
                                                    $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                                    $pdf->SetXY(180+$KorX,173-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }else{
                                                    $txt="--------------";
                                                    $pdf->SetXY(180+$KorX,173-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }    
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(180+$KorX,173-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,"C");
                                            }    
                                            
                                            //angleščina
                                            if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                                if ($Npz[2]["tock"] > 0){
                                                    $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                    $pdf->SetXY(180+$KorX,184-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }else{
                                                    $txt="--------------";
                                                    $pdf->SetXY(180+$KorX,184-$KorY);
                                                    $pdf->Cell(21,0,$txt,0,2,"C");
                                                }    
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(180+$KorX,184-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,"C");
                                            }    
                                            
                                            //prazna vrstica za drugi tuji jezik
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,178-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za LUM
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,189-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za GUM
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,194-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za Družba
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,199-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za Geografija
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,205-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za Zgodovina
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,210-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za SPO
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,215-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za NAR
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,220-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za NIT
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,225-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za TIT
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,231-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za GOS
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,236-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za ŠPO
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,241-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za izbirni 1
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,246-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                            
                                            //prazna vrstica za izbirni 2
                                            $txt="--------------";
                                            $pdf->SetXY(180+$KorX,252-$KorY);
                                            $pdf->Cell(21,0,$txt,0,2,"C");
                                        }
                                }
                                break;    
                            case 7:
                            case 8:
                            case 9:
                                if (!$VGlava){
                                    //' ime in priimek na vrhu lista
                                    $pdf->SetFont('arial_CE','',6);
                                    $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                    $pdf->SetXY(1,3);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    //paralelka
                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["paralelka"]);
                                    $pdf->SetXY(65+$KorX+($VRazred1-7)*25,36-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin(substr($Razred["leto"],2,2)."/".substr($Razred["leto"]+1,2,2));
                                    $pdf->SetXY(58+$KorX+($VRazred1-7)*25,24-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',$FontSize1);
                                    $txt=ToWin($Razred["letosolanja"]);
                                    $pdf->SetXY(60+$KorX+($VRazred1-7)*25,30-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    
                                    switch ($Razred["napredovanje"]){
                                        case 0:
                                        case 1:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            if ($VRazred1==9){
                                                $txt=ToWin("Zaključuje");
                                            }else{
                                                $txt=ToWin("Napreduje");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                            break;
                                        case 2:
                                            $pdf->SetFont('arial_CE','',$FontSize1);
                                            $txt=ToWin("ne napreduje");
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,209-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,203-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["razrednik"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,227-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,232-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'delovodnik
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["evidst"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,221-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'datum spričevala
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $txt=ToWin($Razred["datumizdaje"]);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,215-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $Ocene=$oUcenec->getOcene($VLeto);
                                    $Predmeti=$oUcenec->getPredmeti($VLeto);
                                    $Izbirni=$oUcenec->getIzbirni($VLeto);
                                    
                                    //Izpis redovalnice
                                    //'slovenscina
                                    $NPredmet=ToNPredmet("SLJ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetFont('arial_CE','',$FontSize);
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,47-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $txt="--------------";
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,53-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    
                                    //'matematika
                                    $NPredmet=ToNPredmet("MAT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,59-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,65-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Anglescina - napis
                                    if ($VRazred1==7){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-7)*25,65-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    /*
                                    //'drugi tuji jezik
                                    $NPredmet=ToNPredmet("TJA");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                    */
                                    $txt="--------------";
                                    //}
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,72-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");
                                    /*
                                    //'drugi tuji jezik - napis
                                    if ($VRazred1==7){
                                        $txt=ToWin("Angleščina");
                                        $pdf->SetXY(25+$KorX+($VRazred1-7)*25,65-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,"L");
                                    }
                                    */
                                    
                                    //'Likovna umetnost
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("LUM");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("LVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,77-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Glasbena umetnost
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("GUM");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("GVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,83-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Geografija
                                    $NPredmet=ToNPredmet("GEO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,89-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Zgodovina
                                    $NPredmet=ToNPredmet("ZGO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,95-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Etika
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("DKE");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("DDE");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,101-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Fizika
                                    $NPredmet=ToNPredmet("FIZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,107-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Kemija
                                    $NPredmet=ToNPredmet("KEM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,112.5-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Biologija
                                    $NPredmet=ToNPredmet("BIO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,119-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Naravoslovje
                                    $NPredmet=ToNPredmet("NAR");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,125-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Tehnika in tehnologija
                                    $NPredmet=ToNPredmet("TIT");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,131-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'Šport
								    if ($VLeto >= 2013){
									    $NPredmet=ToNPredmet("ŠPO");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }else{
									    $NPredmet=ToNPredmet("ŠVZ");
									    if ($NPredmet >= 0){
										    switch ($Ocene[$NPredmet]["neocenjen"]){ 
											    case 0:
												    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
												    break;
											    case 1:
												    $txt=ToWin("neocenjeno");
                                                    break;
											    case 2:
												    $txt=ToWin("oproščeno");
										    }
									    }else{
										    $txt="--------------";
									    }
								    }
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,137-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    // 1. izbirni predmeti
                                    if (isset($Izbirni[0]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");


                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,143-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,149-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,143-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    // 2. izbirni predmeti
                                    if (isset($Izbirni[1]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,155-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,161-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,155-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    // 3. izbirni predmeti
                                    if (isset($Izbirni[2]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    break;
                                                case 1:
                                                    $txt=ToWin("neocenjeno");
                                                    break;
                                                case 2:
                                                    $txt=ToWin("oproščeno");
                                            }
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $pdf->SetXY(55+$KorX+($VRazred1-7)*25,167-$KorY);
                                            $pdf->Cell(20,0,$txt,0,2,"C");
                                       }else{
                                            $txt="--------------";
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                             //'napis predmeta
                                            $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,"C");
                                        }
                                    }else{
                                        $txt="--------------";
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,173-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                         //'napis predmeta
                                        $pdf->SetXY(48+$KorX+($VRazred1-7)*25,167-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,"C");
                                    }
                                    
                                    //štiri prazne vrstice pod izbirnimi predmeti
                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,179-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,185-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,191-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    $txt=ToWin("--------------");
                                    $pdf->SetXY(48+$KorX+($VRazred1-7)*25,197-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,"C");

                                    //'vpis podatkov o NPZ
                                    if ($VRazred1==9){
                                        $Npz=$oUcenec->getNPZ($VLeto);
                                        // SLJ
                                        if (isset($Npz[0]["oznaka"])){        
                                            if ($Npz[0]["tock"] > 0){
                                                $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,47-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(90+$KorX,47-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"L");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,47-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"L");
                                        }    
                                        
                                        //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                        $txt="--------------";
                                        $pdf->SetXY(125+$KorX,53-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,"C");
                                        
                                        // MAT
                                        if (isset($Npz[1]["oznaka"])){        
                                            if ($Npz[1]["tock"] > 0){
                                                $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,59-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,59-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,59-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //angleščina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,65-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,65-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,65-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //prazna vrstica za drugi tuji jezik
                                        $txt="--------------";
                                        $pdf->SetXY(125+$KorX,71-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,"C");
                                        
                                        //likovna
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="LVZ")or ($Npz[2]["oznaka"]=="LUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,77-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,77-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,77-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Glasbena vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="GVZ")or ($Npz[2]["oznaka"]=="GUM"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,83-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,83-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,83-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    

                                        //'Geografija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="GEO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,89-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,89-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,89-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Zgodovina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="ZGO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,95-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,95-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,95-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Drzavljanska vzgoja in etika
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="DDE")or ($Npz[2]["oznaka"]=="DKE"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,101-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,101-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,101-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Fizika
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="FIZ")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,107-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,107-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,107-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Kemija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="KEM")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,113-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,113-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,113-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Biologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="BIO")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,119-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,119-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,119-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Naravoslovje
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="NAR")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,125-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,125-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,125-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Tehnika in tehnologija
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TIT")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,131-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,131-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,131-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }    
                                        
                                        //'Sportna vzgoja
                                        if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="ŠVZ")or ($Npz[2]["oznaka"]=="ŠPO"))){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                                $pdf->SetXY(125+$KorX,137-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }else{
                                                $txt="--------------";
                                                $pdf->SetXY(125+$KorX,137-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,"C");
                                            }    
                                        }else{
                                            $txt="--------------";
                                            $pdf->SetXY(125+$KorX,137-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        } 
                                    }   
                                }
                        }
                        break;
                }
            }
                
            $pdf->Output("MaticniListi.pdf","D");
        }
        break;
    case "200": //izbor matičnih listov iz tabele
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Matični listi po meri";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');

        //Korekcija tiska
        if (isset($_POST["id1"])){
            $Vid1=$_POST["id1"];
        }else{
            $Vid1=0;
        }
        if (isset($_SESSION["posx"])) {
            $KorX=$_SESSION["posx"];
        }else{
            $KorX=0;
        }
        if (isset($_SESSION["posy"])){
            $KorY=$_SESSION["posy"];
        }else{
            $KorY=0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay=$_SESSION["DayToPrint"];
        }else{
            $PrintDay=$Danes->format('j.n.Y');
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix = $_SESSION["RefStFix"];
        }else{
            $RefStFix = "";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar = $_SESSION["RefStVar"];
        }else{
            $RefStVar = "";
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe = "";
        }
        switch ($Vid1){
            case "1":
                $KorX=$_POST["koordinatax"];
                $KorY=$_POST["koordinatay"];
                if (isset($_POST["RefStFix"])){
                    $RefStFix=$_POST["RefStFix"];
                }
                if (isset($_POST["RefStVar"])){
                    $RefStVar=$_POST["RefStVar"];
                }
                if (isset($_POST["datum"])){
                    $PrintDay=$_POST["datum"];
                }
                if (isset($_POST["KorOpombe"])){
                    $KorOpombe=$_POST["KorOpombe"];
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
                echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
                break;
            default:    
                if ($KorX==""){
                    $KorX=0;
                }
                if ($KorY==""){
                    $KorY=0;
                }
                if ($PrintDay=="") {
                    $PrintDay=$Danes->format('j.n.Y');
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
        }
                
        echo "<form name='rezultati' method=post action='maticnilisti.php'>";
        echo "<input name='idd' type='hidden' value='200'>";
        echo "<h3>Korekcija tiskanja</h3>";
        echo "<table border='0'>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis višje(+)/nižje(-) mm:";
        echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis bolj desno(+)/levo(-) mm:";
        echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        /*
        if (strstr($PrintDay,".")) { 
            $astr=explode(".",$PrintDay);
            $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
        }else{
            $Datum  = new DateTime($Danes->format('Y-m-d'));
        }
        echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
        echo "</tr>";
        */
        echo "</table>";
        echo "<input name='id1' type='hidden' value='1'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        // konec korekcije tiskanja
        
        //echo "<form name='spricevalo' method='post' action='maticnilisti.php'>";
        //echo "<input name='idd' type='hidden' value='210'>";
        echo "<h2>Matični listi po meri</h2>";

        //echo "<a href='izpisredovalnice.php'>Nazaj na izbor redovalnice</a><br />";
        
        echo "<form name='rezultati1' method='post' action='maticnilisti.php'>";
        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "<input name='vrstaos' type='hidden' value='9'>";
        if ($VLevel < 2){
            $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
            $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
            $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
            $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
        }else{
            $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
            $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
            $SQL .= " ORDER BY idsola,razred,oznaka";
        }
        $result = mysqli_query($link,$SQL);

        echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
        echo "<option value='0'>Ni izbran</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred==$R["id"] ){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred==$R["id"] ){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select>";
        echo "<input name='idd' type='hidden' value='200'>";
        //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
        //echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";

        echo "<a href='tiskanje_navodilo.htm'>Navodilo za tiskanje PDF dokumentov</a><br />";
        //echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika in <b>sprememba datuma tiskanja</b></a><br /><br />";
        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=".$VRazred;
        $result1 = mysqli_query($link,$SQL);
        if ($R1 = mysqli_fetch_array($result1)){
            echo "Izpisi za razred: ".$R1["razred"].". ".$R1["oznaka"]."<br /><br />";
            $_SESSION["razred"]=$VRazred;
        }            
        
        echo "<table border=1>";
        if ($VLevel > 1){
            echo "<tr><th>Št.</th><th>Oznaka</th><th>Tip</th><th>Nastanek</th><th>Izpis glave<br />na obrazec</th><th>Izpis uspeha<br />na obrazec</th><th>Predogled<br />glave</th><th>Predogled<br />uspeha</th><th>Popravi</th><th>Briši</th></tr>";
        }else{
            echo "<tr><th>Št.</th><th>Oznaka</th><th>Tip</th><th>Nastanek</th><th>Izpis glave<br />na obrazec</th><th>Izpis uspeha<br />na obrazec</th><th>Predogled<br />glave</th><th>Predogled<br />uspeha</th></tr>";
        }
        
        $SQL = "SELECT id,oznaka,tip,cas FROM tabmaticnilisti ORDER BY id DESC";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            if (strpos($R["oznaka"],$VLeto."/".($VLeto+1)) > 0){
                echo "<tr bgcolor='lightgreen'>";
            }else{
                echo "<tr>";
            }
            echo "<td>".$i."</td>";
            echo "<td>".$R["oznaka"]."</td>";
            switch ($R["tip"]){
                case "24":
                    echo "<td>Matični list</td>";
                    break;
            }
            echo "<td>".$R["cas"]."</td>";
            echo "<td><a href='maticnilisti.php?idd=240&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=0&glava=on'>Izpis glave na obrazec</a></td>";
            echo "<td><a href='maticnilisti.php?idd=240&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=0'>Izpis uspeha na obrazec</a></td>";
            echo "<td><a href='maticnilisti.php?idd=240&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=1&glava=on'>Predogled glave</a></td>";
            echo "<td><a href='maticnilisti.php?idd=240&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."&predogled=1'>Predogled uspeha</a></td>";
            if ($VLevel > 1){
                echo "<td><a href='maticnilisti.php?idd=220&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."'>Popravi/Kopiraj</a></td>";
                echo "<td><a href='maticnilisti.php?idd=230&zapis=".$R["id"]."&razred=".$VRazred."&solskoleto=".$VLeto."'>Briši</a></td>";
            }
            $i=$i+1;
        }
        echo "</table><br />";
        echo "<a href='maticnilisti.php'>Na izbiro razreda</a>";
        //echo "<input name='submit' type='submit' value='Dodaj novo'>";
        //echo "</form>";
        
        echo "</body>";
        echo "</html>";
        break;
    case "220": //popravljanje matičnega lista
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Matični listi po meri";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');

        $SQL = "SELECT * FROM tabmaticnilisti WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){

            echo "<form name='maticni' method='post' action='maticnilisti.php'>";
            echo "<input name='idd' type='hidden' value='225'>";
            echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<h2>Matični listi po meri</h2><br />";
            
            echo "Oznaka dokumenta: <input name='oznaka' type='text' size='40' value='".$R["oznaka"]."'><br />";
            echo "Ime datoteke predloge: <input name='obrazec' type='text' size='40' value='".$R["obrazec"]."'><br />";
            
            echo "Tip dokumenta: <select name='tip'>";
            switch ($R["tip"]){
                case "24":
                    echo "<option value='24' selected='selected'>Matični list</option>";
                    break;
            }
            echo "</select><br />";
            echo "Čas nastanka dokumenta: ".$R["cas"]."<br />";
            echo "<table border='1'>";
            echo "<tr><th>Pozicija</th><th>Odmik od levega<br /> roba lista (X) [mm]</th><th>Odmik od zg.<br />roba lista (Y) [mm]</th><th>Poravnava<br />besedila</th><th>Velikost<br />pisave (pt)</th></tr>";
            $poz=explode(",",$R["ucenec"]);
            echo "<tr><td>Učenec</td><td><input name='ucenec_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenec_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenec_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenec_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["datroj"]);
            echo "<tr><td>Dat.roj.</td><td><input name='datroj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='datroj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='datroj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='datroj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["matknj"]);
            echo "<tr><td>Mat. knjiga</td><td><input name='matknj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='matknj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='matknj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='matknj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["ucenecspol"]);
            echo "<tr><td>Spol učenca</td><td><input name='ucenecspol_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenecspol_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenecspol_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenecspol_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["ucenecemso"]);
            echo "<tr><td>EMŠO učenca</td><td><input name='ucenecemso_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ucenecemso_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ucenecemso_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ucenecemso_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["krajroj"]);
            echo "<tr><td>Kraj in država roj.</td><td><input name='krajroj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='krajroj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='krajroj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo"<td><input name='krajroj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["drzavljanstvo"]);
            echo "<tr><td>Državljanstvo</td><td><input name='drzavljanstvo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='drzavljanstvo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='drzavljanstvo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='drzavljanstvo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["prebivalisce"]);
            echo "<tr><td>Prebivališče učenca</td><td><input name='prebivalisce_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='prebivalisce_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='prebivalisce_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='prebivalisce_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["oce"]);
            echo "<tr><td>Oče</td><td><input name='oce_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='oce_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='oce_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='oce_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["mati"]);
            echo "<tr><td>Mati</td><td><input name='mati_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='mati_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='mati_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='mati_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["skrbniki"]);
            echo "<tr><td>Skrbniki</td><td><input name='skrbniki_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='skrbniki_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='skrbniki_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='skrbniki_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["sola"]);
            echo "<tr><td>Ime in sedež šole</td><td><input name='sola_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='sola_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='sola_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='sola_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["solaobcina"]);
            echo "<tr><td>Občina šole</td><td><input name='solaobcina_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='solaobcina_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='solaobcina_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='solaobcina_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["solazac"]);
            echo "<tr><td>Začetek šolanja na šoli</td><td><input name='solazac_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='solazac_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='solazac_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='solazac_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["solakon"]);
            echo "<tr><td>Zaključek šolanja na šoli</td><td><input name='solakon_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='solakon_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='solakon_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='solakon_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["solleto"]);
            echo "<tr><td>Šolsko leto</td><td><input name='solleto_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='solleto_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='solleto_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='solleto_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["zapleto"]);
            echo "<tr><td>Zaporedno leto</td><td><input name='zapleto_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='zapleto_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='zapleto_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='zapleto_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["razred"]);
            echo "<tr><td>Razred in paralelka</td><td><input name='razred_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razred_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razred_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razred_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["oddelek"]);
            echo "<tr><td>Oddelek</td><td><input name='oddelek_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='oddelek_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='oddelek_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='oddelek_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["slj"]);
            echo "<tr><td>SLJ</td><td><input name='slj_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='slj_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='slj_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='slj_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["matjezik2"]);
            echo "<tr><td>Dvojezični jezik</td><td><input name='matjezik2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='matjezik2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='matjezik2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='matjezik2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["mat"]);
            echo "<tr><td>MAT</td><td><input name='mat_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='mat_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='mat_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='mat_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["tuj1"]);
            echo "<tr><td>1. tuj jezik</td><td><input name='tuj1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tuj1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tuj1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tuj1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["tujj1n"]);
            echo "<tr><td>Naziv 1. tuj. jezika</td><td><input name='tujj1n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tujj1n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tujj1n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tujj1n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["tuj2"]);
            echo "<tr><td>2. tuj jezik</td><td><input name='tuj2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tuj2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tuj2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tuj2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["tujj2n"]);
            echo "<tr><td>Naziv 2. tuj. jezika</td><td><input name='tujj2n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tujj2n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tujj2n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tujj2n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["lum"]);
            echo "<tr><td>LUM</td><td><input name='lum_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='lum_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='lum_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='lum_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["gum"]);
            echo "<tr><td>GUM</td><td><input name='gum_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gum_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gum_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gum_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["dru"]);
            echo "<tr><td>DRU</td><td><input name='dru_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='dru_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='dru_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='dru_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["geo"]);
            echo "<tr><td>GEO</td><td><input name='geo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='geo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='geo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='geo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["zgo"]);
            echo "<tr><td>ZGO</td><td><input name='zgo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='zgo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='zgo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='zgo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["dke"]);
            echo "<tr><td>DKE</td><td><input name='dke_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='dke_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='dke_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='dke_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["fiz"]);
            echo "<tr><td>FIZ</td><td><input name='fiz_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='fiz_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='fiz_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='fiz_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["kem"]);
            echo "<tr><td>KEM</td><td><input name='kem_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='kem_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='kem_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='kem_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["bio"]);
            echo "<tr><td>BIO</td><td><input name='bio_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='bio_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='bio_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='bio_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["nar"]);
            echo "<tr><td>NAR</td><td><input name='nar_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='nar_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='nar_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='nar_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["nit"]);
            echo "<tr><td>NIT</td><td><input name='nit_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='nit_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='nit_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='nit_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["tit"]);
            echo "<tr><td>TIT</td><td><input name='tit_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='tit_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='tit_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='tit_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["gos"]);
            echo "<tr><td>GOS</td><td><input name='gos_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='gos_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='gos_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='gos_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["sport"]);
            echo "<tr><td>Šport</td><td><input name='sport_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='sport_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='sport_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='sport_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["spo"]);
            echo "<tr><td>SPO</td><td><input name='spo_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='spo_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='spo_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='spo_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb1"]);
            echo "<tr><td>Izbirni 1</td><td><input name='izb1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb1n"]);
            echo "<tr><td>Naziv 1. izb. pr.</td><td><input name='izb1n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb1n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb1n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb1n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb2"]);
            echo "<tr><td>Izbirni 2</td><td><input name='izb2_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb2_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb2_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb2_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb2n"]);
            echo "<tr><td>Naziv 2. izb. pr.</td><td><input name='izb2n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb2n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb2n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb2n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb3"]);
            echo "<tr><td>Izbirni 3</td><td><input name='izb3_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb3_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb3_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb3_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb3n"]);
            echo "<tr><td>Naziv 3. izb. pr.</td><td><input name='izb3n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb3n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb3n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb3n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb4"]);
            echo "<tr><td>Izbirni 4</td><td><input name='izb4_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb4_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb4_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb4_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["izb4n"]);
            echo "<tr><td>Naziv 4. izb. pr.</td><td><input name='izb4n_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='izb4n_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='izb4n_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='izb4n_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["drusl"]);
            echo "<tr><td>Družnoslovje (OŠPP)</td><td><input name='drusl_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='drusl_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='drusl_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='drusl_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["drusln"]);
            echo "<tr><td>Naziv Družboslovje (OŠPP)</td><td><input name='drusln_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='drusln_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='drusln_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='drusln_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["opravicene"]);
            echo "<tr><td>Opravičene/neopravičene ure</td><td><input name='opravicene_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='opravicene_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='opravicene_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='opravicene_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["napreduje_p1"]);
            echo "<tr><td>Napreduje</td><td><input name='napreduje_p1_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='napreduje_p1_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='napreduje_p1_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='napreduje_p1_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["krajdat"]);
            echo "<tr><td>Kraj in datum</td><td><input name='krajdat_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='krajdat_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='krajdat_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='krajdat_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["evst"]);
            echo "<tr><td>Ev. št.</td><td><input name='evst_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='evst_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='evst_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='evst_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["razr"]);
            echo "<tr><td>Razrednik</td><td><input name='razr_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='razr_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='razr_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='razr_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["ravn"]);
            echo "<tr><td>Ravnatelj</td><td><input name='ravn_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='ravn_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='ravn_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='ravn_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["npzsljt"]);
            echo "<tr><td>NPZ SLJ točke</td><td><input name='npzsljt_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzsljt_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzsljt_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzsljt_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";
            
            $poz=explode(",",$R["npzmatt"]);
            echo "<tr><td>NPZ MAT točke</td><td><input name='npzmatt_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npzmatt_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npzmatt_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npzmatt_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["npz3"]);
            echo "<tr><td>NPZ 3. predmet</td><td><input name='npz3_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npz3_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npz3_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npz3_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            $poz=explode(",",$R["npz3t"]);
            echo "<tr><td>NPZ 3. predmet točke</td><td><input name='npz3t_x' type='text' size='5' value='".$poz[0]."'></td><td><input name='npz3t_y' type='text' size='5' value='".$poz[1]."'></td><td><select name='npz3t_j'>";
            switch ($poz[2]){
                case "L":
                    echo "<option value='L' selected='selected'>Levo</option><option value='C'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "C":
                    echo "<option value='L'>Levo</option><option value='C' selected='selected'>Centrirano</option><option value='R'>Desno</option></select></td>";
                    break;
                case "R":
                    echo "<option value='L'>Levo</option><option value='C'>Centrirano</option><option value='R' selected='selected'>Desno</option></select></td>";
                    break;
            }
            echo "<td><input name='npz3t_fs' type='text' size='5' value='".$poz[3]."'></td></tr>";

            

            echo "</table>";
            echo "<input name='submit' type='submit' value='Popravi'><input name='submit' type='submit' value='Dodaj'>";
            echo "</form>";
        }
        echo "<a href='maticnilisti.php?idd=200&razred=".$VRazred."&solskoleto=".$VLeto."'>Na spisek matičnih listov</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "225":
        if (isset($_POST["submit"])){
            $nacin=$_POST["submit"];
            if (intval($_POST["zapis"]) < 3){
                $nacin="Dodaj";
            }
            switch ($nacin){
                case "Popravi":
                    $SQL = "UPDATE tabmaticnilisti SET ";
                    $SQL = $SQL . "oznaka='".$_POST["oznaka"]."'";
                    $SQL = $SQL . ",obrazec='".$_POST["obrazec"]."'";
                    $SQL = $SQL . ",sola='".str_replace(",",".",$_POST["sola_x"]).",".str_replace(",",".",$_POST["sola_y"]).",".$_POST["sola_j"].",".str_replace(",",".",$_POST["sola_fs"])."'";
                    $SQL = $SQL . ",ucenec='".str_replace(",",".",$_POST["ucenec_x"]).",".str_replace(",",".",$_POST["ucenec_y"]).",".$_POST["ucenec_j"].",".str_replace(",",".",$_POST["ucenec_fs"])."'";
                    $SQL = $SQL . ",datroj='".str_replace(",",".",$_POST["datroj_x"]).",".str_replace(",",".",$_POST["datroj_y"]).",".$_POST["datroj_j"].",".str_replace(",",".",$_POST["datroj_fs"])."'";
                    $SQL = $SQL . ",krajroj='".str_replace(",",".",$_POST["krajroj_x"]).",".str_replace(",",".",$_POST["krajroj_y"]).",".$_POST["krajroj_j"].",".str_replace(",",".",$_POST["krajroj_fs"])."'";
                    $SQL = $SQL . ",matknj='".str_replace(",",".",$_POST["matknj_x"]).",".str_replace(",",".",$_POST["matknj_y"]).",".$_POST["matknj_j"].",".str_replace(",",".",$_POST["matknj_fs"])."'";
                    $SQL = $SQL . ",razred='".str_replace(",",".",$_POST["razred_x"]).",".str_replace(",",".",$_POST["razred_y"]).",".$_POST["razred_j"].",".str_replace(",",".",$_POST["razred_fs"])."'";
                    $SQL = $SQL . ",solleto='".str_replace(",",".",$_POST["solleto_x"]).",".str_replace(",",".",$_POST["solleto_y"]).",".$_POST["solleto_j"].",".str_replace(",",".",$_POST["solleto_fs"])."'";
                    $SQL = $SQL . ",slj='".str_replace(",",".",$_POST["slj_x"]).",".str_replace(",",".",$_POST["slj_y"]).",".$_POST["slj_j"].",".str_replace(",",".",$_POST["slj_fs"])."'";
                    $SQL = $SQL . ",mat='".str_replace(",",".",$_POST["mat_x"]).",".str_replace(",",".",$_POST["mat_y"]).",".$_POST["mat_j"].",".str_replace(",",".",$_POST["mat_fs"])."'";
                    $SQL = $SQL . ",tuj1='".str_replace(",",".",$_POST["tuj1_x"]).",".str_replace(",",".",$_POST["tuj1_y"]).",".$_POST["tuj1_j"].",".str_replace(",",".",$_POST["tuj1_fs"])."'";
                    $SQL = $SQL . ",tuj2='".str_replace(",",".",$_POST["tuj2_x"]).",".str_replace(",",".",$_POST["tuj2_y"]).",".$_POST["tuj2_j"].",".str_replace(",",".",$_POST["tuj2_fs"])."'";
                    $SQL = $SQL . ",lum='".str_replace(",",".",$_POST["lum_x"]).",".str_replace(",",".",$_POST["lum_y"]).",".$_POST["lum_j"].",".str_replace(",",".",$_POST["lum_fs"])."'";
                    $SQL = $SQL . ",gum='".str_replace(",",".",$_POST["gum_x"]).",".str_replace(",",".",$_POST["gum_y"]).",".$_POST["gum_j"].",".str_replace(",",".",$_POST["gum_fs"])."'";
                    $SQL = $SQL . ",dru='".str_replace(",",".",$_POST["dru_x"]).",".str_replace(",",".",$_POST["dru_y"]).",".$_POST["dru_j"].",".str_replace(",",".",$_POST["dru_fs"])."'";
                    $SQL = $SQL . ",geo='".str_replace(",",".",$_POST["geo_x"]).",".str_replace(",",".",$_POST["geo_y"]).",".$_POST["geo_j"].",".str_replace(",",".",$_POST["geo_fs"])."'";
                    $SQL = $SQL . ",zgo='".str_replace(",",".",$_POST["zgo_x"]).",".str_replace(",",".",$_POST["zgo_y"]).",".$_POST["zgo_j"].",".str_replace(",",".",$_POST["zgo_fs"])."'";
                    $SQL = $SQL . ",dke='".str_replace(",",".",$_POST["dke_x"]).",".str_replace(",",".",$_POST["dke_y"]).",".$_POST["dke_j"].",".str_replace(",",".",$_POST["dke_fs"])."'";
                    $SQL = $SQL . ",fiz='".str_replace(",",".",$_POST["fiz_x"]).",".str_replace(",",".",$_POST["fiz_y"]).",".$_POST["fiz_j"].",".str_replace(",",".",$_POST["fiz_fs"])."'";
                    $SQL = $SQL . ",kem='".str_replace(",",".",$_POST["kem_x"]).",".str_replace(",",".",$_POST["kem_y"]).",".$_POST["kem_j"].",".str_replace(",",".",$_POST["kem_fs"])."'";
                    $SQL = $SQL . ",bio='".str_replace(",",".",$_POST["bio_x"]).",".str_replace(",",".",$_POST["bio_y"]).",".$_POST["bio_j"].",".str_replace(",",".",$_POST["bio_fs"])."'";
                    $SQL = $SQL . ",nar='".str_replace(",",".",$_POST["nar_x"]).",".str_replace(",",".",$_POST["nar_y"]).",".$_POST["nar_j"].",".str_replace(",",".",$_POST["nar_fs"])."'";
                    $SQL = $SQL . ",nit='".str_replace(",",".",$_POST["nit_x"]).",".str_replace(",",".",$_POST["nit_y"]).",".$_POST["nit_j"].",".str_replace(",",".",$_POST["nit_fs"])."'";
                    $SQL = $SQL . ",tit='".str_replace(",",".",$_POST["tit_x"]).",".str_replace(",",".",$_POST["tit_y"]).",".$_POST["tit_j"].",".str_replace(",",".",$_POST["tit_fs"])."'";
                    $SQL = $SQL . ",gos='".str_replace(",",".",$_POST["gos_x"]).",".str_replace(",",".",$_POST["gos_y"]).",".$_POST["gos_j"].",".str_replace(",",".",$_POST["gos_fs"])."'";
                    $SQL = $SQL . ",sport='".str_replace(",",".",$_POST["sport_x"]).",".str_replace(",",".",$_POST["sport_y"]).",".$_POST["sport_j"].",".str_replace(",",".",$_POST["sport_fs"])."'";
                    $SQL = $SQL . ",spo='".str_replace(",",".",$_POST["spo_x"]).",".str_replace(",",".",$_POST["spo_y"]).",".$_POST["spo_j"].",".str_replace(",",".",$_POST["spo_fs"])."'";
                    $SQL = $SQL . ",izb1='".str_replace(",",".",$_POST["izb1_x"]).",".str_replace(",",".",$_POST["izb1_y"]).",".$_POST["izb1_j"].",".str_replace(",",".",$_POST["izb1_fs"])."'";
                    $SQL = $SQL . ",izb2='".str_replace(",",".",$_POST["izb2_x"]).",".str_replace(",",".",$_POST["izb2_y"]).",".$_POST["izb2_j"].",".str_replace(",",".",$_POST["izb2_fs"])."'";
                    $SQL = $SQL . ",izb3='".str_replace(",",".",$_POST["izb3_x"]).",".str_replace(",",".",$_POST["izb3_y"]).",".$_POST["izb3_j"].",".str_replace(",",".",$_POST["izb3_fs"])."'";
                    $SQL = $SQL . ",izb4='".str_replace(",",".",$_POST["izb4_x"]).",".str_replace(",",".",$_POST["izb4_y"]).",".$_POST["izb4_j"].",".str_replace(",",".",$_POST["izb4_fs"])."'";
                    $SQL = $SQL . ",napreduje_p1='".str_replace(",",".",$_POST["napreduje_p1_x"]).",".str_replace(",",".",$_POST["napreduje_p1_y"]).",".$_POST["napreduje_p1_j"].",".str_replace(",",".",$_POST["napreduje_p1_fs"])."'";
                    $SQL = $SQL . ",krajdat='".str_replace(",",".",$_POST["krajdat_x"]).",".str_replace(",",".",$_POST["krajdat_y"]).",".$_POST["krajdat_j"].",".str_replace(",",".",$_POST["krajdat_fs"])."'";
                    $SQL = $SQL . ",evst='".str_replace(",",".",$_POST["evst_x"]).",".str_replace(",",".",$_POST["evst_y"]).",".$_POST["evst_j"].",".str_replace(",",".",$_POST["evst_fs"])."'";
                    $SQL = $SQL . ",razr='".str_replace(",",".",$_POST["razr_x"]).",".str_replace(",",".",$_POST["razr_y"]).",".$_POST["razr_j"].",".str_replace(",",".",$_POST["razr_fs"])."'";
                    $SQL = $SQL . ",ravn='".str_replace(",",".",$_POST["ravn_x"]).",".str_replace(",",".",$_POST["ravn_y"]).",".$_POST["ravn_j"].",".str_replace(",",".",$_POST["ravn_fs"])."'";
                    $SQL = $SQL . ",npzsljt='".str_replace(",",".",$_POST["npzsljt_x"]).",".str_replace(",",".",$_POST["npzsljt_y"]).",".$_POST["npzsljt_j"].",".str_replace(",",".",$_POST["npzsljt_fs"])."'";
                    $SQL = $SQL . ",npzmatt='".str_replace(",",".",$_POST["npzmatt_x"]).",".str_replace(",",".",$_POST["npzmatt_y"]).",".$_POST["npzmatt_j"].",".str_replace(",",".",$_POST["npzmatt_fs"])."'";
                    $SQL = $SQL . ",npz3='".str_replace(",",".",$_POST["npz3_x"]).",".str_replace(",",".",$_POST["npz3_y"]).",".$_POST["npz3_j"].",".str_replace(",",".",$_POST["npz3_fs"])."'";
                    $SQL = $SQL . ",npz3t='".str_replace(",",".",$_POST["npz3t_x"]).",".str_replace(",",".",$_POST["npz3t_y"]).",".$_POST["npz3t_j"].",".str_replace(",",".",$_POST["npz3t_fs"])."'";
                    $SQL = $SQL . ",tujj1n='".str_replace(",",".",$_POST["tujj1n_x"]).",".str_replace(",",".",$_POST["tujj1n_y"]).",".$_POST["tujj1n_j"].",".str_replace(",",".",$_POST["tujj1n_fs"])."'";
                    $SQL = $SQL . ",tujj2n='".str_replace(",",".",$_POST["tujj2n_x"]).",".str_replace(",",".",$_POST["tujj2n_y"]).",".$_POST["tujj2n_j"].",".str_replace(",",".",$_POST["tujj2n_fs"])."'";
                    $SQL = $SQL . ",izb1n='".str_replace(",",".",$_POST["izb1n_x"]).",".str_replace(",",".",$_POST["izb1n_y"]).",".$_POST["izb1n_j"].",".str_replace(",",".",$_POST["izb1n_fs"])."'";
                    $SQL = $SQL . ",izb2n='".str_replace(",",".",$_POST["izb2n_x"]).",".str_replace(",",".",$_POST["izb2n_y"]).",".$_POST["izb2n_j"].",".str_replace(",",".",$_POST["izb2n_fs"])."'";
                    $SQL = $SQL . ",izb3n='".str_replace(",",".",$_POST["izb3n_x"]).",".str_replace(",",".",$_POST["izb3n_y"]).",".$_POST["izb3n_j"].",".str_replace(",",".",$_POST["izb3n_fs"])."'";
                    $SQL = $SQL . ",izb4n='".str_replace(",",".",$_POST["izb4n_x"]).",".str_replace(",",".",$_POST["izb4n_y"]).",".$_POST["izb4n_j"].",".str_replace(",",".",$_POST["izb4n_fs"])."'";
                    $SQL = $SQL . ",drusl='".str_replace(",",".",$_POST["drusl_x"]).",".str_replace(",",".",$_POST["drusl_y"]).",".$_POST["drusl_j"].",".str_replace(",",".",$_POST["drusl_fs"])."'";
                    $SQL = $SQL . ",drusln='".str_replace(",",".",$_POST["drusln_x"]).",".str_replace(",",".",$_POST["drusln_y"]).",".$_POST["drusln_j"].",".str_replace(",",".",$_POST["drusln_fs"])."'";

                    $SQL = $SQL . ",ucenecemso='".str_replace(",",".",$_POST["ucenecemso_x"]).",".str_replace(",",".",$_POST["ucenecemso_y"]).",".$_POST["ucenecemso_j"].",".str_replace(",",".",$_POST["ucenecemso_fs"])."'";
                    $SQL = $SQL . ",prebivalisce='".str_replace(",",".",$_POST["prebivalisce_x"]).",".str_replace(",",".",$_POST["prebivalisce_y"]).",".$_POST["prebivalisce_j"].",".str_replace(",",".",$_POST["prebivalisce_fs"])."'";
                    $SQL = $SQL . ",drzavljanstvo='".str_replace(",",".",$_POST["drzavljanstvo_x"]).",".str_replace(",",".",$_POST["drzavljanstvo_y"]).",".$_POST["drzavljanstvo_j"].",".str_replace(",",".",$_POST["drzavljanstvo_fs"])."'";
                    $SQL = $SQL . ",oce='".str_replace(",",".",$_POST["oce_x"]).",".str_replace(",",".",$_POST["oce_y"]).",".$_POST["oce_j"].",".str_replace(",",".",$_POST["oce_fs"])."'";
                    $SQL = $SQL . ",mati='".str_replace(",",".",$_POST["mati_x"]).",".str_replace(",",".",$_POST["mati_y"]).",".$_POST["mati_j"].",".str_replace(",",".",$_POST["mati_fs"])."'";
                    $SQL = $SQL . ",skrbniki='".str_replace(",",".",$_POST["skrbniki_x"]).",".str_replace(",",".",$_POST["skrbniki_y"]).",".$_POST["skrbniki_j"].",".str_replace(",",".",$_POST["skrbniki_fs"])."'";
                    $SQL = $SQL . ",solaobcina='".str_replace(",",".",$_POST["solaobcina_x"]).",".str_replace(",",".",$_POST["solaobcina_y"]).",".$_POST["solaobcina_j"].",".str_replace(",",".",$_POST["solaobcina_fs"])."'";
                    $SQL = $SQL . ",solazac='".str_replace(",",".",$_POST["solazac_x"]).",".str_replace(",",".",$_POST["solazac_y"]).",".$_POST["solazac_j"].",".str_replace(",",".",$_POST["solazac_fs"])."'";
                    $SQL = $SQL . ",solakon='".str_replace(",",".",$_POST["solakon_x"]).",".str_replace(",",".",$_POST["solakon_y"]).",".$_POST["solakon_j"].",".str_replace(",",".",$_POST["solakon_fs"])."'";
                    $SQL = $SQL . ",zapleto='".str_replace(",",".",$_POST["zapleto_x"]).",".str_replace(",",".",$_POST["zapleto_y"]).",".$_POST["zapleto_j"].",".str_replace(",",".",$_POST["zapleto_fs"])."'";
                    $SQL = $SQL . ",oddelek='".str_replace(",",".",$_POST["oddelek_x"]).",".str_replace(",",".",$_POST["oddelek_y"]).",".$_POST["oddelek_j"].",".str_replace(",",".",$_POST["oddelek_fs"])."'";
                    $SQL = $SQL . ",opravicene='".str_replace(",",".",$_POST["opravicene_x"]).",".str_replace(",",".",$_POST["opravicene_y"]).",".$_POST["opravicene_j"].",".str_replace(",",".",$_POST["opravicene_fs"])."'";
                    $SQL = $SQL . ",ucenecspol='".str_replace(",",".",$_POST["ucenecspol_x"]).",".str_replace(",",".",$_POST["ucenecspol_y"]).",".$_POST["ucenecspol_j"].",".str_replace(",",".",$_POST["ucenecspol_fs"])."'";
                    $SQL = $SQL . ",matjezik2='".str_replace(",",".",$_POST["matjezik2_x"]).",".str_replace(",",".",$_POST["matjezik2_y"]).",".$_POST["matjezik2_j"].",".str_replace(",",".",$_POST["matjezik2_fs"])."'";

                    $SQL = $SQL . ",tip='".$_POST["tip"]."',cas='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$_POST["zapis"];
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu popravka za spričevalo!<br />$SQL <br />");
                    }
                    break;
                case "Dodaj":
                    $SQL = "INSERT INTO tabmaticnilisti (";
                    $SQL = $SQL . "oznaka";
                    $SQL = $SQL . ",sola";
                    $SQL = $SQL . ",ucenec";
                    $SQL = $SQL . ",datroj";
                    $SQL = $SQL . ",krajroj";
                    $SQL = $SQL . ",matknj";
                    $SQL = $SQL . ",razred";
                    $SQL = $SQL . ",solleto";
                    $SQL = $SQL . ",slj";
                    $SQL = $SQL . ",mat";
                    $SQL = $SQL . ",tuj1";
                    $SQL = $SQL . ",tuj2";
                    $SQL = $SQL . ",lum";
                    $SQL = $SQL . ",gum";
                    $SQL = $SQL . ",dru";
                    $SQL = $SQL . ",geo";
                    $SQL = $SQL . ",zgo";
                    $SQL = $SQL . ",dke";
                    $SQL = $SQL . ",fiz";
                    $SQL = $SQL . ",kem";
                    $SQL = $SQL . ",bio";
                    $SQL = $SQL . ",nar";
                    $SQL = $SQL . ",nit";
                    $SQL = $SQL . ",tit";
                    $SQL = $SQL . ",gos";
                    $SQL = $SQL . ",sport";
                    $SQL = $SQL . ",spo";
                    $SQL = $SQL . ",izb1";
                    $SQL = $SQL . ",izb2";
                    $SQL = $SQL . ",izb3";
                    $SQL = $SQL . ",izb4";
                    $SQL = $SQL . ",napreduje_p1";
                    $SQL = $SQL . ",krajdat";
                    $SQL = $SQL . ",evst";
                    $SQL = $SQL . ",razr";
                    $SQL = $SQL . ",ravn";
                    $SQL = $SQL . ",npzsljt";
                    $SQL = $SQL . ",npzmatt";
                    $SQL = $SQL . ",npz3";
                    $SQL = $SQL . ",npz3t";
                    $SQL = $SQL . ",tujj1n";
                    $SQL = $SQL . ",tujj2n";
                    $SQL = $SQL . ",izb1n";
                    $SQL = $SQL . ",izb2n";
                    $SQL = $SQL . ",izb3n";
                    $SQL = $SQL . ",izb4n";
                    $SQL = $SQL . ",drusl";
                    $SQL = $SQL . ",drusln";
                    $SQL = $SQL . ",ucenecemso";
                    $SQL = $SQL . ",prebivalisce";
                    $SQL = $SQL . ",drzavljanstvo";
                    $SQL = $SQL . ",oce";
                    $SQL = $SQL . ",mati";
                    $SQL = $SQL . ",skrbniki";
                    $SQL = $SQL . ",solaobcina";
                    $SQL = $SQL . ",solazac";
                    $SQL = $SQL . ",solakon";
                    $SQL = $SQL . ",zapleto";
                    $SQL = $SQL . ",oddelek";
                    $SQL = $SQL . ",opravicene";
                    $SQL = $SQL . ",ucenecspol";
                    $SQL = $SQL . ",matjezik2";
                    $SQL = $SQL . ",obrazec";
                    $SQL = $SQL . ",tip,cas) VALUES (";
                    $SQL = $SQL . "'".$_POST["oznaka"]."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["sola_x"]).",".str_replace(",",".",$_POST["sola_y"]).",".$_POST["sola_j"].",".str_replace(",",".",$_POST["sola_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenec_x"]).",".str_replace(",",".",$_POST["ucenec_y"]).",".$_POST["ucenec_j"].",".str_replace(",",".",$_POST["ucenec_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["datroj_x"]).",".str_replace(",",".",$_POST["datroj_y"]).",".$_POST["datroj_j"].",".str_replace(",",".",$_POST["datroj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["krajroj_x"]).",".str_replace(",",".",$_POST["krajroj_y"]).",".$_POST["krajroj_j"].",".str_replace(",",".",$_POST["krajroj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["matknj_x"]).",".str_replace(",",".",$_POST["matknj_y"]).",".$_POST["matknj_j"].",".str_replace(",",".",$_POST["matknj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razred_x"]).",".str_replace(",",".",$_POST["razred_y"]).",".$_POST["razred_j"].",".str_replace(",",".",$_POST["razred_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["solleto_x"]).",".str_replace(",",".",$_POST["solleto_y"]).",".$_POST["solleto_j"].",".str_replace(",",".",$_POST["solleto_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["slj_x"]).",".str_replace(",",".",$_POST["slj_y"]).",".$_POST["slj_j"].",".str_replace(",",".",$_POST["slj_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["mat_x"]).",".str_replace(",",".",$_POST["mat_y"]).",".$_POST["mat_j"].",".str_replace(",",".",$_POST["mat_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tuj1_x"]).",".str_replace(",",".",$_POST["tuj1_y"]).",".$_POST["tuj1_j"].",".str_replace(",",".",$_POST["tuj1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tuj2_x"]).",".str_replace(",",".",$_POST["tuj2_y"]).",".$_POST["tuj2_j"].",".str_replace(",",".",$_POST["tuj2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["lum_x"]).",".str_replace(",",".",$_POST["lum_y"]).",".$_POST["lum_j"].",".str_replace(",",".",$_POST["lum_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gum_x"]).",".str_replace(",",".",$_POST["gum_y"]).",".$_POST["gum_j"].",".str_replace(",",".",$_POST["gum_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["dru_x"]).",".str_replace(",",".",$_POST["dru_y"]).",".$_POST["dru_j"].",".str_replace(",",".",$_POST["dru_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["geo_x"]).",".str_replace(",",".",$_POST["geo_y"]).",".$_POST["geo_j"].",".str_replace(",",".",$_POST["geo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["zgo_x"]).",".str_replace(",",".",$_POST["zgo_y"]).",".$_POST["zgo_j"].",".str_replace(",",".",$_POST["zgo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["dke_x"]).",".str_replace(",",".",$_POST["dke_y"]).",".$_POST["dke_j"].",".str_replace(",",".",$_POST["dke_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["fiz_x"]).",".str_replace(",",".",$_POST["fiz_y"]).",".$_POST["fiz_j"].",".str_replace(",",".",$_POST["fiz_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["kem_x"]).",".str_replace(",",".",$_POST["kem_y"]).",".$_POST["kem_j"].",".str_replace(",",".",$_POST["kem_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["bio_x"]).",".str_replace(",",".",$_POST["bio_y"]).",".$_POST["bio_j"].",".str_replace(",",".",$_POST["bio_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["nar_x"]).",".str_replace(",",".",$_POST["nar_y"]).",".$_POST["nar_j"].",".str_replace(",",".",$_POST["nar_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["nit_x"]).",".str_replace(",",".",$_POST["nit_y"]).",".$_POST["nit_j"].",".str_replace(",",".",$_POST["nit_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tit_x"]).",".str_replace(",",".",$_POST["tit_y"]).",".$_POST["tit_j"].",".str_replace(",",".",$_POST["tit_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["gos_x"]).",".str_replace(",",".",$_POST["gos_y"]).",".$_POST["gos_j"].",".str_replace(",",".",$_POST["gos_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["sport_x"]).",".str_replace(",",".",$_POST["sport_y"]).",".$_POST["sport_j"].",".str_replace(",",".",$_POST["sport_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["spo_x"]).",".str_replace(",",".",$_POST["spo_y"]).",".$_POST["spo_j"].",".str_replace(",",".",$_POST["spo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb1_x"]).",".str_replace(",",".",$_POST["izb1_y"]).",".$_POST["izb1_j"].",".str_replace(",",".",$_POST["izb1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb2_x"]).",".str_replace(",",".",$_POST["izb2_y"]).",".$_POST["izb2_j"].",".str_replace(",",".",$_POST["izb2_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb3_x"]).",".str_replace(",",".",$_POST["izb3_y"]).",".$_POST["izb3_j"].",".str_replace(",",".",$_POST["izb3_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb4_x"]).",".str_replace(",",".",$_POST["izb4_y"]).",".$_POST["izb4_j"].",".str_replace(",",".",$_POST["izb4_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["napreduje_p1_x"]).",".str_replace(",",".",$_POST["napreduje_p1_y"]).",".$_POST["napreduje_p1_j"].",".str_replace(",",".",$_POST["napreduje_p1_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["krajdat_x"]).",".str_replace(",",".",$_POST["krajdat_y"]).",".$_POST["krajdat_j"].",".str_replace(",",".",$_POST["krajdat_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["evst_x"]).",".str_replace(",",".",$_POST["evst_y"]).",".$_POST["evst_j"].",".str_replace(",",".",$_POST["evst_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["razr_x"]).",".str_replace(",",".",$_POST["razr_y"]).",".$_POST["razr_j"].",".str_replace(",",".",$_POST["razr_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ravn_x"]).",".str_replace(",",".",$_POST["ravn_y"]).",".$_POST["ravn_j"].",".str_replace(",",".",$_POST["ravn_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzsljt_x"]).",".str_replace(",",".",$_POST["npzsljt_y"]).",".$_POST["npzsljt_j"].",".str_replace(",",".",$_POST["npzsljt_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npzmatt_x"]).",".str_replace(",",".",$_POST["npzmatt_y"]).",".$_POST["npzmatt_j"].",".str_replace(",",".",$_POST["npzmatt_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npz3_x"]).",".str_replace(",",".",$_POST["npz3_y"]).",".$_POST["npz3_j"].",".str_replace(",",".",$_POST["npz3_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["npz3t_x"]).",".str_replace(",",".",$_POST["npz3t_y"]).",".$_POST["npz3t_j"].",".str_replace(",",".",$_POST["npz3t_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tujj1n_x"]).",".str_replace(",",".",$_POST["tujj1n_y"]).",".$_POST["tujj1n_j"].",".str_replace(",",".",$_POST["tujj1n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["tujj2n_x"]).",".str_replace(",",".",$_POST["tujj2n_y"]).",".$_POST["tujj2n_j"].",".str_replace(",",".",$_POST["tujj2n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb1n_x"]).",".str_replace(",",".",$_POST["izb1n_y"]).",".$_POST["izb1n_j"].",".str_replace(",",".",$_POST["izb1n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb2n_x"]).",".str_replace(",",".",$_POST["izb2n_y"]).",".$_POST["izb2n_j"].",".str_replace(",",".",$_POST["izb2n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb3n_x"]).",".str_replace(",",".",$_POST["izb3n_y"]).",".$_POST["izb3n_j"].",".str_replace(",",".",$_POST["izb3n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["izb4n_x"]).",".str_replace(",",".",$_POST["izb4n_y"]).",".$_POST["izb4n_j"].",".str_replace(",",".",$_POST["izb4n_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["drusl_x"]).",".str_replace(",",".",$_POST["drusl_y"]).",".$_POST["drusl_j"].",".str_replace(",",".",$_POST["drusl_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["drusln_x"]).",".str_replace(",",".",$_POST["drusln_y"]).",".$_POST["drusln_j"].",".str_replace(",",".",$_POST["drusln_fs"])."'";

                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenecemso_x"]).",".str_replace(",",".",$_POST["ucenecemso_y"]).",".$_POST["ucenecemso_j"].",".str_replace(",",".",$_POST["ucenecemso_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["prebivalisce_x"]).",".str_replace(",",".",$_POST["prebivalisce_y"]).",".$_POST["prebivalisce_j"].",".str_replace(",",".",$_POST["prebivalisce_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["drzavljanstvo_x"]).",".str_replace(",",".",$_POST["drzavljanstvo_y"]).",".$_POST["drzavljanstvo_j"].",".str_replace(",",".",$_POST["drzavljanstvo_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["oce_x"]).",".str_replace(",",".",$_POST["oce_y"]).",".$_POST["oce_j"].",".str_replace(",",".",$_POST["oce_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["mati_x"]).",".str_replace(",",".",$_POST["mati_y"]).",".$_POST["mati_j"].",".str_replace(",",".",$_POST["mati_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["skrbniki_x"]).",".str_replace(",",".",$_POST["skrbniki_y"]).",".$_POST["skrbniki_j"].",".str_replace(",",".",$_POST["skrbniki_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["solaobcina_x"]).",".str_replace(",",".",$_POST["solaobcina_y"]).",".$_POST["solaobcina_j"].",".str_replace(",",".",$_POST["solaobcina_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["solazac_x"]).",".str_replace(",",".",$_POST["solazac_y"]).",".$_POST["solazac_j"].",".str_replace(",",".",$_POST["solazac_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["solakon_x"]).",".str_replace(",",".",$_POST["solakon_y"]).",".$_POST["solakon_j"].",".str_replace(",",".",$_POST["solakon_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["zapleto_x"]).",".str_replace(",",".",$_POST["zapleto_y"]).",".$_POST["zapleto_j"].",".str_replace(",",".",$_POST["zapleto_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["oddelek_x"]).",".str_replace(",",".",$_POST["oddelek_y"]).",".$_POST["oddelek_j"].",".str_replace(",",".",$_POST["oddelek_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["opravicene_x"]).",".str_replace(",",".",$_POST["opravicene_y"]).",".$_POST["opravicene_j"].",".str_replace(",",".",$_POST["opravicene_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["ucenecspol_x"]).",".str_replace(",",".",$_POST["ucenecspol_y"]).",".$_POST["ucenecspol_j"].",".str_replace(",",".",$_POST["ucenecspol_fs"])."'";
                    $SQL = $SQL . ",'".str_replace(",",".",$_POST["matjezik2_x"]).",".str_replace(",",".",$_POST["matjezik2_y"]).",".$_POST["matjezik2_j"].",".str_replace(",",".",$_POST["matjezik2_fs"])."'";
                    $SQL = $SQL . ",'".$_POST["obrazec"]."'";

                    $SQL = $SQL . ",'".$_POST["tip"]."','".$Danes->format('Y-m-d H:i:s')."')";
                    
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu podatkov za spričevalo!<br />$SQL<br />");
                    }
                    break;
            }
        }
        header("Location: maticnilisti.php?idd=200&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "230": //brisanje matičnega lista
        switch ($_GET["zapis"]){
            case "1":
            case "2":
                break;
            default:
                $SQL = "DELETE FROM tabmaticnilisti WHERE id=".$_GET["zapis"];
                if (!($result = mysqli_query($link,$SQL))){
                    die("Ne morem zbrisati podatkov!<br />");
                }
        }
        header("Location: maticnilisti.php?idd=200&razred=".$VRazred."&solskoleto=".$VLeto);
        break;
    case "240": //izpis matičnih listov - pozicije s koordinatami
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;
        
        $nazivpredmeta=0;
        if (isset($_SESSION["nazivpredmeta"])){
            if ($_SESSION["nazivpredmeta"]=="on"){
                $nazivpredmeta=1;
            }
        }

        if ($VecSol > 0){
            $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $idsola=$R["idsola"];
            }else{
                $idsola=1;
            }
            
            $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
                $VObcina=$R["Obcina"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
                $VObcina="999";
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
                $VObcina=$R["Obcina"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
                $VObcina="999";
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        //'0-idUcenec, 1-Priimek in ime, 2-datum rojstva, 3-KrajRoj, 4-DrzavaRoj, 5-emso, 6-MaticniList, 7-Naslov, 8-Posta Kraj, 9-oce, 10-mati, 11-Spol,12-državljanstvo,13-naslov oče, 14-naslov mati,15-skrbniki,16-naslov skrbniki,17-Zač. šolanja na šoli,18-konec šolanja na šoli
        if (isset($_GET["glava"])){
            $VGlava = true;
        }else{
            $VGlava = false;
        }
        //$VMaticniList = $_POST["maticnilist"];

        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabsifreobcin WHERE sifra='".$VObcina."'";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VObcina=$R["obcina"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
        $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=8;
        $FontSize1=8;
        $FontSize2=12;

        for ($IndxRazred=0;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);

            $VRazred1 = $Razred["razred"];
            
            if (isset($_POST["zapis"])){
                $VZapis=$_POST["zapis"];
            }else{
                if (isset($_GET["zapis"])){
                    $VZapis=$_GET["zapis"];
                }else{
                    if ($ucenec > 0){
                        $SQL = "SELECT id FROM tabmaticnilisti WHERE tip=24 AND oznaka LIKE '%".$VLeto."/".($VLeto+1)."%' ORDER BY id DESC";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VZapis=intval($R["id"]);
                        }else{
                            $VZapis=0;
                        }
                    }else{
                        $VZapis=0;
                    }
                }
            }
            if (isset($_GET["predogled"])){
                $Predogled=intval($_GET["predogled"]);
            }else{
                $Predogled=1;
            }
            if ($VZapis > 0){
                $SQL = "SELECT * FROM tabmaticnilisti WHERE id=".$VZapis;
                $result = mysqli_query($link,$SQL);
                if ($RS = mysqli_fetch_array($result)){
                    if ($VRazred1 > 6){
                        //vstavi sliko - 2. stran
                        if ($Predogled==1){
                            if ($VGlava){
                                $pdf->Image("img/".$RS["obrazec"]."a.jpg",0,0,210);
                            }else{
                                $pdf->Image("img/".$RS["obrazec"]."b.jpg",0,0,210);
                            }
                        }
                    }else{
                        //vstavi sliko - 1. stran
                        if ($Predogled==1){
                            $pdf->Image("img/".$RS["obrazec"]."a.jpg",0,0,210);
                        }
                    }
                    
                    if ($VGlava){
                        //'izpiše podatke o šoli
                        $poz=explode(",",$RS["sola"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arialbd_CE','',$poz[3]);
                            $txt=ToWin($VSola.", ".$VSolaNaslov);
                            $pdf->SetLeftMargin(12);
                            $pdf->SetRightMargin(130);
                            $pdf->SetXY(12+$KorX,102-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,$poz[2]);
                        }

                        $pdf->SetLeftMargin(10);
                        $pdf->SetRightMargin(10);
                        
                        //'občina
                        $poz=explode(",",$RS["solaobcina"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin($VObcina);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }

                        //'Začetek na šoli
                        $poz=explode(",",$RS["solazac"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin($oUcenec->getZacSolanjaSola());
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //'Konec na šoli
                        $poz=explode(",",$RS["solakon"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin($oUcenec->getKonSolanjaSola());
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //' ime in priimek
                        $poz=explode(",",$RS["ucenec"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arialbd_CE','',$poz[3]);
                            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //'datum rojstva
                        $poz=explode(",",$RS["datroj"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin($oUcenec->getDatRoj());
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //'matični list
                        $poz=explode(",",$RS["matknj"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $txt=ToWin($oUcenec->getMaticniList());
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //'spol
                        if ($oUcenec->getSpol()=="M"){
                            $txt=ToWin("M");
                        }else{
                            $txt=ToWin("Ž");
                        }
                        $poz=explode(",",$RS["ucenecspol"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }
                        
                        //'emšo
                        $txt=ToWin($oUcenec->getemso());
                        $poz=explode(",",$RS["ucenecemso"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }

                        //'kraj roj.
                        $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
                        $poz=explode(",",$RS["krajroj"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }

                        //'državljanstvo
                        $txt=ToWin($oUcenec->getDrzavljanstvo());
                        $poz=explode(",",$RS["drzavljanstvo"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }

                        //'naslov
                        $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj());
                        $poz=explode(",",$RS["prebivalisce"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                        }

                        //'oče
                        $txt=ToWin($oUcenec->getoce()."\n".$oUcenec->getocenaslov());
                        $poz=explode(",",$RS["oce"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            //$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $pdf->MultiCell(0,3,$txt,0,$poz[2]);
                        }

                        //'mati
                        $txt=ToWin($oUcenec->getmati()."\n".$oUcenec->getmatinaslov());
                        $poz=explode(",",$RS["mati"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            //$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $pdf->MultiCell(0,3,$txt,0,$poz[2]);
                        }

                        //'skrbniki
                        $txt=ToWin($oUcenec->getSkrbniki()."\n".$oUcenec->getSkrbnikiNaslov());
                        $poz=explode(",",$RS["skrbniki"]);
                        if ($poz[0] > 0){
                            $pdf->SetFont('arial_CE','',$poz[3]);
                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                            //$pdf->Cell(0,0,$txt,0,2,$poz[2]);
                            $pdf->MultiCell(0,3,$txt,0,$poz[2]);
                        }
                    }
                    //glava - konec

                    //podatki o šolskem letu
                    switch ($VRazred1){
                        case 1:
                        case 2:
                        //case 3:
                            if (!$VGlava){
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $txt=ToWin($Razred["paralelka"]);
                                $poz=explode(",",$RS["oddelek"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                                //šolsko leto
                                $txt=ToWin(substr($Razred["leto"],2,2)."    ".substr($Razred["leto"]+1,2,2));
                                $poz=explode(",",$RS["solleto"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                                //leto šolanja
                                $txt=ToWin($Razred["letosolanja"]);
                                $poz=explode(",",$RS["zapleto"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }

                                
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $txt=ToWin("Napreduje");
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                        break;
                                    case 2:
                                        $txt=ToWin("ne napreduje");
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                }
                                //opravičene in neopravičene ure
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);
                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                
                                $poz=explode(",",$RS["opravicene"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //razrednik
                                $txt=ToWin($Razred["razrednik"]);
                                $poz=explode(",",$RS["razr"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                //ravnatelj
                                $txt=ToWin($VRavnatelj);
                                $poz=explode(",",$RS["ravn"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'delovodnik
                                $txt=ToWin($Razred["evidst"]);
                                $poz=explode(",",$RS["evst"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'datum spričevala
                                $txt=ToWin($Razred["datumizdaje"]);
                                $poz=explode(",",$RS["krajdat"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $txt="--------------";
                                $poz=explode(",",$RS["matjezik2"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                            }
                            break;
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            if (!$VGlava){
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $txt=ToWin($Razred["paralelka"]);
                                $poz=explode(",",$RS["oddelek"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                                //šolsko leto
                                if ($VRazred1 < 6){
                                    $txt=ToWin(substr($Razred["leto"],2,2)."    ".substr($Razred["leto"]+1,2,2));
                                    $poz=explode(",",$RS["solleto"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21.5,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }else{
                                    $txt=ToWin(substr($Razred["leto"],2,2)."    ".substr($Razred["leto"]+1,2,2));
                                    $poz=explode(",",$RS["solleto"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21.5+12,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                //leto šolanja
                                $txt=ToWin($Razred["letosolanja"]);
                                $poz=explode(",",$RS["zapleto"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }

                                //napredovanje                                        
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        $txt=ToWin("Napreduje");
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                        break;
                                    case 2:
                                        $txt=ToWin("ne napreduje");
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                }
                                //opravičene in neopravičene
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);
                                $txt=ToWin($Odsotnost["opraviceno"]." / ".$Odsotnost["neopraviceno"]);

                                $poz=explode(",",$RS["opravicene"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                //razrednik
                                $txt=ToWin($Razred["razrednik"]);
                                $poz=explode(",",$RS["razr"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                //ravnatelj
                                $txt=ToWin($VRavnatelj);
                                $poz=explode(",",$RS["ravn"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'delovodnik
                                $txt=ToWin($Razred["evidst"]);
                                $poz=explode(",",$RS["evst"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'datum spričevala
                                $txt=ToWin($Razred["datumizdaje"]);
                                $poz=explode(",",$RS["krajdat"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                $Ocene=$oUcenec->getOcene($VLeto);
                                $Predmeti=$oUcenec->getPredmeti($VLeto);
                                $Izbirni=$oUcenec->getIzbirni($VLeto);
                                
                                //Izpis redovalnice
                                //'slovenscina
                                $NPredmet=ToNPredmet("SLJ");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["slj"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $txt="--------------";
                                $poz=explode(",",$RS["matjezik2"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                
                                //'matematika
                                $NPredmet=ToNPredmet("MAT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["mat"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                
                                if ($VRazred1 > 3){
                                    //'neobvezni izbirni predmet - tuj jezik (IA2,IN2,II2,IM2,IH2,INN,INA; nove oznake: N1N,N2N,N1A,N2A,N2F,N2I,N2M,N2H)
                                    if (isset($Izbirni[0]["oznaka"])){
                                        switch ($Izbirni[0]["oznaka"]){
                                            case "IA2":
                                            case "IN2":
                                            case "II2":
                                            case "IM2":
                                            case "IH2":
                                            case "INN":
                                            case "INA":
                                            case "N1N":   
                                            case "N1A":   
                                            /*
                                            case "N2N":   //7.-9. razredi
                                            case "N2A":   //7.-9. razredi
                                            case "N2F":   //7.-9. razredi
                                            case "N2I":   //7.-9. razredi
                                            case "N2M":   //7.-9. razredi
                                            case "N2H":   //7.-9. razredi
                                            */
                                                $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                                break;
                                            default:
                                                $NPredmet=-1;
                                        }
                                        if ($NPredmet >= 0){
                                            /*
                                            //'2. tuj jezik - napis
                                            if ($VRazred1==4){
                                                if ($nazivpredmeta==1){
                                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                                    $poz=explode(",",$RS["tujj2n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }else{
                                                    $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                    $poz=explode(",",$RS["tujj2n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }
                                            }
                                            */
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }
                                                    break;
                                                case 1:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."neocenjeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["znaka"].": "."neocenjeno");
                                                    }
                                                    break;
                                                case 2:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."oproščeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": "."oproščeno");
                                                    }
                                            }
                                            $poz=explode(",",$RS["tuj2"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                if (strlen($txt) > 16){
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-2-$KorY);
                                                }else{
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                }
                                                $pdf->MultiCell(22,2.5,$txt,0,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["tuj2"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["tuj2"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                }
                                
                                //'Anglescina
                                $NPredmet=ToNPredmet("TJA");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["tuj1"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Anglescina - napis
                                if ($VRazred1==4){
                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                    $poz=explode(",",$RS["tujj1n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                
                                //'Likovna umetnost
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("LUM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("LVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["lum"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Glasbena umetnost
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("GUM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("GVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["gum"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Druzba
                                $NPredmet=ToNPredmet("DRU");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["dru"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Geografija
                                $NPredmet=ToNPredmet("GEO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["geo"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Zgodovina
                                $NPredmet=ToNPredmet("ZGO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["zgo"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Spoznavanje okolja
                                $NPredmet=ToNPredmet("SPO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["spo"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Naravoslovje
                                $NPredmet=ToNPredmet("NAR");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["nar"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Naravoslovje in tehnika
                                $NPredmet=ToNPredmet("NIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["nit"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Tehnika in tehnologija
                                $NPredmet=ToNPredmet("TIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["tit"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Gospodinjstvo
                                $NPredmet=ToNPredmet("GOS");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["gos"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Šport
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("ŠPO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("ŠVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["sport"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                
                                    // 1. izbirni predmeti
                                    if (isset($Izbirni[0]["oznaka"])){
                                        switch ($Izbirni[0]["oznaka"]){
                                            case "IA2":
                                            case "IN2":
                                            case "II2":
                                            case "IM2":
                                            case "IH2":
                                            case "INN":
                                            case "INA":
                                            case "N1N":
                                            case "N1A":
                                            /*
                                            case "NTE":
                                            case "NŠP":
                                            case "NRA":
                                            case "NUM":
                                            */
                                                $NPredmet=-1;
                                                break;
                                            default:       //če ni jezik
                                                $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                        }
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }
                                                    break;
                                                case 1:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."neocenjeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["znaka"].": "."neocenjeno");
                                                    }
                                                    break;
                                                case 2:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."oproščeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": "."oproščeno");
                                                    }
                                            }
                                            $poz=explode(",",$RS["izb1"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                if (strlen($txt) > 16){
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-2-$KorY);
                                                }else{
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                }
                                                //$pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                $pdf->MultiCell(22,2.5,$txt,0,$poz[2]);
                                            }
                                            /*
                                             //'napis predmeta
                                            if ($VRazred1==4){
                                                if ($nazivpredmeta==1){
                                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                                    $poz=explode(",",$RS["izb1n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }else{
                                                    $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                    $poz=explode(",",$RS["izb1n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }
                                            }
                                            */
                                       }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["izb1"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["izb1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                    // 2. izbirni predmeti
                                    //potrebno je preveriti prejšnja leta! - še
                                    if (isset($Izbirni[1]["oznaka"])){
                                        $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                        if ($NPredmet >= 0){
                                            switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                                case 0:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": ".ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                    }
                                                    break;
                                                case 1:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."neocenjeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["znaka"].": "."neocenjeno");
                                                    }
                                                    break;
                                                case 2:
                                                    if ($nazivpredmeta == 1){
                                                        $txt=ToWin($Ocene[$NPredmet]["opis"].": "."oproščeno");
                                                    }else{
                                                        $txt=ToWin($Ocene[$NPredmet]["oznaka"].": "."oproščeno");
                                                    }
                                            }
                                            $poz=explode(",",$RS["izb2"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                if (strlen($txt) > 16){
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-2-$KorY);
                                                }else{
                                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                }
                                                //$pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                $pdf->MultiCell(22,2.5,$txt,0,$poz[2]);
                                            }
                                            /*
                                             //'napis predmeta
                                            if ($VRazred1==4){
                                                if ($nazivpredmeta==1){
                                                    $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                                    $poz=explode(",",$RS["izb2n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }else{
                                                    $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                                    $poz=explode(",",$RS["izb2n"]);
                                                    if ($poz[0] > 0){
                                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                                        $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                                    }
                                                }
                                            }
                                            */
                                       }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["izb2"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                                $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["izb2"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-1)*21,$poz[1]-$KorY);
                                            $pdf->Cell(22,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                    
                                    /* rezultati NPZ - 2. triada (6. razred) */
                                    //'vpis podatkov o NPZ
                                    if ($VRazred1==6){
                                        $Npz=$oUcenec->getNPZ($VLeto);
                                        // SLJ
                                        if (isset($Npz[0]["oznaka"])){        
                                            if ($Npz[0]["tock"] > 0){
                                                $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                            }else{
                                                $txt="--------------";
                                            }    
                                            $poz=explode(",",$RS["npzsljt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["npzsljt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                        
                                        //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,168-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        // MAT
                                        if (isset($Npz[1]["oznaka"])){        
                                            if ($Npz[1]["tock"] > 0){
                                                $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                            }else{
                                                $txt="--------------";
                                            }    
                                            $poz=explode(",",$RS["npzmatt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["npzmatt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                        
                                        //angleščina
                                        if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                            if ($Npz[2]["tock"] > 0){
                                                $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            }else{
                                                $txt="--------------";
                                            }    
                                            $poz=explode(",",$RS["npz3t"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["npz3t"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(21,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                        
                                        //prazna vrstica za drugi tuji jezik
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,178-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za LUM
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,189-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za GUM
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,194-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za Družba
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,199-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za Geografija
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,205-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za Zgodovina
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,210-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za SPO
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,215-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za NAR
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,220-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za NIT
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,225-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za TIT
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,231-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za GOS
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,236-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za ŠPO
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,241-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za izbirni 1
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,246-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                        
                                        //prazna vrstica za izbirni 2
                                        $txt="--------------";
                                        $pdf->SetXY(180+$KorX,252-$KorY);
                                        $pdf->Cell(21,0,$txt,0,2,"C");
                                    }
                            }
                            break;    
                        case 7:
                        case 8:
                        case 9:
                            if (!$VGlava){
                                //' ime in priimek na vrhu lista
                                $pdf->SetFont('arial_CE','',6);
                                $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
                                $pdf->SetXY(1,3);
                                $pdf->Cell(0,0,$txt,0,2,"L");

                                //paralelka
                                $txt=ToWin($Razred["paralelka"]);
                                $poz=explode(",",$RS["oddelek"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                                // šolsko leto
                                $txt=ToWin(substr($Razred["leto"],2,2)."    ".substr($Razred["leto"]+1,2,2));
                                if ($VRazred1 < 9){
                                    $poz=explode(",",$RS["solleto"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }else{
                                    $poz=explode(",",$RS["solleto"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25+12,$poz[1]-$KorY);
                                        $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                // leto šolanja
                                $txt=ToWin($Razred["letosolanja"]);
                                $poz=explode(",",$RS["zapleto"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                }
                                //napredovanje
                                switch ($Razred["napredovanje"]){
                                    case 0:
                                    case 1:
                                        if ($VRazred1==9){
                                            $txt=ToWin("Zaključuje");
                                        }else{
                                            $txt=ToWin("Napreduje");
                                        }
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                        break;
                                    case 2:
                                        $txt=ToWin("ne napreduje");
                                        $poz=explode(",",$RS["napreduje_p1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                }
                                //opravičene in neopravičene
                                $Odsotnost=$oUcenec->getOdsotnost($VLeto);

                                $txt=ToWin($Odsotnost["opraviceno"]."/".$Odsotnost["neopraviceno"]);
                                $poz=explode(",",$RS["opravicene"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                //razrednik
                                $txt=ToWin($Razred["razrednik"]);
                                $poz=explode(",",$RS["razr"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                //ravnatelj
                                $txt=ToWin($VRavnatelj);
                                $poz=explode(",",$RS["ravn"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'delovodnik
                                $txt=ToWin($Razred["evidst"]);
                                $poz=explode(",",$RS["evst"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'datum spričevala
                                $txt=ToWin($Razred["datumizdaje"]);
                                $poz=explode(",",$RS["krajdat"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                $Ocene=$oUcenec->getOcene($VLeto);
                                $Predmeti=$oUcenec->getPredmeti($VLeto);
                                $Izbirni=$oUcenec->getIzbirni($VLeto);
                                
                                //Izpis redovalnice
                                //'slovenscina
                                $NPredmet=ToNPredmet("SLJ");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["slj"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                $txt="--------------";
                                $poz=explode(",",$RS["matjezik2"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                
                                //'matematika
                                $NPredmet=ToNPredmet("MAT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["mat"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Anglescina
                                $NPredmet=ToNPredmet("TJA");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["tuj1"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Anglescina - napis
                                if ($VRazred1==7){
                                    $txt=ToWin("Angleščina");
                                    $poz=explode(",",$RS["tujj1n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                /*
                                //'drugi tuji jezik
                                $NPredmet=ToNPredmet("TJA");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                */
                                $txt="--------------";
                                //}
                                $poz=explode(",",$RS["tuj2"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }
                                /*
                                //'drugi tuji jezik - napis
                                if ($VRazred1==7){
                                    $txt=ToWin("Angleščina");
                                    $pdf->SetXY(25+$KorX+($VRazred1-7)*25,65-$KorY);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                }
                                */
                                
                                //'Likovna umetnost
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("LUM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("LVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["lum"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Glasbena umetnost
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("GUM");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("GVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["gum"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Geografija
                                $NPredmet=ToNPredmet("GEO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["geo"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Zgodovina
                                $NPredmet=ToNPredmet("ZGO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["zgo"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Etika
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("DKE");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        if ($VRazred1 < 9){
                                            $txt="--------------";
                                        }else{
                                            $txt="";
                                        }
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("DDE");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["dke"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Fizika
                                $NPredmet=ToNPredmet("FIZ");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["fiz"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Kemija
                                $NPredmet=ToNPredmet("KEM");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["kem"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Biologija
                                $NPredmet=ToNPredmet("BIO");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    $txt="--------------";
                                }
                                $poz=explode(",",$RS["bio"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                if ($VRazred1 == 7){
                                    //'Naravoslovje
                                    $NPredmet=ToNPredmet("NAR");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                    $poz=explode(",",$RS["nar"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                    }
                                }

                                //'Tehnika in tehnologija
                                $NPredmet=ToNPredmet("TIT");
                                if ($NPredmet >= 0){
                                    switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                        case 0:
                                            $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                            break;
                                        case 1:
                                            $txt=ToWin("neocenjeno");
                                            break;
                                        case 2:
                                            $txt=ToWin("oproščeno");
                                    }
                                }else{
                                    if ($VRazred1 < 9){
                                        $txt="--------------";
                                    }else{
                                        $txt="";
                                    }
                                }
                                $poz=explode(",",$RS["tit"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                //'Šport
                                if ($VLeto >= 2013){
                                    $NPredmet=ToNPredmet("ŠPO");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }else{
                                    $NPredmet=ToNPredmet("ŠVZ");
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                    }else{
                                        $txt="--------------";
                                    }
                                }
                                $poz=explode(",",$RS["sport"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                // 1. izbirni predmeti
                                if (isset($Izbirni[0]["oznaka"])){
                                    $NPredmet=ToNPredmet($Izbirni[0]["oznaka"]);
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                        $poz=explode(",",$RS["izb1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                        //'napis predmeta
                                        if ($nazivpredmeta==1){
                                            $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                            $poz=explode(",",$RS["izb1n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->MultiCell(20,3,$txt,0,$poz[2]);
                                            }
                                        }else{
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $poz=explode(",",$RS["izb1n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                   }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["izb1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                         //'napis predmeta
                                        $poz=explode(",",$RS["izb1n"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            if ($nazivpredmeta==1){
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                            }else{
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            }
                                            $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                }else{
                                    $txt="--------------";
                                    $poz=explode(",",$RS["izb1"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                    }
                                     //'napis predmeta
                                    $poz=explode(",",$RS["izb1n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                            if ($nazivpredmeta==1){
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                            }else{
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            }
                                        $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                
                                // 2. izbirni predmeti
                                if (isset($Izbirni[1]["oznaka"])){
                                    $NPredmet=ToNPredmet($Izbirni[1]["oznaka"]);
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                        $poz=explode(",",$RS["izb2"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                         //'napis predmeta
                                        if ($nazivpredmeta==1){
                                            $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                            $poz=explode(",",$RS["izb2n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->MultiCell(20,3,$txt,0,$poz[2]);
                                            }
                                        }else{
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $poz=explode(",",$RS["izb2n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                   }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["izb2"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                         //'napis predmeta
                                        $poz=explode(",",$RS["izb2n"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            if ($nazivpredmeta==1){
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                            }else{
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            }
                                            $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                }else{
                                    $txt="--------------";
                                    $poz=explode(",",$RS["izb2"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                    }
                                     //'napis predmeta
                                    $poz=explode(",",$RS["izb2n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        if ($nazivpredmeta==1){
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                        }else{
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        }
                                        $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                // 3. izbirni predmeti
                                if (isset($Izbirni[2]["oznaka"])){
                                    $NPredmet=ToNPredmet($Izbirni[2]["oznaka"]);
                                    if ($NPredmet >= 0){
                                        switch ($Ocene[$NPredmet]["neocenjen"]){ 
                                            case 0:
                                                $txt=ToWin(ToPredmetUspeh($Ocene[$NPredmet]["koncna"]));
                                                break;
                                            case 1:
                                                $txt=ToWin("neocenjeno");
                                                break;
                                            case 2:
                                                $txt=ToWin("oproščeno");
                                        }
                                        $poz=explode(",",$RS["izb3"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                         //'napis predmeta
                                        if ($nazivpredmeta==1){
                                            $txt=ToWin($Ocene[$NPredmet]["opis"]);
                                            $poz=explode(",",$RS["izb3n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->MultiCell(20,3,$txt,0,$poz[2]);
                                            }
                                        }else{
                                            $txt=ToWin($Ocene[$NPredmet]["oznaka"]);
                                            $poz=explode(",",$RS["izb3n"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                                $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                            }
                                        }
                                   }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["izb3"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                        }
                                         //'napis predmeta
                                        if ($nazivpredmeta==1){
                                        }
                                        $poz=explode(",",$RS["izb3n"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            if ($nazivpredmeta==1){
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                            }else{
                                                $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                            }
                                            $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                        }
                                    }
                                }else{
                                    $txt="--------------";
                                    $poz=explode(",",$RS["izb3"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                    }
                                     //'napis predmeta
                                    $poz=explode(",",$RS["izb3n"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        if ($nazivpredmeta==1){
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY+3);
                                        }else{
                                            $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                        }
                                        $pdf->Cell(20,0,$txt,0,2,$poz[2]);
                                    }
                                }
                                
                                //štiri prazne vrstice pod izbirnimi predmeti
                                $txt=ToWin("--------------");
                                $poz=explode(",",$RS["izb4"]);
                                if ($poz[0] > 0){
                                    $pdf->SetFont('arial_CE','',$poz[3]);
                                    $pdf->SetXY($poz[0]+$KorX+($VRazred1-7)*25,$poz[1]-$KorY);
                                    $pdf->Cell(30,0,$txt,0,2,$poz[2]);
                                }

                                $txt=ToWin("--------------");
                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,185-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $txt=ToWin("--------------");
                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,191-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                $txt=ToWin("--------------");
                                $pdf->SetXY(48+$KorX+($VRazred1-7)*25,197-$KorY);
                                $pdf->Cell(30,0,$txt,0,2,"C");

                                //'vpis podatkov o NPZ
                                if ($VRazred1==9){
                                    $Npz=$oUcenec->getNPZ($VLeto);
                                    // SLJ
                                    if (isset($Npz[0]["oznaka"])){        
                                        if ($Npz[0]["tock"] > 0){
                                            $txt=$Npz[0]["tock"]." / ".$Npz[0]["procent"]." %";
                                            $poz=explode(",",$RS["npzsljt"]);
                                            $NpzXpoz=$poz[0];
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["npzsljt"]);
                                            $NpzXpoz=$poz[0];
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["npzsljt"]);
                                        $NpzXpoz=$poz[0];
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(0,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //prazna vrstica pod slovenščino (madžarščina/italijanščina)
                                    $txt="--------------";
                                    $pdf->SetXY(125+$KorX,53-$KorY);
                                    $pdf->Cell(25,0,$txt,0,2,"C");
                                    
                                    // MAT
                                    if (isset($Npz[1]["oznaka"])){        
                                        if ($Npz[1]["tock"] > 0){
                                            $txt=$Npz[1]["tock"]." / ".$Npz[1]["procent"]." %";
                                            $poz=explode(",",$RS["npzmatt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["npzmatt"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["npzmatt"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($poz[0]+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //angleščina
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TJA")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["tuj1"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["tuj1"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["tuj1"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //prazna vrstica za drugi tuji jezik
                                    $txt="--------------";
                                    $poz=explode(",",$RS["tuj2"]);
                                    if ($poz[0] > 0){
                                        $pdf->SetFont('arial_CE','',$poz[3]);
                                        $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                        $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                    }
                                    
                                    //likovna
                                    if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="LVZ")or ($Npz[2]["oznaka"]=="LUM"))){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["lum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                            $pdf->SetXY($NpzXpoz+$KorX,77-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,"C");
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["lum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["lum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Glasbena vzgoja
                                    if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="GVZ")or ($Npz[2]["oznaka"]=="GUM"))){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["gum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["gum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["gum"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    

                                    //'Geografija
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="GEO")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["geo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["geo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["geo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Zgodovina
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="ZGO")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["zgo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["zgo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["zgo"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Drzavljanska vzgoja in etika
                                    if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="DDE")or ($Npz[2]["oznaka"]=="DKE"))){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["dke"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["dke"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["dke"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Fizika
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="FIZ")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["fiz"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["fiz"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["fiz"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Kemija
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="KEM")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["kem"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["kem"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                            $poz=explode(",",$RS["kem"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                    }    
                                    
                                    //'Biologija
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="BIO")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["bio"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["bio"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["bio"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //'Naravoslovje
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="NAR")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["nar"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["nar"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["nar"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //'Tehnika in tehnologija
                                    if (isset($Npz[2]["oznaka"]) && ($Npz[2]["oznaka"]=="TIT")){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["tit"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["tit"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["tit"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    }    
                                    
                                    //'Sportna vzgoja
                                    if (isset($Npz[2]["oznaka"]) && (($Npz[2]["oznaka"]=="ŠVZ")or ($Npz[2]["oznaka"]=="ŠPO"))){        
                                        if ($Npz[2]["tock"] > 0){
                                            $txt=$Npz[2]["tock"]." / ".$Npz[2]["procent"]." %";
                                            $poz=explode(",",$RS["sport"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }else{
                                            $txt="--------------";
                                            $poz=explode(",",$RS["sport"]);
                                            if ($poz[0] > 0){
                                                $pdf->SetFont('arial_CE','',$poz[3]);
                                                $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                                $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                            }
                                        }    
                                    }else{
                                        $txt="--------------";
                                        $poz=explode(",",$RS["sport"]);
                                        if ($poz[0] > 0){
                                            $pdf->SetFont('arial_CE','',$poz[3]);
                                            $pdf->SetXY($NpzXpoz+$KorX,$poz[1]-$KorY);
                                            $pdf->Cell(25,0,$txt,0,2,$poz[2]);
                                        }
                                    } 
                                }   
                            }
                    }
                }
            }else{
                header("Location: izpisredovalnice.php");
            }
        }
        $pdf->Output("MaticniListi.pdf","D");
        break;
    default:  //izbor maticni list
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Matični listi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        /*
            //Korekcija tiska
            if (isset($_POST["id1"])){
                $Vid1=$_POST["id1"];
            }else{
                $Vid1=0;
            }
            if (isset($_SESSION["posx"])) {
                $KorX=$_SESSION["posx"];
            }else{
                $KorX=0;
            }
            if (isset($_SESSION["posy"])){
                $KorY=$_SESSION["posy"];
            }else{
                $KorY=0;
            }
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay=$_SESSION["DayToPrint"];
            }else{
                $PrintDay=$Danes->format('j.n.Y');
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix = $_SESSION["RefStFix"];
            }else{
                $RefStFix = "";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar = $_SESSION["RefStVar"];
            }else{
                $RefStVar = "";
            }
            if (isset($_SESSION["KorOpombe"])){
                $KorOpombe = $_SESSION["KorOpombe"];
            }else{
                $KorOpombe = "";
            }
            switch ($Vid1){
                case "1":
                    $KorX=$_POST["koordinatax"];
                    $KorY=$_POST["koordinatay"];
                    if (isset($_POST["RefStFix"])){
                        $RefStFix=$_POST["RefStFix"];
                    }
                    if (isset($_POST["RefStVar"])){
                        $RefStVar=$_POST["RefStVar"];
                    }
                    if (isset($_POST["datum"])){
                        $PrintDay=$_POST["datum"];
                    }
                    if (isset($_POST["KorOpombe"])){
                        $KorOpombe=$_POST["KorOpombe"];
                    }
                    $_SESSION["posx"]=$KorX;
                    $_SESSION["posy"]=$KorY;
                    $_SESSION["RefStFix"]=$RefStFix;
                    $_SESSION["RefStVar"]=$RefStVar;
                    $_SESSION["DayToPrint"]=$PrintDay;
                    $_SESSION["KorOpombe"]=$KorOpombe;
                    echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
                    break;
                default:    
                    if ($KorX==""){
                        $KorX=0;
                    }
                    if ($KorY==""){
                        $KorY=0;
                    }
                    if ($PrintDay=="") {
                        $PrintDay=$Danes->format('j.n.Y');
                    }
                    $_SESSION["posx"]=$KorX;
                    $_SESSION["posy"]=$KorY;
                    $_SESSION["RefStFix"]=$RefStFix;
                    $_SESSION["RefStVar"]=$RefStVar;
                    $_SESSION["DayToPrint"]=$PrintDay;
                    $_SESSION["KorOpombe"]=$KorOpombe;
            }
                    
            echo "<form name='rezultati' method=post action='maticnilisti.php'>";
            echo "<input name='id' type='hidden' value='4'>";
            echo "<h3>Korekcija tiskanja</h3>";
            echo "<table border='0'>";
            echo "<tr>";
            echo "    <td>";
            echo "        izpis višje(+)/nižje(-) mm:";
            echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
            echo "    </td>";
            echo "</tr>";
            echo "<tr>";
            echo "    <td>";
            echo "        izpis bolj desno(+)/levo(-) mm:";
            echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
            echo "    </td>";
            echo "</tr>";
            echo "<tr>";
            
            if (strstr($PrintDay,".")) { 
                $astr=explode(".",$PrintDay);
                $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
            }else{
                $Datum  = new DateTime($Danes->format('Y-m-d'));
            }
            echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
            echo "</tr>";
            echo "</table>";
            echo "<input name='id1' type='hidden' value='1'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            // konec korekcije tiskanja
        */
        /*
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
         
        echo "<a href='KorekcijaTiska.php'>Korekcija tiska (datum tiska in robovi)</a><br />";
        echo "Datum tiskanja: ".$PrintDay."<br />";
        if ($KorX != 0){
            echo "Korekcija tiskanja po širini je: ".$KorX."<br />";
        }
        if ($KorY != 0){
            echo "Korekcija tiskanja po višini je: ".$KorY."<br />";
        }
        */
        $SQL = "SELECT idrazred FROM tabrazred WHERE leto=".$VLeto." AND idUcitelj=".$Prijavljeni;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VidRazred=$R["idrazred"];
        }else{
            if (isset($_SESSION["razred"])){
                $VidRazred=$_SESSION["razred"];
            }else{
                $VidRazred=0;
            }
        }

        echo "<form name='MaticniListi' method='post' action='maticnilisti.php'>";
        echo "<input name='idd' type='hidden' value='100'>";
        echo "<h2>Izberite razred</h2>";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto: " .  $VLeto  . "/" . ($VLeto+1). "<input type='hidden' name='solskoleto' value='".$VLeto."'></td>";
        echo "</tr>";
        if ($VLeto < 2008){
            echo "<tr>";
            echo "<td>8-/9-letka:<select name='vrstaos'>";
            echo "<option value='9' selected>devetletka</option>";
            echo "<option value='8'>osemletka</option>";
            echo "</select>";
            echo "</td>";
            echo "</tr>";
        }else{
            echo "<input name='vrstaos' type='hidden' value='9'>";
        }
        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred<select name='razred'>";
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VidRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                }
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($R["id"]==$VidRazred){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
            }
        }
        echo "</select></td></tr>";
        echo "<tr><td>";
        echo "<input name='maticnilist' type='radio' value='3'>Matični list obrazec 1.931 2005<br />";
        //echo "<input name='maticnilist' type='radio' value='4'>Matični list obrazec 1.931 2006<br />";
        echo "<input name='maticnilist' type='radio' value='6'>Matični list obrazec 1.931 2008<br />";
        //echo "<input name='maticnilist' type='radio' value='7'>Matični list obrazec 1.931 2013<br />";
        echo "<input name='maticnilist' type='radio' value='8' checked='checked'>Matični listi - izbor iz tabele<br />";
        echo "</td></tr>";
        echo "<tr><td><input name='glava' type='checkbox' checked='checked'>Izpis samo ocen</td></tr>";
        if (isset($_SESSION["nazivpredmeta"])){
            if ($_SESSION["nazivpredmeta"]=="on"){
                echo "<tr><td><input name='nazivpredmeta' type='checkbox' checked='checked'>Ime izb. predmeta v celoti izpisano</td></tr>";
            }else{
                echo "<tr><td><input name='nazivpredmeta' type='checkbox'>Ime izb. predmeta v celoti izpisano</td></tr>";
            }
        }else{
            echo "<tr><td><input name='nazivpredmeta' type='checkbox'>Ime izb. predmeta v celoti izpisano</td></tr>";
        }
        echo "</table><br />";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
}
?>