<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pregled
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
    if (!CheckDostop("DelKontr",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        //$VLetoPregled=$VLeto;
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }

        switch ($Vid){
	        case "1":
                if (isset($_POST["rubrika"])){
                    $Rubrika=$_POST["rubrika"];
                }else{
                    if (isset($_GET["rubrika"])){
                        $Rubrika=$_GET["rubrika"];
                    }else{
                        $Rubrika=0;
                    }
                }
                if (isset($_POST["izpis"])){
                    $Izpis=$_POST["izpis"];
                }else{
                    if (isset($_GET["izpis"])){
                        $Izpis=$_GET["izpis"];
                    }else{
                        $Izpis="";
                    }
                }
                    
		        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.*,tabucitelji.priimek,tabucitelji.ime,tabpregleddelan.id AS pid,tabpregleddelan.Komentar AS pkomentar FROM (tabpregleddelan ";
		        $SQL = $SQL . "INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos) ";
		        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.ucitelj=tabucitelji.idUcitelj ";
		        $SQL = $SQL . "WHERE tabpregleddelan.leto=".$VLetoPregled." AND tabucitelji.status > 0 AND TabDoprinos.idDoprinos =".$Rubrika;
		        $SQL = $SQL ." ORDER BY priimek,ime,datum DESC";
		        $result = mysqli_query($link,$SQL);
		        
		        if ($R = mysqli_fetch_array($result)){
			        echo "<h2>Pregled rubrike: ".$R["OblikaDela"]."</h2>";
		        }
                echo "<a href='PregledRubrik.php?letopregled=".($VLetoPregled-1)."&rubrika=$Rubrika&id=$Vid&izpis=$Izpis'>".($VLetoPregled-1)."</a> | <a href='PregledRubrik.php?letopregled=".($VLetoPregled+1)."&rubrika=$Rubrika&id=$Vid&izpis=$Izpis'>".($VLetoPregled+1)."</a><br /><br />";
		        echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.asp'>";
		        echo "<input name='submit' type='submit' value='Briši'><br />";
		        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
		        if (isset($_POST["izpis"] )) {
			        echo "<tr bgcolor='cyan'><th></th><th>Št.</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
		        }else{
			        echo "<tr bgcolor='cyan'><th>Ime</th><th>Količina</th></tr>";
		        }

		        $Indx=1;
		        $UComp="";
		        $Vsota=0;
		        $Ime="";
                $Prejsnji="";
                $result = mysqli_query($link,$SQL);
		        while ($R = mysqli_fetch_array($result)){
				    $Ime=$R["priimek"]." ".$R["ime"];
				    if ($R["Ucitelj"] != $UComp ) {
					    if ($UComp != "" ) {
						    if ($Izpis != "") {
							    echo "<tr><td colspan='4'>Skupaj</td><td align='right'>".$Vsota."</td></tr>";
						    }else{
							    echo "<tr><td>".$Prejsnji."</td><td align='right'>".$Vsota."</td></tr>";
                                $Prejsnji=$Ime;
						    }
                        }else{
                            $Prejsnji=$Ime;
                        }
                        $Indx=1;
                        $UComp=$R["Ucitelj"];
                        $Vsota=0;
				    }
				    if ($Izpis != "") {
					    switch ($R["aktivno"]) {
						    case 1:
							    if ($R["EnotPotrjeno"] ) {
								    if ($R["Rubrika"]==28 ) {
									    echo "<tr bgcolor='red'>";
								    }else{
									    echo "<tr bgcolor='lightgreen'>";
								    }
							    }else{
								    if ($R["Rubrika"]==28 ) {
									    echo "<tr bgcolor='red'>";
								    }else{
									    echo "<tr bgcolor='lightyellow'>";
								    }
							    }
                                break;
						    default:
								    if ($R["Rubrika"]==28 ) {
									    echo "<tr bgcolor='red'>";
								    }else{
									    echo "<tr bgcolor='lightcyan'>";
								    }
                        }
					    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
					    echo "<td>".$Indx."</td>";
                        $Datum=new DateTime($R["Datum"]);
					    echo "<td>".$Datum->format('d.m.Y')."</td>";
					    echo "<td>".$R["OblikaDela"]."</td>";
					    if ($R["uramin"] > 1 ) {
						    echo "<td>".$R["Enot"]." min</td>";
					    }else{
						    if ($R["koeficient"]==8 or $R["koeficient"]==0 ) {
							    echo "<td>".$R["Enot"]." dni</td>";
						    }else{
							    echo "<td>".$R["Enot"]." ur</td>";
						    }
					    }
					    echo "<td>".$R["pkomentar"]."</td>";
					    if ($R["EnotPotrjeno"] ) {
						    echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["Ucitelj"]."'>da</a></td>";
					    }else{
						    echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=1&Ucitelj=".$R["Ucitelj"]."'>ne</a></td>";
					    }
					    echo "<td><a href='izpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."'>Popravi</a></td>";
					    echo "<td><input name='id' value='".$R["pid"]."' type='checkbox'></td>";
					    echo "</tr>";
				    }
				    $Vsota=$Vsota+$R["Enot"];
			        $Indx=$Indx+1;
		        }
		        if ($UComp != "" ) {
			        if ($Izpis != "") {
				        echo "<tr><td colspan='4'>Skupaj</td><td align='right'>".$Vsota."</td></tr>";
			        }else{
				        echo "<tr><td>".$Ime."</td><td align='right'>".$Vsota."</td></tr>";
			        }
		        }
		        echo "</table><br>";
		        echo "<input name='submit' type='submit' value='Briši'>";
		        echo "</form><br />";
	        default:
                echo "<br />";
                echo "<a href='PregledRubrik.php?letopregled=".($VLetoPregled-1)."'>".($VLetoPregled-1)."</a> | <a href='PregledRubrik.php?letopregled=".($VLetoPregled+1)."'>".($VLetoPregled+1)."</a><br /><br />";
		        echo "<form accept-charset='utf-8' name='PregledRubrik' method=post action='PregledRubrik.php'>";
		        echo "<select name='rubrika'>";
		        
		        $SQL = "SELECT * FROM TabDoprinos WHERE aktivno > 0 ORDER BY sortiranje";
		        $result = mysqli_query($link,$SQL);
		        
		        while ($R = mysqli_fetch_array($result)){
				        echo "<option value='".$R["idDoprinos"]."'>".$R["OblikaDela"]."</option>";
		        }
		        
		        echo "</select><br />";
		        echo "<input name='izpis' type='checkbox' checked='checked'>Izpis vseh zapisov<br />";
		        echo "<input name='submit' type='submit' value='Pošlji'>";
		        echo "<input name='id' type='hidden' value='1'>";
                echo "<input name='letopregled' type='hidden' value='$VLetoPregled'>";
		        echo "</form><br />";
		        
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br>

</body>
</html>
