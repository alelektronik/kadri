<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izobraževanja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("SolskoLeto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    if ($VLevel > 1){
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    }else{
        echo "Nimate potrebnih pooblastil za ogled strani!";
        header("Location: nepooblascen.htm");
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = 0;
        }
    }
}

switch ( $Vid ){
    case "1": //vpis novih izobraževanj
        $VZapisov=$_POST["Zapisov"];
        $VIzobrazevanje=$_POST["Izobrazevanje"];
        $VKraj=$_POST["Kraj"];
        $VDatumOd=$_POST["DatumOd"];
        if (!isDate($VDatumOd)){
            $VDatumOd=$Danes->format('j.n.Y');
        }                        
        $VDatumDo=$_POST["DatumDo"];
        if (!isDate($VDatumDo)){
            $VDatumDo=$Danes->format('j.n.Y');
        }                        
        $VIzvajalec=$_POST["Izvajalec"];
        $VNaslov=$_POST["Naslov"];
        $VTrajanje=$_POST["Trajanje"];
        $VTocke=$_POST["Tocke"];
        $VKotizacija=$_POST["Kotizacija"];
        if (strlen($VKotizacija) > 0){
            $VKotizacija=str_replace(",",".",$VKotizacija);
        }
        if (!is_numeric($VKotizacija)){
            $VKotizacija=0;
        }
        $VOstStroski=str_replace(",",".",$_POST["OstStroski"]);
        if (!is_numeric($VOstStroski)){
            $VOstStroski=0;
        }
        if ($VLevel > 1 ){  //potrjeno
            if (isset($_POST["Priporocam"])){
                $VPriporocam="true";
            }else{
                $VPriporocam="false";
            }
        }else{
            $VPriporocam="false";
        }
        if (isset($_POST["Porocilo"])){
            $VPorocilo=$_POST["Porocilo"];
        }else{
            $VPorocilo="";
        }
        for ($Indx=1;$Indx <= $VZapisov;$Indx++){
            if (isset($_POST["udel_".$Indx])){
                $Ucitelj=$_POST["uc_".$Indx];
                $SQL = "SELECT tabizobrazevanje.*,tabucitelji.priimek,tabucitelji.ime FROM tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.idUcitelj=tabucitelji.idUcitelj ";
                $SQL = $SQL . " WHERE leto=".$VLeto;
                $SQL = $SQL ." AND tabizobrazevanje.idUcitelj=".$Ucitelj;
                $SQL = $SQL ." AND Izobrazevanje='".$VIzobrazevanje."'";
                $SQL = $SQL ." AND tabizobrazevanje.Kraj='".$VKraj."'";
                $SQL = $SQL ." AND DatumOd='".$VDatumOd."'";
                $SQL = $SQL ." AND DatumDo='".$VDatumDo."'";
                $SQL = $SQL ." AND Izvajalec='".$VIzvajalec."'";
                $SQL = $SQL ." AND tabizobrazevanje.Naslov='".$VNaslov."'";
                $SQL = $SQL ." AND Trajanje='".$VTrajanje."'";
                $SQL = $SQL ." AND Tocke='".$VTocke."'";
                
        //'        response.write $SQL."<br>"
                $result = mysqli_query($link,$SQL);
                
                if (mysqli_num_rows($result) > 0){
                    echo "<h2>Podatki so bili že vpisani!</h2>";
                }else{
                    $SQL="INSERT INTO tabizobrazevanje (leto,idUcitelj,Izobrazevanje,Kraj,DatumOd,DatumDo,Izvajalec,Naslov,Trajanje,Tocke,Kotizacija,OstStroski,priporocam,porocilo,vpisal,cas) ";
                    $SQL = $SQL . "VALUES (";
                    $SQL = $SQL .$VLeto.",".$Ucitelj.",";
                    $SQL = $SQL ."'".$VIzobrazevanje."',";
                    $SQL = $SQL ."'".$VKraj."',";
                    $SQL = $SQL ."'".$VDatumOd."',";
                    $SQL = $SQL ."'".$VDatumDo."',";
                    $SQL = $SQL ."'".$VIzvajalec."',";
                    $SQL = $SQL ."'".$VNaslov."',";
                    $SQL = $SQL ."'".$VTrajanje."',";
                    $SQL = $SQL ."'".$VTocke."',";
                    $SQL = $SQL .$VKotizacija.",";
                    $SQL = $SQL .$VOstStroski.",";
                    $SQL = $SQL .$VPriporocam.",";
                    $SQL = $SQL ."'".$VPorocilo."',";
                    $SQL = $SQL ."'".$VUporabnik."',";
                    $SQL = $SQL ."'".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL .")";
                    $result = mysqli_query($link,$SQL);

                    echo "<h2>Podatki so vpisani!</h2>";
                    
                    $VTipID=17;
                    $SQL = "SELECT * FROM tabzapisniktip WHERE id=".$VTipID;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VTipNaslov=$R["tip"];
                    }
                    
                    if ($Opravila==1 ){
                        $SQL = "SELECT tabdeldogodek.id FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='".$VTipNaslov."' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
        }
}

switch ($Vid){
	case "1";
		echo "<a href='VnosIzobrazevanje.php'>Vnos izobraževanja</a><br />";
        break;
	default:
        echo "<a href='VnosIzobrazevanje.php?id=7'>Spisek poročil o izvedenih izobraževanjih</a><br />";
        echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='VnosSkupIzobrazevanje.php'>";
        echo "<h2>Napoved strokovnega izobraževanja delavcev</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";

        echo "<tr><th>Izobraževanje</th><td><input name='Izobrazevanje' type='text' size='30'></td></tr>";
        echo "<tr><th>Izvajalec</th><td><input name='Izvajalec' type='text' size='20'></td></tr>";
        echo "<tr><th>Naslov izvajalca</th><td><input name='Naslov' type='text' size='30'></td></tr>";
        echo "<tr><th>Kraj izvedbe</th><td><input name='Kraj' type='text' size='20' ></td></tr>";
        echo "<tr><th>Datum in čas od</th><td><input name='DatumOd' type='text' size='10'></td></tr>";
        echo "<tr><th>Datum in čas do</th><td><input name='DatumDo' type='text' size='10'></td></tr>";
        echo "<tr><th>Trajanje</th><td><input name='Trajanje' type='text' size='5'></td></tr>";
        echo "<tr><th>Točke</th><td><input name='Tocke' type='text' size='3' ></td></tr>";
        echo "<tr><th>Kotizacija EUR</th><td><input name='Kotizacija' type='text' size='6' ></td></tr>";
        echo "<tr><th>Ostali<br />stroški EUR</th><td><input name='OstStroski' type='text' size='6'></td></tr>";
        echo "<tr><th>Odobreno</th><td><input name='Priporocam' type='checkbox'></td></tr>";
        echo "</table><br />";


		echo "<table border='1' cellspacing='0'>";
		echo "<tr><th>Delavec</th><th>Udeležba</th><tr>";

		$SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		$result = mysqli_query($link,$SQL);
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td><input type='hidden' name='uc_".$indx."' value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
			echo "<td><input type='checkbox' name='udel_".$indx."'></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		
		echo "<input name='Zapisov' type='hidden' value='".($indx-1)."'>";
        echo "<input name='SolskoLeto' type='hidden' value='".$VLeto."'>";
        echo "<input name='id' type='hidden' value='1'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "<br />";
}
?>

</body>
</html>
