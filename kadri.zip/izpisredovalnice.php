<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Redovalnica
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
    };
</script>
<style>
.break { page-break-before: always; }
</style>
<script>
 function pokazi_sliko(str)
 {
     var slika=document.getElementById('slika')
 
     slika.src="img/"+str;
     return;
 }
 </script>
</head>
<body>

<?php
function ClearBlank($x){
    if (strlen($x) > 0){
        $x=str_replace("&nbsp;","",$x);
    }
    return $x;
}
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["iducitelj"];
    $VIdRazrednik=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }
    if (isset($_POST["razred"])){
        $VRazred = $_POST["razred"];
    }else{
        if (isset($_GET["razred"])){
            $VRazred=$_GET["razred"];
        }else{
            if (isset($_SESSION["razred"])){
                $VRazred=$_SESSION["razred"];
            }else{
                $VRazred = 0;
            }
        }
    }
    switch ($Vid){
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        case "3":
            break;
        case "3a":
        case "3b":
            echo "<a href='izpisredovalnice.php?tip=rocna'>Nazaj na izbor redovalnice</a><br />";
            break;
        default:
            if ($Vid != 0){
                //echo "<a href='izpisredovalnice.php'>Nazaj na izbor redovalnice</a><br />";
                
                echo "<form name='rezultati1' method='post' action='izpisredovalnice.php'>";
                echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<input name='vrstaos' type='hidden' value='9'>";
                if ($VLevel < 2){
                    $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
                    $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                    $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
                }else{
                    $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
                    $SQL .= " ORDER BY idsola,razred,oznaka";
                }
                $result = mysqli_query($link,$SQL);

                echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
                echo "<option value='0'>Ni izbran</option>";
                $Indx=1;
                if ($VecSol > 0){
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }else{
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }
                echo "</select>";
                if (isset($_GET["tip"])){
                    if ($_GET["tip"] == "rocna"){
                        echo "<input name='id' type='hidden' value='2'>";
                    }else{
                        echo "<input name='id' type='hidden' value='4'>";
                    }
                }else{
                    if (isset($_GET["id"])){
                        echo "<input name='id' type='hidden' value='".$_GET["id"]."'>";
                    }else{
                        if (isset($_POST["id"])){
                            echo "<input name='id' type='hidden' value='".$_POST["id"]."'>";
                        }else{
                            echo "<input name='id' type='hidden' value='4'>";
                        }
                    }
                }
                //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                //echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
            
    }
    if ($VRazred > 0 or $Vid==0){
        switch ($Vid){
            case "1": //pregled zaključnih ocen
                $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime, TabUcenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.datroj FROM ";
                $SQL = $SQL . "((tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                $SQL = $SQL . "INNER JOIN TabUcenci ON tabrazred.IdUcenec=TabUcenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
                $SQL = $SQL . " ORDER BY TabUcenci.Priimek, TabUcenci.Ime";

                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VDevetletka=$R["osemdevet"];
                    If ($VDevetletka == 8 ){
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) .", Razred: " . $VRazred1 . ". " . $VParalelka . " -  osemletke<br />";
                    }else{
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
                    }
                    $Ucitelj = $R["upriimek"]  . ", " . $R["uime"];
                    $IdUcitelj = $R["IdUcitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj = $R["IdVzgojitelj"];

                    echo "Učitelj: " . $Ucitelj . "<br />";
                    if ($VRazred1 < 6){
                        echo "Drugi učitelj/učitelj PB: " . $Vzgojitelj . "<br />";
                    }
                }

                //$ucenci[30,3)
                //0-idUcenec, 1-Priimek in ime, 2-razred, 3-datum rojstva
                //StUcencev

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0]=$R["IdUcenec"];
                    $ucenci[$Indx][1]=$R["ucpriimek"].", ".$R["ucime"];
                    $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                    $ucenci[$Indx][3]=new DateTime(isDate($R["datroj"]));
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                $_SESSION["leto"]=$VLeto;
                $_SESSION["razred"]=$VRazred;
                $_SESSION["ucitelj"]=$IdUcitelj;
                $_SESSION["vzgojitelj"]=$IdVzgojitelj;

                //Predmeti(50,1)
                //stevilcne ocene: 0-idpredmet,1-oznaka predmeta
                //StPredmetov
                $SQL = "SELECT DISTINCT TabPredmeti.Oznaka,TabPredmeti.Prioriteta,TabPredmeti.VrstniRed,TabUcenje.Predmet,TabUcenje.Razred,TabUcenje.Paralelka,TabUcenje.Leto FROM ";
                $SQL = $SQL . "TabPredmeti INNER JOIN TabUcenje ON TabPredmeti.Id=TabUcenje.Predmet ";
                $SQL = $SQL . "WHERE idRazred=".$VRazred." AND  Prioriteta< 3 ORDER BY TabPredmeti.VrstniRed";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["Predmet"];
                    $Predmeti[$StPredmetov][1]=$R["Oznaka"];
                    $StPredmetov=$StPredmetov+1;
                    $Indx=$Indx+1;
                }
                echo "<br /><a href='tiskanje_navodilo.htm'>Navodilo za tiskanje PDF dokumentov</a><br />";
                echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika</a><br />";
                echo "<a href='vnesiocene.php?id=7&razred=".$VRazred."&solskoleto=".$VLeto."'>Priprava podatkov za končno spričevalo</a><br />";
                echo "<a href='izborrazreda.php?id=odsotnost&razred=".$VRazred."&solskoleto=".$VLeto."'>Vnos izostankov</a><br />";
                echo "<a href='vnosispiski.php?idd=121&razred=".$VRazred."'>Izpis izostankov</a><br />";
                echo "<a href='VnosRealizacije.php?SolskoLeto=".$VLeto."&razred=".$VRazred."'>Vnos realizacije in dnevov dejavnosti</a><br />";
                echo "<a href='PedPorocilo.php'>Pedagoška poročila</a><br />";
                //echo "<a href='izpisidokumentov.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Seznam izdanih dokumentov</a><br /><br />";
                echo "Izpisi:<br />";
                echo "<a href='obvestilaouspehu.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o uspehu za cel razred (1. ocenjevalno obdobje) PDF</a><br />";
                if ($VRazred1 > 2 ){
				    echo "<a href='obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis spričeval (zaključno, razredno, obvestilo o ocenah)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=2&razred=".$VRazred."&solskoleto=".$VLeto."'>Spričevala za cel razred (PDF)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=3&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o zaključnih ocenah za cel razred (PDF)</a><br />";
                }
                if ($VRazred1 == 6 ){
                    echo "<a href='npz.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o desežkih pri NPZ ob koncu 2. triade (PDF)</a><br />";
                }
                /*if ($VRazred1 > 8 ){
                    echo "<a href='obvestilaouspehu.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Zaključna spričevala za cel razred (PDF)</a><br />";
                }
			    */
                echo "<a href='krozkiobvestilartf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o obiskovanju ID in udeležbah na tekmovanjih</a><br />";
                if ($VRazred1 ==1 ){
                    echo "<a href='maticnilistipdf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Matični listi za cel razred (PDF)</a><br />";
                }
                if ($VRazred1 < 3 ){
                    echo "<a href='izboropredovalnice.php'>Opisna redovalnica</a><br />";
                }

                echo "<br /><table border=1 cellspacing=0 bgcolor='cyan'>";
                echo "<th>Št.</th><th>Učenec</th><th>Razred</th>";
                for ($Indx0=0;$Indx0 < $StPredmetov;$Indx0++){
                    echo "<th>".$Predmeti[$Indx0][1]."</th>";
                }
                echo "<th>Uspeh</th>";

                $ColorChange=true;
                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    if ($ColorChange ){
                        echo "<tr bgcolor='lightyellow'>";
                    }else{
                        echo "<tr bgcolor='#FFFFCC'>";
                    }
                    $ColorChange=!$ColorChange;
                    echo "<td>".($IndxUc+1)."</td>";
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$ucenci[$IndxUc][0]."#redovalnica'>".$ucenci[$IndxUc][1]."</a></td><td>".$ucenci[$IndxUc][2]."</td>";
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][0]="";
                        $Ocene[$Indx1][1]="";
                        $Ocene[$Indx1][2]="";
                        $Ocene[$Indx1][3]="";
                        $Ocene[$Indx1][4]=" ";
                        $Ocene[$Indx1][5]="";
                        $Ocene[$Indx1][6]=0;
                    }

                    $SQL = "SELECT  * FROM TabOcene WHERE IdUcenec=".$ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["IdPredmet"]==$Predmeti[$Indx1][0] ){
                                $Ocene[$Indx1][0]="&nbsp;".$R["OcenaS1P"];
                                $Ocene[$Indx1][1]="&nbsp;".$R["OcenaS1U"];
                                $Ocene[$Indx1][2]="&nbsp;".$R["OcenaS2P"];
                                $Ocene[$Indx1][3]="&nbsp;".$R["OcenaS2U"];
                                $Ocene[$Indx1][4]="&nbsp;".$R["OcenaKoncna"];
                                $Ocene[$Indx1][5]="&nbsp;".$R["OcenaPolletna"];
                                $Ocene[$Indx1][6]=$R["Neocenjen"];
                            }
                        }
                        $Indx=$Indx+1;
                    }

                    $SQL = "SELECT  * FROM tabrazred WHERE IdUcenec=".$ucenci[$IndxUc][0]." AND idRazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Uspeh[$IndxUc]=$R["Uspeh"];
                        $Indx=$Indx+1;
                    }

                    for ($Indx1=0;$Indx1 < $StPredmetov;$Indx1++){
                        if (is_numeric(strpos($Ocene[$Indx1][4],"1"))){
                            echo "<td align='center' bgcolor='salmon'>".$Ocene[$Indx1][4]."</td>";
                        }else{
                            if (strlen(ClearBlank($Ocene[$Indx1][4])) > 0 ){
                                echo "<td align='center'>".$Ocene[$Indx1][4]."</td>";
                            }else{
                                switch($Ocene[$Indx1][6]) {
                                    case 0:
                                        echo "<td align='center' bgcolor='orange'>".$Ocene[$Indx1][4]."</td>";
                                        break;
                                    case 1:
                                        echo "<td align='center' bgcolor='salmon'>N</td>";
                                        break;
                                    case 2:
                                        echo "<td align='center' bgcolor='salmon'>O</td>";
                                        break;
                                }
                            }
                        }
                    }
                    if ($Uspeh[$IndxUc] > 4.5 ){
                        echo "<td align='center' bgcolor='lightgreen'><font color=red>".number_format($Uspeh[$IndxUc],2)."</font></td>";
                    }else{
                        echo "<td align='center'><font color=red>".number_format($Uspeh[$IndxUc],2)."</font></td>";
                    }
                    echo "</tr>";
                    
                }

                echo "</table><br />";

                echo "<a href='obvestilaouspehu.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o uspehu za cel razred (1. ocenjevalno obdobje) PDF</a><br />";
                if ($VRazred1 > 2 ){
				    echo "<a href='obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis spričeval (zaključno, razredno, obvestilo o ocenah)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=2&razred=".$VRazred."&solskoleto=".$VLeto."'>Spričevala za cel razred (PDF)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=3&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o zaključnih ocenah za cel razred (PDF)</a><br />";
                }
                if ($VRazred1 == 6 ){
                    echo "<a href='obvestilonpz6pdf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o desežkih pri NPZ ob koncu 2. triade (PDF)</a><br />";
                }
                /*
			    if ($VRazred1 > 8 ){
                    echo "<a href='obvestilaouspehu.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Zaključna spričevala za cel razred (PDF)</a><br />";
                }
			    */
                echo "<a href='krozkiobvestilartf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o obiskovanju ID in udeležbah na tekmovanjih</a><br />";
                if ($VRazred1 ==1 ){
                    echo "<a href='maticnilistipdf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Matični listi za cel razred (PDF)</a><br />";
                }
                if ($VRazred1 < 3 ){
                    echo "<a href='izboropredovalnice.php'>Opisna redovalnica</a><br />";
                }
                echo "<a href='PedPorocilo.php'>Pedagoška poročila</a><br />";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na redovalnico</a><br />";
            
                break;
            case "2": //izpis ročne redovalnice
                $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime, TabUcenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.datroj FROM ";
                //$SQL = "SELECT tabrazred.*, tabucitelji.Priimek, tabucitelji.Ime, tabvzgojitelji.Priimek, tabvzgojitelji.Ime, TabUcenci.*,tabrazdat.* FROM "
                $SQL = $SQL . "((tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                $SQL = $SQL . "INNER JOIN TabUcenci ON tabrazred.IdUcenec=TabUcenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred ;
                $SQL = $SQL . " ORDER BY TabUcenci.Priimek, TabUcenci.Ime";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VDevetletka=$R["osemdevet"];
                    If ($VDevetletka == 8 ){
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) .", Razred: " . $VRazred1 . ". " . $VParalelka . " -  osemletke<br />";
                    }else{
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
                    }
                    $Ucitelj = $R["upriimek"]  . ", " . $R["uime"];
                    $IdUcitelj = $R["IdUcitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj = $R["IdVzgojitelj"];

                    echo "Učitelj: " . $Ucitelj . "<br />";
                    if ($VRazred1 < 6){
                        echo "Drugi učitelj/učitelj PB: " . $Vzgojitelj . "<br />";
                    }
                }

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0]=$R["IdUcenec"];
                    $ucenci[$Indx][1]=$R["ucpriimek"].", ".$R["ucime"];
                    $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                    $ucenci[$Indx][3]=new DateTime(isDate($R["datroj"]));
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                $_SESSION["leto"]=$VLeto;
                $_SESSION["razred"]=$VRazred;
                $_SESSION["ucitelj"]=$IdUcitelj;
                $_SESSION["vzgojitelj"]=$IdVzgojitelj;

                //Predmeti(50,1)
                //stevilcne ocene: 0-idpredmet,1-oznaka predmeta
                //StPredmetov
                $SQL = "SELECT DISTINCT TabPredmeti.Oznaka,TabPredmeti.Prioriteta,TabPredmeti.VrstniRed,TabUcenje.Predmet,TabUcenje.Razred,TabUcenje.Paralelka,TabUcenje.Leto FROM ";
                $SQL = $SQL . "TabPredmeti INNER JOIN TabUcenje ON TabPredmeti.Id=TabUcenje.Predmet ";
                $SQL = $SQL . "WHERE idRazred=".$VRazred." AND  Prioriteta< 3 ORDER BY TabPredmeti.VrstniRed";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["Predmet"];
                    $Predmeti[$StPredmetov][1]=$R["Oznaka"];
                    $StPredmetov=$StPredmetov+1;
                    $Indx=$Indx+1;
                }
                echo "<table>";
                echo "<tr><th>5 uč./stran</th><th>1 uč./stran</th><th>posebna</th>";
                for ($Indx0=0;$Indx0 < $StPredmetov;$Indx0++){
                    echo "<tr>";
                    echo "<td>";
                    echo "<a href='izpisredovalnice.php?id=3&predmet=".$Predmeti[$Indx0][0]."&razred=".$VRazred."' onmouseover=pokazi_sliko('5nastran.jpg')>".$Predmeti[$Indx0][1]."</a>";
                    echo "</td><td>";
                    echo "<a href='izpisredovalnice.php?id=3a&predmet=".$Predmeti[$Indx0][0]."&razred=".$VRazred."' onmouseover=pokazi_sliko('1nastran.jpg')>".$Predmeti[$Indx0][1]."</a>";
                    echo "</td><td>";
                    echo "<a href='izpisredovalnice.php?id=3b&predmet=".$Predmeti[$Indx0][0]."&razred=".$VRazred."' onmouseover=pokazi_sliko('posebna.jpg')>".$Predmeti[$Indx0][1]."</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<img src='' alt='' id='slika' />";
                break;
            case "3": //predmetna redovalnica
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM TabPredmeti WHERE id=".$_GET["predmet"];
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                if ($R = mysqli_fetch_array($result)){
                    $VPredmeti[0] = $R["Id"];
                    $VPredmeti[1] = $R["Oznaka"];
                    $VPredmeti[2] = $R["Opis"];
                    $VPredmeti[3] = $R["Prioriteta"];
                }

                if ($VPredmeti[3]==0 ){ 
                    echo "<h2>Razred: ".$VRazred1.". ".$VParalelka.", predmet: ".$VPredmeti[1]." - ".$VPredmeti[2]."</h2>";
                }else{
                    echo "<h2>Predmet: ".$VPredmeti[1]." - ".$VPredmeti[2]."</h2>";
                }


                if ($VPredmeti[3]==1 ){
                    $SQL = "SELECT tabpredmeti.*, tabizbirni.*,tabucenci.*,tabucenci.iducenec AS ucid,tabrazred.*,tabrazdat.* FROM ";
                    $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.Id=".$VPredmeti[0];
                    $SQL = $SQL ." ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = "SELECT tabrazred.*, tabucenci.*,tabucenci.iducenec AS ucid,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                    $SQL = $SQL ." ORDER BY priimek,ime";
                }

                $result = mysqli_query($link,$SQL);
                //Izpis razrednih podatkov

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0] = $R["ucid"];
                    $ucenci[$Indx][1] = $R["Priimek"].", ".$R["Ime"];
                    if ($VPredmeti[3]==1 ){
                        $ucenci[$Indx][2] = $R["razred"];
                        $ucenci[$Indx][3] = $R["oznaka"];
                        $ucenci[$Indx][4] = $R["slika"];
                    }else{
                        $ucenci[$Indx][2] = $VRazred1;
                        $ucenci[$Indx][3] = $VParalelka;
                        $ucenci[$Indx][4] = $R["slika"];
                    }
                    $ucenci[$Indx][5]=$R["IdUcitelj"];
                    $Indx = $Indx+1;
                } 
                $StUcencev=$Indx-1;

                echo "<div class='break'></div>";
                //Izpis predmetnih podatkov
                //'za redne predmete
                if (($VPredmeti[3]==0) or ($VPredmeti[3]==2) ){    
                    echo "<table border='1'>";
                    echo "<th>".$VRazred1.". ".$VParalelka."</th><th width='100'>Učenec</th><th width='250'>1. semester</th><th width='250'>2. semester</th>";
                    $i1=1;
                    for ($IndxUcenec = 0;$IndxUcenec <= $StUcencev;$IndxUcenec++){
                        //zacetek predmeta i
                        if ($ucenci[$IndxUcenec][0] > 0 ){    
                            echo "<tr height='180'>";
                            echo "<td valign='middle'>".$i1."</td>";
                            echo "<td valign='middle'>";
                            if (strlen($ucenci[$IndxUcenec][4]) > 0){
                                if (file_exists($ucenci[$IndxUcenec][4])){
                                    echo "<img src='".$ucenci[$IndxUcenec][4]."' width='100'>";
                                }
                            }
                            echo "<br />".$ucenci[$IndxUcenec][1]."</td>";
                            echo "<td valign='middle'>&nbsp;</td><td valign='middle'>&nbsp;</td>";
                            echo "</tr>";
                            if ($i1 % 5 == 0 ){
                                echo "</table>";
                                echo "<h2 class='break'>Razred: ".$VRazred1.". ".$VParalelka.", predmet: ".$VPredmeti[1]." - ".$VPredmeti[2]."</h2>";
                                echo "<table border='1'>";
                                echo "<th>".$VRazred1.". ".$VParalelka."</th><th width='100'>Učenec</th><th width='250'>1. semester</th><th width='250'>2. semester</th>";
                            }
                            $i1=$i1+1;
                        }
                    }
                    echo "</table>";
                }

                //konec predmeta i

                //'za izbirne predmete
                if ($VPredmeti[3]==1 ){    
                    echo "<table border='1'>";
                    echo "<th>".$VPredmeti[1]."</th><th width='100'>Učenec</th><th width='250'>1. semester</th><th width='250'>2. semester</th>";
                    $i1=1;
                    for ($IndxUcenec = 0;$IndxUcenec <= $StUcencev;$IndxUcenec++){
                        //zacetek predmeta i
                        if ($ucenci[$IndxUcenec][0] > 0 ){    
                            echo "<tr height='180'>";
                            echo "<td valign='middle'>".$i1."</td>";
                            echo "<td valign='middle'>";
                            if (strlen($ucenci[$IndxUcenec][4]) > 0){
                                if (file_exists($ucenci[$IndxUcenec][4])){
                                    echo "<img src='".$ucenci[$IndxUcenec][4]."' width='100'>";
                                }
                            }
                            echo "<br />".$ucenci[$IndxUcenec][1]." (".$ucenci[$IndxUcenec][2].". ".$ucenci[$IndxUcenec][3].")</td>";
                            echo "<td valign='middle'>&nbsp;</td><td valign='middle'>&nbsp;</td>";
                            echo "</tr>";
                            if ($i1 % 5 == 0 ){
                                echo "</table>";
                                echo "<h2 class='break'>Predmet: ".$VPredmeti[1]." - ".$VPredmeti[2]."</h2>";
                                echo "<table border='1'>";
                                echo "<th>".$VPredmeti[1]."</th><th width='100'>Učenec</th><th width='250'>1. semester</th><th width='250'>2. semester</th>";
                            }
                            $i1=$i1+1;
                        }
                    }
                    echo "</table>";

                    //konec predmeta i
                }
                
                break;
            case "3a": //predmetna redovalnica
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM TabPredmeti WHERE id=".$_GET["predmet"];
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                if ($R = mysqli_fetch_array($result)){
                    $VPredmeti[0] = $R["Id"];
                    $VPredmeti[1] = $R["Oznaka"];
                    $VPredmeti[2] = $R["Opis"];
                    $VPredmeti[3] = $R["Prioriteta"];
                }

                if ($VPredmeti[3]==1 ){
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.iducenec AS ucid,tabrazred.iducitelj,tabrazred.slika,tabrazdat.razred,tabrazdat.oznaka FROM ";
                    $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.Id=".$VPredmeti[0];
                    $SQL = $SQL ." ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = "SELECT tabrazred.iducitelj,tabrazred.slika, tabucenci.priimek,tabucenci.ime,tabucenci.iducenec AS ucid,tabrazdat.razred,tabrazdat.oznaka FROM ";
                    $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                    $SQL = $SQL ." ORDER BY priimek,ime";
                }

                $result = mysqli_query($link,$SQL);
                //Izpis razrednih podatkov

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0] = $R["ucid"];
                    $ucenci[$Indx][1] = $R["priimek"]." ".$R["ime"];
                    if ($VPredmeti[3]==1 ){
                        $ucenci[$Indx][2] = $R["razred"];
                        $ucenci[$Indx][3] = $R["oznaka"];
                        $ucenci[$Indx][4] = $R["slika"];
                    }else{
                        $ucenci[$Indx][2] = $VRazred1;
                        $ucenci[$Indx][3] = $VParalelka;
                        $ucenci[$Indx][4] = $R["slika"];
                    }
                    $ucenci[$Indx][5]=$R["iducitelj"];
                    $Indx = $Indx+1;
                } 
                $StUcencev=$Indx-1;

                //Izpis predmetnih podatkov
                //'za redne predmete
                $i1=1;
                for ($IndxUcenec = 0;$IndxUcenec <= $StUcencev;$IndxUcenec++){
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj=".$ucenci[$IndxUcenec][5];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $Razrednik=$R1["ime"]." ".$R1["priimek"];
                    }else{
                        $Razrednik="";
                    }
                    
                    //glava: razrednik, učenec, slika učenca, razred
                    echo "<div class='break'></div>";
                    echo "<h2>".$VPredmeti[1]." - ".$VPredmeti[2]."</h2>";

                    echo "<table border='1' width='745'>";
                    echo "<tr height='80'>";
                    echo "<td width='100'>".$Razrednik."</td>";
                    //zacetek predmeta i
                    if ($ucenci[$IndxUcenec][0] > 0 ){    
                        echo "<td width='400' align='center' valign='middle'><h1>".$ucenci[$IndxUcenec][1]."</h1></td>";
                        echo "<td align='center' valign='middle'>";
                        if (strlen($ucenci[$IndxUcenec][4]) > 0){
                            if (file_exists($ucenci[$IndxUcenec][4])){
                                echo "<img src='".$ucenci[$IndxUcenec][4]."' height='80'>";
                            }
                        }
                        echo "</td>";
                        echo "<td align='center' valign='middle' width='100'><h3>".$ucenci[$IndxUcenec][2].". ".$ucenci[$IndxUcenec][3]." (".$i1.")</h3></td>";
                    }
                    echo "</tr>";
                    echo "</table>";
                    
                    echo "<br />";
                    //prvi semester
                    echo "<table border='1' cellpadding='10'>";
                    echo "<tr height='200'><td rowspan='2' valign='top' width='80'>Pisno<br /><br />I. semester<br /><br />1.<br /><br /><br /><br /><br /><br />2.<br /><br /><br /><br /><br /><br />3.<br /><br /><br /><br /><br /><br /></td><td width='300' valign='top'>1. Datum:__________________ Ocena: ________</td><td width='300' valign='top'>3. Datum:__________________ Ocena: ________</td></tr>";
                    echo "<tr height='200'><td width='300' valign='top'>2. Datum:__________________ Ocena: ________</td><td width='300' valign='top'>4. Datum:__________________ Ocena: ________</td></tr>";
                    echo "<tr></tr>";
                    echo "</table>";
                    
                    echo "<br />";
                    //drugi semester
                    echo "<table border='1' cellpadding='10'>";
                    echo "<tr height='200'><td rowspan='2' valign='top' width='80'>Pisno<br /><br />II. semester<br /><br />1.<br /><br /><br /><br /><br /><br />2.<br /><br /><br /><br /><br /><br />3.<br /><br /><br /><br /><br /><br /></td><td width='300' valign='top'>1. Datum:__________________ Ocena: ________</td><td width='300' valign='top'>3. Datum:__________________ Ocena: ________</td></tr>";
                    echo "<tr height='200'><td width='300' valign='top'>2. Datum:__________________ Ocena: ________</td><td width='300' valign='top'>4. Datum:__________________ Ocena: ________</td></tr>";
                    echo "<tr></tr>";
                    echo "</table>";
                    
                    echo "<br />";
                    echo "<table class='hide' width='745'>";
                    echo "<tr class='hide'>";
                    echo "<td class='hide' width='500'>Stik s starši - opombe:</td>";
                    echo "<td class='hide'>Nivo:</td>";
                    echo "</tr>";
                    echo "</table>";
                    
                    $i1=$i1+1;
                }

                //konec predmeta i
                break;
            case "3b": //predmetna redovalnica, posebna - Smrekar
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM TabPredmeti WHERE id=".$_GET["predmet"];
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                if ($R = mysqli_fetch_array($result)){
                    $VPredmeti[0] = $R["Id"];
                    $VPredmeti[1] = $R["Oznaka"];
                    $VPredmeti[2] = $R["Opis"];
                    $VPredmeti[3] = $R["Prioriteta"];
                }

                if ($VPredmeti[3]==1 ){
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.iducenec AS ucid,tabrazred.iducitelj,tabrazred.slika,tabrazdat.razred,tabrazdat.oznaka FROM ";
                    $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.Id=".$VPredmeti[0];
                    $SQL = $SQL ." ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = "SELECT tabrazred.iducitelj,tabrazred.slika, tabucenci.priimek,tabucenci.ime,tabucenci.iducenec AS ucid,tabrazdat.razred,tabrazdat.oznaka FROM ";
                    $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                    $SQL = $SQL ." ORDER BY priimek,ime";
                }

                $result = mysqli_query($link,$SQL);
                //Izpis razrednih podatkov

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0] = $R["ucid"];
                    $ucenci[$Indx][1] = $R["ime"]." ".$R["priimek"];
                    if ($VPredmeti[3]==1 ){
                        $ucenci[$Indx][2] = $R["razred"];
                        $ucenci[$Indx][3] = $R["oznaka"];
                        $ucenci[$Indx][4] = $R["slika"];
                    }else{
                        $ucenci[$Indx][2] = $VRazred1;
                        $ucenci[$Indx][3] = $VParalelka;
                        $ucenci[$Indx][4] = $R["slika"];
                    }
                    $ucenci[$Indx][5]=$R["iducitelj"];
                    $Indx = $Indx+1;
                } 
                $StUcencev=$Indx-1;

                echo "<div class='break'></div>";
                //Izpis predmetnih podatkov
                //'za redne predmete
                $i1=1;
                for ($IndxUcenec = 0;$IndxUcenec <= $StUcencev;$IndxUcenec++){
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj=".$ucenci[$IndxUcenec][5];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $Razrednik=$R1["ime"]." ".$R1["priimek"];
                    }else{
                        $Razrednik="";
                    }
                    
                    //glava: razred, zap. številka, učenec
                    if ($i1 % 2 == 1){
                        echo "<div>".$VPredmeti[1]." - ".$VPredmeti[2]."</div>";
                    }

                    echo "<table class='velpis' border='1' width='745'>";
                    echo "<tr>";
                    //echo "<td width='100'>".$Razrednik."</td>";
                    //zacetek predmeta i
                    if ($ucenci[$IndxUcenec][0] > 0 ){    
                        echo "<td align='center' height='50' valign='middle' width='100'><h1>".$ucenci[$IndxUcenec][2].". ".$ucenci[$IndxUcenec][3]."</h1></td>";
                        echo "<td align='center' valign='middle' width='100'><h1>".$i1.".</h1></td>";
                        echo "<td width='400' align='center' valign='middle' colspan='7'><h1>".$ucenci[$IndxUcenec][1]."</h1></td>";
                    }
                    echo "</tr>";
                    //echo "</table>";
                    
                    //echo "<br />";
                    //2. vrstica: slika, ocene, ref./plak., naloge, potreb., ostalo, skupaj
                    echo "<tr>";
                    if ($ucenci[$IndxUcenec][0] > 0 ){    
                        echo "<td align='center' valign='middle' rowspan='3' width='100'>";
                        if (strlen($ucenci[$IndxUcenec][4]) > 0){
                            if (file_exists($ucenci[$IndxUcenec][4])){
                                echo "<img src='".$ucenci[$IndxUcenec][4]."' height='80'>";
                            }
                        }
                        echo "</td>";
                    }else{
                        echo "<td rowspan='3' width='100'>&nbsp;</td>";
                    }
                    echo "<td valign='top' rowspan='3' width='100'>Ocene</td>";
                    echo "<td valign='top' rowspan='3' width='100'>Ref./ plakat (%)</td>";
                    echo "<td valign='top' rowspan='3' width='100'>Naloge (%)</td>";
                    echo "<td valign='top' rowspan='3' width='100'>Potrebščine (%)</td>";
                    echo "<td valign='top' rowspan='3' width='100'>Ostalo (%)</td>";
                    echo "<td valign='top' rowspan='3' colspan='2' width='100'>Skupaj (%) +/-</td>";
                    echo "<td height='40' valign='top' width='100'>Pov. oc.</td>";
                    echo "</tr>";
                    echo "<tr>";
                    echo "<td height='40' valign='top' width='100'>Sk. pov.</td>";
                    echo "</tr>";
                    echo "<tr>";
                    echo "<td height='40' valign='top' width='100'>Kon. oc.</td>";
                    echo "</tr>";
                    
                    //1. konferenca
                    echo "<tr>";
                    echo "<td width='100' align='center' valign='middle' rowspan='3'>1. konferenca</td>";
                    echo "<td width='100' valign='top' rowspan='3'>J<br /><br /><br /><br /><br /><br />J</td>";
                    echo "<td width='100' valign='top' rowspan='3'>-0,10</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='50' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='50' valign='top' rowspan='6'>&nbsp;</td>";
                    echo "<td width='100' valign='top' rowspan='2'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr></tr>";
                    echo "<tr>";
                    echo "<td width='100' valign='top' rowspan='2'>&nbsp;</td>";
                    echo "</tr>";
                    //2. konferenca
                    echo "<tr>";
                    echo "<td width='100' align='center' valign='middle' rowspan='3'>2. konferenca</td>";
                    echo "<td width='100' valign='top' rowspan='3'>J<br /><br /><br /><br /><br /><br />J</td>";
                    echo "<td width='100' valign='top' rowspan='3'>-0,10</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='100' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "<td width='50' valign='top' rowspan='3'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr>";
                    echo "<td width='100' valign='top' rowspan='2'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr></tr>";
                    
                    //opombe
                    echo "<tr>";
                    echo "<td width='100' align='center' valign='middle' height='60'>Opombe</td>";
                    echo "<td valign='middle' colspan='8'></td>";
                    echo "</tr>";
                    echo "</table>";
                    echo "<br />";
                    
                    if ($i1 % 2 == 0){
                        echo "<div class='break'></div>";
                        //echo "<hr>";
                    }
                    
                    $i1=$i1+1;
                }

                //konec predmeta i
                break;
            case "4": //redna redovalnica
			    /*
                if (isset($_SESSION["posx"])){
                    $KorX = $_SESSION["posx"];
                }else{
                    $KorX = 0;
                }
                if (isset($_SESSION["posy"])){
                    $KorY = $_SESSION["posy"];
                }else{
                    $KorY = 0;
                }
                if (isset($_SESSION["DayToPrint"])){
                    $PrintDay = $_SESSION["DayToPrint"];
                }else{
                    $PrintDay = $Danes->format('j. n. Y');
                }
                if (isset($_SESSION["KorOpombe"])){
                    $KorOpombe = $_SESSION["KorOpombe"];
                }else{
                    $KorOpombe="";
                }
                if (isset($_SESSION["RefStFix"])){
                    $RefStFix=$_SESSION["RefStFix"];
                }else{
                    $RefStFix="";
                }
                if (isset($_SESSION["RefStVar"])){
                    $RefStVar=$_SESSION["RefStVar"];
                }else{
                    $RefStVar=0;
                }
                $_SESSION["leto"] = $VLeto;
                $_SESSION["posx"] = $KorX;
                $_SESSION["posy"] = $KorY;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
			    */
			    //Korekcija tiska
			    if (isset($_POST["id1"])){
				    $Vid1=$_POST["id1"];
			    }else{
				    $Vid1=0;
			    }
			    if (isset($_SESSION["posx"])) {
				    $KorX=$_SESSION["posx"];
			    }else{
				    $KorX=0;
			    }
			    if (isset($_SESSION["posy"])){
				    $KorY=$_SESSION["posy"];
			    }else{
				    $KorY=0;
			    }
			    if (isset($_SESSION["DayToPrint"])){
				    $PrintDay=$_SESSION["DayToPrint"];
			    }else{
				    $PrintDay=$Danes->format('j.n.Y');
			    }
			    if (isset($_SESSION["RefStFix"])){
				    $RefStFix = $_SESSION["RefStFix"];
			    }else{
				    $RefStFix = "";
			    }
			    if (isset($_SESSION["RefStVar"])){
				    $RefStVar = $_SESSION["RefStVar"];
			    }else{
				    $RefStVar = "";
			    }
			    if (isset($_SESSION["KorOpombe"])){
				    $KorOpombe = $_SESSION["KorOpombe"];
			    }else{
				    $KorOpombe = "";
			    }
			    switch ($Vid1){
				    case "1":
					    $KorX=$_POST["koordinatax"];
					    $KorY=$_POST["koordinatay"];
					    if (isset($_POST["RefStFix"])){
						    $RefStFix=$_POST["RefStFix"];
					    }
					    if (isset($_POST["RefStVar"])){
						    $RefStVar=$_POST["RefStVar"];
					    }
					    if (isset($_POST["datum"])){
						    $PrintDay=$_POST["datum"];
					    }
					    if (isset($_POST["KorOpombe"])){
						    $KorOpombe=$_POST["KorOpombe"];
					    }
					    $_SESSION["posx"]=$KorX;
					    $_SESSION["posy"]=$KorY;
					    $_SESSION["RefStFix"]=$RefStFix;
					    $_SESSION["RefStVar"]=$RefStVar;
					    $_SESSION["DayToPrint"]=$PrintDay;
					    $_SESSION["KorOpombe"]=$KorOpombe;
					    echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
					    break;
				    default:    
					    if ($KorX==""){
						    $KorX=0;
					    }
					    if ($KorY==""){
						    $KorY=0;
					    }
					    if ($PrintDay=="") {
						    $PrintDay=$Danes->format('j.n.Y');
					    }
					    $_SESSION["posx"]=$KorX;
					    $_SESSION["posy"]=$KorY;
					    $_SESSION["RefStFix"]=$RefStFix;
					    $_SESSION["RefStVar"]=$RefStVar;
					    $_SESSION["DayToPrint"]=$PrintDay;
					    $_SESSION["KorOpombe"]=$KorOpombe;
			    }
					    
			    echo "<form name='rezultati' method=post action='izpisredovalnice.php'>";
			    echo "<input name='id' type='hidden' value='4'>";
			    echo "<h3>Korekcija tiskanja</h3>";
			    echo "<table border='0'>";
			    echo "<tr>";
			    echo "    <td>";
			    echo "        izpis višje(+)/nižje(-) mm:";
			    echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
			    echo "    </td>";
			    echo "</tr>";
			    echo "<tr>";
			    echo "    <td>";
			    echo "        izpis bolj desno(+)/levo(-) mm:";
			    echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
			    echo "    </td>";
			    echo "</tr>";
			    echo "<tr>";
			    
			    if (strstr($PrintDay,".")) { 
				    $astr=explode(".",$PrintDay);
				    $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
			    }else{
				    $Datum  = new DateTime($Danes->format('Y-m-d'));
			    }
			    echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat01'></td>";
			    echo "</tr>";
			    echo "<tr>";
			    echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
			    echo "</tr>";
			    echo "<tr>";
			    echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
			    echo "</tr>";
			    /*
			    echo "<tr>";
			    echo "        <td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
			    echo "</tr>";
			    */
			    echo "</table>";
			    echo "<input name='id1' type='hidden' value='1'>";
			    echo "<input name='razred' type='hidden' value='".$VRazred."'>";
			    echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
			    echo "<input name='submit' type='submit' value='Pošlji'>";
			    echo "</form>";
			    // konec korekcije tiskanja
			    
			    
                $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime, TabUcenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.datroj FROM ";
                //$SQL = "SELECT tabrazred.*, tabucitelji.Priimek, tabucitelji.Ime, tabvzgojitelji.Priimek, tabvzgojitelji.Ime, tabucenci.*,tabrazdat.* FROM ";
                $SQL = $SQL . "((tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred ;
                $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VDevetletka=$R["osemdevet"];
                    If ($VDevetletka == 8 ){
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) .", Razred: " . $VRazred1 . ". " . $VParalelka . " -  osemletke<br />";
                    }else{
                        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
                    }
                    $Ucitelj = $R["upriimek"]  . ", " . $R["uime"];
                    $IdUcitelj = $R["IdUcitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj = $R["IdVzgojitelj"];

                    echo "Učitelj: " . $Ucitelj . "<br />";
                    if ($VRazred1 < 6){
                        echo "Drugi učitelj/učitelj PB: " . $Vzgojitelj . "<br />";
                    }
                }

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0]=$R["IdUcenec"];
                    $ucenci[$Indx][1]=$R["ucpriimek"].", ".$R["ucime"];
                    $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                    $ucenci[$Indx][3]=new DateTime(isDate($R["datroj"]));
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                $_SESSION["leto"]=$VLeto;
                $_SESSION["razred"]=$VRazred;
                $_SESSION["ucitelj"]=$IdUcitelj;
                $_SESSION["vzgojitelj"]=$IdVzgojitelj;

                //Predmeti(50,1)
                //stevilcne ocene: 0-idpredmet,1-oznaka predmeta
                //StPredmetov
                $SQL = "SELECT DISTINCT TabPredmeti.Oznaka,TabPredmeti.Prioriteta,TabPredmeti.VrstniRed,TabUcenje.Predmet,TabUcenje.Razred,TabUcenje.Paralelka,TabUcenje.Leto FROM ";
                $SQL = $SQL . "TabPredmeti INNER JOIN TabUcenje ON TabPredmeti.Id=TabUcenje.Predmet ";
                $SQL = $SQL . "WHERE idRazred=".$VRazred." AND  Prioriteta< 3 ORDER BY TabPredmeti.VrstniRed";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["Predmet"];
                    $Predmeti[$StPredmetov][1]=$R["Oznaka"];
                    $StPredmetov=$StPredmetov+1;
                }

                //predmet, ocena

                echo "<h2><a href='izpisrazreda.php?id=6&leto=".$VLeto."&razred=".$VRazred."&paralelka=".$VParalelka."'>Pošiljanje elektronskih sporočil staršem</a></h2>";
    /*
                if (($KorX != 0) or ($KorY != 0) ){
                    echo "<br />Zamik tiskanja je: ".$KorX." mm po širini (+ bolj desno/- bolj levo) in ".$KorY." mm po višini (+ bolj gor/- bolj dol).";
                }
                if (strlen($PrintDay) > 0) {
                    echo "<br />Datum dokumenta je: ".$PrintDay;
                }
                if ((strlen($RefStFix) > 0) or ($RefStVar > 0) ){
                    echo "<br />Referenčna številka (fiksni del) je: ".$RefStFix;
                    echo "<br />Referenčna številka (spremenljivi del) je: ".$RefStVar;
                }
                if (strlen($KorOpombe) > 0) {
                    echo "<br />Opombe (za spričevalo): ".$KorOpombe;
                }
    */
                echo "<br /><a href='tiskanje_navodilo.htm'>Navodilo za tiskanje PDF dokumentov</a><br />";
    //            echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika in <b>sprememba datuma tiskanja</b></a><br /><br />";
                echo "Vnosi:<br />";
                echo "<a href='vnesiocene.php?id=7&razred=".$VRazred."&solskoleto=".$VLeto."'><b>Priprava podatkov za končno spričevalo</b></a><br />";
                echo "<a href='izborrazreda.php?id=odsotnost&razred=".$VRazred."&solskoleto=".$VLeto."'>Vnos izostankov</a><br />";
                echo "<a href='vnosispiski.php?idd=121&razred=".$VRazred."'>Izpis izostankov</a><br />";
                echo "<a href='VnosRealizacije.php?SolskoLeto=".$VLeto."&razred=".$VRazred."'>Vnos realizacije in dnevov dejavnosti</a><br />";
                echo "<a href='PedPorocilo.php'>Pedagoška poročila</a><br />";
                //echo "<a href='izpisidokumentov.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Seznam izdanih dokumentov</a><br /><br />";
                echo "Izpisi:<br />";
                echo "<a href='obvestilaouspehu.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o uspehu za cel razred (1. ocenjevalno obdobje) PDF</a><br />";
                /*
                if ($VRazred1 > 2 ){
                    echo "<a href='obvestilaouspehu.php?id=2&razred=".$VRazred."&solskoleto=".$VLeto."'>Spričevala za cel razred (PDF)</a><br />";
                    echo "<a href='obvestilaouspehu.php?id=3&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o zaključnih ocenah za cel razred (PDF)</a><br />";
                }
                */
                if ($VRazred1 == 6 ){
                    echo "<a href='npz.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o desežkih pri NPZ ob koncu 2. triade (PDF)</a><br />";
                }
                /*
                if ($VRazred1 > 8 ){
                    echo "<a href='obvestilaouspehu.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Zaključna spričevala za cel razred (PDF)</a><br />";
                }
                */
                echo "<a href='krozkiobvestilartf.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestila o obiskovanju ID in udeležbah na tekmovanjih</a><br />";
                if ($VRazred1 ==1 ){
                    echo "<a href='maticnilisti.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Matični listi</a><br />";
                }
                if ($VRazred1 < 3 ){
                    echo "<a href='izboropredovalnice.php'>Opisna redovalnica</a><br />";
                    echo "<a href='vnesiocene.php?razred=".$VRazred."&solskoleto=".$VLeto."&id=12'>Vsem zaključi 5</a><br />";
                }
                
                echo "<a href='obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis spričeval (zaključno, razredno, obvestilo o ocenah)</a><br />";
                
                echo "<br /><h2><a href='izpisredovalnice.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Redovalnica zaključnih ocen (za preverjanje, če so vse vpisane)</a></h2><br />";
                echo "Za vnos ocen kliknite na učenca in potem v njegovi redovalnici lahko izberete vnašanje za vse predmete, vnašanje za vse učence pri istem predmetu (primerno za izbirne) ali po posameznih predmetih.<br />";
                echo "<table border=1 cellspacing=0 bgcolor='cyan'>";
                echo "<th>Št.</th><th>Ucenec</th><th>Razred</th><th>Vnos<br />ocen</th><th>Vnos<br />spričevala</th>";
                for ($Indx0=0;$Indx0 < $StPredmetov;$Indx0++){
                    echo "<th><a href='vnesiocene.php?id=5&predmet=".$Predmeti[$Indx0][0]."&razred=".$VRazred."&solskoleto=".$VLeto."'>".$Predmeti[$Indx0][1]."</a></th>";
                }

                $ColorChange=true;
                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    if ($ColorChange ){
                        echo "<tr bgcolor='lightyellow'>";
                    }else{
                        echo "<tr bgcolor='#FFFFCC'>";
                    }
                    echo "<td>".($IndxUc+1)."</td>";
                    echo "  <td width='100'><a href='ucenec_pregled.php?ucenec=".$ucenci[$IndxUc][0]."#redovalnica'>".$ucenci[$IndxUc][1]."</a></td>";
                    echo "  <td width='40'>".$ucenci[$IndxUc][2]."</td>";
                    echo "  <td><a href='vnesiocene.php?id=1&iducenec=".$ucenci[$IndxUc][0]."&solskoleto=".$VLeto."'>Ocene</a></td>";
                    echo "  <td><a href='vnesiocene.php?id=3&iducenec=".$ucenci[$IndxUc][0]."&solskoleto=".$VLeto."'>Spričevalo</a></td>";
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][0]="&nbsp;";
                        $Ocene[$Indx1][1]="&nbsp;";
                        $Ocene[$Indx1][2]="&nbsp;";
                        $Ocene[$Indx1][3]="&nbsp;";
                        $Ocene[$Indx1][4]="&nbsp;";
                        $Ocene[$Indx1][5]="&nbsp;";
                    }

                    $SQL = "SELECT  * FROM TabOcene WHERE IdUcenec=".$ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["IdPredmet"]==$Predmeti[$Indx1][0] ){
                                $Ocene[$Indx1][0]="&nbsp;".$R["OcenaS1P"];
                                $Ocene[$Indx1][1]="&nbsp;".$R["OcenaS1U"];
                                $Ocene[$Indx1][2]="&nbsp;".$R["OcenaS2P"];
                                $Ocene[$Indx1][3]="&nbsp;".$R["OcenaS2U"];
                                $Ocene[$Indx1][4]="&nbsp;".$R["OcenaKoncna"];
                                $Ocene[$Indx1][5]="&nbsp;".$R["OcenaPolletna"];
                            }
                        }
                        $Indx=$Indx+1;
                    }

                    for ($Indx1=0;$Indx1 < $StPredmetov;$Indx1++){
                        echo "<td width='120'>";
                        if ($ColorChange ){
                            echo " <table bgcolor='lightyellow' border=1 cellspacing=0 width='88'>";
                        }else{
                            echo " <table bgcolor='#FFFFCC' border=1 cellspacing=0 width='88'>";
                        }
                        if ($ColorChange ){
                            echo "<tr bgcolor='lightyellow'>";
                        }else{
                            echo "<tr bgcolor='#FFFFCC'>";
                        }
                        echo "         <td width='35'><font color='blue'>".$Ocene[$Indx1][0]."</font></td>"; //    '1. polletje pisno
                        echo "         <td width='35'><font color='magenta'>".$Ocene[$Indx1][1]."</font></td>"; //    '1. polletje ustno
                        echo "         <td width='15'><font color='green'>".$Ocene[$Indx1][5]."</font></td>"; //    '1. polletje
                        echo "       </tr>";
                        if ($ColorChange ){
                            echo "<tr bgcolor='lightyellow'>";
                        }else{
                            echo "<tr bgcolor='#FFFFCC'>";
                        }
                        echo "         <td width='35'><font color='blue'>".$Ocene[$Indx1][2]."</font></td>"; //    '2. polletje pisno
                        echo "         <td width='35'><font color='magenta'>".$Ocene[$Indx1][3]."</font></td>"; //    '2. polletje ustno
                        echo "         <td width='15'><font color='red'>".$Ocene[$Indx1][4]."</font></td>"; //    'zakljucena ocena
                        echo "       </tr>";
                        echo " </table>";
                        echo "</td>";
                    }
                    echo "</tr>";

                    $ColorChange=!$ColorChange;
                }

                echo "</table>";
                echo "<a href='obvestilaouspehu.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o uspehu za cel razred (1. ocenjevalno obdobje) PDF</a><br />";
                if ($VRazred1 > 2 ){
				    echo "<a href='obvestilaouspehu.php?id=10&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis spričeval (zaključno, razredno, obvestilo o ocenah)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=2&razred=".$VRazred."&solskoleto=".$VLeto."'>Spričevala za cel razred (PDF)</a><br />";
                    //echo "<a href='obvestilaouspehu.php?id=3&razred=".$VRazred."&solskoleto=".$VLeto."'>Obvestilo o zaključnih ocenah za cel razred (PDF)</a><br />";
                }
                echo "<a href='PedPorocilo.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Pedagoška poročila</a><br />";
                break;
            default: //izbor redovalnice
                $SQL = "SELECT idrazred,paralelka FROM tabrazred WHERE leto=".$VLeto." AND idUcitelj=".$VIdRazrednik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred=$R["idrazred"];
                    $VParalelka=$R["paralelka"];
                }else{
                    $VRazred=0;
                    $VParalelka="A";
                }
                echo "<form name='rezultati' method='post' action='izpisredovalnice.php'>";
                echo "<h2>Izberite razred</h2><br />";
                echo "<table border=0>";
                echo "<tr>";
                echo "<td>";
                echo "Šolsko leto:</td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "</td>";
                echo "</tr>";
                if ($VLeto < 2008 ){
                    echo "<tr>";
                    echo "<td>8-/9-letka:<select name='vrstaos'>";
                    echo "<option value='9' selected>devetletka</option>";
                    echo "<option value='8'>osemletka</option>";
                    echo "</select>";
                    echo "</td>";
                    echo "</tr>";
                    echo "<tr>";
                }else{
                    echo "<input name='vrstaos' type='hidden' value='9'>";
                }
                if ($VLevel < 2){
                    $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
                    $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                    $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
                }else{
                    $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
                    $SQL .= " ORDER BY idsola,razred,oznaka";
                }
                $result = mysqli_query($link,$SQL);

                echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
                echo "<option value='0'>Ni izbran</option>";
                $Indx=1;
                if ($VecSol > 0){
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }else{
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }
                echo "</select>";
                echo "</td>";
                echo "</tr>";
                echo "</table><br />";
                if (isset($_GET["tip"])){
                    if ($_GET["tip"] == "rocna"){
                        echo "<input name='id' type='hidden' value='2'>";
                    }else{
                        echo "<input name='id' type='hidden' value='4'>";
                    }
                }else{
                    echo "<input name='id' type='hidden' value='4'>";
                }
                echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                //echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
        }
    }
}
?>

</body>
</html>
