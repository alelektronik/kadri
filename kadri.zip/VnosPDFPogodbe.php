<?php
include ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>PDF Pogodbe delavcev
</title>
</head>
<body>
<?php
$Danes=new DateTime("now");
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("UpdDel",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["idUcitelj"])){
    $ucitelj = $_POST["idUcitelj"];
}else{
    if (isset($_GET["idUcitelj"])){
        $ucitelj = $_GET["idUcitelj"];
    }else{
        if (isset($_SESSION["idUcitelj"])){ 
            $ucitelj = $_SESSION["idUcitelj"];
        }else{
            $ucitelj = 0;
        }
    }
}

$VIdUcitelj = $ucitelj;
if (isset($_POST["pogodba"])){
    $VPogodba = $_POST["pogodba"];
}else{
    if (isset($_GET["pogodba"])){
        $VPogodba = $_GET["pogodba"];
    }else{
        $VPogodba="";
    }
}
if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}

switch ($id){
    case 1:
        $allowedExts = array("pdf");
        $extension = explode(".", $_FILES["file"]["name"]);
        $ext = end($extension);
        if (($_FILES["file"]["type"] == "application/pdf")
         && ($_FILES["file"]["size"] < 5000000)
         && in_array($ext, $allowedExts))
        {
           if ($_FILES["file"]["error"] > 0){
             echo "Napaka: " . $_FILES["file"]["error"] . "<br />";
           }else{
             echo "Datoteka: " . $_FILES["file"]["name"] . "<br />";
             echo "Tip: " . $_FILES["file"]["type"] . "<br />";
             echo "Velikost: " . round($_FILES["file"]["size"] / 1024) . " Kb<br />";
             echo "Zač. datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
         
             if (file_exists("pogodbe/" . $_FILES["file"]["name"])){
                echo $_FILES["file"]["name"] . " že obstaja. ";
             }else{
                move_uploaded_file($_FILES["file"]["tmp_name"],"pogodbe/" . $_FILES["file"]["name"]);
                echo "Shranjeno v: " . "pogodbe/" . $_FILES["file"]["name"];
                $VDatoteka=$_FILES["file"]["name"];
               
                $SQL = "SELECT * FROM tabpogodbe WHERE id=".$VPogodba;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabpogodbe SET pdf='".$VDatoteka&"',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$R["Id"];
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        echo $SQL."<br />";
                        die("Napaka pri zapisu pogodbe: ".mysqli_error());
                    }
                }
             }
           }
         }else{
            echo "Nepravilen tip ali velikost datoteke!<br />";
         }
                      
        break;
    default:
        $SQL = "SELECT ime, priimek FROM tabucitelji WHERE idUcitelj=".$VIdUcitelj;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
	        if ($VLevel > 1){
		        echo "<h2>Vnos PDF pogodb</h2>";
		        echo "<form accept-charset='utf-8' method='post' ENCTYPE='multipart/form-data' action='VnosPDFPogodbe.php'>";
		        echo "<table>";
		        echo "<tr><td>Ime</td><td>".$R["ime"]." ".$R["priimek"]."</td></tr>";
		        echo "<tr><td>Datoteka:</td><td><input name='file' type='file' id='file' size='40' value=''></td></tr>";
		        echo "<input name='Povezava' type='hidden' value='/'>";
		        echo "</table>";
		        echo "Ime datoteke naj bo enolično - najbolje številka pogodbe (ne uporabljati znakov: \\ / . ,)<br />";
		        echo "<input type='hidden' name='pogodba' value='".$VPogodba."'>";
		        echo "<input type='hidden' name='uporabnik' value='".$VUporabnik."'>";
		        echo "<input type='hidden' name='geslo' value='".$VGeslo."'>";
		        echo "<input type='hidden' name='level' value='".$VLevel."'>";
                echo "<input type='hidden' name='id' value='1'>";
		        echo "<input name='submit' type='submit' value='Pošlji'>";
		        echo "</form><br>";
	        }
        }
}
?>

</body>
</html>
