<?php
require("const.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Preverjanje znanja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");

$VRazred = 0;

$SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=".$VRazred;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VRazred1=$R["razred"];
    $VParalelka=$R["oznaka"];
}

echo "<h2>Spisek datumov pisnih preverjanj znanja</h2>";

$SQL = "SELECT DISTINCT tabpreverjanje.predmet FROM tabpreverjanje WHERE leto=".$VLeto." ORDER BY predmet";
$result = mysqli_query($link,$SQL);

$StPredmetov=0;
while ($R = mysqli_fetch_array($result)){
    $StPredmetov=$StPredmetov+1;
    $Predmeti[$StPredmetov]=$R["predmet"];
}

$SQL = "SELECT razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred >= 3 ORDER BY razred,oznaka";
$result = mysqli_query($link,$SQL);

$StRazredov=0;
while ($R = mysqli_fetch_array($result)){
    if ($R["razred"] >= 3){
        $StRazredov=$StRazredov+1;
        $Razredi[$StRazredov]=$R["razred"].". ".$R["oznaka"];
    }
}

for ($Indx=0;$Indx <= 50;$Indx++){
    for ($i1=0;$i1 <= 50;$i1++){
        $Termin[$Indx][$i1]="";
    }
}

$SQL = "SELECT id,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1)";
$result = mysqli_query($link,$SQL);
$Indx=0;
while ($R = mysqli_fetch_array($result)){
    $StrPredmet[$R["id"]]=$R["oznaka"];
}

$SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
$SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
$SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
$SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
$SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
$SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." ";
$SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.opis,year(datum),month(datum),day(datum)";
$result = mysqli_query($link,$SQL);

if (mysqli_num_rows($result) > 0){
    echo "<h2>Pisna preverjanja znanja za 1. polletje</h2>";
    echo "<table border=1 cellspacing=0>";
    echo "<tr bgcolor=lightcyan><th></th>";
    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        echo "<th>".$Razredi[$Indx]."</th>";
    }
    echo "</tr>";
    
    while ($R = mysqli_fetch_array($result)){
        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
            for ($i1=1;$i1 <= $StRazredov;$i1++){
                $VRazred=$R["razred"].". ".$R["roznaka"];
                if (($VRazred==$Razredi[$i1]) && ($R["pid"]==$Predmeti[$Indx])){
                    $Datum=new DateTime(isDate($R["datum"]));
                    switch(intval($Datum->format('n'))){
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 1:
                            $Termin[$Indx][$i1]=$Termin[$Indx][$i1].$Datum->format('j.n.')." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)"."<br />";
                    }
                }
            }
        }
    }
    
    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
        echo "<tr bgcolor=lightyellow>";
        echo "<td bgcolor=khaki>".$StrPredmet[$Predmeti[$Indx]]."</td>";
        for ($i1=1;$i1 <= $StRazredov;$i1++){
            if (strlen($Termin[$Indx][$i1]) > 0){
                echo "<td>".$Termin[$Indx][$i1]."</td>";
            }else{
                echo "<td>&nbsp;</td>";
            }
        }
        echo "</tr>";
    }
    echo "</table><br />";

    $result = mysqli_query($link,$SQL);
    for ($Indx=0;$Indx <= 50;$Indx++){
        for ($i1=0;$i1 <= 50;$i1++){
            $Termin[$Indx][$i1]="";
        }
    }
    
    $SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
    $SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
    $SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
    $SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
    $SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." ";
    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.opis,year(datum),month(datum),day(datum)";
    $result = mysqli_query($link,$SQL);

    if (mysqli_num_rows($result) > 0){
        echo "<h2>Pisna preverjanja znanja za 2. polletje</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=lightcyan><th></th>";
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            echo "<th>".$Razredi[$Indx]."</th>";
        }
        echo "</tr>";
        
        while ($R = mysqli_fetch_array($result)){
            for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                for ($i1=1;$i1 <= $StRazredov;$i1++){
                    $VRazred=$R["razred"].". ".$R["roznaka"];
                    if (($VRazred==$Razredi[$i1]) && ($R["pid"]==$Predmeti[$Indx])){
                        $Datum=new DateTime(isDate($R["datum"]));
                        switch(intval($Datum->format('n'))){
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                $Termin[$Indx][$i1]=$Termin[$Indx][$i1].$Datum->format('j.n.')." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)"."<br />";
                        }
                    }
                }
            }
        }
        
        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
            echo "<tr bgcolor=lightyellow>";
            echo "<td bgcolor=khaki>".$StrPredmet[$Predmeti[$Indx]]."</td>";
            for ($i1=1;$i1 <= $StRazredov;$i1++){
                if (strlen($Termin[$Indx][$i1]) > 0){
                    echo "<td>".$Termin[$Indx][$i1]."</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
        }
        echo "</table><br />";
    }
}

$SQL = "SELECT datum,kat FROM tabpraznik WHERE leto IN (".$VLeto.",".($VLeto+1).") ORDER BY leto,mesec,dan";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Praznik[$Indx][0]=new DateTime($R["datum"]);
    $Praznik[$Indx][1]=$R["kat"];
    $Indx=$Indx+1;
}
$StPraznikov=$Indx-1;

$SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
$SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
$SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
$SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
$SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
$SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." ";
$SQL = $SQL." ORDER BY year(datum),month(datum),day(datum),tabrazdat.razred,tabrazdat.oznaka,opis";
$result = mysqli_query($link,$SQL);

$CompDate="";
for ($Indx=1;$Indx <= 300;$Indx++){
    $DanPouka[$Indx][0]=""; //'datum
    $DanPouka[$Indx][1]=""; //'zapisi
}

$Indx=0;
while ($R = mysqli_fetch_array($result)){
    $Datum=new DateTime($R["datum"]);
    if ($CompDate != $Datum->format('d.m.Y')){
        $CompDate=$Datum->format('d.m.Y');
        $Indx=$Indx+1;
        $DanPouka[$Indx][0]=new DateTime($Datum->format('Y-m-d'));
        $DanPouka[$Indx][1]=$R["razred"].".".$R["roznaka"]." ".$R["poznaka"]." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)<br />";
    }else{
        $DanPouka[$Indx][1]=$DanPouka[$Indx][1].$R["razred"].".".$R["roznaka"]." ".$R["poznaka"]." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)<br />";
    }
}
$StKontrolk=$Indx;

if (($VLeto+1) % 4 == 0 ) {
    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
}else{
    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
}
$MonthName=array('','januar','februar','marec','april','maj','junij','julij','avgust','september','oktober','november','december');

echo "<h2>Koledar za leto ".$VLeto."/".($VLeto+1)."</h2>";

for ($Indx=9;$Indx <= 12;$Indx++){
    echo $MonthName[$Indx]."<br />";
    echo "<table border=1>";
    echo "<tr bgcolor=lightcyan>";
    for ($i1=0;$i1 <= 6;$i1++){
        echo "<th width='80'>".Int2Dan($i1)."</th>";
    }
    echo "</tr>";
    echo "<tr>";
    $Datum=new DateTime($VLeto."-".$Indx."-01");
    for ($i1=1;$i1 <= $Datum->format('w');$i1++){
        echo "<td>&nbsp;</td>";
    }
    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
        $TekDatum=new DateTime($VLeto."-".$Indx."-".$Indx1);
        switch(intval($TekDatum->format('w'))){
            case 0:
            case 7:
                echo "<tr><td bgcolor=lightsalmon>".$Indx1."</td>";
                break;
            case 6:
                echo "<td bgcolor=lightsalmon>".$Indx1."</td></tr>";
                break;
            default:
                switch(CheckPraznik($TekDatum)){
                    case 1:
                        echo "<td bgcolor=lightgreen>".$Indx1."</td>";
                        break;
                    case 2:
                    case 4:
                        echo "<td bgcolor=lightblue>".$Indx1."</td>";
                        break;
                    default:
                        $Izpis="&nbsp;";
                        for ($i1=1;$i1 <= $StKontrolk;$i1++){
                            if ($DanPouka[$i1][0]->format('Y-m-d')==$TekDatum->format('Y-m-d')){
                                $Izpis=$DanPouka[$i1][1];
                                break;
                            }
                        }
                        echo "<td bgcolor=lightyellow>".$Indx1."<br /><b>".$Izpis."</b></td>";
                        break;
                }
        }
    }
    $KonMeseca=new DateTime($VLeto."-".$Indx."-".$MesecDni[$Indx]);
    if (intval($KonMeseca->format('w')) != 0){
        echo "</tr>";
    }
    echo "</table><br />";
}
    
for ($Indx=1;$Indx <= 6;$Indx++){
    echo $MonthName[$Indx]."<br />";
    echo "<table border=1>";
    echo "<tr bgcolor=lightcyan>";
    for ($i1=0;$i1 <= 6;$i1++){
        echo "<th width='80'>".Int2Dan($i1)."</th>";
    }
    echo "</tr>";
    echo "<tr>";
    $Datum=new DateTime(($VLeto+1)."-".$Indx."-01");
    for ($i1=1;$i1 <= $Datum->format('w');$i1++){
        echo "<td>&nbsp;</td>";
    }
    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
        $TekDatum=new DateTime(($VLeto+1)."-".$Indx."-".$Indx1);
        switch(intval($TekDatum->format('w'))){
            case 0:
            case 7:
                echo "<tr><td bgcolor=lightsalmon>".$Indx1."</td>";
                break;
            case 6:
                echo "<td bgcolor=lightsalmon>".$Indx1."</td></tr>";
                break;
            default:
                switch(CheckPraznik($TekDatum)){
                    case 1:
                        echo "<td bgcolor=lightgreen>".$Indx1."</td>";
                        break;
                    case 2:
                    case 4:
                        echo "<td bgcolor=lightblue>".$Indx1."</td>";
                        break;
                    default:
                        $Izpis="&nbsp;";
                        for ($i1=1;$i1 <= $StKontrolk;$i1++){
                            if ($DanPouka[$i1][0]->format('Y-m-d')==$TekDatum->format('Y-m-d')){
                                $Izpis=$DanPouka[$i1][1];
                                break;
                            }
                        }
                        echo "<td bgcolor=lightyellow>".$Indx1."<br /><b>".$Izpis."</b></td>";
                        break;
                }
        }
    }
    $KonMeseca=new DateTime(($VLeto+1)."-".$Indx."-".$MesecDni[$Indx]);
    if (intval($KonMeseca->format('w')) != 0){
        echo "</tr>";
    }
    echo "</table><br />";
 }
?>

</body>
</html>
