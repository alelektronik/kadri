<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("ucenci.php");
require('fpdf.php');

class PDF extends FPDF
{
    protected $B = 0;
    protected $I = 0;
    protected $U = 0;
    protected $HREF = '';

    function WriteHTML($html)
    {
        // HTML parser
        $html = str_replace("\n",' ',$html);
        $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
        foreach($a as $i=>$e)
        {
            if($i%2==0)
            {
                // Text
                if($this->HREF)
                    $this->PutLink($this->HREF,$e);
                else
                    $this->Write(3.8,$e);
            }
            else
            {
                // Tag
                if($e[0]=='/')
                    $this->CloseTag(strtoupper(substr($e,1)));
                else
                {
                    // Extract attributes
                    $a2 = explode(' ',$e);
                    $tag = strtoupper(array_shift($a2));
                    $attr = array();
                    foreach($a2 as $v)
                    {
                        if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                            $attr[strtoupper($a3[1])] = $a3[2];
                    }
                    $this->OpenTag($tag,$attr);
                }
            }
        }
    }

    function OpenTag($tag, $attr)
    {
        // Opening tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,true);
        if($tag=='A')
            $this->HREF = $attr['HREF'];
        if($tag=='BR')
            $this->Ln(5);
    }

    function CloseTag($tag)
    {
        // Closing tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,false);
        if($tag=='A')
            $this->HREF = '';
    }

    function SetStyle($tag, $enable)
    {
        // Modify style and select corresponding font
        $this->$tag += ($enable ? 1 : -1);
        $style = '';
        foreach(array('B', 'I', 'U') as $s)
        {
            if($this->$s>0)
                $style .= $s;
        }
        if ($style == 'B'){
            $this->SetFont('arialbd_CE');
        }else{
            $this->SetFont('arial_CE');
        }
    }

    function PutLink($URL, $txt)
    {
        // Put a hyperlink
        $this->SetTextColor(0,0,255);
        $this->SetStyle('U',true);
        $this->Write(5,$txt,$URL);
        $this->SetStyle('U',false);
        $this->SetTextColor(0);
    }
}


function ToPredmet($x){
    global $VLeto;
    switch ($x){
    case 16:
        return "SLJ";
    case 11:
        return "MAT";
    case 9:
        if ($VLeto > 2012){
            return "LUM";
        }else{
            return "LVZ";
        }
    case 29:
        if ($VLeto > 2012){
            return "GUM";
        }else{
            return "GVZ";
        }
    case 49:
        return "SPO";
    case 26:
        return "N1A/TJA";
    case 20:
        if ($VLeto > 2012){
            return "ŠPO";
        }else{
            return "ŠVZ";
        }
    default:
        return "SLJ";
    }
}
function ToNovaImena($x){
    global $link,$VLeto;
    if ($VLeto > 2012){
        switch ($x){
            case 9: //LVZ - LUM
                $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='LUM'";
            case 29: //GVZ - GUM
                $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='GUM'";
            case 20: //ŠVZ - ŠPO
                $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='ŠPO'";
        }
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            return $R["id"];
        }else{
            return 0;
        }
    }
    return $x;
}
function VpisOceneU($u){
    global $Ucenci;
    
    for ($Indx=0;$Indx < count($Ucenci);$Indx++){
        if ($u==$Ucenci[$Indx][0]){
            return $Indx;
        }
    }
    return 30;
}

function VpisOceneZ($z){
    global $Znanje;

    for ($Indx=0;$Indx < count($Znanje);$Indx++){
        if ($z==$Znanje[$Indx][0]){
            return $Indx;
        }
    }
    return 5000;
}

function LeadZero($x){
    while (strlen($x) <= 3){
        $x="0".$x;
    }
    return $x;
}

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    //echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["idd"])){
    $VNacin = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VNacin=$_GET["idd"];
    }else{
        $VNacin = 100;
    }
}
switch ($VNacin){
    case 210:
    case 230:
    case 231:
    case 240:
    case 241:
    case 250:
    case 251:
    case 260:
    case 261:
    case 282:
        break;
    default:
        $n=$VLevel;
        /*
        include('menu_func.inc');
        include ('menu.inc');
        */
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}
if (isset($_POST["predmet"])){
    $VPredmet = $_POST["predmet"];
}else{
    if (isset($_GET["predmet"])){
        $VPredmet=$_GET["predmet"];
    }else{
        if (isset($_SESSION["predmet"])){
            $VPredmet=$_SESSION["predmet"];
        }else{
            $VPredmet = 0;
        }
    }
}

switch ($VNacin){
    case "100": //izbor op ciljev
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Opisne ocene";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<form name='OpisniCilji' method='post' action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='110'>";
        echo "<h2>Izberite cilje za izpis</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Razred:<select name='razred'>";
        echo "<option selected>1</option>";
        echo "<option>2</option>";
        echo "<option>3</option>";
        echo "<option>0</option>";
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "Predmet:<select name='predmet'>";
        echo "<option value='16' selected>SLO</option>";
        echo "<option value='11'>MAT</option>";
        echo "<option value='9'>LVZ/LUM</option>";
        echo "<option value='29'>GVZ/GUM</option>";
        echo "<option value='49'>SPO</option>";
        echo "<option value='20'>ŠVZ/ŠPO</option>";
        echo "<option value='26'>N1A/TJA</option>";
        echo "<option value='0'>Vsi</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Izberite 0 za izpis ciljev za vse razrede ali vse predmete.</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "110": //izpis op ciljev
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        if ($VPredmet > 0){
            if ($VRazred > 0){
                $SQL = "SELECT tabopcilji.idcilji,tabopcilji.razred,tabopcilji.opiscilja,tabopcilji.predmet,tabopznanje.idznanje,tabopznanje.tipznanja,tabopznanje.opisznanja FROM tabopznanje INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred." AND tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
            }else{
                $SQL = "SELECT tabopcilji.idcilji,tabopcilji.razred,tabopcilji.opiscilja,tabopcilji.predmet,tabopznanje.idznanje,tabopznanje.tipznanja,tabopznanje.opisznanja FROM tabopznanje INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
            }
        }else{
            if ($VRazred > 0){
                $SQL = "SELECT tabopcilji.idcilji,tabopcilji.razred,tabopcilji.opiscilja,tabopcilji.predmet,tabopznanje.idznanje,tabopznanje.tipznanja,tabopznanje.opisznanja FROM tabopznanje INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
            }else{
                $SQL = "SELECT tabopcilji.idcilji,tabopcilji.razred,tabopcilji.opiscilja,tabopcilji.predmet,tabopznanje.idznanje,tabopznanje.tipznanja,tabopznanje.opisznanja FROM tabopznanje INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
            }
        }
        $result = mysqli_query($link,$SQL);

        echo "<br /><table>";
        echo "<tr><td></td><td></td><td><a href='opisneocene.php?idd=120&predmet=0&razred=0'>Dodaj nov cilj</a></td><td></td><td><a href='opisneocene.php?idd=140&cilj=0'>Dodaj novo znanje</a></td></tr>";
        $IzbraniPredmet=0;
        $IzbraniCilj=0;
        while ($R = mysqli_fetch_array($result)){
            if ($R["predmet"] != $IzbraniPredmet){
                if ($R["idcilji"] != $IzbraniCilj){
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td></td><td><a href='opisneocene.php?idd=140&predmet=".$R["predmet"]."&razred=".$R["razred"]."&cilj=".$R["idcilji"]."'>Dodaj novo znanje za ta cilj</a></td></tr>";
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td>".$R["tipznanja"]."</td><td>".$R["opisznanja"]." <a href='opisneocene.php?idd=170&id=".$R["idznanje"]."&predmet=".$R["predmet"]."&razred=".$R["razred"]."'>(P)</a></td></tr>";
                    $IzbraniPredmet=$R["predmet"];
                    $IzbraniCilj=$R["idcilji"];
                }else{
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td></td><td><a href='opisneocene.php?idd=140&cilj=".$R["idcilji"]."'>Dodaj novo znanje za ta cilj</a></td></tr>";
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td>".$R["tipznanja"]."</td><td>".$R["opisznanja"]." <a href='opisneocene.php?idd=170&id=".$R["idznanje"]."6predmet=".$R["predmet"]."&razred=".$R["razred"]."'>(P)</a></td></tr>";
                    $IzbraniPredmet=$R["predmet"];
                }
            }else{
                if ($R["idcilji"] != $IzbraniCilj){
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td></td><td><a href='opisneocene.php?idd=140&cilj=".$R["idcilji"]."'>Dodaj novo znanje za ta cilj</a></td></tr>";
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td>".$R["tipznanja"]."</td><td>".$R["opisznanja"]." <a href='opisneocene.php?idd=170&id=".$R["idznanje"]."&predmet=".$R["predmet"]."&razred=".$R["razred"]."'>(P)</a></td></tr>";
                    $IzbraniCilj=$R["idcilji"];
                }else{
                    echo "<tr><td>".$R["razred"]."</td><td>".ToPredmet($R["predmet"])."</td><td>".$R["opiscilja"]." <a href='opisneocene.php?idd=160&id=".$R["idcilji"]."'>(P)</a></td><td>".$R["tipznanja"]."</td><td>".$R["opisznanja"]." <a href='opisneocene.php?idd=170&id=".$R["idznanje"]."&predmet=".$R["predmet"]."&razred=".$R["razred"]."'>(P)</a></td></tr>" ;
                }
            }
        }
        echo "</table><br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "120": //dodaj op cilj
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<form name='OpisniCilji' method='post' action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='130'>";
        echo "<h2>Vpis novega cilja</h2><br />";
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Razred:<select name='razred'>";
        echo "<option selected>";
        if ($VRazred==0){ 
            echo "1";
        }else{
            echo $VRazred;
        }
        echo "</option>";
        echo "<option>1</option>";
        echo "<option>2</option>";
        echo "<option>3</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "Predmet:<select name='predmet'>";
        if ($VPredmet==0){ 
            $VPredmet=16;
        }
        echo "<option value='".$VPredmet."' selected>".ToPredmet($VPredmet)."</option>";
        echo "<option value='16'>SLO</option>";
        echo "<option value='11'>MAT</option>";
        echo "<option value='9'>LVZ</option>";
        echo "<option value='29'>GVZ</option>";
        echo "<option value='49'>SPO</option>";
        echo "<option value='20'>ŠVZ</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Nov cilj<br />";
        echo "<TextArea name='opiscilja' rows='5' cols='50'></TextArea>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "130": //insert op cilj
        if (isset($_POST["opiscilja"])){
            $VCilj = $_POST["opiscilja"];
        }else{
            if (isset($_GET["opiscilja"])){
                $VCilj=$_GET["opiscilja"];
            }else{
                $VCilj = 0;
            }
        }
        if (strlen($VCilj) > 0){
            $SQL = "INSERT INTO tabopcilji (Razred,OpisCilja,Predmet) VALUES (".$VRazred.",'".$VCilj."',".$VPredmet.")";
            $result = mysqli_query($link,$SQL);
        }
        header ("Location: opisneocene.php?idd=110&razred=".$VRazred."&predmet=".$VPredmet);
        break;
    case "140": //dodaj op znanje
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        if (isset($_POST["cilj"])){
            $VCilj = $_POST["cilj"];
        }else{
            if (isset($_GET["cilj"])){
                $VCilj=$_GET["cilj"];
            }else{
                $VCilj = 0;
            }
        }

        echo "<form name='OpisniCilji' method=post action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='150'>";
        echo "<h2>Vpis novega znanja</h2><br />";
        echo "<table border=0><tr><td><input name='razred' type='hidden' value='".$VRazred."'><input name='predmet' type='hidden' value='".$VPredmet."'>";
        echo "Cilji:<select name='cilj'>";

        if ($VCilj==0){
            $SQL = "SELECT * FROM tabopcilji ORDER BY Razred,Predmet";
        }else{
            $SQL = "SELECT * FROM tabopcilji WHERE IdCilji=".$VCilj." ORDER BY Razred,Predmet";
        }
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["IdCilji"]."'>".$R["Razred"]." - ".ToPredmet($R["Predmet"]).": ".$R["OpisCilja"]."</option>";
            $Indx=$Indx+1;
        }

        echo "</select></td></tr>";
        echo "<tr>";
        echo "<td>Novo znanje<br />";
        echo "<TextArea name='opisznanja' rows='5' cols='50'></TextArea>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "150": //insert op znanje
        if (isset($_POST["cilj"])){
            $VCilj = $_POST["cilj"];
        }else{
            if (isset($_GET["cilj"])){
                $VCilj=$_GET["cilj"];
            }else{
                $VCilj = 0;
            }
        }
        if (isset($_POST["opisznanja"])){
            $VZnanje = $_POST["opisznanja"];
        }else{
            if (isset($_GET["opisznanja"])){
                $VZnanje=$_GET["opisznanja"];
            }else{
                $VZnanje = "";
            }
        }
        $SQL = "SELECT * FROM tabopcilji WHERE idCilji=".$VCilj;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VOpisCilja=$R["OpisCilja"];
            $VPredmet=$R["Predmet"];
            $vRazred=$R["Razred"];
        }else{
            $VOpisCilja="";
        }

        $SQL = "SELECT * FROM tabopznanje ORDER BY id DESC LIMIT 0,1";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $idZnanje=$R["IdZnanje"]+1;
        }else{
            $idZnanje=1;
        }

        if ($VOpisCilja=="Spričevalo"){
            $SQL = "INSERT INTO tabopznanje (idZnanje,IdCilji,TipZnanja,OpisZnanja) VALUES (".$idZnanje.",".$VCilj.",1,'".$VZnanje."')";
        }else{
            $SQL = "INSERT INTO tabopznanje (idZnanje,IdCilji,TipZnanja,OpisZnanja) VALUES (".$idZnanje.",".$VCilj.",0,'".$VZnanje."')";
        }
        $result = mysqli_query($link,$SQL);

        header ("Location: opisneocene.php?idd=110&razred=".$VRazred."&predmet=".$VPredmet);
        break;
    case "160": //popravi op cilj
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $VCilj=$Vid;
        $SQL = "SELECT * FROM tabopcilji WHERE IdCilji=". $VCilj;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VRazred=$R["Razred"];
            $VPredmet=$R["Predmet"];
            $IzbraniCilj=$R["OpisCilja"];
            echo "<form name='OpisniCilji' method=post action='opisneocene.php'>";
            echo "<input name='idd' type='hidden' value='165'>";
            echo "<h2>Popravljanje cilja</h2><br />";
            echo "<table border=0><tr><td>";
            echo "<input name='idcilj' type='hidden' value='".$R["IdCilji"]."'>";
            echo "Razred:<select name='razred'>";
            echo "<option selected>";
            if ($VRazred==0){
                echo "1";
            }else{
                echo $VRazred;
            }
            echo "</option>";
            echo "</select>";
            echo "</td></tr><tr><td>";
            echo "Predmet:<select name='predmet'>";
            if ($VPredmet==0){
                $VPredmet=16;
            }
            echo "<option value='".$VPredmet."' selected>".ToPredmet($VPredmet)."</option>";
            echo "</select></td></tr><tr>";
            echo "<td>Popravljen cilj<br />";
            echo "<TextArea name='opiscilja' rows='5' cols='50'>";
            echo $IzbraniCilj;
            echo "</TextArea></td></tr><tr>";
            echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
            echo "</tr></table></form><br />";
        }else{
             echo "Cilj ne obstaja!<br />";
        }
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "165": //update op cilj
        if (isset($_POST["opiscilja"])){
            $VCilj = $_POST["opiscilja"];
        }else{
            if (isset($_GET["opiscilja"])){
                $VCilj=$_GET["opiscilja"];
            }else{
                $VCilj = 0;
            }
        }
        if (isset($_POST["idcilj"])){
            $VIdCilj = $_POST["idcilj"];
        }else{
            if (isset($_GET["idcilj"])){
                $VIdCilj=$_GET["idcilj"];
            }else{
                $VIdCilj = 0;
            }
        }
        $SQL = "UPDATE tabopcilji SET OpisCilja='".$VCilj."' WHERE idcilji=".$VIdCilj;
        $result = mysqli_query($link,$SQL);
        header ("Location: opisneocene.php?idd=110&razred=".$VRazred."&predmet=".$VPredmet);
        break;
    case "170": //popravi op znanje
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $VZnanje=$Vid;
        $SQL = "SELECT TabOpZnanje.*,tabopcilji.* FROM TabOpZnanje INNER JOIN tabopcilji ON TabOpZnanje.IdCilji=tabopcilji.IdCilji WHERE IdZnanje=".$VZnanje;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $IzbranoZnanje=$R["OpisZnanja"];
            echo "<form name='OpisniCilji' method=post action='opisneocene.php'>";
            echo "<input name='idd' type='hidden' value='175'>";
            echo "<h2>Popravljanje znanja</h2><br />";
            echo "<table border=0><tr><td>";
            echo "<input name='idznanje' type='hidden' value='".$R["IdZnanje"]."'>";
            echo "Razred:<select name='razred'>";
            echo "<option selected>";
            if ($VRazred==0){
                echo "1";
            }else{
                echo $VRazred;
            }
            echo "</option>";
            echo "</select>";
            echo "</td></tr><tr><td>";
            echo "Predmet:<select name='predmet'>";
            if ($VPredmet==0){
                $VPredmet=16;
            }
            echo "<option value='".$VPredmet."' selected>".ToPredmet($VPredmet)."</option>";
            echo "</select></td></tr><tr>";
            echo "<tr><td><textarea>".$R["OpisCilja"]."</textarea></td></tr>";
            echo "<td>Popravljeno znanje<br />";
            echo "<TextArea name='opisznanja' rows='5' cols='50'>";
            echo $IzbranoZnanje;
            echo "</TextArea></td></tr><tr>";
            echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
            echo "</tr></table></form><br />";
        }else{
             echo "Znanje ne obstaja!<br />";
        }
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "175": //update op znanje
        if (isset($_POST["opisznanja"])){
            $VZnanje = $_POST["opisznanja"];
        }else{
            if (isset($_GET["opisznanja"])){
                $VZnanje=$_GET["opisznanja"];
            }else{
                $VZnanje = 0;
            }
        }
        if (isset($_POST["idznanje"])){
            $VIdZnanje = $_POST["idznanje"];
        }else{
            if (isset($_GET["idznanje"])){
                $VIdZnanje=$_GET["idznanje"];
            }else{
                $VIdZnanje = 0;
            }
        }

        $SQL = "UPDATE tabopznanje SET OpisZnanja='".$VZnanje."' WHERE idznanje=".$VIdZnanje;
        $result = mysqli_query($link,$SQL);

        header ("Location: opisneocene.php?idd=110&razred=".$VRazred."&predmet=".$VPredmet);
        break;
    case "200":  //izbor op redovalnice
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "<br /><a href='tiskanje_navodilo.htm' target='new_win'>Navodilo za tiskanje PDF dokumentov</a><br />";
        //echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika</a><br />";
        echo "<a href='izpisredovalnice.php'>Priprava podatkov za končno spričevalo</a><br />";

        //Korekcija tiska
        if (isset($_SESSION["posx"])) {
            $KorX=$_SESSION["posx"];
        }else{
            $KorX=0;
        }
        if (isset($_SESSION["posy"])){
            $KorY=$_SESSION["posy"];
        }else{
            $KorY=0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay=$_SESSION["DayToPrint"];
        }else{
            $PrintDay=$Danes->format('j.n.Y');
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix = $_SESSION["RefStFix"];
        }else{
            $RefStFix = "";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar = $_SESSION["RefStVar"];
        }else{
            $RefStVar = "";
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe = "";
        }
        switch ($Vid){
            case "1":
                $KorX=$_POST["koordinatax"];
                $KorY=$_POST["koordinatay"];
                if (isset($_POST["RefStFix"])){
                    $RefStFix=$_POST["RefStFix"];
                }
                if (isset($_POST["RefStVar"])){
                    $RefStVar=$_POST["RefStVar"];
                }
                if (isset($_POST["datum"])){
                    $PrintDay=$_POST["datum"];
                }
                if (isset($_POST["KorOpombe"])){
                    $KorOpombe=$_POST["KorOpombe"];
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
                echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
                break;
            default:    
                if ($KorX==""){
                    $KorX=0;
                }
                if ($KorY==""){
                    $KorY=0;
                }
                if ($PrintDay=="") {
                    $PrintDay=$Danes->format('j.n.Y');
                }
                $_SESSION["posx"]=$KorX;
                $_SESSION["posy"]=$KorY;
                $_SESSION["RefStFix"]=$RefStFix;
                $_SESSION["RefStVar"]=$RefStVar;
                $_SESSION["DayToPrint"]=$PrintDay;
                $_SESSION["KorOpombe"]=$KorOpombe;
        }
                
        echo "<form name='rezultati' method=post action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='200'>";
        echo "<h3>Korekcija tiskanja</h3>";
        echo "<table border='0'>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis višje(+)/nižje(-) mm:";
        echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        izpis bolj desno(+)/levo(-) mm:";
        echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        /*
        if (strstr($PrintDay,".")) { 
            $astr=explode(".",$PrintDay);
            $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
        }else{
            $Datum  = new DateTime($Danes->format('Y-m-d'));
        }
        echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
        echo "</tr>";
        echo "<tr>";
        echo "        <td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
        echo "</tr>";
        */
        echo "</table>";
        echo "<input name='id' type='hidden' value='1'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        // konec korekcije tiskanja
        
        echo "<form name='OpisniCilji' method='post' action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='210'>";
        echo "<h2>Izberite razred za redovalnico</h2><br />";
        echo "<table border=0>";
        echo "<tr><td>";
        echo "Šolsko leto: <input name='leto' type='hidden' value='".$VLeto."'></td><td>".$VLeto."/".($VLeto+1);
        echo "</td>";
        echo "</tr>";
        echo "<tr><td>Tip dokumenta:</td><td>";
        
        /*
        echo "<select name='tip'>";
        echo "<option value='-1' selected>&nbsp;</option>";
        echo "<option value='0'>Končno spričevalo</option>";
        //echo "<option value='1'>Polletno obvestilo</option>";
        echo "<option value='2'>Redovalnica 1. semester</option>";
        echo "<option value='3'>Redovalnica 2. semester</option>";
        echo "</select><br />";
        echo "</td>";
        echo "</tr>";

        $SQL = "SELECT program FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VProgram=$R["program"];
        }

        if ($VProgram == "3813"){ //'prilagojen program
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred < 7 AND razred > 0 ORDER BY razred,oznaka";
        }else{
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred < 4 AND razred > 0 ORDER BY razred,oznaka";
        }
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred'>";
        echo "<option value='0'>&nbsp;</option>";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
            $Indx=$Indx+1;
        }
        echo "</select></td></tr>";
        echo "<tr>";
        echo "<td>";
        echo "Predmet:</td><td><select name='predmet'>";
        echo "<option value='-1' selected='selected'>&nbsp;</option>";
        echo "<option value='16'>SLO</option>";
        echo "<option value='11'>MAT</option>";
        echo "<option value='9'>".ToPredmet(9)."</option>";
        echo "<option value='29'>".ToPredmet(29)."</option>";
        echo "<option value='49'>SPO</option>";
        echo "<option value='20'>".ToPredmet(20)."</option>";
        if ($VProgram=="3813"){
            echo "<option value='183'>DRU (OŠPP)</option>";
            echo "<option value='13'>NAR (OŠPP)</option>";
            echo "<option value='25'>TIT (OŠPP)</option>";
            echo "<option value='51'>GOS (OŠPP)</option>";
        }
        echo "<option value='0'>Vsi</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "</table><br />";

        echo "<input name='submit' type='submit' value='Redovalnica - z izbiranjem' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Redovalnica - prosto pisanje' style='width:350px'><br /><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 1. stran (PDF)' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 2. stran (PDF)' style='width:350px'><br /><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 1. stran (PDF) prosti vpis' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 2. stran (PDF) prosti vpis' style='width:350px'><br /><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil' style='width:350px'><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil - prosti vpis' style='width:350px'><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil (na osnovi redovalnice 1. semestra)' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis redovalnice 1. semestra' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis redovalnice 2. semestra' style='width:350px'><br />";
        */
        
        if (isset($_SESSION["tip"])){
            $VTip=$_SESSION["tip"];
        }else{
            $VTip="-1";
        }
        echo "<select name='tip'>";
        if ($VTip=="-1"){
            echo "<option value='-1' selected='selected'>&nbsp;</option>";
        }else{
            echo "<option value='-1'>&nbsp;</option>";
        }
        if ($VTip=="0"){
            echo "<option value='0' selected='selected'>Končno spričevalo</option>";
        }else{
            echo "<option value='0'>Končno spričevalo</option>";
        }

            //echo "<option value='1'>Polletno obvestilo</option>";

        if ($VTip=="2"){
            echo "<option value='2' selected='selected'>Redovalnica 1. semester</option>";
        }else{
            echo "<option value='2'>Redovalnica 1. semester</option>";
        }
        if ($VTip=="3"){
            echo "<option value='3' selected='selected'>Redovalnica 2. semester</option>";
        }else{
            echo "<option value='3'>Redovalnica 2. semester</option>";
        }

        echo "</select><br />";
        echo "</td>";
        echo "</tr>";

        if (isset($_SESSION["dokument"])){
            $VDokument=$_SESSION["dokument"];
        }else{
            $VDokument="";
        }
        $SQL = "SELECT program FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VProgram=$R["program"];
        }
/*
        if ($VProgram == "3813"){ //'prilagojen program
            $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred < 7 AND razred > 0 ORDER BY idsola,razred,oznaka";
        }else{
        */
/*            if ($VLeto > 2012){
                $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred < 3 AND razred > 0 OR (program=3813 AND razred < 7 AND razred > 0 and leto=".$VLeto.") ORDER BY idsola,razred,oznaka";
            }else{
                $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred < 4 AND razred > 0 OR (program=3813 AND razred < 7 AND razred > 0 and leto=".$VLeto.") ORDER BY idsola,razred,oznaka";
            }
            */
            if ($VLeto > 2012){
                if ($VLevel > 1){
                    $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred < 3 AND razred > 0 OR (program=3813 AND razred < 7 AND razred > 0 and leto=".$VLeto.") ORDER BY idsola,razred,oznaka";
                }else{
                    $SQL = "SELECT DISTINCT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred ";
                    $SQL .= "WHERE tabrazred.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.razred < 3 AND tabrazdat.razred > 0 OR (program=3813 AND tabrazdat.razred < 7 AND tabrazdat.razred > 0 and tabrazdat.leto=".$VLeto.") ";
                    $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
                }
            }else{
                if ($VLevel > 1){
                    $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred < 4 AND razred > 0 OR (program=3813 AND razred < 7 AND razred > 0 and leto=".$VLeto.") ORDER BY idsola,razred,oznaka";
                }else{
                    $SQL = "SELECT DISTINCT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM (tabrazdat ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred ";
                    $SQL .= "WHERE tabrazred.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.razred < 4 AND tabrazdat.razred > 0 OR (program=3813 AND tabrazdat.razred < 7 AND tabrazdat.razred > 0 and tabrazdat.leto=".$VLeto.") ";
                    $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
                }
            }
        // }
        $result = mysqli_query($link,$SQL);

        echo "<tr><td>Izberi razred</td><td><select name='razred'>";
        echo "<option value='0'>&nbsp;</option>";
        $Indx=1;
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred==$R["id"]){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($VRazred==$R["id"]){
                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }else{
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                $Indx=$Indx+1;
            }
        }
        echo "</select></td></tr>";
        echo "<tr>";
        echo "<td>";
        echo "Predmet:</td><td><select name='predmet'>";
        if ($VPredmet==-1){
            echo "<option value='-1' selected='selected'>&nbsp;</option>";
        }else{
            echo "<option value='-1'>&nbsp;</option>";
        }
        if ($VPredmet==16){
            echo "<option value='16' selected='selected'>SLO</option>";
        }else{
            echo "<option value='16'>SLO</option>";
        }
        if ($VPredmet==11){
            echo "<option value='11' selected='selected'>MAT</option>";
        }else{
            echo "<option value='11'>MAT</option>";
        }
        if ($VPredmet==9){
            echo "<option value='9' selected='selected'>".ToPredmet(9)."</option>";
        }else{
            echo "<option value='9'>".ToPredmet(9)."</option>";
        }
        if ($VPredmet==29){
            echo "<option value='29' selected='selected'>".ToPredmet(29)."</option>";
        }else{
            echo "<option value='29'>".ToPredmet(29)."</option>";
        }
        if ($VPredmet==49){
            echo "<option value='49' selected='selected'>SPO</option>";
        }else{
            echo "<option value='49'>SPO</option>";
        }
        if ($VPredmet==20){
            echo "<option value='20' selected='selected'>".ToPredmet(20)."</option>";
        }else{
            echo "<option value='20'>".ToPredmet(20)."</option>";
        }
        if ($VPredmet==26){
            echo "<option value='26' selected='selected'>".ToPredmet(26)."</option>";
        }else{
            echo "<option value='26'>".ToPredmet(26)."</option>";
        }
        if ($VProgram=="3813"){
            if ($VPredmet==183){
                echo "<option value='183' selected='selected'>DRU (OŠPP)</option>";
            }else{
                echo "<option value='183'>DRU (OŠPP)</option>";
            }
            if ($VPredmet==13){
                echo "<option value='13' selected='selected'>NAR (OŠPP)</option>";
            }else{
                echo "<option value='13'>NAR (OŠPP)</option>";
            }
            if ($VPredmet==25){
                echo "<option value='25' selected='selected'>TIT (OŠPP)</option>";
            }else{
                echo "<option value='25'>TIT (OŠPP)</option>";
            }
            if ($VPredmet==51){
                echo "<option value='51' selected='selected'>GOS (OŠPP)</option>";
            }else{
                echo "<option value='51'>GOS (OŠPP)</option>";
            }
        }
        echo "<option value='0'>Vsi</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "</table><br />";

        /*
        echo "<input name='submit' type='submit' value='Redovalnica - z izbiranjem' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Redovalnica - prosto pisanje' style='width:350px'><br /><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 1. stran (PDF)' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 2. stran (PDF)' style='width:350px'><br /><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 1. stran (PDF) prosti vpis' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis končnega spričevala - 2. stran (PDF) prosti vpis' style='width:350px'><br /><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil' style='width:350px'><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil - prosti vpis' style='width:350px'><br />";
        //echo "<input name='submit' type='submit' value='Izpis polletnih obvestil (na osnovi redovalnice 1. semestra)' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis redovalnice 1. semestra' style='width:350px'><br />";
        echo "<input name='submit' type='submit' value='Izpis redovalnice 2. semestra' style='width:350px'><br />";
        */
        
        echo "Velikost pisave besedila ocene: <input name='fs' type='text' value='8'><br /><br />";
        
        echo "<input name='predogled' type='checkbox'>Predogled<br />";
        echo "<input name='enotno' type='checkbox'>Enoten blok besedila<br />";
        
        echo "<select name='dokument'>";
        if ($VDokument=="1"){
            echo "<option value='1' selected='selected'>Redovalnica - z izbiranjem</option>";
        }else{
            echo "<option value='1'>Redovalnica - z izbiranjem</option>";
        }
        if ($VDokument=="2"){
            echo "<option value='2' selected='selected'>Redovalnica - prosto pisanje</option>";
        }else{
            echo "<option value='2'>Redovalnica - prosto pisanje</option>";
        }
        if ($VDokument=="3"){
            echo "<option value='3' selected='selected'>Izpis končnega spričevala - 1. stran (PDF)</option>";
        }else{
            echo "<option value='3'>Izpis končnega spričevala - 1. stran (PDF)</option>";
        }
        if ($VDokument=="4"){
            echo "<option value='4' selected='selected'>Izpis končnega spričevala - 2. stran (PDF)</option>";
        }else{
            echo "<option value='4'>Izpis končnega spričevala - 2. stran (PDF)</option>";
        }
        if ($VDokument=="5"){
            echo "<option value='5' selected='selected'>Izpis končnega spričevala - 1. stran (PDF) prosti vpis</option>";
        }else{
            echo "<option value='5'>Izpis končnega spričevala - 1. stran (PDF) prosti vpis</option>";
        }
        if ($VDokument=="6"){
            echo "<option value='6' selected='selected'>Izpis končnega spričevala - 2. stran (PDF) prosti vpis</option>";
        }else{
            echo "<option value='6'>Izpis končnega spričevala - 2. stran (PDF) prosti vpis</option>";
        }

            //echo "<option>Izpis polletnih obvestil</option>";
            //echo "<option>Izpis polletnih obvestil - prosti vpis</option>";
            //echo "<option>Izpis polletnih obvestil (na osnovi redovalnice 1. semestra)</option>";

        if ($VDokument=="7"){
            echo "<option value='7' selected='selected'>Izpis redovalnice 1. semestra</option>";
        }else{
            echo "<option value='7'>Izpis redovalnice 1. semestra</option>";
        }
        if ($VDokument=="8"){
            echo "<option value='8' selected='selected'>Izpis redovalnice 2. semestra</option>";
        }else{
            echo "<option value='8'>Izpis redovalnice 2. semestra</option>";
        }
        if ($VDokument=="9"){
            echo "<option value='9' selected='selected'>Izbor znanj za moj razred</option>";
        }else{
            echo "<option value='9'>Izbor znanj za moj razred</option>";
        }
        echo "</select>";
        echo "<input name='submit' type='submit' value='Izberi'><br />";
        
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "210": //vpis op ocen
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $VTip=$_POST["tip"];
        if (isset($_POST["predogled"])){
            $Predogled=1;
        }else{
            $Predogled=0;
        }
        $_SESSION["fs"]=$_POST["fs"];
        $_SESSION["tip"]=$VTip;
        $_SESSION["razred"]=$VRazred;
        $_SESSION["predmet"]=$VPredmet;
        if (($VTip > -1) && ($VRazred > 0)){
            $VSubmit=$_POST["dokument"];
            $_SESSION["dokument"]=$VSubmit;

            switch ($VSubmit){
                case "3": //"Izpis končnega spričevala - 1. stran (PDF)":
                    if (isset($_POST["enotno"])){
                        header ("Location: opisneocene.php?idd=231&predogled=".$Predogled."&razred=".$VRazred);
                    }else{
                        header ("Location: opisneocene.php?idd=230&predogled=".$Predogled."&razred=".$VRazred);
                    }
                    break;
                case "4": //"Izpis končnega spričevala - 2. stran (PDF)":
                    if (isset($_POST["enotno"])){
                        header ("Location: opisneocene.php?idd=241&predogled=".$Predogled."&razred=".$VRazred);
                    }else{
                        header ("Location: opisneocene.php?idd=240&predogled=".$Predogled."&razred=".$VRazred);
                    }
                    break;
                case "5": //"Izpis končnega spričevala - 1. stran (PDF) prosti vpis":
                    if (isset($_POST["enotno"])){
                        header ("Location: opisneocene.php?idd=251&predogled=".$Predogled."&razred=".$VRazred);
                    }else{
                        header ("Location: opisneocene.php?idd=250&predogled=".$Predogled."&razred=".$VRazred);
                    }
                    break;
                case "6": //"Izpis končnega spričevala - 2. stran (PDF) prosti vpis":
                    if (isset($_POST["enotno"])){
                        header ("Location: opisneocene.php?idd=261&predogled=".$Predogled."&razred=".$VRazred);
                    }else{
                        header ("Location: opisneocene.php?idd=260&predogled=".$Predogled."&razred=".$VRazred);
                    }
                    break;
                case "2": //"Redovalnica - prosto pisanje":
                    header ("Location: opisneocene.php?idd=280&razred=".$VRazred);
                    break;
                /*    
                case "Izpis polletnih obvestil":
                    header ("Location: opisneocene.php?idd=270&id=1&razred=".$VRazred);
                    break;
                case "Izpis polletnih obvestil (na osnovi redovalnice 1. semestra)":
                    header ("Location: opisneocene.php?idd=270&id=4&razred=".$VRazred);
                    break;
                */
                case "7": //"Izpis redovalnice 1. semestra":
                    header ("Location: opisneocene.php?idd=270&id=2&razred=".$VRazred);
                    break;
                case "8": //"Izpis redovalnice 2. semestra":
                    header ("Location: opisneocene.php?idd=270&id=3&razred=".$VRazred);
                    break;
                /*    
                case "Izpis polletnih obvestil - prosti vpis":
                    header ("Location: opisneocene.php?idd=290&id=1&razred=".$VRazred);
                    break;
                */
                case "9": //"Izbor znanj za določen razred":
                    header ("Location: opisneocene.php?idd=275&id=0&razred=".$VRazred);
                    break;
                default:
                    echo "<html>";
                    echo "<head>";
                    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                    echo "<meta http-equiv='pragma' content='no-cache' > ";
                    echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                    echo "<title>Vnosi in spiski";
                    echo "</title>";
                    echo "<style type='text/css'>";
                    echo ".break { page-break-before: always; }";
                    echo "input.groovybutton";
                    echo "{";
                    echo "   font-size:8px;";
                    echo "   font-weight:bold;";
                    echo "   width:18px;";
                    echo "}";
                    echo "</style>";
                    echo "</head>";
                    echo "<body>";
                    
                    $n=$VLevel;
                    include('menu_func.inc');
                    include ('menu.inc');
                    
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                    }
                    //'Prebere podatke o ucencih izbranega razreda
                    $SQL = "SELECT tabrazred.iducenec,tabrazred.iducitelj,tabrazred.idvzgojitelj, ";
                    $SQL = $SQL . "tabucitelji.priimek AS ucpriimek, tabucitelji.ime AS ucime, ";
                    $SQL = $SQL . "tabvzgojitelji.priimek AS vpriimek, tabvzgojitelji.ime AS vime, ";
                    $SQL = $SQL . "tabucenci.priimek AS upriimek,tabucenci.ime AS uime FROM ";
                    $SQL = $SQL . "(tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
                        $IdUcitelj=$R["iducitelj"];
                        $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                        $IdVzgojitelj=$R["idvzgojitelj"];
                    }

                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Ucenci[$Indx][0]=$R["iducenec"];
                        $Ucenci[$Indx][1]=mb_substr($R["upriimek"],0,1,$encoding).".".mb_substr($R["uime"],0,1,$encoding).".";
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx;

                    //'prebere podatke o opisnih ocenah (znanjih) - staro
                    /*
                    switch ($VTip){
                        case "0":
                            if ($VPredmet==0){
                                $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=1 ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                            }else{
                                $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=1 AND tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                            }
                            break;
                        default:
                            if ($VPredmet==0){
                                $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=0 ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                            }else{
                                $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=0 AND tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                            }
                        
                    }
                    */
                    switch ($VTip){
                        case "0":   //spričevalo
                            $SQL = "SELECT * FROM tabopizbranipredmetis WHERE idrazred=$VRazred AND tip=4";
                            $result = mysqli_query($link,$SQL);
                            if (mysqli_num_rows($result) > 0){
                                if ($VPredmet==0){  
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                    $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                    $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                    $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=1 AND tabopizbranipredmetis.tip=4 AND tabopizbranipredmetis.idrazred=$VRazred ";
                                    $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }else{
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                    $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                    $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                    $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=1 AND tabopizbranipredmetis.tip=4 AND tabopcilji.Predmet=".$VPredmet." AND tabopizbranipredmetis.idrazred=$VRazred ";
                                    $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }
                            }else{
                                if ($VPredmet==0){  
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=1 ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }else{
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=1 AND tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }
                            }
                            break;
                        default:  //redovalnica
                            $SQL = "SELECT * FROM tabopizbranipredmetis WHERE idrazred=$VRazred AND tip < 4";
                            $result = mysqli_query($link,$SQL);
                            if (mysqli_num_rows($result) > 0){
                                if ($VPredmet==0){  
                                    switch ($VTip){
                                        case 2: //1. semester
                                            $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                            $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                            $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                            $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=0 AND tabopizbranipredmetis.tip IN (1,3) ";
                                            $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                            break;
                                        case 3: //2. semester
                                            $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                            $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                            $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                            $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=0 AND tabopizbranipredmetis.tip IN (2,3) ";
                                            $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                            break;
                                    }
                                }else{
                                    switch ($VTip){
                                        case 2: //1. semester
                                            $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                            $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                            $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                            $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=0 AND tabopizbranipredmetis.tip IN (1,3)  AND tabopcilji.Predmet=".$VPredmet." ";
                                            $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                            break;
                                        case 3: //2. semester
                                            $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM (tabopznanje ";
                                            $SQL .= "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                                            $SQL .= "INNER JOIN tabopizbranipredmetis ON tabopznanje.idznanje=tabopizbranipredmetis.idznanje ";
                                            $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopznanje.TipZnanja=0 AND tabopizbranipredmetis.tip IN (2,3)  AND tabopcilji.Predmet=".$VPredmet." ";
                                            $SQL .= "ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                            break;
                                    }
                                }
                            }else{
                                if ($VPredmet==0){  
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=0 ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }else{
                                    $SQL = "SELECT tabopcilji.*,tabopznanje.* FROM tabopznanje LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji WHERE tabopcilji.Razred=".$VRazred1." AND TipZnanja=0 AND tabopcilji.Predmet=".$VPredmet." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                                }
                            }
                        
                    }
                    
                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Znanje[$Indx][0]=$R["IdZnanje"];
                        $Znanje[$Indx][1]=$R["OpisZnanja"];
                        $Znanje[$Indx][2]=$R["Razred"];
                        $Znanje[$Indx][3]=$R["Predmet"];
                        $Znanje[$Indx][4]=$R["OpisCilja"];
                        $Indx=$Indx+1;
                    }
                    $StZnanj=$Indx;

                    for ($IndxZ=0;$IndxZ <= $StZnanj;$IndxZ++){
                        for ($IndxU=0;$IndxU <= $StUcencev;$IndxU++){
                            $Redovalnica[$IndxZ][$IndxU]=0;
                        }
                    }

                    //'prebere obstojece ocene za ucence iz TabOpOcene
                    if ($VPredmet==0){
                        $SQL = "SELECT TabOpOcene.*,tabopznanje.*,tabopcilji.* FROM ";
                        $SQL = $SQL . "(TabOpOcene INNER JOIN tabopznanje ON TabOpOcene.OpOcena=tabopznanje.IdZnanje) ";
                        $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." AND tabopcilji.Razred=".$VRazred1." AND tip=".$VTip;
                        $SQL = $SQL ." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopznanje.IdCilji,tabopznanje.IdZnanje";
                    }else{
                        $SQL = "SELECT TabOpOcene.*,tabopznanje.*,tabopcilji.* FROM ";
                        $SQL = $SQL . "(TabOpOcene INNER JOIN tabopznanje ON TabOpOcene.OpOcena=tabopznanje.IdZnanje) ";
                        $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." AND tabopcilji.Razred=".$VRazred1." AND tip=".$VTip." AND tabopcilji.Predmet=".$VPredmet;
                        $SQL = $SQL ." ORDER BY tabopcilji.Razred,tabopcilji.Predmet,tabopznanje.IdCilji,tabopznanje.IdZnanje";
                    }
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Redovalnica[VpisOceneZ($R["OpOcena"])][VpisOceneU($R["IdUcenec"])]=1;
                        $Indx=$Indx+1;
                    }

                    //'izpise redovalnico. Ce je vrednost polja 1, je checkbox izbran
                    echo "Razred: ".$VRazred1.". ".$VParalelka."<br />";
                    echo "Razrednik: ".$Ucitelj."<br />";
                    echo "Šolsko leto: ".$VLeto."/".($VLeto+1);
                    echo "<form name='form_OpisneOcene' method=post action='opisneocene.php'>";
                    echo "<input name='idd' type='hidden' value='220'>";

                    echo "<input type='hidden' name='stucencev' value='".$StUcencev."'>";
                    echo "<input type='hidden' name='predmet' value='".$VPredmet."'>";
                    echo "<input type='hidden' name='stznanj' value='".$StZnanj."'>";
                    echo "<input type='hidden' name='leto' value='".$VLeto."'>";
                    echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                    echo "<input type='hidden' name='tip' value='".$VTip."'>";
                    echo "<table border=1>";
                    echo "<tr><th>Predmet</th><th>Cilj</th><th>Znanje</th>";
                    for ($Indx=0;$Indx < $StUcencev;$Indx++){
                        echo "<th><a href='ucenec_pregled.php?ucenec=".$Ucenci[$Indx][0]."#redovalnica'>".$Ucenci[$Indx][1]."</a></th>";
                    }
                    echo "</tr>";

                    $StVrstic=1;
                    for ($Indx=0;$Indx < $StZnanj;$Indx++){
                        $StVrstic=$StVrstic+1;
                        if ($StVrstic % 10 == 0){
                            echo "<tr><th>Predmet</th><th>Cilj</th><th>Znanje</th>";
                            for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                                echo "<th><a href='ucenec_pregled.php?ucenec=".$Ucenci[$IndxUc][0]."#redovalnica'>".$Ucenci[$IndxUc][1]."</a></th>";
                            }
                            echo "</tr>";
                        }
                        echo "<tr>";
                        echo "<td>".ToPredmet($Znanje[$Indx][3])."</td>";
                        echo "<td>".$Znanje[$Indx][4]."</td>";
                        echo "<td>".$Znanje[$Indx][1]."</td>";
                        for ($Indx0=0;$Indx0 < $StUcencev;$Indx0++){
                            if ($Redovalnica[$Indx][$Indx0]==1){
                                echo "<td>";
                                echo "<input name='zn_".$Indx."' type='hidden' value='".$Znanje[$Indx][0]."'>";
                                echo "<input name='uc_".$Indx0."' type='hidden' value='".$Ucenci[$Indx0][0]."'>";
                                echo "<input type='checkbox' name='znanje_".$Indx."_".$Indx0."' checked='checked'>";
                                echo "</td>";
                            }else{
                                echo "<td>";
                                echo "<input name='zn_".$Indx."' type='hidden' value='".$Znanje[$Indx][0]."'>";
                                echo "<input name='uc_".$Indx0."' type='hidden' value='".$Ucenci[$Indx0][0]."'>";
                                echo "<input type='checkbox' name='znanje_".$Indx."_".$Indx0."'>";
                                echo "</td>";
                            }
                        }
                        echo "</tr>";
                    }
                    echo "</table>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";

                    echo "</form>";

                    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

                    echo "</body>";
                    echo "</html>";
            }
        }else{
            header("Location: opisneocene.php?idd=200");
        }
        break;
    case "220": //insert op ocen
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $StUcencev = $_POST["stucencev"];
        echo "Učencev: ".$StUcencev."<br />";
        $StZnanj = $_POST["stznanj"];
        echo "Znanj: ".$StZnanj."<br />";
        $tip = $_POST["tip"];
        
        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }
        
        echo $VRazred1.". ".$VParalelka.", ".$tip."<br />";

        for ($Indx=0;$Indx < $StUcencev;$Indx++){
            for ($Indx0=0;$Indx0 < $StZnanj;$Indx0++){
                if (isset($_POST["znanje_".$Indx0."_".$Indx])){
                    $SQL = "SELECT tabopocene.*,tabucenci.priimek,tabucenci.ime FROM tabopocene INNER JOIN tabucenci ON tabopocene.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE tabopocene.IdUcenec=".$_POST["uc_".$Indx]." AND OpOcena=".$_POST["zn_".$Indx0]." AND tip=".$tip;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "Znanje je že vpisano: ".$R["priimek"]." ".$R["ime"].", ".$R["OpOcena"]." ".$R["Tip"]."<br />";
                    }else{
                        $SQL = "SELECT priimek,ime FROM tabucenci WHERE iducenec=".$_POST["uc_".$Indx];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "Vpis znanja: ".$R["priimek"]." ".$R["ime"].", ".$_POST["zn_".$Indx0]." ".$tip."<br />";
                            $SQL = "INSERT INTO tabopocene (leto,IdUcenec,OpOcena,Tip) VALUES (".$VLeto.",".$_POST["uc_".$Indx].",".$_POST["zn_".$Indx0].",".$tip.")";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ocene!<br />$SQL <br />");
                            }
                        }
                    }
                }else{
                    $SQL = "SELECT tabopocene.*,tabucenci.priimek,tabucenci.ime FROM tabopocene INNER JOIN tabucenci ON tabopocene.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE tabopocene.IdUcenec=".$_POST["uc_".$Indx]." AND OpOcena=".$_POST["zn_".$Indx0]." AND tip=".$tip;
                    $result = mysqli_query($link,$SQL);
                    //če pri oceni ni kljukice, pa je bila v bazi že od prej, jo pobriše
                    if ($R = mysqli_fetch_array($result)){
                        echo "Brisanje znanja: ".$R["priimek"]." ".$R["ime"].", ".$R["OpOcena"]." ".$R["Tip"]."<br />";
                        $SQL = "DELETE FROM tabopocene WHERE id=".$R["Id"];
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die ("Napaka pri brisanju ocene!<br />$SQL <br />");
                        }
                    }
                }
            }
        }
        echo "<br />Podatki so bili uspešno vpisani!<br /><br />";
        echo "<a href='opisneocene.php?idd=200'>Nazaj na vnos ocen</a><br />";
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "230": //op spricevala 1. stran (z izbiranjem)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];

        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch ($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo1_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo1_2016.jpg",0,0,210);
                        break;
                }
            }
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,97-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
             
            $OpisneOcene=$oUcenec->getOpisneOcene($VLeto,0);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["SLJ"]["predmet"]);
            $pdf->SetXY(15+$KorX,152-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["SLJ"]["ocena"]);
            $pdf->SetXY(15+$KorX,157-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
            
            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["MAT"]["predmet"]);
            $pdf->SetXY(15+$KorX,210-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["MAT"]["ocena"]);
            $pdf->SetXY(15+$KorX,215-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran1.pdf","D");
        break;

    case "231": //op spricevala 1. stran (z izbiranjem) (HTML -> PDF)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];

        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch ($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo1_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo1_2016.jpg",0,0,210);
                        break;
                }
            }
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,97-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
             
            $OpisneOcene=$oUcenec->getOpisneOcene($VLeto,0);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $html="";
            $pdf->SetXY(15+$KorX,152-$KorY);
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            
            $txt=ToWin($OpisneOcene["SLJ"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["SLJ"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["MAT"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["MAT"]["ocena"]);
            $html .= $txt."<br><br>";

            $pdf->WriteHTML($html);
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran1.pdf","D");
        break;
    case "240": //op spricevala 2. stran
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];
        
        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo2_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo2_2016.jpg",0,0,210);
                        break;
                }
            }
            //Izpis osebnih podatkov
            
            $pdf->SetFont('arial_CE','',6);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(3,3);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $OpisneOcene=$oUcenec->getOpisneOcene($VLeto,0);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["LUM"]["predmet"]);
                //$pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->SetXY(15+$KorX,15-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["LVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,25-$KorY);
                $pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["LVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->SetXY(15+$KorX,15-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["LVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,25-$KorY);
                $pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }
            
            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["GUM"]["predmet"]);
                //$pdf->SetXY(15+$KorX,62-$KorY);
                $pdf->SetXY(15+$KorX,52-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["GVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,67-$KorY);
                $pdf->SetXY(15+$KorX,57-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["GVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,62-$KorY);
                $pdf->SetXY(15+$KorX,52-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["GVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,67-$KorY);
                $pdf->SetXY(15+$KorX,57-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }

            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["SPO"]["predmet"]);
            //$pdf->SetXY(15+$KorX,110-$KorY);
            $pdf->SetXY(15+$KorX,89-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["SPO"]["ocena"]);
            //$pdf->SetXY(15+$KorX,115-$KorY);
            $pdf->SetXY(15+$KorX,96-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
            
            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["ŠPO"]["predmet"]);
                //$pdf->SetXY(15+$KorX,164-$KorY);
                $pdf->SetXY(15+$KorX,144-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["ŠVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,169-$KorY);
                $pdf->SetXY(15+$KorX,149-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["ŠVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,164-$KorY);
                $pdf->SetXY(15+$KorX,144-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["ŠVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,169-$KorY);
                $pdf->SetXY(15+$KorX,149-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }

            if ((($VLeto == 2015) && ($VRazred1 == 1)) or (($VLeto > 2015)) ) {
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["TJA"]["predmet"]);
                $pdf->SetXY(15+$KorX,175-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["TJA"]["ocena"]);
                $pdf->SetXY(15+$KorX,180-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(68.0+$KorX, 224-$KorY, 117+$KorX, 224-$KorY);
            }else{
                $pdf->Line(120.0+$KorX, 224-$KorY, 143+$KorX, 224-$KorY);
            }
            
            $pdf->SetLeftMargin(10);
            $pdf->SetRightMargin(10);
            $pdf->SetFont('arial_CE','',$FontSize);
            
            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,236-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 283.8-$KorY, 44+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 283.8-$KorY, 31+$KorX, 283.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 282.8-$KorY, 164+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 283.8-$KorY, 151+$KorX, 283.8-$KorY);
            }
            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran2.pdf","D");
        break;

    case "241": //op spricevala 2. stran (HTML to PDF)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];
        
        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo2_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo2_2016.jpg",0,0,210);
                        break;
                }
            }
            //Izpis osebnih podatkov
            
            $pdf->SetFont('arial_CE','',6);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(3,3);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $OpisneOcene=$oUcenec->getOpisneOcene($VLeto,0);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $html="";
            $pdf->SetXY(15+$KorX,15-$KorY);
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            
            $txt=ToWin($OpisneOcene["LUM"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["LVZ"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["GUM"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["GVZ"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["SPO"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["SPO"]["ocena"]);
            $html .= $txt."<br><br>";

            $txt=ToWin($OpisneOcene["ŠPO"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["ŠVZ"]["ocena"]);
            $html .= $txt."<br><br>";

            if ((($VLeto == 2015) && ($VRazred1 == 1)) or (($VLeto > 2015)) ) {
                $txt=ToWin($OpisneOcene["TJA"]["predmet"]);
                $html .= "<b>$txt</b><br>";
                $txt=ToWin($OpisneOcene["TJA"]["ocena"]);
                $html .= $txt."<br><br>";
            }
            $pdf->WriteHTML($html);
            
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(68.0+$KorX, 224-$KorY, 117+$KorX, 224-$KorY);
            }else{
                $pdf->Line(120.0+$KorX, 224-$KorY, 143+$KorX, 224-$KorY);
            }
            
            $pdf->SetLeftMargin(10);
            $pdf->SetRightMargin(10);
            $pdf->SetFont('arial_CE','',$FontSize);
            
            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,236-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 283.8-$KorY, 44+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 283.8-$KorY, 31+$KorX, 283.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 282.8-$KorY, 164+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 283.8-$KorY, 151+$KorX, 283.8-$KorY);
            }
            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran2.pdf","D");
        break;
    case "250": //op spricevala 1a stran (ročni vpis)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->SetAutoPageBreak(false);
//$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];

        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo1_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo1_2016.jpg",0,0,210);
                        break;
                }
            }
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,97-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
             
            $OpisneOcene=$oUcenec->getOpisneOceneRocne($VLeto);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["SLJ"]["predmet"]);
            $pdf->SetXY(15+$KorX,152-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["SLJ"]["ocena"]);
            $pdf->SetXY(15+$KorX,157-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
            
            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["MAT"]["predmet"]);
            $pdf->SetXY(15+$KorX,210-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["MAT"]["ocena"]);
            $pdf->SetXY(15+$KorX,215-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran1.pdf","D");
        break;
    case "251": //op spricevala 1a stran (ročni vpis) (HTML -> PDF)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
//$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];

        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo1_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo1_2016.jpg",0,0,210);
                        break;
                }
            }
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,49.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,59.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,97-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,108-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
            //    $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            //}else{
                $txt=ToWin($oUcenec->getMaticniList());
            //}
            $pdf->SetXY(20+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,119-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
             
            $OpisneOcene=$oUcenec->getOpisneOceneRocne($VLeto);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $html="";
            $pdf->SetXY(15+$KorX,152-$KorY);
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            
            $txt=ToWin($OpisneOcene["SLJ"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["SLJ"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["MAT"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["MAT"]["ocena"]);
            $html .= $txt."<br><br>";

            $pdf->WriteHTML($html);
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran1.pdf","D");
        break;
    case "260": //op spricevala 2a stran
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];
        
        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo2_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo2_2016.jpg",0,0,210);
                        break;
                }
            }
            //Izpis osebnih podatkov
            $pdf->SetFont('arial_CE','',6);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(3,3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $OpisneOcene=$oUcenec->getOpisneOceneRocne($VLeto);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["LUM"]["predmet"]);
                //$pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->SetXY(15+$KorX,15-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["LUM"]["ocena"]);
                //$pdf->SetXY(15+$KorX,25-$KorY);
                $pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["LVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->SetXY(15+$KorX,15-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["LVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,25-$KorY);
                $pdf->SetXY(15+$KorX,20-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }
            
            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["GUM"]["predmet"]);
                //$pdf->SetXY(15+$KorX,62-$KorY);
                $pdf->SetXY(15+$KorX,52-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["GUM"]["ocena"]);
                //$pdf->SetXY(15+$KorX,67-$KorY);
                $pdf->SetXY(15+$KorX,57-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["GVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,62-$KorY);
                $pdf->SetXY(15+$KorX,52-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["GVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,67-$KorY);
                $pdf->SetXY(15+$KorX,57-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }

            $pdf->SetFont('arialbd_CE','',$FontSize);
            $txt=ToWin($OpisneOcene["SPO"]["predmet"]);
            //$pdf->SetXY(15+$KorX,110-$KorY);
            $pdf->SetXY(15+$KorX,95-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            $txt=ToWin($OpisneOcene["SPO"]["ocena"]);
            //$pdf->SetXY(15+$KorX,115-$KorY);
            $pdf->SetXY(15+$KorX,100-$KorY);
            $pdf->MultiCell(0,4,$txt,0,"J");
            
            if ($VLeto > 2012){
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["ŠPO"]["predmet"]);
                //$pdf->SetXY(15+$KorX,164-$KorY);
                $pdf->SetXY(15+$KorX,144-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["ŠPO"]["ocena"]);
                //$pdf->SetXY(15+$KorX,169-$KorY);
                $pdf->SetXY(15+$KorX,149-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }else{
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["ŠVZ"]["predmet"]);
                //$pdf->SetXY(15+$KorX,164-$KorY);
                $pdf->SetXY(15+$KorX,144-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["ŠVZ"]["ocena"]);
                //$pdf->SetXY(15+$KorX,169-$KorY);
                $pdf->SetXY(15+$KorX,149-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }

            if ((($VLeto == 2015) && ($VRazred1 == 1)) or (($VLeto > 2015)) ) {
                $pdf->SetFont('arialbd_CE','',$FontSize);
                $txt=ToWin($OpisneOcene["TJA"]["predmet"]);
                //$pdf->SetXY(15+$KorX,164-$KorY);
                $pdf->SetXY(15+$KorX,175-$KorY);
                $pdf->Cell(0,0,$txt,0,2,"L");
            
                $pdf->SetFont('arial_CE','',$FontSizeT);
                $txt=ToWin($OpisneOcene["TJA"]["ocena"]);
                //$pdf->SetXY(15+$KorX,169-$KorY);
                $pdf->SetXY(15+$KorX,180-$KorY);
                $pdf->MultiCell(0,4,$txt,0,"J");
            }
            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(68.0+$KorX, 224-$KorY, 117+$KorX, 224-$KorY);
            }else{
                $pdf->Line(120.0+$KorX, 224-$KorY, 143+$KorX, 224-$KorY);
            }
            
            $pdf->SetLeftMargin(10);
            $pdf->SetRightMargin(10);
            $pdf->SetFont('arial_CE','',$FontSize);
            
            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,236-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 283.8-$KorY, 44+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 283.8-$KorY, 31+$KorX, 283.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 282.8-$KorY, 164+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 283.8-$KorY, 151+$KorX, 283.8-$KorY);
            }
            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran2.pdf","D");
        break;

    case "261": //op spricevala 2a stran (HTML ->PDF)
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        if (isset($_GET["predogled"])){
            $Predogled=intval($_GET["predogled"]);
        }else{
            $Predogled=0;
        }
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new PDF();

        $pdf->SetAutoPageBreak(false);
        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");
        $pdf->SetAutoPageBreak(0);

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;
        $FontSizeT=8;
        $FontSizeT=$_SESSION["fs"];
        
        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            if ($IndxRazred > 1){
                $pdf->AddPage("P","A4");
            }
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if ($Predogled==1){
                switch($VLeto){
                    case 2013:
                    case 2014:
                    case 2015:
                        $pdf->Image("img/OpisnoSpricevalo2_2013.jpg",0,0,210);
                        break;
                    default:
                        $pdf->Image("img/OpisnoSpricevalo2_2016.jpg",0,0,210);
                        break;
                }
            }
            //Izpis osebnih podatkov
            $pdf->SetFont('arial_CE','',6);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(3,3);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $OpisneOcene=$oUcenec->getOpisneOceneRocne($VLeto);

            $pdf->SetLeftMargin(15);
            $pdf->SetRightMargin(15);

            $html="";
            $pdf->SetXY(15+$KorX,15-$KorY);
            
            $pdf->SetFont('arial_CE','',$FontSizeT);
            
            $txt=ToWin($OpisneOcene["LUM"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["LUM"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["GUM"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["GUM"]["ocena"]);
            $html .= $txt."<br><br>";
            
            $txt=ToWin($OpisneOcene["SPO"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["SPO"]["ocena"]);
            $html .= $txt."<br><br>";

            $txt=ToWin($OpisneOcene["ŠPO"]["predmet"]);
            $html .= "<b>$txt</b><br>";
            $txt=ToWin($OpisneOcene["ŠPO"]["ocena"]);
            $html .= $txt."<br><br>";

            if ((($VLeto == 2015) && ($VRazred1 == 1)) or (($VLeto > 2015)) ) {
                $txt=ToWin($OpisneOcene["TJA"]["predmet"]);
                $html .= "<b>$txt</b><br>";
                $txt=ToWin($OpisneOcene["TJA"]["ocena"]);
                $html .= $txt."<br><br>";
            }
            $pdf->WriteHTML($html);

            $pdf->SetDrawColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            if ($Razred["napredovanje"] < 2){
                $pdf->Line(68.0+$KorX, 224-$KorY, 117+$KorX, 224-$KorY);
            }else{
                $pdf->Line(120.0+$KorX, 224-$KorY, 143+$KorX, 224-$KorY);
            }
            
            $pdf->SetLeftMargin(10);
            $pdf->SetRightMargin(10);
            $pdf->SetFont('arial_CE','',$FontSize);
            
            //opombe
            if (strlen($Razred["opomba"]) == 0){
                $txt="  /  ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,236-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //kraj in datum
            if (strlen($Razred["datumizdaje"]) > 0){
                $txt=ToWin($VSolaKraj.", ".$Razred["datumizdaje"]);
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(20+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($Razred["evidst"]) > 0){
                $txt=ToWin($Razred["evidst"]);
            }else{
                $txt=ToWin($RefStFix.$RefStVar);
            }
            $pdf->SetXY(143+$KorX,262.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
            
            if ($Razred["spolr"]=="M" ){
                $pdf->Line(34.0+$KorX, 283.8-$KorY, 44+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(16.0+$KorX, 283.8-$KorY, 31+$KorX, 283.8-$KorY);
            }

            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154.0+$KorX, 282.8-$KorY, 164+$KorX, 283.8-$KorY);
            }else{
                $pdf->Line(138.0+$KorX, 283.8-$KorY, 151+$KorX, 283.8-$KorY);
            }
            //razrednik
            $txt=ToWin($Razred["razrednik"]);
            $pdf->SetXY(20+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(143+$KorX,276-$KorY);
            $pdf->Cell(0,5,$txt,0,2,"L");
        }    
        //'zanka za izpis razreda - konec
            
        $pdf->Output("OpisnaSpricevalaStran2.pdf","D");
        break;
    case "270": //obvestilo o op ocenah
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $VFile="opisnaspricevala".$Danes->format('YmdHis').".rtf";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1 \\deff0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f1\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}"."\n");
        fwrite ($fh,"{\\f2\\fmodern\\fcharset238\\fprq1{\\*\\panose 02070309020205020404}Courier New;}{\\f23\\froman\\fcharset128\\fprq1{\\*\\panose 00000000000000000000}MS Mincho{\\*\\falt ?? ??};}{\\f143\\froman\\fcharset128\\fprq1{\\*\\panose 00000000000000000000}@MS Mincho;}"."\n");
        fwrite ($fh,"{\\f144\\froman\\fcharset238\\fprq2 Times New Roman CE;}{\\f145\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\f147\\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f148\\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
        fwrite ($fh,"{\\f149\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f150\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\f151\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f152\\fswiss\\fcharset238\\fprq2 Arial CE;}"."\n");
        fwrite ($fh,"{\\f153\\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f155\\fswiss\\fcharset161\\fprq2 Arial Greek;}{\\f156\\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f157\\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f158\\fswiss\\fcharset178\\fprq2 Arial (Arabic);}"."\n");
        fwrite ($fh,"{\\f159\\fswiss\\fcharset186\\fprq2 Arial Baltic;}{\\f160\\fmodern\\fcharset238\\fprq1 Courier New CE;}{\\f161\\fmodern\\fcharset204\\fprq1 Courier New Cyr;}{\\f163\\fmodern\\fcharset161\\fprq1 Courier New Greek;}{\\f164\\fmodern\\fcharset162\\fprq1 Courier New Tur;}"."\n");
        fwrite ($fh,"{\\f165\\fmodern\\fcharset177\\fprq1 Courier New (Hebrew);}{\\f166\\fmodern\\fcharset178\\fprq1 Courier New (Arabic);}{\\f167\\fmodern\\fcharset186\\fprq1 Courier New Baltic;}}{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;"."\n");
        fwrite ($fh,"\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;"."\n");
        fwrite ($fh,"\\red128\\green128\\blue128;\\red192\\green192\\blue192;}{\\stylesheet{\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{"."\n");
        fwrite ($fh,"\\s1\\qc \\li0\\ri0\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\itap0 \\b\\f1\\fs52\\lang1033\\langfe1060\\cgrid\\langnp1033\\langfenp1060 \\sbasedon0 \\snext0 heading 1;}{"."\n");
        fwrite ($fh,"\\s2\\qc \\li0\\ri0\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\itap0 \\b\\fs72\\lang1033\\langfe1060\\cgrid\\langnp1033\\langfenp1060 \\sbasedon0 \\snext0 heading 2;}{\\*\\cs10 \\additive Default Paragraph Font;}{"."\n");
        fwrite ($fh,"\\s15\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f2\\fs20\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext15 Plain Text;}}"."\n");
        fwrite ($fh,"\\paperw11909\\paperh16834\\margl864\\margr864\\margt864\\margb864 \\widowctrl\\ftnbj\\aenddoc\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dghspace180\\dgvspace180\\dghorigin1701\\dgvorigin1984\\dghshow0\\dgvshow0"."\n");
        fwrite ($fh,"\\jexpand\\viewkind4\\viewscale100\\pgbrdrhead\\pgbrdrfoot\\bdrrlswsix\\nolnhtadjtbl \\fet0\\sectd \\psz9\\linex0\\headery706\\footery706\\colsx708\\endnhere\\sectdefaultcl {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl2"."\n");
        fwrite ($fh,"\\pnucltr\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6"."\n");
        fwrite ($fh,"\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang"."\n");
        fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}"."\n");
        fwrite ($fh,"\\pard\\plain \\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060"."\n");
 
        //uvodna stran
        fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033"."\n");

        //'izpiše podatke o šoli
        fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF("REPUBLIKA SLOVENIJA")."}"."\n");
        fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs144\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs72\\lang1033\\langfe1060\\langnp1033 \\qc {".ToRTF("REDOVALNICA")."}"."\n");
        fwrite ($fh,"\\fs72\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF("Prvega vzgojno izobraževalnega obdobja devetletne šole")."}"."\n");
        fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs200\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033 \\qc {\\b ".ToRTF($VSola)."}"."\n");

        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VSolaNaslov) ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {__________________________________}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF("ime in sedež šole") ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        //fwrite ($fh,"\\par "."\n");
        
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VRazred1.". ".$VParalelka) ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {__________________________________}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF("razred, oddelek") ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        //fwrite ($fh,"\\par "."\n");

        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VLeto."/".($VLeto+1)) ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {__________________________________}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF("šolsko leto") ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033\\par \n");
        //fwrite ($fh,"\\par "."\n");

        fwrite ($fh,"\\fs120\\lang1033\\langfe1060\\langnp1033\\par \n");
        
        $SQL = "SELECT DISTINCT tabucitelji.priimek,tabucitelji.ime,tabucitelji.spol FROM tabucitelji INNER JOIN tabrazred ON tabucitelji.iducitelj=tabrazred.iducitelj WHERE tabrazred.idrazred=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            fwrite ($fh,"\\fs28\\lang1033\\langfe1060\\langnp1033 \\ql \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab {".ToRTF($R["ime"]." ".$R["priimek"]) ."}"."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 {_____________________________} \\tab \\tab \\tab \\tab \\tab {_____________________________}"."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 \n");
            if ($R["spol"]=="M"){
                fwrite ($fh," \\tab ".ToRTF("učiteljica, učitelj")." \\tab \\tab \\tab \\tab \\tab \\tab \\tab razrednik\n");
            }else{
                fwrite ($fh," \\tab ".ToRTF("učiteljica, učitelj")." \\tab \\tab \\tab \\tab \\tab \\tab \\tab ".ToRTF("razredničarka")."\n");
            }
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs60\\lang1033\\langfe1060\\langnp1033\\par \n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 {_____________________________} \\tab \\tab \\tab \\tab \\tab {_____________________________}"."\n");
            //fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\par \\tab podpis \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab podpis\n");
            fwrite ($fh,"\\par "."\n");
        }        
        fwrite ($fh,"\\page}"."\n");
        
    //začetek strani za učenca
        fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033"."\n");

        $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[$Indx]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
            //'izpiše podatke o šoli
            fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VSola)."}"."\n");

            fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VSolaNaslov) ."}"."\n");
            fwrite ($fh,"\\par "."\n");
            switch ($Vid){
                case "1":
                case "4":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Obvestilo o opisnih ocenah prvega polletja }"."\n");
                    break;
                case "2":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Redovalnica opisnih ocen - 1. semester }"."\n");
                    break;
                case "3":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Redovalnica opisnih ocen - 2. semester }"."\n");
            }
            fwrite ($fh,"\\par "."\n");
                 
            //Izpis osebnih podatkov
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            fwrite ($fh,"\\par ".ToRTF($oUcenec->getIme() . " " . $oUcenec->getPriimek())."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql Datum rojstva: ".$oUcenec->getDatRoj()."\n");
            fwrite ($fh,"\\par ".ToRTF("Kraj in država rojstva: ").ToRTF($oUcenec->getKrajRoj().", ". $oUcenec->getDrzavaRoj())."\n");

            //Izpis razrednih podatkov
            fwrite ($fh,"\\par Razred: ".ToRTF($Razred["razred"].". ".$Razred["paralelka"])."\n");
            fwrite ($fh,"\\par ".ToRTF("Šolsko leto: ").$Razred["solskoleto"]."\n");
            fwrite ($fh,"\\par "."\n");
                
            //'izpis opisne ocene slovenscine
            $OpisneOcene=$oUcenec->getOpisneOcene($VLeto,$Vid);
            
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["SLJ"]["predmet"])."} "."\n");
            fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["SLJ"]["ocena"])." "."\n");
            
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["MAT"]["predmet"])."} "."\n");
            fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["MAT"]["ocena"])." "."\n");

            if ($VLeto > 2012){
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["LUM"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["LVZ"]["ocena"])." "."\n");
            }else{
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["LVZ"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["LVZ"]["ocena"])." "."\n");
            }
            if ($VLeto > 2012){
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["GUM"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["GVZ"]["ocena"])." "."\n");
            }else{
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["GVZ"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["GVZ"]["ocena"])." "."\n");
            }
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["SPO"]["predmet"])."} "."\n");
            fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["SPO"]["ocena"])." "."\n");
            
            if ($VLeto > 2012){
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["ŠPO"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["ŠVZ"]["ocena"])." "."\n");
            }else{
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["ŠVZ"]["predmet"])."} "."\n");
                fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["ŠVZ"]["ocena"])." "."\n");
            }
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF($OpisneOcene["TJA"]["predmet"])."} "."\n");
            fwrite ($fh,"\\par - ".ToRTF($OpisneOcene["TJA"]["ocena"])." "."\n");

            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\par ".ToRTF($VSolaKraj.", ".$PrintDay)."\n");
            fwrite ($fh,"\\par "."\n");
            if ($Razred["spolr"]=="M"){
                fwrite ($fh,"\\par Razrednik: ".ToRTF($Razred["razrednik"])."\n");
            }else{
                fwrite ($fh,"\\par ".ToRTF("Razredničarka: ").ToRTF($Razred["razrednik"])."\n");
            }
            fwrite ($fh,"\\par "."\n");
            
            fwrite ($fh,"\\page}"."\n");
            fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033 ");
        }

        //zadnja stran
        //fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033"."\n");

        fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs200\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs200\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs200\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs200\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF("Kraj in datum:") ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc {".ToRTF($VSolaKraj.", ".$PrintDay) ."}"."\n");
        //fwrite ($fh,"\\par "."\n");
        fwrite ($fh,"\\fs32\\lang1033\\langfe1060\\langnp1033\\par \\qc \n");
        //fwrite ($fh,"\\par "."\n");

        fwrite ($fh,"\\fs120\\lang1033\\langfe1060\\langnp1033\\par \n");
        
        $SQL = "SELECT DISTINCT tabucitelji.priimek,tabucitelji.ime,tabucitelji.spol FROM tabucitelji INNER JOIN tabrazred ON tabucitelji.iducitelj=tabrazred.iducitelj WHERE tabrazred.idrazred=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            fwrite ($fh,"\\fs28\\lang1033\\langfe1060\\langnp1033 \\ql \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab {".ToRTF($R["ime"]." ".$R["priimek"]) ."}"."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 {_____________________________} \\tab \\tab \\tab \\tab \\tab {_____________________________}"."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 \n");
            if ($R["spol"]=="M"){
                fwrite ($fh," \\tab ".ToRTF("učiteljica, učitelj")." \\tab \\tab \\tab \\tab \\tab \\tab \\tab razrednik\n");
            }else{
                fwrite ($fh," \\tab ".ToRTF("učiteljica, učitelj")." \\tab \\tab \\tab \\tab \\tab \\tab \\tab ".ToRTF("razredničarka")."\n");
            }
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs60\\lang1033\\langfe1060\\langnp1033\\par \n");
            fwrite ($fh,"\\fs20\\lang1033\\langfe1060\\langnp1033 {_____________________________} \\tab \\tab \\tab \\tab \\tab {_____________________________}"."\n");
            //fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\par \\tab podpis \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab \\tab podpis\n");
            fwrite ($fh,"\\par "."\n");
        }        
        fwrite ($fh,"}"."\n");
        
        fwrite ($fh,"}}"."\n");

        fclose($fh);
        
        switch ($Vid){
            case "1":
            case "4":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri obvestila o opisnih ocenah</a></h2>";
                break;
            case "2":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri redovalnico opisnih ocen 1. semestra</a></h2>";
                break;
            case "3":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri redovalnico opisnih ocen 2. semestra</a></h2>";
        }
        echo "<a href='izpisredovalnice.php'>Izpis redovalnice razreda</a><br />";
        echo "<a href='opisneocene.php?idd=200'>Nazaj na vnos ocen</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "275": //izbor znanj za določen razred
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //tabopizbranipredmeti
        if ($VRazred > 0){ //le, če je izbran razred
            $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=$VRazred";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1 = $R["razred"];
                $VParalelka = $R["oznaka"];
            }else{
                $VRazred1 = 0;
                $VParalelka = ""; 
            }
            
            switch ($Vid){
                case "0": //izbira predmetov iz nabora vseh
                    //pogleda znanja
                    if ($VPredmet==0){
                        $SQL = "SELECT tabopciljin.predmet,tabopznanje.idznanje,tabopznanje.opisznanja,tabopznanje.tipznanja FROM tabopznanje ";
                        $SQL .= "LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji ";
                        $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." ";
                        $SQL .= "ORDER BY tabopznanje.tipznanja,tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                    }else{
                        $SQL = "SELECT tabopcilji.predmet,tabopznanje.idznanje,tabopznanje.opisznanja,tabopznanje.tipznanja FROM tabopznanje ";
                        $SQL .= "LEFT JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji ";
                        $SQL .= "WHERE tabopcilji.Razred=".$VRazred1." AND tabopcilji.Predmet=".$VPredmet;
                        $SQL .= " ORDER BY tabopznanje.tipznanja,tabopcilji.Razred,tabopcilji.Predmet,tabopcilji.IdCilji,tabopznanje.IdZnanje";
                    }
                    $result = mysqli_query($link,$SQL);
                    $i=0;
                    while ($R = mysqli_fetch_array($result)){
                        $i++;
                        $znanja[$i][0]=$R["idznanje"];
                        $znanja[$i][1]=$R["predmet"];
                        $znanja[$i][2]=$R["opisznanja"];
                        $znanja[$i][3]=$R["tipznanja"];
                    }
                    $StZnanj=$i;
                    
                    //pogleda že izbrana znanja
                    $SQL = "SELECT * FROM tabopizbranipredmetis WHERE idrazred=$VRazred";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $izbrano[$R["idznanje"]]=$R["tip"];
                    }
                    
                    //izpis tabele znanja z upoštevanjem izbranih znanj
                    //pri vsakem je možnost izbire: 0-ni izbran, 1-1.semester, 2-2.semester, 3-oba semestra, 4-spričevalo
                    echo "<br />";
                    echo "Navodilo: <br />X - znanje ne bo v naboru za ocenjevanje<br />";
                    echo "1s - znanje bo v naboru redovalnice 1. semestra<br />";
                    echo "2s - znanje bo v naboru redovalnice 2. semestra<br />";
                    echo "I - znanje bo v naboru redovalnice 1. in 2. semestra<br />";
                    echo "S - znanje bo v naboru znanj za spričevalo<br />";
                    echo "<small>Znanja za spričevalo so lahko le sivo obarvana!</small><br />";
                    echo "<br />";
                    echo "<form  name='izbira' method='post' action='opisneocene.php'>";
                    echo "<input name='idd' type='hidden' value='275'>";
                    echo "<input name='id' type='hidden' value='1'>"; //vpis podatkov
                    echo "<input name='razred' type='hidden' value='$VRazred'>";
                    echo "<input name='predmet' type='hidden' value='$VPredmet'>";
                    echo "<h2>Nabor znanj v dokumentih za $VRazred1. $VParalelka</h2>";
                    echo "<table border='1'>";
                    echo "<tr><th>št.</th><th width='120'>X&nbsp;&nbsp;1s 2s I&nbsp;&nbsp;S</th><th>predmet</th><th>opis znanja</th></tr>";
                    for ($i=1;$i <= $StZnanj;$i++){
                        if ($znanja[$i][3]==1){
                            echo "<tr bgcolor='lightgrey'>";
                        }else{
                            echo "<tr>";
                        }
                        echo "<td>$i</td>";
                        echo "<td><input name='pr_$i' type='hidden' value='".$znanja[$i][0]."'>";
                        if (isset($izbrano[$znanja[$i][0]])){
                            if ($izbrano[$znanja[$i][0]]==0){
                                echo "<input name='zn_$i' type='radio' value='0' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='0'>";
                            }
                            if ($izbrano[$znanja[$i][0]]==1){
                                echo "<input name='zn_$i' type='radio' value='1' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='1'>";
                            }
                            if ($izbrano[$znanja[$i][0]]==2){
                                echo "<input name='zn_$i' type='radio' value='2' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='2'>";
                            }
                            if ($izbrano[$znanja[$i][0]]==3){
                                echo "<input name='zn_$i' type='radio' value='3' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='3'>";
                            }
                            if ($izbrano[$znanja[$i][0]]==4){
                                echo "<input name='zn_$i' type='radio' value='4' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='4'>";
                            }
                        }else{ //ni vpisa - upošteva oba semestra ali spričevalo - glede na tip
                            echo "<input name='zn_$i' type='radio' value='0'>";
                            echo "<input name='zn_$i' type='radio' value='1'>";
                            echo "<input name='zn_$i' type='radio' value='2'>";
                            if ($znanja[$i][3]==0){
                                echo "<input name='zn_$i' type='radio' value='3' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='3'>";
                            }
                            if ($znanja[$i][3]==1){
                                echo "<input name='zn_$i' type='radio' value='4' checked='checked'>";
                            }else{
                                echo "<input name='zn_$i' type='radio' value='4'>";
                            }
                        }
                        echo "</td>";
                        switch ($znanja[$i][1]){
                            case 16:
                                echo "<td>SLJ</td>";
                                break;
                            case 11:
                                echo "<td>MAT</td>";
                                break;
                            case 9:
                                echo "<td>LUM</td>";
                                break;
                            case 29:
                                echo "<td>GUM</td>";
                                break;
                            case 49:
                                echo "<td>SPO</td>";
                                break;
                            case 20:
                                echo "<td>ŠPO</td>";
                                break;
                            case 26:
                                echo "<td>N1A/TJA</td>";
                                break;
                            case 183:
                                echo "<td>DRU (OŠPP)</td>";
                                break;
                            case 13:
                                echo "<td>NAR (OŠPP)</td>";
                                break;
                            case 25:
                                echo "<td>TIT (OŠPP)</td>";
                                break;
                            case 51:
                                echo "<td>GOS (OŠPP)</td>";
                                break;
                        }
                        echo "<td>".$znanja[$i][2]."</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                    echo "<input name='stznanj' type='hidden' value='$StZnanj'>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    break;
                case "1":
                    $StZnanj = $_POST["stznanj"];
                    for ($i=1;$i <= $StZnanj;$i++){
                        $tip = $_POST["zn_$i"];
                        $znanje = $_POST["pr_$i"];
                        $SQL = "SELECT id FROM tabopizbranipredmetis WHERE idrazred=$VRazred AND idznanje=$znanje";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabopizbranipredmetis SET tip=$tip WHERE id=".$R["id"];
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri prepisu!<br />$SQL <br />");
                            }
                        }else{
                            $SQL = "INSERT INTO tabopizbranipredmetis (idrazred,idznanje,tip) VALUES ($VRazred,$znanje,$tip)";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu!<br />$SQL <br />");
                            }
                        }
                    }
                    echo "<br /><a href='opisneocene.php?idd=200'>Na redovalnico opisnih ocen</a>";
                    break;
            }
        }
        break;
    case "280": //razred op spricevala - ročni vpis
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br /><br />";
        $SQL = "SELECT * FROM TabRazDat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "SELECT tabrazred.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime,tabucenci.maticnilist, ";
        $SQL = $SQL . "tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime, ";
        $SQL = $SQL . "tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucenci.datroj FROM ";
        $SQL = $SQL . "(tabvzgojitelji INNER JOIN ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";

        $result = mysqli_query($link,$SQL);

        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";

        if ($R = mysqli_fetch_array($result)){
            $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
            $IdUcitelj=$R["IdUcitelj"];
            $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
            $IdVzgojitelj=$R["IdVzgojitelj"];

            echo "Učitelj: " . $Ucitelj . "<br />";
            if ($VRazred1==1){
                echo "Drugi učitelj: " . $Vzgojitelj . "<br />";
            }else{
                echo "Učitelj OPB: " . $Vzgojitelj . "<br />";
            }
        }

        echo "<table border=1><tr><th>Št.</th><th>Mat. list</th><th>Priimek in ime</th><th>Datum rojstva</th><th>Vnos ocen</th></tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Datum=new DateTime(isDate($R["datroj"]));
            echo "<tr><td>" . $Indx ."</td><td>" . $R["maticnilist"] . "</td><td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"] ."'>" . $R["upriimek"] . ", " . $R["uime"] . "</a></td><td align='right'>" . $Datum->format('d.m.Y') . "</td><td align=center><a href='opisneocene.php?idd=281&id=".$R["IdUcenec"] ."&razred=".$VRazred."'>Ocene</a></td></tr>";
            $Indx=$Indx+1;
        }

        echo "</table>";

        echo "<h3>Če ste že prenašali in na roke popravljali, potem ne klikajte na ponovni prenos!</h3>";
        echo "<h2><a href='opisneocene.php?idd=282&submit=vsi&razred=".$VRazred."&solskoleto=".$VLeto."'>Uvozi ocene za cel razred vse predmete</a> (prepiše obstoječe podatke!)</h2>";
        
        echo "<a href='izpisredovalnice.php'>Izpis redovalnice razreda</a><br />";
        echo "<a href='opisneocene.php?idd=200'>Opisna redovalnica (izpisi)</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "281": //ucenec op ocene
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $ucenec = $Vid;

        $SQL = "SELECT * FROM TabRazDat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $Indx=0;
        echo "<form name='form_opOcene' method=post action='opisneocene.php'>";
        echo "<input name='idd' type='hidden' value='282'>";
        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
        echo "<input type='hidden' name='ucenec' value='".$ucenec."'>";
        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";

        $SQL = "SELECT priimek,ime FROM tabucenci WHERE idUcenec=".$ucenec;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $ucenecIme=$R["priimek"].", ".$R["ime"];
        }

        $SQL = "SELECT tabucenci.*,tabopocucenec.* FROM tabucenci LEFT JOIN tabopocucenec ON tabucenci.idUcenec=tabopocucenec.ucenec WHERE tabopocucenec.leto=".$VLeto." AND tabucenci.idUcenec=".$ucenec;
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            echo "Razred: ".$VRazred1.". ".$VParalelka."<br />";
            echo "Učenec: ".$R["Priimek"].", ".$R["Ime"]."<br /><br />";
            echo "<input name='submit' type='submit' value='Shrani'><br /> Če ste znanja označevali s kljukicami in jih želite prenesti v spodnja polja, kliknite tu:<input name='submit' type='submit' value='Uvozi ocene'> (Sicer gumb pustite pri miru, ker boste vse zbrisali!)<br /><br />";
            echo "Slovenščina<br />";
            echo "<textarea name='slo' cols='80' rows='10'>".$R["slo"]."</textarea><br />";
            echo "Matematika<br />";
            echo "<textarea name='mat' cols='80' rows='10'>".$R["mat"]."</textarea><br />";
            if ($VLeto > 2012){
                echo "Likovna umetnost<br />";
            }else{
                echo "Likovna vzgoja<br />";
            }
            echo "<textarea name='lvz' cols='80' rows='10'>".$R["lvz"]."</textarea><br />";
            if ($VLeto > 2012){
                echo "Glasbena umetnost<br />";
            }else{
                echo "Glasbena vzgoja<br />";
            }
            echo "<textarea name='gvz' cols='80' rows='10'>".$R["gvz"]."</textarea><br />";
            if ($VLeto > 2012){
                echo "Šport<br />";
            }else{
                echo "Športna vzgoja<br />";
            }
            echo "<textarea name='svz' cols='80' rows='10'>".$R["svz"]."</textarea><br />";
            switch ($VRazred1){
                case 1:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'>".$R["spo"]."</textarea><br />";
                    echo "Angleščina<br />";
                    echo "<textarea name='tja' cols='80' rows='10'>".$R["rez"]."</textarea><br />";
                    break;
                case 2:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'>".$R["spo"]."</textarea><br />";
                    echo "Angleščina<br />";
                    echo "<textarea name='tja' cols='80' rows='10'>".$R["rez"]."</textarea><br />";
                    break;
                case 3:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'>".$R["spo"]."</textarea><br />";
                    break;
                case 4:
                case 5:
                    echo "Naravoslovje<br />";
                    echo "<textarea name='nar' cols='80' rows='10'>".$R["nar"]."</textarea><br />";
                    echo "Družboslovje<br />";
                    echo "<textarea name='dru' cols='80' rows='10'>".$R["dru"]."</textarea><br />";
                    break;
                case 6:
                    echo "Naravoslovje<br />";
                    echo "<textarea name='nar' cols='80' rows='10'>".$R["nar"]."</textarea><br />";
                    echo "Družboslovje<br />";
                    echo "<textarea name='dru' cols='80' rows='10'>".$R["dru"]."</textarea><br />";
                    echo "Tehnika in tehnologija<br />";
                    echo "<textarea name='tit' cols='80' rows='10'>".$R["tit"]."</textarea><br />";
                    echo "Gospodinjstvo<br />";
                    echo "<textarea name='gos' cols='80' rows='10'>".$R["gos"]."</textarea><br />";
            }
        }else{
            echo "Razred: <b>".$VRazred1.". ".$VParalelka."</b><br />";
            echo "Učenec: <b>".$ucenecIme."</b><br /><br />";
            echo "<input name='submit' type='submit' value='Shrani'> <input name='submit' type='submit' value='Uvozi ocene'><br /><br />";
            echo "Slovenščina<br />";
            echo "<textarea name='slo' cols='80' rows='10'></textarea><br />";
            echo "Matematika<br />";
            echo "<textarea name='mat' cols='80' rows='10'></textarea><br />";
            if ($VLeto > 2012){
                echo "Likovna umetnost<br />";
            }else{
                echo "Likovna vzgoja<br />";
            }
            echo "<textarea name='lvz' cols='80' rows='10'></textarea><br />";
            if ($VLeto > 2012){
                echo "Glasbena umetnost<br />";
            }else{
                echo "Glasbena vzgoja<br />";
            }
            echo "<textarea name='gvz' cols='80' rows='10'></textarea><br />";
            if ($VLeto > 2012){
                echo "Šport<br />";
            }else{
                echo "Športna vzgoja<br />";
            }
            echo "<textarea name='svz' cols='80' rows='10'></textarea><br />";
            switch ($VRazred1){
                case 1:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'></textarea><br />";
                    echo "Angleščina<br />";
                    echo "<textarea name='tja' cols='80' rows='10'></textarea><br />";
                    break;
                case 2:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'></textarea><br />";
                    echo "Angleščina<br />";
                    echo "<textarea name='tja' cols='80' rows='10'></textarea><br />";
                    break;
                case 3:
                    echo "Spoznavanje okolja<br />";
                    echo "<textarea name='spo' cols='80' rows='10'></textarea><br />";
                    break;
                case 4:
                case 5:
                    echo "Naravoslovje<br />";
                    echo "<textarea name='nar' cols='80' rows='10'></textarea><br />";
                    echo "Družboslovje<br />";
                    echo "<textarea name='dru' cols='80' rows='10'></textarea><br />";
                    break;
                case 6:
                    echo "Naravoslovje<br />";
                    echo "<textarea name='nar' cols='80' rows='10'></textarea><br />";
                    echo "Družboslovje<br />";
                    echo "<textarea name='dru' cols='80' rows='10'></textarea><br />";

                    echo "Tehnika in tehnologija<br />";
                    echo "<textarea name='tit' cols='80' rows='10'></textarea><br />";
                    echo "Gospodinjstvo<br />";
                    echo "<textarea name='gos' cols='80' rows='10'></textarea><br />";
            }
        }
        echo "<input name='submit' type='submit' value='Shrani'>";
        echo "</form>";
        echo "<a href='opisneocene.php?idd=200'>Opisna redovalnica (izpisi)</a><br />";
        echo "<a href='opisneocene.php?idd=280&razred=".$VRazred."&solskoleto=".$VLeto."'>Na ročni vnos opisnih ocen</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "282": //vpis op ocene ucenec
        if (isset($_POST["ucenec"])){
            $ucenec = $_POST["ucenec"];
        }else{
            if (isset($_GET["ucenec"])){
                $ucenec=$_GET["ucenec"];
            }else{
                $ucenec = 0;
            }
        }
        if (isset($_POST["submit"])){
            $Izbira = $_POST["submit"];
        }else{
            if (isset($_GET["submit"])){
                $Izbira=$_GET["submit"];
            }else{
                $Izbira = 0;
            }
        }
        if (isset($_GET["id"])){
            $potrdi=$_GET["id"];
        }else{
            $potrdi=0;
        }
            
        switch ($Izbira){
            case "vsi":
                if ($potrdi=="1"){
                    $SQL = "SELECT iducenec FROM tabrazred WHERE idRazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenci[$Indx]=$R["iducenec"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx-1;
                
                    for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                        $ucenec=$ucenci[$Indx];
                        $SQL="SELECT * FROM tabrazred WHERE idUcenec=".$ucenec." AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            if (($VLevel < 1) or (($VLevel==1) && ($Prijavljeni != $R["IdUcitelj"]))){
                                header ("Location: nepooblascen.htm");
                            }
                        }else{
                            header ("Location: nepooblascen.htm");
                        }
                        $SQL = "SELECT tabopocene.*, tabopcilji.*,tabopznanje.* FROM (tabopocene ";
                        $SQL = $SQL . "INNER JOIN tabopznanje ON tabopocene.OpOcena=tabopznanje.idZnanje) ";
                        $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.idCilji=tabopcilji.idCilji ";
                        $SQL = $SQL . "WHERE tabopocene.idUcenec=".$ucenec." AND tabopocene.leto=".$VLeto." AND tabopcilji.OpisCilja='Spričevalo'";
                        $result = mysqli_query($link,$SQL);
                        
                        $Vslo = "";
                        $Vmat = "";
                        $Vlvz = "";
                        $Vgvz = "";
                        $Vspo = "";
                        $Vsvz = "";
                        $Vdru = "";
                        $Vnar = "";
                        $Vtit = "";
                        $Vtja = "";

                        $Vgos = "";
                        while ($R = mysqli_fetch_array($result)){
                            switch ($R["Predmet"]){
                                case 16: //'SLO
                                    $Vslo=$Vslo." ".$R["OpisZnanja"];
                                    break;
                                case 11: // 'MAT
                                    $Vmat=$Vmat." ".$R["OpisZnanja"];
                                    break;
                                case 9: // 'LVZ
                                    $Vlvz=$Vlvz." ".$R["OpisZnanja"];
                                    break;
                                case 29: // 'GVZ
                                    $Vgvz=$Vgvz." ".$R["OpisZnanja"];
                                    break;
                                case 49: // 'SPO
                                    $Vspo=$Vspo." ".$R["OpisZnanja"];
                                    break;
                                case 20: // 'ŠVZ
                                    $Vsvz=$Vsvz." ".$R["OpisZnanja"];
                                    break;
                                case 26: // 'TJA
                                    $Vtja=$Vtja." ".$R["OpisZnanja"];
                                    break;
                                case 183: // 'DRU
                                    $Vdru=$Vdru." ".$R["OpisZnanja"];
                                    break;
                                case 13: // 'NAR
                                    $Vnar=$Vnar." ".$R["OpisZnanja"];
                                    break;
                                case 25: // 'TIT
                                    $Vtit=$Vtit." ".$R["OpisZnanja"];
                                    break;
                                case 51: //'GOS
                                    $Vgos=$Vgos." ".$R["OpisZnanja"];
                            }
                        }

                        $SQL = "SELECT id FROM tabopocucenec WHERE ucenec=".$ucenec." AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE  tabopocucenec SET slo='" . $Vslo . "',mat='".$Vmat."',lvz='".$Vlvz."',gvz='".$Vgvz."',spo='".$Vspo."',svz='".$Vsvz."',nar='".$Vnar."',dru='".$Vdru."',tit='".$Vtit."',gos='".$Vgos."',rez='".$Vtja."',vpisal='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabopocucenec (ucenec,leto,slo,mat,lvz,gvz,spo,svz,nar,dru,tit,gos,rez,vpisal,datum) VALUES (".$ucenec.",".$VLeto.",'".$Vslo."','".$Vmat."','".$Vlvz."','".$Vgvz."','".$Vspo."','".$Vsvz."','".$Vnar."','".$Vdru."','".$Vtit."','".$Vgos."','".$Vtja."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                        }
                        $result = mysqli_query($link,$SQL);
                    }
                    header ("Location: opisneocene.php?idd=280&razred=".$VRazred."&solskoleto=".$VLeto);
                }else{
                    echo "<html>";
                    echo "<head>";
                    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                    echo "<meta http-equiv='pragma' content='no-cache' > ";
                    echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                    echo "<title>Opisne ocene";
                    echo "</title>";
                    echo "<style type='text/css'>";
                    echo ".break { page-break-before: always; }";
                    echo "input.groovybutton";
                    echo "{";
                    echo "   font-size:8px;";
                    echo "   font-weight:bold;";
                    echo "   width:18px;";
                    echo "}";
                    echo "</style>";
                    echo "</head>";
                    echo "<body>";
                    $n=$VLevel;
                    include('menu_func.inc');
                    include ('menu.inc');
                    echo "<h2>Če resnično želite PREPISATI obstoječe podatke s podatki iz VNOSA S KLJUKICAMI, kliknite na spodnjo povezavo.</h2>";
                    echo "<a href='opisneocene.php?idd=282&id=1&submit=vsi&razred=".$VRazred."&solskoleto=".$VLeto."'>Uvozi ocene za cel razred vse predmete</a> (prepiše/pobriše obstoječe podatke!)";
                    echo "</body>";
                    echo "</html>";
                }
                break;
            case "Uvozi ocene":
                $SQL="SELECT iducitelj FROM tabrazred WHERE idUcenec=".$ucenec." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                $DovoljenVpis=true;
                if ($R = mysqli_fetch_array($result)){
                    if ($Prijavljeni != $R["iducitelj"]){
                        if ($VLevel < 2){
                            $DovoljenVpis=false;
                            header ("Location: nepooblascen.htm");
                        }
                    }
                }else{
                    $DovoljenVpis=false;
                    header ("Location: nepooblascen.htm");
                }
                if ($DovoljenVpis){
                    $SQL = "SELECT tabopocene.*, tabopcilji.*,tabopznanje.* FROM (tabopocene ";
                    $SQL = $SQL . "INNER JOIN tabopznanje ON tabopocene.OpOcena=tabopznanje.idZnanje) ";
                    $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.idCilji=tabopcilji.idCilji ";
                    $SQL = $SQL . "WHERE tabopocene.idUcenec=".$ucenec." AND tabopocene.leto=".$VLeto." AND tabopcilji.OpisCilja='Spričevalo'";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vslo = "";
                    $Vmat = "";
                    $Vlvz = "";
                    $Vgvz = "";
                    $Vspo = "";
                    $Vsvz = "";
                    while ($R = mysqli_fetch_array($result)){
                        switch ($R["Predmet"]){
                            case 16: // 'SLO
                                $Vslo=$Vslo." ".$R["OpisZnanja"];
                                break;
                            case 11: // 'MAT
                                $Vmat=$Vmat." ".$R["OpisZnanja"];
                                break;
                            case 9: // 'LVZ
                                $Vlvz=$Vlvz." ".$R["OpisZnanja"];
                                break;
                            case 29: // 'GVZ
                                $Vgvz=$Vgvz." ".$R["OpisZnanja"];
                                break;
                            case 49: // 'SPO
                                $Vspo=$Vspo." ".$R["OpisZnanja"];
                                break;
                            case 20: // 'ŠVZ
                                $Vsvz=$Vsvz." ".$R["OpisZnanja"];
                                break;
                            case 26: // 'TJA
                                $Vtja=$Vtja." ".$R["OpisZnanja"];
                        }
                    }

                    $SQL = "SELECT id FROM tabopocucenec WHERE ucenec=".$ucenec." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE  tabopocucenec SET slo='" . $Vslo . "',mat='".$Vmat."',lvz='".$Vlvz."',gvz='".$Vgvz."',spo='".$Vspo."',svz='".$Vsvz."',rez='".$Vtja."',vpisal='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabopocucenec (ucenec,leto,slo,mat,lvz,gvz,spo,svz,rez,vpisal,datum) VALUES (".$ucenec.",".$VLeto.",'".$Vslo."','".$Vmat."','".$Vlvz."','".$Vgvz."','".$Vspo."','".$Vsvz."','".$Vtja."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                    }
                    $result = mysqli_query($link,$SQL);
                    header ("Location: opisneocene.php?idd=281&id=".$ucenec."&razred=".$VRazred);
                }
                break;
            case "Shrani":
                $Vslo = $_POST["slo"];
                $Vmat = $_POST["mat"];
                $Vlvz = $_POST["lvz"];
                $Vgvz = $_POST["gvz"];
                $Vspo = $_POST["spo"];
                $Vsvz = $_POST["svz"];
                $Vtja = $_POST["tja"];
                $Vnar = $_POST["nar"];
                $Vdru = $_POST["dru"];
                $Vtit = $_POST["tit"];
                $Vgos = $_POST["gos"];

                $SQL = "SELECT id FROM tabopocucenec WHERE ucenec=".$ucenec." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE  tabopocucenec SET slo='" . $Vslo . "',mat='".$Vmat."',lvz='".$Vlvz."',gvz='".$Vgvz."',spo='".$Vspo."',svz='".$Vsvz."',nar='".$Vnar."',dru='".$Vdru."',tit='".$Vtit."',gos='".$Vgos."',rez='".$Vtja."',vpisal='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabopocucenec (ucenec,leto,slo,mat,lvz,gvz,spo,svz,nar,dru,tit,gos,rez,vpisal,datum) VALUES (".$ucenec.",".$VLeto.",'".$Vslo."','".$Vmat."','".$Vlvz."','".$Vgvz."','".$Vspo."','".$Vsvz."','".$Vnar."','".$Vdru."','".$Vtit."','".$Vgos."','".$Vtja."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                }
                $result = mysqli_query($link,$SQL);
                header ("Location: opisneocene.php?idd=280&razred=".$VRazred);
        }
        break;
    case "290": //obvestilo o op ocenah ošpp
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $VFile="opisnaspricevala".$Danes->format('YmdHis').".rtf";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["Razred"];
            $VParalelka=$R["oznaka"];
        }

        fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1 \\deff0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f1\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}"."\n");
        fwrite ($fh,"{\\f2\\fmodern\\fcharset238\\fprq1{\\*\\panose 02070309020205020404}Courier New;}{\\f23\\froman\\fcharset128\\fprq1{\\*\\panose 00000000000000000000}MS Mincho{\\*\\falt ?? ??};}{\\f143\\froman\\fcharset128\\fprq1{\\*\\panose 00000000000000000000}@MS Mincho;}"."\n");
        fwrite ($fh,"{\\f144\\froman\\fcharset238\\fprq2 Times New Roman CE;}{\\f145\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\f147\\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f148\\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
        fwrite ($fh,"{\\f149\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f150\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\f151\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f152\\fswiss\\fcharset238\\fprq2 Arial CE;}"."\n");
        fwrite ($fh,"{\\f153\\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f155\\fswiss\\fcharset161\\fprq2 Arial Greek;}{\\f156\\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f157\\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f158\\fswiss\\fcharset178\\fprq2 Arial (Arabic);}"."\n");
        fwrite ($fh,"{\\f159\\fswiss\\fcharset186\\fprq2 Arial Baltic;}{\\f160\\fmodern\\fcharset238\\fprq1 Courier New CE;}{\\f161\\fmodern\\fcharset204\\fprq1 Courier New Cyr;}{\\f163\\fmodern\\fcharset161\\fprq1 Courier New Greek;}{\\f164\\fmodern\\fcharset162\\fprq1 Courier New Tur;}"."\n");
        fwrite ($fh,"{\\f165\\fmodern\\fcharset177\\fprq1 Courier New (Hebrew);}{\\f166\\fmodern\\fcharset178\\fprq1 Courier New (Arabic);}{\\f167\\fmodern\\fcharset186\\fprq1 Courier New Baltic;}}{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;"."\n");
        fwrite ($fh,"\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;"."\n");
        fwrite ($fh,"\\red128\\green128\\blue128;\\red192\\green192\\blue192;}{\\stylesheet{\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{"."\n");
        fwrite ($fh,"\\s1\\qc \\li0\\ri0\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\itap0 \\b\\f1\\fs52\\lang1033\\langfe1060\\cgrid\\langnp1033\\langfenp1060 \\sbasedon0 \\snext0 heading 1;}{"."\n");
        fwrite ($fh,"\\s2\\qc \\li0\\ri0\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\itap0 \\b\\fs72\\lang1033\\langfe1060\\cgrid\\langnp1033\\langfenp1060 \\sbasedon0 \\snext0 heading 2;}{\\*\\cs10 \\additive Default Paragraph Font;}{"."\n");
        fwrite ($fh,"\\s15\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f2\\fs20\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext15 Plain Text;}}"."\n");
        fwrite ($fh,"\\paperw11909\\paperh16834\\margl864\\margr864\\margt864\\margb864 \\widowctrl\\ftnbj\\aenddoc\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dghspace180\\dgvspace180\\dghorigin1701\\dgvorigin1984\\dghshow0\\dgvshow0"."\n");
        fwrite ($fh,"\\jexpand\\viewkind4\\viewscale100\\pgbrdrhead\\pgbrdrfoot\\bdrrlswsix\\nolnhtadjtbl \\fet0\\sectd \\psz9\\linex0\\headery706\\footery706\\colsx708\\endnhere\\sectdefaultcl {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl2"."\n");
        fwrite ($fh,"\\pnucltr\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang{\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6"."\n");
        fwrite ($fh,"\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang"."\n");
        fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}"."\n");
        fwrite ($fh,"\\pard\\plain \\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060"."\n");
        fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033"."\n");

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
        $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci[0]=$R["iducenec"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($Ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
        
            //'izpiše podatke o šoli
            fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VSola)."}"."\n");

            fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b ".ToRTF($VSolaNaslov) ."}"."\n");
                fwrite ($fh,"\\par "."\n");
            switch ($Vid){
                case "1":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Obvestilo o opisnih ocenah prvega polletja }"."\n");
                    break;
                case "2":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Redovalnica opisnih ocen - 1. semester }"."\n");
                    break;
                case "3":
                    fwrite ($fh,"\\fs36\\lang1033\\langfe1060\\langnp1033\\par \\qc {\\b Redovalnica opisnih ocen - 2. semester }"."\n");
            }
            fwrite ($fh,"\\par "."\n");
                 
            //Izpis osebnih podatkov

            fwrite ($fh,"\\par ".ToRTF($oUcenec->getIme()  . " " . $oUcenec->getPriimek())."\n");
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql Datum rojstva: ".$oUcenec->getDatRoj()."\n");
            fwrite ($fh,"\\par ".ToRTF("Kraj in država rojstva: ").ToRTF($oUcenec->getKrajRoj().", ". $oUcenec->getDrzavaRoj())."\n");

            fwrite ($fh,"\\par Razred: ".ToRTF($Razred["razred"].". ".$Razred["paralelka"])."\n");
            fwrite ($fh,"\\par ".ToRTF("Šolsko leto: ").$Razred["solskoleto"]."\n");
            fwrite ($fh,"\\par "."\n");
                
            //'izpis opisne ocene 
            $SQL = "SELECT tabopocucenec.* FROM tabopocucenec ";
            switch ($Vid){
                case "1":
                    $SQL = $SQL . "WHERE tabopocucenec.Ucenec=".$Ucenci[$IndxRazred]." AND tabopocucenec.leto=".$VLeto." ";
                    break;
                case "2":
                    $SQL = $SQL . "WHERE tabopocucenec.Ucenec=".$Ucenci[$IndxRazred]." AND tabopocucenec.leto=".$VLeto." ";
                    break;
                case "3":
                    $SQL = $SQL . "WHERE tabopocucenec.Ucenec=".$Ucenci[$IndxRazred]." AND tabopocucenec.leto=".$VLeto." ";
            }
            $result = mysqli_query($link,$SQL);
            
            $OpOcena[$IndxRazred][0]="";
            while ($R = mysqli_fetch_array($result)){
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Slovenščina")."} "."\n");
                fwrite ($fh,"\\par - ".$R["slo"]." "."\n");
                fwrite ($fh,"\\par "."\n");
                fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Matematika} "."\n");
                fwrite ($fh,"\\par - ".$R["mat"]." "."\n");
                if ($VLeto > 2012){
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Likovna umetnost} "."\n");
                    fwrite ($fh,"\\par - ".$R["lvz"]." "."\n");
                }else{
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Likovna vzgoja} "."\n");
                    fwrite ($fh,"\\par - ".$R["lvz"]." "."\n");
                }
                if ($VLeto > 2012){
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Glasbena umetnost} "."\n");
                    fwrite ($fh,"\\par - ".$R["gvz"]." "."\n");
                }else{
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Glasbena vzgoja} "."\n");
                    fwrite ($fh,"\\par - ".$R["gvz"]." "."\n");
                }
                if ($VLeto > 2012){
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Šport")."} "."\n");
                    fwrite ($fh,"\\par - ".$R["svz"]." "."\n");
                }else{
                    fwrite ($fh,"\\par "."\n");
                    fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Športna vzgoja")."} "."\n");
                    fwrite ($fh,"\\par - ".$R["svz"]." "."\n");
                }
                fwrite ($fh,"\\par "."\n");
                switch ($VRazred1){
                    case 1:
                    case 2:
                    case 3:
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Spoznavanje okolja} "."\n");
                        fwrite ($fh,"\\par - ".$R["spo"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Angleščina")."} "."\n");
                        fwrite ($fh,"\\par - ".$R["rez"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        break;
                    case 4:
                    case 5:
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Družboslovje")."} "."\n");
                        fwrite ($fh,"\\par - ".$R["dru"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Naravoslovje} "."\n");
                        fwrite ($fh,"\\par - ".$R["nar"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        break;
                    case 6:
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b ".ToRTF("Družboslovje")."} "."\n");
                        fwrite ($fh,"\\par - ".$R["dru"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Naravoslovje} "."\n");
                        fwrite ($fh,"\\par - ".$R["nar"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Tehnika in tehnologija} "."\n");
                        fwrite ($fh,"\\par - ".$R["tit"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                        fwrite ($fh,"\\fs24\\lang1033\\langfe1060\\langnp1033\\par \\ql {\\b Gospodinjstvo} "."\n");
                        fwrite ($fh,"\\par - ".$R["gos"]." "."\n");
                        fwrite ($fh,"\\par "."\n");
                }
            } 
            fwrite ($fh,"\\par "."\n");
            fwrite ($fh,"\\par ".ToRTF($VSolaKraj.", ".$PrintDay)."\n");
            fwrite ($fh,"\\par "."\n");
            if ($Razred["spolr"]=="M"){
                fwrite ($fh,"\\par Razrednik: ".ToRTF($Razred["razrednik"])."\n");
            }else{
                fwrite ($fh,"\\par ".ToRTF("Razredničarka: ").ToRTF($Razred["razrednik"])."\n");
            }
            fwrite ($fh,"\\par "."\n");
            
            fwrite ($fh,"\\page}"."\n");
            fwrite ($fh,"{\\fs24\\lang1033\\langfe1060\\langnp1033 ");

        }

        fwrite ($fh,"}}"."\n");

        switch ($Vid){
            case "1":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri obvestila o opisnih ocenah</a></h2>";
                break;
            case "2":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri redovalnico opisnih ocen 1. semestra</a></h2>";
                break;
            case "3":
                echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri redovalnico opisnih ocen 2. semestra</a></h2>";
        }
        echo "<a href='izpisredovalnice.php'>Izpis redovalnice razreda</a><br />";
        echo "<a href='opisneocene.php?idd=200'>Opisna redovalnica (izpisi)</a><br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a>";
        echo "</body>";
        echo "</html>";
        break;
}
?>