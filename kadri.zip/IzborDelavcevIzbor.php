<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis zaposlenih
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

?>
<form name="rezultati" method=post action="IzpisDelavcevIzbor.php">
<h2>Izpis zaposlenih</h2><br>
<table border=0>
<tr><td>Izberi polja za izpis:</td><td>Pogoj in kriteriji iskanja</td></tr>
<tr>
<td><input name="polje2" type="checkbox" checked>Priimek in ime</td>
</tr>
<tr>
<td><input name="polje9" type="checkbox" >Spol</td>
</tr>
<tr>
<td><input name="polje3" type="checkbox" >Datum rojstva</td>
</tr>
<tr>
<td><input name="polje28" type="checkbox" >Kraj rojstva</td>
<td>
<tr>
<td><input name="polje4" type="checkbox" >Naslov</td>
</tr>
<tr>
<td><input name="polje5" type="checkbox" >Pošta</td>
</tr>
<tr>
<td><input name="polje6" type="checkbox" >Kraj</td>
</tr>
<tr>
<td><input name="polje11" type="checkbox" >EMŠO</td>
</tr>
<tr>
<td><input name="polje12" type="checkbox" >Izobrazba</td>
<td>
<select name="kriterij_izobr">
	<option value='0'>vsi</option>
	<option value='1'>večji od</option>
	<option value='2'>manjši od</option>
	<option value='3'>enak</option>
</select>
<select name="izobrazba">
<?php
$SQL ="SELECT * FROM TabIzobrazba";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    echo "<option value='".$R["idIzobrazba"]."'>".$R["Opis"]."</option>";
}

?>
</select></td>
</tr>
<tr>
<td><input name="polje14" type="checkbox" >Delo</td>
</tr>
<tr>
<td><input name="polje17" type="checkbox" >Datum začetka dela na šoli</td>
</tr>
<tr>
<td><input name="polje18" type="checkbox" >Datum zaključka dela na šoli</td>
</tr>
<tr>
<td><input name="polje19" type="checkbox" >Status</td>
</tr>
<tr>
<td><input name="polje20" type="checkbox" >Naziv</td>
<td>
<select name="kriterij_naziv">
	<option value='0'>enak</option>
	<option value='1'>večji od</option>
	<option value='2'>manjši od</option>
</select>
<select name="naziv">
	<option value="0">vsi</option>
	<option value="1">brez naziva</option>
	<option value="2">mentor</option>
	<option value="3">svetovalec</option>
	<option value="4">svetnik</option>
</select>
</td>
</tr>
<tr>
<td><input name="polje21" type="checkbox" >Prevoz</td>
</tr>
<tr>
<td><input name="polje23" type="checkbox" >Starejši delavec</td>
</tr>
<tr>
<td><input name="polje24" type="checkbox" >Doječa mati</td>
</tr>
<tr>
<td><input name="polje22" type="checkbox" >Dostopne pravice</td>
</tr>
<tr>
<td><input name="polje27" type="checkbox" >Dopusti</td>
</tr>
<tr bgcolor="lightyellow">
<td><input name="polje1" type="checkbox">Izpis učiteljev</td>
</tr>
<tr bgcolor="lightyellow">
<td><input name="polje7" type="checkbox" >Izpis strokovnih delavcev</td>
</tr>
<tr bgcolor="lightyellow">
<td><input name="polje8" type="checkbox" >Izpis tehničnega kadra</td>
</tr>
<tr bgcolor="lightyellow">
<td><input name="polje25" type="checkbox" checked>Izpis vseh - pedagoški, svetovalni in tehnični</td>
</tr>
<tr>
<td><input name="polje26" type="checkbox">Le zaposleni na šoli (brez gostujočih)</td>
</tr>
<tr>
<td><input name="polje13" type="checkbox" >Podpis</td>
</tr>
<tr>
	<td>
        <input name="StPolj" type="hidden" value="28">
		<input name="submit" type="submit" value="Pošlji">
	</td>
</tr>
</table>
</form>
</body>
</html>
