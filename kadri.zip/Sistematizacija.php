<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Sistemizacija
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("DelPregl",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    //' ime, predmet, razredi, ure
    //'ure: 0-ime, 1-predmet, 2-razredi, 3-urer (ure po razredih), 4-urep (ure po predmetih), 5-urev (ure pedagoske), 6-urePB (ure OPB), 7-idUcitelja, 8-idDelo

    echo "<h2>Razporeditve učiteljev za šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";
    $SQL = "SELECT id FROM tabucitelji WHERE status > 0";
    $result = mysqli_query($link,$SQL);
    $StUc=mysqli_num_rows($result);

    $SQL = "SELECT tabucenje.*, tabpredmeti.*, tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.IdUcitelj,tabucitelji.idDelo FROM " ;
    $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj ";
    $SQL = $SQL . " WHERE leto=".$VLeto." ORDER BY tabucitelji.idDelo,tabucitelji.Priimek,tabucitelji.Ime,tabucenje.IdUcitelj,tabpredmeti.VrstniRed,tabpredmeti.Id,tabucenje.Razred,tabucenje.Paralelka";
		    
    $result = mysqli_query($link,$SQL);

    //'Izpis v obliki spiska - zacetek -----------------------------------------------------------------------------------------------------------------------------------

    $SkupajUre=0;
    $BZdruzevanje=false;
    $BZdruzevanje1=false;

    for ($Indx=0;$Indx <= 10;$Indx++){
	    $izbirni[$Indx]=0;
	    $Nivoji[1][$Indx]=0;
	    $Nivoji[2][$Indx]=0;
	    $Nivoji[3][$Indx]=0;
	    $Nivoji[4][$Indx]=0;
	    $Nivoji[5][$Indx]=0;
	    $Nivoji[6][$Indx]=0;
    }

    $StIzbirni=0;
    $Sistemizacija=false;
    $Indx=1;
    $IndxRazrednik=0;
    while ($R = mysqli_fetch_array($result)){
	    $Sistemizacija=true;
	    if ($R["Predmet"]==50 ){
		    $Razredniki[$IndxRazrednik][0]=$R["Priimek"].", ".$R["Ime"];
		    $Razredniki[$IndxRazrednik][1]=$R["Razred"] . ". " . $R["Paralelka"];
		    $Razredniki[$IndxRazrednik][2]=$R["Razred"];
		    $Razredniki[$IndxRazrednik][3]=$R["Paralelka"];
		    $IndxRazrednik=$IndxRazrednik+1;
	    }
	    $Indx=$Indx+1;
    }

    for ($Indx = 0;$Indx <= ($IndxRazrednik-1);$Indx++){
	    for ($Indx0 = 0;$Indx0 <= ($IndxRazrednik-1);$Indx0++){
		    if ($Indx != $Indx0 ){
			    if ($Razredniki[$Indx][1] < $Razredniki[$Indx0][1] ){
				    $Razredniki[$IndxRazrednik][0]=$Razredniki[$Indx][0];
				    $Razredniki[$Indx][0]=$Razredniki[$Indx0][0];
				    $Razredniki[$Indx0][0]=$Razredniki[$IndxRazrednik][0];
				    $Razredniki[$IndxRazrednik][1]=$Razredniki[$Indx][1];
				    $Razredniki[$Indx][1]=$Razredniki[$Indx0][1];
				    $Razredniki[$Indx0][1]=$Razredniki[$IndxRazrednik][1];
			    }
		    }
	    }
    }
    echo "Razredniki: <br />";
    for ($Indx=0;$Indx <= ($IndxRazrednik-1);$Indx++){
	    echo $Razredniki[$Indx][1]." - ".$Razredniki[$Indx][0]."<br />";
    }
    //'Izpis v obliki spiska - konec --------------------------------------------------------------------------------------------------------------------------

    if ($Sistemizacija ){ 
        $result = mysqli_query($link,$SQL);
    }
    //'Izpis v obliki tabele (Crnuce) - zacetek ------------------------------------------------------------------------------------------------------------
    for ($IndxUc=0;$IndxUc <= $StUc;$IndxUc++){
        for ($IndxP=0;$IndxP <= 20;$IndxP++){
            for ($IndxR=0;$IndxR <= 12;$IndxR++){
                $UcDelo[$IndxUc][$IndxP][$IndxR][0]="";
                $UcDelo[$IndxUc][$IndxP][$IndxR][1]="";
                $UcDelo[$IndxUc][$IndxP][$IndxR][2]="";
                $UcDelo[$IndxUc][$IndxP][$IndxR][3]=0;
                $UcDelo[$IndxUc][$IndxP][$IndxR][4]=0;
                $UcDelo[$IndxUc][$IndxP][$IndxR][5]=0;
                $UcDelo[$IndxUc][$IndxP][$IndxR][6]=0;
                $UcDelo[$IndxUc][$IndxP][$IndxR][7]=0;
                $UcDelo[$IndxUc][$IndxP][$IndxR][8]=0;
            }
        }
    }

    $SkupajUre=0;
    $BZdruzevanje=false;
    $BZdruzevanje1=false;

    for ($Indx=0;$Indx<= 10;$Indx++){
        $izbirni[$Indx]=0;
        $Nivoji[1][$Indx]=0;
        $Nivoji[2][$Indx]=0;
        $Nivoji[3][$Indx]=0;
        $Nivoji[4][$Indx]=0;
        $Nivoji[5][$Indx]=0;
        $Nivoji[6][$Indx]=0;
    }

    $StIzbirni=0;

    $UciteljCompare="";
    $PredmetCompare="";
    $RazredCompare="";
    $CountUreR=0;
    $CountUreP=0;
    $CountUreV=0;
    $CountUrePB=0;
    $IndxUc=0;
    $IndxR=0;
    $IndxP=0;

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        if ($UciteljCompare != $R["Priimek"].", ".$R["Ime"]){
            $UcDelo[$IndxUc][$IndxP][$IndxR][3]=$CountUreR;
            $UcDelo[$IndxUc][1][1][4]=$CountUreP;
            $UcDelo[$IndxUc][1][1][5]=$CountUreV;
            $UcDelo[$IndxUc][1][1][6]=$CountUrePB;
            $UciteljCompare=$R["Priimek"].", ".$R["Ime"];
            $PredmetCompare="";
            $RazredCompare="";
            $IndxUc=$IndxUc+1;
            $IndxR=0;
            $IndxP=0;
            $CountUreR=0;
            $CountUreP=0;
            $CountUreV=0;
            $CountUrePB=0;
        }
        if ($PredmetCompare != $R["Oznaka"]){
            $UcDelo[$IndxUc][$IndxP][$IndxR][3]=$CountUreR;
            $PredmetCompare=$R["Oznaka"];
            $RazredCompare="";
            $IndxP=$IndxP+1;
            $IndxR=0;
            $CountUreR=0;
            for ($Indx0=0;$Indx0 <= 10;$Indx0++){
                $izbirni[$Indx0]=0;
                $Nivoji[1][$Indx0]=0;
                $Nivoji[2][$Indx0]=0;
                $Nivoji[3][$Indx0]=0;
                $Nivoji[4][$Indx0]=0;
                $Nivoji[5][$Indx0]=0;
                $Nivoji[6][$Indx0]=0;
            }
            $StIzbirni=0;
        }
        if ($RazredCompare != $R["Razred"]){
            $UcDelo[$IndxUc][$IndxP][$IndxR][3]=$CountUreR;
            $RazredCompare=$R["Razred"];
            $IndxR=$IndxR+1;
            $CountUreR=0;

            $BZdruzevanje=false;
        }

        $UcDelo[$IndxUc][$IndxP][$IndxR][0]=$R["Priimek"].", ".$R["Ime"];
        $UcDelo[$IndxUc][$IndxP][$IndxR][7]=$R["IdUcitelj"];
        switch ($R["Razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                $UcDelo[$IndxUc][0][0][8]=$UcDelo[$IndxUc][0][0][8]+1; // 'uči tudi na razredni stopnji
                break;
            case 6:
            case 7:
            case 8:
            case 9:
                $UcDelo[$IndxUc][1][1][8]=$UcDelo[$IndxUc][1][1][8]+1; //'u?i tudi na predmetni stopnji
        }
        switch ($R["Prioriteta"]){
            case 0:
                $UcDelo[$IndxUc][$IndxP][$IndxR][1]=$R["Oznaka"];
                break;
            case 1:
                $UcDelo[$IndxUc][$IndxP][$IndxR][1]="<font color='darkred'>".$R["Oznaka"]."</font>";
                break;
            case 2:
                $UcDelo[$IndxUc][$IndxP][$IndxR][1]=$R["Oznaka"];
                break;
            case 3:
                $UcDelo[$IndxUc][$IndxP][$IndxR][1]="<font color='green'>".$R["Oznaka"]."</font>";
        }
        if ($UcDelo[$IndxUc][$IndxP][$IndxR][2]==""){
            switch ($R["Razred"]){
                case 7:
                    if ($R["Prioriteta"]==1){
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='darkred'>".$R["Razred"].".".$R["Paralelka"];
                    }else{
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='green'>".$R["Razred"].".".$R["Paralelka"];
                    }
                    break;
                case 8:
                    if ($R["Prioriteta"]==1){
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='darkred'>".$R["Razred"].".".$R["Paralelka"];
                    }else{
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='darkblue'>".$R["Razred"].".".$R["Paralelka"];
                    }
                    break;
                case 9:
                    if ($R["Prioriteta"]==1){
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='darkred'>".$R["Razred"].".".$R["Paralelka"];
                    }else{
                        $UcDelo[$IndxUc][$IndxP][$IndxR][2]="<font color='red'>".$R["Razred"].".".$R["Paralelka"];
                    }
                    break;
                default: 
                    $UcDelo[$IndxUc][$IndxP][$IndxR][2]=$R["Razred"].".".$R["Paralelka"];
            }
        }else{
            $UcDelo[$IndxUc][$IndxP][$IndxR][2]=$UcDelo[$IndxUc][$IndxP][$IndxR][2].",".$R["Paralelka"];
        }
        
            
        switch ($R["Zdruzeno"]){
            case 1:
                $BZdruzevanje= !$BZdruzevanje;
                if ($BZdruzevanje){
                    $CountUreR=$CountUreR-$R["Planirano"];
                    $CountUreP=$CountUreP-$R["Planirano"];
                    $CountUreV=$CountUreV-$R["Planirano"];
                }
                break;
            case 2:
                $StIzbirni=0;
                while ($StIzbirni < 10){
                    if ($izbirni[$StIzbirni]==$R["Predmet"]){
                        switch ($R["Predmet"]){
                            case 52:
                            case 78:
                            case 79:
                            case 80:
                            case 81:
                            case 82:
                            case 83:
                            case 84:
                            case 85:
                            case 86:
                            case 87:
                            case 88:
                            case 89:
                            case 90:
                            case 91:
                                $CountUreR=$CountUreR-$R["Planirano"];
                                $CountUrePB=$CountUrePB-$R["Planirano"];
                                break;
                            default:
                                $CountUreR=$CountUreR-$R["Planirano"];
                                if ($R["Prioriteta"] < 3){
                                    $CountUreP=$CountUreP-$R["Planirano"];
                                }
                                $CountUreV=$CountUreV-$R["Planirano"];
                        }
                        break;
                    }
                    $StIzbirni=$StIzbirni+1;
                }
                if ($StIzbirni==10){
                    $StIzbirni=0;
                    while ($StIzbirni < 10){
                        if ($izbirni[$StIzbirni]==0){
                            $izbirni[$StIzbirni]=$R["Predmet"];
                            break;
                        }
                        $StIzbirni=$StIzbirni+1;
                    }
                }
                break;
            case 4:
            case 5:
            case 6:
                $StNivoji[$R["Zdruzeno"]]=0;
                while ($StNivoji[$R["Zdruzeno"]] < 10){
                    if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==($R["Predmet"].$R["Realizirano"])){
                        $CountUreR=$CountUreR-$R["Planirano"];
                        $CountUreP=$CountUreP-$R["Planirano"];
                        $CountUreV=$CountUreV-$R["Planirano"];
                        break;
                    }
                    $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                }
                if ($StNivoji[$R["Zdruzeno"]]==10){
                    $StNivoji[$R["Zdruzeno"]]=0;
                    while ($StNivoji[$R["Zdruzeno"]] < 10){
                        if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==0){
                            $Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]=$R["Predmet"].$R["Realizirano"];
                            break;
                        }
                        $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                    }
                }
        }   
                
        switch ($R["Predmet"]){
            case 52:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
            case 90:
            case 91:
                $CountUrePB=$CountUrePB+$R["Planirano"];
                $CountUreR=$CountUreR+$R["Planirano"];
                break;
            default:
                $CountUreV=$CountUreV+$R["Planirano"];
                $CountUreR=$CountUreR+$R["Planirano"];
            if ($R["Prioriteta"] < 3){
                $CountUreP=$CountUreP+$R["Planirano"];
            }
        }
        $Indx=$Indx+1;
    }    
    $UcDelo[$IndxUc][$IndxP][$IndxR][3]=$CountUreR;
    $UcDelo[$IndxUc][1][1][4]=$CountUreP;
    $UcDelo[$IndxUc][1][1][5]=$CountUreV;
    $UcDelo[$IndxUc][1][1][6]=$CountUrePB;
        
    for ($Indx=1;$Indx <= $IndxUc;$Indx++){
	    echo "<br /><table border='1' cellspacing='0' bgcolor='lightcyan'>";
	    echo "<th width='150'>Ime</th><th width='100'>Predmet</th><th width='60'>Razred</th><th width='30'>Ur</th><th width='30'>PU</th><th width='40'>Skupaj PU</th><th width='25'>OPB</th><th width='65'>Skupaj DU</th>";
	    for ($IndxP=1;$IndxP <= 20;$IndxP++){
		    for ($IndxR=1;$IndxR <= 12;$IndxR++){
			    if (($IndxR==1) && ($IndxP==1) ){
                    if ($UcDelo[$Indx][0][0][8] > $UcDelo[$Indx][1][1][8]){
                        echo "<tr bgcolor=lightyellow>";
                    }else{
                        echo "<tr bgcolor=lightcyan>";
                    }
				    echo "<td><a href='IzpisUcitelja.php?idUcitelj=".$UcDelo[$Indx][$IndxP][$IndxR][7]."'><b>".$UcDelo[$Indx][$IndxP][$IndxR][0]."</b></a></td>";
				    echo "<td>".$UcDelo[$Indx][$IndxP][$IndxR][1]."</td>";
				    echo "<td>".$UcDelo[$Indx][$IndxP][$IndxR][2]."</td>";
				    echo "<td align='center'>".$UcDelo[$Indx][$IndxP][$IndxR][3]."</td>";
				    echo "<td align='center' bgcolor='lightblue'>".$UcDelo[$Indx][$IndxP][$IndxR][4]."</td>";
				    echo "<td align='center' bgcolor='lightyellow'>".$UcDelo[$Indx][$IndxP][$IndxR][5]."</td>";
				    echo "<td align='center' bgcolor='lightgreen'>".$UcDelo[$Indx][$IndxP][$IndxR][6]."</td>";
				    echo "<td align='center' bgcolor='lightsalmon'>".($UcDelo[$Indx][$IndxP][$IndxR][5]*1.5+$UcDelo[$Indx][$IndxP][$IndxR][6]*1.3)."</td>";
				    echo "</tr>";
			    }else{ 
				    if ($IndxR==1 ){
					    if ($UcDelo[$Indx][$IndxP][$IndxR][2] != "" ){
                            if ($UcDelo[$Indx][0][0][8] > $UcDelo[$Indx][1][1][8]){
                                echo "<tr bgcolor=lightyellow>";
                            }else{
                                echo "<tr bgcolor=lightcyan>";
                            }
						    echo "<td></td>";
						    echo "<td>".$UcDelo[$Indx][$IndxP][$IndxR][1]."</td>";
						    echo "<td>".$UcDelo[$Indx][$IndxP][$IndxR][2]."</td>";
						    echo "<td align='center'>".$UcDelo[$Indx][$IndxP][$IndxR][3]."</td>";
						    echo "<td bgcolor='lightblue'></td>";
						    echo "<td bgcolor='lightyellow'></td>";
						    echo "<td bgcolor='lightgreen'></td>";
						    echo "<td bgcolor='lightsalmon'></td>";
						    echo "</tr>";
					    }
				    }else{
					    if ($UcDelo[$Indx][$IndxP][$IndxR][2] != "" ){
                            if ($UcDelo[$Indx][0][0][8] > $UcDelo[$Indx][1][1][8]){
                                echo "<tr bgcolor=lightyellow>";
                            }else{
                                echo "<tr bgcolor=lightcyan>";
                            }
						    echo "<td></td>";
						    echo "<td></td>";
						    echo "<td>".$UcDelo[$Indx][$IndxP][$IndxR][2]."</td>";
						    echo "<td align='center'>".$UcDelo[$Indx][$IndxP][$IndxR][3]."</td>";
						    echo "<td bgcolor='lightblue'></td>";
						    echo "<td bgcolor='lightyellow'></td>";
						    echo "<td bgcolor='lightgreen'></td>";
						    echo "<td bgcolor='lightsalmon'></td>";
						    echo "</tr>";
					    }
				    }
			    }
		    }
	    }
	    echo "</table><br />";
    }
//'Izpis v obliki tabele (Crnuce) - konec --------------------------------------------------------------------------------------------------------------
}

?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
