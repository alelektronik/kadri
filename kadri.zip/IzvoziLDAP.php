<?php
require ('const.php');
require("razredi.php");
require("iskanje.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Uvoz
</title>
</head>
<body>
<?php
function ToUTF8($x){
    return $x;
    $c1=chr(196).chr(140);
    $c2=chr(196).chr(141);
    $c3=chr(196).chr(134);
    $c4=chr(196).chr(135);
    $s1=chr(197).chr(160);
    $s2=chr(197).chr(161);
    $z1=chr(197).chr(189);
    $z2=chr(197).chr(190);
    $d1=chr(196).chr(144);
    $d2=chr(196).chr(145);
    $o1=chr(195).chr(150);
    $o2=chr(195).chr(182);
    $a1=chr(195).chr(132);
    $a2=chr(195).chr(164);
    $u1=chr(195).chr(156);
    $u2=chr(195).chr(188);
    if (strlen($x) > 0){
        $x=str_replace("Ä",$a1,$x);
        $x=str_replace("Č",$c1,$x);
        $x=str_replace("č",$c2,$x);
        $x=str_replace("Ć",$c3,$x);
        $x=str_replace("ć",$c4,$x);
        $x=str_replace("Š",$s1,$x);
        $x=str_replace("š",$s2,$x);
        $x=str_replace("Ž",$z1,$x);
        $x=str_replace("ž",$z2,$x);
        $x=str_replace("Đ",$d1,$x);
        $x=str_replace("đ",$d2,$x);
        $x=str_replace("Ö",$o1,$x);
        $x=str_replace("ö",$o2,$x);
        $x=str_replace("ä",$a2,$x);
        $x=str_replace("Ü",$u1,$x);
        $x=str_replace("ü",$u2,$x);
    }
    return $x;
}

function ToCSZ($x){
    if (strlen($x) > 0){
        $x=str_replace("Ä","ae",$x);
        $x=str_replace("Č","C",$x);
        $x=str_replace("č","c",$x);
        $x=str_replace("Ć","C",$x);
        $x=str_replace("ć","c",$x);
        $x=str_replace("Š","S",$x);
        $x=str_replace("š","s",$x);
        $x=str_replace("Ž","Z",$x);
        $x=str_replace("ž","z",$x);
        $x=str_replace("Đ","Dj",$x);
        $x=str_replace("đ","dj",$x);
        $x=str_replace("Ö","Oe",$x);
        $x=str_replace("ö","oe",$x);
        $x=str_replace("ä","Ae",$x);
        $x=str_replace("Ü","Ue",$x);
        $x=str_replace("ü","ue",$x);
        $x=str_replace("é","e",$x);
        $x=str_replace(" ","-",$x);
    }                      
    return $x;
}

function ToPassword($x){
    if (strlen($x) > 0){
        $x=str_replace("Ä","A",$x);
        $x=str_replace("Č","C",$x);
        $x=str_replace("č","c",$x);
        $x=str_replace("Ć","c",$x);
        $x=str_replace("ć","c",$x);
        $x=str_replace("Š","S",$x);
        $x=str_replace("š","s",$x);
        $x=str_replace("Ž","Z",$x);
        $x=str_replace("ž","z",$x);
        $x=str_replace("Đ","D",$x);
        $x=str_replace("đ","d",$x);
        $x=str_replace("Ö","O",$x);
        $x=str_replace("ö","o",$x);
        $x=str_replace("ä","a",$x);
        $x=str_replace("Ü","U",$x);
        $x=str_replace("ü","u",$x);
        $x=str_replace("é","e",$x);
        
        $x=str_replace("A","4",$x);
        $x=str_replace("i","1",$x);
        $x=str_replace("e","3",$x);
        $x=str_replace("a","4",$x);
        $x=str_replace("B","8",$x);
        $x=str_replace("s","5",$x);
        $x=str_replace("S","5",$x);
        $x=str_replace("b","8",$x);
        $x=str_replace("E","3",$x);
        $x=str_replace(" ","",$x);
    }
    $s="";
    for ($j=0;$j < strlen($x);$j++){
        //'i=rnd
        if ($j % 2 == 0){
            $s=$s.strtoupper(substr($x,$j,1));
        }else{
            $s=$s.strtolower(substr($x,$j,1));
        }
    }
    while (strlen($s) < 8){
        $s=$s."4";
    }
    return $s;
}

function LeadZero($x){
    if (strlen($x) > 1){
        return $x;
    }else{
        return "0".$x;
    }
}

function LeadZeroN($x,$n){
    while (strlen($x) < $n){
        $x="0".$x;
    }
    return $x;
}

function hexToStr($hex){
    $string='';
    for ($i=0; $i < strlen($hex)-1; $i+=2)
    {
        $string .= chr(hexdec($hex[$i].$hex[$i+1]));
    }
    return $string;
}

Function getGUID(){
    $t=new DateTime("now");
    
    $x[1]=LeadZero(sprintf("%x",$t->format('j')));
    $x[2]=LeadZero(sprintf("%x",$t->format('n')));
    $x[3]=LeadZero(sprintf("%x",($t->format('Y') % 100)));
    $x[4]=LeadZero(sprintf("%x",$t->format('H')));
    $x[5]=LeadZero(sprintf("%x",$t->format('i')));
    $x[6]=LeadZero(sprintf("%x",$t->format('s')));
    $x[7]=LeadZero(sprintf("%x",$t->format('n')));
     
    $rv1 = rand(1,1000000);
    $x[8]=LeadZeroN(sprintf("%x",$rv1),6);    //'6
    $rv1 = rand(1,1000000);
    $x[9]=LeadZeroN(sprintf("%x",$rv1),6);    //'6
    $rv1 = rand(1,1000000);
    $x[10]=LeadZeroN(sprintf("%x",$rv1),6);    //'6
    
    $s=strtolower($x[10].$x[9].$x[8].$x[7].$x[6].$x[5].$x[4].$x[3].$x[2].$x[1]);
    $s1=substr($s,0,8)."-".substr($s,8,4)."-".substr($s,12,4)."-".substr($s,16,4)."-".substr($s,20,12);
    return $s1;
}

$VLeto=PreberiLeto("solskoleto");
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["id"])){
            $id = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $id=$_GET["id"];
            }else{
                $id = 0;
            }
        }

        $VLetoPregled=$VLeto;

        switch ($id){
            case "1": // 'kreiranje LDAP
                //'izpis glave
                $VFile="mdm_zaposleni.csv";
                $MyFile = "dato".$FileSep.$VFile;
                $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");
                
                $VFile1="mdm_ucenci.csv";
                $MyFile1 = "dato".$FileSep.$VFile1;
                $fh1 = fopen($MyFile1,'w') or die("Ne morem odpreti datoteke!");
                
                $VFile2="GoogleApps.csv";
                $MyFile2 = "dato".$FileSep.$VFile2;
                $fh2 = fopen($MyFile2,'w') or die("Ne morem odpreti datoteke!");
                
                $VFile3="o365.csv";
                $MyFile3 = "dato".$FileSep.$VFile3;
                $fh3 = fopen($MyFile3,'w') or die("Ne morem odpreti datoteke!");
                
                $VFile4="moodle.csv";
                $MyFile4 = "dato".$FileSep.$VFile4;
                $fh4 = fopen($MyFile4,'w') or die("Ne morem odpreti datoteke!");
                
                //fwrite ($fh, chr(34)."dn_suffix".chr(34).",".chr(34)."dn_rdn".chr(34).",".chr(34)."givenName".chr(34).",".chr(34)."sn".chr(34).",".chr(34)."cn".chr(34).",".chr(34)."userPassword".chr(34).",".chr(34)."ou".chr(34).",".chr(34)."facsimileTelephoneNumber".chr(34).",".chr(34)."postalAddress".chr(34).",".chr(34)."postalCode".chr(34).",".chr(34)."registeredAddress".chr(34).",".chr(34)."o".chr(34).",".chr(34)."carLicense".chr(34).",".chr(34)."departmentNumber".chr(34).",".chr(34)."displayName".chr(34).",".chr(34)."jpegPhoto".chr(34).",".chr(34)."uid".chr(34).",".chr(34)."mail".chr(34).",".chr(34)."mobile".chr(34).",".chr(34)."preferredLanguage".chr(34).",".chr(34)."userCertificate;binary".chr(34).",".chr(34)."userPKCS12".chr(34).",".chr(34)."userSMIMECertificate".chr(34).",".chr(34)."eduPersonAffiliation".chr(34).",".chr(34)."eduPersonPrimaryAffiliation".chr(34).",".chr(34)."eduPersonOrgDN".chr(34).",".chr(34)."eduPersonOrgUnitDN".chr(34).",".chr(34)."eduPersonPrimaryOrgUnitDN".chr(34).",".chr(34)."eduPersonPrincipalName".chr(34).",".chr(34)."schacMotherTongue".chr(34).",".chr(34)."schacGender".chr(34).",".chr(34)."schacDateOfBirth".chr(34).",".chr(34)."schacPlaceOfBirth".chr(34).",".chr(34)."schacCountryOfCitizenship".chr(34).",".chr(34)."schacSn1".chr(34).",".chr(34)."schacSn2".chr(34).",".chr(34)."schacPersonalTitle".chr(34).",".chr(34)."schacHomeOrganization".chr(34).",".chr(34)."schacHomeOrganizationType".chr(34).",".chr(34)."schacUserPresenceID".chr(34).",".chr(34)."schacPersonalPosition".chr(34).",".chr(34)."schacPersonalUniqueCode".chr(34).",".chr(34)."schacPersonalUniqueID".chr(34).",".chr(34)."schacUUID".chr(34).",".chr(34)."schacExpiryDate".chr(34).chr(13).chr(10));
                fwrite ($fh,"Ime;Priimek;Priimek2;Datum Rojstva;Spol;Emso;Ulica;Hisna Stevilka;Kraj;Posta;Zacasno Ulica;Zacasno Hisna Stevilka;Zacasno Kraj;Zacasno Posta;e-posta;Telefon Doma;Telefon Mobilni;Drzavljanstvo;Drzava Rojstva;Kraj Rojstva;Davcna Stevilka;Vloga;Uporabnisko Ime;Geslo".chr(13).chr(10));
                
                fwrite ($fh1,"Vpisna Stevilka;Ime;Priimek;Priimek2;Datum Rojstva;Spol;Emso;Ulica;Hisna Stevilka;Kraj;Posta;Zacasno Ulica;Zacasno Hisna Stevilka;Zacasno Kraj;Zacasno Posta;e-posta;e-posta Sekundarni;Telefon Doma;Telefon Mobilni;Razred;Drzavljanstvo;Drzava Rojstva;Kraj Rojstva;Nacin Izobrazevanja;Status Udelezenca;Zavod Vpisan Od;Povprecna Ocena;Zavod Vpisan Do;Razred Letnik Vpisan Od;Razred Letnik Vpisan Do;Program Vpisan Od;Program Vpisan Do;Uporabnisko Ime;Geslo".chr(13).chr(10));
                
                fwrite ($fh2, "email address,first name,last name,password".chr(13).chr(10));
                
                fwrite ($fh3, chr(0xEF).chr(0xBB).chr(0xBF)."Uporabniško ime,Ime,Priimek,Prikazno ime,Naziv,Oddelek,Številka pisarne,Službeni telefon,Prenosni telefon,Faks,Naslov,Mesto,Zvezna država ali provinca,Poštna številka,Država ali regija".chr(13).chr(10));

                fwrite ($fh4, "username;password;firstname;lastname;email;lang;institution;department".chr(13).chr(10));
                
                $SQL = "SELECT * FROM tabsola";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VSola=ToUTF8($R["Sola"]);
                }
                
                $SQL = "SELECT * FROM tabucitelji ";
                $SQL = $SQL . "INNER JOIN tabkontakti ON tabucitelji.idUcitelj=tabkontakti.idUcitelj ";
                $SQL = $SQL . "WHERE status > 0 ";
                $SQL = $SQL . "ORDER BY priimek,ime ";
                $result = mysqli_query($link,$SQL);

                $prejsnji="";
                $stevilka=0;
                while ($R = mysqli_fetch_array($result)){
                    $domena=explode(".",$_POST["domena"]);
                    /*
                    fwrite ($fh, chr(34)."dc=".$domena[0].",dc=".$domena[1].chr(34)); //    'dn_suffix
                    fwrite ($fh, ",".chr(34)."eduPersonPrincipalName".chr(34)); //    'dn_rdn
                    fwrite ($fh, ",".chr(34).ToUTF8($R["Priimek"]).chr(34)); //    'sn
                    fwrite ($fh, ",".chr(34).ToUTF8($R["Ime"]." ".$R["Priimek"]).chr(34)); //    'cn
                    fwrite ($fh, ",".chr(34).substr(ToPassword($R["Ime"].$R["Priimek"]),0,8).chr(34)); //    'userPassword
                    fwrite ($fh, ",".chr(34).chr(34)); //    'ou
                    fwrite ($fh, ",".chr(34).chr(34)); //    'fax
                    //fwrite ($fh, ",".chr(34).ToUTF8($R["Naslov"].", ".$R["Kraj"]).chr(34)); //    'postalAddress
                    fwrite ($fh, ",".chr(34)."".chr(34)); //    'postalAddress
                    fwrite ($fh, ",".chr(34)."SI-".$R["Posta"].chr(34)); //    'postalCode
                    //fwrite ($fh, ",".chr(34).ToUTF8($R["NaslovZac"]).chr(34)); //    'registeredAddress
                    fwrite ($fh, ",".chr(34)."".chr(34)); //    'registeredAddress
                    
                    fwrite ($fh, ",".chr(34).$VSola.chr(34)); //    'o
                    
                    fwrite ($fh, ",".chr(34).chr(34)); //    'carLicence
                    fwrite ($fh, ",".chr(34).chr(34)); //    'departmentNumber
                    fwrite ($fh, ",".chr(34).ToUTF8($R["Ime"]).chr(34)); //    'displayName
                    fwrite ($fh, ",".chr(34).chr(34)); //    'jpegPhoto
                    fwrite ($fh, ",".chr(34).chr(34)); //    'uid
                    fwrite ($fh, ",".chr(34).$R["email"].chr(34)); //    'mail
                    fwrite ($fh, ",".chr(34).chr(34)); //    'mobile
                    fwrite ($fh, ",".chr(34)."sl-si".chr(34)); //    'preferredLanguage
                    fwrite ($fh, ",".chr(34).chr(34)); //    'userCertificate;binary
                    fwrite ($fh, ",".chr(34).chr(34)); //    'userPKCS12 
                    fwrite ($fh, ",".chr(34).chr(34)); //    'userSMIMECertificate
                    fwrite ($fh, ",".chr(34)."faculty".chr(34)); //    'eduPersonAffiliation
                    fwrite ($fh, ",".chr(34)."faculty".chr(34)); //    'eduPersonPrimaryAffiliation 
                    fwrite ($fh, ",".chr(34).chr(34)); //    'eduPersonOrgDN
                    fwrite ($fh, ",".chr(34).chr(34)); //    'eduPersonOrgUnitDN
                    fwrite ($fh, ",".chr(34).chr(34)); //    'eduPersonPrimaryOrgUnitDN

                    $ime=$R["Ime"];
                    $priimek=$R["Priimek"];
                    if ($R["Ime"]." ".$R["Priimek"] != $prejsnji ){
                        $ime=str_replace(".","",$ime);
                        $priimek=str_replace(".","",$priimek);
                        fwrite ($fh, ",".chr(34).ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"].chr(34)); //    'eduPersonPrincipalName
                        $stevilka=0;
                    }else{
                        $ime=str_replace(".","",$ime);
                        $priimek=str_replace(".","",$priimek);
                        $stevilka=$stevilka+1;
                        fwrite ($fh, ",".chr(34).ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka."@".$_POST["domena"].chr(34)); //    'eduPersonPrincipalName
                    }
                    fwrite ($fh, ",".chr(34)."sl".chr(34)); //    'schacMotherTongue
                    if ($R["Spol"]=="M"){
                        fwrite ($fh, ",".chr(34)."1".chr(34)); //    'schacGender
                    }else{
                        fwrite ($fh, ",".chr(34)."2".chr(34)); //    'schacGender
                    }
                    if (!isDate($R["DatRoj"])){
                        $DatRoj=new DateTime("now");
                    }else{
                        $DatRoj=new DateTime(isDate($R["DatRoj"]));
                    }
                    //fwrite ($fh, ",".chr(34).$DatRoj->format('Ymd').chr(34)); //    'schacDateOfBirth
                    fwrite ($fh, ",".chr(34).$DatRoj->format('Y0101').chr(34)); //    'schacDateOfBirth
                    fwrite ($fh, ",".chr(34).ToUTF8($R["KrajRoj"]).chr(34)); //    'schacPlaceOfBirth
                    //fwrite ($fh, ",".chr(34)."".chr(34)); //    'schacPlaceOfBirth
                    fwrite ($fh, ",".chr(34)."si".chr(34)); //    'schacCountryOfCitizenship 
                    fwrite ($fh, ",".chr(34).ToUTF8($R["Priimek"]).chr(34)); //    'schacSn1
                    fwrite ($fh, ",".chr(34).chr(34)); //    'schacSn2 
                    fwrite ($fh, ",".chr(34).chr(34)); //   'schacPersonalTitle
                    
                    fwrite ($fh, ",".chr(34).$_POST["domena"].chr(34)); //    'schacHomeOrganization
                    
                    fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:homeOrgType:osnovna šola").chr(34)); //    'schacHomeOrganizationType
                    fwrite ($fh, ",".chr(34).chr(34)); //    'schacUserPresenceID
                    fwrite ($fh, ",".chr(34).chr(34)); //    'schacPersonalPosition
                    fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:personalPublicUniqueCode:vpisna številka:".(1000+$R["IdUcitelj"])).chr(34)); //    'schacPersonalUniqueCode
                    fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:personalPublicUniqueID:vpisna številka:".(1000+$R["IdUcitelj"])).chr(34)); //    'schacPersonalUniqueID
                    
                    fwrite ($fh, ",".chr(34).GetGUID().chr(34)); //    'schacUUID
                    fwrite ($fh, ",".chr(34)."99991030235959Z".chr(34).chr(13).chr(10)); //    'schacExpiryDate
                    */

                    //vpis za mdm.arnes.si - zaposleni
                    fwrite ($fh, ToUTF8($R["Ime"])); //    'ime
                    fwrite ($fh, ";".ToUTF8($R["Priimek"])); //    'priimek
                    fwrite ($fh, ";"); //    'priimek2
                    if (!isDate($R["DatRoj"])){
                        $DatRoj=new DateTime("now");
                    }else{
                        $DatRoj=new DateTime(isDate($R["DatRoj"]));
                    }
                    fwrite ($fh, ";".$DatRoj->format('d.m.Y')); //    'datum rojstva
                    if ($R["Spol"]=="M"){
                        fwrite ($fh, ";"."M"); //    'spol
                    }else{
                        fwrite ($fh, ";"."Ž"); //    'spol
                    }
                    fwrite ($fh, ";".ToUTF8($R["EMSO"])); //    'emšo
                    
                    $sarr=explode(" ",$R["Naslov"]);
                    $n=count($sarr);
                    for ($i=count($sarr)-1;$i >= 0;$i--){
                        if (is_numeric($sarr[$i])){
                            $n=$i;
                            break;
                        }
                    }
                    
                    $Naslov="";
                    if ($n==count($sarr)){
                        $n=count($sarr)-1;
                    }
                    for ($i=0;$i < $n;$i++){
                        if (isset($sarr[$i])){
                            $Naslov=$Naslov." ".$sarr[$i];
                        }else{
                            $Naslov=$R["Naslov"];
                        }
                    }
                    $Naslov=trim($Naslov);
                    $HSt="";
                    for ($i=$n;$i < count($sarr);$i++){
                        $HSt=$HSt." ".$sarr[$i];
                    }
                    $HSt=trim($HSt);
                    $HSt=str_replace(" ","",$HSt);

                    fwrite ($fh, ";".ToUTF8($Naslov)); //    'ulica
                    fwrite ($fh, ";".$HSt); //    'hišna številka
                    fwrite ($fh, ";".ToUTF8($R["Kraj"])); //    'kraj
                    fwrite ($fh, ";".ToUTF8($R["Posta"])); //    'pošta
                    fwrite ($fh, ";"); //    'zač. ulica
                    fwrite ($fh, ";"); //    'zač. h.št.
                    fwrite ($fh, ";"); //    'zač. kraj
                    fwrite ($fh, ";"); //    'zač. pošta
                    fwrite ($fh, ";".ToUTF8($R["email"])); //    'email
                    fwrite ($fh, ";"); //    'tel. doma
                    fwrite ($fh, ";"); //    'tel. mobilni
                    fwrite ($fh, ";"); //    'državljanstvo
                    fwrite ($fh, ";"); //    'država roj.
                    fwrite ($fh, ";"); //    'kraj roj.
                    fwrite ($fh, ";".$R["Davcna"]); //    'davčna
                    fwrite ($fh, ";OP"); //    'vloga

                    $ime=$R["Ime"];
                    $priimek=$R["Priimek"];
                    if ($R["Ime"]." ".$R["Priimek"] != $prejsnji ){
                        $ime=str_replace(".","",$ime);
                        $priimek=str_replace(".","",$priimek);
                        fwrite ($fh, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))); //    'up. ime
                        $stevilka=0;
                    }else{
                        $ime=str_replace(".","",$ime);
                        $priimek=str_replace(".","",$priimek);
                        $stevilka=$stevilka+1;
                        fwrite ($fh, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka); //    'up. ime
                    }
                    fwrite ($fh, ";".substr(ToPassword($R["Ime"].$R["Priimek"]),0,8).chr(13).chr(10)); //    'geslo
                    
                    //'vpis za GoogleApps
                    if ($R["Ime"]." ".$R["Priimek"] != $prejsnji ){
                        fwrite ($fh2, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'email
                    }else{
                        fwrite ($fh2, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka."@".$_POST["domena"]); //    'email
                    }
                    fwrite ($fh2, ",".ToCSZ($R["Ime"])); //    'ime
                    fwrite ($fh2, ",".ToCSZ($R["Priimek"])); //    'priimek
                    fwrite ($fh2, ",a1b2c3d4".chr(13).chr(10)); //    'Password
                    
                    //vpis za o365 
                    if ($R["Ime"]." ".$R["Priimek"] != $prejsnji ){
                        fwrite ($fh3, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'uporabniško ime
                    }else{
                        fwrite ($fh3, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka."@".$_POST["domena"]); //    'uporabniško ime
                    }
                    fwrite ($fh3, ",".$R["Ime"]); //    'ime
                    fwrite ($fh3, ",".$R["Priimek"]); //    'priimek
                    fwrite ($fh3, ",".$R["Ime"]." ".$R["Priimek"]); //    'prikazno ime
                    if ($R["Spol"] == "M"){
                        fwrite ($fh3, ",delavec"); //naziv
                    }else{
                        fwrite ($fh3, ",delavka"); //naziv
                    }
                    fwrite ($fh3, ","); //oddelek
                    fwrite ($fh3, ","); //številka pisarne
                    fwrite ($fh3, ","); //službeni telefon
                    fwrite ($fh3, ","); //prenosni telefon
                    fwrite ($fh3, ","); //faks
                    fwrite ($fh3, ","); //naslov
                    fwrite ($fh3, ","); //mesto
                    fwrite ($fh3, ","); //zvezna država ali provinca
                    fwrite ($fh3, ","); //poštna številka
                    fwrite ($fh3, ",Slovenija".chr(13).chr(10)); //država ali regija

                    //vpis za moodle
                    fwrite ($fh4, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))); //    'uporabniško ime
                    fwrite ($fh4, ";A1b2c3d4"); //geslo
                    fwrite ($fh4, ";".$R["Ime"].";".$R["Priimek"]); //   first name,last name
                    fwrite ($fh4, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'e-mail
                    fwrite ($fh4, ";sl_SI"); //jezik
                    fwrite ($fh4, ";$VSola"); //jezik
                    fwrite ($fh4, ";zaposleni".chr(13).chr(10)); //jezik
                }

                if ($_POST["tudiucenci"] > 0 ){
                    $SQL = "SELECT * FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    if ($_POST["tudiucenci"] == 1 ){
                        $SQL = $SQL . "WHERE tabrazred.leto = ".$VLeto." AND razred > 0 ";
                    }else{
                        $SQL = $SQL . "WHERE tabrazred.leto = ".$VLeto." AND razred > 3 ";
                    }
                    $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime ";
                    $result = mysqli_query($link,$SQL);

                    $prejsnji="";
                    $stevilka=0;
                    while ($R = mysqli_fetch_array($result)){
                        $domena=explode(".",$_POST["domena"]);
                        /*
                        fwrite ($fh, chr(34)."dc=".$domena[0].",dc=".$domena[1].chr(34)); //    'dn_suffix
                        fwrite ($fh, ",".chr(34)."eduPersonPrincipalName".chr(34)); //    'dn_rdn
                        fwrite ($fh, ",".chr(34).ToUTF8($R["Ime"]).chr(34)); //    'givenName
                        fwrite ($fh, ",".chr(34).ToUTF8($R["Priimek"]).chr(34)); //    'sn
                        fwrite ($fh, ",".chr(34).ToUTF8($R["Ime"]." ".$R["Priimek"]).chr(34)); //    'cn
                        fwrite ($fh, ",".chr(34).substr(ToPassword($R["Ime"].$R["Priimek"]),0,8).chr(34)); //    'userPassword
                        fwrite ($fh, ",".chr(34).chr(34)); //    'ou
                        fwrite ($fh, ",".chr(34).chr(34)); //    'fax
                        //fwrite ($fh, ",".chr(34).ToUTF8($R["Naslov"].", ".$R["Kraj"]).chr(34)); //    'postalAddress
                        fwrite ($fh, ",".chr(34).$R["Leto"]." - ".$R["Razred"]." ".$R["Paralelka"].chr(34)); //    'postalAddress
                        fwrite ($fh, ",".chr(34)."SI-".$R["Posta"].chr(34)); //    'postalCode
                        //fwrite ($fh, ",".chr(34).ToUTF8($R["NaslovZac"]).chr(34)); //    'registeredAddress
                        fwrite ($fh, ",".chr(34)."".chr(34)); //    'registeredAddress
                        
                        fwrite ($fh, ",".chr(34).$VSola.chr(34)); //    'o
                        
                        fwrite ($fh, ",".chr(34).chr(34)); //    'carLicence
                        fwrite ($fh, ",".chr(34).chr(34)); //    'departmentNumber
                        fwrite ($fh, ",".chr(34).ToUTF8($R["Ime"]).chr(34)); //    'displayName
                        fwrite ($fh, ",".chr(34).chr(34)); //    'jpegPhoto
                        fwrite ($fh, ",".chr(34).chr(34)); //    'uid
                        
                        $ime=ToCSZ(mb_strtolower($R["Ime"],$encoding));
                        $priimek=ToCSZ(mb_strtolower($R["Priimek"],$encoding));
                        if ($ime." ".$priimek != $prejsnji ){
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            fwrite ($fh, ",".chr(34).$ime.".".$priimek."@".$_POST["domena"].chr(34)); //    'mail
                            $stevilka=0;
                        }else{
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            $stevilka=$stevilka+1;
                            fwrite ($fh, ",".chr(34).$ime.".".$priimek.($stevilka)."@".$_POST["domena"].chr(34)); //    'mail
                        }
                        
                        fwrite ($fh, ",".chr(34).chr(34)); //    'mobile
                        fwrite ($fh, ",".chr(34)."sl-si".chr(34)); //    'preferredLanguage
                        fwrite ($fh, ",".chr(34).chr(34)); //    'userCertificate;binary
                        fwrite ($fh, ",".chr(34).chr(34)); //    'userPKCS12 
                        fwrite ($fh, ",".chr(34).chr(34)); //    'userSMIMECertificate
                        fwrite ($fh, ",".chr(34)."alumn".chr(34)); //    'eduPersonAffiliation
                        fwrite ($fh, ",".chr(34)."alumn".chr(34)); //    'eduPersonPrimaryAffiliation 
                        fwrite ($fh, ",".chr(34).chr(34)); //    'eduPersonOrgDN
                        fwrite ($fh, ",".chr(34).chr(34)); //   'eduPersonOrgUnitDN
                        fwrite ($fh, ",".chr(34).chr(34)); //    'eduPersonPrimaryOrgUnitDN
                        
                        if ($ime." ".$priimek != $prejsnji ){
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            fwrite ($fh, ",".chr(34).$ime.".".$priimek."@".$_POST["domena"].chr(34)); //    'eduPersonPrincipalName
                            $stevilka=0;
                        }else{
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            $stevilka=$stevilka+1;
                            fwrite ($fh, ",".chr(34).$ime.".".$priimek.$stevilka."@".$_POST["domena"].chr(34)); //    'eduPersonPrincipalName
                        }
                        fwrite ($fh, ",".chr(34)."sl".chr(34)); //    'schacMotherTongue
                        if ($R["Spol"]=="M"){
                            fwrite ($fh, ",".chr(34)."1".chr(34)); //    'schacGender
                        }else{
                            fwrite ($fh, ",".chr(34)."2".chr(34)); //    'schacGender
                        }
                        if (!isDate($R["DatRoj"])){
                            $DatRoj=new DateTime("now");
                        }else{
                            $DatRoj=new DateTime(isDate($R["DatRoj"]));
                        }
                        //fwrite ($fh, ",".chr(34).$DatRoj->format('Ymd').chr(34)); //    'schacDateOfBirth
                        fwrite ($fh, ",".chr(34).$DatRoj->format('Y0101').chr(34)); //    'schacDateOfBirth
                        fwrite ($fh, ",".chr(34).ToUTF8($R["KrajRoj"]).chr(34)); //    'schacPlaceOfBirth
                        //fwrite ($fh, ",".chr(34)."".chr(34)); //    'schacPlaceOfBirth
                        fwrite ($fh, ",".chr(34)."si".chr(34)); //    'schacCountryOfCitizenship 
                        fwrite ($fh, ",".chr(34).ToUTF8($R["Priimek"]).chr(34)); //    'schacSn1
                        fwrite ($fh, ",".chr(34).chr(34)); //    'schacSn2 
                        fwrite ($fh, ",".chr(34).chr(34)); //    'schacPersonalTitle
                        
                        fwrite ($fh, ",".chr(34).$_POST["domena"].chr(34)); //    'schacHomeOrganization
                        
                        fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:homeOrgType:osnovna šola").chr(34)); //    'schacHomeOrganizationType
                        fwrite ($fh, ",".chr(34).chr(34)); //    'schacUserPresenceID
                        fwrite ($fh, ",".chr(34).chr(34)); //    'schacPersonalPosition
                        fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:personalPublicUniqueCode:vpisna številka:".(10000+$R["IdUcenec"])).chr(34)); //    'schacPersonalUniqueCode
                        //fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:personalPublicUniqueID:EMŠO:".$R["emso"]).chr(34)); //    'schacPersonalUniqueID
                        fwrite ($fh, ",".chr(34).ToUTF8("urn:arnes.si:personalPublicUniqueID:vpisna številka:".(10000+$R["IdUcenec"])).chr(34)); //    'schacPersonalUniqueID
                        fwrite ($fh, ",".chr(34).GetGUID().chr(34)); //    'schacUUID
                        fwrite ($fh, ",".chr(34).($VLeto+10-$R["Razred"])."1030235959Z".chr(34).chr(13).chr(10)); //    'schacExpiryDate
                        */

                        //vpis za mdm.arnes.si - učenci
                        fwrite ($fh1, ToUTF8($R["IdUcenec"])); //    'vpisna številka
                        fwrite ($fh1, ";".ToUTF8($R["Ime"])); //    'ime
                        fwrite ($fh1, ";".ToUTF8($R["Priimek"])); //    'priimek
                        fwrite ($fh1, ";"); //    'priimek2
                        if (!isDate($R["DatRoj"])){
                            $DatRoj=new DateTime("now");
                        }else{
                            $DatRoj=new DateTime(isDate($R["DatRoj"]));
                        }
                        fwrite ($fh1, ";".$DatRoj->format('d.m.Y')); //    'datum rojstva
                        if ($R["Spol"]=="M"){
                            fwrite ($fh1, ";"."M"); //    'spol
                        }else{
                            fwrite ($fh1, ";"."Ž"); //    'spol
                        }
                        fwrite ($fh1, ";".ToUTF8($R["emso"])); //    'emšo
                        
                        $sarr=explode(" ",$R["Naslov"]);
                        $n=count($sarr);
                        for ($i=count($sarr)-1;$i >= 0;$i--){
                            if (is_numeric($sarr[$i])){
                                $n=$i;
                                break;
                            }
                        }
                        
                        $Naslov="";
                        if ($n==count($sarr)){
                            $n=count($sarr)-1;
                        }
                        for ($i=0;$i < $n;$i++){
                            if (isset($sarr[$i])){
                                $Naslov=$Naslov." ".$sarr[$i];
                            }else{
                                $Naslov=$R["Naslov"];
                            }
                        }
                        $Naslov=trim($Naslov);
                        $HSt="";
                        for ($i=$n;$i < count($sarr);$i++){
                            $HSt=$HSt." ".$sarr[$i];
                        }
                        $HSt=trim($HSt);
                        $HSt=str_replace(" ","",$HSt);

                        fwrite ($fh1, ";".ToUTF8($Naslov)); //    'ulica
                        fwrite ($fh1, ";".$HSt); //    'hišna številka
                        fwrite ($fh1, ";".ToUTF8($R["Kraj"])); //    'kraj
                        fwrite ($fh1, ";".ToUTF8($R["Posta"])); //    'pošta
                        fwrite ($fh1, ";"); //    'zač. ulica
                        fwrite ($fh1, ";"); //    'zač. h.št.
                        fwrite ($fh1, ";"); //    'zač. kraj
                        fwrite ($fh1, ";"); //    'zač. pošta
                        $ime=ToCSZ(mb_strtolower($R["Ime"],$encoding));
                        $priimek=ToCSZ(mb_strtolower($R["Priimek"],$encoding));
                        if ($ime." ".$priimek != $prejsnji ){
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'email
                            //fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'email-sekundarni
                            fwrite ($fh1, ";"); //    'email sekundarni
                            $stevilka=0;
                        }else{
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            $stevilka=$stevilka+1;
                            fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka."@".$_POST["domena"]); //    'email
                            //fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka."@".$_POST["domena"]); //    'email sekundarni
                            fwrite ($fh1, ";"); //    'email sekundarni
                        }
                        fwrite ($fh1, ";"); //    'tel. doma
                        fwrite ($fh1, ";"); //    'tel. mobilni
                        fwrite ($fh1, ";".$R["Razred"].".".mb_strtoupper($R["Paralelka"],$encoding)); //    'razred
                        fwrite ($fh1, ";"); //    'državljanstvo
                        fwrite ($fh1, ";"); //    'država rojstva
                        fwrite ($fh1, ";"); //    'kraj roj.
                        fwrite ($fh1, ";RED"); //    'način izobraževanja
                        fwrite ($fh1, ";UCE"); //    'status udeleženca
                        fwrite ($fh1, ";"); //    'zavod vpisan od
                        fwrite ($fh1, ";"); //    'povprečna ocena
                        fwrite ($fh1, ";"); //    'zavod vpisan do
                        fwrite ($fh1, ";"); //    'razred letnik vpisan od
                        fwrite ($fh1, ";"); //    'razred letnik vpisan do
                        fwrite ($fh1, ";"); //    'program vpisan od
                        fwrite ($fh1, ";"); //    'program vpisan do

                        //$ime=$R["Ime"];
                        //$priimek=$R["Priimek"];
                        if ($ime." ".$priimek != $prejsnji ){
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))); //    'up. ime
                            $stevilka=0;
                        }else{
                            $ime=str_replace(".","",$ime);
                            $priimek=str_replace(".","",$priimek);
                            $stevilka=$stevilka+1;
                            fwrite ($fh1, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding)).$stevilka); //    'up. ime
                        }
                        //fwrite ($fh1, ";".substr(ToPassword($R["Ime"].$R["Priimek"]),0,8).chr(13).chr(10)); //    'geslo
                        fwrite ($fh1, ";"."A1b2c3d4".chr(13).chr(10)); //    'geslo
                        
                        
                        //'podatki za GoogleApps
                        if ($ime." ".$priimek != $prejsnji ){
                            fwrite ($fh2, $ime.".".$priimek."@".$_POST["domena"]); //    'email
                        }else{
                            fwrite ($fh2, $ime.".".$priimek.$stevilka."@".$_POST["domena"]); //    'email
                        }
                        fwrite ($fh2, ",".ToCSZ($R["Ime"])); //    'ime
                        fwrite ($fh2, ",".ToCSZ($R["Priimek"])); //    'priimek
                        fwrite ($fh2, ",a1b2c3d4".chr(13).chr(10)); //    'userPassword
                        
                        //$prejsnji=$ime." ".$priimek;
                        
                        //vpis za o365
                        if ($ime." ".$priimek != $prejsnji ){
                            fwrite ($fh3, $ime.".".$priimek."@".$_POST["domena"]); //    'uporabniško ime
                        }else{
                            fwrite ($fh3, $ime.".".$priimek.$stevilka."@".$_POST["domena"]); //    'uporabniško ime
                        }
                        fwrite ($fh3, ",".$R["Ime"]); //    'ime
                        fwrite ($fh3, ",".$R["Priimek"]); //    'priimek
                        fwrite ($fh3, ",".$R["Ime"]." ".$R["Priimek"]); //    'prikazno ime
                        if ($R["Spol"] == "M"){
                            fwrite ($fh3, ",učenec"); //naziv
                        }else{
                            fwrite ($fh3, ",učenka"); //naziv
                        }
                        fwrite ($fh3, ",".$R["Razred"].". ".$R["Paralelka"]." - ".$VLeto."/".($VLeto+1)); //oddelek
                        fwrite ($fh3, ","); //številka pisarne
                        fwrite ($fh3, ","); //službeni telefon
                        fwrite ($fh3, ","); //prenosni telefon
                        fwrite ($fh3, ","); //faks
                        fwrite ($fh3, ","); //naslov
                        fwrite ($fh3, ","); //mesto
                        fwrite ($fh3, ","); //zvezna država ali provinca
                        fwrite ($fh3, ","); //poštna številka
                        fwrite ($fh3, ",Slovenija".chr(13).chr(10)); //država ali regija

                        //vpis za moodle
                        fwrite ($fh4, ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))); //    'uporabniško ime
                        fwrite ($fh4, ";A1b2c3d4"); //geslo
                        fwrite ($fh4, ";".$R["Ime"].";".$R["Priimek"]); //   first name,last name
                        fwrite ($fh4, ";".ToCSZ(mb_strtolower($ime,$encoding)).".".ToCSZ(mb_strtolower($priimek,$encoding))."@".$_POST["domena"]); //    'e-mail
                        fwrite ($fh4, ";sl_SI"); //jezik
                        fwrite ($fh4, ";$VSola"); //jezik
                        fwrite ($fh4, ";$VLeto - ".$R["Razred"].". ".$R["Paralelka"].chr(13).chr(10)); //jezik
                        
                        $prejsnji=$ime." ".$priimek;
                    }
                }
                echo "<h2><a href='dato/mdm_zaposleni.csv'>LDAP-zaposleni csv datoteka</a></h2>";
                echo "<h2><a href='dato/mdm_ucenci.csv'>LDAP-učenci csv datoteka</a></h2>";
                echo "<h2><a href='dato/GoogleApps.csv'>Google Apps csv datoteka</a></h2>";
                echo "<h2><a href='dato/o365.csv'>Office 365 csv datoteka</a></h2>";
                echo "<h2><a href='dato/moodle.csv'>Moodle csv datoteka</a></h2>";

                fclose($fh);
                fclose($fh1);
                fclose($fh2);
                fclose($fh3);
                fclose($fh4);
                break;
            default: // 'obrazec za vpis manjkajočih podatkov
                echo "<br />";
                echo "<form  name='ldap' method=post action='IzvoziLDAP.php'>";
                echo "<b>Domena ustanove:</b> <input name='domena' type='text' size='40' maxlength='40'><br />";
                echo "<input name='tudiucenci' type='radio' value='0' checked='checked'><b>Ne vključi učencev</b> <br />";
                echo "<input name='tudiucenci' type='radio' value='1'><b>Vključi vse učence</b> <br />";
                echo "<input name='tudiucenci' type='radio' value='2'><b>Vključi učence 4.-9. razreda</b> <br />";
                echo "<input name='id' type='hidden' value='1'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form><br />";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
    
?>

</body>
</html>
