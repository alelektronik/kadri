<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("ucenci.php");
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    if (!CheckDostop("Redov",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = 0;
            }
        }
        if (isset($_POST["idd"])){
            $VNacin = $_POST["idd"];
        }else{
            if (isset($_GET["idd"])){
                $VNacin=$_GET["idd"];
            }else{
                $VNacin = 0;
            }
        }

        if (isset($_POST["razred"])){
            $VRazred = $_POST["razred"];
        }else{
            if (isset($_GET["razred"])){
                $VRazred=$_GET["razred"];
            }else{
                if (isset($_SESSION["razred"])){
                    $VRazred=$_SESSION["razred"];
                }else{
                    $VRazred = 0;
                }
            }
        }

        switch ($VNacin){
            case "100": //maticni listi PDF
                $SQL = "SELECT * FROM tabsola";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VSola=$R["Sola"];
                    $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                    $VSolaKraj=$R["Kraj"];
                    $VRavnatelj=$R["Ravnatelj"];
                    $TipSole=$R["TipSole"];
                    $RavnateljID=$R["ravnatelj_ID"];
                    $VObcina=$R["Obcina"];
                }else{
                    $VSola=" ";
                    $VRavnatelj=" ";
                    $RavnateljID=0;
                    $VSolaNaslov="";
                    $VSolaKraj="";
                    $TipSole=0;
                    $VObcina="999";
                }

                $SQL = "SELECT spol FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SpolRavnatelj=$R["spol"];
                }else{
                    $SpolRavnatelj="M";
                }

                $pdf = new FPDF();

                //$pdf->AddFont('EAN_b','','EAN_b.php');
                $pdf->AddFont('arial_CE','','arial_CE.php');
                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                $pdf->AddPage("P","A4");
                $pdf->SetAutoPageBreak(0);

                $FontSize=7;
                $FontSize1=8;
                $FontSize2=11;
                $KorX=0;
                $KorY=0;
                $XPoz=array(17,78,142,200);
                $YPoz=array(12,21,24,33);

                if ($VRazred==0){
                    $SQL = "SELECT id FROM tabrazdat WHERE razred > 0 AND leto=".$VLeto." ORDER BY razred,oznaka";
                }else{
                    $SQL = "SELECT id FROM tabrazdat WHERE id=".$VRazred;
                }
                $result1 = mysqli_query($link,$SQL);
                $IndxR=0;
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($IndxR > 0){
                        $pdf->AddPage("P","A4");
                    }

                    //'izpiše podatke o šoli
                    $pdf->SetFont('arialbd_CE','',$FontSize2);
                    $pdf->SetRightMargin($XPoz[0]);
                    $txt=ToWin($VSola.", ".$VSolaNaslov);
                    $pdf->SetXY($XPoz[0]+$KorX,$YPoz[0]-$KorY);
                    $pdf->MultiCell(0,3,$txt,0,"L");

                    $IndxR=$IndxR+1;
                    $VRazred=$R1["id"];
                    
                    $SQL = "SELECT tabucenci.iducenec FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
                    $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenci[$Indx]=$R["iducenec"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx-1;
                    $color=true;
                    for ($IndxRazred=1;$IndxRazred <= $StUcencev;$IndxRazred++){
                        $oUcenec=new RUcenec();
                        $oUcenec->getUcenec($ucenci[$IndxRazred]);
                        $Razred=$oUcenec->getRazred($VLeto);

                        $VRazred1 = $Razred["razred"];

                        if (($IndxRazred == 11) or ($IndxRazred == 21)){
                            $pdf->AddPage("P","A4");
                            //'izpiše podatke o šoli
                            $pdf->SetFont('arialbd_CE','',$FontSize2);
                            $txt=ToWin($VSola.", ".$VSolaNaslov);
                            $pdf->SetRightMargin($XPoz[0]);
                            $pdf->SetXY($XPoz[0]+$KorX,$YPoz[0]-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }

                        if ($color){
                            $pdf->SetFillColor(218,245,255);
                            $pdf->Rect(5,$YPoz[1]-3+(($IndxRazred-1)%10)*27,200,27,"F");
                        }
                        $color=!$color;
                        
                        $pdf->SetFont('arial_CE','',$FontSize1);
                        $txt=$IndxRazred.".";
                        $pdf->SetXY($XPoz[0]-8+$KorX,$YPoz[1]+(($IndxRazred-1)%10)*27-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        //' ime in priimek
                        $pdf->SetFont('arialbd_CE','',$FontSize2);
                        $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek().", ".$Razred["razred"].". ".$Razred["paralelka"]);
                        $pdf->SetXY($XPoz[0]+$KorX,$YPoz[1]+(($IndxRazred-1)%10)*27-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        //'datum rojstva
                        /*
                        $pdf->SetFont('arial_CE','',$FontSize2);
                        $txt=ToWin($oUcenec->getDatRoj());
                        $pdf->SetXY(15+$KorX,55.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        */
                        //'matični list
                        /*
                        $pdf->SetFont('arial_CE','',$FontSize2);
                        $txt=ToWin($oUcenec->getMaticniList());
                        $pdf->SetXY(159+$KorX,55.5-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        */

                        //'naslov
                        $pdf->SetFont('arial_CE','',$FontSize1);
                        if (strlen($oUcenec->getTelefonDoma()) > 0){
                            if (strlen($oUcenec->getNaslovZac()) > 0){
                                $txt=ToWin("Tel.doma: ".$oUcenec->getTelefonDoma().", z.n.: ".$oUcenec->getNaslovZac().", ".$oUcenec->getPostaZac()." ".$oUcenec->getKrajZac()." (".$oUcenec->getBivanjePri().")");
                            }else{
                                $txt=ToWin("Tel.doma: ".$oUcenec->getTelefonDoma().", ".$oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj()." (".$oUcenec->getBivanjePri().")");
                            }
                        }else{
                            if (strlen($oUcenec->getNaslovZac()) > 0){
                                $txt=ToWin("z.n.: ".$oUcenec->getNaslovZac().", ".$oUcenec->getPostaZac()." ".$oUcenec->getKrajZac()." (".$oUcenec->getBivanjePri().")");
                            }else{
                                $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj()." (".$oUcenec->getBivanjePri().")");
                            }
                        }
                        $pdf->SetXY($XPoz[1]+$KorX,$YPoz[1]+(($IndxRazred-1)%10)*27-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");

                        //'oče
                        $pdf->SetFont('arial_CE','',$FontSize1);
                        $pdf->SetLeftMargin($XPoz[0]);
                        $pdf->SetRightMargin(210-$XPoz[1]);
                        if (strlen($oUcenec->getocezacnasl()) > 0){
                            $txt=ToWin($oUcenec->getoce().", GSM: ".$oUcenec->getoceGSM()."\n"."tel. doma: ".$oUcenec->getocekontakt()."\n"."tel. sl.: ".$oUcenec->getoceSluzba()."\n"."z.n.: ".$oUcenec->getocezacnasl()."\n".$oUcenec->getoceemail());
                        }else{
                            $txt=ToWin($oUcenec->getoce().", GSM: ".$oUcenec->getoceGSM()."\n"."tel. doma: ".$oUcenec->getocekontakt()."\n"."tel. sl.: ".$oUcenec->getoceSluzba()."\n".$oUcenec->getocenaslov()."\n".$oUcenec->getoceemail());
                        }
                        $pdf->SetXY($XPoz[0]+$KorX,$YPoz[2]+(($IndxRazred-1)%10)*27-$KorY);
                        $pdf->MultiCell(0,3,$txt,0,"L");

                        //'mati
                        $pdf->SetFont('arial_CE','',$FontSize1);
                        $pdf->SetLeftMargin($XPoz[1]);
                        $pdf->SetRightMargin(210-$XPoz[2]);
                        if (strlen($oUcenec->getmatizacnasl()) > 0){
                            $txt=ToWin($oUcenec->getmati().", GSM: ".$oUcenec->getmatiGSM()."\n"."tel. doma: ".$oUcenec->getmatikontakt()."\n"."tel. sl.: ".$oUcenec->getmatiSluzba()."\n"."z.n.: ".$oUcenec->getmatizacnasl()."\n".$oUcenec->getmatiemail());
                        }else{
                            $txt=ToWin($oUcenec->getmati().", GSM: ".$oUcenec->getmatiGSM()."\n"."tel. doma: ".$oUcenec->getmatikontakt()."\n"."tel. sl.: ".$oUcenec->getmatiSluzba()."\n".$oUcenec->getmatinaslov()."\n".$oUcenec->getmatiemail());
                        }
                        $pdf->SetXY($XPoz[1]+$KorX,$YPoz[2]+(($IndxRazred-1)%10)*27-$KorY);
                        $pdf->MultiCell(0,3,$txt,0,"L");

                        //'skrbniki
                        if (strlen($oUcenec->getSkrbniki()) > 0){
                            $pdf->SetFont('arial_CE','',$FontSize1);
                            $pdf->SetLeftMargin($XPoz[2]);
                            $pdf->SetRightMargin(10);
                            $txt=ToWin($oUcenec->getSkrbniki().", GSM: ".$oUcenec->getSkrbnikiKontakt()."\n".$oUcenec->getSkrbnikiNaslov());
                            $pdf->SetXY($XPoz[2]+$KorX,$YPoz[2]+(($IndxRazred-1)%10)*27-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }
                        //opombe
                        if (strlen($oUcenec->getOpombe()) > 0){
                            $pdf->SetFont('arial_CE','',$FontSize);
                            $pdf->SetLeftMargin($XPoz[2]);
                            $pdf->SetRightMargin(10);
                            $txt=ToWin("Opombe: ".$oUcenec->getOpombe());
                            $pdf->SetXY($XPoz[2]+$KorX,$YPoz[3]+(($IndxRazred-1)%10)*27-$KorY);
                            $pdf->MultiCell(0,3,$txt,0,"L");
                        }
                        //glava - konec
                    }
                }    
                $pdf->Output("MaticniListi.pdf","D");
                break;
            default:  //izbor maticni list
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Kontaktni podatki";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');

                $SQL = "SELECT idrazred FROM tabrazred WHERE leto=".$VLeto." AND idUcitelj=".$Prijavljeni;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VidRazred=$R["idrazred"];
                }else{
                    $VidRazred=0;
                }

                echo "<form name='MaticniListi' method='post' action='razrednipodatki.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<h2>Izberite razred</h2>";
                echo "<table border=0>";
                echo "<tr>";
                echo "<td>";
                echo "Šolsko leto: " .  $VLeto  . "/" . ($VLeto+1). "<input type='hidden' name='solskoleto' value='".$VLeto."'></td>";
                echo "</tr>";
                if ($VLeto < 2008){
                    echo "<tr>";
                    echo "<td>8-/9-letka:<select name='vrstaos'>";
                    echo "<option value='9' selected>devetletka</option>";
                    echo "<option value='8'>osemletka</option>";
                    echo "</select>";
                    echo "</td>";
                    echo "</tr>";
                }else{
                    echo "<input name='vrstaos' type='hidden' value='9'>";
                }
                $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
                $result = mysqli_query($link,$SQL);

                echo "<tr><td>Izberi razred<select name='razred'>";
                echo "<option value='0'>Vsi</option>";
                while ($R = mysqli_fetch_array($result)){
                    if ($R["id"]==$VidRazred){
                        echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }
                }
                echo "</select></td></tr>";
                echo "</table><br />";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
                echo "</body>";
                echo "</html>";
        }
    }
}else{
    //echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>