<?php
function CheckPraznik2($d){
//'	response.write d&" "&StPraznikov&"<br>"
	for ($Indx=1;$Indx <= $StPraznikov;$Indx++){
		if ($Praznik[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) {
			switch ( $Praznik[$Indx][1]){
				case 1:
					return 2; //'prost dan
				case 0:
					return 1; //'praznik
				case 2:
					return 3; //'delovni dan - sobota
				case 3:
					return 4; //'dela prost dan
				default:
					return 0; //'ni v bazi/delovni dan
			}
		}else{
			return 0; //'ni v bazi/delovni dan
		}
	}
}

function vrniMesto($datum,$zac,$konec){
    global $Praznik;
//	'izhodni pogoj ob zadnjem elementu, ki ga ?e ni pogledal
	if ($konec-$zac <= 0 ) {
		if ($Praznik[$konec][0]->format('Y-m-d')==$datum->format('Y-m-d') ) {
			return $konec;
		}else{
//			'ni našel
			return -1;
		}
	}else{
        $razlika=$Praznik[round(($konec-$zac) / 2)+$zac][0]->diff($datum);
		if ($razlika->days == 0 ) {
			//'če ga je zadel
			return round(($konec-$zac) / 2) + $zac;
		}else{
			if ($razlika->invert == 0) {
				//'nov klic v zgornji del
				return vrniMesto($datum,(round(($konec-$zac) / 2) + $zac+1),$konec);
			}else{
			//	'nov klic v spodnji del
				return vrniMesto($datum,$zac,(round(($konec-$zac) / 2) + $zac-1));
			}
		}
	}
}

function binarySearch($searchKey){
    $lowIdx  = 1;
    $highIdx = $StPraznikov - 1;
    while (true) {
		if (($highIdx < $lowIdx) ) {
			return -1;
		}
		$currentIdx = round(($lowIdx + $highIdx) / 2);
		if (($Praznik[$currentIdx][0] == $searchKey) ) {
			return $currentIdx;
		}else{ 
			if (($Praznik[$currentIdx][0] < $searchKey) ) {
				$lowIdx = $currentIdx + 1;
			}else{  
				$highIdx = $currentIdx - 1;
			}
		}	
    }
}

function CheckPraznik($d){
    global $StPraznikov,$Praznik;
    
    if ($StPraznikov > 0){
	    $pozicija=vrniMesto($d,1,$StPraznikov);
	    if ($pozicija > -1 ) {
		    switch ( $Praznik[$pozicija][1]){
			    case 1:
				    return 2; //'prost dan
			    case 0:
				    return 1; //'praznik
			    case 2:
				    return 3; //'delovni dan - sobota
			    case 3:
                    return 4; //'dela prost dan
                case 4:
                    return 4; //'dela prost dan
			    default:
				    return 0; //'ni v bazi/delovni dan
		    }
	    }else{
		    return 0; //'ni v bazi/delovni dan
	    }
    }else{
        return 0; //'ni v bazi/delovni dan
    }
    
    /*/novo
    if (isset($Praznik[$d->format('Y')][$d->format('n')][$d->format('j')])){
        return $Praznik[$VLetoPregled][$VMesec][$Indx];
    }else{
        return 0;
    }
    */
}
?>