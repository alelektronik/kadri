<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vpis prihodov in odhodov
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>

<?php
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

function NoLeadZero($x){
    /*
    while (strpos($x,"0") == 0){
        $x=substr($x,1,(strlen($x)-1));
    }
    */
    return trim($x);
}
Function EAN8($BarTextIn){
    //' Initialize input and output strings
    $BarTextOut = "";
    $BarTextIn = trim($BarTextIn);

    //' Throw away non-numeric data
    $TempString = "";
    For ($II = 0;$II < strlen($BarTextIn);$II++){
        if (is_numeric(substr($BarTextIn, $II, 1)) ){ 
            $TempString = $TempString . substr($BarTextIn, $II, 1);
        }
    }

    //' Better be 7 digits long, or error it
    while (strlen($TempString) < 7 ){ 
        $TempString = "0".$TempString;
    }

    If (strlen($TempString) > 7 ){ 
        $TempString = substr($TempString,0,7);
    }
    //' Now calculate checksum and character map left and right sides
    $Sum = 0;
    $WorkL = "";
    $WorkR = "";
    For ($II = 0;$II < 7;$II++){
        If (($II % 2) == 0 ){
            $Sum = $Sum + (3 * substr($TempString, $II, 1));
        }else{
            $Sum = $Sum + substr($TempString, $II, 1);
        }

        If ($II < 4 ){
            $WorkL = $WorkL . Chr(ord(substr($TempString, $II, 1)) + 17);
        }else{
            $WorkR = $WorkR . substr($TempString, $II, 1);
        }
    }

    //' Build actual checksum character
    $CheckSumValue = 10 - ($Sum % 10);
    If ($CheckSumValue == 10 ){ 
        $CheckSumValue = 0;
    }
    $CheckSum = Chr(48 + $CheckSumValue);
    return $CheckSum;
    
    //' Build working bar code string
    $BarCodeOut = "[" . $WorkL . "|" . $WorkR . $CheckSum . "] ";

    return $BarCodeOut;
}

$VDelavec = $_POST["delavec"];
$DatumStart=new DateTime(isDate($_POST["datum"]));
$VLeto = $DatumStart->format('Y');
$VMesec = $DatumStart->format('n');
$VDan = $DatumStart->format('j');
$VCas = new DateTime($_POST["clock"]);
$VUra = $VCas->format('H');
$VMinuta = $VCas->format('i');
$ip=$_POST["ip"];
if (isset($_POST["oddaj1_x"])){
    $VOddaj="1";
}else{
    if (isset($_POST["oddaj2_x"])){
        $VOddaj="2";
    }else{
        if (isset($_POST["oddaj3_x"])){
            $VOddaj="3";
        }else{
            $VOddaj="4";
        }
    }
}
if ((strlen($VDelavec) > 4)&&(strlen($VDelavec) <= 8)) {
    $str_del=substr($VDelavec,0,(strlen($VDelavec)-1));
    $str_delc=substr($VDelavec,strlen($VDelavec)-1,1);
    if ($str_delc == EAN8($str_del)){
        $VDelavec=NoLeadZero(substr($VDelavec,0,(strlen($VDelavec)-1)));
        $VDelavec=intval($VDelavec)-2000;
    }else{
        $VDelavec="-";
    }
}else{
    $VDelavec="-";
}

$SQL = "SELECT * FROM kadrovi WHERE emso='".$VDelavec."' LIMIT 0,1";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VImeDelavca=$R["PRIIMIME"];
    $SifraDelavca=$R["STDELAVCA"];
    $NeSprejmi=false;
    
    switch ($VOddaj){
        case "1": //    'prihod
            $SQL = "SELECT * FROM tabprihodi ORDER BY id DESC LIMIT 0,100";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["SIFRA"]==$SifraDelavca) {
                    switch ($R["VRSTAPRIH"]){
                        case "1001":
                            $DatumP=new DateTime(isDate($R["DATUMPRIH"]));
                            break;
                        default:
                            $DatumP=new DateTime(isDate($R["DATUMODH"]));
                    }
                    if ($DatumP->format('d.m.Y')==$DatumStart->format('d.m.Y')){
                        if ($VUra*60+$VMinuta-$R["MINUT"] <= 5) {
                            if ($R["VRSTAPRIH"]=="1001") {
                                $NeSprejmi=true;
                            }
                        }
                    }    
                }
            }
            $SQL = "INSERT INTO tabprihodi (sifra,datumprih,letopr,mesecpr,danpr,uraprih,minprih,vrstaprih,minut,sistemdat,pripomba) VALUES ('".$SifraDelavca."','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",'1001',".($VUra*60+$VMinuta).",'".$Danes->format('Y-m-d H:i:s')."','".$ip."')";
            break;
        case "2": //    'malica
            $SQL = "SELECT * FROM tabprihodi ORDER BY id DESC LIMIT 0,100";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["SIFRA"]==$SifraDelavca) {
                    switch ($R["VRSTAPRIH"]){
                        case "1001":
                            $DatumP=new DateTime(isDate($R["DATUMPRIH"]));
                            break;
                        default:
                            $DatumP=new DateTime(isDate($R["DATUMODH"]));
                    }
                    if ($DatumP->format('d.m.Y')==$DatumStart->format('d.m.Y')){
                        if ($VUra*60+$VMinuta-$R["MINUT"] <= 5) {
                            if ($R["VRSTAPRIH"]=="3010") {
                                $NeSprejmi=true;
                            }
                        }
                    }    
                }
            }
            $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$SifraDelavca."','3010','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$Danes->format('Y-m-d H:i:s')."','".$ip."')";
            break;
        case "3": //    'službeno
            $SQL = "SELECT * FROM tabprihodi ORDER BY id DESC LIMIT 0,100";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
               if ($R["SIFRA"]==$SifraDelavca) {
                    switch ($R["VRSTAPRIH"]){
                        case "1001":
                            $DatumP=new DateTime(isDate($R["DATUMPRIH"]));
                            break;
                        default:
                            $DatumP=new DateTime(isDate($R["DATUMODH"]));
                    }
                    if ($DatumP->format('d.m.Y')==$DatumStart->format('d.m.Y')){
                        if ($VUra*60+$VMinuta-$R["MINUT"] <= 5) {
                            if ($R["VRSTAPRIH"]=="3002") {
                                $NeSprejmi=true;
                            }
                        }
                    }    
                }
            }
            $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$SifraDelavca."','3002','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$Danes->format('Y-m-d H:i:s')."','".$ip."')";
            break;
        case "4": //    'odhod
            $SQL = "SELECT * FROM tabprihodi ORDER BY id DESC LIMIT 0,100";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
               if ($R["SIFRA"]==$SifraDelavca) {
                    switch ($R["VRSTAPRIH"]){
                        case "1001":
                            $DatumP=new DateTime(isDate($R["DATUMPRIH"]));
                            break;
                        default:
                            $DatumP=new DateTime(isDate($R["DATUMODH"]));
                    }
                    if ($DatumP->format('d.m.Y')==$DatumStart->format('d.m.Y')){
                        if ($VUra*60+$VMinuta-$R["MINUT"] <= 5) {
                            if ($R["VRSTAPRIH"]=="3001") {
                                $NeSprejmi=true;
                            }
                        }
                    }    
                }
            }
            $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$SifraDelavca."','3001','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$Danes->format('Y-m-d H:i:s')."','".$ip."')";
    }
    if ($NeSprejmi){
        echo "<script type='text/javascript'>alert('PODVOJENI PODATKI - NI VPISA (".$VOddaj.")!')</script>";
        echo "<script type='text/javascript'>window.location='prihodiodhodi.php'</script>";
    }else{
        $result = mysqli_query($link,$SQL);
        /*
        echo "<p style='font-size: 60pt'>".$VImeDelavca."</p>";
        switch ($VOddaj){
            case "1":
                echo "<p style='font-size: 60pt'>Prihod na delo: ".$DatumStart->format('d.m.Y')." ".$VUra.":".$VMinuta."</p>";
                break;
            case "2":
                echo "<p style='font-size: 60pt'>Izhod za malico: ".$DatumStart->format('d.m.Y')." ".$VUra.":".$VMinuta."</p>";
                break;
            case "3":
                echo "<p style='font-size: 60pt'>Službeni izhod: ".$DatumStart->format('d.m.Y')." ".$VUra.":".$VMinuta."</p>";
                break;
            case "4":
                echo "<p style='font-size: 60pt'>Odhod z dela: ".$DatumStart->format('d.m.Y')." ".$VUra.":".$VMinuta."</p>";
        }
        */
        echo "<script type='text/javascript'>alert('Podatki so vpisani! (".$VOddaj."): ".$VImeDelavca.", ".$DatumStart->format('d.m.Y')." ".$VUra.":".$VMinuta."')</script>";
        echo "<script type='text/javascript'>window.location='prihodiodhodi.php'</script>";
    }    
}else{
    echo "<script type='text/javascript'>alert('Uporabnik neznan!')</script>";
    echo "<script type='text/javascript'>window.location='prihodiodhodi.php'</script>";
}
?>
</body>
</html>
