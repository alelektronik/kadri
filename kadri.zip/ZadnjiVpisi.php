<?php
include('const.php');
ini_set('max_execution_time', 600); 
include('razredi.php');
include('iskanje.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Zadnji vnosi
</title>
<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%j.%n.%Y",
            yearsRange:[2010,2030],
            limitToToday:true
        });
    };
</script>
</head>
<body>
<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
//    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');

    if (!CheckDostop("DelKontr",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["idUcitelj"])){
            $ucitelj = $_POST["idUcitelj"];
        }else{
            if (isset($_GET["idUcitelj"])){
                $ucitelj = $_GET["idUcitelj"];
            }else{
                if (isset($_SESSION["idUcitelj"])){ 
                    $ucitelj = $_SESSION["idUcitelj"];
                }else{
                    $ucitelj = 0;
                }
            }
        }
        if (isset($_POST["datum"])){
            if (isDate($_POST["datum"])){
                $Datum=new DateTime(isDate($_POST["datum"]));
            }else{
                $Datum=new DateTime($Danes->format('Y-m-d'));
            }
        }else{
            $Datum=new DateTime($Danes->format('Y-m-d'));
        }
        $VLetoPregled=$VLeto;

        echo "<br />";
        echo "<form accept-charset='utf-8' name='dolocidatum' method='post' action='ZadnjiVpisi.php'>";
        echo "Vpisano na dan: <input id='dat01' name='datum' type='text' size='10' value='".$Datum->format('j.n.Y')."'>";
        echo "<input name='submit' type='submit' value='Upoštevaj datum'><br />";
        echo "<small>(To ne pomeni, da velja rubrika za ta dan. Vpisana je bila na ta dan!)</small>";
        echo "</form>";
        
        $SQL = "SELECT tabpregleddelan.id AS pid,tabpregleddelan.komentar AS pkomentar,tabpregleddelan.datum,tabpregleddelan.enot,tabpregleddelan.enotpotrjeno,tabpregleddelan.rubrika,tabpregleddelan.ucitelj,";
        $SQL = $SQL . "tabdoprinos.aktivno,tabdoprinos.koeficient,tabdoprinos.oblikadela,tabdoprinos.uramin,";
        $SQL = $SQL . "tabucitelji.priimek,tabucitelji.ime FROM (tabpregleddelan ";
        $SQL = $SQL . "INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.ucitelj=tabucitelji.idUcitelj ";
        $SQL = $SQL . "WHERE day(tabpregleddelan.cas)=".$Datum->format('j')." AND month(tabpregleddelan.cas)=".$Datum->format('n')." AND year(tabpregleddelan.cas)=".$Datum->format('Y')." AND tabucitelji.status > 0 ";
        $SQL = $SQL ." ORDER BY tabpregleddelan.id DESC";
        //'response.write $SQL."<br>"
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result) > 0){
	        echo "<h2>Vnosi na dan - ".$Datum->format('d.m.Y')."</h2>";
        }else{
	        echo "<h2>zadnjih 200 vnosov</h2>";
	        $SQL = "SELECT tabpregleddelan.id AS pid,tabpregleddelan.komentar AS pkomentar,tabpregleddelan.datum,tabpregleddelan.enot,tabpregleddelan.enotpotrjeno,tabpregleddelan.rubrika,tabpregleddelan.ucitelj,";
            $SQL = $SQL . "tabdoprinos.aktivno,tabdoprinos.koeficient,tabdoprinos.oblikadela,tabdoprinos.uramin,";
            $SQL = $SQL . "tabucitelji.priimek,tabucitelji.ime FROM (tabpregleddelan ";
	        $SQL = $SQL . "INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos) ";
	        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.ucitelj=tabucitelji.idUcitelj ";
	        $SQL = $SQL . "WHERE tabucitelji.status > 0 ";
	        $SQL = $SQL ." ORDER BY tabpregleddelan.id DESC LIMIT 0,200 ";
	        //'echo $SQL."<br>"
	        $result = mysqli_query($link,$SQL);
        }

        echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.php'>";
        echo "<input name='submit' type='submit' value='Briši'><br />";
        echo "<input name='back' type='hidden' value='zadnji'><br />";
        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
        echo "<tr bgcolor='cyan'><th></th><th>Št.</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
	        switch ($R["aktivno"]){
		        case 1:
			        if ($R["enotpotrjeno"] ){
				        if ($R["rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightgreen'>";
				        }
			        }else{
				        if ($R["rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightyellow'>";
				        }
			        }
                    break;
		        default:
				        if ($R["rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightcyan'>";
				        }
	        }
	        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
	        echo "<td>".$Indx."</td>";
            $Datum=new DateTime($R["datum"]);
	        echo "<td>".$Datum->format('d.m.Y')."</td>";
	        echo "<td>".$R["oblikadela"]."</td>";
	        if ($R["uramin"] > 1 ){
		        echo "<td>".$R["enot"]." min</td>";
	        }else{
		        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
			        echo "<td>".$R["enot"]." dni</td>";
		        }else{
			        echo "<td>".$R["enot"]." ur</td>";
		        }
	        }
	        echo "<td>".$R["pkomentar"]."</td>";
	        if ($R["enotpotrjeno"] ){
		        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["ucitelj"]."'>da</a></td>";
	        }else{
		        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=1&Ucitelj=".$R["ucitelj"]."'>ne</a></td>";
	        }
	        echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["ucitelj"]."'>Popravi</a></td>";
        //'		echo "<td><a href='brisiPDN.php?id=".$R["tabpregleddelan.id").".idUcitelj=".ucitelj."'>Briši</td>";
	        //echo "<td><input name='id' value='".$R["pid"]."' type='checkbox'></td>";
            echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
	        echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<input name='StRubrik' type='hidden' value='".($Indx-1)."'><br />";
        echo "<input name='submit' type='submit' value='Briši'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Odznači vse' onClick='BrisiVse(this.form)'>";
        echo "</form><br />";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
