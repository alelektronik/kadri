<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
require('fpdf.php');

class PDF extends FPDF {
    var $B;
    var $I;
    var $U;
    var $HREF;

    /*
    function PDF($orientation='P', $unit='mm', $size='A4')
    {
        // Call parent constructor
        $this->FPDF($orientation,$unit,$size);
        // Initialization
        $this->B = 0;
        $this->I = 0;
        $this->U = 0;
        $this->HREF = '';
    }
    */
    
    function __constructor($orientation='P', $unit='mm', $size='A4')
    {
        // Call parent constructor
        // $this->FPDF($orientation,$unit,$size);
        // Initialization
        $this->B = 0;
        $this->I = 0;
        $this->U = 0;
        $this->HREF = '';
    }
    
    function WriteHTML($h,$html)
    {
        // HTML parser
        $html = str_replace("\n",' ',$html);
        $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
        foreach($a as $i=>$e)
        {
            if($i%2==0)
            {
                // Text
                if($this->HREF)
                    $this->PutLink($this->HREF,$h,$e);
                else
                    $this->Write($h,$e);
            }
            else
            {
                // Tag
                if($e[0]=='/')
                    $this->CloseTag(strtoupper(substr($e,1)));
                else
                {
                    // Extract attributes
                    $a2 = explode(' ',$e);
                    $tag = strtoupper(array_shift($a2));
                    $attr = array();
                    foreach($a2 as $v)
                    {
                        if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                            $attr[strtoupper($a3[1])] = $a3[2];
                    }
                    $this->OpenTag($tag,$attr,$h);
                }
            }
        }
    }

    function OpenTag($tag, $attr,$h)
    {
        // Opening tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,true);
        if($tag=='A')
            $this->HREF = $attr['HREF'];
        if($tag=='BR')
            $this->Ln($h);
    }

    function CloseTag($tag)
    {
        // Closing tag
        if($tag=='B' || $tag=='I' || $tag=='U')
            $this->SetStyle($tag,false);
        if($tag=='A')
            $this->HREF = '';
    }

    function SetStyle($tag, $enable)
    {
        // Modify style and select corresponding font
        $this->$tag += ($enable ? 1 : -1);
        $style = '';
        foreach(array('B', 'I', 'U') as $s)
        {
            if($this->$s>0)
                $style .= $s;
        }
        $this->SetFont('',$style);
    }

    function PutLink($URL,$h, $txt)
    {
        // Put a hyperlink
        $this->SetTextColor(0,0,255);
        $this->SetStyle('U',true);
        $this->Write($h,$txt,$URL);
        $this->SetStyle('U',false);
        $this->SetTextColor(0);
    }
}
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
if (isset($_SESSION["posx"])){
    $KorX = $_SESSION["posx"];
}else{
    $KorX = 0;
}
if (isset($_SESSION["posy"])){
    $KorY = $_SESSION["posy"];
}else{
    $KorY = 0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay = $_SESSION["DayToPrint"];
}else{
    $PrintDay = $Danes->format('j. n. Y');
}

if (isset($_POST["idd"])){
    $Vidd=$_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $Vidd=$_GET["idd"];
    }else{
        $Vidd="";
    }
}
function sPresledki($str){
    $chars = str_split($str);
    $s="";
    foreach($chars as $char){
        $char=$char." ";
        $s .= $char;
    }
    return $s;
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

switch ($Vidd){
    case "12":
    case "22":
        break;
    default:
    ?>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="pragma" content="no-cache" >
        <link rel="stylesheet" type="text/css" href="osmj.css">
        <title>Zdravstveni pregledi
        </title>
            <script>
             function showIskanje(str)
             {
             if (str=="")
               {
               document.getElementById("txtHint").innerHTML="";
               return;
               } 
             if (window.XMLHttpRequest){
               // code for IE7+, Firefox, Chrome, Opera, Safari";
               xmlhttp=new XMLHttpRequest();
               }
             else{
               // code for IE6, IE5";
               xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
               }
             xmlhttp.onreadystatechange=function()
               {
               if (xmlhttp.readyState==4 && xmlhttp.status==200){
                 
                 document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                 }
               }
             xmlhttp.open("GET","getpoklic.php?iskanje="+str,true);
             xmlhttp.send();
             }
             </script>
        </head>
        <body>
<?php        
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo3",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    $VLetoPregled=$ActualYear;
    switch ($Vidd){
        case "11": //izpolnjevanje obrazca 8.204
            $Delavec=$_GET["delavec"];
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($Delavec,$VLetoPregled,$VLeto);
            echo "<form name='form_8204' method='post' action='ZdravniskiPregledi.php'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<table border='1' cellspacing='0'>";

            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $NazivInSedez=$R["SolaKratko"].", ".$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
                $Davcna=$R["ddv_ID"];
                $Ravnatelj=$R["Ravnatelj"];
                $Kraj=$R["Kraj"];
            }
            echo "<tr><th>Rubrika</th><th>Vsebina</th></tr>";
            echo "<tr><td>Naziv in sedež delodajalca</td><td><input name='delodajalec' type='text' size='80' value='".$NazivInSedez."'></td></tr>";
            echo "<tr><td>Davčna številka</td><td><input name='ds' type='text' size='40' value='".$Davcna."'></td></tr>";
            echo "<tr><td>Gospodarska dejavnost</td><td><input name='gospdej' type='text' size='40' value='Osnovnošolsko izobraževanje'></td></tr>";
            echo "<tr><td>Koda gosp. dejavnosti</td><td><input name='kgospdej' type='text' size='10' value='85.200'></td></tr>";

            if (strlen($oUcitelj->getDekliski()) > 0){
                echo "<tr><td>Priimek, dekliški priimek in ime</td><td><input name='ime' type='text' size='40' value='".$oUcitelj->getPriimek()." (".$oUcitelj->getDekliski().") ".$oUcitelj->getIme()."'></td></tr>";
            }else{
                echo "<tr><td>Priimek, dekliški priimek in ime</td><td><input name='ime' type='text' size='40' value='".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."'></td></tr>";
            }
            echo "<tr><td>Kraj rojstva</td><td><input name='krajroj' type='text' size='40' value='".$oUcitelj->getKrajRoj()."'></td></tr>";
            echo "<tr><td>EMŠO</td><td><input name='emso' type='text' size='40' value='".$oUcitelj->getEmso()."'></td></tr>";
            if (strlen($oUcitelj->getNaslovZac()) > 0){
                echo "<tr><td>Kraj, ulica, številka, naziv pošte</td><td><input name='naslov' type='text' size='40' value='".$oUcitelj->getNaslovZac().", ".$oUcitelj->getKrajZac()."'></td></tr>";
            }else{
                echo "<tr><td>Kraj, ulica, številka, naziv pošte</td><td><input name='naslov' type='text' size='40' value='".$oUcitelj->getNaslov().", ".$oUcitelj->getKraj()."'></td></tr>";
            }
            if (strlen($oUcitelj->getNaslovZac()) > 0){
                echo "<tr><td>Poštna številka</td><td><input name='posta' type='text' size='10' value='".$oUcitelj->getPostaZac()."'></td></tr>";
            }else{
                echo "<tr><td>Poštna številka</td><td><input name='posta' type='text' size='10' value='".$oUcitelj->getPosta()."'></td></tr>";
            }
            echo "<tr><td>Izobrazba</td><td><input name='izobrazba' type='text' size='40' value='".$oUcitelj->getIzobOpis()."'></td></tr>";
            
            echo "<tr><td>Stopnja izobrazbe (1-9)</td><td>";
            echo "<select name='stopnja'>";
            $SQL = "SELECT idizobrazba,opis FROM tabizobrazba";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($oUcitelj->getStopnjaIzobrazbe()==$R["idizobrazba"]){
                    echo "<option value='".$R["idizobrazba"]."' selected='selected'>".$R["opis"]."</option>";
                }else{
                    echo "<option value='".$R["idizobrazba"]."'>".$R["opis"]."</option>";
                }
            }
            
            echo "</select></td></tr>";
            
            echo "<tr><td>Poklic (standardna klasifikacija)</td><td>";
            /*
            echo "Išči <input name='iskanje' type='text' onkeyup='showIskanje(this.value)'>";
            //echo "<input name='submit' type='submit' value='Najdi'>";
            
            
            echo "<div id='txtHint'>";
            echo "<select name='poklic'>";
            //$SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev WHERE solstvo=1";
            $SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev ORDER BY solstvo DESC,sifrakat";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["sifrakat"]."'>".$R["sifrakat"]." - ".$R["deskriptor"]."</option>";
            }
            echo "</select>";
            echo "</div>";
            */
            echo "Šifra: <input type='text' name='poklic' value='' size='4'> Opis: <input type='text' name='poklic1' value='' size='20'> <a href='http://www.stat.si/SKP/Esearch.aspx' target='_blank'>Povezava na statistični urad</a>";
            
            echo "</td></tr>";
            
            echo "<tr><td>Zaposlitev na delovnem mestu</td><td><input name='delmesto' type='text' size='40' value='".$oUcitelj->getVzgojnoDelo()."'></td></tr>";
            echo "<tr><td>Interna koda delovnega mesta</td><td><input name='kdelmesto' type='text' size='10' value=''></td></tr>";
            echo "<tr><td>Datum ocene tveganja za delovno mesto</td><td><input name='octveg' type='text' size='10' value=''></td></tr>";
            
            echo "<tr><td>Kratek opis del. procesa</td><td><textarea name='delproc' cols='40' rows='3'>";
            echo $oUcitelj->getOpisDela().", tedenski delovni čas: ".($oUcitelj->getProcZapLetno($VLetoPregled)*40/100)." ur, delo v izmenah: ";
            echo "</textarea></td></tr>";
            
            echo "<tr><td>Delovna oprema</td><td><input name='deloprema' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Predmeti dela</td><td><input name='predmetidela' type='text' size='40' value=''></td></tr>";
            
            echo "<tr><td>Izpostavljenost tveganjem</td><td><textarea name='izpostavljenost' cols='40' rows='3'></textarea></td></tr>";
            
            echo "<tr><td>Ukrepi po oceni tveganja</td><td><textarea name='ukrepi' cols='40' rows='3'></textarea></td></tr>";
            
            echo "<tr><td>Osebna varovalna oprema</td><td><input name='osoprema' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Posebne zdravstvene zahteve</td><td><textarea name='zdrzahteve' cols='40' rows='3'></textarea></td></tr>";
            echo "<tr><td>Delovno mesto je neustrezno za</td><td><input name='neustrezno' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Pripombe delodajalca</td><td><input name='pripombe' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Kraj</td><td><input name='kraj' type='text' size='20' value='".$Kraj."'></td></tr>";
            echo "<tr><td>Dne</td><td><input name='dne' type='text' size='10' value='".$Danes->format('d.m.Y')."'></td></tr>";
            echo "<tr><td>Odgovorna oseba</td><td><input name='odgovorni' type='text' size='30' value='".$Ravnatelj."'></td></tr>";
            echo "</table>";
            echo "<input name='obrazec' type='checkbox' checked='checked'>Izpis skupaj z obrazcem<br />";
            echo "<input name='delavec' type='hidden' value='".$Delavec."'>";
            echo "<input name='idd' type='hidden' value='12'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "12": //PDF obrazec 8.204
            $delodajalec=$_POST["delodajalec"];
            $ds=$_POST["ds"];
            $gospdej=$_POST["gospdej"];
            $kgospdej=$_POST["kgospdej"];
            $ime=$_POST["ime"];
            $krajroj=$_POST["krajroj"];
            $emso=$_POST["emso"];
            $naslov=$_POST["naslov"];
            $posta=$_POST["posta"];
            $izobrazba=$_POST["izobrazba"];
            $stopnja=$_POST["stopnja"];
            $poklic=$_POST["poklic"];
            $poklic1=$_POST["poklic1"];
            $delmesto=$_POST["delmesto"];
            $kdelmesto=$_POST["kdelmesto"];
            $octveg=$_POST["octveg"];
            $delproc=$_POST["delproc"];
            $deloprema=$_POST["deloprema"];
            $predmetidela=$_POST["predmetidela"];
            $izpostavljenost=$_POST["izpostavljenost"];
            $ukrepi=$_POST["ukrepi"];
            $osoprema=$_POST["osoprema"];
            $zdrzahteve=$_POST["zdrzahteve"];
            $neustrezno=$_POST["neustrezno"];
            $pripombe=$_POST["pripombe"];
            $kraj=$_POST["kraj"];
            $dne=$_POST["dne"];
            $odgovorni=$_POST["odgovorni"];
            $obrazec=0;
            if (isset($_POST["obrazec"])){
                $obrazec=1;
            }
            $pdf = new PDF();

            $pdf->SetAutoPageBreak(false);
            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            $pdf->AddPage("P","A4");

            $FontSize=11;
            
            //vstavi sliko
            if ($obrazec==1){
                $pdf->Image("img/Obrazec 8_204 za predhodni pregled_1.jpg",0,0,210);
            }

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($delodajalec);
            $pdf->SetXY(55+$KorX,19-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($ds));
            $pdf->SetXY(39+$KorX,24-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($gospdej);
            $pdf->SetXY(55+$KorX,29-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $kgospdej=str_replace(".","",$kgospdej);
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($kgospdej));
            $pdf->SetXY(168+$KorX,29-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($ime);
            $pdf->SetXY(20+$KorX,53-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($krajroj);
            $pdf->SetXY(130+$KorX,53-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($emso));
            $pdf->SetXY(24+$KorX,61-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($naslov);
            $pdf->SetXY(30+$KorX,69-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($posta));
            $pdf->SetXY(172+$KorX,69-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($izobrazba);
            $pdf->SetXY(30+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($stopnja));
            $pdf->SetXY(83+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            /*
            $SQL = "SELECT deskriptor FROM tabsifrantpoklicev WHERE sifrakat='".$poklic."'";
            $result = mysqli_query($link,$SQL);
            $spoklic="";
            if ($R = mysqli_fetch_array($result)){
                $spoklic=$R["deskriptor"];
            }
            */
            $spoklic=$poklic1;
            $pdf->SetFont('arial_CE','',9);
            $txt=ToWin($spoklic);
            $pdf->SetXY(102+$KorX,74-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(60,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($poklic));
            $pdf->SetXY(162+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',9);
            $txt=ToWin($delmesto);
            $pdf->SetXY(90+$KorX,96-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(85,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($kdelmesto));
            $pdf->SetXY(172+$KorX,97-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            if (isDate($octveg)){
                $datum=new DateTime(isDate($octveg));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(163+$KorX,104-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($delproc);
            $pdf->SetXY(15+$KorX,120-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($deloprema);
            $pdf->SetXY(15+$KorX,148-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($predmetidela);
            $pdf->SetXY(15+$KorX,159-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($izpostavljenost);
            $pdf->SetXY(15+$KorX,167-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($ukrepi);
            $pdf->SetXY(15+$KorX,188-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($osoprema);
            $pdf->SetXY(15+$KorX,206-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($zdrzahteve);
            $pdf->SetXY(15+$KorX,214-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($neustrezno);
            $pdf->SetXY(15+$KorX,238-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($pripombe);
            $pdf->SetXY(50+$KorX,249-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($kraj);
            $pdf->SetXY(15+$KorX,260-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            if (isDate($dne)){
                $datum=new DateTime(isDate($dne));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(71+$KorX,260-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($odgovorni);
            $pdf->SetXY(140+$KorX,260-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");
            
            //vstavi sliko - zadnjo stran obrazca
            if ($obrazec==1){
                $pdf->AddPage("P","A4");
                $pdf->Image("img/Obrazec 8_204 za predhodni pregled_2.jpg",0,0,210);
            }
            $pdf->Output("zdrpregled.pdf","D");
            
            break;
        case "21": //izpolnjevanje obrazca 8.205
            $Delavec=$_GET["delavec"];
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($Delavec,$VLetoPregled,$VLeto);
            echo "<form name='form_8205' method='post' action='ZdravniskiPregledi.php'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<table border='1' cellspacing='0'>";

            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $NazivInSedez=$R["SolaKratko"].", ".$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
                $Davcna=$R["ddv_ID"];
                $Ravnatelj=$R["Ravnatelj"];
                $Kraj=$R["Kraj"];
            }
            echo "<tr><th>Rubrika</th><th>Vsebina</th></tr>";
            echo "<tr><td>Naziv in sedež delodajalca</td><td><input name='delodajalec' type='text' size='80' value='".$NazivInSedez."'></td></tr>";
            echo "<tr><td>Davčna številka</td><td><input name='ds' type='text' size='40' value='".$Davcna."'></td></tr>";
            echo "<tr><td>Gospodarska dejavnost</td><td><input name='gospdej' type='text' size='40' value='Osnovnošolsko izobraževanje'></td></tr>";
            echo "<tr><td>Koda gosp. dejavnosti</td><td><input name='kgospdej' type='text' size='10' value='85.200'></td></tr>";

            echo "<tr><td>Na podlagi točke</td><td><input name='tocka' type='text' size='10' value=''></td></tr>";
            echo "<tr><td>Na podlagi člena pravilnika</td><td><input name='clen' type='text' size='10' value=''></td></tr>";
            
            if (strlen($oUcitelj->getDekliski()) > 0){
                echo "<tr><td>Priimek, dekliški priimek in ime</td><td><input name='ime' type='text' size='40' value='".$oUcitelj->getPriimek()." (".$oUcitelj->getDekliski().") ".$oUcitelj->getIme()."'></td></tr>";
            }else{
                echo "<tr><td>Priimek, dekliški priimek in ime</td><td><input name='ime' type='text' size='40' value='".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."'></td></tr>";
            }
            echo "<tr><td>EMŠO</td><td><input name='emso' type='text' size='40' value='".$oUcitelj->getEmso()."'></td></tr>";
            if (strlen($oUcitelj->getNaslovZac()) > 0){
                echo "<tr><td>Kraj, ulica, številka, naziv pošte</td><td><input name='naslov' type='text' size='40' value='".$oUcitelj->getNaslovZac().", ".$oUcitelj->getKrajZac()."'></td></tr>";
            }else{
                echo "<tr><td>Kraj, ulica, številka, naziv pošte</td><td><input name='naslov' type='text' size='40' value='".$oUcitelj->getNaslov().", ".$oUcitelj->getKraj()."'></td></tr>";
            }
            if (strlen($oUcitelj->getNaslovZac()) > 0){
                echo "<tr><td>Poštna številka</td><td><input name='posta' type='text' size='10' value='".$oUcitelj->getPostaZac()."'></td></tr>";
            }else{
                echo "<tr><td>Poštna številka</td><td><input name='posta' type='text' size='10' value='".$oUcitelj->getPosta()."'></td></tr>";
            }
            echo "<tr><td>Izobrazba</td><td><input name='izobrazba' type='text' size='40' value='".$oUcitelj->getIzobOpis()."'></td></tr>";
            
            echo "<tr><td>Stopnja izobrazbe (1-9)</td><td>";
            echo "<select name='stopnja'>";
            $SQL = "SELECT idizobrazba,opis FROM tabizobrazba";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($oUcitelj->getStopnjaIzobrazbe()==$R["idizobrazba"]){
                    echo "<option value='".$R["idizobrazba"]."' selected='selected'>".$R["opis"]."</option>";
                }else{
                    echo "<option value='".$R["idizobrazba"]."'>".$R["opis"]."</option>";
                }
            }
            
            echo "</select></td></tr>";
            
            echo "<tr><td>Poklic (standardna klasifikacija)</td><td>";
            /*
            echo "Išči <input name='iskanje' type='text' onkeyup='showIskanje(this.value)'>";
            //echo "<input name='submit' type='submit' value='Najdi'>";
            
            echo "<div id='txtHint'>";
            echo "<select name='poklic'>";
            //$SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev WHERE solstvo=1";
            $SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev ORDER BY solstvo DESC,sifrakat";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["sifrakat"]."'>".$R["sifrakat"]." - ".$R["deskriptor"]."</option>";
            }
            echo "</select>";
            echo "</div>";
            */
            echo "Šifra: <input type='text' name='poklic' value='' size='4'> Opis: <input type='text' name='poklic1' value='' size='20'> <a href='http://www.stat.si/SKP/Esearch.aspx' target='_blank'>Povezava na statistični urad</a>";
            
            echo "</td></tr>";
            
            echo "<tr><td>Zaposlen pri nas od</td><td><input name='zaposlenod' type='text' size='10' value='".$oUcitelj->getDatumStart()->format('d.m.Y')."'></td></tr>";
            echo "<tr><td>na sedanjem delovnem mestu</td><td><input name='delmesto' type='text' size='40' value='".$oUcitelj->getVzgojnoDelo()."'></td></tr>";
            echo "<tr><td>Interna koda delovnega mesta</td><td><input name='kdelmesto' type='text' size='10' value=''></td></tr>";
            echo "<tr><td>od dne</td><td><input name='trenutnood' type='text' size='10' value='".$oUcitelj->getDatumStart()->format('d.m.Y')."'></td></tr>";
            echo "<tr><td>Datum zadnjega pregleda</td><td><input name='pregled' type='text' size='10' value='".$oUcitelj->getZdrPregled()."'></td></tr>";
            echo "<tr><td>Datum ocene tveganja za delovno mesto</td><td><input name='octveg' type='text' size='10' value=''></td></tr>";
            
            echo "<tr><td>Kratek opis del. procesa</td><td><textarea name='delproc' cols='40' rows='3'>";
            echo $oUcitelj->getOpisDela().", tedenski delovni čas: ".($oUcitelj->getProcZapLetno($VLetoPregled)*40/100)." ur, delo v izmenah: ";
            echo "</textarea></td></tr>";
            
            echo "<tr><td>Delovna oprema</td><td><input name='deloprema' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Predmeti dela</td><td><input name='predmetidela' type='text' size='40' value=''></td></tr>";
            
            echo "<tr><td>Izpostavljenost tveganjem</td><td><textarea name='izpostavljenost' cols='40' rows='3'></textarea></td></tr>";
            
            echo "<tr><td>Ukrepi po oceni tveganja</td><td><textarea name='ukrepi' cols='40' rows='3'></textarea></td></tr>";
            
            echo "<tr><td>Osebna varovalna oprema</td><td><input name='osoprema' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Posebne zdravstvene zahteve</td><td><textarea name='zdrzahteve' cols='40' rows='3'></textarea></td></tr>";
            echo "<tr><td>Delovno mesto je neustrezno za</td><td><input name='neustrezno' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Pripombe delodajalca</td><td><input name='pripombe' type='text' size='40' value=''></td></tr>";
            echo "<tr><td>Kraj</td><td><input name='kraj' type='text' size='20' value='".$Kraj."'></td></tr>";
            echo "<tr><td>Dne</td><td><input name='dne' type='text' size='10' value='".$Danes->format('d.m.Y')."'></td></tr>";
            echo "<tr><td>Odgovorna oseba</td><td><input name='odgovorni' type='text' size='30' value='".$Ravnatelj."'></td></tr>";
            echo "</table>";
            echo "<input name='obrazec' type='checkbox' checked='checked'>Izpis skupaj z obrazcem<br />";
            echo "<input name='delavec' type='hidden' value='".$Delavec."'>";
            echo "<input name='idd' type='hidden' value='22'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "22": //PDF obrazec 8.205
            $delodajalec=$_POST["delodajalec"];
            $ds=$_POST["ds"];
            $gospdej=$_POST["gospdej"];
            $kgospdej=$_POST["kgospdej"];
            $ime=$_POST["ime"];
            $zaposlenod=$_POST["zaposlenod"];
            $trenutnood=$_POST["trenutnood"];
            $pregled=$_POST["pregled"];
            $tocka=$_POST["tocka"];
            $clen=$_POST["clen"];
            $emso=$_POST["emso"];
            $naslov=$_POST["naslov"];
            $posta=$_POST["posta"];
            $izobrazba=$_POST["izobrazba"];
            $stopnja=$_POST["stopnja"];
            if ($stopnja > 6){
                $stopnja=$stopnja-1;
            }
            $poklic=$_POST["poklic"];
            $poklic1=$_POST["poklic1"];
            $delmesto=$_POST["delmesto"];
            $kdelmesto=$_POST["kdelmesto"];
            $octveg=$_POST["octveg"];
            $delproc=$_POST["delproc"];
            $deloprema=$_POST["deloprema"];
            $predmetidela=$_POST["predmetidela"];
            $izpostavljenost=$_POST["izpostavljenost"];
            $ukrepi=$_POST["ukrepi"];
            $osoprema=$_POST["osoprema"];
            $zdrzahteve=$_POST["zdrzahteve"];
            $neustrezno=$_POST["neustrezno"];
            $pripombe=$_POST["pripombe"];
            $kraj=$_POST["kraj"];
            $dne=$_POST["dne"];
            $odgovorni=$_POST["odgovorni"];
            $obrazec=0;
            if (isset($_POST["obrazec"])){
                $obrazec=1;
            }
            $pdf = new PDF();

            $pdf->SetAutoPageBreak(false);
            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            $pdf->AddPage("P","A4");

            $FontSize=11;
            
            //vstavi sliko
            if ($obrazec==1){
                $pdf->Image("img/Obrazec 8_205 za obdobni pregled_1.jpg",0,0,210);
            }

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($delodajalec);
            $pdf->SetXY(55+$KorX,16-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($ds));
            $pdf->SetXY(42+$KorX,21-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($gospdej);
            $pdf->SetXY(55+$KorX,26-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $kgospdej=str_replace(".","",$kgospdej);
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($kgospdej));
            $pdf->SetXY(172+$KorX,26-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($tocka);
            $pdf->SetXY(40+$KorX,50-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($clen);
            $pdf->SetXY(105+$KorX,50-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($ime);
            $pdf->SetXY(20+$KorX,62-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($emso));
            $pdf->SetXY(137+$KorX,61-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($naslov);
            $pdf->SetXY(30+$KorX,69-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($posta));
            $pdf->SetXY(176+$KorX,68-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($izobrazba);
            $pdf->SetXY(33+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($stopnja));
            $pdf->SetXY(86+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            /*
            $SQL = "SELECT deskriptor FROM tabsifrantpoklicev WHERE sifrakat='".$poklic."'";
            $result = mysqli_query($link,$SQL);
            $spoklic="";
            if ($R = mysqli_fetch_array($result)){
                $spoklic=$R["deskriptor"];
            }
            */
            $spoklic=$poklic1;
            $pdf->SetFont('arial_CE','',9);
            $txt=ToWin($spoklic);
            $pdf->SetXY(105+$KorX,74-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(60,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($poklic));
            $pdf->SetXY(166+$KorX,76-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            if (isDate($zaposlenod)){
                $datum=new DateTime(isDate($zaposlenod));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(56+$KorX,83-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            if (isDate($trenutnood)){
                $datum=new DateTime(isDate($trenutnood));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(28+$KorX,91-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");
            
            if (isDate($pregled)){
                $datum=new DateTime(isDate($pregled));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(135+$KorX,96-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',9);
            $txt=ToWin($delmesto);
            $pdf->SetXY(130+$KorX,82-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(85,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($kdelmesto));
            $pdf->SetXY(176+$KorX,83-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            if (isDate($octveg)){
                $datum=new DateTime(isDate($octveg));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(167+$KorX,103-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($delproc);
            $pdf->SetXY(17+$KorX,120-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($deloprema);
            $pdf->SetXY(17+$KorX,148-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($predmetidela);
            $pdf->SetXY(17+$KorX,159-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($izpostavljenost);
            $pdf->SetXY(17+$KorX,167-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($ukrepi);
            $pdf->SetXY(17+$KorX,188-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($osoprema);
            $pdf->SetXY(17+$KorX,206-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($zdrzahteve);
            $pdf->SetXY(17+$KorX,214-$KorY);
            //$pdf->Cell(0,0,$txt,0,2,"L");
            $pdf->MultiCell(180,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($neustrezno);
            $pdf->SetXY(17+$KorX,238-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($pripombe);
            $pdf->SetXY(50+$KorX,249-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($kraj);
            $pdf->SetXY(17+$KorX,258-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");

            if (isDate($dne)){
                $datum=new DateTime(isDate($dne));
            }else{
                $datum=new DateTime($Danes->format('Y-m-d'));
            }
            $pdf->SetFont('arial_CE','',15);
            $txt=ToWin(sPresledki($datum->format('dmy')));
            $pdf->SetXY(74+$KorX,258-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(0,4,$txt,0,"L");

            $pdf->SetFont('arial_CE','',10);
            $txt=ToWin($odgovorni);
            $pdf->SetXY(143+$KorX,258-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            //$pdf->MultiCell(180,3,$txt,0,"L");
            
            //vstavi sliko - zadnjo stran obrazca
            if ($obrazec==1){
                $pdf->AddPage("P","A4");
                $pdf->Image("img/Obrazec 8_205 za obdobni pregled_2.jpg",0,0,210);
            }
            $pdf->Output("zdrpregled.pdf","D");
            
            break;
        default:  //običajna obdelava tabele zdravstvenih pregledov
            switch ($Vid){
	            case "1":  //vpis popravka
		            for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
			            if (isset($_POST["ZdrPregled".$Indx]) ){
                            if (isset($_POST["PeriodaLet".$Indx])){
				                $PeriodaLet=$_POST["PeriodaLet".$Indx];
                                if (!is_numeric($PeriodaLet)){
                                    $PeriodaLet=4;
                                }
                            }else{
                                $PeriodaLet=4;
                            }
				            $SQL = "UPDATE tabucitelji SET PeriodaLet=".$PeriodaLet.", ZdrPregled='".$_POST["ZdrPregled".$Indx]."' WHERE idUcitelj=".$_POST["ucitelj".$Indx];
				            $result = mysqli_query($link,$SQL);
				            
				            $SQL = "SELECT * FROM TabZdrPregledi WHERE idUcitelj=".$_POST["ucitelj".$Indx]." AND datum='".$_POST["ZdrPregled".$Indx]."'";
				            $result = mysqli_query($link,$SQL);
				            
				            if ($R = mysqli_fetch_array($result)){
					            $PeriodaLet=$PeriodaLet;
				            }else{
					            $SQL = "INSERT INTO TabZdrPregledi (idUcitelj,datum) VALUES (".$_POST["ucitelj".$Indx].",'".$_POST["ZdrPregled".$Indx]."')";
					            $result = mysqli_query($link,$SQL);
				            }
			            }
		            }
                    break;
	            case "2":
		            $SQL = "SELECT tabucitelji.*,TabZdrPregledi.* FROM tabucitelji INNER JOIN TabZdrPregledi ON tabucitelji.idUcitelj=TabZdrPregledi.idUcitelj ";
		            $SQL = $SQL . "WHERE tabucitelji.idUcitelj=".$_GET["delavec"];
		            $result = mysqli_query($link,$SQL);
		            
		            echo "<br><table border='1'>";
		            echo "<tr><th>Št.</th><th>Ime</th><th>Zdr. pregledi</th></tr>";
		            $Indx=1;
		            while ($R = mysqli_fetch_array($result)){
			            echo "<tr>";
			            echo "<td>".$Indx."</td>";
			            echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			            echo "<td align=right>".$R["datum"]."</td>";
			            echo "</tr>";
			            $Indx=$Indx+1;
		            }
		            echo "</table><br />";
                    break;
                case "3": //izpis samo podatkov
                    $SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
                    $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
                    $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.status < 10 ";
                    $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
                    //echo "<br>" . $SQL . "<br>"
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;

                    echo "<h2>Pregled delavcev z opravljenimi zdravstvenimi pregledi</h2>";
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
                    echo "<th>Star</th>";
                    echo "<th>Delo</th><th>Ponavljanje<br />pregledov (let)</th><th>Zadnji <br />zdr. pregled</th>";
                    echo "</tr>";
                    $ColorChange=true;

                    while ($R = mysqli_fetch_array($result)){
                        $oUcitelj=new RUcitelj();
                        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
                        if ($ColorChange ){
                            if (!isDate($oUcitelj->getZdrPregled())){
                                echo "<tr bgcolor='lightsalmon'>";
                            }else{
                                if (!is_numeric($oUcitelj->getPeriodaLet()) ){
                                    $PeriodaLet=4;
                                }else{
                                    $PeriodaLet=$oUcitelj->getPeriodaLet();
                                }
                                $Datum=new DateTime(isDate($oUcitelj->getZdrPregled()));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert==0) && ($Interval->days > $PeriodaLet*365)){
                                    echo "<tr bgcolor='lightsalmon'>";
                                }else{
                                    echo "<tr bgcolor='lightyellow'>";
                                }
                            }
                        }else{
                            if (!isDate($oUcitelj->getZdrPregled()) ){
                                echo "<tr bgcolor='lightsalmon'>";
                            }else{
                                if (!is_numeric($oUcitelj->getPeriodaLet()) ){
                                    $PeriodaLet=4;
                                }else{
                                    $PeriodaLet=$oUcitelj->getPeriodaLet();
                                }
                                $Datum=new DateTime(isDate($oUcitelj->getZdrPregled()));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert==0) && ($Interval->days > $PeriodaLet*365)){
                                    echo "<tr bgcolor='lightsalmon'>";
                                }else{
                                    echo "<tr bgcolor='lightyellow'>";
                                }
                            }
                        }
                        $ColorChange=!$ColorChange;
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</td>";
                        echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
                        echo "<td>".$oUcitelj->getDelMesto()."</td>";
                        echo "<td align='center'>".$oUcitelj->getPeriodaLet()."</td>";
                        echo "<td align='right'>".$oUcitelj->getZdrPregled()."</td>";
                        echo "</tr>";
                        $oUcitelj=null;
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                    //echo "<a href='ZdravniskiPregledi.php'>Na vnos zdravstvenih pregledov</a><br />";
                    break;
                
            }
            $SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
            $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
            $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.status < 10 ";
            $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
            //echo "<br>" . $SQL . "<br>"
            $result = mysqli_query($link,$SQL);

            $Indx=1;

            echo "<h2>Pregled delavcev z opravljenimi zdravstvenimi pregledi</h2>";
            echo "<form name='form_zdrpregledi' method=post action='ZdravniskiPregledi.php'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<table border='1' cellspacing='0'>";
            echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
            echo "<th>Star</th>";
            echo "<th>Delo</th><th>Ponavljanje<br />pregledov (let)</th><th>Zadnji <br />zdr. pregled</th><th>Obr.<br /> 8.204</th><th>Obr.<br /> 8.205</th>";
            echo "</tr>";
            $ColorChange=true;

            while ($R = mysqli_fetch_array($result)){
	            $oUcitelj=new RUcitelj();
	            $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
	            if ($ColorChange ){
		            if (!isDate($oUcitelj->getZdrPregled())){
			            echo "<tr bgcolor='lightsalmon'>";
		            }else{
			            if (!is_numeric($oUcitelj->getPeriodaLet()) ){
				            $PeriodaLet=4;
			            }else{
				            $PeriodaLet=$oUcitelj->getPeriodaLet();
			            }
                        $Datum=new DateTime(isDate($oUcitelj->getZdrPregled()));
                        $Interval=$Datum->diff($Danes);
			            if (($Interval->invert==0) && ($Interval->days > $PeriodaLet*365)){
				            echo "<tr bgcolor='lightsalmon'>";
			            }else{
				            echo "<tr bgcolor='lightyellow'>";
			            }
		            }
	            }else{
		            if (!isDate($oUcitelj->getZdrPregled()) ){
			            echo "<tr bgcolor='lightsalmon'>";
		            }else{
			            if (!is_numeric($oUcitelj->getPeriodaLet()) ){
				            $PeriodaLet=4;
			            }else{
				            $PeriodaLet=$oUcitelj->getPeriodaLet();
			            }
                        $Datum=new DateTime(isDate($oUcitelj->getZdrPregled()));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert==0) && ($Interval->days > $PeriodaLet*365)){
                            echo "<tr bgcolor='lightsalmon'>";
                        }else{
                            echo "<tr bgcolor='lightyellow'>";
                        }
		            }
	            }
	            $ColorChange=!$ColorChange;
	            echo "<td>".$Indx."</td>";
	            echo "<td><input name='ucitelj".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'><a href='ZdravniskiPregledi.php?id=2&delavec=".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
	            echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
	            echo "<td>".$oUcitelj->getDelMesto()."</td>";
	            echo "<td><input name='PeriodaLet".$Indx."' type='text' value='".$oUcitelj->getPeriodaLet()."' size='3'></td>";
	            echo "<td><input name='ZdrPregled".$Indx."' type='text' value='".$oUcitelj->getZdrPregled()."' size='8'></td>";
                
                echo "<td><a href='ZdravniskiPregledi.php?idd=11&delavec=".$oUcitelj->getIdUcitelj()."'>obr.</a></td>";
                echo "<td><a href='ZdravniskiPregledi.php?idd=21&delavec=".$oUcitelj->getIdUcitelj()."'>obr.</a></td>";
	            echo "</tr>";
	            $oUcitelj=null;
	            $Indx=$Indx+1;
            }
            echo "</table>";
            echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            echo "<a href='ZdravniskiPregledi.php?id=3'>Samo izpis tabele (za prenos v Excel)</a><br />";
    }

    switch ($Vidd){
        case "12":
        case "22":
            break;
        default:
            echo "</body>";
            echo "</html>";
    }
}
?>

