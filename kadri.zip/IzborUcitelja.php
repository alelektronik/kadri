<?php
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izbor delavca
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');


echo "Pregled zaposlenega: ";
if (isset($_POST["id"])){
    $id=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id=0;
    }
}        
    
switch ($id){
	case 1:
		if (!CheckDostop("UpdDel",$VUporabnik) ) { 
            header("Location: nepooblascen.htm");
        }else{
		    echo "<form accept-charset='utf-8' name='popravljanje' method=post action='PopraviUcitelja.php'>";
        }
        break;
	case 2:
		if (!CheckDostop("Tajn",$VUporabnik) ) { 
            header("Location: nepooblascen.htm");
        }else{
		    echo "<form accept-charset='utf-8' name='potrdilo' method=post action='PotrdiloOZaposlitviRTF.php'>";
        }
        break;
	case 3:
		if (!CheckDostop("DelKontr",$VUporabnik) ) { 
            header("Location: nepooblascen.htm");
        }else{
		    echo "<form accept-charset='utf-8' name='prihodi' method=post action='VpisPrihodov.php'>";
        }
        break;
	case 4:
		if (!CheckDostop("DelKontr",$VUporabnik) ) { 
            header("Location: nepooblascen.htm");
        }else{
		    echo "<form accept-charset='utf-8' name='pogodbe' method=post action='DodajPogodbo.php'>";
        }
        break;
	case 5:
		if (!CheckDostop("DelKontr",$VUporabnik) ) { 
            header("Location: nepooblascen.htm");
        }else{
		    echo "<form accept-charset='utf-8' name='pogodbe' method=post action='DodajPogodbo.php'>";
		    echo "<input name='id' type='hidden' value='5'>";
        }
        break;
    case 6:
        if ($VLevel < 3 ){ 
            header("Location: nepooblascen.htm");
        }
        echo "<form accept-charset='utf-8' name='brisanje' method=post action='BrisiDelavca.php'>";
        echo "<input name='id' type='hidden' value='6'>";
        break;
	default:
		echo "<form accept-charset='utf-8' name='ucitelji' method=post action='IzpisUcitelja.php'>";
}
echo "<select name='leto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected='selected' value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select><br />";
echo "<noscript>Ta obrazec za pravilno delovanje zahteva omogočen javascript.<br /></noscript>";
echo "<select name='idUcitelj' onchange='this.form.submit()'>";

if (isset($_GET["vsi"])){
    $vsi=$_GET["vsi"];
}else{
    $vsi=0;
}
if ($vsi==0){
    if (CheckDostop("UpdDel",$VUporabnik) ) { 
	    $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY Priimek, Ime ";
    }else{
	    $SQL = "SELECT * FROM tabucitelji WHERE status > 0 AND Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
    }
}else{
    if (CheckDostop("UpdDel",$VUporabnik) ) { 
        $SQL = "SELECT * FROM tabucitelji ORDER BY Priimek, Ime ";
    }else{
        $SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
    }

}
echo "<option value='0'>Ni izbran</option>";
$Indx=1;
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    if ($R["Status"]==0 ) {
         echo "<option value='" . $R["IdUcitelj"] . "'>(".$R["IdUcitelj"].") " . $R["Priimek"] . ", " . $R["Ime"] . " (*) </option>";
    }else{
//             echo "<option value='" . $R["IdUcitelj"] . "'>(".$R["IdUcitelj"].") " . iconv("windows-1250", "utf-8//TRANSLIT",$R["Priimek"] . ", " . $R["Ime"]) . "</option>";
         echo "<option value='" . $R["IdUcitelj"] . "'>(".$R["IdUcitelj"].") " . $R["Priimek"] . ", " . $R["Ime"] . "</option>";
    }
$Indx=$Indx+1;
}
echo "</select><br />";
//echo "	<input name='submit' type='submit' value='Pošlji'>";
echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
echo "</form>";
if ($vsi==0){
    if (CheckDostop("UpdDel",$VUporabnik) ) { 
        if ($id > 0) {
	        echo "<a href='IzborUcitelja.php?id=".$id."&vsi=1'>Možnost izbire vseh delavcev (tudi bivših)</a><br>";
        }else{
            echo "<a href='IzborUcitelja.php?id=0&vsi=1'>Možnost izbire vseh delavcev (tudi bivših)</a><br>";
        }
    }
}else{
    if (CheckDostop("UpdDel",$VUporabnik) ) { 
        if ($id > 0) {
            echo "<a href='IzborUcitelja.php?id=".$id."&vsi=0'>Možnost izbire aktualno zaposlenih delavcev</a><br>";
        }else{
            echo "<a href='IzborUcitelja.php?id=0&vsi=0'>Možnost izbire aktualno zaposlenih delavcev</a><br>";
        }
    }
}
echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";

?>

</body>
</html>
