<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo1",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$VEnotPotrjeno=$_GET["potrdi"];
$ucitelj=$_GET["Ucitelj"];
echo "Leto: ".$VLeto."<br />";

if (isset($_GET["id"])) {
	if ($VEnotPotrjeno=="1") {
    	$SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=true,potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_GET["id"];
	}else{
        $SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=false,potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_GET["id"];
	}
	$result = mysqli_query($link,$SQL);
}

header ("Location:IzpisUcitelja.php?idUcitelj=$ucitelj");
?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br />
</body>
</html>
