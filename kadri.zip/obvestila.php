<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Obvestila
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikIme=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (isset($_POST["idUcitelj"])){
    $ucitelj = $_POST["idUcitelj"];
}else{
    if (isset($_GET["idUcitelj"])){
        $ucitelj = $_GET["idUcitelj"];
    }else{
        if (isset($_SESSION["idUcitelj"])){ 
            $ucitelj = $_SESSION["idUcitelj"];
        }else{
            $ucitelj = 0;
        }
    }
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}
if (isset($_POST["zapis"])){
    $VZapis=$_POST["zapis"];
}else{
    if (isset($_GET["zapis"])){
        $VZapis=$_GET["zapis"];
    }else{
        $VZapis=0;
    }
}

switch ($Vid){
    case "6":
    case "7":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}    

if (!CheckDostop("DelPregl",$VUporabnik)) { 
    header("Location: nepooblascen.htm");
}else{
    switch ($Vid){
        case "2": // 'izpiše obvestilo in pokaže komu je bilo poslano
            echo "<table border='1' cellspacing='0'>";
            echo "<tr><th>Obvestilo</th><th>Vsebina</th><th>Rok</th><th>Objavil</th><th>Datum objave</th><th>Popravi</th><th>Briši</th></tr>";
            $SQL = "SELECT tabobvestila.*,tabucitelji.priimek,tabucitelji.ime FROM (tabobvestila ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabobvestila.objavil=tabucitelji.idUcitelj) ";
            $SQL = $SQL . " WHERE tabobvestila.id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td valign='top'>".$R["naslov"]."</td>";
                echo "<td width='400'>".str_replace("\n","<br />",$R["vsebina"])."</td>";
                echo "<td valign='top'>".$R["rok"]."</td>";
                echo "<td valign='top'>".$R["ime"]." ".$R["priimek"]."</td>";
                $Datum=$R["datum"];
                if (isDate($Datum)){
                    $Datum=new DateTime($Datum);
                    echo "<td valign='top'>".$Datum->format('d.m.Y')."</td>";
                }else{
                    echo "<td valign='top'></td>";
                }
                echo "<td valign='top'><a href='obvestila.php?id=4&zapis=".$R["ID"]."'>Popravi</a></td>";
                echo "<td valign='top'><a href='obvestila.php?id=5&zapis=".$R["ID"]."'>Briši</a></td>";
                echo "</tr>";
            }
            echo "</table><br />"; 
            
            echo "<h3>Prejemniki sporočila:</h3>";
            
            echo "<table border='1' cellspacing='0'>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Briši</th></tr>";
            
            $SQL = "SELECT tabprejemnikiobvestil.id,tabucitelji.priimek,tabucitelji.ime FROM tabprejemnikiobvestil ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabprejemnikiobvestil.idUcitelj=tabucitelji.idUcitelj ";
            $SQL = $SQL . "WHERE tabprejemnikiobvestil.idObvestilo=".$VZapis;
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td valign='top'>".$Indx."</td>";
                echo "<td valign='top'>".$R["ime"]." ".$R["priimek"]."</td>";
                echo "<td valign='top'><a href='obvestila.php?id=5a&zapis=".$R["id"]."&obvestilo=".$VZapis."'>Briši</a></td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />" ;
            break;
        case "3": //    'objava - vpis obvestila
            echo "Objavljam sporočilo:<br />";
            $naslov=$_POST["naslov"];
            $naslov=str_replace("'","",$naslov);
            $naslov=str_replace(chr(34),"",$naslov);
            $naslov=str_replace("<","",$naslov);
            $naslov=str_replace(">","",$naslov);
            $vsebina=$_POST["vsebina"];
            $vsebina=str_replace("'","",$vsebina);
            $vsebina=str_replace(chr(34),"",$vsebina);
            $vsebina=str_replace("<","",$vsebina);
            $vsebina=str_replace(">","",$vsebina);
            
            $SQL = "INSERT INTO tabobvestila (datum,naslov,vsebina,rok,objavil,cas) VALUES ('".$Danes->format('Y-m-d')."','".$naslov."','".$vsebina."','".$_POST["rok"]."',".$VUporabnikIme.",'".$Danes->format('Y-m-d H:i:s')."')";
            $result = mysqli_query($link,$SQL);
            
            $SQL = "SELECT id FROM tabobvestila ORDER BY id DESC LIMIT 0,1";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $idObvestilo=$R["id"];
            }
            
            if (is_numeric($_POST["Stevilo"])){
                for ($Indx=1;$Indx <= intval($_POST["Stevilo"]);$Indx++){
                    if (isset($_POST["em_".$Indx])){
                        $SQL = "INSERT INTO tabprejemnikiobvestil (idObvestilo,idUcitelj,status) VALUES (".$idObvestilo.",".$_POST["uc_".$Indx].",0)";
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }else{
                $SQL = "INSERT INTO tabprejemnikiobvestil (idObvestilo,idUcitelj,status) VALUES (".$idObvestilo.",".$VUporabnikIme.",0)";
                $result = mysqli_query($link,$SQL);
                echo "<h2>Sporočilo ste objavili samo zase (označen ni bil noben prejemnik)!</h2>";
            }
            
            echo "<br />Sporočilo je objavljeno!<br />";
            break;
        case "3a": //    'popravek - vpis obvestila
            $ustrezen=false;
            $SQL = "SELECT objavil FROM tabobvestila WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($R["objavil"]==$VUporabnikIme){
                    $ustrezen=true;
                }
            }
            
            if (($VLevel > 1) or ($ustrezen)){ 
                $SQL = "DELETE FROM tabprejemnikiobvestil WHERE idObvestilo=".$VZapis;
                $result = mysqli_query($link,$SQL);
                
                $SQL = "DELETE FROM tabobvestila WHERE id=".$VZapis;
                $result = mysqli_query($link,$SQL);
                
                echo "Objavljam sporočilo (popravljeno):<br />";
                $naslov=$_POST["naslov"];
                $naslov=str_replace("'","",$naslov);
                $naslov=str_replace(chr(34),"",$naslov);
                $naslov=str_replace("<","",$naslov);
                $naslov=str_replace(">","",$naslov);
                $vsebina=$_POST["vsebina"];
                $vsebina=str_replace("'","",$vsebina);
                $vsebina=str_replace(chr(34),"",$vsebina);
                $vsebina=str_replace("<","",$vsebina);
                $vsebina=str_replace(">","",$vsebina);
                
                $SQL = "INSERT INTO tabobvestila (datum,naslov,vsebina,rok,objavil,cas) VALUES ('".$Danes->format('Y-m-d')."','".$naslov."','".$vsebina."','".$_POST["rok"]."',".$VUporabnikIme.",'".$Danes->format('Y-m-d H:i:s')."')";
                $result = mysqli_query($link,$SQL);
                
                $SQL = "SELECT id FROM tabobvestila ORDER BY id DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $idObvestilo=$R["id"];
                }
                
                if (is_numeric($_POST["Stevilo"])){
                    for ($Indx=1;$Indx <= intval($_POST["Stevilo"]);$Indx++){
                        if (isset($_POST["em_".$Indx])){
                            $SQL = "INSERT INTO tabprejemnikiobvestil (idObvestilo,idUcitelj,status) VALUES (".$idObvestilo.",".$_POST["uc_".$Indx].",0)";
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }else{
                    $SQL = "INSERT INTO tabprejemnikiobvestil (idObvestilo,idUcitelj,status) VALUES (".$idObvestilo.",".$VUporabnikIme.",0)";
                    $result = mysqli_query($link,$SQL);
                    echo "<h2>Sporočilo ste objavili samo zase (označen ni bil noben prejemnik)!</h2>";
                }
                
                echo "<br />Popravljeno sporočilo je objavljeno!<br />";
            }else{
                echo "<h2>Nimate pravic za popravljanje obvestil!</h2>";
            }
            break;
        case "4": //    'popravi obvestilo
            $SQL = "SELECT iducitelj FROM TabVodjeAktivov WHERE leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            
            for ($Indx=0;$Indx <= 30;$Indx++){
                $VVodjaAktiva[$Indx]=0;
            }
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VVodjaAktiva[$Indx]=$R["iducitelj"];
                $Indx=$Indx+1;
            }

            $SQL = "SELECT iducitelj FROM TabUcenje WHERE leto=".$VLeto." AND predmet=50";
            $result = mysqli_query($link,$SQL);
            
            for ($Indx=0;$Indx <= 50;$Indx++){
                $VRazrednik[$Indx]=0;
            }
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VRazrednik[$Indx]=$R["iducitelj"];
                $Indx=$Indx+1;
            }
            
            $SQL = "SELECT DISTINCT TabPogodbe.iducitelj,TabPogodbe.iddelo FROM TabPogodbe WHERE idDelo IN (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)";
            $result = mysqli_query($link,$SQL);
        
            for ($Indx=0;$Indx <= 200;$Indx++){
                $VUcitelj[$Indx]=0;
            }
            
            $Indx=1;
            $VUcitelj[0]=0;
            while ($R = mysqli_fetch_array($result)){
                if ($VUcitelj[$Indx-1] != $R["iducitelj"]){
                    $VUcitelj[$Indx]=$R["iducitelj"];
                }else{
                    $Indx=$Indx-1;
                }
                $Indx=$Indx+1;
            }
            
            echo "<form name='obrazec' method='post' action='obvestila.php'>";
            echo "<table border='1'>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Status</th><th>Vključi v<br />obveščanje</th></tr>";
            
            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji ";
            $SQL = $SQL . " WHERE (tabucitelji.status > 0) ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td>";
                for ($i1=1;$i1 <= 200;$i1++){
                    if ($VUcitelj[$i1]==$R["iducitelj"]){ 
                        echo "<span id='ucitelj_".$Indx."'><font color='blue'>U </font></span>";
                    }
                }
                for ($i1=1;$i1 <= 50;$i1++){
                    if ($VRazrednik[$i1]==$R["iducitelj"]){ 
                        echo "<span id='razrednik_".$Indx."'><font color='green'>R </font></span>";
                    }
                }
                for ($i1=1;$i1 <= 20;$i1++){
                    if ($VVodjaAktiva[$i1]==$R["iducitelj"]){ 
                        echo "<span id='aktiv_".$Indx."'><font color='red'>A </font></span>";
                    }
                }
                echo "</td>";
                
                $SQL = "SELECT id FROM tabprejemnikiobvestil WHERE idObvestilo=".$VZapis." AND idUcitelj=".$R["iducitelj"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td><input name='uc_".$Indx."' type='hidden' value='".$R["iducitelj"]."'><input name='em_".$Indx."' type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td><input name='uc_".$Indx."' type='hidden' value='".$R["iducitelj"]."'><input name='em_".$Indx."' type='checkbox'></td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table>";
            echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
            echo "<input name='gumbrazredniki' type='button' value='Označi razrednike' onClick='OznaciRazrednike(this)'><input name='gumbaktiv' type='button' value='Označi vodje aktivov' onClick='OznaciAktiv(this)'><input name='gumbucitelj' type='button' value='Označi učitelje' onClick='OznaciUcitelje(this)'><br />";
            echo "<br /><input name='Stevilo' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='zapis' type='hidden' value='".$VZapis."'>";
            echo "<input name='id' type='hidden' value='3a'>";
            
            $SQL = "SELECT tabobvestila.*,tabucitelji.priimek,tabucitelji.ime FROM tabobvestila ";
            $SQL = $SQL . " INNER JOIN tabucitelji ON tabobvestila.objavil=tabucitelji.idUcitelj ";
            $SQL = $SQL . " WHERE tabobvestila.id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<b>Zadeva:</b> <input name='naslov' size='40' type='text' value='".$R["naslov"]."'><br />";
                if (isDate($R["datum"])){
                    $Datum=new DateTime(isDate($R["datum"]));
                    echo "<b>Rok:</b> <input name='rok' size='10' type='text' value='".$Datum->format('d.m.Y')."'><br />";
                }else{
                    echo "<b>Rok:</b> <input name='rok' size='10' type='text' value='".$Danes->format('d.m.Y')."'><br />";
                }                    
                echo "<b>Sporočilo:</b><br /><textarea name='vsebina' rows='5' cols='60'>".$R["vsebina"]."</textarea><br />";
                echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
            }
            echo "<input name='submit' type='submit' value='Popravi'><br />";
            echo "</form>";
            break;
        case "5": //    'briši obvestilo
            $ustrezen=false;
            $SQL = "SELECT * FROM tabobvestila WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($R["objavil"]==$VUporabnikIme){
                    $ustrezen=true;
                }
            }
            
            if (($VLevel > 1) or ($ustrezen)){ 
                $SQL = "DELETE FROM tabprejemnikiobvestil WHERE idObvestilo=".$VZapis;
                $result = mysqli_query($link,$SQL);
                
                echo "<h2>Prejemniki obvestil so bili zbrisani!</h2>";
                
                $SQL = "DELETE FROM tabobvestila WHERE id=".$VZapis;
                $result = mysqli_query($link,$SQL);
                
                echo "<h2>Obvestilo je bilo zbrisano!</h2>";
            }else{
                echo "<h2>Nimate pravic za brisanje obvestil in prejemnikov obvestil!</h2>";
            }
            break;
        case "5a": //   'briši prejemnika obvestila
            $ustrezen=false;
            $SQL = "SELECT * FROM tabobvestila WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($R["objavil"]==$VUporabnikIme){
                    $ustrezen=true;
                }
            }
            
            if (($VLevel > 1) or $ustrezen){ 
                $SQL = "DELETE FROM tabprejemnikiobvestil WHERE idObvestilo=".$VZapis;
                $result = mysqli_query($link,$SQL);
                
                echo "<h2>Prejemniki obvestil so bili zbrisani!</h2>";
            }else{
                echo "<h2>Nimate pravic za brisanje prejemnikov obvestil!</h2>";
            }
            break;
        case "6": // 'še kaži
            $SQL = "UPDATE tabprejemnikiobvestil SET status=2 WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            header ("Location: prijava.php");
            break;
        case "7": // 'briši
            $SQL = "UPDATE tabprejemnikiobvestil SET status=3 WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            header ("Location: prijava.php");
            break;
        case "8": // 'izpis obvestila
            $SQL = "SELECT tabprejemnikiobvestil.id AS pid,tabobvestila.*,tabucitelji.priimek,tabucitelji.ime FROM (tabprejemnikiobvestil ";
            $SQL = $SQL . " INNER JOIN tabobvestila ON tabprejemnikiobvestil.idObvestilo=tabobvestila.id) ";
            $SQL = $SQL . " INNER JOIN tabucitelji ON tabobvestila.objavil=tabucitelji.idUcitelj ";
            $SQL = $SQL . " WHERE tabobvestila.id=".$VZapis." AND tabprejemnikiobvestil.idUcitelj=".$VUporabnikIme;
            $result = mysqli_query($link,$SQL);
            echo "<table border='1' cellspacing='0'>";
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td valign='top'>Obvestilo: ".$R["naslov"]."</td></tr>";
                echo "<tr><td valign='top'>Rok: ".$R["rok"]."</td></tr>";
                echo "<tr><td valign='top'>Objavil: ".$R["ime"]." ".$R["priimek"]."</td></tr>";
                if (isDate($R["datum"])){
                    $Datum=new DateTime(isDate($R["datum"]));
                    echo "<tr><td valign='top'>Datum objave: ".$Datum->format('d.m.Y')."</td></tr>";
                }else{
                    echo "<tr><td valign='top'>Datum objave: ".$Danes->format('d.m.Y')."</td></tr>";
                }
                echo "<tr><td width='400'>".str_replace("\n","<br />",$R["vsebina"])."</td></tr>";
                echo "<tr><td valign='top'><a href='obvestila.php?id=7&zapis=".$R["pid"]."'>Ne kaži več</a></td>";
                echo "</tr>";
            }
            echo "</table><br />";
            break;
        default:
            $SQL = "SELECT iducitelj FROM TabVodjeAktivov WHERE leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            
            for ($Indx=0;$Indx <= 30;$Indx++){
                $VVodjaAktiva[$Indx]=0;
            }
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VVodjaAktiva[$Indx]=$R["iducitelj"];
                $Indx=$Indx+1;
            }

            $SQL = "SELECT iducitelj FROM TabUcenje WHERE leto=".$VLeto." AND predmet=50";
            $result = mysqli_query($link,$SQL);
            
            for ($Indx=0;$Indx <= 50;$Indx++){
                $VRazrednik[$Indx]=0;
            }
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VRazrednik[$Indx]=$R["iducitelj"];
                $Indx=$Indx+1;
            }
            
            $SQL = "SELECT DISTINCT TabPogodbe.iducitelj,TabPogodbe.iddelo FROM TabPogodbe WHERE idDelo IN (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)";
            $result = mysqli_query($link,$SQL);
        
            for ($Indx=0;$Indx <= 200;$Indx++){
                $VUcitelj[$Indx]=0;
            }
            
            $Indx=1;
            $VUcitelj[0]=0;
            while ($R = mysqli_fetch_array($result)){
                if ($VUcitelj[$Indx-1] != $R["iducitelj"]){
                    $VUcitelj[$Indx]=$R["iducitelj"];
                }else{
                    $Indx=$Indx-1;
                }
                $Indx=$Indx+1;
            }
            
            echo "<form name='obrazec' method='post' action='obvestila.php'>";
            echo "<table border='1'>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Status</th><th>Vključi v<br />obveščanje</th></tr>";
            
            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji ";
            $SQL = $SQL . " WHERE (tabucitelji.status > 0) ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td>";
                for ($i1=1;$i1 <= 200;$i1++){
                    if ($VUcitelj[$i1]==$R["iducitelj"]){ 
                        echo "<span id='ucitelj_".$Indx."'><font color='blue'>U </font></span>";
                        break;
                    }
                }
                for ($i1=1;$i1 <= 50;$i1++){
                    if ($VRazrednik[$i1]==$R["iducitelj"]){ 
                        echo "<span id='razrednik_".$Indx."'><font color='green'>R </font></span>";
                    }
                }
                for ($i1=1;$i1 <= 20;$i1++){
                    if ($VVodjaAktiva[$i1]==$R["iducitelj"]){ 
                        echo "<span id='aktiv_".$Indx."'><font color='red'>A </font></span>";
                    }
                }
                echo "</td>";
                echo "<td><input name='uc_".$Indx."' type='hidden' value='".$R["iducitelj"]."'><input name='em_".$Indx."' type='checkbox'></td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table>";
            echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
            echo "<input name='gumbrazredniki' type='button' value='Označi razrednike' onClick='OznaciRazrednike(this)'><input name='gumbaktiv' type='button' value='Označi vodje aktivov' onClick='OznaciAktiv(this)'><input name='gumbucitelj' type='button' value='Označi učitelje' onClick='OznaciUcitelje(this)'><br />";
            echo "<br /><input name='Stevilo' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='id' type='hidden' value='3'>";
            echo "<b>Zadeva:</b> <input name='naslov' size='40' type='text'><br />";
            echo "<b>Rok:</b> <input name='rok' size='10' type='text'><br />";
            echo "<b>Sporočilo:</b><br /><textarea name='vsebina' rows='5' cols='60'></textarea><br />";
            echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
            echo "<input name='submit' type='submit' value='Objavi'><br />";
            echo "</form>";
    }

    if ($Vid != "8"){
        echo "Zadnja obvestila:<br />";
        echo "<table border='1' cellspacing='0'>";
        echo "<tr><th>Št.</th><th>Obvestilo</th><th>Vsebina</th><th>Rok</th><th>Objavil</th><th>Datum objave</th><th>Komu</th><th>Popravi</th><th>Briši iz baze</th><th>Status</th></tr>";
        if ($VLevel > 1){
            $SQL = "SELECT tabobvestila.*,tabucitelji.priimek,tabucitelji.ime FROM (tabobvestila ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabobvestila.objavil=tabucitelji.idUcitelj) ";
            $SQL = $SQL . " ORDER BY tabobvestila.id DESC LIMIT 0,100";
        }else{
            $SQL = "SELECT tabobvestila.*,tabucitelji.priimek,tabucitelji.ime,tabprejemnikiobvestil.status,tabprejemnikiobvestil.id AS pid FROM (tabobvestila ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabobvestila.objavil=tabucitelji.idUcitelj) ";
            $SQL = $SQL . "INNER JOIN tabprejemnikiobvestil ON tabobvestila.id=tabprejemnikiobvestil.idObvestilo ";
            $SQL = $SQL . "WHERE tabucitelji.idUcitelj=".$VUporabnikIme." AND tabprejemnikiobvestil.idUcitelj=".$VUporabnikIme;
            $SQL = $SQL . " ORDER BY tabobvestila.id DESC LIMIT 0,100";
        }
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align='center' valign='top'>".$Indx."</td>";
            echo "<td valign='top'>".$R["naslov"]."</td>";
            if (strlen($R["vsebina"]) > 80){
                if ($VLevel > 1){
                    echo "<td width='400'>".mb_substr($R["vsebina"],0,80,$encoding)." ... <a href='obvestila.php?id=8&zapis=".$R["ID"]."'>Več</a></td>";
                }else{
                    echo "<td width='400'>".mb_substr($R["vsebina"],0,80,$encoding)." ... <a href='obvestila.php?id=8&zapis=".$R["ID"]."'>Več</a></td>";
                }
            }else{
                echo "<td width='400'>".$R["vsebina"]."</td>";
            }
            echo "<td valign='top'>".$R["rok"]."</td>";
            echo "<td valign='top'>".$R["ime"]." ".$R["priimek"]."</td>";
            if (isDate($R["datum"])){
                $Datum=new DateTime(isDate($R["datum"]));
                echo "<td valign='top'>".$Datum->format('d.m.Y')."</td>";
            }else{
                echo "<td valign='top'></td>";
            }
            echo "<td valign='top'><a href='obvestila.php?id=2&zapis=".$R["ID"]."'>Pokaži</a></td>";
            echo "<td valign='top'><a href='obvestila.php?id=4&zapis=".$R["ID"]."'>Popravi</a></td>";
            echo "<td valign='top'><a href='obvestila.php?id=5&zapis=".$R["ID"]."'>Briši</a></td>";
            if ($VLevel < 2){
                if ($R["status"] < 3){
                    echo "<td valign='top'><a href='obvestila.php?id=7&zapis=".$R["pid"]."'>Ne kaži več</a></td>";
                }else{
                    echo "<td valign='top'><a href='obvestila.php?id=6&zapis=".$R["pid"]."'>Pokaži</a></td>";
                }
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
    }

    echo "<br />";
    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
}
?>
    <script language="JavaScript">
    function OznaciVse(form){
        for (i=1; i < form.elements.length; i++) {
            form.elements[i].checked=true;
        }
    }
    function BrisiVse(form){
        for (i=1; i < form.elements.length; i++) {
            form.elements[i].checked=false;
        }
    }
    function OznaciRazrednike(form){
        var stevilo = document.forms['obrazec']['Stevilo']
        var razrednik = document.getElementById('razrednik_1')
        
        for (i=1; i <= stevilo.value; i++) {
            razrednik = document.getElementById('razrednik_'+i); 
            if (!(razrednik==null || razrednik=="")) {
                document.forms['obrazec']['em_'+i].checked=true;
            }
        }
    }
    function OznaciAktiv(form){
        var stevilo = document.forms['obrazec']['Stevilo']
        var razrednik = document.getElementById('aktiv_1')
        
        for (i=1; i <= stevilo.value; i++) {
            razrednik = document.getElementById('aktiv_'+i); 
            if (!(razrednik==null || razrednik=="")) {
                document.forms['obrazec']['em_'+i].checked=true;
            }
        }
    }
    function OznaciUcitelje(form){
        var stevilo = document.forms['obrazec']['Stevilo']
        var razrednik = document.getElementById('ucitelj_1')
        
        for (i=1; i <= stevilo.value; i++) {
            razrednik = document.getElementById('ucitelj_'+i); 
            if (!(razrednik==null || razrednik=="")) {
                document.forms['obrazec']['em_'+i].checked=true;
            }
        }
    }
    </script>

    </body>
    </html>
