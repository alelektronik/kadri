<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis učitelja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
        
switch ($Vid){
    case "1":
        $VRazred = $_POST["razred"];
        $VParalelka = $_POST["paralelka"];
        $VDevetletka = $_POST["devetletka"];
        $_SESSION["razred"]=$VRazred;
        $_SESSION["paralelka"]=$VParalelka;
        $_SESSION["devetletka"]=$VDevetletka;

        $StPredmetov=$_POST["StPredmetov"];

        for ($Indx=0;$Indx <= $StPredmetov;$Indx++){
            $Predmeti[$Indx][0]=$_POST["predmet".$Indx];
            $Predmeti[$Indx][1]=$_POST["razred".$Indx];
            $Predmeti[$Indx][2]=$_POST["paralelka".$Indx];
            $Realizacija[$Indx][0]=$_POST["PlanPol".$Indx];
            $Realizacija[$Indx][0]=str_replace(",",".",$Realizacija[$Indx][0]);
            $Realizacija[$Indx][1]=$_POST["RealizacijaPol".$Indx];
            $Realizacija[$Indx][1]=str_replace(",",".",$Realizacija[$Indx][1]);
            $Realizacija[$Indx][2]=$_POST["Plan".$Indx];
            $Realizacija[$Indx][2]=str_replace(",",".",$Realizacija[$Indx][2]);
            $Realizacija[$Indx][3]=$_POST["Realizacija".$Indx];
            $Realizacija[$Indx][3]=str_replace(",",".",$Realizacija[$Indx][3]);
            $Realizacija[$Indx][4]=$_POST["PlanNL".$Indx];
            $Realizacija[$Indx][4]=str_replace(",",".",$Realizacija[$Indx][4]);
            $Realizacija[$Indx][5]=$_POST["RealizacijaNL".$Indx];
            $Realizacija[$Indx][5]=str_replace(",",".",$Realizacija[$Indx][5]);
            $Realizacija[$Indx][6]=$_POST["referenca".$Indx];
            $Realizacija[$Indx][7]=$_POST["ucenje".$Indx];
            $Realizacija[$Indx][9]=$_POST["Plan3_".$Indx];
            $Realizacija[$Indx][9]=str_replace(",",".",$Realizacija[$Indx][9]);
            $Realizacija[$Indx][10]=$_POST["Realizacija3_".$Indx];
            if (is_numeric($Realizacija[$Indx][10])){
                $Realizacija[$Indx][10]=str_replace(",",".",$Realizacija[$Indx][10]);
            }else{
                $Realizacija[$Indx][10]=0;
            }
        }

        //'Izpis predmetnih podatkov

        $SQL = "SELECT TabRazred.idUcitelj,tabrazdat.* FROM TabRazred INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id WHERE idRazred=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $Ucitelj=$R["idUcitelj"];
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
            $VLeto=$R["leto"];
        }

        for ($Indx1=0;$Indx1 <= $StPredmetov;$Indx1++){
            if ($Predmeti[$Indx1][0] > 0){
                if ($Predmeti[$Indx1][2] != ""){
                    $SQL = "SELECT * FROM TabRealizacija WHERE ucenje=".$Realizacija[$Indx1][7];
                    $result = mysqli_query($link,$SQL);
                
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE TabRealizacija SET PlanNL=".$Realizacija[$Indx1][4].",RealizacijaNL=".$Realizacija[$Indx1][5];
                        $SQL = $SQL .",PlanPol=".$Realizacija[$Indx1][0].",RealizacijaPol=".$Realizacija[$Indx1][1];
                        $SQL = $SQL .",Plan3=".$Realizacija[$Indx1][9].",Realizacija3=".$Realizacija[$Indx1][10];
                        $SQL = $SQL .",Plan=".$Realizacija[$Indx1][2].",Realizacija=".$Realizacija[$Indx1][3];
                        $SQL = $SQL .", razred=".$Predmeti[$Indx1][1];
                        $SQL = $SQL .", paralelka='".$Predmeti[$Indx1][2]."'";
                        $SQL = $SQL .", idRazred=".$VRazred;
                        $SQL = $SQL .",referenca=".$Realizacija[$Indx1][6].",ucenje=".$Realizacija[$Indx1][7].",Vpisal='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["Id"];
                        $result1 = mysqli_query($link,$SQL);
                    }else{
                        $SQL = "INSERT INTO TabRealizacija (Leto,Predmet,PlanNL,RealizacijaNL,PlanPol,RealizacijaPol,Plan3,Realizacija3,Plan,Realizacija,Razred,Paralelka,Vpisal,Datum,referenca,ucenje,idRazred) ";
                        $SQL = $SQL . "values (" . $VLeto . "," . $Predmeti[$Indx1][0] . "," . $Realizacija[$Indx1][4] . "," . $Realizacija[$Indx1][5] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][0] . "," . $Realizacija[$Indx1][1] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][9] . "," . $Realizacija[$Indx1][10] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][2] . "," . $Realizacija[$Indx1][3] . "," ;
                        $SQL = $SQL . $Predmeti[$Indx1][1] . ",'" . $Predmeti[$Indx1][2] . "','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "',".$Realizacija[$Indx1][6].",".$Realizacija[$Indx1][7].",".$VRazred.")";
                        $result1 = mysqli_query($link,$SQL);
                    }
                }else{
                    $SQL = "SELECT * FROM TabRealizacija WHERE ucenje=".$Realizacija[$Indx1][7];
                    $result = mysqli_query($link,$SQL);
                
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE TabRealizacija SET PlanNL=".$Realizacija[$Indx1][4].",RealizacijaNL=".$Realizacija[$Indx1][5];
                        $SQL = $SQL .",PlanPol=".$Realizacija[$Indx1][0].",RealizacijaPol=".$Realizacija[$Indx1][1];
                        $SQL = $SQL .",Plan3=".$Realizacija[$Indx1][9].",Realizacija3=".$Realizacija[$Indx1][10];
                        $SQL = $SQL .",Plan=".$Realizacija[$Indx1][2].",Realizacija=".$Realizacija[$Indx1][3];
                        $SQL = $SQL .", razred=".$Predmeti[$Indx1][1];
                        $SQL = $SQL .",referenca=".$Realizacija[$Indx1][6].",ucenje=".$Realizacija[$Indx1][7].",Vpisal='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["Id"];
                        $result1 = mysqli_query($link,$SQL);
                    }else{
                        $SQL = "INSERT INTO TabRealizacija (Leto,Predmet,PlanNL,RealizacijaNL,PlanPol,RealizacijaPol,Plan3,Realizacija3,Plan,Realizacija,Razred,Paralelka,Vpisal,Datum,referenca,ucenje,idRazred) ";
                        $SQL = $SQL . "values (" . $VLeto . "," . $Predmeti[$Indx1][0] . "," . $Realizacija[$Indx1][4] . "," . $Realizacija[$Indx1][5] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][0] . "," . $Realizacija[$Indx1][1] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][9] . "," . $Realizacija[$Indx1][10] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][2] . "," . $Realizacija[$Indx1][3] . "," ;
                        $SQL = $SQL . $Predmeti[$Indx1][1] . ",'" . $Predmeti[$Indx1][2] . "','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "',".$Realizacija[$Indx1][6].",".$Realizacija[$Indx1][7].",0)";
                        $result1 = mysqli_query($link,$SQL);
                    }
                }
            }
        }

        if ($Opravila==1){
            $SQL = "SELECT tabdeldogodek.id FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Realizacija' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["id"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('d.m.Y')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
}

if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred = $_GET["razred"];
    }else{
        $VRazred = 0;
    }
}
        
$VDevetletka=9;
$_SESSION["leto"] = $VLeto;
echo "<br />";

$SQL = "SELECT TabRazred.idUcenec,TabRazred.idUcitelj,TabRazred.idVzgojitelj, tabrazdat.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, TabVzgojitelji.Priimek AS vpriimek, TabVzgojitelji.Ime AS vime, TabUcenci.priimek,TabUcenci.ime,TabUcenci.DatRoj FROM ";
$SQL = $SQL . "((TabVzgojitelji INNER JOIN (TabRazred INNER JOIN tabucitelji ON TabRazred.idUcitelj=tabucitelji.idUcitelj) ON TabVzgojitelji.idUcitelj=TabRazred.IdVzgojitelj) ";
$SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.IdUcenec=TabUcenci.IdUcenec) ";
$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
$SQL = $SQL . "WHERE idRazred=" . $VRazred ;
$SQL = $SQL ." ORDER BY TabUcenci.Priimek, TabUcenci.Ime";
$result = mysqli_query($link,$SQL);

if ($R = mysqli_fetch_array($result)){
	$VRazred1=$R["razred"];
	$VParalelka=$R["oznaka"];
	$VLeto=$R["leto"];
	echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
	$Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
	$idUcitelj=$R["idUcitelj"];
	$Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
	$IdVzgojitelj=$R["idVzgojitelj"];

	echo "Učitelj: " . $Ucitelj . "<br />";
	if ($R["razred"]==1){
		echo "Drugi učitelj: " . $Vzgojitelj . "<br />";
	}else{
		echo "Učitelj OPB: " . $Vzgojitelj . "<br />";
	}
}

/* Ucenci(30,3)
'0-idUcenec, 1-Priimek in ime, 2-razred, 3-datum rojstva
*/

$result = mysqli_query($link,$SQL);
$Indx=0;
while ($R = mysqli_fetch_array($result)){
	$ucenci[$Indx][0]=$R["idUcenec"];
	$ucenci[$Indx][1]=$R["priimek"].", ".$R["ime"];
	$ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
	$ucenci[$Indx][3]=$R["DatRoj"];
	$Indx=$Indx+1;
}
$StUcencev=$Indx;

$_SESSION["leto"]=$VLeto;
$_SESSION["razred"]=$VRazred;
$_SESSION["paralelka"]=$VParalelka;
$_SESSION["devetletka"]=$VDevetletka;
$_SESSION["ucitelj"]=$idUcitelj;
$_SESSION["vzgojitelj"]=$IdVzgojitelj;

if ($VLevel > 1){
    $SQL = "SELECT tabrazdat.* FROM TabRazred INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id WHERE tabrazdat.id=".$VRazred;
    $result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
        $VidRazred1=$R["razred"];
        $VidRazred=$R["id"];
        $VidParalelka=$R["oznaka"];
    }else{
        $VidRazred1=1;
        $VidRazred=0;
        $VidParalelka="A";
    }

    echo "<form accept-charset='utf-8' name='rezultati' method='post' action='VnosRealizacije.php'>";
    echo "<h2>Izberite razred za vnos realizacije</h2><br />";
    echo "<table border=0>";
    echo "<tr>";
    echo "<td>";
    echo "Šolsko leto: </td><td>".  $VLeto  . "/"  . ($VLeto+1) . "</td>";
    echo "</tr>";
    echo "<input name='vrstaos' type='hidden' value='9'>";

    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
    $result = mysqli_query($link,$SQL);

    echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
    while ($R = mysqli_fetch_array($result)){
        if ($VLevel > 1){
            if ($VidRazred == $R["id"]){
                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }
        }
    }
    echo "</select>";
    echo "</td>";
    echo "</tr>";
    echo "</table>";
    //echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";
}

//Predmeti(100,7)
//'predmeti: 0-idpredmet,1-oznaka predmeta

$SQL = "SELECT tabpredmeti.Opis,tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,tabucenje.*,tabucitelji.priimek,tabucitelji.ime FROM ";
$SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.idUcitelj=tabucitelji.idUcitelj ";
$SQL = $SQL . "WHERE Razred=".$VRazred1." AND (paralelka='".$VParalelka."' OR paralelka='".mb_strtoupper($VParalelka,$encoding)."' OR paralelka='".mb_strtolower($VParalelka,$encoding)."' OR paralelka='') AND tabucenje.leto=".$VLeto." AND Prioriteta < 4 ORDER BY tabpredmeti.VrstniRed";
$result = mysqli_query($link,$SQL);

$StPredmetov=0;
while ($R = mysqli_fetch_array($result)){
	$Predmeti[$StPredmetov][0]=$R["Id"];
	$Predmeti[$StPredmetov][1]=$R["Oznaka"]." - ".$R["Opis"]." / ".$R["priimek"]." ".$R["ime"]." (".$R["Id"].")";
	$Predmeti[$StPredmetov][2]=$R["IdUcitelj"];
	$Predmeti[$StPredmetov][3]=$R["Predmet"];
	$Predmeti[$StPredmetov][4]=$R["Id"];
	$Predmeti[$StPredmetov][5]=$R["Id"];
	$Predmeti[$StPredmetov][6]=$R["Razred"];
	$Predmeti[$StPredmetov][7]=$R["Paralelka"];
	$StPredmetov=$StPredmetov+1;
}

//Realizacija(100,10)
//'3/plan,3/realizirano,NL/plan, NL/realizirano, polletje/plan, polletje/realizirano, leto/plan, leto/realizirano, učitelj

echo "<h2><a href='PorociloRazrednikaPregled.php?razred=".$VRazred.".paralelka=".$VParalelka."'>Ogled pedagoškega poročila</a></h2>";
echo "<br /><a href='VnosPosebniDnevi.php'>Vnos kulturnih, naravoslovnih, tehniških in športnih dni</a>";

echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='VnosRealizacije.php'>";
    echo "<input name='id' type='hidden' value='1'>";
	echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
	echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
	echo "<input name='level' type='hidden' value='".$VLevel."'>";
	echo "<input name='razred' type='hidden' value='".$VRazred."'>";
	echo "<input name='paralelka' type='hidden' value='".$VParalelka."'>";
	echo "<input name='devetletka' type='hidden' value='".$VDevetletka."'>";

echo "<table border=1 cellspacing=0>";
echo "<th>Predmet</th><th>Kol.leto<br />Plan</th><th>Kol.leto<br />Realizirano</th><th>Kol.leto<br />%</th><th>Polletje<br />Plan</th><th>Polletje<br />Realizirano</th><th>Polletje<br />%</th><th>25. teden<br />Plan</th><th>25. teden<br />Realizirano</th><th>25. teden<br />%</th><th>Leto<br />Plan</th><th>Leto<br />Realizirano</th><th>Leto<br />%</th>";

for ($ip=0;$ip <= $StPredmetov-1;$ip++){
	echo "<tr><td><input name=predmet".$ip." type=hidden value=".$Predmeti[$ip][3].">".$Predmeti[$ip][1]."</td>";
	$Realizacija[$ip][0]="0";
	$Realizacija[$ip][1]="0";
	$Realizacija[$ip][2]="0";
	$Realizacija[$ip][3]="0";
	$Realizacija[$ip][4]="0";
	$Realizacija[$ip][5]="0";
	$Realizacija[$ip][6]="0";
	$Realizacija[$ip][9]="0";
	$Realizacija[$ip][10]=0;
	$Realizacija[$ip][7]=$Predmeti[$ip][5];

	$SQL = "SELECT * FROM tabucenje WHERE id=".$Predmeti[$ip][0];
	$result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		$Realizacija[$ip][0]=$R["Planirano"]*18; //	'polletje
		$Realizacija[$ip][4]=$R["Planirano"]*14; //	'NL
		if ($VRazred1 < 9){
			$Realizacija[$ip][2]=$R["Planirano"]*35; //	'letna
		}else{
			$Realizacija[$ip][2]=$R["Planirano"]*32; 
		}
		$Realizacija[$ip][6]=$R["IdUcitelj"];
		$Realizacija[$ip][9]=$R["Planirano"]*25; //	'3
	}
	
	$SQL = "SELECT  * FROM TabRealizacija WHERE ucenje=".$Predmeti[$ip][5];
	$result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
		$Realizacija[$ip][0]=$R["PlanPol"];
		$Realizacija[$ip][1]=$R["RealizacijaPol"];
		$Realizacija[$ip][2]=$R["Plan"];
		$Realizacija[$ip][3]=$R["Realizacija"];
 		$Realizacija[$ip][4]=$R["PlanNL"];
		$Realizacija[$ip][5]=$R["RealizacijaNL"];
		if (!is_numeric($R["Ucenje"])){
			$Realizacija[$ip][7]=$Predmeti[$ip][5];
		}else{
			$Realizacija[$ip][7]=$R["Ucenje"];
		}
		if (is_numeric($R["Plan3"])){
			$Realizacija[$ip][9]=$R["Plan3"];
		}
		$Realizacija[$ip][10]=$R["Realizacija3"];
	}

	echo "<td><input name='PlanNL".$ip."' type='text' value='".$Realizacija[$ip][4]."' size='5'></td><td><input name='RealizacijaNL".$ip."' type='text' value='".$Realizacija[$ip][5]."' size='5'></td>";
	if ($Realizacija[$ip][4] > 0){
		echo "<td>".number_format(($Realizacija[$ip][5]/$Realizacija[$ip][4])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='PlanPol".$ip."' type='text' value='".$Realizacija[$ip][0]."' size='5'></td><td><input name='RealizacijaPol".$ip."' type='text' value='".$Realizacija[$ip][1]."' size='5'></td>";
	if ($Realizacija[$ip][0] > 0){
		echo "<td>".number_format(($Realizacija[$ip][1]/$Realizacija[$ip][0])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='Plan3_".$ip."' type='text' value='".$Realizacija[$ip][9]."' size='5'></td><td><input name='Realizacija3_".$ip."' type='text' value='".$Realizacija[$ip][10]."' size='5'></td>";
	if (($Realizacija[$ip][9] > 0) && ($Realizacija[$ip][10] >= 0)){
		echo "<td>".number_format(($Realizacija[$ip][10]/$Realizacija[$ip][9])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='Plan".$ip."' type='text' value='".$Realizacija[$ip][2]."' size='5'></td><td><input name='Realizacija".$ip."' type='text' value='".$Realizacija[$ip][3]."' size='5'>";
	echo "<input name='razred".$ip."' type='hidden' value='".$Predmeti[$ip][6]."'>";
	echo "<input name='paralelka".$ip."' type='hidden' value='".$Predmeti[$ip][7]."'>";
	echo "<input name='referenca".$ip."' type='hidden' value='".$Realizacija[$ip][6]."'>";
	echo "<input name='ucenje".$ip."' type='hidden' value='".$Realizacija[$ip][7]."'>";
	echo "</td>";
	if ($Realizacija[$ip][2] > 0){
		echo "<td>".number_format(($Realizacija[$ip][3]/$Realizacija[$ip][2])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	
	echo "</tr>";
	
}

echo "</table>";
echo "<input name='StPredmetov' type='hidden' value='".($StPredmetov-1)."'>";
echo "<input name='submit' type='submit' value='Pošlji realizacijo'>";
echo "</form>";

$SQL = "SELECT TabOstaleDej.*, tabrazdat.*, TabAktivnosti.*,tabrazdat.Leto AS rleto,tabrazdat.Razred AS rrazred,TabOstaleDej.Id AS oid FROM ";
$SQL = $SQL . "(TabOstaleDej INNER JOIN TabAktivnosti ON TabOstaleDej.IdAktivnost=TabAktivnosti.IdAktivnost) ";
$SQL = $SQL . "INNER JOIN tabrazdat ON TabOstaleDej.idRazred=tabrazdat.id ";
$SQL = $SQL . "WHERE idRazred=".$VRazred;
$SQL = $SQL . " ORDER BY TabAktivnosti.IdAktivnost";
$result = mysqli_query($link,$SQL);

echo "<br />Ostale dejavnosti:<br />";
echo "<table border=1 cellspacing=0>";
echo "<th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Opis</th><th>Kraj</th><th>Datum</th><th>Trajanje</th><th>Vodja</th><th>Briši</th>";

$Indx=0;
while ($R = mysqli_fetch_array($result)){
	echo "<tr>";
	echo "<td>".$R["rleto"]."/".($R["rleto"]+1)."</td>";
	echo "<td>".$R["rrazred"].". ".$R["oznaka"]."</td>";
	echo "<td>".$R["Opis"]."</td>";
	echo "<td>".$R["Vsebina"]."</td>";
	echo "<td>".$R["Kraj"]."</td>";
	echo "<td>".$R["Datum"]."</td>";
	echo "<td>".$R["Trajanje"]."</td>";
	echo "<td>".$R["Vodja"]."</td>";
	echo "<td><a href='posebnidnevi.php?id=8&zapis=".$R["oid"]."'>B</a></td>";
	echo "</tr>";
	$Indx = $Indx+1;
}
	
echo "</table>";
echo "<br /><a href='posebnidnevi.php?id=1&razred=$VRazred'>Vnos kulturnih, naravoslovnih, tehniških in športnih dni</a><br /><br />";
echo "<a href='PedPorocilo.php'>Vnos polletnega in končnega poročila razrednika</a><br />";
if ($VLevel > 1){
	echo "<a href='PorociloRazrednikaPregled.php?razred=".$VRazred."&leto=".$VLeto."'>Pregled poročil razrednikov</a><br />";
}

?>

</body>
</html>
