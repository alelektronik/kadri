<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Urnik
</title>
    <script>
     function potrditevNadomescanja(str)
     {
     var person = prompt("Vnesite vašo kodo", "");
     //if (person != null) {
     //   document.getElementById("demo").innerHTML =
     //   "Hello " + person + "! How are you today?";
     //}
     if (str=="")
       {
       //document.getElementById("txtHint").innerHTML="";
       return;
       } 
     if (window.XMLHttpRequest)
       {// code for IE7+, Firefox, Chrome, Opera, Safari
       xmlhttp=new XMLHttpRequest();
       }
     else
       {// code for IE6, IE5
       xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
       }
     xmlhttp.onreadystatechange=function()
       {
       if (xmlhttp.readyState==4 && xmlhttp.status==200)
         {
         document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
         }
       }
     xmlhttp.open("GET","potrdinadom.php?nadom="+str+"&uporabnik="+person,true);
     xmlhttp.send();
     }
     </script>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
$VSolskoLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Pripravljalec=$R["Ime"]  . " " . $R["Priimek"];

//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

//if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
//    header("Location: nepooblascen.htm");
//}
if (isset($_POST["id"])){
    $Obdelava=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Obdelava=$_GET["id"];
        if (!isset($_GET["mesec"])){
            $VLeto=$Danes->format('Y');
        }
    }else{
        $Obdelava="";
        $VLeto=$Danes->format('Y');
    }
}

$PoUciteljih=1;

if (isset($_POST["mesec"])) {
    $VMesec=$_POST["mesec"];
}else{
    if (isset($_GET["mesec"])){
        $VMesec=$_GET["mesec"];
    }else{
        $VMesec=$Danes->format('n');
    }
}
if (isset($_POST["dan"])) {
    $VDan=$_POST["dan"];
}else{
    if (isset($_GET["dan"])){
        $VDan=$_GET["dan"];
    }else{
        $VDan=$Danes->format('j');
    }
}

$DanObracuna=$VLeto."-".$VMesec."-".$VDan;
if (!isDate($DanObracuna)){
    $DanObracuna=new DateTime(now);
    $VLeto=$DanObracuna->format('Y');
    $VMesec=$DanObracuna->format('n');
    $VDan=$DanObracuna->format('j');
}else{
    $DanObracuna=new DateTime($DanObracuna);
}

$SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $ucitelj[$Indx][0]=$R["IdUcitelj"];
    $ucitelj[$Indx][1]=$R["Priimek"]." ".$R["Ime"];
    $ucitelj[$Indx][2]=true;
    $Indx=$Indx+1;
}
$ucitelj[$Indx][0]=-1;
$ucitelj[$Indx][1]="Anglisti";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=-2;
$ucitelj[$Indx][1]="Slavisti";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=-3;
$ucitelj[$Indx][1]="Matematiki";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=0;
$ucitelj[$Indx][1]="Ni izbran";
$ucitelj[$Indx][2]=false;
$StUciteljev=$Indx;

if ($VMesec > 8){
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
}else{
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".($VLeto-1)." ORDER BY razred,oznaka";
}    
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $razred[$Indx][0]=$R["razred"].". ".$R["oznaka"];
    $razred[$Indx][1]=$R["id"];
    $Indx=$Indx+1;
}
$StRazredov=$Indx-1;

$SQL = "SELECT * FROM tabprostor";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Prostor[$Indx][0]=$R["IdProstor"];
    $Prostor[$Indx][1]=$R["Opis"];
    $Prostor[$Indx][2]=true;
    $VProstor[$R["IdProstor"]][0] = $R["IdProstor"];
    $VProstor[$R["IdProstor"]][1] = $R["Stevilka"];
    $VProstor[$R["IdProstor"]][2] = $R["Oznaka"];
    $VProstor[$R["IdProstor"]][3] = $R["Opis"];
    $Indx=$Indx+1;
}
$Prostor[$Indx][0]=-1;
$Prostor[$Indx][1]="Isti prostor";
$Prostor[$Indx][2]=false;
$StProstorov=$Indx;
$VStProstorov=$Indx-1;

$SQL = "SELECT * FROM tabpredmeti ORDER BY oznaka";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Predmet[$Indx][0]=$R["Id"];
    $Predmet[$Indx][1]=$R["Oznaka"];
    $Indx=$Indx+1;
}
$StPredmetov=$Indx-1;

$SQL = "SELECT * FROM TabNadomOblika";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Nadomescanje[$Indx][0]=$R["id"];
    $Nadomescanje[$Indx][1]=$R["nadomescanje"];
    $Indx=$Indx+1;
}
$StNadomescanj=$Indx-1;

switch ($Obdelava){
    case "2":
    case "4":
    case "5":
    case "10":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

switch ($Obdelava){
    case "1": // 'vnos nadomeščanja
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        echo "<h2>Nadomeščanja</h2>";
        echo "<form accept-charset='utf-8' name='datum' method=post action='VnosNadomescanje.php'>";
        echo "Dan <select name='dan'>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            if ($Indx==$VDan){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Mesec <select name='mesec'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            if ($Indx==$VMesec ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Leto <select name='leto'>";
        for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
            if ($Indx==$VLeto ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo "<input name='id' type='hidden' value='1'>";
        echo "<input name='submit' type='submit' value='Upoštevaj ta datum'>";
        echo "</form><br />";
        
        echo "<h2>Vpis odsotnosti</h2>";
        if (isset($_GET["PoUciteljih"])){
            if ($_GET["PoUciteljih"]=="1" ){
                $PoUciteljih=true;
            }
            if ($_GET["PoUciteljih"]=="0" ){
                $PoUciteljih=false;
            }
        }else{
            $PoUciteljih=true;
        }

        echo "<form accept-charset='utf-8' name='odsotnost' method=post action='VnosNadomescanje.php'>";
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Učitelj</th>";
        echo "<th>Razred</th>";
        echo "<th>Prostor</th>";
        echo "</tr>";
        
        echo "<tr>";
        echo "<td>&nbsp</td>";
        echo "<td>";
        echo "<select name='odsotniuc' multiple>";
        echo "<option value='0' selected='selected'>Ni izbran</option>";
        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
            echo "<option value='".$ucitelj[$Indx][0]."'>".$ucitelj[$Indx][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='odsotnirazr'>";
        echo "<option value='0' selected='selected'>Ni izbran</option>";
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            echo "<option value='".$razred[$Indx][0]."'>".$razred[$Indx][0]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='zasedenprostor'>";
        echo "<option value='0' selected='selected'>Ni izbran</option>";
        for ($Indx=1;$Indx <= $StProstorov;$Indx++){
            echo "<option value='".$Prostor[$Indx][0]."'>".$Prostor[$Indx][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td><input name='id' type='hidden' value='10'>";
        echo "<input name='leto' type='hidden' value='".$VLeto."'>";
        echo "<input name='mesec' type='hidden' value='".$VMesec."'>";
        echo "<input name='dan' type='hidden' value='".$VDan."'>";
        echo "<input name='submit' type='submit' value='Pošlji'></td>";
        echo "</tr>";
        echo "</table><br />";
        echo "Za izbor več učiteljev in razredov uporabi tipko Ctrl istočasno z levim miškinim klikom.<br />";
        echo "</form>";
        
        echo "<h2>Vpis nadomeščanj</h2>";
        $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.*,tabpredmeti.*,TabNadomescanja.id AS nid FROM ";
        $SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
        if ($PoUciteljih ){
            $SQL = $SQL . " ORDER BY ucitelj1,ura,razred,paralelka";
        }else{
            $SQL = $SQL . " ORDER BY razred,paralelka,ura,ucitelj1";
        }
        $result = mysqli_query($link,$SQL);

        echo "<form accept-charset='utf-8' name='nadomescanje' method=post action='VnosNadomescanje.php'>";
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Datum</th>";
        if ($PoUciteljih ){
            echo "<th>Razred</th>";
        }else{
            echo "<th><a href='VnosNadomescanje.php?id=1&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=0'>Razred</a></th>";
        }

        echo "<th>Ura</th>";
        echo "<th>Predmet</th>";
        echo "<th>Prostor</th>";
        if ($PoUciteljih ){
            echo "<th width='150'>Odsotni učitelj</th>";
        }else{
            echo "<th width='150'><a href='VnosNadomescanje.php?id=1&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=1'>Odsotni učitelj</a></th>";
        }
        echo "<th>Nadomestni učitelj</th>";
        echo "<th>Nadomestni prostor</th>";
        echo "<th>Dejavnost</th>";
        echo "<th>Popravi</th>";
        echo "<th>Briši</th>";
        echo "</tr>";

        $color=false;
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($color ){
                echo "<tr bgcolor='white'>";
                $color=false;
            }else{
                echo "<tr bgcolor='lightgray'>";
                $color=true;
            }
            echo "<td align=center>".$Indx."</td>";
            if (isDate($R["datumNad"])){
                $DatumNad=new DateTime(isDate($R["datumNad"]));
            }else{
                $DatumNad=new DateTime(now);
            }
            echo "<td>".$DatumNad->format('j.n.Y')."</td>";
            echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
            echo "<td align=center>".$R["ura"]."</td>";
            echo "<td>".$R["Oznaka"]."</td>";
            $NiRubrike=true;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    $NiRubrike=false;
                    break;
                }
            }
            if ($NiRubrike ){
                echo "<td>".$R["prostor1"]."</td>";
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    break;
                }
            }
            echo "<td>".$R["nadomescanje"]."</td>";
            echo "<td><a href='VnosNadomescanje.php?id=3&zapis=".$R["nid"]."&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=".$PoUciteljih."'>Popravi</a></td>";
            echo "<td><a href='VnosNadomescanje.php?id=4&zapis=".$R["nid"]."&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=".$PoUciteljih."'>Briši</a></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }

        echo "<tr>";
        echo "<td></td>";
        echo "<td><input name='datum' type='hidden' value='".$DanObracuna->format('d.m.Y')."'>".$DanObracuna->format('d.m.Y')."</td>";
        echo "<td>";
        echo "<select name='razred'>";
        for ($i1=1;$i1 <= $StRazredov;$i1++){
            echo "<option value='".$razred[$i1][1]."'>".$razred[$i1][0]."</option>";
        }
        echo "<option value='0'>0</option>";
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='ura'>";
        for ($i1=0;$i1 <= 11;$i1++){
            echo "<option value='".$i1."'>".$i1."</option>";
        }
        echo "</select>";
        echo"</td>";
        echo "<td>";
        echo "<select name='predmet'>";
        echo "<option value='0'>&nbsp;</option>";
        for ($i1=1;$i1 <= $StPredmetov;$i1++){
            echo "<option value='".$Predmet[$i1][0]."'>".$Predmet[$i1][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='prostor1'>";
        echo "<option value='0'>&nbsp;</option>";
        for ($i1=1;$i1 <= $StProstorov;$i1++){
            echo "<option value='".$Prostor[$i1][0]."'>".$Prostor[$i1][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='ucitelj1'>";
        echo "<option value='0'>&nbsp;</option>";
        for ($i1=1;$i1 <= $StUciteljev;$i1++){
            echo "<option value='".$ucitelj[$i1][0]."'>".$ucitelj[$i1][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='ucitelj2'>";
        echo "<option value='0'>&nbsp;</option>";
        for ($i1=1;$i1 <= $StUciteljev;$i1++){
            echo "<option value='".$ucitelj[$i1][0]."'>".$ucitelj[$i1][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='prostor2'>";
        echo "<option value='0'>&nbsp;</option>";
        for ($i1=1;$i1 <= $StProstorov;$i1++){
            if ($i1==$StProstorov ){
                echo "<option value='".$Prostor[$i1][0]."' selected>".$Prostor[$i1][1]."</option>";
            }else{
                echo "<option value='".$Prostor[$i1][0]."'>".$Prostor[$i1][1]."</option>";
            }
        }
        echo "</select>";
        echo "</td>";
        echo "<td>";
        echo "<select name='oblika'>";
        for ($i1=1;$i1 <= $StNadomescanj;$i1++){
            echo "<option value='".$Nadomescanje[$i1][0]."'>".$Nadomescanje[$i1][1]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "</table><br />";
        echo "<input name='id' type='hidden' value='2'>";
        echo "<input name='PoUciteljih' type='hidden' value='".$PoUciteljih."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        break;
    case "2": // 'vpis
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $SQL = "SELECT * FROM TabNadomescanja WHERE datumNad ='".$_POST["datum"]."' AND idRazred=".$_POST["razred"]." AND ura=".$_POST["ura"]." AND predmet=".$_POST["predmet"]." AND ucitelj1=".$_POST["ucitelj1"];
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VProstor1=$_POST["prostor2"];
            if ($VProstor1=="-1" ){
                $VProstor1=$_POST["prostor1"];
            }
            $SQL = "UPDATE TabNadomescanje SET ucitelj2=".$_POST["ucitelj2"].",prostor2=".$VProstor1.",oblika=".$_POST["oblika"].",vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
        }else{
            $SQL = "SELECT * FROM tabrazdat WHERE id=".$_POST["razred"];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
                $VRazred=$R["id"];
            }
            if ($_POST["razred"] == "0" ){
                $VRazred1=0;
                $VParalelka="";
                $VRazred=0;
            }
            $VProstor1=$_POST["prostor2"];
            if ($VProstor1=="-1" ){
                $VProstor1=$_POST["prostor1"];
            }
            $SQL = "INSERT INTO TabNadomescanja (";
            $SQL = $SQL ."leto,datumNad,razred,paralelka,predmet,ura,ucitelj1,prostor1,ucitelj2,prostor2,oblika,vpisal,cas,idRazred,iduntis,potrjeno";
            $SQL = $SQL .") VALUES (";
            if (isDate($_POST["datum"])){
                $Datum=new DateTime(isDate($_POST["datum"]));
            }else{
                $Datum=new DateTime(now);
            }
            $SQL = $SQL .$Datum->format('Y').",'".$Datum->format('d.m.Y')."',".$VRazred1.",'".$VParalelka."',".$_POST["predmet"].",".$_POST["ura"].",".$_POST["ucitelj1"].",".$_POST["prostor1"].",".$_POST["ucitelj2"].",".$VProstor1.",".$_POST["oblika"].",'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VRazred;
            $SQL = $SQL .",0,false)";
        }
        if (!($result = mysqli_query($link,$SQL))){
            die("Napaka pri vpisu!<br />$SQL <br />");
        }

        header("Location: VnosNadomescanje.php?id=1&leto=".$Datum->format('Y')."&mesec=".$Datum-format('n')."&dan=".$Datum-format('j')."&PoUciteljih=".$_POST["PoUciteljih"]);
        break;
    case "3": // 'popravi
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $SQL = "SELECT datumnad,ura FROM TabNadomescanja WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $DanObracuna=new DateTime(isDate($R["datumnad"]));
            $UraOdpade=$R["ura"];
            if ($DanObracuna->format('n') > 8 ){
                $VLetoUrnik=$VLeto;
            }else{
                $VLetoUrnik=$VLeto-1;
            }
            
            $SQL="SELECT razred,paralelka,predmet,ura,idrazred FROM TabNadomescanja WHERE datumNad='".$DanObracuna->format('d.m.Y')."' AND ucitelj1=0 AND ura=".$UraOdpade;
            $result = mysqli_query($link,$SQL);
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $RazredOdpade[$Indx][1]=$R["razred"];
                $RazredOdpade[$Indx][2]=$R["paralelka"];
                $RazredOdpade[$Indx][3]=$DanObracuna->format('w');
                $RazredOdpade[$Indx][4]=$R["predmet"];
                $RazredOdpade[$Indx][5]=$R["ura"];
                $RazredOdpade[$Indx][7]=$R["idrazred"];
                $Indx=$Indx+1;
            }
            $StRazredOdpade=$Indx-1;
            
            for ($Indx=1;$Indx <= $StRazredOdpade;$Indx++){
                $SQL = "SELECT ucitelj FROM taburnik WHERE leto=".$VLetoUrnik." AND DanVTednu=".$RazredOdpade[$Indx][3]." AND ura=".$RazredOdpade[$Indx][5]." AND razred=".$RazredOdpade[$Indx][1]." AND paralelka='".$RazredOdpade[$Indx][2]."' AND predmet=".$RazredOdpade[$Indx][4];
                $result = mysqli_query($link,$SQL);
                
                while ($R = mysqli_fetch_array($result)){
                    for ($i1=1;$i1 <= $StUciteljev;$i1++){
                        if ($ucitelj[$i1][0]==$R["ucitelj"] ){ 
                            $ucitelj[$i1][2]=true;
                        }
                    }
                }
            }
        }

        $SQL = "SELECT datumnad,ura FROM TabNadomescanja WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $Datum=new DateTime($R["datumnad"]);
            $SQL = "SELECT prostor FROM taburnik WHERE leto=".$VLetoUrnik." AND DanVTednu=".($Datum->format('w'))." AND ura=".$R["ura"];
            $result = mysqli_query($link,$SQL);
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                for ($i1=1;$i1 <= $StProstorov;$i1++){
                    if ($Prostor[$i1][0]==$R["prostor"] ){ 
                        $Prostor[$i1][2]=false;
                    }
                }
                $Indx=$Indx+1;
            }
            
            $SQL="SELECT razred,paralelka,predmet,ura,prostor1,idrazred FROM TabNadomescanja WHERE datumNad='".$DanObracuna->format('d.m.Y')."' AND ura=".$UraOdpade;
            $result = mysqli_query($link,$SQL);
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $RazredOdpade[$Indx][1]=$R["razred"];
                $RazredOdpade[$Indx][2]=$R["paralelka"];
                $RazredOdpade[$Indx][3]=$DanObracuna->format('w');
                $RazredOdpade[$Indx][4]=$R["predmet"];
                $RazredOdpade[$Indx][5]=$R["ura"];
                $RazredOdpade[$Indx][6]=$R["prostor1"];
                $RazredOdpade[$Indx][7]=$R["idrazred"];
                $Indx=$Indx+1;
            }
            $StRazredOdpade=$Indx-1;
            
            for ($Indx=1;$Indx <= $StRazredOdpade;$Indx++){
                $SQL = "SELECT prostor FROM taburnik WHERE leto=".$VLetoUrnik." AND DanVTednu=".$RazredOdpade[$Indx][3]." AND prostor <> ".$RazredOdpade[$Indx][6];
                $result = mysqli_query($link,$SQL);
                
                while ($R = mysqli_fetch_array($result)){
                    for ($i1=1;$i1 <= $StProstorov;$i1++){
                        if ($Prostor[$i1][0]==$R["prostor"] ){ 
                            $Prostor[$i1][2]=true;
                        }
                    }
                }
            }
        }
        
        echo "<h2>Popravljanje nadomeščanj</h2>";
        $SQL = "SELECT id,datumnad,idrazred,razred,ura,predmet,prostor1,ucitelj1,ucitelj2,prostor2,oblika FROM TabNadomescanja WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            echo "<form accept-charset='utf-8' name='nadomescanje' method=post action='VnosNadomescanje.php'>";
            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Št.</th>";
            echo "<th>Datum</th>";
            echo "<th>Razred</th>";
            echo "<th>Ura</th>";
            echo "<th>Predmet</th>";
            echo "<th>Prostor</th>";
            echo "<th>Odsotni učitelj</th>";
            echo "<th>Nadomestni učitelj</th>";
            echo "<th>Nadomestni prostor</th>";
            echo "<th>Dejavnost</th>";
            echo "</tr>";
            echo "<tr>";
            echo "<td></td>";
            echo "<td><input name='datum' type='text' value='".$R["datumnad"]."'></td>";
            echo "<td>";
            echo "<select name='razred'>";
            for ($i1=1;$i1 <= $StRazredov;$i1++){
                if ($razred[$i1][1]==$R["idrazred"] ){
                    echo "<option value='".$razred[$i1][1]."' selected='selected'>".$razred[$i1][0]."</option>";
                }else{
                    echo "<option value='".$razred[$i1][1]."'>".$razred[$i1][0]."</option>";
                }
            }
            if ($R["idrazred"]==0 ){
                switch ($R["razred"]){
                    case 0:
                        echo "<option value='0' selected='selected'>0</option>";
                        break;
                    case 1:
                        echo "<option value='1' selected='selected'>1</option>";
                        break;
                    case 2:
                        echo "<option value='2' selected='selected'>2</option>";
                        break;
                    case 3:
                        echo "<option value='3' selected='selected'>3</option>";
                        break;
                    case 4:
                        echo "<option value='4' selected='selected'>4</option>";
                        break;
                    case 5:
                        echo "<option value='5' selected='selected'>5</option>";
                        break;
                    case 6:
                        echo "<option value='6' selected='selected'>6</option>";
                        break;
                    case 7:
                        echo "<option value='7' selected='selected'>7</option>";
                        break;
                    case 8:
                        echo "<option value='8' selected='selected'>8</option>";
                        break;
                    case 9:
                        echo "<option value='9' selected='selected'>9</option>";
                }
            }
            echo "</select>";
            if ($R["idrazred"]==0 ){
                echo "<input name='razred0' type='hidden' value='0'>";
            }else{
                echo "<input name='razred0' type='hidden' value='1'>";
            }
            echo "</td>";
            echo "<td>";
            echo "<select name='ura'>";
            for ($i1=0;$i1 <= 11;$i1++){
                if ($i1==$R["ura"] ){
                    echo "<option value='".$i1."' selected>".$i1."</option>";
                }else{
                    echo "<option value='".$i1."'>".$i1."</option>";
                }
            }
            echo "</select>";
            echo"</td>";
            echo "<td>";
            echo "<select name='predmet'>";
            for ($i1=1;$i1 <= $StPredmetov;$i1++){
                if ($Predmet[$i1][0]==$R["predmet"] ){
                    echo "<option value='".$Predmet[$i1][0]."' selected>".$Predmet[$i1][1]."</option>";
                }else{
                    echo "<option value='".$Predmet[$i1][0]."'>".$Predmet[$i1][1]."</option>";
                }
            }
            echo "</select>";
            echo "</td>";
            echo "<td>";
            echo "<select name='prostor1'>";
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<option value='".$Prostor[$i1][0]."' selected>".$Prostor[$i1][1]."</option>";
                }else{
                    echo "<option value='".$Prostor[$i1][0]."'>".$Prostor[$i1][1]."</option>";
                }
            }
            echo "</select>";
            echo "</td>";
            echo "<td>";
            echo "<select name='ucitelj1'>";
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<option value='".$ucitelj[$i1][0]."' selected>".$ucitelj[$i1][1]."</option>";
                }else{
                    echo "<option value='".$ucitelj[$i1][0]."'>".$ucitelj[$i1][1]."</option>";
                }
            }
            echo "</select>";
            echo "</td>";
            echo "<td>";
            
            echo "<select name='ucitelj2'>";
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<option value='".$ucitelj[$i1][0]."' selected>".$ucitelj[$i1][1]."</option>";
                }else{
                    if ($ucitelj[$i1][2] ){
                        echo "<option value='".$ucitelj[$i1][0]."'>".$ucitelj[$i1][1]."</option>";
                    }
                }
            }
            echo "</select>";
            echo "</td>";
            echo "<td>";
            echo "<select name='prostor2'>";
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
                    echo "<option value='".$Prostor[$i1][0]."' selected>".$Prostor[$i1][1]."</option>";
                }else{
                    echo "<option value='".$Prostor[$i1][0]."'>".$Prostor[$i1][1]."</option>";
                }
            }
            echo "</select>";
            echo "</td>";
            echo "<td>";
            echo "<select name='oblika'>";
            for ($i1=1;$i1 <= $StNadomescanj;$i1++){
                if ($Nadomescanje[$i1][0]==$R["oblika"] ){
                    echo "<option value='".$Nadomescanje[$i1][0]."' selected>".$Nadomescanje[$i1][1]."</option>";
                }else{
                    echo "<option value='".$Nadomescanje[$i1][0]."'>".$Nadomescanje[$i1][1]."</option>";
                }
            }
            echo "</select>";
            echo "</td>";
            echo "</tr>";
            echo "</table><br />";
            echo "<input name='id' type='hidden' value='5'>";
            echo "<input name='zapis' type='hidden' value='".$R["id"]."'>";
            echo "<input name='PoUciteljih' type='hidden' value='".$_GET["PoUciteljih"]."'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form><br />";
        }
        //'izpis urnika po uciteljih
        $Ucitelji="";
        $i1=0;
        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
            //echo $Indx."<br />";
            if ($ucitelj[$Indx][2] ){
                if ($ucitelj[$Indx][0] >= 0 ){
                    if (strlen($Ucitelji)==0){
                        $Ucitelji=$ucitelj[$Indx][0];
                        $i1=$i1+1;
                        $VUcitelji[$i1][0] = $ucitelj[$Indx][0];
                        $VUcitelji[$i1][1] = $ucitelj[$Indx][1];
                        $VUcitelji[$i1][2] = " ";
                    }else{
                        $Ucitelji=$Ucitelji.",".$ucitelj[$Indx][0];
                        $i1=$i1+1;
                        $VUcitelji[$i1][0] = $ucitelj[$Indx][0];
                        $VUcitelji[$i1][1] = $ucitelj[$Indx][1];
                        $VUcitelji[$i1][2] = " ";
                    }
                }
            }
        }
        $StUciteljev=$i1;
        //echo $StUciteljev."<br />";
        $danurnik=intval($DanObracuna->format('Ymd'));
        $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM ((taburnik "; 
        $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) "; 
        $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor ";
        $SQL = $SQL . "WHERE taburnik.leto=".$VLetoUrnik." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik." AND ucitelj IN (".$Ucitelji.") AND DanVTednu=".$DanObracuna->format('w')." ORDER BY tabucitelji.Priimek,tabucitelji.Ime,taburnik.DanVTednu,taburnik.Ura";
        $result = mysqli_query($link,$SQL);

        for ($Indx2=0;$Indx2 <= 200;$Indx2++){
            $Obremenitev[$Indx2]=0;
            $Indx=$DanObracuna->format('w');
            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
            }
        }

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $IzbraniUcitelj=$StUciteljev+1;
            for ($Indx2=1;$Indx2 <= $StUciteljev;$Indx2++){
                if ($R["iducitelj"]==$VUcitelji[$Indx2][0] ){
                    $IzbraniUcitelj=$Indx2;
                    break;
                }
            }
            switch ($R["nivo"]){
                case 1:
                case 2:
                case 3:
                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td><font color='red'>".$R["stevilka"]."</font></td><td><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                    break;
                case 7:
                case 8:
                case 9:
                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td><font color='red'>".$R["stevilka"]."</font></td><td><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                    break;
                default:
                    if ($R["razred"]==0 ){
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"]."</font></td><td><font color='red'>".$R["stevilka"]."</font></td><td></td></tr>";
                    }else{
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"]."</font></td><td><font color='red'>".$R["stevilka"]."</font></td><td><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                        //echo $UrnikUcitelj[$IzbraniUcitelj][$R["DanVTednu"]][$R["Ura"]]." ".$IzbraniUcitelj." ".$R["DanVTednu"]." ".$R["Ura"]."<br />";
                    }
            }
            $Indx=$Indx+1;
        }

        for ($Indx2=0;$Indx2 <= 200;$Indx2++){
            $Indx=$DanObracuna->format('w');
                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                    if (strlen($UrnikUcitelj[$Indx2][$Indx][$Indx0]) > 0 ){
                        $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                    }
                }
        }
        echo "<a name='1'></a>";
        echo "<h2>Urnik po učiteljih (".$VLetoUrnik."/".($VLetoUrnik+1)."):</h2>";
        echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
        echo "<th>Učitelj</th>";
        $Indx=$DanObracuna->format('w');
            echo "<th>".Int2Dan($Indx)."</th>";
            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
                echo "<th width='25'></th>";
            }
        echo "<th>Skupaj ur</th>";
        echo "<tr bgcolor='cyan'><td></td>";
        $Indx=$DanObracuna->format('w');
            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                echo "<td>".$Indx0."</td>";
            }
        echo "<td></td></tr>";

        $ColorChange=true;
        for ($Indx=0;$Indx <= 200;$Indx++){
            if ($Obremenitev[$Indx] > 0 ){
                if ($ColorChange ){
                    echo "<tr bgcolor='lightyellow'>";
                }else{
                    echo "<tr bgcolor='#FFFFCC'>";
                }
                $ColorChange=!$ColorChange;
                echo "<td><a href='IzpisUcitelja.php?iducitelj=".$VUcitelji[$Indx][0]."'>".$VUcitelji[$Indx][1]."</a></td>";
                $Indx1=$DanObracuna->format('w');
                    for ($Indx2=0;$Indx2 <= 12;$Indx2++){
                        if (strlen($UrnikUcitelj[$Indx][$Indx1][$Indx2]) > 0){
                            echo "<td valign='top'>";
                            echo "<table>";
                            echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
                            echo "</table>";
                            echo "</td>";
                        }else{
                            echo "<td>&nbsp;</td>";
                        }
                    }
                echo "<td align='center'>".$Obremenitev[$Indx]."</td>";
            }
        }

        echo "</table><br />";
        
        //'izpis urnika po prostorih
        $Prostori="";
        $i1=0;
        for ($Indx=1;$Indx <= $StProstorov;$Indx++){
            if ($Prostor[$Indx][2] ){
                if ($Prostor[$Indx][0] >= 0 ){
                    if (strlen($Prostori)==0){
                        $Prostori=$Prostor[$Indx][0];
                        $i1=$i1+1;
                        $VProstori[$i1][0] = $Prostor[$Indx][0];
                        $VProstori[$i1][1] = $Prostor[$Indx][1];
                        $VProstori[$i1][2] = " ";
                    }else{
                        $Prostori=$Prostori.",".$Prostor[$Indx][0];
                        $i1=$i1+1;
                        $VProstori[$i1][0] = $Prostor[$Indx][0];
                        $VProstori[$i1][1] = $Prostor[$Indx][1];
                        $VProstori[$i1][2] = " ";
                    }
                }
            }
        }
        $StProstorov=$i1;

        for ($Indx2=0;$Indx2 <= 200;$Indx2++){
            $Obremenitev[$Indx2]=0;
            $Indx=$DanObracuna->format('w');
            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                $UrnikProstorov[$Indx2][$Indx][$Indx0]="";
            }
        }

        $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.idprostor,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM ((taburnik "; 
        $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor ";
        $SQL = $SQL . "WHERE taburnik.leto=".$VLetoUrnik." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik." AND prostor IN (".$Prostori.") AND DanVTednu=".$DanObracuna->format('w')." ORDER BY tabprostor.Stevilka,taburnik.DanVTednu,taburnik.Ura";
        $result = mysqli_query($link,$SQL);

        $zbraniProstor="";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            switch ($R["nivo"]){
                case 1:
                case 2:
                case 3:
                    $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td><font color='red'>".$R["razred"].strtolower($R["paralelka"])."</font></td><td><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                    break;
                case 7:
                case 8:
                case 9:
                    $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td><font color='red'>".$R["razred"].strtolower($R["paralelka"])."</font></td><td><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                    break;
                default:
                    if ($R["razred"]==0 ){
                        $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"]."</font></td><td></td><td><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                    }else{
                        $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr><td><font color='darkblue'>".$R["poznaka"]."</font></td><td><font color='red'>".$R["razred"].strtolower($R["paralelka"])."</font></td><td><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                    }
            }
            $Indx=$Indx+1;
        }
        $StProstorov=$Indx;

        for ($Indx2=0;$Indx2 <= 200;$Indx2++){
            $Indx=$DanObracuna->format('w');
                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                    if (strlen($UrnikProstorov[$Indx2][$Indx][$Indx0]) > 0 ){
                        $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                    }
                }
        }

        echo "<a name='3'></a>";
        echo "<br /><h2>Urnik po prostorih (".$VLetoUrnik."/".($VLetoUrnik+1)."):</h2>";
        echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
        echo "<th>Prostor</th>";
        $Indx=$DanObracuna->format('w');
            echo "<th>".Int2Dan($Indx)."</th>";
            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
                echo "<th></th>";
            }
        echo "<th>Skupaj ur</th>";
        echo "<tr bgcolor='cyan'><td></td>";
        $Indx=$DanObracuna->format('w');
            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                echo "<td>".$Indx0."</td>";
            }
        echo "<td></td></tr>";

        $ColorChange=true;
        for ($Indx=0;$Indx <= 200;$Indx++){
            if ($Obremenitev[$Indx] > 0 ){
                if ($ColorChange ){
                    echo "<tr bgcolor='lightyellow'>";
                }else{
                    echo "<tr bgcolor='#FFFFCC'>";
                }
                $ColorChange=!$ColorChange;
                echo "<td>".$VProstor[$Indx][3]." - ".$VProstor[$Indx][1]." (".$VProstor[$Indx][2].")</td>";
                $Indx1=$DanObracuna->format('w');
                    for ($Indx2=0;$Indx2 <= 12;$Indx2++){
                        if (strlen($UrnikProstorov[$Indx][$Indx1][$Indx2]) > 0){
                            echo "<td valign='top'>";
                            echo "<table>";
                            echo $UrnikProstorov[$Indx][$Indx1][$Indx2];
                            echo "</table>";
                            echo "</td>";
                        }else{
                            echo "<td>&nbsp;</td>";
                        }
                    }
                
                echo "<td>".$Obremenitev[$Indx]."</td>";
            }
        }

        echo "</table>";
        break;
    case "4": // 'briši
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $SQL = "DELETE FROM TabNadomescanja WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        
        header("Location: VnosNadomescanje.php?id=1&leto=".$_GET["leto"]."&mesec=".$_GET["mesec"]."&dan=".$_GET["dan"]."&PoUciteljih=".$_GET["PoUciteljih"]);
        break;
    case "5": // 'popravi
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $VProstor1=$_POST["prostor2"];
        if ($VProstor1=="-1" ){
            $VProstor1=$_POST["prostor1"];
        }
        $SQL = "SELECT * FROM tabrazdat WHERE id=".$_POST["razred"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
            $VRazred=$R["id"];
        }
        if ($_POST["razred0"]=="0" ){
            $VRazred1=$_POST["razred"];
            $VRazred=0;
            $VParalelka="";
        }
        $Datum=new DateTime(isDate($_POST["datum"]));
        $SQL = "UPDATE TabNadomescanja SET ";
        if ($Datum->format('d.m.Y') > 8){
            $SQL = $SQL ."leto=".($Datum->format('Y')-1);
        }else{
            $SQL = $SQL ."leto=".$Datum->format('Y');
        }
        $SQL = $SQL .",datumNad='".$Datum->format('d.m.Y')."'";
        $SQL = $SQL .",razred=".$VRazred1;
        $SQL = $SQL .",paralelka='".$VParalelka."'";
        $SQL = $SQL .",predmet=".$_POST["predmet"];
        $SQL = $SQL .",ura=".$_POST["ura"];
        $SQL = $SQL .",ucitelj1=".$_POST["ucitelj1"];
        $SQL = $SQL .",prostor1=".$_POST["prostor1"];
        $SQL = $SQL .",ucitelj2=".$_POST["ucitelj2"];
        $SQL = $SQL .",prostor2=".$VProstor1;
        $SQL = $SQL .",oblika=".$_POST["oblika"];
        $SQL = $SQL .",vpisal='".$VUporabnik."'";
        $SQL = $SQL .",idRazred=".$VRazred;
        $SQL = $SQL .",cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["zapis"];
        $result = mysqli_query($link,$SQL);
        header("Location: VnosNadomescanje.php?id=1&leto=".$Datum->format('Y')."&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."&PoUciteljih=".$_POST["PoUciteljih"]);
        break;
    case "6": // 'priprava za tisk
        echo "<style>";
        echo "TABLE";
        echo "{";
        echo "    FONT-SIZE: 10pt;";
        echo "    FONT-FAMILY: Verdana;";
        echo "    BORDER: 1;";
        echo "    BACKGROUND-COLOR: white";
        echo "}";
        echo "TR.siv";
        echo "{";
        echo "    BACKGROUND-COLOR: lightgray";
        echo "}";
        echo "TD.siv";
        echo "{";
        echo "    BACKGROUND-COLOR: lightgray";
        echo "}";
        echo "TD.oranzen";
        echo "{";
        echo "    BACKGROUND-COLOR: #ffcf63";
        echo "}";
        echo ".velik";
        echo "{";
        echo "    FONT-SIZE: 10pt";
        echo "}";
        echo "</style>";
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["SolaKratko"];
            $VNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
        }else{
            $VSola=" ";
            $VNaslov=" ";
            $VRavnatelj=" ";
        }
        echo "<table border=0>";
        echo "<tr><td><img src='logo1.gif' height='160'></td><td><h2>".$VSola."<br />".$VNaslov."</h2></td></tr>";
        echo "</table>";
        echo "<h1>Nadomeščanja za dan: ";
        switch ($DanObracuna->format('w')+1){
            case 1:
                echo "nedelja, ";
                break;
            case 2:
                echo "ponedeljek, ";
                break;
            case 3:
                echo "torek, ";
                break;
            case 4:
                echo "sreda, ";
                break;
            case 5:
                echo "četrtek, ";
                break;
            case 6:
                echo "petek, ";
                break;
            case 7:
                echo "sobota, ";
        }
        echo $DanObracuna->format('d.m.Y')."</h1>";

        if ($_GET["PoUciteljih"]=="0" ){
            $PoUciteljih=false;
        }else{
            $PoUciteljih=true;
        }
        
        $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.*,tabpredmeti.*,tabucitelji.priimek,tabucitelji.ime FROM ";
        $SQL = $SQL . "((TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON TabNadomescanja.ucitelj1=tabucitelji.idUcitelj ";
        $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
        if ($PoUciteljih ){
            $SQL = $SQL . " ORDER BY priimek,ime,ura,razred,paralelka";
        }else{
            $SQL = $SQL . " ORDER BY razred,paralelka,ura,priimek,ime";
        }
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Št.</th>";
        //'echo "<th>Datum</th>"
        if (!$PoUciteljih ){
            echo "<th>Razred</th>";
        }else{
            echo "<th><a href='VnosNadomescanje.php?id=6&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=0'>Razred</a></th>";
        }
        echo "<th>Ura</th>";
        echo "<th>Predmet</th>";
        echo "<th>Prostor</th>";
        if ($PoUciteljih ){
            echo "<th width='150'>Odsotni učitelj</th>";
        }else{
            echo "<th width='150'><a href='VnosNadomescanje.php?id=6&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=1'>Odsotni učitelj</a></th>";
        }
        echo "<th width='150'>Nadomestni učitelj</th>";
        //'echo "<th>Nadomestni prostor</th>"
        echo "<th>Dejavnost</th>";
        echo "<th>Podpis</th>";
        echo "</tr>";
        
        $color=false;
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($color ){
                echo "<tr bgcolor='white'>";
                $color=false;
            }else{
                echo "<tr bgcolor='lightgray'>";
                $color=true;
            }
            
            echo "<td align=center>".$Indx."</td>";
            //'echo "<td>".day($R["datumNad")).".".month($R["datumNad")).".".year($R["datumNad"))."</td>"
            echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
            echo "<td align=center>".$R["ura"]."</td>";
            echo "<td>".$R["Oznaka"]."</td>";
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            $OutProstor=true;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
//'                        echo "<td>".$Prostor[i1,1)."</td>"
                    if (($R["prostor2"] != $R["prostor1"]) && ($R["prostor2"] != -1) ){
                        echo $Prostor[$i1][1]."</td>";
                        $OutProstor=false;
                    }
                    break;
                }
            }
            if ($OutProstor ){
                echo "</td>";
            }
            echo "<td>".$R["nadomescanje"]."</td>";
            echo "<td width='150'></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo $VKraj.", ".$Danes->format('j.n.Y')."<br />";
//'        echo "Pripravil/a: ".Pripravljalec."<br />"
        break;
    case "7":
        echo "<br /><form accept-charset='utf-8' name='datum' method=post action='VnosNadomescanje.php'>" ;
        echo "Dan <select name='dan'>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            if ($Indx==$VDan ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Mesec <select name='mesec'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            if ($Indx==$VMesec ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Leto <select name='leto'>";
        for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
            if ($Indx==$VLeto ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo "<input name='id' type='hidden' value='7'>";
        echo "<input name='submit' type='submit' value='Upoštevaj ta datum'>";
        echo "</form><br />";

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["SolaKratko"];
            $VNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
        }else{
            $VSola=" ";
            $VNaslov=" ";
            $VRavnatelj=" ";
        }
        echo "<table border=0>";
        echo "<tr><td><img src='logo1.gif' height='160'></td><td><h2>".$VSola."<br />".$VNaslov."</h2></td></tr>";
        echo "</table>";
        echo "<h1>Nadomeščanja za dan: ".$DanObracuna->format('d.m.Y')."</h1>";
        $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.*,tabpredmeti.* FROM ";
        $SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
        $SQL = $SQL . " ORDER BY razred,paralelka,ura";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Datum</th>";
        echo "<th>Razred</th>";
        echo "<th>Ura</th>";
        echo "<th>Predmet</th>";
        echo "<th>Prostor</th>";
        echo "<th>Odsotni učitelj</th>";
        echo "<th>Nadomestni učitelj</th>";
        echo "<th>Nadomestni prostor</th>";
        echo "<th>Dejavnost</th>";
        echo "</tr>";
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align=center>".$Indx."</td>";
            echo "<td>".$R["datumNad"]."</td>";
            echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
            echo "<td align=center>".$R["ura"]."</td>";
            echo "<td>".$R["Oznaka"]."</td>";
            $p=false;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            echo "<td>".$R["nadomescanje"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo $VKraj.", ".$Danes->format('j.n.Y')."<br />";
//'        echo "Pripravil/a: ".Pripravljalec."<br />"
        break;
    case "7a":  //izpis za potrjevanje nadomeščanj
        echo "<br /><form accept-charset='utf-8' name='datum' method='post' action='VnosNadomescanje.php'>" ;
        echo "Dan <select name='dan'>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            if ($Indx==$VDan ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Mesec <select name='mesec'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            if ($Indx==$VMesec ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Leto <select name='leto'>";
        for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
            if ($Indx==$VLeto ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo "<input name='id' type='hidden' value='7a'>";
        echo "<input name='submit' type='submit' value='Upoštevaj ta datum'>";
        echo "</form>";

        /*
        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["SolaKratko"];
            $VNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
        }else{
            $VSola=" ";
            $VNaslov=" ";
            $VRavnatelj=" ";
        }
        echo "<table border=0>";
        echo "<tr><td><img src='logo1.gif' height='160'></td><td><h2>".$VSola."<br />".$VNaslov."</h2></td></tr>";
        echo "</table>";
        */
        echo "<h1>Nadomeščanja za dan: ".$DanObracuna->format('d.m.Y')."</h1>";
        $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.nadomescanje,tabpredmeti.oznaka FROM ";
        $SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
        $SQL = $SQL . " ORDER BY razred,paralelka,ura";
        $result = mysqli_query($link,$SQL);

        echo "<form accept-charset='utf-8' name='potrditve' method='post' action='VnosNadomescanje.php'>";

        echo "<div id='txtHint'>";

        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Datum</th>";
        echo "<th>Razred</th>";
        echo "<th>Ura</th>";
        echo "<th>Predmet</th>";
        echo "<th>Prostor</th>";
        echo "<th>Odsotni učitelj</th>";
        echo "<th>Nadomestni učitelj</th>";
        echo "<th>Nadomestni prostor</th>";
        echo "<th>Dejavnost</th>";
        echo "<th>Učitelj<br />potrdil</th>";
        echo "</tr>";
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($R["potrjeno"]){
                echo "<tr bgcolor='lightgreen'>";
            }else{
                echo "<tr>";
            }
            echo "<td align=center><br />".$Indx."<br /><br /></td>";
            echo "<td>".$R["datumNad"]."</td>";
            echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
            echo "<td align=center>".$R["ura"]."</td>";
            echo "<td>".$R["oznaka"]."</td>";
            $p=false;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            $p=false;
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    $p=true;
                    break;
                }
            }
            if (!$p){
                echo "<td>&nbsp;</td>";
            }
            echo "<td>".$R["nadomescanje"]."</td>";
            
            echo "<td align='center'>";
            //echo "<input name='pid_".$Indx."' type='hidden' value='".$R["id"]."'>";
            if (intval($R["ucitelj2"]) > 0){
                if ($R["potrjeno"]){
                    echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' checked='checked' onchange='potrditevNadomescanja(".$R["id"].")'>";
                }else{
                    echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' onchange='potrditevNadomescanja(".$R["id"].")'>";
                }
            }
            echo "</td>";
            
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "</div>";
        echo "</form>";
        //echo $VKraj.", ".$Danes->format('j.n.Y')."<br />";
//'        echo "Pripravil/a: ".Pripravljalec."<br />"
        break;
    case "8":   //prenos v mesečne preglede dela
        echo "<br /><form accept-charset='utf-8' name='datum' method=post action='VnosNadomescanje.php'>" ;
        echo "Dan <select name='dan'>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            if ($Indx==$VDan ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Mesec <select name='mesec'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            if ($Indx==$VMesec ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo " Leto <select name='leto'>";
        for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
            if ($Indx==$VLeto ){
                echo "<option value='".$Indx."' selected>".$Indx."</option>";
            }else{
                echo "<option value='".$Indx."'>".$Indx."</option>";
            }
        }
        echo "</select>";
        echo "<input name='id' type='hidden' value='8'>";
        echo "<input name='submit' type='submit' value='Upoštevaj ta datum'>";
        echo "</form><br />";
        
        echo "<h1>Nadomeščanja za dan: ".$DanObracuna->format('d.m.Y')."</h1>";

        $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.*,tabpredmeti.*,TabNadomescanja.id AS nid FROM ";
        $SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
        $SQL = $SQL . " ORDER BY razred,paralelka,ura";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Prenos nadomeščanj v mesečne preglede dela</h2>";
        echo "<form accept-charset='utf-8' name='nadomescanje' method=post action='VnosNadomescanje.php'>";
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Datum</th>";
        echo "<th>Razred</th>";
        echo "<th>Ura</th>";
        echo "<th>Predmet</th>";
        echo "<th>Prostor</th>";
        echo "<th>Odsotni učitelj</th>";
        echo "<th>Nadomestni učitelj</th>";
        echo "<th>Nadomestni prostor</th>";
        echo "<th>Dejavnost</th>";
        echo "<th>Prenesi</th>";
        echo "</tr>";
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align=center>".$Indx."</td>";
            echo "<td>".$R["datumNad"]."</td>";
            echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
            echo "<td align=center>".$R["ura"]."</td>";
            echo "<td>".$R["Oznaka"]."</td>";
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor1"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                    echo "<td>".$ucitelj[$i1][1]."</td>";
                    break;
                }
            }
            for ($i1=1;$i1 <= $StProstorov;$i1++){
                if ($Prostor[$i1][0]==$R["prostor2"] ){
                    echo "<td>".$Prostor[$i1][1]."</td>";
                    break;
                }
            }
            echo "<td><input type='hidden' name='zapis".$Indx."' value='".$R["nid"]."'>".$R["nadomescanje"]."</td>";
            if ($R["ucitelj2"] > 0 ){
                switch ($R["oblika"]){
                    case 1:
                        echo "<td><input name='nadom".$Indx."' type='checkbox' checked></td>";
                        break;
                    case 2:
                    case 3:
                    case 4:
                        echo "<td><input name='nadom".$Indx."' type='checkbox'></td>";
                }
            }else{
                echo "<td><input name='nadom".$Indx."' type='checkbox'></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }

        echo "</table><br />";
        
        echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
        echo "<input name='id' type='hidden' value='9'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        break;
    case "9":    //vpis prenosa v mesečni pregled dela
        if (!CheckDostop("VnosNadom",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        echo "<h2>Poročilo o prenosu nadomeščanj v mesečne preglede dela</h2>";
        $StZapisov=$_POST["StZapisov"];
        for ($Indx=1;$Indx <= $StZapisov;$Indx++){
            if (isset($_POST["nadom".$Indx])){
                $SQL = "SELECT TabNadomescanja.*,tabpredmeti.* FROM TabNadomescanja INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id WHERE TabNadomescanja.id=".$_POST["zapis".$Indx];
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $Prenos[0]=$R["ucitelj2"];
                    $Prenos[1]=$R["predmet"];
                    $Prenos[2]=$R["Oznaka"];
                    $Prenos[3]=$R["datumNad"];
                    $Prenos[4]=$R["ura"];
                    for ($i1=1;$i1 <= $StUciteljev;$i1++){
                        if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                            $Prenos[5]=$ucitelj[$i1][1];
                            break;
                        }
                    }
                    $Prenos[6]=$R["razred"].$R["paralelka"];
                    $Datum=new DateTime($Prenos[3]);
                    $SQL = "SELECT * FROM tabpregleddelan WHERE leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j')." AND ucitelj=".$Prenos[0]." AND komentar LIKE '%".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."%'";
                    $result2 = mysqli_query($link,$SQL);
                    
                    if ($R2 = mysqli_fetch_array($result2)){
                        echo "Učitelj/ica ".$Prenos[5]." ima že vpisano nadomeščanje ".$Prenos[3]." - ".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."<br />";
                    }else{
                        $SQL = "INSERT INTO tabpregleddelan (";
                        $SQL = $SQL ."datum,leto,mesec,dan,rubrika,enot,komentar,EnotPotrjeno,DatVnosa,ucitelj,Vpisal,potrdil,cas";
                        $SQL = $SQL .") VALUES (";
                        $SQL = $SQL ."'".$Datum->format('Y-m-d')."',".$Datum->format('Y').",".$Datum->format('n').",".$Datum->format('j').",";
                        switch ($R["oblika"]){
                              case 1:
                                  switch ($Prenos[1]){
                                      case 52:
                                      case 78:
                                      case 79:
                                      case 80:
                                      case 81:
                                      case 82:
                                      case 83:
                                      case 84:
                                      case 85:
                                      case 86:
                                      case 87:
                                      case 88:
                                      case 89:
                                      case 90:
                                      case 91: // 'OPB
                                          $SQL = $SQL . "10,50,";
                                          break;
                                      default: //    'pedagoške ure
                                          $SQL = $SQL . "9,1,";
                                  }
                                  break;
                              case 2: //združeno. nadzor
                              case 3:
                                  $SQL = $SQL . "25,0.5,";
                          }
                        $SQL = $SQL ."'".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."',true,'".$Danes->format('Y-m-d H:i:s')."',".$Prenos[0].",'".$VUporabnik."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL .")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                        
                        echo "Učitelj/ica ".$Prenos[5]." ima dodano novo nadomeščanje ".$Prenos[3]." - ".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."<br />";
                    }
                }
            }
        }
        echo "<br />";
        break;
    case "10":    //vpis odsotnosti
        $DanVTednu=$DanObracuna->format('w');
        $danurnik=$DanObracuna->format('Ymd');
        if ($_POST["odsotniuc"] != "0" ){
            switch ($DanVTednu){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    if ($VMesec > 8 ){
                        $SQL = "SELECT * FROM taburnik WHERE ucitelj IN (".$_POST["odsotniuc"].") AND DanVTednu=".$DanVTednu." AND leto=".$VLeto." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }else{
                        $SQL = "SELECT * FROM taburnik WHERE ucitelj IN (".$_POST["odsotniuc"].") AND DanVTednu=".$DanVTednu." AND leto=".($VLeto-1)." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }
                    $result = mysqli_query($link,$SQL);
                    
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $PredlogNadom[$Indx][0]=$R["Leto"];
                        $PredlogNadom[$Indx][1]=$R["Ucitelj"];
                        $PredlogNadom[$Indx][2]=$R["Predmet"];
                        $PredlogNadom[$Indx][3]=$R["Nivo"];
                        $PredlogNadom[$Indx][4]=$R["Razred"];
                        $PredlogNadom[$Indx][5]=$R["Paralelka"];
                        $PredlogNadom[$Indx][6]=$R["VrstaOS"];
                        $PredlogNadom[$Indx][7]=$R["DanVTednu"];
                        $PredlogNadom[$Indx][8]=$R["Ura"];
                        $PredlogNadom[$Indx][9]=$R["Prostor"];
                        $PredlogNadom[$Indx][10]=$R["idRazred"];
                        $Indx=$Indx+1;
                    }
                    $StPredlogov=$Indx-1;
                    
                    for ($Indx=1;$Indx <= $StPredlogov;$Indx++){
                        $SQL = "INSERT INTO TabNadomescanja (leto,datumNad,razred,paralelka,predmet,ura,ucitelj1,prostor1,ucitelj2,prostor2,oblika,vpisal,cas,idRazred,iduntis,potrjeno) VALUES (";
                        $SQL = $SQL . $PredlogNadom[$Indx][0].",";
                        $SQL = $SQL . "'".$DanObracuna->format('d.m.Y')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][4].",";
                        $SQL = $SQL . "'".$PredlogNadom[$Indx][5]."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][2].",";
                        $SQL = $SQL . $PredlogNadom[$Indx][8].",";
                        $SQL = $SQL . $PredlogNadom[$Indx][1].",";
                        $SQL = $SQL . $PredlogNadom[$Indx][9].",";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "-1,";
                        $SQL = $SQL . "4,";
                        $SQL = $SQL . "'".$VUporabnik."',";
                        $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][10];
                        $SQL = $SQL .",0,false)";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                        //echo $SQL."<br />";
                    }
            }
        }
        
        if ($_POST["odsotnirazr"] != "0" ){
            switch ($DanVTednu){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    if ($VMesec > 8 ){
                        $SQL = "SELECT * FROM taburnik WHERE razred=".mb_substr($_POST["odsotnirazr"],0,1)." AND paralelka='".mb_substr($_POST["odsotnirazr"],-1)."' AND DanVTednu=".$DanVTednu." AND leto=".$VLeto." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }else{
                        $SQL = "SELECT * FROM taburnik WHERE razred=".mb_substr($_POST["odsotnirazr"],0,1)." AND paralelka='".mb_substr($_POST["odsotnirazr"],-1)."' AND DanVTednu=".$DanVTednu." AND leto=".($VLeto-1)." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }
                    $result = mysqli_query($link,$SQL);
                    
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $PredlogNadom[$Indx][0]=$R["Leto"];
                        $PredlogNadom[$Indx][1]=$R["Ucitelj"];
                        $PredlogNadom[$Indx][2]=$R["Predmet"];
                        $PredlogNadom[$Indx][3]=$R["Nivo"];
                        $PredlogNadom[$Indx][4]=$R["Razred"];
                        $PredlogNadom[$Indx][5]=$R["Paralelka"];
                        $PredlogNadom[$Indx][6]=$R["VrstaOS"];
                        $PredlogNadom[$Indx][7]=$R["DanVTednu"];
                        $PredlogNadom[$Indx][8]=$R["Ura"];
                        $PredlogNadom[$Indx][9]=$R["Prostor"];
                        $PredlogNadom[$Indx][10]=$R["idRazred"];
                        $Indx=$Indx+1;
                    }
                    $StPredlogov=$Indx-1;
                    
                    for ($Indx=1;$Indx <= $StPredlogov;$Indx++){
                        $SQL = "INSERT INTO TabNadomescanja (leto,datumNad,razred,paralelka,predmet,ura,ucitelj1,prostor1,ucitelj2,prostor2,oblika,vpisal,cas,idRazred,iduntis,potrjeno) VALUES (";
                        $SQL = $SQL . $PredlogNadom[$Indx][0].",";
                        $SQL = $SQL . "'".$DanObracuna->format('d.m.Y')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][4].",";
                        $SQL = $SQL . "'".$PredlogNadom[$Indx][5]."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][2].",";
                        $SQL = $SQL . $PredlogNadom[$Indx][8].",";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . $PredlogNadom[$Indx][9].",";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "-1,";
                        $SQL = $SQL . "4,";
                        $SQL = $SQL . "'".$VUporabnik."',";
                        $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][10];
                        $SQL = $SQL .",0,false)";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                    }
            }
        }

        if ($_POST["zasedenprostor"] != "0" ){
            switch ($DanVTednu){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    if ($VMesec > 8 ){
                        $SQL = "SELECT * FROM taburnik WHERE prostor=".$_POST["zasedenprostor"]." AND DanVTednu=".$DanVTednu." AND leto=".$VLeto." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }else{
                        $SQL = "SELECT * FROM taburnik WHERE prostor=".$_POST["zasedenprostor"]." AND DanVTednu=".$DanVTednu." AND leto=".($VLeto-1)." AND taburnik.od <= ".$danurnik." AND taburnik.do >= ".$danurnik;
                    }
                    $result = mysqli_query($link,$SQL);
                    
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $PredlogNadom[$Indx][0]=$R["Leto"];
                        $PredlogNadom[$Indx][1]=$R["Ucitelj"];
                        $PredlogNadom[$Indx][2]=$R["Predmet"];
                        $PredlogNadom[$Indx][3]=$R["Nivo"];
                        $PredlogNadom[$Indx][4]=$R["Razred"];
                        $PredlogNadom[$Indx][5]=$R["Paralelka"];
                        $PredlogNadom[$Indx][6]=$R["VrstaOS"];
                        $PredlogNadom[$Indx][7]=$R["DanVTednu"];
                        $PredlogNadom[$Indx][8]=$R["Ura"];
                        $PredlogNadom[$Indx][9]=$R["Prostor"];
                        $PredlogNadom[$Indx][10]=$R["idRazred"];
                        $Indx=$Indx+1;
                    }
                    $StPredlogov=$Indx-1;
                    
                    for ($Indx=1;$Indx <= $StPredlogov;$Indx++){
                        $SQL = "INSERT INTO TabNadomescanja (leto,datumNad,razred,paralelka,predmet,ura,ucitelj1,prostor1,ucitelj2,prostor2,oblika,vpisal,cas,idrazred,iduntis,potrjeno) VALUES (";
                        $SQL = $SQL . $PredlogNadom[$Indx][0].",";
                        $SQL = $SQL . "'".$DanObracuna->format('d.m.Y')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][4].",";
                        $SQL = $SQL . "'".$PredlogNadom[$Indx][5]."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][2].",";
                        $SQL = $SQL . $PredlogNadom[$Indx][8].",";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . $PredlogNadom[$Indx][9].",";
                        $SQL = $SQL . "0,";
                        $SQL = $SQL . "-1,";
                        $SQL = $SQL . "4,";
                        $SQL = $SQL . "'".$VUporabnik."',";
                        $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."',";
                        $SQL = $SQL . $PredlogNadom[$Indx][10];
                        $SQL = $SQL .",0,false)";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                    }
            }
        }

        header("Location: VnosNadomescanje.php?id=1&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan);
}
switch ($Obdelava ){
    case "1":
    case "2":
    case "3":
    case "4":
    case "5":
        echo "<a href='VnosNadomescanje.php?id=6&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=1'>Priprava za tisk</a><br />";
        echo "<a href='VnosNadomescanje.php?id=8&leto=".$VLeto."&mesec=".$VMesec."&dan=".$VDan."&PoUciteljih=1'>Prenos nadomeščanj v mesečne preglede dela</a><br />";
        echo "<br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        break;
    case "7":
    case "9":
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
}

?>

</body>
</html>
