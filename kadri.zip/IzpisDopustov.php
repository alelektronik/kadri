<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid) {
	case "1":  //prenos dopustov v naslednje leto
		$SQL = "SELECT * FROM TabDopust WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
		
		$indx=0;
        while ($R = mysqli_fetch_array($result)){
			$Delavec[$indx][0]=$R["IdUcitelj"];
			$Delavec[$indx][1]=$R["DelDobaLet"]+1;
			$Delavec[$indx][2]=$R["DopustNaDD"];
			$Delavec[$indx][3]=$R["DopustNaIz"];
			$Delavec[$indx][4]=$R["DopustNaOt"];
			$Delavec[$indx][5]=$R["DopustNaSta"];
			$Delavec[$indx][6]=$R["DopustNaInv"];
			$Delavec[$indx][7]=$R["DopustNaVod"];
			$Delavec[$indx][8]=$R["DopustVzgoja"];
			$Delavec[$indx][9]=0; //'stari dopust
			$Delavec[$indx][10]=$R["DopustDelInv"];
			$Delavec[$indx][11]=$R["DopustPP"];
			$Delavec[$indx][12]=$R["Drugo"];
			$indx=$indx+1;
		}
		
		if ($indx > 0) {
			for ($i1=0;$i1 <= $indx-1;$i1++){
				$SQL = "SELECT * FROM TabDopust WHERE leto=".($VLeto+1)." AND idUcitelj=".$Delavec[$i1][0];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
					$SQL = "UPDATE TabDopust SET ";
					$SQL = $SQL . "DelDobaLet=".$Delavec[$i1][1].", ";
					$SQL = $SQL . "DopustNaDD=".$Delavec[$i1][2].", ";
					$SQL = $SQL . "DopustNaIz=".$Delavec[$i1][3].", ";
					$SQL = $SQL . "DopustNaOt=".$Delavec[$i1][4].", ";
					$SQL = $SQL . "DopustNaSta=".$Delavec[$i1][5].", ";
					$SQL = $SQL . "DopustNaInv=".$Delavec[$i1][6].", ";
					$SQL = $SQL . "DopustNaVod=".$Delavec[$i1][7].", ";
					$SQL = $SQL . "DopustVzgoja=".$Delavec[$i1][8].", ";
					$SQL = $SQL . "DopustDelInv=".$Delavec[$i1][10].", ";
					$SQL = $SQL . "DopustPP=".$Delavec[$i1][11].", ";
					$SQL = $SQL . "Drugo=".$Delavec[$i1][12].", ";
					$SQL = $SQL . "DopustStari=".$Delavec[$i1][9];
					$SQL = $SQL . " WHERE Id=".$R["Id"];
				}else{
					$SQL = "INSERT INTO TabDopust (leto,IdUcitelj,DelDobaLet,DopustNaDD,DopustNaIz,DopustNaOt,DopustNaSta,DopustNaInv,DopustNaVod,DopustVzgoja,DopustStari,";
					$SQL = $SQL . "DopustDelInv,DopustPP,Drugo) ";
					$SQL = $SQL . "VALUES (".($VLeto+1);
					$SQL = $SQL .",".$Delavec[$i1][0];
					$SQL = $SQL .",".$Delavec[$i1][1];
					$SQL = $SQL .",".$Delavec[$i1][2];
					$SQL = $SQL .",".$Delavec[$i1][3];
					$SQL = $SQL .",".$Delavec[$i1][4];
					$SQL = $SQL .",".$Delavec[$i1][5];
					$SQL = $SQL .",".$Delavec[$i1][6];
					$SQL = $SQL .",".$Delavec[$i1][7];
					$SQL = $SQL .",".$Delavec[$i1][8];
					$SQL = $SQL .",".$Delavec[$i1][9];
					$SQL = $SQL .",".$Delavec[$i1][10];
					$SQL = $SQL .",".$Delavec[$i1][11];
					$SQL = $SQL .",".$Delavec[$i1][12];
					$SQL = $SQL .")";
				}
			    $result = mysqli_query($link,$SQL);
            }
		}
		
		$SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.DelDobaSol,TabDopust.* FROM tabucitelji INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj WHERE status > 0 AND TabDopust.leto=".($VLeto+1);
        $result = mysqli_query($link,$SQL);
            
		$StUciteljev=0;
        while ($R = mysqli_fetch_array($result)){
			$StUciteljev=$StUciteljev+1;
			$Ucitelj[$StUciteljev][0]=$R["IdUcitelj"];
			$Ucitelj[$StUciteljev][3]=$R["Priimek"]." ".$R["Ime"];
			$Ucitelj[$StUciteljev][1]=$R["DelDobaLet"];
			if (!isset($Ucitelj[$StUciteljev][1])){
				$Ucitelj[$StUciteljev][1]=0;
			}
			$Ucitelj[$StUciteljev][2]=$R["DelDobaSol"];
			if (!isset($Ucitelj[$StUciteljev][2])){
				$Ucitelj[$StUciteljev][2]=0;
			}
			$Ucitelj[$StUciteljev][4]=$R["Priimek"];
			$Ucitelj[$StUciteljev][5]=$R["Ime"];
		}

		for ($indx=1;$indx <= $StUciteljev;$indx++){
			$SQL = "UPDATE tabucitelji SET DelDobaSol=".($Ucitelj[$indx][2]+1).", DelDobaLet=".$Ucitelj[$indx][1]." WHERE IdUcitelj=".$Ucitelj[$indx][0]; 
            $result = mysqli_query($link,$SQL);
			echo "Delavec: ".$Ucitelj[$indx][3]." Del. doba: ".($Ucitelj[$indx][1]-1)."/".$Ucitelj[$indx][1]." Del. doba šol.: ".$Ucitelj[$indx][2]."/".($Ucitelj[$indx][2]+1)."<br />";
		}
        break;
	case "2":// 'pobriše podatke o dopustu v določenem letu
		$SQL = "DELETE * FROM TabDopust WHERE leto=".($VLeto+1);
        $result = mysqli_query($link,$SQL);
		echo "<h2>Podatki o dopustih za leto ".($VLeto+1)." so izbrisani. Preverite delovno dobo in delovno dobo v šolstvu!</h2>"; 
		
}

$SQL = "SELECT * FROM tabucitelji WHERE (Status > 0) AND (Status < 10) ORDER BY Priimek,Ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
	$UciteljZaObdelavo[$Indx]=$R["IdUcitelj"];
	$Indx=$Indx+1;
}
$StUciteljevZaObdelavo=$Indx-1;

echo "<br><a href='KorekcijaTiska.php'>Vpis datuma izpisa in evidenčnih številk</a><br />";
echo "<a href='OdlocbeDopustRTF2.php?leto=".$VLeto."'>Odločbe v RTF/Word - Oblika s prenosom starega dopusta in podpisom prejemnika</a><br />";
echo "<a href='OdlocbeDopustRTF3.php?leto=".$VLeto."'>Odločbe v RTF/Word - Oblika (OŠ II Žalec)</a><br />";
echo "<h2>Dopusti za leto ".$VLeto."</h2>";
echo "<a href='IzpisDopustov.php?leto=".($VLeto-1)."'>Leto-1</a> <a href='IzpisDopustov.php?leto=".($VLeto+1)."'>Leto+1</a><br><br />";
echo "<a href='IzpisDopustov.php?id=1&leto=".$VLeto."'>Prenos podatkov o dopustih v leto ".($VLeto+1)."</a><br />";
echo "<a href='IzpisDopustov.php?id=2&leto=".$VLeto."'>Briši podatke o dopustih v letu ".($VLeto+1)."</a><br /><br />";
//echo "<a href='PopraviLeta.php?id=1&leto=".$VLeto."' target='new_win'>Prištej eno leto k del. dobi vseh delavcev</a><br />";
//echo "<a href='PopraviLeta.php?id=2&leto=".$VLeto."' target='new_win'>Odštej eno leto od del. dobe vseh delavcev</a><br />";
echo "<a href='PopraviLeta.php?id=1&leto=".$VLeto."'>Prištej eno leto k del. dobi vseh delavcev</a><br />";
echo "<a href='PopraviLeta.php?id=2&leto=".$VLeto."'>Odštej eno leto od del. dobe vseh delavcev</a><br />";
echo "<table border=1 cellspacing=0>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th><th>Starost</th><th>Stopnja izobrazbe</th><th>Del. doba</th>";
echo "<th>Na del. dobo</th><th>Na izobr.</th><th>Na vodenje</th><th>Na otroke</th><th>Na vzgojo</th><th>Na inv.</th><th>Na starost</th>";
echo "<th>Del. inv.</th><th>PP</th><th>Drugo</th>";
echo "<th>Skupaj</th>";
echo "<th>Star</th>";
echo "<th>Opis dela</th><th>Status</th>";
echo "</tr>";
$ColorChange=true;

for ($IndxObdelava=1;$IndxObdelava <= $StUciteljevZaObdelavo;$IndxObdelava++){
	$oUcitelj=new RUcitelj;
	$oUcitelj->PreberiSeGlavno($UciteljZaObdelavo[$IndxObdelava],$VLeto,$VLeto);
	if ($ColorChange){
		echo "<tr bgcolor='lightyellow'>";
	}else{
		echo "<tr bgcolor=#FFFFCC>";
	}

	$ColorChange=!$ColorChange;
	echo "<td>".$IndxObdelava."</td>";
	echo "<td><a href='PopraviDopust.php?idUcitelj=".$oUcitelj->getIdUcitelj()."&leto=".$VLeto."&id=1'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
    $DatRoj=$oUcitelj->getDatRoj();
	echo "<td align=center>".($VLeto-$DatRoj->format('Y'))."</td>";
	echo "<td>".$oUcitelj->getIzobrazba()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDelDobaLet()."&nbsp;</td>";

	echo "<td align=right>".$oUcitelj->getDopustNaDD()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustNaIz()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustNaVod()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustNaOt()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustVzgoja()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustNaInv()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustNaSta()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustDelInv()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustPP()."&nbsp;</td>";
	echo "<td align=right>".$oUcitelj->getDopustDrugo()."&nbsp;</td>";

	if ($oUcitelj->getDelez() >= 0){
		echo "<td align=right>".$oUcitelj->getDelez()." (".($oUcitelj->getDopustNaDD()+$oUcitelj->getDopustNaIz()+$oUcitelj->getDopustNaVod()+$oUcitelj->getDopustNaOt()+$oUcitelj->getDopustVzgoja()+$oUcitelj->getDopustNaInv()+$oUcitelj->getDopustNaSta()+$oUcitelj->getDopustDelInv()+$oUcitelj->getDopustPP()+$oUcitelj->getDopustDrugo()).")</td>";
	}else{
		echo "<td align=right>".$oUcitelj->getDopust()."</td>";
	}

	echo "<td align=right>".$oUcitelj->getDopustStari()."&nbsp;</td>";
	echo "<td>".$oUcitelj->getDelMesto()."&nbsp;</td>";
	echo "<td>".$oUcitelj->getStatusDelavca()."&nbsp;</td>";
	echo "</tr>";
}
echo "</table><br /><br />";

?>

</body>
</html>
