<?php 
/*
if (!isset($_SERVER["HTTPS"])){
    header("Location: https://".$_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']);
}else{
    if ($_SERVER["HTTPS"] != "on"){
        header("Location: https://".$_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']);
    }else{
*/
?>
<?php
if (file_exists("nastavitve.php")) {
    echo "<html>";
    echo "<head>";
    echo "<title>Kadri in učenci</title>";
    echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"osmp3.css\">"; 
    echo "<meta name=\"robots\" content=\"noindex,nofollow\">";
    echo "</head>";

    echo "<body bgcolor=\"#FFFFFF\" text=\"#000000\">";
    //osnovne nastavitve obstajajo, izvede prijavo
    echo "<form name='prijava' method='post' action='prijava.php'>";
    echo "<div class='ozadje'>";
    echo "<label for='Uporabnik'>Vnesite  uporabniško ime</label> <input name='Uporabnik' type='text' size='8'><br />";
    echo "<label for='Geslo'>Vnesite  geslo</label><input name='Geslo' type='password' size='16'><br />";
    /*
    $Sifra1 = rand(1,9).rand(1,9).rand(1,9).rand(1,9);
    echo "Vstopna koda 1 je: ".$Sifra1."<br />";
    echo "<input name='sifra1' type='hidden' value='".$Sifra1."'>";
    echo "Vnesite vstopno kodo 2: <input name='sifra2' type='password' size='10'><br />";
    */
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</div>";
    echo "</form>";
    echo "</body>";
    echo "</html>";
} else {
    //če ni nastavitev, preusmeri v njihovo nastavljanje
    header("Location: setup.php");
}
?>
