<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<?php

if (isset($_GET["ucenec"])){
    $Isci=explode(" ", $_GET["ucenec"]);
    $VUcenec=$Isci[0];
    $VUcenec=$_GET["ucenec"];
    //echo $VUcenec[0]."<br />";

    if (strlen($VUcenec) > 2){
        echo "Najdeno na iskalni niz - ".$VUcenec."<br />";
        //echo "<table class='condensed' border=1>";
        echo "<table class='condensed' border=1><tr><th>N</th><th>Priimek in ime</th><td></td><td>Razred</td><th>Datum rojstva</th><th>Naslov</th><th>Posta</th><th>Kraj</th><th>Oče</th><th>Telefon</th><th>Mati</th><th>Telefon</th></tr>";

        if (isDate($VUcenec) or (strlen($VUcenec) == 0)){
            if (strlen($VUcenec)==0){
                $SQL = "SELECT * FROM tabucenci WHERE ";
                $SQL = $SQL . "(day(DatRoj)=".$Danes->format('j')." AND month(DatRoj)=".$Danes->format('n').")";
                $SQL = $SQL ." ORDER BY priimek,ime";
            }else{
                $Datum=new DateTime(isDate($VUcenec));
                $SQL = "SELECT * FROM tabucenci WHERE ";
                $SQL = $SQL . "(day(DatRoj)=".$Datum->format('j')." AND month(DatRoj)=".$Datum->format('n').")";
                $SQL = $SQL ." ORDER BY priimek,ime";
            }
        }else{
            $SQL = "SELECT * FROM tabucenci WHERE ";
            $SQL = $SQL . "(priimek LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ime LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR naslov LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR posta LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR kraj LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR naslovzac LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR krajzac LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR postazac LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR emso LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR maticnilist LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR oce LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR mati LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR skrbniki LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR placnik LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR oceemail LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matiemail LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ocenaslov LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matinaslov LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ocezacnasl LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matizacnasl LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR opombe LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ocekontakt LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matikontakt LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ocegsm LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matigsm LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR ocesluzba LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR matisluzba LIKE '%".$VUcenec."%'";
            $SQL = $SQL . " OR telefondoma LIKE '%".$VUcenec."%'";
            $SQL = $SQL . ")";
            $SQL = $SQL ." ORDER BY priimek,ime";
        }
        $result = mysqli_query($link,$SQL);

        $VLeto=$_SESSION["solskoleto"];
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>" . $Indx ."</td>";
            echo "<td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"] ."'>" . $R["Priimek"] . ", " . $R["Ime"] . "</a></td>";

            $SQL = "SELECT slika,razred,paralelka,idrazred FROM tabrazred WHERE leto=".$VLeto." AND iducenec=".$R["IdUcenec"];
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                if (isset($R1["slika"])){
                    if (file_exists($R1["slika"])){
                        echo "<td><img src='".$R1["slika"]."' width='40'></td> ";
                    }else{
                        echo "<td>&nbsp;</td>";
                    }
                }else{
                    echo "<td>&nbsp;</td>";
                }
                if (isset($R1["idrazred"])){
                    echo "<td><a href='izpisrazreda.php?solskoleto=".$VLeto."&razred=".$R1["idrazred"]."'>".$R1["razred"].".".$R1["paralelka"]."</a></td> ";
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }else{
                echo "<td>&nbsp;</td>";
                echo "<td>&nbsp;</td>";
            }
            
            $Datum=new DateTime(isDate($R["DatRoj"]));
            echo "<td align='right'>" . $Datum->format('d.m.Y') . "</td>";
            echo "<td>". $R["Naslov"] ."</td>";
            echo "<td>". $R["Posta"] ."</td>";
            echo "<td>". $R["Kraj"] ."</td>";
            echo "<td>". $R["oce"] ."</td>";
            echo "<td>". $R["ocekontakt"] .", ".$R["oceGSM"]."</td>";
            echo "<td>". $R["mati"] ."</td>";
            echo "<td>". $R["matikontakt"] .", ".$R["matiGSM"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
    }else{
        echo "Vpišite vsaj tri znake!<br />";
    }
}
mysqli_close($link);
?>
