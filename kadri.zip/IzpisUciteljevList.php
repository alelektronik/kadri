<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis kadrov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

/*
$SQL = "SELECT tabucitelji.*, TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo, TabStatus.Status,TabIzobrazba.Opis FROM ";
$SQL = $SQL . "((TabVzgDelo INNER JOIN (TabDelo INNER JOIN tabucitelji ON TabDelo.IdDelo=tabucitelji.IdDelo) ON TabVzgDelo.IdVzgojnoDelo=tabucitelji.IdVzgojnoDelo)";
$SQL = $SQL . " INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus)";
$SQL = $SQL . " INNER JOIN TabIzobrazba ON tabucitelji.Izobrazba=TabIzobrazba.IdIzobrazba";
$SQL = $SQL . " WHERE tabucitelji.Status > 0 ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
*/
$SQL = "SELECT tabucitelji.*, TabStatus.Status,TabIzobrazba.Opis FROM ";
$SQL = $SQL . " (tabucitelji ";
$SQL = $SQL . " INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus)";
$SQL = $SQL . " INNER JOIN TabIzobrazba ON tabucitelji.Izobrazba=TabIzobrazba.IdIzobrazba";
$SQL = $SQL . " WHERE tabucitelji.Status > 0 ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
$result = mysqli_query($link,$SQL);

$Indx=1;

echo "<br>Spisek zaposlenih:<br />";
echo "<table border=1 cellspacing=0>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th><th>Datum Rojstva</th><th>Stopnja izobrazbe</th><th>Izobrazba</th>";
echo "</tr>";
$ColorChange=true;

while ($R = mysqli_fetch_array($result)){
	if ($ColorChange ){
		echo "<tr bgcolor=lightyellow>";
	}else{
		echo "<tr bgcolor=#FFFFCC>";
	}
	$ColorChange=!$ColorChange;
	echo "<td>".$Indx."</td>";
	echo "<td><a href='PopraviUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</a></td>";
    if (isDate($R["DatRoj"])){
        $Datum=new DateTime(isDate($R["DatRoj"]));
		echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
    }else{
        echo "<td align=right>Ni vneseno</td>";
    }
	echo "<td align=center>".$R["Opis"]."&nbsp;</td>";
	echo "<td>".$R["IzobOpis"]."&nbsp;</td>";
	echo "</tr>";
	$Indx=$Indx+1;
}
echo "</table>";

$result = mysqli_query($link,$SQL);
$Indx=0;
$CountBN=0;
$CountMentor=0;
$CountSvetovalec=0;
$CountSvetnik=0;
while ($R = mysqli_fetch_array($result)){
	if ($R["Svetnik"] != "" ){
		$CountSvetnik=$CountSvetnik+1;
	}else{
		if ($R["Svetovalec"] != "" ){
			$CountSvetovalec=$CountSvetovalec+1;
		}else{
			if ($R["Mentor"] != "" ){
				$CountMentor=$CountMentor+1;
			}else{
				if ($R["Izobrazba"] > 5 ){
					$CountBN=$CountBN+1;
				}
			}
		}
	}
	$Indx=$Indx+1;
}
echo "<br />";
echo "Svetniki: ".$CountSvetnik."<br />";
echo "Svetovalci: ".$CountSvetovalec."<br />";
echo "Mentorji: ".$CountMentor."<br />";
echo "Brez naziva: ".$CountBN."<br />";

$VMesec=$Danes->format('n');
$Vdan=$Danes->format('j');
$SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY month(DatRoj),day(DatRoj)";
$result = mysqli_query($link,$SQL);

echo "<br>Razvrščeni po mesecu in dnevu rojstva<br />";
echo "<table border=1 cellspacing=0>";
echo "<tr><th>Ime</th>";
echo "<th>Dat.roj.</th></tr>";
while ($R = mysqli_fetch_array($result)){
    $Datum=new DateTime(isDate($R["DatRoj"]));
	if ($VMesec==$Datum->format('n')) {
		if ($Vdan==$Datum->format('j')) {
			echo "<tr bgcolor='red'>";
		}else{
			echo "<tr bgcolor='lightgreen'>";
		}
	}else{
		echo "<tr>";
	}
	echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
	echo "<td align=right>".$Datum->format('j.n.Y')."</td>";
	echo "</tr>";
	$Indx=$Indx+1;
}
echo "</table>";

?>

</body>
</html>
