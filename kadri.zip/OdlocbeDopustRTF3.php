<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odločbe za dopuste
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

function To437($txt){
    $txt=str_replace("Č","^",$txt);
    $txt=str_replace("č","~",$txt);
    $txt=str_replace("Š","[",$txt);
    $txt=str_replace("š","{",$txt);
    $txt=str_replace("Ž","@",$txt);
    $txt=str_replace("ž","`",$txt);
    $txt=str_replace("Ć","]",$txt);
    $txt=str_replace("ć","}",$txt);
    $txt=str_replace("Đ","\\",$txt);
    $txt=str_replace("đ","|",$txt);
    return $txt;
}

$VFile="OdlocbeDopust.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti log datoteke!");

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VRavnatelj=$R["Ravnatelj"];
    $VKraj=$R["Kraj"];
    $VNaslov=$R["Naslov"];
    $VPosta=$R["Posta"]." ".$VKraj;
    $VidRavnatelj=$R["ravnatelj_ID"];
}else{
    $VSola=" ";
    $VRavnatelj=" ";
    $VKraj=" ";
    $VNaslov=" ";
    $VPosta=" ";
    $VidRavnatelj=0;
}

$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VidRavnatelj;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VRavnateljSpol=$R["Spol"];
}

fwrite ($fh,"{\\rtf1\\adeflang1025\\ansi\\ansicpg1250\\uc1\\adeff0\\deff0\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060\\themelang1060\\themelangfe0\\themelangcs0{\\fonttbl{\\f0\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f34\\fbidi \\froman\\fcharset1\\fprq2{\\*\\panose 02040503050406030204}Cambria Math;}"."\n");
fwrite ($fh,"{\\f37\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}{\\f38\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604030504040204}Tahoma;}{\\f39\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02050604050505020204}Bookman Old Style;}"."\n");
fwrite ($fh,"{\\flomajor\\f31500\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fdbmajor\\f31501\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\fhimajor\\f31502\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria;}{\\fbimajor\\f31503\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\flominor\\f31504\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fdbminor\\f31505\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\fhiminor\\f31506\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}{\\fbiminor\\f31507\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f43\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
fwrite ($fh,"{\\f42\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\f44\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f45\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f46\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
fwrite ($fh,"{\\f47\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\f48\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f49\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f413\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}"."\n");
fwrite ($fh,"{\\f412\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}{\\f414\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\f415\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}{\\f418\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}"."\n");
fwrite ($fh,"{\\f419\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\f423\\fbidi \\fswiss\\fcharset0\\fprq2 Tahoma;}{\\f422\\fbidi \\fswiss\\fcharset204\\fprq2 Tahoma Cyr;}{\\f424\\fbidi \\fswiss\\fcharset161\\fprq2 Tahoma Greek;}"."\n");
fwrite ($fh,"{\\f425\\fbidi \\fswiss\\fcharset162\\fprq2 Tahoma Tur;}{\\f426\\fbidi \\fswiss\\fcharset177\\fprq2 Tahoma (Hebrew);}{\\f427\\fbidi \\fswiss\\fcharset178\\fprq2 Tahoma (Arabic);}{\\f428\\fbidi \\fswiss\\fcharset186\\fprq2 Tahoma Baltic;}"."\n");
fwrite ($fh,"{\\f429\\fbidi \\fswiss\\fcharset163\\fprq2 Tahoma (Vietnamese);}{\\f430\\fbidi \\fswiss\\fcharset222\\fprq2 Tahoma (Thai);}{\\f433\\fbidi \\froman\\fcharset0\\fprq2 Bookman Old Style;}{\\f432\\fbidi \\froman\\fcharset204\\fprq2 Bookman Old Style Cyr;}"."\n");
fwrite ($fh,"{\\f434\\fbidi \\froman\\fcharset161\\fprq2 Bookman Old Style Greek;}{\\f435\\fbidi \\froman\\fcharset162\\fprq2 Bookman Old Style Tur;}{\\f438\\fbidi \\froman\\fcharset186\\fprq2 Bookman Old Style Baltic;}"."\n");
fwrite ($fh,"{\\flomajor\\f31510\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flomajor\\f31509\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\flomajor\\f31511\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}"."\n");
fwrite ($fh,"{\\flomajor\\f31512\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flomajor\\f31513\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\flomajor\\f31514\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
fwrite ($fh,"{\\flomajor\\f31515\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flomajor\\f31516\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fdbmajor\\f31520\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
fwrite ($fh,"{\\fdbmajor\\f31519\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbmajor\\f31521\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fdbmajor\\f31522\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
fwrite ($fh,"{\\fdbmajor\\f31523\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbmajor\\f31524\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fdbmajor\\f31525\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}"."\n");
fwrite ($fh,"{\\fdbmajor\\f31526\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhimajor\\f31530\\fbidi \\froman\\fcharset0\\fprq2 Cambria;}{\\fhimajor\\f31529\\fbidi \\froman\\fcharset204\\fprq2 Cambria Cyr;}"."\n");
fwrite ($fh,"{\\fhimajor\\f31531\\fbidi \\froman\\fcharset161\\fprq2 Cambria Greek;}{\\fhimajor\\f31532\\fbidi \\froman\\fcharset162\\fprq2 Cambria Tur;}{\\fhimajor\\f31535\\fbidi \\froman\\fcharset186\\fprq2 Cambria Baltic;}"."\n");
fwrite ($fh,"{\\fhimajor\\f31536\\fbidi \\froman\\fcharset163\\fprq2 Cambria (Vietnamese);}{\\fbimajor\\f31540\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fbimajor\\f31539\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
fwrite ($fh,"{\\fbimajor\\f31541\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbimajor\\f31542\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fbimajor\\f31543\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
fwrite ($fh,"{\\fbimajor\\f31544\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbimajor\\f31545\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fbimajor\\f31546\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}"."\n");
fwrite ($fh,"{\\flominor\\f31550\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flominor\\f31549\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\flominor\\f31551\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}"."\n");
fwrite ($fh,"{\\flominor\\f31552\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flominor\\f31553\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\flominor\\f31554\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
fwrite ($fh,"{\\flominor\\f31555\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flominor\\f31556\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fdbminor\\f31560\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
fwrite ($fh,"{\\fdbminor\\f31559\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbminor\\f31561\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fdbminor\\f31562\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
fwrite ($fh,"{\\fdbminor\\f31563\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbminor\\f31564\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fdbminor\\f31565\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}"."\n");
fwrite ($fh,"{\\fdbminor\\f31566\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhiminor\\f31570\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}{\\fhiminor\\f31569\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}"."\n");
fwrite ($fh,"{\\fhiminor\\f31571\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\fhiminor\\f31572\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}{\\fhiminor\\f31575\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}"."\n");
fwrite ($fh,"{\\fhiminor\\f31576\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\fbiminor\\f31580\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fbiminor\\f31579\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
fwrite ($fh,"{\\fbiminor\\f31581\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbiminor\\f31582\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fbiminor\\f31583\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
fwrite ($fh,"{\\fbiminor\\f31584\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbiminor\\f31585\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fbiminor\\f31586\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}}"."\n");
fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;"."\n");
fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;}{\\*\\defchp }{\\*\\defpap \\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 }\\noqfpromote {\\stylesheet{"."\n");
fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs22\\alang1025 \\ltrch\\fcs0 \\fs22\\lang1060\\langfe1033\\loch\\f37\\hich\\af37\\dbch\\af37\\cgrid\\langnp1060\\langfenp1033 "."\n");
fwrite ($fh,"\\snext0 \\sqformat \\spriority0 \\styrsid9308638 Normal;}{\\*\\cs10 \\additive \\ssemihidden \\spriority0 Default Paragraph Font;}{\\*"."\n");
fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\trcbpat1\\trcfpat1\\tblind0\\tblindtype3\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs20\\alang1025 \\ltrch\\fcs0 \\fs20\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext11 \\ssemihidden \\spriority0 Normal Table;}{\\*\\cs15 \\additive "."\n");
fwrite ($fh,"\\rtlch\\fcs1 \\af0\\afs16 \\ltrch\\fcs0 \\fs16 \\sbasedon10 \\ssemihidden \\spriority0 \\styrsid7237279 annotation reference;}{\\s16\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs20\\alang1025 \\ltrch\\fcs0 "."\n");
fwrite ($fh,"\\fs20\\lang1060\\langfe1033\\loch\\f37\\hich\\af37\\dbch\\af37\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext16 \\ssemihidden \\spriority0 \\styrsid7237279 annotation text;}{\\s17\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\rtlch\\fcs1 \\ab\\af0\\afs20\\alang1025 \\ltrch\\fcs0 \\b\\fs20\\lang1060\\langfe1033\\loch\\f37\\hich\\af37\\dbch\\af37\\cgrid\\langnp1060\\langfenp1033 \\sbasedon16 \\snext16 \\ssemihidden \\spriority0 \\styrsid7237279 annotation subject;}{"."\n");
fwrite ($fh,"\\s18\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af38\\afs16\\alang1025 \\ltrch\\fcs0 \\fs16\\lang1060\\langfe1033\\loch\\f38\\hich\\af38\\dbch\\af37\\cgrid\\langnp1060\\langfenp1033 "."\n");
fwrite ($fh,"\\sbasedon0 \\snext18 \\ssemihidden \\spriority0 \\styrsid7237279 Balloon Text;}}{\\*\\listtable{\\list\\listtemplateid-1981122626\\listhybrid{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelold\\levelspace0\\levelindent283"."\n");
fwrite ($fh,"{\\leveltext\\leveltemplateid-1498792368\\'03\\'00. ;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\b0\\i0\\f39\\fs20\\ulnone\\fbias0 \\fi-283\\li403\\lin403 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0"."\n");
fwrite ($fh,"{\\leveltext\\leveltemplateid-2076408324\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\b0\\i0\\fs20\\ulnone\\fbias0 \\fi-360\\li1440\\jclisttab\\tx1440\\lin1440 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'02.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li2160\\jclisttab\\tx2160\\lin2160 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li2880\\jclisttab\\tx2880\\lin2880 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li3600\\jclisttab\\tx3600\\lin3600 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li4320\\jclisttab\\tx4320\\lin4320 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li5040\\jclisttab\\tx5040\\lin5040 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'07.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li5760\\jclisttab\\tx5760\\lin5760 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1"."\n");
fwrite ($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'08.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li6480\\jclisttab\\tx6480\\lin6480 }{\\listname ;}\\listid1123041283}{\\list\\listtemplateid1826410986\\listhybrid"."\n");
fwrite ($fh,"{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'00.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li360\\jclisttab\\tx360\\lin360 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li1080\\jclisttab\\tx1080\\lin1080 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'02.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li1800\\jclisttab\\tx1800\\lin1800 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li2520\\jclisttab\\tx2520\\lin2520 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li3240\\jclisttab\\tx3240\\lin3240 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li3960\\jclisttab\\tx3960\\lin3960 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li4680\\jclisttab\\tx4680\\lin4680 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'07.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-360\\li5400\\jclisttab\\tx5400\\lin5400 }{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace360\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'08.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fi-180\\li6120\\jclisttab\\tx6120\\lin6120 }{\\listname "."\n");
fwrite ($fh,";}\\listid1874489466}}{\\*\\listoverridetable{\\listoverride\\listid1874489466\\listoverridecount0\\ls1}{\\listoverride\\listid1123041283\\listoverridecount0\\ls2}}{\\*\\pgptbl {\\pgp\\ipgp0\\itap0\\li0\\ri0\\sb0\\sa0}}{\\*\\rsidtbl \\rsid203504\\rsid918448\\rsid2182264"."\n");
fwrite ($fh,"\\rsid2577764\\rsid5464626\\rsid6842159\\rsid7221956\\rsid7237279\\rsid7630960\\rsid8077670\\rsid8992733\\rsid9308638\\rsid9702758\\rsid10313844\\rsid12010592}{\\mmathPr\\mmathFont34\\mbrkBin0\\mbrkBinSub0\\msmallFrac0\\mdispDef1\\mlMargin0\\mrMargin0\\mdefJc1\\mwrapIndent1440"."\n");
fwrite ($fh,"\\mintLim0\\mnaryLim1}{\\info{\\title Dopust}{\\author WINXP}{\\operator Kadri}{\\creatim\\yr2011\\mo11\\dy1\\hr13\\min36}{\\revtim\\yr2011\\mo11\\dy1\\hr13\\min36}{\\printim\\yr2011\\mo11\\dy1\\hr11\\min20}{\\version2}{\\edmins0}{\\nofpages1}{\\nofwords415}{\\nofchars2367}"."\n");
fwrite ($fh,"{\\nofcharsws2777}{\\vern49255}}{\\*\\xmlnstbl {\\xmlns1 http://schemas.microsoft.com/office/word/2003/wordml}}\\paperw11906\\paperh16838\\margl1418\\margr1134\\margt1134\\margb1418\\gutter0\\ltrsect "."\n");
fwrite ($fh,"\\deftab709\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\trackmoves0\\trackformatting1\\donotembedsysfont1\\relyonvml0\\donotembedlingdata0\\grfdocevents0\\validatexml1\\showplaceholdtext0\\ignoremixedcontent0\\saveinvalidxml0"."\n");
fwrite ($fh,"\\showxmlerrors1\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dgmargin\\dghspace187\\dgvspace180\\dghorigin1418\\dgvorigin1134\\dghshow1\\dgvshow2"."\n");
fwrite ($fh,"\\jexpand\\viewkind1\\viewscale100\\pgbrdrhead\\pgbrdrfoot\\splytwnine\\ftnlytwnine\\htmautsp\\nolnhtadjtbl\\useltbaln\\alntblind\\lytcalctblwd\\lyttblrtgr\\lnbrkrule\\nobrkwrptbl\\snaptogridincell\\allowfieldendsel\\wrppunct"."\n");
fwrite ($fh,"\\asianbrkrule\\nojkernpunct\\rsidroot10313844\\utinl \\fet0{\\*\\wgrffmtfilter 013f}\\ilfomacatclnup0\\ltrpar \\sectd \\ltrsect\\psz9\\linex0\\headery709\\footery709\\colsx708\\endnhere\\sectlinegrid360\\sectdefaultcl\\sectrsid918448\\sftnbj {\\*\\pnseclvl1"."\n");
fwrite ($fh,"\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5"."\n");
fwrite ($fh,"\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang "."\n");
fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 \\rtlch\\fcs1 \\af0\\afs22\\alang1025 "."\n");
fwrite ($fh,"\\ltrch\\fcs0 \\fs22\\lang1060\\langfe1033\\loch\\af37\\hich\\af37\\dbch\\af37\\cgrid\\langnp1060\\langfenp1033 "."\n");

    $SQL = "SELECT * FROM tabucitelji ";
    $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.Status < 10";
    $SQL = $SQL . " ORDER BY Priimek, Ime";
    //Response.Write "<br>" . SQL . "<br>"
    $result = mysqli_query($link,$SQL);

    $VLetoPregled=$VLeto;
    
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $oUcitelj = new RUcitelj;
        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
        /*
			ucitelji(Indx,0)=R("tabucitelji.IdUcitelj")
			ucitelji(Indx,1)=R("Ime")." ".R("Priimek")
			'ucitelji(Indx,2)=R("VzgojnoDelo")
			ucitelji(Indx,3)=day(R("DatRoj")).". ".Month(R("DatRoj")).". ".Year(R("DatRoj"))
			Dopust = R("TabDopust.DopustNaDD")+R("TabDopust.DopustNaIz")+R("TabDopust.DopustNaOt")+R("TabDopust.DopustNaSta")+R("TabDopust.DopustNaInv")+R("TabDopust.DopustNaVod")+R("TabDopust.DopustVzgoja")+R("DopustDelInv")+R("DopustPP")+R("Drugo")
			ucitelji(Indx,4)=Dopust
			ucitelji(Indx,5)=R("TabDopust.DopustNaDD")
			ucitelji(Indx,6)=R("TabDopust.DopustNaIz")
			ucitelji(Indx,7)=R("TabDopust.DopustNaVod")
			ucitelji(Indx,8)=R("TabDopust.DopustNaOt")
			ucitelji(Indx,9)=R("TabDopust.DopustNaInv")
			ucitelji(Indx,10)=R("TabDopust.DopustNaSta")
			ucitelji(Indx,11)=R("TabDopust.DopustVzgoja")
			ucitelji(Indx,12)=R("spol")
			ucitelji(Indx,13)=R("TabDopust.DelDobaLet")
			select case R("Status")
				case 1,2
					ucitelji(Indx,14)="nedolo?en ?as"
				case else 
					ucitelji(Indx,14)="dolo?en ?as"
			end select
			ucitelji(Indx,15)=R("TabDopust.DopustStari")
			ucitelji(Indx,16)=R("DopustDelInv")
			ucitelji(Indx,17)=R("DopustPP")
			ucitelji(Indx,18)=R("Drugo")
			ucitelji(Indx,19)=R("Delez")
'			response.write (Ucitelji(Indx,1)."<br>")

			'prebere podatke iz pogodb
			SQL = "SELECT tabpogodbe.*, TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo FROM "
			SQL = SQL ."((tabpogodbe LEFT JOIN TabDelo ON tabpogodbe.IdDelo=TabDelo.IdDelo) "
			SQL = SQL ."INNER JOIN TabVzgDelo ON tabpogodbe.IdVzgojnoDelo=TabVzgDelo.IdVzgojnoDelo) "
			SQL = SQL . "WHERE idUcitelj=".R("tabucitelji.idUcitelj")
			set R1 = conn.execute(SQL,,adcmdtext)
			i=0
			Do
				if NOT R1.EOF then
					i=i+1 'upo?teva le pogodbe za aktualno leto
					
					DatumEnd(i)=R1("DatumEnd")
					if isNull(DatumEnd(i)) then
						DatumEnd(i)="1.1.".VLetoPregled+1
					end if
					if NOT isDate(DatumEnd(i)) then
						DatumEnd(i)="1.1.".VLetoPregled+1
					end if
					DatumStart(i)=R1("DatumStart")
					if isNull(DatumStart(i)) then
						DatumStart(i)="1.1.".VletoPregled
					end if
					if NOT isDate(DatumStart(i)) then
						DatumStart(i)="1.1.".VLetoPregled
					end if
					
					'pripravi le aktualne pogodbe (veljavne za to leto)
					if (VLetoPregled <= year(DatumEnd(i))) and (VLetoPregled >= year(DatumStart(i))) then
						NazivDelMesta(i)=R1("NazivDelMesta")
					else
						i=i-1
					end if
				else
					Exit Do
				end if
				R1.MoveNext
			Loop
			StPogodb=i

			Ucitelji(indx,2)=""
			if StPogodb > 0 then
				for i=1 to StPogodb
					if i=1 then
						Ucitelji(indx,2)=NazivDelMesta(i)
					else
						enak=0
						for i1=1 to i-1
							if NazivDelMesta(i) = NazivDelMesta(i1) then
								enak=enak+1
							end if
						next
						if enak = 0 then
							Ucitelji(indx,2)=Ucitelji(indx,2).", ".NazivDelMesta(i)
						end if
					end if
				next
			end if
			
	    else
	        Exit Do
	    End If
				Indx=Indx+1
	    R.MoveNext
	Loop
	StUciteljev=Indx

	Dim IndxUcitelj
	Dim Indx1
	
	for IndxUcitelj=0 to StUciteljev-1
         */
		$Indx1=0;
		//'zakonska podlaga in naslov
		fwrite ($fh,"{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\f39\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 N}{\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 a podlagi 49. \\'e8lena Zakona o organizaciji in financiranju vzgoje in izobra\\'9eevanja \\endash "."\n");
		fwrite ($fh," ZOFVI-UPB5 (Ur.l.RS 16/2007 in spremembe), v skladu z Zakonom o delovnih razmerjih (Ur.l. RS, \\'9at. 42/02}{\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 , 103/07}{\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  in spremembe) ter v skladu s Kolektivno pogodbo za dejavnost vzgoje in izobra\\'9eevanja (Ur.l. RS, \\'9at. 52/94}{\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 , 49/95, 34/96}{\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  in spremembe) izdajam"."\n");
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs24 \\ltrch\\fcs0 \\b\\f38\\fs24\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs24 \\ltrch\\fcs0 \\b\\f38\\fs24\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 OBVESTIL}{\\rtlch\\fcs1 "."\n");
		fwrite ($fh,"\\af38\\afs24 \\ltrch\\fcs0 \\b\\f38\\fs24\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 O O LETNEM  DOPUSTU ZA LETO ".$VLeto."}{\\rtlch\\fcs1 \\af38\\afs24 \\ltrch\\fcs0 \\b\\f38\\fs24\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par IN  NJEGOVI  IZRABI"."\n");
		fwrite ($fh,"\\par "."\n");
		fwrite ($fh,"\\par }"."\n");

        $Datum=$oUcitelj->getDatRoj();
        switch ($oUcitelj->getStatus()){
            case 0:
                $Status="ni več zaposlen";
                break;
            case 1:
            case 2:
                $Status="nedoločen čas";
                break;
            case 3:
            case 4:
            case 5:
                $Status="določen čas";
                break;
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                $Status="nedefinirano";
        }
		
		//'delavec, datroj, delovno mesto, dni dopusta
		if ($oUcitelj->getSpol() =="M") {
            fwrite ($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\fi-709\\li709\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin709\\itap0\\pararsid1451694 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694 1.\\tab }{");
            fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Delavcu, }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".ToRTF($oUcitelj->getIme()." ".$oUcitelj->getPriimek())."}{\\rtlch\\fcs1 ");
            fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 , rojenemu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('d')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 . }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('m')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('Y')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,  zaposlenemu na delovnem  mestu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ".ToRTF($oUcitelj->getDelMesto())."}{");
            fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638  pripada }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 ".$oUcitelj->getDopust()."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  dni letnega dopusta. ");
            fwrite ($fh,"\\par }");
/*            
            
			fwrite ($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par {\\listtext\\pard\\plain\\ltrpar \\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\insrsid9308638\\charrsid4216459 \\hich\\af38\\dbch\\af0\\loch\\f38 1.\\tab}}\\pard \\ltrpar\\ql \\fi-360\\li360\\ri0\\sl360\\slmult1\\widctlpar"."\n");
			fwrite ($fh,"\\jclisttab\\tx360\\wrapdefault\\aspalpha\\aspnum\\faauto\\ls1\\adjustright\\rin0\\lin360\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Delavcu, }{\\rtlch\\fcs1 \\af38\\afs18 "."\n");
			fwrite ($fh,"\\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".ToRTF($oUcitelj->getIme()." ".$oUcitelj->getPriimek())."}"."\n");
			fwrite ($fh,"{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 , rojenemu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('d')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 . }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('m')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('Y')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,  zaposlenemu na delovnem  mestu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ".ToRTF($oUcitelj->getDelMesto())."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638  pripada }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 ".$oUcitelj->getDopust()."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  dni letnega dopusta. "."\n");
			fwrite ($fh,"\\par "."\n");
            */
		}else{
            
            fwrite ($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\fi-709\\li709\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin709\\itap0\\pararsid1451694 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694 1.\\tab }{");
            fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Delavki, }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".ToRTF($oUcitelj->getIme()." ".$oUcitelj->getPriimek())."}{\\rtlch\\fcs1 ");
            fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 , rojeni }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('d')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 . }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('m')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('Y')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,  zaposleni na delovnem  mestu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ".ToRTF($oUcitelj->getDelMesto())."}{");
            fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638  pripada }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 ".$oUcitelj->getDopust()."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  dni letnega dopusta. ");
            fwrite ($fh,"\\par }");

/*            
			fwrite ($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par {\\listtext\\pard\\plain\\ltrpar \\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\insrsid9308638\\charrsid4216459 \\hich\\af38\\dbch\\af0\\loch\\f38 1.\\tab}}\\pard \\ltrpar\\ql \\fi-360\\li360\\ri0\\sl360\\slmult1\\widctlpar"."\n");
			fwrite ($fh,"\\jclisttab\\tx360\\wrapdefault\\aspalpha\\aspnum\\faauto\\ls1\\adjustright\\rin0\\lin360\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Delavki, }{\\rtlch\\fcs1 \\af38\\afs18 "."\n");
			fwrite ($fh,"\\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".ToRTF($oUcitelj->getIme()." ".$oUcitelj->getPriimek())."}"."\n");
			fwrite ($fh,"{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 , rojeni }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('d')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 . }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('m')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ".$Datum->format('Y')."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,  zaposleni na delovnem  mestu }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ".ToRTF($oUcitelj->getDelMesto())."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 ,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638  pripada }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
			fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 ".$oUcitelj->getDopust()."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  dni letnega dopusta. "."\n");
			fwrite ($fh,"\\par "."\n");
            */
		}

        fwrite ($fh,"{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694 2.\\tab }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Letni dopust koristi }{\\rtlch\\fcs1 ");
        fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 praviloma v \\'e8asu poletnih, jesenskih, novol}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 ");
        fwrite ($fh,"etnih,  zimskih in}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  prvomajskih }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 po\\'e8");
        fwrite ($fh,"itnic .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694  }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 Do 31.8.}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
        fwrite ($fh,"\\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956\\charrsid7221956 2013}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459   lahko koristi neizkori\\'9a\\'e8eni }{\\rtlch\\fcs1 ");
        fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 del letnega dopusta za leto }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956\\charrsid7221956 2012}{\\rtlch\\fcs1 ");
        fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7221956 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  ");
        if ($oUcitelj->getSpol() =="M") {
            fwrite ($fh,"Poleg letnega dopusta delavec lahko koristi tudi ure v dobrem, ki jih je opravil na delovnem mestu izven rednega dela. ");
            fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694 3.\\tab }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 ");
            fwrite ($fh,"Delavec ima pravico 2 dneva letnega dopusta iz 1. to\\'e8ke tega obvestila izrabiti na tista dneva, ki ju sam dolo\\'e8i,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670  }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 pri \\'e8emer mora o tem obvestiti ravnatelja oz. poobla\\'9a\\'e8eno osebo najmanj 3 delovne dni pred izrabo.");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Obrazlo\\'9eitev"."\n");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
            fwrite ($fh,"\\par Kriteriji za dolo\\'e8itev letnega dopusta so opredeljeni v Zakonu o delovnih razmerjih in kolektivni pogodbi za vzgojo in izobra\\'9eevanje. "."\n");
            fwrite ($fh,"Delavcu v skladu z zakonom in na podlagi osnov in meril v kolektivni pogodbi in glede na njegovo izpolnjevanje pogojev za dolo\\'e8itev obsega letnega dopusta za koledarsko leto pripada:"."\n");
            fwrite ($fh,"\\par }"."\n");
        }else{
            fwrite ($fh,"Poleg letnega dopusta delavka lahko koristi tudi ure v dobrem, ki jih je opravila na delovnem mestu izven rednega dela. ");
            fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid1451694 3.\\tab }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 ");
            fwrite ($fh,"Delavka ima pravico 2 dneva letnega dopusta iz 1. to\\'e8ke tega obvestila izrabiti na tista dneva, ki ju sama dolo\\'e8i,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670  }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 ");
            fwrite ($fh,"\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 pri \\'e8emer mora o tem obvestiti ravnatelja oz. poobla\\'9a\\'e8eno osebo najmanj 3 delovne dni pred izrabo.");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Obrazlo\\'9eitev"."\n");
            fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
            fwrite ($fh,"\\par Kriteriji za dolo\\'e8itev letnega dopusta so opredeljeni v Zakonu o delovnih razmerjih in kolektivni pogodbi za vzgojo in izobra\\'9eevanje. "."\n");
            fwrite ($fh,"Delavki v skladu z zakonom in na podlagi osnov in meril v kolektivni pogodbi in glede na njegovo/njeno izpolnjevanje pogojev za dolo\\'e8itev obsega letnega dopusta za koledarsko leto pripada:"."\n");
            fwrite ($fh,"\\par }"."\n");
        }

		/*
		//'2. in 3. to?ka - pojasnilo o kori??enju, obrazlo?itev
		fwrite ($fh,"{\\listtext\\pard\\plain\\ltrpar \\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\insrsid9308638\\charrsid4216459 \\hich\\af38\\dbch\\af0\\loch\\f38 2.\\tab}Letni dopust koristi }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 praviloma v \\'e8asu poletnih, jesenskih, novol}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 etnih,  zimskih in}{\\rtlch\\fcs1 "."\n");
		fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  prvomajskih }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 po\\'e8itnic .}{\\rtlch\\fcs1 \\af38\\afs18 "."\n");
		fwrite ($fh,"\\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\fi360\\li0\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 Do 31.8.}{\\rtlch\\fcs1 "."\n");
		fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956\\charrsid7221956 ".($VLeto+1)."}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459   lahko koristi neizkori\\'9a\\'e8eni "."\n");
		fwrite ($fh,"}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956 del letnega dopusta za leto }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid7221956\\charrsid7221956 ".$VLeto."}{"."\n");
		fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7221956 .}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  "."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li360\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin360\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");

		if ($oUcitelj->getSpol() =="M") {
			fwrite ($fh,"Poleg letnega dopusta delavec lahko koristi tudi ure v dobrem, ki jih je opravil na delovnem mestu izven rednega dela. "."\n");
			fwrite ($fh,"\\par "."\n");
			fwrite ($fh,"{\\listtext\\pard\\plain\\ltrpar \\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\insrsid9308638\\charrsid8077670 \\hich\\af38\\dbch\\af0\\loch\\f38 3.\\tab}}\\pard \\ltrpar\\ql \\fi-360\\li360\\ri0\\sl360\\slmult1\\widctlpar"."\n");
			fwrite ($fh,"\\jclisttab\\tx360\\wrapdefault\\aspalpha\\aspnum\\faauto\\ls1\\adjustright\\rin0\\lin360\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 "."\n");
			fwrite ($fh,"Delavec ima pravico 2 dneva letnega dopusta iz 1. to\\'e8ke tega obvestila izrabiti na tista dneva, ki ju sam dolo\\'e8i,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670  }{\\rtlch\\fcs1 \\af38\\afs18 "."\n");
			fwrite ($fh,"\\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 pri \\'e8emer mora o tem obvestiti ravnatelja oz. poobla\\'9a\\'e8eno osebo najmanj 3 delovne dni pred izrabo."."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Obrazlo\\'9eitev"."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par Kriteriji za dolo\\'e8itev letnega dopusta so opredeljeni v Zakonu o delovnih razmerjih in kolektivni pogodbi za vzgojo in izobra\\'9eevanje. "."\n");
			fwrite ($fh,"Delavcu v skladu z zakonom in na podlagi osnov in meril v kolektivni pogodbi in glede na njegovo izpolnjevanje pogojev za dolo\\'e8itev obsega letnega dopusta za koledarsko leto pripada:"."\n");
			fwrite ($fh,"\\par }"."\n");
		}else{
			fwrite ($fh,"Poleg letnega dopusta delavka lahko koristi tudi ure v dobrem, ki jih je opravil na delovnem mestu izven rednega dela. "."\n");
			fwrite ($fh,"\\par "."\n");
			fwrite ($fh,"{\\listtext\\pard\\plain\\ltrpar \\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\insrsid9308638\\charrsid8077670 \\hich\\af38\\dbch\\af0\\loch\\f38 3.\\tab}}\\pard \\ltrpar\\ql \\fi-360\\li360\\ri0\\sl360\\slmult1\\widctlpar"."\n");
			fwrite ($fh,"\\jclisttab\\tx360\\wrapdefault\\aspalpha\\aspnum\\faauto\\ls1\\adjustright\\rin0\\lin360\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 "."\n");
			fwrite ($fh,"Delavka ima pravico 2 dneva letnega dopusta iz 1. to\\'e8ke tega obvestila izrabiti na tista dneva, ki ju sama dolo\\'e8i,}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670  }{\\rtlch\\fcs1 \\af38\\afs18 "."\n");
			fwrite ($fh,"\\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid8077670 pri \\'e8emer mora o tem obvestiti ravnatelja oz. poobla\\'9a\\'e8eno osebo najmanj 3 delovne dni pred izrabo."."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\b\\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Obrazlo\\'9eitev"."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par Kriteriji za dolo\\'e8itev letnega dopusta so opredeljeni v Zakonu o delovnih razmerjih in kolektivni pogodbi za vzgojo in izobra\\'9eevanje. "."\n");
			fwrite ($fh,"Delavki v skladu z zakonom in na podlagi osnov in meril v kolektivni pogodbi in glede na njegovo/njeno izpolnjevanje pogojev za dolo\\'e8itev obsega letnega dopusta za koledarsko leto pripada:"."\n");
			fwrite ($fh,"\\par }"."\n");
		}
		*/
		//'rubrike dopustov
		fwrite ($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\tqr\\tldot\\tx8505\\tx8647\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8077670 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 - za }{\\rtlch\\fcs1 "."\n");
		fwrite ($fh,"\\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 ".$oUcitelj->getDelDobaLet()." }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 let delovne dobe \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 "."\n");
		fwrite ($fh,"\\hich\\af37\\dbch\\af37\\loch\\f37 ".$oUcitelj->getDopustNaDD()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - stopnja izobrazbe, ki se zahteva za delovno mesto \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 ".$oUcitelj->getDopustNaIz()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 "."\n");
		fwrite ($fh,"\\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - za zahtevnost/vodenje \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustNaVod()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 \\hich\\f37 - na otroke (materi otroka do 7. leta starosti: 2 dni, star\\'9a\\loch\\f37 evstvo otroka do 15. leta starosti: 1 dan) \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 ".$oUcitelj->getDopustNaOt()."\n");
		fwrite ($fh,"}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 \\hich\\f37 - strokovnim delavcem v vzgoji in izobra\\'9e\\loch\\f37 evanju 1 dan \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 ".$oUcitelj->getDopustVzgoja()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - invalidu II. in III. kategorije 3 dni \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustNaInv()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - delovnemu invalidu in delavcu z najmanj 60% telesno okvaro 5 dni \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustDelInv()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  "."\n");
		fwrite ($fh,"\\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - za dopolnjenih 50 let starosti \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustNaSta()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - za delo v VIZ s prilagojenim\\hich\\af37\\dbch\\af37\\loch\\f37 i programi (3/5/10 dni) \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustPP()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 "."\n");
		fwrite ($fh,"\\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par \\hich\\af37\\dbch\\af37\\loch\\f37 - drugo \\tab }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 ".$oUcitelj->getDopustDrugo()."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37  \\tab dni"."\n");
		
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 SKUPAJ DNI DOPUSTA \\tab ".$oUcitelj->getDopust()." \\tab dni}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 "."\n");
		
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\ab\\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8077670 \\hich\\af37\\dbch\\af37\\loch\\f37 Prenos dopusta iz preteklega leta \\tab ".$oUcitelj->getDopustStari()." \\tab dni}"."\n");

		//'pravni pouk
		if ($oUcitelj->getSpol() =="M") {
			fwrite ($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Pravni pouk:"."\n");
			fwrite ($fh,"\\par \\'c8e delavec meni, da je delodajalec z izdajo tega obvestila kr\\'9ail katero od njegovih pravic iz delovnega razmerja, ima pravico pisno zahtevati, da delodajalec v roku 8 delovnih dni od vro\\'e8itve pisne zahteve delavca kr\\'9a"."\n");
			fwrite ($fh,"itev odpravi. \\'c8e se delavec z odgovorom ne strinja ali ga ne dobi, lahko v nadaljnjem roku 8 dni vlo\\'9ei prito\\'9ebo na svet zavoda ali v roku 30 dni zahteva sodno varstvo pred pristojnim sodi\\'9a\\'e8em."."\n");
			fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par "."\n");
			fwrite ($fh,"\\par }"."\n");
		}else{
			fwrite ($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8077670 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\sl360\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs14 \\ltrch\\fcs0 \\f38\\fs14\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Pravni pouk:"."\n");
			fwrite ($fh,"\\par \\'c8e delavka meni, da je delodajalec z izdajo tega obvestila kr\\'9ail katero od njenih pravic iz delovnega razmerja, ima pravico pisno zahtevati, da delodajalec v roku 8 delovnih dni od vro\\'e8itve pisne zahteve delavke kr\\'9a"."\n");
			fwrite ($fh,"itev odpravi. \\'c8e se delavka z odgovorom ne strinja ali ga ne dobi, lahko v nadaljnjem roku 8 dni vlo\\'9ei prito\\'9ebo na svet zavoda ali v roku 30 dni zahteva sodno varstvo pred pristojnim sodi\\'9a\\'e8em."."\n");
			fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
			fwrite ($fh,"\\par "."\n");
			fwrite ($fh,"\\par }"."\n");
		}

		//'podpisi, datum
		fwrite ($fh,"{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 \\'8at.:}{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638  }{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\b\\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ");
		if ($RefStFix <> ""){
			fwrite ($fh,$RefStFix."-".$RefStVar."/".$VLeto);
			$RefStVar=$RefStVar+1;
		}else{
			fwrite ($fh," ");
		}
		fwrite ($fh,"}{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  "."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\tqc\\tx7088\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8077670 {\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Datum}{"."\n");
		fwrite ($fh,"\\rtlch\\fcs1 \\af38\\afs20 \\ltrch\\fcs0 \\f38\\fs20\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid16716954 : }{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\b\\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid7237279 ");
		fwrite ($fh,ToRTF($VKraj.", ".$PrintDay));
		fwrite ($fh,"}{\\rtlch\\fcs1 "."\n");
		fwrite ($fh,"\\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638 \\tab }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459  "."\n");
		if ($VRavnateljSpol=="M"){
			fwrite ($fh,"Ravnatelj");
		}else{
			fwrite ($fh,"Ravnateljica");
		}
		fwrite ($fh,"\\par \\tab  ".$VRavnatelj."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid9308638 {\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par "."\n");
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 Vro\\'e8iti:"."\n");
		if ($oUcitelj->getSpol() =="M") {
			fwrite ($fh,"\\par - delavcu"."\n");
		}else{
			fwrite ($fh,"\\par - delavki"."\n");
		}
		fwrite ($fh,"\\par - obra\\'e8un OD"."\n");
		fwrite ($fh,"\\par - personalna mapa"."\n");
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par "."\n");
		if ($oUcitelj->getSpol() =="M") {
			fwrite ($fh,"\\par Delavec__________________________________"."\n");
		}else{
			fwrite ($fh,"\\par Delavka__________________________________"."\n");
		}
		fwrite ($fh,"\\par potrjujem prejem tega obvestila dne, }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid8077670 ____________}{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 "."\n");
		fwrite ($fh,"\\f38\\fs18\\ul\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af38\\afs18 \\ltrch\\fcs0 \\f38\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 s svojim podpisom: ___________________________"."\n");
		fwrite ($fh,"\\par }"."\n");

		//'zaklju?ek strani
		fwrite ($fh,"{\\rtlch\\fcs1 \\af0\\afs18 \\ltrch\\fcs0 \\f39\\fs18\\lang1060\\langfe1060\\langfenp1060\\insrsid9308638\\charrsid4216459 "."\n");
		fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
		fwrite ($fh,"{\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\insrsid2646690 \\page }"."\n");
		fwrite ($fh,"{\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\insrsid9702758 "."\n");
		fwrite ($fh,"\\par }"."\n");
	}	
	
	//'zaklju?ek dokumenta
	fwrite ($fh,"{\\*\\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a"."\n");
	fwrite ($fh,"9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad"."\n");
	fwrite ($fh,"5689811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6"."\n");
	fwrite ($fh,"b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0"."\n");
	fwrite ($fh,"0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6"."\n");
	fwrite ($fh,"a7e7c0000000360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f"."\n");
	fwrite ($fh,"c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b6309512"."\n");
	fwrite ($fh,"0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462"."\n");
	fwrite ($fh,"a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865"."\n");
	fwrite ($fh,"6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b"."\n");
	fwrite ($fh,"4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b"."\n");
	fwrite ($fh,"4757e8d3f729e245eb2b260a0238fd010000ffff0300504b0304140006000800000021008c12afcaae060000a91b0000160000007468656d652f7468656d652f"."\n");
	fwrite ($fh,"7468656d65312e786d6cec594d6f1b4518be23f11f467b6f6327761a4775aad8b11b48d346b15bd4e37877bc3bcdecce6a669cd437d41e9190100571a012370e"."\n");
	fwrite ($fh,"08a8d44a5ccaaf09144191fa1778676677bd13af49d24650417d48bcb3cffbfd31ef8caf5ebb1f33744884a43c697bf5cb350f91c4e7014dc2b6777bd8bfb4e6"."\n");
	fwrite ($fh,"21a9701260c613d2f6a6447ad736de7fef2a5e5711890902fa44aee3b6172995ae2f2d491f96b1bccc5392c0bb31173156f028c2a540e023e01bb3a5e55a6d75"."\n");
	fwrite ($fh,"29c634f1508263607b6b3ca63ee1871829a0f63672f63d06321225f582cfc440332719cd1e955824161c1cd435444e659709748859db0351013f1a92fbca430c"."\n");
	fwrite ($fh,"4b052fda5ecd7cbca58dab4b783d23626a016d89ae6f3e195d46101c2c1b99221c1542ebfd46ebca56c1df00989ac7f57abd6eaf5ef03300ecfb60aad5a5ccb3"."\n");
	fwrite ($fh,"d15fab77729e2590fd3acfbb5b6bd61a2ebec47f654ee756a7d369b6325d2c5303b25f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8e257e7f0"."\n");
	fwrite ($fh,"fd2badd5868b37a088d1e4600ead03daef67dc0bc898b3ed4af81ac0d76a197c86826c28d24b8b18f3442d4cb618dfe3a20f088d6458d104a9694ac6d8874cee"."\n");
	fwrite ($fh,"e2782428d612f03a817c2eded8255fce2d696148fa82a6aaed7d9862a88a19d5abe7dfbf7afe141d3f7876fce0a7e3870f8f1ffc68193954db3809cb542fbffd"."\n");
	fwrite ($fh,"eccfc71fa33f9e7ef3f2d117d57859c6fffac327bffcfc793510ea67a6ce8b2f9ffcf6ecc98baf3efdfdbb4715f04d814765f890c644a29be408edf3180c335e"."\n");
	fwrite ($fh,"71352723713e8a61846999623309254eb09652c1bfa722077d738a59161d478f0e713d784740ffa8025e9fdc73141e4462a26885e49d287680bb9cb30e17955e"."\n");
	fwrite ($fh,"d8d1b24a6e1e4e92b05ab8989471fb181f56c9eee2c4896f6f9242e7ccd3d231bc1b1147cd3d86138543921085f43b7e40488575772975fcba4b7dc1251f2b74"."\n");
	fwrite ($fh,"97a20ea6952e19d291934d33a26d1a435ca6553643bc1ddfecde411dceaaacde22872e12aa02b30ae58784396ebc8e270ac7552c8738666587dfc02aaa527230"."\n");
	fwrite ($fh,"157e19d7930a221d12c6512f205256d1dc12606f29e83b185a5665d877d934769142d1832a9e3730e765e4163fe846384eabb0039a4465ec07f2005214a33dae"."\n");
	fwrite ($fh,"aae0bbdcad10fd0c71c0c9c270dfa1c409f7e9dde0360d1d956609a2df4c44452caf13eee4ef60cac6989856035ddde9d5314dfeae71330a9ddb4ab8b8c60dad"."\n");
	fwrite ($fh,"f2c5d78f2bf47e5b5bf626ec5e5535b37da2512fc29d6ccf5d2e02faf677e72d3c49f60814c4fc16f5ae39bf6bcede7fbe392faae78b6fc9b32e0c0d5acf2276"."\n");
	fwrite ($fh,"d2367377bc78ec1e53c6066acac80d69266f099b4fd087454d688e9da43887a5117cd5a50c121c5c28b0a14182ab8fa88a06114e616aaf7b9a492833d6a14429"."\n");
	fwrite ($fh,"97705c34cb95bc351e267f650f9b4d7d0cb1ad4362b5cb03bbbca297f3d346c1c668159a336d2e68453338abb0952b1953b0ed7584d5b55267965637aa99aee8"."\n");
	fwrite ($fh,"482b4cd62e36e7727079611a2c16de84a906c12c045e5e8583bf160da71dcc48a0fd6e639487c544e1224324231c902c46daeef918d54d90f25c993344db6193"."\n");
	fwrite ($fh,"411f1d4ff15a495a4bb37d0369670952595c6381b83c7a6f12a53c836751026e27cb9125e5e264093a6a7bade672d3433e4edbde180ecaf0354e21ea520f9298"."\n");
	fwrite ($fh,"8570e3e42b61d3fed46236553e8b662b37cc2d823a5c7e58bfcf19ecf4815448b585656453c3bcca5280255a92d57fb9096ebd28032abad1d9b458598364f8d7"."\n");
	fwrite ($fh,"b4003fbaa125e331f15539d8a515ed3bfb98b5523e51440ca2e0088dd844ec6308bf4e55b027a012ee3b4c47d00f703ba7bd6d5eb9cd392bbaf29d98c1d975cc"."\n");
	fwrite ($fh,"d20867ed5697685ec9166e1a52a183792aa907b655ea6e8c3bbf29a6e42fc894721affcf4cd1fb095c3fac043a023edc0f0b8c74a5b43d2e54c4a10ba511f5fb"."\n");
	fwrite ($fh,"022607d33b205be086175e4352c12db5f92fc8a1fe6f6bcef230650da748b54f432428ec472a1284ec415b32d9770ab37ab67759962c636432aaa4ae4cadda23"."\n");
	fwrite ($fh,"7248d850f7c055bdb77b28825437dd246b03067732ffdce7ac8246a11e72caf5e674b262efb535f04f4f3eb698c128b70f9b8126f77fa162311ecc76554b6fc8"."\n");
	fwrite ($fh,"f3bdb76c887e311bb31a795580b0d256d0cacafe355538e7566b3bd69cc5cbcd5c3988e2bcc5b0580c44295c2221fd07f63f2a7c464c1aeb0d75c8f7a1b722f8"."\n");
	fwrite ($fh,"f9423383b481acbe64070fa41ba45d1cc1e064176d326956d6b5d9e8a4bd966fd6173ce916724f385b6b7696789fd3d9c570e68a736af1229d9d79d8f1b55d5b"."\n");
	fwrite ($fh,"e86a88ecc91285a5717e92318131bf95957fcce2a37b10e82df8d160c29434c904bf54090c33f4c0d40114bf95684837fe020000ffff0300504b030414000600"."\n");
	fwrite ($fh,"0800000021000dd1909fb60000001b010000270000007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d"."\n");
	fwrite ($fh,"0ac2301484f78277086f6fd3ba109126dd88d0add40384e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec"."\n");
	fwrite ($fh,"8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524"."\n");
	fwrite ($fh,"bd62107bd5001996509affb3fd381a89672f1f165dfe514173d9850528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000"."\n");
	fwrite ($fh,"002100e9de0fbfff0000001c0200001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d00140006000800"."\n");
	fwrite ($fh,"00002100a5d6a7e7c0000000360100000b00000000000000000000000000300100005f72656c732f2e72656c73504b01022d00140006000800000021006b7996"."\n");
	fwrite ($fh,"16830000008a0000001c00000000000000000000000000190200007468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d00140006"."\n");
	fwrite ($fh,"000800000021008c12afcaae060000a91b00001600000000000000000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d"."\n");
	fwrite ($fh,"00140006000800000021000dd1909fb60000001b0100002700000000000000000000000000b80900007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000b30a00000000}"."\n");
	fwrite ($fh,"{\\*\\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d"."\n");
	fwrite ($fh,"617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169"."\n");
	fwrite ($fh,"6e22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363"."\n");
	fwrite ($fh,"656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}"."\n");
	fwrite ($fh,"{\\*\\latentstyles\\lsdstimax267\\lsdlockeddef0\\lsdsemihiddendef1\\lsdunhideuseddef1\\lsdqformatdef0\\lsdprioritydef99{\\lsdlockedexcept \\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority0 \\lsdlocked0 Normal;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 1;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 2;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 3;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 4;"."\n");
	fwrite ($fh,"\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 5;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 6;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 7;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 8;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 9;"."\n");
	fwrite ($fh,"\\lsdpriority39 \\lsdlocked0 toc 1;\\lsdpriority39 \\lsdlocked0 toc 2;\\lsdpriority39 \\lsdlocked0 toc 3;\\lsdpriority39 \\lsdlocked0 toc 4;\\lsdpriority39 \\lsdlocked0 toc 5;\\lsdpriority39 \\lsdlocked0 toc 6;\\lsdpriority39 \\lsdlocked0 toc 7;"."\n");
	fwrite ($fh,"\\lsdpriority39 \\lsdlocked0 toc 8;\\lsdpriority39 \\lsdlocked0 toc 9;\\lsdqformat1 \\lsdpriority35 \\lsdlocked0 caption;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority10 \\lsdlocked0 Title;\\lsdpriority1 \\lsdlocked0 Default Paragraph Font;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority11 \\lsdlocked0 Subtitle;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority22 \\lsdlocked0 Strong;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority20 \\lsdlocked0 Emphasis;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority59 \\lsdlocked0 Table Grid;\\lsdunhideused0 \\lsdlocked0 Placeholder Text;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority1 \\lsdlocked0 No Spacing;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 1;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 1;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 1;\\lsdunhideused0 \\lsdlocked0 Revision;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority34 \\lsdlocked0 List Paragraph;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority29 \\lsdlocked0 Quote;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority30 \\lsdlocked0 Intense Quote;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 1;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 1;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 2;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 3;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 3;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 3;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 3;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 3;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 4;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 4;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 4;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 4;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 5;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 5;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 5;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 5;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 5;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 6;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 6;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 6;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 6;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 6;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority19 \\lsdlocked0 Subtle Emphasis;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority21 \\lsdlocked0 Intense Emphasis;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority31 \\lsdlocked0 Subtle Reference;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority32 \\lsdlocked0 Intense Reference;"."\n");
	fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority33 \\lsdlocked0 Book Title;\\lsdpriority37 \\lsdlocked0 Bibliography;\\lsdqformat1 \\lsdpriority39 \\lsdlocked0 TOC Heading;}}{\\*\\datastore 010500000200000018000000"."\n");
	fwrite ($fh,"4d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000"."\n");
	fwrite ($fh,"d0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"fffffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
	fwrite ($fh,"ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072007900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e5000000000000000000000000102f"."\n");
	fwrite ($fh,"3de99298cc01feffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000"."\n");
	fwrite ($fh,"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000"."\n");
	fwrite ($fh,"000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff000000000000000000000000000000000000000000000000"."\n");
	fwrite ($fh,"0000000000000000000000000000000000000000000000000105000000000000}}		"."\n");
		
	unset($oUcitelj);

fwrite ($fh," }"."\n");
fclose($fh);
echo "<h2><a href='dato/".$VFile."' target='_blank'>Odpri odločbe za dopuste</a></h2>";

?>
</body>
</html>

