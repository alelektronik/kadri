<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prisotnost
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = intval($_POST["id"]);
}else{
    if (isset($_GET["id"])){
        $Vid=intval($_GET["id"]);
    }else{
        $Vid = 0;
    }
}

if ($Vid == 0){
    echo "<h1><a href='InitPrisotnost.php?id=1'>Želim pobrisati vse podatke o evidenci dela in kreirati nov spisek zaposlenih.</a></h1>";
}else{
    if ($VLevel > 2) {
        //brisanje podatkov o delavcih
	    $SQL = "DELETE FROM kadrovi WHERE stdelavca <> ''";
        $result = mysqli_query($link,$SQL);

        if ($Vid=="1"){
            //brisanje prihodov in odhodov (avtomatskih)
	        $SQL = "DELETE FROM promet1 WHERE sifra <> ''";
            $result = mysqli_query($link,$SQL);

            //brisanje odsotnosti (ročno vpisanih)
	        $SQL = "DELETE FROM tabodsotnost WHERE stdelavca <> ''";
            $result = mysqli_query($link,$SQL);

            //brisanje prihodov in odhodov (ročno vpisanih)
	        $SQL = "DELETE FROM tabprihodi WHERE sifra <> ''";
            $result = mysqli_query($link,$SQL);
	    }    
	    $SQL = "SELECT * FROM tabucitelji ORDER BY id";
	    $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    $SQL = "INSERT INTO kadrovi (stdelavca,sifra,priimime,emso) VALUES ('".$R["IdUcitelj"]."','".$R["IdUcitelj"]."','".$R["Priimek"]." ".$R["Ime"]."','".$R["IdUcitelj"]."')";
            $result1 = mysqli_query($link,$SQL);
	    }
	    
	    echo "<h1>Opravljeno!</h1>";
    }
}
?>

</body>
</html>
