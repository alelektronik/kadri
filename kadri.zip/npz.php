<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function displayverticalgraph($strtitle,$strytitle,$strxtitle,$avalues,$alabels){
    /*
    '************************************************************************
    '           user customizeable values for different formats
    '            of the graph
    '             FREEWARE!!
    '    Just tell me if you are going to use it - info@cool.co.za
    '************************************************************************
    */
    $GRAPH_HEIGHT     = 300; //              'set up the graph height
    $GRAPH_WIDTH     = 400; //           'set up the graph width
    $GRAPH_SPACING     = 1;    
    $GRAPH_BORDER     = 0; //             'if you would like to see the borders to align things differently    
    $GRAPH_BARS     = 10; //             'loops through different colored bars e.g. 2 bars = gold,blue,gold,blue
    $USELOWVALUE     = FALSE; //         'this uses the low value of the array as the value of origin (default = 0)
    $SHOWLABELS     = TRUE; //          'set this to toggle whether or not the labels are shown
    $L_LABEL_SEPARATOR = " "; //            ' |Label
    $R_LABEL_SEPARATOR = " "; //            ' Label|
    $LABELSIZE     = -4; //            
    $GRAPHBORDERSIZE     = 1; //
    $INTIMGBORDER     = 1; //               'border around the bars
    $ALT_TEXT        = 3; //            'Changes the format of the alternate text of the bar image
    /*                        '1 = Labels ,2 = Values , 3 = Labels + Values , 4 = Percent

    '************************************************************************
    'array of different bars to loop through
    'you can change the order of these 
    'Count = 10 
    '"dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple"
    'cut and paste from here and insert into the agraph_bars array below Make sure the 
    'number specified in the const GRAPH_BARS is the same as or less than that in the array 
    ' 7 graph_bars <= 7 elements in array
    '************************************************************************
    */
    $agraph_bars = array("dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple");

    $intmax = 0;

    $ZgMeja=0;
    for ($i=0;$i < count($alabels);$i++){
        if (strlen($alabels[$i]) > 0){
            $ZgMeja=$ZgMeja+1;
        }
    }
    $ZgMeja=$ZgMeja-1;
    //'find the maximum value of the values array
    for ($i = 0;$i <= $ZgMeja;$i++){
        if ($intmax < $avalues[$i]){
            $intmax = $avalues[$i]; 
        }
    }
    if ($USELOWVALUE){
        $intmin = $avalues[0];
        for ($i = 0;$i <= $ZgMeja;$i++){
            if  ($intmin > $avalues[$i]){
                $intmin = $avalues[$i]; 
            }
        }
    }
    //'establish the graph multiplier
    if ($intmax==0) $intmax=1;
    $graphmultiplier = round($GRAPH_HEIGHT-100/$intmax);

    $imgwidth = round(300/($ZgMeja+1));
    if ($imgwidth > 16) $imgwidth = 16;

    echo "<table class='graf' border ='".$GRAPH_BORDER."' width='".$GRAPH_WIDTH."' height='".$GRAPH_HEIGHT."'>";
        echo "<tr class='graf'>";
            echo "<td class='graf' rowspan='3' valign='middle'>".$strytitle."</td>";
            echo "<td class='graf' colspan='".($ZgMeja+2)."' height='50' align='center'><h4>".$strtitle."</h4></td>";
        echo "</tr>";
        $count = 0;
        echo "<tr class='graf'>";
            echo "<td class='graf'>";
                echo "<table class='graf' border='".$GRAPH_BORDER."' cellpadding = '0' cellspacing = '".$GRAPH_SPACING."'>";
                    echo "<tr class='graf'>";
                        echo "<TD class='graf' height='100%'>";
                            echo "<table class='graf' border='".$GRAPH_BORDER."' height='100%'>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='top' align='right'>".number_format($intmax,2)."</td>";
                                echo "</tr>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='bottom' align='right'>";
                                     
                                    if ($USELOWVALUE){
                                        echo number_format($intmin,2);
                                    }else{
                                        echo "0";
                                    }
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                        echo "</td>";
                        echo "<td class='graf' valign='bottom' align='right'><img src='leftbord.gif' width='2' height='".($graphmultiplier+8)."'></td>";
                        
                    //    echo "<td class='graf' ><table class='graf' border=".$GRAPH_BORDER." height='100%'>";
                    //    echo "<tr>";
                                     
                        //             '*******************MAIN PART OF THE CHART************************************
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            $strgraph = $agraph_bars[$count];
                            if ($ALT_TEXT == 1){
                                $stralt = $alabels[$i];
                            }else{
                                if ($ALT_TEXT == 2){
                                    $stralt = $avalues[$i];
                                }else{
                                    if ($ALT_TEXT == 3){
                                        $stralt = $alabels[$i] ." - "  .$avalues[$i];
                                    }else{
                                        if ($ALT_TEXT == 4){
                                            $stralt = round($avalues[$i] /$intmax  *100,2) ."%";
                                        }
                                    }
                                }
                            }

                            if ($USELOWVALUE){
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round(($avalues[$i]-$intmin)/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            }else{
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round($avalues[$i]/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            } 
                                
                            if ($count == $GRAPH_BARS-1){
                                $count = 0;
                            }else{
                                $count = $count + 1;
                            }        
                        }
                    //    echo "</tr></table></td>";          
                        //            'write out the border at the bottom of the bars also leave a blank cell for spacing on the right
                        echo "<td class='graf' width='50'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr class='graf'>";
                        echo "<td class='graf' width='8'>&nbsp;</td>";
                        echo "<td class='graf'>&nbsp;</td>";
                        echo "<td class='graf' colspan='" .($ZgMeja+1) ."' valign='top'>"."<img src='botbord.gif' width='100%' height='2'></td>";
                    echo "</tr>";
                    if ($SHOWLABELS){
                        echo "<tr class='graf'>";
                            echo "<th class='graf' width='8' height='1'>&nbsp;</th>";
                            echo "<th class='graf'>&nbsp;</th>";
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            echo "<th class='graf' valign='top' align='center' width='".$imgwidth."'><font size='".$LABELSIZE."'>".$L_LABEL_SEPARATOR.$alabels[$i].$R_LABEL_SEPARATOR."</font></th>";
                        }
                        echo "</tr>";
                    }
                    echo "<tr class='graf'><td class='graf' colspan='".($ZgMeja+3)."' height='50' align='center'>".$strxtitle."</td>";
                    echo "</tr>";
                echo "</table>";
            echo "</td>";
        echo "</tr>";
        echo "<tr class='graf'>";
            echo "<td class='graf'></td>";
        echo"</tr>";
    echo "</table>";
}

class UcenecNpz {
    var $EMSO;  
    var $IME;
    var $PRIIMEK;  
    var $RAZRED_OBISK;
    var $ODDELEK_OZNAKA;
    var $PREDMET_REF;
    var $TOCK_MAKS;
    var $TOCK_ST;
    var $TOCK_PROC;
    
    function UcenecNpz ($aa) 
    {
        foreach ($aa as $k=>$v)
            $this->$k = $aa[$k];
    }
}

function readDatabase($filename) 
{
    // read the XML database of aminoacids
    $data = implode("", file($filename));
    $parser = xml_parser_create();
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, $data, $values, $tags);
    xml_parser_free($parser);

    // loop through the structures
    foreach ($tags as $key=>$val) {
        if ($key == "UcenecDosezek") {
            $molranges = $val;
            // each contiguous pair of array entries are the 
            // lower and upper range for each molecule definition
            for ($i=0; $i < count($molranges); $i+=2) {
                $offset = $molranges[$i] + 1;
                $len = $molranges[$i + 1] - $offset;
                $tdb[] = parseNpz(array_slice($values, $offset, $len));
            }
        } else {
            continue;
        }
    }
    return $tdb;
}

function parseNpz($mvalues) 
{
    for ($i=0; $i < count($mvalues); $i++) {
        if (isset($mvalues[$i]["value"])){
            $ucenec[$mvalues[$i]["tag"]] = $mvalues[$i]["value"];
        }else{
            $ucenec[$mvalues[$i]["tag"]] ="";
        }
    }
    return new UcenecNpz($ucenec);
}

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function Arr2Str($a){
    $s="";
    if (count($a) > 0){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }
    return $s;
}
function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $Ucitelj=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosNPZ",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["idd"])){
    $VSelect = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VSelect=$_GET["idd"];
    }else{
        $VSelect = 0;
    }
}
switch ($VSelect){
    case "120":
    case "125":
    case "130":
    case "170":
    case "210":
    case "310":
    case "510":
        break;
    default:
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<script language='JavaScript'>";
        echo "function OznaciVse(form){";
        echo "    for (i=1; i < form.elements.length; i++) {";
        echo "        form.elements[i].checked=true;";
        echo "    }";
        echo "}";
        echo "function BrisiVse(form){";
        echo "    for (i=1; i < form.elements.length; i++) {";
        echo "        form.elements[i].checked=false;";
        echo "    }";
        echo "}";
        echo "</script>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        $VRazred = 0;
    }
}

switch ($VSelect){
    case "100": //npz predmeti
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<h2>Izbor predmetov za NPZ - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p><b>Navodilo</b>: najprej izberite in pošljite predmete, ki bodo to šolsko leto na nacinalnem preverjanju znanj.</p>";
        $SQL = "SELECT idpredmet FROM tabnpzpredmeti WHERE leto=".$VLeto." ORDER BY razred,prednost";
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result) > 0){
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $NpzPredmeti[$Indx]=$R["idpredmet"];
                $Indx=$Indx+1;
            }
        }else{
            $NpzPredmeti[1]=16; //'SLO
            $NpzPredmeti[2]=11; //'MAT
            $NpzPredmeti[3]=26; //'TJA
            $NpzPredmeti[4]=16; //'SLO
            $NpzPredmeti[5]=11; //'MAT
            $NpzPredmeti[6]=1;  //'BIO
        }

        echo "<form name='NPZpredmeti' method=post action='npz.php'>";
        echo "<input name='idd' type='hidden' value='110'>";
        echo "<table border=0>";

        $SQL = "SELECT id,oznaka,opis FROM tabpredmeti WHERE prioriteta=0";
        $result = mysqli_query($link,$SQL);

        echo "<tr><td><b>Šesti razredi</b></td></tr>";
        echo "<tr><td>1. predmet</td><td>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[1]==$R["id"]){
                echo "<input name='npzpredmet1' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"];
            }
        }
        echo "</td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>2. predmet</td><td>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[2]==$R["id"]){
                echo "<input name='npzpredmet2' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"];
            }
        }
        echo "</td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>3. predmet</td><td>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[3]==$R["id"]){
                echo "<input name='npzpredmet3' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"];
            }
        }
        echo "</td></tr>";

        echo "<tr><td><b>Deveti razredi</b></td></tr>";
        $result = mysqli_query($link,$SQL);
        echo "<tr><td>1. predmet</td><td>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[4]==$R["id"]){
                echo "<input name='npzpredmet4' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"];
            }
        }
        echo "</td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>2. predmet</td><td>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[5]==$R["id"]){
                echo "<input name='npzpredmet5' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"];
            }
        }
        echo "</td></tr>";

        $result = mysqli_query($link,$SQL);
        echo "<tr><td>3. predmet</td><td><select name='npzpredmet6'>";
        while ($R = mysqli_fetch_array($result)){
            if ($NpzPredmeti[6]==$R["id"]){
                echo "<option value='".$R["id"]."' selected>".$R["oznaka"]." - ".$R["opis"]."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"]."</option>";
            }
        }
        echo "</select></td></tr>";

        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";

        echo "</body>";
        echo "</html>";
        break;
    case "110": //vpis npz predmeti
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<h2>Izbor terminov, nadzornikov in prostorov za NPZ - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p><b>Navodilo</b>: Izberite razred, predmet, prostor, nadzorna učitelja in datum preverjanja. Navedeno imate število učencev v šestih in devetih razredih. Določite dovolj prostorov, da bo program lahko izdelal sedežne rede.<br />";
        echo "Za dodatni termin ravno tako določite razrede, prostore, nadzorne učitelje in termin, nato pa kliknite na gumb za Izbor učencev za dodatni termin.</p>";
        if (isset($_POST["npzpredmet1"])){
            $NpzPredmeti[1]=$_POST["npzpredmet1"]; //'SLO/6
            $NpzPredmeti[2]=$_POST["npzpredmet2"]; //'MAT/6
            $NpzPredmeti[3]=$_POST["npzpredmet3"]; //'TJA/6
            $NpzPredmeti[4]=$_POST["npzpredmet4"]; //'SLO/9
            $NpzPredmeti[5]=$_POST["npzpredmet5"]; //'MAT/9
            $NpzPredmeti[6]=$_POST["npzpredmet6"]; //'3. predmet/9

            if (strlen($NpzPredmeti[1]) > 0){
                //'za šeste razrede
                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=6 AND prednost=1";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[1]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[1].",6,1)";
                }
                $result = mysqli_query($link,$SQL);

                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=6 AND prednost=2";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[2]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[2].",6,2)";
                }
                $result = mysqli_query($link,$SQL);

                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=6 AND prednost=3";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[3]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[3].",6,3)";
                }
                $result = mysqli_query($link,$SQL);

                //'za devete razrede
                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=9 AND prednost=1";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[4]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[4].",9,1)";
                }
                $result = mysqli_query($link,$SQL);

                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=9 AND prednost=2";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[5]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[5].",9,2)";
                }
                $result = mysqli_query($link,$SQL);

                $SQL = "SELECT id FROM tabnpzpredmeti WHERE leto=".$VLeto." AND razred=9 AND prednost=3";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabnpzpredmeti SET idPredmet=".$NpzPredmeti[6]." WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabnpzpredmeti (leto,idPredmet,razred,prednost) VALUES (".$VLeto.",".$NpzPredmeti[6].",9,3)";
                }
                $result = mysqli_query($link,$SQL);
            }
        }
        echo "<b>Predmeti na NPZ</b><br />";
        echo "<table border=1>";
        echo "<tr><th>Razred</th><th>Predmet</th></tr>";
        $SQL = "SELECT tabnpzpredmeti.prednost,tabnpzpredmeti.razred,tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." ORDER BY tabnpzpredmeti.razred,tabnpzpredmeti.prednost";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td align=center>".$R["razred"]."</td><td>".$R["prednost"].". predmet ".$R["oznaka"]." - ".$R["opis"]."</td></tr>";
        }
        echo "</table><br />";

        $SQL = "SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 OR (idUcitelj=0) ORDER BY Priimek,Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Nadzornik[$Indx][0]=$R["iducitelj"];
            $Nadzornik[$Indx][1]=$R["priimek"]." ".$R["ime"];
            $Indx=$Indx+1;
        }
        $StNadzornikov=$Indx-1;

        $SQL = "SELECT idprostor,opis,oznaka,stevilka,stmiz FROM tabprostor WHERE (StMiz > 1) OR (idProstor=0) ORDER BY Opis";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $NpzProstor[$Indx][0]=$R["idprostor"];
            $NpzProstor[$Indx][1]=$R["opis"]." - ".$R["oznaka"]."/".$R["stevilka"]." (".$R["stmiz"]." miz)";
            $Indx=$Indx+1;
        }
        $StProstorov=$Indx-1;

        $SQL = "SELECT leto,razred,Count(razred) AS countofrazred FROM tabrazred GROUP BY leto,razred HAVING leto=".$VLeto." AND (razred IN (6,9)) ORDER BY razred";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            switch ($R["razred"]){
                case 6:
                    echo "Učenci 6. razreda: ".$R["countofrazred"]."<br />";
                    break;
                case 9:
                    echo "Učenci 9. razreda: ".$R["countofrazred"]."<br />";
            }
        }

        $SQL = "SELECT tabnpzpredmeti.idpredmet,tabnpzpredmeti.razred,tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." ORDER BY tabnpzpredmeti.razred,tabnpzpredmeti.prednost";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx][0]=$R["idpredmet"];
            $Predmeti[$Indx][1]=$R["razred"]." - ".$R["oznaka"]." - ".$R["opis"];
            $Indx=$Indx+1;
        }

        $SQL = "SELECT tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,";
        $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
        $SQL = $SQL . "(tabnpztermini INNER JOIN tabpredmeti ON tabnpztermini.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
        $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto;
        $SQL = $SQL . " ORDER BY tabnpztermini.razred,tabpredmeti.VrstniRed,tabnpztermini.datum";
        $result = mysqli_query($link,$SQL);

        echo "<form name='NPZprostori' method=post action='npz.php'>";
        echo "<input name='idd' type='hidden' value='120'>";
        echo "<b>Predmeti, prostori, nadzorniki in datumi NPZ</b>";
        echo "<table border=1>";
        echo "<tr><th>Leto</th><th>Razred</th><th>Predmet</th><th>Prostor</th><th>1. nadzornik</th><th>2. nadzornik</th><th>Datum</th><th>Redni/Dodatni</th><th>Briši</th><th>Popravi</th></tr>";

        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
            echo "<td>".$R["razred"]."</td><td>".$R["poznaka"]." - ".$R["popis"]."</td>";
            echo "<td>".$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"]." (".$R["stmiz"]." miz)</td>";
            for ($i=1;$i <= $StNadzornikov;$i++){
                if ($R["iducitelj1"] == $Nadzornik[$i][0]){
                    echo "<td>".$Nadzornik[$i][1]."</td>";
                    break;
                }
            }
            for ($i=1;$i <= $StNadzornikov;$i++){
                if ($R["iducitelj2"] == $Nadzornik[$i][0]){
                    echo "<td>".$Nadzornik[$i][1]."</td>";
                    break;
                }
            }
            if (isdate($R["datum"])){
                $Datum=new DateTime($R["datum"]);
                echo "<td>".$Datum->format('d.m.Y')."</td>";
            }else{
                echo "<td>&nbsp;</td>";
            }
            if ($R["termin"]==0){
                echo "<td>Redni</td>";
            }else{
                echo "<td>Dodatni</td>";
            }
            echo "<td><a href='npz.php?idd=130&id=".$R["id"]."'>Briši</a></td>";
            echo "<td><a href='npz.php?idd=115&popravi=".$R["id"]."'>Popravi</a></td>";
            echo "</tr>";
        }

        echo "<tr>";
        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
        echo "<td><select name='razred'>";
        if (isset($_SESSION["npz_razred"])){
            if ($_SESSION["npz_razred"] == 9){
                echo "<option value='9' selected='selected'>9</option>";
                echo "<option value='6'>6</option>";
            }else{
                echo "<option value='9'>9</option>";
                echo "<option value='6' selected='selected'>6</option>";
            }
        }else{
            echo "<option value='9' selected='selected'>9</option>";
            echo "<option value='6'>6</option>";
        }
        echo "</select></td>";
        echo "<td><select name='predmet'>";
        for ($Indx=1;$Indx <= 6;$Indx++){
            if (isset($_SESSION["npz_predmet"])){
                if ($Predmeti[$Indx][0] == $_SESSION["npz_predmet"]){
                    echo "<option value='".$Predmeti[$Indx][0]."' selected='selected'>".$Predmeti[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Predmeti[$Indx][0]."'>".$Predmeti[$Indx][1]."</option>";
                }
            }else{
                if ($Indx==4){
                    echo "<option value='".$Predmeti[$Indx][0]."' selected='selected'>".$Predmeti[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Predmeti[$Indx][0]."'>".$Predmeti[$Indx][1]."</option>";
                }
            }
        }
        echo "</select></td>";
        echo "<td><select name='prostor'>";
        for ($Indx=1;$Indx <= $StProstorov;$Indx++){
            if (isset($_SESSION["npz_prostor"])){
                if ($NpzProstor[$Indx][0]==$_SESSION["npz_prostor"]){
                    echo "<option value='".$NpzProstor[$Indx][0]."' selected='selected'>".$NpzProstor[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$NpzProstor[$Indx][0]."'>".$NpzProstor[$Indx][1]."</option>";
                }
            }else{
                if ($NpzProstor[$Indx][0]==0){
                    echo "<option value='".$NpzProstor[$Indx][0]."' selected='selected'>".$NpzProstor[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$NpzProstor[$Indx][0]."'>".$NpzProstor[$Indx][1]."</option>";
                }
            }
        }
        echo "</select></td>";
        echo "<td><select name='nadzornik1'>";
        for ($Indx=1;$Indx <= $StNadzornikov;$Indx++){
            if (isset($_SESSION["npz_nadzornik1"])){
                if ($Nadzornik[$Indx][0]==$_SESSION["npz_nadzornik1"]){
                    echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                }
            }else{
                if ($Nadzornik[$Indx][0]==0){
                    echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                }
            }
        }
        echo "</select></td>";
        echo "<td><select name='nadzornik2'>";
        for ($Indx=1;$Indx <= $StNadzornikov;$Indx++){
            if (isset($_SESSION["npz_nadzornik2"])){
                if ($Nadzornik[$Indx][0]==$_SESSION["npz_nadzornik2"]){
                    echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                }
            }else{
                if ($Nadzornik[$Indx][0]==0){
                    echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                }else{
                    echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                }
            }
        }
        echo "</select></td>";
        if (isset($_SESSION["npz_datum"])){
            echo "<td><input name='datum' type='text' size='10' value='".$_SESSION["npz_datum"]."'></td>";
        }else{
            echo "<td><input name='datum' type='text' size='10'></td>";
        }
        echo "<td><select name='termin'>";
        if (isset($_SESSION["termin"])){
            if ($_SESSION["termin"]==0){
                echo "<option value='0' selected='selected'>Redni</option>";
                echo "<option value='1'>Dodatni</option>";
            }else{
                echo "<option value='0'>Redni</option>";
                echo "<option value='1' selected='selected'>Dodatni</option>";
            }
        }else{
            echo "<option value='0' selected='selected'>Redni</option>";
            echo "<option value='1'>Dodatni</option>";
        }
        echo "</select></td>";
        echo "</tr>";
        echo "</table>";

        echo "<input name='submit' type='submit' value='Dodaj termin'><br />";
        echo "<br />";
        echo "Če so vneseni prostori in termini, lahko uporabite spodnje gumbe:<br />";
        echo "<input name='submit' type='submit' value='Tvori obrazce za redni rok'><br />";
        echo "<input name='submit' type='submit' value='Izberi učence za redni rok'><br />";
        echo "<input name='submit' type='submit' value='Izberi učence za dodatni rok'><br />";
        echo "</form>";
        echo "<br /><br /><a href='npz.php?idd=200'>Preveri in uredi obstoječe spiske</a><br />";
        echo "<a href='npz.php?idd=170'>Obrazci NPZ (PDF) - na osnovi že vpisanih podatkov</a><br />";
        echo "<a href='npz.php?idd=300'>Vpis dosežkov na NPZ</a><br />";
        echo "<a href='npz.php?idd=400'>Pregled rezultatov NPZ</a><br />";
        echo "</body>";
        echo "</html>";
        break;

    case "115": //popravi termin
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<h2>Popravljanje terminov, nadzornikov in prostorov za NPZ - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<b>Predmeti na NPZ</b><br />";
        echo "<table border=1>";
        echo "<tr><th>Razred</th><th>Predmet</th></tr>";
        $SQL = "SELECT tabnpzpredmeti.prednost,tabnpzpredmeti.razred,tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." ORDER BY tabnpzpredmeti.razred,tabnpzpredmeti.prednost";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td align=center>".$R["razred"]."</td><td>".$R["prednost"].". predmet ".$R["oznaka"]." - ".$R["opis"]."</td></tr>";
        }
        echo "</table><br />";

        $SQL = "SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 OR (idUcitelj=0) ORDER BY Priimek,Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Nadzornik[$Indx][0]=$R["iducitelj"];
            $Nadzornik[$Indx][1]=$R["priimek"]." ".$R["ime"];
            $Indx=$Indx+1;
        }
        $StNadzornikov=$Indx-1;

        $SQL = "SELECT idprostor,opis,oznaka,stevilka,stmiz FROM tabprostor WHERE (StMiz > 1) OR (idProstor=0) ORDER BY Opis";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $NpzProstor[$Indx][0]=$R["idprostor"];
            $NpzProstor[$Indx][1]=$R["opis"]." - ".$R["oznaka"]."/".$R["stevilka"]." (".$R["stmiz"]." miz)";
            $Indx=$Indx+1;
        }
        $StProstorov=$Indx-1;

        $SQL = "SELECT leto,razred,Count(razred) AS countofrazred FROM tabrazred GROUP BY leto,razred HAVING leto=".$VLeto." AND (razred IN (6,9)) ORDER BY razred";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            switch ($R["razred"]){
                case 6:
                    echo "Učenci 6. razreda: ".$R["countofrazred"]."<br />";
                    break;
                case 9:
                    echo "Učenci 9. razreda: ".$R["countofrazred"]."<br />";
            }
        }

        $SQL = "SELECT tabnpzpredmeti.idpredmet,tabnpzpredmeti.razred,tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." ORDER BY tabnpzpredmeti.razred,tabnpzpredmeti.prednost";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx][0]=$R["idpredmet"];
            $Predmeti[$Indx][1]=$R["razred"]." - ".$R["oznaka"]." - ".$R["opis"];
            $Indx=$Indx+1;
        }

        $SQL = "SELECT tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,tabnpztermini.idpredmet,tabnpztermini.idprostor,";
        $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
        $SQL = $SQL . "(tabnpztermini INNER JOIN tabpredmeti ON tabnpztermini.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
        $SQL = $SQL . "WHERE tabnpztermini.id=".$_GET["popravi"];
        $SQL = $SQL . " ORDER BY tabnpztermini.razred,tabpredmeti.VrstniRed,tabnpztermini.datum";
        $result = mysqli_query($link,$SQL);

        echo "<form name='NPZprostori' method=post action='npz.php'>";
        echo "<input name='popravi' type='hidden' value='".$_GET["popravi"]."'>";
        echo "<input name='idd' type='hidden' value='125'>";
        echo "<b>Predmeti, prostori, nadzorniki in datumi NPZ</b>";
        echo "<table border=1>";
        echo "<tr><th>Leto</th><th>Razred</th><th>Predmet</th><th>Prostor</th><th>1. nadzornik</th><th>2. nadzornik</th><th>Datum</th><th>Redni/Dodatni</th></tr>";

        if ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
            echo "<td><select name='razred'>";
            if (isset($R["razred"])){
                if ($R["razred"] == 9){
                    echo "<option value='9' selected='selected'>9</option>";
                    echo "<option value='6'>6</option>";
                }else{
                    echo "<option value='9'>9</option>";
                    echo "<option value='6' selected='selected'>6</option>";
                }
            }else{
                echo "<option value='9' selected='selected'>9</option>";
                echo "<option value='6'>6</option>";
            }
            echo "</select></td>";
            echo "<td><select name='predmet'>";
            for ($Indx=1;$Indx <= 6;$Indx++){
                if (isset($R["idpredmet"])){
                    if ($Predmeti[$Indx][0] == $R["idpredmet"]){
                        echo "<option value='".$Predmeti[$Indx][0]."' selected='selected'>".$Predmeti[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$Indx][0]."'>".$Predmeti[$Indx][1]."</option>";
                    }
                }else{
                    if ($Indx==4){
                        echo "<option value='".$Predmeti[$Indx][0]."' selected='selected'>".$Predmeti[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Predmeti[$Indx][0]."'>".$Predmeti[$Indx][1]."</option>";
                    }
                }
            }
            echo "</select></td>";
            echo "<td><select name='prostor'>";
            for ($Indx=1;$Indx <= $StProstorov;$Indx++){
                if (isset($R["idprostor"])){
                    if ($NpzProstor[$Indx][0]==$R["idprostor"]){
                        echo "<option value='".$NpzProstor[$Indx][0]."' selected='selected'>".$NpzProstor[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$NpzProstor[$Indx][0]."'>".$NpzProstor[$Indx][1]."</option>";
                    }
                }else{
                    if ($NpzProstor[$Indx][0]==0){
                        echo "<option value='".$NpzProstor[$Indx][0]."' selected='selected'>".$NpzProstor[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$NpzProstor[$Indx][0]."'>".$NpzProstor[$Indx][1]."</option>";
                    }
                }
            }
            echo "</select></td>";
            echo "<td><select name='nadzornik1'>";
            for ($Indx=1;$Indx <= $StNadzornikov;$Indx++){
                if (isset($R["iducitelj1"])){
                    if ($Nadzornik[$Indx][0]==$R["iducitelj1"]){
                        echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                    }
                }else{
                    if ($Nadzornik[$Indx][0]==0){
                        echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                    }
                }
            }
            echo "</select></td>";
            echo "<td><select name='nadzornik2'>";
            for ($Indx=1;$Indx <= $StNadzornikov;$Indx++){
                if (isset($R["iducitelj2"])){
                    if ($Nadzornik[$Indx][0]==$R["iducitelj2"]){
                        echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                    }
                }else{
                    if ($Nadzornik[$Indx][0]==0){
                        echo "<option value='".$Nadzornik[$Indx][0]."' selected='selected'>".$Nadzornik[$Indx][1]."</option>";
                    }else{
                        echo "<option value='".$Nadzornik[$Indx][0]."'>".$Nadzornik[$Indx][1]."</option>";
                    }
                }
            }
            echo "</select></td>";
            if (isset($R["datum"])){
                $datum=new DateTime($R["datum"]);
                echo "<td><input name='datum' type='text' size='10' value='".$datum->format('d.m.Y')."'></td>";
            }else{
                echo "<td><input name='datum' type='text' size='10'></td>";
            }
            echo "<td><select name='termin'>";
            if (isset($R["termin"])){
                if ($R["termin"]==0){
                    echo "<option value='0' selected='selected'>Redni</option>";
                    echo "<option value='1'>Dodatni</option>";
                }else{
                    echo "<option value='0'>Redni</option>";
                    echo "<option value='1' selected='selected'>Dodatni</option>";
                }
            }else{
                echo "<option value='0' selected='selected'>Redni</option>";
                echo "<option value='1'>Dodatni</option>";
            }
            echo "</select></td>";
            echo "</tr>";
        }
        echo "</table>";

        echo "<input name='submit' type='submit' value='Popravi'><br />";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "120": //vpis npz terminov
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $Izhod=false;
        $VSubmit=$_POST["submit"];
        switch ($VSubmit){
            case "Dodaj termin":
                $VRazred=$_POST["razred"];
                $Predmet=$_POST["predmet"];
                $Prostor=$_POST["prostor"];
                $Nadzornik1=$_POST["nadzornik1"];
                $Nadzornik2=$_POST["nadzornik2"];
                $DatumNpz=$_POST["datum"];
                $Termin=$_POST["termin"];

                if (!isDate($DatumNpz)){
                    echo "<script language='JavaScript'>";
                    echo "alert('Napačen datum!')";
                    echo "</script>";
                    header ("Location: npz.php?idd=110");
                }else{
                    $Datum=new DateTime(isDate($DatumNpz));
                    $SQL = "SELECT * FROM tabnpztermini WHERE leto=".$VLeto." AND idPredmet=".$Predmet." AND idProstor=".$Prostor." AND razred=".$VRazred." AND idUcitelj1=".$Nadzornik1." AND idUcitelj2=".$Nadzornik2." AND datum='".$Datum->format('Y-m-d')."' AND termin=".$Termin;
                    //echo $SQL."<br />";
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        echo "<script language='JavaScript'>";
                        echo "alert('Ti podatki so že vpisani!')";
                        echo "</script>";
                        
                        header("Location: npz.php?idd=110");
                    }else{

                        $SQL = "INSERT INTO tabnpztermini (leto,idPredmet,datum,razred,termin,idProstor,idUcitelj1,idUcitelj2) VALUES (".$VLeto.",".$Predmet.",'".$Datum->format('Y-m-d')."',".$VRazred.",".$Termin.",".$Prostor.",".$Nadzornik1.",".$Nadzornik2.")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                        $_SESSION["npz_razred"]=$VRazred;
                        $_SESSION["npz_predmet"]=$Predmet;
                        $_SESSION["npz_prostor"]=$Prostor;
                        $_SESSION["npz_termin"]=$Termin;
                        $_SESSION["npz_nadzornik1"]=$Nadzornik1;
                        $_SESSION["npz_nadzornik2"]=$Nadzornik2;
                        $_SESSION["npz_datum"]=$Datum->format('d.m.Y');
                        
                        header("Location: npz.php?idd=110");
                    }
                }
                break;
            case "Tvori obrazce za redni rok":
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<script language='JavaScript'>";
                echo "function OznaciVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=true;";
                echo "    }";
                echo "}";
                echo "function BrisiVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=false;";
                echo "    }";
                echo "}";
                echo "</script>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
                
                echo "<h2>NPZ - Razporeditev</h2>";
                //'6. razredi
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE razred=6 AND leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci6[$Indx][0]=$R["iducenec"];
                    $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                    $Ucenci6[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    $Indx=$Indx+1;
                }
                $StUcencev6=$Indx-1;
                
                //'9. razredi
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE razred=9 AND leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci9[$Indx][0]=$R["iducenec"];
                    $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].".".$R["paralelka"];
                    $Ucenci9[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    $Indx=$Indx+1;
                }
                $StUcencev9=$Indx-1;
                
                $SQL = "SELECT razred,idpredmet FROM tabnpzpredmeti WHERE leto=".$VLeto." ORDER BY razred,prednost";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$Indx][0]=$R["razred"];
                    $Predmeti[$Indx][1]=$R["idpredmet"];
                    $Indx=$Indx+1;
                }
                
                //' prostorov po predmetih za 6. razrede
                $SQL = "SELECT tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,tabnpztermini.idpredmet,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=6 AND tabnpzpredmeti.razred=6 AND tabnpztermini.termin=0 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Šesti razredi</h3>";
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                echo "<form name='NPZTermin6' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='6'>";
                echo "<input type='hidden' name='stucencev61' value='".$StUcencev6."'>";
                echo "<input type='hidden' name='stucencev62' value='".$StUcencev6."'>";
                echo "<input type='hidden' name='stucencev63' value='".$StUcencev6."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev6 <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev6/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev6){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev6-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev6-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci6[$Indx][0]."'>".$Ucenci6[$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci6[$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";

                //' prostorov po predmetih za 9. razrede
                $SQL = "SELECT tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,tabnpztermini.idpredmet,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=9 AND tabnpzpredmeti.razred=9 AND tabnpztermini.termin=0 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Deveti razredi</h3>";
                
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                echo "<form name='NPZTermin9' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='9'>";
                echo "<input type='hidden' name='stucencev91' value='".$StUcencev9."'>";
                echo "<input type='hidden' name='stucencev92' value='".$StUcencev9."'>";
                echo "<input type='hidden' name='stucencev93' value='".$StUcencev9."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev9 <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev9/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev9){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev9-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev9-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci9[$Indx][0]."'>".$Ucenci9[$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci9[$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";
                break;
            case "Izberi učence za dodatni rok":
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<script language='JavaScript'>";
                echo "function OznaciVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=true;";
                echo "    }";
                echo "}";
                echo "function BrisiVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=false;";
                echo "    }";
                echo "}";
                echo "</script>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
                
                //'6. razredi
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE razred=6 AND leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci6[$Indx][0]=$R["iducenec"];
                    $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].".".mb_strtolower($R["paralelka"],$encoding);
                    $Ucenci6[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    $Indx=$Indx+1;
                }
                $StUcencev6=$Indx-1;
                
                //'9. razredi
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE razred=9 AND leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci9[$Indx][0]=$R["iducenec"];
                    $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].".".mb_strtolower($R["paralelka"],$encoding);
                    $Ucenci9[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    $Indx=$Indx+1;
                }
                $StUcencev9=$Indx-1;
                
                $SQL = "SELECT tabnpzpredmeti.idpredmet,tabnpzpredmeti.razred,tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE leto=".$VLeto." ORDER BY razred,prednost";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$Indx][0]=$R["razred"];
                    $Predmeti[$Indx][1]=$R["idpredmet"];
                    $Predmeti[$Indx][2]=$R["oznaka"]." - ".$R["opis"];
                    $Predmeti[$Indx][3]=$R["oznaka"];
                    $Indx=$Indx+1;
                }
                
                echo "<form name='NPZTermin6' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='160'>";
                echo "<h2>Izbor učencev za NPZ - dodatni termin</h2>";
                echo "<input type='hidden' name='ucencev6' value='".$StUcencev6."'>";
                echo "<input type='hidden' name='ucencev9' value='".$StUcencev9."'>";
                echo "<table border=0><tr><td valign=top>";
                echo "<h3>6. razredi</h3>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Učenec</th><th>".$Predmeti[1][3]."</th><th>".$Predmeti[2][3]."</th><th>".$Predmeti[3][3]."</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev6;$Indx++){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input type='hidden' name='ucenec6".$Indx."' value='".$Ucenci6[$Indx][0]."'>".$Ucenci6[$Indx][1]."</td>";
                    echo "<td><input name='predmet61".$Indx."' type='checkbox'></td>";
                    echo "<td><input name='predmet62".$Indx."' type='checkbox'></td>";
                    echo "<td><input name='predmet63".$Indx."' type='checkbox'></td>";
                    echo "</tr>";
                }
                echo "</table>";
                
                echo "</td><td valign=top>";
                
                echo "<h3>9. razredi</h3>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Učenec</th><th>".$Predmeti[4][3]."</th><th>".$Predmeti[5][3]."</th><th>".$Predmeti[6][3]."</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev9;$Indx++){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input type='hidden' name='ucenec9".$Indx."' value='".$Ucenci9[$Indx][0]."'>".$Ucenci9[$Indx][1]."</td>";
                    echo "<td><input name='predmet91".$Indx."' type='checkbox'></td>";
                    echo "<td><input name='predmet92".$Indx."' type='checkbox'></td>";
                    echo "<td><input name='predmet93".$Indx."' type='checkbox'></td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "</td></tr></table><br />";
                
                echo "<input name='submit' type='submit' value='Pošlji'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
                echo "</form>";
                break;
            case "Izberi učence za redni rok":
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<script language='JavaScript'>";
                echo "function OznaciVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=true;";
                echo "    }";
                echo "}";
                echo "function BrisiVse(form){";
                echo "    for (i=1; i < form.elements.length; i++) {";
                echo "        form.elements[i].checked=false;";
                echo "    }";
                echo "}";
                echo "</script>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
                
                //'6. razredi
                $SQL = "SELECT npz,iducenec FROM tabnpz6 WHERE leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                
                $UcenciNPZ6="";
                while ($R = mysqli_fetch_array($result)){
                    if ($R["npz"]){
                        if (strlen($UcenciNPZ6) == 0){
                            $UcenciNPZ6=$R["iducenec"];
                        }else{
                            $UcenciNPZ6=$UcenciNPZ6.",".$R["iducenec"];
                        }
                    }
                }
                
                if (strlen($UcenciNPZ6) > 0){
                    $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabnpz6.npz,tabsola.solakratko FROM ";
                    $SQL = $SQL ." (((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL ." INNER JOIN tabnpz6 ON tabrazred.idUcenec=tabnpz6.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL = $SQL ." WHERE tabrazred.razred=6 AND tabrazred.leto=".$VLeto." AND tabnpz6.leto=".$VLeto." ORDER BY priimek,ime";
                }else{
                    $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabnpz6.npz,tabsola.solakratko FROM ";
                    $SQL .= "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                    $SQL .= "LEFT JOIN tabnpz6 ON tabrazred.idUcenec=tabnpz6.idUcenec ";
                    $SQL .= "WHERE tabrazred.razred=6 AND tabrazred.leto=".$VLeto;
                    $SQL .=" ORDER BY priimek,ime";
                }
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci6[$Indx][0]=$R["iducenec"];
                    if ($VecSol > 0){
                        $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".mb_strtolower($R["paralelka"],$encoding)." - ".$R["solakratko"];
                    }else{
                        $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".mb_strtolower($R["paralelka"],$encoding);
                    }
                    if ($R["npz"]){
                        $Ucenci6[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    }else{
                        $Ucenci6[$Indx][2]=0; // '0-ne sodeluje, 1-sodeluje
                    }
                    $Indx=$Indx+1;
                }
                $StUcencev6=$Indx-1;
                
                //'9. razredi
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabsola.solakratko FROM ";
                $SQL .= "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL .= "WHERE tabrazred.razred=9 AND tabrazred.leto=".$VLeto;
                $SQL .= " ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci9[$Indx][0]=$R["iducenec"];
                    if ($VecSol > 0){
                        $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".mb_strtolower($R["paralelka"],$encoding)." - ".$R["solakratko"];
                    }else{
                        $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".mb_strtolower($R["paralelka"],$encoding);
                    }
                    $Ucenci9[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                    $Indx=$Indx+1;
                }
                $StUcencev9=$Indx-1;
                
                $SQL = "SELECT tabnpzpredmeti.razred,tabnpzpredmeti.idpredmet,tabpredmeti.oznaka,tabpredmeti.opis FROM ";
                $SQL .= "tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id ";
                $SQL .= "WHERE leto=".$VLeto;
                $SQL .= " ORDER BY razred,prednost";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$Indx][0]=$R["razred"];
                    $Predmeti[$Indx][1]=$R["idpredmet"];
                    $Predmeti[$Indx][2]=$R["oznaka"]." - ".$R["opis"];
                    $Predmeti[$Indx][3]=$R["oznaka"];
                    $Indx=$Indx+1;
                }
                
                echo "<form name='NPZTermin6' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='140'>";
                echo "<h2>Izbor učencev za NPZ - redni termin</h2>";
                echo "<input type='hidden' name='ucencev6' value='".$StUcencev6."'>";
                echo "<input type='hidden' name='ucencev9' value='".$StUcencev9."'>";
                echo "<table border=0><tr><td valign=top>";
                echo "<h3>6. razredi</h3>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Učenec</th><th>".$Predmeti[1][3]."</th><th>".$Predmeti[2][3]."</th><th>".$Predmeti[3][3]."</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev6;$Indx++){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input type='hidden' name='ucenec6".$Indx."' value='".$Ucenci6[$Indx][0]."'>".$Ucenci6[$Indx][1]."</td>";
                    if ($Ucenci6[$Indx][2]==0){
                        echo "<td><input name='predmet61".$Indx."' type='checkbox'></td>";
                        echo "<td><input name='predmet62".$Indx."' type='checkbox'></td>";
                        echo "<td><input name='predmet63".$Indx."' type='checkbox'></td>";
                    }else{
                        echo "<td><input name='predmet61".$Indx."' type='checkbox' checked='checked'></td>";
                        echo "<td><input name='predmet62".$Indx."' type='checkbox' checked='checked'></td>";
                        echo "<td><input name='predmet63".$Indx."' type='checkbox' checked='checked'></td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
                
                echo "</td><td valign=top>";
                
                echo "<h3>9. razredi</h3>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Učenec</th><th>".$Predmeti[4][3]."</th><th>".$Predmeti[5][3]."</th><th>".$Predmeti[6][3]."</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev9;$Indx++){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input type='hidden' name='ucenec9".$Indx."' value='".$Ucenci9[$Indx][0]."'>".$Ucenci9[$Indx][1]."</td>";
                    echo "<td><input name='predmet91".$Indx."' type='checkbox' checked='checked'></td>";
                    echo "<td><input name='predmet92".$Indx."' type='checkbox' checked='checked'></td>";
                    echo "<td><input name='predmet93".$Indx."' type='checkbox' checked='checked'></td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "</td></tr></table><br />";
                
                echo "<input name='submit' type='submit' value='Pošlji'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
                echo "</form>";
                break;
        }
        echo "</body>";
        echo "</html>";
        break;

    case "125": //vpis popravkov npz terminov
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $Izhod=false;
        $VRazred=$_POST["razred"];
        $Predmet=$_POST["predmet"];
        $Prostor=$_POST["prostor"];
        $Nadzornik1=$_POST["nadzornik1"];
        $Nadzornik2=$_POST["nadzornik2"];
        $DatumNpz=$_POST["datum"];
        $Termin=$_POST["termin"];

        if (!isDate($DatumNpz)){
            echo "<script language='JavaScript'>";
            echo "alert('Napačen datum!')";
            echo "</script>";
            header ("Location: npz.php?idd=110");
        }else{
            $Datum=new DateTime(isDate($DatumNpz));

            $SQL = "UPDATE tabnpztermini SET idpredmet=$Predmet,datum='".$Datum->format('Y-m-d')."',razred=$VRazred,termin=$Termin,idprostor=$Prostor,iducitelj1=$Nadzornik1,iducitelj2=$Nadzornik2 WHERE id=".$_POST["popravi"];
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu!<br />$SQL<br />");
            }
            header("Location: npz.php?idd=110");
        }
        echo "</body>";
        echo "</html>";
        break;
    case "130": //briši npz termin
        $SQL = "DELETE FROM tabnpztermini WHERE id=".$Vid;
        $result = mysqli_query($link,$SQL);

        $SQL = "DELETE FROM TabNPZ WHERE idTermin=".$Vid;
        $result = mysqli_query($link,$SQL);

        header("Location: npz.php?idd=110");
        break;
    case "140": //vpis npz učenci redni
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $Izhod=false;
        $VSubmit=$_POST["submit"];
        switch ($VSubmit){
            case "Pošlji":
                echo "<h2>NPZ - Razporeditev</h2>";
                //'6. razredi
                $StUcencev=intval($_POST["ucencev6"]);
                for ($i2=1;$i2 <= 3;$i2++){
                    $Indx=1;
                    for ($i1=1;$i1 <= $StUcencev;$i1++){
                        $ReadUc=$_POST["ucenec6".$i1];
                        //$ReadPredmet=$_POST["predmet6".$i2.$i1];
                        if (isset($_POST["predmet6".$i2.$i1])){
                            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE tabrazred.idUcenec=".$ReadUc." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            
                            while ($R = mysqli_fetch_array($result)){
                                $Ucenci6[$i2][$Indx][0]=$R["iducenec"];
                                $Ucenci6[$i2][$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                                $Ucenci6[$i2][$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    $StUcencev6[$i2]=$Indx-1;
                }
                
                //'9. razredi
                $StUcencev=intval($_POST["ucencev9"]);
                for ($i2=1;$i2 <= 3;$i2++){
                    $Indx=1;
                    for ($i1=1;$i1 <= $StUcencev;$i1++){
                        $ReadUc=$_POST["ucenec9".$i1];
                        if (isset($_POST["predmet9".$i2.$i1])){
                            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE tabrazred.idUcenec=".$ReadUc." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            
                            while ($R = mysqli_fetch_array($result)){
                                $Ucenci9[$i2][$Indx][0]=$R["iducenec"];
                                $Ucenci9[$i2][$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                                $Ucenci9[$i2][$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    $StUcencev9[$i2]=$Indx-1;
                }
                
                $SQL = "SELECT razred,idpredmet FROM tabnpzpredmeti WHERE leto=".$VLeto." ORDER BY razred,prednost";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$Indx][0]=$R["razred"];
                    $Predmeti[$Indx][1]=$R["idpredmet"];
                    $Indx=$Indx+1;
                }
                
                //' prostorov po predmetih za 6. razrede
                $SQL = "SELECT tabnpztermini.idpredmet,tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=6 AND tabnpzpredmeti.razred=6 AND tabnpztermini.termin=0 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Šesti razredi</h3>";
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                
                echo "<form name='NPZTermin6' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='6'>";
                echo "<input type='hidden' name='stucencev61' value='".$StUcencev6[1]."'>";
                echo "<input type='hidden' name='stucencev62' value='".$StUcencev6[2]."'>";
                echo "<input type='hidden' name='stucencev63' value='".$StUcencev6[3]."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev6[$i1] <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev6[$i1]/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev6[$i1]){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev6[$i1]-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev6[$i1]-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci6[$i1][$Indx][0]."'>".$Ucenci6[$i1][$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci6[$i1][$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";

                //' prostorov po predmetih za 9. razrede
                $SQL = "SELECT tabnpztermini.idpredmet,tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=9 AND tabnpzpredmeti.razred=9 AND tabnpztermini.termin=0 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Deveti razredi</h3>";
                
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                
                echo "<form name='NPZTermin9' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='9'>";
                echo "<input type='hidden' name='stucencev91' value='".$StUcencev9[1]."'>";
                echo "<input type='hidden' name='stucencev92' value='".$StUcencev9[2]."'>";
                echo "<input type='hidden' name='stucencev93' value='".$StUcencev9[3]."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev9[$i1] <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev9[$i1]/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev9[$i1]){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev9[$i1]-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev9[$i1]-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci9[$i1][$Indx][0]."'>".$Ucenci9[$i1][$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci9[$i1][$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";
        }
        break;
    case "150": //vpis npz učenci
        echo "<a href='npz.php?idd=110'>Na vnos terminov</a><br />";
        
        $VRazred=$_POST["razred"];
        $SQL = "DELETE FROM tabnpz WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        
        if ($VRazred=="6"){
            $StUcencev=intval($_POST["stucencev61"]);
            if (isset($_POST["predmetp1"])){
                $Predmet=$_POST["predmetp1"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
            
            $StUcencev=intval($_POST["stucencev62"]);
            if (isset($_POST["predmetp2"])){
                $Predmet=$_POST["predmetp2"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
            
            $StUcencev=intval($_POST["stucencev63"]);
            if (isset($_POST["predmetp3"])){
                $Predmet=$_POST["predmetp3"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
        }else{
            $StUcencev=intval($_POST["stucencev91"]);
            if (isset($_POST["predmetp1"])){
                $Predmet=$_POST["predmetp1"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
            
            $StUcencev=intval($_POST["stucencev92"]);
            if (isset($_POST["predmetp2"])){
                $Predmet=$_POST["predmetp2"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
            
            $StUcencev=intval($_POST["stucencev93"]);
            if (isset($_POST["predmetp3"])){
                $Predmet=$_POST["predmetp3"];
            }else{
                $Predmet=0;
            }
            if ($Predmet > 0){
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if (isset($_POST["ucudel".$Predmet.$Indx])){
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT id FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabnpz SET miza=".$NPZUcenec[4]." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabnpz (leto,miza,idUcenec,idTermin) VALUES (".$VLeto.",".$NPZUcenec[4].",".$NPZUcenec[1].",".$NPZUcenec[3].")";
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $NPZUcenec[1]=$_POST["ucenec".$Predmet.$Indx];
                        $NPZUcenec[3]=$_POST["termin".$Predmet.$Indx];
                        $NPZUcenec[4]=$_POST["miza".$Predmet.$Indx];
                        
                        $SQL = "SELECT * FROM tabnpz WHERE leto=".$VLeto." AND idTermin=".$NPZUcenec[3]." AND idUcenec=".$NPZUcenec[1];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabnpz WHERE id=".$R["id"];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }
            }
        }

        $SQL = "SELECT tabnpz.*,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,";
        $SQL = $SQL . "tabrazred.razred AS rrazred,tabrazred.paralelka,";
        $SQL = $SQL . "tabnpztermini.razred AS trazred,tabnpztermini.termin,tabnpztermini.datum,";
        $SQL = $SQL . "tabpredmeti.id AS prid,tabpredmeti.oznaka AS proznaka,tabpredmeti.opis AS propis,";
        $SQL = $SQL . "tabprostor.idprostor AS pid,tabprostor.opis AS popis,tabprostor.oznaka AS poznaka,tabprostor.stevilka,";
        $SQL = $SQL . "tabucitelji.Priimek AS upriimek,tabucitelji.Ime AS uime,";
        $SQL = $SQL . "tabvzgojitelji.Priimek AS vpriimek,tabvzgojitelji.Ime AS vime FROM ";
        $SQL = $SQL."((((((tabnpz INNER JOIN tabucenci ON tabnpz.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL."INNER JOIN tabnpztermini ON tabnpz.idTermin=tabnpztermini.id) ";
        $SQL = $SQL."INNER JOIN tabpredmeti ON tabnpztermini.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL."INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor) ";
        $SQL = $SQL."INNER JOIN tabucitelji ON tabnpztermini.idUcitelj1=tabucitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabvzgojitelji ON tabnpztermini.idUcitelj2=tabvzgojitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec ";
        $SQL = $SQL."WHERE tabnpz.leto=".$VLeto." AND tabnpztermini.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
        $SQL = $SQL." ORDER BY tabnpztermini.termin,tabnpztermini.razred,tabpredmeti.VrstniRed,tabprostor.oznaka,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<h2>NPZ - Razporeditev učencev in nadzornikov po predmetih in učilnicah</h2>";
        echo "<a href='npz.php?idd=170'>Obrazci NPZ (PDF)</a><br /><br />";
        echo "<table border=0>";
        $CompPredmet=0;
        $CompRazred=0;
        $CompProstor=0;
        while ($R = mysqli_fetch_array($result)){
            if ($CompRazred != $R["trazred"]){
                $CompRazred=$R["trazred"];
                $CompProstor=$R["pid"];
                $CompPredmet=$R["prid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th></tr>";
            }
            if ($CompPredmet != $R["prid"]){
                $CompPredmet=$R["prid"];
                $CompProstor=$R["pid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th></tr>";
            }
            if ($CompProstor != $R["pid"]){
                $CompProstor=$R["pid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th></tr>";
            }
            echo "<tr>";
            echo "<td align=center>".$R["trazred"]."</td>";
            echo "<td>".$R["proznaka"]." - ".$R["propis"]."</td>";
            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["rrazred"].". ".$R["paralelka"]."</td>";
            $Datum=new DateTime($R["datum"]);
            echo "<td>".$Datum->format('d.m.Y')."</td>";
            echo "<td>".$R["popis"]." - ".$R["poznaka"]."/".$R["stevilka"]."</td>";
            echo "<td align=center>".$R["miza"]."</td>";
            echo "<td>".$R["upriimek"]." ".$R["uime"]."</td>";
            echo "<td>".$R["vpriimek"]." ".$R["vime"]."</td>";
            echo "</tr>";
        }
        echo "</table><br /><br />";

        echo "<a href='npz.php?idd=170'>Obrazci NPZ (PDF)</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "160": //vpis npz učenci dodatni
        echo "<a href='npz.php?idd=110'>Na vnos terminov</a><br />";
        
        $Izhod=false;
        $VSubmit=$_POST["submit"];
        switch ($VSubmit){
            case "Pošlji":
                echo "<h2>NPZ - Razporeditev</h2>";
                //'6. razredi
                $StUcencev=intval($_POST["ucencev6"]);
                for ($i2=1;$i2 <= 3;$i2++){
                    $Indx=1;
                    for ($i1=1;$i1 <= $StUcencev;$i1++){
                        $ReadUc=$_POST["ucenec6".$i1];
                        //$ReadPredmet=$_POST["predmet6".$i2.$i1];
                        if (isset($_POST["predmet6".$i2.$i1])){
                            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE tabrazred.idUcenec=".$ReadUc." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            
                            while ($R = mysqli_fetch_array($result)){
                                $Ucenci6[$i2][$Indx][0]=$R["iducenec"];
                                $Ucenci6[$i2][$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                                $Ucenci6[$i2][$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    $StUcencev6[$i2]=$Indx-1;
                }
                
                //'9. razredi
                $StUcencev=intval($_POST["ucencev9"]);
                for ($i2=1;$i2 <= 3;$i2++){
                    $Indx=1;
                    for ($i1=1;$i1 <= $StUcencev;$i1++){
                        $ReadUc=$_POST["ucenec9".$i1];
                        if (isset($_POST["predmet9".$i2.$i1])){
                            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE tabrazred.idUcenec=".$ReadUc." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            
                            while ($R = mysqli_fetch_array($result)){
                                $Ucenci9[$i2][$Indx][0]=$R["iducenec"];
                                $Ucenci9[$i2][$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                                $Ucenci9[$i2][$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
                                $Indx=$Indx+1;
                            }
                        }
                    }
                    $StUcencev9[$i2]=$Indx-1;
                }
                
                $SQL = "SELECT razred,idpredmet FROM tabnpzpredmeti WHERE leto=".$VLeto." ORDER BY razred,prednost";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$Indx][0]=$R["razred"];
                    $Predmeti[$Indx][1]=$R["idpredmet"];
                    $Indx=$Indx+1;
                }
                
                //' prostorov po predmetih za 6. razrede
                $SQL = "SELECT tabnpztermini.idpredmet,tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=6 AND tabnpzpredmeti.razred=6 AND tabnpztermini.termin=1 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Šesti razredi</h3>";
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                
                echo "<form name='NPZTermin6' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='6'>";
                echo "<input type='hidden' name='stucencev61' value='".$StUcencev6[1]."'>";
                echo "<input type='hidden' name='stucencev62' value='".$StUcencev6[2]."'>";
                echo "<input type='hidden' name='stucencev63' value='".$StUcencev6[3]."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev6[$i1] <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev6[$i1]/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev6[$i1]){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev6[$i1]-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev6[$i1]-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci6[$i1][$Indx][0]."'>".$Ucenci6[$i1][$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci6[$i1][$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";

                //' prostorov po predmetih za 9. razrede
                $SQL = "SELECT tabnpztermini.idpredmet,tabnpztermini.id,tabnpztermini.leto,tabnpztermini.razred,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,tabnpztermini.datum,tabnpztermini.termin,";
                $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.opis AS popis,tabprostor.idprostor,tabprostor.opis AS propis,tabprostor.oznaka AS proznaka,tabprostor.stevilka,tabprostor.stmiz FROM ";
                $SQL = $SQL . "((tabnpztermini INNER JOIN tabnpzpredmeti ON tabnpztermini.idPredmet=tabnpzpredmeti.idPredmet)";
                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id) ";
                $SQL = $SQL . " INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor ";
                $SQL = $SQL . "WHERE tabnpztermini.leto=".$VLeto." AND tabnpzpredmeti.leto=".$VLeto." AND tabnpztermini.razred=9 AND tabnpzpredmeti.razred=9 AND tabnpztermini.termin=1 ORDER BY prednost";
                $result = mysqli_query($link,$SQL);

                echo "<h3>Deveti razredi</h3>";
                
                $CompProstor=0;
                $Indx=0;
                $Indx1=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["idpredmet"] != $CompProstor){
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $Prostori[$Indx][0]=1;
                        $Prostori[$Indx][1]=$R["stmiz"];
                        $Prostori[$Indx][2]=$R["idpredmet"];
                        $Prostori[$Indx][3]=$R["poznaka"]." - ".$R["popis"];
                        
                        $CompProstor=$R["idpredmet"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Prostori[$Indx][0]=$Prostori[$Indx][0]+1;
                        $Prostori[$Indx][1]=$Prostori[$Indx][1]+$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][0]=$R["idprostor"];
                        $PredmetMiz[$Indx][$Indx1][1]=$R["stmiz"];
                        $PredmetMiz[$Indx][$Indx1][2]=$R["propis"]." - ".$R["proznaka"]."/".$R["stevilka"];
                        $PredmetMiz[$Indx][$Indx1][3]=$R["id"];
                        $Indx1=$Indx1+1;
                    }
                }
                
                echo "<form name='NPZTermin9' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='150'>";
                echo "<input type='hidden' name='razred' value='9'>";
                echo "<input type='hidden' name='stucencev91' value='".$StUcencev9[1]."'>";
                echo "<input type='hidden' name='stucencev92' value='".$StUcencev9[2]."'>";
                echo "<input type='hidden' name='stucencev93' value='".$StUcencev9[3]."'>";
                
                for ($i1=1;$i1 <= 3;$i1++){
                    if (isset($Prostori[$i1][1])){
                        if ($StUcencev9[$i1] <= $Prostori[$i1][1]){
                            echo "<input type='hidden' name='predmetp".$i1."' value='".$i1."'>";
                            $Povprecje[1]=intval($StUcencev9[$i1]/$Prostori[$i1][0]);
                            while ($Povprecje[1]*$Prostori[$i1][0] < $StUcencev9[$i1]){    
                                //'ce je sestevek povprecij manjsi od števila učencev, ga povečuje za 1
                                $Povprecje[1]=$Povprecje[1]+1;
                            }
                            
                            $Indx=1;
                            $RazlikaZap=0;
                            $SkupajPopolnjeno=0;  
                            while (1){
                                if ($Indx < $Prostori[$i1][0]){    
                                //'popolnjuje prostore s povprečnim številom učencev. Če je prostor manjši, vzame velikost prostora in korekcijo upošteva pri naslednjem
                                    $Zapolnjevanje=$Povprecje[1]+$RazlikaZap;
                                    if ($Zapolnjevanje > $PredmetMiz[$i1][$Indx][1]){
                                        $Zapolnjevanje=$PredmetMiz[$i1][$Indx][1];
                                        $RazlikaZap=$Povprecje[1]-$Zapolnjevanje;
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                    }else{
                                        $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                        $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        $RazlikaZap=0;
                                    }
                                    $Indx=$Indx+1;
                                }else{
                                    $RazlikaZap=0;
                                    if ($Indx == $Prostori[$i1][0]){
                                        $Zapolnjevanje=$StUcencev9[$i1]-$SkupajPopolnjeno;
                                        if ($Zapolnjevanje <= $PredmetMiz[$i1][$Indx][1]){
                                            $PolnjenjeProstorov[$Indx]=$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }else{    //'zmanjka prostora
                                            $PolnjenjeProstorov[$Indx]=$PredmetMiz[$i1][$Indx][1];
                                            $RazlikaZap=$StUcencev9[$i1]-$SkupajPopolnjeno-$Zapolnjevanje;
                                            $SkupajPopolnjeno=$SkupajPopolnjeno+$PolnjenjeProstorov[$Indx];
                                        }
                                        $Indx=$Indx+1;
                                    }else{
                                        break;
                                    }
                                }
                            }
                            //'če zmanjka prostora, ker so bili veliki prostori premalo polnjeni, polni prostore po vrsti, kjer je prostor

                            if ($RazlikaZap > 0){
                                $Indx=1;
                                while (1){
                                    if ($Indx <= $Prostori[$i1][0]){
                                        while (1){
                                            if ($RazlikaZap==0){
                                                $Indx=$Indx+1;
                                                break;
                                            }
                                            if ($PolnjenjeProstorov[$Indx] < $PredmetMiz[$i1][$Indx][1]){
                                                $PolnjenjeProstorov[$Indx]=$PolnjenjeProstorov[$Indx]+1;
                                                $RazlikaZap=$RazlikaZap-1;
                                            }else{
                                                $Indx=$Indx+1;
                                                if ($Indx > $Prostori[$i1][0]){
                                                    break;
                                                }
                                            }
                                        }
                                    }else{
                                        break;
                                    }
                                }
                            }
                            
                            //'izpis učencev po prostorih za določen predmet
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Ime</th><th>Udeležba</th><th>Predmet</th><th>Prostor</th><th>Miza</th></tr>";
                            $Indx=1;
                            for ($Indx1=1;$Indx1 <= $Prostori[$i1][0];$Indx1++){
                                for ($Indx2=1;$Indx2 <= $PolnjenjeProstorov[$Indx1];$Indx2++){
                                    echo "<tr>";
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><input type='hidden' name='ucenec".$i1.$Indx."' value='".$Ucenci9[$i1][$Indx][0]."'>".$Ucenci9[$i1][$Indx][1]."</td>"; // 'Ime
                                    if ($Ucenci9[$i1][$Indx][2] > 0){
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox' checked='checked'></td>"; // 'Udeležba
                                    }else{
                                        echo "<td><input name='ucudel".$i1.$Indx."' type='checkbox'></td>";
                                    }
                                    echo "<td><input type='hidden' name='predmet".$i1.$Indx."' value='".$Prostori[$i1][2]."'>".$Prostori[$i1][3]."</td>"; // 'predmet
                                    echo "<td><input type='hidden' name='termin".$i1.$Indx."' value='".$PredmetMiz[$i1][$Indx1][3]."'>".$PredmetMiz[$i1][$Indx1][2]."</td>"; // 'prostor
                                    echo "<td><input name='miza".$i1.$Indx."' type='text' value='".$Indx2."' size='3'></td>";
                                    echo "</tr>";
                                    $Indx=$Indx+1;
                                }
                            }
                            echo "</table><br />";
                        }else{
                            echo "Premalo prostora/miz za predmet ".$Prostori[$i1][3]."<br />";
                        }
                    }
                }
                echo "<input name='submit' type='submit' value='Pošlji'><br />";
                echo "</form>";
        }
        break;
    case "170": //obrazci npz pdf
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabnpz.*,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,";
        $SQL = $SQL . "tabrazred.razred AS rrazred,tabrazred.paralelka,";
        $SQL = $SQL . "tabnpztermini.razred AS trazred,tabnpztermini.termin,tabnpztermini.datum,tabnpztermini.iducitelj1,tabnpztermini.iducitelj2,";
        $SQL = $SQL . "tabpredmeti.id AS prid,tabpredmeti.oznaka AS proznaka,tabpredmeti.opis AS propis,";
        $SQL = $SQL . "tabprostor.idprostor AS pid,tabprostor.opis AS popis,tabprostor.oznaka AS poznaka,tabprostor.stevilka,tabprostor.stmiz,";
        $SQL = $SQL . "tabucitelji.Priimek AS upriimek,tabucitelji.Ime AS uime,";
        $SQL = $SQL . "tabvzgojitelji.Priimek AS vpriimek,tabvzgojitelji.Ime AS vime FROM ";
        $SQL = $SQL."((((((tabnpz INNER JOIN tabucenci ON tabnpz.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL."INNER JOIN tabnpztermini ON tabnpz.idTermin=tabnpztermini.id) ";
        $SQL = $SQL."INNER JOIN tabpredmeti ON tabnpztermini.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL."INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor) ";
        $SQL = $SQL."INNER JOIN tabucitelji ON tabnpztermini.idUcitelj1=tabucitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabvzgojitelji ON tabnpztermini.idUcitelj2=tabvzgojitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec ";
        $SQL = $SQL."WHERE tabnpz.leto=".$VLeto." AND tabnpztermini.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
        $SQL = $SQL." ORDER BY tabnpztermini.termin,tabnpztermini.razred,tabpredmeti.VrstniRed,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        $CompPredmet=0;
        $CompRazred=0;
        $ompProstor=0;
        $VStran=0;
        $Indx1=0;
        $Indx=1;
        $XPoz[1]=15;
        $XPoz[2]=125;
        $YPoz=110;
        while ($R = mysqli_fetch_array($result)){
            if ($CompRazred != $R["trazred"]){
                $CompRazred=$R["trazred"];
                $CompProstor=$R["pid"];
                $CompPredmet=$R["prid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;
                
                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }
                
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $VStran=$VStran+1;

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Miza");
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            if ($CompPredmet != $R["prid"]){
                $CompPredmet=$R["prid"];
                $CompProstor=$R["pid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;

                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $VStran=$VStran+1;

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Miza");
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            if ($CompProstor != $R["pid"]){
                $CompProstor=$R["pid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;

                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $VStran=$VStran+1;

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Miza");
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($R["ucpriimek"]." ".$R["ucime"].", ".$R["rrazred"].". ".mb_strtolower($R["paralelka"],$encoding));
            $pdf->SetXY($XPoz[1],$YPoz+$Indx*6);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($R["miza"]);
            $pdf->SetXY($XPoz[2],$YPoz+$Indx*6);
            $pdf->Cell(25,0,$txt,0,2,"C");

            $CountUc=$CountUc+1;
            $Indx=$Indx+1;
        }

        $result = mysqli_query($link,$SQL);

        $CompPredmet=0;
        $CompRazred=0;
        $CompProstor=0;
        $Indx1=0;
        $Indx=1;
        $XPoz[1]=15;
        $XPoz[2]=125;
        $YPoz=110;
        while ($R = mysqli_fetch_array($result)){
            if ($CompRazred != $R["trazred"]){
                $CompRazred=$R["trazred"];
                $CompProstor=$R["pid"];
                $CompPredmet=$R["prid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;
                
                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                //izriše mize
                for ($i1=1;$i1 <= $R["stmiz"];$i1++){
                    switch ($i1){
                        case 1:
                            $pdf->Rect(140,230,56,26);
                            break;
                        case 2:
                            $pdf->Rect(79,230,56,26);
                            break;
                        case 3:
                            $pdf->Rect(15,230,56,26);
                            break;
                        case 4:
                            $pdf->Rect(140,200,56,26);
                            break;
                        case 5:
                            $pdf->Rect(79,200,56,26);
                            break;
                        case 6:
                            $pdf->Rect(15,200,56,26);
                            break;
                        case 7:
                            $pdf->Rect(140,170,56,26);
                            break;
                        case 8:
                            $pdf->Rect(79,170,56,26);
                            break;
                        case 9:
                            $pdf->Rect(15,170,56,26);
                            break;
                        case 10:
                            $pdf->Rect(140,140,56,26);
                            break;
                        case 11:
                            $pdf->Rect(79,140,56,26);
                            break;
                        case 12:
                            $pdf->Rect(15,140,56,26);
                            break;
                        case 13:
                            $pdf->Rect(140,110,56,26);
                            break;
                        case 14:
                            $pdf->Rect(79,110,56,26);
                            break;
                        case 15:
                            $pdf->Rect(15,110,56,26);
                    }
                }
            }
            if ($CompPredmet != $R["prid"]){
                $CompPredmet=$R["prid"];
                $CompProstor=$R["pid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;

                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }
                
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $VStran=$VStran+1;

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                
                //izriše mize
                for ($i1=1;$i1 <= $R["stmiz"];$i1++){
                    switch ($i1){
                        case 1:
                            $pdf->Rect(140,230,56,26);
                            break;
                        case 2:
                            $pdf->Rect(79,230,56,26);
                            break;
                        case 3:
                            $pdf->Rect(15,230,56,26);
                            break;
                        case 4:
                            $pdf->Rect(140,200,56,26);
                            break;
                        case 5:
                            $pdf->Rect(79,200,56,26);
                            break;
                        case 6:
                            $pdf->Rect(15,200,56,26);
                            break;
                        case 7:
                            $pdf->Rect(140,170,56,26);
                            break;
                        case 8:
                            $pdf->Rect(79,170,56,26);
                            break;
                        case 9:
                            $pdf->Rect(15,170,56,26);
                            break;
                        case 10:
                            $pdf->Rect(140,140,56,26);
                            break;
                        case 11:
                            $pdf->Rect(79,140,56,26);
                            break;
                        case 12:
                            $pdf->Rect(15,140,56,26);
                            break;
                        case 13:
                            $pdf->Rect(140,110,56,26);
                            break;
                        case 14:
                            $pdf->Rect(79,110,56,26);
                            break;
                        case 15:
                            $pdf->Rect(15,110,56,26);
                    }
                }
            }
            if ($CompProstor != $R["pid"]){
                $CompProstor=$R["pid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;
                if ($VStran > 0){
                    $pdf->AddPage("P","A4");
                }

                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $VStran=$VStran+1;

                $pdf->Image("logo1.gif",15,10,30);

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Nacionalno preverjanje znanja");
                $pdf->SetXY(10,45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za ".$R["trazred"].". razrede");
                $pdf->SetXY(10,53);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arial_CE','',14);
                $txt=ToWin("Predmet: ".$R["proznaka"]." - ".$R["propis"]);
                $pdf->SetXY(10,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $Datum=new DateTime($R["datum"]);
                if ($R["termin"]==0){
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - redni termin");
                }else{
                    $txt=ToWin("Datum: ".$Datum->format('j.n.Y')." - dodatni termin");
                }
                $pdf->SetXY(10,77);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Prostor: ".$R["popis"]." - ".$R["poznaka"]." (učilnica ".$R["stevilka"].")");
                $pdf->SetXY(10,84);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($R["iducitelj1"] > 0){
                    $txt=ToWin("1. nadzorni učitelj: ".$R["uime"]." ".$R["upriimek"]);
                    $pdf->SetXY(10,91);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                if ($R["iducitelj2"] > 0){
                    $txt=ToWin("2. nadzorni učitelj: ".$R["vime"]." ".$R["vpriimek"]);
                    $pdf->SetXY(10,98);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                
                //izriše mize
                for ($i1=1;$i1 <= $R["stmiz"];$i1++){
                    switch ($i1){
                        case 1:
                            $pdf->Rect(140,230,56,26);
                            break;
                        case 2:
                            $pdf->Rect(79,230,56,26);
                            break;
                        case 3:
                            $pdf->Rect(15,230,56,26);
                            break;
                        case 4:
                            $pdf->Rect(140,200,56,26);
                            break;
                        case 5:
                            $pdf->Rect(79,200,56,26);
                            break;
                        case 6:
                            $pdf->Rect(15,200,56,26);
                            break;
                        case 7:
                            $pdf->Rect(140,170,56,26);
                            break;
                        case 8:
                            $pdf->Rect(79,170,56,26);
                            break;
                        case 9:
                            $pdf->Rect(15,170,56,26);
                            break;
                        case 10:
                            $pdf->Rect(140,140,56,26);
                            break;
                        case 11:
                            $pdf->Rect(79,140,56,26);
                            break;
                        case 12:
                            $pdf->Rect(15,140,56,26);
                            break;
                        case 13:
                            $pdf->Rect(140,110,56,26);
                            break;
                        case 14:
                            $pdf->Rect(79,110,56,26);
                            break;
                        case 15:
                            $pdf->Rect(15,110,56,26);
                    }
                }
            }
            
            switch ($R["miza"]){
                case 1:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(141,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(150,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(150,242);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(150,248);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 2:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(80,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(90,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(90,242);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(90,248);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 3:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(16,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(26,236);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(26,242);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(26,248);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 4:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(141,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(150,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(150,212);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(150,218);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 5:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(80,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(90,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(90,212);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(90,218);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 6:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(16,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(26,206);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(26,212);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(26,218);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 7:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(141,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(150,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(150,182);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(150,188);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 8:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(80,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(90,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(90,182);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(90,188);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 9:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(16,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(26,176);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(26,182);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(26,188);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 10:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(141,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(150,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(150,152);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(150,158);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 11:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(80,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(90,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(90,152);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(90,158);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 12:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(16,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(26,146);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(26,152);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(26,158);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 13:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(141,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(150,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(150,122);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(150,128);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 14:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(80,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(90,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(90,122);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(90,128);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                case 15:
                    $pdf->SetFont('arial_CE','',14);
                    $txt=ToWin($R["miza"]);
                    $pdf->SetXY(16,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin($R["ucime"]);
                    $pdf->SetXY(26,116);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["ucpriimek"]);
                    $pdf->SetXY(26,122);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $txt=ToWin($R["rrazred"].". ".mb_strtolower($R["paralelka"]));
                    $pdf->SetXY(26,128);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    break;
                    
            }
            $CountUc=$CountUc+1;
            $Indx=$Indx+1;
        }

        $pdf->Output("npz.pdf","D");
        break;
    case "200": //npz učenci
        echo "<a href='npz.php?idd=110'>Na vnos terminov</a><br />";
        
        $SQL = "SELECT tabnpz.*,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,";
        $SQL = $SQL . "tabrazred.razred AS rrazred,tabrazred.paralelka,";
        $SQL = $SQL . "tabnpztermini.razred AS trazred,tabnpztermini.termin,tabnpztermini.datum,";
        $SQL = $SQL . "tabpredmeti.id AS prid,tabpredmeti.oznaka AS proznaka,tabpredmeti.opis AS propis,";
        $SQL = $SQL . "tabprostor.idprostor AS pid,tabprostor.opis AS popis,tabprostor.oznaka AS poznaka,tabprostor.stevilka,";
        $SQL = $SQL . "tabucitelji.Priimek AS upriimek,tabucitelji.Ime AS uime,";
        $SQL = $SQL . "tabvzgojitelji.Priimek AS vpriimek,tabvzgojitelji.Ime AS vime FROM ";
        $SQL = $SQL."(((((((tabnpz INNER JOIN tabucenci ON tabnpz.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL."INNER JOIN tabnpztermini ON tabnpz.idTermin=tabnpztermini.id) ";
        $SQL = $SQL."INNER JOIN tabpredmeti ON tabnpztermini.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL."INNER JOIN tabprostor ON tabnpztermini.idProstor=tabprostor.idProstor) ";
        $SQL = $SQL."INNER JOIN tabucitelji ON tabnpztermini.idUcitelj1=tabucitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabvzgojitelji ON tabnpztermini.idUcitelj2=tabvzgojitelji.idUcitelj) ";
        $SQL = $SQL."INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN TabRazDat ON tabrazred.idRazred=TabRazDat.id ";
        $SQL = $SQL."WHERE tabnpz.leto=".$VLeto." AND tabnpztermini.leto=".$VLeto." AND TabRazDat.leto=".$VLeto;
        $SQL = $SQL." ORDER BY tabnpztermini.termin,tabnpztermini.razred,tabpredmeti.VrstniRed,tabucenci.Priimek,tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        echo "<h2>NPZ - Razporeditev učencev in nadzornikov po predmetih in učilnicah</h2>";
        echo "<a href='npz.php?idd=170'>Obrazci NPZ (PDF)</a><br /><br />";
        echo "<table border=0>";
        $CompPredmet=0;
        $CompRazred=0;
        $CompProstor=0;
        while ($R = mysqli_fetch_array($result)){
            if ($CompRazred != $R["trazred"]){
                $CompRazred=$R["trazred"];
                $CompProstor=$R["pid"];
                $CompPredmet=$R["prid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th><th>Briši</th></tr>";
            }
            if ($CompPredmet != $R["prid"]){
                $CompPredmet=$R["prid"];
                $CompProstor=$R["pid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th><th>Briši</th></tr>";
            }
            if ($CompProstor != $R["pid"]){
                $CompProstor=$R["pid"];
                echo "</table><br />";
                if ($R["termin"]==0){
                    echo "Redni termin<br />";
                }else{
                    echo "Dodatni termin<br />";
                }
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='100'>Predmet</th><th width='220'>Učenec</th><th width='80'>Datum</th><th width='150'>Prostor</th><th>Miza</th><th width='120'>1. nadzornik</th><th width='120'>2. nadzornik</th><th>Briši</th></tr>";
            }
            echo "<tr>";
            echo "<td align=center>".$R["trazred"]."</td>";
            echo "<td>".$R["proznaka"]." - ".$R["propis"]."</td>";
            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["rrazred"].". ".$R["paralelka"]."</td>";
            $Datum=new DateTime($R["datum"]);
            echo "<td>".$Datum->format('d.m.Y')."</td>";
            echo "<td>".$R["popis"]." - ".$R["poznaka"]."/".$R["stevilka"]."</td>";
            echo "<td align=center>".$R["miza"]."</td>";
            echo "<td>".$R["upriimek"]." ".$R["uime"]."</td>";
            echo "<td>".$R["vpriimek"]." ".$R["vime"]."</td>";
            echo "<td><a href='npz.php?idd=210&id=".$R["id"]."'>Odstrani</a></td>";
            echo "</tr>";
        }
        echo "</table><br /><br />";

        echo "<a href='npz.php?idd=170'>Obrazci NPZ (PDF)</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "210": //npz briši učenca
        $SQL = "DELETE FROM tabnpz WHERE id=".$Vid;
        $result = mysqli_query($link,$SQL);

        header("Location: npz.php?idd=200");
        break;
    case "300": //npz vpis rezultatov
        echo "<a href='npz.php?idd=110'>Na vnos terminov</a><br />";
        
        $SQL = "SELECT tabnpzpredmeti.razred,tabnpzpredmeti.idpredmet,tabpredmeti.oznaka FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE leto=".$VLeto." ORDER BY razred,prednost";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx][0]=$R["razred"];
            $Predmeti[$Indx][1]=$R["idpredmet"];
            $Predmeti[$Indx][2]=$R["oznaka"];
            $Indx=$Indx+1;
        }

        $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE razred=6 AND leto=".$VLeto." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci6[$Indx][0]=$R["iducenec"];
            $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
            $Ucenci6[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
            $Indx=$Indx+1;
        }
        $StUcencev6=$Indx-1;

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.razred=9 AND tabrazdat.leto=".$VLeto." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci9[$Indx][0]=$R["iducenec"];
            $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"];
            $Ucenci9[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
            $Indx=$Indx+1;
        }
        $StUcencev9=$Indx-1;

        $SQL = "SELECT id FROM tabnpzocene WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $SQL = "DELETE FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred=6) AND NOT (idPredmet IN (".$Predmeti[1][1].",".$Predmeti[2][1].",".$Predmeti[3][1]."))";
            $result = mysqli_query($link,$SQL);
            $SQL = "DELETE FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred=9) AND NOT (idPredmet IN (".$Predmeti[4][1].",".$Predmeti[5][1].",".$Predmeti[6][1]."))";
            $result = mysqli_query($link,$SQL);
            
            //'šesti razredi
            for ($i1=1;$i1 <= 3;$i1++){
                for ($Indx=1;$Indx <= $StUcencev6;$Indx++){
                    $SQL = "SELECT * FROM tabnpzocene WHERE leto=".$VLeto." AND idUcenec=".$Ucenci6[$Indx][0]." AND idPredmet=".$Predmeti[$i1][1];
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnpzocene SET razred=6 WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idPredmet,razred,odstotek,tock,moznihTock) VALUES (".$VLeto.",".$Ucenci6[$Indx][0].",".$Predmeti[$i1][1].",6,0,0,0)";
                    }
                    $result = mysqli_query($link,$SQL);
                }
            }
            
            //'deveti razredi
            for ($i1=4;$i1 <= 6;$i1++){
                for ($Indx=1;$Indx <= $StUcencev9;$Indx++){
                    $SQL = "SELECT * FROM tabnpzocene WHERE leto=".$VLeto." AND idUcenec=".$Ucenci9[$Indx][0]." AND idPredmet=".$Predmeti[$i1][1];
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnpzocene SET razred=9 WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idPredmet,razred,odstotek,tock,moznihTock) VALUES (".$VLeto.",".$Ucenci9[$Indx][0].",".$Predmeti[$i1][1].",9,0,0,0)";
                    }
                    $result = mysqli_query($link,$SQL);
                }
            }
        }else{
            //'šesti razredi
            for ($i1=1;$i1 <= 3;$i1++){
                for ($Indx=1;$Indx <= $StUcencev6;$Indx++){
                    $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idPredmet,razred,odstotek,tock,moznihTock) VALUES (".$VLeto.",".$Ucenci6[$Indx][0].",".$Predmeti[$i1][1].",6,0,0,0)";
                    $result = mysqli_query($link,$SQL);
                }
            }
            
            //'deveti razredi
            for ($i1=4;$i1 <= 6;$i1++){
                for ($Indx=1;$Indx <= $StUcencev9;$Indx++){
                    $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idPredmet,razred,odstotek,tock,moznihTock) VALUES (".$VLeto.",".$Ucenci9[$Indx][0].",".$Predmeti[$i1][1].",9,0,0,0)";
                    $result = mysqli_query($link,$SQL);
                }
            }
        }

        echo "<h2>Vnos ocen NPZ</h2>";
        echo "<form name='NPZRezultati6' method=post action='npz.php'>";
        echo "<input name='idd' type='hidden' value='310'>";

        echo "<table border=1>";
        echo "<tr><th>Razred</th><th>Predmet</th><th>Možnih točk</th></tr>";
        for ($Indx=1;$Indx <= 6;$Indx++){
            echo "<tr>";
            echo "<td align=center>".$Predmeti[$Indx][0]."</td>";
            echo "<td>".$Predmeti[$Indx][2]."</td>";
            if ($Indx < 4){
                $SQL = "SELECT moznihtock FROM tabnpzocene WHERE leto=".$VLeto." AND razred=6 AND idPredmet=".$Predmeti[$Indx][1]." LIMIT 0,1";
            }else{
                $SQL = "SELECT moznihtock FROM tabnpzocene WHERE leto=".$VLeto." AND razred=9 AND idPredmet=".$Predmeti[$Indx][1]." LIMIT 0,1";
            }
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if (isset($R["moznihtock"])){
                    echo "<td><input type='text' name='predmet".$Indx."' size='10' value='".$R["moznihtock"]."'></td>";
                }else{
                    echo "<td><input type='text' name='predmet".$Indx."' size='10'></td>";
                }
            }else{
                echo "<td><input type='text' name='predmet".$Indx."' size='10'></td>";
            }
            echo "</tr>";
        }
        echo "</table><br /><br />";

        $SQL = "SELECT tabnpzocene.id,tabnpzocene.tock,tabnpzocene.razred AS orazred,";
        $SQL = $SQL . "tabucenci.priimek,tabucenci.ime,";
        $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,";
        $SQL = $SQL . "tabrazdat.razred AS rrazred,tabrazdat.oznaka AS roznaka FROM ";
        $SQL = $SQL . "(((tabnpzocene INNER JOIN tabucenci ON tabnpzocene.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabnpzocene.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
//        $SQL = $SQL . "WHERE tabnpzocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." ORDER BY tabnpzocene.razred,VrstniRed,priimek,ime";
        $SQL = $SQL . "WHERE tabnpzocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." ORDER BY tabrazdat.razred,tabrazdat.oznaka,VrstniRed,priimek,ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1>";
        echo "<tr><th>Razred</th><th>Učenec</th><th>Predmet</th><th>Točk</th></tr>";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align=center>".$R["orazred"]."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["rrazred"].". ".$R["roznaka"]."</td>";
            echo "<td>".$R["poznaka"]."</td>";
            echo "<td><input type='hidden' name='uc".$Indx."' value='".$R["id"]."'><input type='text' name='ocena".$R["id"]."' size='4' value='".$R["tock"]."'></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table>";
        echo "<input type='hidden' name='zapisov' value='".($Indx-1)."'>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";

        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "310": //npz vpis
        $SQL = "SELECT tabnpzpredmeti.razred,tabnpzpredmeti.idpredmet FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE leto=".$VLeto." ORDER BY razred,prednost";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx][0]=$R["razred"];
            $Predmeti[$Indx][1]=$R["idpredmet"];
            if (!is_numeric($_POST["predmet".$Indx])){
                $Predmeti[$Indx][2]=0;
            }else{
                $Predmeti[$Indx][2]=intval($_POST["predmet".$Indx]);
            }
            $Indx=$Indx+1;
        }

        $zapisov=intval($_POST["zapisov"]);
        for ($Indx=1;$Indx <= $zapisov;$Indx++){
            $i1=$_POST["uc".$Indx];
            $i2=$_POST["ocena".$i1];
            $SQL = "UPDATE tabnpzocene SET tock=".$i2." WHERE id=".$i1;
            $result = mysqli_query($link,$SQL);
        }

        for ($Indx=1;$Indx <= 3;$Indx++){
            if ($Predmeti[$Indx][2] > 0){
                $SQL = "UPDATE tabnpzocene SET moznihTock=".$Predmeti[$Indx][2]." WHERE idPredmet=".$Predmeti[$Indx][1]." AND razred=6 AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
            }
        }
        for ($Indx=4;$Indx <= 6;$Indx++){
            if ($Predmeti[$Indx][2] > 0){
                $SQL = "UPDATE tabnpzocene SET moznihTock=".$Predmeti[$Indx][2]." WHERE idPredmet=".$Predmeti[$Indx][1]." AND razred=9 AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
            }
        }

        $SQL = "SELECT id,tock,moznihtock FROM tabnpzocene WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $i=$R["tock"];
            $j=$R["moznihtock"];
            if ($j > 0){
                $odstotek=$i/$j*100;
            }else{
                $odstotek = 0;
            }
            $NPZUcenec[$Indx][1]=$i;
            $NPZUcenec[$Indx][2]=$j;
            $NPZUcenec[$Indx][3]=round($odstotek);
            $NPZUcenec[$Indx][0]=$R["id"];
            $Indx=$Indx+1;
        }
        $i=$Indx-1;
        for ($Indx=1;$Indx <= $i;$Indx++){
            $SQL = "UPDATE tabnpzocene SET odstotek=".$NPZUcenec[$Indx][3]." WHERE id=".$NPZUcenec[$Indx][0];
            $result = mysqli_query($link,$SQL);
        }
    
        header("Location: npz.php?idd=400");
        break;
    case "400": //npz izpis rezultatov
        echo "<a href='npz.php?idd=110'>Na vnos terminov</a><br />";
        
        $SQL = "SELECT tabnpzpredmeti.razred,tabnpzpredmeti.idpredmet,tabpredmeti.oznaka FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE leto=".$VLeto." ORDER BY razred,prednost";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$Indx][0]=$R["razred"];
            $Predmeti[$Indx][1]=$R["idpredmet"];
            $Predmeti[$Indx][2]=$R["oznaka"];
            $Indx=$Indx+1;
        }

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.razred=6 AND tabrazdat.leto=".$VLeto." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci6[$Indx][0]=$R["iducenec"];
            $Ucenci6[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"];
            $Ucenci6[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
            $Indx=$Indx+1;
        }
        $StUcencev6=$Indx-1;

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.razred=9 AND tabrazdat.leto=".$VLeto." ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Ucenci9[$Indx][0]=$R["iducenec"];
            $Ucenci9[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"];
            $Ucenci9[$Indx][2]=1; // '0-ne sodeluje, 1-sodeluje
            $Indx=$Indx+1;
        }
        $StUcencev9=$Indx-1;

        $SQL = "SELECT tabnpzocene.razred AS orazred,tabnpzocene.tock,tabnpzocene.moznihtock,tabnpzocene.odstotek,";
        $SQL = $SQL . "tabucenci.priimek,tabucenci.ime,";
        $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,tabpredmeti.id,";
        $SQL = $SQL . "tabrazdat.razred AS rrazred,tabrazdat.oznaka AS roznaka FROM ";
        $SQL = $SQL . "(((tabnpzocene INNER JOIN tabucenci ON tabnpzocene.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabnpzocene.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabnpzocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." ORDER BY tabnpzocene.razred,VrstniRed,priimek,ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1>";
        echo "<tr><th>Razred</th><th width='220'>Učenec</th><th>Predmet</th><th>Točk</th><th>Možnih točk</th><th>Odstotek</th></tr>";
        $Indx=1;
        $CompPredmet=16;
        while ($R = mysqli_fetch_array($result)){
            if ($CompPredmet != $R["id"]){
                echo "</table><br /><br />";
                echo "<table border=1>";
                echo "<tr><th>Razred</th><th width='220'>Učenec</th><th>Predmet</th><th>Točk</th><th>Možnih točk</th><th>Odstotek</th></tr>";
                $CompPredmet= $R["id"];
            }
            echo "<tr>";
            echo "<td align=center>".$R["orazred"]."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["rrazred"].". ".$R["roznaka"]."</td>";
            echo "<td>".$R["poznaka"]."</td>";
            echo "<td align=center>".$R["tock"]."</td>";
            echo "<td align=center>".$R["moznihtock"]."</td>";
            echo "<td align=center>".$R["odstotek"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table>";
        echo "</body>";
        echo "</html>";
        break;
    case "500": //prijava npz 6. razred
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            if ($R["razred"] != 6){
               echo "<h2>Izbrati morate 6. razred</h2>";
                $VRazred1=$R["razred"];
            }else{
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
            }
        }
        if ($VRazred1 == 6){
            if (isset($_POST["stucencev"])){
                $SteviloUcencev=$_POST["stucencev"];
            }else{
                $SteviloUcencev=0;
            }

            if ($SteviloUcencev > 0){
                for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                    $ucenec=$_POST["ucenec".$Indx];
                    $SQL="SELECT id FROM tabnpz6 WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnpz6 SET ";
                        if (isset($_POST["izjava".$Indx])){
                            $SQL=$SQL."npz=true,";
                        }else{
                            $SQL=$SQL."npz=false,";
                        }
                        $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabnpz6 (";
                        $SQL=$SQL."npz,vpisal,cas,leto,idUcenec) VALUES (";
                        if (isset($_POST["izjava".$Indx])){
                            $SQL=$SQL."true,";
                        }else{
                            $SQL=$SQL."false,";
                        }
                        $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$ucenec.")";
                    }
                    $result = mysqli_query($link,$SQL);
                }
                echo "<h2>Podatki SO vpisani!</h2>";

                if ($Opravila==1){
                    $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Ucitelj=$R["iducitelj"];
                    }else{
                        $Ucitelj=0;
                    }
                    
                    $SQL = "SELECT tabdeldogodek.* FROM ";
                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Prijave na NPZ - 6. razred' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VDogodki[$Indx]=$R["id"];
                        $Indx=$Indx+1;
                    }
                    $StDogodkov=$Indx-1;

                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }

            $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
            $SQL = $SQL."((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
            $SQL = $SQL."WHERE tabrazred.leto=".$VLeto." AND tabrazred.idRazred=" . $VRazred;
            $SQL = $SQL." ORDER BY tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            //'Izpis razrednih podatkov
            if (mysqli_num_rows($result) > 0){
                echo "<h2>Prijava na NPZ - ".$R["razred"].". ".$R["oznaka"]." - ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<form  name='prijava' method=post action='npz.php'>";
                echo "<input name='idd' type='hidden' value='500'>";
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                echo "<th>Udeležba</th>";
                echo "</tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    $SQL = "SELECT npz FROM tabnpz6 WHERE iducenec=".$R["iducenec"]." AND leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["npz"]){
                            echo "<td><input name='izjava".$Indx."' type='checkbox' checked></td>";
                        }else{
                            echo "<td><input name='izjava".$Indx."' type='checkbox'></td>";
                        }
                    }else{
                        echo "<td><input name='izjava".$Indx."' type='checkbox'></td>";
                    }
                    echo "</tr>";
                    $Indx = $Indx+1;
                } 
                $SteviloUcencev=$Indx-1;
                echo "</table>";
                echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input name='submit' type='submit' value='Pošlji'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'></form><br /><br />";

                echo "</form>";
            }
        }
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='izborrazreda.php?id=prijavanpz'>Na izbor razreda</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "510": //obvestilo npz 6 pdf
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        $pdf = new FPDF();
        $pdf->SetAutoPageBreak(false);

        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");


        $SQL = "SELECT tabucenci.iducenec,tabrazdat.idsola FROM ";
        $SQL = $SQL . "((tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
        $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx]=$R["iducenec"];
            $sola[$Indx]=$R["idsola"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;

        for ($IndxRazred=0;$IndxRazred <= $StUcencev;$IndxRazred++){
            $SQL = "SELECT * FROM tabsola WHERE id=".$sola[$IndxRazred];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }

            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }

            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if (!isset($_POST["obrazec"])){
                $pdf->Image("img/obvestilonpz.jpg",0,0,210,297);
            }
            
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,50-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,60-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //izpis razreda za katerega je opravljal npz (6 ali 9)
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($Razred["razred"].".");
            $pdf->SetXY(143+$KorX,87-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10+$KorX,106-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20+$KorX,117-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78+$KorX,117-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
                $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            }else{
                $txt=ToWin($oUcenec->getMaticniList());
            }
            $pdf->SetXY(20+$KorX,128-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(78+$KorX,128-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(153+$KorX,128-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");


            $SQL = "SELECT tabnpzocene.tock,tabnpzocene.odstotek, tabpredmeti.id,tabpredmeti.opis FROM tabnpzocene INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id WHERE idUcenec=".$oUcenec->getIdUcenec()." AND leto=".$VLeto." ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                switch ($R["id"]){
                    case 16: //slovenščina
                        $pdf->SetFont('arial_CE','',12);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(90+$KorX,178-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(130+$KorX,178-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");
                        break;
                    case 11: //matematika
                        $pdf->SetFont('arial_CE','',12);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(90+$KorX,185-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(130+$KorX,185-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");
                        break;
                    default: //tretji predmet
                        $pdf->SetFont('arial_CE','',12);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(90+$KorX,191-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(130+$KorX,191-$KorY);
                        $pdf->Cell(30,0,$txt,0,2,"C");

                        /*if ($R["tock"]==0){
                            $txt="--------";
                        }else{
						*/
                            $txt=ToWin(mb_strtolower($R["opis"],$encoding));
                        //}
                        $pdf->SetXY(35+$KorX,191-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                }
            }
            
            if ($SpolRavnatelj=="M" ){
                $pdf->Line(153+$KorX, 282-$KorY, 165+$KorX, 282-$KorY);
            }else{
                $pdf->Line(137+$KorX, 282-$KorY, 153+$KorX, 282-$KorY);
            }
            //opombe
            $pdf->SetFont('arial_CE','',$FontSize);
            if (strlen($Razred["opomba"]) == 0){
                $txt=" / ";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(20+$KorX,240-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(142+$KorX,276-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //kraj in datum
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(20+$KorX,260-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            if (strlen($RefStFix) > 0){
                $txt=ToWin($RefStFix.$RefStVar);
                $RefStVar=$RefStVar+1;
            }else{
                $SQL = "SELECT evstev FROM tabevstevilkeu WHERE iducenec=".$oUcenec->getIdUcenec()." AND leto=$VLeto AND dokument=6";
                $result1 = mysqli_query($link,$SQL);

                if ($R1 = mysqli_fetch_array($result1)){
                    $txt=ToWin($R1["evstev"]);
                }else{
                    $txt="";
                }
            }
            $pdf->SetXY(142+$KorX,260-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }    
        $pdf->Output("npz.pdf","D");
        break;
    case "510a": //obvestilo npz 6 pdf    - pred 2013/2014
        if (isset($_SESSION["posx"])){
            $KorX = $_SESSION["posx"];
        }else{
            $KorX = 0;
        }
        if (isset($_SESSION["posy"])){
            $KorY = $_SESSION["posy"];
        }else{
            $KorY = 0;
        }
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        if (isset($_SESSION["KorOpombe"])){
            $KorOpombe = $_SESSION["KorOpombe"];
        }else{
            $KorOpombe="";
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix=$_SESSION["RefStFix"];
        }else{
            $RefStFix="";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        $_SESSION["leto"] = $VLeto;
        $_SESSION["posx"] = $KorX;
        $_SESSION["posy"] = $KorY;
        $_SESSION["DayToPrint"]=$PrintDay;
        $_SESSION["KorOpombe"]=$KorOpombe;
        $_SESSION["RefStFix"]=$RefStFix;
        $_SESSION["RefStVar"]=$RefStVar;

        $pdf = new FPDF();
        $pdf->SetAutoPageBreak(false);

        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");


        $SQL = "SELECT tabucenci.iducenec,tabrazdat.idsola FROM ";
        $SQL = $SQL . "((tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred ;
        $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx]=$R["iducenec"];
            $sola[$Indx]=$R["idsola"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx-1;

        $FontSize=10;

        for ($IndxRazred=0;$IndxRazred <= $StUcencev;$IndxRazred++){
            $SQL = "SELECT * FROM tabsola WHERE id=".$sola[$IndxRazred];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }

            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }

            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred]);
            $Razred=$oUcenec->getRazred($VLeto);
            
            //vstavi sliko
            if (!isset($_POST["obrazec"])){
                $pdf->Image("img/obvestilonpz6.jpg",0,0,210,297);
            }
            
            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($VSola);
            $pdf->SetXY(10+$KorX,46.5-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //'naslov šole
            $pdf->SetFont('arial_CE','',14);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10+$KorX,52-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"C");

            //Izpis osebnih podatkov
            $pdf->SetFont('arialbd_CE','',16);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(50+$KorX,114-$KorY);
            $pdf->Cell(110,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(50+$KorX,132-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(140+$KorX,132-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if ((strlen($oUcenec->getMaticnaKnjiga()) > 0) && ($oUcenec->getMaticnaKnjiga() != $oUcenec->getMaticniList()) ){
                $txt=ToWin($oUcenec->getMaticnaKnjiga()."/".$oUcenec->getMaticniList());
            }else{
                $txt=ToWin($oUcenec->getMaticniList());
            }
            $pdf->SetXY(65+$KorX,141-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //Izpis razrednih podatkov
            $txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
            $pdf->SetXY(125+$KorX,141-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($Razred["solskoleto"]);
            $pdf->SetXY(172+$KorX,141-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");


            $SQL = "SELECT tabnpzocene.tock,tabnpzocene.odstotek, tabpredmeti.id,tabpredmeti.opis FROM tabnpzocene INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id WHERE idUcenec=".$oUcenec->getIdUcenec()." AND leto=".$VLeto." ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                switch ($R["id"]){
                    case 16:
                        $pdf->SetFont('arial_CE','',16);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(115+$KorX,184-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(135+$KorX,184-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");
                        break;
                    case 11:
                        $pdf->SetFont('arial_CE','',16);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(115+$KorX,199-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(135+$KorX,199-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");
                        break;
                    default:
                        $pdf->SetFont('arial_CE','',16);
                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["tock"]);
                        }
                        $pdf->SetXY(115+$KorX,214-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["odstotek"]);
                        }
                        $pdf->SetXY(135+$KorX,214-$KorY);
                        $pdf->Cell(20,0,$txt,0,2,"C");

                        if ($R["tock"]==0){
                            $txt="--------";
                        }else{
                            $txt=ToWin($R["opis"]);
                        }
                        $pdf->SetXY(65+$KorX,214-$KorY);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                }
            }
            
            if ($SpolRavnatelj=="M" ){
                $pdf->Line(154+$KorX, 263.5-$KorY, 170+$KorX, 263.5-$KorY);
            }else{
                $pdf->Line(130+$KorX, 263.5-$KorY, 151+$KorX, 263.5-$KorY);
            }
            //opombe
            $pdf->SetFont('arial_CE','',$FontSize);
            if (strlen($Razred["opomba"]) == 0){
                $txt="----------";
            }else{
                $txt=ToWin($Razred["opomba"]);
            }
            $pdf->SetXY(40+$KorX,240-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //ravnatelj
            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(120+$KorX,253-$KorY);
            $pdf->Cell(70,0,$txt,0,2,"C");

            //kraj in datum
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(20+$KorX,275-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //'evid. št.
            $txt=ToWin($RefStFix.$RefStVar);
            $pdf->SetXY(55+$KorX,253-$KorY);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;
        }    
        $pdf->Output("npz.pdf","D");
        break;
    case "600": //stat npz 9
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<h3>Rezultati na nivoju šole - ".$VLeto."/".($VLeto+1)."</h3>";
        echo "Vsi trije predmeti<br />";

        $SQL = "SELECT tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." AND tabnpzpredmeti.razred=9 AND tabnpzpredmeti.prednost=3";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $NpzPredmet[0]=$R["oznaka"];
            $NpzPredmet[1]=$R["opis"];
        }

        $SQL = "SELECT tabnpzocene.idpredmet,tabnpzocene.odstotek FROM (tabnpzocene ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabnpzocene.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE (tabnpzocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto.") AND (odstotek > 0) AND tabnpzocene.razred=9 ";
        $SQL = $SQL . "ORDER BY tabnpzocene.idPredmet,tabrazred.razred,tabrazred.paralelka";
        $result = mysqli_query($link,$SQL);

        $aMonthNames[0]="SLO";
        $aMonthNames[1]="MAT";
        $aMonthNames[2]=$NpzPredmet[0];
        $aMonthValues[0]=0;
        $aMonthValues[1]=0;
        $aMonthValues[2]=0;
        $i[0]=0;
        $i[1]=0;
        $i[2]=0;

        while ($R = mysqli_fetch_array($result)){
            switch ($R["idpredmet"]){
                case 16: // 'SLO
                    $aMonthValues[0]=$aMonthValues[0]+$R["odstotek"];
                    $i[0]=$i[0]+1;
                    break;
                case 11: // 'MAT
                    $aMonthValues[1]=$aMonthValues[1]+$R["odstotek"];
                    $i[1]=$i[1]+1;
                    break;
                default: // 'tretji predmet
                    $aMonthValues[2]=$aMonthValues[2]+$R["odstotek"];
                    $i[2]=$i[2]+1;
            }
        }
        for ($Indx=0;$Indx <= 2;$Indx++){
            if ($i[$Indx]==0){
                $i[$Indx]=1;
            }
            $aMonthValues[$Indx]= number_format($aMonthValues[$Indx]/$i[$Indx],0);
        }
        displayverticalgraph ("NPZ 9. razredi - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Predmet",$aMonthValues,$aMonthNames);

        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =9) AND (idPredmet=16) ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 9. razredi slovenščina - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);

        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =9) AND (idPredmet=11) ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 9. razredi matematika - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);


        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =9) AND NOT (idPredmet IN (11,16)) ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 9. razredi ".$NpzPredmet[1]." - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);

        $SQL = "SELECT tabnpzocene.idpredmet,tabnpzocene.tock,tabnpzocene.moznihtock,tabpredmeti.opis,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (((tabnpzocene ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabnpzocene.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabnpzocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabnpzocene.razred=9 ";
        $SQL = $SQL . "ORDER BY tabrazdat.oznaka,tabnpzocene.idPredmet,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        $CompParalelka="";
        $CompPredmet=0;
        $Indx=0;
        $StatSola[1]=0;
        $StatSola[2]=0;
        $StatSola[3]=0;
        $StatSola[4]=0;
        $StatRazred[1]=0;
        $StatRazred[2]=0;
        $StatRazred[3]=0;
        $StatRazred[4]=0;
        $StatParalelka[1]=0;
        $StatParalelka[2]=0;
        $StatParalelka[3]=0;
        $StatParalelka[4]=0;
        $StatPredmet[1]=0;
        $StatPredmet[2]=0;
        $StatPredmet[3]=0;
        $StatPredmet[4]=0;
        $StatPredmet[5]=0;
        $StatPredmet[6]=0;
        $StatPredmet[7]=0;

        echo "<table border='1'>";
        echo "<tr><th>Razred</th><th>Predmet</th><th>učencev</th><th>Povprečno<br />točk</th><th>Možnih<br />točk</th><th>Odstotek</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            if ($CompParalelka != $R["oznaka"]){
                if ($CompParalelka != ""){
                    //'izpis podatkov predmeta
                    $StatPredmet[3]=$Indx;
                    if ($StatPredmet[3] > 0){
                        $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
                    }else{
                        $StatPredmet[5]=0;
                    }
                    if ($StatPredmet[6] > 0){
                        $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;
                    }else{
                        $StatPredmet[7]=0;
                    }
                    
                    echo "<tr>";
                    echo "<td>".$StatPredmet[1]."</td>";
                    echo "<td>".$StatPredmet[2]."</td>";
                    echo "<td>".$StatPredmet[3]."</td>";
                    echo "<td>".number_format($StatPredmet[5],2)."</td>";
                    echo "<td>".$StatPredmet[6]."</td>";
                    echo "<td>".number_format($StatPredmet[7],2)."</td>";
                    echo "</tr>";
                }
                
                //'spremeni paralelko
                $CompParalelka=$R["oznaka"];
                //'ponastavi predmet
                $CompPredmet=$R["idpredmet"];
                $StatPredmet[1]=$R["razred"].". ".$R["oznaka"];// 'razred
                $StatPredmet[2]=$R["opis"]; // 'predmet
                
                if ($R["tock"] > 0){
                    $Indx=1;
                    $StatParalelka[1]=$StatParalelka[1]+1;
                    $StatRazred[1]=$StatRazred[1]+1;
                    $StatSola[1]=$StatSola[1]+1;

                    $StatPredmet[4]=$R["tock"];
                    $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                    $StatRazred[2]=$StatRazred[2]+$R["tock"];
                    $StatSola[2]=$StatSola[2]+$R["tock"];
                }else{
                    $Indx=0;
                    $StatPredmet[4]=0;
                }
                $StatPredmet[6]=$R["moznihtock"];
            }else{
                if ($CompPredmet != $R["idpredmet"]){
                    $CompPredmet=$R["idpredmet"];
                    $StatPredmet[3]=$Indx;
                    if ($StatPredmet[3] > 0){
                        $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
                    }else{
                        $StatPredmet[5]=0;
                    }
                    $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;
                    
                    echo "<tr>";
                    echo "<td>".$StatPredmet[1]."</td>";
                    echo "<td>".$StatPredmet[2]."</td>";
                    echo "<td>".$StatPredmet[3]."</td>";
                    echo "<td>".number_format($StatPredmet[5],2)."</td>";
                    echo "<td>".$StatPredmet[6]."</td>";
                    echo "<td>".number_format($StatPredmet[7],2)."</td>";
                    echo "</tr>";
                    
                    $StatPredmet[1]=$R["razred"].". ".$R["oznaka"];// 'razred
                    $StatPredmet[2]=$R["opis"]; // 'predmet
                    $StatPredmet[6]=$R["moznihtock"];
                    if ($R["tock"] > 0){
                        $Indx=1;
                        $StatParalelka[1]=$StatParalelka[1]+1;
                        $StatRazred[1]=$StatRazred[1]+1;
                        $StatSola[1]=$StatSola[1]+1;

                        $StatPredmet[4]=$R["tock"];
                        $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                        $StatRazred[2]=$StatRazred[2]+$R["tock"];
                        $StatSola[2]=$StatSola[2]+$R["tock"];
                    }else{
                        $Indx=0;
                        $StatPredmet[4]=0;
                    }
                }else{
                    if ($R["tock"] > 0){
                        $Indx=$Indx+1;
                        $StatParalelka[1]=$StatParalelka[1]+1;
                        $StatRazred[1]=$StatRazred[1]+1;
                        $StatSola[1]=$StatSola[1]+1;

                        $StatPredmet[4]=$StatPredmet[4]+$R["tock"];
                        $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                        $StatRazred[2]=$StatRazred[2]+$R["tock"];
                        $StatSola[2]=$StatSola[2]+$R["tock"];
                    }
                }
            }
        }
        //'izpis še za zadnji predmet zadnje paralelke
        $StatPredmet[3]=$Indx;
        if ($StatPredmet[3] > 0){
            $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
        }else{
            $StatPredmet[5]=0;
        }
        $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;

        echo "<tr>";
        echo "<td>".$StatPredmet[1]."</td>";
        echo "<td>".$StatPredmet[2]."</td>";
        echo "<td>".$StatPredmet[3]."</td>";
        echo "<td>".number_format($StatPredmet[5],2)."</td>";
        echo "<td>".$StatPredmet[6]."</td>";
        echo "<td>".number_format($StatPredmet[7],2)."</td>";
        echo "</tr>";

        echo "</table><br />";

        echo "<br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;    
    case "610": //stat npz 6
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<h3>Rezultati na nivoju šole - ".$VLeto."/".($VLeto+1)."</h3>";
        echo "Vsi trije predmeti<br />";

        $SQL = "SELECT tabpredmeti.oznaka,tabpredmeti.opis FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idPredmet=tabpredmeti.id WHERE tabnpzpredmeti.leto=".$VLeto." AND tabnpzpredmeti.razred=6 AND tabnpzpredmeti.prednost=3";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $NpzPredmet[0]=$R["oznaka"];
            $NpzPredmet[1]=$R["opis"];
        }

        $SQL = "SELECT tabnpzocene.idpredmet,tabnpzocene.odstotek FROM (tabnpzocene ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabnpzocene.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE (tabnpzocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto.") AND (odstotek > 0) AND tabnpzocene.razred=6 ";
        $SQL = $SQL . "ORDER BY tabnpzocene.idPredmet,tabrazred.razred,tabrazred.paralelka";
        $result = mysqli_query($link,$SQL);

        $aMonthNames[0]="SLO";
        $aMonthNames[1]="MAT";
        $aMonthNames[2]="TJA";
        $aMonthValues[0]=0;
        $aMonthValues[1]=0;
        $aMonthValues[2]=0;
        $i[0]=0;
        $i[1]=0;
        $i[2]=0;

        while ($R = mysqli_fetch_array($result)){
            switch ($R["idpredmet"]){
                case 16: // 'SLO
                    $aMonthValues[0]=$aMonthValues[0]+$R["odstotek"];
                    $i[0]=$i[0]+1;
                    break;
                case 11: // 'MAT
                    $aMonthValues[1]=$aMonthValues[1]+$R["odstotek"];
                    $i[1]=$i[1]+1;
                    break;
                default: // 'tretji predmet
                    $aMonthValues[2]=$aMonthValues[2]+$R["odstotek"];
                    $i[2]=$i[2]+1;
            }
        }
        for ($Indx=0;$Indx <= 2;$Indx++){
            if ($i[$Indx]==0){
                $i[$Indx]=1;
            }
            $aMonthValues[$Indx]= number_format($aMonthValues[$Indx]/$i[$Indx],0);
        }
        displayverticalgraph ("NPZ 6. razredi - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Predmet",$aMonthValues,$aMonthNames);

        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =6) AND (idPredmet=16) ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 6. razredi slovenščina - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);

        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =6) AND (idPredmet=11) ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 6. razredi matematika - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);


        $SQL = "SELECT odstotek FROM tabnpzocene WHERE (leto=".$VLeto.") AND (razred =6) AND idPredmet = 26 ORDER BY odstotek DESC";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $aMonthValues[$Indx]=0;
            $aMonthNames[$Indx]=$Indx+1;
            if ($R["odstotek"] > 0){
                $aMonthValues[$Indx]=number_format($R["odstotek"],0);
            }else{
                $aMonthValues[$Indx]=0;
            }
            $Indx=$Indx+1;
        }
        displayverticalgraph ("NPZ 6. razredi angleščina - ".$VLeto."/".($VLeto+1)." ","Uspeh [%]","Učenci",$aMonthValues,$aMonthNames);

        $SQL = "SELECT tabnpzocene.idpredmet,tabnpzocene.tock,tabnpzocene.moznihtock,tabpredmeti.opis,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (((tabnpzocene ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabnpzocene.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabnpzocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabnpzocene.razred=6 ";
        $SQL = $SQL . "ORDER BY tabrazdat.oznaka,tabnpzocene.idPredmet,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        $CompParalelka="";
        $CompPredmet=0;
        $Indx=0;
        $StatSola[1]=0;
        $StatSola[2]=0;
        $StatSola[3]=0;
        $StatSola[4]=0;
        $StatRazred[1]=0;
        $StatRazred[2]=0;
        $StatRazred[3]=0;
        $StatRazred[4]=0;
        $StatParalelka[1]=0;
        $StatParalelka[2]=0;
        $StatParalelka[3]=0;
        $StatParalelka[4]=0;
        $StatPredmet[1]=0;
        $StatPredmet[2]=0;
        $StatPredmet[3]=0;
        $StatPredmet[4]=0;
        $StatPredmet[5]=0;
        $StatPredmet[6]=0;
        $StatPredmet[7]=0;

        echo "<table border='1'>";
        echo "<tr><th>Razred</th><th>Predmet</th><th>učencev</th><th>Povprečno<br />točk</th><th>Možnih<br />točk</th><th>Odstotek</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            if ($CompParalelka != $R["oznaka"]){
                if ($CompParalelka != ""){
                    //'izpis podatkov predmeta
                    $StatPredmet[3]=$Indx;
                    if ($StatPredmet[3] > 0){
                        $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
                    }else{
                        $StatPredmet[5]=0;
                    }
                    if ($StatPredmet[6] > 0){
                        $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;
                    }else{
                        $StatPredmet[7]=0;
                    }
                    
                    echo "<tr>";
                    echo "<td>".$StatPredmet[1]."</td>";
                    echo "<td>".$StatPredmet[2]."</td>";
                    echo "<td>".$StatPredmet[3]."</td>";
                    echo "<td>".number_format($StatPredmet[5],2)."</td>";
                    echo "<td>".$StatPredmet[6]."</td>";
                    echo "<td>".number_format($StatPredmet[7],2)."</td>";
                    echo "</tr>";
                }
                
                //'spremeni paralelko
                $CompParalelka=$R["oznaka"];
                //'ponastavi predmet
                $CompPredmet=$R["idpredmet"];
                $StatPredmet[1]=$R["razred"].". ".$R["oznaka"];// 'razred
                $StatPredmet[2]=$R["opis"]; // 'predmet
                
                if ($R["tock"] > 0){
                    $Indx=1;
                    $StatParalelka[1]=$StatParalelka[1]+1;
                    $StatRazred[1]=$StatRazred[1]+1;
                    $StatSola[1]=$StatSola[1]+1;

                    $StatPredmet[4]=$R["tock"];
                    $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                    $StatRazred[2]=$StatRazred[2]+$R["tock"];
                    $StatSola[2]=$StatSola[2]+$R["tock"];
                }else{
                    $Indx=0;
                    $StatPredmet[4]=0;
                }
                $StatPredmet[6]=$R["moznihtock"];
            }else{
                if ($CompPredmet != $R["idpredmet"]){
                    $CompPredmet=$R["idpredmet"];
                    $StatPredmet[3]=$Indx;
                    if ($StatPredmet[3] > 0){
                        $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
                    }else{
                        $StatPredmet[5]=0;
                    }
                    $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;
                    
                    echo "<tr>";
                    echo "<td>".$StatPredmet[1]."</td>";
                    echo "<td>".$StatPredmet[2]."</td>";
                    echo "<td>".$StatPredmet[3]."</td>";
                    echo "<td>".number_format($StatPredmet[5],2)."</td>";
                    echo "<td>".$StatPredmet[6]."</td>";
                    echo "<td>".number_format($StatPredmet[7],2)."</td>";
                    echo "</tr>";
                    
                    $StatPredmet[1]=$R["razred"].". ".$R["oznaka"];// 'razred
                    $StatPredmet[2]=$R["opis"]; // 'predmet
                    $StatPredmet[6]=$R["moznihtock"];
                    if ($R["tock"] > 0){
                        $Indx=1;
                        $StatParalelka[1]=$StatParalelka[1]+1;
                        $StatRazred[1]=$StatRazred[1]+1;
                        $StatSola[1]=$StatSola[1]+1;

                        $StatPredmet[4]=$R["tock"];
                        $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                        $StatRazred[2]=$StatRazred[2]+$R["tock"];
                        $StatSola[2]=$StatSola[2]+$R["tock"];
                    }else{
                        $Indx=0;
                        $StatPredmet[4]=0;
                    }
                }else{
                    if ($R["tock"] > 0){
                        $Indx=$Indx+1;
                        $StatParalelka[1]=$StatParalelka[1]+1;
                        $StatRazred[1]=$StatRazred[1]+1;
                        $StatSola[1]=$StatSola[1]+1;

                        $StatPredmet[4]=$StatPredmet[4]+$R["tock"];
                        $StatParalelka[2]=$StatParalelka[2]+$R["tock"];
                        $StatRazred[2]=$StatRazred[2]+$R["tock"];
                        $StatSola[2]=$StatSola[2]+$R["tock"];
                    }
                }
            }
        }
        //'izpis še za zadnji predmet zadnje paralelke
        $StatPredmet[3]=$Indx;
        if ($StatPredmet[3] > 0){
            $StatPredmet[5]=$StatPredmet[4]/$StatPredmet[3];
        }else{
            $StatPredmet[5]=0;
        }
        $StatPredmet[7]=$StatPredmet[5]/$StatPredmet[6]*100;

        echo "<tr>";
        echo "<td>".$StatPredmet[1]."</td>";
        echo "<td>".$StatPredmet[2]."</td>";
        echo "<td>".$StatPredmet[3]."</td>";
        echo "<td>".number_format($StatPredmet[5],2)."</td>";
        echo "<td>".$StatPredmet[6]."</td>";
        echo "<td>".number_format($StatPredmet[7],2)."</td>";
        echo "</tr>";

        echo "</table><br />";

        echo "<br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        echo "</body>";
        echo "</html>";
        break;    
    case "700": //uvoz NPZ
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        echo "<form method='post' ENCTYPE='multipart/form-data' action='npz.php'>";
        echo "<input name='idd' type='hidden' value='710'>";
        echo "<h2>Uvoz rezultatov NPZ (XML)</h2>";
        echo "<table border=0><tr>";
        echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
        echo "<input name='povezava' type='hidden' value='/'>";
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "710": //import npz
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $uploaded=false;
        $allowedExts = array("txt", "csv","xml");
        $Preneseno=$_FILES["file"];
        $extension = explode(".", $Preneseno["name"]);
        $extension = end($extension);
        $extension = strtolower($extension);
        if (($_FILES["file"]["size"] < 500000) && in_array($extension, $allowedExts)){
            if ($_FILES["file"]["error"] > 0){
                echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
            }else{
                echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                echo "Type: " . $_FILES["file"]["type"] . "<br />";
                echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
         
                if (file_exists("dato/" . $_FILES["file"]["name"])){
                    echo $_FILES["file"]["name"] . " already exists. ";
                    move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                    echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                    $uploaded=true;
                }else{
                    move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                    echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                    $uploaded=true;
                }
           }
        }else{
            echo "Invalid file";
        }

        $StUcencevIndx=0;

        if ($uploaded){
            $myFile = "dato/".$_FILES["file"]["name"];
            $fh = fopen($myFile,'r') or die("Ne morem odpreti log datoteke!");
            //$VServer=$_POST["servaddr"];
            $indx=0;
            while(!feof($fh)){
               //echo fgets($file). "<br />";
               $Vrstica[$indx]=fgets($fh);
               $indx=$indx+1;
            }
            $StVrstic=$indx-1;
            fclose($fh);

            $db = readDatabase($myFile);
            //echo "** Database of Učenci-CEUVIZ objects:\n";
            //print_r($db);
            echo "<h2>Uvoz ocen za NPZ</h2>";
            for ($Indx=0;$Indx < count($db);$Indx++){
                if ($db[$Indx]->RAZRED_OBISK == 9){
                    $SQL = "SELECT id FROM tabpredmeti WHERE siframss=".$db[$Indx]->PREDMET_REF;
                    $result2 = mysqli_query($link,$SQL);
                    if ($R2 = mysqli_fetch_array($result2)){
                        $Predmet=$R2["id"];
                    }else{
                        $Predmet=0;
                    }
                    $SQL = "SELECT tabnpzocene.id,tabucenci.priimek,tabucenci.ime FROM tabnpzocene INNER JOIN tabucenci ON tabnpzocene.iducenec=tabucenci.iducenec WHERE tabnpzocene.leto=".$VLeto." AND emso='".$db[$Indx]->EMSO."' AND tabnpzocene.idpredmet=".$Predmet;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'ima učenca
                        
                        //'update
                        $SQL = "UPDATE tabnpzocene SET ";
                        $SQL = $SQL . "tock=".intval($db[$Indx]->TOCK_ST);
                        $SQL = $SQL . ",moznihtock=".intval($db[$Indx]->TOCK_MAKS);
                        $SQL = $SQL . ",odstotek=".intval($db[$Indx]->TOCK_PROC);
                        $SQL = $SQL . " WHERE id=".$R["id"];
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu rezultatov NPZ. <br />$SQL<br />");
                        }else{
                            echo "Popravljeni podatki za: ".$db[$Indx]->PRIIMEK." ".$db[$Indx]->IME." (".$db[$Indx]->EMSO."): ".$db[$Indx]->PREDMET_REF." (".$db[$Indx]->TOCK_PROC."), id=".$R["id"]."<br />";
                        }
                    }else{
                        //'insert
                        $StUcencevIndx=$StUcencevIndx+1;
                        $DatRoj=substr($db[$Indx]->EMSO,0,2) . "." . substr($db[$Indx]->EMSO,2,2) . ".";
                        if (intval(substr($db[$Indx]->EMSO,4,3)) < 900){
                            $DatRoj=$DatRoj."2".substr($db[$Indx]->EMSO,4,3);
                        }else{
                            $DatRoj=$DatRoj."1".substr($db[$Indx]->EMSO,4,3);
                        }
                        $Datum=new DateTime(isDate($DatRoj));
                        $SQL = "SELECT iducenec FROM tabucenci WHERE emso='".$db[$Indx]->EMSO."'";
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idpredmet,razred,odstotek,tock,moznihtock)";
                            $SQL = $SQL . " VALUES (";
                            $SQL = $SQL . $VLeto;
                            $SQL = $SQL . ",".$R1["iducenec"];
                            $SQL = $SQL . ",".$Predmet;
                            $SQL = $SQL . ",".$db[$Indx]->RAZRED_OBISK;
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_PROC);
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_ST);
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_MAKS);
                            $SQL = $SQL . ")";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu rezultatov NPZ. <br />$SQL<br />");
                            }else{
                                echo "Nov vpis za: ".$db[$Indx]->PRIIMEK." ".$db[$Indx]->IME." (".$db[$Indx]->EMSO."): ".$db[$Indx]->PREDMET_REF." (".$db[$Indx]->TOCK_PROC.")<br />";
                            }
                        }
                    }
                }
                if ($db[$Indx]->RAZRED_OBISK == 6){
                    $SQL = "SELECT id FROM tabpredmeti WHERE siframss=".$db[$Indx]->PREDMET_REF;
                    $result2 = mysqli_query($link,$SQL);
                    if ($R2 = mysqli_fetch_array($result2)){
                        $Predmet=$R2["id"];
                    }else{
                        $Predmet=0;
                    }
                    $SQL = "SELECT tabnpzocene.id,tabucenci.priimek,tabucenci.ime FROM tabnpzocene INNER JOIN tabucenci ON tabnpzocene.iducenec=tabucenci.iducenec WHERE tabnpzocene.leto=".$VLeto." AND emso='".$db[$Indx]->EMSO."' AND tabnpzocene.idpredmet=".$Predmet;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'ima učenca
                        
                        //'update
                        $SQL = "UPDATE tabnpzocene SET ";
                        $SQL = $SQL . "tock=".intval($db[$Indx]->TOCK_ST);
                        $SQL = $SQL . ",moznihtock=".intval($db[$Indx]->TOCK_MAKS);
                        $SQL = $SQL . ",odstotek=".intval($db[$Indx]->TOCK_PROC);
                        $SQL = $SQL . " WHERE id=".$R["id"];
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu rezultatov NPZ. <br />$SQL<br />");
                        }else{
                            echo "Popravljeni podatki za: ".$db[$Indx]->PRIIMEK." ".$db[$Indx]->IME." (".$db[$Indx]->EMSO."): ".$db[$Indx]->PREDMET_REF." (".$db[$Indx]->TOCK_PROC."), id=".$R["id"]."<br />";
                        }
                    }else{
                        //'insert
                        $StUcencevIndx=$StUcencevIndx+1;
                        $DatRoj=substr($db[$Indx]->EMSO,0,2) . "." . substr($db[$Indx]->EMSO,2,2) . ".";
                        if (intval(substr($db[$Indx]->EMSO,4,3)) < 900){
                            $DatRoj=$DatRoj."2".substr($db[$Indx]->EMSO,4,3);
                        }else{
                            $DatRoj=$DatRoj."1".substr($db[$Indx]->EMSO,4,3);
                        }
                        $Datum=new DateTime(isDate($DatRoj));
                        $SQL = "SELECT iducenec FROM tabucenci WHERE emso='".$db[$Indx]->EMSO."'";
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            $SQL = "INSERT INTO tabnpzocene (leto,idUcenec,idpredmet,razred,odstotek,tock,moznihtock)";
                            $SQL = $SQL . " VALUES (";
                            $SQL = $SQL . $VLeto;
                            $SQL = $SQL . ",".$R1["iducenec"];
                            $SQL = $SQL . ",".$Predmet;
                            $SQL = $SQL . ",".$db[$Indx]->RAZRED_OBISK;
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_PROC);
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_ST);
                            $SQL = $SQL . ",".intval($db[$Indx]->TOCK_MAKS);
                            $SQL = $SQL . ")";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu rezultatov NPZ. <br />$SQL<br />");
                            }else{
                                echo "Nov vpis za: ".$db[$Indx]->PRIIMEK." ".$db[$Indx]->IME." (".$db[$Indx]->EMSO."): ".$db[$Indx]->PREDMET_REF." (".$db[$Indx]->TOCK_PROC.")<br />";
                            }
                        }
                    }
                }
            }
        }     
        echo "</body>";
        echo "</html>";
        break;
    case "800": //export npz dat
        /*
          Kontakt za prenos podatkov:
          podpora@b2.eu
          01/2444-222
        */
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $VFile="vpisvsrednjosolo.xml";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        fwrite ($fh,"<"."?xml version='1.0' encoding='utf-8' standalone='yes'?".">"."\n");
        echo "<h3>Izvoz ocen in podatkov NPZ za vpis v srednje šole</h3>";

		$SQL = "SELECT tabpredmeti.siframss FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idpredmet=tabpredmeti.id ";
		$SQL = $SQL . "WHERE tabnpzpredmeti.leto=".$VLeto." AND razred=9 AND prednost=3";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
			$TretjiPredmet=$R["siframss"];
		}else{
			$TretjiPredmet=1487;
		}
		
        $SQL = "SELECT tabrazred.iducenec,tabpredmeti.siframss FROM ";
        $SQL = $SQL . "(((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN TabIzbirni ON tabrazred.idUcenec=TabIzbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabIzbirni.izbirni=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred=9) AND (TabIzbirni.leto=".$VLeto.") AND (tabpredmeti.prioriteta=1) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        $CompUcenec=0;
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["iducenec"]){
                $CountIzb=1;
                $Indx=$Indx+1;
                $CompUcenec=$R["iducenec"];
                $UcenecIzb[$Indx][0]=$R["iducenec"];
                $UcenecIzb[$Indx][1]="0";
                $UcenecIzb[$Indx][2]="0";
                $UcenecIzb[$Indx][3]="0";
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }else{
                $CountIzb=$CountIzb+1;
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }
        }
        $StUcencev=$Indx;

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabucenci.spol,tabucenci.datroj,tabucenci.krajroj,tabucenci.maticnilist,tabucenci.naslov,tabucenci.kraj,tabucenci.posta,";
        $SQL = $SQL . "tabucitelji.ime AS uime,tabucitelji.priimek AS upriimek,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola FROM ";
        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabrazred.idUcitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred IN (6,9)) ORDER BY tabrazdat.razred,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        fwrite ($fh,"<Ucenci xmlns=".chr(34)."https://soca1.mss.edus.si/NPZinVpis2009/Dokumenti/NPZUvoz.xsd".chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34).">"."\n");

        $CompUcenec="";
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["priimek"]." ".$R["ime"]." ".$R["emso"]){
                if (strlen($R["emso"]) > 0){
                    $SQL1 = "SELECT ustanovaid,npzsifra,tipsole,siframss,program FROM tabsola WHERE id=".$R["idsola"];
                    $result1 = mysqli_query($link,$SQL1);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $VSolaID=$R1["ustanovaid"];
                        $NPZSifra=$R1["npzsifra"];
                        $TipSole=$R1["tipsole"];
                        $SifraZavoda=$R1["siframss"];
                        $VTipSole=$R1["program"];
                    }else{
                        $VSolaID=" ";
                        $NPZSifra=0;
                        $TipSole="Slovenska šola";
                        $SifraZavoda="0";
                        $VTipSole=3803;
                    }

                    $CountIzb=1;
                    $CompUcenec=$R["priimek"]." ".$R["ime"]." ".$R["emso"];
                    fwrite ($fh,"<Ucenec xmlns=".chr(34)."".chr(34).">"."\n");
                    fwrite ($fh,"  <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                    fwrite ($fh,"  <UVOZ_VIR>1</UVOZ_VIR>"."\n");
                    fwrite ($fh,"  <STATUS>1</STATUS>"."\n");
                    fwrite ($fh,"  <OPOMBA></OPOMBA>"."\n");
                    fwrite ($fh,"  <PRIIMEK>".$R["priimek"]."</PRIIMEK>"."\n");
                    fwrite ($fh,"  <IME>".$R["ime"]."</IME>"."\n");
                    if ($R["spol"]=="M"){
                        fwrite ($fh,"  <SPOL>M</SPOL>"."\n");
                    }else{
                        fwrite ($fh,"  <SPOL>Ž</SPOL>"."\n");
                    }
                    fwrite ($fh,"  <EMSO>".$R["emso"]."</EMSO>"."\n");
                    $Datum=new DateTime(isDate($R["datroj"]));
                    fwrite ($fh,"  <ROJSTVO_DATUM>".$Datum->format('Y-m-d')."</ROJSTVO_DATUM>"."\n");
                    fwrite ($fh,"  <ROJSTVO_KRAJ>".$R["krajroj"]."</ROJSTVO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROJSTVO_DRZ_REF>705</ROJSTVO_DRZ_REF>"."\n");
                    fwrite ($fh,"  <DRZAVLJANSTVO_REF>705</DRZAVLJANSTVO_REF>"."\n");
                    fwrite ($fh,"  <MATICNI_LIST_ST>".$R["maticnilist"]."</MATICNI_LIST_ST>"."\n");
                    fwrite ($fh,"  <EVIDENCNA_ST></EVIDENCNA_ST>"."\n");
                    fwrite ($fh,"  <OB_MID_REF xsi:nil=".chr(34)."true".chr(34)."></OB_MID_REF>"."\n");
                    fwrite ($fh,"  <HS_MID_REF xsi:nil=".chr(34)."true".chr(34)."></HS_MID_REF>"."\n");
                    fwrite ($fh,"  <DRZAVA_REF>705</DRZAVA_REF>"."\n");
                    
                    fwrite ($fh,"  <ROCNO_ULICA>".$R["naslov"]."</ROCNO_ULICA>"."\n");
                    fwrite ($fh,"  <ROCNO_KRAJ>".$R["kraj"]."</ROCNO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA_ID>".$R["posta"]."</ROCNO_POSTA_ID>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA>".$R["kraj"]."</ROCNO_POSTA>"."\n");
                    fwrite ($fh,"  <ZAVSIF>".$SifraZavoda."</ZAVSIF>"."\n");
                    fwrite ($fh,"  <SOLSKO_LETO_REF>".($VLeto-1995)."</SOLSKO_LETO_REF>"."\n");
                    fwrite ($fh,"  <PROGRAM_REF>".$VTipSole."</PROGRAM_REF>"."\n");
                    if ($VTipSole != 3813){
                        fwrite ($fh,"  <RAZRED_NOS>0</RAZRED_NOS>"."\n");
                    }else{
                        fwrite ($fh,"  <RAZRED_NOS>1</RAZRED_NOS>"."\n");
                    }
                    fwrite ($fh,"  <RAZRED_OBISK>".$R["razred"]."</RAZRED_OBISK>"."\n");
                    if ($R["razred"]==9){
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>".$TretjiPredmet."</TP_PREDMET_REF>"."\n");
                    }else{
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>1487</TP_PREDMET_REF>"."\n");
                    }
                    fwrite ($fh,"  <ODDELEK_OZNAKA>".$R["oznaka"]."</ODDELEK_OZNAKA>"."\n");
                    fwrite ($fh,"  <RAZREDNIK_IME>".$R["uime"]." ".$R["upriimek"]."</RAZREDNIK_IME>"."\n");
                    $VsebujeIzb=false;
                    if ($R["razred"]==9){
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            if ($R["iducenec"] == $UcenecIzb[$Indx][0]){
                                if (($UcenecIzb[$Indx][1] == "") or ($UcenecIzb[$Indx][1]=="0")){
                                    fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP1_PREDMET_REF>".$UcenecIzb[$Indx][1]."</IP1_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][2] == "") or ($UcenecIzb[$Indx][2]=="0")){
                                    fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP2_PREDMET_REF>".$UcenecIzb[$Indx][2]."</IP2_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][3] == "") or ($UcenecIzb[$Indx][3]=="0")){
                                    fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP3_PREDMET_REF>".$UcenecIzb[$Indx][3]."</IP3_PREDMET_REF>"."\n");
                                }
                                fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                                fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                                fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                                $VsebujeIzb=true;
                            }
                        }
                    }
                    if ($R["razred"]==6){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                        $VsebujeIzb=true;
                    }
                    if (!$VsebujeIzb){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                    }
                    fwrite ($fh,"</Ucenec>"."\n");
                }
            }
        }

        fwrite ($fh,"  <UcenecOcene xmlns=".chr(34).chr(34).">"."\n");

        $SQL = "SELECT tabucenci.iducenec,tabocene.ocenakoncna,tabocene.neocenjen,tabpredmeti.siframss,tabrazdat.razred FROM (((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabocene ON tabucenci.idUcenec=tabocene.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazdat.razred=9 ";
        $SQL = $SQL . "ORDER BY tabrazdat.razred,priimek,ime,vrstnired";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                fwrite ($fh,"   <UcenecOcena xmlns=".chr(34).chr(34).">"."\n");
                fwrite ($fh,"     <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                fwrite ($fh,"     <RAZRED>".$R["razred"]."</RAZRED>"."\n");
                fwrite ($fh,"     <PREDMET_REF>".$R["siframss"]."</PREDMET_REF>"."\n");
                switch ($R["neocenjen"]){
                    case 1:
                        fwrite ($fh,"     <OCENA>N</OCENA>"."\n");
                        break;
                    case 2:
                        fwrite ($fh,"     <OCENA>O</OCENA>"."\n");
                        break;
                    default:   
                        fwrite ($fh,"     <OCENA>".$R["ocenakoncna"]."</OCENA>"."\n");
                }
                fwrite ($fh,"   </UcenecOcena>"."\n");
            }
        }

        $SQL = "SELECT tabucenci.iducenec,tabocene.ocenakoncna,tabocene.neocenjen,tabpredmeti.siframss,tabpredmeti.prioriteta,tabrazdat.razred FROM (((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabocene ON tabucenci.idUcenec=tabocene.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
//        $SQL = $SQL . "WHERE tabrazred.leto=".($VLeto-1)." AND tabrazdat.leto=".($VLeto-1)." AND tabocene.leto=".($VLeto-1)." AND tabrazdat.razred=8 ";
        $SQL = $SQL . "WHERE tabrazred.leto=".($VLeto-1)." AND tabrazdat.leto=".($VLeto-1)." AND tabocene.leto=".($VLeto-1)." AND tabrazdat.razred=8 AND tabpredmeti.prioriteta = 0 ";
        $SQL = $SQL . "ORDER BY tabrazdat.razred,priimek,ime,vrstnired";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                if ($R["prioriteta"]==1 or $R["prioriteta"]==0){
                    fwrite ($fh,"   <UcenecOcena xmlns=".chr(34).chr(34).">"."\n");
                    fwrite ($fh,"     <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                    fwrite ($fh,"     <RAZRED>".$R["razred"]."</RAZRED>"."\n");
                    fwrite ($fh,"     <PREDMET_REF>".$R["siframss"]."</PREDMET_REF>"."\n");
                    switch ($R["neocenjen"]){
                        case 1:
                            fwrite ($fh,"     <OCENA>N</OCENA>"."\n");
                            break;
                        case 2:
                            fwrite ($fh,"     <OCENA>O</OCENA>"."\n");
                            break;
                        default:   
                            fwrite ($fh,"     <OCENA>".$R["ocenakoncna"]."</OCENA>"."\n");
                    }
                    fwrite ($fh,"   </UcenecOcena>"."\n");
                }
            }
        }
        $SQL = "SELECT tabucenci.iducenec,tabocene.ocenakoncna,tabocene.neocenjen,tabpredmeti.siframss,tabpredmeti.prioriteta,tabrazdat.razred FROM (((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabocene ON tabucenci.idUcenec=tabocene.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazred.leto=".($VLeto-2)." AND tabrazdat.leto=".($VLeto-2)." AND tabocene.leto=".($VLeto-2)." AND tabrazdat.razred=7 AND tabpredmeti.prioriteta = 0 ";
        $SQL = $SQL . "ORDER BY tabrazdat.razred,priimek,ime,vrstnired";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                if ($R["prioriteta"]==1 or $R["prioriteta"]==0){
                    fwrite ($fh,"   <UcenecOcena xmlns=".chr(34).chr(34).">"."\n");
                    fwrite ($fh,"     <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                    fwrite ($fh,"     <RAZRED>".$R["razred"]."</RAZRED>"."\n");
                    fwrite ($fh,"     <PREDMET_REF>".$R["siframss"]."</PREDMET_REF>"."\n");
                    switch ($R["neocenjen"]){
                        case 1:
                            fwrite ($fh,"     <OCENA>N</OCENA>"."\n");
                            break;
                        case 2:
                            fwrite ($fh,"     <OCENA>O</OCENA>"."\n");
                            break;
                        default:   
                            fwrite ($fh,"     <OCENA>".$R["ocenakoncna"]."</OCENA>"."\n");
                    }
                    fwrite ($fh,"   </UcenecOcena>"."\n");
                }
            }
        }
        fwrite ($fh,"  </UcenecOcene>"."\n");

        fwrite ($fh,"</Ucenci>"."\n");
        fclose($fh);

        echo "<h2>Pozor!</h2>";
        echo "<font color='red'>Vsi učenci imajo za državo rojstva vpisano Slovenijo in slovensko državljanstvo!</font><br />";
        echo "<font color='red'>Učenci brez vpisane EMŠO ne bodo uvoženi v aplikacijo MŠŠ!</font><br />";
        echo "<br />";
        echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
        echo "<h3>Shrani datoteko <a href='".$MyFile."'>".$VFile."</a></h3>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "801": //export npz dat - samo podatki - brez ocen
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $VFile="vpisvsrednjosolo.xml";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        fwrite ($fh,"<"."?xml version='1.0' encoding='utf-8' standalone='yes'?".">"."\n");
        echo "<h3>Izvoz ocen in podatkov NPZ za vpis v srednje šole</h3>";

		$SQL = "SELECT tabpredmeti.siframss FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idpredmet=tabpredmeti.id ";
		$SQL = $SQL . "WHERE tabnpzpredmeti.leto=".$VLeto." AND razred=9 AND prednost=3";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
			$TretjiPredmet=$R["siframss"];
		}else{
			$TretjiPredmet=1487;
		}
		
        $SQL = "SELECT tabrazred.iducenec,tabpredmeti.siframss FROM ";
        $SQL = $SQL . "(((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN TabIzbirni ON tabrazred.idUcenec=TabIzbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabIzbirni.izbirni=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred=9) AND (TabIzbirni.leto=".$VLeto.") AND (tabpredmeti.prioriteta=1) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        $CompUcenec=0;
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["iducenec"]){
                $CountIzb=1;
                $Indx=$Indx+1;
                $CompUcenec=$R["iducenec"];
                $UcenecIzb[$Indx][0]=$R["iducenec"];
                $UcenecIzb[$Indx][1]="0";
                $UcenecIzb[$Indx][2]="0";
                $UcenecIzb[$Indx][3]="0";
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }else{
                $CountIzb=$CountIzb+1;
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }
        }
        $StUcencev=$Indx;

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabucenci.spol,tabucenci.datroj,tabucenci.krajroj,tabucenci.maticnilist,tabucenci.naslov,tabucenci.kraj,tabucenci.posta,";
        $SQL = $SQL . "tabucitelji.ime AS uime,tabucitelji.priimek AS upriimek,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola FROM ";
        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabrazred.idUcitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred IN (6,9)) ORDER BY tabrazdat.razred,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        fwrite ($fh,"<Ucenci xmlns=".chr(34)."https://soca1.mss.edus.si/NPZinVpis2009/Dokumenti/NPZUvoz.xsd".chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34).">"."\n");

        $CompUcenec="";
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["priimek"]." ".$R["ime"]." ".$R["emso"]){
                if (strlen($R["emso"]) > 0){
                    $SQL1 = "SELECT ustanovaid,npzsifra,tipsole,siframss,program FROM tabsola WHERE id=".$R["idsola"];
                    $result1 = mysqli_query($link,$SQL1);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $VSolaID=$R1["ustanovaid"];
                        $NPZSifra=$R1["npzsifra"];
                        $TipSole=$R1["tipsole"];
                        $SifraZavoda=$R1["siframss"];
                        $VTipSole=$R1["program"];
                    }else{
                        $VSolaID=" ";
                        $NPZSifra=0;
                        $TipSole="Slovenska šola";
                        $SifraZavoda="0";
                        $VTipSole=3803;
                    }

                    $CountIzb=1;
                    $CompUcenec=$R["priimek"]." ".$R["ime"]." ".$R["emso"];
                    fwrite ($fh,"<Ucenec xmlns=".chr(34)."".chr(34).">"."\n");
                    fwrite ($fh,"  <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                    fwrite ($fh,"  <UVOZ_VIR>1</UVOZ_VIR>"."\n");
                    fwrite ($fh,"  <STATUS>1</STATUS>"."\n");
                    fwrite ($fh,"  <OPOMBA></OPOMBA>"."\n");
                    fwrite ($fh,"  <PRIIMEK>".$R["priimek"]."</PRIIMEK>"."\n");
                    fwrite ($fh,"  <IME>".$R["ime"]."</IME>"."\n");
                    if ($R["spol"]=="M"){
                        fwrite ($fh,"  <SPOL>M</SPOL>"."\n");
                    }else{
                        fwrite ($fh,"  <SPOL>Ž</SPOL>"."\n");
                    }
                    fwrite ($fh,"  <EMSO>".$R["emso"]."</EMSO>"."\n");
                    $Datum=new DateTime(isDate($R["datroj"]));
                    fwrite ($fh,"  <ROJSTVO_DATUM>".$Datum->format('Y-m-d')."</ROJSTVO_DATUM>"."\n");
                    fwrite ($fh,"  <ROJSTVO_KRAJ>".$R["krajroj"]."</ROJSTVO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROJSTVO_DRZ_REF>705</ROJSTVO_DRZ_REF>"."\n");
                    fwrite ($fh,"  <DRZAVLJANSTVO_REF>705</DRZAVLJANSTVO_REF>"."\n");
                    fwrite ($fh,"  <MATICNI_LIST_ST>".$R["maticnilist"]."</MATICNI_LIST_ST>"."\n");
                    fwrite ($fh,"  <EVIDENCNA_ST></EVIDENCNA_ST>"."\n");
                    fwrite ($fh,"  <OB_MID_REF xsi:nil=".chr(34)."true".chr(34)."></OB_MID_REF>"."\n");
                    fwrite ($fh,"  <HS_MID_REF xsi:nil=".chr(34)."true".chr(34)."></HS_MID_REF>"."\n");
                    fwrite ($fh,"  <DRZAVA_REF>705</DRZAVA_REF>"."\n");
                    
                    fwrite ($fh,"  <ROCNO_ULICA>".$R["naslov"]."</ROCNO_ULICA>"."\n");
                    fwrite ($fh,"  <ROCNO_KRAJ>".$R["kraj"]."</ROCNO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA_ID>".$R["posta"]."</ROCNO_POSTA_ID>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA>".$R["kraj"]."</ROCNO_POSTA>"."\n");
                    fwrite ($fh,"  <ZAVSIF>".$SifraZavoda."</ZAVSIF>"."\n");
                    fwrite ($fh,"  <SOLSKO_LETO_REF>".($VLeto-1995)."</SOLSKO_LETO_REF>"."\n");
                    fwrite ($fh,"  <PROGRAM_REF>".$VTipSole."</PROGRAM_REF>"."\n");
                    if ($VTipSole != 3813){
                        fwrite ($fh,"  <RAZRED_NOS>0</RAZRED_NOS>"."\n");
                    }else{
                        fwrite ($fh,"  <RAZRED_NOS>1</RAZRED_NOS>"."\n");
                    }
                    fwrite ($fh,"  <RAZRED_OBISK>".$R["razred"]."</RAZRED_OBISK>"."\n");
                    if ($R["razred"]==9){
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>".$TretjiPredmet."</TP_PREDMET_REF>"."\n");
                    }else{
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>1487</TP_PREDMET_REF>"."\n");
                    }
                    fwrite ($fh,"  <ODDELEK_OZNAKA>".$R["oznaka"]."</ODDELEK_OZNAKA>"."\n");
                    fwrite ($fh,"  <RAZREDNIK_IME>".$R["uime"]." ".$R["upriimek"]."</RAZREDNIK_IME>"."\n");
                    $VsebujeIzb=false;
                    if ($R["razred"]==9){
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            if ($R["iducenec"] == $UcenecIzb[$Indx][0]){
                                if (($UcenecIzb[$Indx][1] == "") or ($UcenecIzb[$Indx][1]=="0")){
                                    fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP1_PREDMET_REF>".$UcenecIzb[$Indx][1]."</IP1_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][2] == "") or ($UcenecIzb[$Indx][2]=="0")){
                                    fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP2_PREDMET_REF>".$UcenecIzb[$Indx][2]."</IP2_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][3] == "") or ($UcenecIzb[$Indx][3]=="0")){
                                    fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP3_PREDMET_REF>".$UcenecIzb[$Indx][3]."</IP3_PREDMET_REF>"."\n");
                                }
                                fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                                fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                                fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                                $VsebujeIzb=true;
                            }
                        }
                    }
                    if ($R["razred"]==6){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                        $VsebujeIzb=true;
                    }
                    if (!$VsebujeIzb){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                    }
                    fwrite ($fh,"</Ucenec>"."\n");
                }
            }
        }

        fwrite ($fh,"</Ucenci>"."\n");
        fclose($fh);

        echo "<h2>Pozor!</h2>";
        echo "<font color='red'>Vsi učenci imajo za državo rojstva vpisano Slovenijo in slovensko državljanstvo!</font><br />";
        echo "<font color='red'>Učenci brez vpisane EMŠO ne bodo uvoženi v aplikacijo MŠŠ!</font><br />";
        echo "<br />";
        echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
        echo "<h3>Shrani datoteko <a href='".$MyFile."'>".$VFile."</a></h3>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "802": //export ocen za 6. razrede
        /*
          Kontakt za prenos podatkov:
          podpora@b2.eu
          01/2444-222
        */
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $VFile="ocene6r.xml";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        fwrite ($fh,"<"."?xml version='1.0' encoding='utf-8' standalone='yes'?".">"."\n");
        echo "<h3>Izvoz ocen 6. razredov</h3>";

        $SQL = "SELECT tabpredmeti.siframss FROM tabnpzpredmeti INNER JOIN tabpredmeti ON tabnpzpredmeti.idpredmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabnpzpredmeti.leto=".$VLeto." AND razred=9 AND prednost=3";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $TretjiPredmet=$R["siframss"];
        }else{
            $TretjiPredmet=1487;
        }
        /*
        $SQL = "SELECT tabrazred.iducenec,tabpredmeti.siframss FROM ";
        $SQL = $SQL . "(((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN TabIzbirni ON tabrazred.idUcenec=TabIzbirni.Ucenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON TabIzbirni.izbirni=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred=9) AND (TabIzbirni.leto=".$VLeto.") AND (tabpredmeti.prioriteta=1) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        $CompUcenec=0;
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["iducenec"]){
                $CountIzb=1;
                $Indx=$Indx+1;
                $CompUcenec=$R["iducenec"];
                $UcenecIzb[$Indx][0]=$R["iducenec"];
                $UcenecIzb[$Indx][1]="0";
                $UcenecIzb[$Indx][2]="0";
                $UcenecIzb[$Indx][3]="0";
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }else{
                $CountIzb=$CountIzb+1;
                $UcenecIzb[$Indx][$CountIzb]=$R["siframss"];
            }
        }
        $StUcencev=$Indx;
        */
        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabucenci.spol,tabucenci.datroj,tabucenci.krajroj,tabucenci.maticnilist,tabucenci.naslov,tabucenci.kraj,tabucenci.posta,";
        $SQL = $SQL . "tabucitelji.ime AS uime,tabucitelji.priimek AS upriimek,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola FROM ";
        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabrazred.idUcitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE (tabrazdat.leto=".$VLeto.") AND (tabrazdat.razred = 6) ORDER BY tabrazdat.razred,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        fwrite ($fh,"<Ucenci xmlns=".chr(34)."https://soca1.mss.edus.si/NPZinVpis2009/Dokumenti/NPZUvoz.xsd".chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34).">"."\n");

        $CompUcenec="";
        while ($R = mysqli_fetch_array($result)){
            if ($CompUcenec != $R["priimek"]." ".$R["ime"]." ".$R["emso"]){
                if (strlen($R["emso"]) > 0){
                    $SQL1 = "SELECT ustanovaid,npzsifra,tipsole,siframss,program FROM tabsola WHERE id=".$R["idsola"];
                    $result1 = mysqli_query($link,$SQL1);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $VSolaID=$R1["ustanovaid"];
                        $NPZSifra=$R1["npzsifra"];
                        $TipSole=$R1["tipsole"];
                        $SifraZavoda=$R1["siframss"];
                        $VTipSole=$R1["program"];
                    }else{
                        $VSolaID=" ";
                        $NPZSifra=0;
                        $TipSole="Slovenska šola";
                        $SifraZavoda="0";
                        $VTipSole=3803;
                    }

                    $CountIzb=1;
                    $CompUcenec=$R["priimek"]." ".$R["ime"]." ".$R["emso"];
                    fwrite ($fh,"<Ucenec xmlns=".chr(34)."".chr(34).">"."\n");
                    fwrite ($fh,"  <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                    fwrite ($fh,"  <UVOZ_VIR>1</UVOZ_VIR>"."\n");
                    fwrite ($fh,"  <STATUS>1</STATUS>"."\n");
                    fwrite ($fh,"  <OPOMBA></OPOMBA>"."\n");
                    fwrite ($fh,"  <PRIIMEK>".$R["priimek"]."</PRIIMEK>"."\n");
                    fwrite ($fh,"  <IME>".$R["ime"]."</IME>"."\n");
                    if ($R["spol"]=="M"){
                        fwrite ($fh,"  <SPOL>M</SPOL>"."\n");
                    }else{
                        fwrite ($fh,"  <SPOL>Ž</SPOL>"."\n");
                    }
                    fwrite ($fh,"  <EMSO>".$R["emso"]."</EMSO>"."\n");
                    $Datum=new DateTime(isDate($R["datroj"]));
                    fwrite ($fh,"  <ROJSTVO_DATUM>".$Datum->format('Y-m-d')."</ROJSTVO_DATUM>"."\n");
                    fwrite ($fh,"  <ROJSTVO_KRAJ>".$R["krajroj"]."</ROJSTVO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROJSTVO_DRZ_REF>705</ROJSTVO_DRZ_REF>"."\n");
                    fwrite ($fh,"  <DRZAVLJANSTVO_REF>705</DRZAVLJANSTVO_REF>"."\n");
                    fwrite ($fh,"  <MATICNI_LIST_ST>".$R["maticnilist"]."</MATICNI_LIST_ST>"."\n");
                    fwrite ($fh,"  <EVIDENCNA_ST></EVIDENCNA_ST>"."\n");
                    fwrite ($fh,"  <OB_MID_REF xsi:nil=".chr(34)."true".chr(34)."></OB_MID_REF>"."\n");
                    fwrite ($fh,"  <HS_MID_REF xsi:nil=".chr(34)."true".chr(34)."></HS_MID_REF>"."\n");
                    fwrite ($fh,"  <DRZAVA_REF>705</DRZAVA_REF>"."\n");
                    
                    fwrite ($fh,"  <ROCNO_ULICA>".$R["naslov"]."</ROCNO_ULICA>"."\n");
                    fwrite ($fh,"  <ROCNO_KRAJ>".$R["kraj"]."</ROCNO_KRAJ>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA_ID>".$R["posta"]."</ROCNO_POSTA_ID>"."\n");
                    fwrite ($fh,"  <ROCNO_POSTA>".$R["kraj"]."</ROCNO_POSTA>"."\n");
                    fwrite ($fh,"  <ZAVSIF>".$SifraZavoda."</ZAVSIF>"."\n");
                    fwrite ($fh,"  <SOLSKO_LETO_REF>".($VLeto-1995)."</SOLSKO_LETO_REF>"."\n");
                    fwrite ($fh,"  <PROGRAM_REF>".$VTipSole."</PROGRAM_REF>"."\n");
                    if ($VTipSole != 3813){
                        fwrite ($fh,"  <RAZRED_NOS>0</RAZRED_NOS>"."\n");
                    }else{
                        fwrite ($fh,"  <RAZRED_NOS>1</RAZRED_NOS>"."\n");
                    }
                    fwrite ($fh,"  <RAZRED_OBISK>".$R["razred"]."</RAZRED_OBISK>"."\n");
                    /*if ($R["razred"]==9){
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>".$TretjiPredmet."</TP_PREDMET_REF>"."\n");
                    }else{
                    */
                        fwrite ($fh,"  <MJ_PREDMET_REF>1304</MJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <TJ_PREDMET_REF>1487</TJ_PREDMET_REF>"."\n");
                        fwrite ($fh,"  <DRUGI_TJ_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)."/>"."\n");
                        fwrite ($fh,"  <TP_PREDMET_REF>1487</TP_PREDMET_REF>"."\n");
                    //}
                    fwrite ($fh,"  <ODDELEK_OZNAKA>".$R["oznaka"]."</ODDELEK_OZNAKA>"."\n");
                    fwrite ($fh,"  <RAZREDNIK_IME>".$R["uime"]." ".$R["upriimek"]."</RAZREDNIK_IME>"."\n");
                    $VsebujeIzb=false;
                    /*
                    if ($R["razred"]==9){
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            if ($R["iducenec"] == $UcenecIzb[$Indx][0]){
                                if (($UcenecIzb[$Indx][1] == "") or ($UcenecIzb[$Indx][1]=="0")){
                                    fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP1_PREDMET_REF>".$UcenecIzb[$Indx][1]."</IP1_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][2] == "") or ($UcenecIzb[$Indx][2]=="0")){
                                    fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP2_PREDMET_REF>".$UcenecIzb[$Indx][2]."</IP2_PREDMET_REF>"."\n");
                                }
                                if (($UcenecIzb[$Indx][3] == "") or ($UcenecIzb[$Indx][3]=="0")){
                                    fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                                }else{
                                    fwrite ($fh,"  <IP3_PREDMET_REF>".$UcenecIzb[$Indx][3]."</IP3_PREDMET_REF>"."\n");
                                }
                                fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                                fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                                fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                                $VsebujeIzb=true;
                            }
                        }
                    }
                    */
                    //if ($R["razred"]==6){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                        $VsebujeIzb=true;
                    //}
                    if (!$VsebujeIzb){
                        fwrite ($fh,"  <IP1_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP2_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP3_PREDMET_REF xsi:nil=".chr(34)."true".chr(34)." />"."\n");
                        fwrite ($fh,"  <IP1_OCENA>5</IP1_OCENA>"."\n");
                        fwrite ($fh,"  <IP2_OCENA>5</IP2_OCENA>"."\n");
                        fwrite ($fh,"  <IP3_OCENA>5</IP3_OCENA>"."\n");
                    }
                    fwrite ($fh,"</Ucenec>"."\n");
                }
            }
        }

        fwrite ($fh,"  <UcenecOcene xmlns=".chr(34).chr(34).">"."\n");

        $SQL = "SELECT tabucenci.iducenec,tabocene.ocenakoncna,tabocene.neocenjen,tabpredmeti.siframss,tabrazdat.razred FROM (((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabocene ON tabucenci.idUcenec=tabocene.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabocene.idPredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazdat.razred=6 ";
        $SQL = $SQL . "ORDER BY tabrazdat.razred,priimek,ime,vrstnired";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                fwrite ($fh,"   <UcenecOcena xmlns=".chr(34).chr(34).">"."\n");
                fwrite ($fh,"     <SIFRA>".$R["iducenec"]."</SIFRA>"."\n");
                fwrite ($fh,"     <RAZRED>".$R["razred"]."</RAZRED>"."\n");
                fwrite ($fh,"     <PREDMET_REF>".$R["siframss"]."</PREDMET_REF>"."\n");
                switch ($R["neocenjen"]){
                    case 1:
                        fwrite ($fh,"     <OCENA>N</OCENA>"."\n");
                        break;
                    case 2:
                        fwrite ($fh,"     <OCENA>O</OCENA>"."\n");
                        break;
                    default:   
                        fwrite ($fh,"     <OCENA>".$R["ocenakoncna"]."</OCENA>"."\n");
                }
                fwrite ($fh,"   </UcenecOcena>"."\n");
            }
        }

        fwrite ($fh,"  </UcenecOcene>"."\n");
        fwrite ($fh,"</Ucenci>"."\n");
        fclose($fh);

        echo "<h2>Pozor!</h2>";
        echo "<font color='red'>Vsi učenci imajo za državo rojstva vpisano Slovenijo in slovensko državljanstvo!</font><br />";
        echo "<font color='red'>Učenci brez vpisane EMŠO ne bodo uvoženi v aplikacijo MŠŠ!</font><br />";
        echo "<br />";
        echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
        echo "<h3>Shrani datoteko <a href='".$MyFile."'>".$VFile."</a></h3>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "</body>";
        echo "</html>";
        break;
}
?>