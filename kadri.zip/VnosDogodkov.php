<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vnos dogodkov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

function Arr2Str($a){
    $s="";
    if (is_array($a)){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }else{
        return $a;
    }
    return $s;
}

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo2",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    function Vsebuje($a,$s){
	    $x=split(",",$s);
        return (in_array($a,$x));
    }

    switch ($Vid){
	    case "1":
		    $VDogodek=$_POST["Dogodek"];
            if (isDate($_POST["datum"])){
		        $VDatum=$_POST["datum"];
            }else{
                $VDatum=$Danes->format('j.n.Y');
            }
            
		    if (isDate($_POST["porocilaDo"])){ 
                $VporocilaDo=$_POST["porocilaDo"];
            }else{
                $VporocilaDo=$Danes->format('j.n.Y');
            }
		    $Vkdo=$_POST["kdo"];
		    
		    switch ($Vkdo){
			    case 1:	//'vsi ucitelji
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto;
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 2:	//'razredniki
				    $SQL = "SELECT DISTINCT iducitelj FROM TabRazred WHERE leto=".$VLeto;
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 3:	//'učitelji na razredni stopnji
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (1,2,3,4,5)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 4:	//'učitelji na predmetni stopnji
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (6,7,8,9)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 5:	//'učitelji prve triade
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (1,2,3)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 6:	//'učitelji druge triade
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (4,5,6)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 7:	//'učitelji tretje triade
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (7,8,9)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 8:	//'učitelji OPB
				    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND predmet IN (52,78,79,80,81,82,83,84,85,86,87,88,89,90,91)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 9:	//'vodje aktivov
				    $SQL = "SELECT iducitelj FROM TabVodjeAktivov WHERE leto=".$VLeto;
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 10:	//'določeni učitelji
				    $Vizbrani=Arr2Str($_POST["ucitelji"]);
                    break;
			    case 11:	//'razredniki druge triade
				    $SQL = "SELECT DISTINCT iducitelj FROM Tabrazred WHERE leto=".$VLeto." AND razred IN (4,5,6)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
			    case 12: //	'razredniki druge triade
				    $SQL = "SELECT DISTINCT iducitelj FROM Tabrazred WHERE leto=".$VLeto." AND razred IN (7,8,9)";
				    $result = mysqli_query($link,$SQL);
				    
				    $Vizbrani="";
				    while ($R = mysqli_fetch_array($result)){
					    if ($Vizbrani == "" ){
						    $Vizbrani=$R["iducitelj"];
					    }else{
						    $Vizbrani=$Vizbrani.",".$R["iducitelj"];
					    }
				    }
                    break;
                default:
                    $Vizbrani="0";
		    }
		    
		    $SQL = "SELECT tabdogodek.* FROM tabdogodek ";
		    $SQL = $SQL . " WHERE (dogodek='".$VDogodek."')";
		    $SQL = $SQL . " AND(leto=".$VLeto.")";
		    $SQL = $SQL . " AND (datum='".$VDatum."')";
		    $SQL = $SQL . " AND (porocilaDo='".$VporocilaDo."')";
		    $SQL = $SQL . " AND (kdo=".$Vkdo.")";
		    
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    echo "<h2>Podatki so bili že vpisani!</h2>";
		    }else{
			    $VSedaj=$Danes->format('Y-m-d H:i:s');
			    $SQL="INSERT INTO tabdogodek (leto,Dogodek,datum,porocilaDo,kdo,ucitelji,cas,vpisal) ";
			    $SQL = $SQL . "VALUES (";
			    $SQL = $SQL .$VLeto.",'".$VDogodek."',";
			    $SQL = $SQL ."'".$VDatum."',";
			    $SQL = $SQL ."'".$VporocilaDo."',";
			    $SQL = $SQL .$Vkdo.",";
			    $SQL = $SQL ."'".$Vizbrani."',";
			    $SQL = $SQL ."'".$VSedaj."',";
			    $SQL = $SQL ."'".$VUporabnik."'";
			    $SQL = $SQL .")";
			    $result = mysqli_query($link,$SQL);

			    $SQL = "SELECT tabdogodek.* FROM tabdogodek WHERE cas='".$VSedaj."'";
			    $result = mysqli_query($link,$SQL);

			    if ($R = mysqli_fetch_array($result)){
				    $VidDogodek=$R["id"];
				    $SQL = "SELECT iducitelj FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelji"].")";
				    $result = mysqli_query($link,$SQL);
				    $indx=1;
				    while ($R = mysqli_fetch_array($result)){
					    $Delavci[$indx]=$R["iducitelj"];
					    $indx=$indx+1;
				    }
			    }
			    
			    for ($i1=1;$i1 <= ($indx-1);$i1++){
				    $SQL="INSERT INTO tabdeldogodek (idDogodek,idUcitelj,opravljeno,datum) VALUES (".$VidDogodek.",".$Delavci[$i1].",false,'')";
				    $result = mysqli_query($link,$SQL);
			    }
			    echo "<h2>Podatki so vpisani!</h2>";
		    }
            break;
	    case "2":
    //'		echo request("popravi")."<br>"
		    $SQL = "SELECT * FROM tabdogodek WHERE id=".$_GET["zapis"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $VDogodek=$R["Dogodek"];
			    $VDatum=$R["datum"];
			    $VporocilaDo=$R["porocilaDo"];
			    $Vkdo=$R["kdo"];
			    $Vizbrani=$R["ucitelji"];
		    }
		    echo "<form accept-charset='utf-8' name='form_dogodki' method=post action='VnosDogodkov.php'>";
		    echo "<table border=1 cellspacing=0>";
    //		echo "<tr><th>Leto</th><th>Dogodek</th><th>Datum</th><th>Zadnji rok<br>oddaje poročila</th><th>Kdo</th><th>Učitelji</th><th>Popravi</th><th>Briši</th></tr>";
            echo "<tr><th>Leto</th><th>Dogodek</th><th>Datum</th><th>Zadnji rok<br>oddaje poročila</th><th>Kdo</th><th>Učitelji</th><th></th></tr>";
		    echo "<tr>";
		    echo "<td>".$VLeto."/".($VLeto+1)."</td>";
		    
		    echo "<td><select name='Dogodek'>";
		    $SQL = "SELECT tip FROM tabzapisniktip";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if ($VDogodek==$R["tip"] ){
				    echo "<option selected>".$R["tip"]."</option>";
			    }else{
				    echo "<option>".$R["tip"]."</option>";
			    }
		    }
		    $SQL = "SELECT tip FROM tabporocilotip";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if ($VDogodek==$R["tip"] ){
				    echo "<option selected>".$R["tip"]."</option>";
			    }else{
				    echo "<option>".$R["tip"]."</option>";
			    }
		    }
		    echo "</select></td>";
		    
    //'		echo "<td><input name='dogodek' type='text' size='30' value='".$VDogodek."'></td>"
		    echo "<td><input name='datum' type='text' size='8' value='".$VDatum."'></td>";
		    echo "<td><input name='porocilaDo' type='text' size='8' value='".$VporocilaDo."'></td>";
		    echo "<td><select name='kdo'>";

		    $SQL = "SELECT idskupina,skupina FROM TabSifrantSkupin ORDER BY idSkupina";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if ($Vkdo==$R["idskupina"] ){
				    echo "<option value=".$R["idskupina"]." selected='selected'>".$R["skupina"]."</option>";
			    }else{
				    echo "<option value=".$R["idskupina"].">".$R["skupina"]."</option>";
			    }
		    }
		    echo "</select></td>";

		    echo "<td><select name='ucitelji[]' size='5' multiple>";

		    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    if (Vsebuje($R["iducitelj"],$Vizbrani) ){
				    echo "<option value=".$R["iducitelj"]." selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
			    }else{
				    echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
			    }
		    }
		    echo "</select></td>";
    //'	echo "<td><a href='VnosDogodkov.php?id=2.zapis=".$R["id")."'>Popravi</a></td>"
    //'	echo "<td><a href='VnosDogodkov.php?id=3.zapis=".$R["id")."'>Bri?i</a></td>"

		    echo "<td><input name='solskoleto' type='hidden' value='".$VLeto."'>";
		    echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
		    echo "<input name='id' type='hidden' value='4'>";
		    echo "<input name='submit' type='submit' value='Pošlji'>";
		    echo "</td>";
		    echo "</tr>";

		    echo "</table>";
		    echo "</form>";
            break;
	    case "3":
		    $SQL = "SELECT * FROM tabdogodek WHERE id=".$_GET["zapis"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $SQL = "DELETE FROM tabdogodek WHERE id=".$_GET["zapis"];
			    $result = mysqli_query($link,$SQL);
			    
			    $SQL = "DELETE FROM tabdeldogodek WHERE idDogodek=".$_GET["zapis"];
			    $result = mysqli_query($link,$SQL);
		    }
            break;
	    case "4":
		    $VDogodek=$_POST["Dogodek"];
		    $VDatum=$_POST["datum"];
		    if (!isDate($VDatum) ){ 
                $VDatum=$Danes->format('j.n.Y');
            }
		    $VporocilaDo=$_POST["porocilaDo"];
		    if (!isDate($VporocilaDo) ){ 
                $VporocilaDo=$Danes->format('j.n.Y');
            }
		    $Vkdo=$_POST["kdo"];
		    
		    switch ($Vkdo){
                case 1:    //'vsi ucitelji
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 2:    //'razredniki
                    $SQL = "SELECT DISTINCT iducitelj FROM TabRazred WHERE leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 3:    //'učitelji na razredni stopnji
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (1,2,3,4,5)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 4:    //'učitelji na predmetni stopnji
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (6,7,8,9)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 5:    //'učitelji prve triade
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (1,2,3)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 6:    //'učitelji druge triade
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (4,5,6)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 7:    //'učitelji tretje triade
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND razred IN (7,8,9)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 8:    //'učitelji OPB
                    $SQL = "SELECT DISTINCT iducitelj FROM tabucenje WHERE leto=".$VLeto." AND predmet IN (52,78,79,80,81,82,83,84,85,86,87,88,89,90,91)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 9:    //'vodje aktivov
                    $SQL = "SELECT iducitelj FROM TabVodjeAktivov WHERE leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 10:    //'določeni učitelji
                    $Vizbrani=Arr2Str($_POST["ucitelji"]);
                    break;
                case 11:    //'razredniki druge triade
                    $SQL = "SELECT DISTINCT iducitelj FROM Tabrazred WHERE leto=".$VLeto." AND razred IN (4,5,6)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
                    break;
                case 12: //    'razredniki druge triade
                    $SQL = "SELECT DISTINCT iducitelj FROM Tabrazred WHERE leto=".$VLeto." AND razred IN (7,8,9)";
                    $result = mysqli_query($link,$SQL);
                    
                    $Vizbrani="";
                    while ($R = mysqli_fetch_array($result)){
                        if ($Vizbrani == "" ){
                            $Vizbrani=$R["iducitelj"];
                        }else{
                            $Vizbrani=$Vizbrani.",".$R["iducitelj"];
                        }
                    }
		    }
		    
		    $SQL="UPDATE tabdogodek SET ";
		    $SQL = $SQL . "dogodek='".$VDogodek."',";
		    $SQL = $SQL . "datum='".$VDatum."',";
		    $SQL = $SQL . "porocilaDo='".$VporocilaDo."',";
		    $SQL = $SQL . "kdo=".$Vkdo.",";
		    $SQL = $SQL . "ucitelji='".$Vizbrani."',";
		    $SQL = $SQL . "vpisal='".$VUporabnik."',";
		    $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
		    $SQL = $SQL ." WHERE id=".$_POST["zapis"];
		    $result = mysqli_query($link,$SQL);
    }

    if ($Vid <> 2 ){
	    echo "<form accept-charset='utf-8' name='form_dogodek' method=post action='VnosDogodkov.php'>";
	    echo "<h2>Vnos šolskih dogodkov</h2>";
	    echo "<table border=1 cellspacing=0>";
	    echo "<tr><th>Leto</th><th>Dogodek</th><th>Datum</th><th>Zadnji rok<br>oddaje poročila</th><th>Kdo</th><th>Učitelji</th><th></th></tr>";
	    echo "<tr>";
	    echo "<td>".$VLeto."/".($VLeto+1)."</td>";

	    echo "<td><select name='Dogodek'>";
	    $SQL = "SELECT tip FROM tabzapisniktip";
	    $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    echo "<option>".$R["tip"]."</option>";
	    }
	    $SQL = "SELECT tip FROM tabporocilotip";
	    $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    echo "<option>".$R["tip"]."</option>";
	    }
	    echo "</select></td>";
	    
	    echo "<td><input name='datum' type='text' size='8'></td>";
	    echo "<td><input name='porocilaDo' type='text' size='8'></td>";
	    echo "<td><select name='kdo'>";

	    $SQL = "SELECT idskupina,skupina FROM TabSifrantSkupin ORDER BY idSkupina";
	    $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    echo "<option value=".$R["idskupina"].">".$R["skupina"]."</option>";
	    }
	    echo "</select></td>";

	    echo "<td><select name='ucitelji[]' size='5' multiple>";

	    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
	    $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
	    }
	    echo "</select></td>";
    //'	echo "<td><a href='VnosDogodkov.php?id=2.zapis=".$R["id")."'>Popravi</a></td>"
    //'	echo "<td><a href='VnosDogodkov.php?id=3.zapis=".$R["id")."'>Bri?i</a></td>"

	    echo "<td><input name='solskoleto' type='hidden' value='".$VLeto."'>";
	    echo "<input name='id' type='hidden' value='1'>";
	    echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
	    echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
	    echo "<input name='level' type='hidden' value='".$VLevel."'>";
	    echo "<input name='submit' type='submit' value='Pošlji'>";
	    echo "</form></td>";
	    echo "</tr>";

	    $SQL = "SELECT tabdogodek.*,tabdogodek.id AS did,TabSifrantSkupin.* FROM ";
	    $SQL = $SQL."tabdogodek INNER JOIN TabSifrantSkupin ON tabdogodek.kdo=TabSifrantSkupin.IdSkupina ";
	    $SQL = $SQL."WHERE tabdogodek.leto=".$VLeto;
	    $SQL = $SQL." ORDER BY tabdogodek.id";
	    $result = mysqli_query($link,$SQL);

	    $indx=0;
	    while ($R = mysqli_fetch_array($result)){
		    echo "<tr>";
		    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
		    echo "<td>".$R["Dogodek"]."</td>";
		    echo "<td>".$R["datum"]."</td>";
		    echo "<td>".$R["porocilaDo"]."</td>";
		    echo "<td>".$R["skupina"]."</td><td>&nbsp;</td>";
		    echo "<td><a href='VnosDogodkov.php?id=2&zapis=".$R["did"]."'>Popravi</a></td>";
		    echo "<td><a href='VnosDogodkov.php?id=3&zapis=".$R["did"]."'>Briši</a></td>";
		    echo "</tr>";
		    $indx = $indx+1;
	    }
	    echo "</table>";
		    
    }
}
?>
<a href="IzpisOpravil.php">Izpis realizacije opravil</a><br />
<a href="prijava.php">Nazaj na glavni meni</a><br />
</body>
</html>
