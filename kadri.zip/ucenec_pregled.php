<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmp3.css"> 
<title>Učenec
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }

    function ToTip($x){
        switch ($x){
            case 0:
                return "Končno spričevalo";
            case 1:
                return "Polletno obvestilo";
            case 2:
                return "Redovalnica 1. semester";
            case 3:
                return "Redovalnica 2. semester";
        }
    }
    function ToNivojski($x){
        switch ($x){
            case 1:
                return "MAT";
            case 2:
                return "MAT1";
            case 3:
                return "MAT2";
            case 4:
                return "MAT3";
            case 13:
                return "MAT4";
            case 14:
                return "MAT5";
            case 15:
                return "MAT6";
            case 5:
                return "SLO";
            case 6:
                return "SLO1";
            case 7:
                return "SLO2";
            case 8:
                return "SLO3";
            case 16:
                return "SLO4";
            case 17:
                return "SLO5";
            case 18:
                return "SLO6";
            case 9:
                return "TJA";
            case 10:
                return "TJA1";
            case 11:
                return "TJA2";
            case 12:
                return "TJA3";
            case 19:
                return "TJA4";
            case 20:
                return "TJA5";
            case 21:
                return "TJA6";
        }
    }

    function MonthName($x){
        switch ($x){
            case 1:
                return "januar";
            case 2:
                return "februar";
            case 3:
                return "marec";
            case 4:
                return "april";
            case 5:
                return "maj";
            case 6:
                return "junij";
            case 7:
                return "julij";
            case 8:
                return "avgust";
            case 9:
                return "september";
            case 10:
                return "oktober";
            case 11:
                return "november";
            case 12:
                return "december";
        }       
    }
    if (isset($_POST["ucenec"])){
        $ucenec = $_POST["ucenec"];
    }else{
        if (isset($_GET["ucenec"])){
            $ucenec=$_GET["ucenec"];
        }else{
            $ucenec = 0;
        }
    }

    echo "Leto: ".$VLeto."/".($VLeto+1)."<br />";
    //Izpis navigacije naprej/nazaj
	$SQL = "SELECT idrazred FROM tabrazred WHERE iducenec=".$ucenec." AND leto=".$VLeto;
	$result = mysqli_query($link,$SQL);
	if ($R = mysqli_fetch_array($result)){
		$VRazred=$R["idrazred"];
	}else{
		$VRazred=0;
	}
	$_SESSION["razred"]=$VRazred;
	$SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred ";
	$SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
	$SQL = $SQL . " WHERE idrazred=".$VRazred." ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    $izbrani=0;
    while ($R = mysqli_fetch_array($result)){
        $idUcenec[$Indx][0]=$R["iducenec"];
        $idUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
        if ($R["iducenec"]==$ucenec){
            $izbrani=$Indx;
        }
        $Indx=$Indx+1;
    }
    $vseh=$Indx-1;
	if ($vseh > 1){
		switch ($izbrani){
			case 1:
				echo "<a href='izborrazreda.php'>Izberi razred</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani+1][0]."'> Naslednji (".$idUcenec[$izbrani+1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$vseh][0]."'> Zadnji (".$idUcenec[$vseh][1].")</a><br />";
				break;
			case $vseh:
				echo "<a href='ucenec_pregled.php?ucenec=".$idUcenec[1][0]."'> Prvi (".$idUcenec[1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani-1][0]."'>Prejšnji (".$idUcenec[$izbrani-1][1].")</a> | <a href='izborrazreda.php'>Izberi razred</a><br />";
				break;
			default:
				if ($izbrani > 1){
					echo "<a href='ucenec_pregled.php?ucenec=".$idUcenec[1][0]."'> Prvi (".$idUcenec[1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani-1][0]."'>Prejšnji (".$idUcenec[$izbrani-1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani+1][0]."'>Naslednji (".$idUcenec[$izbrani+1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$vseh][0]."'> Zadnji (".$idUcenec[$vseh][1].")</a><br />";
				}else{
					echo "<a href='ucenec_pregled.php?ucenec=".$idUcenec[1][0]."'> Prvi (".$idUcenec[1][1].")</a> |  <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani+1][0]."'>Naslednji (".$idUcenec[$izbrani+1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$vseh][0]."'> Zadnji (".$idUcenec[$vseh][1].")</a><br />";
				}
		}
	}
    
    if ($ucenec > 0){
        $oUcenec=new RUcenec();
        $oUcenec->getUcenec($ucenec);
        
        //splošni podatki
        echo "<h2>Izpis učenca:</h2>";
        $SQL = "SELECT * FROM tabrazred WHERE idUcenec=".$ucenec ." AND slika LIKE '%slike%' AND leto > 2010";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if (file_exists($R["slika"])){
                echo "<img src='".$R["slika"]."' width='100'> ";
            }
        }
        echo "<br />";
        
        echo "Ime: <b>" . $oUcenec->getPriimek()  . ", " . $oUcenec->getIme() . "</b>, Datum rojstva: <b>" . $oUcenec->getDatRoj(). "</b>, Spol: <b>" . $oUcenec->getSpol2() . "</b><br />";
        echo "Naslov:<b> " . $oUcenec->getNaslov() . ", " . $oUcenec->getPosta() . " " . $oUcenec->getKraj() . "</b><br />";
        if (strlen($oUcenec->getNaslovZac()) > 0){
            echo "Začasni naslov:<b> " . $oUcenec->getNaslovZac() . ", " . $oUcenec->getPostaZac() . " " . $oUcenec->getKrajZac() . "</b><br />";
        }
        echo "Bivanje:<b> " . $oUcenec->getBivanjePri(). "</b><br />";
        if (strlen($oUcenec->getTelefonDoma()) > 0){
            echo "Telefon doma: <b>" . $oUcenec->getTelefonDoma(). "</b><br />";
        }
        echo "<table><tr class='head'><th class='hide'>&nbsp;</th><th class='hide'>Oče</th><th class='hide'>Mati</th></tr>";
        echo "<tr class='hide'>";
        echo "<td class='hide'>Ime: </td>";
        echo "<td class='hide'><b>" . $oUcenec->getoce() ."</b></td>";
        echo "<td class='hide'><b> " . $oUcenec->getmati() ."</b></td>";
        echo "</tr>";
        echo "<tr class='hide'>";
        echo "<td class='hide'>Naslov: </td>";
        echo "<td class='hide'><b>".$oUcenec->getocenaslov()."</b></td>";
        echo "<td class='hide'><b>".$oUcenec->getmatinaslov()."</b></td>";
        echo "</tr>";
        if ((strlen($oUcenec->getocezacnasl()) > 0) or (strlen($oUcenec->getmatizacnasl()) > 0)){
            echo "<tr class='hide'>";
            echo "<td class='hide'>Začasni naslov: </td>";
            if (strlen($oUcenec->getocezacnasl()) > 0){
                echo "<td class='hide'><b>".$oUcenec->getocezacnasl()."</b></td>";
            }else{
                echo "<td class='hide'>&nbsp;</td>";
            }
            if (strlen($oUcenec->getmatizacnasl()) > 0){
                echo "<td class='hide'><b>".$oUcenec->getmatizacnasl()."</b></td>";
            }else{
                echo "<td class='hide'>&nbsp;</td>";
            }
            echo "</tr>";
        }
        echo "<tr class='hide'>";
        echo "<td class='hide'>Kontakt: </td>";
        echo "<td class='hide'>";
        if (strlen($oUcenec->getocekontakt()) > 0){
            echo "<b>".$oUcenec->getocekontakt()."</b>&nbsp;";
        }
        if (strlen($oUcenec->getoceGSM()) > 0){
            echo "GSM: <b>".$oUcenec->getoceGSM()."</b>&nbsp;";
        }
        if (strlen($oUcenec->getoceSluzba()) > 0){
            echo "služba: <b>".$oUcenec->getoceSluzba(). "</b>";
        }
        echo "</td>";
        
        echo "<td class='hide'>";
        if (strlen($oUcenec->getmatikontakt()) > 0){
            echo "<b>".$oUcenec->getmatikontakt()."</b>&nbsp;";
        }            
        if (strlen($oUcenec->getmatiGSM()) > 0){
            echo "GSM: <b>".$oUcenec->getmatiGSM()."</b>&nbsp;";
        }
        if (strlen($oUcenec->getmatiSluzba()) > 0){
            echo "služba: <b>".$oUcenec->getmatiSluzba(). "</b>";
        }
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td class='hide'>e-pošta: </td>";
        echo "<td class='hide'>";
        if (strlen($oUcenec->getoceemail()) > 1){
            echo $oUcenec->getoceemail();
        }
        echo "</td>";
        echo "<td class='hide'>";
        if (strlen($oUcenec->getmatiemail()) > 1){
            echo $oUcenec->getmatiemail();
        }
        echo "</td>";
        echo "</tr>";
        
        echo "</table><br />";

        echo "<a href='ucenec.php?id=3&ucenec=".$oUcenec->getIdUcenec()."'>Popravi podatke o učencu</a><br />";

        if ($VLevel > 2 ){
            echo "<br /><a href='ucenec.php?id=5&ucenec=".$ucenec."'>Dokončno briši učenca</a><br />";
        }

        $SQL = "SELECT leto FROM tabrazred WHERE iducenec=" . $ucenec . " ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);

        //Izpis razrednih podatkov
        if (mysqli_num_rows($result) > 0){
            echo "<br /><table>";
            echo "<tr class='head'>";
            if ($VLevel < 2 ){
                echo "<th class='hide'>Leto</th>";
                echo "<th class='hide'>Razred</th>";
                echo "<th class='hide'>Polletni<br />uspeh</th>";
                echo "<th class='hide'>Uspeh</th>";
                echo "<th class='hide'>Status</th>";
                echo "<th class='hide'>Razr.<br />izpit</th>";
                echo "<th class='hide'>Napredovanje</th>";
                echo "<th class='hide'>Leto<br />šolanja</th>";
                echo "<th class='hide'>Nadarjen</th>";
                echo "<th class='hide'>Športnik</th>";
                echo "<th class='hide'>Kulturnik</th>";
                echo "<th class='hide'>Učitelj</th>";
                echo "<th class='hide'>Vzgojitelj</th>";
            }else{
                echo "<th class='hide'>Leto</th>";
                echo "<th class='hide'>Razred</th>";
                echo "<th class='hide'>Polletni<br />uspeh</th>";
                echo "<th class='hide'>Uspeh</th>";
                echo "<th class='hide'>Status</th>";
                echo "<th class='hide'>Razr.<br />izpit</th>";
                echo "<th class='hide'>Napredovanje</th>";
                echo "<th class='hide'>Leto<br />šolanja</th>";
                echo "<th class='hide'>Nadarjen</th>";
                echo "<th class='hide'>Športnik</th>";
                echo "<th class='hide'>Kulturnik</th>";
                echo "<th class='hide'>Učitelj</th>";
                echo "<th class='hide'>Vzgojitelj</th>";
                echo "<th class='hide'>Popravi</th>";
            }    
            echo "</tr>";
            while ($R = mysqli_fetch_array($result)){
                $Razred=$oUcenec->getRazred($R["leto"]);
                echo "<tr class='hide'>";
                echo "<td class='hide'>".$Razred["leto"]."/".($Razred["leto"]+1)."</td>";
                echo "<td class='hide'><a href='izpisrazreda.php?solskoleto=".$Razred["leto"]."&razred=".$Razred["idrazred"]."'>".$Razred["razred"].". ". $Razred["paralelka"]."</td>";
                echo "<td class='hide'>".$Razred["uspehpol"]."</td>";
                echo "<td class='hide'>".number_format($Razred["uspeh"],2)."</td>";
                
                if ($Razred["ponavljalec"]==0){
                    echo "<td class='hide'>redni</td>";
                }else{
                    echo "<td class='hide'>ponavlja</td>";
                }
                if ($Razred["razredniizpit"] > 0){
                    echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td class='hide'>&nbsp;</td>";
                }
                echo "<td class='hide'>".$Razred["napredovanje2"]."</td>";
                echo "<td class='hide' align='center'>".$Razred["letosolanja"]."</td>";
                if ($Razred["nadarjen"] > 0){
                    echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td class='hide'>&nbsp;</td>";
                }
                if ($Razred["statussport"] > 0){
                    echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td class='hide'>&nbsp;</td>";
                }
                if ($Razred["statuskult"]){
                    echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td class='hide'>&nbsp;</td>";
                }
                echo "<td class='hide'><a href='izpisucitelja.php?idUcitelj=".$Razred["iducitelj"]."'>".$Razred["razrednik"]."</a></td>";
                if ($Razred["idvzgojitelj"] > 0){
                    echo "<td class='hide'><a href='izpisucitelja.php?idUcitelj=".$Razred["idvzgojitelj"]."'>".$Razred["drugiucitelj"]."</a></td>";
                }else{
                    echo "<td class='hide'>&nbsp;</td>";
                }
                
                /*
                echo "<td class='hide'>".$Razred["ponavljalec"]."</td>";
                echo "<td class='hide'>".$Razred["razredniizpit"]."</td>";
                echo "<td class='hide'>".$Razred["napredovanje2"]."</td>";
                echo "<td class='hide'>".$Razred["letosolanja"]."</td>";
                echo "<td class='hide'>".$Razred["nadarjen"]."</td>";
                echo "<td class='hide'>".$Razred["statussport"]."</td>";
                echo "<td class='hide'>".$Razred["statuskult"]."</td>";
                echo "<td class='hide'><a href='izpisucitelja.php?iducitelj=".$Razred["iducitelj"]."'>".$Razred["razrednik"]."</a></td>";
                echo "<td class='hide'><a href='izpisucitelja.php?iducitelj=".$Razred["idvzgojitelj"]."'>".$Razred["drugiucitelj"]."</a></td>";
                */
                if ($VLevel > 1 ){
                    echo "<td class='hide' align='center'><a href='vnesiocene.php?id=7&razred=".$Razred["idrazred"]."&solskoleto=".$Razred["leto"]."'>P</a></td>";
                }
                echo "</tr>";
            } 
            echo "</table><br />";
        }

        //Izpis predmetnih podatkov
        //Izpis zaključnih ocen - začetek
        echo "<b>Zaključne ocene</b><br />";
        /*
        Dim UcenecZO(250,11)    'predmet,leto
        Dim LetoZO(11)    'leta zaključnih ocen
        Dim PredmetZO(250,1)    'oznaka predmeta
        Dim StLet
        Dim IzpisZO
        Dim i
        */
        $SQL = "SELECT tabocene.leto,tabocene.ocenakoncna,tabpredmeti.id,tabpredmeti.vrstnired,tabpredmeti.oznaka FROM ";
        $SQL = $SQL . "tabocene INNER JOIN tabpredmeti ON tabocene.IdPredmet=TabPredmeti.id ";
        $SQL = $SQL . "WHERE idUcenec=".$ucenec." ORDER BY leto";
        $result = mysqli_query($link,$SQL);

        for ($Indx=0;$Indx <= 11;$Indx++){
            $LetoZO[$Indx]=0;
        }
        for ($i=0;$i <= 250;$i++){
            $PredmetZO[$i][0]=0;
            $PredmetZO[$i][1]="";
        }
        for ($i=0;$i <= 250;$i++){
            for ($j=1;$j <= 50;$j++){
                $UcenecZO[$i][$j]="";
            }
        }  
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if ($LetoZO[$Indx] != $R["leto"] ){
                $Indx=$Indx+1;
                $LetoZO[$Indx]=$R["leto"];
            }
            $PredmetZO[$R["id"]][1]=$R["oznaka"];
            $PredmetZO[$R["id"]][0]=$R["vrstnired"];
            $UcenecZO[$R["id"]][$Indx]=$R["ocenakoncna"];
        }
        $StLet=$Indx;

        echo "<table>";
        echo "<tr class='head'><th class='hide'>Predmet</th>";
        for ($Indx=1;$Indx <= $StLet;$Indx++){
            echo "<th class='hide'>".$LetoZO[$Indx]."/<br />".($LetoZO[$Indx]+1)."</th>";
        }
        echo "</tr>";
        for ($Indx=1;$Indx <= 150;$Indx++){
            for ($i=1;$i <= 250;$i++){
                if ($PredmetZO[$i][0]==$Indx ){
                    $IzpisZo=false;
                    for ($Indx0=1;$Indx0 <= $StLet;$Indx0++){
                        if (strlen($UcenecZO[$i][$Indx0]) > 0){
                            $IzpisZo=true;
                        }
                    }
                    if ($IzpisZo ){
                        echo "<tr class='hide'>";
                        echo "<td class='hide'>".$PredmetZO[$i][1]."</td>";
                        for ($Indx0=1;$Indx0 <= $StLet;$Indx0++){
                            if (strlen($UcenecZO[$i][$Indx0]) > 0){
                                echo "<td class='hide' align='center'>".$UcenecZO[$i][$Indx0]."</td>";
                            }else{
                                echo "<td class='hide'>&nbsp;</td>";
                            }
                        }
                        echo "</tr>";
                    }
                }
            }
        }
        echo "</table><br />";

        //Izpis zaključnih ocen - konec

        //Predmetnik
        $Razred=$oUcenec->getRazred($VLeto);
        if (count($Razred) > 0){
            $SQL = "SELECT tabucenje.*, tabucitelji.priimek, tabucitelji.ime, tabpredmeti.oznaka, tabpredmeti.opis FROM (tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet)  INNER JOIN tabucitelji ON tabucitelji.iducitelj = tabucenje.iducitelj WHERE tabucenje.idrazred=" . $Razred["idrazred"] ."  ORDER BY tabucenje.predmet";
            $result = mysqli_query($link,$SQL);

            echo "<br /><b>Predmetnik</b>";
            echo "<br /><table>";
            echo "<tr class='head'><th class='hide'>Leto</th><th class='hide'>Razred</th><th class='hide'>Predmet</th><th class='hide'>Ure</th><th class='hide'>Posebnosti</th><th class='hide'>Skupina</th><th class='hide'>Učitelj</th></tr>";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VZdruzeno = "";
                if ($R["Zdruzeno"] == 1 ){
                    $VZdruzeno = "Združeni/skupine";
                }    
                if ($R["Zdruzeno"] == 2 ){
                    $VZdruzeno = "Izbirni/skupine";
                }    
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$Razred["razred"].". ". $Razred["paralelka"]."</td><td class='hide'>".$R["oznaka"]." - ".$R["opis"]."</td><td class='hide'>".$R["Planirano"]."</td><td class='hide'>". $VZdruzeno ."</td><td class='hide' align='center'>".$R["Realizirano"]."</td><td class='hide'>".$R["priimek"]." " .$R["ime"]."</td></tr>";
                $Indx = $Indx+1;
            } 
            echo "</table>";
        }
        //Urnik - zacetek

        //'izpis urnika po razredih - 2
        $Obremenitev[1]=0;
        for ($Indx=0;$Indx <= 5;$Indx++){
            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                $UrnikRazred[1][$Indx][$Indx0]="";
            }
        }
        $danurnik=intval($Danes->format('Ymd'));
        if (isset($Razred["razred"])){    
            $SQL = "SELECT taburnik.*,tabucitelji.*,tabpredmeti.*,tabpredmeti.oznaka AS poznaka,tabprostor.* FROM ((taburnik " ;
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor " ;
            $SQL = $SQL . "WHERE taburnik.idRazred=".$Razred["idrazred"]." AND od <= ".$danurnik." AND do >= ".$danurnik." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.DanVTednu,taburnik.Ura";
            //$SQL = $SQL . "WHERE taburnik.idRazred=".$Razred["idrazred"]." AND od <= ".$danurnik." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.DanVTednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["Nivo"]){
                    case 1:
                    case 2:
                    case 3:      //v primeru skupin izpiše še skupino
                        $UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]=$UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["Nivo"]."</font></td><td class='hide'><font color='red'>".$R["Stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["Priimek"],0,3,$encoding).mb_substr($R["Ime"],0,1,$encoding)."</font></td></tr>";
                        break;
                    default:
                        $UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]=$UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["Stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["Priimek"],0,3,$encoding).mb_substr($R["Ime"],0,1,$encoding)."</font></td></tr>";
                }
            }

            //prešteje ure v urniku
            $Indx2=1;
            for ($Indx=0;$Indx <= 5;$Indx++){
                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                    if (strlen($UrnikRazred[$Indx2][$Indx][$Indx0]) > 0){
                        $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                    }
                }
            }

            //'echo "Obremenitev: ".Obremenitev(1)."<br />"

            $Indx=1;
            if ($Obremenitev[$Indx] > 0 ){
                echo "<br /><h2>Urnik (".$VLeto."/".($VLeto+1)."):</h2>";
                echo "<table border='1' cellspacing='0' bgcolor='lightyellow'>";
                echo "<tr bgcolor='cyan'><td><b>".$Razred["razred"].". ".$Razred["paralelka"]."</b></td>";
                echo "<td>".$Obremenitev[$Indx]."</td>";
                for ($Indx2=1;$Indx2 <= 5;$Indx2++){
                    echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
                }
                echo "</tr>";
                $ColorChange=true;
                for ($Indx2=0;$Indx2 <= 12;$Indx2++){
                    $ColorChange=!$ColorChange;
                    if ($ColorChange ){
                        echo "<tr bgcolor='lightyellow'>";
                    }else{
                        echo "<tr bgcolor='#FFFFCC'>";
                    }
                    echo "<td></td><td>".$Indx2."</td>";
                    for ($Indx1=1;$Indx1 <= 5;$Indx1++){
                        if (strlen($UrnikRazred[$Indx][$Indx1][$Indx2]) > 0){
                            echo "<td valign='top'>";
                            echo "<table class='hide'>";
                            echo $UrnikRazred[$Indx][$Indx1][$Indx2];
                            echo "</table>";
                            echo "</td>";
                        }else{
                            echo "<td>&nbsp;</td>";
                        }
                    }
                    echo "</tr>";
                }
            }
            echo "</table>";
        }
        //Urnik - konec

        //izpis izbirnih predmetov
        //inicializacija
        $IzbraniPredmet[0]=0;
        $IzbraniPredmet[1]=0;
        $IzbraniPredmet[2]=0;
        $IzbraniPredmet[3]=0;
        $IzbraniPredmet[4]=0;
        
        $SQL = "SELECT tabizbirni.*,tabizbirni.id AS iid,tabucenci.*,tabpredmeti.*,tabpredmeti.id AS pid FROM (tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni WHERE tabizbirni.Ucenec=" .$ucenec . " ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);
        $IndxIzb=0;
        echo "<br /><b>Izbirni predmeti</b>: ";
        if (isset($Razred["idrazred"])){
            echo "<br /><a href='izbirniskupine.php?id=4&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>Dodaj izbirne predmete</a>";
        }
        echo "<br /><table>";
        echo "<tr class='head'><th class='hide'>Leto</th><th class='hide'>Izbirni predmet</th><th class='hide'>Briši</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            if ($VLevel > 0 ){
                if ($VLeto == $R["Leto"] ){
                    echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td><td class='hide'><a href='izbirniskupine.php?id=8&zapis=".$R["iid"]."&ucenec=".$R["Ucenec"]."'>Briši</a></td></tr>";
                }else{
                    echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";
                }
            }else{
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";        
            }
            if ($R["Leto"]== $VLeto) {
                $IzbraniPredmet[$IndxIzb]=$R["pid"];
                $IndxIzb=$IndxIzb+1;
            }
        } 
        echo "</table>";

        //izpis nivojev in skupin
        echo "<a name='nivoji'>&nbsp;</a><br />";
        echo "<b>Nivojski predmeti/skupine</b>: ";
        if (isset($Razred["idrazred"])){
            echo "<br /><a href='izbirniskupine.php?id=11&razred=".$Razred["idrazred"]."'>Dodaj nivojske predmete</a>";
        }
        $SQL = "SELECT tabnivoji.*,tabnivoji.leto AS nleto,tabucenci.*,tabrazred.*,tabrazred.leto AS rleto FROM ";
        $SQL = $SQL . "((tabnivoji INNER JOIN tabucenci ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabnivoji.Ucenec) ";
        $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." AND tabnivoji.leto = tabrazred.leto ";
        $SQL = $SQL . " ORDER BY tabnivoji.leto DESC,nivoji";
        $result = mysqli_query($link,$SQL);

        echo "<table>";
        echo "<tr class='head'><th class='hide'>N</th><th class='hide'>Leto</th><th class='hide'>Ucenec</th><th class='hide'>Predmet 1</th><th class='hide'>Predmet 2</th><th class='hide'>Predmet 3</th></tr>";
        echo "<tr class='hide'>";

        $UcenecIzbirni="";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($UcenecIzbirni == $R["nleto"]){
                echo "<td class='hide' align='center'>".ToNivojski($R["Nivoji"])."</td>";
            }else{
                if ($UcenecIzbirni != "" ){
                    echo "</tr>";
                }
                echo "<tr class='hide'><td class='hide' align='center'>".$Indx."</td>";
                $Indx=$Indx+1;
                echo "<td class='hide'>".$R["rleto"]."/".($R["rleto"]+1)."</td><td class='hide'>".$R["Priimek"]." ".$R["Ime"].", ".$R["Razred"].". ".$R["Paralelka"]."</td><td class='hide' align='center'>".ToNivojski($R["Nivoji"])."</td>";
                $UcenecIzbirni = $R["nleto"];
            }
        }

        echo "</table>";

        //vzgojni ukrepi
        $SQL = "SELECT tabvzgukrepi.*, tabopomini.Opis FROM tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep WHERE tabvzgukrepi.IdUcenec=" .$ucenec . " AND tabvzgukrepi.leto=".$VLeto." ORDER BY tabvzgukrepi.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br /><b>Vzgojni ukrepi</b>: ";
        $_SESSION["iducenec"]=$ucenec;
        $_SESSION["leto"]=$VLeto;
        if ($VLevel > 0 ){
            echo "<br /><a href='izborucenca.php?idd=200&ucenec=".$ucenec."'>Dodaj vzgojni ukrep</a>";
        }
        echo "<br /><table>";
        echo "<tr class='head'><th class='hide'>Leto</th><th class='hide'>Ukrep</th><th class='hide'>Datum izreka</th><th class='hide'>Datum</th><th class='hide'>Obrazec</th></tr>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if ($VLevel > 1 ){
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Opis"]."</td><td class='hide'>".$R["DatIzreka"]."</td><td class='hide'>".$R["Datum"]."</td><td class='hide'><a href='izborucenca.php?idd=270&id=".$R["Id"]."'>Obrazec</a></td><td class='hide'><a href='izborucenca.php?idd=260&id=".$R["Id"]."'>Briši</a></td></tr>";
            }else{
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Opis"]."</td><td class='hide'>".$R["DatIzreka"]."</td><td class='hide'>".$R["Datum"]."</td><td class='hide'><a href='izborucenca.php?idd=270&id=".$R["Id"]."'>Obrazec</a></td></tr>";
            }
            $Indx = $Indx+1;
        } 
        echo "</table>";

        //'učenčeve aktivnosti (interesne dejavnosti, športna tekmovanja)
        $SQL = "SELECT tabdrtekmclan.*, tabucenci.* FROM tabdrtekmclan ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec ";
        $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." ";
        $SQL = $SQL . " ORDER BY tabdrtekmclan.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br /><b>Tekmovanja iz znanja</b>:<br />";
        echo "<table>";
        echo "<tr class='head'><th class='hide'>šolsko<br />leto</th><th class='hide'>tekmovanje</th><th class='hide'>datum</th><th class='hide'>stopnja</th><th class='hide'>priznanje</th><th class='hide'>mentor</th></tr>";
        while ($R = mysqli_fetch_array($result)){    
            echo "<tr class='hide'>";
            echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
            echo "<td class='hide'>".$R["tekmovanje"]."</td>";
            echo "<td class='hide'>".$R["datum"]."</td>";
            echo "<td class='hide'>".$R["stopnja"]."</td>";
            echo "<td class='hide'>".$R["priznanje"]."</td>";
            echo "<td class='hide'>".$R["mentor1"]."</td>";
            echo "</tr>";
        }
        echo "</table>";

        $SQL = "SELECT tabsstclan.*, tabucenci.* FROM tabsstclan ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabsstclan.idUcenec=tabucenci.idUcenec ";
        $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." ";
        $SQL = $SQL . " ORDER BY tabsstclan.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br /><b>Šolska športna tekmovanja</b>:<br />";
        echo "<table>";
        echo "<tr class='head'><th class='hide'>šolsko<br />leto</th><th class='hide'>tekmovanje</th><th class='hide'>datum</th><th class='hide'>stopnja</th><th class='hide'>priznanje</th><th class='hide'>mentor</th></tr>";
        while ($R = mysqli_fetch_array($result)){    
            echo "<tr class='hide'>";
            echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
            echo "<td class='hide'>".$R["tekmovanje"]."</td>";
            echo "<td class='hide'>".$R["datum"]."</td>";
            echo "<td class='hide'>".$R["stopnja"]."</td>";
            echo "<td class='hide'>".$R["priznanje"]."</td>";
            echo "<td class='hide'>".$R["mentor1"]."</td>";
            echo "</tr>";
        }
        echo "</table>";

        //'interesne dejavnosti
        $SQL = "SELECT tabkrozekclan.*,tabkrozekclan.leto AS cleto, tabkrozki.*,tabkrozki.krozek AS kkrozek, tabucenci.* FROM (tabkrozekclan ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabkrozekclan.Ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
        $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." ";
        $SQL = $SQL . "ORDER BY tabkrozki.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br /><b>Interesne dejavnosti</b>:<br />";
        echo "<table>";
        echo "<tr class='head'><th class='hide'>šolsko leto</th><th class='hide'>dejavnost</th><th class='hide'>mentor</th></tr>";
        while ($R = mysqli_fetch_array($result)){    
            echo "<tr class='hide'>";
            echo "<td class='hide'>".$R["cleto"]."/".($R["cleto"]+1)."</td>";
            echo "<td class='hide'>".$R["kkrozek"]."</td>";
            echo "<td class='hide'>".$R["mentor"]."</td>";
            echo "</tr>";
        }
        echo "</table><br />";
        
        //tehniški, kulturni in naravoslovni dnevi
        $SQL = "SELECT razred,idrazred FROM tabrazred WHERE iducenec=".$ucenec." ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);
        $razred="";
        while ($R = mysqli_fetch_array($result)){
            if (strlen($razred) > 0){
                $razred .= ",".$R["idrazred"];
            }else{
                $razred .= $R["idrazred"];
            }
        }
        if (strlen($razred) > 0){
            echo "<table class='klasika'>";
            echo "<tr class='head'><th class='klasika'>Leto</th><th class='klasika'>Razred</th><th class='klasika'>Kulturni dnevi</th><th class='klasika'>Naravoslovni dnevi</th><th class='klasika'>Tehniški dnevi</th><th class='klasika'>Drugo</th></tr>";
            $SQL = "SELECT leto,razred,paralelka,idaktivnost,datum,kraj,vsebina FROM tabostaledej WHERE idrazred IN ($razred) ORDER BY leto DESC,idaktivnost";
            $result = mysqli_query($link,$SQL);
            $kd="";
            $nd="";
            $td="";
            $dd="";
            $r=0;
            while ($R = mysqli_fetch_array($result)){
                if ($r != $R["leto"]){
                    $r=$R["leto"];
                    if ($r > 0){
                        $kd .= "</td>";
                        $nd .= "</td>";
                        $td .= "</td>";
                        $dd .= "</td>";
                        echo $kd;
                        echo $nd;
                        echo $td;
                        echo $dd;
                        echo "</tr>";
                        echo "<tr class='klasika'>";
                    }else{
                        echo "<tr class='klasika'>";
                    }
                    echo "<td class='klasika'>".$R["leto"]."</td>";
                    echo "<td class='klasika'>".$R["razred"].". ".$R["paralelka"]."</td>";
                    $kd = "<td class='klasika'>";
                    $nd = "<td class='klasika'>";
                    $td = "<td class='klasika'>";
                    $dd = "<td class='klasika'>";
                }
                switch (intval($R["idaktivnost"])){
                    case 1:
                        if (isset($R["vsebina"])){
                            $kd .= $R["datum"]." ".$R["kraj"].": ".$R["vsebina"]."<br />";
                        }else{
                            $kd .= $R["datum"]." ".$R["kraj"]."<br />";
                        }
                        break;
                    case 2:
                        if (isset($R["vsebina"])){
                            $nd .= $R["datum"]." ".$R["kraj"].": ".$R["vsebina"]."<br />";
                        }else{
                            $nd .= $R["datum"]." ".$R["kraj"]."<br />";
                        }
                        break;
                    case 3:
                        if (isset($R["vsebina"])){
                            $td .= $R["datum"]." ".$R["kraj"].": ".$R["vsebina"]."<br />";
                        }else{
                            $td .= $R["datum"]." ".$R["kraj"]."<br />";
                        }
                        break;
                    case 5:
                        if (isset($R["vsebina"])){
                            $dd .= $R["datum"]." ".$R["kraj"].": ".$R["vsebina"]."<br />";
                        }else{
                            $dd .= $R["datum"]." ".$R["kraj"]."<br />";
                        }
                        break;
                }
            }
            echo "</table><br />";
        }
            
        //'odsotnosti    
        if ($eDnevnik==1 ){
            /*
            Dim MesecDni(12)
            Dim $VLetoPregled
            Dim Praznik(200,2)
            Dim PreveriPraznik
            Dim Datum
            Dim StPraznikov
            */
            $SQL = "SELECT * FROM tabpraznik WHERE leto IN (".$VLeto.",".($VLeto+1).") ORDER BY datum";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                $Praznik[$Indx][1]=$R["kat"];
                $Indx=$Indx+1;
            }
            $StPraznikov=$Indx-1;
            
            if (($VLeto+1) % 4 == 0 ) {
                $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
            }else{
                $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
            }

            echo "<b>Koledar izostankov in opomb</b><br />";
            echo "<table class='klasika'>";
            echo "<tr class='head'><th class='klasika'></th>";
            for ($Indx=1;$Indx <= 31;$Indx++){
                echo "<th class='klasika' width='25'>".$Indx."</th>";
            }
            echo "</tr>";
            for ($Indx=9;$Indx <= 12;$Indx++){
                $VLetoPregled=$VLeto;
                echo "<tr class='klasika'><td class='klasika' align='left'><b>".MonthName($Indx)."</b></td>";
                for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                    $Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
                    switch ($Datum->format('w')){
                        case 0:
                        case 6:
                        case 7: //'vikend
                            $PreveriPraznik=CheckPraznik($Datum);
                            switch ($PreveriPraznik){
                                case 3: //'delovna sobota
                                    echo "<td class='klasika' align='right'>";
                                    break;
                                default:
                                    echo "<td class='klasika' bgcolor='lightsalmon' align='right'>";
                            }
                            break;
                        default: // 'delovnik
                            $PreveriPraznik=CheckPraznik($Datum);
                            switch ($PreveriPraznik){
                                case 4: // 'dela prost dan
                                    echo "<td class='klasika' bgcolor='khaki' align='right'>";
                                    break;
                                case 0: // 'delovni dan
                                    echo "<td class='klasika' align='right'>";
                                    break;
                                case 2: //počitnice
                                    echo "<td class='klasika' bgcolor='lightblue' align='right'>";
                                    break;
                                case 1: // 'praznik
                                    echo "<td class='klasika' bgcolor='lightgreen' align='right'>";
                            }
                    }
                    $SQL = "SELECT * FROM tabodsotnostuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<a href='dnevnik.php?idd=200&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Iz</a>";
                    }

                    $SQL = "SELECT * FROM tabopombeuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "&nbsp;<a href='dnevnik.php?idd=300&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Op</a>";
                    }
                    echo "</td>";
                }
                echo "</tr>";
            }
            for ($Indx=1;$Indx <= 6;$Indx++){
                $VLetoPregled=$VLeto+1;
                echo "<tr><td align='left'><b>".MonthName($Indx)."</b></td>";
                for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                    $Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
                    switch ($Datum->format('w')){
                        case 0:
                        case 6:
                        case 7: //'vikend
                            $PreveriPraznik=CheckPraznik($Datum);
                            switch ($PreveriPraznik){
                                case 3: //'delovna sobota
                                    echo "<td class='klasika' align='right'>";
                                    break;
                                default:
                                    echo "<td class='klasika' bgcolor='lightsalmon' align='right'>";
                            }
                            break;
                        default: // 'delovnik
                            $PreveriPraznik=CheckPraznik($Datum);
                            switch ($PreveriPraznik){
                                case 4: // 'dela prost dan
                                    echo "<td class='klasika' bgcolor='khaki' align='right'>";
                                    break;
                                case 0: // 'delovni dan
                                    echo "<td class='klasika' align='right'>";
                                    break;
                                case 2: //počitnice
                                    echo "<td class='klasika' bgcolor='lightblue' align='right'>";
                                    break;
                                case 1: // 'praznik
                                    echo "<td class='klasika' bgcolor='lightgreen' align='right'>";
                            }
                    }
                    $SQL = "SELECT * FROM tabodsotnostuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<a href='dnevnik.php?idd=200&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Iz</a>";
                    }

                    $SQL = "SELECT * FROM tabopombeuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "&nbsp;<a href='dnevnik.php?idd=300&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Op</a>";
                    }
                    echo "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
            echo "<a href='dnevnik.php?idd=200&ucenec=".$ucenec."'>Vpis izostankov</a> <a href='dnevnik.php?idd=300&ucenec=".$ucenec."'>Vpis opomb</a><br />";
        }

        //izostanki po mesecih
        $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto." AND mesec > 8 ORDER BY leto,mesec";
        //$SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto." ORDER BY leto,mesec DESC";
        $result = mysqli_query($link,$SQL);
        
        for ($Indx=0;$Indx <= 10;$Indx++){
            $Izostanki[$Indx][0]=0;
            $Izostanki[$Indx][1]=0;
        }

        echo "<br /><b>Odsotnost</b>: ";
        if ($VLevel > 0 ){
            echo "<br /><a href='izborrazreda.php?id=odsotnost&razred=".$VRazred."'>Dodaj odsotnost</a>";
        }
        echo "<br /><table>";
        echo "<tr class='head'><th class='hide'>Šol. leto</th><th class='hide'>Mesec</th><th class='hide'>Opravičeno</th><th class='hide'>Neopravičeno</th></tr>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
            echo "<td class='hide' align=center>".$R["Mesec"]."</td>";
            echo "<td class='hide' align=center>".$R["Opraviceno"]."</td>";
            echo "<td class='hide' align=center>".$R["Neopraviceno"]."</td></tr>";
            if ($R["Mesec"] > 0 ){
                $Izostanki[0][0]=$Izostanki[0][0]+$R["Opraviceno"];
                $Izostanki[0][1]=$Izostanki[0][1]+$R["Neopraviceno"];
            }
            $Indx = $Indx+1;
        } 
        $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto." AND mesec < 8 ORDER BY leto,mesec";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
            echo "<td class='hide' align=center>".$R["Mesec"]."</td>";
            echo "<td class='hide' align=center>".$R["Opraviceno"]."</td>";
            echo "<td class='hide' align=center>".$R["Neopraviceno"]."</td></tr>";
            if ($R["Mesec"] > 0 ){
                $Izostanki[0][0]=$Izostanki[0][0]+$R["Opraviceno"];
                $Izostanki[0][1]=$Izostanki[0][1]+$R["Neopraviceno"];
            }
            $Indx = $Indx+1;
        } 
        echo "<tr class='hide'><td class='hide'>Skupaj</td><td class='hide'>&nbsp;</td><td class='hide' align=center>".$Izostanki[0][0]."</td><td class='hide' align=center>".$Izostanki[0][1]."</td></tr>";
        echo "</table>";

    //Izpis redovalnice
        $Indx1=0;
        if (isset($Razred["razred"])){
            if ($Razred["razred"] > 0){
                //inicializacija predmetov
                for ($i=0;$i <= 50;$i++){
                    $Predmeti[$i][0]=0;
                    $Predmeti[$i][1]="";
                }
                
                $SQL = "SELECT DISTINCT tabpredmeti.*,tabucenje.predmet,tabucenje.razred,tabucenje.paralelka,tabucenje.leto FROM tabpredmeti ";
                $SQL = $SQL . "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet ";
                $SQL = $SQL . "WHERE tabpredmeti.Prioriteta < 3 AND tabucenje.idRazred=" . $Razred["idrazred"]; 
                $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    if (($R["Prioriteta"]==0) or ($R["Prioriteta"]==2) ){
                        $Predmeti[$Indx][0]=$R["Id"];
                        $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                        $Indx=$Indx+1;
                    }else{
                        if ($R["Id"]==$IzbraniPredmet[0] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[1] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[2] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[3] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[4] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                    }
                }
                $Predmetov=$Indx;
                    
                $SQL = "SELECT tabocene.*,tabocene.id AS oid, tabpredmeti.Id AS pid,tabpredmeti.Oznaka, tabpredmeti.Opis FROM tabpredmeti ";
                $SQL = $SQL . "INNER JOIN tabocene ON tabocene.IdPredmet = tabpredmeti.Id ";
                $SQL = $SQL . "WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                    
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    for ($Indx1=0;$Indx1 <= 50;$Indx1++){
                        if ($R["pid"]==$Predmeti[$Indx1][0]){
                            $OcenePredmeta[$Indx1][0]=$R["Leto"];
                            $OcenePredmeta[$Indx1][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $OcenePredmeta[$Indx1][2]="&nbsp;".$R["OcenaS1P"];
                            $OcenePredmeta[$Indx1][3]="&nbsp;".$R["OcenaS1U"];
                            $OcenePredmeta[$Indx1][4]="&nbsp;".$R["OcenaS2P"];
                            $OcenePredmeta[$Indx1][5]="&nbsp;".$R["OcenaS2U"];
                            $OcenePredmeta[$Indx1][11]="&nbsp;".$R["OcenaPolletna"];
                            $OcenePredmeta[$Indx1][6]="&nbsp;".$R["OcenaKoncna"];
                            $OcenePredmeta[$Indx1][7]=$R["Neocenjen"];
                            $OcenePredmeta[$Indx1][8]=$R["Popravni"];
                            $OcenePredmeta[$Indx1][9]=$R["Datum"];
                            $OcenePredmeta[$Indx1][10]=$R["oid"];
                        }
                    }
                    $Indx = $Indx+1;
                } 
                
                echo "<a name='redovalnica'>&nbsp;</a>";
                echo "<h2><a href='vnesiocene.php?id=1&iducenec=".$ucenec."&solskoleto=".$VLeto."&razred=".$Razred["idrazred"]."'>Vnos vseh ocen</a></h2>";
                echo "<h2><a href='vnesiocene.php?id=3&iducenec=".$ucenec."&solskoleto=".$VLeto."&razred=".$Razred["idrazred"]."'>Vnos spričevala</a></h2>";
                echo "<table>";
                echo "<tr class='head'><th class='hide'>Leto</th><th class='hide'>Predmet</th><th class='hide'>Pisne ocene</th><th class='hide'>Ustne ocene</th><th class='hide'>Polletno</th><th class='hide'>Zaključeno</th><th class='hide'>Ocenjen</th><th class='hide'>Popravni</th><th class='hide'>Datum</th><th class='hide'>Popravi</th></tr>";

                for ($Indx=0;$Indx < $Predmetov;$Indx++){
                    if (!isset($OcenePredmeta[$Indx][0])){
                        echo "<tr class='hide'>";
                        echo " <td class='hide'>".$VLeto."/".($VLeto+1)."</td>";
                        echo " <td class='hide'><a href='vnesiocene.php?id=5&predmet=".$Predmeti[$Indx][0]."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>".$Predmeti[$Indx][1]."</a></td>";
                        echo " <td class='hide'>";
                        echo "  <table class='trans' width='70'>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans'></td>";
                        echo "   </tr>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans'></td>";
                        echo "   </tr>";
                        echo "  </table>";
                        echo " </td>";
                        echo " <td class='hide'>";
                        echo "  <table class='trans' width='70'>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans'></td>";
                        echo "   </tr>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans'></td>";
                        echo "   </tr>";
                        echo "  </table>";
                        echo " </td>";
                        echo " <td class='hide'></td>";
                        echo " <td class='hide'></td>";
                        echo " <td class='hide'></td>";
                        echo " <td class='hide'></td>";
                        echo " <td class='hide'></td>";
                        if ($VLevel > 0){
                            if (($Prijavljeni==$Razred["iducitelj"]) or ($VLevel > 0) ){
                                echo "<td class='hide' align='center'><a href='vnesiocene.php?id=9&predmet=".$Predmeti[$Indx][0]."&solskoleto=".$VLeto."&razred=".$Razred["idrazred"]."'>P</a></td></tr>";
                            }else{
                                echo "<td class='hide'></td></tr>";
                            }
                        }
                    }else{
                        echo "<tr class='hide'>";
                        echo " <td class='hide'>".$OcenePredmeta[$Indx][0]."/".($OcenePredmeta[$Indx][0]+1)."</td>";
                        echo " <td class='hide'><a href='vnesiocene.php?id=5&predmet=".$Predmeti[$Indx][0]."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>".$OcenePredmeta[$Indx][1]."</a></td>";
                        echo " <td class='hide'>";
                        echo "  <table class='trans' cellspacing=0 width='70'>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans' width='70'><font color='blue'>".$OcenePredmeta[$Indx][2]."</font></td>";
                        echo "   </tr>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans' width='70'><font color='blue'>".$OcenePredmeta[$Indx][4]."</font></td>";
                        echo "   </tr>";
                        echo "  </table>";
                        echo " </td>";
                        echo " <td class='hide'>";
                        echo "  <table class='trans' cellspacing=0 width='70'>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans' width='70'><font color='magenta'>".$OcenePredmeta[$Indx][3]."</font></td>";
                        echo "   </tr>";
                        echo "   <tr class='trans'>";
                        echo "    <td class='trans' width='70'><font color='magenta'>".$OcenePredmeta[$Indx][5]."</font></td>";
                        echo "   </tr>";
                        echo "  </table>";
                        echo " </td>";
                        echo " <td class='hide' align='center'><font color='green'>".$OcenePredmeta[$Indx][11]."</font></td>";
                        echo " <td class='hide' align='center'><font color='red'>".$OcenePredmeta[$Indx][6]."</font></td>";
                        switch (intval($OcenePredmeta[$Indx][7])){
                            case 0: //ocenjeno
                                echo " <td class='hide' align='center'>&nbsp;</td>";
                                break;
                            case 1: //neocenjeno
                                echo " <td class='hide' align='center'>neocenjeno</td>";
                                break;
                            case 2: //opravičeno
                                echo " <td class='hide' align='center'>opravičeno</td>";
                                break;
                        }
                        if ($OcenePredmeta[$Indx][8] > 0){
                            echo " <td class='hide' align='center'>popravni</td>";
                        }else{
                            echo " <td class='hide' align='center'>&nbsp;</td>";
                        }
                        /*
                        echo " <td class='hide'>".$OcenePredmeta[$Indx][7]."</td>";
                        echo " <td class='hide'>".$OcenePredmeta[$Indx][8]."</td>";
                        */
                        echo " <td class='hide'>".$OcenePredmeta[$Indx][9]."</td>";
                        if ($VLevel > 0){
                            if (($Prijavljeni=$Razred["iducitelj"]) or ($VLevel > 0) ){
                                echo "<td class='hide' align='center'><a href='vnesiocene.php?id=5&predmet=".$Predmeti[$Indx][0]."&solskoleto=".$VLeto."&razred=".$Razred["idrazred"]."'>P</a></td></tr>";
                            }else{
                                echo "<td class='hide'>&nbsp;</td></tr>";
                            }
                        }
                    }
                }
                echo "</table>";

                if ($Razred["razred"] < 3 ){
                    $SQL = "SELECT tabopocene.*,tabopznanje.*,tabopcilji.*,tabpredmeti.*,tabpredmeti.id AS pid FROM ((tabopocene ";
                    $SQL = $SQL . "INNER JOIN tabopznanje ON tabopocene.OpOcena=tabopznanje.IdZnanje) ";
                    $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopcilji.Predmet=tabpredmeti.Id ";
                    $SQL = $SQL . "WHERE leto=".$Razred["leto"]." AND tabopcilji.Razred=".$Razred["razred"]." AND tabopocene.IdUcenec=".$ucenec." ";
                    $SQL = $SQL . "ORDER BY tabopocene.Tip,tabopcilji.Predmet,tabopznanje.IdCilji,tabopznanje.IdZnanje";
                    $result = mysqli_query($link,$SQL);
                    
                    echo "<br /><table border='1'>";
                    echo "<th>Tip</th><th>Leto</th><th>Predmet</th><th>Tema</th><th>Znanje</th>";
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".ToTip($R["Tip"])."</td>";
                        echo "<td>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                        echo "<td><a href='vpisopocen.php?razred=".$Razred["idrazred"]."&paralelka=".$Razred["paralelka"]."&predmet=".$R["pid"]."&tip=".$R["Tip"]."&submit=redovalnica'>".$R["Oznaka"]." - ".$R["Opis"]."</a></td>";
                        echo "<td>".$R["OpisCilja"]."</td>";
                        echo "<td>".$R["OpisZnanja"]."</td>";
                        echo "</tr>";
                    }
                    echo "</table><br />";
                }
                
                if ($VLevel > 0 ){
                    //echo "<a href='zapisnikizpitovpdf.php?id=".$ucenec."' target='new_win'>Zapisnik o izpitih</a><br />";
                    echo "<a href='obvestilaouspehu.php?id=19&ucenec=".$ucenec."' target='new_win'>Zapisnik o izpitih</a><br />";
                    echo "<a href='obvestilaouspehu.php?id=1&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>Obvestilo o uspehu za 1. ocenjevalno obdobje (PDF)</a><br />";
                    echo "<h3><a href='obvestilaouspehu.php?id=5&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>Izpisek iz redovalnice (PDF)</a></h3>";
                    if ($Razred["razred"] >= 3 ){
        //                echo "<a href='spricevalo".$VLeto.".php?id=".$ucenec."'>Spričevalo za ŠL ".$VLeto."/".($VLeto+1)." (PDF)</a><br />";
                        echo "<a href='obvestilaouspehu.php?id=21&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."&predogled=0'>Aktualno spričevalo (PDF)</a> (<a href='obvestilaouspehu.php?id=21&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."&predogled=1'>Predogled</a>)<br />";
                        //echo "<a href='izpisizevidence".$VLeto.".php?id=".$ucenec."'>Izpis iz evidence za ŠL ".$VLeto."/".($VLeto+1)." (PDF)</a><br />";
                        echo "<a href='obvestilaouspehu.php?id=23&ucenec=".$ucenec."&razred=".$Razred["idrazred"]."&solskoleto=".$VLeto."'>Obvestilo o zaključnih ocenah (PDF)</a><br />";
                        echo "<a href='KorekcijaTiska.php'>Korekcija tiskanja na obrazce</a><br />";
                    }
                    echo "<a href='izpisredovalnice.php?id=4&solskoleto=".$Razred["leto"]."&razred=".$Razred["idrazred"]."'>Razredna redovalnica</a><br />";
                    echo "<a href='izpisredovalnice.php'>Na izbor redovalnice</a><br />";
                }
            }
        }
    }    
}
?>

</body>
</html>
