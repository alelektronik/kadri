<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis potrjevalcev
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("DelKontr",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }
        $VLetoPregled=$Danes->format('Y');

        echo "Leto: <a href='IzpisPotrjevalcev.php?leto=".($VLeto-1)."'>".($VLeto-1)."</a> | ".$VLeto." | <a href='IzpisPotrjevalcev.php?leto=".($VLeto+1)."'>".($VLeto+1)."</a><br />";

        if (isset($_GET["potrdil"])){
            $potrdil=$_GET["potrdil"];
        }else{
            $potrdil="";
        }

        switch ($potrdil){
	        case "":
		        $SQL = "SELECT Leto,Mesec,Potrdil,Count(Potrdil) AS CountPotrdil FROM tabpregleddelan GROUP BY leto,mesec,potrdil HAVING leto=".$VLeto;
		        $SQL = $SQL ." ORDER BY leto,mesec,potrdil";
		        $result = mysqli_query($link,$SQL);

		        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
		        echo "<tr bgcolor='cyan'><th>leto</th><th>mesec</th><th>potrdil</th><th>število</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        if (isset($R["Potrdil"])){
				        echo "<tr>";
				        echo "<td>".$R["Leto"]."</td>";
				        echo "<td align=center>".$R["Mesec"]."</td>";
				        echo "<td align=right><a href='IzpisPotrjevalcev.php?potrdil=".$R["Potrdil"]."&leto=".$R["Leto"]."&mesec=".$R["Mesec"]."'>".$R["Potrdil"]."</a></td>";
				        echo "<td align=right>".$R["CountPotrdil"]."</td>";
				        echo "</tr>";
			        }
			        $Indx=$Indx+1;
		        }
		        echo "</table><br>";

		        $SQL = "SELECT Leto,Mesec,EnotPotrjeno,Count(EnotPotrjeno) AS CountPotrdil FROM tabpregleddelan GROUP BY leto,mesec,enotPotrjeno HAVING leto=".$VLeto;
		        $SQL = $SQL ." ORDER BY leto,mesec";
		        $result = mysqli_query($link,$SQL);

		        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
		        echo "<tr bgcolor='cyan'><th>leto</th><th>mesec</th><th>stanje</th><th>?tevilo</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        echo "<tr>";
			        echo "<td>".$R["Leto"]."</td>";
			        echo "<td align=center>".$R["Mesec"]."</td>";
			        if ($R["EnotPotrjeno"] ){
				        echo "<td align=right><a href='IzpisPotrjevalcev.php?potrdil=os&potrjeno=1&leto=".$R["Leto"]."&mesec=".$R["Mesec"]."'>Potrjeno</a></td>";
			        }else{
				        echo "<td align=right><a href='IzpisPotrjevalcev.php?potrdil=os&potrjeno=0&leto=".$R["Leto"]."&mesec=".$R["Mesec"]."'>Nepotrjeno</a></td>";
			        }
			        echo "<td align=right>".$R["CountPotrdil"]."</td>";
			        echo "</tr>";
			        $Indx=$Indx+1;
		        }
		        echo "</table><br />";
                break;
	        case "os":
		        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.*,tabucitelji.*,tabpregleddelan.Komentar AS pkomentar,tabpregleddelan.id AS pid FROM ";
		        $SQL = $SQL . "(tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos) ";
		        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.Ucitelj=tabucitelji.idUcitelj ";
                if (isset($_GET["potrjeno"])){
                    $potrjeno=$_GET["potrjeno"];
                }else{
                    $potrjeno="0";
                }
		        if ($potrjeno=="0"){
			        $SQL = $SQL . "WHERE tabpregleddelan.leto=".$_GET["leto"]." AND tabpregleddelan.mesec=".$_GET["mesec"]." AND EnotPotrjeno=false";
		        }else{
			        $SQL = $SQL . "WHERE tabpregleddelan.leto=".$_GET["leto"]." AND tabpregleddelan.mesec=".$_GET["mesec"]." AND EnotPotrjeno=true";
		        }
		        $SQL = $SQL ." ORDER BY datum DESC";
		        $result = mysqli_query($link,$SQL);
		        
		        echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.php'>";
		        echo "<input name='submit' type='submit' value='Briši'><br>";
		        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
		        echo "<tr bgcolor='cyan'><th>Št.</th><th>Ime</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        switch ($R["aktivno"]){
				        case 1:
					        if ($R["EnotPotrjeno"] ){
						        if ($R["Rubrika"]==28 ){
							        echo "<tr bgcolor='red'>";
						        }else{
							        echo "<tr bgcolor='lightgreen'>";
						        }
					        }else{
						        if ($R["Rubrika"]==28 ){
							        echo "<tr bgcolor='red'>";
						        }else{
							        echo "<tr bgcolor='lightyellow'>";
						        }
					        }
                            break;
				        default:
					        if ($R["Rubrika"]==28 ){
						        echo "<tr bgcolor='red'>";
					        }else{
						        echo "<tr bgcolor='lightcyan'>";
					        }
			        }
			        echo "<td>".$Indx."</td>";
			        echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime(isDate($R["Datum"]));
			        echo "<td>".$Datum->format('d.m.Y')."</td>";
			        echo "<td>".$R["OblikaDela"]."</td>";
			        if ($R["uramin"] > 1 ){
				        echo "<td>".$R["Enot"]." min</td>";
			        }else{
				        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
					        echo "<td>".$R["Enot"]." dni</td>";
				        }else{
					        echo "<td>".$R["Enot"]." ur</td>";
				        }
			        }
			        echo "<td>".$R["pkomentar"]."</td>";
			        if ($R["EnotPotrjeno"]) {
				        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["Ucitelj"]."'>da</a></td>";
			        }else{
				        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=1&Ucitelj=".$R["Ucitelj"]."'>ne</a></td>";
			        }
			        echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."'>Popravi</a></td>";
			        $Ucitelj=$R["Ucitelj"];
			        echo "<td><input name='id' value='".$R["pid"]."' type='checkbox'></td>";
			        echo "</tr>";
			        $Indx=$Indx+1;
		        }
		        echo "</table><br />";
		        echo "<input name='idUcitelj' type='hidden' value='".$Ucitelj."'>";
		        echo "<input name='submit' type='submit' value='Briši'>";
		        echo "</form><br />";
                break;
	        default:
		        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.*,tabucitelji.*,tabpregleddelan.Komentar AS pkomentar,tabpregleddelan.id AS pid FROM ";
		        $SQL = $SQL . "(tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos) ";
		        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.Ucitelj=tabucitelji.idUcitelj ";
		        $SQL = $SQL . "WHERE (tabpregleddelan.leto=".$_GET["leto"].") AND (tabpregleddelan.mesec=".$_GET["mesec"].") AND (potrdil='".$_GET["potrdil"]."') AND (EnotPotrjeno=true)";
		        $SQL = $SQL ." ORDER BY datum DESC";
		        $result = mysqli_query($link,$SQL);;
		        
		        echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.php'>";
		        echo "<input name='submit' type='submit' value='Briši'><br />";
		        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
		        echo "<tr bgcolor='cyan'><th>Št.</th><th>Ime</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        switch ($R["aktivno"]){
				        case 1:
					        if ($R["EnotPotrjeno"] ){
						        if ($R["Rubrika"]==28 ){
							        echo "<tr bgcolor='red'>";
						        }else{
							        echo "<tr bgcolor='lightgreen'>";
						        }
					        }else{
						        if ($R["Rubrika"]==28 ){
							        echo "<tr bgcolor='red'>";
						        }else{
							        echo "<tr bgcolor='lightyellow'>";
						        }
					        }
                            break;
				        default:
						        if ($R["Rubrika"]==28 ){
							        echo "<tr bgcolor='red'>";
						        }else{
							        echo "<tr bgcolor='lightcyan'>";
						        }
			        }
			        echo "<td>".$Indx."</td>";
			        echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime(isDate($R["Datum"]));
			        echo "<td>".$Datum->format('d.m.Y')."</td>";
			        echo "<td>".$R["OblikaDela"]."</td>";
			        if ($R["uramin"] > 1 ){
				        echo "<td>".$R["Enot"]." min</td>";
			        }else{
				        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
					        echo "<td>".$R["Enot"]." dni</td>";
				        }else{
					        echo "<td>".$R["Enot"]." ur</td>";
				        }
			        }
			        echo "<td>".$R["pkomentar"]."</td>";
			        if ($R["EnotPotrjeno"] ){
				        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["Ucitelj"]."'>da</a></td>";
			        }else{
				        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=1&Ucitelj=".$R["Ucitelj"]."'>ne</a></td>";
			        }
			        echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"].".idUcitelj=".$R["Ucitelj"]."'>Popravi</a></td>";
			        echo "<td><input name='id' value='".$R["pid"]."' type='checkbox'></td>";
			        echo "</tr>";
			        $Ucitelj=$R["Ucitelj"];
			        $Indx=$Indx+1;
		        }
		        echo "</table><br />";
		        echo "<input name='idUcitelj' type='hidden' value='".$Ucitelj."'>";
		        echo "<input name='submit' type='submit' value='Briši'>";
		        echo "</form><br />";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
