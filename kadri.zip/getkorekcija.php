<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<?php

if (isset($_GET["klasif"])){
    $Isci=$_GET["klasif"];
    
    $SQL = "SELECT stvloge FROM tabdelovodnik WHERE stvloge LIKE '".$Isci."-%' ORDER BY id";
    $result = mysqli_query($link,$SQL);
    $i=1;
    if (mysqli_num_rows($result) > 0){
        $i = mysqli_num_rows($result);
    }
    echo "Ref. št. (spremenljivi del): <input id='RefStVar' name='RefStVar' type='text' size='5' value='". $i ."'>";
}
mysqli_close($link);
?>
