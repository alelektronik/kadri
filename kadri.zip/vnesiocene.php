<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Ocene
</title>
<style>
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VIdRazrednik=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    function ClearBlank($x){
        if (strlen($x) > 0){
            $x=str_replace("&nbsp;","",$x);
        }
        return $x;
    }

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }
    if (isset($_POST["razred"])){
        $VRazred = $_POST["razred"];
    }else{
        if (isset($_GET["razred"])){
            $VRazred=$_GET["razred"];
        }else{
            if (isset($_SESSION["razred"])){
                $VRazred=$_SESSION["razred"];
            }else{
                $VRazred = 0;
            }
        }
    }
    if (isset($_POST["iducenec"])){
        $ucenec = $_POST["iducenec"];
    }else{
        if (isset($_GET["iducenec"])){
            $ucenec=$_GET["iducenec"];
        }else{
            if (isset($_SESSION["iducenec"])){
                $ucenec=$_SESSION["iducenec"];
            }else{
                $ucenec = 0;
            }
        }
    }

	switch ($Vid){
		case "2":
		case "4":
		case "6":
		case "8":
		case "10":
        case "12":
			break;
		default:
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
	}
    switch ($Vid){
        case "1": //vnesi ocene za učenca
                //'pogleda podatke o učencu: razred, paralelka, predmete, ocene
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."'>Nazaj na redovalnico</a><br />";

                $SQL = "SELECT tabrazred.*,tabrazdat.* FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id WHERE iducenec=".$ucenec." AND tabrazdat.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VRazred=$R["idRazred"];
                    $VParalelka=$R["oznaka"];
                }else{
                    header("Location: nepooblascen.htm");
                }
                $IzbraniPredmet[0]=0;
                $IzbraniPredmet[1]=0;
                $IzbraniPredmet[2]=0;
                $IzbraniPredmet[3]=0;
                $IzbraniPredmet[4]=0;
                
                $SQL = "SELECT tabizbirni.*,tabucenci.*,tabpredmeti.*,tabpredmeti.id AS pid FROM ";
                $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni ";
                $SQL = $SQL . "WHERE tabizbirni.Ucenec=" .$ucenec . " AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $IzbraniPredmet[$Indx]=$R["pid"];
                    $Indx = $Indx+1;
                } 
                
                $SQL = "SELECT DISTINCT tabpredmeti.*,tabucenje.Predmet,tabucenje.Razred,tabucenje.Paralelka,tabucenje.Leto FROM tabpredmeti ";
                $SQL = $SQL . "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet ";
                $SQL = $SQL . "WHERE tabpredmeti.Prioriteta < 3 AND tabucenje.idRazred=" . $VRazred;
                $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    if (($R["Prioriteta"]==0) or ($R["Prioriteta"]==2) ){
                        $Predmeti[$Indx][0]=$R["Id"];
                        $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                        $Indx=$Indx+1;
                    }else{
                        if ($R["Id"]==$IzbraniPredmet[0] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[1] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[2] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[3] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[4] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                    }
                }
            $Predmetov=$Indx;
                
            for ($Indx=0;$Indx < $Predmetov;$Indx++){
                $PredmetPopravi[$Indx]=$Predmeti[$Indx][0];
            }

            //Izpis osebnih podatkov
            $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Dodajanje ocen:</h2>";
                $Datum=new DateTime(isDate($R["DatRoj"]));
                echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b><br />";
            }

            $SQL = "SELECT tabrazred.*, tabrazdat.*,tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM ";
            $SQL = $SQL . "((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE idUcenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov
            echo "<br /><table border=1>";
            echo "<th>Leto</th><th>Razred</th><th>Uspeh</th><th>Ponavljalec</th><th>Leto šolanja</th><th>Učitelj</th><th>Vzgojitelj</th>";
            $Indx=0;
            if ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izpisrazreda.php?solskoleto=".$R["leto"]."&razred=".$R["idRazred"]."'>".$R["razred"].". ". $R["oznaka"]."</td><td>".round($R["Uspeh"],2)."</td><td>".$R["Ponavljalec"]."</td><td>".$R["LetoSolanja"]."</td><td>".$R["upriimek"]." " .$R["uime"]."</td><td>".$R["vpriimek"]." ". $R["vime"]."</td></tr>";
                $Razredi[$Indx][0] = $R["leto"];
                $Razredi[$Indx][1] = $R["razred"];
                $Razredi[$Indx][2] = $R["oznaka"];
                $Razredi[$Indx][3] = $R["osemdevet"];
                $Razredi[$Indx][4] = $R["IdUcitelj"];
            }
            $SteviloRazredov=$Indx;
            echo "</table><br />";

            //'Izpis predmetnih podatkov
            $SQL = "SELECT * FROM tabpredmeti";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VPredmeti[$R["Id"]][0] = $R["Id"];
                $VPredmeti[$R["Id"]][1] = $R["Oznaka"];
                $VPredmeti[$R["Id"]][2] = $R["Opis"];
                $VPredmeti[$R["Id"]][3] = $R["Prioriteta"];
                $Indx=$Indx+1;
            }

            echo "<form  name='UcenecOceneVse' method=post action='vnesiocene.php'>";
            echo "<table border='1'>";
            echo "<th>Predmet</th><th>Pisna ocena</th><th>Ustna ocena</th><th>Polletno</th><th>Zaključeno</th><th>Ocenjen</th><th>Popravni</th>";
            $color=false;
            for ($IndxPredmet = 0;$IndxPredmet < $Predmetov;$IndxPredmet++){
            //zacetek predmeta i
                if ($PredmetPopravi[$IndxPredmet] > 0 ){    
                    $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$PredmetPopravi[$IndxPredmet]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        $VOcenaS1P=$R["OcenaS1P"];
                        $VOcenaS2P=$R["OcenaS2P"];
                        $VOcenaS1U=$R["OcenaS1U"];
                        $VOcenaS2U=$R["OcenaS2U"];
                        $VOcenaKoncna=$R["OcenaKoncna"];
                        $VOcenaPolletna=$R["OcenaPolletna"];
                        $VNeocenjen=$R["Neocenjen"];
                        $VPopravni=$R["Popravni"];
                    }else{
                        $VOcenaS1P="";
                        $VOcenaS2P="";
                        $VOcenaS1U="";
                        $VOcenaS2U="";
                        $VOcenaKoncna="";
                        $VOcenaPolletna="";
                        $VNeocenjen=0;
                        $VPopravni=0;
                    }
                    
                    $color=!$color;
                    if ($color){
                        echo "<tr bgcolor='lightgrey'>";
                        echo "<td class='trans'><input class='trans' name='predmet".$IndxPredmet."' type='hidden' value=".$PredmetPopravi[$IndxPredmet].">".$VPredmeti[$PredmetPopravi[$IndxPredmet]][1]." - ".$VPredmeti[$PredmetPopravi[$IndxPredmet]][2]."</td>";
                        echo "<td class='trans'>1. semester<input class='trans' name='OcenaS1P".$IndxPredmet."' type='text' value='".$VOcenaS1P."' tabindex='".$IndxPredmet."1'><br />2. semester<input class='trans' name='OcenaS2P".$IndxPredmet."' type='text' value='".$VOcenaS2P."' tabindex='".$IndxPredmet."3'></td><td><input class='trans' name='OcenaS1U".$IndxPredmet."' type='text' value='".$VOcenaS1U."' tabindex='".$IndxPredmet."2'><br /><input class='trans' name='OcenaS2U".$IndxPredmet."' type='text' value='".$VOcenaS2U."' tabindex='".$IndxPredmet."4'></td>";
                        echo "<td class='trans'><select name='OcenaPolletna".$IndxPredmet."'>";
                        switch ( $VOcenaPolletna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
                        //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>ZU</option><option>U</option><option>MU</option><option>Opravil</option><option>Ni opravil</option><option>.nbsp;</option></select></td>"
                        //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td class='trans'><select name='OcenaKoncna".$IndxPredmet."'>";
                        switch ( $VOcenaKoncna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
                        echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td class='trans'>";
                        switch ( $VNeocenjen){
                            case 0:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=0 selected>Ocenjeno</option><option value=1>Neocenjeno</option><option value=2>Opravičeno</option>";
                                break;
                            case 1:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=1 selected>Neocenjeno</option><option value=0>Ocenjeno</option><option value=2>Opravičeno</option>";
                                break;
                            case 2:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=2 selected>Opravičeno</option><option value=0>Ocenjeno</option><option value=1>Neocenjeno</option>";
                        }
                        echo "</select></td>";
                        echo "<td class='trans'>";
                        switch ( $VPopravni){
                            case 0:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0 selected>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                break;
                            case 1:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0>Ni popravnega izpita</option><option value=1 selected>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                break;
                            case 2:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2 selected>Predmetni izpit</option>";
                        }
                        echo "</select></td>";
                        echo "</tr>";
                    }else{
                        echo "<tr>";
                        echo "<td><input name='predmet".$IndxPredmet."' type='hidden' value=".$PredmetPopravi[$IndxPredmet].">".$VPredmeti[$PredmetPopravi[$IndxPredmet]][1]." - ".$VPredmeti[$PredmetPopravi[$IndxPredmet]][2]."</td>";
                        echo "<td>1. semester<input name='OcenaS1P".$IndxPredmet."' type='text' value='".$VOcenaS1P."' tabindex='".$IndxPredmet."1'><br />2. semester<input name='OcenaS2P".$IndxPredmet."' type='text' value='".$VOcenaS2P."' tabindex='".$IndxPredmet."3'></td><td><input name='OcenaS1U".$IndxPredmet."' type='text' value='".$VOcenaS1U."' tabindex='".$IndxPredmet."2'><br /><input name='OcenaS2U".$IndxPredmet."' type='text' value='".$VOcenaS2U."' tabindex='".$IndxPredmet."4'></td>";
                        echo "<td><select name='OcenaPolletna".$IndxPredmet."'>";
                        switch ( $VOcenaPolletna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
                        //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>ZU</option><option>U</option><option>MU</option><option>Opravil</option><option>Ni opravil</option><option>.nbsp;</option></select></td>"
                        //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td><select name='OcenaKoncna".$IndxPredmet."'>";
                        switch ( $VOcenaKoncna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
                        echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td>";
                        switch ( $VNeocenjen){
                            case 0:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=0 selected>Ocenjeno</option><option value=1>Neocenjeno</option><option value=2>Opravičeno</option>";
                                break;
                            case 1:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=1 selected>Neocenjeno</option><option value=0>Ocenjeno</option><option value=2>Opravičeno</option>";
                                break;
                            case 2:
                                echo "<select name='neocenjen".$IndxPredmet."'><option value=2 selected>Opravičeno</option><option value=0>Ocenjeno</option><option value=1>Neocenjeno</option>";
                        }
                        echo "</select></td>";
                        echo "<td>";
                        switch ( $VPopravni){
                            case 0:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0 selected>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                break;
                            case 1:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0>Ni popravnega izpita</option><option value=1 selected>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                break;
                            case 2:
                                echo "<select name='popravni".$IndxPredmet."'><option value=0>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2 selected>Predmetni izpit</option>";
                        }
                        echo "</select></td>";
                        echo "</tr>";
                    }
                }
                //konec predmeta i
            }

            echo "</table>";
            echo "<input name='leto' type='hidden' value='".$VLeto."'>";
            echo "<input name='iducenec' type='hidden' value='".$ucenec."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            /*
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            */
            echo "<input name='stpredmetov' type='hidden' value='".$Predmetov."'>";
            echo "<input name='id' type='hidden' value='2'>";
            echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";
            break;
        case "2":  //vpis ocen
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                $SQL = "SELECT tabrazred.*,tabrazdat.* FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id WHERE iducenec=".$ucenec." AND tabrazdat.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VRazred=$R["idRazred"];
                    $VParalelka=$R["oznaka"];
                }
                $Predmetov=$_POST["stpredmetov"];
                for ($Indx=0;$Indx < $Predmetov;$Indx++){
                    $VPredmet[$Indx]=$_POST["predmet".$Indx];
                    $VOcenaS1P[$Indx]=$_POST["OcenaS1P".$Indx];
                    $VOcenaS1U[$Indx]=$_POST["OcenaS1U".$Indx];
                    $VOcenaS2P[$Indx]=$_POST["OcenaS2P".$Indx];
                    $VOcenaS2U[$Indx]=$_POST["OcenaS2U".$Indx];
                    $VOcenaKoncna[$Indx]=$_POST["OcenaKoncna".$Indx];
                    $VOcenaPolletna[$Indx]=$_POST["OcenaPolletna".$Indx];
                    $VNeocenjen[$Indx]=$_POST["neocenjen".$Indx];
                    if (is_numeric($VOcenaKoncna[$Indx])){
                        $VNeocenjen[$Indx]=0;
                    }
                    $VPopravni[$Indx]=$_POST["popravni".$Indx];
                }
                /*
                //Izpis osebnih podatkov
                $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Vpis ocene za učenca:</h2>";
                    $Datum=new DateTime(isDate($R["DatRoj"]));
                    echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b><br />";
                }

                $SQL = "SELECT tabrazred.*, tabucitelji.Priimek, tabucitelji.Ime, tabvzgojitelji.Priimek, tabvzgojitelji.Ime FROM (tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj WHERE iducenec=" . $ucenec . " AND leto=" . $VLeto;
                $result = mysqli_query($link,$SQL);

                //Izpis razrednih podatkov
                $SQL = "SELECT tabrazred.*, tabrazdat.*,tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM ";
                $SQL = $SQL . "((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idUcenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
                $result = mysqli_query($link,$SQL);

                //Izpis razrednih podatkov
                echo "<br /><table border=1>";
                echo "<th>Leto</th><th>Razred</th><th>Uspeh</th><th>Ponavljalec</th><th>Leto šolanja</th><th>Učitelj</th><th>Vzgojitelj</th>";
                $Indx=0;
                if ($R = mysqli_fetch_array($result)){
                    echo "<tr><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izpisrazreda.asp?solskoleto=".$R["leto"]."&razred=".$R["idRazred"]."'>".$R["razred"].". ". $R["oznaka"]."</td><td>".$R["Uspeh"]."</td><td>".$R["Ponavljalec"]."</td><td>".$R["LetoSolanja"]."</td><td>".$R["upriimek"]." " .$R["uime"]."</td><td>".$R["vpriimek"]." ". $R["vime"]."</td></tr>";
                    $Razredi[$Indx][0] = $R["leto"];
                    $Razredi[$Indx][1] = $R["razred"];
                    $Razredi[$Indx][2] = $R["oznaka"];
                    $Razredi[$Indx][3] = $R["osemdevet"];
                    $Razredi[$Indx][4] = $R["idUcitelj"];
                }
                $SteviloRazredov=$Indx;
                echo "</table>";
                */
                //vpis predmetnih podatkov
                for ($Indx1=0;$Indx1 < $Predmetov;$Indx1++){
                    if ($VPredmet[$Indx1] > 0 ){
                        $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                        $result = mysqli_query($link,$SQL);
                        $vejica=false;
                        if ($R = mysqli_fetch_array($result)){
                            //$SQL = "UPDATE tabocene SET OcenaS1P='".$VOcenaS1P[$Indx1]."',OcenaS1U='".$VOcenaS1U[$Indx1]."',OcenaS2P='".$VOcenaS2P[$Indx1]."',OcenaS2U='".$VOcenaS2U[$Indx1]."',OcenaPolletna='".$VOcenaPolletna[$Indx1]."',OcenaKoncna='".$VOcenaKoncna[$Indx1]."',Neocenjen=".$VNeocenjen[$Indx1].",Popravni=".$VPopravni[$Indx1].",Datum='".$Danes->format('Y-m-d H:i:s')."',Vpisovalec='".$VUporabnik."' WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                            $SQL = "UPDATE tabocene SET ";
                            if ($VOcenaS1P[$Indx1] != $R["OcenaS1P"]){
                                $SQL .= "OcenaS1P='".$VOcenaS1P[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS1U[$Indx1] != $R["OcenaS1U"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS1U='".$VOcenaS1U[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS2P[$Indx1] != $R["OcenaS2P"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS2P='".$VOcenaS2P[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS2U[$Indx1] != $R["OcenaS2U"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS2U='".$VOcenaS2U[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaPolletna[$Indx1] != $R["OcenaPolletna"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaPolletna='".$VOcenaPolletna[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaKoncna[$Indx1] != $R["OcenaKoncna"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaKoncna='".$VOcenaKoncna[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VNeocenjen[$Indx1] != $R["Neocenjen"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "Neocenjen=".$VNeocenjen[$Indx1];
                                $vejica=true;
                            }
                            if ($VPopravni[$Indx1] != $R["Popravni"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "Popravni=".$VPopravni[$Indx1];
                                $vejica=true;
                            }
                            if ($vejica){
                                $SQL .= ",Datum='".$Danes->format('Y-m-d H:i:s')."',";
                                $SQL .= "Vpisovalec='".$VUporabnik."'";
                                $SQL .= " WHERE Id=".$R["Id"];
                                if (!($result1 = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu ocene!<br />$SQL<br />");
                                }
                            }
                        }else{
                            $SQL = "INSERT INTO tabocene (Leto,IdUcenec,IdPredmet,OcenaS1P,OcenaS1U,OcenaS2P,OcenaS2U,OcenaPolletna,OcenaKoncna,Neocenjen,Popravni,Datum,Vpisovalec) values (" . $VLeto . "," . $ucenec . "," . $VPredmet[$Indx1] . ",'" . $VOcenaS1P[$Indx1] . "','" . $VOcenaS1U[$Indx1] . "','" . $VOcenaS2P[$Indx1] . "','" . $VOcenaS2U[$Indx1] . "','" . $VOcenaPolletna[$Indx1] . "','" . $VOcenaKoncna[$Indx1] . "'," . $VNeocenjen[$Indx1] . "," . $VPopravni[$Indx1] . ",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ocene!<br />$SQL<br />");
                            }
                        }

                    }
                }

                header("Location: izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto);
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }
            break;
        case "3": //vnesi spričevalo
            //'pogleda podatke o učencu: razred, paralelka, predmete, ocene

                $SQL = "SELECT tabrazred.*,tabrazdat.* FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id WHERE iducenec=".$ucenec." AND tabrazdat.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred=$R["id"];
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }else{
                    header("Location: nepooblascen.htm");
                }
                $IzbraniPredmet[0]=0;
                $IzbraniPredmet[1]=0;
                $IzbraniPredmet[2]=0;
                $IzbraniPredmet[3]=0;
                $IzbraniPredmet[4]=0;
                
                $SQL = "SELECT tabizbirni.*,tabucenci.*,tabpredmeti.* FROM ";
                $SQL = $SQL . "(tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni ";
                $SQL = $SQL . "WHERE tabizbirni.Ucenec=" .$ucenec . " AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $IzbraniPredmet[$Indx]=$R["Izbirni"];
                    $Indx = $Indx+1;
                } 
                
                //0-idUcenec, 1-Priimek in ime, 2-razred, 3-datum rojstva
                
                $SQL = "SELECT tabrazred.*, tabucenci.*,tabrazdat.* FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred ;
                $SQL = $SQL . " ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$Indx][0]=$R["IdUcenec"];
                    $ucenci[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
                    $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                    $ucenci[$Indx][3]=new DateTime(isDate($R["DatRoj"]));
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;
                
                $prejsnji=0;
                $naslednji=0;
                for ($Indx=0;$Indx < $StUcencev;$Indx++){
                    switch ( $Indx){
                        case 0:
                            if ($ucenci[$Indx][0]==$ucenec){
                                $prejsnji=0;
                                $naslednji=1;
                            }
                            break;
                        case ($StUcencev-1);
                            if ($ucenci[$Indx][0]==$ucenec){
                                $naslednji=$StUcencev-1;
                                if ($StUcencev-2 >= 0 ){
                                    $prejsnji=$StUcencev-2;
                                }else{
                                    $prejsnji=0;
                                }
                            }
                            break;
                        default:
                            if ($ucenci[$Indx][0]==$ucenec){
                                $prejsnji=$Indx-1;
                                $naslednji=$Indx+1;
                            }
                    }
                }
                
                $SQL = "SELECT DISTINCT tabpredmeti.*,tabucenje.Predmet,tabucenje.idRazred,tabrazdat.* FROM (tabpredmeti ";
                $SQL = $SQL . "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabpredmeti.Prioriteta < 3 AND tabucenje.idRazred=" . $VRazred;
                $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";

                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    if (($R["Prioriteta"]==0) or ($R["Prioriteta"]==2) ){
                        $Predmeti[$Indx][0]=$R["Id"];
                        $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                        $Indx=$Indx+1;
                    }else{
                        if ($R["Id"]==$IzbraniPredmet[0]){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[1] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[2] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[3] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                        if ($R["Id"]==$IzbraniPredmet[4] ){
                            $Predmeti[$Indx][0]=$R["Id"];
                            $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                            $Indx=$Indx+1;
                        }
                    }
                }
            $Predmetov=$Indx;
                
            for ($Indx=0;$Indx < $Predmetov;$Indx++){
                $PredmetPopravi[$Indx]=$Predmeti[$Indx][0];
            }

            //Izpis osebnih podatkov
            $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Vnos zaključnih ocen: </h2>";
                if (isset($_GET["vpisano"])){
                    echo "<h1>Vpisano!  ";
                    if (isset($_GET["povprecje"])){
                        echo "Povprečje je: ".$_GET["povprecje"]."</h1>";
                    }else{
                        echo "</h1>";
                    }
                }
                echo "<a href='vnesiocene.php?id=3&iducenec=".$ucenci[$prejsnji][0]."&solskoleto=".$VLeto."'>Prejšnji</a> | <a href='vnesiocene.php?id=3&iducenec=".$ucenci[$naslednji][0]."&solskoleto=".$VLeto."'>Naslednji</a><br />";
                $Datum=new DateTime(isDate($R["DatRoj"]));
                echo "<h3>Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b></h3>";
            }

            $SQL = "SELECT tabrazred.*, tabrazdat.*,tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM ";
            $SQL = $SQL . "((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE idUcenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov
            echo "<br /><table border=1>";
            echo "<th>Leto</th><th>Razred</th><th>Uspeh</th><th>Ponavljalec</th><th>Leto šolanja</th><th>Učitelj</th><th>Vzgojitelj</th>";
            $Indx=0;
            if ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izpisrazreda.php?solskoleto=".$R["leto"]."&razred=".$R["idRazred"]."'>".$R["razred"].". ". $R["oznaka"]."</td><td>".round($R["Uspeh"],2)."</td><td>".$R["Ponavljalec"]."</td><td>".$R["LetoSolanja"]."</td><td>".$R["upriimek"]." " .$R["uime"]."</td><td>".$R["vpriimek"]." ". $R["vime"]."</td></tr>";
                $Razredi[$Indx][0] = $R["leto"];
                $Razredi[$Indx][1] = $R["razred"];
                $Razredi[$Indx][2] = $R["oznaka"];
                $Razredi[$Indx][3] = $R["osemdevet"];
                $Razredi[$Indx][4] = $R["IdUcitelj"];
            }
            $SteviloRazredov=$Indx;
            echo "</table>";

            //'Izpis predmetnih podatkov
            $SQL = "SELECT * FROM tabpredmeti";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VPredmeti[$R["Id"]][0] = $R["Id"];
                $VPredmeti[$R["Id"]][1] = $R["Oznaka"];
                $VPredmeti[$R["Id"]][2] = $R["Opis"];
                $VPredmeti[$R["Id"]][3] = $R["Prioriteta"];
                $Indx=$Indx+1;
            }

            echo "<form  name='UcenecOceneVse' method=post action='vnesiocene.php'>";
            echo "<br />Navodilo: N-neocenjeno, O-opravičeno, P-popravni izpit<br />";
            echo "<table border='1'>";
            echo "<tr><th>Predmet</th><th>Zaključeno</th></tr>";

            for ($IndxPredmet = 0;$IndxPredmet < $Predmetov;$IndxPredmet++){
            //zacetek predmeta i
                if ($PredmetPopravi[$IndxPredmet] > 0 ){    
                    $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$PredmetPopravi[$IndxPredmet]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        $VOcenaS1P=$R["OcenaS1P"];
                        $VOcenaS2P=$R["OcenaS2P"];
                        $VOcenaS1U=$R["OcenaS1U"];
                        $VOcenaS2U=$R["OcenaS2U"];
                        $VOcenaKoncna=$R["OcenaKoncna"];
                        $VOcenaPolletna=$R["OcenaPolletna"];
                        $VNeocenjen=$R["Neocenjen"];
                        $VPopravni=$R["Popravni"];
                    }else{
                        $VOcenaS1P="";
                        $VOcenaS2P="";
                        $VOcenaS1U="";
                        $VOcenaS2U="";
                        $VOcenaKoncna="";
                        $VOcenaPolletna="";
                        $VNeocenjen=0;
                        $VPopravni=0;
                    }
                    
                    echo "<tr>";
                    echo "<td><input name='predmet".$IndxPredmet."' type='hidden' value=".$PredmetPopravi[$IndxPredmet].">".$VPredmeti[$PredmetPopravi[$IndxPredmet]][1]." - ".$VPredmeti[$PredmetPopravi[$IndxPredmet]][2]."</td>";
                    switch (intval($VNeocenjen)){
                        case 1:
                            echo "<td><input name='OcenaKoncna".$IndxPredmet."' value='N' size='3'>";
                            break;
                        case 2:
                            echo "<td><input name='OcenaKoncna".$IndxPredmet."' value='O' size='3'>";
                            break;
                        default:
                            if (intval($VPopravni) > 0){
                                echo "<td><input name='OcenaKoncna".$IndxPredmet."' value='P' size='3'>";
                            }else{
                                echo "<td><input name='OcenaKoncna".$IndxPredmet."' value='".$VOcenaKoncna."' size='3'>";
                            }
                    }
                    echo "</td>";
                    echo "</tr>";
                }
            //konec predmeta i
            }
            echo "</table>";
            
    //'    vnos ostalih podatkov: napredovanje, Evid.št, datum izpisa
            $SQL = "SELECT tabrazred.*, tabrazdat.*,tabucenci.*, tabucitelji.Priimek, tabucitelji.Ime, tabvzgojitelji.Priimek, tabvzgojitelji.Ime FROM ";
            $SQL = $SQL."(((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
            $SQL = $SQL."INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
            $SQL = $SQL."INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL."WHERE tabrazred.idUcenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<br />Napredovanje: <select name='napredovanje'>";
                switch ( $R["Napredovanje"]){
                    case 0:
                        echo "<option value='0' selected>Napreduje/zaključuje</option><option value='1'>Napreduje z negativno</option><option value='2'>Ne napreduje</option>";
                        break;
                    case 1:
                        echo "<option value='0'>Napreduje/zaključuje</option><option value='1' selected>Napreduje z negativno</option><option value='2'>Ne napreduje</option>";
                        break;
                    case 2:
                        echo "<option value='0'>Napreduje/zaključuje</option><option value='1'>Napreduje z negativno</option><option value='2' selected>Ne napreduje</option>";
                        break;
                    default:
                        echo "<option value='0' selected>Napreduje/zaključuje</option><option value='1'>Napreduje z negativno</option><option value='2'>Ne napreduje</option>";
                }
                echo "</select></br>";

                if ($R["LetoSolanja"] > 8 ){
                    if ((!isset($R["OSObveza"])) or (strlen($R["OSObveza"]) == 0)){
                        echo "Leto izpolnitve OŠ obveznosti: <input name='obveznost' type='text' value='".$VLeto."/".($VLeto+1)."' size='8'><br />";
                    }else{
                        echo "Leto izpolnitve OŠ obveznosti: <input name='obveznost' type='text' value='".$R["OSObveza"]."' size='8'><br />";
                    }
                }
                echo "Matični list: <input name='maticna' type='text' value='".$R["MaticniList"]."' size='8'><br />";
                echo "Evid. št.: <input name='evidst' type='text' value='".$R["EvidSt"]."' size='10'><br />";
                echo "Datum izdaje: <input name='datizd' type='text' value='".$R["DatumIzdaje"]."' size='8'><br />";
            }
            echo "<input name='iducenec' type='hidden' value='".$ucenec."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='leto' type='hidden' value='".$VLeto."'>";
            /*
            echo "<input name='level' type='hidden' value='".VLevel."'>"
            echo "<input name='geslo' type='hidden' value='".VGeslo."'>"
            echo "<input name='uporabnik' type='hidden' value='".VUporabnik."'>"
            */
            echo "<input name='stpredmetov' type='hidden' value='".$Predmetov."'>";
            echo "<input name='id' type='hidden' value='4'>";
            echo "<input name='submit' type='submit' value='Pošlji'></form><br />";
            echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na redovalnico</a>";
            break;
        case "4": //vpis spričevala
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                if (isset($_POST["stpredmetov"])){
                    $Predmetov=$_POST["stpredmetov"];
                }else{
                    $Predmetov=0;
                }
                for ($Indx=0;$Indx < $Predmetov;$Indx++){
                    $VPredmet[$Indx]=$_POST["predmet".$Indx];
                    $VOcenaKoncna[$Indx]=$_POST["OcenaKoncna".$Indx];
                    if (is_numeric($VOcenaKoncna[$Indx])){
                        $VNeocenjen[$Indx]=0;
                    }
                }

                for ($Indx1=0;$Indx1 < $Predmetov;$Indx1++){
                    if ($VPredmet[$Indx1] > 0 ){
                        if (is_numeric($VOcenaKoncna[$Indx1]) ){
                            switch ($VOcenaKoncna[$Indx1]){
                                case 1;
                                    $VNeocenjen[$Indx1]=0;
                                    $VPopravni[$Indx1]=1;
                                    break;
                                default:
                                    $VNeocenjen[$Indx1]=0;
                                    $VPopravni[$Indx1]=0;
                            }
                        }
                        if (($VOcenaKoncna[$Indx1]=="N") or ($VOcenaKoncna[$Indx1]=="n") ){
                            $VOcenaKoncna[$Indx1]="0";
                            $VNeocenjen[$Indx1]=1;
                            $VPopravni[$Indx1]=2;
                        }
                        if (($VOcenaKoncna[$Indx1]=="O") or ($VOcenaKoncna[$Indx1]=="o") ){
                            $VOcenaKoncna[$Indx1]=0;
                            $VNeocenjen[$Indx1]=2;
                            $VPopravni[$Indx1]=0;
                        }
                        if (($VOcenaKoncna[$Indx1]=="P") or ($VOcenaKoncna[$Indx1]=="p") ){
                            $VOcenaKoncna[$Indx1]=1;
                            $VNeocenjen[$Indx1]=0;
                            $VPopravni[$Indx1]=1;
                        }
                        $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabocene SET OcenaKoncna='".$VOcenaKoncna[$Indx1]."',Neocenjen=".$VNeocenjen[$Indx1].",Popravni=".$VPopravni[$Indx1].",Datum='".$Danes->format('Y-m-d H:i:s')."',Vpisovalec='".$VUporabnik."' WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                        }else{
                            $SQL = "INSERT INTO tabocene (Leto,IdUcenec,IdPredmet,OcenaKoncna,Neocenjen,Popravni,Datum,Vpisovalec) values (" . $VLeto . "," . $ucenec . "," . $VPredmet[$Indx1] . ",'" . $VOcenaKoncna[$Indx1] . "'," . $VNeocenjen[$Indx1] . "," . $VPopravni[$Indx1] . ",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                        }
                        $result = mysqli_query($link,$SQL);
                        
                    }
                }
                //'izračun povprečnega uspeha
                $vsota=0;
                $SQL = "SELECT tabocene.ocenakoncna FROM tabocene INNER JOIN tabpredmeti ON tabocene.idpredmet=tabpredmeti.id WHERE iducenec=".$ucenec." AND tabpredmeti.prioriteta=0 AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                $ocen=0;
                while ($R = mysqli_fetch_array($result)){
                    if (is_numeric($R["ocenakoncna"]) ){
                        if ($R["ocenakoncna"] > 0 ){
                            $vsota=$vsota+$R["ocenakoncna"];
                            $ocen=$ocen+1;
                        }
                    }
                }

                //'vpis podatkov za spricevalo - tabrazred
                if ($ocen > 0 ){
                    $SQL = "UPDATE tabrazred SET uspeh=".str_replace(",",".",number_format($vsota/$ocen,2)).", napredovanje=".$_POST["napredovanje"].",EvidSt='".$_POST["evidst"]."',datumIzdaje='".$_POST["datizd"]."' WHERE idUcenec=".$ucenec." AND leto=".$VLeto;
                }else{
                    $SQL = "UPDATE tabrazred SET napredovanje=".$_POST["napredovanje"].",EvidSt='".$_POST["evidst"]."',datumIzdaje='".$_POST["datizd"]."' WHERE idUcenec=".$ucenec." AND leto=".$VLeto;
                }
                $result = mysqli_query($link,$SQL);
                
                //'vpis matične številke
                $SQL = "UPDATE tabucenci SET MaticniList='".$_POST["maticna"]."' WHERE idUcenec=".$ucenec;
                $result = mysqli_query($link,$SQL);
                
                //'vpis izpolnjene obveze OŠ
                if (strlen($_POST["obveznost"]) > 0 ){
                    $SQL = "UPDATE tabucenci SET OSobveza='".$_POST["obveznost"]."' WHERE idUcenec=".$ucenec;
                    $result = mysqli_query($link,$SQL);
                }
                if ($ocen > 0 ){
                    header ("Location: vnesiocene.php?id=3&razred=".$VRazred."&iducenec=".$ucenec."&solskoleto=".$VLeto."&vpisano=1&povprecje=".str_replace(",",".",number_format($vsota/$ocen,2)));
                }else{
                    header ("Location: vnesiocene.php?id=3&razred=".$VRazred."&iducenec=".$ucenec."&solskoleto=".$VLeto."&vpisano=1");
                }
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }    
            break;
        case "5": //popravi ocene predmet
            $PredmetPopravi=$_GET["predmet"];

            $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
            }

            $SQL = "SELECT * FROM tabpredmeti WHERE id=".$PredmetPopravi;
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            if ($R = mysqli_fetch_array($result)){
                $VPredmeti[0] = $R["Id"];
                $VPredmeti[1] = $R["Oznaka"];
                $VPredmeti[2] = $R["Opis"];
                $VPredmeti[3] = $R["Prioriteta"];
            }

            echo "<h2>Redovalnica - predmetna</h2>";
            if (($VPredmeti[3]==0) or ($VPredmeti[3]==0) ){ 
                echo "<h2>Razred: ".$VRazred1.". ".$VParalelka."</h2>";
            }

            if ($VPredmeti[3]==1 ){
                $SQL = "SELECT tabpredmeti.*, tabizbirni.*,tabucenci.*,tabrazred.*,tabrazdat.* FROM ";
                $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabizbirni.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabpredmeti.Id=".$VPredmeti[0];
                $SQL = $SQL ." ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";
            }else{
                $SQL = "SELECT tabrazred.*, tabucenci.*,tabrazdat.* FROM ";
                $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                $SQL = $SQL ." ORDER BY priimek,ime";
            }

            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Ucenci[$Indx][0] = $R["IdUcenec"];
                $Ucenci[$Indx][1] = $R["Priimek"].", ".$R["Ime"];
                if ($VPredmeti[3]==1 ){
                    $Ucenci[$Indx][2] = $R["razred"];
                    $Ucenci[$Indx][3] = $R["oznaka"];
                }else{
                    $Ucenci[$Indx][2] = $VRazred1;
                    $Ucenci[$Indx][3] = $VParalelka;
                }
                $Ucenci[$Indx][4]=$R["IdUcitelj"];
                $Indx = $Indx+1;
            } 
            $SteviloUcencev=$Indx-1;

            //Izpis predmetnih podatkov
            //'za redne predmete
            if (($VPredmeti[3]==0) or ($VPredmeti[3]==2) ){    
                echo "<form  name='UcenecOcenePredmet' method=post action='vnesiocene.php'>";
                echo "<table border='1'>";
                echo "<th>Predmet</th><th>Učenec</th><th>Pisna ocena</th><th>Ustna ocena</th><th>Polletno</th><th>Zaključeno</th><th>Ocenjen</th><th>Popravni</th><th>Briši</th>";
                $color=true;
                for ($IndxUcenec = 0;$IndxUcenec <= $SteviloUcencev;$IndxUcenec++){
                    //zacetek predmeta i
                    if ($Ucenci[$IndxUcenec][0] > 0 ){    
                        $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$PredmetPopravi." AND leto=".$VLeto." AND IdUcenec=".$Ucenci[$IndxUcenec][0];
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VOcenaS1P=$R["OcenaS1P"];
                            $VOcenaS2P=$R["OcenaS2P"];
                            $VOcenaS1U=$R["OcenaS1U"];
                            $VOcenaS2U=$R["OcenaS2U"];
                            $VOcenaKoncna=$R["OcenaKoncna"];
                            $VOcenaPolletna=$R["OcenaPolletna"];
                            $VNeocenjen=$R["Neocenjen"];
                            $VPopravni=$R["Popravni"];
                        }else{
                            $VOcenaS1P="";
                            $VOcenaS2P="";
                            $VOcenaS1U="";
                            $VOcenaS2U="";
                            $VOcenaKoncna="";
                            $VOcenaPolletna="";
                            $VNeocenjen=0;
                            $VPopravni=0;
                        }
                        $color=!$color;
                        if ($color){
                            echo "<tr bgcolor='lightgrey'>";
                            echo "<td class='trans'><input class='trans' name='predmet".$IndxUcenec."' type='hidden' value=".$PredmetPopravi.">".$VPredmeti[1]." - ".$VPredmeti[2]."</td>";
                            echo "<td class='trans'><input class='trans' name='ucenec".$IndxUcenec."' type='hidden' value=".$Ucenci[$IndxUcenec][0].">".$Ucenci[$IndxUcenec][1]."</td>";
                            echo "<td class='trans'>1. semester<input class='trans' name='OcenaS1P".$IndxUcenec."' type='text' value='".$VOcenaS1P."' tabindex='".$IndxUcenec."1'><br />2. semester<input class='trans' name='OcenaS2P".$IndxUcenec."' type='text' value='".$VOcenaS2P."' tabindex='".$IndxUcenec."3'></td><td><input class='trans' name='OcenaS1U".$IndxUcenec."' type='text' value='".$VOcenaS1U."' tabindex='".$IndxUcenec."2'><br /><input class='trans' name='OcenaS2U".$IndxUcenec."' type='text' value='".$VOcenaS2U."' tabindex='".$IndxUcenec."4'></td>";
                            echo "<td class='trans'><select name='OcenaPolletna".$IndxUcenec."'>";
                            switch ( $VOcenaPolletna){
                                case "5";
                                    echo "<option selected>5</option>";
                                    break;
                                case "4":
                                    echo "<option selected>4</option>";
                                    break;
                                case "3":
                                    echo "<option selected>3</option>";
                                    break;
                                case "2":
                                    echo "<option selected>2</option>";
                                    break;
                                case "1":
                                    echo "<option selected>1</option>";
                                    break;
                                default:
                                    echo "<option selected> </option>";
                            }
                            //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                            echo "<option>1</option><option>&nbsp;</option></select></td>";
                            echo "<td class='trans'><select name='OcenaKoncna".$IndxUcenec."'>";
                            switch ( $VOcenaKoncna){
                                case "5";
                                    echo "<option selected>5</option>";
                                    break;
                                case "4":
                                    echo "<option selected>4</option>";
                                    break;
                                case "3":
                                    echo "<option selected>3</option>";
                                    break;
                                case "2":
                                    echo "<option selected>2</option>";
                                    break;
                                case "1":
                                    echo "<option selected>1</option>";
                                    break;
                                default:
                                    echo "<option selected> </option>";
                            }
                            echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                            echo "<td class='trans'>";
                            switch ( $VNeocenjen){
                                case 0:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=0 selected>Ocenjeno</option><option value=1>Neocenjeno</option><option value=2>Opravičeno</option>";
                                    break;
                                case 1:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=1 selected>Neocenjeno</option><option value=0>Ocenjeno</option><option value=2>Opravičeno</option>";
                                    break;
                                case 2:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=2 selected>Opravičeno</option><option value=0>Ocenjeno</option><option value=1>Neocenjeno</option>";
                            }
                            echo "</select></td>";
                            echo "<td class='trans'>";
                            switch ( $VPopravni){
                                case 0:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0 selected>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                    break;
                                case 1:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0>Ni popravnega izpita</option><option value=1 selected>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                    break;
                                case 2:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2 selected>Predmetni izpit</option>";
                            }
                            echo "</select></td>";
                            echo "</tr>";
                        
                        }else{
                            echo "<tr>";
                            echo "<td><input name='predmet".$IndxUcenec."' type='hidden' value=".$PredmetPopravi.">".$VPredmeti[1]." - ".$VPredmeti[2]."</td>";
                            echo "<td><input name='ucenec".$IndxUcenec."' type='hidden' value=".$Ucenci[$IndxUcenec][0].">".$Ucenci[$IndxUcenec][1]."</td>";
                            echo "<td>1. semester<input name='OcenaS1P".$IndxUcenec."' type='text' value='".$VOcenaS1P."' tabindex='".$IndxUcenec."1'><br />2. semester<input name='OcenaS2P".$IndxUcenec."' type='text' value='".$VOcenaS2P."' tabindex='".$IndxUcenec."3'></td><td><input name='OcenaS1U".$IndxUcenec."' type='text' value='".$VOcenaS1U."' tabindex='".$IndxUcenec."2'><br /><input name='OcenaS2U".$IndxUcenec."' type='text' value='".$VOcenaS2U."' tabindex='".$IndxUcenec."4'></td>";
                            echo "<td><select name='OcenaPolletna".$IndxUcenec."'>";
                            switch ( $VOcenaPolletna){
                                case "5";
                                    echo "<option selected>5</option>";
                                    break;
                                case "4":
                                    echo "<option selected>4</option>";
                                    break;
                                case "3":
                                    echo "<option selected>3</option>";
                                    break;
                                case "2":
                                    echo "<option selected>2</option>";
                                    break;
                                case "1":
                                    echo "<option selected>1</option>";
                                    break;
                                default:
                                    echo "<option selected> </option>";
                            }
                            //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                            echo "<option>1</option><option>&nbsp;</option></select></td>";
                            echo "<td><select name='OcenaKoncna".$IndxUcenec."'>";
                            switch ( $VOcenaKoncna){
                                case "5";
                                    echo "<option selected>5</option>";
                                    break;
                                case "4":
                                    echo "<option selected>4</option>";
                                    break;
                                case "3":
                                    echo "<option selected>3</option>";
                                    break;
                                case "2":
                                    echo "<option selected>2</option>";
                                    break;
                                case "1":
                                    echo "<option selected>1</option>";
                                    break;
                                default:
                                    echo "<option selected> </option>";
                            }
                            echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                            echo "<td>";
                            switch ( $VNeocenjen){
                                case 0:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=0 selected>Ocenjeno</option><option value=1>Neocenjeno</option><option value=2>Opravičeno</option>";
                                    break;
                                case 1:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=1 selected>Neocenjeno</option><option value=0>Ocenjeno</option><option value=2>Opravičeno</option>";
                                    break;
                                case 2:
                                    echo "<select name='neocenjen".$IndxUcenec."'><option value=2 selected>Opravičeno</option><option value=0>Ocenjeno</option><option value=1>Neocenjeno</option>";
                            }
                            echo "</select></td>";
                            echo "<td>";
                            switch ( $VPopravni){
                                case 0:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0 selected>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                    break;
                                case 1:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0>Ni popravnega izpita</option><option value=1 selected>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                                    break;
                                case 2:
                                    echo "<select name='popravni".$IndxUcenec."'><option value=0>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2 selected>Predmetni izpit</option>";
                            }
                            echo "</select></td>";
                            echo "</tr>";
                        }
                    }
                //konec predmeta i
                }
                    echo "</table>";
            }

            //'za izbirne predmete
            if ($VPredmeti[3]==1 ){    
                echo "<form  name='UcenecOcenePredmet' method=post action='vnesiocene.php'>";
                echo "<table border='1'>";
                echo "<th>Predmet</th><th>Učenec</th><th>Razred</th><th>Pisna ocena</th><th>Ustna ocena</th><th>Polletno</th><th>Zaključeno</th><th>Ocenjen</th><th>Popravni</th>";

                for ($IndxUcenec = 0;$IndxUcenec <= $SteviloUcencev;$IndxUcenec++){
                    //zacetek predmeta i
                    if ($Ucenci[$IndxUcenec][0] > 0 ){    
                        $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$PredmetPopravi." AND leto=".$VLeto." AND IdUcenec=".$Ucenci[$IndxUcenec][0];
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VOcenaS1P=$R["OcenaS1P"];
                            $VOcenaS2P=$R["OcenaS2P"];
                            $VOcenaS1U=$R["OcenaS1U"];
                            $VOcenaS2U=$R["OcenaS2U"];
                            $VOcenaKoncna=$R["OcenaKoncna"];
                            $VOcenaPolletna=$R["OcenaPolletna"];
                            $VNeocenjen=$R["Neocenjen"];
                            $VPopravni=$R["Popravni"];
                            $VBrisanje=$R["Id"];
                        }else{
                            $VOcenaS1P="";
                            $VOcenaS2P="";
                            $VOcenaS1U="";
                            $VOcenaS2U="";
                            $VOcenaKoncna="";
                            $VOcenaPolletna="";
                            $VNeocenjen=0;
                            $VPopravni=0;
                            $VBrisanje=0;
                        }
                        
                        echo "<tr>";
                        echo "<td><input name='predmet".$IndxUcenec."' type='hidden' value='".$PredmetPopravi."'>".$VPredmeti[1]." - ".$VPredmeti[2]."</td>";
                        echo "<td><input name='ucenec".$IndxUcenec."' type='hidden' value='".$Ucenci[$IndxUcenec][0]."'>".$Ucenci[$IndxUcenec][1]."</td>";
                        echo "<td>".$Ucenci[$IndxUcenec][2].". ".$Ucenci[$IndxUcenec][3]."</td>";
                        echo "<td>1. semester<input name='OcenaS1P".$IndxUcenec."' type='text' value='".$VOcenaS1P."'><br />2. semester<input name='OcenaS2P".$IndxUcenec."' type='text' value='".$VOcenaS2P."'></td><td><input name='OcenaS1U".$IndxUcenec."' type='text' value='".$VOcenaS1U."'><br /><input name='OcenaS2U".$IndxUcenec."' type='text' value='".$VOcenaS2U."'></td>";
                        echo "<td><select name='OcenaPolletna".$IndxUcenec."'>";
                        switch ( $VOcenaPolletna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
//                        echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td><select name='OcenaKoncna".$IndxUcenec."'>";
                        switch ( $VOcenaKoncna){
                            case "5";
                                echo "<option selected>5</option>";
                                break;
                            case "4":
                                echo "<option selected>4</option>";
                                break;
                            case "3":
                                echo "<option selected>3</option>";
                                break;
                            case "2":
                                echo "<option selected>2</option>";
                                break;
                            case "1":
                                echo "<option selected>1</option>";
                                break;
                            default:
                                echo "<option selected> </option>";
                        }
                        echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>&nbsp;</option></select></td>";
                        echo "<td>";
                        switch ( $VNeocenjen){
                            case 0:
                                echo "<select name='neocenjen".$IndxUcenec."'><option value=0 selected>Ocenjen</option><option value=1>Neocenjen</option>";
                                break;
                            case 1:
                                echo "<select name='neocenjen".$IndxUcenec."'><option value=0>Ocenjen</option><option value=1 selected>Neocenjen</option>";
                        }
                        echo "</select></td>";
                        echo "<td>";
                        switch ( $VPopravni){
                            case 0:
                                echo "<select name='popravni".$IndxUcenec."'><option value=0 selected>Opravil</option><option value=1>Popravni</option>";
                                break;
                            case 1:
                                echo "<select name='popravni".$IndxUcenec."'><option value=1 selected>Popravni</option><option value=0>Opravil</option>";
                        }
                        echo "</select></td>";
                        if (($VLevel > 1) && ($VBrisanje > 0) ){
                            echo "<td><a href='vnesiocene.php?id=11&brisi=".$VBrisanje."&razred=".$VRazred."&solskoleto=".$VLeto."&predmet=".$PredmetPopravi."'>B</a></td>";
                        }
                        echo "</tr>";
                    }
                //konec predmeta i
                }
                echo "</table>";

            }
                
                
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='iducenec' type='hidden' value='".$ucenec."'>";
            echo "<input name='stucencev' type='hidden' value='".$SteviloUcencev."'>";
            /*
            echo "<input name='level' type='hidden' value='".VLevel."'>"
            echo "<input name='geslo' type='hidden' value='".VGeslo."'>"
            echo "<input name='uporabnik' type='hidden' value='".VUporabnik."'>"
            */
            echo "<input name='id' type='hidden' value='6'>";
            echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";
        
            break;
        case "6": //vpis ocene predmet
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                if (isset($_POST["stucencev"])){
                    $SteviloUcencev=$_POST["stucencev"];
                }else{
                    $SteviloUcencev=0;
                }
                for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                    $VPredmet[$Indx]=$_POST["predmet".$Indx];
                    $VOcenaS1P[$Indx]=$_POST["OcenaS1P".$Indx];
                    $VOcenaS1U[$Indx]=$_POST["OcenaS1U".$Indx];
                    $VOcenaS2P[$Indx]=$_POST["OcenaS2P".$Indx];
                    $VOcenaS2U[$Indx]=$_POST["OcenaS2U".$Indx];
                    $VOcenaKoncna[$Indx]=$_POST["OcenaKoncna".$Indx];
                    $VOcenaPolletna[$Indx]=$_POST["OcenaPolletna".$Indx];
                    $VNeocenjen[$Indx]=$_POST["neocenjen".$Indx];
                    if (is_numeric($VOcenaKoncna[$Indx])){
                        $VNeocenjen[$Indx]=0;
                    }
                    $VPopravni[$Indx]=$_POST["popravni".$Indx];
                    $VUcenec[$Indx]=$_POST["ucenec".$Indx];
                }

                //vpis predmetnih podatkov
                for ($Indx1=0;$Indx1 <= $SteviloUcencev;$Indx1++){
                    if ($VUcenec[$Indx1] > 0 ){
                        $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$VUcenec[$Indx1];
                        $result = mysqli_query($link,$SQL);
                        $vejica=false;
                        if ($R = mysqli_fetch_array($result)){
                            //$SQL = "UPDATE tabocene SET OcenaS1P='".$VOcenaS1P[$Indx1]."',OcenaS1U='".$VOcenaS1U[$Indx1]."',OcenaS2P='".$VOcenaS2P[$Indx1]."',OcenaS2U='".$VOcenaS2U[$Indx1]."',OcenaPolletna='".$VOcenaPolletna[$Indx1]."',OcenaKoncna='".$VOcenaKoncna[$Indx1]."',Neocenjen=".$VNeocenjen[$Indx1].",Popravni=".$VPopravni[$Indx1].",Datum='".$Danes->format('Y-m-d H:i:s')."',Vpisovalec='".$VUporabnik."' WHERE IdPredmet=".$VPredmet[$Indx1]." AND leto=".$VLeto." AND IdUcenec=".$VUcenec[$Indx1];
                            $SQL = "UPDATE tabocene SET ";
                            if ($VOcenaS1P[$Indx1] != $R["OcenaS1P"]){
                                $SQL .= "OcenaS1P='".$VOcenaS1P[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS1U[$Indx1] != $R["OcenaS1U"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS1U='".$VOcenaS1U[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS2P[$Indx1] != $R["OcenaS2P"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS2P='".$VOcenaS2P[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaS2U[$Indx1] != $R["OcenaS2U"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaS2U='".$VOcenaS2U[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaPolletna[$Indx1] != $R["OcenaPolletna"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaPolletna='".$VOcenaPolletna[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VOcenaKoncna[$Indx1] != $R["OcenaKoncna"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "OcenaKoncna='".$VOcenaKoncna[$Indx1]."'";
                                $vejica=true;
                            }
                            if ($VNeocenjen[$Indx1] != $R["Neocenjen"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "Neocenjen=".$VNeocenjen[$Indx1];
                                $vejica=true;
                            }
                            if ($VPopravni[$Indx1] != $R["Popravni"]){
                                if ($vejica) {
                                    $SQL .= ",";
                                }
                                $SQL .= "Popravni=".$VPopravni[$Indx1];
                                $vejica=true;
                            }
                            if ($vejica){
                                $SQL .= ",Datum='".$Danes->format('Y-m-d H:i:s')."',";
                                $SQL .= "Vpisovalec='".$VUporabnik."'";
                                $SQL .= " WHERE Id=".$R["Id"];
                                if (!($result1 = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu ocene!<br />$SQL<br />");
                                }
                            }
                        }else{
                            $SQL = "INSERT INTO tabocene (Leto,IdUcenec,IdPredmet,OcenaS1P,OcenaS1U,OcenaS2P,OcenaS2U,OcenaPolletna,OcenaKoncna,Neocenjen,Popravni,Datum,Vpisovalec) values (" . $VLeto . "," . $VUcenec[$Indx1] . "," . $VPredmet[$Indx1] . ",'" . $VOcenaS1P[$Indx1] . "','" . $VOcenaS1U[$Indx1] . "','" . $VOcenaS2P[$Indx1] . "','" . $VOcenaS2U[$Indx1] . "','" . $VOcenaPolletna[$Indx1] . "','" . $VOcenaKoncna[$Indx1] . "'," . $VNeocenjen[$Indx1] . "," . $VPopravni[$Indx1] . ",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ocen!<br />$SQL<br />");
                            }
                        }

                    }
                }
                //response.redirect "ucenec_pregled.php?id=".ucenec."#redovalnica"
                header ("Location: izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto);
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }
            break;
        case "7": //popravi uspeh razred
            $SQL = "SELECT tabrazred.*, tabrazdat.*, tabucenci.*,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime FROM ";
            $SQL = $SQL."((tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj = tabucitelji.IdUcitelj) ";
            $SQL = $SQL."INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL."WHERE tabrazred.idRazred=" . $VRazred ;
            $SQL = $SQL." ORDER BY tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov
            echo "<h2>Vpis podatkov o statusih in za spričevalo</h2>";
            echo "<p>V rubriki ponavljalec izberite 1, če je učenec ponavljal to leto, za katero vpisujete uspeh.</p>";
            echo "<form  name='UcenciUspehRazred' method=post action='vnesiocene.php'>";
            echo "<br /><table border='1'>";
            echo "<tr>";
            echo "<th>Leto</th>";
            echo "<th>Razred</th>";
            echo "<th>Ime</th>";
            if ($VLeto < 2008 ){
                echo "<th>Polletni<br />uspeh</th>";
                echo "<th>Uspeh</th>";
            }
            echo "<th>Status</th>";
            echo "<th>Razr.<br />izpit</th>";
            echo "<th>Napredovanje</th>";
            echo "<th>Leto<br />šolanja</th>";
            echo "<th>Nadarjen</th>";
            echo "<th>Športnik</th>";
            echo "<th>Kulturnik</th>";
            echo "<th>Razrednik/<br />Razredničarka</th>";
            echo "<th>EMŠO</th>";
            echo "<th>Mat.<br />list</th>";
            echo "<th>Evid. št.</th>";
            echo "<th>Datum<br />izdaje</th>";
            echo "<th>Opomba</th>";
            echo "</tr>";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$R["leto"]."/".($R["leto"]+1)."</td><td>".$R["razred"].". ". $R["oznaka"]."</td>";
                echo "<td><input name=ucenec".$Indx." type=hidden value=".$R["IdUcenec"].">".$R["ucpriimek"].", ".$R["ucime"]."</td>";
                if ($VLeto < 2008 ){
                    echo "<td><select name='uspehpol".$Indx."'>";
                    echo "<option selected>".$R["UspehPol"]."</option><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>0</option>";
                    echo "</select></td>";
                    echo "<td><select name='uspeh".$Indx."'>";
                    echo "<option selected>".$R["Uspeh"]."</option><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option>0</option>";
                    echo "</select></td>";
                }
                echo "<td><select name='ponavljanje".$Indx."'>";
                if ($R["Ponavljalec"] == 0){
                    echo "<option value='0' selected='selected'>redni</option>";
                    echo "<option value='1'>ponavlja</option>";
                }else{
                    echo "<option value='0'>redni</option>";
                    echo "<option value='1' selected='selected'>ponavlja</option>";
                }
                echo "</select></td>";

                echo "<td>";
                /*
                echo "<select name='razredniizpit".$Indx."'>";
                echo "<option selected>".$R["RazredniIzpit"]."</option><option>0</option><option>1</option>";
                echo "</select>";
                */
                if ($R["RazredniIzpit"]==0){
                    echo "<input name='razredniizpit".$Indx."' type='checkbox'>";
                }else{
                    echo "<input name='razredniizpit".$Indx."' type='checkbox' checked='checked'>";
                }
                echo "</td>";
                echo "<td><select name='napredovanje".$Indx."'>";
                switch ( $R["Napredovanje"]){
                    case 0:
                        if ($R["razred"] < 9){
                            echo "<option value='0' selected='selected'>Napreduje</option>";
                        }else{
                            echo "<option value='0' selected='selected'>Zaključuje</option>";
                        }
                        echo "<option value='1'>Napreduje z negativno</option>";
                        echo "<option value='2'>Ne napreduje</option>";
                        break;
                    case 1:
                        if ($R["razred"] < 9){
                            echo "<option value='0'>Napreduje</option>";
                        }else{
                            echo "<option value='0'>Zaključuje</option>";
                        }
                        echo "<option value='1' selected='selected'>Napreduje z negativno</option>";
                        echo "<option value='2'>Ne napreduje</option>";
                        break;
                    case 2:
                        if ($R["razred"] < 9){
                            echo "<option value='0'>Napreduje</option>";
                        }else{
                            echo "<option value='0'>Zaključuje</option>";
                        }
                        echo "<option value='1'>Napreduje z negativno</option>";
                        echo "<option value='2' selected='selected'>Ne napreduje</option>";
                        break;
                    default:
                        if ($R["razred"] < 9){
                            echo "<option value='0' selected='selected'>Napreduje</option>";
                        }else{
                            echo "<option value='0' selected='selected'>Zaključuje</option>";
                        }
                        echo "<option value='1'>Napreduje z negativno</option>";
                        echo "<option value='2'>Ne napreduje</option>";
                }
                echo "</select>";
                echo "</td>";

                echo "<td><select name='solanje".$Indx."'>";
                echo "<option selected>".$R["LetoSolanja"]."</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option>";
                echo "</select></td>";

                echo "<td align='center'>";
                /*
                echo "<select name='nadarjen".$Indx."'>";
                echo "<option selected>".$R["Nadarjen"]."</option><option>0</option><option>1</option>";
                echo "</select>";
                */
                if ($R["Nadarjen"]==0){
                    echo "<input name='nadarjen".$Indx."' type='checkbox'>";
                }else{
                    echo "<input name='nadarjen".$Indx."' type='checkbox' checked='checked'>";
                }
                echo "</td>";
                
                echo "<td align='center'>";
                /*
                echo "<select name='statussport".$Indx."'>";
                echo "<option selected>".$R["StatusSport"]."</option><option>0</option><option>1</option>";
                echo "</select>";
                */
                if ($R["StatusSport"]==0){
                    echo "<input name='statussport".$Indx."' type='checkbox'>";
                }else{
                    echo "<input name='statussport".$Indx."' type='checkbox' checked='checked'>";
                }
                echo "</td>";

                echo "<td align='center'>";
                /*
                echo "<select name='statuskult".$Indx."'>";
                echo "<option selected>".$R["StatusKult"]."</option><option>0</option><option>1</option>";
                echo "</select>";
                */
                if ($R["StatusKult"]==0){
                    echo "<input name='statuskult".$Indx."' type='checkbox'>";
                }else{
                    echo "<input name='statuskult".$Indx."' type='checkbox' checked='checked'>";
                }
                echo "</td>";
                
                echo "<td>".$R["upriimek"]." " .$R["uime"]."</td>";
                echo "<td><input name='emso".$Indx."' type='text' value='".$R["emso"]."' size='10'></td>";
                echo "<td><input name='maticna".$Indx."' type='text' value='".$R["MaticniList"]."' size='8'></td>";
                echo "<td><input name='evidst".$Indx."' type='text' value='".$R["EvidSt"]."' size='15'></td>";
                echo "<td><input name='datizd".$Indx."' type='text' value='".$R["DatumIzdaje"]."' size='8'></td>";
                echo "<td><input name='opomba".$Indx."' type='text' value='".$R["Opomba"]."' size='8'></td>";
                echo "</tr>";
                $Indx = $Indx+1;
            } 
            $SteviloUcencev=$Indx-1;
            echo "</table>";

            echo "<input name='leto' type='hidden' value='".$VLeto."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='stucencev' type='hidden' value='".$SteviloUcencev."'>";
            echo "<input name='id' type='hidden' value='8'>";
            echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";
            echo "</form>";

            //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
            echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na redovalnico</a><br />";
            if ($VLevel > 1){
                echo "<a href='izborrazreda.php?id=uspeh'>Na izbor razreda</a><br />";
            }
        
            break;
        case "8": //vpis uspeha razred
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                if (isset($_POST["stucencev"])){
                    $SteviloUcencev=$_POST["stucencev"];
                }else{
                    $SteviloUcencev=0;
                }
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                    $ucenci[$Indx] = $_POST["ucenec".$Indx];
                    if ($VLeto < 2008){
                        $VUspeh[$Indx] = $_POST["uspeh".$Indx];
                        $VUspehPol[$Indx] = $_POST["uspehpol".$Indx];
                    }
                    $VPonavljanje[$Indx] = $_POST["ponavljanje".$Indx];
                    $VSolanje[$Indx]=$_POST["solanje".$Indx];
                    $VEvidSt[$Indx]=$_POST["evidst".$Indx];
                    if (isset($_POST["nadarjen".$Indx])){
                        $VNadarjen[$Indx]=1;
                    }else{
                        $VNadarjen[$Indx]=0;
                    }
                    if (isset($_POST["statussport".$Indx])){
                        $VStatusSport[$Indx]=1;
                    }else{
                        $VStatusSport[$Indx]=0;
                    }
                    if (isset($_POST["statuskult".$Indx])){
                        $VStatusKult[$Indx]=1;
                    }else{
                        $VStatusKult[$Indx]=0;
                    }
                    if (isset($_POST["razredniizpit".$Indx])){
                        $VRazredniIzpit[$Indx]=1;
                    }else{
                        $VRazredniIzpit[$Indx]=0;
                    }
                    $VNapredovanje[$Indx]=$_POST["napredovanje".$Indx];
                    $VEmso[$Indx]=$_POST["emso".$Indx];
                    $VMaticna[$Indx]=$_POST["maticna".$Indx];
                    $VDatumIzdaje[$Indx]=$_POST["datizd".$Indx];
                    $VOpomba[$Indx]=$_POST["opomba".$Indx];
                }

                //'Vpiše oz. popravi uspeh
                for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                    if ($ucenci[$Indx] > 0 ){
                        $SQL="UPDATE  tabrazred SET  ponavljalec=". $VPonavljanje[$Indx] .", letosolanja=". $VSolanje[$Indx];
                        $SQL=$SQL.", vpisal='". $VUporabnik ."', datumvpisa='". $Danes->format('Y-m-d H:i:s') ."',EvidSt='".$VEvidSt[$Indx]."'";
                        $SQL=$SQL.",nadarjen=".$VNadarjen[$Indx].",StatusSport=".$VStatusSport[$Indx].",statusKult=".$VStatusKult[$Indx];
                        $SQL=$SQL.",RazredniIzpit=".$VRazredniIzpit[$Indx].",napredovanje=".$VNapredovanje[$Indx].",DatumIzdaje='".$VDatumIzdaje[$Indx]."',Opomba='".$VOpomba[$Indx]."'";
                        $SQL=$SQL." WHERE IdUcenec=". $ucenci[$Indx] ." AND leto=".$VLeto;
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                        
                        $SQL="UPDATE tabucenci SET emso='".$VEmso[$Indx]."',MaticniList='".$VMaticna[$Indx]."' WHERE idUcenec=". $ucenci[$Indx];
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />$SQL<br />");
                        }
                        
                        if (($VNapredovanje[$Indx]==0) && ($VRazred1==9) ){
                            $SQL="UPDATE tabucenci SET Aktivnost=5,KonSolanja='".$VDatumIzdaje[$Indx]."',KonSolanjaSola='".$VDatumIzdaje[$Indx]."' WHERE idUcenec=". $ucenci[$Indx];
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu!<br />$SQL<br />");
                            }
                        }else{
                            if ($VRazred1 == 9 ){
                                $SQL="UPDATE tabucenci SET Aktivnost=1,KonSolanja='',KonSolanjaSola='' WHERE idUcenec=". $ucenci[$Indx];
                                if (!($result = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu!<br />$SQL<br />");
                                }
                            }
                        }
                    }
                }

                if ($Opravila==1 ){
                    $SQL = "SELECT * FROM tabrazred WHERE idrazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Ucitelj=$R["IdUcitelj"];
                    }else{
                        $Ucitelj=0;
                    }
                    
                    $SQL = "SELECT tabdogodek.*,tabdeldogodek.*,tabdeldogodek.id AS did FROM ";
                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vpis statusov, napredovanja, popravnih izpitov' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VDogodki[$Indx]=$R["did"];
                        $Indx=$Indx+1;
                    }
                    $StDogodkov=$Indx-1;

                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('d.m.Y')."' WHERE id=".$VDogodki[$Indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }

                header ("Location: izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto);
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }
            break;
        case "9": //popravi ocene
            $PredmetPopravi=$_GET["predmet"];

            //Izpis osebnih podatkov
            $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Dodajanje ocen:</h2>";
                $Datum=new DateTime(isDate($R["DatRoj"]));
                echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b><br />";
            }

            $SQL = "SELECT tabrazred.*, tabrazdat.*,tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM ";
            $SQL = $SQL . "((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE idUcenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov
            echo "<br /><table border=1>";
            echo "<th>Leto</th><th>Razred</th><th>Uspeh</th><th>Ponavljalec</th><th>Leto šolanja</th><th>Učitelj</th><th>Vzgojitelj</th>";
            $Indx=0;
            if ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$R["leto"]."/".($R["leto"]+1)."</td><td><a href='izpisrazreda.php?solskoleto=".$R["leto"]."&razred=".$R["idRazred"]."'>".$R["razred"].". ". $R["oznaka"]."</td><td>".$R["Uspeh"]."</td><td>".$R["Ponavljalec"]."</td><td>".$R["LetoSolanja"]."</td><td>".$R["upriimek"]." " .$R["uime"]."</td><td>".$R["vpriimek"]." ". $R["vime"]."</td></tr>";
                $Razredi[$Indx][0] = $R["leto"];
                $Razredi[$Indx][1] = $R["razred"];
                $Razredi[$Indx][2] = $R["oznaka"];
                $Razredi[$Indx][3] = $R["osemdevet"];
                $Razredi[$Indx][4] = $R["IdUcitelj"];
                $VRazred1=$R["razred"];
            }
            $SteviloRazredov=$Indx;
            echo "</table>";

            if ($VRazred1 < 4 ){
                echo "<p>Pri opisnem ocenjevanju lahko vpišete praktično poljubno število znakov v vsako od polj za ocenjevanje.</p>";
            }else{
                echo "<p>Za negativno oceno v polletju ali ob koncu leta lahko uporabite 1 ali Ni opravil. Ni opravil je sicer mišljeno za opisno oceno, program pa bo spoznal obe izbiri kot nedoseganje minimalnih standardov.</p>";
            }
            //Izpis predmetnih podatkov

            $SQL = "SELECT * FROM tabpredmeti";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VPredmeti[$R["Id"]][0] = $R["Id"];
                $VPredmeti[$R["Id"]][1] = $R["Oznaka"];
                $VPredmeti[$R["Id"]][2] = $R["Opis"];
                $VPredmeti[$R["Id"]][3] = $R["Prioriteta"];




                $Indx=$Indx+1;
            }

            $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$PredmetPopravi." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $VOcenaS1P=$R["OcenaS1P"];
                $VOcenaS2P=$R["OcenaS2P"];
                $VOcenaS1U=$R["OcenaS1U"];
                $VOcenaS2U=$R["OcenaS2U"];
                $VOcenaKoncna=$R["OcenaKoncna"];
                $VOcenaPolletna=$R["OcenaPolletna"];
                $VNeocenjen=$R["Neocenjen"];
                $VPopravni=$R["Popravni"];
            }else{
                $VOcenaS1P="";
                $VOcenaS2P="";
                $VOcenaS1U="";
                $VOcenaS2U="";
                $VOcenaKoncna="";
                $VOcenaPolletna="";
                $VNeocenjen=0;
                $VPopravni=0;
            }
            
            echo "<form  name='UcenecOcene' method=post action='vnesiocene.php'>";
            echo "<table border='1'>";
            echo "<th>Predmet</th><th>Pisna ocena</th><th>Ustna ocena</th><th>Polletna</th><th>Zaključeno</th><th>Ocenjen</th><th>Popravni</th>";
            echo "<tr>";
            echo "<td><input name='predmet' type='hidden' value=".$PredmetPopravi.">".$VPredmeti[$PredmetPopravi][1]." - ".$VPredmeti[$PredmetPopravi][2]."</td>";
            if ($VRazred1 > 2 ){
                echo "<td>1. semester<input name='OcenaS1P' type='text' value='".$VOcenaS1P."'><br />";
                echo "2. semester<input name='OcenaS2P' type='text' value='".$VOcenaS2P."'></td>";
                echo "<td><input name='OcenaS1U' type='text' value='".$VOcenaS1U."'><br />";
                echo "<input name='OcenaS2U' type='text' value='".$VOcenaS2U."'></td>";
            }else{
                echo "<td>1. semester<textarea name='OcenaS1P' cols='20' rows='3'>".$VOcenaS1P."</textarea><br />";
                echo "2. semester<textarea name='OcenaS2P' cols='20' rows='3'>".$VOcenaS2P."</textarea></td>";
                echo "<td><textarea name='OcenaS1U' cols='20' rows='3'>".$VOcenaS1U."</textarea><br />";
                echo "<textarea name='OcenaS2U'  cols='20' rows='3'>".$VOcenaS2U."</textarea></td>";
            }
            echo "<td><select name='OcenaPolletna'>";
            switch ( $VOcenaPolletna){
                case "5";
                    echo "<option selected>5</option>";
                    break;
                case "4":
                    echo "<option selected>4</option>";
                    break;
                case "3":
                    echo "<option selected>3</option>";
                    break;
                case "2":
                    echo "<option selected>2</option>";
                    break;
                case "1":
                    echo "<option selected>1</option>";
                    break;
                default:
                    echo "<option selected> </option>";
            }
            //echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option> </option></select></td>";
            echo "<option>1</option><option> </option></select></td>";
            echo "<td><select name='OcenaKoncna'>";
            switch ( $VOcenaKoncna){
                case "5";
                    echo "<option selected>5</option>";
                    break;
                case "4":
                    echo "<option selected>4</option>";
                    break;
                case "3":
                    echo "<option selected>3</option>";
                    break;
                case "2":
                    echo "<option selected>2</option>";
                    break;
                case "1":
                    echo "<option selected>1</option>";
                    break;
                default:
                    echo "<option selected> </option>";
            }
            echo "<option>5</option><option>4</option><option>3</option><option>2</option><option>1</option><option> </option></select></td>";
            echo "<td>";
            switch ( $VNeocenjen){
                case 0:
                    echo "<select name='neocenjen'><option value=0 selected>Ocenjeno</option><option value=1>Neocenjeno</option><option value=2>Opravičeno</option>";
                    break;
                case 1:
                    echo "<select name='neocenjen'><option value=1 selected>Neocenjeno</option><option value=0>Ocenjeno</option><option value=2>Opravičeno</option>";
                    break;
                case 2:
                    echo "<select name='neocenjen'><option value=2 selected>Opravičeno</option><option value=0>Ocenjeno</option><option value=1>Neocenjeno</option>";
            }
            echo "</select></td>";
            echo "<td>";
            switch ( $VPopravni){
                case 0:
                    echo "<select name='popravni'><option value=0 selected>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                    break;
                case 1:
                    echo "<select name='popravni'><option value=0>Ni popravnega izpita</option><option value=1 selected>Popravni izpit</option><option value=2>Predmetni izpit</option>";
                    break;
                case 2:
                    echo "<select name='popravni'><option value=0>Ni popravnega izpita</option><option value=1>Popravni izpit</option><option value=2 selected>Predmetni izpit</option>";
            }
            echo "</select></td>";
            echo "</tr></table>";
            
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='iducenec' type='hidden' value='".$ucenec."'>";
            /*
            echo "<input name='level' type='hidden' value='".VLevel."'>"
            echo "<input name='geslo' type='hidden' value='".VGeslo."'>"
            echo "<input name='uporabnik' type='hidden' value='".VUporabnik."'>"
            */
            echo "<input name='id' type='hidden' value='10'>";
            echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";
        
            break;
        case "10": //vpis ocene
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                $VPredmet=$_POST["predmet"];
                $VOcenaS1P=$_POST["OcenaS1P"];
                $VOcenaS1U=$_POST["OcenaS1U"];
                $VOcenaS2P=$_POST["OcenaS2P"];
                $VOcenaS2U=$_POST["OcenaS2U"];
                $VOcenaKoncna=$_POST["OcenaKoncna"];
                $VOcenaPolletna=$_POST["OcenaPolletna"];
                $VNeocenjen=$_POST["neocenjen"];
                if (is_numeric($VOcenaKoncna)){
                    $VNeocenjen=0;
                }
                $VPopravni=$_POST["popravni"];

                //Izpis predmetnih podatkov

                $SQL = "SELECT * FROM tabocene WHERE IdPredmet=".$VPredmet." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabocene SET OcenaS1P='".$VOcenaS1P."',OcenaS1U='".$VOcenaS1U."',OcenaS2P='".$VOcenaS2P."',OcenaS2U='".$VOcenaS2U."',OcenaKoncna='".$VOcenaKoncna."',OcenaPolletna='".$VOcenaPolletna."',Neocenjen=".$VNeocenjen.",Popravni=".$VPopravni.",Datum='".$Danes->format('Y-m-d H:i:s')."',Vpisovalec='".$VUporabnik."' WHERE IdPredmet=".$VPredmet." AND leto=".$VLeto." AND IdUcenec=".$ucenec;
                }else{
                    $SQL = "INSERT INTO tabocene (Leto,IdUcenec,IdPredmet,OcenaS1P,OcenaS1U,OcenaS2P,OcenaS2U,OcenaKoncna,OcenaPolletna,Neocenjen,Popravni,Datum,Vpisovalec) values (" . $VLeto . "," . $ucenec . "," . $VPredmet . ",'" . $VOcenaS1P . "','" . $VOcenaS1U . "','" . $VOcenaS2P . "','" . $VOcenaS2U . "','" . $VOcenaKoncna . "','" . $VOcenaPolletna . "'," . $VNeocenjen . "," . $VPopravni . ",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                }
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu ocen!<br />$SQL<br />");
                }

                header ("Location: ucenec_pregled.php?ucenec=".$ucenec);
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }
            break;
        case "11": //brisanje ocene
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "DELETE FROM tabocene WHERE id=".$_GET["brisi"];
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju ocene!<br />$SQL<br />");
                }

                echo "<br />Uspešno ste izbrisali oceno!<br /><br />";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Vrni se na redovalnico</a><br />";
                echo "<a href='vnesiocene.php?id=5&razred=".$VRazred."&solskoleto=".$VLeto."&predmet=".$_GET["predmet"]."'>Vrni se na ocene predmeta</a><br />";
            }else{
                echo "<h2>Nimate dovoljenja za vpis/popravljanje podatkov</h2>";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice</a><br />";
            }
            break;
        case "12": //vpis samih zaključnih 5 za opisno ocenjevanje
            $DovoljenVpis=true;
            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
            $Interval=$Danes->diff($MejniDatum);
            if ($Interval->invert > 0){
                if ($VLevel < 3){
                    $DovoljenVpis=false;
                }
            }
            if ($DovoljenVpis){    
                $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
                $result = mysqli_query($link,$SQL);
                $i=1;
                while ($R = mysqli_fetch_array($result)){
                    $ucenci[$i]=$R["iducenec"];
                    $i += 1;
                }
                $StUcencev=$i-1;
                for ($i=1;$i <= $StUcencev;$i++){
                    $oUcenec=new RUcenec();
                    $oUcenec->getUcenec($ucenci[$i]);
                    $predmeti=$oUcenec->getPredmeti($VLeto);
                    
                    for ($j=0;$j < count($predmeti);$j++){
                        $SQL = "SELECT id FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$ucenci[$i]." AND idpredmet=".$predmeti[$j]["id"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabocene SET ocenakoncna='5',datum='".$Danes->format('Y-m-d H:i:s')."',vpisovalec='".$VUporabnik."' WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabocene (leto,iducenec,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u,neocenjen,popravni,ocenakoncna,ocenapolletna,datum,vpisovalec) VALUES (";
                            $SQL .= $VLeto.",".$ucenci[$i].",".$predmeti[$j]["id"].",'','','','',0,0,'5','','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                        }
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu zaključne ocene!<br />$SQL<br />");
                        }
                    }
                }
            }
            header("Location: izpisredovalnice.php?id=4&razred=".$VRazred);
            break;
    }
}
?>

</body>
</html>
