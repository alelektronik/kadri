<script type="text/javascript">
<!--

var timeOut=30; //min do poteka
var pTimer;
var tmpTimer;
var maxTimer = timeOut*60*1000;
var blnStopTimer = 0;
var ip = ''+"<?php echo $_SERVER['HTTP_HOST']; ?>";    
var host = 'https';

//document.write("testna vrednost");

InitTimer()

function InitTimer() {
   tmpTimer=maxTimer;
   pTimer = setInterval("DecreaseTimer()",1000)
}

function DecreaseTimer(ip,host) {
	if (blnStopTimer == 0) {
		tmpTimer=tmpTimer-1000;
		var toF = tmpTimer/60000;
		var toFs = (tmpTimer % 60000)/1000;
        if (toFs < 10){
		    document.getElementById("btnTimer").value="Do konca seanse je še " + parseInt(toF)+ ":0" +toFs.toString() + " min";
        }else{
            document.getElementById("btnTimer").value="Do konca seanse je še " + parseInt(toF)+ ":" +toFs.toString() + " min";
        }
		if (tmpTimer<=0) {
			LogOut();
		}
	}
}

function btnTimerClick(form) {
	blnStopTimer = !(blnStopTimer);
	if (blnStopTimer) {
		document.getElementById("btnTimer").value="Časovnik ustavljen";
	}
}

function LogOut() {
	// alarm("Časovna seansa je potekla...");
    clearInterval(pTimer);
	document.getElementById("btnTimer").value="Seansa je potekla!";
    window.location = host+"://"+ip+"/Izhod.php";

}

function ResetTimer() {
	tmpTimer = maxTimer;
}

//
//-->
</script>



