<?php
/*
Program za obdelavo 
    e-dnevnika (100)
    urne odsotnosti otrok (200)
    urnih opomb otrokom (300)
    vnosa dežurnih učencev (400)

e-dnevnik:
    - pripravijo se podatki s prenosa
    1. vpis dnevniškega zapisa (nov ali popravek obstoječega)
    2. vpis popravka dnevniškega zapisa
    3. izpis dnevniških poročil učitelja
    4. izpis tedenskega dnevnika razreda
    5. brisanje dnevniškega zapisa
    6. vnos določene ure za določen razred s klicem iz razrednega tedenskega pregleda
    7. iskanje učencev, ki so pri določeni uri (iz dnevnika, skupin, ...)
    8. izpis dnevniških zapisov za določen pouk
    9. izpis vseh dnevniških zapisov za določen mesec
    10. vpis ocen v redovalnico
    11. izpis tedenskega dnevnika učitelja
    12. prenos dnevnih priprav
    - izpis obrazca za vnos dnevniškega zapisa
    
Odsotnost otrok:
    1. vpis odsotnosti
    2. popravljanje odsotnosti
    2a. vpis popravka
    3. vse odsotnosti učenca
    3a. odsotnosti učenca na določen dan
    4. vpis sprememb statusov odsotnosti
    5. izpis odsotnosti razreda
    - obrazec za vpis odsotnosti
    
Opombe otrokom:
    1. vpis opomb
    2. popravljanje opomb
    2a. vpis popravka
    3. vse opombe učenca
    3a. opombe učenca na določen dan
    4. brisanje opombe
    5. izpis opomb razreda
    6. izpis opomb določenega učitelja
    - obrazec za vpis opomb

Dežurni učenci:
    obrazec za izbor dežurnih učencev za določen mesec

Tabele:
    tabucenci
    tabrazred
    tabopb
    tabizbirni
    tabnivoji
    tabrazdat
    tabpredmeti
    tabucitelji
    tabdnevnik
    tabdnevniku
    tabdnevnikr
    tabdnevnikure
    tabprisotnost
    tabopombeuc
    tabocene
    tabucenje
    tabdezurniuc
    
*/

require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>e-Dnevnik
</title>
<style>
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
$UrNaDan=10;
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $IdUcitelj=$R["iducitelj"];
    $VUporabnikId=$Ucitelj;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if ($VLeto > 2012){
    $OznakaSport="20";
    $SQL = "SELECT id,oznaka FROM tabpredmeti WHERE oznaka like 'ŠPO%'";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if (mb_substr($R["oznaka"],0,3,$encoding)=="ŠPO"){
            $OznakaSport=$R["id"];
        }
    }
}else{
    $OznakaSport="20";
}
function ClearBlank($x){
    if (strlen($x) > 0){
        $x=str_replace("&nbsp;","",$x);
    }
    return $x;
}
function vsebuje($s,$a){
    //ali niz števil ločenih z vejico $s vsebuje število $a
    $sarr=explode(",",$s);
    for ($i=0;$i < count($sarr);$i++){
        if (intval($a)==intval($sarr[$i])){
            return true;
        }
    }
    return false;
}
function Arr2Str($a){
    $s="";
    if (is_array($a)){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }else{
        return $a;
    }
    return $s;
}
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["idd"])){
    $VNacin = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VNacin=$_GET["idd"];
    }else{
        $VNacin = 100;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}
if (isset($_POST["ucitelj"])){
    $VUcitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $VUcitelj=$_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){
            $VUcitelj=$_SESSION["ucitelj"];
        }else{
            $VUcitelj = 0;
        }
    }
}

function Nivo2Skupina($x){
    switch ($x){
        case 2:
        case 6:
        case 10:
            return 1;
        case 3:
        case 7:
        case 11:
            return 2;
        case 4:
        case 8:
        case 12:
            return 3;
        case 13:
        case 16:
        case 19:
            return 7; // '4. skupina
        case 14:
        case 17:
        case 20:
            return 8; // '5. skupina
        case 15:
        case 18:
        case 21:
            return 9; // '6. skupina
        default:
            return 0; // 'samostojen predmet
    }
}

function Skupina2Nivo($x,$p){
    switch ($x){
        case 1:
            //'Skupina2Nivo="2,6,10"
            if (is_numeric(strpos($p,"11"))) return 2;
            if (is_numeric(strpos($p,"16"))) return 6;
            if (is_numeric(strpos($p,"26"))) return 10;
        case 2:
            //'Skupina2Nivo="3,7,11"
            if (is_numeric(strpos($p,"11"))) return 3;
            if (is_numeric(strpos($p,"16"))) return 7;
            if (is_numeric(strpos($p,"26"))) return 11;
        case 3:
            //'Skupina2Nivo="4,8,12"
            if (is_numeric(strpos($p,"11"))) return 4;
            if (is_numeric(strpos($p,"16"))) return 8;
            if (is_numeric(strpos($p,"26"))) return 12;
        case 7:
            //'Skupina2Nivo="13,16,19"
            if (is_numeric(strpos($p,"11"))) return 13;
            if (is_numeric(strpos($p,"16"))) return 16;
            if (is_numeric(strpos($p,"26"))) return 19;
        case 8:
            //'Skupina2Nivo="14,17,20"
            if (is_numeric(strpos($p,"11"))) return 14;
            if (is_numeric(strpos($p,"16"))) return 17;
            if (is_numeric(strpos($p,"26"))) return 20;
        case 9:
            //'Skupina2Nivo="15,18,21"
            if (is_numeric(strpos($p,"11"))) return 15;
            if (is_numeric(strpos($p,"16"))) return 18;
            if (is_numeric(strpos($p,"26"))) return 21;
    }
}

function ToNivo($x){
    switch ($x){
        case 0:
            return "Sam. pr.";
        case 1:
            return "1. sk.";
        case 2:
            return "2. sk.";
        case 3:
            return "3. sk.";
        case 4:
            return "Izb.";
        case 5:
            return "PB";
        case 6:
            return "Drugo";
        case 7:
            return "4. sk.";
        case 8:
            return "5. sk.";
        case 9:
            return "6. sk.";
        default:
            return "Sam. pr.";
    }
}

function ToNivo2($x){
    switch ($x){
        case 0:
            return "";
        case 1:
            return "1";
        case 2:
            return "2";
        case 3:
            return "3";
        case 4:
            return "";
        case 5:
            return "";
        case 6:
            return "";
        case 7:
            return "4";
        case 8:
            return "5";
        case 9:
            return "6";
        default:
            return "";
    }
}
function ToSkupina($x){
    switch ($x){
        case 1:
            return "1";
        case 2:
            return "2";
        case 3:
            return "3";
        case 4:
            return "7";
        case 5:
            return "8";
        case 6:
            return "9";
        case 101: //izbirni
            return "4";
        case 102: //PB
            return "5";
        case 103: //drugo
            return "6";
        default:
            return "0";
    }
}

function SolskiDan($x,$sl){
    //$x - datum
    //$sl - šolsko leto
    global $link;
    
    $stDni=0;
    $dan=new DateTime($sl."-8-31");
    $dstart=new DateTime($sl."-9-1");
    $dend=new DateTime(($sl+1)."-6-25");
    $Interval1=$x->diff($dstart);
    $Interval2=$x->diff($dend);
    //if (dateDiff("d",x,"1.9."&cstr(sl)) <= 0) and (dateDiff("d",x,"25.6."&cstr(sl+1)) > 0) then
    if (($Interval1->invert==1) && ($Interval2->invert==0)){
        //'če je dan med 1.9. in 25.6.
        //'pogleda ali je konkreten dan slučajno kakšen dan, ki ne šteje med dni pouka
        $racunaj=false;
        switch ($x->format('w')){
            case 6: //'če je sobota
                $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$x->format('j')." AND month(datum)=".$x->format('n')." AND year(datum)=".$x->format('Y');
                $result2 = mysqli_query($link,$SQL);
                if ($R2 = mysqli_fetch_array($result2)){
                    if ($R2["kat"]==2){
                        $racunaj=true; // 'delovna sobota
                    }
                }else{
                    $stDni=0;
                }
                break;
            case 1:
            case 2:
            case 3:
            case 4:
            case 5: // 'če je delovnik
                $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$x->format('j')." AND month(datum)=".$x->format('n')." AND year(datum)=".$x->format('Y');
                $result2 = mysqli_query($link,$SQL);
                if ($R2 = mysqli_fetch_array($result2)){
                    switch ($R2["kat"]){
                        case 0:
                        case 1:
                        case 3:
                            $stDni=0; // 'praznik, počitnice, prost dan
                            break;
                        default:
                            $racunaj=true;
                    }
                }else{
                    $racunaj=true;
                }
                break;
            default: //'če je nedelja
                $stDni=0;
        }
        
        if ($racunaj){
            //'če naj za ta dan računa zaporedni dan pouka
            while (1){
                $dan=$dan->add(new DateInterval('P1D'));
                $Interval=$dan->diff($x);
                if ($Interval->invert == 0){
                    //'šteje dneve od dan do vključno datuma x
                    $wday=$dan->format('w');
                    switch ($dan->format('w')){
                        case 6:
                            $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$dan->format('j')." AND month(datum)=".$dan->format('n')." AND year(datum)=".$dan->format('Y');
                            $result2 = mysqli_query($link,$SQL);
                            if ($R2 = mysqli_fetch_array($result2)){
                                if ($R2["kat"]==2){
                                    $stDni=$stDni+1; //'delovna sobota
                                }
                            }
                            break;
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                            $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$dan->format('j')." AND month(datum)=".$dan->format('n')." AND year(datum)=".$dan->format('Y');
                            $result2 = mysqli_query($link,$SQL);
                            if ($R2 = mysqli_fetch_array($result2)){
                                switch ($R2["kat"]){
                                    case 0:
                                    case 1:
                                    case 3:
                                        $stDni=$stDni;
                                        break; // 'praznik, počitnice, prost dan
                                    default:
                                        $stDni=$stDni+1;
                                }
                            }else{
                                $stDni=$stDni+1; // 'običajen delovni dan
                            }
                    }
                }else{
                    break;
                }
            }
        }
    }
    return $stDni;
}

function IzpisUrnihPodatkov(){
    global $link;
    global $VDatum;
    global $VUra;
    global $Count;
    global $VPredmeti;
    global $StPredmetov;
    global $VSkupina;
    global $VRazredi;
    global $StRazredov;
    global $VUcitelji;
    global $StUciteljev;
    global $VZapStUre;
    global $VStatusUre;
    global $VOpombe;
    global $VNaloge;
    global $VPriprava;
    global $VPriprave;
    global $StPriprav;
    global $VRefSt;
    global $refst;
    global $StRefSt;
    global $VLevel;
    global $IzDnevnika;
    global $VZapStUre;
    global $VStatusUre;
    global $VSedRed;
    global $sedred;
    global $StSedRed;
    global $VecSol;
    
    $h1=30;
    $h2=80;
    $h3=60;
    //'izpis podatkov za uro
    echo "<form name='dnevnik' method='POST' action='dnevnik.php'>";
    echo "<input name='idd' type='hidden' value='100'>";
    echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
    echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
    echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
    echo "<input name='ura' type='hidden' value='".$VUra."'>";
    echo "<table border='1' cellspacing='0'>";
    
    echo "<tr><td valign='top'><table border='0'>";

    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Predmet</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Skupina</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='lightcyan'>Razred</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='lightcyan'>Učitelj(i)</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Zap.št.ure</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Status</td></tr>";
    echo "<tr><td height='".$h3."' bgcolor='lightcyan'>Dn. zapis</td></tr>";
    echo "<tr><td height='".$h3."' bgcolor='lightcyan'>Dom. naloga</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Priprava</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'><a href='sedeznired.php'>Sed. red</a></td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>Ref.št.</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightcyan'>&nbsp;</td></tr>";
    
    echo "</table></td><td valign='top'><table border='0'>";
    
    echo "<tr>";
    if ($Count[3] > 1){
        echo "<td bgcolor='lightsalmon' height='".$h1."'>";
    }else{
        echo "<td height='".$h1."' bgcolor='lightyellow'>";
    }
    
    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
        if ($VPredmeti[$Indx][2]==1){
            echo $VPredmeti[$Indx][1]."<br />";
        }
    }
    if ($Count[3] > 1){
        echo "<b>Izberite samostojno uro!</b>";
    }
    echo "</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    echo ToNivo($VSkupina);
    echo "</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='lightyellow'>";
    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        if ($VRazredi[$Indx][2]==1){
            echo "<a href='dnevnik.php?idd=100&id=4&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letod=".$VDatum->format('Y')."&idrazred=".$VRazredi[$Indx][0]."'>".$VRazredi[$Indx][1]."</a><br />";
        }
    }
    echo "</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='lightyellow'>";
    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
        if ($VUcitelji[$Indx][2]==1){
            echo $VUcitelji[$Indx][1]."<br />";
        }
    }
    echo "</td></tr>";
    
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    echo $VZapStUre;
    echo "</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    $SQL = "SELECT * FROM tabsifrantstatusure WHERE idStatusure=".$VStatusUre;
    $result1 = mysqli_query($link,$SQL);
    if ($R1 = mysqli_fetch_array($result1)){
        echo $R1["opis"];
    }else{
        echo "&nbsp;"; // 'status
    }

    echo "</td></tr>";
    echo "<tr><td height='".$h3."' bgcolor='lightyellow'>";
    echo $VOpombe; // 'opombe
    echo "</td></tr>";

    echo "<tr><td height='".$h3."' bgcolor='lightyellow'>";
    echo $VNaloge; // 'naloge
    echo "</td></tr>";

    // 'priprava
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    if ($VPriprava > 0){
        for ($Indx=1;$Indx <= $StPriprav;$Indx++){
            if ($VPriprave[$Indx][0]==$VPriprava){
                echo "<a href='upload/priprave/".$VPriprave[$Indx][1]."' target='_blank'>".$VPriprave[$Indx][1]."</a>";
            }
        }
    }
    echo "</td></tr>";

    // 'sedežni red
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    if ($StSedRed > 0){
        for ($Indx=1;$Indx <= $StSedRed;$Indx++){
            if ($sedred[$Indx]["id"]==$VSedRed){
                echo $sedred[$Indx]["opomba"];
            }
        }
    }
    echo "</td></tr>";
    
    // 'ref.št.
    echo "<tr><td height='".$h1."' bgcolor='lightyellow'>";
    if ($VRefSt > 0){
        for ($Indx=1;$Indx <= $StRefSt;$Indx++){
            if ($refst[$Indx]["id"]==$VRefSt){
                echo "(".$refst[$Indx]["id"].") ".$refst[$Indx]["oznaka"].".".$refst[$Indx]["skupina"]."-".$refst[$Indx]["razred"]." ".$refst[$Indx]["ucitelj"];
            }
        }
    }
    echo "</td></tr>";
    
    if ($VLevel > 1){
        if ($IzDnevnika > 0){
            echo "<tr><td height='".$h1."' bgcolor='lightyellow'><a href='dnevnik.php?idd=100&id=5&izdnevnika=".$IzDnevnika."'>Briši</a></td></tr>";
        }else{
            echo "<tr><td height='".$h1."' bgcolor='lightyellow'>&nbsp;</td></tr>";
        }
    }else{
        echo "<tr><td height='".$h1."' bgcolor='lightyellow'>&nbsp;</td></tr>";
    }
    
    echo "</table></td><td valign='top'><table border='0'>";
    
    //'izpis nastavitev za uro
    echo "<tr>";
    if ($Count[3] > 1){
        echo "<td bgcolor='lightsalmon' height='".$h1."'><b>Izberite samo en predmet!</b><br />";
    }else{
        echo "<td height='".$h1."' bgcolor='springgreen'>";
    }
    echo "<select name='predmet'>";
    echo "<option value='0'>Ni izbran</option>";
    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
        if ($VPredmeti[$Indx][2]==1){
            echo "<option value='".$VPredmeti[$Indx][0]."' selected='selected'>".$VPredmeti[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VPredmeti[$Indx][0]."'>".$VPredmeti[$Indx][1]."</option>";
        }
    }
    
    echo "</select>";
    echo "</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<select name='nivo'>";
    for ($Indx=0;$Indx <=9;$Indx++){
        if ($Indx==$VSkupina){
            echo "<option value='".$Indx."' selected='selected'>".ToNivo($Indx)."</option>";
        }else{
            echo "<option value='".$Indx."'>".ToNivo($Indx)."</option>";
        }
    }
    echo "</select>";
    
    echo "</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='springgreen'>";
    echo "<select name='razred[]' multiple='multiple'>";
    if ($VecSol > 0){
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VRazredi[$Indx][3];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $sola=$R["solakratko"];
            }else{
                $sola="";
            }
            if ($VRazredi[$Indx][2]==1){
                echo "<option value='".$VRazredi[$Indx][0]."' selected='selected'>".$VRazredi[$Indx][1]." ".$sola."</option>";
            }else{
                echo "<option value='".$VRazredi[$Indx][0]."'>".$VRazredi[$Indx][1]." ".$sola."</option>";
            }
        }
    }else{
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            if ($VRazredi[$Indx][2]==1){
                echo "<option value='".$VRazredi[$Indx][0]."' selected='selected'>".$VRazredi[$Indx][1]."</option>";
            }else{
                echo "<option value='".$VRazredi[$Indx][0]."'>".$VRazredi[$Indx][1]."</option>";
            }
        }
    }
    echo "</select>";
    echo "</td></tr>";
    echo "<tr><td height='".$h2."' bgcolor='springgreen'>";
    echo "<select name='ucitelj[]' multiple='multiple' size='2'>";
    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
        if ($VUcitelji[$Indx][2]==1){
            echo "<option value='".$VUcitelji[$Indx][0]."' selected='selected'>".$VUcitelji[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VUcitelji[$Indx][0]."'>".$VUcitelji[$Indx][1]."</option>";
        }
    }
    echo "</select>";
    echo "</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<input name='zapsture' type='text' size='4' value='".$VZapStUre."'>";
    echo "</td></tr>";
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<select name='status'>";
    $SQL = "SELECT * FROM tabsifrantstatusure";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if ($R["idStatusUre"]==$VStatusUre){
            echo "<option value='".$R["idStatusUre"]."' selected='selected'>".$R["opis"]."</option>";
        }else{
            echo "<option value='".$R["idStatusUre"]."'>".$R["opis"]."</option>";
        }
    }
    echo "</select>";
    
    echo "</td></tr>";
    echo "<tr><td height='".$h3."' bgcolor='springgreen'>";
    echo "<textarea name='opombe' cols='20' rows='2'>".$VOpombe."</textarea>"; //'opombe
    echo "</td></tr>";
    echo "<tr><td height='".$h3."' bgcolor='springgreen'>";
    echo "<textarea name='opombe' cols='20' rows='2'>".$VNaloge."</textarea>"; //'opombe
    echo "</td></tr>";
    
    //priprave
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<select name='priprava'>";
    for ($Indx=0;$Indx <= $StPriprav;$Indx++){
        if ($VPriprave[$Indx][0]==$VPriprava){
            echo "<option value='".$VPriprave[$Indx][0]."' selected='selected'>".$VPriprave[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VPriprave[$Indx][0]."'>".$VPriprave[$Indx][1]."</option>";
        }
    }
    echo "</select>";
    echo "</td></tr>";
    
    //sedežni red
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<select name='sedred'>";
    echo "<option value='0'>Ni izbrano</option>";
    for ($Indx=1;$Indx <= $StSedRed;$Indx++){
        if ($sedred[$Indx]["id"]==$VSedRed){
            echo "<option value='".$sedred[$Indx]["id"]."' selected='selected'>".$sedred[$Indx]["opomba"]."</option>";
        }else{
            echo "<option value='".$sedred[$Indx]["id"]."'>".$sedred[$Indx]["opomba"]."</option>";
        }
    }
    echo "</select>";
    echo "</td></tr>";
    
    //ref.št.
    echo "<tr><td height='".$h1."' bgcolor='springgreen'>";
    echo "<select name='refst'>";
    echo "<option value='0'>Ni izbrano</option>";
    for ($Indx=1;$Indx <= $StRefSt;$Indx++){
        if ($refst[$Indx]["id"]==$VRefSt){
            echo "<option value='".$refst[$Indx]["id"]."' selected='selected'>"."(".$refst[$Indx]["id"].") ".$refst[$Indx]["oznaka"].".".$refst[$Indx]["skupina"]."-".$refst[$Indx]["razred"]." ".$refst[$Indx]["ucitelj"]."</option>";
        }else{
            echo "<option value='".$refst[$Indx]["id"]."'>"."(".$refst[$Indx]["id"].") ".$refst[$Indx]["oznaka"].".".$refst[$Indx]["skupina"]."-".$refst[$Indx]["razred"]." ".$refst[$Indx]["ucitelj"]."</option>";
        }
    }
    echo "</select>";
    echo "</td></tr>";

    //'gumb za iskanje učencev
    echo "<tr><td height='".$h1."' bgcolor='springgreen'><input name='submit' type='submit' value='Poišči učence' /></td>";
    
    echo "</tr>";
    echo "</table></td></tr>";

/*                
    echo "<tr bgcolor='SkyBlue'><th>Predmet</th><th>Skupina</th><th>Razred</th><th>Učitelj</th><th>Zap.št.ure</th><th>Status</th><th>Opombe</th><th>Priprava</th></tr>";
    echo "<tr bgcolor='lightyellow'>";
    if ($Count[3] > 1){
        echo "<td bgcolor='lightsalmon'>";
    }else{
        echo "<td>";
    }
    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
        if ($VPredmeti[$Indx][2]==1){
            echo $VPredmeti[$Indx][1]."<br />";
        }
    }
    if ($Count[3] > 1){
        echo "<b>Izberite samostojno uro!</b>";
    }
    echo "</td><td>";
    echo ToNivo($VSkupina);
    echo "</td><td>";
    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        if ($VRazredi[$Indx][2]==1){
            echo "<a href='dnevnik.php?idd=100&id=4&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letod=".$VDatum->format('Y')."&idrazred=".$VRazredi[$Indx][0]."'>".$VRazredi[$Indx][1]."</a><br />";
        }
    }
    echo "</td><td>";
    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
        if ($VUcitelji[$Indx][2]==1){
            echo $VUcitelji[$Indx][1]."<br />";
        }
    }
    echo "</td><td>";
    echo $VZapStUre;
    echo "</td><td>";
    $SQL = "SELECT * FROM tabsifrantstatusure WHERE idStatusure=".$VStatusUre;
    $result1 = mysqli_query($link,$SQL);
    if ($R1 = mysqli_fetch_array($result1)){
        echo $R1["opis"];
    }else{
        echo "&nbsp;"; // 'status
    }

    echo "</td><td>";
    echo $VOpombe; // 'opombe
    
    echo "</td><td>";
    // 'priprava
    if ($VPriprava > 0){
        for ($Indx=1;$Indx <= $StPriprav;$Indx++){
            if ($VPriprave[$Indx][0]==$VPriprava){
                echo "<a href='upload/priprave/".$VPriprave[$Indx][1]."' target='_blank'>".$VPriprave[$Indx][1]."</a>";
            }
        }
    }
    echo "</td>";
    
    if ($VLevel > 1){
        if ($IzDnevnika > 0){
            echo "<td><a href='dnevnik.php?idd=100&id=5&izdnevnika=".$IzDnevnika."'>Briši</a></td>";
        }
    }
    
    echo "</tr>";
    
    //'izpis nastavitev za uro
    echo "<tr bgcolor='SpringGreen'>";
    if ($Count[3] > 1){
        echo "<td bgcolor='lightsalmon'><b>Izberite samo en predmet!</b><br />";
    }else{
        echo "<td>";
    }
    echo "<select name='predmet'>";
    echo "<option value='0'>Ni izbran</option>";
    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
        if ($VPredmeti[$Indx][2]==1){
            echo "<option value='".$VPredmeti[$Indx][0]."' selected='selected'>".$VPredmeti[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VPredmeti[$Indx][0]."'>".$VPredmeti[$Indx][1]."</option>";
        }
    }
    
    echo "</select>";
    echo "</td><td>";
    echo "<select name='nivo'>";
    for ($Indx=0;$Indx <=9;$Indx++){
        if ($Indx==$VSkupina){
            echo "<option value='".$Indx."' selected='selected'>".ToNivo($Indx)."</option>";
        }else{
            echo "<option value='".$Indx."'>".ToNivo($Indx)."</option>";
        }
    }
    echo "</select>";
    
    echo "</td><td>";
    echo "<select name='razred[]' multiple='multiple'>";
    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        if ($VRazredi[$Indx][2]==1){
            echo "<option value='".$VRazredi[$Indx][0]."' selected='selected'>".$VRazredi[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VRazredi[$Indx][0]."'>".$VRazredi[$Indx][1]."</option>";
        }
    }
    echo "</select>";
    echo "</td><td>";
    echo "<select name='ucitelj[]' multiple='multiple'>";
    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
        if ($VUcitelji[$Indx][2]==1){
            echo "<option value='".$VUcitelji[$Indx][0]."' selected='selected'>".$VUcitelji[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VUcitelji[$Indx][0]."'>".$VUcitelji[$Indx][1]."</option>";
        }
    }
    echo "</select>";
    echo "</td><td>";
    echo "<input name='zapsture' type='text' size='4' value='".$VZapStUre."'>";
    echo "</td><td>";
    echo "<select name='status'>";
    $SQL = "SELECT * FROM tabsifrantstatusure";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if ($R["idStatusUre"]==$VStatusUre){
            echo "<option value='".$R["idStatusUre"]."' selected='selected'>".$R["opis"]."</option>";
        }else{
            echo "<option value='".$R["idStatusUre"]."'>".$R["opis"]."</option>";
        }
    }
    echo "</select>";
    
    echo "</td><td>";
    echo "<textarea name='opombe' cols='20' rows='2'>".$VOpombe."</textarea>"; //'opombe
    echo "</td><td>";
    echo "<select name='priprava'>";
    for ($Indx=0;$Indx <= $StPriprav;$Indx++){
        if ($VPriprave[$Indx][0]==$VPriprava){
            echo "<option value='".$VPriprave[$Indx][0]."' selected='selected'>".$VPriprave[$Indx][1]."</option>";
        }else{
            echo "<option value='".$VPriprave[$Indx][0]."'>".$VPriprave[$Indx][1]."</option>";
        }
    }
    echo "</select>";
    echo "</td>";
    
    //'gumb za iskanje učencev
    echo "<td><input name='submit' type='submit' value='Poišči učence' /></td>";
    
    echo "</tr>";
*/                
    echo "</table>";
}

switch ($VNacin){
    case "100": //e-dnevnik
        $VUcitelj=Arr2Str($VUcitelj);
        $VRazred=Arr2Str($VRazred);
        if (!isset($VRazred)){
            $VRazred="";
        }
        if (isset($_POST["submit"])){;
            if ($_POST["submit"]=="Poišči učence"){
                $Vid="7";
            }
        }
        $VAktMin=$Danes->format('H')*60+$Danes->format('i');
        if (isset($_POST["ura"])){
            $VUra = $_POST["ura"];
        }else{
            if (isset($_GET["ura"])){
                $VUra=$_GET["ura"];
            }else{
                $VUra = -1;
            }
        }
        
        if ($VUra < 0){
            $SQL = "SELECT ura FROM tabdnevnikure WHERE zacetek >= ".$VAktMin." AND konec <= ".$VAktMin;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VUra=$R["ura"];
            }else{
                if ($Danes->format('H') >= 7){
                    $VUra=$Danes->format('H')-7;
                }else{
                    $VUra=0;
                }
            }
        }
        if (isset($_POST["dan"])){
            $VDan = $_POST["dan"];
        }else{
            if (isset($_GET["dan"])){
                $VDan=$_GET["dan"];
            }else{
                $VDan = $Danes->format('j');
            }
        }
        if (isset($_POST["mesec"])){
            $VMesec = $_POST["mesec"];
        }else{
            if (isset($_GET["mesec"])){
                $VMesec=$_GET["mesec"];
            }else{
                $VMesec = $Danes->format('n');
            }
        }
        if (isset($_POST["letod"])){
            $VLetoD = $_POST["letod"];
        }else{
            if (isset($_GET["letod"])){
                $VLetoD=$_GET["letod"];
            }else{
                $VLetoD = $Danes->format('Y');
            }
        }
        if (checkdate($VMesec,$VDan,$VLetoD)){
            $VDatum=new DateTime($VLetoD."-".$VMesec."-".$VDan);
        }else{
            $VDatum=new DateTime($Danes->format('Y-m-d'));
        }
        if (isset($_POST["zapsture"])){
            $VZapStUre = $_POST["zapsture"];
        }else{
            if (isset($_GET["zapsture"])){
                $VZapStUre=$_GET["zapsture"];
            }else{
                $VZapStUre = 1;
            }
        }
        if (isset($_POST["predmet"])){
            $VPredmet = $_POST["predmet"];
        }else{
            if (isset($_GET["predmet"])){
                $VPredmet=$_GET["predmet"];
            }else{
                $VPredmet = 0;
            }
        }
        $VPredmet=Arr2Str($VPredmet);
        if (!isset($VPredmet)){
            $VPredmet=0;
        }
        if (isset($_POST["nivo"])){
            $VNivo = $_POST["nivo"];
        }else{
            if (isset($_GET["nivo"])){
                $VNivo=$_GET["nivo"];
            }else{
                $VNivo = "";
            }
        }
        if (isset($_POST["opombe"])){
            $VOpombe = $_POST["opombe"];
        }else{
            if (isset($_GET["opombe"])){
                $VOpombe=$_GET["opombe"];
            }else{
                $VOpombe = "";
            }
        }
        $VOpombe=str_replace("'","&#39",$VOpombe);
        $VOpombe=str_replace(chr(34),"&#34",$VOpombe);
        
        if (isset($_POST["status"])){
            $VStatus = $_POST["status"];
        }else{
            if (isset($_GET["status"])){
                $VStatus=$_GET["status"];
            }else{
                $VStatus = "";
            }
        }

        if (isset($_POST["naloge"])){
            $VNaloge = $_POST["naloge"];
        }else{
            if (isset($_GET["naloge"])){
                $VNaloge=$_GET["naloge"];
            }else{
                $VNaloge = "";
            }
        }
        $VNaloge=str_replace("'","&#39",$VNaloge);
        $VNaloge=str_replace(chr(34),"&#34",$VNaloge);

        if (isset($_POST["stucencev"])){
            $StUcencev = $_POST["stucencev"];
        }else{
            if (isset($_GET["stucencev"])){
                $StUcencev=$_GET["stucencev"];
            }else{
                $StUcencev = 0;
            }
        }
        if (isset($_POST["izdnevnika"])){
            $IzDnevnika = $_POST["izdnevnika"];
        }else{
            if (isset($_GET["izdnevnika"])){
                $IzDnevnika=$_GET["izdnevnika"];
            }else{
                $IzDnevnika = 0;
            }
        }
        if (isset($_POST["idrazred"])){
            $idRazred = $_POST["idrazred"];
        }else{
            if (isset($_GET["idrazred"])){
                $idRazred=$_GET["idrazred"];
            }else{
                $idRazred = 0;
            }
        }
        if (isset($_POST["pouk"])){
            $VPouk = $_POST["pouk"];
        }else{
            if (isset($_GET["pouk"])){
                $VPouk=$_GET["pouk"];
            }else{
                $VPouk = 0;
            }
        }

        switch ( $Vid){
            case "1": // 'vpis v dnevnik (praviloma nov zapis)
                //'vpis splošnih podatkov
                $DovoljenVpis=false;
                if ($VLevel < 2){
                    if (vsebuje($VUcitelj,$IdUcitelj)){
                        $DovoljenVpis=true;
                    }else{
                        $SQL = "SELECT DISTINCT idrazred,iducitelj FROM tabrazred WHERE idRazred IN (".$VRazred.")";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            if ($IdUcitelj==$R1["iducitelj"]){
                                $DovoljenVpis=true;
                            }
                        }
                    }
                }else{
                    $DovoljenVpis=true;
                }
                    
                //'pogleda, če ima že vpisano

                if ($DovoljenVpis){
                    $SQL = "SELECT * FROM tabdnevnik WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                    $SQL = $SQL . " AND ura=".$VUra." AND ucitelj ='".$VUcitelj."'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'zapis obstaja - popravljanje
                        //'z ravnateljskimi pooblastili
                        $SQL = "UPDATE tabdnevnik SET ";
                        $SQL = $SQL . "razred='".$VRazred."'";
                        $SQL = $SQL . ",predmet=".$VPredmet;
                        $SQL = $SQL . ",skupina='".$VNivo."'";
                        $SQL = $SQL . ",ZapUra=".$VZapStUre;
                        $SQL = $SQL . ",opis='".$VOpombe."'";
                        $SQL = $SQL . ",naloge='".$VNaloge."'";
                        $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                        $SQL = $SQL . ",statusUre=".$VStatus;
                        if (isset($_POST["priprava"])){
                            $SQL = $SQL . ",idpriprava=".intval($_POST["priprava"]);
                        }else{
                            $SQL = $SQL . ",idpriprava=0";
                        }
                        if (isset($_POST["sedred"])){
                            $SQL = $SQL . ",idsedred=".intval($_POST["sedred"]);
                        }else{
                            $SQL = $SQL . ",idsedred=0";
                        }
                        if (isset($_POST["refst"])){
                            $SQL = $SQL . ",refid=".intval($_POST["refst"]);
                        }else{
                            $SQL = $SQL . ",refid=0";
                        }
                        $SQL = $SQL . ",spremenil=".$IdUcitelj;
                        $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["ID"];
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "<h2>Zapis je bil popravljen!</h2>";
                        }else{
                            echo "<h2>Napaka pri vpisu!</h2>";
                        }
                    }else{
                        //'nov zapis
                        $SQL = "INSERT INTO tabdnevnik (leto,datum,ura,razred,predmet,skupina,ZapUra,opis,naloge,ucitelj,statusUre,vpisal,casVp,idpriprava,idsedred,refid) VALUES (";
                        $SQL = $SQL . $VLeto;
                        $SQL = $SQL . ",'".$VDatum->format('Y-m-d')."'";
                        $SQL = $SQL . ",".$VUra;
                        $SQL = $SQL . ",'".$VRazred."'";
                        $SQL = $SQL . ",".$VPredmet;
                        $SQL = $SQL . ",'".$VNivo."'";
                        $SQL = $SQL . ",".$VZapStUre;
                        $SQL = $SQL . ",'".$VOpombe."'";
                        $SQL = $SQL . ",'".$VNaloge."'";
                        $SQL = $SQL . ",'".$VUcitelj."'";
                        $SQL = $SQL . ",".$VStatus;
                        $SQL = $SQL . ",".$IdUcitelj;
                        $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                        if (isset($_POST["priprava"])){
                            if (strlen($_POST["priprava"]) > 0){
                                $SQL = $SQL . ",".intval($_POST["priprava"]);
                            }else{
                                $SQL = $SQL . ",0";
                            }
                        }else{
                            $SQL = $SQL . ",0";
                        }
                        if (isset($_POST["sedred"])){
                            if (strlen($_POST["sedred"]) > 0){
                                $SQL = $SQL . ",".intval($_POST["sedred"]);
                            }else{
                                $SQL = $SQL . ",0";
                            }
                        }else{
                            $SQL = $SQL . ",0";
                        }
                        if (isset($_POST["refst"])){
                            if (strlen($_POST["refst"]) > 0){
                                $SQL = $SQL . ",".intval($_POST["refst"]);
                            }else{
                                $SQL = $SQL . ",0";
                            }
                        }else{
                            $SQL = $SQL . ",0";
                        }
                        $SQL = $SQL . ")";
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "<h2>Zapis je bil dodan!</h2>";
                            if ($VZapStUre == 1){
                                $SQL = "SELECT id FROM tabdnevnik WHERE datum='".$VDatum->format('Y-m-d')."' AND razred='".$VRazred."' AND ura=$VUra AND predmet=$VPredmet AND ucitelj='".$VUcitelj."' AND zapura=1";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    $SQL = "UPDATE tabdnevnik SET refid=".$R1["id"]." WHERE id=".$R1["id"];
                                    $result1 = mysqli_query($link,$SQL);
                                    if (!($result1 = mysqli_query($link,$SQL))){
                                        die("Napaka pri popravku referenčne številke!<br />$SQL<br />");
                                    }
                                }
                            }
                        }else{
                            echo "<h2>Napaka pri vpisu!</h2>";
                        }
                    }
                    
                    $SQL = "SELECT * FROM tabdnevnik WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                    $SQL = $SQL . " AND ura=".$VUra." AND ucitelj ='".$VUcitelj."' AND predmet IN (".$VPredmet.")";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'vpiše še izostanke in opombe učencem
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            //'vpiše odsotnost
                            if (isset($_POST["ods_".$Indx])){
                                $SQL = "SELECT tabodsotnostuc.*,tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc ";
                                $SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabodsotnostuc.idUcenec=".$_POST["odsuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabodsotnostuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",idDnevnik=".$R["id"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljen izostanek učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["odsuc_".$Indx].").<br />";
                                }else{
                                    //'doda zapis
                                    $SQL = "INSERT INTO tabodsotnostuc (leto,datum,idUcenec,ura,predmet,ucitelj,status,idDnevnik,vpisal,casVp) VALUES (";
                                    $SQL = $SQL . $VLeto;
                                    $SQL = $SQL . ",'".$VDatum->format('Y-m-d')."'";
                                    $SQL = $SQL . ",".$_POST["odsuc_".$Indx];
                                    $SQL = $SQL . ",".$R["ura"];
                                    $SQL = $SQL . ",".$R["predmet"];
                                    $SQL = $SQL . ",'".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",0";
                                    $SQL = $SQL . ",".$R["ID"];
                                    $SQL = $SQL . ",".$IdUcitelj;
                                    $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . ")";
                                    echo "Vpisan izostanek učenca: (".$_POST["odsuc_".$Indx].").<br />";
                                }
                                $result2 = mysqli_query($link,$SQL);
                            }else{
                                $SQL = "SELECT tabodsotnostuc.*,tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc ";
                                $SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabodsotnostuc.idUcenec=".$_POST["odsuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabodsotnostuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",status=3";
                                    $SQL = $SQL . ",idDnevnik=".$R["ID"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljen izostanek učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["odsuc_".$Indx].").<br />";
                                    $result2 = mysqli_query($link,$SQL);
                                }
                            }
                            
                            //'vpiše opombe
                            if (strlen($_POST["op_".$Indx]) > 0){
                                $SQL = "SELECT tabopombeuc.*,tabucenci.priimek,tabucenci.ime FROM tabopombeuc ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabopombeuc.idUcenec=".$_POST["opuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabopombeuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",opomba='".$_POST["op_".$Indx]."'";
                                    $SQL = $SQL . ",idDnevnik=".$R["ID"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljene opombe za učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["opuc_".$Indx].").<br />";
                                }else{
                                    //'doda zapis
                                    $SQL = "INSERT INTO tabopombeuc (leto,datum,idUcenec,ura,predmet,ucitelj,opomba,idDnevnik,vpisal,casVp) VALUES (";
                                    $SQL = $SQL . $VLeto;
                                    $SQL = $SQL . ",'".$VDatum->format('Y-m-d')."'";
                                    $SQL = $SQL . ",".$_POST["opuc_".$Indx];
                                    $SQL = $SQL . ",".$R["ura"];
                                    $SQL = $SQL . ",".$R["predmet"];
                                    $SQL = $SQL . ",'".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",'".$_POST["op_".$Indx]."'";
                                    $SQL = $SQL . ",".$R["ID"];
                                    $SQL = $SQL . ",".$IdUcitelj;
                                    $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . ")";
                                    echo "Vpisana opomba učencu: (".$_POST["opuc_".$Indx].").<br />";
                                }
                                $result2 = mysqli_query($link,$SQL);
                            }else{
                                $SQL = "SELECT tabopombeuc.*,tabucenci.priimek,tabucenci.ime FROM tabopombeuc ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabopombeuc.idUcenec=".$_POST["opuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    $SQL = "DELETE FROM tabopombeuc WHERE id=".$R1["ID"];
                                    $result2 = mysqli_query($link,$SQL);
                                }
                            }
                            
                            
                            //vpiše ocene
                            if (isset($_POST["redovalnica"])){
                                if (isset($_POST["oc_".$Indx])){
                                    if ($_POST["oc_".$Indx]=="0"){
                                        //nov vpis
                                        $SQL = "SELECT id,prioriteta FROM tabpredmeti WHERE id IN (".$_POST["pr_".$Indx].") AND prioriteta < 2";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            $SQL = "INSERT INTO tabocene (leto,iducenec,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u,neocenjen,popravni,ocenakoncna,ocenapolletna,datum,vpisovalec) VALUES (";
                                            $SQL = $SQL . $VLeto;
                                            $SQL = $SQL . ",".$_POST["uc_".$Indx];
                                            $SQL = $SQL . ",".$R1["id"];
                                            $SQL = $SQL . ",'".$_POST["s1p_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s1u_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s2p_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s2u_".$Indx]."'";
                                            $SQL = $SQL . ",0,0,'','','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                            
                                            $DovoljenVpis=true;
                                            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                                            $Interval=$Danes->diff($MejniDatum);
                                            if ($Interval->invert > 0){
                                                if ($VLevel < 3){
                                                    $DovoljenVpis=false;
                                                }
                                            }
                                            if ($DovoljenVpis){    
                                                $result2 = mysqli_query($link,$SQL);
                                            }
                                        }
                                    }else{
                                        //vpis popravka
                                        $SQL = "SELECT ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE id =".$_POST["oc_".$Indx];
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            $Vpis=0;
                                            $SQL = "UPDATE tabocene SET ";
                                            if ($_POST["s1p_".$Indx] != $R1["ocenas1p"]){
                                                $SQL = $SQL . "ocenas1p='".$_POST["s1p_".$Indx]."'";
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s1u_".$Indx] != $R1["ocenas1u"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas1u='".$_POST["s1u_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas1u='".$_POST["s1u_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s2p_".$Indx] != $R1["ocenas2p"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas2p='".$_POST["s2p_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas2p='".$_POST["s2p_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s2u_".$Indx] != $R1["ocenas2u"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas2u='".$_POST["s2u_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas2u='".$_POST["s2u_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($Vpis > 0){
                                                $SQL = $SQL . ",vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["oc_".$Indx];
                                            }else{
                                                $SQL = $SQL . "vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["oc_".$Indx];
                                            }
                                            
                                            //v primeru spremembe popravi podatek
                                            if ($Vpis > 0){
                                                $DovoljenVpis=true;
                                                $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                                                $Interval=$Danes->diff($MejniDatum);
                                                if ($Interval->invert > 0){
                                                    if ($VLevel < 3){
                                                        $DovoljenVpis=false;
                                                    }
                                                }
                                                if ($DovoljenVpis){    
                                                    $result2 = mysqli_query($link,$SQL);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            //'vpiše razrede
                            //'najprej stare pobriše
                            $SQL = "DELETE FROM tabdnevnikr WHERE idDnevnik=".$R["ID"];
                            $result1 = mysqli_query($link,$SQL);
                            
                            $idRazred=0;
                            $SQL = "SELECT id FROM tabrazdat WHERE id IN (".$R["razred"].")";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                $SQL = "INSERT INTO tabdnevnikr (idDnevnik,idRazred) VALUES (".$R["ID"].",".$R1["id"].")";
                                $result2 = mysqli_query($link,$SQL);
                                if ($idRazred == 0){
                                    $idRazred=$R1["id"];
                                }
                            }
                            
                            //'vpiše učitelje
                            //'najprej stare pobriše
                            $SQL = "DELETE FROM tabdnevniku WHERE idDnevnik=".$R["ID"];
                            $result1 = mysqli_query($link,$SQL);
                            
                            $SQL = "SELECT iducitelj FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                $SQL = "INSERT INTO tabdnevniku (idDnevnik,idUcitelj) VALUES (".$R["ID"].",".$R1["iducitelj"].")";
                                $result2 = mysqli_query($link,$SQL);
                            }
                        }
                    }
                    
                    if ($VLevel > 1){
                        header ("Location: dnevnik.php?idd=100&id=4&idrazred=".$idRazred."&dan=".$VDan."&mesec=".$VMesec."&letod=".$VLetoD);
                    }else{
                        header ("Location: dnevnik.php?idd=100&id=11&uciteljp=".$IdUcitelj."&idrazred=".$idRazred."&dan=".$VDan."&mesec=".$VMesec."&letod=".$VLetoD);
                    }
                }else{
                    header ("Location: nepooblascen.htm");
                }
                break;
            case "2": // 'vpis popravka v dnevnik 
                //'vpis splošnih podatkov
                //'pogleda, če ima že vpisano
                $DovoljenVpis=false;
                $SQL = "SELECT id,ucitelj,razred,predmet,ura FROM tabdnevnik WHERE id =".$IzDnevnika;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    if ($VLevel < 2){
                        if (vsebuje($R["ucitelj"],$IdUcitelj)){
                            $DovoljenVpis=true;
                        }else{
                            $SQL = "SELECT DISTINCT idrazred,iducitelj FROM tabrazred WHERE idRazred IN (".$R["razred"].")";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                if ($IdUcitelj==$R1["iducitelj"]){
                                    $DovoljenVpis=true;
                                }
                            }
                        }
                    }else{
                        $DovoljenVpis=true;
                    }
                    
                    if ($DovoljenVpis){
                        //'zapis obstaja - popravljanje
                        $SQL = "UPDATE tabdnevnik SET ";
                        $SQL = $SQL . "razred='".$VRazred."'";
                        $SQL = $SQL . ",predmet=".$VPredmet;
                        $SQL = $SQL . ",skupina='".$VNivo."'";
                        $SQL = $SQL . ",ZapUra=".$VZapStUre;
                        $SQL = $SQL . ",opis='".$VOpombe."'";
                        $SQL = $SQL . ",naloge='".$VNaloge."'";
                        $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                        if (isset($_POST["priprava"])){
                            if (strlen($_POST["priprava"]) > 0){
                                $SQL = $SQL . ",idpriprava=".intval($_POST["priprava"]);
                            }else{
                                $SQL = $SQL . ",idpriprava=0";
                            }
                        }else{
                            $SQL = $SQL . ",idpriprava=0";
                        }
                        if (isset($_POST["sedred"])){
                            if (strlen($_POST["sedred"]) > 0){
                                $SQL = $SQL . ",idsedred=".intval($_POST["sedred"]);
                            }else{
                                $SQL = $SQL . ",idsedred=0";
                            }
                        }else{
                            $SQL = $SQL . ",idsedred=0";
                        }
                        if (isset($_POST["refst"])){
                            if (strlen($_POST["refst"]) > 0){
                                $SQL = $SQL . ",refid=".intval($_POST["refst"]);
                            }else{
                                $SQL = $SQL . ",refid=0";
                            }
                        }else{
                            $SQL = $SQL . ",refid=0";
                        }
                        $SQL = $SQL . ",statusUre=".$VStatus;
                        $SQL = $SQL . ",spremenil=".$IdUcitelj;
                        $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["id"];
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "<h2>Zapis je bil popravljen!</h2>";
                        }else{
                            echo "<h2>Napaka pri vpisu!</h2>";
                        }

                        //'vpiše še izostanke in opombe učencem
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            //'vpiše odsotnost
                            if (isset($_POST["ods_".$Indx])){
                                $SQL = "SELECT tabodsotnostuc.*,tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc ";
                                $SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabodsotnostuc.idUcenec=".$_POST["odsuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabodsotnostuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",idDnevnik=".$R["id"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljen izostanek učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["odsuc_".$Indx].").<br />";
                                }else{
                                    //'doda zapis
                                    $SQL = "INSERT INTO tabodsotnostuc (leto,datum,idUcenec,ura,predmet,ucitelj,status,idDnevnik,vpisal,casVp) VALUES (";
                                    $SQL = $SQL . $VLeto;
                                    $SQL = $SQL . ",'".$VDatum->format('Y-m-d')."'";
                                    $SQL = $SQL . ",".$_POST["odsuc_".$Indx];
                                    $SQL = $SQL . ",".$R["ura"];
                                    $SQL = $SQL . ",".$R["predmet"];
                                    $SQL = $SQL . ",'".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",0";
                                    $SQL = $SQL . ",".$R["id"];
                                    $SQL = $SQL . ",".$IdUcitelj;
                                    $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . ")";
                                    echo "Vpisan izostanek učenca: (".$_POST["odsuc_".$Indx].").<br />";
                                }
                                $result2 = mysqli_query($link,$SQL);
                            }else{
                                $SQL = "SELECT tabodsotnostuc.*,tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc ";
                                $SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabodsotnostuc.idUcenec=".$_POST["odsuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabodsotnostuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",status=3";
                                    $SQL = $SQL . ",idDnevnik=".$R["id"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljen izostanek učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["odsuc_".$Indx].").<br />";
                                    $result2 = mysqli_query($link,$SQL);
                                }
                            }
                            
                            //'vpiše opombe
                            if (strlen($_POST["op_".$Indx]) > 0){
                                $SQL = "SELECT tabopombeuc.*,tabucenci.priimek,tabucenci.ime FROM tabopombeuc ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabopombeuc.idUcenec=".$_POST["opuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //'popravi zapis
                                    $SQL = "UPDATE tabopombeuc SET ";
                                    $SQL = $SQL . "predmet=".$R["predmet"];
                                    $SQL = $SQL . ",ucitelj='".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",opomba='".$_POST["op_".$Indx]."'";
                                    $SQL = $SQL . ",idDnevnik=".$R["id"];
                                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                                    $SQL = $SQL . ",casSpr='".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . " WHERE id=".$R1["ID"];
                                    echo "Popravljene opombe za učenca: ".$R1["priimek"]." ".$R1["ime"]." (".$_POST["opuc_".$Indx].").<br />";
                                }else{
                                    //'doda zapis
                                    $SQL = "INSERT INTO tabopombeuc (leto,datum,idUcenec,ura,predmet,ucitelj,opomba,idDnevnik,vpisal,casVp) VALUES (";
                                    $SQL = $SQL . $VLeto;
                                    $SQL = $SQL . ",'".$VDatum->format('Y-m-d')."'";
                                    $SQL = $SQL . ",".$_POST["opuc_".$Indx];
                                    $SQL = $SQL . ",".$R["ura"];
                                    $SQL = $SQL . ",".$R["predmet"];
                                    $SQL = $SQL . ",'".$R["ucitelj"]."'";
                                    $SQL = $SQL . ",'".$_POST["op_".$Indx]."'";
                                    $SQL = $SQL . ",".$R["id"];
                                    $SQL = $SQL . ",".$IdUcitelj;
                                    $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL = $SQL . ")";
                                    echo "Vpisana opomba učencu: (".$_POST["opuc_".$Indx].").<br />";
                                }
                                $result2 = mysqli_query($link,$SQL);
                            }else{
                                $SQL = "SELECT tabopombeuc.*,tabucenci.priimek,tabucenci.ime FROM tabopombeuc ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                                $SQL = $SQL . " AND ura=".$VUra." AND tabopombeuc.idUcenec=".$_POST["opuc_".$Indx];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    $SQL = "DELETE FROM tabopombeuc WHERE id=".$R1["ID"];
                                    $result2 = mysqli_query($link,$SQL);
                                }
                            }
                            
                            //vpiše ocene
                            if (isset($_POST["redovalnica"])){
                                if (isset($_POST["oc_".$Indx])){
                                    if ($_POST["oc_".$Indx]=="0"){
                                        //nov vpis
                                        $SQL = "SELECT id,prioriteta FROM tabpredmeti WHERE id IN (".$_POST["pr_".$Indx].") AND prioriteta < 2";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            $SQL = "INSERT INTO tabocene (leto,iducenec,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u,neocenjen,popravni,ocenakoncna,ocenapolletna,datum,vpisovalec) VALUES (";
                                            $SQL = $SQL . $VLeto;
                                            $SQL = $SQL . ",".$_POST["uc_".$Indx];
                                            $SQL = $SQL . ",".$R1["id"];
                                            $SQL = $SQL . ",'".$_POST["s1p_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s1u_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s2p_".$Indx]."'";
                                            $SQL = $SQL . ",'".$_POST["s2u_".$Indx]."'";
                                            $SQL = $SQL . ",0,0,'','','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                            
                                            $DovoljenVpis=true;
                                            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                                            $Interval=$Danes->diff($MejniDatum);
                                            if ($Interval->invert > 0){
                                                if ($VLevel < 3){
                                                    $DovoljenVpis=false;
                                                }
                                            }
                                            if ($DovoljenVpis){    
                                                $result2 = mysqli_query($link,$SQL);
                                            }
                                        }
                                    }else{
                                        //vpis popravka
                                        $SQL = "SELECT ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE id =".$_POST["oc_".$Indx];
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            $Vpis=0;
                                            $SQL = "UPDATE tabocene SET ";
                                            if ($_POST["s1p_".$Indx] != $R1["ocenas1p"]){
                                                $SQL = $SQL . "ocenas1p='".$_POST["s1p_".$Indx]."'";
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s1u_".$Indx] != $R1["ocenas1u"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas1u='".$_POST["s1u_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas1u='".$_POST["s1u_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s2p_".$Indx] != $R1["ocenas2p"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas2p='".$_POST["s2p_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas2p='".$_POST["s2p_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($_POST["s2u_".$Indx] != $R1["ocenas2u"]){
                                                if ($Vpis > 0){
                                                    $SQL = $SQL . ",ocenas2u='".$_POST["s2u_".$Indx]."'";
                                                }else{
                                                    $SQL = $SQL . "ocenas2u='".$_POST["s2u_".$Indx]."'";
                                                }
                                                $Vpis=$Vpis+1;
                                            }
                                            if ($Vpis > 0){
                                                $SQL = $SQL . ",vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["oc_".$Indx];
                                            }else{
                                                $SQL = $SQL . "vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["oc_".$Indx];
                                            }
                                            
                                            //v primeru spremembe popravi podatek
                                            if ($Vpis > 0){
                                                $DovoljenVpis=true;
                                                $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                                                $Interval=$Danes->diff($MejniDatum);
                                                if ($Interval->invert > 0){
                                                    if ($VLevel < 3){
                                                        $DovoljenVpis=false;
                                                    }
                                                }
                                                if ($DovoljenVpis){    
                                                    if (!$result2 = mysqli_query($link,$SQL)){
                                                        echo "Napaka pri vpisu<br />";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            //'vpiše razrede
                            //'najprej stare pobriše
                            $SQL = "DELETE FROM tabdnevnikr WHERE idDnevnik=".$R["id"];
                            $result1 = mysqli_query($link,$SQL);
                            
                            $SQL = "SELECT id FROM tabrazdat WHERE id IN (".$R["razred"].")";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                $SQL = "INSERT INTO tabdnevnikr (idDnevnik,idRazred) VALUES (".$R["id"].",".$R1["id"].")";
                                $result2 = mysqli_query($link,$SQL);
                            }
                            
                            //'vpiše učitelje
                            //'najprej stare pobriše
                            $SQL = "DELETE FROM tabdnevniku WHERE idDnevnik=".$R["id"];
                            $result1 = mysqli_query($link,$SQL);
                            
                            $SQL = "SELECT iducitelj FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                $SQL = "INSERT INTO tabdnevniku (idDnevnik,idUcitelj) VALUES (".$R["id"].",".$R1["iducitelj"].")";
                                $result2 = mysqli_query($link,$SQL);
                            }
                        }
                        header ("Location: dnevnik.php?idd=100&id=0&izdnevnika=".$IzDnevnika."&dan=".$VDan."&mesec=".$VMesec."&letod=".$VLetoD);
                    }else{
                        echo "<h2>Zapis lahko popravi le tisti, ki ga je vpisal oz. z ustreznimi pooblastili!</h2>";
                    }
                }
                break;
            case "3": //izpis dnevniških zapisov po učiteljih
                $Ucitelj=$_POST["uciteljp"];
                
                $Tedenski=false;
                
                $SQL = "SELECT tabdnevnik.*,tabdnevnik.opis AS dopis,tabpredmeti.Opis AS popis,tabpredmeti.oznaka,tabsifrantstatusure.opis AS sopis FROM (tabdnevnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabsifrantstatusure ON tabdnevnik.statusUre=tabsifrantstatusure.idStatusUre ";
                switch ($_POST["obdobje"]){
                    case "1": //vsi zapisi
                        $SQL = $SQL . "WHERE leto=$VLeto AND ucitelj LIKE '%".$Ucitelj."%'";
                        break;
                    case "2": //mesečni zapisi
                        $SQL = $SQL . "WHERE leto=$VLeto AND month(datum)=".$VMesec." AND ucitelj LIKE '%".$Ucitelj."%'";
                        break;
                    case "3"://tedenski pregled
                        $Tedenski=true;
                        header ("Location: dnevnik.php?idd=100&id=11&dan=$VDan&mesec=$VMesec&letod=$VLetoD&uciteljp=$Ucitelj");
                        break;
                    default: //dnevni zapisi
                        $SQL = $SQL . "WHERE year(datum)=$VLetoD AND month(datum)=$VMesec AND day(datum)=$VDan  AND ucitelj LIKE '%".$Ucitelj."%'";
                }
                if (!$Tedenski){
                    $SQL = $SQL . " ORDER BY popis,skupina,razred,ZapUra";
                    $result1 = mysqli_query($link,$SQL);
                    
                    $n=$VLevel;
                    include('menu_func.inc');
                    include ('menu.inc');

                    $Indx=0;
                    $Comp="";
                    echo "<table border='0'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (vsebuje($R1["ucitelj"],$Ucitelj) > 0){
                            if (isset($R1["refid"])){
                                if ($R1["refid"] > 0){
                                    if ($Comp != $R1["refid"]){
                                        echo "</table><br />";
                                        $Indx=0;
                                        echo "<table border='1'>";
                                        echo "<tr><th>Št.</th><th>Datum</th><th width='200'>Predmet</th><th>Skupina</th><th width='80'>Razred</th><th>Zap. ura</th><th width='200'>Dn. zapis</th><th width='150'>Dom. naloga</th><th width='120'>Učitelj</th><th>Status</th><th>Vpisano</th><th>Spremenjeno</th><th width='100'>Odsotni</th><th width='100'>Opombe</th></tr>";
                                        
                                        $Comp = $R1["refid"];
                                    }
                                }else{
                                    if ($Comp != $R1["refid"].$R1["popis"].$R1["skupina"].$R1["razred"]){
                                        echo "</table><br />";
                                        $Indx=0;
                                        echo "<table border='1'>";
                                        echo "<tr><th>Št.</th><th>Datum</th><th width='200'>Predmet</th><th>Skupina</th><th width='80'>Razred</th><th>Zap. ura</th><th width='200'>Dn. zapis</th><th width='150'>Dom. naloga</th><th width='120'>Učitelj</th><th>Status</th><th>Vpisano</th><th>Spremenjeno</th><th width='100'>Odsotni</th><th width='100'>Opombe</th></tr>";
                                        
                                        $Comp = $R1["refid"].$R1["popis"].$R1["skupina"].$R1["razred"];
                                    }
                                }
                            }else{
                                if ($Comp != "0".$R1["popis"].$R1["skupina"].$R1["razred"]){
                                    echo "</table><br />";
                                    $Indx=0;
                                    echo "<table border='1'>";
                                    echo "<tr><th>Št.</th><th>Datum</th><th width='200'>Predmet</th><th>Skupina</th><th width='80'>Razred</th><th>Zap. ura</th><th width='200'>Dn. zapis</th><th width='150'>Dom. naloga</th><th width='120'>Učitelj</th><th>Status</th><th>Vpisano</th><th>Spremenjeno</th><th width='100'>Odsotni</th><th width='100'>Opombe</th></tr>";
                                    
                                    $Comp = "0".$R1["popis"].$R1["skupina"].$R1["razred"];
                                }
                            }
                            
                            $Indx=$Indx+1;
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            $Datum=new DateTime(isDate($R1["datum"]));
                            echo "<td>".$Datum->format('d.m.Y')."</td>";
                            echo "<td><a href='dnevnik.php?idd=100&izdnevnika=".$R1["ID"]."'>".$R1["popis"]." (".$R1["oznaka"].")</a></td>";
                            echo "<td>".ToNivo($R1["skupina"])."</td>";
                            
                            echo "<td>";
                            $SQL = "SELECT * FROM tabrazdat WHERE id IN (".$R1["razred"].")";
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["razred"].". ".$R2["oznaka"]." ";
                            }
                            echo "</td>";
                            
                            echo "<td>".$R1["ZapUra"]."</td>";
                            if (isset($R1["idpriprava"])){
                                $SQL = "SELECT priprava FROM tabpriprava WHERE id=".$R1["idpriprava"];
                                $result2 = mysqli_query($link,$SQL);
                                if ($R2 = mysqli_fetch_array($result2)){
                                    echo "<td><a href='upload/priprave/".$R2["priprava"]."' target='_blank'>".$R1["dopis"]."</a></td>";
                                }else{
                                    echo "<td>".$R1["dopis"]."</td>";
                                }  
                            }else{
                                echo "<td>".$R1["dopis"]."</td>";
                            }
                            
                            echo "<td>".$R1["naloge"]."</td>";
                            
                            echo "<td>";
                            $SQL = "SELECT ime,priimek FROM tabucitelji WHERE idUcitelj IN (".$R1["ucitelj"].")";
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]."<br />";
                            }
                            echo "</td>";
                            
                            echo "<td>".$R1["sopis"]."</td>";
                            echo "<td>".$R1["casvp"]."</td>";
                            echo "<td>".$R1["casSpr"]."</td>";
                            
                            //'odsotni
                            echo "<td>";
                            $SQL = "SELECT tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec WHERE idDnevnik=".$R1["ID"];
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]."<br />";
                            }
                            echo "</td>";
                            
                            //'opombe
                            echo "<td>";
                            $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopombeuc.opomba FROM tabopombeuc INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec WHERE idDnevnik=".$R1["ID"];
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]." ".$R2["opomba"]."<br />";
                            }
                            echo "</td>";
                            
                            echo "</tr>";
                        }
                    }
                    echo "</table><br />";
                }
                break;
            case "4": // 'izpiše tedenski dnevnik za določen razred
                if ($idRazred == 0){
                    header ("Location: dnevnik.php");
                }else{
					$n=$VLevel;
					include('menu_func.inc');
					include ('menu.inc');
//					echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";
					echo "<a href='dnevnik.php?idd=100'>Nazaj na splošen vnos dnevnika</a><br>";
					$SQL = "SELECT * FROM tabrazdat WHERE id=".$idRazred;
					$result = mysqli_query($link,$SQL);
					if ($R = mysqli_fetch_array($result)){
						echo "<h2>Tedenski dnevniški zapis za: ".$R["razred"].". ".$R["oznaka"]."</h2>";
						$VRazred1=$R["razred"];
						$VParalelka=$R["oznaka"];
					}
					//'glava tabele
					echo "<table border='1' cellspacing='0'>";
					echo "<tr><th>Datum</th><th>Dan</th>";
					for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
						echo "<th>".$Indx."</th>";
					}
					echo "<th>Izostanki</th>";
					echo "<th>Opombe</th>";
					echo "<th>Dežurni</th>";
					echo "</tr>";
					
					//'ugotovi začetni in končni dan v tednu
					switch ($VDatum->format('w')){
						case 1: // 'PON
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P1D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						case 2: // 'TOR
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P2D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						case 3: // 'SRE
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P3D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						case 4: // 'ČET
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P4D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						case 5: // 'PET
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P5D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						case 6: // 'SOB
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P6D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
							break;
						default: // 'NED
							$VZacDan=new DateTime($VDatum->format('Y-m-d'));
							$VZacDan->sub(new DateInterval('P7D'));
							$VKonDan=new DateTime($VZacDan->format('Y-m-d'));
							$VKonDan->add(new DateInterval('P6D'));
					}
					
					$VDatum=new DateTime($VZacDan->format('Y-m-d'));
					while (1){
						$VDatum->add(new DateInterval('P1D'));
						$Interval1=$VDatum->diff($Danes);
						
						$SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
						$result = mysqli_query($link,$SQL);
						if ($R = mysqli_fetch_array($result)){
							switch ( $R["kat"]){
								case 0: // 'praznik
									if ($Interval1->days==0 && $Interval1->invert==0){
										echo "<tr bgcolor='yellowgreen'>";
									}else{
										echo "<tr bgcolor='lightgreen'>";
									}
									break;
								case 1: // 'počitnice
									if ($Interval1->days==0 && $Interval1->invert==0){
										echo "<tr bgcolor='lightseagreen'>";
									}else{
										echo "<tr bgcolor='lightcyan'>";
									}
									break;
								case 2: // 'delovni dan
									if ($Interval1->days==0){
										echo "<tr bgcolor='lightyellow'>";
									}else{
										echo "<tr>";
									}
							}
						}else{
							if (($VDatum->format('w') == 6) or ($VDatum->format('w') == 0)){
								if ($Interval1->days==0 && $Interval1->invert==0){
									echo "<tr bgcolor='salmon'>";
								}else{
									echo "<tr bgcolor='lightsalmon'>";
								}
							}else{
								if ($Interval1->days==0 && $Interval1->invert==0){
									echo "<tr bgcolor='lightyellow'>";
								}else{
									echo "<tr>";
								}
							}
						}
						
						echo "<td align='center'><a href='dnevnik.php?idd=100&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letod=".$VDatum->format('Y')."&ura=1'>".$VDatum->format('d.m.Y')."</a><br />";
						$SolDan=SolskiDan($VDatum,$VLeto);
						if ($SolDan > 0){
							echo $SolDan;
						}
						echo "</td><td>".int2Dan($VDatum->format('w'))."</td>";
						
						$SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE idRazred=".$idRazred." ORDER BY priimek,ime";
						$result = mysqli_query($link,$SQL);
						$Indx=0;
						while ($R = mysqli_fetch_array($result)){
							$Indx=$Indx+1;
							for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
								$VOdsotni[$Indx][$Indx1][0]=0;
								$VOdsotni[$Indx][$Indx1][1]=0;
								$VOdsotni[$Indx][$Indx1][2]=0;
								$VOdsotni[$Indx][$Indx1][3]=0;
							}
							$VOdsotni[$Indx][14][0]=$R["iducenec"];
							$VOdsotni[$Indx][15][0]=$R["priimek"]." ".$R["ime"];
							$VOdsotni[$Indx][16][0]=0; // 'ni odsoten ta dan
							
							for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
								$VOpombeUc[$Indx][$Indx1]="";
							}
							$VOpombeUc[$Indx][14]=$R["iducenec"];
							$VOpombeUc[$Indx][15]=$R["priimek"]." ".$R["ime"];
							$VOpombeUc[$Indx][16]=0; // 'ni opomb ta dan
						}
						$StUcencev=$Indx;
						
						for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
							$SQL = "SELECT tabdnevnik.*,tabdnevnik.id AS did,tabdnevnik.opis AS dopis,tabpredmeti.*,tabpredmeti.id AS pid,tabpredmeti.oznaka FROM tabdnevnik ";
							$SQL = $SQL . " INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id ";
							$SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$Indx;
							$result = mysqli_query($link,$SQL);
							$Indx1=0;
                            if ($R = mysqli_fetch_array($result)){
                                switch ($R["statusUre"]){
                                    case 1:   //nadomeščanje
                                    case 2:   //združena
                                        echo "<td class='dn_ura' valign='top' bgcolor='yellow'>";
                                        break;
                                    case 3:   //odpadla
                                        echo "<td class='dn_ura' valign='top' bgcolor='magenta'>";
                                        break;
                                    case 4:   //športni dan
                                    case 5:   //kulturni dan
                                    case 6:   //naravoslovni dan
                                    case 7:   //tehniški dan
                                    case 9:   //ekskurzija
                                        echo "<td class='dn_ura' valign='top' bgcolor='lightblue'>";
                                        break;
                                    case 8:   //šola v naravi
                                        echo "<td class='dn_ura' valign='top' bgcolor='lightcyan'>";
                                        break;
                                    case 10:  //proslava
                                    case 11:  //drugo
                                        echo "<td class='dn_ura' valign='top' bgcolor='lightpink'>";
                                        break;
                                    default: //redna ura
							            echo "<td class='dn_ura' valign='top'>";
                                }
                            }else{
                                echo "<td class='dn_ura' valign='top'>";
                            }
                            $result = mysqli_query($link,$SQL);
							while ($R = mysqli_fetch_array($result)){
								if (strlen($R["razred"]) > 0){
									//'dnevniškim zapisom za določen dan poišče razrede
									$SQL = "SELECT * FROM tabdnevnikr WHERE idRazred IN (".$R["razred"].")";
									$result1 = mysqli_query($link,$SQL);
									while ($R1 = mysqli_fetch_array($result1)){
										//'iz ustreznih razredov pridobi naslove dnevniških zapisov
										if ($R1["idRazred"]==$idRazred){
											//'izpiše ustrezen dnevniški zapis
											if ($R1["idDnevnik"]==$R["did"]){
												$Indx1=$Indx1+1;
												echo "<table class='dn_celica' border='0' cellspacing='0' width='50'>";
												echo "<tr class='dn_celica'>";
												echo "<td class='dn_celica'><a href='dnevnik.php?idd=100&izdnevnika=".$R["did"]."'>".$R["oznaka"].ToNivo2($R["skupina"])."</a></td>";
												echo "<td class='dn_celica'>".$R["ZapUra"]."</td>";
												echo "</tr>";
												echo "<tr class='dn_celica'>";
												echo "<td class='dn_celica' colspan='2'>";
                                                if (isset($R["idpriprava"])){
                                                    $SQL = "SELECT priprava FROM tabpriprava WHERE id=".$R["idpriprava"];
                                                    $result2 = mysqli_query($link,$SQL);
                                                    if ($R2 = mysqli_fetch_array($result2)){
                                                        echo "<a href='upload/priprave/".$R2["priprava"]."' target='_blank'>".$R["dopis"]."</a></td>";
                                                    }else{
                                                        echo $R["dopis"]."</td>";
                                                    }
                                                }else{    
                                                    echo $R["dopis"]."</td>";
                                                }
												echo "</tr>";
												echo "<tr class='dn_celica'>";
												echo "<td class='dn_celica' colspan='2'>";
												$SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
												$result2 = mysqli_query($link,$SQL);
												while ($R2 = mysqli_fetch_array($result2)){
													echo $R2["priimek"]." ".$R2["ime"]."<br />";
												}
												echo "</td>";
												echo "</tr>";
												echo "</table><br />";
												//'obdelava odsotnosti
												$SQL = "SELECT tabodsotnostuc.* FROM (tabodsotnostuc ";
												$SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec)";
												$SQL = $SQL . " INNER JOIN tabrazred ON tabodsotnostuc.idUcenec=tabrazred.idUcenec";
												$SQL = $SQL . " WHERE idDnevnik=".$R["ID"]." AND tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND idRazred=".$idRazred." AND tabodsotnostuc.status < 3";
												$result2 = mysqli_query($link,$SQL);
												while ($R2 = mysqli_fetch_array($result2)){
													for ($Indx2=1;$Indx2 <= $StUcencev;$Indx2++){
														if ($VOdsotni[$Indx2][14][0]==$R2["idUcenec"]){
															$VOdsotni[$Indx2][$Indx][$R2["status"]]=1;
															$VOdsotni[$Indx2][16][0]=1;
														}
													}
												}
												//'obdelava opomb
												$SQL = "SELECT tabopombeuc.* FROM (tabopombeuc ";
												$SQL = $SQL . " INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec)";
												$SQL = $SQL . " INNER JOIN tabrazred ON tabopombeuc.idUcenec=tabrazred.idUcenec";
												$SQL = $SQL . " WHERE idDnevnik=".$R["ID"]." AND tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND idRazred=".$idRazred;
												$result2 = mysqli_query($link,$SQL);
												while ($R2 = mysqli_fetch_array($result2)){
													for ($Indx2=1;$Indx2 <= $StUcencev;$Indx2++){
														if ($VOpombeUc[$Indx2][14]==$R2["idUcenec"]){
															$VOpombeUc[$Indx2][$Indx]=$R2["opomba"];
															$VOpombeUc[$Indx2][16]=1;
														}
													}
												}
											}
										}
									}
								}
							}
							if ($Indx1==0){
								//echo $VDatum->format('d.m.Y');
								$danl=$VDatum->format('j');
								$mesl=$VDatum->format('n');
								$letl=$VDatum->format('Y');
								
                                /*
								echo "<a href='dnevnik.php?idd=100&id=6&dan=".$danl."&mesec=".$mesl."&letod=".$letl."&ura=".$Indx."&idrazred=".$idRazred."'>".$Indx."</a><br /><table border='0' cellspacing='0' width='50'>";
								echo "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>";
								echo "<tr><td colspan='2'>&nbsp;</td></tr>";
								echo "<tr><td colspan='2'>&nbsp;</td></tr>";
								echo "</table>";
                                */
                                echo "<a href='dnevnik.php?idd=100&id=6&dan=".$danl."&mesec=".$mesl."&letod=".$letl."&ura=".$Indx."&idrazred=".$idRazred."'>".$Indx."</a><br /><table border='0' cellspacing='0' width='50'>";
                                $SQL = "SELECT prioriteta FROM taburnik INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id ";
                                $SQL = $SQL . "WHERE prioriteta IN (0,1,3) AND taburnik.od <= ".$VDatum->format('Ymd')." AND taburnik.do >= ".$VDatum->format('Ymd')." AND taburnik.leto=$VLeto AND taburnik.idrazred=".$idRazred." AND taburnik.ura=$Indx AND taburnik.danvtednu=".$VDatum->format('w');
                                $result2 = mysqli_query($link,$SQL);
                                if (mysqli_num_rows($result2) > 0){
                                    if ($R2 = mysqli_fetch_array($result2)){
                                        if ($R2["prioriteta"]==3){
                                            echo "<tr class='dn_celicap1' bgcolor='orange'>";
                                        }else{
                                            echo "<tr class='dn_celicap2' bgcolor='red'>";
                                        }
                                    }else{
                                        echo "<tr class='dn_celica'>";
                                    }
                                }else{
                                    echo "<tr class='dn_celica'>";
                                }
                                echo "<td class='dn_celica'>";
                                $SQL = "SELECT oznaka FROM taburnik INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id  WHERE leto=$VLeto AND od <= ".$VDatum->format('Ymd')." AND do >= ".$VDatum->format('Ymd')." AND idrazred=".$idRazred." AND ura=$Indx AND danvtednu=".$VDatum->format('w');
                                $result2 = mysqli_query($link,$SQL);
                                while ($R2 = mysqli_fetch_array($result2)){
                                    echo $R2["oznaka"]." ";
                                }
                                echo "</td>";
                                echo "<td class='dn_celica'>&nbsp;</td></tr>";
                                echo "<tr class='dn_celica'><td class='dn_celica' colspan='2'>&nbsp;</td></tr>";
                                echo "</table>";
							}
							echo "</td>";
						}
						
						//'izpiše še odsotnosti
						echo "<td valign='top'>";
						echo "<table border='0' cellspacing='0'>";
						echo "<tr><th width='150'>ime</th><th>&nbsp;?</th><th>Op</th><th>NO</th></tr>";
						for ($Indx=1;$Indx <= $StUcencev;$Indx++){
							$SumaOds[$Indx][0][0]=$VOdsotni[$Indx][14][0]; // 'idUcenec
							$SumaOds[$Indx][0][1]=$VOdsotni[$Indx][15][0]; // 'priimek in ime
							$SumaOds[$Indx][$VDatum->format('w')][2]=0;
							$SumaOds[$Indx][$VDatum->format('w')][3]=0;
							$SumaOds[$Indx][$VDatum->format('w')][4]=0;
							if ($VOdsotni[$Indx][16][0]==1){
								echo "<tr><td>";
								echo "<a href='dnevnik.php?idd=200&id=3&ucenec=".$VOdsotni[$Indx][14][0]."&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letoods=".$VDatum->format('Y')."&ura=".$Indx."&idrazred=".$idRazred."'>".$VOdsotni[$Indx][15][0]."</a>:";
								for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
									if (($VOdsotni[$Indx][$Indx1][0]==1) or ($VOdsotni[$Indx][$Indx1][1]==1) or ($VOdsotni[$Indx][$Indx1][2]==1)){
										echo " ".$Indx1;
										if ($VOdsotni[$Indx][$Indx1][0]==1){
											$SumaOds[$Indx][$VDatum->format('w')][2]=$SumaOds[$Indx][$VDatum->format('w')][2]+1;
										}
										if ($VOdsotni[$Indx][$Indx1][1]==1){
											$SumaOds[$Indx][$VDatum->format('w')][3]=$SumaOds[$Indx][$VDatum->format('w')][3]+1;
										}
										if ($VOdsotni[$Indx][$Indx1][2]==1){
											$SumaOds[$Indx][$VDatum->format('w')][4]=$SumaOds[$Indx][$VDatum->format('w')][4]+1;
										}
									}
								}
								echo "</td>";
								echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][2]."</td>";
								echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][3]."</td>";
								echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][4]."</td>";
								echo "</tr>";
							}
						}
						echo "</table>";
						echo "</td>";
						//' in opombe
						echo "<td valign='top'>";
						for ($Indx=1;$Indx <= $StUcencev;$Indx++){
							if ($VOpombeUc[$Indx][16]==1){
								echo "<a href='dnevnik.php?idd=300&id=3&ucenec=".$VOpombeUc[$Indx][14]."&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letoods=".$VDatum->format('Y')."&ura=".$Indx."&idrazred=".$idRazred."'>".$VOpombeUc[$Indx][15]."</a>:<br />";
								for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
									if (strlen($VOpombeUc[$Indx][$Indx1]) > 0){
										echo $Indx1.": ".$VOpombeUc[$Indx][$Indx1]."<br />";
									}
								}
							}
						}
						echo "</td>";
						
						//'izpiše dežurne učence
						if ($VDatum->format('w')==1){
							echo "<td rowspan='7' valign='top'>";
							$SQL = "SELECT DISTINCT tabucenci.priimek,tabucenci.ime,tabrazred.slika FROM (tabrazred ";
							$SQL = $SQL . " INNER JOIN TabDezurniUc ON tabrazred.idUcenec=TabDezurniUc.idUcenec) ";
							$SQL = $SQL . " INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
							$SQL = $SQL . " WHERE tabrazred.leto=". $VLeto ." AND idRazred=".$idRazred." AND (";
							$Datum=new DateTime($VDatum->format('Y-m-d'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').") OR";
							$Datum->add(new DateInterval('P1D'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').") OR";
							$Datum->add(new DateInterval('P1D'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').") OR";
							$Datum->add(new DateInterval('P1D'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').") OR";
							$Datum->add(new DateInterval('P1D'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').") OR";
							$Datum->add(new DateInterval('P1D'));
							$SQL = $SQL . "(TabDezurniUc.leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j').")";
							$SQL = $SQL . ")";
							$SQL = $SQL . " ORDER BY priimek,ime";
							$result2 = mysqli_query($link,$SQL);
							while ($R2 = mysqli_fetch_array($result2)){
								echo "<img src='".$R2["slika"]."' width='50'>".$R2["priimek"]." ".$R2["ime"]."<br />";
							}
							echo "<a href='dnevnik.php?idd=400&razred=".$idRazred."&mesec=".$VDatum->format('n')."'>Izberi dežurne</a>";
							echo "</td>";
						}
						echo "</tr>";
						//'zaključi zanko
						$IntervalOut=$VDatum->diff($VKonDan);
						if ($IntervalOut->days == 0){
							break;
						}
					}
					//'izpiše vsote odsotnosti
					echo "<tr>";
					echo "<td colspan='13'>&nbsp;</td>";
					echo "<td>";
					echo "<table border='0' cellspacing='0'>";
					echo "<tr><th width='150'>&nbsp;</th><th>&nbsp;?</th><th>Op</th><th>NO</th></tr>";
					echo "<tr><td>Skupaj</td>";
					
					$CountOds[0]=0;
					$CountOds[1]=0;
					$CountOds[2]=0;
					for ($Indx=1;$Indx <= $StUcencev;$Indx++){
						for ($Indx1=1;$Indx1 < 7;$Indx1++){
							$CountOds[0]=$CountOds[0]+$SumaOds[$Indx][$Indx1][2];
							$CountOds[1]=$CountOds[1]+$SumaOds[$Indx][$Indx1][3];
							$CountOds[2]=$CountOds[2]+$SumaOds[$Indx][$Indx1][4];
						}
					}
					echo "<td align='center'>".$CountOds[0]."</td>";
					echo "<td align='center'>".$CountOds[1]."</td>";
					echo "<td align='center'>".$CountOds[2]."</td>";
					echo "</tr></table></td>";
					echo "<td></td>";
					echo "</tr>";
					echo "</table><br />";
					
					//'naprej/nazaj/datum
					$TedenPrej=new DateTime($VKonDan->format('Y-m-d'));
					$TedenPrej->sub(new DateInterval('P7D'));
					$TedenPotem=new DateTime($VKonDan->format('Y-m-d'));
					$TedenPotem->add(new DateInterval('P7D'));
					echo "<a href='dnevnik.php?idd=100&id=4&dan=".$TedenPrej->format('j')."&mesec=".$TedenPrej->format('n')."&letod=".$TedenPrej->format('Y')."&ura=0&idrazred=".$idRazred."'>Prejšnji teden</a> | <a href='dnevnik.php?idd=100&id=4&dan=".$TedenPotem->format('j')."&mesec=".$TedenPotem->format('n')."&letod=".$TedenPotem->format('Y')."&ura=0&idrazred=".$idRazred."'>Naslednji teden</a>";
					
					echo "";
					echo "<form name='izborDatuma' method='POST' action='dnevnik.php'>";
					echo "<input name='idd' type='hidden' value='100'>";
					echo "<input name='id' type='hidden' value='4'>";
					echo "<input name='idrazred' type='hidden' value='".$idRazred."'>";
					echo "Datum ";
					echo "<select name='dan'>";
					for ($Indx=1;$Indx <= 31;$Indx++){
						if ($Indx==$VDatum->format('j')){
							echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
						}else{
							echo "<option value='".$Indx."' >".$Indx."</option>";
						}
					}
					echo "</select>";
					echo "<select name='mesec'>";
					for ($Indx=1;$Indx <= 12;$Indx++){
						if ($Indx==$VDatum->format('n')){
							echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
						}else{
							echo "<option value='".$Indx."' >".$Indx."</option>";
						}
					}
					echo "</select>";
					echo "<select name='letod'>";
					for ($Indx=$Danes->format('Y')-1;$Indx <= ($Danes->format('Y')+1);$Indx++){
						if ($Indx==$VDatum->format('Y')){
							echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
						}else{
							echo "<option value='".$Indx."' >".$Indx."</option>";
						}
					}
					echo "</select>";
					
					echo "<input name='submit' type='submit' value='Izberi'>";
					echo "</form><br>";
					
					//'izpis kumulative odsotnosti in opomb
					echo "<h3><a href='dnevnik.php?idd=200&id=5&razred=".$idRazred."'>Izostanki učencev</a></h3>";
					echo "<table border='1' cellspacing='0'>";
					echo "<tr><th rowspan='2'>št</th><th rowspan='2'>ime</th>";
					for ($Indx = 9;$Indx <= 12;$Indx++){
						echo "<th colspan='3'>".$Indx."</th>";
					}
					for ($Indx = 1;$Indx <= 6;$Indx++){
						echo "<th colspan='3'>".$Indx."</th>";
					}
					echo "<th colspan='3'>letno</th></tr>";
					echo "<tr>";
					for ($Indx=1;$Indx <= $UrNaDan;$Indx++){
						echo "<th>Op</th><th>NO</th><th>&nbsp;?</th>";
					}
					echo "<th>Op</th><th>NO</th><th>&nbsp;?</th></tr>";
					$SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE leto=".$VLeto." AND idRazred=".$idRazred." ORDER BY priimek,ime";
					$result = mysqli_query($link,$SQL);
					$Indx=0;
					while ($R = mysqli_fetch_array($result)){
						$Indx=$Indx+1;
						$SumOdsotnosti[0][1]=0; // 'letna odsotnost Op
						$SumOdsotnosti[0][2]=0; // 'letna odsotnost NeOp
						$SumOdsotnosti[0][3]=0; // 'letna odsotnost Dr
						for ($Indx1=9;$Indx1 <= 12;$Indx1++){
							$SumOdsotnosti[$Indx1][1]=0; // 'mesečna odsotnost Op
							$SumOdsotnosti[$Indx1][2]=0; // 'mesečna odsotnost NeOp
							$SumOdsotnosti[$Indx1][3]=0; // 'mesečna odsotnost Dr
							$SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND month(datum)=".$Indx1." AND idUcenec=".$R["iducenec"];
							$result1 = mysqli_query($link,$SQL);
							while ($R1 = mysqli_fetch_array($result1)){
								switch ( $R1["status"]){
									case 0:
										$SumOdsotnosti[0][3]=$SumOdsotnosti[0][3]+1;
										$SumOdsotnosti[$Indx1][3]=$SumOdsotnosti[$Indx1][3]+1;
										break;
									case 1:
										$SumOdsotnosti[0][1]=$SumOdsotnosti[0][1]+1;
										$SumOdsotnosti[$Indx1][1]=$SumOdsotnosti[$Indx1][1]+1;
										break;
									case 2:
										$SumOdsotnosti[0][2]=$SumOdsotnosti[0][2]+1;
										$SumOdsotnosti[$Indx1][2]=$SumOdsotnosti[$Indx1][2]+1;
								}
							}
						}
						for ($Indx1=1;$Indx1 <= 6;$Indx1++){
							$SumOdsotnosti[$Indx1][1]=0; // 'mesečna odsotnost Op
							$SumOdsotnosti[$Indx1][2]=0; // 'mesečna odsotnost NeOp
							$SumOdsotnosti[$Indx1][3]=0; // 'mesečna odsotnost Dr
							$SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND month(datum)=".$Indx1." AND idUcenec=".$R["iducenec"];
							$result1 = mysqli_query($link,$SQL);
							while ($R1 = mysqli_fetch_array($result1)){
								switch ( $R1["status"]){
									case 0:
										$SumOdsotnosti[0][3]=$SumOdsotnosti[0][3]+1;
										$SumOdsotnosti[$Indx1][3]=$SumOdsotnosti[$Indx1][3]+1;
										break;
									case 1:
										$SumOdsotnosti[0][1]=$SumOdsotnosti[0][1]+1;
										$SumOdsotnosti[$Indx1][1]=$SumOdsotnosti[$Indx1][1]+1;
										break;
									case 2:
										$SumOdsotnosti[0][2]=$SumOdsotnosti[0][2]+1;
										$SumOdsotnosti[$Indx1][2]=$SumOdsotnosti[$Indx1][2]+1;
								}
							}
						}
						//'izpiše podatke za učenca
						if ($Indx % 2 == 0){
							echo "<tr>";
						}else{
							echo "<tr bgcolor='lightgrey'>";
						}
						echo "<td>".$Indx."</td>";
						echo "<td><a href='dnevnik.php?idd=200&id=3&ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
						for ($Indx1=9;$Indx1 <= 12;$Indx1++){
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][1]."</td>";
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][2]."</td>";
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][3]."</td>";
						}
						for ($Indx1=1;$Indx1 <= 6;$Indx1++){
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][1]."</td>";
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][2]."</td>";
							echo "<td align='center'>".$SumOdsotnosti[$Indx1][3]."</td>";
						}
						echo "<td align='center'>".$SumOdsotnosti[0][1]."</td>";
						echo "<td align='center'>".$SumOdsotnosti[0][2]."</td>";
						echo "<td align='center'>".$SumOdsotnosti[0][3]."</td>";
						echo "</tr>";
					}
					echo "</table><br />";
					
					//'izpis opomb za učence po predmetih
					$SQL = "SELECT DISTINCT tabucenje.predmet,tabpredmeti.oznaka,tabpredmeti.vrstnired FROM (tabucenje ";
					$SQL = $SQL . " INNER JOIN tabrazred ON tabucenje.idRazred=tabrazred.idRazred) ";
					$SQL = $SQL . " INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id";
					$SQL = $SQL . " WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabucenje.idRazred=".$idRazred;
					$SQL = $SQL . " ORDER BY tabpredmeti.vrstniRed";
					$result = mysqli_query($link,$SQL);
					$Indx=0;
					while ($R = mysqli_fetch_array($result)){
						$Indx=$Indx+1;
						$SumOpombe[$Indx][0]=$R["predmet"];
						$SumOpombe[$Indx][1]=$R["oznaka"];
					}
					$StPredmetov=$Indx;
					
					echo "<h3>Spisek opomb za aktualni mesec</h3>";;
					echo "<table border='1' cellspacing='0'>";
					echo "<tr><th>št</th><th>ime</th>";
					for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
						echo "<th>".$SumOpombe[$Indx][1]."</th>";
					}
					echo "</tr>";
					$SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabucenci.iducenec FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE leto=".$VLeto." AND idRazred=".$idRazred." ORDER BY priimek,ime";
					$result = mysqli_query($link,$SQL);
					$Indx=0;
					while ($R = mysqli_fetch_array($result)){
						$Indx=$Indx+1;
						echo "<tr>";
						echo "<td>".$Indx."</td>";
						echo "<td><a href='dnevnik.php?idd=300&id=3&ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
						for ($Indx1=1;$Indx1 <= $StPredmetov;$Indx1++){
							echo "<td>";
							$SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND month(datum)=".$VDatum->format('n')." AND idUcenec=".$R["iducenec"]." AND predmet=".$SumOpombe[$Indx1][0];
							$result1 = mysqli_query($link,$SQL);
							$IndxOp=1;
							while ($R1 = mysqli_fetch_array($result1)){
								echo "<a href='dnevnik.php?idd=300&id=2&zapis=".$R1["ID"]."'>Op".$IndxOp."</a><br />";
								$IndxOp=$IndxOp+1;
							}
							echo "</td>";
						}
						echo "</tr>";
					}
					echo "</table><br />";
					
					//'ponudi pregled po predmetih določenega razreda
					echo "<h3>Pregled po predmetih</h3>";
					$SQL = "SELECT tabucenje.id,tabucenje.realizirano,tabpredmeti.opis,tabpredmeti.oznaka,tabucenje.razred,tabucenje.paralelka FROM tabucenje ";
					$SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
					$SQL = $SQL . " WHERE leto=".$VLeto." AND prioriteta IN (0,1) AND idRazred=".$idRazred;
					$SQL = $SQL . " ORDER BY VrstniRed";
					$result = mysqli_query($link,$SQL);
					echo "<form name='popredmetih' method='post' action='dnevnik.php'>";
					echo "<input name='idd' type='hidden' value='100'>";
					echo "<select name='predmet'>";
					while ($R = mysqli_fetch_array($result)){
						echo "<option value='".$R["id"]."'>";
						if ($R["realizirano"] > 0){
							echo $R["opis"]." (".$R["oznaka"].") - skupina ".$R["realizirano"].", ".$R["razred"].". ".$R["paralelka"];
						}else{
							echo $R["opis"]." (".$R["oznaka"]."), ".$R["razred"].". ".$R["paralelka"];
						}
						echo "</option>";
					}
					echo "</select>";
					echo "<input name='id' type='hidden' value='8'>";
					echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
					echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
					echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
					echo "<input name='ura' type='hidden' value='".$VUra."'>";
					echo "<input name='razred' type='hidden' value='".$idRazred."'>";
					echo "<input name='submit' type='submit' value='Izberi'><br />";
					echo "</form><br />";
				}
                break;
            case "5": // 'brisanje dnevniškega zapisa
                if ($VLevel > 1){
                    $SQL = "DELETE FROM tabdnevnikr WHERE idDnevnik=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    echo "Pobrisani podatki o predmetih v dnevniškem zapisu: ".$IzDnevnika."!<br />";
                    $SQL = "DELETE FROM tabdnevniku WHERE idDnevnik=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    echo "Pobrisani podatki o učencih v dnevniškem zapisu: ".$IzDnevnika."!<br />";
                    $SQL = "DELETE FROM tabodsotnostuc WHERE idDnevnik=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    echo "Pobrisani podatki o izostankih v dnevniškem zapisu: ".$IzDnevnika."!<br />";
                    $SQL = "DELETE FROM tabopombeuc WHERE idDnevnik=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    echo "Pobrisani podatki o opombah v dnevniškem zapisu: ".$IzDnevnika."!<br />";
                    $SQL = "DELETE FROM tabdnevnik WHERE id=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    echo "Pobrisan dnevniški zapis: ".$IzDnevnika."!<br />";
                }else{
                    echo "<h2>Nimate pooblastil za brisanje dnevniških zapisov!</h2>";
                }
                break;
            case "6": // 'vnos določene ure za določen razred s klicem iz razrednega tedenskega pregleda
				$n=$VLevel;
				include('menu_func.inc');
				include ('menu.inc');
                $VSkupina=0;
                $VPriprava=0;
                echo "<h2>Vnos dnevniškega zapisa</h2>";

                $VRefSt=0;
                $VSedRed=0;

                //'izbor datuma in ure
                echo "<form name='vnosUre' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<table border='0'>";
                echo "<tr><td>Datum</td><td>";
                echo "<select name='dan'>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    if ($Indx==$VDatum->format('j')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='mesec'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if ($Indx==$VDatum->format('n')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='letod'>";
                for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
                    if ($Indx==$VDatum->format('Y')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "</td></tr>";
                
                $VDanVTednu=$VDatum->format('w'); // '0-NED,1-PON ...6-SOB
                $VOpombe="";
                $VNaloge="";
                $VStatusUre=0;
                $urnikdan=$VDatum->format('Ymd');
                
                echo "<tr><td>Ura v urniku</td><td><b>".Int2Dan($VDanVTednu)."</b>&nbsp;";
                echo "<select name='ura'>";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    if ($Indx==$VUra){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."'>".$Indx."</option>";
                    }
                }
                echo "</select><input name='submit' type='submit' value='Izberi'></td></tr>";
                echo "</table><br />";
                echo "</form>";
                
                //'vnos ostalih podatkov
                if (isset($_GET["uciteljp"])){
                    $VUcitelj=intval($_GET["uciteljp"]);
                }else{
                    $VUcitelj="0";
                }
                $VRazred=$idRazred;
                $VPredmet="";
                //'prebere učitelje
                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcitelji[$Indx][0]=$R["iducitelj"];
                    $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    if ($VUcitelj == $VUcitelji[$Indx][0]){
                        $VUcitelji[$Indx][2]=1;
                    }else{
                        $VUcitelji[$Indx][2]=0;
                    }
                    $Indx=$Indx+1;
                }
                $StUciteljev=$Indx-1;

                echo "<a href='dnevnik.php?idd=100&id=11&dan=$VDan&mesec=$VMesec&letod=$VLeto&uciteljp=$VUcitelj'>Na tedenski urnik učitelja</a><br />";
                echo "<br />";
                //'prebere predmete
                $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta in (0,1,3) ORDER BY prioriteta,opis";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VPredmeti[$Indx][0]=$R["id"];
                    $VPredmeti[$Indx][1]=$R["opis"]." (".$R["oznaka"].")";
                    $VPredmeti[$Indx][2]=0;
                    $Indx=$Indx+1;
                }
                $StPredmetov=$Indx-1;
                
                //'prebere razrede
                $Count[1]=0; // 'razredi
                $VRazredi[0][0]=0;
                $VRazredi[0][1]="Ni izbran";
                $VRazredi[0][2]=0;
                $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VRazredi[$Indx][0]=$R["id"];
                    $VRazredi[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                    if ($idRazred==$R["id"]){
                        $VRazredi[$Indx][2]=1;
                        $Count[1]=$Count[1]+1;
                    }else{
                        $VRazredi[$Indx][2]=0;
                    }
                    $Indx=$Indx+1;
                }
                $StRazredov=$Indx-1;
                
                //'prebere priprave
                $VPriprave[0][0]=0;
                $VPriprave[0][1]="Ni izbrano";
                $VPriprave[0][2]=0;
                $SQL = "SELECT id,iducitelj,priprava FROM tabpriprava WHERE leto=".$VLeto." AND iducitelj = $IdUcitelj ORDER BY priprava";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VPriprave[$Indx][0]=$R["id"];
                    $VPriprave[$Indx][1]=$R["priprava"];
                    $VPriprave[$Indx][2]=0;
                    $Indx=$Indx+1;
                }
                $StPriprav=$Indx-1;
                
                //prebere ref. številke
                $SQL = "SELECT tabdnevnik.id,tabdnevnik.refid,tabdnevnik.predmet,tabdnevnik.skupina,tabdnevnik.razred,tabdnevnik.ucitelj,tabpredmeti.oznaka FROM (tabdnevnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE zapura=1 AND tabdnevnik.leto=".$VLeto." ORDER BY predmet,razred,ucitelj";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $refst[$Indx]["id"]=$R["id"];
                    $refst[$Indx]["oznaka"]=$R["oznaka"];
                    $refst[$Indx]["skupina"]=ToNivo($R["skupina"]);
                    $refst[$Indx]["razred"]="";
                    $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id IN (".$R["razred"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($refst[$Indx]["razred"])==0){
                            $refst[$Indx]["razred"]=$R1["razred"].$R1["oznaka"];
                        }else{
                            $refst[$Indx]["razred"]=$refst[$Indx]["razred"].",".$R1["razred"].$R1["oznaka"];
                        }
                    }
                    $refst[$Indx]["ucitelj"]="";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj IN (".$R["ucitelj"].") ORDER BY priimek,ime";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($refst[$Indx]["ucitelj"])==0){
                            $refst[$Indx]["ucitelj"]=mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                        }else{
                            $refst[$Indx]["ucitelj"]=$refst[$Indx]["ucitelj"].",".mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                        }
                    }
                    $Indx=$Indx+1;
                }   
                $StRefSt=$Indx-1;

                //prebere sedežne rede
                $SQL = "SELECT id,opomba FROM tabsedred WHERE leto=".$VLeto." ORDER BY opomba";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $sedred[$Indx]["id"]=$R["id"];
                    $sedred[$Indx]["opomba"]=$R["opomba"];
                    $Indx=$Indx+1;
                }
                $StSedRed=$Indx-1;
                
                $Count[2]=1; // 'ucitelji
                $Count[3]=1; // 'predmeti
                $VSkupina=0;

                //pogleda, če ima razred kaj v urniku
                if ($idRazred > 0){
                    //izpis za razred
                    $SQL = "SELECT id,idrazred,ucitelj,predmet,nivo FROM taburnik WHERE leto=".$VLeto." AND od <= ".$urnikdan." AND do >= ".$urnikdan." AND ura=".$VUra." AND DanVTednu=".$VDanVTednu." AND idrazred=".$idRazred;
                    $result = mysqli_query($link,$SQL);
                    if (mysqli_num_rows($result) > 0){
                        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                            $VUcitelji[$Indx][2]=0;
                        }
                        $Count[2]=0;
                    }
                    while ($R = mysqli_fetch_array($result)){
                        $VRazredRez="";
                        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                            if ($R["idrazred"]==$VRazredi[$Indx][0]){
                                $VRazredi[$Indx][2]=1;
                                if ($VRazred==0){
                                    $VRazred=$VRazredi[$Indx][0];
                                    $Count[1]=$Count[1]+1;
                                }else{
                                    if (!vsebuje($VRazred,$VRazredi[$Indx][0])){
                                        $VRazred=$VRazred.",".$VRazredi[$Indx][0];
                                        $Count[1]=$Count[1]+1;
                                    }
                                }
                                if (strlen($VRazredRez)==0){
                                    $VRazredRez=$VRazredi[$Indx][0];
                                }else{
                                    if (!vsebuje($VRazredRez,$VRazredi[$Indx][0])){
                                        $VRazredRez=$VRazredRez.",".$VRazredi[$Indx][0];
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                            if ($R["ucitelj"]==$VUcitelji[$Indx][0]){
                                $VUcitelji[$Indx][2]=1;
                                if ($VUcitelj==0){
                                    $VUcitelj=$VUcitelji[$Indx][0];
                                    $Count[2]=$Count[2]+1;
                                }else{
                                    if (!vsebuje($VUcitelj,$VUcitelji[$Indx][0])){
                                        $VUcitelj=$VUcitelj.",".$VUcitelji[$Indx][0];
                                        $Count[2]=$Count[2]+1;
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["predmet"]==$VPredmeti[$Indx][0]){
                                $VPredmeti[$Indx][2]=1;
                                $VPredmet=$VPredmeti[$Indx][0];
                                $Count[3]=1;
                            }
                        }
                        $VSkupina=$R["nivo"];
                    }
                    if (($Count[1] > 0) && ($Count[3] > 0)){ //'če obstajajo predmeti in razredi
                        if ($VSkupina != "0"){
                            $SQL = "SELECT * FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND skupina='".$VSkupina."' AND leto=$VLeto ORDER BY ZapUra DESC";
                        }else{
                            $SQL = "SELECT * FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND leto=$VLeto ORDER BY ZapUra DESC";
                        }
                        $result = mysqli_query($link,$SQL);
                        $VZapStUre=1;
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "SELECT * FROM tabrazdat WHERE id IN (".$VRazred.")";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                $VZapStUre=$R["ZapUra"]+1;
                                $VRefSt=$R["refid"];
                                $VSedRed=$R["idsedred"];
                            }
                        }
                    }else{
                        $VZapStUre=1;
                    }
                }else{ //izpis za učitelja
                    $SQL = "SELECT id,idrazred,ucitelj,predmet,nivo FROM taburnik WHERE leto=".$VLeto." AND od <= ".$urnikdan." AND do >= ".$urnikdan." AND ura=".$VUra." AND DanVTednu=".$VDanVTednu." AND ucitelj=".$VUcitelj;
                    $result = mysqli_query($link,$SQL);
                    if (mysqli_num_rows($result) > 0){
                        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                            $VRazredi[$Indx][2]=0;
                        }
                        $Count[1]=0;
                    }
                    while ($R = mysqli_fetch_array($result)){
                        $VRazredRez="";
                        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                            if ($R["idrazred"]==$VRazredi[$Indx][0]){
                                $VRazredi[$Indx][2]=1;
                                if ($VRazred==0){
                                    $VRazred=$VRazredi[$Indx][0];
                                    $Count[1]=$Count[1]+1;
                                }else{
                                    if (!vsebuje($VRazred,$VRazredi[$Indx][0])){
                                        $VRazred=$VRazred.",".$VRazredi[$Indx][0];
                                        $Count[1]=$Count[1]+1;
                                    }
                                }
                                if (strlen($VRazredRez)==0){
                                    $VRazredRez=$VRazredi[$Indx][0];
                                }else{
                                    if (!vsebuje($VRazredRez,$VRazredi[$Indx][0])){
                                        $VRazredRez=$VRazredRez.",".$VRazredi[$Indx][0];
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                            if ($R["ucitelj"]==$VUcitelji[$Indx][0]){
                                $VUcitelji[$Indx][2]=1;
                                if ($VUcitelj==0){
                                    $VUcitelj=$VUcitelji[$Indx][0];
                                    $Count[2]=$Count[2]+1;
                                }else{
                                    if (!vsebuje($VUcitelj,$VUcitelji[$Indx][0])){
                                        $VUcitelj=$VUcitelj.",".$VUcitelji[$Indx][0];
                                        $Count[2]=$Count[2]+1;
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["predmet"]==$VPredmeti[$Indx][0]){
                                $VPredmeti[$Indx][2]=1;
                                $VPredmet=$VPredmeti[$Indx][0];
                                $Count[3]=1;
                            }
                        }
                        $SQL = "SELECT id,oznaka,prioriteta FROM tabpredmeti WHERE id=".$VPredmet;
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            switch ($R1["prioriteta"]){
                                case 1:
                                    $VSkupina=4;
                                    break;
                                case 3:
                                    switch ($R1["oznaka"]){
                                        case "PB01":
                                        case "PB02":
                                        case "PB03":
                                        case "PB04":
                                        case "PB05":
                                        case "PB06":
                                        case "PB07":
                                        case "PB08":
                                        case "PB09":
                                        case "PB10":
                                        case "PB11":
                                        case "PB12":
                                        case "PB13":
                                        case "PB14":
                                        case "OPB":
                                            $VSkupina=5;
                                            break;
                                        case "JUV":
                                            $VSkupina=6;
                                            break;
                                        default:
                                            $VSkupina=$R["nivo"];
                                    }
                                    break;
                                default:
                                    $VSkupina=$R["nivo"];
                            }
                        }else{
                            $VSkupina=$R["nivo"];
                        }
                    }
                    if (($Count[1] > 0) && ($Count[3] > 0)){ //'če obstajajo predmeti in razredi
                        if ($VSkupina != "0"){
                            $SQL = "SELECT * FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND skupina='".$VSkupina."' AND leto=".$VLeto." ORDER BY ZapUra DESC";
                        }else{
                            $SQL = "SELECT * FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND leto=$VLeto ORDER BY ZapUra DESC";
                        }
                        $result = mysqli_query($link,$SQL);
                        $VZapStUre=1;
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "SELECT * FROM tabrazdat WHERE id IN (".$VRazred.")";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                $VZapStUre=$R["ZapUra"]+1;
                                $VRefSt=$R["refid"];
                                $VSedRed=$R["idsedred"];
                            }
                        }
                        $idRazred=$VRazred;
                    }else{
                        $VZapStUre=1;
                    }
                }
                
                IzpisUrnihPodatkov();
                echo "<font color='red'>Pri izbiri dodatnih (več izbir) učiteljev in razredov uporabite <b>Ctrl</b>+klik</font><br /><br />";
                
                //'izpis podatkov o učencih
                
                if ($idRazred > 0){
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE leto=".$VLeto." AND idRazred IN (".$idRazred.") ";
                    $SQL = $SQL . "ORDER BY razred,paralelka,priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr  style='background-color:lightcyan;'><th>št.</th><th>Ime</th><th>Izostanki</th><th>Opombe</th></tr>";
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $IzpisiUcenca=false;
                        switch ( $VSkupina){
                            case 1:
                            case 2:
                            case 3:
                            case 7:
                            case 8:
                            case 9:
                                if (vsebuje($VPredmet,$OznakaSport)){
                                    //'v primeru športne vzgoje razdeli na fante in dekleta
                                    if ($VSkupina==1){
                                        if ($R["spol"]=="M"){
                                            $IzpisiUcenca=true;
                                        }
                                    }else{
                                        if ($R["spol"]=="F"){
                                            $IzpisiUcenca=true;
                                        }
                                    }
                                }else{
                                    $SQL = "SELECT * FROM tabnivoji WHERE leto=".$VLeto." AND Nivoji IN (".Skupina2Nivo($VSkupina,$VPredmet).") AND ucenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        $IzpisiUcenca=true;
                                    }
                                }
                                break;
                            case 4:
                                $SQL = "SELECT * FROM tabizbirni WHERE leto=".$VLeto." AND Izbirni IN (".$VPredmet.") AND ucenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    $IzpisiUcenca=true;
                                }
                                break;
                            case 5:
                                $SQL = "SELECT * FROM tabopb WHERE leto=".$VLeto." AND ucenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                if (vsebuje($VPredmet,"78") && $R1["pb1"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"79") && $R1["pb2"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"80") && $R1["pb3"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"81") && $R1["pb4"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"82") && $R1["pb5"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"83") && $R1["pb6"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"84") && $R1["pb7"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"85") && $R1["pb8"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"86") && $R1["pb9"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"87") && $R1["pb10"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"88") && $R1["pb11"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"89") && $R1["pb12"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"90") && $R1["pb13"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"91") && $R1["pb14"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"52") && $R1["pb15"]) $IzpisiUcenca=true;
                                break;
                            case 6:
                                //jutranje varstvo
                                if (vsebuje($VPredmet,"62")){
                                    $SQL = "SELECT * FROM tabopb WHERE leto=".$VLeto." AND ucenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        if ($R1["juv"]) $IzpisiUcenca=true;
                                    }
                                }else{
                                    $IzpisUcenca=true;
                                }
                                break;
                            default:
                                $IzpisiUcenca=true;
                        }
                        if ($IzpisiUcenca){
                            $Indx=$Indx+1;
                            if ($Indx % 2 == 0){
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"]." AND status < 3";
                                $result1 = mysqli_query($link,$SQL);
                                echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                                if ($R1 = mysqli_fetch_array($result1)){
                                    echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                                }else{
                                    echo "<input name='ods_".$Indx."' type='checkbox'>";
                                }
                                if ($VUra > 0){
                                    $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                    }
                                }
                                
                                echo "</td>";
                                
                                $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                                if ($R1 = mysqli_fetch_array($result1)){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'>".$R1["opomba"]."</textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'></textarea>";
                                }
                                if ($VUra > 0){
                                    $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                    }
                                }
                                echo "</td>";
                                
                                echo "</tr>";
                            }else{
                                echo "<tr style='background-color:lightgrey;'>";
                                echo "<td>".$Indx."</td>";
                                echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"]." AND status < 3";
                                $result1 = mysqli_query($link,$SQL);
                                echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                                if ($R1 = mysqli_fetch_array($result1)){
                                    echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                                }else{
                                    echo "<input name='ods_".$Indx."' type='checkbox'>";
                                }
                                if ($VUra > 0){
                                    $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                    }
                                }
                                
                                echo "</td>";
                                
                                $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                                if ($R1 = mysqli_fetch_array($result1)){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'>".$R1["opomba"]."</textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'></textarea>";
                                }
                                if ($VUra > 0){
                                    $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                    }
                                }
                                echo "</td>";
                                
                                echo "</tr>";
                            }
                        }
                    }
                    echo "</table><br />";
                    echo "<input name='stucencev' type='hidden' value='".$Indx."'>";
                }else{
                    echo "<input name='stucencev' type='hidden' value='0'>";
                }
                echo "<input name='id' type='hidden' value='1'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form><br />";
                break;
            case "7": // 'išče učence
				$n=$VLevel;
				include('menu_func.inc');
				include ('menu.inc');
                
                if (isset($_POST["priprava"])){
                    $VPriprava=$_POST["priprava"];
                }else{
                    $VPriprava=0;
                }
                $VRefSt=0;
                if (isset($_POST["sedred"])){
                    $VSedRed=intval($_POST["sedred"]);
                }else{
                    $VSedRed=0;
                }
                echo "<h2>Vnos dnevniškega zapisa</h2>";
                //'izbor datuma in ure
                echo "<form name='vnosUre' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<table border='0'>";
                echo "<tr><td>Datum</td><td>";
                echo "<select name='dan'>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    if ($Indx==$VDatum->format('j')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='mesec'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if ($Indx==$VDatum->format('n')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='letod'>";
                for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                    if ($Indx==$VDatum->format('Y')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "</td></tr>";
                
                $VDanVTednu=$VDatum->format('w'); // '1. dan je ponedeljek
                $VStatusUre=$VStatus;
                echo "<tr><td>Ura v urniku</td><td><b>".Int2Dan($VDanVTednu)."</b>&nbsp;";
                echo "<select name='ura'>";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    if ($Indx==$VUra){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."'>".$Indx."</option>";
                    }
                }
                echo "</select><input name='submit' type='submit' value='Izberi'></td></tr>";
                echo "</table><br />";
                echo "</form><br>";
                
                //'izbor drugega pouka iz dnevnika (če je drug učitelj, ...)
                echo "<form name='vnosIzDnevnika' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
                echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
                echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<select name='izdnevnika'>";
                $SQL = "SELECT tabdnevnik.id AS did,tabdnevnik.skupina,tabpredmeti.opis AS popis FROM (tabdnevnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["did"]."'>";
                    $SQL = "SELECT tabdnevnikr.*,tabrazdat.* FROM tabdnevnikr INNER JOIN tabrazdat ON tabdnevnikr.idRazred=tabrazdat.id WHERE idDnevnik=".$R["did"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["razred"].". ".$R1["oznaka"].", ";
                    }
                    echo $R["popis"]." (".ToNivo($R["skupina"]).") - ";
                    
                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"].", ";
                    }
                    echo "</option>";
                }
                echo "</select>";
                echo "<input name='submit' type='submit' value='Izberi iz dnevnika'>";
                echo "</form>";
                        
                //'izbor drugega pouka iz urnika (če je drug učitelj, ...)
                echo "<form name='vnospouka' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
                echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
                echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<select name='pouk'>";
                $urnikdan=$VDatum->format('Ymd');
                $SQL = "SELECT taburnik.id AS uid,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,taburnik.razred,taburnik.paralelka,taburnik.nivo FROM (taburnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj ";
                $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND taburnik.od <= ".$urnikdan." AND taburnik.do >= ".$urnikdan." AND DanVTednu=".$VDanVTednu." AND ura=".$VUra;
                $SQL = $SQL . " ORDER BY razred,paralelka";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($VPouk > 0){
                        if ($VPouk==$R["uid"]){
                            echo "<option value='".$R["uid"]."' selected='selected'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                        }else{
                            echo "<option value='".$R["uid"]."'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                        }
                    }else{
                        echo "<option value='".$R["uid"]."'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                    }
                }
                echo "</select>";
                echo "<input name='submit' type='submit' value='Izberi iz urnika'>";
                echo "</form><br>";
                        
                //'vnos ostalih podatkov
                if (strlen($VUcitelj) == 0){
                    header ("Location: dnevnik.php?idd=100");
                }
                if ($VPredmet > 0){ 
                    $VSkupina=$VNivo;
                    //'prebere učitelje
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$VUcitelj.") ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VUcitelji[$Indx][0]=$R["iducitelj"];
                        $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                        $VUcitelji[$Indx][2]=1;
                        $Indx=$Indx+1;
                    }
                    $StUciteljev=$Indx-1;
                    
                    //'prebere predmete
                    if (strlen($VPredmet)==0){
                        $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1,3) ORDER BY prioriteta,opis";
                    }else{
                        $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE id =".$VPredmet." ORDER BY prioriteta,opis";
                    }
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VPredmeti[$Indx][0]=$R["id"];
                        $VPredmeti[$Indx][1]=$R["opis"]." (".$R["oznaka"].")";
                        if (strlen($VPredmet)==0){
                            $VPredmeti[$Indx][2]=0;
                        }else{
                            $VPredmeti[$Indx][2]=1;
                            $VPredmetOzn=$R["oznaka"];
                        }
                        $Indx=$Indx+1;
                    }
                    $StPredmetov=$Indx-1;
                    
                    //'prebere razrede
                    $VRazredi[0][0]=0;
                    $VRazredi[0][1]="Ni izbran";
                    $VRazredi[0][2]=0;
                    if ($VRazred == 0){
                        $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
                    }else{
                        $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE id IN (".$VRazred.") ORDER BY razred,oznaka";
                    }
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VRazredi[$Indx][0]=$R["id"];
                        $VRazredi[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                        if ($VRazred == 0){
                            $VRazredi[$Indx][2]=0;
                        }else{
                            $VRazredi[$Indx][2]=1;
                        }
                        $Indx=$Indx+1;
                    }
                    $StRazredov=$Indx-1;
                    
                    //'prebere priprave
                    $VPriprave[0][0]=0;
                    $VPriprave[0][1]="Ni izbrano";
                    $VPriprave[0][2]=0;
                    $SQL = "SELECT id,iducitelj,priprava FROM tabpriprava WHERE leto=".$VLeto." AND iducitelj = $IdUcitelj ORDER BY priprava";
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VPriprave[$Indx][0]=$R["id"];
                        $VPriprave[$Indx][1]=$R["priprava"];
                        $VPriprave[$Indx][2]=0;
                        $Indx=$Indx+1;
                    }
                    $StPriprav=$Indx-1;
                    
                    //prebere ref. številke
                    $SQL = "SELECT tabdnevnik.id,tabdnevnik.refid,tabdnevnik.predmet,tabdnevnik.skupina,tabdnevnik.razred,tabdnevnik.ucitelj,tabpredmeti.oznaka FROM (tabdnevnik ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE zapura=1 AND tabdnevnik.leto=".$VLeto." ORDER BY predmet,razred,ucitelj";
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $refst[$Indx]["id"]=$R["id"];
                        $refst[$Indx]["oznaka"]=$R["oznaka"];
                        $refst[$Indx]["skupina"]=ToNivo($R["skupina"]);
                        $refst[$Indx]["razred"]="";
                        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id IN (".$R["razred"].")";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            if (strlen($refst[$Indx]["razred"])==0){
                                $refst[$Indx]["razred"]=$R1["razred"].$R1["oznaka"];
                            }else{
                                $refst[$Indx]["razred"]=$refst[$Indx]["razred"].",".$R1["razred"].$R1["oznaka"];
                            }
                        }
                        $refst[$Indx]["ucitelj"]="";
                        $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj IN (".$R["ucitelj"].") ORDER BY priimek,ime";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            if (strlen($refst[$Indx]["ucitelj"])==0){
                                $refst[$Indx]["ucitelj"]=mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                            }else{
                                $refst[$Indx]["ucitelj"]=$refst[$Indx]["ucitelj"].",".mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                            }
                        }
                        $Indx=$Indx+1;
                    }   
                    $StRefSt=$Indx-1;
                    
                    //prebere sedežne rede
                    $SQL = "SELECT id,opomba FROM tabsedred WHERE leto=".$VLeto." ORDER BY opomba";
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $sedred[$Indx]["id"]=$R["id"];
                        $sedred[$Indx]["opomba"]=$R["opomba"];
                        $Indx=$Indx+1;
                    }
                    $StSedRed=$Indx-1;
                    //'v urnik pogleda uro za učitelja
                    
                    $Count[1]=$StRazredov; // 'razredi
                    $Count[2]=$StUciteljev; // 'ucitelji
                    $Count[3]=$StPredmetov; // 'predmeti
                    
                    IzpisUrnihPodatkov();
                    echo "<div>Za dneve dejavnosti nastavite: Predmet (Dan dejavnosti), Skupina (Drugo), Zap.št.ure (1 za prvo uro, 2 za drugo, ...), Status (ustrezna izbira)<br />";
                    echo "<font color='red'>Pri izbiri dodatnih (več izbir) učiteljev in razredov uporabite <b>Ctrl</b>+klik</font><br />";
                    echo "<font color='blue'>Za predmete/dejavnosti, ki niso v urniku, izberite predmet/dejavnost, razred in učitelja ter kliknite na Poišči učence. Nato vnestite ostale podatke. </font></p>";
                    
                    //'izpis podatkov o učencih na osnovi izbranega predmeta
                    
                    echo "<div id='izpisucencev'>";
                    
                    for ($Indx=0;$Indx <= 1000;$Indx++){
                        $VUcenci[$Indx]=0;
                    }
                    if ($VSedRed > 0){
                        $SQL = "SELECT tabsedredu.iducenec FROM tabsedred INNER JOIN tabsedredu ON tabsedred.iducenci=tabsedredu.iducenci WHERE tabsedred.id=".$VSedRed;
                    }else{
                        switch ( $VPredmetOzn){
                            case "OPB": // '52    'OPB
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb15=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "JUV": // '62    'JUV
                                if (strlen($VRazred) > 0){
                                    $SQL = "SELECT DISTINCT tabopb.iducenec,tabrazred.idRazred FROM (tabopb ";
                                    $SQL = $SQL . "INNER JOIN tabrazred ON tabopb.idUcenec=tabrazred.idUcenec) ";
                                    $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                    $SQL = $SQL . " WHERE tabopb.leto=".$VLeto." AND juv=true AND tabrazred.idRazred IN (".$VRazred.")";
                                    $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                }else{
                                    $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                    $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                    $SQL = $SQL . "WHERE leto=".$VLeto." AND juv=true";
                                    $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                }
                                break;
                            case "PB01": // '78    'pb1
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb1=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB02": // '79    'pb2
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb2=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB03": // '80    'pb3
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb3=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB04": // '81    'pb4
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb4=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB05": // '82    'pb5
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb5=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB06": // '83    'pb6
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb6=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB07": // '84    'pb7
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb7=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB08": // '85    'pb8
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb8=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB09": // '86    'pb9
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb9=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB10": // '87    'pb10
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb10=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB11": // '88    'pb11
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb11=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB12": // '89    'pb12
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb12=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB13": // '90    'pb13
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb13=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            case "PB14": // '91    'pb14
                                $SQL = "SELECT DISTINCT tabopb.iducenec FROM tabopb ";
                                $SQL = $SQL . "INNER JOIN tabucenci ON tabopb.iducenec=tabucenci.iducenec ";
                                $SQL = $SQL . "WHERE leto=".$VLeto." AND pb14=true";
                                $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                break;
                            default:    //'ostali predmeti
                                $SQL = "SELECT * FROM tabpredmeti WHERE id=".$VPredmet;
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    switch ( $R1["Prioriteta"]){
                                        case 0: //    'redni predmet
                                            if (strlen($VRazred) > 0){
                                                switch ( $VSkupina){
                                                    case 0: //    'samostojen predmet
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabucenje ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenje.idRazred=tabrazred.idRazred) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabrazred.idRazred IN (".$VRazred.") AND tabucenje.predmet=".$VPredmet;
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                    case 7:
                                                    case 8:
                                                    case 9: //    'skupine/nivoji
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM ((tabucenje ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenje.idRazred=tabrazred.idRazred) ";
                                                        $SQL = $SQL . "INNER JOIN tabnivoji ON tabrazred.idUcenec=tabnivoji.Ucenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabrazred.idRazred IN (".$VRazred.") AND tabucenje.predmet=".$VPredmet." AND tabnivoji.Nivoji IN (".Skupina2Nivo($VSkupina,$VPredmet).")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                }
                                            }else{
                                                $SQL ="";
                                            }
                                            break;
                                        case 1: //    'izbirni predmet
                                            $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabizbirni ";
                                            $SQL = $SQL . "INNER JOIN tabrazred ON tabizbirni.Ucenec=tabrazred.idUcenec) ";
                                            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                            $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND Izbirni=".$VPredmet;
                                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                            break;
                                        default:  //  'druge dejavnosti: DOD/DOP
                                            if (strlen($VRazred) > 0){
                                                switch ( $R1["Oznaka"]){
                                                    case "DD":
                                                        $SQL = "SELECT DISTINCT tabdodpouk.iducenec,tabrazred.idrazred FROM (tabdodpouk ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.idUcenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabdodpouk.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdodpouk.pomoc IN (3,4) AND tabrazred.idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "DOD":
                                                        $SQL = "SELECT DISTINCT tabdodpouk.iducenec,tabrazred.idrazred FROM (tabdodpouk ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.idUcenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabdodpouk.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdodpouk.pomoc =3 AND tabrazred.idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "DOP":
                                                        $SQL = "SELECT DISTINCT tabdodpouk.iducenec,tabrazred.idrazred FROM tabdodpouk ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.idUcenec=tabrazred.idUcenec ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabdodpouk.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdodpouk.pomoc =4 AND tabrazred.idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "KOL":
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM tabrazred ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "DSP":
                                                        $SQL = "SELECT DISTINCT tabdodpouk.iducenec,tabrazred.idrazred FROM (tabdodpouk ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.idUcenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabdodpouk.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdodpouk.pomoc =2 AND tabrazred.idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "ISP":
                                                        $SQL = "SELECT DISTINCT tabdodpouk.iducenec,tabrazred.idrazred FROM (tabdodpouk ";
                                                        $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.idUcenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabdodpouk.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdodpouk.pomoc =1 AND tabrazred.idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "BZ":
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM tabrazred ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "DrDe": // 'druge dejavnosti
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM tabrazred ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "MPZ": // 'pevski zbor
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabizbirni INNER JOIN tabrazred ON tabizbirni.Ucenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND Izbirni=".$VPredmet;
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "OPZ": // 'pevski zbor
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabizbirni INNER JOIN tabrazred ON tabizbirni.Ucenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND Izbirni=".$VPredmet;
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    default:
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM tabrazred ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE idRazred IN (".$VRazred.")";
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                }
                                            }else{
                                                $SQL="";
                                                switch ( $R1["Oznaka"]){
                                                    case "MPZ": // 'pevski zbor
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabizbirni INNER JOIN tabrazred ON tabizbirni.Ucenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND Izbirni=".$VPredmet;
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                        break;
                                                    case "OPZ": // 'pevski zbor
                                                        $SQL = "SELECT DISTINCT tabucenci.iducenec FROM (tabizbirni INNER JOIN tabrazred ON tabizbirni.Ucenec=tabrazred.idUcenec) ";
                                                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                                                        $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND Izbirni=".$VPredmet;
                                                        $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                                                }
                                            }
                                    }
                                }
                        }
                    }
                    if (strlen($SQL) > 0){
                        $result1 = mysqli_query($link,$SQL);
                        $Indx=0;
                        while ($R1 = mysqli_fetch_array($result1)){
                            $Indx=$Indx+1;
                            $VUcenci[$Indx]=$R1["iducenec"];
                        }
                        $StUcencev=$Indx;
                        
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "<br />";
                        
                        echo "<table border='1' cellspacing='0'>";
                        echo "<tr style='background-color:lightcyan;'><th>št.</th><th>Ime</th><th>Izostanki</th><th>Opombe</th><th>Redovalnica<br />Pisno | Ustno</th></tr>";
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            $SQL = "SELECT tabucenci.iducenec AS uid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred FROM tabrazred ";
                            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                            $SQL = $SQL . "WHERE leto=".$VLeto." AND tabucenci.idUcenec=".$VUcenci[$Indx];
                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                //'pripravi seznam razredov pri pouku
                                for ($Indx1=1;$Indx1 <= $StRazredov;$Indx1++){
                                    if ($VRazredi[$Indx1][0]==$R["idrazred"]){
                                        $VRazredi[$Indx1][2]=1;
                                    }
                                }
                                if ($Indx % 2 == 0){
                                    echo "<tr>";
                                    //izpis odostnosti
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["uid"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                                    $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["uid"]." AND status < 3";
                                    $result1 = mysqli_query($link,$SQL);
                                    echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["uid"]."'>";
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                                    }else{
                                        echo "<input name='ods_".$Indx."' type='checkbox'>";
                                    }
                                    if ($VUra > 0){
                                        $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["uid"];
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                        }
                                    }
                                    
                                    echo "</td>";
                                    //izpis opomb
                                    $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["uid"];
                                    $result1 = mysqli_query($link,$SQL);
                                    echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["uid"]."'>";
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        echo "<textarea name='op_".$Indx."' cols='40' rows='2'>".$R1["opomba"]."</textarea>";
                                    }else{
                                        echo "<textarea name='op_".$Indx."' cols='40' rows='2'></textarea>";
                                    }
                                    if ($VUra > 0){
                                        $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["uid"];
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                        }
                                    }
                                    echo "</td>";

                                    //izpis redovalnice
                                    echo "<td>";
                                    if ($R["razred"] > 2){
                                        $SQL = "SELECT id,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$R["uid"]." AND idpredmet IN (".$VPredmet.")";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                            //echo "<input name='idd' type='hidden' value='100'>";
                                            //echo "<input name='id' type='hidden' value='10'>";
                                            echo "<table border='1'>";
                                            echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["uid"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."'></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."'</td></tr>";
                                            echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."'></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."'</td></tr>";
                                            echo "</table>";
                                            //echo "<input name='submit' type='submit' value='Oceni'>";
                                            //echo "</form>";
                                        }else{
                                            //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                            //echo "<input name='idd' type='hidden' value='100'>";
                                            //echo "<input name='id' type='hidden' value='10'>";
                                            echo "<table border='1'>";
                                            echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["uid"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value=''></td><td><input name='s1u_".$Indx."' type='text' value=''</td></tr>";
                                            echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value=''></td><td><input name='s2u_".$Indx."' type='text' value=''</td></tr>";
                                            echo "</table>";
                                            //echo "<input name='submit' type='submit' value='Oceni'>";
                                            //echo "</form>";
                                        }
                                    }
                                    echo "</td>";
                                    
                                    echo "</tr>";
                                }else{
                                    echo "<tr style='background-color:lightgrey;'>";
                                    //izpis odostnosti
                                    echo "<td>".$Indx."</td>";
                                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["uid"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                                    $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["uid"]." AND status < 3";
                                    $result1 = mysqli_query($link,$SQL);
                                    echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["uid"]."'>";
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                                    }else{
                                        echo "<input name='ods_".$Indx."' type='checkbox'>";
                                    }
                                    if ($VUra > 0){
                                        $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["uid"];
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                        }
                                    }
                                    
                                    echo "</td>";
                                    //izpis opomb
                                    $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["uid"];
                                    $result1 = mysqli_query($link,$SQL);
                                    echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["uid"]."'>";
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'>".$R1["opomba"]."</textarea>";
                                    }else{
                                        echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'></textarea>";
                                    }
                                    if ($VUra > 0){
                                        $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["uid"];
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                        }
                                    }
                                    echo "</td>";

                                    //izpis redovalnice
                                    echo "<td>";
                                    if ($R["razred"] > 2){
                                        $SQL = "SELECT id,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$R["uid"]." AND idpredmet IN (".$VPredmet.")";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                            //echo "<input name='idd' type='hidden' value='100'>";
                                            //echo "<input name='id' type='hidden' value='10'>";
                                            echo "<table border='1' style='background-color:lightgrey;'>";
                                            echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["uid"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."' style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."' style='background-color:lightgrey;'></td></tr>";
                                            echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."' style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."' style='background-color:lightgrey;'></td></tr>";
                                            echo "</table>";
                                            //echo "<input name='submit' type='submit' value='Oceni'>";
                                            //echo "</form>";
                                        }else{
                                            //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                            //echo "<input name='idd' type='hidden' value='100'>";
                                            //echo "<input name='id' type='hidden' value='10'>";
                                            echo "<table border='1' style='background-color:lightgrey;'>";
                                            echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["uid"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td></tr>";
                                            echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td></tr>";
                                            echo "</table>";
                                            //echo "<input name='submit' type='submit' value='Oceni'>";
                                            //echo "</form>";
                                        }
                                    }
                                    echo "</td>";
                                    
                                    echo "</tr>";
                                }
                            }
                        }
                        echo "</table><br />";
                        //'če razredi niso bili poslani, pogleda po učencih in kreira niz
                        if ($VRazred==0){
                            for ($Indx1=1;$Indx1 <= $StRazredov;$Indx1++){
                                if ($VRazredi[$Indx1][2]==1){
                                    if ($VRazred==0){
                                        $VRazred=$VRazredi[$Indx1][0];
                                    }else{
                                        if (!vsebuje($VRazred,$VRazredi[$Indx1][0])){
                                            $VRazred=$VRazred.",".$VRazredi[$Indx1][0];
                                        }
                                    }
                                }
                            }
                            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                        }
                        echo "<input name='stucencev' type='hidden' value='".$StUcencev."'>";
                        echo "</div>";
                        echo "<input name='id' type='hidden' value='1'>";
                        echo "<input name='redovalnica' type='checkbox'>dovoli vpis ocen<br />";
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form><br />";
                    }else{
                        echo "<h3>Niste izbrali razreda!</h3>";
                    }
                }
                break;
            case "8": // 'izpis dnevniških zapisov predmeta/učenja
				$n=$VLevel;
				include('menu_func.inc');
				include ('menu.inc');
                $idRazred=$VRazred;
                $VUcenje=$VPredmet;
                $SQL = "SELECT * FROM tabucenje WHERE id=".$VUcenje;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<br /><table border='1'>";
                    echo "<tr><th>Št.</th><th>Datum</th><th>Predmet</th><th>Skupina</th><th>Razred</th><th>Zap. ura</th><th>Dn. zapis</th><th>Dom. naloge</th><th>Priprava</th><th>Učitelj</th><th>Status</th><th>Vpisano</th><th>Spremenjeno</th><th>Odsotni</th><th>Opombe</th></tr>";
                    $VPredmet=intval($R["Predmet"]);
                    if (intval($R["Realizirano"]) > 0){
                        //če je izbrana skupina, jo upošteva
                        $VSkupina=$R["Realizirano"];
                    }else{
                        //če ni izbrana skupina (=0), potem pogleda, kako je z rubriko Zdruzevanje
                        switch (intval($R["Zdruzeno"])){
                            case 2: //izbirni
                                $VSkupina=101;
                                break;
                            case 3: //drugo
                                //preveri, če gre za OPB
                                switch ($VPredmet){
                                    case 50:
                                    case 78:
                                    case 79:
                                    case 80:
                                    case 81:
                                    case 82:
                                    case 83:
                                    case 84:
                                    case 85:
                                    case 86:
                                    case 87:
                                    case 88:
                                    case 89:
                                    case 90:
                                    case 91:
                                        $VSkupina=102;
                                        break;
                                    default:
                                        $VSkupina=103;
                                }
                                break;
                            default:  //0,1 če ni skupin
                                $VSkupina=0;
                        }
                    }
                    
                    $SQL = "SELECT tabdnevnik.*,tabdnevnik.opis AS dopis,tabpredmeti.Opis AS popis,tabpredmeti.oznaka,tabsifrantstatusure.opis AS sopis FROM ((tabdnevnik ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "INNER JOIN tabsifrantstatusure ON tabdnevnik.statusUre=tabsifrantstatusure.idStatusUre) ";
                    //$SQL = $SQL . "LEFT JOIN tabpriprava ON tabdnevnik.idpriprava=tabpriprava.id ";
                    $SQL = $SQL . "WHERE predmet=".$VPredmet." AND skupina='".ToSkupina($VSkupina)."'";
                    $SQL = $SQL . " ORDER BY datum,ZapUra";
                    $result1 = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (vsebuje($R1["razred"],$idRazred) > 0){
                            $Indx=$Indx+1;
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            $Datum=new DateTime(isDate($R1["datum"]));
                            echo "<td>".$Datum->format('d.m.Y')."</td>";
                            echo "<td>".$R1["popis"]." (".$R1["oznaka"].")</td>";
                            echo "<td>".ToNivo($R1["skupina"])."</td>";
                            
                            echo "<td>";
                            $SQL = "SELECT * FROM tabrazdat WHERE id IN (".$R1["razred"].")";
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["razred"].". ".$R2["oznaka"]." ";
                            }
                            echo "</td>";
                            
                            echo "<td>".$R1["ZapUra"]."</td>";
                            echo "<td>".$R1["dopis"]."</td>";
                            echo "<td>".$R1["naloge"]."</td>";
                            //priprava
                            if (isset($R1["idpriprava"])){
                                $SQL = "SELECT priprava FROM tabpriprava WHERE id=".$R1["idpriprava"];
                                $result2 = mysqli_query($link,$SQL);
                                if ($R2 = mysqli_fetch_array($result2)){
                                    echo "<td><a href='upload/priprave/".$R2["priprava"]."' target='_blank'>".$R2["priprava"]."</a></td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                }
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                            
                            echo "<td>";
                            $SQL = "SELECT ime,priimek FROM tabucitelji WHERE idUcitelj IN (".$R1["ucitelj"].")";
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]."<br />";
                            }
                            echo "</td>";
                            
                            echo "<td>".$R1["sopis"]."</td>";
                            echo "<td>".$R1["casvp"]."</td>";
                            echo "<td>".$R1["casSpr"]."</td>";
                            
                            //'odsotni
                            echo "<td>";
                            $SQL = "SELECT tabucenci.priimek,tabucenci.ime FROM tabodsotnostuc INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec WHERE idDnevnik=".$R1["ID"];
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]."<br />";
                            }
                            echo "</td>";
                            
                            //'opombe
                            echo "<td>";
                            $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopombeuc.opomba FROM tabopombeuc INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec WHERE idDnevnik=".$R1["ID"];
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["ime"]." ".$R2["priimek"]." ".$R2["opomba"]."<br />";
                            }
                            echo "</td>";
                            
                            echo "</tr>";
                        }
                    }
                    echo "</table><br />";
                }
                break;
            case "9": // 'izpiše poročila za vse razrede za določen mesec
                //'naprej/nazaj/datum
				$n=$VLevel;
				include('menu_func.inc');
				include ('menu.inc');
                echo "<form name='izborDatuma' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='id' type='hidden' value='9'>";
                echo "Pregled za mesec/leto ";
                echo "<input name='dan' type='hidden' value='1'>";
                echo "<select name='mesec'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if ($Indx==$VDatum->format('n')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='letod'>";
                for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                    if ($Indx==$VDatum->format('Y')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                
                echo "<input name='submit' type='submit' value='Izberi'>";
                echo "</form><br>";

                $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Indx=$Indx+1;
                    $VRazredi[$Indx][0]=$R["id"];
                    $VRazredi[$Indx][1]=$R["razred"];
                    $VRazredi[$Indx][2]=$R["oznaka"];
                }
                $StRazredov=$Indx;
                
                $VDatumZac=new DateTime($VDatum->format('Y-m-d'));
                
                //'izpisi za vse razrede
                for ($IndxR=1;$IndxR <= $StRazredov;$IndxR++){
                    $idRazred=$VRazredi[$IndxR][0];
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$idRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VRazred=$R["razred"];
                        $VParalelka=$R["oznaka"];
                    }
                    
                    $VDatum=new DateTime($VDatumZac->format('Y-m-d'));
                    //'izpiše za 5 tednov
                    for ($IndxM=1;$IndxM <= 5;$IndxM++){
                        //'glava tabele
                        //'ugotovi začetni in končni dan v tednu
                        switch ($VDatum->format('w')){
                            case 1: // 'PON
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P1D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            case 2: // 'TOR
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P2D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            case 3: // 'SRE
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P3D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            case 4: // 'ČET
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P4D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            case 5: // 'PET
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P5D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            case 6: // 'SOB
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P6D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                                break;
                            default: // 'NED
                                $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                                $VZacDan->sub(new DateInterval('P7D'));
                                $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                                $VKonDan->add(new DateInterval('P6D'));
                        }
                        
                        $VDatum=new DateTime($VZacDan->format('Y-m-d'));
                        
                        echo "<h2 class='break'>Tedenski dnevniški zapis za: ".$VRazred.". ".$VParalelka." - ".$VDatum->format('j').".".$VDatum->format('n').".".$VDatum->format('Y')."</h2>";
                        echo "<table border='1' cellspacing='0'>";
                        echo "<tr><th>Datum</th><th>Dan</th>";
                        for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                            echo "<th>".$Indx."</th>";
                        }
                        echo "<th>Izostanki</th>";
                        echo "<th>Opombe</th>";
                        echo "<th>Dežurni</th>";
                        echo "</tr>";
                        
                        while (1){
                            $VDatum->add(new DateInterval('P1D'));
                            $Interval1=$VDatum->diff($Danes);
                            
                            $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                switch ( $R["kat"]){
                                    case 0: // 'praznik
                                        if ($Interval1->days==0 && $Interval1->invert==0){
                                            echo "<tr bgcolor='yellowgreen'>";
                                        }else{
                                            echo "<tr bgcolor='lightgreen'>";
                                        }
                                        break;
                                    case 1: // 'počitnice
                                        if ($Interval1->days==0 && $Interval1->invert==0){
                                            echo "<tr bgcolor='lightseagreen'>";
                                        }else{
                                            echo "<tr bgcolor='lightcyan'>";
                                        }
                                        break;
                                    case 2: // 'delovni dan
                                        if ($Interval1->days==0 && $Interval1->invert==0){
                                            echo "<tr bgcolor='lightyellow'>";
                                        }else{
                                            echo "<tr>";
                                        }
                                }
                            }else{
                                if (($VDatum->format('w') == 6) or ($VDatum->format('w') == 0)){
                                    if ($Interval1->days==0 && $Interval1->invert==0){
                                        echo "<tr bgcolor='salmon'>";
                                    }else{
                                        echo "<tr bgcolor='lightsalmon'>";
                                    }
                                }else{
                                    if ($Interval1->days==0 && $Interval1->invert==0){
                                        echo "<tr bgcolor='lightyellow'>";
                                    }else{
                                        echo "<tr>";
                                    }
                                }
                            }
                            $danl=$VDatum->format('j');
                            $mesl=$VDatum->format('n');
                            $letl=$VDatum->format('Y');
                            echo "<td align='center'><a href='dnevnik.php?idd=100&dan=".$danl."&mesec=".$mesl."&letod=".$letl."&ura=1'>".$VDatum->format('d.m.Y')."</a><br />";
                            $SolDan=SolskiDan($VDatum,$VLeto);
                            if ($SolDan > 0){
                                echo $SolDan;
                            }
                            echo "</td><td>".int2Dan($VDatum->format('w'))."</td>";
                            
                            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec WHERE idRazred=".$idRazred." ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);
                            $Indx=0;
                            while ($R = mysqli_fetch_array($result)){
                                $Indx=$Indx+1;
                                for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
                                    $VOdsotni[$Indx][$Indx1][0]=0;
                                    $VOdsotni[$Indx][$Indx1][1]=0;
                                    $VOdsotni[$Indx][$Indx1][2]=0;
                                    $VOdsotni[$Indx][$Indx1][3]=0;
                                }
                                $VOdsotni[$Indx][14][0]=$R["iducenec"];
                                $VOdsotni[$Indx][15][0]=$R["priimek"]." ".$R["ime"];
                                $VOdsotni[$Indx][16][0]=0; // 'ni odsoten ta dan
                                
                                for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
                                    $VOpombeUc[$Indx][$Indx1]="";
                                }
                                $VOpombeUc[$Indx][14]=$R["iducenec"];
                                $VOpombeUc[$Indx][15]=$R["priimek"]." ".$R["ime"];
                                $VOpombeUc[$Indx][16]=0; // 'ni opomb ta dan
                            }
                            $StUcencev=$Indx;
                            
                            for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                                $SQL = "SELECT tabdnevnik.*,tabdnevnik.id AS did,tabdnevnik.opis AS dopis,tabpredmeti.*,tabpredmeti.id AS pid FROM tabdnevnik ";
                                $SQL = $SQL . " INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id ";
                                $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$Indx;
                                $result = mysqli_query($link,$SQL);
                                $Indx1=0;
                                echo "<td valign='top'>";
                                while ($R = mysqli_fetch_array($result)){
                                    if (strlen($R["razred"]) > 0){
                                        //'dnevniškim zapisom za določen dan poišče razrede
                                        $SQL = "SELECT * FROM tabdnevnikr WHERE idRazred IN (".$R["razred"].")";
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            //'iz ustreznih razredov pridobi naslove dnevniških zapisov
                                            if ($R1["idRazred"]==$idRazred){
                                                //'izpiše ustrezen dnevniški zapis
                                                if ($R1["idDnevnik"]==$R["did"]){
                                                    $Indx1=$Indx1+1;
                                                    echo "<table border='0' cellspacing='0' width='50'>";
                                                    echo "<tr>";
                                                    echo "<td><a href='dnevnik.php?idd=100&izdnevnika=".$R["did"]."'>".$R["oznaka"].ToNivo2($R["skupina"])."</a></td>";
                                                    echo "<td>".$R["ZapUra"]."</td>";
                                                    echo "</tr>";
                                                    echo "<tr>";
                                                    echo "<td colspan='2'>".$R["dopis"]."</td>";
                                                    echo "</tr>";
                                                    echo "<tr>";
                                                    echo "<td colspan='2'>".$R["naloge"]."</td>";
                                                    echo "</tr>";
                                                    echo "<tr>";
                                                    echo "<td colspan='2'>";
                                                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                                                    $result2 = mysqli_query($link,$SQL);
                                                    while ($R2 = mysqli_fetch_array($result2)){
                                                        echo $R2["priimek"]." ".$R2["ime"]."<br />";
                                                    }
                                                    echo "</td>";
                                                    echo "</tr>";
                                                    echo "</table><br />";
                                                    //'obdelava odsotnosti
                                                    $SQL = "SELECT tabodsotnostuc.* FROM (tabodsotnostuc ";
                                                    $SQL = $SQL . " INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec)";
                                                    $SQL = $SQL . " INNER JOIN tabrazred ON tabodsotnostuc.idUcenec=tabrazred.idUcenec";
                                                    $SQL = $SQL . " WHERE idDnevnik=".$R["ID"]." AND tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND idRazred=".$idRazred." AND tabodsotnostuc.status < 3";
                                                    $result2 = mysqli_query($link,$SQL);
                                                    while ($R2 = mysqli_fetch_array($result2)){
                                                        for ($Indx2=1;$Indx2 <= $StUcencev;$Indx2++){
                                                            if ($VOdsotni[$Indx2][14][0]==$R2["idUcenec"]){
                                                                $VOdsotni[$Indx2][$Indx][$R2["status"]]=1;
                                                                $VOdsotni[$Indx2][16][0]=1;
                                                            }
                                                        }
                                                    }
                                                    //'obdelava opomb
                                                    $SQL = "SELECT tabopombeuc.* FROM (tabopombeuc ";
                                                    $SQL = $SQL . " INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec)";
                                                    $SQL = $SQL . " INNER JOIN tabrazred ON tabopombeuc.idUcenec=tabrazred.idUcenec";
                                                    $SQL = $SQL . " WHERE idDnevnik=".$R["ID"]." AND tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND idRazred=".$idRazred;
                                                    $result2 = mysqli_query($link,$SQL);
                                                    while ($R2 = mysqli_fetch_array($result2)){
                                                        for ($Indx2=1;$Indx2 <= $StUcencev;$Indx2++){
                                                            if ($VOpombeUc[$Indx2][14]==$R2["idUcenec"]){
                                                                $VOpombeUc[$Indx2][$Indx]=$R2["opomba"];
                                                                $VOpombeUc[$Indx2][16]=1;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if ($Indx1==0){
                                    $danl=$VDatum->format('j');
                                    $mesl=$VDatum->format('n');
                                    $letl=$VDatum->format('Y');
                                    echo "<a href='dnevnik.php?idd=100&id=6&dan=".$danl."&mesec=".$mesl."&letod=".$letl."&ura=".$Indx."&idrazred=".$idRazred."'>".$Indx."</a><br /><table border='0' cellspacing='0' width='50'>";
                                    echo "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>";
                                    echo "<tr><td colspan='2'>&nbsp;</td></tr>";
                                    echo "<tr><td colspan='2'>&nbsp;</td></tr>";
                                    echo "</table>";
                                }
                                echo "</td>";
                            }
 
                            //'izpiše še odsotnosti
                            echo "<td valign='top'>";
                            echo "<table border='0' cellspacing='0'>";
                            echo "<tr><th width='150'>ime</th><th>&nbsp;?</th><th>Op</th><th>NO</th></tr>";
                            for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                                $SumaOds[$Indx][0][0]=$VOdsotni[$Indx][14][0]; // 'idUcenec
                                $SumaOds[$Indx][0][1]=$VOdsotni[$Indx][15][0]; // 'priimek in ime
                                $SumaOds[$Indx][$VDatum->format('w')][2]=0;
                                $SumaOds[$Indx][$VDatum->format('w')][3]=0;
                                $SumaOds[$Indx][$VDatum->format('w')][4]=0;
                                if ($VOdsotni[$Indx][16][0]==1){
                                    echo "<tr><td>";
                                    echo "<a href='dnevnik.php?idd=200&id=3&ucenec=".$VOdsotni[$Indx][14][0]."'>".$VOdsotni[$Indx][15][0]."</a>:";
                                    for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
                                        if (($VOdsotni[$Indx][$Indx1][0]==1) or ($VOdsotni[$Indx][$Indx1][1]==1) or ($VOdsotni[$Indx][$Indx1][2]==1)){
                                            echo " ".$Indx1;
                                            if ($VOdsotni[$Indx][$Indx1][0]==1){
                                                $SumaOds[$Indx][$VDatum->format('w')][2]=$SumaOds[$Indx][$VDatum->format('w')][2]+1;
                                            }
                                            if ($VOdsotni[$Indx][$Indx1][1]==1){
                                                $SumaOds[$Indx][$VDatum->format('w')][3]=$SumaOds[$Indx][$VDatum->format('w')][3]+1;
                                            }
                                            if ($VOdsotni[$Indx][$Indx1][2]==1){
                                                $SumaOds[$Indx][$VDatum->format('w')][4]=$SumaOds[$Indx][$VDatum->format('w')][4]+1;
                                            }
                                        }
                                    }
                                    echo "</td>";
                                    echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][2]."</td>";
                                    echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][3]."</td>";
                                    echo "<td align='center'>".$SumaOds[$Indx][$VDatum->format('w')][4]."</td>";
                                    echo "</tr>";
                                }
                            }
                            echo "</table>";
                            echo "</td>";
                            //' in opombe
                            echo "<td valign='top'>";
                            for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                                if ($VOpombeUc[$Indx][16]==1){
                                    echo "<a href='dnevnik.php?idd=300&id=3&ucenec=".$VOpombeUc[$Indx][14]."'>".$VOpombeUc[$Indx][15]."</a>:<br />";
                                    for ($Indx1=0;$Indx1 <= $UrNaDan;$Indx1++){
                                        if (strlen($VOpombeUc[$Indx][$Indx1]) > 0){
                                            echo $Indx1.": ".$VOpombeUc[$Indx][$Indx1]."<br />";
                                        }
                                    }
                                }
                            }
                            echo "</td>";
                            
                            //'izpiše dežurne učence
                            if ($VDatum->format('w')==1){
                                echo "<td rowspan='7' valign='top'>";
                                $SQL = "SELECT DISTINCT tabucenci.priimek,tabucenci.ime,tabrazred.slika FROM (tabrazred ";
                                $SQL = $SQL . " INNER JOIN TabDezurniUc ON tabrazred.idUcenec=TabDezurniUc.idUcenec) ";
                                $SQL = $SQL . " INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                                $SQL = $SQL . " WHERE tabrazred.leto=". $VLeto ." AND idRazred=".$idRazred." AND (";
                                $Datum=new DateTime($VDatum->format('Y-m-d'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').") OR";
                                $Datum->add(new DateInterval('P1D'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').") OR";
                                $Datum->add(new DateInterval('P1D'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').") OR";
                                $Datum->add(new DateInterval('P1D'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').") OR";
                                $Datum->add(new DateInterval('P1D'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').") OR";
                                $Datum->add(new DateInterval('P1D'));
                                $SQL = $SQL . "(TabDezurniUc.leto=".$VDatum->format('Y')." AND mesec=".$VDatum->format('n')." AND dan=".$VDatum->format('j').")";
                                $SQL = $SQL . ")";
                                $SQL = $SQL . " ORDER BY priimek,ime";
                                $result2 = mysqli_query($link,$SQL);
                                while ($R2 = mysqli_fetch_array($result2)){
                                    echo "<img src='".$R2["slika"]."' width='50'>".$R2["priimek"]." ".$R2["ime"]."<br />";
                                }
                                echo "<a href='dnevnik.php?idd=400&razred=".$idRazred."&mesec=".$VDatum->format('n')."'>Izberi dežurne</a>";
                                echo "</td>";
                            }
                            echo "</tr>";
                            //'zaključi zanko
                            $IntervalOut=$VDatum->diff($VKonDan);
                            if ($IntervalOut->days == 0){
                                break;
                            }
                        }
                        
                        //'izpiše vsote odsotnosti
                        echo "<tr>";
                        echo "<td colspan='13'>&nbsp;</td>";
                        echo "<td>";
                        echo "<table border='0' cellspacing='0'>";
                        echo "<tr><th width='150'>&nbsp;</th><th>&nbsp;?</th><th>Op</th><th>NO</th></tr>";
                        echo "<tr><td>Skupaj</td>";
                        
                        $CountOds[0]=0;
                        $CountOds[1]=0;
                        $CountOds[2]=0;
                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            for ($Indx1=1;$Indx1 < 7;$Indx1++){
                                $CountOds[0]=$CountOds[0]+$SumaOds[$Indx][$Indx1][2];
                                $CountOds[1]=$CountOds[1]+$SumaOds[$Indx][$Indx1][3];
                                $CountOds[2]=$CountOds[2]+$SumaOds[$Indx][$Indx1][4];
                            }
                        }
                        echo "<td align='center'>".$CountOds[0]."</td>";
                        echo "<td align='center'>".$CountOds[1]."</td>";
                        echo "<td align='center'>".$CountOds[2]."</td>";
                        echo "</tr></table></td>";
                        echo "<td></td>";
                        echo "</tr>";
                        echo "</table><br />";
                        
                        echo "<hr />";
                        
                        //'naprej/nazaj/datum
                        /*
                        $TedenPrej=new DateTime($VKonDan->format('Y-m-d'));
                        $TedenPrej->sub(new DateInterval('P7D'));
                        $TedenPotem=new DateTime($VKonDan->format('Y-m-d'));
                        $TedenPrej->add(new DateInterval('P7D'));
                         */
                        $VDatum= new DateTime($VKonDan->add(new DateInterval('P7D'))->format('Y-m-d'));
                    }
                }
                break;
            case "10": //vpis ocen
                if (isset($_POST["oc"])){
                    if ($_POST["oc"]=="0"){
                        //nov vpis
                        $SQL = "SELECT id,prioriteta FROM tabpredmeti WHERE id IN (".$_POST["predmet"].") AND prioriteta < 2";
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            $SQL = "INSERT INTO tabocene (leto,iducenec,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u,neocenjen,popravni,ocenakoncna,ocenapolletna,datum,vpisovalec) VALUES (";
                            $SQL = $SQL . $VLeto;
                            $SQL = $SQL . ",".$_POST["ucenec"];
                            $SQL = $SQL . ",".$R1["id"];
                            $SQL = $SQL . ",'".$_POST["s1p"]."'";
                            $SQL = $SQL . ",'".$_POST["s1u"]."'";
                            $SQL = $SQL . ",'".$_POST["s2p"]."'";
                            $SQL = $SQL . ",'".$_POST["s2u"]."'";
                            $SQL = $SQL . ",0,0,'','','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                            
                            $DovoljenVpis=true;
                            $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                            $Interval=$Danes->diff($MejniDatum);
                            if ($Interval->invert > 0){
                                if ($VLevel < 3){
                                    $DovoljenVpis=false;
                                }
                            }
                            if ($DovoljenVpis){    
                                $result2 = mysqli_query($link,$SQL);
                                echo "<h2>Ocena je vpisana/popravljena</h2>";
                            }else{
                                echo "<h2>Ocena NI vpisana/popravljena</h2>";
                            }                                    
                        }
                    }else{
                        //vpis popravka
                        $SQL = "SELECT ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE id =".$_POST["oc"];
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            $Vpis=0;
                            $SQL = "UPDATE tabocene SET ";
                            if ($_POST["s1p"] != $R1["ocenas1p"]){
                                $SQL = $SQL . "ocenas1p='".$_POST["s1p"]."'";
                                $Vpis=$Vpis+1;
                            }
                            if ($_POST["s1u"] != $R1["ocenas1u"]){
                                $SQL = $SQL . ",ocenas1u='".$_POST["s1u"]."'";
                                $Vpis=$Vpis+1;
                            }
                            if ($_POST["s2p"] != $R1["ocenas2p"]){
                                $SQL = $SQL . ",ocenas2p='".$_POST["s2p"]."'";
                                $Vpis=$Vpis+1;
                            }
                            if ($_POST["s2u"] != $R1["ocenas2u"]){
                                $SQL = $SQL . ",ocenas2u='".$_POST["s2u"]."'";
                                $Vpis=$Vpis+1;
                            }
                            $SQL = $SQL . ",vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["oc"];
                            
                            //v primeru spremembe popravi podatek
                            if ($Vpis > 0){
                                $DovoljenVpis=true;
                                $MejniDatum=new DateTime(($VLeto+1)."-08-31");
                                $Interval=$Danes->diff($MejniDatum);
                                if ($Interval->invert > 0){
                                    if ($VLevel < 3){
                                        $DovoljenVpis=false;
                                    }
                                }
                                if ($DovoljenVpis){    
                                    $result2 = mysqli_query($link,$SQL);
                                    echo "<h2>Ocena je vpisana/popravljena</h2>";
                                }else{
                                    echo "<h2>Ocena NI vpisana/popravljena</h2>";
                                }                                    
                            }
                        }
                    }
                }
                break;
            case "11": // 'izpiše tedenski dnevnik za določenega učitelja
                if (isset($_POST["uciteljp"])){
                    $Ucitelj=$_POST["uciteljp"];
                }else{
                    if (isset($_GET["uciteljp"])){
                        $Ucitelj=$_GET["uciteljp"];
                    }else{
                        $Ucitelj=$VUporabnikId;
                    }
                }
                
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');

                echo "<a href='dnevnik.php?idd=100'>Na splošen vnos dnevnika</a><br>";
                
                $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj=".$Ucitelj;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Tedenski dnevniški zapis za učitelja: ".$R["ime"]." ".$R["priimek"]."</h2>";
                }
                //'glava tabele
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>Datum</th><th>Dan</th>";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    echo "<th>".$Indx."</th>";
                }
                /*
                echo "<th>Izostanki</th>";
                echo "<th>Opombe</th>";
                echo "<th>Dežurni</th>";
                */
                echo "</tr>";
                
                //'ugotovi začetni in končni dan v tednu
                switch ($VDatum->format('w')){
                    case 1: // 'PON
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P1D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    case 2: // 'TOR
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P2D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    case 3: // 'SRE
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P3D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    case 4: // 'ČET
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P4D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    case 5: // 'PET
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P5D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    case 6: // 'SOB
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P6D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                        break;
                    default: // 'NED
                        $VZacDan=new DateTime($VDatum->format('Y-m-d'));
                        $VZacDan->sub(new DateInterval('P7D'));
                        $VKonDan=new DateTime($VZacDan->format('Y-m-d'));
                        $VKonDan->add(new DateInterval('P6D'));
                }
                
                $VDatum=new DateTime($VZacDan->format('Y-m-d'));
                while (1){
                    $VDatum->add(new DateInterval('P1D'));
                    $Interval1=$VDatum->diff($Danes);
                    
                    $SQL = "SELECT * FROM tabpraznik WHERE day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y');
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        switch ( $R["kat"]){
                            case 0: // 'praznik
                                if ($Interval1->days==0 && $Interval1->invert==0){
                                    echo "<tr bgcolor='yellowgreen'>";
                                }else{
                                    echo "<tr bgcolor='lightgreen'>";
                                }
                                break;
                            case 1: // 'počitnice
                                if ($Interval1->days==0 && $Interval1->invert==0){
                                    echo "<tr bgcolor='lightseagreen'>";
                                }else{
                                    echo "<tr bgcolor='lightcyan'>";
                                }
                                break;
                            case 2: // 'delovni dan
                                if ($Interval1->days==0){
                                    echo "<tr bgcolor='lightyellow'>";
                                }else{
                                    echo "<tr>";
                                }
                        }
                    }else{
                        if (($VDatum->format('w') == 6) or ($VDatum->format('w') == 0)){
                            if ($Interval1->days==0 && $Interval1->invert==0){
                                echo "<tr bgcolor='salmon'>";
                            }else{
                                echo "<tr bgcolor='lightsalmon'>";
                            }
                        }else{
                            if ($Interval1->days==0 && $Interval1->invert==0){
                                echo "<tr bgcolor='lightyellow'>";
                            }else{
                                echo "<tr>";
                            }
                        }
                    }
                    
                    echo "<td align='center'><a href='dnevnik.php?idd=100&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letod=".$VDatum->format('Y')."&ura=1&uciteljp=".$Ucitelj."'>".$VDatum->format('d.m.Y')."</a><br />";
                    $SolDan=SolskiDan($VDatum,$VLeto);
                    if ($SolDan > 0){
                        echo $SolDan;
                    }
                    echo "</td><td>".int2Dan($VDatum->format('w'))."</td>";
                    
                    for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                        $SQL = "SELECT tabdnevnik.*,tabdnevnik.id AS did,tabdnevnik.opis AS dopis,tabpredmeti.id AS pid,tabpredmeti.oznaka FROM (tabdnevnik ";
                        $SQL = $SQL . " INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                        //$SQL = $SQL . " LEFT JOIN tabpriprava ON tabdnevnik.idpriprava=tabpriprava.id ";
                        $SQL = $SQL . " WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$Indx;
                        $result = mysqli_query($link,$SQL);
                        $Indx1=0;
                        if ($R = mysqli_fetch_array($result)){
                            switch ($R["statusUre"]){
                                case 1:   //nadomeščanje
                                case 2:   //združena
                                    echo "<td class='dn_ura' valign='top' bgcolor='yellow'>";
                                    break;
                                case 3:   //odpadla
                                    echo "<td class='dn_ura' valign='top' bgcolor='magenta'>";
                                    break;
                                case 4:   //športni dan
                                case 5:   //kulturni dan
                                case 6:   //naravoslovni dan
                                case 7:   //tehniški dan
                                case 9:   //ekskurzija
                                    echo "<td class='dn_ura' valign='top' bgcolor='lightblue'>";
                                    break;
                                case 8:   //šola v naravi
                                    echo "<td class='dn_ura' valign='top' bgcolor='lightcyan'>";
                                    break;
                                case 10:  //proslava
                                case 11:  //drugo
                                    echo "<td class='dn_ura' valign='top' bgcolor='lightpink'>";
                                    break;
                                default: //redna ura
                                    echo "<td class='dn_ura' valign='top'>";
                            }
                        }else{
                            echo "<td class='dn_ura' valign='top'>";
                        }
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if (strlen($R["ucitelj"]) > 0){
                                //'dnevniškim zapisom za določen dan poišče učitelje
                                $SQL = "SELECT * FROM tabdnevniku WHERE idUcitelj IN (".$R["ucitelj"].")";
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    //'iz ustreznih učiteljev pridobi naslove dnevniških zapisov
                                    if ($R1["idUcitelj"]==$Ucitelj){
                                        //'izpiše ustrezen dnevniški zapis
                                        if ($R1["idDnevnik"]==$R["did"]){
                                            $Indx1=$Indx1+1;
                                            echo "<table class='dn_celica' border='0' cellspacing='0' width='50'>";
                                            echo "<tr class='dn_celica'>";
                                            echo "<td class='dn_celica'><a href='dnevnik.php?idd=100&izdnevnika=".$R["did"]."'>".$R["oznaka"].ToNivo2($R["skupina"])."</a></td>";
                                            echo "<td class='dn_celica'>".$R["ZapUra"]."</td>";
                                            echo "</tr>";
                                            echo "<tr class='dn_celica'>";
                                            echo "<td class='dn_celica' colspan='2'>";
                                            $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id IN (".$R["razred"].") ORDER BY razred,oznaka";
                                            $result2 = mysqli_query($link,$SQL);
                                            while ($R2 = mysqli_fetch_array($result2)){
                                                echo $R2["razred"].$R2["oznaka"]." ";
                                            }
                                            echo "<br />";
                                            if (isset($R["idpriprava"])){
                                                $SQL = "SELECT priprava FROM tabpriprava WHERE id=".$R["idpriprava"];
                                                $result2 = mysqli_query($link,$SQL);
                                                if ($R2 = mysqli_fetch_array($result2)){
                                                    echo "<a href='upload/priprave/".$R2["priprava"]."' target='_blank'>".$R["dopis"]."</a></td>";
                                                }else{
                                                    echo $R["dopis"]."</td>";
                                                }
                                            }else{
                                                echo $R["dopis"]."</td>";
                                            }
                                            echo "</tr>";
                                            echo "<tr class='dn_celica'>";
                                            echo "<td class='dn_celica' colspan='2'>";
                                            echo $R["naloge"]."</td>";
                                            echo "</tr>";
                                            echo "<tr class='dn_celica'>";
                                            echo "<td class='dn_celica' colspan='2'>";
                                            $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                                            $result2 = mysqli_query($link,$SQL);
                                            while ($R2 = mysqli_fetch_array($result2)){
                                                echo $R2["priimek"]." ".$R2["ime"]."<br />";
                                            }
                                            echo "</td>";
                                            echo "</tr>";
                                            echo "</table><br />";
                                        }
                                    }
                                }
                            }
                        }
                        if ($Indx1==0){
                            //echo $VDatum->format('d.m.Y');
                            $danl=$VDatum->format('j');
                            $mesl=$VDatum->format('n');
                            $letl=$VDatum->format('Y');
                            
                            echo "<a href='dnevnik.php?idd=100&id=6&dan=".$danl."&mesec=".$mesl."&letod=".$letl."&ura=".$Indx."&idrazred=".$idRazred."&uciteljp=".$Ucitelj."'>".$Indx."</a><br /><table border='0' cellspacing='0' width='50'>";
                            $SQL = "SELECT prioriteta FROM taburnik INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id ";
                            $SQL = $SQL . "WHERE prioriteta IN (0,1,3) AND taburnik.od <= ".$VDatum->format('Ymd')." AND taburnik.do >= ".$VDatum->format('Ymd')." AND taburnik.leto=$VLeto AND taburnik.ucitelj=$Ucitelj AND taburnik.ura=$Indx AND taburnik.danvtednu=".$VDatum->format('w');
                            $result2 = mysqli_query($link,$SQL);
                            if (mysqli_num_rows($result2) > 0){
                                if ($R2 = mysqli_fetch_array($result2)){
                                    if ($R2["prioriteta"]==3){
                                        echo "<tr class='dn_celicap1' bgcolor='orange'>";
                                    }else{
                                        echo "<tr class='dn_celicap2' bgcolor='red'>";
                                    }
                                }else{
                                    echo "<tr class='dn_celica'>";
                                }
                            }else{
                                echo "<tr class='dn_celica'>";
                            }
                            echo "<td class='dn_celica'>&nbsp;</td><td class='dn_celica'>&nbsp;</td></tr>";
                            echo "<tr class='dn_celica'><td class='dn_celica' colspan='2'>";
                            $SQL = "SELECT razred,paralelka FROM taburnik WHERE leto=$VLeto AND od <= ".$VDatum->format('Ymd')." AND do >= ".$VDatum->format('Ymd')." AND ucitelj=$Ucitelj AND ura=$Indx AND danvtednu=".$VDatum->format('w');
                            $result2 = mysqli_query($link,$SQL);
                            while ($R2 = mysqli_fetch_array($result2)){
                                echo $R2["razred"].$R2["paralelka"]." ";
                            }
                            echo "</td></tr>";
                            echo "<tr class='dn_celica'><td class='dn_celica' colspan='2'>&nbsp;</td></tr>";
                            echo "</table>";
                        }
                        echo "</td>";
                    }
                    
                    echo "</tr>";
                    //'zaključi zanko
                    $IntervalOut=$VDatum->diff($VKonDan);
                    if ($IntervalOut->days == 0){
                        break;
                    }
                }
                echo "</table><br />";
                
                //'naprej/nazaj/datum
                $TedenPrej=new DateTime($VKonDan->format('Y-m-d'));
                $TedenPrej->sub(new DateInterval('P7D'));
                $TedenPotem=new DateTime($VKonDan->format('Y-m-d'));
                $TedenPotem->add(new DateInterval('P7D'));
                echo "<a href='dnevnik.php?idd=100&id=11&dan=".$TedenPrej->format('j')."&mesec=".$TedenPrej->format('n')."&letod=".$TedenPrej->format('Y')."&ura=0&uciteljp=".$Ucitelj."'>Prejšnji teden</a> | <a href='dnevnik.php?idd=100&id=11&dan=".$TedenPotem->format('j')."&mesec=".$TedenPotem->format('n')."&letod=".$TedenPotem->format('Y')."&ura=0&uciteljp=".$Ucitelj."'>Naslednji teden</a>";
                
                echo "";
                echo "<form name='izborDatuma' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='id' type='hidden' value='11'>";
                echo "<input name='uciteljp' type='hidden' value='".$Ucitelj."'>";
                echo "Datum ";
                echo "<select name='dan'>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    if ($Indx==$VDatum->format('j')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='mesec'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if ($Indx==$VDatum->format('n')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='letod'>";
                for ($Indx=$Danes->format('Y')-1;$Indx <= ($Danes->format('Y')+1);$Indx++){
                    if ($Indx==$VDatum->format('Y')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                
                echo "<input name='submit' type='submit' value='Izberi'>";
                echo "</form><br>";
                
                //'ponudi pregled po predmetih določenega učitelja
                echo "<h3>Pregled po predmetih</h3>";
                $SQL = "SELECT tabucenje.id,tabucenje.realizirano,tabpredmeti.opis,tabpredmeti.oznaka,tabucenje.razred,tabucenje.paralelka FROM tabucenje ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
                $SQL = $SQL . " WHERE leto=".$VLeto." AND prioriteta IN (0,1) AND iducitelj=".$Ucitelj;
                $SQL = $SQL . " ORDER BY VrstniRed";
                $result = mysqli_query($link,$SQL);
                echo "<form name='popredmetih' method='post' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<select name='predmet'>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["id"]."'>";
                    if ($R["realizirano"] > 0){
                        echo $R["opis"]." (".$R["oznaka"].") - skupina ".$R["realizirano"].", ".$R["razred"].". ".$R["paralelka"];
                    }else{
                        echo $R["opis"]." (".$R["oznaka"]."), ".$R["razred"].". ".$R["paralelka"];
                    }
                    echo "</option>";
                }
                echo "</select>";
                echo "<input name='id' type='hidden' value='8'>";
                echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
                echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
                echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<input name='razred' type='hidden' value='".$idRazred."'>";
                echo "<input name='submit' type='submit' value='Izberi'><br />";
                echo "</form><br />";
                break;
            case "12"; //prenos datoteke za pripravo
                $uploaded=false;
                $allowedExts = array("txt","doc","docx","rtf","pdf");
                $Preneseno=$_FILES["priprava"];
                $extension = explode(".", $Preneseno["name"]);
                $extension = end($extension);
                $extension = strtolower($extension);
                if (($_FILES["priprava"]["size"] < 500000)
                    && in_array($extension, $allowedExts)){
                         if ($_FILES["priprava"]["error"] > 0){
                            //echo "Napaka: " . $_FILES["attachment"]["error"] . "<br />";
                            echo "Ddatoteka ni bila poslana na strežnik<br />";
                            $Datoteka="";
                         }else{
                             echo "Naloženo: " . $_FILES["priprava"]["name"] . "<br />";
                             echo "Tip: " . $_FILES["priprava"]["type"] . "<br />";
                             echo "Velikost: " . round($_FILES["priprava"]["size"] / 1024,2) . " kB<br />";
                             echo "Temp file: " . $_FILES["priprava"]["tmp_name"] . "<br />";
                         
                             if (file_exists("upload/priprave/" . $_FILES["priprava"]["name"])){
                                 echo "<h2>".$_FILES["priprava"]["name"] . " že obstaja. </h2>";
                             }else{
                                 move_uploaded_file($_FILES["priprava"]["tmp_name"],"upload/priprave/" . $_FILES["priprava"]["name"]);
                                 echo "Shranjeno v: " . "upload/priprave/" . $_FILES["priprava"]["name"]. "<br />";
                                 $uploaded=true;
                             }
                             $Datoteka="upload".$FileSep."priprave".$FileSep. $_FILES["priprava"]["name"];
                         }
                }else{
                    echo "<h2>Datoteka je prevelika ali pa ima napačen podaljšek!</h2>";
                }
                if ($uploaded){
                    $SQL = "INSERT INTO tabpriprava (iducitelj,leto,priprava,datobj,objavil) VALUES (".$IdUcitelj.",".$VLeto.",'".$_FILES["priprava"]["name"]."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                    if ($result = mysqli_query($link,$SQL)){
                        echo "<h2>Priprava je pripravljena za uporabo!</h2>";
                    }else{
                        echo "<h2>Napaka pri vnosu priprave!</h2>";
                    }
                }
                echo "<br />";
                break;
            default: //'vstop iz menija
				$n=$VLevel;
				include('menu_func.inc');
				include ('menu.inc');
                echo "<h2>Vnos dnevniškega zapisa</h2>";
                $VRefSt=0;
                $VSedRed=0;
                $VOpombe="";
                $VNaloge="";
                $VStatusUre=0;
                $VPriprava=0;
                //'izbor datuma in ure
                if ($IzDnevnika > 0){
                    $SQL = "SELECT ura,datum,zapura,refid,opis,idsedred,idpriprava FROM tabdnevnik WHERE id=".$IzDnevnika;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VDatum=new DateTime(isDate($R["datum"]));
                        $VUra=$R["ura"];
                        $VZapStUre=$R["zapura"];
                        $VRefSt=$R["refid"];
                        $VPriprava=$R["idpriprava"];
                        $VSedRed=$R["idsedred"];
                        $VOpombe=$R["opis"];
                        $VNaloge=$R["naloge"];
                    }
                }
                echo "<form name='vnosUre' method='POST' action='dnevnik.php'>";
                echo "<table border='0'>";
                echo "<tr><td>Datum</td><td>";
                echo "<select name='dan'>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    if ($Indx==$VDatum->format('j')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='mesec'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if ($Indx==$VDatum->format('n')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "<select name='letod'>";
                for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                    if ($Indx==$VDatum->format('Y')){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."' >".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "</td></tr>";
                
                $VDanVTednu=$VDatum->format('w'); //'1. dan je ponedeljek
                
                echo "<tr><td>Ura v urniku</td><td><b>".Int2Dan($VDanVTednu)."</b>&nbsp;";
                echo "<select name='ura'>";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    if ($Indx==$VUra){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."'>".$Indx."</option>";
                    }
                }
                echo "</select><input name='submit' type='submit' value='Izberi'></td></tr>";
                echo "</table><br />";
                echo "</form>";
                
                //'vnos ostalih podatkov
                $VUcitelj="";
                $VRazred="";
                $VPredmet="";
                //'prebere učitelje
                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcitelji[$Indx][0]=$R["iducitelj"];
                    $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    if ($R["iducitelj"]==$IdUcitelj){
                        $VUcitelji[$Indx][2]=1;
                    }else{
                        $VUcitelji[$Indx][2]=0;
                    }
                    $Indx=$Indx+1;
                }
                $StUciteljev=$Indx-1;

                echo "<a href='dnevnik.php?idd=100&id=11&dan=$VDan&mesec=$VMesec&letod=$VLeto&uciteljp=$IdUcitelj'>Na tedenski urnik učitelja</a><br />";
                echo "<br />";
                
                //'prebere predmete
                $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta in (0,1,3) ORDER BY prioriteta,opis";
//                $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta in (0,1,3) ORDER BY prioriteta,oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VPredmeti[$Indx][0]=$R["id"];
                    $VPredmeti[$Indx][1]=$R["opis"]." (".$R["oznaka"].")";
//                    $VPredmeti[$Indx][1]=$R["oznaka"];
                    $VPredmeti[$Indx][2]=0;
                    $Indx=$Indx+1;
                }
                $StPredmetov=$Indx-1;
                
                //'prebere razrede
                $VRazredi[0][0]=0;
                $VRazredi[0][1]="Ni izbran";
                $VRazredi[0][2]=0;
                $VRazredi[0][3]=0;
                $SQL = "SELECT id,razred,oznaka,idsola FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VRazredi[$Indx][0]=$R["id"];
                    $VRazredi[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                    $VRazredi[$Indx][2]=0;
                    $VRazredi[$Indx][3]=$R["idsola"];
                    $Indx=$Indx+1;
                }
                $StRazredov=$Indx-1;
                
                //'prebere priprave
                $VPriprave[0][0]=0;
                $VPriprave[0][1]="Ni izbrano";
                $VPriprave[0][2]=0;
                $SQL = "SELECT id,iducitelj,priprava FROM tabpriprava WHERE leto=".$VLeto." AND iducitelj = $IdUcitelj ORDER BY id DESC";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VPriprave[$Indx][0]=$R["id"];
                    $VPriprave[$Indx][1]=$R["priprava"];
                    $VPriprave[$Indx][2]=0;
                    $Indx=$Indx+1;
                }
                $StPriprav=$Indx-1;
                
                //prebere ref. številke
                $SQL = "SELECT tabdnevnik.id,tabdnevnik.refid,tabdnevnik.predmet,tabdnevnik.skupina,tabdnevnik.razred,tabdnevnik.ucitelj,tabpredmeti.oznaka FROM (tabdnevnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE zapura=1 AND tabdnevnik.leto=".$VLeto." ORDER BY predmet,razred,ucitelj";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $refst[$Indx]["id"]=$R["id"];
                    $refst[$Indx]["oznaka"]=$R["oznaka"];
                    $refst[$Indx]["skupina"]=ToNivo($R["skupina"]);
                    $refst[$Indx]["razred"]="";
                    $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id IN (".$R["razred"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($refst[$Indx]["razred"])==0){
                            $refst[$Indx]["razred"]=$R1["razred"].$R1["oznaka"];
                        }else{
                            $refst[$Indx]["razred"]=$refst[$Indx]["razred"].",".$R1["razred"].$R1["oznaka"];
                        }
                    }
                    $refst[$Indx]["ucitelj"]="";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj IN (".$R["ucitelj"].") ORDER BY priimek,ime";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($refst[$Indx]["ucitelj"])==0){
                            $refst[$Indx]["ucitelj"]=mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                        }else{
                            $refst[$Indx]["ucitelj"]=$refst[$Indx]["ucitelj"].",".mb_substr($R1["ime"],0,1,$encoding).".".mb_substr($R1["priimek"],0,3,$encoding);
                        }
                    }
                    $Indx=$Indx+1;
                }   
                $StRefSt=$Indx-1;

                //prebere sedežne rede
                $SQL = "SELECT id,opomba FROM tabsedred WHERE leto=".$VLeto." ORDER BY opomba";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $sedred[$Indx]["id"]=$R["id"];
                    $sedred[$Indx]["opomba"]=$R["opomba"];
                    $Indx=$Indx+1;
                }
                $StSedRed=$Indx-1;
                
                //'v urnik pogleda uro za učitelja
                if ($VPouk > 0){
                    $SQL = "SELECT * FROM taburnik WHERE id=".$VPouk;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "SELECT id,idrazred,ucitelj,predmet,nivo FROM taburnik WHERE leto=".$R["Leto"]." AND od=".$R["od"]." AND do=".$R["do"]." AND ura=".$R["Ura"]." AND DanVTednu=".$R["DanVTednu"]." AND predmet=".$R["Predmet"]." AND nivo=".$R["Nivo"]." AND ucitelj=".$R["Ucitelj"];
                    }
                }else{
                    if ($IzDnevnika > 0){
                        $SQL = "SELECT id,predmet,skupina,idpriprava,refid,idsedred FROM tabdnevnik WHERE id=".$IzDnevnika;
                    }else{
                        $SQL = "SELECT id,idrazred,ucitelj,predmet,nivo FROM taburnik WHERE leto=".$VLeto." AND od <= ".$VDatum->format('Ymd')." AND do >= ".$VDatum->format('Ymd')." AND ura=".$VUra." AND DanVTednu=".$VDanVTednu." AND ucitelj=".$IdUcitelj;
                    }
                }
                $result = mysqli_query($link,$SQL);
                
                $Count[1]=0; // 'razredi
                $Count[2]=1; // 'ucitelji
                $Count[3]=0; // 'predmeti
                $VSkupina=0;
                
                if ($IzDnevnika > 0){   //podatke prebere iz dnevnika
                    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                        $VUcitelji[$Indx][2]=0;
                    }
                    $Count[2]=0;
                    while ($R = mysqli_fetch_array($result)){
                        $SQL = "SELECT * FROM tabdnevnikr WHERE idDnevnik=".$R["id"];
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                                if ($R1["idRazred"]==$VRazredi[$Indx][0]){
                                    $VRazredi[$Indx][2]=1;
                                    if ($VRazred==0){
                                        $VRazred=$VRazredi[$Indx][0];
                                        $Count[1]=$Count[1]+1;
                                    }else{
                                        if (!vsebuje($VRazred,$VRazredi[$Indx][0])){
                                            $VRazred=$VRazred.",".$VRazredi[$Indx][0];
                                            $Count[1]=$Count[1]+1;
                                        }
                                    }
                                }
                            }
                        }
                        
                        $SQL = "SELECT * FROM tabdnevniku WHERE idDnevnik=".$R["id"];
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                                if ($R1["idUcitelj"]==$VUcitelji[$Indx][0]){
                                    $VUcitelji[$Indx][2]=1;
                                    if ($VUcitelj==0){
                                        $VUcitelj=$VUcitelji[$Indx][0];
                                        $Count[2]=$Count[2]+1;
                                    }else{
                                        if (!vsebuje($VUcitelj,$VUcitelji[$Indx][0])){
                                            $VUcitelj=$VUcitelj.",".$VUcitelji[$Indx][0];
                                            $Count[2]=$Count[2]+1;
                                        }
                                    }
                                }
                            }
                        }
                        
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["predmet"]==$VPredmeti[$Indx][0]){
                                $VPredmeti[$Indx][2]=1;
                                $VPredmet=$VPredmeti[$Indx][0];
                                $Count[3]=1;
                            }
                        }
                        $VSkupina=$R["skupina"];
                        
                        //prebere pripravo
                        if (isset($R["idpriprava"])){
                            $VPriprava=$R["idpriprava"];
                        }else{
                            $VPriprava=0;
                        }
                        
                        //prebere ref.št.
                        if (isset($R["refid"])){
                            $VRefSt=$R["refid"];
                        }else{
                            $VRefSt=0;
                        }
                        //prebere sed.red
                        if (isset($R["idsedred"])){
                            $VSedRed=$R["idsedred"];
                        }else{
                            $VSedRed=0;
                        }
                    }
                }else{    //podatke prebere iz urnika
                    if (mysqli_num_rows($result) > 0){
                        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                            $VUcitelji[$Indx][2]=0;
                        }
                        $Count[2]=0;
                    }
                    while ($R = mysqli_fetch_array($result)){
                        $VRazredRez="";
                        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                            if ($R["idrazred"]==$VRazredi[$Indx][0]){
                                $VRazredi[$Indx][2]=1;
                                if ($VRazred==0){
                                    $VRazred=$VRazredi[$Indx][0];
                                    $Count[1]=$Count[1]+1;
                                }else{
                                    if (!vsebuje($VRazred,$VRazredi[$Indx][0])){
                                        $VRazred=$VRazred.",".$VRazredi[$Indx][0];
                                        $Count[1]=$Count[1]+1;
                                    }
                                }
                                if (strlen($VRazredRez)==0){
                                    $VRazredRez=$VRazredi[$Indx][0];
                                }else{
                                    if (!vsebuje($VRazredRez,$VRazredi[$Indx][0])){
                                        $VRazredRez=$VRazredRez.",".$VRazredi[$Indx][0];
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                            if ($R["ucitelj"]==$VUcitelji[$Indx][0]){
                                $VUcitelji[$Indx][2]=1;
                                if ($VUcitelj==0){
                                    $VUcitelj=$VUcitelji[$Indx][0];
                                    $Count[2]=$Count[2]+1;
                                }else{
                                    if (!vsebuje($VUcitelj,$VUcitelji[$Indx][0])){
                                        $VUcitelj=$VUcitelj.",".$VUcitelji[$Indx][0];
                                        $Count[2]=$Count[2]+1;
                                    }
                                }
                            }
                        }
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["predmet"]==$VPredmeti[$Indx][0]){
                                $VPredmeti[$Indx][2]=1;
                                $VPredmet=$VPredmeti[$Indx][0];
                                $Count[3]=1;
                            }
                        }
                        $VSkupina=$R["nivo"];
                    }
                    if (($Count[1] > 0) && ($Count[3] > 0)){ //'če obstajajo predmeti in razredi
                        if ($VSkupina != "0"){
                            $SQL = "SELECT zapura FROM tabdnevnik WHERE leto=".$VLeto." AND predmet IN (".$VPredmet.") AND skupina='".$VSkupina."' ORDER BY ZapUra DESC";
                        }else{
                            $SQL = "SELECT zapura FROM tabdnevnik WHERE leto=".$VLeto." AND predmet IN (".$VPredmet.") ORDER BY ZapUra DESC";
                        }
                        $result = mysqli_query($link,$SQL);
                        $VZapStUre=1;
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "SELECT id FROM tabrazdat WHERE id IN (".$VRazred.")";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                $VZapStUre=$R["zapura"]+1;
                                if (isset($R["idsedred"])){
                                    $VSedRed=$R["idsedred"];
                                }
                                if ($VSkupina != "0"){
                                    $SQL = "SELECT id FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND skupina='".$VSkupina."' AND zapura=1";
                                }else{
                                    $SQL = "SELECT id FROM tabdnevnik WHERE predmet IN (".$VPredmet.") AND zapura=1";
                                }
                                $result2 = mysqli_query($link,$SQL);
                                if ($R2 = mysqli_fetch_array($result2)){
                                    $VRefSt=$R2["id"];
                                }
                            }
                        }
                    }else{
                        $VZapStUre=1;
                    }
                }
                
                IzpisUrnihPodatkov();
                echo "<div>Za dneve dejavnosti nastavite: Predmet (Dan dejavnosti), Skupina (Drugo), Zap.št.ure (1 za prvo uro, 2 za drugo, ...), Status (ustrezna izbira)<br />";
                echo "<font color='red'>Pri izbiri dodatnih (več izbir) učiteljev in razredov uporabite <b>Ctrl</b>+klik</font><br />";
                echo "<font color='blue'>Za predmete/dejavnosti, ki niso v urniku, izberite predmet/dejavnost, razred in učitelja ter kliknite na Poišči učence. Nato vnestite ostale podatke. </font></div>";
                
                //'izpis podatkov o učencih
                
                if (($Count[1] > 0) && ($Count[3] > 0)){
                    if ($IzDnevnika > 0){
                        echo "<input name='submit' type='submit' value='Popravi'>";
                        echo "<br /><br />";
                    }else{
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "<br /><br />";
                    }
                    echo "<div id='izpisucencev'>";
                    if ($VSedRed > 0){
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred FROM ((tabsedred ";
                        $SQL = $SQL . "INNER JOIN tabsedredu ON tabsedred.iducenci=tabsedredu.iducenci) ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                        $SQL = $SQL . "WHERE tabsedred.id=".$VSedRed." AND tabsedred.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY priimek,ime,razred,paralelka";
                    }else{
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred FROM tabrazred ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." AND idRazred IN (".$VRazred.") ";
                        $SQL = $SQL . "ORDER BY priimek,ime,razred,paralelka";
                    }
                    $result = mysqli_query($link,$SQL);
                    
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr style='background-color:lightcyan;'><th>št.</th><th>Ime</th><th>Izostanki</th><th>Opombe</th><th>Redovalnica<br />pisno | ustno</th></tr>";
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $IzpisiUcenca=false;
                        switch ( $VSkupina){
                            case 1:
                            case 2:
                            case 3:
                            case 7:
                            case 8:
                            case 9:
                                if (vsebuje($VPredmet,$OznakaSport)){
                                    //'v primeru športne vzgoje razdeli na fante in dekleta
                                    if ($VSkupina==1){
                                        if ($R["spol"]=="M"){
                                            $IzpisiUcenca=true;
                                        }
                                    }else{
                                        if ($R["spol"]=="F"){
                                            $IzpisiUcenca=true;
                                        }
                                    }
                                }else{
                                    if (strlen(Skupina2Nivo($VSkupina,$VPredmet)) > 0){
                                        $SQL = "SELECT * FROM tabnivoji WHERE leto=".$VLeto." AND Nivoji IN (".Skupina2Nivo($VSkupina,$VPredmet).") AND ucenec=".$R["iducenec"];
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            $IzpisiUcenca=true;
                                        }
                                    }
                                }
                                break;
                            case 4:
                                $SQL = "SELECT * FROM tabizbirni WHERE leto=".$VLeto." AND Izbirni IN (".$VPredmet.") AND ucenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    $IzpisiUcenca=true;
                                }
                                break;
                            case 5:
                                $SQL = "SELECT * FROM tabopb WHERE leto=".$VLeto." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                if (vsebuje($VPredmet,"78") && $R1["pb1"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"79") && $R1["pb2"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"80") && $R1["pb3"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"81") && $R1["pb4"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"82") && $R1["pb5"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"83") && $R1["pb6"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"84") && $R1["pb7"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"85") && $R1["pb8"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"86") && $R1["pb9"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"87") && $R1["pb10"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"88") && $R1["pb11"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"89") && $R1["pb12"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"90") && $R1["pb13"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"91") && $R1["pb14"]) $IzpisiUcenca=true;
                                if (vsebuje($VPredmet,"52") && $R1["pb15"]) $IzpisiUcenca=true;
                                break;
                            case 6:
                                if (vsebuje($VPredmet,"62")){
                                    $SQL = "SELECT * FROM tabopb WHERE leto=".$VLeto." AND idUcenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        if ($R1["juv"]) $IzpisiUcenca=true;
                                    }
                                }else{
                                    $IzpisUcenca=true;
                                }
                                break;
                            default:
                                //'preveri na izbirne predmete, če v urniku ni vnesen podatek o izbirnem predmetu
                                $SQL = "SELECT * FROM tabpredmeti WHERE id IN (".$VPredmet.")";
                                $result1 = mysqli_query($link,$SQL);
                                $JeNivo=false;
                                while ($R1 = mysqli_fetch_array($result1)){
                                    if ($R1["Prioriteta"] == 1){
                                        $JeNivo=true;
                                    }
                                }
                                if ($JeNivo){
                                    $SQL = "SELECT * FROM tabizbirni WHERE leto=".$VLeto." AND Izbirni IN (".$VPredmet.") AND ucenec=".$R["iducenec"];
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        $IzpisiUcenca=true;
                                    }
                                }else{
                                    //'preveri na OPB, če ni vnesenih skupin v urniku
                                    $SQL = "SELECT id FROM tabpredmeti WHERE id IN (".$VPredmet.")";
                                    $result1 = mysqli_query($link,$SQL);
                                    $JeNivo=false;
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        switch ( $R1["id"]){
                                            case 52:
                                            case 78:
                                            case 79:
                                            case 80:
                                            case 81:
                                            case 82:
                                            case 83:
                                            case 84:
                                            case 85:
                                            case 86:
                                            case 87:
                                            case 88:
                                            case 89:
                                            case 90:
                                            case 91:
                                                $JeNivo=true;
                                        }
                                    }
                                    if ($JeNivo){
                                        $SQL = "SELECT * FROM tabopb WHERE leto=".$VLeto." AND ucenec=".$R["iducenec"];
                                        $result1 = mysqli_query($link,$SQL);
                                        if (vsebuje($VPredmet,"78") && $R1["pb1"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"79") && $R1["pb2"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"80") && $R1["pb3"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"81") && $R1["pb4"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"82") && $R1["pb5"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"83") && $R1["pb6"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"84") && $R1["pb7"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"85") && $R1["pb8"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"86") && $R1["pb9"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"87") && $R1["pb10"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"88") && $R1["pb11"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"89") && $R1["pb12"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"90") && $R1["pb13"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"91") && $R1["pb14"]) $IzpisiUcenca=true;
                                        if (vsebuje($VPredmet,"52") && $R1["pb15"]) $IzpisiUcenca=true;
                                    }else{
                                        $IzpisiUcenca=true;
                                    }
                                }
                        }
                        if ($IzpisiUcenca){
                            $Indx=$Indx+1;
                            if ($Indx % 2 == 0){
                                echo "<tr>";
                            }else{
                                echo "<tr  style='background-color:lightgrey;'>";
                            }
                            //izpis odsotnosti
                            echo "<td>".$Indx."</td>";
                            echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                            $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"]." AND status < 3";
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                            }else{
                                echo "<input name='ods_".$Indx."' type='checkbox'>";
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                }
                            }
                            
                            echo "</td>";
                            
                            //izpis opomb
                            $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"];
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                if ($Indx % 2 == 0){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'>".$R1["opomba"]."</textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'>".$R1["opomba"]."</textarea>";
                                }
                            }else{
                                if ($Indx % 2 == 0){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'></textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'></textarea>";
                                }
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                }
                            }
                            //zadnjih 10 opomb pri aktualnem predmetu
                            $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND predmet IN (".$VPredmet.") AND idUcenec=".$R["iducenec"]." ORDER BY datum DESC LIMIT 0,10";
                            $result1 = mysqli_query($link,$SQL);
                            if (mysqli_num_rows($result1) > 0){
                                echo "<br /><a href='dnevnik.php?idd=300&id=3&ucenec=".$R["iducenec"]."'>Zadnjih 10 vpisov pri tem predmetu</a>: ";
                                while ($R1 = mysqli_fetch_array($result1)){
                                    $VDatumOp=new DateTime($R1["datum"]);
                                    echo $VDatumOp->format('j.n.').": ".$R1["opomba"].", ";
                                }
                            }
                                
                            echo "</td>";
                            
                            //izpis redovalnice
                            echo "<td>";
                            if ($R["razred"] > 2){
                                $SQL = "SELECT id,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$R["iducenec"]." AND idpredmet IN (".$VPredmet.")";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    if ($Indx % 2 == 0){
                                        echo "<table border='1'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."' ></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."' ></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."' ></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."'></td></tr>";
                                    }else{
                                        echo "<table border='1'  style='background-color:lightgrey;'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."'  style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."'  style='background-color:lightgrey;'></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."'  style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."' style='background-color:lightgrey;'></td></tr>";
                                    }
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }else{
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    if ($Indx % 2 == 0){
                                        echo "<table border='1'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value=''></td><td><input name='s1u_".$Indx."' type='text' value=''></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value=''></td><td><input name='s2u_".$Indx."' type='text' value=''></td></tr>";
                                    }else{
                                        echo "<table border='1'  style='background-color:lightgrey;'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value=''  style='background-color:lightgrey;'></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td></tr>";
                                    }
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }
                            }
                            echo "</td>";
                            echo "</tr>";
                        }
                    }
                    if ($Indx==0){
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred FROM tabrazred ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." AND idRazred IN (".$VRazred.") ";
                        $SQL = $SQL . "ORDER BY razred,paralelka,priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            $Indx=$Indx+1;
                            if ($Indx % 2 == 0){
                                echo "<tr>";
                            }else{
                                echo "<tr  style='background-color:lightgrey;'>";
                            }
                            //izpis odsotnosti
                            /*
                            echo "<td>".$Indx."</td>";
                            echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                            $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"]." AND status < 3";
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                            }else{
                                echo "<input name='ods_".$Indx."' type='checkbox'>";
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                }
                            }
                            
                            echo "</td>";
                            
                            //izpis opomb
                            $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"];
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo "<textarea name='op_".$Indx."' cols='40' rows='2'>".$R1["opomba"]."</textarea>";
                            }else{
                                echo "<textarea name='op_".$Indx."' cols='40' rows='2'></textarea>";
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                }
                            }
                            echo "</td>";
                            
                            //izpis redovalnice
                            echo "<td>";
                            if ($R["razred"] > 2){
                                $SQL = "SELECT id,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$R["iducenec"]." AND idpredmet IN (".$VPredmet.")";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    echo "<table border='1'>";
                                    echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."'></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."'</td></tr>";
                                    echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."'></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."'</td></tr>";
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }else{
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    echo "<table border='1'>";
                                    echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value=''></td><td><input name='s1u_".$Indx."' type='text' value=''</td></tr>";
                                    echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value=''></td><td><input name='s2u_".$Indx."' type='text' value=''</td></tr>";
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }
                            }
                            echo "</td>";
                            */

                            echo "<td>".$Indx."</td>";
                            echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                            $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"]." AND status < 3";
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='odsuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo "<input name='ods_".$Indx."' type='checkbox' checked='checked'>";
                            }else{
                                echo "<input name='ods_".$Indx."' type='checkbox'>";
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "&nbsp;<a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>";
                                }
                            }
                            
                            echo "</td>";
                            
                            //izpis opomb
                            $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra." AND idUcenec=".$R["iducenec"];
                            $result1 = mysqli_query($link,$SQL);
                            echo "<td><input name='opuc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>";
                            if ($R1 = mysqli_fetch_array($result1)){
                                if ($Indx % 2 == 0){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'>".$R1["opomba"]."</textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'>".$R1["opomba"]."</textarea>";
                                }
                            }else{
                                if ($Indx % 2 == 0){
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2'></textarea>";
                                }else{
                                    echo "<textarea name='op_".$Indx."' cols='40' rows='2' style='background-color:lightgrey;'></textarea>";
                                }
                            }
                            if ($VUra > 0){
                                $SQL = "SELECT * FROM tabopombeuc WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura < ".$VUra." AND idUcenec=".$R["iducenec"];
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){
                                    echo "<br /><a href='dnevnik.php?idd=100&izdnevnika=".$R1["idDnevnik"]."'>".$R1["ura"]."</a>: ".$R1["opomba"];
                                }
                            }
                            echo "</td>";
                            
                            //izpis redovalnice
                            echo "<td>";
                            if ($R["razred"] > 2){
                                $SQL = "SELECT id,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE leto=".$VLeto." AND iducenec=".$R["iducenec"]." AND idpredmet IN (".$VPredmet.")";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    if ($Indx % 2 == 0){
                                        echo "<table border='1'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."' ></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."' ></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."' ></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."'></td></tr>";
                                    }else{
                                        echo "<table border='1'  style='background-color:lightgrey;'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$R1["idpredmet"]."'><input name='oc_".$Indx."' type='hidden' value='".$R1["id"]."'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='".$R1["ocenas1p"]."'  style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value='".$R1["ocenas1u"]."'  style='background-color:lightgrey;'></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='".$R1["ocenas2p"]."'  style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='".$R1["ocenas2u"]."' style='background-color:lightgrey;'></td></tr>";
                                    }
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }else{
                                    //echo "<form name='ocene_".$Indx."' method='POST' action='dnevnik.php'>";
                                    //echo "<input name='idd' type='hidden' value='100'>";
                                    //echo "<input name='id' type='hidden' value='10'>";
                                    if ($Indx % 2 == 0){
                                        echo "<table border='1'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value=''></td><td><input name='s1u_".$Indx."' type='text' value=''></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value=''></td><td><input name='s2u_".$Indx."' type='text' value=''></td></tr>";
                                    }else{
                                        echo "<table border='1'  style='background-color:lightgrey;'>";
                                        echo "<tr><td><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'><input name='pr_".$Indx."' type='hidden' value='".$VPredmet."'><input name='oc_".$Indx."' type='hidden' value='0'><a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>1.</a><input name='s1p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s1u_".$Indx."' type='text' value=''  style='background-color:lightgrey;'></td></tr>";
                                        echo "<tr><td>2.<input name='s2p_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td><td><input name='s2u_".$Indx."' type='text' value='' style='background-color:lightgrey;'></td></tr>";
                                    }
                                    echo "</table>";
                                    //echo "<input name='submit' type='submit' value='Oceni'>";
                                    //echo "</form>";
                                }
                            }
                            echo "</td>";
                            
                            echo "</tr>";
                        }
                    }
                    echo "</table><br />";
                    echo "<input name='stucencev' type='hidden' value='".$Indx."'>";
                    echo "</div>";
                }else{
                    echo "<input name='stucencev' type='hidden' value='0'>";
                }
                if ($IzDnevnika > 0){
                    echo "<input name='id' type='hidden' value='2'>";
                    echo "<input name='redovalnica' type='checkbox'>dovoli vpis ocen<br />";
                    echo "<input name='izdnevnika' type='hidden' value='".$IzDnevnika."'>";
                    echo "<input name='submit' type='submit' value='Popravi'>";
                }else{
                    echo "<input name='id' type='hidden' value='1'>";
                    echo "<input name='redovalnica' type='checkbox'>dovoli vpis ocen<br />";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                }
                echo "</form><br />";
                
        }
        echo "<div style='background-color:lightgrey'><h2>Izbor ure</h2>V primeru neprimernega predloga dnevniškega zapisa s strani programa, uporabite spodnje izbore iz dnevnika ali iz urnika.<br />";
        
                //'izbor drugega pouka iz dnevnika (če je drug učitelj, ...)
                echo "<form name='vnosIzDnevnika' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
                echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
                echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<select name='izdnevnika'>";
                $SQL = "SELECT tabdnevnik.id AS did,tabdnevnik.opis AS dopis,tabdnevnik.statusure,tabdnevnik.skupina,tabpredmeti.opis AS popis FROM (tabdnevnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabdnevnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE leto=".$VLeto." AND day(datum)=".$VDatum->format('j')." AND month(datum)=".$VDatum->format('n')." AND year(datum)=".$VDatum->format('Y')." AND ura=".$VUra;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($IzDnevnika > 0){
                        if ($IzDnevnika==$R["did"]){
                            $VOpombe=$R["dopis"];
                            $VStatusUre=$R["statusure"];
                            echo "<option value='".$R["did"]."' selected='selected'>";
                            $SQL = "SELECT tabrazdat.* FROM tabdnevnikr INNER JOIN tabrazdat ON tabdnevnikr.idRazred=tabrazdat.id WHERE idDnevnik=".$R["did"];
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["razred"].". ".$R1["oznaka"].", ";
                            }
                            echo $R["popis"]." (".ToNivo($R["skupina"]).") - ";
                            
                            $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["priimek"]." ".$R1["ime"].", ";
                            }
                            echo "</option>";
                        }else{
                            echo "<option value='".$R["did"]."'>";
                            $SQL = "SELECT tabrazdat.* FROM tabdnevnikr INNER JOIN tabrazdat ON tabdnevnikr.idRazred=tabrazdat.id WHERE idDnevnik=".$R["did"];
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["razred"].". ".$R1["oznaka"].", ";
                            }
                            echo $R["popis"]." (".ToNivo($R["skupina"]).") - ";
                            
                            $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["priimek"]." ".$R1["ime"].", ";
                            }
                            echo "</option>";
                        }
                    }else{
                        echo "<option value='".$R["did"]."'>";
                        $SQL = "SELECT tabrazdat.* FROM tabdnevnikr INNER JOIN tabrazdat ON tabdnevnikr.idRazred=tabrazdat.id WHERE idDnevnik=".$R["did"];
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo $R1["razred"].". ".$R1["oznaka"].", ";
                        }
                        echo $R["popis"]." (".ToNivo($R["skupina"]).") - ";
                        
                        $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM tabdnevniku INNER JOIN tabucitelji ON tabdnevniku.idUcitelj=tabucitelji.idUcitelj WHERE idDnevnik=".$R["did"];
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo $R1["priimek"]." ".$R1["ime"].", ";
                        }
                        echo "</option>";
                    }
                }
                echo "</select>";
                echo "<input name='submit' type='submit' value='Izberi iz dnevnika'>";
                echo "</form>";
                        
                //'izbor drugega pouka iz urnika (če je drug učitelj, ...)
                echo "<form name='vnosPouka' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='100'>";
                echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
                echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
                echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<select name='pouk'>";
                $SQL = "SELECT taburnik.id,taburnik.razred,taburnik.paralelka,taburnik.nivo,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime FROM (taburnik ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj ";
                $SQL = $SQL . "WHERE leto=".$VLeto." AND od <= ".$VDatum->format('Ymd')." AND do >= ".$VDatum->format('Ymd')." AND DanVTednu=".$VDatum->format('w')." AND ura=".$VUra;
                $SQL = $SQL . " ORDER BY razred,paralelka";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($VPouk > 0){
                        if ($VPouk==$R["id"]){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                        }
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["paralelka"].", ".$R["opis"]." (".ToNivo($R["nivo"]).") - ".$R["priimek"]." ".$R["ime"]."</option>";
                    }
                }
                echo "</select>";
                echo "<input name='submit' type='submit' value='Izberi iz urnika'>";
                echo "</form><br>";
        echo "</div>";

        echo "<div style='background-color:lightyellow'><h2>Vnos priprav</h2>";
        
        //Naloži pripravo
        echo "<form name='fpriprava' method='post' ENCTYPE='multipart/form-data' action='dnevnik.php'>";
        echo "<input name='idd' type='hidden' value='100'>";
        echo "<input name='id' type='hidden' value='12'>";
        echo "<div>Zaradi lažjega pregleda naj bo ime datoteke sestavljeno iz predmeta, razreda, ure, inicialk učitelja in datuma. Npr.: TJA8_12_MV_20131002<br/>";
        echo "<font color='green'>Prenesete lahko datoteke tipa: <b>txt, doc, docx, rtf, pdf</b></font></div>";
        echo "<input name='priprava' size='40' type='file'><br />";
        echo "<input name='submit' type='submit' value='Naloži pripravo'>";
        echo "</form><br />";

        echo "</div>";
        
        echo "<div style='background-color:lightcyan'><h2>Različne oblike izpisov dnevnika</h2>";
        //razredni tedenski dnevniški zapisi
        echo "<font color='green'>Za pregled tedenskega razrednega dnevnika izberite razred.<br /> Tam lahko pregledate tudi vse <b>predmetne dnevniške zapise</b>.</font>";
        echo "<form name='dnevnikR' method='POST' action='dnevnik.php'>";
        echo "<input name='idd' type='hidden' value='100'>";
        echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
        echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
        echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
        echo "<input name='ura' type='hidden' value='".$VUra."'>";
        echo "<select name='idrazred'>";
        $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($idRazred==$R["id"]){
                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }
        }
        echo "</select>";
        echo "<input name='id' type='hidden' value='4'>";
        echo "<input name='submit' type='submit' value='Izberi razred'>";
        echo "</form><br />";

        //dnevniški zapisi učiteljev
        echo "<div>Pregled dnevniških zapisov po učiteljih:<br />";
        echo "<form name='dnevnikUc' method='POST' action='dnevnik.php'>";
        echo "<input name='idd' type='hidden' value='100'>";
        echo "<input name='dan' type='hidden' value='".$VDatum->format('j')."'>";
        echo "<input name='mesec' type='hidden' value='".$VDatum->format('n')."'>";
        echo "<input name='letod' type='hidden' value='".$VDatum->format('Y')."'>";
        echo "<input name='ura' type='hidden' value='".$VUra."'>";
        echo "<select name='uciteljp'>";
        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($IdUcitelj == $R["iducitelj"]){
                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
            }else{
                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
            }
        }
        echo "</select>";
        echo "<input name='submit' type='submit' value='Izberi učitelja'>";
        echo "<br />";
        echo "<input name='obdobje' type='radio' value='1'>Vsi vpisi <input name='obdobje' type='radio' value='2'>Mesečni vpisi <input name='obdobje' type='radio' value='3' checked='checked'>Tedenski vpisi <input name='obdobje' type='radio' value='4'>Dnevni vpisi<br />";
        echo "<input name='id' type='hidden' value='3'>";
        echo "</form><br /></div>";
        echo "</div>";
        echo "<a href='dnevnik.php?idd=100&id=9&dan=".$VDatum->format('j')."&mesec=".$VDatum->format('n')."&letod=".$VDatum->format('Y')."'>Mesečni izpisi za vse razrede</a><br>";
        echo "<a href='dnevnik.php?idd=100'>Nazaj na splošen vnos dnevnika</a><br>";
//        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";
        break;
    case "200": //vnos odsotnosti učenca
        /*
        'pogleda, kaj naj naredi:
        '1 - vpiše novo odsotnost
        '2 - popravi odsotnost
        '2a - vpis popravka
        '3 - vse odsotnosti učenca
        */
        switch ($Vid){
            case "4":
                break;
            default:
		        $n=$VLevel;
		        include('menu_func.inc');
		        include ('menu.inc');
        }
        if (isset($_POST["ucenec"])){
            $VUcenec = intval($_POST["ucenec"]);
        }else{
            if (isset($_GET["ucenec"])){
                $VUcenec=intval($_GET["ucenec"]);
            }else{
                $VUcenec = 0;
            }
        }
        if (isset($_POST["mesec"])){
            $VMesec = $_POST["mesec"];
        }else{
            if (isset($_GET["mesec"])){
                $VMesec=$_GET["mesec"];
            }else{
                $VMesec = $Danes->format('n');
            }
        }
        if (isset($_POST["dan"])){
            $VDan = $_POST["dan"];
        }else{
            if (isset($_GET["dan"])){
                $VDan=$_GET["dan"];
            }else{
                $VDan = $Danes->format('j');
            }
        }
        if (isset($_POST["letoods"])){
            $VLetoD = $_POST["letoods"];
        }else{
            if (isset($_GET["letoods"])){
                $VLetoD=$_GET["letoods"];
            }else{
                $VLetoD = $Danes->format('Y');
            }
        }
        if (checkdate($VMesec,$VDan,$VLetoD)){
            $VDatum=new DateTime($VLetoD."-".$VMesec."-".$VDan);
        }else{
            $VDatum=new DateTime($Danes->format('Y-m-d'));
        }
        if (isset($_POST["predmet"])){
            $VPredmet = $_POST["predmet"];
        }else{
            if (isset($_GET["predmet"])){
                $VPredmet=$_GET["predmet"];
            }else{
                $VPredmet = 0;
            }
        }
         if (isset($_POST["opomba"])){
            $VOpomba = $_POST["opomba"];
        }else{
            if (isset($_GET["opomba"])){
                $VOpomba=$_GET["opomba"];
            }else{
                $VOpomba = "";
            }
        }
         if (isset($_POST["odsotnost"])){
            $VOdostnost = $_POST["odsotnost"];
        }else{
            if (isset($_GET["odsotnost"])){
                $VOdsotnost=$_GET["odsotnost"];
            }else{
                $VOdsotnost = 0;
            }
        }
         if (isset($_POST["zapis"])){
            $VZapis = $_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                $VZapis = 0;
            }
        }
        if (isset($_POST["ura"])){
            $VUra = $_POST["ura"];
        }else{
            if (isset($_GET["ura"])){
                $VUra=$_GET["ura"];
            }else{
                $VUra = 0;
            }
        }
        $VUcitelj=Arr2Str($VUcitelj);
        echo "<h2>Vpis odsotnosti učenca</h2>";
        switch ( $Vid){
            case "1": // 'vpiše novo odsotnost
                $SQL = "SELECT * FROM tabodsotnostuc WHERE leto=".$VLeto." AND idUcenec=".$VUcenec." AND year(datum)=".$VLetoD;
                $SQL = $SQL . " AND month(datum)=".$VMesec." AND day(datum)=".$VDan." AND ura=".$VUra ;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //'zapis obstaja
                    $SQL = "UPDATE tabodsotnostuc SET ";
                    $SQL = $SQL . "predmet=".$VPredmet;
                    $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                    $SQL = $SQL . ",status=".$VOdsotnost;
                    $SQL = $SQL . ",opomba='".$VOpomba."'";
                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                    $SQL = $SQL . ",casspr='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$R["ID"];
                    echo "<h2>Odsotnost je bila popravljena</h2>";
                }else{
                    //'zapis ne obstaja
                    $SQL = "INSERT INTO tabodsotnostuc (leto,datum,idUcenec,ura,predmet,ucitelj,status,opomba,vpisal,casvp) VALUES (";
                    $SQL = $SQL . $VLeto.",";
                    $SQL = $SQL . "'".$VDatum->format('Y-m-d')."',";
                    $SQL = $SQL . $VUcenec.",";
                    $SQL = $SQL . $VUra.",";
                    $SQL = $SQL . $VPredmet.",";
                    $SQL = $SQL . "'".$VUcitelj."',";
                    $SQL = $SQL . $VOdsotnost.",";
                    $SQL = $SQL . "'".$VOpomba."',";
                    $SQL = $SQL . $IdUcitelj.",";
                    $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."')";
                    echo "<h2>Odsotnost je bila vpisana</h2>";
                }
                $result = mysqli_query($link,$SQL);
                break;
            case "2": // 'popravi odsotnost
                $SQL = "SELECT tabodsotnostuc.id,tabodsotnostuc.leto,tabodsotnostuc.status,tabodsotnostuc.iducenec,tabodsotnostuc.datum,tabodsotnostuc.predmet,tabodsotnostuc.ura,tabodsotnostuc.opomba,tabodsotnostuc.ucitelj,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabsifrantodsuc.* FROM (((tabodsotnostuc ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabodsotnostuc.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabsifrantodsuc ON tabodsotnostuc.status=tabsifrantodsuc.idOdsotnost ";
                $SQL = $SQL . "WHERE tabodsotnostuc.id=".$VZapis." AND tabrazred.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $VIdUcenec=$R["iducenec"];
                    $VLeto=$R["leto"];
                    echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                    echo "<input name='idd' type='hidden' value='200'>";
                    echo "<input name='id' type='hidden' value='2a'>";
                    echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                    echo "<input name='zapis' type='hidden' value='".$VZapis."'>";
                    echo "<input name='leto' type='hidden' value='".$VLeto."'>";
                    echo "<table border='0'>";
                    echo "<tr><td>Šolsko leto</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
                    echo "<tr><td>Učenec</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                    
                    echo "<tr><td>Datum</td><td>";
                    echo "<select name='dan'>";
                    $Datum=new DateTime($R["datum"]);
                    for ($Indx=1;$Indx <= 31;$Indx++){
                        if ($Indx==$Datum->format('j')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "<select name='mesec'>";
                    for ($Indx=1;$Indx <= 12;$Indx++){
                        if ($Indx==$Datum->format('n')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "<select name='letoods'>";
                    for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                        if ($Indx==$Datum->format('Y')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td></tr>";
                    
                    echo "<tr><td>Ura v urniku</td><td>";
                    echo int2Dan($Datum->format('w'))." ";
                    echo "<select name='ura'>";
                    for ($Indx=0;$Indx <= 13;$Indx++){
                        if ($Indx==$R["ura"]){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."'>".$Indx."</option>";
                        }
                    }
                    echo "</td></tr>";
                    
                    echo "<tr><td>Predmet</td><td>";
                    $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.vrstnired,tabucenje.predmet FROM ((tabucenje ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.idRazred=tabucenje.idRazred) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                    $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                    $result1 = mysqli_query($link,$SQL);
                    echo "<select name='predmet'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["id"]==$R["predmet"]){
                            echo "<option value='".$R1["id"]."' selected='selected'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                        }else{
                            echo "<option value='".$R1["id"]."'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                        }
                    }
                    $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta=3 ORDER BY opis";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo "<option value='".$R1["id"]."'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                    }
                    echo "</td></tr>";
                    
                    echo "<tr><td>Učitelj</td><td>";
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    $VUcitelj="";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($VUcitelj)==0){
                            $VUcitelj=$R1["iducitelj"];
                            echo $R1["priimek"]." ".$R1["ime"]."<br />";
                        }else{
                            if (!vsebuje($VUcitelj,$R1["iducitelj"])){
                                $VUcitelj=$VUcitelj.",".$R1["iducitelj"];
                                echo $R1["priimek"]." ".$R1["ime"]."<br />";
                            }
                        }
                    }
                    
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                    $result1 = mysqli_query($link,$SQL);
                    echo "<select name='ucitelj[]' multiple='multiple'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (vsebuje($VUcitelj,$R1["iducitelj"])){
                            echo "<option value='".$R1["iducitelj"]."' selected='selected'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                        }else{
                            echo "<option value='".$R1["iducitelj"]."'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                        }
                    }
                    echo "</td></tr>";

                    echo "<tr><td>Odsotnost</td><td>";
                    $SQL = "SELECT tabsifrantodsuc.* FROM tabsifrantodsuc ";
                    $result1 = mysqli_query($link,$SQL);
                    echo "<select name='odsotnost'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["idodsotnost"]==$R["status"]){
                            echo "<option value='".$R1["idodsotnost"]."' selected='selected'>".$R1["odsotnost"]."</option>";
                        }else{
                            echo "<option value='".$R1["idodsotnost"]."'>".$R1["odsotnost"]."</option>";
                        }
                    }
                    echo "</td></tr>";
                    
                    echo "<tr><td>Opomba</td><td><textarea name='opomba' cols='40' rows='5'>".$R["opomba"]."</textarea>";
                    echo "</td></tr>";
                    
                    echo "</table><br />";
                    echo "<input name='submit' type='submit' value='Pošlji'><br />";
                    echo "</form><br />";
                }
                break;
            case "2a": // 'vpis popravka
                $SQL = "SELECT id FROM tabodsotnostuc WHERE id=".$VZapis; 
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //'zapis obstaja
                    $SQL = "UPDATE tabodsotnostuc SET ";
                    $SQL = $SQL . "predmet=".$VPredmet;
                    $SQL = $SQL . ",ura=".$VUra;
                    $SQL = $SQL . ",datum='".$VDatum->format('Y-m-d')."'";
                    $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                    $SQL = $SQL . ",status=".$Vodsotnost;
                    $SQL = $SQL . ",opomba='".$VOpomba."'";
                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                    $SQL = $SQL . ",casspr='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$R["id"];
                    echo "<h2>Odsotnost je bila popravljena</h2>";
                    $result = mysqli_query($link,$SQL);
                }else{
                    echo "<h2>Zapis ne obstaja</h2>";
                }
                break;
            case "3": // 'vse odsotnosti učenca
                $SQL = "SELECT tabodsotnostuc.*,tabodsotnostuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis,tabsifrantodsuc.* FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabodsotnostuc ON tabucenci.idUcenec=tabodsotnostuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabsifrantodsuc ON tabodsotnostuc.status=tabsifrantodsuc.idOdsotnost ";
                $SQL = $SQL . "WHERE tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabodsotnostuc.idUcenec=".$VUcenec;
                $SQL = $SQL . " ORDER BY datum DESC";
                $result = mysqli_query($link,$SQL);
                echo "<form name='status' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='200'>";
                echo "<input name='id' type='hidden' value='4'>";
                echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>status<br /><font color='red'>Dr</font> <font color='green'>Op NO</font> Br</th><th>opomba</th><th>Popravi</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td><input name='ods_".$Indx."' type='hidden' value='".$R["oid"]."'>";
                    switch ( $R["status"]){
                        case 0:
                            echo "<input name='bods_".$Indx."' type='radio' value='0' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 1:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 2:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 3:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3' checked='checked'>";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=200&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='stods' type='hidden' value='".($Indx-1)."'>";
                echo "<input name='submit' type='submit' value='Nastavi statuse'><br />";
                echo "</form>";
                break;
            case "3a": // 'odsotnosti na določen dan
                $SQL = "SELECT tabodsotnostuc.*,tabodsotnostuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis,tabsifrantodsuc.* FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabodsotnostuc ON tabucenci.idUcenec=tabodsotnostuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabsifrantodsuc ON tabodsotnostuc.status=tabsifrantodsuc.idOdsotnost ";
                $SQL = $SQL . "WHERE tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabodsotnostuc.idUcenec=".$VUcenec." AND year(datum)=".$VDatum->format('Y')." AND month(datum)=".$VDatum->format('n')." AND day(datum)=".$VDatum->format('j');
                $SQL = $SQL . " ORDER BY ura";
                $result = mysqli_query($link,$SQL);
                echo "<form name='status' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='200'>";
                echo "<input name='id' type='hidden' value='4'>";
                echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>status<br /><font color='red'>Dr</font> <font color='green'>Op NO</font> Br</th><th>opomba</th><th>Popravi</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td><input name='ods_".$Indx."' type='hidden' value='".$R["oid"]."'>";
                    switch ( $R["status"]){
                        case 0:
                            echo "<input name='bods_".$Indx."' type='radio' value='0' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 1:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 2:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 3:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3' checked='checked'>";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=200&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='stods' type='hidden' value='".($Indx-1)."'>";
                echo "<input name='submit' type='submit' value='Nastavi statuse'><br />";
                echo "</form>";
                break;
            case "4": //vpis sprememb statusov odsotnosti
                $StOds=$_POST["stods"];
                for ($Indx=1;$Indx <= $StOds;$Indx++){
                    $SQL = "UPDATE tabodsotnostuc SET ";
                    $SQL = $SQL . "status=".$_POST["bods_".$Indx];
                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                    $SQL = $SQL . ",casspr='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$_POST["ods_".$Indx];
                    $result = mysqli_query($link,$SQL);
                }
                if ($VUcenec > 0){
                    header ("Location: dnevnik.php?idd=200&id=3&ucenec=".$VUcenec);
                }else{
                    if (isset($_POST["mesec"])){
                        header ("Location: dnevnik.php?idd=200&id=5&razred=".$VRazred."&mesec=".$_POST["mesec"]);
                    }else{
                        header ("Location: dnevnik.php?idd=200&id=5&razred=".$VRazred);
                    }
                }
                break;
            case "5": // 'vse odsotnosti razreda
                if (isset($_POST["mesec"])){
                   $mesec=$_POST["mesec"];
                }else{
                    if (isset($_GET["mesec"])){
                        $mesec=$_GET["mesec"];
                    }else{
                        $mesec=0;
                    }
                }
                $SQL = "SELECT tabodsotnostuc.*,tabodsotnostuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis,tabsifrantodsuc.* FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabodsotnostuc ON tabucenci.idUcenec=tabodsotnostuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabsifrantodsuc ON tabodsotnostuc.status=tabsifrantodsuc.idOdsotnost ";
                if ($mesec > 0){
                    $SQL = $SQL . "WHERE tabodsotnostuc.leto=".$VLeto." AND month(datum)=".$mesec." AND tabrazred.leto=".$VLeto." AND tabrazred.idRazred=".$VRazred;
                }else{
                    $SQL = $SQL . "WHERE tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.idRazred=".$VRazred;
                }
                $SQL = $SQL . " ORDER BY datum DESC, priimek,ime";
                $result = mysqli_query($link,$SQL);
                echo "<form name='status' method='POST' action='dnevnik.php'>";
                echo "<input name='idd' type='hidden' value='200'>";
                echo "<input name='id' type='hidden' value='4'>";
                echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                if ($mesec > 0){
                    echo "<input name='mesec' type='hidden' value='".$mesec."'>";
                }
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>status<br /><font color='red'>Dr</font> <font color='green'>Op NO</font> Br</th><th>opomba</th><th>Popravi</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td><input name='ods_".$Indx."' type='hidden' value='".$R["oid"]."'>";
                    switch ( $R["status"]){
                        case 0:
                            echo "<input name='bods_".$Indx."' type='radio' value='0' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 1:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 2:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2' checked='checked'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3'>";
                            break;
                        case 3:
                            echo "<input name='bods_".$Indx."' type='radio' value='0'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='1'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='2'>";
                            echo "<input name='bods_".$Indx."' type='radio' value='3' checked='checked'>";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td align='center'><a href='dnevnik.php?idd=200&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='stods' type='hidden' value='".($Indx-1)."'>";
                echo "<input name='submit' type='submit' value='Nastavi statuse'><br />";
                echo "</form><br />";
                echo "<a href='dnevnik.php?idd=100&id=4&idrazred=".$VRazred."'>Dnevniški zapis</a><br />";
                break;
            default:
                if ((strlen($VUcenec) == 0) or (intval($VUcenec) == 0)){ //'na izbor učenca
                    echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                    echo "<input name='idd' type='hidden' value='200'>";
                    echo "<input name='id' type='hidden' value=''>";
                    echo "<select name='ucenec'>";
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE leto=".$VLeto." AND razred > 0 ORDER BY priimek,ime,razred,paralelka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</option>";
                    }
                    echo "</select>";
                    echo "<input name='submit' type='submit' value='Pošlji'><br />";
                    echo "</form><br />";
                }else{
                    //'vnos podatkov o odsotnosti
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                        echo "<input name='idd' type='hidden' value='200'>";
                        echo "<input name='id' type='hidden' value='1'>";
                        echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                        echo "<input name='leto' type='hidden' value='".$VLeto."'>";
                        echo "<table border='0'>";
                        echo "<tr><td>Šolsko leto</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
                        echo "<tr><td>Učenec</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                        echo "<tr><td>Datum</td><td>";
                        echo "<select name='dan'>";
                        for ($Indx=1;$Indx <= 31;$Indx++){
                            if ($Indx==$Danes->format('j')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "<select name='mesec'>";
                        for ($Indx=1;$Indx <= 12;$Indx++){
                            if ($Indx==$Danes->format('n')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "<select name='letoOds'>";
                        for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                            if ($Indx==$Danes->format('Y')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "</td></tr>";
                        
                        echo "<tr><td>Ura v urniku</td><td>";
                        echo "<select name='ura'>";
                        for ($Indx=0;$Indx <= 13;$Indx++){
                            echo "<option value='".$Indx."'>".$Indx."</option>";
                        }
                        echo "</td></tr>";
                        
                        echo "<tr><td>Predmet</td><td>";
                        $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.vrstnired,tabucenje.predmet FROM ((tabucenje ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.idRazred=tabucenje.idRazred) ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id) ";
                        $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                        $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                        $result = mysqli_query($link,$SQL);
                        echo "<select name='predmet'>";
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                        }
                        $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta=3 ORDER BY opis";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                        }
                        echo "</td></tr>";
                        
                        echo "<tr><td>Učitelj</td><td>";
                        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        echo "<select name='ucitelj[]' multiple='multiple'>";
                        while ($R = mysqli_fetch_array($result)){
                            if ($idUcitelj==$R["iducitelj"]){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }
                        echo "</td></tr>";

                        echo "<tr><td>Odsotnost</td><td>";
                        $SQL = "SELECT idodsotnost,odsotnost FROM tabsifrantodsuc ";
                        $result = mysqli_query($link,$SQL);
                        echo "<select name='odsotnost'>";
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["idodsotnost"]==0){
                                echo "<option value='".$R["idodsotnost"]."' selected='selected'>".$R["odsotnost"]."</option>";
                            }else{
                                echo "<option value='".$R["idodsotnost"]."'>".$R["odsotnost"]."</option>";
                            }
                        }
                        echo "</td></tr>";
                        
                        echo "<tr><td>Opomba</td><td><textarea name='opomba' cols='40' rows='5'></textarea>";
                        echo "</td></tr>";
                        
                        echo "</table><br />";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "</form><br />";
                    }else{
                        //'če ne najde učenca, gre v izbor učenca
                        echo "<input name='id' type='hidden' value=''>";
                        echo "<select name='ucenec'>";
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." ORDER BY priimek,ime,razred,paralelka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</option>";
                        }
                        echo "</select>";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "</form><br />";
                    }
                }
        }

        if ($VUcenec > 0){
            switch ( $Vid){
                case "2":
                    echo "<br />";
                    break;
                case "3":
                case "3a":
                    echo "<br />";
                    break;
                default:
                    //'izpis zadnjih 20 odsotnosti
                    echo "<hr>";
                    echo "Zadnjih 20 vpisov:<br />";
                    $SQL = "SELECT tabodsotnostuc.*,tabodsotnostuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis,tabsifrantodsuc.* FROM (((tabodsotnostuc ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabodsotnostuc.idUcenec=tabrazred.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabodsotnostuc.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "INNER JOIN tabsifrantodsuc ON tabodsotnostuc.status=tabsifrantodsuc.idOdsotnost ";
                    $SQL = $SQL . "WHERE tabodsotnostuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
                    $SQL = $SQL . " ORDER BY datum DESC LIMIT 0,20";
                    $result = mysqli_query($link,$SQL);
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>status</th><th>opomba</th><th>Popravi</th></tr>";
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                        $Datum=new DateTime($R["datum"]);
                        echo "<td>".$Datum->format('d.m.Y')."</td>";
                        echo "<td align='center'>".$R["ura"]."</td>";
                        echo "<td>".$R["opis"]."</td>";
                        echo "<td>";
                        $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo $R1["priimek"]." ".$R1["ime"]."<br />";
                        }
                        echo "</td>";
                        echo "<td>".$R["odsotnost"]."</td>";
                        echo "<td>".$R["opomba"]."</td>";
                        echo "<td align='center'><a href='dnevnik.php?idd=200&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                
            }
        }
        $VRazred=0;
        $SQL = "SELECT idrazred FROM tabrazred WHERE iducenec=".$VUcenec." AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred=$R["idrazred"];
        }
        
        echo "<a href='dnevnik.php?idd=200&id=&ucenec=".$VUcenec."'>Na vnos odsotnosti učenca</a><br>";
        echo "<a href='dnevnik.php?idd=200'>Na izbor drugega učenca</a><br>";
        echo "<a href='dnevnik.php?idd=200&id=3&ucenec=".$VUcenec."'>Pokaži vse odsotnosti učenca</a><br>";
        echo "<a href='dnevnik.php?idd=100&id=4&idrazred=".$VRazred."'>Tedenski dnevniški zapis za razred</a><br>";
        echo "<a href='dnevnik.php?idd=100'>Na vnos dnevnika</a><br>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";
        break;
    case "300": //vnos opomb
        /*
        'pogleda, kaj naj naredi:
        '1 - vpiše novo opombo
        '2 - popravi opombo
        '2a - vpis popravka
        '3 - vse opombe učenca
        */
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
        if (isset($_POST["ucenec"])){
            $VUcenec = $_POST["ucenec"];
        }else{
            if (isset($_GET["ucenec"])){
                $VUcenec=$_GET["ucenec"];
            }else{
                $VUcenec = 0;
            }
        }
        if (isset($_POST["mesec"])){
            $VMesec = $_POST["mesec"];
        }else{
            if (isset($_GET["mesec"])){
                $VMesec=$_GET["mesec"];
            }else{
                $VMesec = $Danes->format('n');
            }
        }
        if (isset($_POST["dan"])){
            $VDan = $_POST["dan"];
        }else{
            if (isset($_GET["dan"])){
                $VDan=$_GET["dan"];
            }else{
                $VDan = $Danes->format('j');
            }
        }
        if (isset($_POST["letoods"])){
            $VLetoD = $_POST["letoods"];
        }else{
            if (isset($_GET["letoods"])){
                $VLetoD=$_GET["letoods"];
            }else{
                $VLetoD = $Danes->format('Y');
            }
        }
        if (checkdate($VMesec,$VDan,$VLetoD)){
            $VDatum=new DateTime($VLetoD."-".$VMesec."-".$VDan);
        }else{
            $VDatum=new DateTime($Danes->format('Y-m-d'));
        }
        if (isset($_POST["predmet"])){
            $VPredmet = $_POST["predmet"];
        }else{
            if (isset($_GET["predmet"])){
                $VPredmet=$_GET["predmet"];
            }else{
                $VPredmet = 0;
            }
        }
         if (isset($_POST["opomba"])){
            $VOpomba = $_POST["opomba"];
        }else{
            if (isset($_GET["opomba"])){
                $VOpomba=$_GET["opomba"];
            }else{
                $VOpomba = "";
            }
        }
         if (isset($_POST["zapis"])){
            $VZapis = $_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                $VZapis = 0;
            }
        }
        if (isset($_POST["ura"])){
            $VUra = $_POST["ura"];
        }else{
            if (isset($_GET["ura"])){
                $VUra=$_GET["ura"];
            }else{
                $VUra = 0;
            }
        }
        $VUcitelj=Arr2Str($VUcitelj);
        echo "<h2>Vpis opomb učencu</h2>";

        switch ( $Vid){
            case "1": // 'vpiše novo opombo
                $SQL = "SELECT id FROM tabopombeuc WHERE leto=".$VLeto." AND idUcenec=".$VUcenec." AND year(datum)=".$VDatum->format('Y');
                $SQL = $SQL . " AND month(datum)=".$VDatum->format('n')." AND day(datum)=".$VDatum->format('j')." AND ura=".$VUra;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //'zapis obstaja
                    $SQL = "UPDATE tabopombeuc SET ";
                    $SQL = $SQL . "predmet=".$VPredmet;
                    $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                    $SQL = $SQL . ",opomba=".$VOpomba;
                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                    $SQL = $SQL . ",casspr='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$R["id"];
                    echo "<h2>Opomba je bila popravljena</h2>";
                }else{
                    //'zapis ne obstaja
                    $SQL = "INSERT INTO tabopombeuc (leto,datum,idUcenec,ura,predmet,ucitelj,opomba,vpisal,casvp) VALUES (";
                    $SQL = $SQL . $VLeto.",";
                    $SQL = $SQL . "'".$VDatum->format('Y-m-d')."',";
                    $SQL = $SQL . $VUcenec.",";
                    $SQL = $SQL . $VUra.",";
                    $SQL = $SQL . $VPredmet.",";
                    $SQL = $SQL . "'".$VUcitelj."',";
                    $SQL = $SQL . "'".$VOpomba."',";
                    $SQL = $SQL . $IdUcitelj.",";
                    $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."')";
                    echo "<h2>Opomba je bila vpisana</h2>";
                }
                $result = mysqli_query($link,$SQL);
                break;
            case "2": // 'popravi opombo
                $SQL = "SELECT tabopombeuc.*,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.* FROM (((tabopombeuc ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabopombeuc.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE tabopombeuc.id=".$VZapis." AND tabrazred.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $VUcenec=$R["idUcenec"];
                    $VLeto=$R["leto"];
                    echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                    echo "<input name='idd' type='hidden' value='300'>";
                    echo "<input name='id' type='hidden' value='2a'>";
                    echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                    echo "<input name='zapis' type='hidden' value='".$VZapis."'>";
                    echo "<input name='leto' type='hidden' value='".$VLeto."'>";
                    echo "<table border='0'>";
                    echo "<tr><td>Šolsko leto</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
                    echo "<tr><td>Učenec</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                    
                    echo "<tr><td>Datum</td><td>";
                    echo "<select name='dan'>";
                    $Datum=new DateTime($R["datum"]);
                    for ($Indx=1;$Indx <= 31;$Indx++){
                        if ($Indx==$Datum->format('j')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "<select name='mesec'>";
                    for ($Indx=1;$Indx <= 12;$Indx++){
                        if ($Indx==$Datum->format('n')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "<select name='letoOds'>";
                    for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                        if ($Indx==$Datum->format('Y')){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."' >".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td></tr>";
                    
                    echo "<tr><td>Ura v urniku</td><td>";
                    echo int2Dan($Datum->format('w'))." ";
                    echo "<select name='ura'>";
                    for ($Indx=0;$Indx <= 13;$Indx++){
                        if ($Indx==$R["ura"]){
                            echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value='".$Indx."'>".$Indx."</option>";
                        }
                    }
                    echo "</select></td></tr>";
                    
                    echo "<tr><td>Predmet</td><td>";
                    $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.VrstniRed,tabucenje.predmet FROM ((tabucenje ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.idRazred=tabucenje.idRazred) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                    $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                    $result1 = mysqli_query($link,$SQL);
                    echo "<select name='predmet'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["id"]==$R["predmet"]){
                            echo "<option value='".$R1["id"]."' selected='selected'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                        }else{
                            echo "<option value='".$R1["id"]."'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                        }
                    }
                    $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta=3 ORDER BY opis";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo "<option value='".$R1["id"]."'>".$R1["opis"]." (".$R1["oznaka"].")</option>";
                    }
                    echo "</select></td></tr>";
                    
                    echo "<tr><td>Učitelj</td><td>";
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    $VUcitelj="";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($VUcitelj)==0){
                            $VUcitelj=$R1["iducitelj"];
                            echo $R1["priimek"]." ".$R1["ime"]."<br />";
                        }else{
                            if (!vsebuje($VUcitelj,$R1["iducitelj"])){
                                $VUcitelj=$VUcitelj.",".$R1["iducitelj"];
                                echo $R1["priimek"]." ".$R1["ime"]."<br />";
                            }
                        }
                    }
                    
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                    $result1 = mysqli_query($link,$SQL);
                    echo "<select name='ucitelj[]' multiple='multiple'>";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (vsebuje($VUcitelj,$R1["iducitelj"])){
                            echo "<option value='".$R1["iducitelj"]."' selected='selected'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                        }else{
                            echo "<option value='".$R1["iducitelj"]."'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                        }
                    }
                    echo "</select></td></tr>";

                    echo "<tr><td>Opomba</td><td><textarea name='opomba' cols='40' rows='5'>".$R["opomba"]."</textarea>";
                    echo "</td></tr>";
                    
                    echo "</table><br />";
                    echo "<input name='submit' type='submit' value='Pošlji'><br />";
                    echo "</form><br />";
                }
                break;
            case "2a": // 'vpis popravka
                if (isset($_POST["ura"])){
                    $VUra = $_POST["ura"];
                }else{
                    if (isset($_GET["ura"])){
                        $VUra=$_GET["ura"];
                    }else{
                        $VUra = 0;
                    }
                }
                $SQL = "SELECT id FROM tabopombeuc WHERE id=".$VZapis; 
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //'zapis obstaja
                    $SQL = "UPDATE tabopombeuc SET ";
                    $SQL = $SQL . "predmet=".$VPredmet;
                    $SQL = $SQL . ",ura=".$VUra;
                    $SQL = $SQL . ",datum='".$VDatum->format('Y-m-d')."'";
                    $SQL = $SQL . ",ucitelj='".$VUcitelj."'";
                    $SQL = $SQL . ",opomba='".$VOpomba."'";
                    $SQL = $SQL . ",spremenil=".$IdUcitelj;
                    $SQL = $SQL . ",casspr='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$R["id"];
                    echo "<h2>Opomba je bila popravljena</h2>";
                    $result = mysqli_query($link,$SQL);
                }else{
                    echo "<h2>Zapis ne obstaja</h2>";
                }
                break;
            case "3": // 'vse opombe učenca
                $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabopombeuc ON tabucenci.idUcenec=tabopombeuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabopombeuc.idUcenec=".$VUcenec;
                $SQL = $SQL . " ORDER BY datum DESC";
                $result = mysqli_query($link,$SQL);
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>opomba</th><th>Popravi</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=4&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                break;
            case "3a": // 'opombe na določen dan
                $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabopombeuc ON tabucenci.idUcenec=tabopombeuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabopombeuc.idUcenec=".$VUcenec." AND year(datum)=".$VDatum->format('Y')." AND month(datum)=".$VDatum->format('n')." AND day(datum)=".$VDatum->format('j');
                $SQL = $SQL . " ORDER BY ura";
                $result = mysqli_query($link,$SQL);
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>opomba</th><th>Popravi</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=4&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                break;
            case "4": //brisanje opombe
                $SQL = "DELETE FROM tabopombeuc WHERE id=".$VZapis;
                $result = mysqli_query($link,$SQL);
                echo "<h2>Zapis je bil odstranjen!</h2>";
                break;
            case "5": //izpis mesečnih opomb za razred
                echo "<a href='izborrazreda.php?id=opombe'>Na izbor razreda</a><br />";
                switch (intval($VMesec)){
                    case 1:
                        echo "<a href='dnevnik.php?idd=300&id=5&mesec=12&razred=".$VRazred."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec+1)."&razred=".$VRazred."'>Naslednji</a>";
                        break;
                    case 9:
                        echo "<a href='dnevnik.php?idd=300&id=5&mesec=6&razred=".$VRazred."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec+1)."&razred=".$VRazred."'>Naslednji</a>";
                        break;
                    case 6:
                        echo "<a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec-1)."&razred=".$VRazred."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=5&mesec=9&razred=".$VRazred."'>Naslednji</a>";
                        break;
                    case 12:
                        echo "<a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec-1)."&razred=".$VRazred."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=5&mesec=1&razred=".$VRazred."'>Naslednji</a>";
                        break;
                    default:
                        echo "<a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec-1)."&razred=".$VRazred."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=5&mesec=".($VMesec+1)."&razred=".$VRazred."'>Naslednji</a>";
                        break;
                }
                echo "<br />";
                if ($VRazred == 0){
                    $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabucenci ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabopombeuc ON tabucenci.idUcenec=tabopombeuc.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND month(datum)=".$VMesec;
                    $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime,predmet,oid";
                }else{
                    $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabucenci ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabopombeuc ON tabucenci.idUcenec=tabopombeuc.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.idrazred=".$VRazred." AND month(datum)=".$VMesec;
                    $SQL = $SQL . " ORDER BY priimek,ime,predmet,oid";
                }
                $result = mysqli_query($link,$SQL);
                echo "<h2>Opombe za šolsko leto: ".$VLeto."/".($VLeto+1)." - ".$VMesec."</h2>";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>opomba</th><th>Popravi</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=3&ucenec=".$R["idUcenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo "<a href='dnevnik.php?idd=300&id=6&ucitelj=".$R1["iducitelj"]."'>".$R1["priimek"]." ".$R1["ime"]."</a><br />";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=4&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                break;
            case "6": //izpis mesečnih opomb za učitelja
                echo "<a href='izborrazreda.php?id=opombe'>Na izbor razreda</a><br />";
                switch (intval($VMesec)){
                    case 1:
                        echo "<a href='dnevnik.php?idd=300&id=6&mesec=12&ucitelj=".$VUcitelj."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec+1)."&ucitelj=".$VUcitelj."'>Naslednji</a>";
                        break;
                    case 9:
                        echo "<a href='dnevnik.php?idd=300&id=6&mesec=6&ucitelj=".$VUcitelj."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec+1)."&ucitelj=".$VUcitelj."'>Naslednji</a>";
                        break;
                    case 6:
                        echo "<a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec-1)."&ucitelj=".$VUcitelj."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=6&mesec=9&ucitelj=".$VUcitelj."'>Naslednji</a>";
                        break;
                    case 12:
                        echo "<a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec-1)."&ucitelj=".$VUcitelj."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=6&mesec=1&ucitelj=".$VUcitelj."'>Naslednji</a>";
                        break;
                    default:
                        echo "<a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec-1)."&ucitelj=".$VUcitelj."'>Prejšnji</a> | <a href='dnevnik.php?idd=300&id=6&mesec=".($VMesec+1)."&ucitelj=".$VUcitelj."'>Naslednji</a>";
                        break;
                }
                echo "<br />";
                $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabucenci ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabopombeuc ON tabucenci.idUcenec=tabopombeuc.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND ucitelj=".$VUcitelj." AND month(datum)=".$VMesec;
                $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime,predmet,oid";
                $result = mysqli_query($link,$SQL);
                echo "<h2>Opombe učitelja za šolsko leto: ".$VLeto."/".($VLeto+1)." - ".$VMesec."</h2>";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>opomba</th><th>Popravi</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=3&ucenec=".$R["idUcenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</a></td>";
                    $Datum=new DateTime($R["datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["ura"]."</td>";
                    echo "<td>".$R["opis"]."</td>";
                    echo "<td>";
                    $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        echo $R1["priimek"]." ".$R1["ime"]."<br />";
                    }
                    echo "</td>";
                    echo "<td>".$R["opomba"]."</td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    echo "<td><a href='dnevnik.php?idd=300&id=4&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                break;
            default:
                if ($VUcenec == 0){ //'na izbor učenca
                    echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                    echo "<input name='idd' type='hidden' value='300'>";
                    echo "<input name='id' type='hidden' value=''>";
                    echo "<select name='ucenec'>";
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE leto=".$VLeto." AND razred > 0 ORDER BY priimek,ime,razred,paralelka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</option>";
                    }
                    echo "</select>";
                    echo "<input name='submit' type='submit' value='Pošlji'><br />";
                    echo "</form><br />";
                }else{
                    //'vnos podatkov o opomba
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "WHERE leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<form name='izborUcenca' method='post' action='dnevnik.php'>";
                        echo "<input name='idd' type='hidden' value='300'>";
                        echo "<input name='id' type='hidden' value='1'>";
                        echo "<input name='ucenec' type='hidden' value='".$VUcenec."'>";
                        echo "<input name='leto' type='hidden' value='".$VLeto."'>";
                        echo "<table border='0'>";
                        echo "<tr><td>Šolsko leto</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
                        echo "<tr><td>Učenec</td><td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                        
                        echo "<tr><td>Datum</td><td>";
                        echo "<select name='dan'>";
                        for ($Indx=1;$Indx <= 31;$Indx++){
                            if ($Indx==$Danes->format('j')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "<select name='mesec'>";
                        for ($Indx=1;$Indx <= 12;$Indx++){
                            if ($Indx==$Danes->format('n')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "<select name='letoOds'>";
                        for ($Indx=$Danes->format('Y')-1;$Indx <=$Danes->format('Y')+1;$Indx++){
                            if ($Indx==$Danes->format('Y')){
                                echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value='".$Indx."' >".$Indx."</option>";
                            }
                        }
                        echo "</select>";
                        echo "</td></tr>";
                        
                        echo "<tr><td>Ura v urniku</td><td>";
                        echo "<select name='ura'>";
                        for ($Indx=0;$Indx <= 13;$Indx++){
                            echo "<option value='".$Indx."'>".$Indx."</option>";
                        }
                        echo "</select></td></tr>";
                        
                        echo "<tr><td>Predmet</td><td>";
                        $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka,tabpredmeti.VrstniRed,tabucenje.predmet FROM ((tabucenje ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.idRazred=tabucenje.idRazred) ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id) ";
                        $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.idUcenec=".$VUcenec;
                        $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                        $result = mysqli_query($link,$SQL);
                        echo "<select name='predmet'>";
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                        }
                        $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta=3 ORDER BY opis";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                        }
                        echo "</select></td></tr>";
                        
                        echo "<tr><td>Učitelj</td><td>";
                        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 AND izobrazba > 5 ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        echo "<select name='ucitelj[]' multiple='multiple'>";
                        while ($R = mysqli_fetch_array($result)){
                            if ($IdUcitelj==$R["iducitelj"]){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }
                        echo "</select></td></tr>";

                        echo "<tr><td>Opomba</td><td><textarea name='opomba' cols='40' rows='5'></textarea>";
                        echo "</td></tr>";
                        
                        echo "</table><br />";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "</form><br />";
                    }else{
                        //'če ne najde učenca, gre v izbor učenca
                        echo "<input name='id' type='hidden' value=''>";
                        echo "<select name='ucenec'>";
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                        $SQL = $SQL . "WHERE leto=".$VLeto." ORDER BY priimek,ime,razred,paralelka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</option>";
                        }
                        echo "</select>";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "</form><br />";
                    }
                }
        }

        if ($VUcenec > 0){
            switch ( $Vid){
                case "2":
                    echo "<br />";
                    break;
                case "3":
                case "3a":
                    echo "<br />";
                    break;
                default:
                    //'izpis zadnjih 20 odsotnosti
                    echo "<hr>";
                    echo "Zadnjih 20 opomb:<br />";
                    $SQL = "SELECT tabopombeuc.*,tabopombeuc.id AS oid,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabpredmeti.opis FROM (((tabopombeuc ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabopombeuc.idUcenec=tabrazred.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabucenci ON tabopombeuc.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "WHERE tabopombeuc.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
                    $SQL = $SQL . " ORDER BY datum DESC LIMIT 0,20";
                    $result = mysqli_query($link,$SQL);
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr><th>št.</th><th>ime</th><th>datum</th><th>ura</th><th>predmet</th><th>učitelj</th><th>opomba</th><th>Popravi</th><th>Briši</th></tr>";
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                        $Datum=new DateTime($R["datum"]);
                        echo "<td>".$Datum->format('d.m.Y')."</td>";
                        echo "<td align='center'>".$R["ura"]."</td>";
                        echo "<td>".$R["opis"]."</td>";
                        echo "<td>";
                        $SQL = "SELECT priimek,ime FROM tabucitelji WHERE idUcitelj IN (".$R["ucitelj"].")";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo $R1["priimek"]." ".$R1["ime"]."<br />";
                        }
                        echo "</td>";
                        echo "<td>".$R["opomba"]."</td>";
                        echo "<td align='center'><a href='dnevnik.php?idd=300&id=2&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                        echo "<td align='center'><a href='dnevnik.php?idd=300&id=4&ucenec=".$R["idUcenec"]."&zapis=".$R["oid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                
            }
        }

        $VRazred=0;
        $SQL = "SELECT idrazred FROM tabrazred WHERE iducenec=".$VUcenec." AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred=$R["idrazred"];
        }
        
        echo "<a href='izborrazreda.php?id=opombe'>Na izbor razreda</a><br />";
        echo "<a href='dnevnik.php?idd=300&id=&ucenec=".$VUcenec."'>Na vnos opomb učencu</a><br>";
        echo "<a href='dnevnik.php?idd=300'>Na izbor drugega učenca</a><br>";
        echo "<a href='dnevnik.php?idd=300&id=3&ucenec=".$VUcenec."'>Pokaži vse opombe učenca</a><br>";
        echo "<a href='dnevnik.php?idd=100&id=4&idrazred=".$VRazred."'>Tedenski dnevniški zapis za razred</a><br>";
        echo "<a href='dnevnik.php?idd=100'>Na vnos dnevnika</a><br>";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br>";
        break;
    case "400": //vnos dežurnih učencev
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
        $SQL = "SELECT * FROM TabRazDat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        if (isset($_POST["mesec"])){
            $VMesec = $_POST["mesec"];
        }else{
            if (isset($_GET["mesec"])){
                $VMesec=$_GET["mesec"];
            }else{
                $VMesec = $Danes->format('n');
            }
        }
        if ($VMesec < 9){
            $VLetoPregled=$VLeto+1;
        }else{
            $VLetoPregled=$VLeto;
        }

        $SQL = "SELECT datum,kat FROM tabpraznik WHERE leto=".$VLetoPregled." ORDER BY datum";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Datum=new DateTime(isDate($R["datum"]));
            $Praznik[$Indx][0]=new DateTime($Datum->format('Y-m-d'));
            $Praznik[$Indx][1]=$R["kat"];
            $Indx=$Indx+1;
        }
        $StPraznikov=$Indx-1;

        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        if ($Vid=="1"){
            $DovoljenVpis=true;
                
            if ($DovoljenVpis ){
                $SQL = "SELECT tabucenci.iducenec FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                if ($VRazred > 0 ){
                    $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = $SQL . "WHERE tabrazdat.leto=" . $VLeto ." AND tabrazdat.razred > 0";
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
                }
                $result = mysqli_query($link,$SQL);

                //'Izpis razrednih podatkov
                $PrvaStran=true;
                $CompRazred=0;
                while ($R = mysqli_fetch_array($result)){
                    for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                        $Datum=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                        switch ($Datum->Format('w')){
                            case 0:
                            case 6:
                                echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                                break;
                            default:
                                $VCheckPraznik=CheckPraznik($Datum);
                                switch ($VCheckPraznik){
                                    case 1:
                                    case 2:
                                    case 4:
                                        echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                                        break;
                                    default:
                                        $SQL1="SELECT tabdezurniuc.id FROM tabdezurniuc WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                        $result1 = mysqli_query($link,$SQL1);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                $SQL1=$SQL1;
                                            }else{
                                                $SQL1="DELETE FROM tabdezurniuc WHERE id=".$R1["id"];
                                                $result1 = mysqli_query($link,$SQL1);
                                            }
                                        }else{
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                $SQL1="INSERT INTO tabdezurniuc (idUcenec,leto,mesec,dan) VALUES (".$R["iducenec"].",".$VLetoPregled.",".$VMesec.",".$Indx.")";
                                                $result1 = mysqli_query($link,$SQL1);
                                            }
                                        }
                                }
                        }
                    }
                }
            }else{
                echo "<h2>Potekel je rok za vnos podatkov. Obrnite se na vodjo prehrane!</h2>";
            }
        }

        echo "<form  name='malica' method=post action='dnevnik.php'>";
        echo "<input type='hidden' name='idd' value='400'>";
        echo "<br><table border=1>";

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime, tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        if ($VRazred > 0 ){
            $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred;
            $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
        }else{
            $SQL = $SQL . "WHERE tabrazdat.leto=" . $VLeto; 
            $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
        }
        $result = mysqli_query($link,$SQL);

        //'Izpis razrednih podatkov
        $i1=1;
        $i2=0;
        $PrvaStran=true;
        $CompRazred=0;
        for ($Indx=0;$Indx <= 31;$Indx++){
            $StDezurstevDan[$Indx]=0;
        }
        while ($R = mysqli_fetch_array($result)){
            if ($CompRazred != $R["id"] ){
                if (!$PrvaStran ){
                    //'vsote po dnevih
                    echo "<tr bgcolor='lightgreen'>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>Skupaj</td>";
                    echo "<td>&nbsp;</td>";
                    $StDezurstev=0;
                    for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                        $Datum=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                        switch ($Datum->Format('w')){
                            case 0:
                            case 6:
                                echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                                break;
                            default:
                                $VCheckPraznik=CheckPraznik($Datum);
                                switch ($VCheckPraznik){
                                    case 1:
                                    case 2:
                                    case 4:
                                        echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                                        break;
                                    default:
                                        echo "<td align='right' width='20'>".$StDezurstevDan[$Indx]."</td>";
                                        $StDezurstev=$StDezurstev+$StDezurstevDan[$Indx];
                                }
                        }
                        
                    }
                    echo "<td align='center'>".$StDezurstev."</td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                if ($PrvaStran ){
                    echo "<h2>Dežurni učenci: ".$R["razred"].". ".$R["oznaka"].", ".$VMesec." - ".$VLeto."/".($VLeto+1)."</h2>";
                }else{
                    echo "<h2 class='break'>Dežurni učenci: ".$R["razred"].". ".$R["oznaka"].", ".$VMesec." - ".$VLeto."/".($VLeto+1)."</h2>";
                }
                $PrvaStran=false;
                echo "<br><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th width='180'>Ime</th>";
                echo "<th>Razred</th>";
                for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                    $Datum=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                    switch ($Datum->format('w')){
                        case 0:
                        case 6:
                            echo "<td width='20' bgcolor='lightsalmon'>".$Indx."</td>";
                            break;
                        default:
                            echo "<th width='20'>".$Indx."</th>";
                    }
                }
                echo "<th>Skupaj</th>";
                echo "</tr>";
                $CompRazred=$R["id"];
                for ($Indx=0;$Indx <= 31;$Indx++){
                    $StDezurstevDan[$Indx]=0;
                }
                $i1=1;
            }
            if ($i1 % 2 == 0 ){
                echo "<tr>";
            }else{
                echo "<tr bgcolor=#e5e5e5>";
            }
            echo "<td>".$i1."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
            echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
            $StDezurstev=0;
            for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                $Datum=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                switch ($Datum->Format('w')){
                    case 0:
                    case 6:
                        echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                        break;
                    default:
                        $VCheckPraznik=CheckPraznik($Datum);
                        switch ($VCheckPraznik){
                            case 1:
                            case 2:
                            case 4:
                                echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                                break;
                            default:
                                $SQL1="SELECT * FROM tabdezurniuc WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                $result1 = mysqli_query($link,$SQL1);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox' checked='checked'></td>";
                                    $StDezurstev=$StDezurstev+1;
                                    $StDezurstevDan[$Indx]=$StDezurstevDan[$Indx]+1;
                                }else{
                                    echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox'></td>";
                                }
                        }
                }
            }
            echo "<td align='center'>".$StDezurstev."</td>";
            echo "</tr>";
            $i1=$i1+1;
            $i2=$i2+1;
        }

        //'vsote po dnevih
        echo "<tr bgcolor='lightgreen'>";
        echo "<td>&nbsp;</td>";
        echo "<td>Skupaj</td>";
        echo "<td>&nbsp;</td>";
        $StDezurstev=0;
        for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
            $Datum=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
            switch ($Datum->Format('w')){
                case 0:
                case 6:
                    echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                    break;
                default:
                    $VCheckPraznik=CheckPraznik($Datum);
                    switch ($VCheckPraznik){
                        case 1:
                        case 2:
                        case 4:
                            echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                            break;
                        default:
                            echo "<td align='right' width='20'>".$StDezurstevDan[$Indx]."</td>";
                            $StDezurstev=$StDezurstev+$StDezurstevDan[$Indx];
                    }
            }
            
        }
        echo "<td align='center'>".$StDezurstev."</td>";
        echo "</tr>";

        echo "</table>";

        echo "<input id='StOtrok' type='hidden' name='stotrok' value='".($i2-1)."'>";
        echo "<input type='hidden' name='id' value='1'>";
        echo "<input type='hidden' name='razred' value='".$VRazred."'>";
        echo "<input type='hidden' name='mesec' value='".$VMesec."'>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form><br><br>";
        echo "<a href='dnevnik.php?idd=100&id=4&idrazred=".$VRazred."&dan=1&mesec=".$VMesec."&letod=".$VLetoPregled."'>Na tedenski pregled razrednega dnevnika</a><br />";
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        break;
}
?>

</body>
</html>
