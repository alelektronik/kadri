<?php
session_start();
setlocale (LC_ALL, 'sl_SI.UTF-8');

//true - vklop in false - izklop sporočil o napakah
$DEBUGGING = True;
$TRACECOUNT = 0;
 
if($DEBUGGING){
    error_reporting(E_ALL);
    ini_set('display_errors', True);
}else{
    //ini_set('display_errors', false);
    
    // Turn off all error reporting
    error_reporting(0);

    // Report simple running errors
    //error_reporting(E_ERROR | E_WARNING | E_PARSE);

    // Reporting E_NOTICE can be good too (to report uninitialized
    // variables or catch variable name misspellings ...)
    //error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

    // Report all errors except E_NOTICE
    // This is the default value set in php.ini
    //error_reporting(E_ALL ^ E_NOTICE);

    // Report all PHP errors (see changelog)
    //error_reporting(E_ALL);

    // Report all PHP errors
    //error_reporting(-1);

    // Same as error_reporting(E_ALL);
    //ini_set('error_reporting', E_ALL);
} 
function trace($message){
 
    global $DEBUGGING;
    global $TRACECOUNT;
    if($DEBUGGING)
    {
        echo '<hr />;'.$TRACECOUNT++.'<code>'.$message.'</code><hr />';
    }
}
 
function tarr($arr)
{
    global $DEBUGGING; 
    global $TRACECOUNT; 
    if($DEBUGGING) 
    { 
        echo '<hr />'.$TRACECOUNT++.'<code>'; 
        print_r($arr); 
        echo '</code><hr />'; 
    } 
} 
//----------sporočila o napakah

require("nastavitve.php");
/*
    //'0-izpiše DU v spisku rubrik, 1-ne izpiše (default=0)
    $izpisDU=0;	

    //'0-izpiše Jesenski in pomladni del, 1-ne izpiše jesenski in pomladni del (default=0)
    $IzpisSezon=0;	

    //0-izpiše podatke o porodniških le ob prvem vstopu, 1-stalno izpisuje podatke o porodniških (default=0)
    $IzpisPorodniske=0; 

    //v nekaterih primerih dodatek izpisa k paralelki (default="")
    $DodatekParalelki="";

    //1-vklop modula za pošiljanje delovnih opravil delovcem, 0-izklop modula  (default=1)
    $Opravila=1;

    //poštni strežnik (default="mail.siol.net")
    $MailServer="mail.siol.net";

    //false - izklopljeno pošiljanje sporočil na policijo, true - vklopljeno (default=false)
    $ObvestiloPolicije=false;

    //email policije za sprejemanje obvestil s šole (default="")
    $EmailPolicija="";

    //email, ki se kaže kot pošiljatelj, pri splošnih sporočilih delavcem (default="")
    $EmailRavnatelj="";

    //število dni tolerance za vpis doprinovo delavcev (default=0)
    $RazlikaDniVpis=0;

    //število dodatnih rubrik v tabdoprinos (default=22)
    $DodatnihRubrik=22;

    //število ur za izračun polne obveze učitelja (default=22)
    $ObremenitevUcitelj=22;

    //število ur za izračun polne obveze PB učitelja (default=25)
    $ObremenitevPB=25;

    //1-nov obračun, 0-star obračun pred letom 2006 (default=1) 
    $NacinObracunaDoprinosa=1;

    //1 - vklop modula za evidentiranje prisotnosti, 0 - izklop (default=1)
    $EvidencaPrisotnosti=1;

    //1 - vklop modula za evidenco prehrano, 0 - izklop (default=0) - ni modula v PHP, le v ASP
    $EvidencaPrehrane=0;

    //1 - izklop modula učencev, 0 - aplikacija z obdelavo učencev (default=0)
    $SamoKadri=0;

    //1 - vklop modula eDnevnik, 0 - izklop (default=1)
    $eDnevnik=1;

    //niz znakov za označevanje direktorijev "/" ali "\\"
    $FileSep="/";

    //0 - izključe modul za rezervacijo prostorov, 1 - vključen
    $RezervacijaProstorov = 1;

    //Zaščitna sredstva: 0 - običajen prikaz, 1 - za OŠ Bežigrad
    $ZascSre=0;

    //Število neobveznih izbirnih predmetov, ki jih učenci lahko izbirajo
    $StNeobveznihIzbirnih = 1;

    //število ur za obračun - po letih 2000+pozicija v polju
    $DelovniDan=array(8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8);
    //$DelovniDan=array(7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5, 7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5, 7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5);

    //kodni nabor za pretvorbo znakov. Uporablja se pri klicih mb_ funkcij za obdelavo nizov
    $encoding="UTF-8";

    //Če je baza z več šolami (podružnicami) -> 1, baza z eno šolo -> 0
    $VecSol=0;

    //Prikaz neizpolnjenih podatkov: 0 - ni prikaza, 1 - je prikaz
    $Semafor=1;
    $SemaforPrehrana=1;
    $SemaforRealizacija=1;

    //Upoštevanje Du: 0 - ne poračunava, 1 - poračunava  (default = 0)
    $ObracunajDu = 1;

    //podatki za dostop do baze podatkov
    $dbk_host = "127.0.0.1";
    $dbk_user = "kadri";
    $dbk_pass = "kadriSQL";
    $dbk_base = "osmp";
*/

//kodni nabor za pretvorbo znakov. Uporablja se pri klicih mb_ funkcij za obdelavo nizov
$encoding="UTF-8";

//1-nov obračun, 0-star obračun pred letom 2006 (default=1) 
$NacinObracunaDoprinosa=1;
    
//število dodatnih rubrik v tabdoprinos (default=22)
$DodatnihRubrik=22;

//niz znakov za označevanje direktorijev "/" ali "\\"
$FileSep="/";

//inicializacija podatkovne baze
$link=mysqli_connect($dbk_host, $dbk_user, $dbk_pass) or die(mysqli_error());
mysqli_select_db($link,$dbk_base) or die(mysqli_error());
//določitev kodne tabele
mysqli_query($link,"SET NAMES 'utf8' COLLATE 'utf8_slovenian_ci'");
/*
//inicializacija druge podatkovne baze (za združevanje podatkov)
$link1=mysqli_connect("127.0.0.1", "kadri", "kadriSQL") or die(mysqli_error());
mysqli_select_db($link1,"polica") or die(mysqli_error());
//določitev kodne tabele
mysqli_query($link1,"SET NAMES 'utf8' COLLATE 'utf8_slovenian_ci'");

//inicializacija druge podatkovne baze (za združevanje podatkov)
$link2=mysqli_connect("127.0.0.1", "kadri", "kadriSQL") or die(mysqli_error());
mysqli_select_db($link2,"ospp") or die(mysqli_error());
//določitev kodne tabele
mysqli_query($link2,"SET NAMES 'utf8' COLLATE 'utf8_slovenian_ci'");
*/

//inicializira podatek o trenutnem času
$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');

//zapiše v log-sledenje
if (isset($_SESSION["Uporabnik"])){
    $up=$_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $up=$_POST["Uporabnik"];
    }else{
        if (isset($_GET["uporabnik"])){
            $up=$_GET["uporabnik"];
        }else{
            $up="";
        }
    }
}
$p=serialize($_POST);
$g=serialize($_GET);

$SQL = "INSERT INTO tablog (user,stran,post,get,cas,ip) VALUES (";
$SQL = $SQL . "'".$up."'";
$SQL = $SQL . ",'".$_SERVER["SCRIPT_NAME"]."'";
$SQL = $SQL . ",'".$p."'";
$SQL = $SQL . ",'".$g."'";
$SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
$SQL = $SQL . ",'".$_SERVER["REMOTE_ADDR"]."'";
$SQL = $SQL .")";
$result = mysqli_query($link,$SQL);

//funkcija vrne true, če ima uporabnik dostopno pravico in false, če je nima
function CheckDostop($s,$u){
    global $link;
	$SQL = "SELECT TabDostop.*,tabucitelji.* FROM TabDostop ";
	$SQL = $SQL . "INNER JOIN tabucitelji ON TabDostop.idUcitelj=tabucitelji.idUcitelj ";
	$SQL = $SQL . "WHERE tabucitelji.uporabnik='".$u."'";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		if ($R[$s]){
			return true;
		}else{
			return false;
		}
	}else{
		return false;
	}
}

//funkcija preveri strukturo pordatkovnega niza znakov in ga predela na LLLL-MM-DD
function isDate($s) {
    $s=str_replace(" ","",$s);
    if (strlen($s) > 7){
        if (strpos($s,".") > 0) {
            $astr = explode(".",$s);
            if (count($astr) > 2){
                if (checkdate(intval(trim($astr[1])),intval(trim($astr[0])),intval(trim($astr[2])))){
                    return trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]);
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        else {
            if (strpos($s,"-") > 0) {
                $astr = explode("-",$s);
                if (count($astr) > 2){
                    $bstr = substr($astr[2],0,2);
                    if (checkdate(intval(trim($astr[1])),intval(trim($bstr)),intval(trim($astr[0])))){
                        return trim($astr[0])."-".trim($astr[1])."-".trim($bstr);
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
    }else{    
        return false;
    }
}

//funkcija pretvori število v tričrkovni dnevni niz
function Int2Dan($x){
    switch ($x){
        case 1:
            return "PON";
        case 2:
            return "TOR";
        case 3:
            return "SRE";
        case 4:
            return "ČET";
        case 5:
            return "PET";
        case 6:
            return "SOB";
        case 7:
        case 0:
            return "NED";
    }
}

//funkcija vrne podatek o letu, ki se uporablja: ga prebere iz prenesenih podatkov ali določi iz aktualnega časa
function PreberiLeto($l){
    global $Danes,$ActualMonth,$ActualYear;
    if (isset($_POST[$l])){
        $VLeto=$_POST[$l];
        if ($VLeto == "" ) {
            if (isset($_SESSION[$l])){
                $VLeto=$_SESSION[$l];
                if (($VLeto == "") or ($VLeto < 1000) ) {
                    if ($ActualMonth > 8 ) {
                        $VLeto = $ActualYear;
                    }else{
                        if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                            return $ActualYear;
                        }else{
                            return ($ActualYear-1);
                        }
                    }
                }    
            }
        }
    }else{
        if (isset($_GET[$l])){
            return $_GET[$l];
        }else{
            if (isset($_SESSION[$l])){
                $VLeto=$_SESSION[$l];
                if (($VLeto == "") or ($VLeto < 1000) ) {
                    if ($ActualMonth > 8 ) {
                        return $ActualYear;
                    }else{
                        if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                            return $ActualYear;
                        }else{
                            return ($ActualYear-1);
                        }
                    }
                }    
            }else{
                if ($ActualMonth > 8 ) {
                    return $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        return $ActualYear;
                    }else{
                        return ($ActualYear-1);
                    }
                }
            }    
        }
    }
    return $VLeto;
}
//' Funkcija za testiranje Nivoja Dostopa
function ND($x,$s){
    GLOBAL $SamoKadri;
    if (!is_numeric(strpos($s,$x))){
        return false;
    }else{
        if ($SamoKadri){
            if (!is_numeric(strpos($s,"K"))){
                return false;
            }else{
                return true;
            }
        }else{
            return true;
        }
    }
}
    
?>
