<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis učitelja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}

$SQL = "SELECT tabrazdat.* FROM TabRazred INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id WHERE tabrazdat.leto=".$VLeto." AND idUcitelj=".$UciteljComp;
$result = mysqli_query($link,$SQL);

if ($R = mysqli_fetch_array($result)){
	$VidRazred1=$R["razred"];
	$VidRazred=$R["id"];
	$VidParalelka=$R["oznaka"];
}else{
	$VidRazred1=1;
	$VidRazred=0;
	$VidParalelka="A";
}

echo "<form accept-charset='utf-8' name='rezultati' method='post' action='VnosRealizacije.php'>";
echo "<h2>Izberite razred za vnos realizacije</h2><br />";
echo "<table border=0>";
echo "<tr>";
echo "<td>";
echo "Šolsko leto: </td><td>".  $VLeto  . "/"  . ($VLeto+1) . "</td>";
echo "</tr>";
echo "<input name='vrstaos' type='hidden' value='9'>";

$SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
$result = mysqli_query($link,$SQL);

echo "<tr><td>Izberi razred</td><td><select name='razred' onchange='this.form.submit()'>";
while ($R = mysqli_fetch_array($result)){
    if ($VLevel > 1){
    	echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
    }else{
        if ($VidRazred == $R["id"]){
            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
        }
    }
}
echo "</select>";
echo "</td>";
echo "</tr>";
echo "</table><br />";
echo "<input name='submit1' type='button' value='Pošlji' onclick='this.form.submit()'>";
echo "</form>";
?>
</body>
</html>
