<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require("fpdf.php");

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace(chr(226).chr(128).chr(147),"\\'2d",$txt);
    return $txt;
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["idd"])){
    $VNacin = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VNacin=$_GET["idd"];
    }else{
        $VNacin = 0;
    }
}
switch ($VNacin){
    case "300";
    case "400";
    case "500";
    case "510";
        break;
    default:
        $n=$VLevel;
/*
        include('menu_func.inc');
        include ('menu.inc');
*/
}
if (isset($_POST["ucenec"])){
    $ucenec = $_POST["ucenec"];
}else{
    if (isset($_GET["ucenec"])){
        $ucenec=$_GET["ucenec"];
    }else{
        $ucenec = 0;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}

switch ($VNacin){
    case "100":
        break;
    case "200":  //dodaj vzgojni ukrep
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
            echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
            echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
            echo "<script type=\"text/javascript\">";
            echo "    window.onload = function(){";
            echo "        var Danes = new Date();";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat_1\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat_2\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "    };";
            echo "</script>";
        echo "<title>Vzgojni ukrepi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>Izpis učenca:</h2>";
            $Datum=new DateTime(isDate($R["DatRoj"]));
            echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b><br />";
            echo "Naslov:<b> " . $R["Naslov"] . ", " . $R["Posta"] . " " . $R["Kraj"] . "</b><br />";
            echo "Oče: <b>" . $R["oce"] . "</b><br />";
            echo "Mati:<b> " . $R["mati"] . "</b><br />";
        }

        $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis FROM tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep WHERE tabvzgukrepi.IdUcenec=" .$ucenec . " ORDER BY tabvzgukrepi.leto DESC";

        //    echo $SQL . "<br />"
        $result = mysqli_query($link,$SQL);
        echo "<br />Vzgojni ukrepi: ";
        echo "<br /><a href='izborucenca.php?id=3'>Dodaj vzgojni ukrep</a>";
        echo "<br /><table border=1>";
        echo "<th>Leto</th><th>Ukrep</th><th>Datum</th><th>Podlaga</th><th>Obrazložitev</th><th>Evid. št.</th>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td><td>".$R["opis"]."</td><td>".$R["DatIzreka"]."</td>";
            echo "<td>".$R["podlaga"]."</td>";
            echo "<td>".$R["obrazlozitev"]."</td>";
            echo "<td>".$R["stdokumenta"]."</td>";
            echo "</tr>";
            $Indx = $Indx+1;
        } 
        echo "</table><br />";

        $SQL = "SELECT * FROM tabopomini WHERE IdUkrep < 7";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $VOpomini[$Indx][0] = $R["IdUkrep"];
            $VOpomini[$Indx][1] = $R["Opis"];
            $Indx=$Indx+1;
        }


        echo "<form  name='UcenecOpomin' method=post action='izborucenca.php'>";
        echo "<input name='idd' type='hidden' value='250'>";
        echo "<input name='ucenec' type='hidden' value='".$ucenec."'>";
        echo "<table border='1'>";
        echo "<tr><td>Leto</td><td><select name='solskoleto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select></td></tr>";
        echo "<tr><td>Ukrep</td><td><select name='ukrep'>";
        for ($Indx1=0;$Indx1 <= $Indx-1;$Indx1++){
            echo "<option value=" . $VOpomini[$Indx1][0] . ">" . $VOpomini[$Indx1][1] .  "</option>";
        }
        echo "</select></td></tr>";
        echo "<tr><td>Datum izreka</td><td><input name='datizreka' type='text' size='10' id='dat_1'></td></tr>";
        echo "<tr><td>Podlaga (alineja, odstavek)</td><td>Na podlagi vzgojnega načrta šole sprejetega dne <input name='podlaga' type='text' size='10' id='dat_2'> na seji Sveta šole</td></tr>";
        echo "<tr><td>Obrazložitev</td><td><textarea name='obrazlozitev' rows='5' cols='60'>";
        echo "Datum kršitve: \n\n";
        echo "Opis kršitve: \n\n";
        echo "Datum pisnega predloga razredniku: \n\n";
        echo "Datum razgovora razrednika z učencem in starši: \n\n";
        echo "Datum pisnega predloga učiteljskemu zboru: \n\n";
        echo "Datum izreka opomina učiteljskega zbora: \n\n";
        echo "Ukrepi šole pred izrekom opomina: \n\n";
        echo "</textarea></td></tr>";
        echo "<tr><td>Evid. št.</td><td><input name='stdokumenta' type='text' size='8'></td></tr>";
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";

        echo "</body>";
        echo "</html>";
        break;
    case "250": //vpis vzgojnega ukrepa
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vzgojni ukrepi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $VLeto1=$VLeto;
        $VUkrep=$_POST["ukrep"];
        $VDatIzreka=$_POST["datizreka"];
        $VPodlaga=$_POST["podlaga"];
        $VObrazlozitev=$_POST["obrazlozitev"];
        $VStDokumenta=$_POST["stdokumenta"];

        //Izpis osebnih podatkov

        $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
        $result = mysqli_query($link,$SQL);

         if ($R = mysqli_fetch_array($result)){
            echo "<h2>Vpis vzgojnega ukrepa za učenca:</h2>";
            $Datum=new DateTime(isDate($R["DatRoj"]));
            echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $Datum->format('d.m.Y') . "</b>, Spol: <b>" . $R["Spol"] . "</b><br />";
            echo "Naslov:<b> " . $R["Naslov"] . ", " . $R["Posta"] . " " . $R["Kraj"] . "</b><br />";
            echo "Oče: <b>" . $R["oce"] . "</b><br />";
            echo "Mati:<b> " . $R["mati"] . "</b><br />";
        }

        $SQL = "SELECT tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime,tabrazdat.* FROM ";
        $SQL = $SQL . "((tabvzgojitelji INNER JOIN tabrazred ON tabvzgojitelji.IdUcitelj = tabrazred.IdVzgojitelj)  ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabucitelji.IdUcitelj = tabrazred.IdUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE iducenec=" . $ucenec . " AND tabrazdat.leto=" . $VLeto;
        $result = mysqli_query($link,$SQL);

        //Izpis predmetnih podatkov

        $SQL = "INSERT INTO tabvzgukrepi (Leto,IdUcenec,IdUkrep,DatIzreka,Datum,Vpisal,podlaga,obrazlozitev,stdokumenta";
        $SQL = $SQL . ") values (" . $VLeto1 . "," . $ucenec .",". $VUkrep . ",'".$VDatIzreka."','".$Danes->format('d.m.Y')."','".$VUporabnik."','".$VPodlaga."','".$VObrazlozitev."','".$VStDokumenta."'";
        $SQL = $SQL . ")";
        $result = mysqli_query($link,$SQL);

        $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis FROM tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep WHERE tabvzgukrepi.IdUcenec=" .$ucenec . " ORDER BY tabvzgukrepi.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br />Vzgojni ukrepi: ";
        echo "<br /><a href='izborucenca.php?id=3'>Dodaj vzgojni ukrep</a>";
        echo "<br /><table border=1>";
        echo "<th>Leto</th><th>Ukrep</th><th>Datum</th><th>Podlaga</th><th>Obrazložitev</th><th>Evid. št.</th><th>Briši</th><th>Izpis</th>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td><td>".$R["opis"]."</td><td>".$R["DatIzreka"]."</td><td>".$R["podlaga"]."</td><td>".$R["obrazlozitev"]."</td><td>".$R["stdokumenta"]."</td><td><a href='izborucenca.php?idd=260&id=" . $R["Id"] . "'>Briši</a></td>";
            echo "<td><a href='izborucenca.php?idd=270&id=" . $R["Id"] . "'>Izpiši obrazec</a></td></tr>";
            $Indx = $Indx+1;
        } 
        echo "</table><br /><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "260": //briši vzg ukrep
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vzgojni ukrepi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $SQL = "SELECT iducenec FROM tabvzgukrepi WHERE id=".$Vid;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
             $ucenec=$R["iducenec"];
        }

        $SQL = "DELETE FROM tabvzgukrepi WHERE id=".$Vid;
        if (!($result = mysqli_query($link,$SQL))){
            die("Napaka pri brisanju vzg. uktrepa!<br />$SQL<br />");
        }
        
        if ($ucenec == 0){
            $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis,tabucenci.priimek,tabucenci.ime FROM (tabopomini ";
            $SQL .= "INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep) ";
            $SQL .= "INNER JOIN tabucenci ON tabvzgukrepi.iducenec=tabucenci.iducenec ";
            $SQL .= "WHERE tabvzgukrepi.leto=" .$VLeto;
            $SQL .= " ORDER BY tabvzgukrepi.leto DESC";
        }else{
            $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis,tabucenci.priimek,tabucenci.ime FROM (tabopomini ";
            $SQL .= "INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep) ";
            $SQL .= "INNER JOIN tabucenci ON tabvzgukrepi.iducenec=tabucenci.iducenec ";
            $SQL .= "WHERE tabvzgukrepi.IdUcenec=" .$ucenec;
            $SQL .= " ORDER BY tabvzgukrepi.leto DESC";
        }
        $result = mysqli_query($link,$SQL);

        echo "<br />Vzgojni ukrepi: ";
        echo "<br /><a href='izborucenca.php?id=3'>Dodaj vzgojni ukrep</a>";
        echo "<br /><table border=1>";
        echo "<th>Leto</th><th>Učenec</th><th>Ukrep</th><th>Datum</th><th>Podlaga</th><th>Obrazložitev</th><th>Evid. št.</th><th>Briši</th><th>Izpis</th>";
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
            echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
            echo "<td>".$R["opis"]."</td>";
            echo "<td>".$R["DatIzreka"]."</td>";
            echo "<td>".$R["podlaga"]."</td>";
            echo "<td>".$R["obrazlozitev"]."</td>";
            echo "<td>".$R["stdokumenta"]."</td>";
            echo "<td><a href='izborucenca.php?idd=260&id=" . $R["Id"] . "'>Briši</a></td>";
            echo "<td><a href='izborucenca.php?idd=270&id=" . $R["Id"] . "'>Izpiši obrazec</a></td></tr>";
            $Indx = $Indx+1;
        } 
        echo "</table><br /><br />";
        echo "<a href='izborucenca.php?idd=265'>Vsi ukrepi</a><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "265": //izpiše vse ukrepe v šolskem letu
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vzgojni ukrepi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis,tabucenci.priimek,tabucenci.ime FROM (tabopomini ";
        $SQL .= "INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep) ";
        $SQL .= "INNER JOIN tabucenci ON tabvzgukrepi.iducenec=tabucenci.iducenec ";
        $SQL .= "WHERE tabvzgukrepi.leto=" .$VLeto;
        $SQL .= " ORDER BY tabvzgukrepi.leto DESC";
        $result = mysqli_query($link,$SQL);

        echo "<br />Vzgojni ukrepi: ";
        echo "<br /><a href='izborucenca.php?id=3'>Dodaj vzgojni ukrep</a>";
        echo "<br /><table border=1>";
        if ($VLevel > 2){
            echo "<th>Leto</th><th>Učenec</th><th>Ukrep</th><th>Datum</th><th>Podlaga</th><th>Obrazložitev</th><th>Evid. št.</th><th>Briši</th><th>Izpis</th>";
        }else{
            echo "<th>Leto</th><th>Učenec</th><th>Ukrep</th><th>Datum</th><th>Podlaga</th><th>Obrazložitev</th><th>Evid. št.</th><th>Izpis</th>";
        }
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
            echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
            echo "<td>".$R["opis"]."</td>";
            echo "<td>".$R["DatIzreka"]."</td>";
            echo "<td>".$R["podlaga"]."</td>";
            echo "<td>".$R["obrazlozitev"]."</td>";
            echo "<td>".$R["stdokumenta"]."</td>";
            if ($VLevel > 2){
                echo "<td><a href='izborucenca.php?idd=260&id=" . $R["Id"] . "'>Briši</a></td>";
            }
            echo "<td><a href='izborucenca.php?idd=270&id=" . $R["Id"] . "'>Izpiši obrazec</a></td></tr>";
            $Indx = $Indx+1;
        } 
        echo "</table><br /><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "270": //vzgojni ukrep RTF
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vzgojni ukrepi";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        $VFile="vzgojniukrep.rtf";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;
        
        if ($VecSol > 0){
            $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabucenci.spol,tabrazred.razred,tabrazred.paralelka FROM " ;
            $SQL = $SQL . "((tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabvzgukrepi.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabvzgukrepi.idUcenec=tabrazred.idUcenec ";
            $SQL = $SQL . "WHERE tabvzgukrepi.Id=" .$Vid . " ORDER BY tabrazred.leto DESC";

            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $ucenec=$R["IdUcenec"];
            }else{
                $ucenec=0;
            }
            $SQL = "SELECT tabrazred.idrazred,tabrazdat.idsola FROM tabrazdat INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VIdSola=$R["idsola"];
            }else{
                $VIdSola=1;
            }

            $SQL = "SELECT * FROM tabsola WHERE id=".$VIdSola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        fwrite($fh,"{\\rtf1\\adeflang1025\\ansi\\ansicpg1250\\uc1\\adeff0\\deff0\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060\\themelang1060\\themelangfe0\\themelangcs0{\\fonttbl{\\f0\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
        fwrite($fh,"{\\f34\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria Math;}{\\f38\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604030504040204}Tahoma;}"."\n");
        fwrite($fh,"{\\flomajor\\f31500\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fdbmajor\\f31501\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
        fwrite($fh,"{\\fhimajor\\f31502\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria;}{\\fbimajor\\f31503\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
        fwrite($fh,"{\\flominor\\f31504\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fdbminor\\f31505\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
        fwrite($fh,"{\\fhiminor\\f31506\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}{\\fbiminor\\f31507\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f41\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
        fwrite($fh,"{\\f40\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\f42\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f43\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f44\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
        fwrite($fh,"{\\f45\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\f46\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f47\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f381\\fbidi \\froman\\fcharset0\\fprq2 Cambria Math;}"."\n");
        fwrite($fh,"{\\f380\\fbidi \\froman\\fcharset204\\fprq2 Cambria Math Cyr;}{\\f382\\fbidi \\froman\\fcharset161\\fprq2 Cambria Math Greek;}{\\f383\\fbidi \\froman\\fcharset162\\fprq2 Cambria Math Tur;}{\\f386\\fbidi \\froman\\fcharset186\\fprq2 Cambria Math Baltic;}"."\n");
        fwrite($fh,"{\\f387\\fbidi \\froman\\fcharset163\\fprq2 Cambria Math (Vietnamese);}{\\f421\\fbidi \\fswiss\\fcharset0\\fprq2 Tahoma;}{\\f420\\fbidi \\fswiss\\fcharset204\\fprq2 Tahoma Cyr;}{\\f422\\fbidi \\fswiss\\fcharset161\\fprq2 Tahoma Greek;}"."\n");
        fwrite($fh,"{\\f423\\fbidi \\fswiss\\fcharset162\\fprq2 Tahoma Tur;}{\\f424\\fbidi \\fswiss\\fcharset177\\fprq2 Tahoma (Hebrew);}{\\f425\\fbidi \\fswiss\\fcharset178\\fprq2 Tahoma (Arabic);}{\\f426\\fbidi \\fswiss\\fcharset186\\fprq2 Tahoma Baltic;}"."\n");
        fwrite($fh,"{\\f427\\fbidi \\fswiss\\fcharset163\\fprq2 Tahoma (Vietnamese);}{\\f428\\fbidi \\fswiss\\fcharset222\\fprq2 Tahoma (Thai);}{\\flomajor\\f31510\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flomajor\\f31509\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
        fwrite($fh,"{\\flomajor\\f31511\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\flomajor\\f31512\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flomajor\\f31513\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
        fwrite($fh,"{\\flomajor\\f31514\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\flomajor\\f31515\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flomajor\\f31516\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}"."\n");
        fwrite($fh,"{\\fdbmajor\\f31520\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fdbmajor\\f31519\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbmajor\\f31521\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}"."\n");
        fwrite($fh,"{\\fdbmajor\\f31522\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fdbmajor\\f31523\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbmajor\\f31524\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
        fwrite($fh,"{\\fdbmajor\\f31525\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fdbmajor\\f31526\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhimajor\\f31530\\fbidi \\froman\\fcharset0\\fprq2 Cambria;}"."\n");
        fwrite($fh,"{\\fhimajor\\f31529\\fbidi \\froman\\fcharset204\\fprq2 Cambria Cyr;}{\\fhimajor\\f31531\\fbidi \\froman\\fcharset161\\fprq2 Cambria Greek;}{\\fhimajor\\f31532\\fbidi \\froman\\fcharset162\\fprq2 Cambria Tur;}"."\n");
        fwrite($fh,"{\\fhimajor\\f31535\\fbidi \\froman\\fcharset186\\fprq2 Cambria Baltic;}{\\fhimajor\\f31536\\fbidi \\froman\\fcharset163\\fprq2 Cambria (Vietnamese);}{\\fbimajor\\f31540\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
        fwrite($fh,"{\\fbimajor\\f31539\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fbimajor\\f31541\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbimajor\\f31542\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
        fwrite($fh,"{\\fbimajor\\f31543\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fbimajor\\f31544\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbimajor\\f31545\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}"."\n");
        fwrite($fh,"{\\fbimajor\\f31546\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\flominor\\f31550\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flominor\\f31549\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
        fwrite($fh,"{\\flominor\\f31551\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\flominor\\f31552\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flominor\\f31553\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}"."\n");
        fwrite($fh,"{\\flominor\\f31554\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\flominor\\f31555\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flominor\\f31556\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}"."\n");
        fwrite($fh,"{\\fdbminor\\f31560\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fdbminor\\f31559\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbminor\\f31561\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}"."\n");
        fwrite($fh,"{\\fdbminor\\f31562\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fdbminor\\f31563\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbminor\\f31564\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
        fwrite($fh,"{\\fdbminor\\f31565\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fdbminor\\f31566\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhiminor\\f31570\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}"."\n");
        fwrite($fh,"{\\fhiminor\\f31569\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}{\\fhiminor\\f31571\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\fhiminor\\f31572\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}"."\n");
        fwrite($fh,"{\\fhiminor\\f31575\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}{\\fhiminor\\f31576\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\fbiminor\\f31580\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}"."\n");
        fwrite($fh,"{\\fbiminor\\f31579\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fbiminor\\f31581\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbiminor\\f31582\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}"."\n");
        fwrite($fh,"{\\fbiminor\\f31583\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fbiminor\\f31584\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbiminor\\f31585\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}"."\n");
        fwrite($fh,"{\\fbiminor\\f31586\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}}{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;"."\n");
        fwrite($fh,"\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red255\\green255\\blue255;}{\\*\\defchp }"."\n");
        fwrite($fh,"{\\*\\defpap \\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 }\\noqfpromote {\\stylesheet{\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs24\\alang1025 \\ltrch\\fcs0 "."\n");
        fwrite($fh,"\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 \\sqformat \\spriority0 Normal;}{\\*\\cs10 \\additive \\ssemihidden \\spriority1 Default Paragraph Font;}{\\*"."\n");
        fwrite($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblind0\\tblindtype3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
        fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs20\\alang1025 \\ltrch\\fcs0 \\fs20\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext11 \\ssemihidden \\sunhideused \\sqformat Normal Table;}{\\*"."\n");
        fwrite($fh,"\\ts15\\tsrowd\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
        fwrite($fh,"\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblind0\\tblindtype3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
        fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af0\\afs20\\alang1025 \\ltrch\\fcs0 \\fs20\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon11 \\snext15 \\spriority59 \\styrsid4211230 Table Grid;}{"."\n");
        fwrite($fh,"\\s16\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af38\\afs16\\alang1025 \\ltrch\\fcs0 \\f38\\fs16\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext16 \\slink17 \\ssemihidden \\styrsid6496122 "."\n");
        fwrite($fh,"Balloon Text;}{\\*\\cs17 \\additive \\rtlch\\fcs1 \\af38\\afs16 \\ltrch\\fcs0 \\f38\\fs16 \\sbasedon10 \\slink16 \\slocked \\ssemihidden Besedilo obla\\'e8ka Znak;}}{\\*\\listtable{\\list\\listtemplateid-689823442\\listhybrid{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0"."\n");
        fwrite($fh,"\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'00.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fbias0\\hres0\\chhres0 \\fi-360\\li720\\jclisttab\\tx720\\lin720 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0"."\n");
        fwrite($fh,"\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li1440\\jclisttab\\tx1440\\lin1440 }{\\listlevel\\levelnfc2"."\n");
        fwrite($fh,"\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'02.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li2160\\jclisttab\\tx2160\\lin2160 }"."\n");
        fwrite($fh,"{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li2880"."\n");
        fwrite($fh,"\\jclisttab\\tx2880\\lin2880 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 "."\n");
        fwrite($fh,"\\fi-360\\li3600\\jclisttab\\tx3600\\lin3600 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 "."\n");
        fwrite($fh,"\\hres0\\chhres0 \\fi-180\\li4320\\jclisttab\\tx4320\\lin4320 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 "."\n");
        fwrite($fh,"\\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5040\\jclisttab\\tx5040\\lin5040 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'07.;}{\\levelnumbers\\'01;}"."\n");
        fwrite($fh,"\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5760\\jclisttab\\tx5760\\lin5760 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187"."\n");
        fwrite($fh,"\\'02\\'08.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li6480\\jclisttab\\tx6480\\lin6480 }{\\listname ;}\\listid252206415}{\\list\\listtemplateid250495320\\listhybrid{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0"."\n");
        fwrite($fh,"\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'00.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fbias0\\hres0\\chhres0 \\fi-360\\li720\\jclisttab\\tx720\\lin720 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0"."\n");
        fwrite($fh,"\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li1440\\jclisttab\\tx1440\\lin1440 }{\\listlevel\\levelnfc2\\levelnfcn2"."\n");
        fwrite($fh,"\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'02.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li2160\\jclisttab\\tx2160\\lin2160 }{\\listlevel"."\n");
        fwrite($fh,"\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li2880\\jclisttab\\tx2880\\lin2880 "."\n");
        fwrite($fh,"}{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li3600"."\n");
        fwrite($fh,"\\jclisttab\\tx3600\\lin3600 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 "."\n");
        fwrite($fh,"\\fi-180\\li4320\\jclisttab\\tx4320\\lin4320 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 "."\n");
        fwrite($fh,"\\hres0\\chhres0 \\fi-360\\li5040\\jclisttab\\tx5040\\lin5040 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'07.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 "."\n");
        fwrite($fh,"\\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5760\\jclisttab\\tx5760\\lin5760 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'08.;}{\\levelnumbers\\'01;}"."\n");
        fwrite($fh,"\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li6480\\jclisttab\\tx6480\\lin6480 }{\\listname ;}\\listid631251639}{\\list\\listtemplateid250495320{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0"."\n");
        fwrite($fh,"{\\leveltext\\'02\\'00.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fbias0\\hres0\\chhres0 \\fi-360\\li720\\jclisttab\\tx720\\lin720 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext"."\n");
        fwrite($fh,"\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li1440\\jclisttab\\tx1440\\lin1440 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'02.;}{\\levelnumbers"."\n");
        fwrite($fh,"\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li2160\\jclisttab\\tx2160\\lin2160 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 "."\n");
        fwrite($fh,"\\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li2880\\jclisttab\\tx2880\\lin2880 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 "."\n");
        fwrite($fh,"\\hres0\\chhres0 \\fi-360\\li3600\\jclisttab\\tx3600\\lin3600 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 "."\n");
        fwrite($fh,"\\fi-180\\li4320\\jclisttab\\tx4320\\lin4320 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5040"."\n");
        fwrite($fh,"\\jclisttab\\tx5040\\lin5040 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'07.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5760"."\n");
        fwrite($fh,"\\jclisttab\\tx5760\\lin5760 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'02\\'08.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li6480"."\n");
        fwrite($fh,"\\jclisttab\\tx6480\\lin6480 }{\\listname ;}\\listid1536889127}{\\list\\listtemplateid2014887358\\listhybrid{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175"."\n");
        fwrite($fh,"\\'02\\'00.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\fbias0\\hres0\\chhres0 \\fi-360\\li720\\jclisttab\\tx720\\lin720 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext"."\n");
        fwrite($fh,"\\leveltemplateid69468185\\'02\\'01.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li1440\\jclisttab\\tx1440\\lin1440 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0"."\n");
        fwrite($fh,"\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'02.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li2160\\jclisttab\\tx2160\\lin2160 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative"."\n");
        fwrite($fh,"\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'03.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li2880\\jclisttab\\tx2880\\lin2880 }{\\listlevel\\levelnfc4\\levelnfcn4\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1"."\n");
        fwrite($fh,"\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'04.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li3600\\jclisttab\\tx3600\\lin3600 }{\\listlevel\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0"."\n");
        fwrite($fh,"\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'05.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li4320\\jclisttab\\tx4320\\lin4320 }{\\listlevel\\levelnfc0\\levelnfcn0\\leveljc0\\leveljcn0"."\n");
        fwrite($fh,"\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468175\\'02\\'06.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5040\\jclisttab\\tx5040\\lin5040 }{\\listlevel\\levelnfc4\\levelnfcn4"."\n");
        fwrite($fh,"\\leveljc0\\leveljcn0\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468185\\'02\\'07.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-360\\li5760\\jclisttab\\tx5760\\lin5760 }{\\listlevel"."\n");
        fwrite($fh,"\\levelnfc2\\levelnfcn2\\leveljc2\\leveljcn2\\levelfollow0\\levelstartat1\\lvltentative\\levelspace0\\levelindent0{\\leveltext\\leveltemplateid69468187\\'02\\'08.;}{\\levelnumbers\\'01;}\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\hres0\\chhres0 \\fi-180\\li6480\\jclisttab\\tx6480\\lin6480 "."\n");
        fwrite($fh,"}{\\listname ;}\\listid1662730124}}{\\*\\listoverridetable{\\listoverride\\listid252206415\\listoverridecount0\\ls1}{\\listoverride\\listid631251639\\listoverridecount0\\ls2}{\\listoverride\\listid1536889127\\listoverridecount0\\ls3}{\\listoverride\\listid1662730124"."\n");
        fwrite($fh,"\\listoverridecount0\\ls4}}{\\*\\rsidtbl \\rsid18501\\rsid145216\\rsid215517\\rsid218808\\rsid347280\\rsid466970\\rsid552571\\rsid722834\\rsid790995\\rsid869432\\rsid870283\\rsid927542\\rsid928798\\rsid945992\\rsid1187874\\rsid1267704\\rsid1464920\\rsid1473633\\rsid1770202"."\n");
        fwrite($fh,"\\rsid1837944\\rsid1842768\\rsid2046224\\rsid2318277\\rsid2325485\\rsid2510170\\rsid2561726\\rsid2623941\\rsid2624804\\rsid2640837\\rsid2642787\\rsid2695267\\rsid2713293\\rsid2765530\\rsid3157333\\rsid3171088\\rsid3212426\\rsid3287235\\rsid3493202\\rsid3680990\\rsid3701683"."\n");
        fwrite($fh,"\\rsid3751456\\rsid3752700\\rsid3761096\\rsid3812243\\rsid3870297\\rsid3961446\\rsid4020728\\rsid4130182\\rsid4201430\\rsid4210645\\rsid4211230\\rsid4479054\\rsid4479430\\rsid4532695\\rsid4591002\\rsid4729016\\rsid4857187\\rsid5141491\\rsid5142716\\rsid5509292\\rsid5838466"."\n");
        fwrite($fh,"\\rsid5920246\\rsid5929644\\rsid5987532\\rsid6029968\\rsid6166517\\rsid6181522\\rsid6299067\\rsid6304907\\rsid6425318\\rsid6496122\\rsid6500690\\rsid6564589\\rsid6701484\\rsid6781535\\rsid6910514\\rsid7435149\\rsid7670045\\rsid7887643\\rsid7945661\\rsid7950525\\rsid7961914"."\n");
        fwrite($fh,"\\rsid8153546\\rsid8192345\\rsid8213661\\rsid8391456\\rsid8410809\\rsid8471214\\rsid8585941\\rsid8615408\\rsid8617916\\rsid8670744\\rsid8718720\\rsid8730381\\rsid8799160\\rsid8879600\\rsid8937108\\rsid8981408\\rsid8982874\\rsid9122069\\rsid9136958\\rsid9177327\\rsid9335683"."\n");
        fwrite($fh,"\\rsid9392235\\rsid9392961\\rsid9596805\\rsid9641725\\rsid9715989\\rsid9769709\\rsid9779769\\rsid9924162\\rsid10312888\\rsid10558684\\rsid10638245\\rsid10703264\\rsid10946282\\rsid11087098\\rsid11100413\\rsid11171208\\rsid11171620\\rsid11219509\\rsid11238712\\rsid11285755"."\n");
        fwrite($fh,"\\rsid11292182\\rsid11299215\\rsid11487725\\rsid11561681\\rsid11627675\\rsid11742996\\rsid11996209\\rsid12263815\\rsid12543018\\rsid12863049\\rsid12931565\\rsid13052580\\rsid13266413\\rsid13312491\\rsid13325167\\rsid13376754\\rsid13567107\\rsid13645961\\rsid13900788"."\n");
        fwrite($fh,"\\rsid14090872\\rsid14232828\\rsid14357171\\rsid14506790\\rsid14695690\\rsid14755174\\rsid14757754\\rsid14759213\\rsid15140162\\rsid15284896\\rsid15540495\\rsid15605018\\rsid15612821\\rsid15624611\\rsid15666118\\rsid15670384\\rsid15690713\\rsid15733581\\rsid15760597"."\n");
        fwrite($fh,"\\rsid16000496\\rsid16537345}{\\mmathPr\\mmathFont34\\mbrkBin0\\mbrkBinSub0\\msmallFrac0\\mdispDef1\\mlMargin0\\mrMargin0\\mdefJc1\\mwrapIndent1440\\mintLim0\\mnaryLim1}{\\info{\\title OSNOVNA \\'8aOLA}{\\author MGacesa}{\\operator }"."\n");
        fwrite($fh,"{\\creatim\\yr2010\\mo6\\dy6\\hr10\\min55}{\\revtim\\yr2010\\mo6\\dy6\\hr10\\min55}{\\printim\\yr2009\\mo8\\dy7\\hr11\\min39}{\\version2}{\\edmins6}{\\nofpages1}{\\nofwords234}{\\nofchars1610}{\\*\\company Ministrstvo za \\'9aolstvo in \\'9aport}{\\nofcharsws1841}{\\vern32859}}"."\n");
        fwrite($fh,"{\\*\\xmlnstbl {\\xmlns1 http://schemas.microsoft.com/office/word/2003/wordml}}\\paperw11906\\paperh16838\\margl1021\\margr1021\\margt737\\margb680\\gutter0\\ltrsect "."\n");
        fwrite($fh,"\\deftab708\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\trackmoves0\\trackformatting1\\donotembedsysfont1\\relyonvml0\\donotembedlingdata0\\grfdocevents0\\validatexml1\\showplaceholdtext0\\ignoremixedcontent0\\saveinvalidxml0"."\n");
        fwrite($fh,"\\showxmlerrors1\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dgmargin\\dghspace180\\dgvspace180\\dghorigin1021\\dgvorigin737\\dghshow1\\dgvshow1"."\n");
        fwrite($fh,"\\jexpand\\viewkind1\\viewscale110\\pgbrdrhead\\pgbrdrfoot\\splytwnine\\ftnlytwnine\\htmautsp\\nolnhtadjtbl\\useltbaln\\alntblind\\lytcalctblwd\\lyttblrtgr\\lnbrkrule\\nobrkwrptbl\\snaptogridincell\\allowfieldendsel\\wrppunct\\asianbrkrule\\rsidroot9779769\\utinl \\fet0"."\n");
        fwrite($fh,"{\\*\\wgrffmtfilter 013f}\\ilfomacatclnup0\\ltrpar \\sectd \\ltrsect\\linex0\\headery709\\footery709\\colsx708\\endnhere\\sectlinegrid360\\sectdefaultcl\\sectrsid7670045\\sftnbj {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2"."\n");
        fwrite($fh,"\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6"."\n");
        fwrite($fh,"\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang "."\n");
        fwrite($fh,"{\\pntxtb (}{\\pntxta )}}\\pard\\plain \\ltrpar\\ql \\li0\\ri566\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\itap0\\pararsid927542 \\rtlch\\fcs1 \\af0\\afs24\\alang1025 \\ltrch\\fcs0 \\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {"."\n");
        fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid927542\\charrsid3761096 "."\n");
        fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
        fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 "."\n");
        fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\pard \\ltrpar\\ql \\li0\\ri566\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\pararsid927542"."\n");

        //0-idUcenec, 1-Priimek in ime, 2-razred, 3-datum rojstva

        $StUcencev=1;

        $SQL = "SELECT tabvzgukrepi.*, tabopomini.opis,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabucenci.spol,tabrazred.razred,tabrazred.paralelka FROM " ;
        $SQL = $SQL . "((tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabvzgukrepi.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabvzgukrepi.idUcenec=tabrazred.idUcenec ";
        $SQL = $SQL . "WHERE tabvzgukrepi.Id=" .$Vid . " ORDER BY tabrazred.leto DESC";

        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $Ucenci[0]=$R["IdUcenec"];
            $Ucenci[1]=$R["ime"]." ".$R["priimek"];
            $Ucenci[2]=$R["razred"].". ".$R["paralelka"];
            $Ucenci[3]=$R["podlaga"];
            $Ucenci[4]=$R["obrazlozitev"];
            
            $PosStart=mb_strpos($Ucenci[4],"Datum kršitve: ",0,$encoding)+mb_strlen("Datum kršitve: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Opis kršitve:",0,$encoding);
            $DatumKrsitve=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Datum razgovora razrednika z učencem in starši: ",0,$encoding)+mb_strlen("Datum razgovora razrednika z učencem in starši: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Datum pisnega predloga učiteljskemu zboru:",0,$encoding);
            $DatumRazgovora=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Datum pisnega predloga razredniku: ",0,$encoding)+mb_strlen("Datum pisnega predloga razredniku: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Datum razgovora razrednika z učencem in starši:",0,$encoding);
            $DatumPredlogaRazredniku=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Datum pisnega predloga učiteljskemu zboru: ",0,$encoding)+mb_strlen("Datum pisnega predloga učiteljskemu zboru: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Datum izreka opomina učiteljskega zbora: ",0,$encoding);
            $DatumPredlogaZboru=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Datum izreka opomina učiteljskega zbora: ",0,$encoding)+mb_strlen("Datum izreka opomina učiteljskega zbora: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Ukrepi šole pred izrekom opomina:",0,$encoding);
            $DatumIzreka=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Ukrepi šole pred izrekom opomina: ",0,$encoding)+mb_strlen("Ukrepi šole pred izrekom opomina: ",$encoding);
            $PosEnd=mb_strlen($Ucenci[4],$encoding)-$PosStart;
            $Ukrepi=mb_substr($Ucenci[4],$PosStart,$PosEnd,$encoding);
            
            $PosStart=mb_strpos($Ucenci[4],"Opis kršitve: ",0,$encoding)+mb_strlen("Opis kršitve: ",$encoding);
            $PosEnd=mb_strpos($Ucenci[4],"Datum pisnega predloga razredniku:",0,$encoding);
            $OpisKrsitve=mb_substr($Ucenci[4],$PosStart,$PosEnd-$PosStart,$encoding);
            
            $Ucenci[5]=$R["stdokumenta"];
            $Ucenci[6]=$R["opis"];
            switch ($R["IdUkrep"]){
                case 1:
                    $StevilkaOpomina="prvi";
                    break;
                case 2:
                    $StevilkaOpomina="drugi";
                    break;
                case 3:
                    $StevilkaOpomina="tretji";
                    break;
                default:
                    $StevilkaOpomina="prvi";
            }
            $Vleto=$R["Leto"];
            $Datum=new DateTime(isDate($R["datroj"]));
            $Ucenci[8]=$Datum->format('d.m.Y');
            $Ucenci[10]=$R["spol"];
            $Ucenci[7]=$R["DatIzreka"];
            //$Ucenci[8]=$Danes->format('d.m.Y');
            switch ($R["IdUkrep"]){
                case 1:
                case 2:
                case 3:
                    $Ucenci[9]="razrednik/-čarka";
                    break;
                case 4:
                    $Ucenci[9]="oddelčni učiteljski zbor";
                    break;
                case 5:
                    $Ucenci[9]="ravnatelj/-ica";
                    break;
                case 6:
                    $Ucenci[9]="učiteljski zbor";
            }

            $Indx1=0;

            //'glava šole
            //'ime šole
            fwrite($fh," {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($VSola)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4211230\\charrsid1187874 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid4211230\\charrsid1187874 \\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\row \\ltrrow}\\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\pard \\ltrpar\\ql \\li0\\ri566\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\pararsid927542 "."\n");
            //'naslov
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid4532695 ".ToRTF($VSolaNaslov)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid1464920\\charrsid1187874 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\b\\fs20\\insrsid1464920\\charrsid1187874 \\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\row \\ltrrow}\\pard \\ltrpar\\ql \\li0\\ri566\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\pararsid927542 "."\n");
            //'pošta
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($VSolaKraj)."}"."\n");
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid9392961\\charrsid1187874 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\b\\fs20\\insrsid9392961\\charrsid1187874 \\trowd \\irow2\\irowband2\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\row \\ltrrow}\\trowd \\irow3\\irowband3\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\pard \\ltrpar\\qc \\li0\\ri566\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\pararsid9392961 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs14\\insrsid9392961\\charrsid9392961 ime in sede\\'9e \\'9aole\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid9392961\\charrsid9392961 "."\n");
            fwrite($fh,"\\trowd \\irow3\\irowband3\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrb\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5328\\clshdrawnil \\cellx5220\\row }\\pard \\ltrpar\\ql \\li0\\ri566\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin566\\lin0\\itap0\\pararsid4211230 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid722834\\charrsid3761096                }"."\n");

            //'Obvestilo
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4211230\\charrsid3761096 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri-1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\itap0\\pararsid927542 {\\rtlch\\fcs1 \\af38\\afs20 \\ltrch\\fcs0 \\b\\i\\f38\\fs20\\insrsid927542\\charrsid3761096 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri-1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\itap0\\pararsid927542 {\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\b\\ul\\insrsid3761096 OBVESTILO}{\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\b\\ul\\insrsid927542\\charrsid3761096 "."\n");
            fwrite($fh," o  vzgojnem opominu }{\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\b\\ul\\insrsid927542 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8192345\\charrsid3761096 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10103\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid4532695\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4514\\clshdrawnil \\cellx5954"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1701\\clshdrawnil \\cellx7655\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2340\\clshdrawnil \\cellx9995\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 "."\n");

            //'Učenki/učencu
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 U\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 ki}"."\n");
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4591002\\charrsid3761096 /u\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 cu}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid4591002\\charrsid3761096 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4532695 "."\n");
            //'ime učenca in dat.roj.
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695\\charrsid4532695 ".ToRTF($Ucenci[1])."}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4591002\\charrsid4532695 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 , }{\\rtlch\\fcs1 "."\n");
            fwrite($fh,"\\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872\\charrsid3761096 rojeni }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 /}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 rojenemu}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid4591002\\charrsid3761096 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4532695 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695\\charrsid4532695 ".$Ucenci[8]."}"."\n");
            //'šolsko leto, razred, vrsta
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid1842768\\charrsid4479054 ,}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4591002\\charrsid4479054 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4591002\\charrsid3761096 \\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth10103\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid4532695\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4514\\clshdrawnil "."\n");
            fwrite($fh,"\\cellx5954\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1701\\clshdrawnil \\cellx7655\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2340\\clshdrawnil \\cellx9995\\row \\ltrrow}\\trowd \\irow1\\irowband1\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth10103\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid4532695\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4514\\clshdrawnil "."\n");
            fwrite($fh,"\\cellx5954\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1701\\clshdrawnil \\cellx7655\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2340\\clshdrawnil \\cellx9995\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4591002\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4591002 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4591002\\charrsid3761096 (ime in priimek)\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4591002\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4591002 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4591002\\charrsid3761096 (datum rojstva)\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4591002\\charrsid3761096 \\trowd \\irow1\\irowband1\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10103\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid4532695\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4514\\clshdrawnil \\cellx5954"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1701\\clshdrawnil \\cellx7655\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2340\\clshdrawnil \\cellx9995\\row }\\pard \\ltrpar\\qj \\li0\\ri-1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\itap0\\pararsid8981408 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid6181522\\charrsid2325485 "."\n");

            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1728\\clshdrawnil \\cellx1620\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1172\\clshdrawnil \\cellx2792\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth988\\clshdrawnil \\cellx3780\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth611\\clshdrawnil \\cellx4391\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5689\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid6181522 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8615408\\charrsid3761096 ki v \\'9aolskem letu\\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid3212426 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid4532695 ".$VLeto."/".($VLeto+1)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8615408\\charrsid13645961 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid6181522 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid8615408\\charrsid3761096 obiskuje\\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid12263815 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($Ucenci[2])."}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8615408\\charrsid13645961 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid6181522 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid8615408\\charrsid3761096 razred, je bil v skladu s Pravilnikom o vzgojnih opominih}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8615408  v }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8615408\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8615408\\charrsid3761096 \\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1728\\clshdrawnil \\cellx1620\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1172\\clshdrawnil \\cellx2792\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth988\\clshdrawnil \\cellx3780\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth611\\clshdrawnil \\cellx4391\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5689\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar\\qj \\li0\\ri-1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\itap0\\pararsid8981408 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid8981408\\charrsid2325485     "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4068\\clshdrawnil \\cellx3960\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx5580\\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4500\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid9641725 osnovni}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid9641725\\charrsid3761096  }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid6181522\\charrsid3761096 \\'9aoli (Uradni list RS, \\'9at. 76/08) izre\\'e8en\\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid9641725 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$StevilkaOpomina."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid6181522\\charrsid2624804 "."\n");
            fwrite($fh,"\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid9122069\\charrsid3761096 vzgojni opomin}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid6181522\\charrsid4479054 .}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid6181522\\charrsid3761096 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid6181522\\charrsid3761096 \\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4068\\clshdrawnil \\cellx3960\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx5580\\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4500\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow1\\irowband1\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4068\\clshdrawnil \\cellx3960\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx5580\\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4500\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs14\\insrsid6181522\\charrsid3761096 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid9641725 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid6181522\\charrsid3761096 "."\n");
            fwrite($fh,"(prvi, drugi, tretji)\\cell }"."\n");
            //'Obrazložitev
            fwrite($fh,"\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\b\\fs14\\insrsid6181522\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid6181522\\charrsid3761096 \\trowd \\irow1\\irowband1\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4068\\clshdrawnil \\cellx3960\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx5580\\clvertalt\\clbrdrt"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth4500\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\b\\fs20\\insrsid13376754\\charrsid3761096 "."\n");
            fwrite($fh,"\\par Obrazlo\\'9eitev:}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8410809 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\b\\fs12\\insrsid8879600\\charrsid2325485 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1987\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3600\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1080\\clshdrawnil \\cellx4680"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5400\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 1.\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 U}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872\\charrsid3761096 \\'e8enka}{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid14090872 /u}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 \\'e8enec je dne\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$DatumKrsitve."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid13266413\\charrsid4130182 \\cell }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13266413 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 kr\\'9ail}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 a}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 /kr\\'9ail\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4532695 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF("vzgojni načrt šole sprejet dne ").$Ucenci[3]."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid5509292\\charrsid4130182 "."\n");
            fwrite($fh,"\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13266413\\charrsid3761096 \\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1987\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3600\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1080\\clshdrawnil \\cellx4680"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5400\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9007\\clshdrawnil \\cellx9360\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx9596\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx9832"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth248\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8471214\\charrsid3761096 \\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8471214 \\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid8471214\\charrsid4130182 \\cell }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13266413 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8471214\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid8471214\\charrsid4130182 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8471214\\charrsid3761096 \\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9007\\clshdrawnil \\cellx9360\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx9596\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx9832"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth248\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow2\\irowband2\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1987\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3600\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3420\\clshdrawnil \\cellx7020"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3060\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid9924162\\charrsid10312888 \\cell \\cell }{\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\b\\fs12\\insrsid9924162\\charrsid10312888 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13266413 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid3157333\\charrsid18501 (navesti pravni akt \\endash  zakon, akt \\'9aole..)}{\\rtlch\\fcs1 \\af0\\afs12 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs12\\insrsid9924162\\charrsid10312888 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8471214 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid9924162\\charrsid8471214 \\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid9924162\\charrsid10312888 \\trowd \\irow2\\irowband2\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth461\\clshdrawnil \\cellx353\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1987\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3600\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3420\\clshdrawnil \\cellx7020"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3060\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow3\\irowband3\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trwWidthA856\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth468\\clshdrawnil \\cellx360\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1980\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth404\\clshdrawnil \\cellx2744\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1304\\clshdrawnil \\cellx4048"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5176\\clshdrawnil \\cellx9224\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8471214\\charrsid8471214 \\cell }"."\n");

            //'opis kršitve
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid9335683 Opis kr\\'9aitve:}{\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid8471214\\charrsid10312888 \\cell }{\\rtlch\\fcs1 "."\n");
            fwrite($fh,"\\af0\\afs12 \\ltrch\\fcs0 \\b\\fs12\\insrsid8471214\\charrsid10312888 \\cell }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13266413 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs12\\insrsid8471214\\charrsid10312888 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8471214 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid8471214\\charrsid18501 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid8471214\\charrsid10312888 \\trowd \\irow3\\irowband3\\ltrrow\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trwWidthA856\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
            fwrite($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth468\\clshdrawnil \\cellx360\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1980\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrnone "."\n");
            fwrite($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth404\\clshdrawnil \\cellx2744\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1304\\clshdrawnil \\cellx4048"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth5176\\clshdrawnil \\cellx9224\\row \\ltrrow}\\trowd \\irow4\\irowband4\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft360\\trbrdrt\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trwWidthB468\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth9720\\clshdrawnil \\cellx10080\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8410809 {\\rtlch\\fcs1 "."\n");
            fwrite($fh,"\\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 ".ToRTF($OpisKrsitve)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8617916 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid9335683 "."\n");
            fwrite($fh,"\\par }"."\n");
            //'predlog za ukrep razredniku
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2510170\\charrsid3761096 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8410809\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow4\\irowband4\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft360\\trbrdrt\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trwWidthB468\\trftsWidthA3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth9720\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs12\\insrsid11238712\\charrsid2325485 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth7774\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5917\\clshdrawnil \\cellx6300\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1366\\clshdrawnil \\cellx7666\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4020728\\charrsid3761096 2.\\cell Pisni predlog za izrek vzgojnega opomina je bil podan razredniku dne\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid11996209 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 ".$DatumPredlogaRazredniku."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11996209\\charrsid4479054 .}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4020728\\charrsid4479054 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4020728\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth7774\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5917\\clshdrawnil \\cellx6300\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1366\\clshdrawnil \\cellx7666\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid13325167\\charrsid2325485 "."\n");
            fwrite($fh,"\\par \\ltrrow}"."\n");

            //'razgovor razrednika z učencem
            fwrite($fh,"\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1597\\clshdrawnil \\cellx1980\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3240\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3910\\clshdrawnil \\cellx7150\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2930\\clshdrawnil \\cellx10080\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid3761096 3.\\cell Razrednik je dne\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid15690713 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$DatumRazgovora."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid2640837\\charrsid15690713 \\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid3761096 opravil razgovor z u\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid14090872 ko}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid945992 /u\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872\\charrsid3761096 cem}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid3761096  in }{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid7945661 star\\'9ai}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid3761096 /\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid2510170 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid5141491\\charrsid4479054 .}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid4479054 "."\n");
            fwrite($fh,"\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2640837\\charrsid3761096 \\trowd \\irow0\\irowband0\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1597\\clshdrawnil \\cellx1980\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx3240\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3910\\clshdrawnil \\cellx7150\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2930\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid13376754\\charrsid2325485 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10218\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3217\\clshdrawnil \\cellx3600\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx4860\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth5250\\clshdrawnil \\cellx10110\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 "."\n");

            //'predlog razrednika uč. zboru
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid13900788\\charrsid3761096 4.\\cell Razrednik je u\\'e8iteljskemu zboru dne\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$DatumPredlogaZboru."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid13900788\\charrsid13900788 \\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13900788 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13900788\\charrsid3761096 podal pisni obrazlo\\'9een predlog }{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid13900788 za izrek vzgojnega }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13900788\\charrsid3761096 opomina.\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 "."\n");
            fwrite($fh,"\\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13900788\\charrsid3761096 \\trowd \\irow0\\irowband0\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10218\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3217\\clshdrawnil \\cellx3600\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1260\\clshdrawnil \\cellx4860\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5250\\clshdrawnil \\cellx10110\\row }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid2640837\\charrsid2325485 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth487\\clshdrawnil \\cellx379\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3176\\clshdrawnil \\cellx3555\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1218\\clshdrawnil \\cellx4773\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2461\\clshdrawnil \\cellx7234\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1947\\clshdrawnil \\cellx9181\\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth899\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 "."\n");

            //'datum izreka
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid11087098\\charrsid3761096 5.\\cell U\\'e8iteljski zbor je u\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098 ki}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098\\charrsid3761096 /u\\'e8en}{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid11087098 cu}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098\\charrsid3761096  dne\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$DatumIzreka."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid11087098\\charrsid11087098 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid11087098 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098\\charrsid3761096 za kr\\'9a"."\n");
            fwrite($fh,"itev iz 1. to\\'e8ke izrekel\\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid11087098 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".$StevilkaOpomina." vzgojni}{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\b\\fs20\\insrsid11087098\\charrsid11087098 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid11087098 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098\\charrsid3761096 "."\n");
            fwrite($fh,"opomin.\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11087098\\charrsid3761096 \\trowd \\irow0\\irowband0\\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth487\\clshdrawnil \\cellx379\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3176\\clshdrawnil \\cellx3555\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1218\\clshdrawnil \\cellx4773\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2461\\clshdrawnil \\cellx7234\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1947\\clshdrawnil \\cellx9181\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb"."\n");
            fwrite($fh,"\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth899\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow1\\irowband1\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth487\\clshdrawnil \\cellx379\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3176\\clshdrawnil \\cellx3555\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1305\\clshdrawnil \\cellx4860\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2374\\clshdrawnil "."\n");
            fwrite($fh,"\\cellx7234\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1947\\clshdrawnil \\cellx9181\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth899\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid5142716 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid9715989 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid11087098 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 (prvi, drugi, tretji)\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid9715989 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid11087098\\charrsid3761096 \\trowd \\irow1\\irowband1\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth487\\clshdrawnil \\cellx379\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3176\\clshdrawnil \\cellx3555\\clvertalt"."\n");
            fwrite($fh,"\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1305\\clshdrawnil \\cellx4860\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2374\\clshdrawnil "."\n");
            fwrite($fh,"\\cellx7234\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1947\\clshdrawnil \\cellx9181\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth899\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid5142716\\charrsid8617916 "."\n");
            fwrite($fh,"\\par }"."\n");

            //'ukrepi
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid12543018\\charrsid3761096 \\'8aola lahko v skladu s 54. \\'e8lenom Zakona o osnovni \\'9aoli }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 u\\'e8enko/}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid12543018\\charrsid3761096 u\\'e8enca po izre\\'e8enem tret}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid16537345 jem vzgojnem opominu pre\\'9aola na }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid12543018\\charrsid3761096 drugo \\'9a"."\n");
            fwrite($fh,"olo brez soglasja star\\'9aev.}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid13376754\\charrsid3761096 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid13376754\\charrsid8617916 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15760597\\charrsid3761096 6.\\cell "."\n");
            fwrite($fh,"Pred izrekom vzgojnega opomina je \\'9aola uporabila naslednje ukrepe, dolo\\'e8ene z vzgojnim na\\'e8rtom in \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid15760597\\charrsid3761096 \\trowd \\irow0\\irowband0\\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\row \\ltrrow"."\n");
            fwrite($fh,"}\\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 "."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15760597\\charrsid3761096 \\cell pravili \\'9a"."\n");
            fwrite($fh,"olskega reda}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15666118\\charrsid3761096 :}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15760597 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs8 \\ltrch\\fcs0 \\fs8\\insrsid2642787\\charrsid2642787 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15760597\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow1\\irowband1\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 "."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow2\\irowband2\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15666118\\charrsid3761096 \\cell }{\\rtlch\\fcs1 "."\n");
            fwrite($fh,"\\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 ".ToRTF($Ukrepi)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid8937108 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2510170 "."\n");
            fwrite($fh,"\\par "."\n");
            fwrite($fh,"\\par }"."\n");
            //'kraj in datum, evid. št., ravnatelj
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2510170\\charrsid3761096 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15666118\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow2\\irowband2\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth491\\clshdrawnil \\cellx383\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
            fwrite($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth9697\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid12543018\\charrsid8617916 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3240\\clshdrawnil \\cellx4680\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth917\\clshdrawnil \\cellx5597\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1888\\clshdrawnil \\cellx7485\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2595\\clshdrawnil \\cellx10080\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid870283\\charrsid3761096 Kraj in datum:\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($VSolaKraj.", ".$PrintDay)."}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid870283\\charrsid4729016 \\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid870283\\charrsid3761096 \\cell Eviden\\'e8na \\'9atevilka:\\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($Ucenci[5])."\n");
            fwrite($fh,"}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid870283\\charrsid4729016 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid870283\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1548\\clshdrawnil \\cellx1440\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3240\\clshdrawnil \\cellx4680\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth917\\clshdrawnil \\cellx5597\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1888\\clshdrawnil \\cellx7485\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2595\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid15284896 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid6564589 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0 \\ltrch\\fcs0 \\lang1024\\langfe1024\\noproof\\insrsid4532695 {\\shp{\\*\\shpinst\\shpleft2160\\shptop108\\shpright2700\\shpbottom648\\shpfhdr0\\shpbxcolumn\\shpbxignore\\shpbypara\\shpbyignore\\shpwr3\\shpwrk0\\shpfblwtxt0\\shpz0\\shplid1026"."\n");
            fwrite($fh,"{\\sp{\\sn shapeType}{\\sv 3}}{\\sp{\\sn fFlipH}{\\sv 0}}{\\sp{\\sn fFlipV}{\\sv 0}}{\\sp{\\sn fRecolorFillAsPicture}{\\sv 0}}{\\sp{\\sn fUseShapeAnchor}{\\sv 0}}{\\sp{\\sn fFilled}{\\sv 0}}{\\sp{\\sn dhgt}{\\sv 251657728}}{\\sp{\\sn fLayoutInCell}{\\sv 1}}"."\n");
            fwrite($fh,"{\\sp{\\sn fPseudoInline}{\\sv 0}}{\\sp{\\sn fLayoutInCell}{\\sv 1}}}{\\shprslt{\\*\\do\\dobxcolumn\\dobypara\\dodhgt8192\\dpellipse\\dpx2160\\dpy108\\dpxsize540\\dpysize540"."\n");
            fwrite($fh,"\\dpfillfgcr255\\dpfillfgcg255\\dpfillfgcb255\\dpfillbgcr255\\dpfillbgcg255\\dpfillbgcb255\\dpfillpat0\\dplinew15\\dplinecor0\\dplinecog0\\dplinecob0}}}}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid15284896 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\ql \\fi708\\li1416\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin1416\\itap0\\pararsid15284896 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid6299067   }{\\rtlch\\fcs1 \\af0\\afs18 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs18\\insrsid9769709\\charrsid12863049 Pe\\'e8at}{\\rtlch\\fcs1 \\af0\\afs16 \\ltrch\\fcs0 \\fs16\\insrsid11292182\\charrsid12863049 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft3600\\trftsWidth3\\trwWidth6480\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind3708\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2071\\clshdrawnil \\cellx5671\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth4409\\clshdrawnil \\cellx10080\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid6564589 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11292182\\charrsid3761096 "."\n");
            fwrite($fh,"Ravnatelj}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 ica}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11292182\\charrsid3761096 /ravnatelj}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2325485 :}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid11292182 \\cell }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid4532695 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid4532695 ".ToRTF($VRavnatelj)."}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\b\\fs20\\insrsid11292182\\charrsid6299067 \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid11292182 \\trowd \\irow0\\irowband0\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft3600\\trftsWidth3\\trwWidth6480\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind3708\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2071\\clshdrawnil \\cellx5671\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4409\\clshdrawnil \\cellx10080\\row "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid13325167 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid6564589 "."\n");
            fwrite($fh,"\\par "."\n");
            fwrite($fh,"\\par }"."\n");
            
            //'zaključel lista
            fwrite($fh,"{\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid9335683\\charrsid8617916 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4248\\clshdrawnil \\cellx4140\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1414\\clshdrawnil \\cellx5554\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx5790\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2670\\clshdrawnil \\cellx8460\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx10080\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13325167 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid3761096 Dva}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174 "."\n");
            fwrite($fh," izvoda obvestila izro\\'e8ena u\\'e8enki}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid3761096 /u\\'e8e}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174 ncu}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs20\\insrsid14755174\\charrsid3761096  dne\\cell }\\pard \\ltrpar\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid2510170 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 ".$Danes->format('j.n.Y')."}{\\rtlch\\fcs1 \\af0\\afs20 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid4479054 .\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid13325167 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid3761096 \\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14755174 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid3761096 Podpisan izvod vrnjen dne\\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid2510170 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4532695 }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid4479054 .\\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14755174\\charrsid3761096 \\trowd \\irow0\\irowband0\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4248\\clshdrawnil \\cellx4140\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1414\\clshdrawnil \\cellx5554"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth236\\clshdrawnil \\cellx5790\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2670\\clshdrawnil \\cellx8460\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid13325167 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid11299215\\charrsid8617916 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid1464920 {\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid1464920\\charrsid10946282 Vlo\\'9eiti v mapo vzgojnih opominov.}{\\rtlch\\fcs1 \\af0\\afs14 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs14\\insrsid1464920 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid9335683 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid9335683\\charrsid10946282 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid12263815 {\\rtlch\\fcs1 \\af0\\afs40 \\ltrch\\fcs0 \\b\\fs40\\insrsid10638245\\charrsid11219509 "."\n");
            fwrite($fh,"-----------------------------------------------------------------------}{\\rtlch\\fcs1 \\af0\\afs40 \\ltrch\\fcs0 \\b\\fs40\\insrsid3287235 ---}{\\rtlch\\fcs1 \\af0\\afs40 \\ltrch\\fcs0 \\b\\fs40\\insrsid15624611 "."\n");
            fwrite($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid14757754\\charrsid14757754 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1908\\clshdrawnil \\cellx1800\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3600\\clshdrawnil \\cellx5400\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4680\\clshdrawnil \\cellx10080\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid3493202 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4210645\\charrsid3761096 Podpisan}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 a}{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4210645\\charrsid3761096 /podpisan}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid14090872 i}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4210645\\charrsid3761096 \\cell \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid4210645 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid2318277\\charrsid3761096 potrjujem prejem obvestila o }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0" ."\n");
            fwrite($fh,"\\fs20\\insrsid4210645\\charrsid3761096 vzgojnem opominu.\\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid4210645\\charrsid3761096 "."\n");
            fwrite($fh,"\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 "."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1908\\clshdrawnil \\cellx1800\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth3600\\clshdrawnil \\cellx5400\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4680\\clshdrawnil \\cellx10080\\row \\ltrrow}\\trowd \\irow1\\irowband1\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1908\\clshdrawnil \\cellx1800\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3600\\clshdrawnil \\cellx5400"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4680\\clshdrawnil \\cellx10080\\pard \\ltrpar\\qc \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid4210645 {"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid4210645\\charrsid6496122 \\cell (star\\'9ai/zakoniti zastopnik otroka)\\cell \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs14 "."\n");
            fwrite($fh,"\\ltrch\\fcs0 \\fs14\\insrsid4210645\\charrsid6496122 \\trowd \\irow1\\irowband1\\lastrow \\ltrrow"."\n");
            fwrite($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1908\\clshdrawnil \\cellx1800\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3600\\clshdrawnil \\cellx5400"."\n");
            fwrite($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth4680\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri-1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\itap0\\pararsid3493202 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid12931565\\charrsid8617916 "."\n");
            fwrite($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth828\\clshdrawnil \\cellx720\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2160\\clshdrawnil \\cellx4500\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1671\\clshdrawnil \\cellx6171\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3909\\clshdrawnil \\cellx10080\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid3493202 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243\\charrsid3761096 Datum}{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243 :\\cell "."\n");
            fwrite($fh,"}\\pard \\ltrpar\\qc \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid7435149 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\b\\fs20\\insrsid3812243\\charrsid7435149 \\cell }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\qj \\li0\\ri-1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin-1\\lin0\\pararsid3493202 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243 \\cell }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243\\charrsid3761096 Podpis star"."\n");
            fwrite($fh,"\\'9aev:   }{\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243 \\cell \\cell }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\fs20\\insrsid3812243 "."\n");
            fwrite($fh,"\\trowd \\irow0\\irowband0\\lastrow \\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth3\\trwWidth10188\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol"."\n");
            fwrite($fh,"\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth828\\clshdrawnil \\cellx720\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl "."\n");
            fwrite($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1620\\clshdrawnil \\cellx2340\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2160\\clshdrawnil \\cellx4500\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl "."\n");
            fwrite($fh,"\\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth1671\\clshdrawnil \\cellx6171\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth3909\\clshdrawnil \\cellx10080\\row }\\pard \\ltrpar"."\n");
            fwrite($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af0\\afs12 \\ltrch\\fcs0 \\fs12\\insrsid6500690\\charrsid8617916 "."\n");
            fwrite($fh,"\\par }{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid15624611\\charrsid10946282 U\\'e8en}{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid14090872\\charrsid10946282 ka/u\\'e8enec}{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid15624611\\charrsid10946282  }{"."\n");
            fwrite($fh,"\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid1464920\\charrsid10946282 vrne \\'9aoli en}{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid15624611\\charrsid10946282  izvod s podpisom star\\'9aev}{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 "."\n");
            fwrite($fh,"\\fs14\\insrsid13325167\\charrsid10946282 .}{\\rtlch\\fcs1 \\af0\\afs14 \\ltrch\\fcs0 \\fs14\\insrsid15624611\\charrsid10946282 "."\n");
            fwrite($fh,"\\par }{\\*\\themedata 504b030414000600080000002100828abc13fa0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb6ac3301045f785fe83d0b6d8"."\n");
            fwrite($fh,"72ba28a5d8cea249777d2cd20f18e4b12d6a8f843409c9df77ecb850ba082d74231062ce997b55ae8fe3a00e1893f354e9555e6885647de3a8abf4fbee29bbd7"."\n");
            fwrite($fh,"2a3150038327acf409935ed7d757e5ee14302999a654e99e393c18936c8f23a4dc072479697d1c81e51a3b13c07e4087e6b628ee8cf5c4489cf1c4d075f92a0b"."\n");
            fwrite($fh,"44d7a07a83c82f308ac7b0a0f0fbf90c2480980b58abc733615aa2d210c2e02cb04430076a7ee833dfb6ce62e3ed7e14693e8317d8cd0433bf5c60f53fea2fe7"."\n");
            fwrite($fh,"065bd80facb647e9e25c7fc421fd2ddb526b2e9373fed4bb902e182e97b7b461e6bfad3f010000ffff0300504b030414000600080000002100a5d6a7e7c00000"."\n");
            fwrite($fh,"00360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4fc7060abb08"."\n");
            fwrite($fh,"84a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b63095120f88d94fbc"."\n");
            fwrite($fh,"52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462a1a82fe353"."\n");
            fwrite($fh,"bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f7468656d652f7468"."\n");
            fwrite($fh,"656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b4b0d592c9c"."\n");
            fwrite($fh,"070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b4757e8d3f7"."\n");
            fwrite($fh,"29e245eb2b260a0238fd010000ffff0300504b030414000600080000002100bf34bdc09c060000551b0000160000007468656d652f7468656d652f7468656d65"."\n");
            fwrite($fh,"312e786d6cec594d6f1b4518be23f11f467b6f6327761a4775aad8b11b48d346b15bd4e37877bc3bcdecce6a669cd437d41e9190100571a012370e08a8d44a5c"."\n");
            fwrite($fh,"caaf09144191fa1778676677bd13af49d24650417d48bcb3cffbfd31ef8caf5ebb1f33744884a43c697bf5cb350f91c4e7014dc2b6777bd8bfb4e621a9701260"."\n");
            fwrite($fh,"c613d2f6a6447ad736de7fef2a5e5711890902fa44aee3b6172995ae2f2d491f96b1bccc5392c0bb31173156f028c2a540e023e01bb3a5e55a6d7529c634f150"."\n");
            fwrite($fh,"8263607b6b3ca63ee1871829a0f63672f63d06321225f582cfc440332719cd1e955824161c1cd435444e659709748859db0351013f1a92fbca430c4b052fda5e"."\n");
            fwrite($fh,"cd7cbca58dab4b783d23626a016d89ae6f3e195d46101c2c1b99221c1542ebfd46ebca56c1df00989ac7f57abd6eaf5ef03300ecfb60aad5a5ccb3d15fab7772"."\n");
            fwrite($fh,"9e2590fd3acfbb5b6bd61a2ebec47f654ee756a7d369b6325d2c5303b25f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8e257e7f0fd2badd586"."\n");
            fwrite($fh,"8b37a088d1e4600ead03daef67dc0bc898b3ed4af81ac0d76a197c86826c28d24b8b18f3442d4cb618dfe3a20f088d6458d104a9694ac6d8874ceee2782428d6"."\n");
            fwrite($fh,"12f03a817c2eded8255fce2d696148fa82a6aaed7d9862a88a19d5abe7dfbf7afe141d3f7876fce0a7e3870f8f1ffc68193954db3809cb542fbffdeccfc71fa3"."\n");
            fwrite($fh,"3f9e7ef3f2d117d57859c6fffac327bffcfc793510ea67a6ce8b2f9ffcf6ecc98baf3efdfdbb4715f04d814765f890c644a29be408edf3180c335e7135272371"."\n");
            fwrite($fh,"3e8a61846999623309254eb09652c1bfa722077d738a59161d478f0e713d784740ffa8025e9fdc73141e4462a26885e49d287680bb9cb30e17955ed8d1b24a6e"."\n");
            fwrite($fh,"1e4e92b05ab8989471fb181f56c9eee2c4896f6f9242e7ccd3d231bc1b1147cd3d86138543921085f43b7e40488575772975fcba4b7dc1251f2b7497a20ea695"."\n");
            fwrite($fh,"2e19d291934d33a26d1a435ca6553643bc1ddfecde411dceaaacde22872e12aa02b30ae58784396ebc8e270ac7552c8738666587dfc02aaa527230157e19d793"."\n");
            fwrite($fh,"0a221d12c6512f205256d1dc12606f29e83b185a5665d877d934769142d1832a9e3730e765e4163fe846384eabb0039a4465ec07f2005214a33daeaae0bbdcad"."\n");
            fwrite($fh,"10fd0c71c0c9c270dfa1c409f7e9dde0360d1d956609a2df4c848e25f46aa703c734f9bb76cc28f4639b0317d78ea101bef8fa714566bdad8d7813f6a4aa4ad8"."\n");
            fwrite($fh,"3ed17e17e14e36dd2e17017dfb7bee169e247b04d27c7ee379d772dfb55cef3fdf7217d5f3591bedacb742dbd573839d8acd8c1c2f1e91c794b1819a3272439a"."\n");
            fwrite($fh,"2959c24611f46151139a232229ce4c69045fb3c6eee042810d0d125c7d44553488700a1376ddd34c4299b10e254ab984a39d59aee4adf130a52b7b306cea2383"."\n");
            fwrite($fh,"6d0812ab5d1ed8e515bd9c9f0c0a3666bb09cdf93317b4a2199c55d8ca958c2998fd3ac2ea5aa9334bab1bd54caf73a415264310e74d83c5c29b308120985bc0"."\n");
            fwrite($fh,"cbab7048d7a2e164821909b4dfede69b87c544e1224324231c902c46daeef918d54d90f25c319701903b1531d2c7bc53bc5692d6d26cdf40da59825416d75820"."\n");
            fwrite($fh,"2e8fde9b4429cfe0599474e19e284796948b9325e8a8edb59acb4d0ff9386d7b6338d4c2d73885a84b3df46116c2ed90af844dfb538bd954f92c9aaddc30b708"."\n");
            fwrite($fh,"ea705161fd3e67b0d3075221d51696914d0df32a4b0196684956ffe526b8f5a20cb099fe1a5aacac4132fc6b5a801fddd092f198f8aa1cecd28af69d7dcc5a29"."\n");
            fwrite($fh,"9f282206517084466c22f631845fa72ad81350097713a623e807b849d3de36afdce69c155df9fecae0ec3a666984b376ab4b34af640b37755ce8609e4aea816d"."\n");
            fwrite($fh,"95ba1be3ce6f8a29f90b32a59cc6ff3353f47e0257052b818e800f77b902235daf6d8f0b1571e8426944fdbe80c9c1f40ec816b88d85d7905470a36cfe0b72a8"."\n");
            fwrite($fh,"ffdb9ab33c4c59c3894fedd310090afb918a04217bd0964cf69dc2ac9eed5d9625cb18998c2aa92b53abf6881c1236d43d7055efed1e8a20d54d37c9da80c19d"."\n");
            fwrite($fh,"cc3ff739aba051a8879c72bd393da4d87b6d0dfcd3938f2d6630caedc366a0c9fd5fa858b1ab5a7a439eefbd6543f48bd998d5c8ab028495b6825656f6afa9c2"."\n");
            fwrite($fh,"39b75adbb1e62c5e6ee6ca4114e72d86c562204ae1c207e93fb0ff51e13362d2586fa843be0fbd15c14f0d9a19a40d64f5253b7820dd20ede2080627bb689349"."\n");
            fwrite($fh,"b3b2aecd4627edb57cb3bee049b7907bc2d95ab3b3c4fb9cce2e8633579c538b17e9ecccc38eafedda425743644f96282c8df3938c098cf95dabfcc3131fdd83"."\n");
            fwrite($fh,"406fc105ff84296992097e55121846cf81a903287e2bd1906efc050000ffff0300504b0304140006000800000021000dd1909fb60000001b0100002700000074"."\n");
            fwrite($fh,"68656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f78277086f6fd3ba109126dd88d0add40384"."\n");
            fwrite($fh,"e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec8e4052164e89d93b64b060828e6f37ed1567914b284d26"."\n");
            fwrite($fh,"2452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3fd381a89672f1f165dfe51"."\n");
            fwrite($fh,"4173d9850528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100828abc13fa0000001c0200001300000000000000"."\n");
            fwrite($fh,"000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100a5d6a7e7c0000000360100000b000000000000"."\n");
            fwrite($fh,"000000000000002b0100005f72656c732f2e72656c73504b01022d00140006000800000021006b799616830000008a0000001c00000000000000000000000000"."\n");
            fwrite($fh,"140200007468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d0014000600080000002100bf34bdc09c060000551b000016000000"."\n");
            fwrite($fh,"00000000000000000000d10200007468656d652f7468656d652f7468656d65312e786d6c504b01022d00140006000800000021000dd1909fb60000001b010000"."\n");
            fwrite($fh,"2700000000000000000000000000a10900007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d0100009c0a00000000}"."\n");
            fwrite($fh,"{\\*\\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d"."\n");
            fwrite($fh,"617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169"."\n");
            fwrite($fh,"6e22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363"."\n");
            fwrite($fh,"656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}"."\n");
            fwrite($fh,"{\\*\\latentstyles\\lsdstimax267\\lsdlockeddef0\\lsdsemihiddendef1\\lsdunhideuseddef1\\lsdqformatdef0\\lsdprioritydef99{\\lsdlockedexcept \\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority0 \\lsdlocked0 Normal;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 1;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 2;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 3;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 4;"."\n");
            fwrite($fh,"\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 5;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 6;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 7;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 8;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 9;"."\n");
            fwrite($fh,"\\lsdpriority39 \\lsdlocked0 toc 1;\\lsdpriority39 \\lsdlocked0 toc 2;\\lsdpriority39 \\lsdlocked0 toc 3;\\lsdpriority39 \\lsdlocked0 toc 4;\\lsdpriority39 \\lsdlocked0 toc 5;\\lsdpriority39 \\lsdlocked0 toc 6;\\lsdpriority39 \\lsdlocked0 toc 7;"."\n");
            fwrite($fh,"\\lsdpriority39 \\lsdlocked0 toc 8;\\lsdpriority39 \\lsdlocked0 toc 9;\\lsdqformat1 \\lsdpriority35 \\lsdlocked0 caption;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority10 \\lsdlocked0 Title;\\lsdpriority1 \\lsdlocked0 Default Paragraph Font;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority11 \\lsdlocked0 Subtitle;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority22 \\lsdlocked0 Strong;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority20 \\lsdlocked0 Emphasis;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority59 \\lsdlocked0 Table Grid;\\lsdunhideused0 \\lsdlocked0 Placeholder Text;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority1 \\lsdlocked0 No Spacing;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 1;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 1;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 1;\\lsdunhideused0 \\lsdlocked0 Revision;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority34 \\lsdlocked0 List Paragraph;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority29 \\lsdlocked0 Quote;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority30 \\lsdlocked0 Intense Quote;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 1;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 1;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 2;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 3;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 3;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 3;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 3;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 3;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 4;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 4;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 4;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 4;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 5;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 5;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 5;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 5;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 5;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 6;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 6;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 6;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 6;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 6;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority19 \\lsdlocked0 Subtle Emphasis;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority21 \\lsdlocked0 Intense Emphasis;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority31 \\lsdlocked0 Subtle Reference;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority32 \\lsdlocked0 Intense Reference;"."\n");
            fwrite($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority33 \\lsdlocked0 Book Title;\\lsdpriority37 \\lsdlocked0 Bibliography;\\lsdqformat1 \\lsdpriority39 \\lsdlocked0 TOC Heading;}}{\\*\\datastore 010500000200000018000000"."\n");
            fwrite($fh,"4d73786d6c322e534158584d4c5265616465722e352e3000000000000000000000060000"."\n");
            fwrite($fh,"d0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"fffffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"."\n");
            fwrite($fh,"ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072007900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000500ffffffffffffffffffffffffec69d9888b8b3d4c859eaf6cd158be0f000000000000000000000000d0af"."\n");
            fwrite($fh,"09085605cb01feffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000"."\n");
            fwrite($fh,"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000"."\n");
            fwrite($fh,"000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff000000000000000000000000000000000000000000000000"."\n");
            fwrite($fh,"0000000000000000000000000000000000000000000000000105000000000000}}}"."\n");
            fclose($fh);
        }
        echo "<h2><a href='dato/".$VFile."' target='_blank'>Odpri vzgojni ukrep</a></h2>";
        echo "<a href='izborucenca.php?idd=265'>Vsi ukrepi</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "300": //vpisni list razred PDF
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        if ($VecSol > 0){
            $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VIdSola=$R["idsola"];
            }else{
                $VIdSola=1;
            }

            $SQL = "SELECT * FROM tabsola WHERE id=".$VIdSola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabrazdat.razred,tabrazdat.oznaka FROM ";
        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE idRazred=" . $VRazred;
        $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
        $result = mysqli_query($link,$SQL);

        //0-idUcenec, 1-Priimek in ime, 2-razred, 3-datum rojstva
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx][0]=$R["iducenec"];
            $ucenci[$Indx][1]=$R["priimek"].", ".$R["ime"];
            $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
            $ucenci[$Indx][3]=$R["datroj"];
            $Indx=$Indx+1;
        }
        $StUcencev=$Indx;

        $FontSize=10;

        for ($IndxRazred=0;$IndxRazred < $StUcencev;$IndxRazred++){
            if ($IndxRazred > 0){
                $pdf->AddPage("P","A4");
            }
            $pdf->Image("img/vpisnilist.jpg",1,1,209,290);

            //'izpiše podatke o šoli
            $pdf->SetFont('arialbd_CE','',11);
            $txt=ToWin($VSola);
            $pdf->SetXY(10,22);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $pdf->SetFont('arial_CE','',11);
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10,27);
            $pdf->Cell(0,0,$txt,0,2,"C");
            
            //Izpis osebnih podatkov
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$IndxRazred][0]);

            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10,85);
            $pdf->Cell(110,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin(($VLeto+1)."/".($VLeto+2));
            $pdf->SetXY(150,81);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(150,94);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(10,106);
            $pdf->Cell(110,0,$txt,0,2,"C");

            $txt=ToWin($oUcenec->getemso());
            $pdf->SetXY(150,106);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getNaslov().", ".$oUcenec->getPosta()." ".$oUcenec->getKraj());
            $pdf->SetXY(10,119);
            $pdf->Cell(110,0,$txt,0,2,"C");

            $txt=ToWin($oUcenec->getDrzavljanstvo());
            $pdf->SetXY(150,119);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getOpombe());
            $pdf->SetXY(25,135);
            $pdf->Cell(170,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getoce());
            $pdf->SetXY(20,187);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getocenaslov());
            $pdf->SetLeftMargin(30);
            $pdf->SetXY(20,200);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getocekontakt());
            $pdf->SetXY(20,213);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getmati());
            $pdf->SetXY(115,187);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getmatinaslov());
            $pdf->SetLeftMargin(115);
            $pdf->SetXY(115,200);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getmatikontakt());
            $pdf->SetXY(115,213);
            $pdf->Cell(75,0,$txt,0,2,"L");
                
            $txt=ToWin($oUcenec->getSkrbniki());
            $pdf->SetXY(20,240);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getSkrbnikiNaslov());
            $pdf->SetLeftMargin(30);
            $pdf->SetXY(20,252);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getSkrbnikiKontakt());
            $pdf->SetXY(20,265);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getPlacnik());
            $pdf->SetXY(115,240);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getPlacnikNaslov());
            $pdf->SetLeftMargin(115);
            $pdf->SetXY(115,252);
            $pdf->Cell(75,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getPlacnikKontakt());
            $pdf->SetXY(115,265);
            $pdf->Cell(75,0,$txt,0,2,"L");
        }    

        $pdf->Output("vpisnilisti.pdf","D");
        break;
    case "400": //potrdilo o os obveznosti PDF
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        if ($VecSol > 0){
            $SQL = "SELECT tabrazred.idrazred,tabrazdat.idsola FROM tabrazdat INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VIdSola=$R["idsola"];
            }else{
                $VIdSola=1;
            }

            $SQL = "SELECT * FROM tabsola WHERE id=".$VIdSola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }
        $FontSize=12;
        $pdf = new FPDF();
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        //predogled z ozadjem obrazca
        if (isset($_POST["predogled"])){
            $pdf->Image("img/PotrdiloOSObveznost.jpg",0,1,210);
            
        }
        
        $pdf->SetFont('arialbd_CE','',14);
        $txt=ToWin($VSola);
        $pdf->SetXY(10,49.5);
        $pdf->Cell(0,0,$txt,0,2,"C");

        //'naslov šole
        $pdf->SetFont('arial_CE','',14);
        $txt=ToWin($VSolaNaslov);
        $pdf->SetXY(10,59.5);
        $pdf->Cell(0,0,$txt,0,2,"C");

        $oUcenec=new RUcenec();
        $oUcenec->getUcenec($ucenec);
        //Izpis osebnih podatkov
        $pdf->SetFont('arialbd_CE','',16);
        $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
        $pdf->SetXY(10,121);
        $pdf->Cell(0,0,$txt,0,2,"C");

        $pdf->SetFont('arial_CE','',$FontSize);
        $txt=ToWin($oUcenec->getDatRoj());
        $pdf->SetXY(20,132);
        $pdf->Cell(0,0,$txt,0,2,"L");

        if ($oUcenec->getSpol()=="M"){
            $pdf->Line(165,177.5,178,177.5);
        }else{
            $pdf->Line(147,177.5,162,177.5);
        }
        $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
        $pdf->SetXY(78,132);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($oUcenec->getMaticniList());
        $pdf->SetXY(145,229);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $Razrednik=$_POST["razrednik"];
        $EvidSt=$_POST["evidst"];
        $ObiskovalOd=$_POST["obiskovalod"];
        $ObiskovalDo=$_POST["obiskovaldo"];
        $Izpolnil=$_POST["izpolnil"];

        $txt=ToWin($ObiskovalOd);
        $pdf->SetXY(78,174);
        $pdf->Cell(0,0,$txt,0,2,"L");
        
        $txt=ToWin($ObiskovalDo);
        $pdf->SetXY(115,174);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($Izpolnil);
        $pdf->SetXY(55,183);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($Razrednik);
        $pdf->SetXY(20,256);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($VRavnatelj);
        $pdf->SetXY(143,256);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($_POST["krajdatum"]);
        $pdf->SetXY(20,240);
        $pdf->Cell(0,0,$txt,0,2,"L");

        $txt=ToWin($EvidSt);
        $pdf->SetXY(20,229);
        $pdf->Cell(0,0,$txt,0,2,"L");
        
        $pdf->Output("osobveznost.pdf","D");
        break;
    case "500": //potrdilo o solanju PDF
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        if ($VecSol > 0){
            $SQL = "SELECT tabrazred.idrazred,tabrazdat.idsola FROM tabrazdat INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VIdSola=$R["idsola"];
            }else{
                $VIdSola=1;
            }

            $SQL = "SELECT * FROM tabsola WHERE id=".$VIdSola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $RefStFix=$_POST["evidst"];
        $RefStVar=1;
        /*
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        */
        $pdf = new FPDF();
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        if ($ucenec==0 && $VRazred > 0){
            $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
            $SQL = $SQL . "WHERE tabrazred.idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["iducenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx-1;
        }else{
            $Indx=1;
            $ucenci[$Indx]=$ucenec;
            $StUcencev=$Indx;
        }

        $FontSize=10;

        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
            if ($Indx > 1){
                $pdf->AddPage("P","A4");
            }
            $pdf->Image("img/potrdiloosolanju.jpg",1,1,210);
            
            if (strlen($VSola.", ".$VSolaNaslov) > 60){
                $pdf->SetFont('arialbd_CE','',12);
            }else{    
                $pdf->SetFont('arialbd_CE','',14);
            }
            $txt=ToWin($VSola.", ".$VSolaNaslov);
            $pdf->SetXY(10,33.5);
            $pdf->Cell(0,0,$txt,0,2,"C");

        //Izpis osebnih podatkov
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$Indx]);
            
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10,69);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20,81.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78,81.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $Razred=$oUcenec->getRazred($VLeto);
            
			if ($Razred["razred"] == 0){
				$pdf->Line(20,95,25,95);  //podrčta besedo: je (v šolskem letu)
				if ($oUcenec->getSpol()=="M"){ //podčrta učenka - učenec
					$pdf->Line(93,95,105,95);
				}else{
					$pdf->Line(80,95,92,95);
				}
				
				$txt=ToWin("1. ");
				$pdf->SetXY(110,93);
				$pdf->Cell(0,0,$txt,0,2,"L");

				$txt=ToWin(($VLeto+1)."/".($VLeto+2));
				$pdf->SetXY(48,93);
				$pdf->Cell(0,0,$txt,0,2,"L");
			}else{
				$pdf->Line(12,95,17,95);  //podrčta besedo: je (v šolskem letu)
				if ($oUcenec->getSpol()=="M"){ //podčrta učenka - učenec
					$pdf->Line(93,95,105,95);
				}else{
					$pdf->Line(80,95,92,95);
				}
				
				$txt=ToWin($Razred["razred"].". ".$Razred["paralelka"]);
				$pdf->SetXY(110,93);
				$pdf->Cell(0,0,$txt,0,2,"L");

				$txt=ToWin($Razred["solskoleto"]);
				$pdf->SetXY(48,93);
				$pdf->Cell(0,0,$txt,0,2,"L");
			}

            //if ($RefStVar > 0){
            //    $txt=ToWin($RefStFix.$RefStVar);
            //}else{
            $datum=null;
            if (strlen($RefStFix) > 0){
                $txt=ToWin($RefStFix."-".$RefStVar."/".$Danes->format('Y'));
            }else{
                $SQL = "SELECT evstev,datum FROM tabevstevilkeu WHERE iducenec=".$oUcenec->getIdUcenec()." AND leto=$VLeto AND dokument=1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $txt=ToWin($R["evstev"]);
                    $datum=new DateTime($R["datum"]);
                }else{
                    $txt=ToWin("");
                }
            }
            //}
            $pdf->SetXY(15,119);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $RefStVar=$RefStVar+1;

            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(142,131);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            if ($SpolRavnatelj=="M"){     //podrčta ravnatelji-ravnatelj
                $pdf->Line(154,136,163,136);
            }else{
                $pdf->Line(140,136,153,136);
            }
            if (isset($datum)){
                $txt=ToWin($VSolaKraj.", ".$datum->format('j. n. Y'));
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(15,131);
            $pdf->Cell(0,0,$txt,0,2,"L");

        }    
        $pdf->Output("potrdilo.pdf","D");
        break;
    case "510": //potrdilo o solanju novih prvošolcev
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        if ($VecSol > 0){
            $SQL = "SELECT tabrazred.idrazred,tabrazdat.idsola FROM tabrazdat INNER JOIN tabrazred ON tabrazdat.id=tabrazred.idrazred WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VIdSola=$R["idsola"];
            }else{
                $VIdSola=1;
            }

            $SQL = "SELECT * FROM tabsola WHERE id=".$VIdSola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }else{
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }
        }

        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["Spol"];
        }else{
            $SpolRavnatelj="M";
        }
        
        $RefStFix=$_POST["evidst"];
        /*
        if (isset($_SESSION["RefStVar"])){
            $RefStVar=$_SESSION["RefStVar"];
        }else{
            $RefStVar=0;
        }
        */
        $pdf = new FPDF();
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddPage("P","A4");

        if (isset($_POST["vsi"])){
            $SQL = "SELECT tabucenci.iducenec FROM tabrazred ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND razred=0";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx]=$R["iducenec"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx-1;
        }else{
            $Indx=1;
            $ucenci[$Indx]=$ucenec;
            $StUcencev=$Indx;
        }

        $FontSize=10;

        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
            if ($Indx > 1){
                $pdf->AddPage("P","A4");
            }
            $pdf->Image("img/potrdiloosolanju.jpg",1,1,210);
            
            if (strlen($VSola.", ".$VSolaNaslov) > 60){
                $pdf->SetFont('arialbd_CE','',12);
            }else{    
                $pdf->SetFont('arialbd_CE','',14);
            }
            $txt=ToWin($VSola.", ".$VSolaNaslov);
            $pdf->SetXY(10,33.5);
            $pdf->Cell(0,0,$txt,0,2,"C");

        //Izpis osebnih podatkov
            $oUcenec=new RUcenec();
            $oUcenec->getUcenec($ucenci[$Indx]);
            
            $pdf->SetFont('arialbd_CE','',14);
            $txt=ToWin($oUcenec->getIme()." ".$oUcenec->getPriimek());
            $pdf->SetXY(10,69);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',$FontSize);
            $txt=ToWin($oUcenec->getDatRoj());
            $pdf->SetXY(20,81.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $txt=ToWin($oUcenec->getKrajRoj().", ".$oUcenec->getDrzavaRoj());
            $pdf->SetXY(78,81.5);
            $pdf->Cell(0,0,$txt,0,2,"L");

            $Razred=$oUcenec->getRazred($VLeto);
            
            $pdf->Line(20,95,25,95);  //podrčta besedo: bo (v šolskem letu)
            if ($oUcenec->getSpol()=="M"){ //podčrta učenka - učenec
                $pdf->Line(93,95,104,95);
            }else{
                $pdf->Line(80,95,92,95);
            }
            $txt=ToWin("1.");
            $pdf->SetXY(110,93);
            $pdf->Cell(0,0,$txt,0,2,"L");

            if (isset($Razred["leto"])){
                $txt=ToWin(($Razred["leto"]+1)."/".($Razred["leto"]+2));
            }else{
                $txt=ToWin(($VLeto+1)."/".($VLeto+2));
            }
            $pdf->SetXY(48,93);
            $pdf->Cell(0,0,$txt,0,2,"L");

            //if ($RefStVar > 0){
            //    $txt=ToWin($RefStFix.$RefStVar);
            //}else{
            $datum=null;
            if (strlen($RefStFix) > 0){
                $txt=ToWin($RefStFix."/".$Danes->format('Y'));
            }else{
                $SQL = "SELECT evstev,datum FROM tabevstevilkeu WHERE iducenec=".$oUcenec->getIdUcenec()." AND leto=$VLeto AND dokument=1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $txt=ToWin($R["evstev"]);
                    $datum=new DateTime($R["datum"]);
                }else{
                    $txt=ToWin("");
                }
            }
            //}
            $pdf->SetXY(15,119);
            $pdf->Cell(0,0,$txt,0,2,"L");
            if (strlen($RefStFix) > 0){
                $RefStFix=$RefStFix+1;
            }

            $txt=ToWin($VRavnatelj);
            $pdf->SetXY(142,131);
            $pdf->Cell(0,0,$txt,0,2,"L");
            
            if ($SpolRavnatelj=="M"){     //podrčta ravnatelji-ravnatelj
                $pdf->Line(154,136,163,136);
            }else{
                $pdf->Line(140,136,152,136);
            }
            if (isset($datum)){
                $txt=ToWin($VSolaKraj.", ".$datum->format('j. n. Y'));
            }else{
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
            }
            $pdf->SetXY(15,131);
            $pdf->Cell(0,0,$txt,0,2,"L");

        }    
        $pdf->Output("potrdilo.pdf","D");
        break;
    default:
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Vnosi in spiski";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<h2>Izbor učenca</h2>";
        switch ($Vid){
            case "3":
                echo "<br />";
                echo "<a href='izborucenca.php?idd=265'>Vsi ukrepi</a><br />";
                echo "<br />";
                echo "<form  name='UcenciUkrepi' method=post action='izborucenca.php'>";
                echo "<input name='idd' type='hidden' value='200'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola FROM ";
                $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazred.leto = ". $VLeto ." ORDER BY Priimek, Ime";
                break;
            case "2":
                echo "<form  name='UcenciVRazred' method=post action='ucenec.php'>";
                echo "<input name='id' type='hidden' value='3'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj FROM ";
                $SQL = $SQL . "tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                //$SQL = $SQL . "WHERE year(datroj) > ". ($VLeto-20) ." ORDER BY Priimek, Ime";
                $SQL .= "WHERE tabrazred.leto=$VLeto ORDER BY priimek,ime";
                break;
            case "1": //'potrdilo o šolanju
                echo "<form  name='Potrdilo' method=post action='izborucenca.php'>";
                echo "<input name='idd' type='hidden' value='500'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola FROM ";
                $SQL = $SQL . "(tabucenci LEFT JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." ORDER BY priimek, ime,idsola,razred,paralelka";
                echo "Evid. št. <input name='evidst' type='text' size='10'><br />";
                break;
            case "4": // 'potrdilo o šolanju za bodoče prvošolce
                echo "<form  name='Potrdilo' method=post action='izborucenca.php'>";
                echo "<input name='idd' type='hidden' value='510'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj FROM tabucenci ";
                $SQL = $SQL . "WHERE year(DatRoj) > ".($VLeto-7)." ORDER BY Priimek, Ime";
                echo "Evid. št. <input name='evidst' type='text' size='10'><br />";
                echo "Izpis vseh <input name='vsi' type='checkbox'><br />";
                break;
            case "5": // 'potrdilo o izpolnjeni OŠ obveznosti
                echo "<form  name='Potrdilo' method=post action='izborucenca.php'>";
                echo "<input name='idd' type='hidden' value='400'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola FROM ";
                $SQL = $SQL . "(tabucenci LEFT JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." ORDER BY priimek, ime,razred,paralelka";
                echo "<h2>Potrdilo o izpolnjeni OŠ obveznosti</h2>";
                echo "<input name='predogled' type='checkbox' checked='checked'>Predogled<br />";
                echo "<br />";
                echo "Evid. št. <input name='evidst' type='text' size='10'><br />";
                echo "Obiskoval OŠ od: <input name='obiskovalod' type='text' size='10'><br />";
                echo "Obiskoval OŠ do: <input name='obiskovaldo' type='text' size='10'><br />";
                echo "Izpolnil OŠ obveznost v šolskem letu <input name='izpolnil' type='text' size='10' value='".$VLeto."/".($VLeto+1)."'><br />";
                echo "Kraj in datum: <input name='krajdatum' type='text' size='40'><br />";
                echo "Razrednik/-čarka: <input name='razrednik' type='text' size='30'><br />";
                break;
            default:
                echo "<form  name='UcenciVRazred' method=post action='ucenec_pregled.php'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj FROM ";
                $SQL = $SQL . "tabucenci ";
                $SQL = $SQL . " ORDER BY priimek, ime";
        }
        echo "Šolsko leto: <select name='solskoleto'>";
                echo "<option value='" .  $VLeto  . "' selected='selected'>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
                echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . $VLeto . "</option>";
                echo "<option value='" .  ($VLeto+1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
        echo "</select><br />";

        echo "<select  name='ucenec'>";

        $result = mysqli_query($link,$SQL);
        $Indx =1;
        while ($R = mysqli_fetch_array($result)){
            $Datum=new DateTime(isDate($R["datroj"]));
            if (isset($R["razred"])){
                if ($VecSol > 0){
                    echo "<option value=". $R["iducenec"].">".$R["priimek"].", ".$R["ime"]." ".$Datum->format('d.m.Y')." - ".$R["razred"].". ".$R["paralelka"]." (".$R["idsola"].")</option>";
                }else{
                    echo "<option value=". $R["iducenec"].">".$R["priimek"].", ".$R["ime"]." ".$Datum->format('d.m.Y')." - ".$R["razred"].". ".$R["paralelka"]."</option>";
                }
            }else{
                echo "<option value=". $R["iducenec"].">".$R["priimek"].", ".$R["ime"]." ".$Datum->format('d.m.Y')."</option>";
            }
        }
        echo "</select><br /><br />";
        echo "<input name='submit' type='submit' value='Pošlji'>";

        echo "</form>";
        echo "</body>";
        echo "</html>";
    
}
?>
