<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Nastavitve
</title>
<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>
</head>
<body>

<?php
/* test za branje XML vsebine v polje */

class UcenecCeuviz {
    var $emso;  
    var $ime;
    var $priimek;  
    var $kraj_rojstva;
    var $drzava_rojstva;
    var $ulica_stpr;
    var $hs_stpr;
    var $postna_st_stpr;
    var $kraj_stpr;
    var $ulica_zcpr;
    var $hs_zcpr;
    var $postna_st_zcpr;
    var $kraj_zcpr;
    var $drzavljanstvo;  
    
    function UcenecCeuviz ($aa) 
    {
        foreach ($aa as $k=>$v)
            $this->$k = $aa[$k];
    }
}
function readDatabase($filename) 
{
    // read the XML database of aminoacids
    $data = implode("", file($filename));
    $parser = xml_parser_create();
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, $data, $values, $tags);
    xml_parser_free($parser);

    // loop through the structures
    foreach ($tags as $key=>$val) {
        if ($key == "udelezenec") {
            $molranges = $val;
            // each contiguous pair of array entries are the 
            // lower and upper range for each molecule definition
            for ($i=0; $i < count($molranges); $i+=2) {
                $offset = $molranges[$i] + 1;
                $len = $molranges[$i + 1] - $offset;
                $tdb[] = parseUcenec(array_slice($values, $offset, $len));
            }
        } else {
            continue;
        }
    }
    return $tdb;
}

function parseUcenec($mvalues) 
{
    for ($i=0; $i < count($mvalues); $i++) {
        if (isset($mvalues[$i]["value"])){
            $ucenec[$mvalues[$i]["tag"]] = $mvalues[$i]["value"];
        }else{
            $ucenec[$mvalues[$i]["tag"]] ="";
        }
    }
    return new UcenecCeuviz($ucenec);
}

class UcenecVasco {
    var $MaticnaStevilka;  
    var $Ime;
    var $Priimek;  
    var $Sifra;
    var $Razred;
    var $Aktiven;
    
    function UcenecVasco ($aa) 
    {
        foreach ($aa as $k=>$v)
            $this->$k = $aa[$k];
    }
}

function readDatabaseVasco($filename) 
{
    // read the XML database of aminoacids
    $data = implode("", file($filename));
    $parser = xml_parser_create();
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, $data, $values, $tags);
    xml_parser_free($parser);

    // loop through the structures
    foreach ($tags as $key=>$val) {
        if ($key == "Ucenec") {
            $molranges = $val;
            // each contiguous pair of array entries are the 
            // lower and upper range for each molecule definition
            for ($i=0; $i < count($molranges); $i+=2) {
                $offset = $molranges[$i] + 1;
                $len = $molranges[$i + 1] - $offset;
                $tdb[] = parseUcenecVasco(array_slice($values, $offset, $len));
            }
        } else {
            continue;
        }
    }
    return $tdb;
}

function parseUcenecVasco($mvalues) 
{
    for ($i=0; $i < count($mvalues); $i++) {
        if (isset($mvalues[$i]["value"])){
            $ucenec[$mvalues[$i]["tag"]] = $mvalues[$i]["value"];
        }else{
            $ucenec[$mvalues[$i]["tag"]] ="";
        }
    }
    return new UcenecVasco($ucenec);
}
function LeadZero($x){
    if (strlen($x) > 1){
        return $x;
    }else{
        return "0".$x;
    }
}
function PreveriPoljePrvosolci($x){
    //'vrne index polja
    global $encoding;
    switch (mb_strtoupper($x,$encoding)){
        case "EMSO":
            return 9;
            break;
        case "PRIIMEK":
            return 3;
            break;
        case "IME":
            return 4;
            break;
        case "ROJEN/A":
            return 5;
            break;
        case "SPOL":
            return 26;
            break;
        case "ULICA1":
            return 45;
            break;
        case "H.ST.1":
            return 46;
            break;
        case "POSTNA ST.1":
            return 47;
            break;
        case "POSTA1":
            return 48;
            break;
        case "IME IN PRIIEK MATERE":
            return 19;
            break;
        case "ULICA2":
            return 50;
            break;
        case "H.ST.2":
            return 51;
            break;
        case "POSTNA ST.2":
            return 52;
            break;
        case "POSTA3":
            return 53;
            break;
        case "IME IN PRIIEK OCETA":
            return 15;
            break;
        case "ULICA3":
            return 55;
            break;
        case "H.ST.3":
            return 56;
            break;
        case "POSTNA ST.3":
            return 57;
            break;
        case "POSTA3":
            return 58;
            break;
        default:
            return 0;
    }
}
function PreveriPoljeKadri($x){
    //'vrne index polja
    global $encoding;
    switch (mb_strtoupper($x,$encoding)){
        case "ID":
            return 1;
            break;
        case "IDUCENEC":
            return 2;
            break;
        case "PRIIMEK":
            return 3;
            break;
        case "IME":
            return 4;
            break;
        case "DATROJ":
            return 5;
            break;
        case "KRAJROJ":
            return 6;
            break;
        case "DRZAVAROJ":
            return 7;
            break;
        case "DRZAVLJANSTVO":
            return 8;
            break;
        case "EMSO":
            return 9;
            break;
        case "MATICNILIST":
            return 10;
            break;
        case "MATICNAKNJIGA":
            return 11;
            break;
        case "NASLOV":
            return 12;
            break;
        case "POSTA":
            return 13;
            break;
        case "KRAJ":
            return 14;
            break;
        case "OCE":
            return 15;
            break;
        case "OCENASLOV":
            return 16;
            break;
        case "OCEKONTAKT":
            return 17;
            break;
        case "OCEEMAIL":
            return 18;
            break;
        case "MATI":
            return 19;
            break;
        case "MATINASLOV":
            return 20;
            break;
        case "MATIKONTAKT":
            return 21;
            break;
        case "MATIEMAIL":
            return 22;
            break;
        case "AKTIVNOST":
            return 23;
            break;
        case "LETOROJ":
            return 24;
            break;
        case "IDKRAJBIVANJA":
            return 25;
            break;
        case "SPOL":
            return 26;
            break;
        case "IDPOSEBNEPOTREBE":
            return 27;
            break;
        case "BIVANJE":
            return 28;
            break;
        case "ROM":
            return 29;
            break;
        case "ZACSOLANJA":
            return 30;
            break;
        case "KONSOLANJA":
            return 31;
            break;
        case "ZACSOLANJASOLA":
            return 32;
            break;
        case "KONSOLANJASOLA":
            return 33;
            break;
        case "SKRBNIKI":
            return 34;
            break;
        case "SKRBNIKINASLOV":
            return 35;
            break;
        case "SKRBNIKIKONTAKT":
            return 36;
            break;
        case "SKRBNIKIEMAIL":
            return 37;
            break;
        case "PLACNIK":
            return 38;
            break;
        case "PLACNIKNASLOV":
            return 39;
            break;
        case "PLACNIKKONTAKT":
            return 40;
            break;
        case "OPOMBE":
            return 41;
            break;
        case "OSOBVEZA":
            return 42;
        default:
            return 0;
    }
}
function PreveriPoljeCeuviz($x){
    //'vrne index polja
    global $encoding;
    switch (mb_strtoupper($x,$encoding)){
        case "PRIIMEK":
            return 12;
            break;
        case "IME":
            return 13;
            break;
        case "EMSO":
            return 2;
            break;
        case "KRAJ_ROJSTVA":
            return 3;
            break;
        case "DRZAVA_ROJSTVA":
            return 4;
            break;
        case "ULICA_STPR":
            return 6;
            break;
        case "HS_STPR":
            return 14;
            break;
        case "POSTNA_ST_STPR":
            return 7;
            break;
        case "KRAJ_STPR":
            return 8;
            break;
        case "ULICA_ZCPR":
            return 9;
            break;
        case "HS_ZCPR":
            return 15;
            break;
        case "POSTNA_ST_ZCPR":
            return 10;
            break;
        case "KRAJ_ZCPR":
            return 11;
            break;
        case "DRZAVLJANSTVO":
            return 5;
        default:
            return 0;
    }
}
function PreveriPoljeLopolis($x){
    global $encoding;
    switch (mb_strtoupper($x,$encoding)){
        case "ODDELEK":
            return 1;
            break;
        case "PROGRAM":
            return 2;
            break;
        case "RAZRED":
            return 3;
            break;
        case "NIVOMATEMATIKA":
            return 4;
            break;
        case "NIVOMATEMATIKASKUPINA":
            return 5;
            break;
        case "MATERNIJEZIK":
            return 6;
            break;
        case "NIVOMATERNIJEZIK":
            return 7;
            break;
        case "NIVOMATERNIJEZIKSKUPINA":
            return 8;
            break;
        case "TUJJEZIK":
            return 9;
            break;
        case "NIVOTUJJEZIK":
            return 10;
            break;
        case "NIVOTUJJEZIKSKUPINA":
            return 11;
            break;
        case "1.IZBIRNIPREDMET":
            return 12;
            break;
        case "IZB1SKUP":
            return 13;
            break;
        case "2.IZBIRNIPREDMET":
            return 14;
            break;
        case "IZB2SKUP":
            return 15;
            break;
        case "3.IZBIRNIPREDMET":
            return 16;
            break;
        case "IZB3SKUP":
            return 17;
            break;
        case "PRIIMEK":
            return 18;
            break;
        case "IME":
            return 19;
            break;
        case "DATUMROJSTVA":
            return 20;
            break;
        case "DRŽAVAROJSTVA":
            return 21;
            break;
        case "KRAJROJSTVA":
            return 22;
            break;
        case "SPOL":
            return 23;
            break;
        case "EMSO":
            return 24;
            break;
        case "OBČINA":
            return 25;
            break;
        case "KRAJ":
            return 26;
            break;
        case "ULICA":
            return 27;
            break;
        case "HISNASTEVILKA":
            return 28;
            break;
        case "POŠTA":
            return 29;
            break;
        case "TELEFON":
            return 30;
            break;
        case "MATIČNILIST":
            return 31;
            break;
        case "ŠTEVILKAMATIČNAKNJIGA":
            return 32;
            break;
        case "DELOVODNIK":
            return 33;
            break;
        case "VPISSOLSKOLETO":
            return 34;
            break;
        case "DATUMVPISA":
            return 35;
            break;
        case "DATUMZAČETKAŠOLANJA":
            return 36;
            break;
        case "DATUMZAČETKAŠOLANJANAŠOLI":
            return 37;
            break;
        case "OPOMBE":
            return 38;
            break;
        case "MATI":
            return 39;
            break;
        case "MATITELEFONDOMA":
            return 40;
            break;
        case "MATITELEFONMOBILNI":
            return 41;
            break;
        case "MATITELEFONSLUŽBA":
            return 42;
            break;
        case "MATIEPOSTA":
            return 43;
            break;
        case "OČE":
            return 44;
            break;
        case "OČETELEFONDOMA":
            return 45;
            break;
        case "OČETELEFONMOBILNI":
            return 46;
            break;
        case "OČETELEFONSLUŽBA":
            return 47;
            break;
        case "OČEEPOSTA":
            return 48;
            break;
        case "ZAKONITIZASTOPNIK":
            return 49;
            break;
        case "ZAKONITIZASTOPNIKTELEFONDOMA":
            return 50;
            break;
        case "ZAKONITIZASTOPNIKTELEFONMOBILNI":
            return 51;
            break;
        case "ZAKONITIZASTOPNIKTELEFONSLUŽBA":
            return 52;
            break;
        case "ZAKONITIZASTOPNIKEPOSTA":
            return 53;
            break;
        case "PLAČNIK":
            return 54;
            break;
        case "PLAČNIKTELEFONDOMA":
            return 55;
            break;
        case "PLAČNIKTELEFONMOBILNI":
            return 56;
            break;
        case "PLAČNIKTELEFONSLUŽBA":
            return 57;
            break;
        case "PLAČNIKEPOSTA":
            return 58;
            break;
        case "DELOVODNIK":
            return 59;
            break;
        case "KARTICA":
            return 60;
            break;
        default:
            return 0;
    }
}

function CheckEmso($s){
    if (strlen($s) != 13){
        return false;
    }
    $sum=0;
    $n=intval(substr($s,0,1))*7;
    $sum += $n;
    $n=intval(substr($s,1,1))*6;
    $sum += $n;
    $n=intval(substr($s,2,1))*5;
    $sum += $n;
    $n=intval(substr($s,3,1))*4;
    $sum += $n;
    $n=intval(substr($s,4,1))*3;
    $sum += $n;
    $n=intval(substr($s,5,1))*2;
    $sum += $n;
    $n=intval(substr($s,6,1))*7;
    $sum += $n;
    $n=intval(substr($s,7,1))*6;
    $sum += $n;
    $n=intval(substr($s,8,1))*5;
    $sum += $n;
    $n=intval(substr($s,9,1))*4;
    $sum += $n;
    $n=intval(substr($s,10,1))*3;
    $sum += $n;
    $n=intval(substr($s,11,1))*2;
    $sum += $n;
    $n=intval(substr($s,12,1));
    $o=$sum % 11;
    if ($o == 0 && $o == $n){
        return true;
    }else{
        if ((11-$o)==$n){
            return true;
        }else{
            return false;
        }
    }
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }
    if (isset($_POST["idd"])){
        $VSelect = $_POST["idd"];
    }else{
        if (isset($_GET["idd"])){
            $VSelect=$_GET["idd"];
        }else{
            $VSelect = 0;
        }
    }

	switch ($VSelect){
		case "500":
			switch ($Vid){
				case "2":
				case "3":
					break;
				default:
					$n=$VLevel;
					include('menu_func.inc');
					include ('menu.inc');
			}
			break;
		default:
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
	}
    switch ($VSelect){
        case "100": //zaključek leta
            if (!CheckDostop("NovoSL",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }else{
                switch ($Vid){
                    case "1": //prenos učencev v naslednje šolsko leto
                        $SQL = "SELECT tabrazred.leto,tabrazred.iducenec,tabrazred.letosolanja,tabrazred.razred,tabrazred.paralelka,tabrazred.napredovanje,tabrazred.nadarjen,tabrazdat.idsola,tabrazdat.id,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                        $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." ORDER BY tabrazdat.idsola,tabrazred.razred,tabrazred.paralelka";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["razred"] < 9){
                                $Prenesi[$Indx][1]=$R["leto"]+1; //    'leto
                                if (isset($R["napredovanje"])){
                                    if ($R["napredovanje"] < 2){
                                        $Prenesi[$Indx][2]=$R["razred"]+1; //    'razred
                                        $Prenesi[$Indx][3]=$R["paralelka"]; //    'paralelka
                                        $Prenesi[$Indx][4]=9; //    'devetletka
                                        $Prenesi[$Indx][8]=0; //    'ponavljalec
                                    }else{
                                        $Prenesi[$Indx][2]=$R["razred"];
                                        $Prenesi[$Indx][3]=$R["paralelka"];
                                        $Prenesi[$Indx][4]=9;
                                        $Prenesi[$Indx][8]=1;   // 'ponavljalec
                                    }
                                }else{
                                    $Prenesi[$Indx][2]=$R["razred"]+1; //    'razred
                                    $Prenesi[$Indx][3]=$R["paralelka"]; //    'paralelka
                                    $Prenesi[$Indx][4]=9; //    'devetletka
                                    $Prenesi[$Indx][8]=0; //    'ponavljalec
                                }
                                $Prenesi[$Indx][5]=$R["iducenec"]; //    'učenec
                                $Prenesi[$Indx][6]=0; //    'uspeh
                                $Prenesi[$Indx][7]=0; //    'uspehpol
                                $Prenesi[$Indx][9]=$R["letosolanja"]+1; //    'leto šolanja
                                $Prenesi[$Indx][10]=0; //    'učitelj
                                $Prenesi[$Indx][11]=0; //    'vzgojitelj
                                //$Prenesi[$Indx][12]=$R["id"]; //    'idrazred
                                $Prenesi[$Indx][13]=$R["idsola"]; //    'šola
                                if (isset($R["nadarjen"])){
                                    $Prenesi[$Indx][14]=$R["nadarjen"]; //    'šola
                                }else{
                                    $Prenesi[$Indx][14]=0; //    'šola
                                }
                                $Prenesi[$Indx][15]=$R["ime"]." ".$R["priimek"]; //    'vzgojitelj
                                $Indx=$Indx+1;
                            }
                        }
                        $StPrenosov=$Indx-1;
                        echo "Učencev: ".$StPrenosov."<br />";

                        for ($Indx=1;$Indx <= $StPrenosov;$Indx++){
                            $SQL = "SELECT * FROM tabrazdat WHERE leto=".$Prenesi[$Indx][1]." AND razred=".$Prenesi[$Indx][2]." AND oznaka='".$Prenesi[$Indx][3]."' AND idsola=".$Prenesi[$Indx][13] ;
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $Prenesi[$Indx][12]=$R["id"];
                            }else{
                                $SQL = "INSERT INTO tabrazdat (leto,razred,oznaka,prostor,idsola) VALUES (";
                                $SQL = $SQL . $Prenesi[$Indx][1];
                                $SQL = $SQL . ",".$Prenesi[$Indx][2];
                                $SQL = $SQL . ",'".$Prenesi[$Indx][3]."'";
                                $SQL = $SQL . ",0,".$Prenesi[$Indx][13].")";  //ohrani idsola
                                if (!($result1 = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu učenca!<br />$SQL<br />");
                                }

                                $SQL = "SELECT * FROM tabrazdat WHERE leto=".$Prenesi[$Indx][1]." AND razred=".$Prenesi[$Indx][2]." AND oznaka='".$Prenesi[$Indx][3]."' AND idsola=".$Prenesi[$Indx][13];
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    $Prenesi[$Indx][12]=$R["id"];
                                }
                            }
                        }

                        for ($Indx=1;$Indx <= $StPrenosov;$Indx++){
                            if ($Prenesi[$Indx][5] > 0){
                                $SQL = "SELECT * FROM tabrazred WHERE idUcenec=".$Prenesi[$Indx][5]." AND leto=".$Prenesi[$Indx][1];
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    echo $Indx.". ";
                                    echo "Učenec/-ka ".$Prenesi[$Indx][15]." (".$Prenesi[$Indx][5].") v razredu ".$Prenesi[$Indx][2].". ".$Prenesi[$Indx][3]." ŽE OBSTAJA!<br />";
                                }else{
                                    echo $Indx.". ";
                                    $SQL = "INSERT INTO tabrazred (leto,razred,paralelka,osemdevet,IdUcenec,Uspeh,UspehPol,Ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,LetoSolanja,IdUcitelj,IdVzgojitelj,idRazred,slika,opomba,evidst,datumizdaje,vpisal,datumvpisa";
                                    $SQL = $SQL . ") VALUES (";
                                    $SQL = $SQL . $Prenesi[$Indx][1].",".$Prenesi[$Indx][2].",'".$Prenesi[$Indx][3]."',".$Prenesi[$Indx][4].",".$Prenesi[$Indx][5].",0,0,".$Prenesi[$Indx][8].",0,0,".$Prenesi[$Indx][14].",0,0,".$Prenesi[$Indx][9].",".$Prenesi[$Indx][10].",".$Prenesi[$Indx][11].",".$Prenesi[$Indx][12].",'slike/".$Prenesi[$Indx][1]."_".$Prenesi[$Indx][5].".jpg','','','','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                                    if (!($result1 = mysqli_query($link,$SQL))){
                                        die("Napaka pri prenosu učenca!<br />$SQL<br />");
                                    }else{
                                        echo "Prenesen učenec/-ka ".$Prenesi[$Indx][15]." (".$Prenesi[$Indx][5].") v razred ".$Prenesi[$Indx][2].". ".$Prenesi[$Indx][3]."<br />";
                                    }
                                }
                            }
                        }
                        break;
                    default:
                        echo "S klikom na spodnjo povezavo boste prenesli učence šolskega leta ".$VLeto."/".($VLeto+1)." v naslednje šolsko leto.<br />";
                        echo "Pri tem se bodo kreirali novi razredi na osnovi preteklega šolskega leta. V primeru dodatnih paralelk ali združevanja paralelk, bo potrebno ročno popravljanje.<br />";
                        echo "<h1><a href='priprava.php?idd=100&id=1&solskoleto=".$VLeto."'>Prenesi učence</a></h1>";
                }
            }
            break;
        case "150": //generiranje gesel za dostop staršev na vpogled.php
            //generirajo se gesla staršem, ki še nimajo vpisanih gesel
            //izpiše se tudi tabela uporabniških imen in gesel za obvestilo staršem
            if ($VLevel > 2){
                //prebere zadnje leto vnesenih razredov
                $SQL = "SELECT leto FROM tabrazdat ORDER BY leto DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $Leto=$R["leto"];
                }else{
                    $Leto=$VLeto;
                }
                
                $SQL = "SELECT tabucenci.id,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabucenci.geslo,tabrazred.razred,tabrazred.paralelka FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".$Leto;
                $SQL .= " ORDER BY razred,paralelka,priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                echo "<br />";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th>Št.</th><th>ŠL</th><th>Razred</th><th>Učenec</th><th>EMŠO</th><th>geslo</th><th>status</th></tr>";
                while ($R = mysqli_fetch_array($result)){
                    if (isset($R["geslo"])){
                        if (strlen($R["geslo"]) > 0){
                            //geslo je vpisano - ne spreminjamo
                            $ugeslo=$R["geslo"];
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$Leto."/".($Leto+1)."</td>";
                            echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                            echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
                            if (CheckEmso($R["emso"])){
                                echo "<td>".$R["emso"]."</td>";
                            }else{
                                echo "<td><font color='red'>".$R["emso"]."</font></td>";
                            }
                            echo "<td>".$ugeslo."</td>";
                            echo "<td>2</td>";
                            echo "</tr>";
                        }else{
                            //geslo še ni vpisano - prazno
                            $ugeslo=rand (10000000,99999999);
                            $SQL = "UPDATE tabucenci SET geslo='".$ugeslo."' WHERE id=".$R["id"];
                            if (!($result1 = mysqli_query($link,$SQL))){
                                $ugeslo="";
                                die("Napaka pri vpisu gesla!<br />$SQL <br />");
                            }
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$Leto."/".($Leto+1)."</td>";
                            echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                            echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
                            if (CheckEmso($R["emso"])){
                                echo "<td>".$R["emso"]."</td>";
                            }else{
                                echo "<td><font color='red'>".$R["emso"]."</font></td>";
                            }
                            echo "<td>".$ugeslo."</td>";
                            echo "<td>1</td>";
                            echo "</tr>";
                        }
                    }else{
                        //geslo še ni bilo vpisano
                        $ugeslo=rand (10000000,99999999);
                        $SQL = "UPDATE tabucenci SET geslo='".$ugeslo."' WHERE id=".$R["id"];
                        if (!($result1 = mysqli_query($link,$SQL))){
                            $ugeslo="";
                            die("Napaka pri vpisu gesla!<br />$SQL <br />");
                        }
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$Leto."/".($Leto+1)."</td>";
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
                        if (CheckEmso($R["emso"])){
                            echo "<td>".$R["emso"]."</td>";
                        }else{
                            echo "<td><font color='red'>".$R["emso"]."</font></td>";
                        }
                        echo "<td>".$ugeslo."</td>";
                        echo "<td>1</td>";
                        echo "</tr>";
                    }
                    $Indx += 1;
                }
                echo "</table><br />";
            }else{
                echo "Nimate pravic za to opravilo!<br />";
            }
            break;
        case "200": //popravek razrednikov
            if ($VLevel > 2){
                //prireditev novih razredov učenju - sistemizaciji
                
                //če ne najde nobenega, so bili spremenjeni razredi ali pa sistemizacija še ni vnesena
                $SQL = "SELECT tabucenje.iducitelj,tabrazdat.* FROM ";
                $SQL = $SQL . "tabucenje INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE Predmet=50 AND tabrazdat.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) == 0){
                    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);

                    while ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabucenje SET idrazred=".$R["id"]." WHERE razred=".$R["razred"]." AND paralelka='".$R["oznaka"]."' AND leto=".$VLeto;
                        $result1 = mysqli_query($link,$SQL);
                    }
                }
                
                $SQL = "SELECT tabucenje.iducitelj,tabrazdat.* FROM ";
                $SQL = $SQL . "tabucenje INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE Predmet=50 AND tabrazdat.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Razrednik[$Indx][0]=$R["leto"];
                    $Razrednik[$Indx][1]=$R["iducitelj"];
                    $Razrednik[$Indx][2]=$R["razred"];
                    $Razrednik[$Indx][3]=$R["oznaka"];
                    $Razrednik[$Indx][4]=$R["id"];
                    echo $Razrednik[$Indx][2].". ".$Razrednik[$Indx][3]." ".$Razrednik[$Indx][0].", ".$Razrednik[$Indx][1]."<br />";
                    $Indx=$Indx+1;
                }
                $StRazredov=$Indx-1;

                for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                    if ($Razrednik[$Indx][2] < 6){
                        $SQL= "UPDATE tabrazred SET idUcitelj=".$Razrednik[$Indx][1]." WHERE idRazred=".$Razrednik[$Indx][4];
                    }else{
                        $SQL= "UPDATE tabrazred SET idUcitelj=".$Razrednik[$Indx][1].",idVzgojitelj=0 WHERE idRazred=".$Razrednik[$Indx][4];
                    }
                    $result = mysqli_query($link,$SQL);
                    echo $SQL."<br />";
                }
                echo "<h2>Razredniki iz sistemizacije (".$StRazredov.") so vpisani v razredne podatke.</h2>";
            }else{
                echo "Nimate pravic za to opravilo!<br />";
            }
            break;
        case "300":  //izracunaj uspeh
            if ($VLeto >= 2008){
                $SQL = "SELECT tabrazred.id,tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.ime,tabucenci.priimek FROM tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                $SQL = $SQL . "WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,paralelka,priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT avg(ocenakoncna) AS ock FROM tabocene INNER JOIN TabPredmeti ON tabocene.idPredmet=tabpredmeti.id WHERE idUcenec=".$R["iducenec"]." AND tabpredmeti.prioriteta=0 AND leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    
                    if ($R1 = mysqli_fetch_array($result1)){
                        $UspehUcenec[$Indx][1]=$R["id"];
                        $UspehUcenec[$Indx][2]=$R1["ock"];
                    }else{
                        $UspehUcenec[$Indx][1]=$R["id"];
                        $UspehUcenec[$Indx][2]=0;
                    }
                    $SQL = "UPDATE tabrazred SET uspeh=".str_replace(",",".",number_format($UspehUcenec[$Indx][2],2))." WHERE id=".$UspehUcenec[$Indx][1];
                    if ($result1 = mysqli_query($link,$SQL)){
                        echo $Indx." ".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"].": ".str_replace(",",".",number_format($UspehUcenec[$Indx][2],2))."<br />";
                    }else{
                        die("Napaka pri vpisu povprečne ocene!<br />$SQL<br />");
                    }
                    $Indx=$Indx+1;
                    /*
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (is_numeric($R1["OcenaKoncna"])){
                            $vsota=$vsota+intval($R1["OcenaKoncna"]);
                            $ocen=$ocen+1;
                        }
                    }

                    if ($ocen > 0){
                        $UspehUcenec[$Indx][1]=$R["id"];
                        $UspehUcenec[$Indx][2]=$vsota/$ocen;
                    }else{
                        if ($R["razred"] < 4){
                            $UspehUcenec[$Indx][1]=$R["id"];
                            $UspehUcenec[$Indx][2]=5;
                        }else{
                            $UspehUcenec[$Indx][1]=$R["id"];
                            $UspehUcenec[$Indx][2]=0;
                        }
                    }
                    $Indx=$Indx+1;
                    */
                    
                }
                /*
                for ($i=1;$i < $Indx;$i++){
                    $SQL = "UPDATE tabrazred SET uspeh=".str_replace(",",".",number_format($UspehUcenec[$i][2],2))." WHERE id=".$UspehUcenec[$i][1];
                    $result1 = mysqli_query($link,$SQL);
                }
                */
                echo "<h1>Povprečne ocene (".($Indx-1).") so vpisane za šolsko leto ".$VLeto."/".($VLeto+1)."</h1>";
            }
            echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
            echo "<a href='izpisredovalnice.php'>Redovalnica</a><br />";
            echo "<a href='izborrazreda.php?id=uspeh'>Na izbor razreda</a><br />";
            break;
        case "400": //slike_vpis
            if (!CheckDostop("NovoSL",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }else{
				echo "<h2>Vpis podatkov za slike</h2>";
				$SQL="SELECT id,leto,iducenec FROM tabrazred WHERE leto =".$VLeto;
				$result = mysqli_query($link,$SQL);
				$Indx=1;
				while ($R = mysqli_fetch_array($result)){
					$SQL = "UPDATE tabrazred SET slika='slike/".$R["leto"]."_".$R["iducenec"].".jpg' WHERE id=".$R["id"];
					$result1 = mysqli_query($link,$SQL);
					$Indx=$Indx+1;
					//echo $SQL . "<br />";
				}
				echo "<h2>V bazo so vpisani podatki za slike (".($Indx-1).").</h2>";
			}
            break;
        case "500": //vnos dni pouka
            $Obdelava=$Vid;

            switch ($Obdelava){
                case "1": // 'vnos praznikov in počitnic

                    $SQL = "SELECT * FROM tabdnipouka ORDER BY leto DESC";
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $ActualYear=$R["leto"];
                    }else{
                        $ActualYear=$Danes->format('Y')-1;
                    }
                    
                    echo "<h2>Vnos dni pouka po mesecih</h2>";
                    echo "<form name='DneviPouka' method=post action='priprava.php'>";
                    echo "<input name='idd' type='hidden' value='500'>";
                    echo "<table border=1>";
                    echo "<tr><th>Leto</th><th>sep</th><th>okt</th><th>nov</th><th>dec</th><th>jan</th><th>feb</th><th>mar</th><th>apr</th><th>maj</th><th>jun</th><th>jun/9r</th><th>Skupaj</th><th>Briši</th></tr>";
                    
                    echo "<tr>";
                    echo "<td>";
                    echo "<select name='leto'>";
                    for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+3;$Indx++){
                        if ($Indx==$ActualYear+1){
                            echo "<option selected>".$Indx."</option>";
                        }else{
                            echo "<option>".$Indx."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td>";
                    for ($Indx=1;$Indx <= 10;$Indx++){
                        echo "<td><select name='m".$Indx."'>";
                        for ($Indx1=0;$Indx1 <= 25;$Indx1++){
                            if ($Indx1==0){
                                echo "<option value='".$Indx1."' selected='selected'>&nbsp;</option>";
                            }else{
                                echo "<option value='".$Indx1."'>".$Indx1."</option>";
                            }
                        }
                        echo "</select></td>";
                    }
                    //'dodatno za junij - 9r
                    echo "<td><select name='m109'>";
                    for ($Indx1=0;$Indx1 <= 25;$Indx1++){
                        if ($Indx1==0){
                            echo "<option value='".$Indx1."' selected='selected'>&nbsp;</option>";
                        }else{
                            echo "<option value='".$Indx1."'>".$Indx1."</option>";
                        }
                    }
                    echo "</select></td>";
                    echo "<td>&nbsp;</td><td><input name='submit' type='submit' value='Pošlji'></td>";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $VsotaDni=$R["m1"]+$R["m2"]+$R["m3"]+$R["m4"]+$R["m5"]+$R["m6"]+$R["m7"]+$R["m8"]+$R["m9"];
                        echo "<tr>";
                        echo "<td>".$R["leto"]."</td>";
                        echo "<td>".$R["m1"]."</td>";
                        echo "<td>".$R["m2"]."</td>";
                        echo "<td>".$R["m3"]."</td>";
                        echo "<td>".$R["m4"]."</td>";
                        echo "<td>".$R["m5"]."</td>";
                        echo "<td>".$R["m6"]."</td>";
                        echo "<td>".$R["m7"]."</td>";
                        echo "<td>".$R["m8"]."</td>";
                        echo "<td>".$R["m9"]."</td>";
                        echo "<td>".$R["m10"]."</td>";
                        echo "<td>".$R["m109"]."</td>";
                        echo "<td>".($VsotaDni+$R["m10"])."/".($VsotaDni+$R["m109"])."</td>";
                        echo "<td><a href='priprava.php?idd=500&id=3&zapis=".$R["id"]."'>Briši</a></td>";
                        echo "</tr>";
                    }
                    
                    echo "</table>";
                    echo "<input name='id' type='hidden' value='2'>";
                    echo "</form>";
                    break;
                case "2": // 'vpis zapisa
                    $SQL = "SELECT * FROM tabdnipouka WHERE leto=".$_POST["leto"];
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabdnipouka SET ";
                        $SQL = $SQL . "m1=".$_POST["m1"];
                        $SQL = $SQL .", m2=".$_POST["m2"];
                        $SQL = $SQL .", m3=".$_POST["m3"];
                        $SQL = $SQL .", m4=".$_POST["m4"];
                        $SQL = $SQL .", m5=".$_POST["m5"];
                        $SQL = $SQL .", m6=".$_POST["m6"];
                        $SQL = $SQL .", m7=".$_POST["m7"];
                        $SQL = $SQL .", m8=".$_POST["m8"];
                        $SQL = $SQL .", m9=".$_POST["m9"];
                        $SQL = $SQL .", m10=".$_POST["m10"];
                        $SQL = $SQL .", m109=".$_POST["m109"];
                        $SQL = $SQL ." WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabdnipouka (leto,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m109) VALUES ";
                        $SQL = $SQL . "(".$_POST["leto"].",";
                        $SQL = $SQL . $_POST["m1"].",";
                        $SQL = $SQL . $_POST["m2"].",";
                        $SQL = $SQL . $_POST["m3"].",";
                        $SQL = $SQL . $_POST["m4"].",";
                        $SQL = $SQL . $_POST["m5"].",";
                        $SQL = $SQL . $_POST["m6"].",";
                        $SQL = $SQL . $_POST["m7"].",";
                        $SQL = $SQL . $_POST["m8"].",";
                        $SQL = $SQL . $_POST["m9"].",";
                        $SQL = $SQL . $_POST["m10"].",";
                        $SQL = $SQL . $_POST["m109"].")";
                        
                    }
                    $result = mysqli_query($link,$SQL);
                    header ("Location: priprava.php?idd=500&id=1");
                    break;
                case "3":
                    $SQL = "DELETE FROM tabdnipouka WHERE id=".$_GET["zapis"];
                    $result = mysqli_query($link,$SQL);
                    
                    header ("Location: priprava.php?idd=500&id=1");
            }
            echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
            break;
        case "600": //export ceuviz
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }else{
                $VFile="podatkiceuviz.xml";
                $MyFile = "dato".$FileSep.$VFile;
                $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

                echo "<h2>Izvoz podatkov o učencih za CEUVIZ</h2>";

                switch ($Vid){
                    case "1": // 'kreiranje datoteke
                        $VOpravilnaSt=$_POST["opravilnast"];
                        $VOperacija=$_POST["operacija"];
                        $VTipVnosa=$_POST["tipvnosa"];
                        $VSkupina=$_POST["skupina"];
                        //$VProgram=$_POST["program"];
                        
                        $SQL = "SELECT * FROM tabsola";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VSolaId=$R["UstanovaIDmin"];
                        }else{
                            $VSolaId=" ";
                        }

                        fwrite($fh, chr(239).chr(187).chr(191)."<"."?xml version=".chr(34)."1.0".chr(34)." encoding=".chr(34)."UTF-8".chr(34)."?".">"."\n");
                        fwrite($fh, "<!--XML file generated by Kadri-->"."\n");
                        fwrite($fh, "<ceuviz_uvoz xsi:noNamespaceSchemaLocation=".chr(34)."uvoz.xsd".chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34).">"."\n");
                        fwrite($fh, "  <verzija>1.4</verzija>"."\n");
                        fwrite($fh, "  <operacija>");
                        switch ($VOperacija){
                            case "1":
                                fwrite($fh, "KONTROLA");
                                break;
                            case "2":
                                fwrite($fh, "VPIS");
                        }
                        fwrite($fh, "</operacija>"."\n");
                        fwrite($fh, "  <udelezenci>"."\n");
                        if ($VTipVnosa=="3"){
                            if ($VSkupina=="1"){
                                $VSkupina="2";
                            }
                        }
                        switch ($VSkupina){
                            case "1": // 'vsi učenci
                                $SQL = "SELECT tabucenci.*,tabrazred.*,tabrazdat.*,tabprogrammss.* FROM ";
                                $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                                $SQL = $SQL . " INNER JOIN tabprogrammss ON tabucenci.idUcenec=tabprogrammss.idUcenec ";
                                $SQL = $SQL . " WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0";
                                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
                                $result = mysqli_query($link,$SQL);
                                while ($R = mysqli_fetch_array($result)){
                                    if (strlen($R["emso"]) == 13){
                                        fwrite($fh, "    <udelezenec>"."\n");
                                        fwrite($fh, "      <tip_vnosa>");
                                        switch ($VTipVnosa){
                                            case "1":
                                                fwrite($fh, "INSERT");
                                                break;
                                            case "2":
                                                fwrite($fh, "DELETE");
                                                break;
                                            case "3":
                                                fwrite($fh, "OCENA");
                                        }
                                        fwrite($fh, "</tip_vnosa>"."\n");
                                        fwrite($fh, "      <udelezenec_id></udelezenec_id>"."\n");
                                        fwrite($fh, "      <opravilna_st>".$VOpravilnaSt."</opravilna_st>"."\n");
                                        fwrite($fh, "      <emso>".$R["emso"]."</emso>"."\n");
                                        fwrite($fh, "      <ime>".$R["Ime"]."</ime>"."\n");
                                        fwrite($fh, "      <priimek>".$R["Priimek"]."</priimek>"."\n");
                                        fwrite($fh, "      <kraj_rojstva>".$R["KrajRoj"]."</kraj_rojstva>"."\n");
                                        fwrite($fh, "      <drzava_rojstva>".$R["DrzavaRoj"]."</drzava_rojstva>"."\n");
                                        
                                        //poišče hišno številko:
                                        //razbije niz na osnovi presledka in od konca išče številko
                                        //ko številko najde, tvori niz iz delov do številke in hišno številko iz preostalega dela
                                        $sarr=explode(" ",$R["Naslov"]);
                                        $n=count($sarr);
                                        for ($i=count($sarr)-1;$i >= 0;$i--){
                                            if (is_numeric($sarr[$i])){
                                                $n=$i;
                                                break;
                                            }
                                        }
                                        
                                        $Naslov="";
                                        if ($n==count($sarr)){
                                            $n=count($sarr)-1;
                                        }
                                        for ($i=0;$i < $n;$i++){
                                            if (isset($sarr[$i])){
                                                $Naslov=$Naslov." ".$sarr[$i];
                                            }else{
                                                $Naslov=$R["Naslov"];
                                            }
                                        }
                                        $Naslov=trim($Naslov);
                                        $HSt="";
                                        for ($i=$n;$i < count($sarr);$i++){
                                            $HSt=$HSt." ".$sarr[$i];
                                        }
                                        $HSt=trim($HSt);
                                        fwrite($fh, "      <ulica_stpr>".$Naslov."</ulica_stpr>"."\n");
                                        fwrite($fh, "      <hs_stpr>");
                                        fwrite($fh, $HSt."</hs_stpr>"."\n");
                                        
                                        fwrite($fh, "      <postna_st_stpr>".$R["Posta"]."</postna_st_stpr>"."\n");
                                        fwrite($fh, "      <kraj_stpr>".$R["Kraj"]."</kraj_stpr>"."\n");
                                        

                                        if (isset($R["NaslovZac"])){
                                            $sarr=explode(" ",$R["NaslovZac"]);
                                        }else{
                                            $sarr=explode(" ","");
                                        }
                                        $n=count($sarr);
                                        for ($i=count($sarr)-1;$i >= 0;$i--){
                                            if (is_numeric($sarr[$i])){
                                                $n=$i;
                                                break;
                                            }
                                        }
                                        
                                        $NaslovZac="";
                                        if ($n==count($sarr)){
                                            $n=count($sarr)-1;
                                        }
                                        if (isset($R["NaslovZac"])){
                                            for ($i=0;$i < $n;$i++){
                                                if (isset($sarr[$i])){
                                                    $NaslovZac=$Naslov." ".$sarr[$i];
                                                }else{
                                                    $NaslovZac=$R["NaslovZac"];
                                                }
                                            }
                                        }
                                        $NaslovZac=trim($NaslovZac);
                                        $HStZac="";
                                        for ($i=$n;$i < count($sarr);$i++){
                                            $HStZac=$HStZac." ".$sarr[$i];
                                        }
                                        $HStZac=trim($HStZac);
                                        fwrite($fh, "      <ulica_zcpr>".$NaslovZac."</ulica_zcpr>"."\n");
                                        fwrite($fh, "      <hs_zcpr>".$HStZac."</hs_zcpr>"."\n");
                                        if (isset($R["PostaZac"])){
                                            fwrite($fh, "      <postna_st_zcpr>".$R["PostaZac"]."</postna_st_zcpr>"."\n");
                                        }else{
                                            fwrite($fh, "      <postna_st_zcpr></postna_st_zcpr>"."\n");
                                        }
                                        if (isset($R["KrajZac"])){
                                            fwrite($fh, "      <kraj_zcpr>".$R["KrajZac"]."</kraj_zcpr>"."\n");
                                        }else{
                                            fwrite($fh, "      <kraj_zcpr></kraj_zcpr>"."\n");
                                        }
                                        fwrite($fh, "      <drzavljanstvo>".$R["Drzavljanstvo"]."</drzavljanstvo>"."\n");
                                        fwrite($fh, "      <spol>");
                                        if ($R["Spol"]=="M"){
                                            fwrite($fh, "M");
                                        }else{
                                            fwrite($fh, "Ž");
                                        }
                                        fwrite($fh, "</spol>"."\n");
                                        fwrite($fh, "      <zavod_id>".$VSolaId."</zavod_id>"."\n");
                                        if (isDate($R["ZacSolanjaSola"])){
                                            $DatumZ=new DateTime(isDate($R["ZacSolanjaSola"]));
                                        }else{
                                            $DatumZ=new DateTime($VLeto."-09-01");
                                        }
                                        $DatumZ1=new DateTime($VLeto."-09-01");
                                        fwrite($fh, "      <zav_vpisan_od>".$DatumZ->format('Y-m-d')."</zav_vpisan_od>"."\n");
                                        
                                        
                                        if (isDate($R["KonSolanjaSola"])){
                                            $DatumK=new DateTime(isDate($R["KonSolanjaSola"]));
                                        }else{
                                            $DatumK=new DateTime(($VLeto+1)."-08-31");
                                        }
                                        $DatumK1=new DateTime(($VLeto+1)."-08-31");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <zav_vpisan_do>".$DatumK1->format('Y-m-d')."</zav_vpisan_do>"."\n");
                                        }
                                        
                                        fwrite($fh, "      <program_id>".$R["program"]."</program_id>\n");

                                        fwrite($fh, "      <prg_vpisan_od>".$DatumZ->format('Y-m-d')."</prg_vpisan_od>"."\n");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <prg_vpisan_do>".$DatumK1->format('Y-m-d')."</prg_vpisan_do>"."\n");
                                            fwrite($fh, "      <datum_zaklj>".$DatumK1->format('Y-m-d')."</datum_zaklj>"."\n");
                                        }
                                        fwrite($fh, "      <status_udel>UCE</status_udel>"."\n");
                                        fwrite($fh, "      <solsko_leto>".$VLeto."/".($VLeto+1)."</solsko_leto>"."\n");
                                        if ($R["razred"]==9){
                                            fwrite($fh, "      <razred>16</razred>"."\n");
                                        }else{
                                            fwrite($fh, "      <razred>".$R["razred"]."</razred>"."\n");
                                        }
                                        if (is_numeric(strpos($R["oznaka"],"komb"))){
                                            fwrite($fh, "      <oddelek>KOMB.</oddelek>"."\n");
                                        }else{
                                            fwrite($fh, "      <oddelek>".mb_strtoupper(mb_substr($R["oznaka"],0,1,$encoding),$encoding)."</oddelek>"."\n");
                                        }
                                        
                                        fwrite($fh, "      <let_vpisan_od>".$DatumZ1->format('Y-m-d')."</let_vpisan_od>"."\n");
                                        fwrite($fh, "      <let_vpisan_do>".$DatumK1->format('Y-m-d')."</let_vpisan_do>"."\n");
                                        fwrite($fh, "      <nacin_izb>");
                                        if ($R["Ponavljalec"]==0){
                                            fwrite($fh, "RED");
                                        }else{
                                            fwrite($fh, "PON");
                                        }
                                        fwrite($fh, "</nacin_izb>"."\n");
                                        fwrite($fh, "      <oblika_izb></oblika_izb>"."\n");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <povpr_ocena>".str_replace(",",".",number_format($R["Uspeh"],2))."</povpr_ocena>"."\n");
                                        }
                                        $SQL = "SELECT malica,kosilo FROM tabprehrana WHERE iducenec=".$R["IdUcenec"]." AND leto=".$VLeto;
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            if ($R1["malica"]){
                                                fwrite($fh, "      <malica>DA</malica>\n");
                                            }else{
                                                fwrite($fh, "      <malica>NE</malica>\n");
                                            }
                                            if ($R1["kosilo"]){
                                                fwrite($fh, "      <kosilo>DA</kosilo>\n");
                                            }else{
                                                fwrite($fh, "      <kosilo>NE</kosilo>\n");
                                            }
                                        }
                                        fwrite($fh, "    </udelezenec>"."\n");
                                    }
                                }
                                break;
                            case "2": // 'deveti razredi
                                $SQL = "SELECT tabucenci.*,tabrazred.*,tabrazdat.*,tabprogrammss.* FROM ";
                                $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                                $SQL = $SQL . " INNER JOIN tabprogrammss ON tabucenci.idUcenec=tabprogrammss.idUcenec ";
                                $SQL = $SQL . " WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred=9";
                                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
                                $result = mysqli_query($link,$SQL);
                                while ($R = mysqli_fetch_array($result)){
                                    if (strlen($R["emso"]) == 13){
                                        fwrite($fh, "    <udelezenec>"."\n");
                                        fwrite($fh, "      <tip_vnosa>");
                                        switch ($VTipVnosa){
                                            case "1":
                                                fwrite($fh, "INSERT");
                                                break;
                                            case "2":
                                                fwrite($fh, "DELETE");
                                                break;
                                            case "3":
                                                fwrite($fh, "OCENA");
                                        }
                                        fwrite($fh, "</tip_vnosa>"."\n");
                                        fwrite($fh, "      <udelezenec_id></udelezenec_id>"."\n");
                                        fwrite($fh, "      <opravilna_st>".$VOpravilnaSt."</opravilna_st>"."\n");
                                        fwrite($fh, "      <emso>".$R["emso"]."</emso>"."\n");
                                        fwrite($fh, "      <ime>".$R["Ime"]."</ime>"."\n");
                                        fwrite($fh, "      <priimek>".$R["Priimek"]."</priimek>"."\n");
                                        fwrite($fh, "      <kraj_rojstva>".$R["KrajRoj"]."</kraj_rojstva>"."\n");
                                        fwrite($fh, "      <drzava_rojstva>".$R["DrzavaRoj"]."</drzava_rojstva>"."\n");
                                        //poišče hišno številko:
                                        //razbije niz na osnovi presledka in od konca išče številko
                                        //ko številko najde, tvori niz iz delov do številke in hišno številko iz preostalega dela
                                        $sarr=explode(" ",$R["Naslov"]);
                                        $n=count($sarr);
                                        for ($i=count($sarr)-1;$i >= 0;$i--){
                                            if (is_numeric($sarr[$i])){
                                                $n=$i;
                                                break;
                                            }
                                        }
                                        
                                        $Naslov="";
                                        if ($n==count($sarr)){
                                            $n=count($sarr)-1;
                                        }
                                        for ($i=0;$i < $n;$i++){
                                            if (isset($sarr[$i])){
                                                $Naslov=$Naslov." ".$sarr[$i];
                                            }else{
                                                $Naslov=$R["Naslov"];
                                            }
                                        }
                                        $Naslov=trim($Naslov);
                                        $HSt="";
                                        for ($i=$n;$i < count($sarr);$i++){
                                            $HSt=$HSt." ".$sarr[$i];
                                        }
                                        $HSt=trim($HSt);
                                        fwrite($fh, "      <ulica_stpr>".$Naslov."</ulica_stpr>"."\n");
                                        fwrite($fh, "      <hs_stpr>");
                                        fwrite($fh, $HSt."</hs_stpr>"."\n");
                                        
                                        fwrite($fh, "      <postna_st_stpr>".$R["Posta"]."</postna_st_stpr>"."\n");
                                        fwrite($fh, "      <kraj_stpr>".$R["Kraj"]."</kraj_stpr>"."\n");
                                        fwrite($fh, "      <ulica_zcpr></ulica_zcpr>"."\n");
                                        fwrite($fh, "      <hs_zcpr></hs_zcpr>"."\n");
                                        fwrite($fh, "      <postna_st_zcpr></postna_st_zcpr>"."\n");
                                        fwrite($fh, "      <kraj_zcpr></kraj_zcpr>"."\n");
                                        fwrite($fh, "      <drzavljanstvo>".$R["Drzavljanstvo"]."</drzavljanstvo>"."\n");
                                        fwrite($fh, "      <spol>");
                                        if ($R["Spol"]=="M"){
                                            fwrite($fh, "M");
                                        }else{
                                            fwrite($fh, "Ž");
                                        }
                                        fwrite($fh, "</spol>"."\n");
                                        fwrite($fh, "      <zavod_id>".$VSolaId."</zavod_id>"."\n");
                                        if (isDate($R["ZacSolanjaSola"])){
                                            $DatumZ=new DateTime(isDate($R["ZacSolanjaSola"]));
                                        }else{
                                            $DatumZ=new DateTime($VLeto."-09-01");
                                        }
                                        $DatumZ1=new DateTime($VLeto."-09-01");
                                        fwrite($fh, "      <zav_vpisan_od>".$DatumZ->format('Y-m-d')."</zav_vpisan_od>"."\n");
                                        
                                        if (isDate($R["KonSolanjaSola"])){
                                            $DatumK=new DateTime(isDate($R["KonSolanjaSola"]));
                                        }else{
                                            $DatumK=new DateTime(($VLeto+1)."-08-31");
                                        }
                                        $DatumK1=new DateTime(($VLeto+1)."-08-31");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <zav_vpisan_do>".$DatumK1->format('Y-m-d')."</zav_vpisan_do>"."\n");
                                        }
                                        
                                        fwrite($fh, "      <program_id>".$R["program"]."</program_id>\n");

                                        fwrite($fh, "      <prg_vpisan_od>".$DatumZ->format('Y-m-d')."</prg_vpisan_od>"."\n");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <prg_vpisan_do>".$DatumK1->format('Y-m-d')."</prg_vpisan_do>"."\n");
                                            fwrite($fh, "      <datum_zaklj>".$DatumK1->format('Y-m-d')."</datum_zaklj>"."\n");
                                        }
                                        fwrite($fh, "      <status_udel>UCE</status_udel>"."\n");
                                        fwrite($fh, "      <solsko_leto>".$VLeto."/".($VLeto+1)."</solsko_leto>"."\n");
                                        if ($R["razred"]==9){
                                            fwrite($fh, "      <razred>16</razred>"."\n");
                                        }else{
                                            fwrite($fh, "      <razred>".$R["razred"]."</razred>"."\n");
                                        }
                                        if (is_numeric(strpos($R["oznaka"],"komb"))){
                                            fwrite($fh, "      <oddelek>KOMB.</oddelek>"."\n");
                                        }else{
                                            fwrite($fh, "      <oddelek>".mb_strtoupper(mb_substr($R["oznaka"],0,1,$encoding),$encoding)."</oddelek>"."\n");
                                        }
                                        
                                        fwrite($fh, "      <let_vpisan_od>".$DatumZ1->format('Y-m-d')."</let_vpisan_od>"."\n");
                                        fwrite($fh, "      <let_vpisan_do>".$DatumK1->format('Y-m-d')."</let_vpisan_do>"."\n");
                                        fwrite($fh, "      <nacin_izb>");
                                        if ($R["Ponavljalec"]==0){
                                            fwrite($fh, "RED");
                                        }else{
                                            fwrite($fh, "PON");
                                        }
                                        fwrite($fh, "</nacin_izb>"."\n");
                                        fwrite($fh, "      <oblika_izb></oblika_izb>"."\n");
                                        if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                            fwrite($fh, "      <povpr_ocena>".str_replace(",",".",number_format($R["Uspeh"],2))."</povpr_ocena>"."\n");
                                        }
                                        $SQL = "SELECT malica,kosilo FROM tabprehrana WHERE iducenec=".$R["IdUcenec"]." AND leto=".$VLeto;
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            if ($R1["malica"]){
                                                fwrite($fh, "      <malica>DA</malica>\n");
                                            }else{
                                                fwrite($fh, "      <malica>NE</malica>\n");
                                            }
                                            if ($R1["kosilo"]){
                                                fwrite($fh, "      <kosilo>DA</kosilo>\n");
                                            }else{
                                                fwrite($fh, "      <kosilo>NE</kosilo>\n");
                                            }
                                        }
                                        fwrite($fh, "    </udelezenec>"."\n");
                                    }
                                }
                                break;
                            case "3": // 'izbrani učenci
                                for ($Indx=1;$Indx <= intval($_POST["stucencev"]);$Indx++){
                                    if (isset($_POST["cb_".$Indx])){
                                        $SQL = "SELECT tabucenci.*,tabrazred.*,tabrazdat.*,tabprogrammss.* FROM ";
                                        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                                        $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                                        $SQL = $SQL . " INNER JOIN tabprogrammss ON tabucenci.idUcenec=tabprogrammss.idUcenec ";
                                        $SQL = $SQL . " WHERE tabrazdat.leto=".$VLeto." AND tabrazred.idUcenec=".$_POST["uc_".$Indx];
                                        $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
                                        $result = mysqli_query($link,$SQL);
                                        while ($R = mysqli_fetch_array($result)){
                                            if (strlen($R["emso"]) == 13){
                                                fwrite($fh, "    <udelezenec>"."\n");
                                                fwrite($fh, "      <tip_vnosa>");
                                                switch ($VTipVnosa){
                                                    case "1":
                                                        fwrite($fh, "INSERT");
                                                        break;
                                                    case "2":
                                                        fwrite($fh, "DELETE");
                                                        break;
                                                    case "3":
                                                        fwrite($fh, "OCENA");
                                                }
                                                fwrite($fh, "</tip_vnosa>"."\n");
                                                fwrite($fh, "      <udelezenec_id></udelezenec_id>"."\n");
                                                fwrite($fh, "      <opravilna_st>".$VOpravilnaSt."</opravilna_st>"."\n");
                                                fwrite($fh, "      <emso>".$R["emso"]."</emso>"."\n");
                                                fwrite($fh, "      <ime>".$R["Ime"]."</ime>"."\n");
                                                fwrite($fh, "      <priimek>".$R["Priimek"]."</priimek>"."\n");
                                                fwrite($fh, "      <kraj_rojstva>".$R["KrajRoj"]."</kraj_rojstva>"."\n");
                                                fwrite($fh, "      <drzava_rojstva>".$R["DrzavaRoj"]."</drzava_rojstva>"."\n");
                                                //poišče hišno številko:
                                                //razbije niz na osnovi presledka in od konca išče številko
                                                //ko številko najde, tvori niz iz delov do številke in hišno številko iz preostalega dela
                                                $sarr=explode(" ",$R["Naslov"]);
                                                $n=count($sarr);
                                                for ($i=count($sarr)-1;$i >= 0;$i--){
                                                    if (is_numeric($sarr[$i])){
                                                        $n=$i;
                                                        break;
                                                    }
                                                }
                                                
                                                $Naslov="";
                                                if ($n==count($sarr)){
                                                    $n=count($sarr)-1;
                                                }
                                                for ($i=0;$i < $n;$i++){
                                                    if (isset($sarr[$i])){
                                                        $Naslov=$Naslov." ".$sarr[$i];
                                                    }else{
                                                        $Naslov=$R["Naslov"];
                                                    }
                                                }
                                                $Naslov=trim($Naslov);
                                                $HSt="";
                                                for ($i=$n;$i < count($sarr);$i++){
                                                    $HSt=$HSt." ".$sarr[$i];
                                                }
                                                $HSt=trim($HSt);
                                                fwrite($fh, "      <ulica_stpr>".$Naslov."</ulica_stpr>"."\n");
                                                fwrite($fh, "      <hs_stpr>");
                                                fwrite($fh, $HSt."</hs_stpr>"."\n");
                                                
                                                fwrite($fh, "      <postna_st_stpr>".$R["Posta"]."</postna_st_stpr>"."\n");
                                                fwrite($fh, "      <kraj_stpr>".$R["Kraj"]."</kraj_stpr>"."\n");
                                                fwrite($fh, "      <ulica_zcpr></ulica_zcpr>"."\n");
                                                fwrite($fh, "      <hs_zcpr></hs_zcpr>"."\n");
                                                fwrite($fh, "      <postna_st_zcpr></postna_st_zcpr>"."\n");
                                                fwrite($fh, "      <kraj_zcpr></kraj_zcpr>"."\n");
                                                fwrite($fh, "      <drzavljanstvo>".$R["Drzavljanstvo"]."</drzavljanstvo>"."\n");
                                                fwrite($fh, "      <spol>");
                                                if ($R["Spol"]=="M"){
                                                    fwrite($fh, "M");
                                                }else{
                                                    fwrite($fh, "Ž");
                                                }
                                                fwrite($fh, "</spol>"."\n");
                                                fwrite($fh, "      <zavod_id>".$VSolaId."</zavod_id>"."\n");
                                                if (isDate($R["ZacSolanjaSola"])){
                                                    $DatumZ=new DateTime(isDate($R["ZacSolanjaSola"]));
                                                }else{
                                                    $DatumZ=new DateTime($VLeto."-09-01");
                                                }
                                                $DatumZ1=new DateTime($VLeto."-09-01");
                                                fwrite($fh, "      <zav_vpisan_od>".$DatumZ->format('Y-m-d')."</zav_vpisan_od>"."\n");
                                                
                                                if (isDate($R["KonSolanjaSola"])){
                                                    $DatumK=new DateTime(isDate($R["KonSolanjaSola"]));
                                                }else{
                                                    $DatumK=new DateTime(($VLeto+1)."-08-31");
                                                }
                                                $DatumK1=new DateTime(($VLeto+1)."-08-31");
                                                if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                                    fwrite($fh, "      <zav_vpisan_do>".$DatumK1->format('Y-m-d')."</zav_vpisan_do>"."\n");
                                                }
                                                
                                                fwrite($fh, "      <program_id>".$R["program"]."</program_id>\n");

                                                fwrite($fh, "      <prg_vpisan_od>".$DatumZ->format('Y-m-d')."</prg_vpisan_od>"."\n");
                                                if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                                    fwrite($fh, "      <prg_vpisan_do>".$DatumK1->format('Y-m-d')."</prg_vpisan_do>"."\n");
                                                    fwrite($fh, "      <datum_zaklj>".$DatumK1->format('Y-m-d')."</datum_zaklj>"."\n");
                                                }
                 
                                                fwrite($fh, "      <status_udel>UCE</status_udel>"."\n");
                                                fwrite($fh, "      <solsko_leto>".$VLeto."/".($VLeto+1)."</solsko_leto>"."\n");
                                                if ($R["razred"]==9){
                                                    fwrite($fh, "      <razred>16</razred>"."\n");
                                                }else{
                                                    fwrite($fh, "      <razred>".$R["razred"]."</razred>"."\n");
                                                }
                                                if (is_numeric(strpos($R["oznaka"],"komb"))){
                                                    fwrite($fh, "      <oddelek>KOMB.</oddelek>"."\n");
                                                }else{
                                                    fwrite($fh, "      <oddelek>".mb_strtoupper(mb_substr($R["oznaka"],0,1,$encoding),$encoding)."</oddelek>"."\n");
                                                }
                                                
                                                fwrite($fh, "      <let_vpisan_od>".$DatumZ1->format('Y-m-d')."</let_vpisan_od>"."\n");
                                                fwrite($fh, "      <let_vpisan_do>".$DatumK1->format('Y-m-d')."</let_vpisan_do>"."\n");
                                                fwrite($fh, "      <nacin_izb>");
                                                if ($R["Ponavljalec"]==0){
                                                    fwrite($fh, "RED");
                                                }else{
                                                    fwrite($fh, "PON");
                                                }
                                                fwrite($fh, "</nacin_izb>"."\n");
                                                fwrite($fh, "      <oblika_izb></oblika_izb>"."\n");
                                                if (($VTipVnosa=="3") && ($R["razred"]==9)){
                                                    fwrite($fh, "      <povpr_ocena>".str_replace(",",".",number_format($R["Uspeh"],2))."</povpr_ocena>"."\n");
                                                }
                                                $SQL = "SELECT malica,kosilo FROM tabprehrana WHERE iducenec=".$R["IdUcenec"]." AND leto=".$VLeto;
                                                $result1 = mysqli_query($link,$SQL);
                                                if ($R1 = mysqli_fetch_array($result1)){
                                                    if ($R1["malica"]){
                                                        fwrite($fh, "      <malica>DA</malica>\n");
                                                    }else{
                                                        fwrite($fh, "      <malica>NE</malica>\n");
                                                    }
                                                    if ($R1["kosilo"]){
                                                        fwrite($fh, "      <kosilo>DA</kosilo>\n");
                                                    }else{
                                                        fwrite($fh, "      <kosilo>NE</kosilo>\n");
                                                    }
                                                }
                                                fwrite($fh, "    </udelezenec>"."\n");
                                            }
                                        }       
                                    }
                                }
                        }
                        
                        fwrite($fh, "  </udelezenci>"."\n");
                        fwrite($fh, "</ceuviz_uvoz>"."\n");
                        fclose($fh);
                        
                        echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
                        echo "<h3>Shrani datoteko <a href='".$MyFile."'>".$VFile."</a></h3>";
                        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                        break;
                    case "2": // 'izbor učencev
                        $VOpravilnaSt=$_POST["opravilnast"];
                        $VOperacija=$_POST["operacija"];
                        $VTipVnosa=$_POST["tipvnosa"];
                        $VSkupina=$_POST["skupina"];
                        //$VProgram=$_POST["program"];
                        
                        switch ($VSkupina){
                            case "1": // 'vsi učenci
                                echo "<form  name='ceuviz' method=post action='priprava.php'>";
                                echo "<input name='idd' type='hidden' value='600'>";
                                echo "<b>Opravilna številka:</b> <input name='opravilnast' type='hidden' value='".$VOpravilnaSt."'>".$VOpravilnaSt."<br />";
                                switch ($VOperacija){
                                    case "1":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='1'>Kontrolni prenos podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='2'>Vpis podatkov<br />";
                                }
                                echo "<b>Tip vnosa podatkov:</b> ";
                                switch ($VTipVnosa){
                                    case "1":
                                        echo "<input name='tipvnosa' type='hidden' value='1'>Vstavljanje novih podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<input name='tipvnosa' type='hidden' value='2'>Brisanje podatkov za izbrane učence<br />";
                                        break;
                                    case "3":
                                        echo "<input name='tipvnosa' type='hidden' value='3'>Vpis povprečnih ocen za učence devetih razredov<br />";
                                        break;
                                }
                                echo "<b>Način izbora ciljne skupine učencev:</b> <input name='skupina' type='hidden' value='1'>Vsi učenci<br />";
                                echo "<input name='id' type='hidden' value='1'>";
                                echo "<input name='submit' type='submit' value='Pošlji'>";
                                echo "</form><br />";
                                break;
                            case "2": // 'samo deveti
                                echo "<form  name='ceuviz' method=post action='priprava.php'>";
                                echo "<input name='idd' type='hidden' value='600'>";
                                echo "<b>Opravilna številka:</b> <input name='opravilnast' type='hidden' value='".$VOpravilnaSt."'>".$VOpravilnaSt."<br />";
                                switch ($VOperacija){
                                    case "1":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='1'>Kontrolni prenos podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='2'>Vpis podatkov<br />";
                                        break;
                                }
                                echo "<b>Tip vnosa podatkov:</b> ";
                                switch ($VTipVnosa){
                                    case "1":
                                        echo "<input name='tipvnosa' type='hidden' value='1'>Vstavljanje novih podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<input name='tipvnosa' type='hidden' value='2'>Brisanje podatkov za izbrane učence<br />";
                                        break;
                                    case "3":
                                        echo "<input name='tipvnosa' type='hidden' value='3'>Vpis povprečnih ocen za učence devetih razredov<br />";
                                }
                                echo "<b>Način izbora ciljne skupine učencev:</b> <input name='skupina' type='hidden' value='2'>Učenci devetih razredov<br />";
                                echo "<input name='id' type='hidden' value='1'>";
                                echo "<input name='submit' type='submit' value='Pošlji'>";
                                echo "</form><br />";
                                break;
                            case "3": // 'določeni
                                echo "<form  name='ceuviz' method=post action='priprava.php'>";
                                echo "<input name='idd' type='hidden' value='600'>";
                                echo "<b>Opravilna številka:</b> <input name='opravilnast' type='hidden' value='".$VOpravilnaSt."'>".$VOpravilnaSt."<br />";
                                switch ($VOperacija){
                                    case "1":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='1'>Kontrolni prenos podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<b>Način prenosa podatkov:</b> <input name='operacija' type='hidden' value='2'>Vpis podatkov<br />";
                                }
                                echo "<b>Tip vnosa podatkov:</b> ";
                                switch ($VTipVnosa){
                                    case "1":
                                        echo "<input name='tipvnosa' type='hidden' value='1'>Vstavljanje novih podatkov<br />";
                                        break;
                                    case "2":
                                        echo "<input name='tipvnosa' type='hidden' value='2'>Brisanje podatkov za izbrane učence<br />";
                                        break;
                                    case "3":
                                        echo "<input name='tipvnosa' type='hidden' value='3'>Vpis povprečnih ocen za učence devetih razredov<br />";
                                }
                                echo "<b>Način izbora ciljne skupine učencev:</b> <input name='skupina' type='hidden' value='3'>Izbrani učenci<br />";
                                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabrazdat.razred,tabrazdat.oznaka FROM ";
                                $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                                $SQL = $SQL . " INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                                $SQL = $SQL . " WHERE tabrazdat.leto=".$VLeto." ";
                                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,priimek,ime";
                                $result = mysqli_query($link,$SQL);
                                $Indx=0;
                                while ($R = mysqli_fetch_array($result)){
                                    $Indx=$Indx+1;
                                    echo "<input name='cb_".$Indx."' type='checkbox'><input name='uc_".$Indx."' type='hidden' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." (".$R["emso"].")"."<br />";
                                }
                                echo "<input name='stucencev' type='hidden' value='".$Indx."'>";
                                echo "<input name='id' type='hidden' value='1'>";
                                echo "<input name='submit' type='submit' value='Pošlji'>";
                                echo "</form><br />";
                        }
                        break;
                    default:
                    //' določitev podatkov (opravilna številka, tip komunikacije)
                        echo "<p>Za uspešen prenos podatkov morajo imeti učenci vnesene <b>EMŠO</b> številke!</p>";
                        echo "<p>Na Portalu za vnos v CEUVIZ <b>najprej</b> vnesite razrede in oddelke (tam najdete tudi ID izobraževalnega programa)</p>";
                        echo "<h3>Program izobraževanja učencev vpišite <a href='vnosispiski.php?idd=118'>\"tule\"</a>. Izračun končnih povprečnih ocen pa <a href='priprava.php?idd=300'>\"tule\"</a></h3>";
                        echo "<form  name='ceuviz' method=post action='priprava.php'>";
                        echo "<input name='idd' type='hidden' value='600'>";
                        echo "<b>Opravilna številka:</b> <input name='opravilnast' type='text' size='25' maxlength='25'> (zaradi lastne evidence v primeru pojasnjevanja dostopov do registra prebivalcev)<br />";
                        echo "<b>Način prenosa podatkov:</b> <br />";
                        echo "<input name='operacija' type='radio' value='1'>Kontrolni prenos podatkov<br />";
                        echo "<input name='operacija' type='radio' value='2'>Vpis podatkov<br />";
                        echo "<b>Tip vnosa podatkov:</b> <br />";
                        echo "<input name='tipvnosa' type='radio' value='1'>Vstavljanje novih podatkov<br />";
                        echo "<input name='tipvnosa' type='radio' value='2'>Brisanje podatkov za izbrane učence<br />";
                        echo "<input name='tipvnosa' type='radio' value='3'>Vpis povprečnih ocen za učence devetih razredov<br />";
                        echo "<b>Način izbora ciljne skupine učencev:</b> <br />";
                        echo "<input name='skupina' type='radio' value='1'>Vsi učenci<br />";
                        echo "<input name='skupina' type='radio' value='2'>Učenci devetih razredov<br />";
                        echo "<input name='skupina' type='radio' value='3'>Izbrani učenci<br />";
                        echo "<input name='id' type='hidden' value='2'>";
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form><br />";
                }
            }
            break;
        case "610": //uvoz ceuviz
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            echo "<form method='post' ENCTYPE='multipart/form-data' action='priprava.php'>";
            echo "<input name='idd' type='hidden' value='620'>";
            echo "<input name='servaddr' type='hidden' value='".$_SERVER["SERVER_ADDR"]."'>";
            echo "<h2>Uvoz podatkov iz CEUVIZ (XML)</h2>";
            echo "<table border=0><tr>";
            echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
            echo "<input name='Povezava' type='hidden' value='/'>";
            echo "</table>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "620": //import ceuviz
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            $uploaded=false;
            $allowedExts = array("txt", "csv","xml");
            $Preneseno=$_FILES["file"];
            $extension = explode(".", $Preneseno["name"]);
            $extension = end($extension);
            $extension = strtolower($extension);
            if (($_FILES["file"]["size"] < 2000000) && in_array($extension, $allowedExts)){
                    if ($_FILES["file"]["error"] > 0){
                        echo "Napaka: " . $_FILES["file"]["error"] . "<br />";
                    }else{
                        echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                        echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                        echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                        echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
                 
                        if (file_exists("dato/" . $_FILES["file"]["name"])){
                            echo $_FILES["file"]["name"] . " že obstaja. ";
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }else{
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }
                   }
            }else{
                echo "Napačna datoteka";
            }
            echo "<br />";
            $StUcencevIndx=0;
            if ($uploaded){
                $myFile = "dato/".$_FILES["file"]["name"];
                $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
                $VServer=$_POST["servaddr"];
                $indx=0;
                while(!feof($fh)){
                   //echo fgets($file). "<br />";
                   $Vrstica[$indx]=fgets($fh);
                   $indx=$indx+1;
                }
                $StVrstic=$indx-1;
                fclose($fh);

                $fh = fopen($myFile,'w') or die("Ne morem odpreti datoteke!");
                for ($Indx=0;$Indx <= $StVrstic;$Indx++){
                    $Vrstica[$Indx]=str_replace("<kraj_rojstva/>","<kraj_rojstva> </kraj_rojstva>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<drzava_rojstva/>","<drzava_rojstva> </drzava_rojstva>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<ulica_stpr/>","<ulica_stpr> </ulica_stpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<hs_stpr/>","<hs_stpr> </hs_stpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<postna_st_stpr/>","<postna_st_stpr>0</postna_st_stpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<kraj_stpr/>","<kraj_stpr> </kraj_stpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<ulica_zcpr/>","<ulica_zcpr> </ulica_zcpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<hs_zcpr/>","<hs_zcpr> </hs_zcpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<postna_st_zcpr/>","<postna_st_zcpr>0</postna_st_zcpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<kraj_zcpr/>","<kraj_zcpr> </kraj_zcpr>",$Vrstica[$Indx]);
                    $Vrstica[$Indx]=str_replace("<drzavljanstvo/>","<drzavljanstvo> </drzavljanstvo>",$Vrstica[$Indx]);
                    fwrite($fh,$Vrstica[$Indx]);
                }
                fclose($fh);

                $db = readDatabase($myFile);
                //echo "** Database of Učenci-CEUVIZ objects:\n";
                //print_r($db);
                echo "<h2>Uvoz podatkov iz CEUVIZ</h2>";
                for ($Indx=0;$Indx < count($db);$Indx++){
                    $SQL = "SELECT id,iducenec FROM tabucenci WHERE emso='".$db[$Indx]->emso."'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'ima učenca
                        
                        //'update
                        $SQL = "UPDATE tabucenci SET ";
                        $SQL = $SQL . "priimek='".$db[$Indx]->priimek."'";
                        $SQL = $SQL . ",ime='".$db[$Indx]->ime."'";
                        if (isset($db[$Indx]->kraj_rojstva)) $SQL = $SQL . ",KrajRoj='".$db[$Indx]->kraj_rojstva."'";
                        if (isset($db[$Indx]->drzava_rojstva)) $SQL = $SQL . ",DrzavaRoj='".$db[$Indx]->drzava_rojstva."'";
                        if (isset($db[$Indx]->drzavljanstvo)) $SQL = $SQL . ",Drzavljanstvo='".$db[$Indx]->drzavljanstvo."'";
                        if (isset($db[$Indx]->ulica_stpr)) $SQL = $SQL . ",Naslov='".$db[$Indx]->ulica_stpr." ".$db[$Indx]->hs_stpr."'";
                        if (isset($db[$Indx]->postna_st_stpr)) $SQL = $SQL . ",Posta=".$db[$Indx]->postna_st_stpr;
                        if (isset($db[$Indx]->kraj_stpr)) $SQL = $SQL . ",Kraj='".$db[$Indx]->kraj_stpr."'";
                        if (isset($db[$Indx]->ulica_zcpr)) $SQL = $SQL . ",NaslovZac='".$db[$Indx]->ulica_zcpr." ".$db[$Indx]->hs_zcpr."'";
                        if (isset($db[$Indx]->postna_st_zcpr)) $SQL = $SQL . ",PostaZac=".$db[$Indx]->postna_st_zcpr;
                        if (isset($db[$Indx]->kraj_zcpr)) $SQL = $SQL . ",KrajZac='".$db[$Indx]->kraj_zcpr."'";
                        if (isset($db[$Indx]->prg_vpisan_od)) {
                            $Datum=new DateTime($db[$Indx]->prg_vpisan_od);
                            $SQL = $SQL . ",ZacSolanja='".$Datum->format('j.n.Y')."'";
                        }
                        if (isset($db[$Indx]->zav_vpisan_od)) {
                            $Datum=new DateTime($db[$Indx]->zav_vpisan_od);
                            $SQL = $SQL . ",ZacSolanjaSola='".$Datum->format('j.n.Y')."'";
                        }
                        $SQL = $SQL . " WHERE id=".$R["id"];
                        $result1 = mysqli_query($link,$SQL);
                        echo "Popravljeni podatki za: ".$db[$Indx]->priimek." ".$db[$Indx]->ime." (".$db[$Indx]->emso.")<br />";
                        
                        //popravi še razredni vpis
                        //prebere šolsko leto
                        $UcSolLeto=explode("/",$db[$Indx]->solsko_leto);
                        $UcRazred=intval($db[$Indx]->razred);
                        if ($UcRazred == 16) $UcRazred=9;
                        $SQL = "SELECT id FROM tabrazred WHERE iducenec=".$R["iducenec"]." AND leto=".$UcSolLeto[0];
                        $result2 = mysqli_query($link,$SQL);
                        if ($R2 = mysqli_fetch_array($result2)){
                            //preveri če obstaja vpisan razred v tabrazdat
                            $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                            $result3 = mysqli_query($link,$SQL);
                            if ($R3 = mysqli_fetch_array($result3)){
                                $SQL = "UPDATE tabrazred set razred=".$UcRazred.",paralelka='".strtolower($db[$Indx]->oddelek)."'";
                                if ($db[$Indx]->nacin_izb == "RED"){
                                    $SQL = $SQL . ",ponavljalec=0";
                                }else{
                                    $SQL = $SQL . ",ponavljalec=1";
                                }
                                $SQL = $SQL . ",idrazred=".$R3["id"];
                                $SQL = $SQL . " WHERE id=".$R2["id"];
                                if (!($result4 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
                            }else{ //razred ne obstaja - kreira novega
                                $SQL = "INSERT INTO tabrazdat (razred,oznaka,leto,prostor,osemdevet,idsola) VALUES (".$UcRazred.",'".strtolower($db[$Indx]->oddelek)."',".$UcSolLeto[0].",0,9,1)";
                                $result3 = mysqli_query($link,$SQL);
                                
                                //ponovno prebere zaradi id številke razreda
                                $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."'";
                                $result3 = mysqli_query($link,$SQL);
                                if ($R3 = mysqli_fetch_array($result3)){
                                    //vpiše popravljene podatke
                                    $SQL = "UPDATE tabrazred set razred=".$UcRazred.",paralelka='".strtolower($db[$Indx]->oddelek)."'";
                                    if ($db[$Indx]->nacin_izb == "RED"){
                                        $SQL = $SQL . ",ponavljalec=0";
                                    }else{
                                        $SQL = $SQL . ",ponavljalec=1";
                                    }
                                    $SQL = $SQL . ",idrazred=".$R3["id"];
                                    $SQL = $SQL . " WHERE id=".$R2["id"];
                                    if (!($result4 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu!<br />$SQL<br />";
                                    }
                                }
                            }   
                        }else{
                            //vpisa za razred še ni
                            //pogleda, če so podatki v tabrazdat sploh že vpisani
                            $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                            $result3 = mysqli_query($link,$SQL);
                            if ($R3 = mysqli_fetch_array($result3)){
                                //so vpisani - vpiše zapis v tabrazred
                                $SQL = "INSERT INTO tabrazred (leto,razred,paralelka,osemdevet,iducenec,uspeh,uspehpol,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,letosolanja,iducitelj,idvzgojitelj,vpisal,datumvpisa,evidst,datumizdaje,idrazred,opomba,slika) VALUES ";
                                $SQL = $SQL . "(";
                                $SQL = $SQL . $UcSolLeto[0];
                                $SQL = $SQL . ",".$UcRazred;
                                $SQL = $SQL . ",'".strtolower($db[$Indx]->oddelek)."'";
                                $SQL = $SQL . ",9";
                                $SQL = $SQL . ",".$R["iducenec"];
                                $SQL = $SQL . ",0.0,0";
                                if ($db[$Indx]->nacin_izb == "RED"){
                                    $SQL = $SQL . ",0";
                                }else{
                                    $SQL = $SQL . ",1";
                                }
                                $SQL = $SQL . ",0,0,0,0,0";
                                //leto šolanja je kar razred
                                $SQL = $SQL . ",".$UcRazred;
                                $SQL = $SQL . ",0,0,'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."','','',".$R3["id"].",'',''";
                                $SQL = $SQL . ")";
                                if (!($result4 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
                            }else{
                                //niso vpisani - vpiše
                                $SQL = "INSERT INTO tabrazdat (razred,oznaka,leto,prostor,osemdevet,idsola) VALUES (".$UcRazred.",'".strtolower($db[$Indx]->oddelek)."',".$UcSolLeto[0].",0,9,1)";
                                $result3 = mysqli_query($link,$SQL);
                                
                                //doda še vpis v tabrazred
                                $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                                $result3 = mysqli_query($link,$SQL);
                                if ($R3 = mysqli_fetch_array($result3)){
                                    //so vpisani - vpiše zapis v tabrazred
                                    $SQL = "INSERT INTO tabrazred (leto,razred,paralelka,osemdevet,iducenec,uspeh,uspehpol,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,letosolanja,iducitelj,idvzgojitelj,vpisal,datumvpisa,evidst,datumizdaje,idrazred,opomba,slika) VALUES ";
                                    $SQL = $SQL . "(";
                                    $SQL = $SQL . $UcSolLeto[0];
                                    $SQL = $SQL . ",".$UcRazred;
                                    $SQL = $SQL . ",'".strtolower($db[$Indx]->oddelek)."'";
                                    $SQL = $SQL . ",9";
                                    $SQL = $SQL . ",".$R["iducenec"];
                                    $SQL = $SQL . ",0.0,0";
                                    if ($db[$Indx]->nacin_izb == "RED"){
                                        $SQL = $SQL . ",0";
                                    }else{
                                        $SQL = $SQL . ",1";
                                    }
                                    $SQL = $SQL . ",0,0,0,0,0";
                                    //leto šolanja je kar razred
                                    $SQL = $SQL . ",".$UcRazred;
                                    $SQL = $SQL . ",0,0,'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."','','',".$R3["id"].",'',''";
                                    $SQL = $SQL . ")";
                                    if (!($result4 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu!<br />$SQL<br />";
                                    }
                                }
                            }
                        }
                    }else{
                        //'nima učenca - insert
                        $StUcencevIndx=$StUcencevIndx+1;
                        $DatRoj=substr($db[$Indx]->emso,0,2) . "." . substr($db[$Indx]->emso,2,2) . ".";
                        if (intval(substr($db[$Indx]->emso,4,3)) < 900){
                            $DatRoj=$DatRoj."2".substr($db[$Indx]->emso,4,3);
                            $LetoRoj="2".substr($db[$Indx]->emso,4,3);
                        }else{
                            $DatRoj=$DatRoj."1".substr($db[$Indx]->emso,4,3);
                            $LetoRoj="1".substr($db[$Indx]->emso,4,3);
                        }
                        $Spol=substr($db[$Indx]->emso,9,1);
                        if (intval($Spol) > 4){
                            $Spol="F";
                        }else{
                            $Spol="M";
                        }
                        
                        $Datum=new DateTime(isDate($DatRoj));
                        $SQL = "INSERT INTO tabucenci (idUcenec,priimek,ime,emso,spol,letoroj,DatRoj,KrajRoj,DrzavaRoj,Drzavljanstvo,Naslov,Posta,Kraj,NaslovZac,PostaZac,KrajZac,ZacSolanja,ZacSolanjaSola)";
                        $SQL = $SQL . " VALUES (";
                        $SQL = $SQL . $StUcencevIndx;
                        $SQL = $SQL . ",'".$db[$Indx]->priimek."'";
                        $SQL = $SQL . ",'".$db[$Indx]->ime."'";
                        $SQL = $SQL . ",'".$db[$Indx]->emso."'";
                        $SQL = $SQL . ",'".$Spol."'";
                        $SQL = $SQL . ",".$LetoRoj;
                        $SQL = $SQL . ",'".$Datum->format('Y-m-d')."'";
                        $SQL = $SQL . ",'".$db[$Indx]->kraj_rojstva."'";
                        $SQL = $SQL . ",'".$db[$Indx]->drzava_rojstva."'";
                        $SQL = $SQL . ",'".$db[$Indx]->drzavljanstvo."'";
                        $SQL = $SQL . ",'".$db[$Indx]->ulica_stpr." ".$db[$Indx]->hs_stpr."'";
                        $SQL = $SQL . ",".$db[$Indx]->postna_st_stpr;
                        $SQL = $SQL . ",'".$db[$Indx]->kraj_stpr."'";
                        $SQL = $SQL . ",'".$db[$Indx]->ulica_zcpr." ".$db[$Indx]->hs_zcpr."'";
                        $SQL = $SQL . ",".$db[$Indx]->postna_st_zcpr;
                        $SQL = $SQL . ",'".$db[$Indx]->kraj_zcpr."'";
                        if (isset($db[$Indx]->prg_vpisan_od)) {
                            $Datum=new DateTime($db[$Indx]->prg_vpisan_od);
                            $SQL = $SQL . ",'".$Datum->format('j.n.Y')."'";
                        }else{
                            $SQL = $SQL . ",''";
                        }
                        if (isset($db[$Indx]->zav_vpisan_od)) {
                            $Datum=new DateTime($db[$Indx]->zav_vpisan_od);
                            $SQL = $SQL . ",'".$Datum->format('j.n.Y')."'";
                        }else{
                            $SQL = $SQL . ",''";
                        }
                        $SQL = $SQL . ")";
                        if (!($result1 = mysqli_query($link,$SQL))){
                            echo "Napaka pri vpisu!<br />$SQL<br />";
                        }
                        echo "Nov vpis za: ".$db[$Indx]->priimek." ".$db[$Indx]->ime." (".$db[$Indx]->emso.")<br />";

                        $SQL = "SELECT id,iducenec FROM tabucenci WHERE emso='".$db[$Indx]->emso."'";
                        $result = mysqli_query($link,$SQL);
                        $R = mysqli_fetch_array($result);
                        
                        //popravi še razredni vpis
                        //prebere šolsko leto
                        $UcSolLeto=explode("/",$db[$Indx]->solsko_leto);
                        $UcRazred=intval($db[$Indx]->razred);
                        if ($UcRazred == 16) $UcRazred=9;
                        $SQL = "SELECT id FROM tabrazred WHERE iducenec=".$R["iducenec"]." AND leto=".$UcSolLeto[0];
                        $result2 = mysqli_query($link,$SQL);
                        if ($R2 = mysqli_fetch_array($result2)){
                            //preveri če obstaja vpisan razred v tabrazdat
                            $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                            $result3 = mysqli_query($link,$SQL);
                            if ($R3 = mysqli_fetch_array($result3)){
                                $SQL = "UPDATE tabrazred set razred=".$UcRazred.",paralelka='".strtolower($db[$Indx]->oddelek)."'";
                                if ($db[$Indx]->nacin_izb == "RED"){
                                    $SQL = $SQL . ",ponavljalec=0";
                                }else{
                                    $SQL = $SQL . ",ponavljalec=1";
                                }
                                $SQL = $SQL . ",idrazred=".$R3["id"];
                                $SQL = $SQL . " WHERE id=".$R2["id"];
                                if (!($result4 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
                            }else{ //razred ne obstaja - kreira novega
                                $SQL = "INSERT INTO tabrazdat (razred,oznaka,leto,prostor,osemdevet,idsola) VALUES (".$UcRazred.",'".strtolower($db[$Indx]->oddelek)."',".$UcSolLeto[0].",0,9,1)";
                                if (!($result3 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
                                
                                //ponovno prebere zaradi id številke razreda
                                $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                                $result3 = mysqli_query($link,$SQL);
                                if ($R3 = mysqli_fetch_array($result3)){
                                    //vpiše popravljene podatke
                                    $SQL = "UPDATE tabrazred set razred=".$UcRazred.",paralelka='".strtolower($db[$Indx]->oddelek)."'";
                                    if ($db[$Indx]->nacin_izb == "RED"){
                                        $SQL = $SQL . ",ponavljalec=0";
                                    }else{
                                        $SQL = $SQL . ",ponavljalec=1";
                                    }
                                    $SQL = $SQL . ",idrazred=".$R3["id"];
                                    $SQL = $SQL . " WHERE id=".$R2["id"];
                                    if (!($result4 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu!<br />$SQL<br />";
                                    }
                                }
                            }   
                        }else{
                            //vpisa za razred še ni
                            //pogleda, če so podatki v tabrazdat sploh že vpisani
                            $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."' AND leto=".$UcSolLeto[0];
                            $result3 = mysqli_query($link,$SQL);
                            if ($R3 = mysqli_fetch_array($result3)){
                                //so vpisani - vpiše zapis v tabrazred
                                $SQL = "INSERT INTO tabrazred (leto,razred,paralelka,osemdevet,iducenec,uspeh,uspehpol,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,letosolanja,iducitelj,idvzgojitelj,vpisal,datumvpisa,evidst,datumizdaje,idrazred,opomba,slika) VALUES ";
                                $SQL = $SQL . "(";
                                $SQL = $SQL . $UcSolLeto[0];
                                $SQL = $SQL . ",".$UcRazred;
                                $SQL = $SQL . ",'".strtolower($db[$Indx]->oddelek)."'";
                                $SQL = $SQL . ",9";
                                $SQL = $SQL . ",".$R["iducenec"];
                                $SQL = $SQL . ",0.0,0";
                                if ($db[$Indx]->nacin_izb == "RED"){
                                    $SQL = $SQL . ",0";
                                }else{
                                    $SQL = $SQL . ",1";
                                }
                                $SQL = $SQL . ",0,0,0,0,0";
                                //leto šolanja je kar razred
                                $SQL = $SQL . ",".$UcRazred;
                                $SQL = $SQL . ",0,0,'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."','','',".$R3["id"].",'',''";
                                $SQL = $SQL . ")";
                                if (!($result4 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
                            }else{
                                //niso vpisani - vpiše
                                $SQL = "INSERT INTO tabrazdat (razred,oznaka,leto,prostor,osemdevet,idsola) VALUES (".$UcRazred.",'".strtolower($db[$Indx]->oddelek)."',".$UcSolLeto[0].",0,9,1)";
                                if (!($result3 = mysqli_query($link,$SQL))){
                                    echo "Napaka pri vpisu!<br />$SQL<br />";
                                }
            
                                //doda še vpis v tabrazred
                                $SQL = "SELECT id FROM tabrazdat WHERE razred=".$UcRazred." AND oznaka='".strtolower($db[$Indx]->oddelek)."'";
                                $result3 = mysqli_query($link,$SQL);
                                if ($R3 = mysqli_fetch_array($result3)){
                                    //so vpisani - vpiše zapis v tabrazred
                                    $SQL = "INSERT INTO tabrazred (leto,razred,paralelka,osemdevet,iducenec,uspeh,uspehpol,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,letosolanja,iducitelj,idvzgojitelj,vpisal,datumvpisa,evidst,datumizdaje,idrazred,opomba,slika) VALUES ";
                                    $SQL = $SQL . "(";
                                    $SQL = $SQL . $UcSolLeto[0];
                                    $SQL = $SQL . ",".$UcRazred;
                                    $SQL = $SQL . ",'".strtolower($db[$Indx]->oddelek)."'";
                                    $SQL = $SQL . ",9";
                                    $SQL = $SQL . ",".$R["iducenec"];
                                    $SQL = $SQL . ",0.0,0";
                                    if ($db[$Indx]->nacin_izb == "RED"){
                                        $SQL = $SQL . ",0";
                                    }else{
                                        $SQL = $SQL . ",1";
                                    }
                                    $SQL = $SQL . ",0,0,0,0,0";
                                    //leto šolanja je kar razred
                                    $SQL = $SQL . ",".$UcRazred;
                                    $SQL = $SQL . ",0,0,'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."','','',".$R3["id"].",'',''";
                                    $SQL = $SQL . ")";
                                    if (!($result4 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu!<br />$SQL<br />";
                                    }
                                }
                            }
                        }
                    }
                    //response.write SQL & "<br />"
                }
            }     
            break;
        case "650": //uvoz šifer VASCO
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            echo "<form method='post' ENCTYPE='multipart/form-data' action='priprava.php'>";
            echo "<input name='idd' type='hidden' value='660'>";
            echo "<input name='servaddr' type='hidden' value='".$_SERVER["SERVER_ADDR"]."'>";
            echo "<h2>Uvoz šifer učencev za prehrano - Vasco (XML)</h2>";
            echo "<table border=0><tr>";
            echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
            echo "<input name='Povezava' type='hidden' value='/'>";
            echo "</table>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "660": //import šifer VASCO
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            $uploaded=false;
            $allowedExts = array("txt", "csv","xml");
            $Preneseno=$_FILES["file"];
            $extension = explode(".", $Preneseno["name"]);
            $extension = end($extension);
            $extension = strtolower($extension);
            if (($_FILES["file"]["size"] < 700000) && in_array($extension, $allowedExts)){
                    if ($_FILES["file"]["error"] > 0){
                        echo "Koda: " . $_FILES["file"]["error"] . "<br />";
                    }else{
                        echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                        echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                        echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                        echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
                 
                        if (file_exists("dato/" . $_FILES["file"]["name"])){
                            echo $_FILES["file"]["name"] . " že obstaja. ";
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }else{
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }
                   }
            }else{
                echo "Napačna datoteka!";
            }
            echo "<br />";
            if ($uploaded){
                $myFile = "dato/".$_FILES["file"]["name"];
                $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
                $VServer=$_POST["servaddr"];
                $indx=0;
                while(!feof($fh)){
                   //echo fgets($file). "<br />";
                   $Vrstica[$indx]=fgets($fh);
                   $indx=$indx+1;
                }
                $StVrstic=$indx-1;
                fclose($fh);

                $db = readDatabaseVasco($myFile);
                //echo "** Database of Učenci-CEUVIZ objects:\n";
                //print_r($db);
                echo "<h2>Uvoz podatkov iz Vasco</h2>";
                $SQL = "DELETE FROM tabvasco WHERE id > 0";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Ne morem pobrisati Vasco tabele!<br />$SQL <br />");
                }else{
                    for ($Indx=0;$Indx < count($db);$Indx++){
                        $emso=trim($db[$Indx]->MaticnaStevilka);
                        $SQL = "SELECT iducenec FROM tabucenci WHERE emso='".$emso."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            //'ima učenca
                            $SQL = "INSERT INTO tabvasco (iducenec,sifra)";
                            $SQL = $SQL . " VALUES (";
                            $SQL = $SQL . $R["iducenec"];
                            $SQL = $SQL . ",'".$db[$Indx]->Sifra."'";
                            $SQL = $SQL . ")";
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu v tabvasco!<br />$SQL<br />");
                            }
                        }else{
                            echo "Učenec ".$db[$Indx]->Priimek." ".$db[$Indx]->Ime." ".$db[$Indx]->MaticnaStevilka." ".$db[$Indx]->Razred." ni vpisan v Kadre!<br />";
                        }
                    }
                    echo "<h3>Šifre učencev so vpisane.</h3>";
                }
            }     
            break;
        case "700": //export MŠŠ prehrana
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            $VFile="podatkiucencev.xml";
            $myFile = "dato/".$VFile;

            $fh = fopen($myFile,'w') or die("Ne morem odpreti log datoteke!");

            fwrite($fh, "<"."?xml version=".chr(34)."1.0".chr(34)." encoding=".chr(34)."utf-8".chr(34)."?".">"."\n");
            fwrite($fh, "<PupilRegistry xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34)." xmlns:xsd=".chr(34)."http://www.w3.org/2001/XMLSchema".chr(34)." xmlns=".chr(34)."http://hsl.com/edfood/xsd/PupilRegistryDataContract".chr(34).">"."\n");

            echo "<h3>Izvoz podatkov o učencih za subvencije prehrane</h3>";
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSolaId=substr($R["UstanovaIDmin"],0,7);
            }else{
                $VSolaId=" ";
            }

            fwrite($fh, "  <CommonData internalUse=".chr(34)."true".chr(34)." ZavPrsId=".chr(34).$VSolaId.chr(34)." ZavMssId=".chr(34)."000".chr(34).">"."\n");
            fwrite($fh, "    <EncryptedPupilNumbers />"."\n");
            fwrite($fh, "  </CommonData>"."\n");

            $SQL = "SELECT tabrazred.*,tabucenci.* FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);

            fwrite($fh, "  <Registry>"."\n");

            while ($R = mysqli_fetch_array($result)){
                fwrite($fh, "    <Record>"."\n");
                fwrite($fh, "      <LegalGuardian Name=".chr(34).$R["mati"].chr(34)." Surname=".chr(34).chr(34)." StreetAddr=".chr(34).$R["matinaslov"].chr(34)." AddrNo=".chr(34).chr(34)." PostalCode=".chr(34)."0".chr(34)." PostName=".chr(34).chr(34)." Relation=".chr(34)."1".chr(34)." />"."\n");
                fwrite($fh, "      <LegalGuardian Name=".chr(34).$R["oce"].chr(34)." Surname=".chr(34).chr(34)." StreetAddr=".chr(34).$R["ocenaslov"].chr(34)." AddrNo=".chr(34).chr(34)." PostalCode=".chr(34)."0".chr(34)." PostName=".chr(34).chr(34)." Relation=".chr(34)."2".chr(34)." />"."\n");
                fwrite($fh, "      <Pupil Identifier=".chr(34).$R["emso"].chr(34)." Name=".chr(34).$R["Ime"].chr(34)." Surname=".chr(34).$R["Priimek"].chr(34)." StreetAddr=".chr(34).$R["Naslov"].chr(34)." AddrNo=".chr(34).chr(34)." PostalCode=".chr(34).$R["Posta"].chr(34)." PostName=".chr(34).$R["Kraj"].chr(34)." HasPermAddr=".chr(34)."true".chr(34)." ZavPrsId=".chr(34).chr(34)." ZavMssId=".chr(34).chr(34)." ProgEnid=".chr(34)."0".chr(34)." ProgEnidDod=".chr(34)."".chr(34)." Class=".chr(34).$R["Razred"].chr(34)." Department=".chr(34).$R["Paralelka"].chr(34)." />"."\n");
                fwrite($fh, "    </Record>"."\n");
            }

            fwrite($fh, "  </Registry>"."\n");
            fwrite($fh, "  <SubEdInst ZavPrsId=".chr(34).$VSolaId.chr(34)." ZavMssId=".chr(34)."000".chr(34)." ProgEnid=".chr(34)."0".chr(34)." ProgEnidDod=".chr(34).chr(34)." />"."\n");
            fwrite($fh, "</PupilRegistry>"."\n");

            fclose($fh);          

            echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
            echo "<h3><a href='".$myFile."'>Shrani datoteko ".$VFile."</a></h3>";
            echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
            break;
        case "800": //izvoz kadri
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }
            $VFile="podatkiucencevkadri.csv";

            echo "<h2>Izvoz podatkov o učencih iz Kadrov</h2>";

            switch ($Vid){
                case "1": // 'kreiranje datoteke
                    $myFile = "dato/".$VFile;

                    $fh = fopen($myFile,'w') or die("Ne morem odpreti log datoteke!");

                    fwrite($fh, "ID;IdUcenec;");
                    fwrite($fh, "Priimek;Ime;DatRoj;KrajRoj;DrzavaRoj;Drzavljanstvo;emso;MaticniList;MaticnaKnjiga;Naslov;Posta;Kraj;");
                    fwrite($fh, "oce;ocenaslov;ocekontakt;oceemail;mati;matinaslov;matikontakt;matiemail;Aktivnost;LetoRoj;IdKrajBivanja;Spol;");
                    fwrite($fh, "IdPosebnePotrebe;Bivanje;Rom;ZacSolanja;KonSolanja;ZacSolanjaSola;KonSolanjaSola;Skrbniki;SkrbnikiNaslov;SkrbnikiKontakt;");
                    //fwrite($fh, "Skrbnikiemail;Placnik;PlacnikNaslov;PlacnikKontakt;Opombe;OSobveza"."\n");
                    //fwrite($fh, " ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; "."\n");
                    fwrite($fh, "Skrbnikiemail;Placnik;PlacnikNaslov;PlacnikKontakt;Opombe;OSobveza;razred"."\n");
                    fwrite($fh, " ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; ; "."\n");
                    
                    for ($Indx=1;$Indx <= 9;$Indx++){
                        if (isset($_POST["cb_".$Indx])){
                            $SQL = "SELECT tabucenci.*,tabrazred.razred,tabrazred.paralelka FROM tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec WHERE leto=".$VLeto." AND razred=".$Indx;
                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                fwrite($fh, $R["ID"].";");
                                fwrite($fh, $R["IdUcenec"].";");
                                fwrite($fh, $R["Priimek"].";");
                                fwrite($fh, $R["Ime"].";");
                                $Datum=new DateTime(isDate($R["DatRoj"]));
                                fwrite($fh, $Datum->format('Y-m-d').";");
                                fwrite($fh, $R["KrajRoj"].";");
                                fwrite($fh, $R["DrzavaRoj"].";");
                                fwrite($fh, $R["Drzavljanstvo"].";");
                                fwrite($fh, $R["emso"].";");
                                fwrite($fh, $R["MaticniList"].";");
                                fwrite($fh, $R["MaticnaKnjiga"].";");
                                fwrite($fh, $R["Naslov"].";");
                                fwrite($fh, $R["Posta"].";");
                                fwrite($fh, $R["Kraj"].";");
                                fwrite($fh, $R["oce"].";");
                                fwrite($fh, $R["ocenaslov"].";");
                                fwrite($fh, $R["ocekontakt"].";");
                                fwrite($fh, $R["oceemail"].";");
                                fwrite($fh, $R["mati"].";");
                                fwrite($fh, $R["matinaslov"].";");
                                fwrite($fh, $R["matikontakt"].";");
                                fwrite($fh, $R["matiemail"].";");
                                fwrite($fh, $R["Aktivnost"].";");
                                fwrite($fh, $R["LetoRoj"].";");
                                fwrite($fh, $R["IdKrajBivanja"].";");
                                fwrite($fh, $R["Spol"].";");
                                fwrite($fh, $R["IdPosebnePotrebe"].";");
                                fwrite($fh, $R["Bivanje"].";");
                                fwrite($fh, $R["Rom"].";");
                                fwrite($fh, $R["ZacSolanja"].";");
                                fwrite($fh, $R["KonSolanja"].";");
                                fwrite($fh, $R["ZacSolanjaSola"].";");
                                fwrite($fh, $R["KonSolanjaSola"].";");
                                fwrite($fh, $R["Skrbniki"].";");
                                fwrite($fh, $R["SkrbnikiNaslov"].";");
                                fwrite($fh, $R["SkrbnikiKontakt"].";");
                                fwrite($fh, $R["SkrbnikiEmail"].";");
                                fwrite($fh, $R["Placnik"].";");
                                fwrite($fh, $R["PlacnikNaslov"].";");
                                fwrite($fh, $R["PlacnikKontakt"].";");
                                fwrite($fh, $R["Opombe"].";");
                                //fwrite($fh, $R["OSObveza"]."\n");
                                fwrite($fh, $R["OSObveza"].";".$R["razred"].". ".$R["paralelka"]."\n");
                            }
                        }
                    }
                    fclose($fh);

                    echo "Za prenos CSV datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
                    echo "<h3><a href='".$myFile."'>Shrani datoteko ".$VFile."</a></h3>";
                    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                    break;
                default:
                //' določitev razredov za izvoz
                    echo "<p>Za uspešen prenos podatkov morajo imeti učenci vnesene <b>EMŠO</b> številke!</p>";
                    echo "<form  name='izvoz' method=post action='priprava.php'>";
                    echo "<input name='idd' type='hidden' value='800'>";
                    echo "<b>Izbor podatkov za izvoz:</b> <br />";
                    for ($Indx=1;$Indx <= 9;$Indx++){
                        echo "<input name='cb_".$Indx."' type='checkbox'>".$Indx.". razred<br />";
                    }
                    echo "<input name='id' type='hidden' value='1'>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form><br />";
            }
            break;
        case "900": //uvoz učenci OŠ
            if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                header("Location: nepooblascen.htm");
            }

            switch ($Vid){
                case "0":
                case "1":
                    echo "<form method='post' ENCTYPE='multipart/form-data' action='priprava.php'>";
                    echo "<input name='idd' type='hidden' value='910'>";
                    echo "<h2>Uvoz podatkov iz Lo.Polisa (CSV)</h2>";
                    break;
                case "2":
                    echo "<form method='post' ENCTYPE='multipart/form-data' action='priprava.php'>";
                    echo "<input name='idd' type='hidden' value='920'>";
                    echo "<h2>Uvoz podatkov iz Kadrov (CSV)</h2>";
                    break;
                case "3":
                    echo "<p>Navodilo:<br />Iz Excel datoteke aplikacije SOKOL odstranite vrstice pred glavo in prvi stolpec z zaporedno številko. ";
                    echo "Preverite, da ni kakšnega besedila tudi pri koncu tabele (odstranite jih z glavo vred). ";
                    echo "Tako popravljeno datoteko shranite kot .csv (comma separated values) datoteko ter jo nato pretvorite še v Unicode UTF-8 brez BOM.<br />Nato jo izberite tukaj.<br /></p>";
                    echo "<pre>prva vrstica naj ima naslednjo obliko:<br />EMSO;PRIIMEK;IME;ROJEN/A;SPOL;KRAJ1;ULICA1;H.ST.1;POSTNA ST.1;POSTA1;IME IN PRIIEK MATERE;KRAJ2;ULICA2;H.ST.2;POSTNA ST.2;POSTA2;IME IN PRIIEK OCETA;KRAJ3;ULICA3;H.ST.3;POSTNA ST.3;POSTA3</pre>";
                    echo "<p>Še najlažje pa bo, če mi datoteko pošljete na ales.drinovec@alelektronik-ad.si, da vam jo pripravim in uvozim.</p>";
                    echo "<form method='post' ENCTYPE='multipart/form-data' action='priprava.php'>";
                    echo "<input name='idd' type='hidden' value='930'>";
                    echo "<h2>Uvoz novih prvošolcev (CSV)</h2>";
            }
            echo "<table border=0><tr>";
            echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
            echo "<input name='povezava' type='hidden' value='/'>";
            echo "<input name='id' type='hidden' value='".$Vid."'>";
            echo "</table>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "910": //uvoz lopolis
            $uploaded=false;
            $allowedExts = array("txt", "csv");
            $Preneseno=$_FILES["file"];
            $extension = explode(".", $Preneseno["name"]);
            $extension = end($extension);
            $extension = strtolower($extension);
            if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain") || ($_FILES["file"]["type"] == "application/vnd.ms-excel"))
                && ($_FILES["file"]["size"] < 500000)
                && in_array($extension, $allowedExts)){
                    if ($_FILES["file"]["error"] > 0){
                        echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                    }else{
                        echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                        echo "Type: " . $_FILES["file"]["type"] . "<br />";
                        echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                        echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
                 
                        if (file_exists("dato/" . $_FILES["file"]["name"])){
                            echo $_FILES["file"]["name"] . " already exists. ";
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }else{
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }
                   }
            }else{
                echo "Invalid file";
            }

            if ($uploaded){
                $myFile = "dato/".$_FILES["file"]["name"];
                $fh = fopen($myFile,'r') or die("Ne morem odpreti log datoteke!");
                $indx=0;
                while(!feof($fh)){
                   //echo fgets($file). "<br />";
                   $Vrstica[$indx]=fgets($fh);
                   $indx=$indx+1;
                }
                $StVrstic=$indx-1;
                fclose($fh);

                $SQL = "SELECT iducenec FROM tabucenci ORDER BY idUcenec DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                $StUcencev=0;
                if ($R = mysqli_fetch_array($result)){
                     $StUcencev=$R["iducenec"];
                }
                $StUcencevIndx=$StUcencev;

                //'Uvoz na novo vpisanih
                //'ID;Priimek;Ime;DatumRojstva;DržavaRojstva;KrajRojstva;Spol;EMSO;Občina;Kraj;Ulica;HisnaStevilka;Pošta;Telefon;Eposta;MatičniList;ŠtevilkaMatičnaKnjiga;VpisSolskoLeto;DatumVpisa;DatumZačetkaŠolanja;DatumZačetkaŠolanjaNaŠoli;Opombe;Kartica;Mati;MatiTelefonDoma;MatiTelefonMobilni;MatiTelefonSlužba;MatiEposta;Oče;OčeTelefonDoma;OčeTelefonMobilni;OčeTelefonSlužba;OčeEposta;ZakonitiZastopnik;ZakonitiZastopnikTelefonDoma;ZakonitiZastopnikTelefonMobilni;ZakonitiZastopnikTelefonSlužba;ZakonitiZastopnikEposta;Plačnik;PlačnikTelefonDoma;PlačnikTelefonMobilni;PlačnikTelefonSlužba;PlačnikEposta

                //'uvoz po razredih
                //'Oddelek;Program;Razred;NivoMatematika;NivoMatematikaSkupina;MaterniJezik;NivoMaterniJezik;NivoMaterniJezikSkupina;TujJezik;NivoTujJezik;NivoTujJezikSkupina;1.IzbirniPredmet;Izb1skup;2.IzbirniPredmet;Izb2skup;3.IzbirniPredmet;Izb3skup;
                //'ID;Priimek;Ime;DatumRojstva;DržavaRojstva;KrajRojstva;Spol;EMSO;Občina;Kraj;Ulica;HisnaStevilka;Pošta;Telefon;Eposta;MatičniList;ŠtevilkaMatičnaKnjiga;Delovodnik;VpisSolskoLeto;DatumVpisa;DatumZačetkaŠolanja;DatumZačetkaŠolanjaNaŠoli;Opombe;Kartica;Mati;MatiTelefonDoma;MatiTelefonMobilni;MatiTelefonSlužba;MatiEposta;Oče;OčeTelefonDoma;OčeTelefonMobilni;OčeTelefonSlužba;OčeEposta;ZakonitiZastopnik;ZakonitiZastopnikTelefonDoma;ZakonitiZastopnikTelefonMobilni;ZakonitiZastopnikTelefonSlužba;ZakonitiZastopnikEposta;Plačnik;PlačnikTelefonDoma;PlačnikTelefonMobilni;PlačnikTelefonSlužba;PlačnikEposta

                //'vrstico razstavi na polja. Imena polj shrani in jim priredi ustrezno ime polja v tabucenci
                //'katera polja naj naslavlja
                $Polje[1][1]="paralelka";
                $Polje[2][1]="osemdevet";
                $Polje[3][1]="razred";
                $Polje[4][1]="nivoji";
                $Polje[5][1]="";
                $Polje[6][1]="";
                $Polje[7][1]="nivoji";
                $Polje[8][1]="";
                $Polje[9][1]="";
                $Polje[10][1]="nivoji";
                $Polje[11][1]="";
                $Polje[12][1]="izbirni1";
                $Polje[13][1]="";
                $Polje[14][1]="izbirni2";
                $Polje[15][1]="";
                $Polje[16][1]="izbirni3";
                $Polje[17][1]="";
                $Polje[18][1]="priimek";
                $Polje[19][1]="ime";
                $Polje[20][1]="datroj";
                $Polje[21][1]="drzavaroj";
                $Polje[22][1]="krajroj";
                $Polje[23][1]="spol";
                $Polje[24][1]="emso";
                $Polje[25][1]="";
                $Polje[26][1]="kraj";
                $Polje[27][1]="naslov";
                $Polje[28][1]="";
                $Polje[29][1]="posta";
                $Polje[30][1]="";
                $Polje[31][1]="maticnilist";
                $Polje[32][1]="maticnaknjiga";
                $Polje[33][1]="evidst";
                $Polje[34][1]="";
                $Polje[35][1]="";
                $Polje[36][1]="zacsolanja";
                $Polje[37][1]="zacsolanjasola";
                $Polje[38][1]="opombe";
                $Polje[39][1]="mati";
                $Polje[40][1]="matikontakt";
                $Polje[41][1]="";
                $Polje[42][1]="";
                $Polje[43][1]="matiemail";
                $Polje[44][1]="oce";
                $Polje[45][1]="ocekontakt";
                $Polje[46][1]="";
                $Polje[47][1]="";
                $Polje[48][1]="oceemail";
                $Polje[49][1]="skrbniki";
                $Polje[50][1]="skrbnikikontakt";
                $Polje[51][1]="";
                $Polje[52][1]="";
                $Polje[53][1]="skrbnikiemail";
                $Polje[54][1]="placnik";
                $Polje[55][1]="placnikkontakt";
                $Polje[56][1]="";
                $Polje[57][1]="";
                $Polje[58][1]="";
                $Polje[59][1]="";
                $Polje[60][1]="";

                //'iz katere tabele naj jemlje podatke: 0-tabucenci][1-TabIzbirni][2-TabNivoji][3-tabrazred
                $Polje[1][3]=3;
                $Polje[2][3]=3;
                $Polje[3][3]=3;
                $Polje[4][3]=2;
                $Polje[5][3]=-1;
                $Polje[6][3]=-1;
                $Polje[7][3]=2;
                $Polje[8][3]=-1;
                $Polje[9][3]=-1;
                $Polje[10][3]=2;
                $Polje[11][3]=-1;
                $Polje[12][3]=1;
                $Polje[13][3]=-1;
                $Polje[14][3]=1;
                $Polje[15][3]=-1;
                $Polje[16][3]=1;
                $Polje[17][3]=-1;
                $Polje[18][3]=0;
                $Polje[19][3]=0;
                $Polje[20][3]=0;
                $Polje[21][3]=0;
                $Polje[22][3]=0;
                $Polje[23][3]=0;
                $Polje[24][3]=0;
                $Polje[25][3]=0;
                $Polje[26][3]=0;
                $Polje[27][3]=0;
                $Polje[28][3]=0;
                $Polje[29][3]=0;
                $Polje[30][3]=0;
                $Polje[31][3]=0;
                $Polje[32][3]=0;
                $Polje[33][3]=3;
                $Polje[34][3]=0;
                $Polje[35][3]=0;
                $Polje[36][3]=0;
                $Polje[37][3]=0;
                $Polje[38][3]=0;
                $Polje[39][3]=0;
                $Polje[40][3]=0;
                $Polje[41][3]=0;
                $Polje[42][3]=0;
                $Polje[43][3]=0;
                $Polje[44][3]=0;
                $Polje[45][3]=0;
                $Polje[46][3]=0;
                $Polje[47][3]=0;
                $Polje[48][3]=0;
                $Polje[49][3]=0;
                $Polje[50][3]=0;
                $Polje[51][3]=0;
                $Polje[52][3]=0;
                $Polje[53][3]=0;
                $Polje[54][3]=0;
                $Polje[55][3]=0;
                $Polje[56][3]=0;
                $Polje[57][3]=0;
                $Polje[58][3]=0;
                $Polje[59][3]=3;
                $Polje[60][3]=-1;

                //'tip polja: 0-niz][ 1-število
                $Polje[1][4]=0;
                $Polje[2][4]=1;
                $Polje[3][4]=1;
                $Polje[4][4]=1;
                $Polje[5][4]=1;
                $Polje[6][4]=1;
                $Polje[7][4]=1;
                $Polje[8][4]=1;
                $Polje[9][4]=1;
                $Polje[10][4]=1;
                $Polje[11][4]=1;
                $Polje[12][4]=1;
                $Polje[13][4]=1;
                $Polje[14][4]=1;
                $Polje[15][4]=1;
                $Polje[16][4]=1;
                $Polje[17][4]=1;
                $Polje[18][4]=0;
                $Polje[19][4]=0;
                $Polje[20][4]=0;
                $Polje[21][4]=0;
                $Polje[22][4]=0;
                $Polje[23][4]=0;
                $Polje[24][4]=0;
                $Polje[25][4]=0;
                $Polje[26][4]=0;
                $Polje[27][4]=0;
                $Polje[28][4]=0;
                $Polje[29][4]=1;
                $Polje[30][4]=0;
                $Polje[31][4]=0;
                $Polje[32][4]=0;
                $Polje[33][4]=0;
                $Polje[34][4]=0;
                $Polje[35][4]=0;
                $Polje[36][4]=0;
                $Polje[37][4]=0;
                $Polje[38][4]=0;
                $Polje[39][4]=0;
                $Polje[40][4]=0;
                $Polje[41][4]=0;
                $Polje[42][4]=0;
                $Polje[43][4]=0;
                $Polje[44][4]=0;
                $Polje[45][4]=0;
                $Polje[46][4]=0;
                $Polje[47][4]=0;
                $Polje[48][4]=0;
                $Polje[49][4]=0;
                $Polje[50][4]=0;
                $Polje[51][4]=0;
                $Polje[52][4]=0;
                $Polje[53][4]=0;
                $Polje[54][4]=0;
                $Polje[55][4]=0;
                $Polje[56][4]=0;
                $Polje[57][4]=0;
                $Polje[58][4]=0;
                $Polje[59][4]=0;
                $Polje[60][4]=0;

                for ($Indx=0;$Indx <= 100;$Indx++){
                    $Polje[$Indx][0]=0;    //'$Polje ne obstaja
                }

                $Glava=explode(";",$Vrstica[0]);
                $StPolj=count($Glava);
                //korigira prvo polje in pobriše znake za UTF-8 datoteko (BOM)
                $Glava[0]=substr($Glava[0],3,strlen($Glava[0])-3);
                for ($i=0;$i < count($Glava);$i++){
                    $Glava[$i]=trim($Glava[$i]);
                }
                
                for ($Indx=0;$Indx < count($Glava);$Indx++){
                    $Indx0=PreveriPoljeLopolis($Glava[$Indx]);
                    $Polje[$Indx0][0]=1;
                    $Polje[$Indx0][2]=$Indx;
                }

                for ($Indx0=2;$Indx0 <= $StVrstic;$Indx0++){
                //'    vrstice se preberejo v VUcenec z indexi polj
                    $VUcenec[$Indx0]=explode(";",$Vrstica[$Indx0]);
                    for ($i=0;$i < count($VUcenec[$Indx0]);$i++){
                        $VUcenec[$Indx0][$i]=trim($VUcenec[$Indx0][$i]);
                    }
                }

                $i2=0;
                echo "<form  name='uvozLopolis' method=post action='priprava.php'>";
                echo "<input name='idd' type='hidden' value='911'>";
                echo "<br /><table border='1' cellspacing='0'>";
                echo "<tr>";
                for ($i1=1;$i1 <= 100;$i1++){
                    if ($Polje[$i1][0]==1){
                        if ($Polje[$i1][1] != ""){
                            echo "<th>".$Polje[$i1][1]."</th>";
                        }
                    }
                }
                echo "<th>uvozi</th>";
                echo "</tr>";

                for ($Indx=2;$Indx < $StVrstic;$Indx++){
                    //'izpiše učence
                    //'echo $VUcenec[$Indx,18)." ".$VUcenec[$Indx,19)."<br />"
                    
                    //'prilagoditev podatkov
                    //'paralelka
                    if ($Polje[1][0]==1){
                        $aarr=explode(".",$VUcenec[$Indx][$Polje[1][2]]);
                        if (count($aarr) > 1){
                            $VUcenec[$Indx][$Polje[1][2]]=$aarr[1];
                        }else{
                            $VUcenec[$Indx][$Polje[1][2]]="";
                        }
                    }
                    //'devetletka
                    if ($Polje[2][0]==1){
                        $VUcenec[$Indx][$Polje[2][2]]=9;
                    }
                    //'spol
                    if ($Polje[23][0]==1){
                        if ($VUcenec[$Indx][$Polje[23][2]]=="Ž"){
                            $VUcenec[$Indx][$Polje[23][2]]="F";
                        }
                    }
                    //'pošta
                    if ($Polje[29][0]==1){
                        //'echo $VUcenec[$Indx,$Polje(29,2))."<br />"
                        if (strlen($VUcenec[$Indx][$Polje[29][2]]) > 3){
                            $VUcenec[$Indx][$Polje[29][2]]=substr($VUcenec[$Indx][$Polje[29][2]],0,4);
                            if (is_numeric($VUcenec[$Indx][$Polje[29][2]])){
                                $VUcenec[$Indx][$Polje[29][2]]=intval($VUcenec[$Indx][$Polje[29][2]]);
                            }else{
                                $VUcenec[$Indx][$Polje[29][2]]="0";
                            }
                        }else{
                            $VUcenec[$Indx][$Polje[29][2]]="0";
                        }
                    }
                    //'mati kontakt
                    if ($Polje[40][0]==1){
                        $VUcenec[$Indx][$Polje[40][2]]=$VUcenec[$Indx][$Polje[40][2]].", ".$VUcenec[$Indx][$Polje[41][2]].", ".$VUcenec[$Indx][$Polje[42][2]];
                    }
                    //'oče kontakt
                    if ($Polje[45][0]==1){
                        $VUcenec[$Indx][$Polje[45][2]]=$VUcenec[$Indx][$Polje[45][2]].", ".$VUcenec[$Indx][$Polje[46][2]].", ".$VUcenec[$Indx][$Polje[47][2]];
                    }
                    //'skrbniki kontakt
                    if ($Polje[50][0]==1){
                        $VUcenec[$Indx][$Polje[50][2]]=$VUcenec[$Indx][$Polje[50][2]].", ".$VUcenec[$Indx][$Polje[51][2]].", ".$VUcenec[$Indx][$Polje[52][2]];
                    }
                    //'plačnik kontakt
                    if ($Polje[55][0]==1){
                        $VUcenec[$Indx][$Polje[55][2]]=$VUcenec[$Indx][$Polje[55][2]].", ".$VUcenec[$Indx][$Polje[56][2]].", ".$VUcenec[$Indx][$Polje[57][2]].", ".$VUcenec[$Indx][$Polje[58][2]];
                    }
                    
                    //'vpis v tabucenci
                    
                    if (($Polje[18][0] == 1) && ($Polje[19][0]==1) && ($Polje[20][0]==1)){
                        $i2=$i2+1;
                        echo "<tr>";
                        $VdatumUc=new DateTime(isDate($VUcenec[$Indx][$Polje[20][2]]));
                        if (strlen($VUcenec[$Indx][$Polje[24][2]])==13){
                            $SQL = "SELECT iducenec FROM tabucenci WHERE emso='".$VUcenec[$Indx][$Polje[24][2]]."'";
                        }else{
                            $SQL = "SELECT iducenec FROM tabucenci WHERE priimek='".$VUcenec[$Indx][$Polje[18][2]]."' AND ime='".$VUcenec[$Indx][$Polje[19][2]]."' AND day(DatRoj)=".$VdatumUc->format('j')." AND month(DatRoj)=".$VdatumUc->format('n')." AND year(DatRoj)=".$VdatumUc->format('Y');
                        }
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            //'update
                            for ($i1=1;$i1 <= $StPolj;$i1++){
                                if ($Polje[$i1][0]==1){
                                    if ($Polje[$i1][1] != ""){
                                        if ($Polje[$i1][3]==0){
                                            if ($R[$Polje[$i1][1]] != $VUcenec[$Indx][$Polje[$i1][2]]){
                                                echo "<td bgcolor='lightyellow'>".$R[$Polje[$i1][1]]."<br/><input name='".$Polje[$i1][1]."_".$i2."' type='text' value='".$VUcenec[$Indx][$Polje[$i1][2]]."'</td>";
                                            }else{
                                                echo "<td bgcolor='lightgreen'>".$R[$Polje[$i1][1]]."<br/><input name='".$Polje[$i1][1]."_".$i2."' type='text' value='".$VUcenec[$Indx][$Polje[$i1][2]]."'</td>";
                                            }
                                        }else{
                                            echo "<td><input name='".$Polje[$i1][1]."_".$i2."' type='text' value='".$VUcenec[$Indx][$Polje[$i1][2]]."'</td>";
                                        }
                                    }
                                }
                            }
                            echo "<td><input name='cb_".$i2."' type='checkbox' checked='checked'><input name='iducenec_".$i2."' type='hidden' value='".$R["iducenec"]."'><input name='akcija_".$i2."' type='hidden' value='update'></td>";
                        }else{
                            //'insert
                            for ($i1=1;$i1 < $StPolj;$i1++){
                                if ($Polje[$i1][0]==1){
                                    if ($Polje[$i1][1] != ""){
                                        echo "<td bgcolor='blue'><input name='".$Polje[$i1][1]."_".$i2."' type='text' value='".$VUcenec[$Indx][$Polje[$i1][2]]."'</td>";
                                    }
                                }
                            }
                            echo "<td><input name='cb_".$i2."' type='checkbox' checked='checked'><input name='iducenec_".$i2."' type='hidden' value='0'><input name='akcija_".$i2."' type='hidden' value='insert'></td>";
                        }
                    }
                    echo "</tr>";
                    
                }
                echo "</table><br />";
                echo "<input name='id' type='hidden' value='".$Vid."'>";
                echo "<input name='stucencev' type='hidden' value='".$i2."'>";
                echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
            break;
        case "911": //uvoz lopolis form
            $StUcencev=intval($_POST["stucencev"]);
            for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                if (isset($_POST["cb_".$Indx])){
                    switch ($_POST["akcija_".$Indx]){
                        case "update":
                            $SQL = "UPDATE TabUcenci SET ";
                            $SQL = $SQL . "Priimek='".$_POST["priimek_".$Indx]."',";
                            $SQL = $SQL . "Ime='".$_POST["ime_".$Indx]."',";
                            $SQL = $SQL . "DatRoj='".$_POST["datroj_".$Indx]."',";
                            $SQL = $SQL . "DrzavaRoj='".$_POST["drzavaroj_".$Indx]."',";
                            $SQL = $SQL . "KrajRoj='".$_POST["krajroj_".$Indx]."',";
                            $SQL = $SQL . "Spol='".$_POST["spol_".$Indx]."',";
                            $SQL = $SQL . "emso='".$_POST["emso_".$Indx]."',";
                            $SQL = $SQL . "Kraj='".$_POST["kraj_".$Indx]."',";                
                            $SQL = $SQL . "naslov='".$_POST["naslov_".$Indx]."',";
                            $SQL = $SQL . "posta=".$_POST["posta_".$Indx].",";
                            $SQL = $SQL . "MaticniList='".$_POST["maticnilist_".$Indx]."',";
                            $SQL = $SQL . "MaticnaKnjiga='".$_POST["maticnaknjiga_".$Indx]."',";
                            $SQL = $SQL . "ZacSolanja='".$_POST["zacsolanja_".$Indx]."',";                
                            $SQL = $SQL . "ZacSolanjaSola='".$_POST["zacsolanjasola_".$Indx]."',";
                            $SQL = $SQL . "Opombe='".$_POST["opombe_".$Indx]."',";
                            $SQL = $SQL . "mati='".$_POST["mati_".$Indx]."',";           
                            $SQL = $SQL . "matikontakt='".$_POST["matikontakt_".$Indx]."',";
                            $SQL = $SQL . "matiemail='".$_POST["matiemail_".$Indx]."',";
                            $SQL = $SQL . "oce='".$_POST["oce_".$Indx]."',";
                            $SQL = $SQL . "ocekontakt='".$_POST["ocekontakt_".$Indx]."',";
                            $SQL = $SQL . "oceemail='".$_POST["oceemail_".$Indx]."',";
                            $SQL = $SQL . "skrbniki='".$_POST["skrbniki_".$Indx]."',";
                            $SQL = $SQL . "skrbnikikontakt='".$_POST["skrbnikikontakt_".$Indx]."',";
                            $SQL = $SQL . "skrbnikiemail='".$_POST["skrbnikiemail_".$Indx]."',";
                            $SQL = $SQL . "placnik='".$_POST["placnik_".$Indx]."',";
                            $SQL = $SQL . "placnikkontakt='".$_POST["placnikkontakt_".$Indx]."',";
                            if (strlen($_POST["datroj_".$Indx]) > 0){
                                $aarr=explode(".",$_POST["datroj_".$Indx]);
                                $SQL = $SQL . "LetoRoj=".$aarr[2]." ";
                            }else{
                                $SQL = $SQL . "LetoRoj=0 ";
                            }
                            $SQL = $SQL . " WHERE idUcenec=".$_POST["iducenec_".$Indx];
                            $result = mysqli_query($link,$SQL);
                            echo "Popravljen zapis za: ".$_POST["priimek_".$Indx]." ".$_POST["ime_".$Indx].", ".$_POST["emso_".$Indx]." (".$_POST["iducenec_".$Indx].")<br />";
                            
                            //'pogleda, če so razredi že vpisani
                            $SQL = "SELECT * FROM TabRazDat WHERE leto=".$VLeto." AND razred=".$_POST["razred_".$Indx]." AND oznaka='".$_POST["paralelka_".$Indx]."' OR oznaka='".strtolower($_POST["paralelka_".$Indx])."'";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $i1=$i1; // 'pass
                            }else{
                                $SQL = "INSERT INTO TabRazDat (leto,razred,oznaka,prostor,osemdevet) VALUES (";
                                $SQL = $SQL . $VLeto.",";
                                $SQL = $SQL . $_POST["razred_".$Indx].",";
                                $SQL = $SQL . "'".strtolower($_POST["paralelka_".$Indx])."',0,9)";
                                $result = mysqli_query($link,$SQL);
                                echo "Dodan je bil razred: ".$_POST["razred_".$Indx].". ".strtolower($_POST["paralelka_".$Indx])."<br />";
                            }
                            //'prebere podatke o razredih
                            $SQL = "SELECT * FROM TabRazDat WHERE leto=".$VLeto." AND razred=".$_POST["razred_".$Indx]." AND (oznaka='".$_POST["paralelka_".$Indx]."' OR oznaka='".strtolower($_POST["paralelka_".$Indx])."')";
                            //'echo $SQL . "<br />"
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $VRazred1=$R["razred"];
                                $VParalelka=$R["oznaka"];
                                $VRazred=$R["id"];
                            }
                            
                            $SQL = "SELECT * FROM TabRazred WHERE idUcenec=".$_POST["iducenec_".$Indx]." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            //'echo $SQL . "<br />"

                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabrazred SET ";
                                $SQL = $SQL . "razred=".$VRazred1.",";
                                $SQL = $SQL . "paralelka='".$VParalelka."',";
                                $SQL = $SQL . "osemdevet=".$_POST["osemdevet_".$Indx].",";
                                $SQL = $SQL . "EvidSt='".$_POST["evidst_".$Indx]."',";
                                $SQL = $SQL . "letoSolanja=".$VRazred1.",";
                                $SQL = $SQL . "idRazred=".$VRazred;
                                $SQL = $SQL . " WHERE id=".$R["id"];
                                echo "Popravljeni razredni podatki: ".$VRazred1.". ".$VParalelka."<br />";
                            }else{
                                $SQL = "INSERT INTO tabrazred (Leto,Razred,Paralelka,osemdevet,IdUcenec,Uspeh,UspehPol,Ponavljalec,LetoSolanja,IdUcitelj,IdVzgojitelj,napredovanje,RazredniIzpit,Nadarjen,StatusSport,StatusKult,EvidSt,idRazred) values (" ;
                                $SQL = $SQL . $VLeto.",".$VRazred1.",'".$VParalelka."',".$_POST["osemdevet_".$Indx].",".$_POST["iducenec_".$Indx].",0,0,";
                                $SQL = $SQL ."0,".$VRazred1.",0,0,0,0,0,0,0,'".$_POST["evidst_".$Indx]."',".$VRazred.")";
                                echo "Dodani razredni podatki: ".$VRazred1.". ".$VParalelka."<br />";
                            }
                            $result = mysqli_query($link,$SQL);
                            
                            if ($Vid=="1"){
                    //'vpis izbirnih predmetov
                               // 'najprej pobriše predmete za aktualno leto
                                $SQL = "DELETE FROM tabizbirni WHERE leto=".$VLeto." AND idUcenec=".$_POST["iducenec_".$Indx];
                                $result = mysqli_query($link,$SQL);
                                
                                if (strlen($_POST["izbirni1_".$Indx]) > 0){
                                    $SQL = "SELECT id FROM tabpredmeti WHERE opisLopolis='".$_POST["izbirni1_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO TabIzbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 1. izbirnega predmeta (".$_POST["izbirni1_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                                
                                if (strlen($_POST["izbirni2_".$Indx]) > 0){
                                    $SQL = "SELECT id FROM tabpredmeti WHERE opisLopolis='".$_POST["izbirni2_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO TabIzbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 2. izbirnega predmeta (".$_POST["Izbirni2_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }

                                if (isset($_POST["izbirni3_".$Indx])){
                                    $SQL = "SELECT * FROM TabPredmeti WHERE opisLopolis='".$_POST["izbirni3_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO TabIzbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 3. izbirnega predmeta (".$_POST["Izbirni3_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                            }
                            
                            break;
                        case "insert":
                            $SQL = "SELECT iducenec FROM tabucenci ORDER BY idUcenec DESC LIMIT 0,1";
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $VIdUcenec=$R["iducenec"]+1;
                            }
                            $SQL = "INSERT INTO tabucenci (";
                            $SQL = $SQL . "idUcenec,";
                            $SQL = $SQL . "Priimek,";
                            $SQL = $SQL . "Ime,";                
                            $SQL = $SQL . "DatRoj,";
                            $SQL = $SQL . "DrzavaRoj,";                
                            $SQL = $SQL . "KrajRoj,";                
                            $SQL = $SQL . "Spol,";                
                            $SQL = $SQL . "emso,";                
                            $SQL = $SQL . "Kraj,";                
                            $SQL = $SQL . "naslov,";                
                            $SQL = $SQL . "posta,";                
                            $SQL = $SQL . "MaticniList,";                
                            $SQL = $SQL . "MaticnaKnjiga,";                
                            $SQL = $SQL . "ZacSolanja,";                
                            $SQL = $SQL . "ZacSolanjaSola,";                
                            $SQL = $SQL . "Opombe,";                
                            $SQL = $SQL . "mati,";                
                            $SQL = $SQL . "matikontakt,";                
                            $SQL = $SQL . "matiemail,";                
                            $SQL = $SQL . "oce,";                
                            $SQL = $SQL . "ocekontakt,";                
                            $SQL = $SQL . "oceemail,";                
                            $SQL = $SQL . "skrbniki,";                
                            $SQL = $SQL . "skrbnikikontakt,";                
                            $SQL = $SQL . "skrbnikiemail,";                
                            $SQL = $SQL . "placnik,";                
                            $SQL = $SQL . "placnikkontakt,";                
                            $SQL = $SQL . "LetoRoj) VALUES (";                
                            $SQL = $SQL . $VIdUcenec.",";
                            $SQL = $SQL . "'".$_POST["priimek_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["ime_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["datroj_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["drzavaroj_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["krajroj_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["spol_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["emso_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["kraj_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["naslov_".$Indx]."',";
                            $SQL = $SQL . "".$_POST["posta_".$Indx].",";                
                            $SQL = $SQL . "'".$_POST["maticnilist_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["maticnaknjiga_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["zacsolanja_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["zacsolanjasola_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["opombe_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["mati_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["matikontakt_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["matiemail_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["oce_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["ocekontakt_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["oceemail_".$Indx]."',";        
                            $SQL = $SQL . "'".$_POST["skrbniki_".$Indx]."',";                
                            $SQL = $SQL . "'".$_POST["skrbnikikontakt_".$Indx]."',";
                            $SQL = $SQL . "'".$_POST["skrbnikiemail_".$Indx]."',";            
                            $SQL = $SQL . "'".$_POST["placnik_".$Indx]."',";    
                            $SQL = $SQL . "'".$_POST["placnikkontakt_".$Indx]."',";
                            if (strlen($_POST["datroj_".$Indx] > 0)){
                                $aarr=explode(".",$_POST["datroj_".$Indx]);
                                $SQL = $SQL . $aarr[2].") ";
                            }else{
                                $SQL = $SQL . "0) ";
                            }
                            $result = mysqli_query($link,$SQL);
                            echo "Dodan zapis za: ".$_POST["priimek_".$Indx]." ".$_POST["ime_".$Indx].", ".$_POST["emso_".$Indx]."<br />";
                            
                            //'pogleda, če so razredi že vpisani
                            $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred=".$_POST["razred_".$Indx]." AND (oznaka='".$_POST["paralelka_".$Indx]."' OR oznaka='".strtolower($_POST["paralelka_".$Indx])."')";
                            $result = mysqli_query($link,$SQL);
                            
                            if (mysqli_num_rows($result)==0){
                                $SQL = "INSERT INTO tabrazdat (leto,razred,oznaka,prostor,osemdevet) VALUES (";
                                $SQL = $SQL . $VLeto.",";
                                $SQL = $SQL . $_POST["razred_".$Indx].",";
                                $SQL = $SQL . "'".strtolower($_POST["paralelka_".$Indx])."',0,9)";
                                echo $SQL . "<br />";
                                $result = mysqli_query($link,$SQL);
                                echo "Dodan je bil razred: ".$_POST["razred_".$Indx].". ".strtolower($_POST["paralelka_".$Indx])."<br />";
                            }
                            //'prebere podatke o razredih
                            $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred=".$_POST["razred_".$Indx]." AND (oznaka='".$_POST["paralelka_".$Indx]."' OR oznaka='".strtolower($_POST["paralelka_".$Indx])."')";
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $VRazred1=$R["razred"];
                                $VParalelka=$R["oznaka"];
                                $VRazred=$R["id"];
                            }
                            
                            $SQL = "SELECT * FROM tabrazred WHERE idUcenec=".$VIdUcenec." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);

                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabrazred SET ";
                                $SQL = $SQL . "razred=".$VRazred1.",";
                                $SQL = $SQL . "paralelka='".$VParalelka."',";
                                $SQL = $SQL . "osemdevet=".$_POST["osemdevet_".$Indx].",";
                                $SQL = $SQL . "EvidSt='".$_POST["evidst_".$Indx]."',";
                                $SQL = $SQL . "letoSolanja=".$VRazred1.",";
                                $SQL = $SQL . "idRazred=".$VRazred;
                                $SQL = $SQL . " WHERE id=".$R["id"];
                                echo "Popravljeni razredni podatki: ".$Vrazred1.". ".$VParalelka."<br />";
                            }else{
                                $SQL = "INSERT INTO tabrazred (Leto,Razred,Paralelka,osemdevet,IdUcenec,Uspeh,UspehPol,Ponavljalec,LetoSolanja,IdUcitelj,IdVzgojitelj,napredovanje,RazredniIzpit,Nadarjen,StatusSport,StatusKult,EvidSt,idRazred) values (" ;
                                $SQL = $SQL . $VLeto.",".$VRazred1.",'".$VParalelka."',".$_POST["osemdevet_".$Indx].",".$_POST["iducenec_".$Indx].",0,0,";
                                $SQL = $SQL ."0,".$VRazred1.",0,0,0,0,0,0,0,'".$_POST["evidst_".$Indx]."',".$VRazred.")";
                                echo "Dodani razredni podatki: ".$VRazred1.". ".$VParalelka."<br />";
                            }
                            $result = mysqli_query($link,$SQL);
                            
                            if ($Vid=="1"){
                    //'vpis izbirnih predmetov
                                //'najprej pobriše predmete za aktualno leto
                                $SQL = "DELETE FROM tabizbirni WHERE leto=".$VLeto." AND idUcenec=".$_POST["iducenec_".$Indx];
                                $result = mysqli_query($link,$SQL);
                                
                                if (strlen($_POST["izbirni1_".$Indx]) > 0){
                                    $SQL = "SELECT id FROM tabpredmeti WHERE opisLopolis='".$_POST["izbirni1_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO tabizbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 1. izbirnega predmeta (".$_POST["izbirni1_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                                
                                if (strlen($_POST["izbirni2_".$Indx]) > 0){
                                    $SQL = "SELECT id FROM tabpredmeti WHERE opisLopolis='".$_POST["izbirni2_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO tabizbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 2. izbirnega predmeta (".$_POST["Izbirni2_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }

                                if (strlen($_POST["izbirni3_".$Indx]) > 0){
                                    $SQL = "SELECT id FROM tabpredmeti WHERE opisLopolis='".$_POST["izbirni3_".$Indx]."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $VIzbirni=$R["id"];
                                        
                                        $SQL = "INSERT INTO tabizbirni (Ucenec,Leto,Izbirni) values (" .$_POST["iducenec_".$Indx].",".$VLeto.",".$VIzbirni.")";
                                        echo "Vpis 3. izbirnega predmeta (".$_POST["izbirni3_".$Indx].")<br />";
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                            }
                    }
                }
            }

            break;
        case "920": //uvoz kadri
            $uploaded=false;
            $allowedExts = array("txt", "csv");
            $Preneseno=$_FILES["file"];
            $extension = explode(".", $Preneseno["name"]);
            $extension = end($extension);
            $extension = strtolower($extension);
            if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain") || ($_FILES["file"]["type"] == "application/vnd.ms-excel"))
                && ($_FILES["file"]["size"] < 500000)
                && in_array($extension, $allowedExts)){
                    if ($_FILES["file"]["error"] > 0){
                        echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                    }else{
                        echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                        echo "Type: " . $_FILES["file"]["type"] . "<br />";
                        echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                        echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
                 
                        if (file_exists("dato/" . $_FILES["file"]["name"])){
                            echo $_FILES["file"]["name"] . " already exists. ";
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }else{
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }
                   }
            }else{
                echo "Invalid file";
            }
            echo "<br />";
            if ($uploaded){
                $myFile = "dato/".$_FILES["file"]["name"];
                $fh = fopen($myFile,'r') or die("Ne morem odpreti log datoteke!");
                $indx=0;
                while(!feof($fh)){
                   //echo fgets($file). "<br />";
                   $Vrstica[$indx]=fgets($fh);
                   $indx=$indx+1;
                }
                $StVrstic=$indx-1;
                fclose($fh);

                $SQL = "SELECT iducenec FROM tabucenci ORDER BY idUcenec DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $StUcencevIndx=$R["iducenec"];
                }

                //'V DatoVsebina prebere vsebino datoteke

                //'vrstico razstavi na polja. Imena polj shrani in jim priredi ustrezno ime polja v tabucenci
                //'katera polja naj naslavlja
                $Polje [1][1]="ID";
                $Polje [2][1]="IdUcenec";
                $Polje [3][1]="Priimek";
                $Polje [4][1]="Ime";
                $Polje [5][1]="DatRoj";
                $Polje [6][1]="KrajRoj";
                $Polje [7][1]="DrzavaRoj";
                $Polje [8][1]="Drzavljanstvo";
                $Polje [9][1]="emso";
                $Polje[10][1]="MaticniList";
                $Polje[11][1]="MaticnaKnjiga";
                $Polje[12][1]="Naslov";
                $Polje[13][1]="Posta";
                $Polje[14][1]="Kraj";
                $Polje[15][1]="oce";
                $Polje[16][1]="ocenaslov";
                $Polje[17][1]="ocekontakt";
                $Polje[18][1]="oceemail";
                $Polje[19][1]="mati";
                $Polje[20][1]="matinaslov";
                $Polje[21][1]="matikontakt";
                $Polje[22][1]="matiemail";
                $Polje[23][1]="Aktivnost";
                $Polje[24][1]="LetoRoj";
                $Polje[25][1]="IdKrajBivanja";
                $Polje[26][1]="Spol";
                $Polje[27][1]="IdPosebnePotrebe";
                $Polje[28][1]="Bivanje";
                $Polje[29][1]="Rom";
                $Polje[30][1]="ZacSolanja";
                $Polje[31][1]="KonSolanja";
                $Polje[32][1]="ZacSolanjaSola";
                $Polje[33][1]="KonSolanjaSola";
                $Polje[34][1]="Skrbniki";
                $Polje[35][1]="SkrbnikiNaslov";
                $Polje[36][1]="SkrbnikiKontakt";
                $Polje[37][1]="Skrbnikiemail";
                $Polje[38][1]="Placnik";
                $Polje[39][1]="PlacnikNaslov";
                $Polje[40][1]="PlacnikKontakt";
                $Polje[41][1]="Opombe";
                $Polje[42][1]="OSobveza";
                $Polje[43][1]="";
                $Polje[44][1]="";
                $Polje[45][1]="";
                $Polje[46][1]="";
                $Polje[47][1]="";
                $Polje[48][1]="";
                $Polje[49][1]="";
                $Polje[50][1]="";
                $Polje[51][1]="";
                $Polje[52][1]="";
                $Polje[53][1]="";
                $Polje[54][1]="";
                $Polje[55][1]="";
                $Polje[56][1]="";
                $Polje[57][1]="";
                $Polje[58][1]="";

                //'iz katere tabele naj jemlje podatke: 0-tabucenci][1-tabizbirni][2-TabNivoji][3-tabrazred
                $Polje[1][3]=0;
                $Polje[2][3]=0;
                $Polje[3][3]=0;
                $Polje[4][3]=0;
                $Polje[5][3]=0;
                $Polje[6][3]=0;
                $Polje[7][3]=0;
                $Polje[8][3]=0;
                $Polje[9][3]=0;
                $Polje[10][3]=0;
                $Polje[11][3]=0;
                $Polje[12][3]=0;
                $Polje[13][3]=0;
                $Polje[14][3]=0;
                $Polje[15][3]=0;
                $Polje[16][3]=0;
                $Polje[17][3]=0;
                $Polje[18][3]=0;
                $Polje[19][3]=0;
                $Polje[20][3]=0;
                $Polje[21][3]=0;
                $Polje[22][3]=0;
                $Polje[23][3]=0;
                $Polje[24][3]=0;
                $Polje[25][3]=0;
                $Polje[26][3]=0;
                $Polje[27][3]=0;
                $Polje[28][3]=0;
                $Polje[29][3]=0;
                $Polje[30][3]=0;
                $Polje[31][3]=0;
                $Polje[32][3]=0;
                $Polje[33][3]=0;
                $Polje[34][3]=0;
                $Polje[35][3]=0;
                $Polje[36][3]=0;
                $Polje[37][3]=0;
                $Polje[38][3]=0;
                $Polje[39][3]=0;
                $Polje[40][3]=0;
                $Polje[41][3]=0;
                $Polje[42][3]=0;
                $Polje[43][3]=0;
                $Polje[44][3]=0;
                $Polje[45][3]=0;
                $Polje[46][3]=0;
                $Polje[47][3]=0;
                $Polje[48][3]=0;
                $Polje[49][3]=0;
                $Polje[50][3]=0;
                $Polje[51][3]=0;
                $Polje[52][3]=0;
                $Polje[53][3]=0;
                $Polje[54][3]=0;
                $Polje[55][3]=0;
                $Polje[56][3]=0;
                $Polje[57][3]=0;
                $Polje[58][3]=0;

                //'tip polja: 0-niz, 1-število
                $Polje[1][4]=1;
                $Polje[2][4]=1;
                $Polje[3][4]=0;
                $Polje[4][4]=0;
                $Polje[5][4]=0;
                $Polje[6][4]=0;
                $Polje[7][4]=0;
                $Polje[8][4]=0;
                $Polje[9][4]=0;
                $Polje[10][4]=0;
                $Polje[11][4]=0;
                $Polje[12][4]=0;
                $Polje[13][4]=1;
                $Polje[14][4]=0;
                $Polje[15][4]=0;
                $Polje[16][4]=0;
                $Polje[17][4]=0;
                $Polje[18][4]=0;
                $Polje[19][4]=0;
                $Polje[20][4]=0;
                $Polje[21][4]=0;
                $Polje[22][4]=0;
                $Polje[23][4]=1;
                $Polje[24][4]=1;
                $Polje[25][4]=1;
                $Polje[26][4]=0;
                $Polje[27][4]=1;
                $Polje[28][4]=1;
                $Polje[29][4]=1;
                $Polje[30][4]=0;
                $Polje[31][4]=0;
                $Polje[32][4]=0;
                $Polje[33][4]=0;
                $Polje[34][4]=0;
                $Polje[35][4]=0;
                $Polje[36][4]=0;
                $Polje[37][4]=0;
                $Polje[38][4]=0;
                $Polje[39][4]=0;
                $Polje[40][4]=0;
                $Polje[41][4]=0;
                $Polje[42][4]=0;
                $Polje[43][4]=0;
                $Polje[44][4]=0;
                $Polje[45][4]=0;
                $Polje[46][4]=0;
                $Polje[47][4]=0;
                $Polje[48][4]=0;
                $Polje[49][4]=0;
                $Polje[50][4]=0;
                $Polje[51][4]=0;
                $Polje[52][4]=0;
                $Polje[53][4]=0;
                $Polje[54][4]=0;
                $Polje[55][4]=0;
                $Polje[56][4]=0;
                $Polje[57][4]=0;
                $Polje[58][4]=0;

                for ($Indx=0;$Indx <= 100;$Indx++){
                    $Polje[$Indx][0]=0; //    '$Polje ne obstaja
                }

                $Glava=explode(";",$Vrstica[0]);
                $StPolj=count($Glava);
                for ($Indx=0;$Indx < count($Glava);$Indx++){
                    $Indx0=PreveriPoljeKadri($Glava[$Indx]);
                    $Polje[$Indx0][0]=1;
                    $Polje[$Indx0][2]=$Indx;
                }

                for ($Indx0=2;$Indx0 <= $StVrstic;$Indx0++){
                //'    vrstice se preberejo v VUcenec z indexi polj
                    $VUcenec[$Indx0]=explode(";",$Vrstica[$Indx0]);
                    for ($i=0;$i < count($VUcenec[$Indx0]);$i++){
                        $VUcenec[$Indx0][$i]=trim($VUcenec[$Indx0][$i]);
                    }
                }

                for ($Indx=2;$Indx < $StVrstic;$Indx++){
                    //'vpis v tabucenci
                    $SQL = "SELECT id,iducenec,priimek,ime FROM tabucenci WHERE priimek='".$VUcenec[$Indx][$Polje[3][2]]."' AND ime='".$VUcenec[$Indx][$Polje[4][2]]."' AND emso='".$VUcenec[$Indx][$Polje[9][2]]."'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'update
                        $SQL = "UPDATE tabucenci SET ";
                        for ($i1=4;$i1 <= $StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && $Polje[$i1][3]==0){
                                    if ($Polje[$i1][4]==0){
                                        $SQL = $SQL . $Polje[$i1][1]."='".$VUcenec[$Indx][$Polje[$i1][2]]."',";
                                    }else{
                                        $SQL = $SQL . $Polje[$i1][1]."=".$VUcenec[$Indx][$Polje[$i1][2]].",";
                                    }
                                }
                            }
                        }
                        $SQL = $SQL . "priimek='".$VUcenec[$Indx][$Polje[3][2]]."' WHERE id=".$R["id"];
                        echo "Popravljeno: ".$VUcenec[$Indx][$Polje[3][2]]." ".$VUcenec[$Indx][$Polje[4][2]]."<br />";
                        $VIdUcenec=$R["iducenec"];
                    }else{
                        //'insert
                        $StUcencevIndx=$StUcencevIndx+1;
                        $SQL = "INSERT INTO tabucenci (";
                        for ($i1=3;$i1 <=$StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && ($Polje[$i1][3]==0)){
                                    $SQL = $SQL . $Polje[$i1][1].",";
                                }
                            }
                        }
                        $SQL = $SQL . "IdUcenec) VALUES (";
                        for ($i1=3;$i1 <=$StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && ($Polje[$i1][3]==0)){
                                    if ($Polje[$i1][4]==0){
                                        $SQL = $SQL . "'".$VUcenec[$Indx][$Polje[$i1][2]]."',";
                                    }else{
                                        $SQL = $SQL . $VUcenec[$Indx][$Polje[$i1][2]].",";
                                    }
                                }
                            }
                        }
                        $SQL = $SQL . $StUcencevIndx .")";
                        $VIdUcenec=$StUcencevIndx;
                        echo "Vpis: ".$VUcenec[$Indx][$Polje[3][2]]." ".$VUcenec[$Indx][$Polje[4][2]]."<br />";
                    }
                    $result = mysqli_query($link,$SQL);
                }
            }
            break;
        case "930": //uvoz prvošolci
            $uploaded=false;
            $allowedExts = array("txt", "csv");
            $Preneseno=$_FILES["file"];
            $extension = explode(".", $Preneseno["name"]);
            $extension = end($extension);
            $extension = strtolower($extension);
            if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain") || ($_FILES["file"]["type"] == "application/vnd.ms-excel"))
                && ($_FILES["file"]["size"] < 500000)
                && in_array($extension, $allowedExts)){
                    if ($_FILES["file"]["error"] > 0){
                        echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                    }else{
                        echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                        echo "Type: " . $_FILES["file"]["type"] . "<br />";
                        echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                        echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
                 
                        if (file_exists("dato/" . $_FILES["file"]["name"])){
                            echo $_FILES["file"]["name"] . " already exists. ";
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }else{
                            move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                            echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                            $uploaded=true;
                        }
                   }
            }else{
                echo "Invalid file";
            }

            if ($uploaded){
                $myFile = "dato/".$_FILES["file"]["name"];
                $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
                $indx=0;
                while(!feof($fh)){
                   //echo fgets($file). "<br />";
                   $Vrstica[$indx]=fgets($fh);
                   $indx=$indx+1;
                }
                $StVrstic=$indx-1;
                fclose($fh);

                $SQL = "SELECT iducenec FROM tabucenci ORDER BY idUcenec DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $StUcencevIndx=$R["iducenec"];
                }

                //'vrstico razstavi na polja. Imena polj shrani in jim priredi ustrezno ime polja v tabucenci
                //'katera polja naj naslavlja

                $Polje [1][1]="ID";
                $Polje [2][1]="IdUcenec";
                $Polje [3][1]="Priimek";
                $Polje [4][1]="Ime";
                $Polje [5][1]="DatRoj";
                $Polje [6][1]="KrajRoj";
                $Polje [7][1]="DrzavaRoj";
                $Polje [8][1]="Drzavljanstvo";
                $Polje [9][1]="emso";
                $Polje[10][1]="MaticniList";
                $Polje[11][1]="MaticnaKnjiga";
                $Polje[12][1]="Naslov";
                $Polje[13][1]="Posta";
                $Polje[14][1]="Kraj";
                $Polje[15][1]="oce";
                $Polje[16][1]="ocenaslov";
                $Polje[17][1]="ocekontakt";
                $Polje[18][1]="oceemail";
                $Polje[19][1]="mati";
                $Polje[20][1]="matinaslov";
                $Polje[21][1]="matikontakt";
                $Polje[22][1]="matiemail";
                $Polje[23][1]="Aktivnost";
                $Polje[24][1]="LetoRoj";
                $Polje[25][1]="IdKrajBivanja";
                $Polje[26][1]="Spol";
                $Polje[27][1]="IdPosebnePotrebe";
                $Polje[28][1]="Bivanje";
                $Polje[29][1]="Rom";
                $Polje[30][1]="ZacSolanja";
                $Polje[31][1]="KonSolanja";
                $Polje[32][1]="ZacSolanjaSola";
                $Polje[33][1]="KonSolanjaSola";
                $Polje[34][1]="Skrbniki";
                $Polje[35][1]="SkrbnikiNaslov";
                $Polje[36][1]="SkrbnikiKontakt";
                $Polje[37][1]="Skrbnikiemail";
                $Polje[38][1]="Placnik";
                $Polje[39][1]="PlacnikNaslov";
                $Polje[40][1]="PlacnikKontakt";
                $Polje[41][1]="Opombe";
                $Polje[42][1]="OSobveza";
                $Polje[43][1]="";
                $Polje[44][1]="";
                $Polje[45][1]="";
                $Polje[46][1]="";
                $Polje[47][1]="";
                $Polje[48][1]="";
                $Polje[49][1]="";
                $Polje[50][1]="";
                $Polje[51][1]="";
                $Polje[52][1]="";
                $Polje[53][1]="";
                $Polje[54][1]="";
                $Polje[55][1]="";
                $Polje[56][1]="";
                $Polje[57][1]="";
                $Polje[58][1]="";

                //'iz katere tabele naj jemlje podatke: 0-tabucenci][1-tabizbirni][2-TabNivoji][3-tabrazred
                $Polje[1][3]=0;
                $Polje[2][3]=0;
                $Polje[3][3]=0;
                $Polje[4][3]=0;
                $Polje[5][3]=0;
                $Polje[6][3]=0;
                $Polje[7][3]=0;
                $Polje[8][3]=0;
                $Polje[9][3]=0;
                $Polje[10][3]=0;
                $Polje[11][3]=0;
                $Polje[12][3]=0;
                $Polje[13][3]=0;
                $Polje[14][3]=0;
                $Polje[15][3]=0;
                $Polje[16][3]=0;
                $Polje[17][3]=0;
                $Polje[18][3]=0;
                $Polje[19][3]=0;
                $Polje[20][3]=0;
                $Polje[21][3]=0;
                $Polje[22][3]=0;
                $Polje[23][3]=0;
                $Polje[24][3]=0;
                $Polje[25][3]=0;
                $Polje[26][3]=0;
                $Polje[27][3]=0;
                $Polje[28][3]=0;
                $Polje[29][3]=0;
                $Polje[30][3]=0;
                $Polje[31][3]=0;
                $Polje[32][3]=0;
                $Polje[33][3]=0;
                $Polje[34][3]=0;
                $Polje[35][3]=0;
                $Polje[36][3]=0;
                $Polje[37][3]=0;
                $Polje[38][3]=0;
                $Polje[39][3]=0;
                $Polje[40][3]=0;
                $Polje[41][3]=0;
                $Polje[42][3]=0;
                $Polje[43][3]=0;
                $Polje[44][3]=0;
                $Polje[45][3]=0;
                $Polje[46][3]=0;
                $Polje[47][3]=0;
                $Polje[48][3]=0;
                $Polje[49][3]=0;
                $Polje[50][3]=0;
                $Polje[51][3]=0;
                $Polje[52][3]=0;
                $Polje[53][3]=0;
                $Polje[54][3]=0;
                $Polje[55][3]=0;
                $Polje[56][3]=0;
                $Polje[57][3]=0;
                $Polje[58][3]=0;

                //'tip polja: 0-niz, 1-število
                $Polje[1][4]=1;
                $Polje[2][4]=1;
                $Polje[3][4]=0;
                $Polje[4][4]=0;
                $Polje[5][4]=0;
                $Polje[6][4]=0;
                $Polje[7][4]=0;
                $Polje[8][4]=0;
                $Polje[9][4]=0;
                $Polje[10][4]=0;
                $Polje[11][4]=0;
                $Polje[12][4]=0;
                $Polje[13][4]=1;
                $Polje[14][4]=0;
                $Polje[15][4]=0;
                $Polje[16][4]=0;
                $Polje[17][4]=0;
                $Polje[18][4]=0;
                $Polje[19][4]=0;
                $Polje[20][4]=0;
                $Polje[21][4]=0;
                $Polje[22][4]=0;
                $Polje[23][4]=1;
                $Polje[24][4]=1;
                $Polje[25][4]=1;
                $Polje[26][4]=0;
                $Polje[27][4]=1;
                $Polje[28][4]=1;
                $Polje[29][4]=1;
                $Polje[30][4]=0;
                $Polje[31][4]=0;
                $Polje[32][4]=0;
                $Polje[33][4]=0;
                $Polje[34][4]=0;
                $Polje[35][4]=0;
                $Polje[36][4]=0;
                $Polje[37][4]=0;
                $Polje[38][4]=0;
                $Polje[39][4]=0;
                $Polje[40][4]=0;
                $Polje[41][4]=0;
                $Polje[42][4]=0;
                $Polje[43][4]=0;
                $Polje[44][4]=0;
                $Polje[45][4]=0;
                $Polje[46][4]=0;
                $Polje[47][4]=0;
                $Polje[48][4]=0;
                $Polje[49][4]=0;
                $Polje[50][4]=0;
                $Polje[51][4]=0;
                $Polje[52][4]=0;
                $Polje[53][4]=0;
                $Polje[54][4]=0;
                $Polje[55][4]=0;
                $Polje[56][4]=0;
                $Polje[57][4]=0;
                $Polje[58][4]=0;

                for ($Indx=0;$Indx <= 100;$Indx++){
                    $Polje[$Indx][0]=0; //    '$Polje ne obstaja
                }

                $Glava=explode(";",rtrim($Vrstica[0]));
                $StPolj=count($Glava);
                for ($Indx=0;$Indx < count($Glava);$Indx++){
                    $Indx0=PreveriPoljePrvosolci($Glava[$Indx]);
                    $Polje[$Indx0][0]=1;
                    $Polje[$Indx0][2]=$Indx;
                }

                for ($Indx0=1;$Indx0 <= $StVrstic;$Indx0++){
                //'    vrstice se preberejo v VUcenec z indexi polj
                    $VUcenec[$Indx0]=explode(";",rtrim($Vrstica[$Indx0]));
                }
                //'pri emšo pobriše presledek, pretvorbe naslovov in spola
                for ($Indx0=1;$Indx0 <= $StVrstic;$Indx0++){
                    if (mb_strlen($VUcenec[$Indx0][0],$encoding) > 12){
                        //'pobriše presledek pri emšo
                        $VUcenec[$Indx0][0]=mb_substr($VUcenec[$Indx0][0],1,13,$encoding);
                        
                        if (isDate($VUcenec[$Indx0][3])){
                            $Datum=new DateTime(isDate($VUcenec[$Indx0][3]));
                            $VUcenec[$Indx0][3]=$Datum->format('Y-m-d');
                        }else{
                            if (isDate('2'.substr($VUcenec[$Indx0][0],4,3)."-".substr($VUcenec[$Indx0][0],2,2)."-".substr($VUcenec[$Indx0][0],0,2))){
                                $Datum=new DateTime('2'.substr($VUcenec[$Indx0][0],4,3)."-".substr($VUcenec[$Indx0][0],2,2)."-".substr($VUcenec[$Indx0][0],0,2));
                                $VUcenec[$Indx0][3]=$Datum->format('Y-m-d');
                            }else{
                                $VUcenec[$Indx0][3]=$Danes->format('Y-m-d');
                            }
                        }
                        //'pretvori Ž v F pri spolu
                        if ($VUcenec[$Indx0][4]=="Ž"){ 
                            $VUcenec[$Indx0][4]="F";
                        }
                        /*
                        //'razstavi naslov: ulica,kraj,ZIP pošta -> ulica kraj, ZIP, pošta
                        $sarr=explode(",",$VUcenec[$Indx0][6]);
                        $VUcenec[$Indx0][6]=$sarr[0].", ".$sarr[1];
                        $sarr2=explode(" ",$sarr[2]);
                        $VUcenec[$Indx0][$StPolj+1]=$sarr2[0];
                        
                        $VUcenec[$Indx0][$StPolj+2]="";
                        for ($i=1;$i < count($sarr2);$i++){
                            $VUcenec[$Indx0][$StPolj+2]=$VUcenec[$Indx0][$StPolj+2]." ".$sarr[$i];
                        }
                        */
                        
                        //Tvori otrokov, materin in očetov naslov
                        $VUcenec[$Indx0][6]=$VUcenec[$Indx0][6]." ".$VUcenec[$Indx0][7];
                        //oče
                        $VUcenec[$Indx0][12]=$VUcenec[$Indx0][12]." ".$VUcenec[$Indx0][13].", ".$VUcenec[$Indx0][14]." ".$VUcenec[$Indx0][15];
                        //mati
                        $VUcenec[$Indx0][18]=$VUcenec[$Indx0][18]." ".$VUcenec[$Indx0][19].", ".$VUcenec[$Indx0][20]." ".$VUcenec[$Indx0][21];
                    }
                }
                $Polje[12][0]=1;
                $Polje[13][0]=1;
                $Polje[14][0]=1;
                $Polje[16][0]=1;
                $Polje[20][0]=1;
                $Polje[12][2]=6;
                $Polje[13][2]=8;
                $Polje[14][2]=9;
                $Polje[16][2]=12;
                $Polje[20][2]=18;
                
                $Polje[44][0]=0;
                $Polje[45][0]=0;
                $Polje[46][0]=0;
                $Polje[47][0]=0;
                $Polje[48][0]=0;
                $Polje[49][0]=0;
                $Polje[50][0]=0;
                $Polje[51][0]=0;
                $Polje[52][0]=0;
                $Polje[53][0]=0;
                $Polje[54][0]=0;
                $Polje[55][0]=0;
                $Polje[56][0]=0;
                $Polje[57][0]=0;
                $Polje[58][0]=0;
                $StPolj=58;

                for ($Indx=1;$Indx < $StVrstic;$Indx++){
                    //'vpis v tabucenci
                    $SQL = "SELECT id,iducenec,priimek,ime FROM tabucenci WHERE priimek='".$VUcenec[$Indx][$Polje[3][2]]."' AND ime='".$VUcenec[$Indx][$Polje[4][2]]."' AND emso='".$VUcenec[$Indx][$Polje[9][2]]."'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //'update
                        $SQL = "UPDATE tabucenci SET ";
                        for ($i1=4;$i1 <= $StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && $Polje[$i1][3]==0){
                                    if ($Polje[$i1][4]==0){
                                        $SQL = $SQL . $Polje[$i1][1]."='".$VUcenec[$Indx][$Polje[$i1][2]]."',";
                                    }else{
                                        $SQL = $SQL . $Polje[$i1][1]."=".$VUcenec[$Indx][$Polje[$i1][2]].",";
                                    }
                                }
                            }
                        }
                        $SQL = $SQL . "priimek='".$VUcenec[$Indx][$Polje[3][2]]."' WHERE id=".$R["id"];
                        echo "Popravljeno: ".$VUcenec[$Indx][$Polje[3][2]]." ".$VUcenec[$Indx][$Polje[4][2]]."<br />";
                        $VIdUcenec=$R["iducenec"];
                    }else{
                        //'insert
                        $StUcencevIndx=$StUcencevIndx+1;
                        $SQL = "INSERT INTO tabucenci (";
                        for ($i1=3;$i1 <=$StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && ($Polje[$i1][3]==0)){
                                    $SQL = $SQL . $Polje[$i1][1].",";
                                }
                            }
                        }
                        $SQL = $SQL . "IdUcenec,aktivnost,IdPosebnePotrebe,Bivanje) VALUES (";
                        for ($i1=3;$i1 <=$StPolj;$i1++){
                            if ($Polje[$i1][0]==1){
                                if (($Polje[$i1][1] != "") && ($Polje[$i1][3]==0)){
                                    if ($Polje[$i1][4]==0){
                                        $SQL = $SQL . "'".$VUcenec[$Indx][$Polje[$i1][2]]."',";
                                    }else{
                                        $SQL = $SQL . $VUcenec[$Indx][$Polje[$i1][2]].",";
                                    }
                                }
                            }
                        }
                        $SQL = $SQL . $StUcencevIndx .",1,1,0)";
                        $VIdUcenec=$StUcencevIndx;
                        echo "Vpis: ".$VUcenec[$Indx][$Polje[3][2]]." ".$VUcenec[$Indx][$Polje[4][2]]."<br />";
                    }
                    if (!($result = mysqli_query($link,$SQL))){
                        echo "Napaka pri vpisu!<br />";
                    }
                }
            }
            break;
    }
}
?>

</body>
</html>
