<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Prihodi - odhodi</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<script language="Javascript">
<!--
setInterval("settime()", 1000);

function settime () {
  var curtime = new Date();
  var curyear = curtime.getFullYear();
  var curmonth = curtime.getMonth()+1;
  var curday = curtime.getDate();
  var curhour = curtime.getHours()
  //var TimeOffset = curtime.getTimezoneOffset()/60;
  var curmin = curtime.getMinutes();
  var cursec = curtime.getSeconds();
  var time = "";
  var datum = "";
 
  time = curhour + ":" +
         (curmin < 10 ? "0" : "") + curmin + ":" +
         (cursec < 10 ? "0" : "") + cursec + " ";
  datum = curday + "." + curmonth + "." + curyear;
  document.obrazec.clock.value = time;
  document.obrazec.datum.value = datum;
  document.obrazec.delavec.focus();
}

function oddaj (gumbOddan) {
	document.obrazec.oddaj.value=gumbOddan;
	//document.writeln(document.obrazec.oddaj.value + '<br />');
	document.obrazec.submit();
}
//-->
</script>

</head>

<body >

<script type="text/javascript">
function addCode(key){
    var code = document.obrazec.delavec;
    if(code.value.length < 8){
        code.value = code.value + key;
    }
    if (key == "*"){
        code.value = "";
    }
    if (key == " "){
        code.value = code.value.substr(0,code.value.length-2);
    }
    if(code.value.length == 8){
        document.getElementById("message").style.display = "block";
        //setTimeout(submitForm,1000);    
    }
}

function submitForm(){
    document.obrazec.submit();
}

function emptyCode(){
    document.obrazec.delavec.value = "";
}
</script>
<style>
    
#keypad {margin:auto; margin-top:20px;}

#keypad tr td {
    vertical-align:middle; 
    text-align:center; 
    border:1px solid #000000; 
    font-size:72px; 
    font-weight:bold; 
    width:120px; 
    height:100px; 
    cursor:pointer; 
    background-color:#666666; 
    color:#CCCCCC;}
#keypad tr td:hover {background-color:#999999; color:#FFFF00;}

.display {
    width:130px; 
    margin:10px auto auto auto; 
    background-color:#000000; 
    color:#00FF00; 
    font-size:18px; 
    border:1px solid #999999;
}
#message {
    text-align:center; 
    color:#009900; 
    font-size:14px; 
    font-weight:bold; 
    display:none;
}
</style>

<form name="obrazec" method="post" action="VpisCasa.php">
<table border="0">
<tr><td>
	<table border="0">
	<tr><td>
	<input type="text" name="datum" style="border: 0px; font-size: 60pt" value="" size="10" readonly="readonly" ><br />
	<input type="text" name="clock" style="border: 0px; font-size: 60pt" value="" size="10" readonly="readonly" ><br />
    <input type="hidden" name="ip" value="<?php echo $_SERVER["REMOTE_ADDR"]; ?>">
	<input type="text" name="delavec" style="border: 1px; font-size: 60pt" value="" readonly="readonly" maxlength="8" size="8" >
	<input type="hidden" name="oddaj" value="0">
	</td>
	<td rowspan="2">
		<table id="keypad" cellpadding="5" cellspacing="3">
			<tr>
				<td onclick="addCode('1');">1</td>
				<td onclick="addCode('2');">2</td>
				<td onclick="addCode('3');">3</td>
			</tr>
			<tr>
				<td onclick="addCode('4');">4</td>
				<td onclick="addCode('5');">5</td>
				<td onclick="addCode('6');">6</td>
			</tr>
			<tr>
				<td onclick="addCode('7');">7</td>
				<td onclick="addCode('8');">8</td>
				<td onclick="addCode('9');">9</td>
			</tr>
			<tr>
				<td onclick="addCode('*');">*</td>
				<td onclick="addCode('0');">0</td>
				<td onclick="addCode(' ');">&#60;</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
<td>
	<table border="0">
	<tr>
            <td><INPUT name="oddaj1" TYPE="image" SRC="img/bPrihod.png" BORDER="0" ALT="Prihod"></td>
            <!--<td><INPUT name="oddaj2" TYPE="image" SRC="bMalica.png" BORDER="0" ALT="Malica"></td> -->
	</tr><tr>
            <!--<td><INPUT name="oddaj3" TYPE="image" SRC="bSluzbeno.png" BORDER="0" ALT="Službeno"></td>-->
            <td><INPUT name="oddaj4" TYPE="image" SRC="img/bIzhod.png" BORDER="0" ALT="Izhod"></td>
	</tr>
	</table>
</td>
</tr>
</table>
</form>

</body>
</html>
