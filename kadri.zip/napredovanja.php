<?php
include('const.php');
//ini_set('max_execution_time', 600); 
include('razredi.php');
include('iskanje.php');
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToOcena($x){
    switch ($x){
        case 1:
            return "NEZADOSTNO";
        case 2:
            return "ZADOSTNO";
        case 3:
            return "DOBRO";
        case 4:
            return "ZELO DOBRO";
        case 5:
            return "ODLIČNO";
    }
}
function stevnik($x){
    switch ($x){
        case 1:
            return "prva";
        case 2:
            return "druga";
        case 3:
            return "tretja";
    }
}
function ToOcenaTxt($x){
    switch ($x){
        case 1:
            return "nezadovoljivo, to je v celoti pod pričakovanji.";
        case 2:
            return "zadovoljivo, to je delno pod pričakovanji.";
        case 3:
            return "dobro, to je v skladu s pričakovanji.";
        case 4:
            return "zelo dobro, to je nad pričakovanji.";
        case 5:
            return "odlično, to je visoko nad pričakovanji.";
    }
}

if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        $VLeto=intval($Danes->format('Y'));
    }
}
$VLetoPregled=$VLeto;

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik="";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo="";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel=0;
}


$SQL = "SELECT iducitelj,ime,priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["ime"] . " " . $R["priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    if (isset($_POST["id"])){
        $id = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $id = $_GET["id"];
        }else{
            $id=0;
        }
    }

    switch ($id){
        case "1":
        case "1a":
        case "3":
        case "5":
        case "7":
        case "8":
        case "9":
        case "9a":
            break;
        default:
            echo "<html>";
            echo "<head>";
            echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
            echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
            echo "<title>Ocene delavcev in napredovanja";
            echo "</title>";
            echo "</head>";
            echo "<body>";
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
    }
    
    switch ($id){
        case "1": //dodajanje zapisov
            $delavec=$_POST["ime"];
            if ($delavec > 0){
                $delm=$_POST["delm"];
                if ($delm > 0){
                    $SQL = "SELECT id,placnirazbn,placnirazzn FROM tabdelmesta WHERE id=".$delm;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "INSERT INTO tabnapredovanja (iducitelj,rmax,rakt,rdelmosn,napredovanj,datznapred,napredod,napreddo,aneks,delm) VALUES (";
                        $SQL .= $delavec.",";
                        $SQL .= $R["placnirazzn"].",";
                        if (strlen($_POST["rakt"]) > 0){
                            $SQL .= $_POST["rakt"].",";
                        }else{
                            $SQL .= $R["placnirazbn"];
                        }
                        $SQL .= $R["placnirazbn"].",";
                        $SQL .= $_POST["napredovanj"].",";
                        $SQL .= "'".$_POST["datznapred"]."',";
                        $SQL .= "'".$_POST["napredod"]."',";
                        $SQL .= "'".$_POST["napreddo"]."',";
                        $SQL .= "'".$_POST["aneks"]."',";
                        $SQL .= $delm;
                        $SQL .= ")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die('Napaka pri vpisu delavca!<br />$SQL<br />');
                        }
                    }
                }
            }
            header("Location: napredovanja.php");
            break;
        case "1a": //dodajanje zapisov
            $delavec=$_POST["ime"];
            if ($delavec > 0){
                $delm=$_POST["delm"];
                if ($delm > 0){
                    $SQL = "SELECT id,placnirazbn,placnirazzn FROM tabdelmesta WHERE id=".$delm;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabnapredovanja SET ";
                        $SQL .= "iducitelj=".$delavec.",";
                        //if (strlen($_POST["rmax"]) > 0){
                        //    $SQL .= "rmax=".$_POST["rmax"].",";
                        //}else{
                            $SQL .= "rmax=".$R["placnirazzn"].",";
                        //}
                        if (strlen($_POST["rakt"]) > 0){
                            $SQL .= "rakt=".$_POST["rakt"].",";
                        }else{
                            $SQL .= "rakt=".$R["placnirazbn"];
                        }
                        $SQL .= "rdelmosn=".$R["placnirazbn"].",";
                        $SQL .= "napredovanj=".$_POST["napredovanj"].",";
                        $SQL .= "datznapred='".$_POST["datznapred"]."',";
                        $SQL .= "napredod='".$_POST["napredod"]."',";
                        $SQL .= "napreddo='".$_POST["napreddo"]."',";
                        $SQL .= "aneks='".$_POST["aneks"]."',";
                        $SQL .= "delm=".$delm;
                        $SQL .= " WHERE id=".$_POST["zapis"];
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri popravljanju delavca!<br />$SQL<br />");
                        }
                    }
                }
            }
            header("Location: napredovanja.php");
            break;
        case "2": //obrazec za vnos ocen delavca
            //polja v tabdelocena
            //    id   leto  ref  obdod   obddo   rdstrok   rdobs  rdprav  rdocena  sunsam  sunustv  sunnat  sunocena  zizpobv    zinf  zocena  ksosod  ksoorg  ksoocena  dsinter   dsodn   dskom  dsdrugo  dsocena   ocena  cas  spremenil  upostevaj
            ?>
            <script>
                function Vnesi5(){
                    document.getElementById("oc_1").value=5;
                    document.getElementById("oc_2").value=5;
                    document.getElementById("oc_3").value=5;
                    document.getElementById("oc_4").value=5;
                    document.getElementById("oc_5").value=5;
                    document.getElementById("oc_6").value=5;
                    document.getElementById("oc_7").value=5;
                    document.getElementById("oc_8").value=5;
                    document.getElementById("oc_9").value=5;
                    document.getElementById("oc_10").value=5;
                    document.getElementById("oc_11").value=5;
                    document.getElementById("oc_12").value=5;
                    document.getElementById("oc_13").value=5;
                    document.getElementById("oc_14").value=5;
                }

                function ocene(){
                    var oc_1=parseInt(document.getElementById("oc_1").value);
                    var oc_2=parseInt(document.getElementById("oc_2").value);
                    var oc_3=parseInt(document.getElementById("oc_3").value);
                    var oc_4=parseInt(document.getElementById("oc_4").value);
                    var oc_5=parseInt(document.getElementById("oc_5").value);
                    var oc_6=parseInt(document.getElementById("oc_6").value);
                    var oc_7=parseInt(document.getElementById("oc_7").value);
                    var oc_8=parseInt(document.getElementById("oc_8").value);
                    var oc_9=parseInt(document.getElementById("oc_9").value);
                    var oc_10=parseInt(document.getElementById("oc_10").value);
                    var oc_11=parseInt(document.getElementById("oc_11").value);
                    var oc_12=parseInt(document.getElementById("oc_12").value);
                    var oc_13=parseInt(document.getElementById("oc_13").value);
                    var oc_14=parseInt(document.getElementById("oc_14").value);
                    var ocs_1=0;
                    var ocs_2=0;
                    var ocs_3=0;
                    var ocs_4=0;
                    var ocs_5=0;
                    var ocs_6=0;
                    
                    if ((oc_1 != NaN) && (oc_2 != NaN) && (oc_3 != NaN)){
                        ocs_1=Math.round((oc_1+oc_2+oc_3+0.01)/3);
                        document.getElementById("ocs_1").innerHTML=Math.round((oc_1+oc_2+oc_3+0.01)/3);
                    }
                    if ((oc_4 != NaN) && (oc_5 != NaN) && (oc_6 != NaN)){
                        ocs_2=Math.round((oc_4+oc_5+oc_6+0.01)/3);
                        document.getElementById("ocs_2").innerHTML=Math.round((oc_4+oc_5+oc_6+0.01)/3);
                    }
                    if ((oc_7 != NaN) && (oc_8 != NaN)){
                        ocs_3=Math.round((oc_7+oc_8+0.01)/2);
                        document.getElementById("ocs_3").innerHTML=Math.round((oc_7+oc_8+0.01)/2);
                    }
                    if ((oc_9 != NaN) && (oc_10 != NaN)){
                        ocs_4=Math.round((oc_9+oc_10+0.01)/2);
                        document.getElementById("ocs_4").innerHTML=Math.round((oc_9+oc_10+0.01)/2);
                    }
                    if ((oc_11 != NaN) && (oc_12 != NaN) && (oc_13 != NaN) && (oc_14 != NaN)){
                        ocs_5=Math.round((oc_11+oc_12+oc_13+oc_14+0.01)/4);
                        document.getElementById("ocs_5").innerHTML=Math.round((oc_11+oc_12+oc_13+oc_14+0.01)/4);
                    }
                    document.getElementById("ocs_6").innerHTML=Math.round((ocs_1+ocs_2+ocs_3+ocs_4+ocs_5+0.01)/5);
                    return;
                }
            </script>
            <?php
            $zapis=$_GET["zapis"];
            
            $SQL = "SELECT tabnapredovanja.id,tabucitelji.priimek,tabucitelji.ime FROM tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj ";
            $SQL .= "ORDER BY tabucitelji.priimek,tabucitelji.ime";
            $result = mysqli_query($link,$SQL);
            $delavec=array();
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                $delavec[$i][0]=$R["id"];
                $delavec[$i][1]=$R["ime"]." ".$R["priimek"];
                $i += 1;
            }
            $stdelavcev=$i-1;
            $pravi=1;
            for ($i=1;$i <= $stdelavcev;$i++){
                if ($delavec[$i][0]==$zapis){
                    $pravi=$i;
                    break;
                }
            }
            
            echo "<h2>Ocenjevanje delavca</h2>";
            if ($pravi > 1){
                echo "<a href='napredovanja.php?id=2&zapis=".$delavec[$pravi-1][0]."'>Prejšnji (".$delavec[$pravi-1][1].")</a>";
            }
            echo " | ";
            if ($pravi < $stdelavcev){
                echo "<a href='napredovanja.php?id=2&zapis=".$delavec[$pravi+1][0]."'>Naslednji (".$delavec[$pravi+1][1].")</a>";
            }
            echo "<br />";
            $SQL = "SELECT tabnapredovanja.datznapred,tabucitelji.priimek,tabucitelji.ime FROM tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj ";
            $SQL .= "WHERE tabnapredovanja.id=".$zapis;
            $result = mysqli_query($link,$SQL);
            $letoZadnjegaNapredovanja=0;
            if ($R = mysqli_fetch_array($result)){
                echo "<h3>".$R["ime"]." ".$R["priimek"]."</h3>";
                if (isDate($R["datznapred"])){
                    $Datum=new DateTime(isDate($R["datznapred"]));
                    $letoZadnjegaNapredovanja=$Datum->format('Y');
                }
            }
            echo "<form name='ocena' accept-charset='utf-8' method='post' action='napredovanja.php' onchange=ocene()>";
            echo "<input name='id' type='hidden' value='5'>";
            echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
            echo "<table>";
            echo "<tr>";
            echo "<th>Področje</th>";
            echo "<th>Sposobnost</th>";
            $SQL = "SELECT DISTINCT leto FROM tabdelocena WHERE ref=".$zapis." AND leto >=$letoZadnjegaNapredovanja ORDER BY leto";
            $result = mysqli_query($link,$SQL);
            $leto=$Danes->format('Y')-1;
            $stocen=0;
            $letoocen=array();
            $i=1;
            if (mysqli_num_rows($result) > 0){
                while ($R = mysqli_fetch_array($result)){
                    echo "<th>".$R["leto"]."</th>";
                    $stocen += 1;
                    $letoocen[$i]=$R["leto"];
                    $i += 1;
                }
            }
            echo "<td><select name='letooc'>";
            for ($i=$leto-5;$i <= $leto+1;$i++){
                if ($leto == $i){
                    echo "<option value='".$i."' selected='selected'>$i</option>";
                }else{
                    echo "<option value='".$i."'>$i</option>";
                }
            }
            echo "</select>";
            echo "<input name='gumb' type='button' value='Vse 5' onmousedown=Vnesi5()>";
            echo "</td>";
            echo "</tr>";
            
            echo "<tr>";
            echo "<td rowspan='2'>Ocenjevalno<br />obdobje</td>";
            echo "<td>od</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT obdod FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td>".$R["obdod"]."</td>";
                }
            }
            echo "<td><input name='obdod' type='text' value='1.1.' size='10'></td>";
            echo "</tr>";
            echo "<tr>";
            //echo "<td>Ocenjevalno obdobje</td>";
            echo "<td>do</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT obddo FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td>".$R["obddo"]."</td>";
                }
            }
            echo "<td><input name='obddo' type='text' value='31.12.' size='10'></td>";
            echo "</tr>";

            //rezultati dela
            echo "<tr>";
            echo "<td rowspan='4'>rezultati<br />dela</td>";
            echo "<td>strokovnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT rdstrok FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["rdstrok"]."</td>";
                }
            }
            echo "<td><input id='oc_1' name='rdstrok' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>obseg</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT rdobs FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["rdobs"]."</td>";
                }
            }
            echo "<td><input id='oc_2' name='rdobs' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>pravočasnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT rdprav FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["rdprav"]."</td>";
                }
            }
            echo "<td><input id='oc_3' name='rdprav' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT rdocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["rdocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_1'>&nbsp;</div></td>";
            echo "</tr>";
            
            //samostojnost, ustvarjalnost in natančnost
            echo "<tr>";
            echo "<td rowspan='4'>samostojnost,<br />ustvarjalnost in<br />natančnost</td>";
            echo "<td>samostojnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT sunsam FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["sunsam"]."</td>";
                }
            }
            echo "<td><input id='oc_4' name='sunsam' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>ustvarjalnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT sunustv FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["sunustv"]."</td>";
                }
            }
            echo "<td><input id='oc_5' name='sunustv' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>natančnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT sunnat FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["sunnat"]."</td>";
                }
            }
            echo "<td><input id='oc_6' name='sunnat' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT sunocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["sunocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_2'>&nbsp;</div></td>";
            echo "</tr>";
            
            //zanesljivost
            echo "<tr>";
            echo "<td rowspan='3'>zanesljivost</td>";
            echo "<td>izpolnjevanje<br />obveznosti</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT zizpobv FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["zizpobv"]."</td>";
                }
            }
            echo "<td><input id='oc_7' name='zizpobv' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>popoln in točen<br />prenos informacij</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT zinf FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["zinf"]."</td>";
                }
            }
            echo "<td><input id='oc_8' name='zinf' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT zocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["zocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_3'>&nbsp;</div></td>";
            echo "</tr>";
            
            //kvaliteta sodelovanja in organizacija dela
            echo "<tr>";
            echo "<td rowspan='3'>kvaliteta<br />sodelovanja in<br />organizacija dela</td>";
            echo "<td>sodelovanje</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT ksosod FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["ksosod"]."</td>";
                }
            }
            echo "<td><input id='oc_9' name='ksosod' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>organizacija<br />dela</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT ksoorg FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["ksoorg"]."</td>";
                }
            }
            echo "<td><input id='oc_10' name='ksoorg' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT ksoocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["ksoocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_4'>&nbsp;</div></td>";
            echo "</tr>";
            
            //druge sposobnosti
            echo "<tr>";
            echo "<td rowspan='5'>druge<br />sposobnosti</td>";
            echo "<td>interdisciplinarnost</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT dsinter FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["dsinter"]."</td>";
                }
            }
            echo "<td><input id='oc_11' name='dsinter' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>odnos do<br />uporabnikov<br />storitev</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT dsodn FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["dsodn"]."</td>";
                }
            }
            echo "<td><input id='oc_12' name='dsodn' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>komuniciranje</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT dskom FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["dskom"]."</td>";
                }
            }
            echo "<td><input id='oc_13' name='dskom' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td>drugo</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT dsdrugo FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'>".$R["dsdrugo"]."</td>";
                }
            }
            echo "<td><input id='oc_14' name='dsdrugo' type='text' value='' size='2'></td>";
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT dsocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["dsocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_5'>&nbsp;</div></td>";
            echo "</tr>";
            
            //skupna ocena
            echo "<tr class='head'>";
            echo "<td colspan='2'>Skupaj</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT ocena FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td align='center'><b>".$R["ocena"]."</b></td>";
                }
            }
            echo "<td><div id='ocs_6'>&nbsp;</div></td>";
            echo "</tr>";

            //upoštevanje ocene
            echo "<tr>";
            echo "<td colspan='2'>Upoštevaj oceno</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT upostevaj FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    if ($R["upostevaj"]){
                        echo "<td align='center'><input name='upostevaj_".$letoocen[$i]."' type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td align='center'><input name='upostevaj_".$letoocen[$i]."' type='checkbox'></td>";
                    }
                }
            }
 //           echo "<td align='center'><input name='upostevaj' type='checkbox' checked='checked'></td>";
            echo "<td align='center'><input name='upostevaj' type='checkbox'></td>";
            echo "</tr>";
            
            echo "<tr>";
            echo "<td colspan='2'>&nbsp;</td>";
            for ($i=1;$i <= $stocen;$i++){
                $SQL = "SELECT id FROM tabdelocena WHERE ref=$zapis AND leto=".$letoocen[$i];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td><a href='napredovanja.php?id=6&zapis=$zapis&letooc=".$letoocen[$i]."&ocena=".$R["id"]."'>Popravi</a></td>";
                }
            }
            echo "<td><input type='submit' value='Pošlji' name='submit'></td>";
            echo "</tr>";
            echo "</table>";
            echo "</form>";
            
            //evidenčni list
            echo "<br />";
            echo "<h3>Izberite tri različna ocenjevalna obdobja, ki se jih bo upoštevalo v evidenčnem listu za napredovanje</h3><hr>";
            
            $SQL = "SELECT * FROM tabdelocena WHERE upostevaj=true AND ref=$zapis AND leto >=$letoZadnjegaNapredovanja ORDER BY leto DESC LIMIT 0,3";
            $result = mysqli_query($link,$SQL);
            $i=1;
            $skupnaocena=0;
            while ($R = mysqli_fetch_array($result)){
                $obdobje[$i]=$R["leto"];
                $skupnaocena += $R["ocena"];
                $i += 1;
            }
            $obdobij=$i-1;
            echo "<table>";
            for ($i=1;$i <= $obdobij;$i++){
                echo "<tr><td>$i. ocenjevalno obdobje</td><td>".$obdobje[$i]."</td></tr>";
            }
            echo "<tr><td><b>SKUPAJ</b></td><td><b>".$skupnaocena."</b></td></tr>";
            echo "</table><br />";
            
            $SQL = "SELECT * FROM tabnapredovanja WHERE id=$zapis";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "Število napredovanj do sedaj: ".$R["napredovanj"]."<br />";
                echo "<table>";
                echo "<tr>";
                echo "<td>Ob ".($R["napredovanj"]+1).". napredovanju:</td>";
                echo "<td>&nbsp;</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>je potrebno za napredovanje za en plačni razred najmanj število točk:</td>";
                echo "<td><b>";
                $potrebno1=0;
                switch ($R["napredovanj"]){
                    case 0:
                    case 1:
                    case 2:
                        echo "11 točk";
                        $potrebno1=11;
                        break;
                    case 3:
                    case 4:
                        echo "12 točk";
                        $potrebno1=12;
                        break;
                    case 5:
                        echo "13 točk";
                        $potrebno1=13;
                        break;
                    default:
                        echo "14 točk";
                        $potrebno1=14;
                }
                echo "</b></td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>je potrebno za napredovanje za dva plačna razreda najmanj število točk:</td>";
                echo "<td><b>";
                $potrebno2=0;
                switch ($R["napredovanj"]){
                    case 0:
                    case 1:
                        echo "14 točk";
                        $potrebno2=14;
                        break;
                    default:
                        echo "15 točk";
                        $potrebno2=15;
                }
                echo "</b></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td>Število plačnih razredov, za kolikor bi delavec lahko napredoval:</td>";
                echo "<td><b>";
                if ($skupnaocena >= $potrebno2){
                    $napredovanje=2;
                    echo "2";
                }else{
                    if ($skupnaocena >= $potrebno1){
                        $napredovanje=1;
                        echo "1";
                    }else{
                        $napredovanje=0;
                        echo "0";
                    }
                }
                echo "</b></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td>Najvišji plačni razred, ki ga lahko doseže delavec:</td>";
                echo "<td><b>";
                echo $R["rmax"];
                echo "</b></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td>Plačni razred javnega uslužbenca:</td>";
                echo "<td><b>";
                echo $R["rakt"];
                echo "</b></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td>Koliko razredov lahko delavec še napreduje na delovnem mestu:</td>";
                echo "<td><b>";
                echo $R["rmax"]-$R["rakt"];
                echo "</b></td>";
                echo "</tr>";
                
                echo "<tr>";
                echo "<td><b>Število plačnih razredov, za kolikor delavec lahko napreduje:</b></td>";
                echo "<td><b>";
                if ($napredovanje > $R["rmax"]-$R["rakt"]){
                    echo $R["rmax"]-$R["rakt"];
                    $napredovanje=$R["rmax"]-$R["rakt"];
                }else{
                    echo $napredovanje;
                }
                echo "</b></td>";
                echo "</tr>";
                
                echo "</table><br />";
                echo "<a href='napredovanja.php?id=9&zapis=$zapis&napredovanj=$napredovanje'>Izpis evidenčnega lista v PDF</a><br />";
                echo "<a href='napredovanja.php?id=9a&zapis=$zapis&napredovanj=$napredovanje'>Pisno obvestilo delavcu v PDF</a><br /><br />";
            }else{
                echo "Zapis ne obstaja!<br />";
            }
            
            break;
        case "3": //briši delvca in vse njegove ocene
            $SQL = "DELETE FROM tabnapredovanja WHERE id=".$_GET["zapis"];
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri brisanju delavca!<br />$SQL<br />");
            }
            $SQL = "DELETE FROM tabdelocena WHERE ref=".$_GET["zapis"];
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri brisanju ocen delavca!<br />$SQL<br />");
            }
            header("Location: napredovanja.php");
            break;
        case "4": //popravi podatke o delavcu
            echo "<h2>Spisek delavcev za ocenjevanje in napredovanja</h2>";
            echo "<form name='napredovanja' accept-charset='utf-8' method='post' action='napredovanja.php' >";
            echo "<input name='id' type='hidden' value='1a'>";
            echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
            echo "<table>";
            echo "<tr>";
            echo "<th>Št.</th>";
            echo "<th>Delavec</th>";
            echo "<th>Dat.roj.</th>";
            echo "<th>Pl.razr.<br />Max</th>";
            echo "<th>Pl.razr.<br />akt.</th>";
            echo "<th>Pl.razr.<br />osn.DM</th>";
            echo "<th>Št.<br />napredovanj</th>";
            echo "<th>Datum<br />zadnj. napred.</th>";
            echo "<th>obdobje<br />od</th>";
            echo "<th>obdobje<br />do</th>";
            echo "<th>št. in datum<br />aneksa</th>";
            echo "<th>šifra in<br />ime DM</th>";
            echo "<th>Briši</th>";
            echo "<th>Popravi</th>";
            echo "<th>Ocene</th>";
            echo "</tr>";
            
            $SQL = "SELECT tabnapredovanja.*,tabucitelji.ime,tabucitelji.priimek,tabucitelji.datroj,tabdelmesta.sifra,tabdelmesta.delmesto FROM (tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabdelmesta ON tabnapredovanja.delm=tabdelmesta.id ";
            $SQL .= "WHERE tabnapredovanja.id=".$_GET["zapis"];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>&nbsp;</td>";
                echo "<td>";
                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                $result1 = mysqli_query($link,$SQL);
                echo "<select name='ime'>";
                echo "<option value='0'>Ni izbran</option>";
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($R1["iducitelj"] == $R["iducitelj"]){
                        echo "<option value='".$R1["iducitelj"]."' selected='selected'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                    }else{
                        echo "<option value='".$R1["iducitelj"]."'>".$R1["priimek"]." ".$R1["ime"]."</option>";
                    }
                }
                echo "</select>";
                echo "</td>";
                echo "<td>&nbsp;</td>";
                echo "<td><input name='rmax' type='text' value='".$R["rmax"]."' size='3'></td>";
                echo "<td><input name='rakt' type='text' value='".$R["rakt"]."' size='3'></td>";
                echo "<td><input name='rdelmosn' type='text' value='".$R["rdelmosn"]."' size='3'></td>";
                echo "<td><input name='napredovanj' type='text' value='".$R["napredovanj"]."' size='2'></td>";
                echo "<td><input name='datznapred' type='text' value='".$R["datznapred"]."' size='10'></td>";
                echo "<td><input name='napredod' type='text' value='".$R["napredod"]."' size='10'></td>";
                echo "<td><input name='napreddo' type='text' value='".$R["napreddo"]."' size='10'></td>";
                echo "<td><input name='aneks' type='text' value='".$R["aneks"]."' size='15'></td>";
                echo "<td>";
                $SQL = "SELECT id,sifra,delmesto,placnirazbn,placnirazzn FROM tabdelmesta";
                $result1 = mysqli_query($link,$SQL);
                echo "<select name='delm'>";
                echo "<option value='0'>Ni izbrano</option>";
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($R1["id"]==$R["delm"]){
                        echo "<option value='".$R1["id"]."' selected='selected'>".$R1["sifra"]." - ".$R1["delmesto"]."</option>";
                    }else{
                        echo "<option value='".$R1["id"]."'>".$R1["sifra"]." - ".$R1["delmesto"]."</option>";
                    }
                }
                echo "</td>";
                echo "<td colspan='3' align='center'><input type='submit' value='Popravi' name='submit'></td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "</form>";

            break;
        case "5": //vpis ocene
            if (!CheckDostop("drugo6",$VUporabnik) ) {
                //header("Location: nepooblascen.htm");
                echo "Nimate pravic za vpisovanje ocen delavcem!<br />";
            }else{
                $ref=$_POST["zapis"];
                $letooc=$_POST["letooc"];
                $SQL = "SELECT leto FROM tabdelocena WHERE ref=$ref AND leto=$letooc";
                $result1 = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result1) == 0){
                    $obdod=$_POST["obdod"];
                    if (strlen($obdod) <= 6){
                        $obdod=$obdod.$letooc;
                    }
                    if (isDate($obdod)){
                        $datod=new DateTime(isDate($obdod));
                    }else{
                        $datod=new DateTime($letooc."-1-1");
                    }
                    $obddo=$_POST["obddo"];
                    if (strlen($obddo) <= 6){
                        $obddo=$obddo.$letooc;
                    }
                    if (isDate($obddo)){
                        $datdo=new DateTime(isDate($obddo));
                    }else{
                        $datdo=new DateTime($letooc."-12-31");
                    }
                    $rdstrok=intval($_POST["rdstrok"]);
                    $rdobs=intval($_POST["rdobs"]);
                    $rdprav=intval($_POST["rdprav"]);
                    $rdocena=round(($rdstrok+$rdobs+$rdprav+0.01)/3,0);
                    $sunsam=intval($_POST["sunsam"]);
                    $sunustv=intval($_POST["sunustv"]);
                    $sunnat=intval($_POST["sunnat"]);
                    $sunocena=round(($sunsam+$sunustv+$sunnat+0.01)/3,0);
                    $zizpobv=intval($_POST["zizpobv"]);
                    $zinf=intval($_POST["zinf"]);
                    $zocena=round(($zizpobv+$zinf+0.01)/2,0);
                    $ksosod=intval($_POST["ksosod"]);
                    $ksoorg=intval($_POST["ksoorg"]);
                    $ksoocena=round(($ksosod+$ksoorg+0.01)/2,0);
                    $dsinter=intval($_POST["dsinter"]);
                    $dsodn=intval($_POST["dsodn"]);
                    $dskom=intval($_POST["dskom"]);
                    $dsdrugo=intval($_POST["dsdrugo"]);
                    $dsocena=round(($dsinter+$dsodn+$dskom+$dsdrugo+0.01)/4,0);
                    if (isset($_POST["upostevaj"])){
                        $upostevaj="true";
                    }else{
                        $upostevaj="false";
                    }
                    $ocena=round(($rdocena+$sunocena+$zocena+$ksoocena+$dsocena)/5,0);
                    
                    $SQL = "INSERT INTO tabdelocena (ref,leto,obdod,obddo,rdstrok,rdobs,rdprav,rdocena,sunsam,sunustv,sunnat,sunocena,zizpobv,zinf,zocena,ksosod,ksoorg,ksoocena,dsinter,dsodn,dskom,dsdrugo,dsocena,ocena,cas,spremenil,upostevaj) VALUES (";
                    $SQL .= $ref.",";
                    $SQL .= $letooc.",";
                    $SQL .= "'".$datod->format('d.m.Y')."',";
                    $SQL .= "'".$datdo->format('d.m.Y')."',";
                    $SQL .= $rdstrok.",";
                    $SQL .= $rdobs.",";
                    $SQL .= $rdprav.",";
                    $SQL .= $rdocena.",";
                    $SQL .= $sunsam.",";
                    $SQL .= $sunustv.",";
                    $SQL .= $sunnat.",";
                    $SQL .= $sunocena.",";
                    $SQL .= $zizpobv.",";
                    $SQL .= $zinf.",";
                    $SQL .= $zocena.",";
                    $SQL .= $ksosod.",";
                    $SQL .= $ksoorg.",";
                    $SQL .= $ksoocena.",";
                    $SQL .= $dsinter.",";
                    $SQL .= $dsodn.",";
                    $SQL .= $dskom.",";
                    $SQL .= $dsdrugo.",";
                    $SQL .= $dsocena.",";
                    $SQL .= $ocena.",";
                    $SQL .= "'".$Danes->format('Y-m-d H:i:s')."',";
                    $SQL .= "'".$VUporabnik."',";
                    $SQL .= $upostevaj;
                    $SQL .= ")";
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu ocene delavca!<br />$SQL<br />");
                    }
                }
                header("Location: napredovanja.php?id=2&zapis=$ref");
            }
            break;
        case "6": //popravi letno oceno
            ?>
            <script>
                function ocene(){
                    var oc_1=parseInt(document.getElementById("oc_1").value);
                    var oc_2=parseInt(document.getElementById("oc_2").value);
                    var oc_3=parseInt(document.getElementById("oc_3").value);
                    var oc_4=parseInt(document.getElementById("oc_4").value);
                    var oc_5=parseInt(document.getElementById("oc_5").value);
                    var oc_6=parseInt(document.getElementById("oc_6").value);
                    var oc_7=parseInt(document.getElementById("oc_7").value);
                    var oc_8=parseInt(document.getElementById("oc_8").value);
                    var oc_9=parseInt(document.getElementById("oc_9").value);
                    var oc_10=parseInt(document.getElementById("oc_10").value);
                    var oc_11=parseInt(document.getElementById("oc_11").value);
                    var oc_12=parseInt(document.getElementById("oc_12").value);
                    var oc_13=parseInt(document.getElementById("oc_13").value);
                    var oc_14=parseInt(document.getElementById("oc_14").value);
                    var ocs_1=0;
                    var ocs_2=0;
                    var ocs_3=0;
                    var ocs_4=0;
                    var ocs_5=0;
                    var ocs_6=0;
                    
                    if ((oc_1 != NaN) && (oc_2 != NaN) && (oc_3 != NaN)){
                        ocs_1=Math.round((oc_1+oc_2+oc_3+0.01)/3);
                        document.getElementById("ocs_1").innerHTML=Math.round((oc_1+oc_2+oc_3+0.01)/3);
                    }
                    if ((oc_4 != NaN) && (oc_5 != NaN) && (oc_6 != NaN)){
                        ocs_2=Math.round((oc_4+oc_5+oc_6+0.01)/3);
                        document.getElementById("ocs_2").innerHTML=Math.round((oc_4+oc_5+oc_6+0.01)/3);
                    }
                    if ((oc_7 != NaN) && (oc_8 != NaN)){
                        ocs_3=Math.round((oc_7+oc_8+0.01)/2);
                        document.getElementById("ocs_3").innerHTML=Math.round((oc_7+oc_8+0.01)/2);
                    }
                    if ((oc_9 != NaN) && (oc_10 != NaN)){
                        ocs_4=Math.round((oc_9+oc_10+0.01)/2);
                        document.getElementById("ocs_4").innerHTML=Math.round((oc_9+oc_10+0.01)/2);
                    }
                    if ((oc_11 != NaN) && (oc_12 != NaN) && (oc_13 != NaN) && (oc_14 != NaN)){
                        ocs_5=Math.round((oc_11+oc_12+oc_13+oc_14+0.01)/4);
                        document.getElementById("ocs_5").innerHTML=Math.round((oc_11+oc_12+oc_13+oc_14+0.01)/4);
                    }
                    document.getElementById("ocs_6").innerHTML=Math.round((ocs_1+ocs_2+ocs_3+ocs_4+ocs_5+0.01)/5);
                    return;
                }
            </script>
            <?php
            echo "<h2>Ocenjevanje delavca</h2>";
            echo "<form name='ocena' accept-charset='utf-8' method='post' action='napredovanja.php' onchange=ocene()>";
            echo "<input name='id' type='hidden' value='7'>";
            echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
            $zapis=$_GET["zapis"];
            $letooc=$_GET["letooc"];
            $ocena=$_GET["ocena"]; //id zapisa
            echo "<input name='ocena' type='hidden' value='".$ocena."'>";
            echo "<table>";
            echo "<tr>";
            echo "<th>Področje</th>";
            echo "<th>Sposobnost</th>";
            $leto=$letooc;
            $stocen=0;
            echo "<td><select name='letooc'>";
            for ($i=$leto-5;$i <= $leto+1;$i++){
                if ($leto == $i){
                    echo "<option value='".$i."' selected='selected'>$i</option>";
                }else{
                    echo "<option value='".$i."'>$i</option>";
                }
            }
            echo "</select></td>";
            echo "</tr>";
            
            echo "<tr>";
            echo "<td rowspan='2'>Ocenjevalno<br />obdobje</td>";
            echo "<td>od</td>";
            $SQL = "SELECT obdod FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input name='obdod' type='text' value='".$R["obdod"]."' size='10'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            //echo "<td>Ocenjevalno obdobje</td>";
            echo "<td>do</td>";
            $SQL = "SELECT obddo FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input name='obddo' type='text' value='".$R["obddo"]."' size='10'></td>";
            }
            echo "</tr>";

            //rezultati dela
            echo "<tr>";
            echo "<td rowspan='4'>rezultati<br />dela</td>";
            echo "<td>strokovnost</td>";
            $SQL = "SELECT rdstrok FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_1' name='rdstrok' type='text' value='".$R["rdstrok"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>obseg</td>";
            $SQL = "SELECT rdobs FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_2' name='rdobs' type='text' value='".$R["rdobs"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>pravočasnost</td>";
            $SQL = "SELECT rdprav FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_3' name='rdprav' type='text' value='".$R["rdprav"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            $SQL = "SELECT rdocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_1'><b>".$R["rdocena"]."</b></div></td>";
            }
            echo "</tr>";
            
            //samostojnost, ustvarjalnost in natančnost
            echo "<tr>";
            echo "<td rowspan='4'>samostojnost,<br />ustvarjalnost in<br />natančnost</td>";
            echo "<td>samostojnost</td>";
            $SQL = "SELECT sunsam FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_4' name='sunsam' type='text' value='".$R["sunsam"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>ustvarjalnost</td>";
            $SQL = "SELECT sunustv FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_5' name='sunustv' type='text' value='".$R["sunustv"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>natančnost</td>";
            $SQL = "SELECT sunnat FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_6' name='sunnat' type='text' value='".$R["sunnat"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            $SQL = "SELECT sunocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_2'><b>".$R["sunocena"]."</b></div></td>";
            }
            echo "</tr>";
            
            //zanesljivost
            echo "<tr>";
            echo "<td rowspan='3'>zanesljivost</td>";
            echo "<td>izpolnjevanje<br />obveznosti</td>";
            $SQL = "SELECT zizpobv FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_7' name='zizpobv' type='text' value='".$R["zizpobv"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>popoln in točen<br />prenos informacij</td>";
            $SQL = "SELECT zinf FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_8' name='zinf' type='text' value='".$R["zinf"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            $SQL = "SELECT zocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_3'><b>".$R["zocena"]."</b></div></td>";
            }
            echo "</tr>";
            
            //kvaliteta sodelovanja in organizacija dela
            echo "<tr>";
            echo "<td rowspan='3'>kvaliteta<br />sodelovanja in<br />organizacija dela</td>";
            echo "<td>sodelovanje</td>";
            $SQL = "SELECT ksosod FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_9' name='ksosod' type='text' value='".$R["ksosod"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>organizacija<br />dela</td>";
            $SQL = "SELECT ksoorg FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_10' name='ksoorg' type='text' value='".$R["ksoorg"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            $SQL = "SELECT ksoocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_4'><b>".$R["ksoocena"]."</b></div></td>";
            }
            echo "</tr>";
            
            //druge sposobnosti
            echo "<tr>";
            echo "<td rowspan='5'>druge<br />sposobnosti</td>";
            echo "<td>interdisciplinarnost</td>";
            $SQL = "SELECT dsinter FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_11' name='dsinter' type='text' value='".$R["dsinter"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>odnos do<br />uporabnikov<br />storitev</td>";
            $SQL = "SELECT dsodn FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_12' name='dsodn' type='text' value='".$R["dsodn"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>komuniciranje</td>";
            $SQL = "SELECT dskom FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_13' name='dskom' type='text' value='".$R["dskom"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr>";
            echo "<td>drugo</td>";
            $SQL = "SELECT dsdrugo FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><input id='oc_14' name='dsdrugo' type='text' value='".$R["dsdrugo"]."' size='2'></td>";
            }
            echo "</tr>";
            echo "<tr class='head'>";
            echo "<td>ocena</td>";
            $SQL = "SELECT dsocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_5'><b>".$R["dsocena"]."</b></div></td>";
            }
            echo "</tr>";
            
            //skupna ocena
            echo "<tr class='head'>";
            echo "<td colspan='2'>Skupaj</td>";
            $SQL = "SELECT ocena FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<td><div id='ocs_6'><b>".$R["ocena"]."</b></div></td>";
            }
            echo "</tr>";

            //upoštevanje ocene
            echo "<tr>";
            echo "<td colspan='2'>Upoštevaj oceno</td>";
            $SQL = "SELECT upostevaj FROM tabdelocena WHERE ref=$zapis AND leto=".$leto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($R["upostevaj"]){
                    echo "<td align='center'><input name='upostevaj' type='checkbox' checked='checked'></td>";
                }else{
                    echo "<td align='center'><input name='upostevaj' type='checkbox'></td>";
                }
            }
            echo "</tr>";
            
            echo "<tr>";
            echo "<td colspan='2'>&nbsp;</td>";
            echo "<td><input type='submit' value='Pošlji' name='submit'></td>";
            echo "</tr>";
            echo "</table>";
            echo "</form>";
            break;
        case "7": //vpis popravka
            if (!CheckDostop("drugo6",$VUporabnik) ) {
                echo "Nimate pravic za vpisovanje ocen delavcem!<br />";
            }else{
                $idocena=$_POST["ocena"]; //id ocene
                $ref=$_POST["zapis"];
                $letooc=$_POST["letooc"];
                $SQL = "SELECT leto FROM tabdelocena WHERE ref=$ref AND leto=$letooc";
                $result1 = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result1) > 0){
                    $obdod=$_POST["obdod"];
                    if (strlen($obdod) <= 6){
                        $obdod=$obdod.$letooc;
                    }
                    if (isDate($obdod)){
                        $datod=new DateTime(isDate($obdod));
                    }else{
                        $datod=new DateTime($letooc."-1-1");
                    }
                    $obddo=$_POST["obddo"];
                    if (strlen($obddo) <= 6){
                        $obddo=$obddo.$letooc;
                    }
                    if (isDate($obddo)){
                        $datdo=new DateTime(isDate($obddo));
                    }else{
                        $datdo=new DateTime($letooc."-12-31");
                    }
                    $rdstrok=intval($_POST["rdstrok"]);
                    $rdobs=intval($_POST["rdobs"]);
                    $rdprav=intval($_POST["rdprav"]);
                    $rdocena=round(($rdstrok+$rdobs+$rdprav+0.01)/3,0);
                    $sunsam=intval($_POST["sunsam"]);
                    $sunustv=intval($_POST["sunustv"]);
                    $sunnat=intval($_POST["sunnat"]);
                    $sunocena=round(($sunsam+$sunustv+$sunnat+0.01)/3,0);
                    $zizpobv=intval($_POST["zizpobv"]);
                    $zinf=intval($_POST["zinf"]);
                    $zocena=round(($zizpobv+$zinf+0.01)/2,0);
                    $ksosod=intval($_POST["ksosod"]);
                    $ksoorg=intval($_POST["ksoorg"]);
                    $ksoocena=round(($ksosod+$ksoorg+0.01)/2,0);
                    $dsinter=intval($_POST["dsinter"]);
                    $dsodn=intval($_POST["dsodn"]);
                    $dskom=intval($_POST["dskom"]);
                    $dsdrugo=intval($_POST["dsdrugo"]);
                    $dsocena=round(($dsinter+$dsodn+$dskom+$dsdrugo+0.01)/4,0);
                    if (isset($_POST["upostevaj"])){
                        $upostevaj="true";
                    }else{
                        $upostevaj="false";
                    }
                    $ocena=round(($rdocena+$sunocena+$zocena+$ksoocena+$dsocena)/5,0);
                    
                    $SQL = "UPDATE tabdelocena SET ";
                    //$SQL .= "ref=".$ref.",";
                    $SQL .= "leto=".$letooc.",";
                    $SQL .= "obdod='".$datod->format('d.m.Y')."',";
                    $SQL .= "obddo='".$datdo->format('d.m.Y')."',";
                    $SQL .= "rdstrok=".$rdstrok.",";
                    $SQL .= "rdobs=".$rdobs.",";
                    $SQL .= "rdprav=".$rdprav.",";
                    $SQL .= "rdocena=".$rdocena.",";
                    $SQL .= "sunsam=".$sunsam.",";
                    $SQL .= "sunustv=".$sunustv.",";
                    $SQL .= "sunnat=".$sunnat.",";
                    $SQL .= "sunocena=".$sunocena.",";
                    $SQL .= "zizpobv=".$zizpobv.",";
                    $SQL .= "zinf=".$zinf.",";
                    $SQL .= "zocena=".$zocena.",";
                    $SQL .= "ksosod=".$ksosod.",";
                    $SQL .= "ksoorg=".$ksoorg.",";
                    $SQL .= "ksoocena=".$ksoocena.",";
                    $SQL .= "dsinter=".$dsinter.",";
                    $SQL .= "dsodn=".$dsodn.",";
                    $SQL .= "dskom=".$dskom.",";
                    $SQL .= "dsdrugo=".$dsdrugo.",";
                    $SQL .= "dsocena=".$dsocena.",";
                    $SQL .= "ocena=".$ocena.",";
                    $SQL .= "cas='".$Danes->format('Y-m-d H:i:s')."',";
                    $SQL .= "spremenil='".$VUporabnik."',";
                    $SQL .= "upostevaj=".$upostevaj;
                    $SQL .= " WHERE id=".$idocena;
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu popravka ocene delavca!<br />$SQL<br />");
                    }
                }
                header("Location: napredovanja.php?id=2&zapis=$ref");
            }
            break;
        case "8": //ocenjevalni listi
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix=$_SESSION["RefStFix"];
            }else{
                $RefStFix="";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar=$_SESSION["RefStVar"];
            }else{
                $RefStVar=1;
            }
            $leto=$_POST["letooc"];
            $pdf = new FPDF();

            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }

            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }
            
            $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.spol,tabucitelji.priimek,tabucitelji.ime,tabdelocena.* FROM (tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabdelocena ON tabnapredovanja.id=tabdelocena.ref ";
            $SQL .= "WHERE leto=$leto ORDER BY tabucitelji.priimek,tabucitelji.ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $pdf->AddPage("P","A4");
                $XPoz[1]=15;
                $XPoz[2]=110;
                $YPoz=240;
                $YPozDiff=4.5;
                
                //$pdf->Image("logo1.gif",15,10,30);
                //podatki o šoli
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin($VSola);
                $pdf->SetXY($XPoz[1],18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY($XPoz[1],22);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                if (strlen($RefStFix) == 0){
                    $SQL = "SELECT evstev,datum FROM tabevstevilked WHERE iducitelj=".$R["iducitelj"]." AND leto=".($leto+1)." AND dokument=2";
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $txt=ToWin("Evid. št.: ".$R1["evstev"]);
                        $pdf->SetXY($XPoz[1],26);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }else{
                        $txt=ToWin("Evid. št.: ");
                        $pdf->SetXY($XPoz[1],26);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }
                }else{
                    $txt=ToWin("Evid. št.: ".$RefStFix."-".$RefStVar."/".$VLeto);
                    $RefStVar += 1;
                    $pdf->SetXY($XPoz[1],26);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                //ravnatelj
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(100,0,$txt,0,2,"C");

                $pdf->Line($XPoz[1], $YPoz+2, $XPoz[1]+80,$YPoz+2);
                
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("ocenjevalec - odgovorna oseba");
                }else{
                    $txt=ToWin("ocenjevalka - odgovorna oseba");
                }
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+4);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->Line($XPoz[1], $YPoz+17, $XPoz[1]+80,$YPoz+17);
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+20);
                $pdf->Cell(0,0,"podpis",0,2,"L");
                
                $txt=ToWin($PrintDay);
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[1],$YPoz+28);
                $pdf->Cell(100,0,$txt,0,2,"C");
                $pdf->Line($XPoz[1], $YPoz+30, $XPoz[1]+80,$YPoz+30);
                $pdf->SetFont('arial_CE','',10);
                $txt=ToWin("datum");
                $pdf->SetXY($XPoz[1],$YPoz+34);
                $pdf->Cell(0,0,$txt,0,2,"L");
                            
                //delavec
                $pdf->SetFont('arialbd_CE','',12);
                $pdf->SetXY($XPoz[2],$YPoz-10);
                $pdf->Cell(0,0,"Izjava o seznanitvi z oceno",0,2,"L");
                
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($R["ime"]." ".$R["priimek"]);
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(100,0,$txt,0,2,"C");

                $pdf->Line($XPoz[2], $YPoz+2, $XPoz[2]+80,$YPoz+2);
                
                if ($R["spol"]=="M"){
                    $txt=ToWin("javni uslužbenec");
                }else{
                    $txt=ToWin("javna uslužbenka");
                }
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[2],$YPoz+4);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->Line($XPoz[2], $YPoz+17, $XPoz[2]+80,$YPoz+17);
                $pdf->SetXY($XPoz[2],$YPoz+20);
                $pdf->Cell(0,0,"podpis",0,2,"L");
                
                $txt=ToWin($PrintDay);
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[2],$YPoz+28);
                $pdf->Cell(100,0,$txt,0,2,"C");
                $pdf->Line($XPoz[2], $YPoz+30, $XPoz[2]+80,$YPoz+30);
                $pdf->SetFont('arial_CE','',10);
                $txt=ToWin("datum");
                $pdf->SetXY($XPoz[2],$YPoz+34);
                $pdf->Cell(0,0,$txt,0,2,"L");
                            
                //obrazec
                $pdf->SetFont('arialbd_CE','',16);
                $txt=ToWin("OCENJEVALNI LIST");
                $pdf->SetXY($XPoz[1],40);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("za oceno delovne uspešnosti javnega uslužbenca v ocenjevalnem obdobju");
                $pdf->SetXY($XPoz[1],45);
                $pdf->Cell(0,0,$txt,0,2,"C");
                
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("Podatki o javnem uslužbencu:");
                $pdf->SetXY($XPoz[1],55);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Ime in priimek javnega uslužbenca:");
                $pdf->SetXY($XPoz[1],65);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin($R["ime"]." ".$R["priimek"]);
                $pdf->SetXY($XPoz[2],65);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("Ocena javnega uslužbenca: ".ToOcena($R["ocena"]));
                $pdf->SetXY($XPoz[1],75);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Leto ocenjevanja: ".$leto);
                $pdf->SetXY($XPoz[1],85);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("V obdobju od ".$R["obdod"]." do ".$R["obddo"]." je javni uslužbenec dosegel naslednje število točk: ".$R["ocena"]);
                $pdf->SetXY($XPoz[1],95);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("SKUPNA UTEMELJITEV OCENE (glede na kriterije ocenjevanja, v povezavi s pričakovanji na delovnem mestu)");
                $pdf->SetXY($XPoz[1],105);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("rezultati dela");
                $pdf->SetXY($XPoz[1],120);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Zaposleni je po strokovnosti, obsegu dela in pravočasnosti glede veljavnih standardov oziroma pravili stroke, količine dela in predvidenih rokov opravil zaupane delovne naloge in zadolžitve ".ToOcenaTxt($R["rdocena"]));
                $pdf->SetXY($XPoz[1],123);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("samostojnost, ustvarjalnost in natančnost pri opravljanju dela");
                $pdf->SetXY($XPoz[1],140);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Po samostojnosti, ustvarjalnosti in natančnosti glede na navodila in nadzorovanje, razvijanje novih uporabnih idej in dajanje koristnih pobud in predlogov pri opravljanju dela in zadolžitev je ".ToOcenaTxt($R["sunocena"]));
                $pdf->SetXY($XPoz[1],143);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("zanesljivost pri opravljanju dela");
                $pdf->SetXY($XPoz[1],162);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Dogovorjene delovne obveznosti in zanesljivost v smislu popolnega in točnega prenosa informacij izpolnjuje ".ToOcenaTxt($R["zocena"]));
                $pdf->SetXY($XPoz[1],165);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("kvaliteta sodelovanja in organizacija dela");
                $pdf->SetXY($XPoz[1],180);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("V smislu kvalitete medsebojnega sodelovanja, odnosa do sodelavcev, prenosa znanja in mentorstva ter organiziranega in načrtovanega izkoriščanja delovnega časa glede na vsebino nalog in postavljenih rokov je delo zaposlenega ".ToOcenaTxt($R["ksoocena"]));
                $pdf->SetXY($XPoz[1],183);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("druge sposobnosti v zvezi z opravljanjem dela");
                $pdf->SetXY($XPoz[1],202);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Glede interdisciplinarnega dela v smislu povezovanja znanja različnih delovnih področij, odnosa do uporabnikov storitev, komunikacij zlasti  pisnega in ustnega izražanje, ustvarjanja notranjega in zunanjega socialnega omrežja in izvajanja drugih nalog, značilnih za stroko, je delo zaposlenega ".ToOcenaTxt($R["dsocena"]));
                $pdf->SetXY($XPoz[1],205);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");
            }
            $pdf->Output("OcenjevalniListi.pdf","D");
            break;
        case "9": //evidenčni list za napredovanje
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }
            $napredovanj=$_GET["napredovanj"];
            $zapis=$_GET["zapis"];
            
            $pdf = new FPDF();

            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }

            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }
            
            $SQL = "SELECT tabnapredovanja.*,tabucitelji.spol,tabucitelji.priimek,tabucitelji.ime,tabucitelji.datroj,tabdelmesta.sifra,tabdelmesta.delmesto FROM (tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabdelmesta ON tabnapredovanja.delm=tabdelmesta.id ";
            $SQL .= "WHERE tabnapredovanja.id=$zapis";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $pdf->AddPage("P","A4");
                $XPoz[1]=15;
                $XPoz[2]=110;
                $YPoz=240;
                $YPozDiff=4.5;
                
                //$pdf->Image("logo1.gif",15,10,30);
                //podatki o šoli
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($VSola);
                $pdf->SetXY($XPoz[1],18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY($XPoz[1],23);
                $pdf->Cell(0,0,$txt,0,2,"L");

                //ravnatelj
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(100,0,$txt,0,2,"C");

                $pdf->Line($XPoz[1], $YPoz+2, $XPoz[1]+80,$YPoz+2);
                
                $txt=ToWin("odgovorna oseba");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+4);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->Line($XPoz[1], $YPoz+17, $XPoz[1]+80,$YPoz+17);
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+20);
                $pdf->Cell(0,0,"podpis",0,2,"L");
                
                $txt=ToWin($PrintDay);
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[1],$YPoz+28);
                $pdf->Cell(100,0,$txt,0,2,"C");
                $pdf->Line($XPoz[1], $YPoz+30, $XPoz[1]+80,$YPoz+30);
                $pdf->SetFont('arial_CE','',10);
                $txt=ToWin("datum");
                $pdf->SetXY($XPoz[1],$YPoz+34);
                $pdf->Cell(0,0,$txt,0,2,"L");
                            
                //delavec
                $pdf->Line($XPoz[2], $YPoz+2, $XPoz[2]+80,$YPoz+2);
                
                if ($R["spol"]=="M"){
                    $txt=ToWin("javni uslužbenec po pooblastilu odgovorne osebe");
                }else{
                    $txt=ToWin("javna uslužbenka po pooblastilu odgovorne osebe");
                }
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[2],$YPoz+4);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->Line($XPoz[2], $YPoz+17, $XPoz[2]+80,$YPoz+17);
                $pdf->SetXY($XPoz[2],$YPoz+20);
                $pdf->Cell(0,0,"podpis",0,2,"L");
                
                $txt=ToWin($PrintDay);
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[2],$YPoz+28);
                $pdf->Cell(100,0,$txt,0,2,"C");
                $pdf->Line($XPoz[2], $YPoz+30, $XPoz[2]+80,$YPoz+30);
                $pdf->SetFont('arial_CE','',10);
                $txt=ToWin("datum");
                $pdf->SetXY($XPoz[2],$YPoz+34);
                $pdf->Cell(0,0,$txt,0,2,"L");
                            
                //obrazec
                $pdf->SetFont('arialbd_CE','',16);
                $txt=ToWin("EVIDENČNI LIST");
                $pdf->SetXY($XPoz[1],40);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arialbd_CE','',13);
                $txt=ToWin("NAPREDOVANJA JAVNEGA USLUŽBENCA V NAPREDOVALNEM OBDOBJU");
                $pdf->SetXY($XPoz[1],46);
                $pdf->Cell(0,0,$txt,0,2,"C");
                
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("Podatki o javnem uslužbencu:");
                $pdf->SetXY($XPoz[1],55);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Ime in priimek javnega uslužbenca:");
                $pdf->SetXY($XPoz[1],65);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin($R["ime"]." ".$R["priimek"]);
                $pdf->SetXY($XPoz[2],65);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',10);
                $Datum=new DateTime($R["datroj"]);
                $txt=ToWin("Rojstni dan javnega uslužbenca: ".$Datum->format('d.m.Y'));
                $pdf->SetXY($XPoz[1],75);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Šifra in ime delovnega mesta oz. naziva: ".$R["sifra"]."-".$R["delmesto"]);
                $pdf->SetXY($XPoz[1],80);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Organizacijska enota: ");
                $pdf->SetXY($XPoz[1],85);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Osnovni plačni razred delovnega mesta: ".$R["rdelmosn"]);
                $pdf->SetXY($XPoz[1],95);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Datum zadnjega napredovanja: ".$R["datznapred"]);
                $pdf->SetXY($XPoz[1],100);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $LetoZadNapred=0;
                if (isDate($R["datznapred"])){
                    $datum=new DateTime(isDate($R["datznapred"]));
                    $LetoZadNapred=$datum->format('Y');
                }

                $txt=ToWin("Plačni razred javnega uslužbenca: ".$R["rakt"]);
                $pdf->SetXY($XPoz[1],105);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Napredovalno obdobje od: ".$R["napredod"]);
                $pdf->SetXY($XPoz[1],110);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("Ocene javnega uslužbenca v napredovalnem obdobju");
                $pdf->SetXY($XPoz[1],120);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',10);
                $SQL = "SELECT * FROM tabdelocena WHERE upostevaj=true AND ref=$zapis AND leto >=$LetoZadNapred ORDER BY leto DESC LIMIT 0,3";
                $result1 = mysqli_query($link,$SQL);
                $i=1;
                $ypoz=126;
                $vsota=0;
                while ($R1 = mysqli_fetch_array($result1)){
                    $txt=ToWin("V ocenjevalnem obdobju od ".$R1["obdod"]." do ".$R1["obddo"]." je ".stevnik($i)." ocena ".ToOcena($R1["ocena"])." število točk: ".$R1["ocena"]);
                    $pdf->SetXY($XPoz[1],$ypoz+$YPozDiff*$i);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $vsota += $R1["ocena"];
                    $i += 1;
                }
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin("TOČKE SKUPAJ: $vsota");
                $pdf->SetXY($XPoz[1],150);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Ocena javnega uslužbenca v napredovalnem obdobju");
                $pdf->SetXY($XPoz[1],160);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',10);
                $txt=ToWin("Izpolnjuje pogoje za napredovanje za:");
                $pdf->SetXY($XPoz[1],170);
                $pdf->Cell(0,0,$txt,0,2,"L");

                if ($napredovanj > 1){
                    $txt=ToWin("$napredovanj plačna razreda");
                }else{
                    $txt=ToWin("$napredovanj plačni razred");
                }
                $pdf->SetXY($XPoz[2],170);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Javni uslužbenec napreduje z dnem:");
                $pdf->SetXY($XPoz[1],175);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin($R["napreddo"]);
                $pdf->SetXY($XPoz[2],175);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Številka in datum aneksa:");
                $pdf->SetXY($XPoz[1],180);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin($R["aneks"]);
                $pdf->SetXY($XPoz[2],180);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Nov plačni razred je:");
                $pdf->SetXY($XPoz[1],185);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin($R["rakt"]+$napredovanj);
                $pdf->SetXY($XPoz[2],185);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Ne izpolnjuje pogojev za napredovanje, datum:");
                $pdf->SetXY($XPoz[1],190);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("________________________________");
                $pdf->SetXY($XPoz[2],190);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin(":");
                $pdf->SetXY($XPoz[1],197);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            $pdf->Output("EvidencniList.pdf","D");
            break;
        case "9a": //pisno obvestilo delavcu
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix=$_SESSION["RefStFix"];
            }else{
                $RefStFix="";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar=$_SESSION["RefStVar"];
            }else{
                $RefStVar=1;
            }
            $napredovanj=$_GET["napredovanj"];
            $zapis=$_GET["zapis"];
            
            $pdf = new FPDF();

            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddFont('arial_CE','','arial_CE.php');
            $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
            
            $SQL = "SELECT * FROM tabsola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                $VSolaKraj=$R["Kraj"];
                $VRavnatelj=$R["Ravnatelj"];
                $TipSole=$R["TipSole"];
                $RavnateljID=$R["ravnatelj_ID"];
            }else{
                $VSola=" ";
                $VRavnatelj=" ";
                $RavnateljID=0;
                $VSolaNaslov="";
                $VSolaKraj="";
                $TipSole=0;
            }

            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SpolRavnatelj=$R["Spol"];
            }else{
                $SpolRavnatelj="M";
            }
            
            $SQL = "SELECT tabnapredovanja.*,tabucitelji.spol,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabucitelji.datroj,tabdelmesta.sifra,tabdelmesta.delmesto FROM (tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabdelmesta ON tabnapredovanja.delm=tabdelmesta.id ";
            $SQL .= "WHERE tabnapredovanja.id=$zapis";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $pdf->AddPage("P","A4");
                $XPoz[1]=15;
                $XPoz[2]=110;
                $XPoz[3]=200;
                $YPoz=230;
                $YPozDiff=4.5;
                
                //$pdf->Image("logo1.gif",15,10,30);
                //podatki o šoli
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($VSola);
                $pdf->SetXY($XPoz[1],18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY($XPoz[1],23);
                $pdf->Cell(0,0,$txt,0,2,"L");

                //ravnatelj
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY($XPoz[2]-10,$YPoz-10);
                $pdf->Cell(100,0,$txt,0,2,"C");

                $pdf->Line($XPoz[2], $YPoz+2-10, $XPoz[2]+80,$YPoz+2-10);
                
                $txt=ToWin("odgovorna oseba");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[2],$YPoz+4-10);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Vročeno:");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+14);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("zaposlenemu osebno: _________________");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1]+20,$YPoz+14);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("po pošti s povratnico");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1]+20,$YPoz+18);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $txt=ToWin("Priloga:");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+24);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Aneks k Pogodbi o zaposlitvi številka: ".$R["aneks"].".");
                $pdf->SetFont('arial_CE','',10);
                $pdf->SetXY($XPoz[1],$YPoz+28);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                //delavec
                
                if ($R["spol"]=="M"){
                    $txt=ToWin("Gospod");
                }else{
                    $txt=ToWin("Gospa");
                }
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[1],80);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin($R["ime"]." ".$R["priimek"]);
                $pdf->SetXY($XPoz[1]+20,80);
                $pdf->Cell(0,0,$txt,0,2,"L");

                //delovodnik
                $pdf->SetFont('arial_CE','',12);
                
                if (strlen($RefStFix) == 0){
                    $SQL = "SELECT evstev,datum FROM tabevstevilked WHERE iducitelj=".$R["iducitelj"]." AND leto=$VLeto AND dokument=3";
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $txt=ToWin("Evid. št.: ".$R1["evstev"]);
                        $pdf->SetXY($XPoz[1],33);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $datum=new DateTime($R1["datum"]);
                        $PrintDay=$datum->format('j.n.Y');
                    }else{
                        $txt=ToWin("Evid. št.: ");
                        $pdf->SetXY($XPoz[1],33);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                    }
                }else{
                    $txt=ToWin("Evid. št.: ".$RefStFix."-".$RefStVar."/".$VLeto);
                    $RefStVar += 1;
                    $pdf->SetXY($XPoz[1],33);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }

                //$txt=ToWin("Ev. številka:");
                //$pdf->SetXY($XPoz[1],33);
                //$pdf->Cell(0,0,$txt,0,2,"L");
                /*
                $txt=ToWin($R["aneks"]);
                $pdf->SetXY($XPoz[1]+30,33);
                $pdf->Cell(0,0,$txt,0,2,"L");
                */
                //datum
                $txt=ToWin($PrintDay);
                $pdf->SetFont('arial_CE','',12);
                $pdf->SetXY($XPoz[1]+30,38);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Datum:");
                $pdf->SetXY($XPoz[1],38);
                $pdf->Cell(0,0,$txt,0,2,"L");
                            
                //obrazec
                $pdf->SetFont('arialbd_CE','',16);
                $txt=ToWin("ZADEVA:");
                $pdf->SetXY($XPoz[1],60);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',13);
                $txt=ToWin("Obvestilo o napredovanju");
                $pdf->SetXY($XPoz[1]+30,60);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Na osnovi 7. člena Uredbe o napredovanju javnih uslužbencev v plačne razrede (Uradni list RS št. 51/08, 91/08, 113/09, v nadaljevanju Uredba), ");
                $txt .=ToWin("ki določa, da se javnega uslužbenca obvesti s pisnim obvestilom o napredovanju, o številu plačnih razredov napredovanja in o plačnem razredu osnovne plače, ");
                $txt .=ToWin("Vas obveščamo, da po določilih 17. člena ZSPJS in Uredbe izpolnjujete pogoje za napredovanje v višji plačni razred na delovnem mestu.");
                $pdf->SetXY($XPoz[1],90);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Napredovali boste za:");
                $pdf->SetXY($XPoz[1],120);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arialbd_CE','',12);
                if ($napredovanj > 1){
                    $txt=ToWin("$napredovanj plačna razreda");
                }else{
                    $txt=ToWin("$napredovanj plačni razred");
                }
                $pdf->SetXY($XPoz[2],120);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Vaš novi plačni razred bo");
                $pdf->SetXY($XPoz[1],130);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin($R["rakt"]+$napredovanj);
                $pdf->SetXY($XPoz[2],130);
                $pdf->Cell(0,0,$txt,0,2,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Na osnovi novega plačnega razreda Vam bo plača obračunana od ________________.");
                $pdf->SetXY($XPoz[1],140);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("V prilogi Vam pošiljamo predlog Aneksa k Pogodbi o zaposlitvi št. ".$R["aneks"]." in Vas pozivamo, da ga podpišete ter dva izvoda vrnete v tajništvo v roku osmih dni od prejema.");
                $pdf->SetXY($XPoz[1],155);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");

                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("V kolikor se ne strinjate z oceno, lahko v osmih delovnih dneh od seznanitve z oceno, zahtevate preizkus ocene pred komisijo.");
                $pdf->SetXY($XPoz[1],175);
                $pdf->MultiCell(0,$YPozDiff,$txt,0,"L");
            }
            $pdf->Output("PisnoObvestilo.pdf","D");
            break;
        default:  //izpis podatkov z obrazcem za dodajanje učiteljevega delovnega mesta
            echo "<h2>Spisek delavcev za ocenjevanje in napredovanja</h2>";
            echo "<form name='napredovanja' accept-charset='utf-8' method='post' action='napredovanja.php' >";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<table>";
            echo "<tr>";
            echo "<th>Št.</th>";
            echo "<th>Delavec</th>";
            echo "<th>Briši</th>";
            echo "<th>Popravi</th>";
            echo "<th>Ocene</th>";
            echo "<th>Dat.roj.</th>";
            echo "<th>Pl.razr.<br />Max</th>";
            echo "<th>Pl.razr.<br />akt.</th>";
            echo "<th>Pl.razr.<br />osn.DM</th>";
            echo "<th>Št.<br />napredovanj</th>";
            echo "<th>Datum<br />zadnj. napred.</th>";
            echo "<th>obdobje<br />od</th>";
            echo "<th>obdobje<br />do</th>";
            echo "<th>št. in datum<br />aneksa</th>";
            echo "<th>šifra in<br />ime DM</th>";
            echo "</tr>";
            
            $SQL = "SELECT tabnapredovanja.*,tabucitelji.ime,tabucitelji.priimek,tabucitelji.datroj,tabdelmesta.sifra,tabdelmesta.delmesto FROM (tabnapredovanja ";
            $SQL .= "INNER JOIN tabucitelji ON tabnapredovanja.iducitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabdelmesta ON tabnapredovanja.delm=tabdelmesta.id ";
            $SQL .= "ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$i."</td>";
                echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
                echo "<td><a href='napredovanja.php?id=3&zapis=".$R["id"]."'>Briši</a></td>";
                echo "<td><a href='napredovanja.php?id=4&zapis=".$R["id"]."'>Popravi</a></td>";
                echo "<td><a href='napredovanja.php?id=2&zapis=".$R["id"]."'>ocene</a></td>";
                $Datum=new DateTime($R["datroj"]);
                echo "<td>".$Datum->format("d.m.Y")."</td>";
                echo "<td>".$R["rmax"]."</td>";
                echo "<td>".$R["rakt"]."</td>";
                echo "<td>".$R["rdelmosn"]."</td>";
                echo "<td>".$R["napredovanj"]."</td>";
                echo "<td>".$R["datznapred"]."</td>";
                echo "<td>".$R["napredod"]."</td>";
                echo "<td>".$R["napreddo"]."</td>";
                echo "<td>".$R["aneks"]."</td>";
                echo "<td>".$R["sifra"]." - ".$R["delmesto"]."</td>";
                echo "</tr>";
                $i += 1;
            }
            echo "<tr>";
            echo "<td>&nbsp;</td>";
            echo "<td>";
            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            echo "<select name='ime'>";
            echo "<option value='0'>Ni izbran</option>";
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
            }
            echo "</select>";
            echo "</td>";
            echo "<td colspan='3' align='center'>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td><input name='rakt' type='text' value='' size='3'></td>";
            echo "<td>&nbsp;</td>";
            echo "<td><input name='napredovanj' type='text' value='' size='2'></td>";
            echo "<td><input name='datznapred' type='text' value='' size='10'></td>";
            echo "<td><input name='napredod' type='text' value='' size='10'></td>";
            echo "<td><input name='napreddo' type='text' value='' size='10'></td>";
            echo "<td><input name='aneks' type='text' value='' size='15'></td>";
            echo "<td>";
            $SQL = "SELECT id,sifra,delmesto,placnirazbn,placnirazzn FROM tabdelmesta";
            $result = mysqli_query($link,$SQL);
            echo "<select name='delm'>";
            echo "<option value='0'>Ni izbrano</option>";
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["sifra"]." - ".$R["delmesto"]."</option>";
            }
            echo "</select><input type='submit' value='Dodaj' name='submit'></td>";
            echo "</tr>";
            
            echo "</table>";
            echo "</form>";
            
            echo "<form name='listi' accept-charset='utf-8' method='post' action='napredovanja.php' >";
            echo "<input name='id' type='hidden' value='8'>";
            echo "Ocenjevalni listi za leto: ";
            echo "<select name='letooc'>";
            for ($i=2008;$i <= intval($Danes->format('Y'));$i++){
                if ($i == $Danes->format('Y')-1){
                    echo "<option value='$i' selected='selected'>$i</option>";
                }else{
                    echo "<option value='$i'>$i</option>";
                }
            }
            echo "</select>";
            echo "<input type='submit' value='Izberi' name='submit'>";
            echo "</form>";
    }
    switch ($id){
        case "1":
        case "1a":
        case "3":
        case "5";
        case "7";
        case "8";
        case "9";
        case "9a":
            break;
        default:
            echo "<a href='napredovanja.php'>Nazaj na vstopno stran napredovanj</a><br />";
            echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

            echo "</body>";
            echo "</html>";
    }
}
?>
