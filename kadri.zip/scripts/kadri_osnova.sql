/*
SQLyog Ultimate v12.03 (32 bit)
MySQL - 5.5.32 : Database - sola
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `kadrovi` */

DROP TABLE IF EXISTS `kadrovi`;

CREATE TABLE `kadrovi` (
  `STDELAVCA` varchar(7) DEFAULT NULL,
  `WIRKODA` varchar(10) DEFAULT NULL,
  `SIFRA` varchar(10) DEFAULT NULL,
  `SKUPINA` int(10) DEFAULT NULL,
  `PODSKUPINA` int(10) DEFAULT NULL,
  `PRIIMIME` varchar(25) DEFAULT NULL,
  `SPOL` varchar(1) DEFAULT NULL,
  `IMEOCETA` varchar(10) DEFAULT NULL,
  `EMSO` varchar(13) DEFAULT NULL,
  `DATUMROJ` timestamp NULL DEFAULT NULL,
  `DATUMPRIH` timestamp NULL DEFAULT NULL,
  `ORGENOT` varchar(4) DEFAULT NULL,
  `DELMESTO` varchar(4) DEFAULT NULL,
  `NAZIV` varchar(25) DEFAULT NULL,
  `LETNIDOP` int(10) DEFAULT NULL,
  `OSTANDOPU` int(10) DEFAULT NULL,
  `OSTANDOPM` int(10) DEFAULT NULL,
  `URE` int(10) DEFAULT NULL,
  `MIN` int(10) DEFAULT NULL,
  `VRSTADC` varchar(2) DEFAULT NULL,
  `TELEFON` varchar(30) DEFAULT NULL,
  `IZPLMESTO` int(10) DEFAULT NULL,
  `STATUS` int(10) DEFAULT NULL,
  `DAVCSTEV` varchar(8) DEFAULT NULL,
  `STEVODLDOP` varchar(10) DEFAULT NULL,
  `KRAJROJ` varchar(20) DEFAULT NULL,
  `ULICA` varchar(20) DEFAULT NULL,
  `POSTSTEV` int(10) DEFAULT NULL,
  `KRAJBIV` varchar(20) DEFAULT NULL,
  `VRSTADELAV` int(10) DEFAULT NULL,
  `SISTENDAT` timestamp NULL DEFAULT NULL,
  `DATSPREMV` timestamp NULL DEFAULT NULL,
  `SSTDELAVCA` int(10) DEFAULT NULL,
  `SSIFRA` double DEFAULT NULL,
  `SEMSO` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `kadrovi` */

/*Table structure for table `promet1` */

DROP TABLE IF EXISTS `promet1`;

CREATE TABLE `promet1` (
  `SIFRA` varchar(10) DEFAULT NULL,
  `DATUMPRIH` timestamp NULL DEFAULT NULL,
  `LETOPR` varchar(4) DEFAULT NULL,
  `MESECPR` varchar(2) DEFAULT NULL,
  `DANPR` varchar(2) DEFAULT NULL,
  `URAPRIH` int(10) DEFAULT NULL,
  `MINPRIH` int(10) DEFAULT NULL,
  `VRSTAPRIH` varchar(4) DEFAULT NULL,
  `DATUMODH` timestamp NULL DEFAULT NULL,
  `LETODH` varchar(4) DEFAULT NULL,
  `MESECODH` varchar(2) DEFAULT NULL,
  `DANODH` varchar(2) DEFAULT NULL,
  `URAODH` int(10) DEFAULT NULL,
  `MINODH` int(10) DEFAULT NULL,
  `MINUT` int(10) DEFAULT NULL,
  `PMINUT` int(10) DEFAULT NULL,
  `VSTOPMEST` varchar(3) DEFAULT NULL,
  `SIFDELPOP` varchar(10) DEFAULT NULL,
  `ZAPSTVPIS` int(10) DEFAULT NULL,
  `POZICIJA` int(10) DEFAULT NULL,
  `OZNAKSPREM` int(10) DEFAULT NULL,
  `SISTEMDAT` timestamp NULL DEFAULT NULL,
  `USALDO` int(10) DEFAULT NULL,
  `MSALDO` int(10) DEFAULT NULL,
  `PRIPOMBA` varchar(60) DEFAULT NULL,
  `SSIFRA` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `promet1` */

/*Table structure for table `tabaktiv` */

DROP TABLE IF EXISTS `tabaktiv`;

CREATE TABLE `tabaktiv` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Aktiv` varchar(50) DEFAULT NULL,
  `orderlevel` smallint(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

/*Data for the table `tabaktiv` */

insert  into `tabaktiv`(`id`,`Aktiv`,`orderlevel`) values (1,'Aktiv prvih razredov',1),(2,'Aktiv drugih razredov',2),(3,'Aktiv tretjih razredov',3),(4,'Aktiv četrtih razredov',4),(5,'Aktiv petih razredov',5),(6,'Aktiv šestih razredov',6),(7,'Aktiv sedmih razredov',7),(8,'Aktiv osmih razredov',8),(9,'Aktiv devetih razredov',9),(10,'Aktiv podaljšanega bivanja',10),(11,'Slovenistični aktiv',11),(12,'Aktiv anglistov',12),(13,'Matematični aktiv',13),(14,'Družboslovni aktiv',14),(15,'Aktiv naravoslovja in gospodinjstva',15),(16,'Aktiv športne vzgoje',16),(17,'Aktiv svetovalnih delavcev',17),(18,'Aktiv vzgojiteljic',18);

/*Table structure for table `tabaktivnosti` */

DROP TABLE IF EXISTS `tabaktivnosti`;

CREATE TABLE `tabaktivnosti` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdAktivnost` int(10) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  `kratica` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `TabAktivnostiIdAktivnost` (`IdAktivnost`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tabaktivnosti` */

insert  into `tabaktivnosti`(`Id`,`IdAktivnost`,`Opis`,`kratica`) values (1,1,'Kulturni dan','KD'),(2,2,'Naravoslovni dan','ND'),(3,3,'Tehniški dan','TD'),(4,4,'Športni dan','ŠD'),(5,5,'Drugo','Drugo');

/*Table structure for table `tabaktivnostucenca` */

DROP TABLE IF EXISTS `tabaktivnostucenca`;

CREATE TABLE `tabaktivnostucenca` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `AktivnostUcenca` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tabaktivnostucenca` */

insert  into `tabaktivnostucenca`(`Id`,`AktivnostUcenca`) values (1,'Redni učenec'),(2,'Izredni učenec'),(3,'Opravlja izpite'),(4,'Se je prešolal'),(5,'Končal osnovno šolo');

/*Table structure for table `tabaktivplan` */

DROP TABLE IF EXISTS `tabaktivplan`;

CREATE TABLE `tabaktivplan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `aktiv` int(10) DEFAULT NULL,
  `razred1` int(10) DEFAULT NULL,
  `razred2` int(10) DEFAULT NULL,
  `razred3` int(10) DEFAULT NULL,
  `razred4` int(10) DEFAULT NULL,
  `razred5` int(10) DEFAULT NULL,
  `razred6` int(10) DEFAULT NULL,
  `razred7` int(10) DEFAULT NULL,
  `razred8` int(10) DEFAULT NULL,
  `razred9` int(10) DEFAULT NULL,
  `programDela` text,
  `dneviDejavnosti` text,
  `dopolnilniPouk` text,
  `individualniPouk` text,
  `interesneDejavnosti` text,
  `roditeljskiSestanki` text,
  `studijskaSkupina` text,
  `izobrazevanje` text,
  `projekti` text,
  `drugo` text,
  `avtor` varchar(20) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabaktivplan` */

/*Table structure for table `tabaktivporocilo` */

DROP TABLE IF EXISTS `tabaktivporocilo`;

CREATE TABLE `tabaktivporocilo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `aktiv` int(10) DEFAULT NULL,
  `razred1` int(10) DEFAULT NULL,
  `razred2` int(10) DEFAULT NULL,
  `razred3` int(10) DEFAULT NULL,
  `razred4` int(10) DEFAULT NULL,
  `razred5` int(10) DEFAULT NULL,
  `razred6` int(10) DEFAULT NULL,
  `razred7` int(10) DEFAULT NULL,
  `razred8` int(10) DEFAULT NULL,
  `razred9` int(10) DEFAULT NULL,
  `programDela` text,
  `dneviDejavnosti` text,
  `dopolnilniPouk` text,
  `individualniPouk` text,
  `interesneDejavnosti` text,
  `roditeljskiSestanki` text,
  `studijskaSkupina` text,
  `izobrazevanje` text,
  `projekti` text,
  `drugo` text,
  `avtor` varchar(20) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabaktivporocilo` */

/*Table structure for table `tabanketa` */

DROP TABLE IF EXISTS `tabanketa`;

CREATE TABLE `tabanketa` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idAnketa` varchar(255) DEFAULT NULL,
  `naziv` varchar(255) DEFAULT NULL,
  `navodilo` text,
  `veljavnost` varchar(255) DEFAULT NULL,
  `objavi` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idAnketa` (`idAnketa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabanketa` */

/*Table structure for table `tabanketadef` */

DROP TABLE IF EXISTS `tabanketadef`;

CREATE TABLE `tabanketadef` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idAnketa` varchar(255) DEFAULT NULL,
  `vprasanje` int(10) DEFAULT NULL,
  `odgovor` int(10) DEFAULT NULL,
  `vsebina` text,
  `tip` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idAnketa` (`idAnketa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabanketadef` */

/*Table structure for table `tabanketarez` */

DROP TABLE IF EXISTS `tabanketarez`;

CREATE TABLE `tabanketarez` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idAnketa` varchar(255) DEFAULT NULL,
  `vprasanje` int(10) DEFAULT NULL,
  `odgovor` int(10) DEFAULT NULL,
  `vsebina` text,
  `tip` int(10) DEFAULT NULL,
  `oddal` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idAnketa` (`idAnketa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabanketarez` */

/*Table structure for table `tabbivanje` */

DROP TABLE IF EXISTS `tabbivanje`;

CREATE TABLE `tabbivanje` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idBivanje` int(10) DEFAULT NULL,
  `Bivanje` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idBivanje` (`idBivanje`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `tabbivanje` */

insert  into `tabbivanje`(`id`,`idBivanje`,`Bivanje`) values (1,0,'pri starših'),(2,1,'pri starih starših'),(3,2,'pri rejnikih'),(4,3,'pri sorodnikih'),(5,4,'pri skrbnikih'),(6,5,'pri znancih'),(7,6,'v dijaškem domu'),(8,7,'drugje'),(9,8,'pri mami'),(10,9,'pri očetu');

/*Table structure for table `tabcasovnashema` */

DROP TABLE IF EXISTS `tabcasovnashema`;

CREATE TABLE `tabcasovnashema` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `oznaka` varchar(50) DEFAULT NULL,
  `ura` int(10) DEFAULT NULL,
  `cas` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `tabcasovnashema` */

insert  into `tabcasovnashema`(`id`,`oznaka`,`ura`,`cas`) values (1,'ure12s',0,NULL),(2,'ure12s',1,'08.15-09.00'),(3,'ure12s',2,'09.20-10.05'),(4,'ure12s',3,'10.10-10.55'),(5,'ure12s',4,'11.10-11.55'),(6,'ure12s',5,'12.00-12.45'),(7,'ure12s',6,'12.50-13.35'),(8,'ure12s',7,'13.55-14.40'),(9,'ure12s',8,'15.00-15.45'),(10,'ure12s',9,'15.50-16.35'),(11,'ure12s',10,'16.40-17.15'),(12,'ure39s',0,'07.25-08.10'),(13,'ure39s',1,'08.15-09.00'),(14,'ure39s',2,'09.20-10.05'),(15,'ure39s',3,'10.10-10.55'),(16,'ure39s',4,'11.10-11.55'),(17,'ure39s',5,'12.00-12.45'),(18,'ure39s',6,'12.50-13.35'),(19,'ure39s',7,'13.55-14.40'),(20,'ure39s',8,'15.00-15.45');

/*Table structure for table `tabdejavnosti` */

DROP TABLE IF EXISTS `tabdejavnosti`;

CREATE TABLE `tabdejavnosti` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdDejavnost` varchar(50) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  `Datum` timestamp NULL DEFAULT NULL,
  `Kraj` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdDejavnost` (`IdDejavnost`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdejavnosti` */

/*Table structure for table `tabdeldogodek` */

DROP TABLE IF EXISTS `tabdeldogodek`;

CREATE TABLE `tabdeldogodek` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idDogodek` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `opravljeno` bit(1) NOT NULL,
  `datum` varchar(50) DEFAULT NULL,
  `intervencija1` bit(1) NOT NULL,
  `intervencija2` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idDogodek` (`idDogodek`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdeldogodek` */

/*Table structure for table `tabdelmesta` */

DROP TABLE IF EXISTS `tabdelmesta`;

CREATE TABLE `tabdelmesta` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idDelMesto` text,
  `PlacnaPodskupina` text,
  `Sifra` text,
  `DelMesto` text,
  `TarifniRaz` text,
  `SifraNaz` int(10) DEFAULT NULL,
  `PlacniRazBN` int(10) DEFAULT NULL,
  `PlacniRazZN` int(10) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

/*Data for the table `tabdelmesta` */

insert  into `tabdelmesta`(`id`,`idDelMesto`,`PlacnaPodskupina`,`Sifra`,`DelMesto`,`TarifniRaz`,`SifraNaz`,`PlacniRazBN`,`PlacniRazZN`) values (1,'1','D2','D027019','Pomočnik ravnatelja šole-svetnik','VII/1',1,40,45),(2,'2','D2','D027019','Pomočnik ravnatelja šole- svetovalec','VII/1',2,37,42),(3,'3','D2','D027019','Pomočnik ravnatelja šole- svetnik','VII/1',3,35,40),(4,'4','D2','D027020','Pomočnik ravnatelja šole- svetnik','VII/2',1,40,45),(5,'5','D2','D027020','Pomočnik ravnatelja šole- svetovalec','VII/2',2,37,42),(6,'6','D2','D027020','Pomočnik ravnatelja šole- mentor','VII/2',3,35,40),(7,'7','D2','D027017','Organizator šolske prehrane-svetnik','VII/2',1,38,43),(8,'8','D2','D027017','Organizator šolske prehrane-svetovalec','VII/2',2,35,40),(9,'9','D2','D027017','Organizator šolske prehrane-mentor','VII/2',3,33,38),(10,'10','D2','D027017','Organizator šolske prehrane','VII/2',4,30,35),(11,'11','D2','D027022','Računalnikar-organizator informacijskih dejavnosti-svetnik','VII/2',1,38,43),(12,'12','D2','D027022','Računalnikar-organizator informacijskih dejavnosti -svetovalec','VII/2',2,35,40),(13,'13','D2','D027022','Računalnikar-organizator informacijskih dejavnosti -mentor','VII/2',3,33,38),(14,'14','D2','D027022','Računalnikar-organizator informacijskih dejavnosti ','VII/2',4,30,35),(15,'15','D2','D027003','Knjižničar-svetnik','VII/1',1,38,43),(16,'16','D2','D027003','Knjižničar-svetovalec','VII/1',2,35,40),(17,'17','D2','D027003','Knjižničar-mentor','VII/1',3,33,38),(18,'18','D2','D027003','Knjižničar','VII/1',4,30,35),(19,'19','D2','D027004','Knjižničar-svetnik','VII/2',1,38,43),(20,'20','D2','D027004','Knjižničar-svetovalec','VII/2',2,35,40),(21,'21','D2','D027004','Knjižničar-mentor','VII/2',3,33,38),(22,'22','D2','D027004','Knjižničar','VII/2',4,30,35),(23,'23','D2','D025001','Laborant III','V',0,19,29),(24,'24','D2','D027006','Mobilni učitelj za dodatno strokovno pomoč-svetnik','VII/2',1,39,44),(25,'25','D2','D027006','Mobilni učitelj za dodatno strokovno pomoč-svetovalec','VII/2',2,36,41),(26,'26','D2','D027006','Mobilni učitelj za dodatno strokovno pomoč-mentor','VII/2',3,34,39),(27,'27','D2','D027006','Mobilni učitelj za dodatno strokovno pomoč','VII/2',4,31,36),(28,'28','D2','D027025','Svetovalni delavec-svetnik','VII/1',1,38,43),(29,'29','D2','D027025','Svetovalni delavec-svetovalec','VII/1',2,35,40),(30,'30','D2','D027025','Svetovalni delavec-mentor','VII/1',3,33,38),(31,'31','D2','D027025','Svetovalni delavec','VII/1',4,30,35),(32,'32','D2','D027026','Svetovalni delavec-svetnik','VII/2',1,38,43),(33,'33','D2','D027026','Svetovalni delavec-svetovalec','VII/2',2,35,40),(34,'34','D2','D027026','Svetovalni delavec-mentor','VII/2',3,33,38),(35,'35','D2','D027026','Svetovalni delavec','VII/2',4,30,35),(36,'36','D2','D027029','Učitelj-svetnik','VII/1',1,38,43),(37,'37','D2','D027029','Učitelj-svetovalec','VII/1',2,35,40),(38,'38','D2','D027029','Učitelj-mentor','VII/1',3,33,38),(39,'39','D2','D027029','Učitelj','VII/1',4,30,35),(40,'40','D2','D027030','Učitelj-svetnik','VII/2',1,38,43),(41,'41','D2','D027030','Učitelj-svetovalec','VII/2',2,35,40),(42,'42','D2','D027030','Učitelj-mentor','VII/2',3,33,38),(43,'43','D2','D027030','Učitelj','VII/2',4,30,35),(44,'44','D2','D037007','Vzgojitelj-svetnik','VII/1',1,36,41),(45,'45','D2','D037007','Vzgojitelj-svetovalec','VII/1',2,34,39),(46,'46','D2','D037007','Vzgojitelj-mentor','VII/1',3,32,37),(47,'47','D2','D037007','Vzgojitelj','VII/1',4,30,35),(48,'48','J','J015013','Knjigovodja V','V',0,17,27),(49,'49','J','J016027','Računovodja VI','VI',0,22,32),(50,'50','J','J025002','Administrator V','V',0,17,27),(51,'51','J','J026004','Poslovni sekretar VI','VI',0,21,31),(52,'52','J','J032001','Čistilka II','II',0,7,17),(53,'53','J','J032008','Kuharski pomočnik II','II',0,8,18),(54,'54','J','J032013','Perica II','II',0,8,18),(55,'55','J','J033008','Kuhinjski pomočnik III','III',0,9,19),(56,'56','J','J034020','Hišnik IV','IV',0,13,23),(57,'57','J','J034030','Kuhar IV','IV',0,14,24),(58,'58','J','J035016','Glavni kuhar V','V',0,18,28),(59,'59','J','J035020','Gospodinjec III','III',0,20,30),(60,'60','J','J035064','Spremljevalec gibalno oviranih učencev V','V',0,17,27),(61,'61','B','B017316 ','Ravnatelj OŠ','VII/2',0,42,50);

/*Table structure for table `tabdelo` */

DROP TABLE IF EXISTS `tabdelo`;

CREATE TABLE `tabdelo` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdDelo` int(10) DEFAULT NULL,
  `OpisDela` varchar(250) DEFAULT NULL,
  `SkupinaDela` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdDelo` (`IdDelo`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `tabdelo` */

insert  into `tabdelo`(`Id`,`IdDelo`,`OpisDela`,`SkupinaDela`) values (1,1,'Učitelj na razredni stopnji v I. in II. triadi 9-letne OŠ','Razredni učitelji'),(2,2,'Učitelj na predmetni stopnji v III. triadi 9-letne OŠ','Predmetni učitelji'),(3,3,'Učitelj v oddelku PB','Učitelji PB'),(4,4,'Vodstveni delavec','Vodstveni delavci'),(5,5,'Pedagog','Svetovalni delavci'),(6,6,'Psiholog','Svetovalni delavci'),(7,7,'Socialni delavec','Svetovalni delavci'),(8,8,'Specialni pedagog','Svetovalni delavci'),(9,9,'Socialni pedagog','Svetovalni delavci'),(10,10,'Drugi','Svetovalni delavci'),(11,11,'Mobilni specialni pedagog','Drugi strokovni delavci'),(12,12,'Knjižničar','Drugi strokovni delavci'),(13,13,'Organizator informacijske dejavnosti','Drugi strokovni delavci'),(14,14,'Organizator prehrane','Drugi strokovni delavci'),(15,15,'Drugi','Drugi strokovni delavci'),(16,16,'Administrativni in računovodski delavec','Drugi zaposleni delavci'),(17,17,'Tehnični delavec','Drugi zaposleni delavci'),(18,18,'Drugi','Drugi zaposleni delavci'),(19,0,'Nedoločeno','Nedoločeno');

/*Table structure for table `tabdelocena` */

DROP TABLE IF EXISTS `tabdelocena`;

CREATE TABLE `tabdelocena` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ref` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `obdod` varchar(20) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `obddo` varchar(20) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `rdstrok` int(10) DEFAULT NULL,
  `rdobs` int(10) DEFAULT NULL,
  `rdprav` int(10) DEFAULT NULL,
  `rdocena` int(10) DEFAULT NULL,
  `sunsam` int(10) DEFAULT NULL,
  `sunustv` int(10) DEFAULT NULL,
  `sunnat` int(10) DEFAULT NULL,
  `sunocena` int(10) DEFAULT NULL,
  `zizpobv` int(10) DEFAULT NULL,
  `zinf` int(10) DEFAULT NULL,
  `zocena` int(10) DEFAULT NULL,
  `ksosod` int(10) DEFAULT NULL,
  `ksoorg` int(10) DEFAULT NULL,
  `ksoocena` int(10) DEFAULT NULL,
  `dsinter` int(10) DEFAULT NULL,
  `dsodn` int(10) DEFAULT NULL,
  `dskom` int(10) DEFAULT NULL,
  `dsdrugo` int(10) DEFAULT NULL,
  `dsocena` int(10) DEFAULT NULL,
  `ocena` int(10) DEFAULT NULL,
  `cas` datetime DEFAULT NULL,
  `spremenil` varchar(50) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `upostevaj` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;

/*Data for the table `tabdelocena` */

/*Table structure for table `tabdelopog` */

DROP TABLE IF EXISTS `tabdelopog`;

CREATE TABLE `tabdelopog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `datumOd` varchar(50) DEFAULT NULL,
  `datumDo` varchar(50) DEFAULT NULL,
  `DelCas` int(10) DEFAULT NULL,
  `Pogodba` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdelopog` */

/*Table structure for table `tabdelovodnik` */

DROP TABLE IF EXISTS `tabdelovodnik`;

CREATE TABLE `tabdelovodnik` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ZapSt` int(10) DEFAULT NULL,
  `Leto` int(10) DEFAULT NULL,
  `DatumPrejema` varchar(50) DEFAULT NULL,
  `Vlozil` varchar(100) DEFAULT NULL,
  `StVloge` varchar(50) DEFAULT NULL,
  `DatumVloge` varchar(50) DEFAULT NULL,
  `Zadeva` varchar(250) DEFAULT NULL,
  `Priloge` varchar(250) DEFAULT NULL,
  `Referenca` varchar(50) DEFAULT NULL,
  `Resitev` varchar(250) DEFAULT NULL,
  `DatumResitve` varchar(50) DEFAULT NULL,
  `DatumVlozitveArhiv` varchar(50) DEFAULT NULL,
  `Roki` varchar(250) DEFAULT NULL,
  `ArhPripombe` varchar(250) DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdelovodnik` */

/*Table structure for table `tabdezurniuc` */

DROP TABLE IF EXISTS `tabdezurniuc`;

CREATE TABLE `tabdezurniuc` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `mesec` int(10) DEFAULT NULL,
  `dan` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdezurniuc` */

/*Table structure for table `tabdiploma` */

DROP TABLE IF EXISTS `tabdiploma`;

CREATE TABLE `tabdiploma` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `priznanje` varchar(250) DEFAULT NULL,
  `PozXSola` int(10) DEFAULT NULL,
  `PozYSola` int(10) DEFAULT NULL,
  `PozXNaslov` int(10) DEFAULT NULL,
  `PozYNaslov` int(10) DEFAULT NULL,
  `PozXRavnatelj` int(10) DEFAULT NULL,
  `PozYRavnatelj` int(10) DEFAULT NULL,
  `PozXKraj` int(10) DEFAULT NULL,
  `PozYkraj` int(10) DEFAULT NULL,
  `PozXIzvajalec` int(10) DEFAULT NULL,
  `PozYIzvajalec` int(10) DEFAULT NULL,
  `PozXPriznanje` int(10) DEFAULT NULL,
  `PozYpriznanje` int(10) DEFAULT NULL,
  `PozXLine1` int(10) DEFAULT NULL,
  `PozYLine1` int(10) DEFAULT NULL,
  `PozXLine2` int(10) DEFAULT NULL,
  `PozYLine2` int(10) DEFAULT NULL,
  `PozXVsebina` int(10) DEFAULT NULL,
  `PozYVsebina` int(10) DEFAULT NULL,
  `PozXDatum` int(10) DEFAULT NULL,
  `PozYDatum` int(10) DEFAULT NULL,
  `PozXLogo` int(10) DEFAULT NULL,
  `PozYLogo` int(10) DEFAULT NULL,
  `PozXIme` int(10) DEFAULT NULL,
  `PozYIme` int(10) DEFAULT NULL,
  `PozX1Crta1` int(10) DEFAULT NULL,
  `PozY1Crta1` int(10) DEFAULT NULL,
  `PozX2Crta1` int(10) DEFAULT NULL,
  `PozY2Crta1` int(10) DEFAULT NULL,
  `PozX1Crta2` int(10) DEFAULT NULL,
  `PozY1Crta2` int(10) DEFAULT NULL,
  `PozX2Crta2` int(10) DEFAULT NULL,
  `PozY2Crta2` int(10) DEFAULT NULL,
  `PozX1Crta3` int(10) DEFAULT NULL,
  `PozY1Crta3` int(10) DEFAULT NULL,
  `PozX2Crta3` int(10) DEFAULT NULL,
  `PozY2Crta3` int(10) DEFAULT NULL,
  `LogoSize` int(10) DEFAULT NULL,
  `PorSola` int(10) DEFAULT NULL,
  `PorRavnatelj` int(10) DEFAULT NULL,
  `PorPriznanje` int(10) DEFAULT NULL,
  `PorLine1` int(10) DEFAULT NULL,
  `PorLine2` int(10) DEFAULT NULL,
  `PorVsebina` int(10) DEFAULT NULL,
  `PorDatum` int(10) DEFAULT NULL,
  `PorIme` int(10) DEFAULT NULL,
  `PorNaslov` int(10) DEFAULT NULL,
  `PorKraj` int(10) DEFAULT NULL,
  `PorIzvajalec` int(10) DEFAULT NULL,
  `FSSola` int(10) DEFAULT NULL,
  `FSRavnatelj` int(10) DEFAULT NULL,
  `FSPriznanje` int(10) DEFAULT NULL,
  `FSLine1` int(10) DEFAULT NULL,
  `FSLine2` int(10) DEFAULT NULL,
  `FSVsebina` int(10) DEFAULT NULL,
  `FSDatum` int(10) DEFAULT NULL,
  `FSIme` int(10) DEFAULT NULL,
  `FSNaslov` int(10) DEFAULT NULL,
  `FSKraj` int(10) DEFAULT NULL,
  `FSIzvajalec` int(10) DEFAULT NULL,
  `Font` varchar(20) DEFAULT NULL,
  `sola` text,
  `naslov` text,
  `diploma` text,
  `line1` text,
  `line2` text,
  `vsebina` text,
  `kraj` text,
  `izvajalec` text,
  `ravnatelj` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdiploma` */

/*Table structure for table `tabdnevnice` */

DROP TABLE IF EXISTS `tabdnevnice`;

CREATE TABLE `tabdnevnice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datum` varchar(50) DEFAULT NULL,
  `km` double DEFAULT NULL,
  `dnevnica_do8` double DEFAULT NULL,
  `dnevnica_8do12` double DEFAULT NULL,
  `dnevnica_nad12` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnevnice` */

/*Table structure for table `tabdnevnik` */

DROP TABLE IF EXISTS `tabdnevnik`;

CREATE TABLE `tabdnevnik` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  `ura` int(10) DEFAULT NULL,
  `razred` varchar(255) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `skupina` varchar(255) DEFAULT NULL,
  `ZapUra` int(10) DEFAULT NULL,
  `opis` text,
  `ucitelj` varchar(255) DEFAULT NULL,
  `statusUre` int(10) DEFAULT NULL,
  `vpisal` int(10) DEFAULT NULL,
  `casvp` varchar(50) DEFAULT NULL,
  `spremenil` int(10) DEFAULT NULL,
  `casSpr` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnevnik` */

/*Table structure for table `tabdnevnikr` */

DROP TABLE IF EXISTS `tabdnevnikr`;

CREATE TABLE `tabdnevnikr` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idDnevnik` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idDnevnik` (`idDnevnik`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnevnikr` */

/*Table structure for table `tabdnevniku` */

DROP TABLE IF EXISTS `tabdnevniku`;

CREATE TABLE `tabdnevniku` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idDnevnik` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idDnevnik` (`idDnevnik`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnevniku` */

/*Table structure for table `tabdnevnikure` */

DROP TABLE IF EXISTS `tabdnevnikure`;

CREATE TABLE `tabdnevnikure` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ura` int(10) DEFAULT NULL,
  `zacetek` int(10) DEFAULT NULL,
  `konec` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnevnikure` */

/*Table structure for table `tabdnipouka` */

DROP TABLE IF EXISTS `tabdnipouka`;

CREATE TABLE `tabdnipouka` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `m1` int(10) DEFAULT NULL,
  `m2` int(10) DEFAULT NULL,
  `m3` int(10) DEFAULT NULL,
  `m4` int(10) DEFAULT NULL,
  `m5` int(10) DEFAULT NULL,
  `m6` int(10) DEFAULT NULL,
  `m7` int(10) DEFAULT NULL,
  `m8` int(10) DEFAULT NULL,
  `m9` int(10) DEFAULT NULL,
  `m10` int(10) DEFAULT NULL,
  `m109` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdnipouka` */

/*Table structure for table `tabdodatnedejavnosti` */

DROP TABLE IF EXISTS `tabdodatnedejavnosti`;

CREATE TABLE `tabdodatnedejavnosti` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `dejavnost` varchar(250) DEFAULT NULL,
  `potrdilo` varchar(255) DEFAULT NULL,
  `zavod` varchar(50) DEFAULT NULL,
  `DatumOd` varchar(50) DEFAULT NULL,
  `DatumDo` varchar(50) DEFAULT NULL,
  `pravilnik` int(10) DEFAULT NULL,
  `opombe` text,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdodatnedejavnosti` */

/*Table structure for table `tabdodoblikep` */

DROP TABLE IF EXISTS `tabdodoblikep`;

CREATE TABLE `tabdodoblikep` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `oznaka` varchar(50) DEFAULT NULL,
  `opis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tabdodoblikep` */

insert  into `tabdodoblikep`(`id`,`oznaka`,`opis`) values (1,'ISP','Individualna strokovna pomoč'),(2,'DSP','Dodatna strokovna pomoč'),(3,'DOD','Dodatni pouk'),(4,'DOP','Dopolnilni pouk'),(5,'SP','Strokovna pomoč');

/*Table structure for table `tabdodpouk` */

DROP TABLE IF EXISTS `tabdodpouk`;

CREATE TABLE `tabdodpouk` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `pomoc` int(10) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `ustreznost` text,
  `predlogi` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdodpouk` */

/*Table structure for table `tabdogodek` */

DROP TABLE IF EXISTS `tabdogodek`;

CREATE TABLE `tabdogodek` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `Dogodek` varchar(100) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  `porocilaDo` varchar(50) DEFAULT NULL,
  `kdo` int(10) DEFAULT NULL,
  `ucitelji` text,
  `cas` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdogodek` */

/*Table structure for table `tabdoprinos` */

DROP TABLE IF EXISTS `tabdoprinos`;

CREATE TABLE `tabdoprinos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idDoprinos` int(10) DEFAULT NULL,
  `OblikaDela` varchar(250) DEFAULT NULL,
  `OblikaDelaKratko` varchar(50) DEFAULT NULL,
  `OblikaDelaOznaka` varchar(50) DEFAULT NULL,
  `spremenljivka` varchar(50) DEFAULT NULL,
  `addsub` varchar(5) DEFAULT NULL,
  `uramin` int(10) DEFAULT NULL,
  `koeficient` double DEFAULT NULL,
  `sortiranje` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `aktivno` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

/*Data for the table `tabdoprinos` */

insert  into `tabdoprinos`(`id`,`idDoprinos`,`OblikaDela`,`OblikaDelaKratko`,`OblikaDelaOznaka`,`spremenljivka`,`addsub`,`uramin`,`koeficient`,`sortiranje`,`leto`,`aktivno`) values (1,4,'Tečaj, izobraževanje brez dnevnice (samo vožnja)','Teč.VbD','Tv','PlaniraneUre','add',1,0,42,0,20),(2,5,'Nerealizirane ure (DU)','Nere. ure',NULL,'NerealiziraneUre','sub',60,1,2,0,1),(3,6,'Tabori (vsak dan 8 DU+5 DU zadnji dan)','Šola v nar.',NULL,'SolaVNaravi','add',1,1,5,0,1),(4,7,'Izobraževanje - delovni dan (po 15:00 uri), za izobraževanje je max. 24 ur letno, študijske skupine pišite pod Drugo z utemeljitvijo','Izobr.',NULL,'Izobrazevanje','add',1,1,6,0,1),(5,8,'Izobraževanje - prosti dnevi: (max. 8 ur)','Izobr. PD',NULL,'IzobrazevanjePD','add',1,1,7,0,1),(6,9,'Nadomeščanje - redne ure: (1 PU=45 min)','Nad. RU',NULL,'NadomescanjeRU','add',1,1.5,8,0,1),(7,10,'Nadomeščanje - v OPB: (1 PU=50 min)','Nad. OPB',NULL,'NadomescanjeOPB','add',50,1.3,9,0,1),(8,11,'Nadomeščanje: (DU)','Nad. DU',NULL,'Dezurstva','add',60,1,10,0,1),(9,12,'Spremstvo - delovni dan (DU)','Spr. DD',NULL,'SpremstvaDD','add',1,1,11,0,1),(10,13,'Spremstvo - prosti dnevi (DU)','Spr. PD',NULL,'SpremstvaPD','add',1,1,12,0,1),(11,14,'Govorilne ure - dopoldne (1 DU na teden)','GU dop.',NULL,'GovUreD','add',1,1,13,0,0),(12,15,'Govorilne ure - popoldne (2 DU na teden oz. po realizaciji)','GU pop.',NULL,'GovUreP','add',1,1,14,0,0),(13,16,'Izredni roditeljski sestanek (DU)','Rod. sest.',NULL,'RodSest','add',1,1,15,0,1),(14,17,'Inventura (DU po programu ur)','Invt.',NULL,'Inventura','add',1,1,16,0,0),(15,18,'Dežurstva v času pouka in počitnic (po realizaciji DU)','Dež. p.',NULL,'DezurstvoP','add',1,1,17,0,0),(16,19,'Občasni timi, evalvacijski sestanki (DU) - (obvezna utemeljitev)','Obč. timi',NULL,'ObcasniTimi','add',60,1,19,0,1),(17,20,'Šolska tekmovanja (nad 8 ur)','Šol. tekm.',NULL,'SolTekme','add',1,1,20,0,1),(18,21,'Koriščenje doprinosa ur izven počitnic (cel dan)','Dop.ure',NULL,'Komisije','sub',1,8,26,0,1),(19,22,'Bralna značka (5 min/knjigo na učenca)','Br. zn.',NULL,'BralnaZnacka','add',60,1,22,0,1),(20,23,'Delovni sestanki (1 DU/teden)','Del. sk.',NULL,'DelSestanki','add',1,1,23,0,0),(21,24,'Sestanki: nivojski/aktivi/del.sk. (PU)','Niv. sk.',NULL,'NivojskiSestanki','add',1,1.5,23,0,1),(22,25,'Delovne in druge obveznosti, ki se štejejo za opravljene ure dela (obvezna utemeljitev)','Drugo',NULL,'Zpz','add',1,1,24,0,1),(23,26,'Koriščen doprinos v urah (DU)','Dop.ure',NULL,'DezurstvoMalice','sub',1,1,25,0,1),(24,27,'Koriščen redni dopust izven počitnic (do 2 dni, 1+1, Gaber)','Kor. dop.','Dl','KoriscenDopust','sub',1,8,27,0,2),(25,28,'Izplačila (DU)','Izpl.',NULL,'Predure','sub',1,1,28,0,1),(26,29,'Nerealizirane pedagoške ure','Nere. PU',NULL,'NerealiziranePU','sub',1,1.5,3,0,1),(27,30,'Nerealizirane OPB ure','Nere. OPB',NULL,'NerealiziraneOPB','sub',50,1.3,4,0,1),(28,31,'Interesne dejavnosti: (PU) , če ni za izplačilo','Inter.',NULL,'Interesne','add',1,1.5,18,0,1),(29,32,'Bolniška odsotnost','Boln.','B','Bolniska','add',1,0,29,0,3),(30,33,'Bolniška odsotnost 50%','Boln. 50%','B4','Bolniska50','add',1,0,30,0,4),(31,34,'Koriščenje doprinosa ur med počitnicami','Dopust ure','Du','DopUre','sub',1,0,31,0,5),(32,35,'Letni dopust','Dopust','Dl','DopLet','sub',1,0,32,0,6),(33,36,'Izredni plačani dopust','Izr. pl. dop.','Dip','DopIzrPl','sub',1,0,33,0,7),(34,37,'Izredni neplačani dopust','Izr. nepl. dop','Dn','DopIzrNepl','sub',1,0,34,0,8),(35,38,'Očetovski neplačani dopust','Oč. nepl. dop','Očn','OcNeplDop','sub',1,0,36,0,9),(36,39,'Porodniški dopust','Por. dop','Pd','PorDop','sub',1,0,37,0,10),(37,40,'Dopust za nego in varstvo otroka','Dop. otrok','N','Nega','sub',1,0,38,0,11),(38,41,'Neopravičena odsotnost','Neopr.','In','NeopOds','sub',1,8,39,0,12),(39,42,'Tečaj, izobraževanje z dnevnico','Teč. dnevn.','T','TecajDnevn','add',1,0,40,0,13),(40,43,'Tečaj, izobraževanje brez dnevnice','Teč. b. dnevn.','Tb','TecajBDnevn','add',1,0,41,0,14),(41,44,'Spremstvo (dnevi dejavnosti, tabori, šola v naravi) z dnevnico','Sprem.','S','SpremDnevn','add',1,0,43,0,15),(42,45,'Spremstvo (dnevi dejavnosti, tabori, šola v naravi) brez dnevnice','Sprem. b. dnevn.','Sb','SpremBDnevn','add',1,0,44,0,16),(43,46,'Državni praznik','Praznik','Dp','DrzPraznik','add',1,0,45,0,17),(44,47,'Očetovski dopust','Oč. dop.','Oč','OcDop','sub',1,0,35,0,18),(45,48,'Bolniška ?%','Boln. ?%','B%','BolniskaP','add',1,0,46,0,19);

/*Table structure for table `tabdopust` */

DROP TABLE IF EXISTS `tabdopust`;

CREATE TABLE `tabdopust` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `IdUcitelj` int(10) DEFAULT NULL,
  `DelDobaLet` int(10) DEFAULT NULL,
  `DopustNaDD` int(10) DEFAULT NULL,
  `DopustNaIz` int(10) DEFAULT NULL,
  `DopustNaOt` int(10) DEFAULT NULL,
  `DopustNaSta` int(10) DEFAULT NULL,
  `DopustNaInv` int(10) DEFAULT NULL,
  `DopustNaVod` int(10) DEFAULT NULL,
  `DopustStari` int(10) DEFAULT NULL,
  `DopustVzgoja` int(10) DEFAULT NULL,
  `DopustDelInv` int(10) DEFAULT NULL,
  `DopustPP` int(10) DEFAULT NULL,
  `Drugo` int(10) DEFAULT NULL,
  `Delez` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `TabUciteljiIdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdopust` */

/*Table structure for table `tabdostop` */

DROP TABLE IF EXISTS `tabdostop`;

CREATE TABLE `tabdostop` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `VnosUcDat` bit(1) NOT NULL,
  `UpdUc` bit(1) NOT NULL,
  `Redov` bit(1) NOT NULL,
  `VnosNPZ` bit(1) NOT NULL,
  `ImpExNPZ` bit(1) NOT NULL,
  `DelPregl` bit(1) NOT NULL,
  `DelKontr` bit(1) NOT NULL,
  `UpdDel` bit(1) NOT NULL,
  `Tajn` bit(1) NOT NULL,
  `VnosSist` bit(1) NOT NULL,
  `VnosAktivi` bit(1) NOT NULL,
  `VnosUrnik` bit(1) NOT NULL,
  `VnosNadom` bit(1) NOT NULL,
  `Inventura` bit(1) NOT NULL,
  `StatUc` bit(1) NOT NULL,
  `StatDel` bit(1) NOT NULL,
  `LetnPor` bit(1) NOT NULL,
  `Prehrana` bit(1) NOT NULL,
  `Prisotnost` bit(1) NOT NULL,
  `NovoSL` bit(1) NOT NULL,
  `ImpExUc` bit(1) NOT NULL,
  `DatSola` bit(1) NOT NULL,
  `Prazniki` bit(1) NOT NULL,
  `Prostori` bit(1) NOT NULL,
  `Predmeti` bit(1) NOT NULL,
  `TabEd` bit(1) NOT NULL,
  `RDU` bit(1) NOT NULL,
  `PreglZbirn` bit(1) NOT NULL,
  `PreglPoroc` bit(1) NOT NULL,
  `PreglReal` bit(1) NOT NULL,
  `drugo1` bit(1) NOT NULL,
  `drugo2` bit(1) NOT NULL,
  `drugo3` bit(1) NOT NULL,
  `drugo4` bit(1) NOT NULL,
  `drugo5` bit(1) NOT NULL,
  `drugo6` bit(1) NOT NULL,
  `drugo7` bit(1) NOT NULL,
  `drugo8` bit(1) NOT NULL,
  `drugo9` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8;

/*Data for the table `tabdostop` */

insert  into `tabdostop`(`id`,`idUcitelj`,`VnosUcDat`,`UpdUc`,`Redov`,`VnosNPZ`,`ImpExNPZ`,`DelPregl`,`DelKontr`,`UpdDel`,`Tajn`,`VnosSist`,`VnosAktivi`,`VnosUrnik`,`VnosNadom`,`Inventura`,`StatUc`,`StatDel`,`LetnPor`,`Prehrana`,`Prisotnost`,`NovoSL`,`ImpExUc`,`DatSola`,`Prazniki`,`Prostori`,`Predmeti`,`TabEd`,`RDU`,`PreglZbirn`,`PreglPoroc`,`PreglReal`,`drugo1`,`drugo2`,`drugo3`,`drugo4`,`drugo5`,`drugo6`,`drugo7`,`drugo8`,`drugo9`) values (174,0,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''),(175,1,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

/*Table structure for table `tabdovoljenja` */

DROP TABLE IF EXISTS `tabdovoljenja`;

CREATE TABLE `tabdovoljenja` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `Izjava` bit(1) NOT NULL,
  `Komentar` text,
  `ZdravoZivljenje` bit(1) NOT NULL,
  `KomentZdrZiv` text,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdovoljenja` */

/*Table structure for table `tabdrobniinv` */

DROP TABLE IF EXISTS `tabdrobniinv`;

CREATE TABLE `tabdrobniinv` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `InvSt` varchar(50) DEFAULT NULL,
  `OsnSredstvo` varchar(50) DEFAULT NULL,
  `DodatniOpis` varchar(50) DEFAULT NULL,
  `DatumVpisa` varchar(50) DEFAULT NULL,
  `DatumInv` varchar(50) DEFAULT NULL,
  `idProstor` int(10) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `Opomba` varchar(50) DEFAULT NULL,
  `Prevzel` int(10) DEFAULT NULL,
  `DatumPrevzem` varchar(50) DEFAULT NULL,
  `Prevzemnica` varchar(250) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdrobniinv` */

/*Table structure for table `tabdrtekm` */

DROP TABLE IF EXISTS `tabdrtekm`;

CREATE TABLE `tabdrtekm` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` varchar(50) DEFAULT NULL,
  `stopnja` int(10) DEFAULT NULL,
  `mentor` varchar(50) DEFAULT NULL,
  `porocilo` text,
  `tip` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdrtekm` */

/*Table structure for table `tabdrtekmclan` */

DROP TABLE IF EXISTS `tabdrtekmclan`;

CREATE TABLE `tabdrtekmclan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `mentor1` varchar(50) DEFAULT NULL,
  `mentor2` varchar(50) DEFAULT NULL,
  `datum` varchar(15) DEFAULT NULL,
  `tekmovanje` varchar(50) DEFAULT NULL,
  `idtekmovanje` int(10) DEFAULT NULL,
  `priznanje` varchar(50) DEFAULT NULL,
  `napredovanje` bit(1) NOT NULL,
  `stopnja` varchar(50) DEFAULT NULL,
  `kraj` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `idDogodek` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idtekmovanje` (`idtekmovanje`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabdrtekmclan` */

/*Table structure for table `tabgovorilne` */

DROP TABLE IF EXISTS `tabgovorilne`;

CREATE TABLE `tabgovorilne` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `rs1` bit(1) NOT NULL,
  `rs2` bit(1) NOT NULL,
  `rs3` bit(1) NOT NULL,
  `rs4` bit(1) NOT NULL,
  `rs5` bit(1) NOT NULL,
  `gu1` bit(1) NOT NULL,
  `gu2` bit(1) NOT NULL,
  `gu3` bit(1) NOT NULL,
  `gu4` bit(1) NOT NULL,
  `gu5` bit(1) NOT NULL,
  `gu6` bit(1) NOT NULL,
  `gu7` bit(1) NOT NULL,
  `gu8` bit(1) NOT NULL,
  `gu9` bit(1) NOT NULL,
  `gu10` bit(1) NOT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabgovorilne` */

/*Table structure for table `tabgudatum` */

DROP TABLE IF EXISTS `tabgudatum`;

CREATE TABLE `tabgudatum` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `paralelka` varchar(50) DEFAULT NULL,
  `rs1d` varchar(50) DEFAULT NULL,
  `rs2d` varchar(50) DEFAULT NULL,
  `rs3d` varchar(50) DEFAULT NULL,
  `rs4d` varchar(50) DEFAULT NULL,
  `rs5d` varchar(50) DEFAULT NULL,
  `gu1d` varchar(50) DEFAULT NULL,
  `gu2d` varchar(50) DEFAULT NULL,
  `gu3d` varchar(50) DEFAULT NULL,
  `gu4d` varchar(50) DEFAULT NULL,
  `gu5d` varchar(50) DEFAULT NULL,
  `gu6d` varchar(50) DEFAULT NULL,
  `gu7d` varchar(50) DEFAULT NULL,
  `gu8d` varchar(50) DEFAULT NULL,
  `gu9d` varchar(50) DEFAULT NULL,
  `gu10d` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabgudatum` */

/*Table structure for table `tabinventar` */

DROP TABLE IF EXISTS `tabinventar`;

CREATE TABLE `tabinventar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `InvSt` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabinventar` */

/*Table structure for table `tabinventura` */

DROP TABLE IF EXISTS `tabinventura`;

CREATE TABLE `tabinventura` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `InvSt` varchar(50) DEFAULT NULL,
  `OsnSredstvo` varchar(50) DEFAULT NULL,
  `DodatniOpis` varchar(50) DEFAULT NULL,
  `DatumVpisa` varchar(50) DEFAULT NULL,
  `DatumInv` varchar(50) DEFAULT NULL,
  `idProstor` int(10) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `Opomba` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabinventura` */

/*Table structure for table `tabinvstat` */

DROP TABLE IF EXISTS `tabinvstat`;

CREATE TABLE `tabinvstat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `statusInv` int(10) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabinvstat` */

/*Table structure for table `tabip` */

DROP TABLE IF EXISTS `tabip`;

CREATE TABLE `tabip` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `Naslov` varchar(250) DEFAULT NULL,
  `Datum` varchar(50) DEFAULT NULL,
  `avtor` int(10) DEFAULT NULL,
  `ucenec` int(10) DEFAULT NULL,
  `komentar` text,
  `datoteka` varchar(250) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `Dovoljenja` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabip` */

/*Table structure for table `tabizbirni` */

DROP TABLE IF EXISTS `tabizbirni`;

CREATE TABLE `tabizbirni` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Ucenec` int(10) DEFAULT NULL,
  `Leto` int(10) DEFAULT NULL,
  `Izbirni` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabizbirni` */

/*Table structure for table `tabizbirniizbor` */

DROP TABLE IF EXISTS `tabizbirniizbor`;

CREATE TABLE `tabizbirniizbor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` smallint(6) DEFAULT NULL,
  `ucenec` int(10) DEFAULT NULL,
  `p11` int(10) DEFAULT NULL,
  `p12` int(10) DEFAULT NULL,
  `p13` int(10) DEFAULT NULL,
  `p21` int(10) DEFAULT NULL,
  `p22` int(10) DEFAULT NULL,
  `p23` int(10) DEFAULT NULL,
  `p31` int(10) DEFAULT NULL,
  `p32` int(10) DEFAULT NULL,
  `p33` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;

/*Data for the table `tabizbirniizbor` */

/*Table structure for table `tabizjave` */

DROP TABLE IF EXISTS `tabizjave`;

CREATE TABLE `tabizjave` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `VarPod` bit(1) NOT NULL,
  `DatVarPod` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabizjave` */

/*Table structure for table `tabizobrazba` */

DROP TABLE IF EXISTS `tabizobrazba`;

CREATE TABLE `tabizobrazba` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idIzobrazba` int(10) DEFAULT NULL,
  `Opis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idIzobrazba` (`idIzobrazba`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `tabizobrazba` */

insert  into `tabizobrazba`(`ID`,`idIzobrazba`,`Opis`) values (1,1,'Nedokončana OŠ - 1'),(2,2,'Končana OŠ - 2'),(3,3,'Priučen - 3'),(4,4,'Poklicna - 4'),(5,5,'Srednja - 5'),(6,6,'Višja - 6/1'),(7,7,'Visoka/Univerzitetna (1. Bol. st.) - 6/2'),(8,8,'Univerzitetna/Magisterij (2. Bol. st.) - 7'),(9,9,'Magisterij - 8/1'),(10,10,'Doktorat/(3. Bol. st.) - 8/2');

/*Table structure for table `tabizobrazevanje` */

DROP TABLE IF EXISTS `tabizobrazevanje`;

CREATE TABLE `tabizobrazevanje` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `Izobrazevanje` varchar(250) DEFAULT NULL,
  `Kraj` varchar(50) DEFAULT NULL,
  `DatumOd` varchar(50) DEFAULT NULL,
  `DatumDo` varchar(50) DEFAULT NULL,
  `Izvajalec` varchar(50) DEFAULT NULL,
  `Naslov` varchar(250) DEFAULT NULL,
  `Trajanje` varchar(50) DEFAULT NULL,
  `Tocke` varchar(50) DEFAULT NULL,
  `Kotizacija` int(10) DEFAULT NULL,
  `OstStroski` int(10) DEFAULT NULL,
  `priporocam` bit(1) NOT NULL,
  `porocilo` text,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabizobrazevanje` */

/*Table structure for table `tabkljucdelavec` */

DROP TABLE IF EXISTS `tabkljucdelavec`;

CREATE TABLE `tabkljucdelavec` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `idKljuc` int(10) DEFAULT NULL,
  `datumOd` varchar(50) DEFAULT NULL,
  `datumDo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idKljuc` (`idKljuc`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkljucdelavec` */

/*Table structure for table `tabkljuci` */

DROP TABLE IF EXISTS `tabkljuci`;

CREATE TABLE `tabkljuci` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Opis` varchar(250) DEFAULT NULL,
  `idProstor` varchar(250) DEFAULT NULL,
  `Dodatno` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idKljuca` (`Opis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkljuci` */

/*Table structure for table `tabkoefdela` */

DROP TABLE IF EXISTS `tabkoefdela`;

CREATE TABLE `tabkoefdela` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `koeficient` double DEFAULT NULL,
  `datumOd` timestamp NULL DEFAULT NULL,
  `datumDo` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkoefdela` */

/*Table structure for table `tabkontakti` */

DROP TABLE IF EXISTS `tabkontakti`;

CREATE TABLE `tabkontakti` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `Telefon` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `drugo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;

/*Data for the table `tabkontakti` */

insert  into `tabkontakti`(`id`,`idUcitelj`,`Telefon`,`email`,`drugo`) values (164,1,'','',NULL);

/*Table structure for table `tabkontrolka` */

DROP TABLE IF EXISTS `tabkontrolka`;

CREATE TABLE `tabkontrolka` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdKontrolka` varchar(50) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `nivo` varchar(50) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  `snov` varchar(50) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `obdobje` int(10) DEFAULT NULL,
  `ucitelj` int(10) DEFAULT NULL,
  `t01` double DEFAULT NULL,
  `t02` double DEFAULT NULL,
  `t03` double DEFAULT NULL,
  `t04` double DEFAULT NULL,
  `t05` double DEFAULT NULL,
  `t06` double DEFAULT NULL,
  `t07` double DEFAULT NULL,
  `t08` double DEFAULT NULL,
  `t09` double DEFAULT NULL,
  `t10` double DEFAULT NULL,
  `t11` double DEFAULT NULL,
  `t12` double DEFAULT NULL,
  `t13` double DEFAULT NULL,
  `t14` double DEFAULT NULL,
  `t15` double DEFAULT NULL,
  `t16` double DEFAULT NULL,
  `t17` double DEFAULT NULL,
  `t18` double DEFAULT NULL,
  `t19` double DEFAULT NULL,
  `t20` double DEFAULT NULL,
  `t21` double DEFAULT NULL,
  `t22` double DEFAULT NULL,
  `t23` double DEFAULT NULL,
  `t24` double DEFAULT NULL,
  `t25` double DEFAULT NULL,
  `k2s` double DEFAULT NULL,
  `k2z` double DEFAULT NULL,
  `k3s` double DEFAULT NULL,
  `k3z` double DEFAULT NULL,
  `k4s` double DEFAULT NULL,
  `k4z` double DEFAULT NULL,
  `dato` varchar(100) DEFAULT NULL,
  `potrjeno` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkontrolka` */

/*Table structure for table `tabkontrolkaucenec` */

DROP TABLE IF EXISTS `tabkontrolkaucenec`;

CREATE TABLE `tabkontrolkaucenec` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ucenec` int(10) DEFAULT NULL,
  `n01` double DEFAULT NULL,
  `n02` double DEFAULT NULL,
  `n03` double DEFAULT NULL,
  `n04` double DEFAULT NULL,
  `n05` double DEFAULT NULL,
  `n06` double DEFAULT NULL,
  `n07` double DEFAULT NULL,
  `n08` double DEFAULT NULL,
  `n09` double DEFAULT NULL,
  `n10` double DEFAULT NULL,
  `n11` double DEFAULT NULL,
  `n12` double DEFAULT NULL,
  `n13` double DEFAULT NULL,
  `n14` double DEFAULT NULL,
  `n15` double DEFAULT NULL,
  `n16` double DEFAULT NULL,
  `n17` double DEFAULT NULL,
  `n18` double DEFAULT NULL,
  `n19` double DEFAULT NULL,
  `n20` double DEFAULT NULL,
  `n21` double DEFAULT NULL,
  `n22` double DEFAULT NULL,
  `n23` double DEFAULT NULL,
  `n24` double DEFAULT NULL,
  `n25` double DEFAULT NULL,
  `kontrolka` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkontrolkaucenec` */

/*Table structure for table `tabkrajbivanja` */

DROP TABLE IF EXISTS `tabkrajbivanja`;

CREATE TABLE `tabkrajbivanja` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `KrajBivanja` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `tabkrajbivanja` */

insert  into `tabkrajbivanja`(`Id`,`KrajBivanja`) values (1,'Šolski okoliš'),(2,'Ljubljana - peš'),(3,'Ljubljana - avtobus'),(4,'Ljubljana - vlak'),(5,'Ljubljana - osebni prevoz'),(6,'Ljubljana okolica - peš'),(7,'Ljubljana okolica - avtobus'),(8,'Ljubljana okolica - vlak'),(9,'Ljubljana okolica - osebni prevoz');

/*Table structure for table `tabkrajsidelovnik` */

DROP TABLE IF EXISTS `tabkrajsidelovnik`;

CREATE TABLE `tabkrajsidelovnik` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `ProcZaposl` int(10) DEFAULT NULL,
  `Obremen1` int(10) DEFAULT NULL,
  `Obremen2` int(10) DEFAULT NULL,
  `Obremen3` int(10) DEFAULT NULL,
  `Obremen4` int(10) DEFAULT NULL,
  `Obremen5` int(10) DEFAULT NULL,
  `datumOd` timestamp NULL DEFAULT NULL,
  `datumDo` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkrajsidelovnik` */

/*Table structure for table `tabkriterijizanapredovanje` */

DROP TABLE IF EXISTS `tabkriterijizanapredovanje`;

CREATE TABLE `tabkriterijizanapredovanje` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `tip` int(10) DEFAULT NULL,
  `clen` varchar(255) DEFAULT NULL,
  `razdelek` varchar(255) DEFAULT NULL,
  `alineja` varchar(255) DEFAULT NULL,
  `tock` double DEFAULT NULL,
  `vsebina` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

/*Data for the table `tabkriterijizanapredovanje` */

insert  into `tabkriterijizanapredovanje`(`ID`,`tip`,`clen`,`razdelek`,`alineja`,`tock`,`vsebina`) values (1,NULL,'19',NULL,'1',4,'diploma'),(2,NULL,'19',NULL,'2',6,'specializacija'),(3,NULL,'19',NULL,'3',8,'magisterij'),(4,NULL,'19',NULL,'4',16,'doktorat znanosti'),(5,NULL,'19',NULL,'5',0.5,'program od 8-15 ur'),(6,NULL,'19',NULL,'6',1,'program od 16-23 ur'),(7,NULL,'19',NULL,'7',1.5,'program 24 ur in več'),(8,NULL,'20','a','1',1,'(1) enoletno mentorstvo za najmanj tri učence ali druge udeležence izobraževanja in usposabljanja ali enoletno mentorstvo športni ekipi, zboru, komorni skupini, orkestru oziroma\r\n\r\n(1) enoletno mentorstvo za najmanj tri učence ali druge udeležence izobraževanja in usposabljanja ali enoletno mentorstvo športni ekipi, zboru, komorni skupini, orkestru oziroma\r\n\r\ndrugi podobni skupini, ki je dobila priznanje na tekmovanju ali natečaju izven zavoda'),(9,NULL,'20','a','2',1,'(2) enoletno mentorstvo za najmanj tri učence ali druge udeležence izobraževanja in usposabljanja, ki sodelujejo v izvenšolskih projektih, ali enoletno vodenje interesnih dejavnosti'),(10,NULL,'20','a','3',1,'(3) tri hospitacije za študente ali dijake (vzorni nastop)'),(11,NULL,'20','a','4',1,'(4) mentorstvo petim študentom za pripravo za nastop'),(12,NULL,'20','a','5',1,'(5) enotedensko mentorstvo za vsakega študenta oziroma\r\n\r\ndijaka na pedagoški oziroma andragoški praksi'),(13,NULL,'20','a','6',1,'(6) pet nastopov za starše (praktična predstavitev pouka)'),(14,NULL,'20','a','7',1,'(7) trije nastopi za sodelavce (praktična predstavitev pouka)'),(15,NULL,'20','a','8',1,'(8) izvedba petih delavnic z aktivnim sodelovanjem otrok ali drugih udeležencev izobraževanja in usposabljanja ter staršev'),(16,NULL,'20','a','9',1,'(9) pet točk programa lastnega javnega nastopa'),(17,NULL,'20','a','10',1,'(10) izvedba treh pedagoških delavnic oziroma predavanj za učiteljski oziroma vzgojiteljski oziroma andragoški zbor'),(18,NULL,'20','a','11',1,'(11) dva nastopa za strokovne delavce najmanj treh šol'),(19,NULL,'20','a','12',1,'(12) enoletno vodenje strokovnega aktiva v zavodu'),(20,NULL,'20','a','13',1,'(13) organizacija treh tematskih razstav, odprtih za javnost'),(21,NULL,'20','a','14',1,'(14) organizacija treh javnih nastopov učencev glasbene šole'),(22,NULL,'20','a','15',1,'(15) mentorstvo najmanj trem učencem ali skupini na javnem nastopu'),(23,NULL,'20','a','16',1,'(16) korepeticije za deset učencev na javnem nastopu ali korepeticije na dveh celovečernih javnih koncertih'),(24,NULL,'20','a','17',1,'(17) organizacija javne prireditve v kraju z najmanj petimi točkami programa ali tremi nastopajočimi skupinami'),(25,NULL,'20','a','18',1,'(18) organizacija revije glasbenih šol'),(26,NULL,'20','a','19',1,'(19) vodenje skupine učencev ali drugih udeležencev izobraževanja in usposabljanja v dveh šolah v naravi ali na dveh raziskovalnih taborih ali vodenje dveh strokovnih ekskurzij'),(27,NULL,'20','a','20',1,'(20) predstavitev plakata ali razstave na organiziranem strokovnem izobraževanju ali strokovnem posvetu strokovnih delavcev izven zavoda'),(28,NULL,'20','a','21',1,'(21) organizacija enega tekmovanja na lokalni ravni med učenci ali drugimi udeleženci izobraževanja in usposabljanja najmanj petih zavodov ter aktivno sodelovanje na takem tekmovanju'),(29,NULL,'20','a','22',1,'(22) izdelava propozicij ali priprava nalog za eno tekmovanje'),(30,NULL,'20','a','23',1,'(23) organizacija enega strokovnega posveta ali seminarja z aktivnim sodelovanjem'),(31,NULL,'20','a','24',1,'(24) strokovno delo v ocenjevalnih komisijah ali žirijah na treh tekmovanjih'),(32,NULL,'20','a','25',1,'(25) strokovno delo ocenjevalca pri zunanjem preverjanju znanja v obsegu sto ur'),(33,NULL,'20','a','26',1,'(26) dveletno strokovno delo v šolski komisiji za izvedbo zunanjega preverjanja znanja'),(34,NULL,'20','a','27',1,'(27) mentorstvo petim učencem ali drugim udeležencem izobraževanja in usposabljanja v okviru izvenšolskih raziskovalnih projektov, organiziranih na lokalni ravni'),(35,NULL,'20','a','28',1,'(28) enoletno delo v okviru projektov za trajnostni razvoj, v inovacijskih projektih ali v projektih uveljavljanja in izmenjave projektnih dosežkov, ki potekajo na podlagi javnih razpisov ministrstva, pristojnega za šolstvo, in za to pooblaščenih javnih zavodov'),(36,NULL,'20','a','29',1,'(29) izvedba prireditev in dejavnosti, ki jih za učence ali druge udeležence izobraževanja in usposabljanja organizira šola v času počitnic v trajanju najmanj pet dni'),(37,NULL,'20','b','1',2,'(1) enoletno mentorstvo oziroma korepetitorstvo za vsake tri učence ali druge udeležence izobraževanja in usposabljanja oziroma za vsako športno ekipo, zbor, komorno skupino, orkester ali drugo skupino, ki se uvrsti na prva tri mesta oziroma osvoji plaketo (zlato, srebrno, bronasto) na tekmovanju na državni ravni'),(38,NULL,'20','b','2',2,'(2) mentorstvo za vsake tri učence glasbene šole, ki so uspešno opravili sprejemni izpit iz inštrumenta na srednji glasbeni šoli'),(39,NULL,'20','b','3',2,'(3) mentorstvo za vsakih pet učencev glasbene šole, ki so uspešno opravili sprejemni izpit iz nauka o glasbi na srednji glasbeni šoli'),(40,NULL,'20','b','4',2,'(4) mentorstvo pripravniku, tujemu lektorju, asistentu za tuji jezik ali drugemu strokovnemu delavcu začetniku'),(41,NULL,'20','b','5',2,'(5) mentorstvo učencem ali drugim udeležencem izobraževanja in usposabljanja v okviru izvenšolskih raziskovalnih projektov na državni ali mednarodni ravni (npr. Znanost mladini), ali v okviru razvojno aplikativnih projektov, ki potekajo na podlagi javnih razpisov ministrstva, pristojnega za šolstvo, in za to pooblaščenih javnih zavodov ali društev, raziskovalno delo pa javno predstavijo ali ga objavijo na spletni strani'),(42,NULL,'20','b','6',2,'(6) enoletno mentorstvo šolski dijaški skupnosti ali šolskemu otroškemu parlamentu'),(43,NULL,'20','b','7',2,'(7) enoletno vodenje in koordiniranje izvenšolskega nacionalnega ali mednarodnega projekta na šoli ali enoletno vodenje in koordiniranje razvojno aplikativnega projekta ali projekta uveljavljanja in izmenjave projektnih dosežkov, ki je bil izbran na razpisu ministrstva, pristojnega za šolstvo'),(44,NULL,'20','b','8',2,'(8) tri koreografije oziroma kompozicija treh vaj za učence glasbenih in baletnih šol za javne nastope'),(45,NULL,'20','b','9',2,'(9) enoletno vodenje strokovnega društva izven zavoda'),(46,NULL,'20','b','10',2,'(10) enoletno vodenje kluba ali sekcije izven zavoda, v katerega so vključeni učenci ali drugi udeleženci izobraževanja in usposabljanja ter se navezuje na vzgojno delo z učenci ali drugimi udeleženci izobraževanja in usposabljanja'),(47,NULL,'20','b','11',2,'(11) enoletno vodenje društva glasbenih ali plesnih pedagogov ali Zveze Glasbenih šol Republike Slovenije'),(48,NULL,'20','b','12',2,'(12) enoletno vodenje strokovnega aktiva izven zavoda'),(49,NULL,'20','b','13',2,'(13) enoletno vodenje študijskih skupin'),(50,NULL,'20','b','14',2,'(14) enoletno delo v komisiji za strokovne izpite v vzgoji in izobraževanju'),(51,NULL,'20','b','15',2,'(15) en mandat sodelovanja v strokovnih združenjih ravnateljev na državni ravni oziroma v Zvezi ljudskih univerz ali drugih združenj izobraževalcev odraslih'),(52,NULL,'20','b','16',2,'(16) samostojno predavanje ali izvedba pedagoške delavnice na organiziranem strokovnem izobraževanju ali strokovnem posvetu strokovnih delavcev izven zavoda'),(53,NULL,'20','b','17',2,'(17) organizacija enega tekmovanja na državni ravni med učenci zavodov in aktivno sodelovanje na takem tekmovanju'),(54,NULL,'20','b','18',2,'(18) koncertni nastop učitelja izven zavoda'),(55,NULL,'20','b','19',2,'(19) prva objava samostojnega prevoda strokovnega članka v strokovnem časopisu ali pedagoški reviji'),(56,NULL,'20','b','20',2,'(20) prva objava samostojnega avtorskega strokovnega članka ali petih didaktičnih nalog v strokovnem časopisu ali pedagoški reviji, objava priredbe glasbenega dela ali objava lastne skladbe'),(57,NULL,'20','b','21',2,'(21) strokovna recenzija v postopku potrjevanja učbenika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa, priročnika ali učnega sredstva, ki ga je potrdil pristojni strokovni svet'),(58,NULL,'20','b','22',2,'(22) lektoriranje učbenika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa, priročnika ali učnega sredstva, ki ga je potrdil pristojni strokovni svet'),(59,NULL,'20','b','23',2,'(23) dveletno vodenje in koordiniranje skupine ocenjevalcev pri zunanjem preverjanju znanja'),(60,NULL,'20','b','24',2,'(24) štiriletno strokovno delo v državni predmetni komisiji za pripravo in izvedbo zunanjega preverjanja znanja'),(61,NULL,'20','b','25',2,'(25) obdobje štirih let tajništva v šolski komisiji za izvedbo zunanjega preverjanja znanja'),(62,NULL,'20','b','26',2,'(26) štiriletno vodenje šolske komisije za izvedbo zunanjega preverjanja znanja'),(63,NULL,'20','b','27',2,'(27) strokovno delo pregledovalca izpitnega gradiva pri zunanjem preverjanju znanja v obsegu 20 do 30 ur'),(64,NULL,'20','b','28',2,'(28) štiriletno strokovno delo izvedenca za pritožbene postopke pri zunanjem preverjanju znanja'),(65,NULL,'20','b','29',2,'(29) enoletno vodenje dejavnosti študijskih krožkov ali mentorstvo posameznega študijskega krožka na področju izobraževanja odraslih'),(66,NULL,'20','b','30',2,'(30) organizacija Tedna vseživljenjskega učenja'),(67,NULL,'20','b','31',2,'(31) organizacija enotedenskega gostovanja tuje šole'),(68,NULL,'20','b','32',2,'(32) štiriletno sodelovanje v programskem sosvetu za vsebinski izbor programov nadaljnjega izobraževanja in usposabljanja v vzgoji in izobraževanju'),(69,NULL,'20','b','33',2,'(33) organizacija in izvedba javne prireditve v kraju z učenci prvih dveh vzgojno-izobraževalnih obdobij ali z učenci šol in zavodov za otroke in mladostnike s posebnimi potrebami, namenjene obeleževanju pomembnejših datumov (državni prazniki in pomembne obletnice kraja)'),(70,NULL,'20','b','34',2,'(34) organizacija in pedagoško vodenje dveh šol v naravi ali dveh raziskovalnih taborov'),(71,NULL,'20','c','1',3,'(1) priprava ali sodelovanje pri pripravi predloga učnega programa ali učnega načrta za sprejem na pristojnem strokovnem svetu'),(72,NULL,'20','c','2',3,'(2) javni koncertni nastop, gledališka predstava ali samostojna avtorska razstava likovnih del, v organizaciji inštitucij na državnem nivoju'),(73,NULL,'20','c','3',3,'(3) samostojni referat na kongresu ali konferenci v organizaciji inštitucij na državnem nivoju'),(74,NULL,'20','c','4',3,'(4) prva objava avtorske raziskovalne naloge ali avtorstvo knjige'),(75,NULL,'20','c','5',3,'(5) avtorstvo skladb na CD plošči ali izdaja CD plošče (solist, duo, trio, kvartet, kvintet)'),(76,NULL,'20','c','6',3,'(6) prva objava samostojnega prevoda strokovne knjige'),(77,NULL,'20','c','7',3,'(7) prva objava avtorskega strokovnega članka v tujem strokovnem časopisu ali pedagoški reviji'),(78,NULL,'20','c','8',3,'(8) enoletno razvojno-raziskovalno delo v povezavi z ministrstvom, pristojnim za šolstvo, univerzitetnim ali drugim visokošolskim zavodom, ki izobražuje kadre za področje šolstva,\r\n\r\nPedagoškim inštitutom, Zavodom Republike Slovenije za šolstvo, Centrom Republike Slovenije za poklicno izobraževanje, Andragoškim centrom Republike Slovenije, Državnim izpitnim centrom in Centrom šolskih in obšolskih dejavnosti'),(79,NULL,'20','c','9',3,'(9) dveletno strokovno delo glavnega ocenjevalca pri pripravi in izvedbi zunanjega preverjanja znanja'),(80,NULL,'20','c','10',3,'(10) organizacija enega tekmovanja med učenci ali drugimi udeleženci izobraževanja in usposabljanja na mednarodni ravni in aktivno sodelovanje na takem tekmovanju'),(81,NULL,'20','c','11',3,'(11) organizacija mednarodnega strokovnega posveta ali seminarja'),(82,NULL,'20','c','12',3,'(12) koordinatorstvo projektov decentraliziranih akcij, ki jih potrdi Programski svet Socrates ali Leonardo da Vinci'),(83,NULL,'20','c','13',3,'(13) obdobje enega mandata sodelovanja v strokovnih organih na mednarodni ravni na področju glasbe oziroma plesa (EMU, EMCY.)'),(84,NULL,'20','č','1',4,'(1) mentorstvo ali korepetitorstvo za vsakega učenca ali drugega udeleženca izobraževanja in usposabljanja oziroma za vsako športno ekipo, zbor, komorno skupino, orkester ali drugo skupino, ki se uvrsti na prva tri mesta oziroma osvoji plaketo (zlato, srebrno, bronasto) na tekmovanju ali natečaju na mednarodni ravni med predstavniki najmanj petih držav'),(85,NULL,'20','č','2',4,'(2) samostojni referat na mednarodnem kongresu ali konferenci'),(86,NULL,'20','č','3',4,'(3) uvrstitev strokovnega delavca na prva tri mesta oziroma osvojitev plakete (zlate, srebrne, bronaste) na tekmovanju na mednarodni ravni med predstavniki najmanj petih držav'),(87,NULL,'20','č','4',4,'(4) koncertna izvedba orkestralnih oziroma vokalno-instrumentalnih del učitelja v organizaciji državnih koncertnih inštitucij ali meddržavne menjave'),(88,NULL,'20','č','5',4,'(5) celovečerni solistični koncert (duo, trio, kvartet, kvintet, solistični nastop z orkestrom, solistični nastop v operni ali baletni predstavi) v organizaciji državnih koncertnih inštitucij ali meddržavne menjave'),(89,NULL,'20','č','6',4,'(6) objavljen prevod učbenika, ki ga je potrdil pristojni strokovni svet, pri čemer edinemu prevajalcu pripadajo vse točke, če je prevajalcev več, pa se njihovi deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih'),(90,NULL,'20','č','7',4,'(7) obdobje enega mandata sodelovanja v strokovnem svetu, pristojnem za vzgojo in izobraževanje'),(91,NULL,'20','č','8',4,'(8) štiriletno strokovno delo v državni komisiji za izvedbo zunanjega preverjanja znanja'),(92,NULL,'20','d','1',5,'(1) nosilstvo projekta oziroma mreže izbrane na razpisu centraliziranih akcij, ki jih potrdi Programski svet Socrates ali Leonardo da Vinci'),(93,NULL,'20','d','2',5,'(2) obdobje enega mandata vodenja komisije strokovnega sveta, pristojnega za vzgojo in izobraževanje'),(94,NULL,'20','d','3',5,'(3) avtorstvo priročnika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa ali učnega sredstva, ki ga je potrdil pristojni strokovni svet, in sicer tako, da edinemu avtorju pripadajo vse točke, če je avtorjev več, pa se deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih k ustvaritvi avtorskega dela'),(95,NULL,'20','e','1',8,'(1) obdobje enega mandata vodenja strokovnega sveta, pristojnega za vzgojo in izobraževanje'),(96,NULL,'20','f','1',10,'(1) avtorstvo učbenika, ki ga je potrdil pristojni strokovni svet, in sicer tako, da edinemu avtorju pripadajo vse točke, če je avtorjev več, pa se deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih k ustvaritvi avtorskega dela'),(97,NULL,'22',NULL,'1',0.5,'- znanja in veščine, ki jih je zaposleni pridobil s tečaji, seminarji in usposabljanji v trajanju najmanj osem pedagoških ur oziroma en dan brez preizkusa znanja z 0,5 točke'),(98,NULL,'22',NULL,'2',1,'- znanja in veščine, ki jih je zaposleni pridobil z dve do štiri dnevnimi tečaji, seminarji in usposabljanji brez preizkusa znanja z 1 točko'),(99,NULL,'22',NULL,'3',1.5,'- znanja in veščine, ki jih je zaposleni pridobil s pet in večdnevnimi tečaji, seminarji in usposabljanji brez preizkusa znanja z 1,5 točke'),(100,NULL,'22',NULL,'1',1,'- znanja in veščine, ki jih je zaposleni pridobil s tečaji, seminarji in usposabljanji v trajanju najmanj osem pedagoških ur oziroma en dan s preizkusom znanja 1 točko'),(101,NULL,'22',NULL,'2',1.5,'- znanja in veščine, ki jih je zaposleni pridobil z dve do štiri dnevnimi tečaji, seminarji in usposabljanji s preizkusom znanja z 1,5 točko'),(102,NULL,'22',NULL,'3',2,'- znanja in veščine, ki jih je zaposleni pridobil s pet in večdnevnimi tečaji, seminarji in usposabljanji s preizkusom znanja z 2 točkama'),(103,NULL,'22',NULL,'5',3,'- certifikat o aktivnem znanju tujega jezika s 3 točkami'),(104,NULL,'22',NULL,'6',3,'- strokovni izpit, razen izpita po končani pripravniški dobi s 3 točkami'),(105,NULL,'22',NULL,'7',4,'- diploma s 4 točkami'),(106,NULL,'22',NULL,'8',6,'- specializacija s 6 točkami'),(107,NULL,'22',NULL,'9',8,'- magisterij z 8 točkami'),(108,NULL,'22',NULL,'10',16,'- doktorat znanosti s 16 točkami'),(109,NULL,'23','a','1',1,'(1) pet nastopov za sodelavce (praktična predstavitev pouka)'),(110,NULL,'23','a','2',1,'(2) izvedba treh pedagoških delavnic oziroma predavanj za učiteljski oziroma vzgojiteljski zbor oziroma strokovni aktiv'),(111,NULL,'23','a','3',1,'(3) organizacija ene kulturne, športne, okoljevarstvene dejavnosti na lokalni ravni'),(112,NULL,'23','a','4',1,'(4) organizacija in aktivno sodelovanje na raziskovalnem taboru, ki ni del obveznega programa šole'),(113,NULL,'23','a','5',1,'(5) aktivno sodelovanje na strokovnem posvetu'),(114,NULL,'23','a','6',1,'(6) strokovno delo v ocenjevalnih komisijah ali žirijah na\r\n\r\ntreh tekmovanjih'),(115,NULL,'23','a','7',1,'(7) enoletno vodenje strokovnega aktiva v zavodu'),(116,NULL,'23','a','8',1,'(8) strokovno delo ocenjevalca pri zunanjem preverjanju znanja v obsegu sto ur'),(117,NULL,'23','a','9',1,'(9) dveletno strokovno delo v šolski komisiji za izvedbo zunanjega preverjanja znanja'),(118,NULL,'23','a','10',1,'(10) en mandat dela v področni kurikularni komisiji in področnih strokovnih komisijah'),(119,NULL,'23','a','11',1,'(11) sodelovanje v komisijah za ugotavljanje izpolnjevanja pogojev za izvajanje javnoveljavnih programov vzgoje in izobraževanja'),(120,NULL,'23','a','12',1,'(12) organizacija in aktivno sodelovanje pri izvedbi seminarja (štiri ure predavanj, vaj, delavnic ) v posameznem šolskem letu'),(121,NULL,'23','a','13',1,'(13) organizacija državnega tekmovanja (brez aktivne udeležbe učencev)'),(122,NULL,'23','a','14',1,'(14) konzulentstvo v inovacijskih projektih šol ali recenzentstvo gradiv, nastalih v inovacijskih projektih (en projekt = ena točka)'),(123,NULL,'23','a','15',1,'(15) najmanj enoletno vodenje aktivnosti pri promociji in ohranjanju naravne in kulturne dediščine na lokalni ravni'),(124,NULL,'23','a','16',1,'(16) obdobje enega mandata sodelovanja v strokovnih organih zavoda'),(125,NULL,'23','a','17',1,'(17) koordinatorstvo in konzulentstvo pri razvojnih, inovacijskih in mednarodnih projektih, sprejetih na javnem razpisu'),(126,NULL,'23','b','1',2,'(1) enoletno vodenje strokovnega društva ali strokovne komisije izven zavoda'),(127,NULL,'23','b','2',2,'(2) enoletno vodenje kluba ali sekcije izven zavoda, v katerega so vključeni učenci ali drugi udeleženci izobraževanja in usposabljanja in se navezuje na vzgojno delo z učenci in drugimi udeleženci izobraževanja in usposabljanja'),(128,NULL,'23','b','3',2,'(3) enoletno vodenje društva glasbenih ali plesnih pedagogov ali Zveze Glasbenih šol Republike Slovenije'),(129,NULL,'23','b','4',2,'(4) enoletno delo v komisiji za strokovne izpite v vzgoji in izobraževanju ali v komisiji za mojstrske, delovodske in poslovne izpite'),(130,NULL,'23','b','5',2,'(5) sodelovanje pri organizaciji mednarodnih tekmovanj, koordinacija in organizacija izobraževalno-sejemskih prireditev v tujini'),(131,NULL,'23','b','6',2,'(6) prva objava samostojnega prevoda strokovnega članka v strokovnem časopisu ali pedagoški reviji'),(132,NULL,'23','b','7',2,'(7) prva objava samostojnega avtorskega strokovnega članka v strokovnem časopisu ali pedagoški reviji'),(133,NULL,'23','b','8',2,'(8) strokovna recenzija v postopku potrjevanja učbenika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa, priročnika ali učnega sredstva, ki ga je potrdil pristojni strokovni svet'),(134,NULL,'23','b','9',2,'(9) lektoriranje učbenika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa, priročnika ali učnega sredstva, ki ga je potrdil pristojni strokovni svet'),(135,NULL,'23','b','10',2,'(10) štiriletno sodelovanje v programskem sosvetu za vsebinski izbor programov nadaljnjega izobraževanja in usposabljanja v vzgoji in izobraževanju'),(136,NULL,'23','b','11',2,'(11) organizacija mednarodnega srečanja, kongresa, delavnice, posveta ali tekmovanja z udeležbo najmanj pet držav'),(137,NULL,'23','b','12',2,'(12) enoletno vodenje strokovnega aktiva izven zavoda'),(138,NULL,'23','b','13',2,'(13) udeležba na znanstvenem oziroma strokovnem posvetu z aktivnim sodelovanjem'),(139,NULL,'23','b','14',2,'(14) dveletno vodenje in koordiniranje skupine ocenjevalcev pri zunanjem preverjanju znanja'),(140,NULL,'23','b','15',2,'(15) štiriletno strokovno delo v državni predmetni komisiji za pripravo in izvedbo zunanjega preverjanja znanja'),(141,NULL,'23','b','16',2,'(16) obdobje .tirih let tajništva v šolski komisiji za izvedbo zunanjega preverjanja znanja'),(142,NULL,'23','b','17',2,'(17) štiriletno vodenje šolske komisije za izvedbo zunanjega preverjanja znanja'),(143,NULL,'23','b','18',2,'(18) strokovno delo pregledovalca izpitnega gradiva pri zunanjem preverjanju znanja v obsegu 20 do 30 ur'),(144,NULL,'23','b','19',2,'(19) štiriletno strokovno delo izvedenca za pritožbene postopke pri zunanjem preverjanju znanja'),(145,NULL,'23','c','1',3,'(1) samostojni referat na kongresu, strokovnem posvetu ali konferenci v organizaciji institucij na državnem nivoju'),(146,NULL,'23','c','2',3,'(2) enoletno vodenje inovacijskih in razvojnih projektov, sprejetih na mednarodnem javnem razpisu'),(147,NULL,'23','c','3',3,'(3) sodelovanje pri organizaciji mednarodnega srečanja, kongresa, delavnice, posveta ali tekmovanja z udeležbo najmanj deset držav'),(148,NULL,'23','c','4',3,'(4) zasnova, priprava in sodelovanje z lokalno skupnostjo pri izvedbi učnih poti'),(149,NULL,'23','c','5',3,'(5) dveletno strokovno delo glavnega ocenjevalca pri pripravi in izvedbi zunanjega preverjanja znanja'),(150,NULL,'23','č','1',4,'(1) referat na mednarodnem kongresu, konferenci ali posvetu'),(151,NULL,'23','č','2',4,'(2) uvrstitev zaposlenega na prva tri mesta na tekmovanju na mednarodni ravni oziroma osvojitev plakete (zlate, srebrne, bronaste) na tekmovanju na mednarodni ravni med predstavniki najmanj petih držav'),(152,NULL,'23','č','3',4,'(3) objavljen prevod učbenika, ki ga je potrdil pristojni strokovni svet, pri čemer edinemu prevajalcu pripadajo vse točke, če je prevajalcev več, pa se njihovi deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih'),(153,NULL,'23','č','4',4,'(4) obdobje enega mandata sodelovanja v strokovnem svetu, pristojnem za vzgojo in izobraževanje'),(154,NULL,'23','č','5',4,'(5) štiriletno strokovno delo v državni komisiji za izvedbo zunanjega preverjanja znanja'),(155,NULL,'23','d','1',5,'(1) obdobje enega mandata vodenja komisije strokovnega sveta, pristojnega za vzgojo in izobraževanje'),(156,NULL,'23','d','2',5,'(2) avtorstvo priročnika, delovnega zvezka, zbirke nalog oziroma vaj, atlasa ali učnega sredstva, ki ga je potrdil pristojni strokovni svet, in sicer tako, da edinemu avtorju pripadajo vse točke, če je avtorjev več, pa se deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih k ustvaritvi avtorskega dela'),(157,NULL,'23','e','1',8,'(1) obdobje enega mandata vodenja strokovnega sveta, pristojnega za vzgojo in izobraževanje'),(158,NULL,'23','f','1',10,'(1) avtorstvo učbenika, ki ga je potrdil pristojni strokovni svet, in sicer tako, da edinemu avtorju pripadajo vse točke, če je avtorjev več, pa se deleži določijo v sorazmerju z dejanskim prispevkom vsakega izmed njih k ustvaritvi avtorskega dela'),(159,NULL,NULL,NULL,NULL,NULL,'drugo');

/*Table structure for table `tabkritosoc` */

DROP TABLE IF EXISTS `tabkritosoc`;

CREATE TABLE `tabkritosoc` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Kriterij` varchar(250) DEFAULT NULL,
  `Vsebina` varchar(250) DEFAULT NULL,
  `Aktivno` bit(1) NOT NULL,
  `VrstniRed` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

/*Data for the table `tabkritosoc` */

insert  into `tabkritosoc`(`id`,`Kriterij`,`Vsebina`,`Aktivno`,`VrstniRed`) values (1,'Znanje in strokovnost','mentorstvo pripravniku, študentu, ...','',1),(2,'Znanje in strokovnost','priprava predavanj in delavnic za starše, učiteljski zbor, aktivno sodelovanje na posvetih, nadpovprečno izvedene hospitacije (redne, za študente, za kolege)','',1),(3,'Znanje in strokovnost','izboljšanje del procesa tehničnih in administrativnih delavcev','',1),(4,'Kakovost in natančnost','mentorstvo učencem (ki so prejeli priznanje na tekmovanju - šolsko, regijsko, državno; dosežki na natečajih)','',2),(5,'Kakovost in natančnost','mentorstvo učencem na tekmovanju, na natečaju','',2),(6,'Kakovost in natančnost','vodenje strokovnega tima (aktiv, šolski sklad, delo z učenci s posebnimi potrebami)','',2),(7,'Kakovost in natančnost','prispevek dela timu (šolski sklad, vzgojni načrt, delo z učenci s posebnimi potrebami)','',2),(8,'Kakovost in natančnost','delo pomočnika ravnatelja, tajnice, rač. v mesecih, ko je največ dela (urnik, publikacija)','',2),(9,'Kakovost in natančnost','vodenje oz. sodelovanje v projektih, humanitarnih akcijah, skrb za varovanje okolja','',2),(10,'Kakovost in natančnost','organizacija prireditev (dan odprtih vrat, valeta, sprejem prvošolcev, proslave, ...)','',2),(11,'Kakovost in natančnost','kakovostno in natančno delo tehničnih in administrativnih delavcev','',2),(12,'Odnos do dela in delovnih sredstev','uvajanje in uporaba nove učne tehnologije','',3),(13,'Odnos do dela in delovnih sredstev','urejanje šolske kronike, glasila, objave na spletni strani','',3),(14,'Odnos do dela in delovnih sredstev','dodatne obremenitve (računalnišla podpora, slikanje, snemanje, krasitev)','',3),(15,'Odnos do dela in delovnih sredstev','namestitev nove računalniške opreme, opremljanje','',3),(16,'Obseg in učinkovitost dela','delo v svetu šole, vodenje strokovnega tima (šolski sklad, vzgojni načrt, OPP, ...)','',4),(17,'Obseg in učinkovitost dela','sodelovanje (proslave, razstave, ustvarjalne delavnice)','',4),(18,'Obseg in učinkovitost dela','dodatno delo: sodelovanje z institucijami, ...','',4),(19,'Obseg in učinkovitost dela','organizacija tekmovanj, dejavnosti, šole v naravi, proslav, akcij, ...','',4),(20,'Obseg in učinkovitost dela','vodenje šolskih organizacij RK, šolski parlament, interesne dejavnosti','',4),(21,'Obseg in učinkovitost dela','večji obseg in učinkovitost dela tehničnih in administrativnih delavcev','',4),(22,'Obseg in učinkovitost dela','daljše nadomeščanje sodelavca, sprejemanje dela njegovih nalog, ...','',4),(23,'Inovativnost','učilo, tekst, članek, predstava, razstava','',5),(24,'Inovativnost','uvajanje in predstavitev novih metod dela','',5),(25,'Inovativnost','uvajanje boljše organizacije dela','',5),(26,'Inovativnost','lastna pobuda za spremembe, nova dogajanja in dejavnosti na šoli','',5),(27,'Znanje in strokovnost','znanja pridobljena z izobraževanjem, usposabljanjem in izkušnjami','\0',1),(28,'Znanje in strokovnost','celovitost znanj na celotnem področju dela','\0',1),(29,'Znanje in strokovnost','prenos znanja','\0',1),(30,'Odnos do dela in delovnih sredstev','odnos in odgovornost zaposlenega do dela in do delovnih sredstev','\0',2),(31,'Odnos do dela in delovnih sredstev','pripravljenost zaposlenega za sodelovanje in izvrševanje delovnih obveznosti','\0',2),(32,'Kakovost in natančnost','vestnost in natančnost pri delu','\0',3),(33,'Kakovost in natančnost','pogostost napak','\0',3),(34,'Kakovost in natančnost','kvaliteta dela in pogostost napak pri delu','\0',3),(35,'Obseg in učinkovitost dela','obseg dela, opravljenega pod normalnimi pogoji','\0',4),(36,'Obseg in učinkovitost dela','hitrost in učinkovitost dela','\0',4),(37,'Inovativnost','daje koristne predloge s katerimi se delovni proces bistveno izboljša','\0',5),(38,'Inovativnost','daje pobude za spremembe in izboljšave, ki so s strani uporabnikov pozitivno sprejete','\0',5),(39,'Inovativnost','razvijanje novih uporabnih idej','\0',5),(40,'Znanje in strokovnost','drugo …','',1),(41,'Kakovost in natančnost','drugo …','',2),(42,'Odnos do dela in delovnih sredstev','drugo …','',3),(43,'Obseg in učinkovitost dela','drugo …','',4),(44,'Inovativnost','drugo …','',5),(45,'Znanje in strokovnost','(tehnični kader) Mentorstvo pripravniku','',1),(46,'Znanje in strokovnost','(tehnični kader) Izboljšanje del procesa','',1),(47,'Kakovost in natančnost','(tehnični kader) Rezultati inšpekcijskih pregledov','',2),(48,'Kakovost in natančnost','(tehnični kader) Prispevek dela v skupini','',2),(49,'Kakovost in natančnost','(tehnični kader) Vodenje oz. sodelovanje v  projektih','',2),(50,'Kakovost in natančnost','(tehnični kader) Organizacija prireditev (dan odprtih vrat, valeta, sprejem prvošolcev, proslave, s….)','',2),(51,'Odnos do dela in delovnih sredstev','(tehnični kader) Uvajanje in uporaba nove tehnologije','',3),(52,'Odnos do dela in delovnih sredstev','(tehnični kader) Dodatne obremenitve','',3),(53,'Odnos do dela in delovnih sredstev','(tehnični kader) Zmanjšanje stroškov','',3),(54,'Obseg in učinkovitost dela','(tehnični kader) Delo nad svojo delovno obveznostjo- izredno','',4),(55,'Obseg in učinkovitost dela','(tehnični kader) Sodelovanje  pri izrednih nalogah','',4),(56,'Obseg in učinkovitost dela','(tehnični kader) Dodatno delo: sodelovanje z institucijami…','',4),(57,'Obseg in učinkovitost dela','(tehnični kader) Organizacij dejavnosti, akcij…','',4),(58,'Obseg in učinkovitost dela','(tehnični kader) Vodenje','',4),(59,'Obseg in učinkovitost dela','(tehnični kader) Večja učinkovitost dela tehničnih in administrativnih delavcev','',4),(60,'Obseg in učinkovitost dela','(tehnični kader) Daljše nadomeščanje sodelavca, sprejemanje dela njegovih nalog,..','',4),(61,'Inovativnost','(tehnični kader) Uvajanje in predstavitev novih metod dela','',5),(62,'Inovativnost','(tehnični kader) Uvajanje boljše organizacije dela','',5);

/*Table structure for table `tabkrozekclan` */

DROP TABLE IF EXISTS `tabkrozekclan`;

CREATE TABLE `tabkrozekclan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` int(10) DEFAULT NULL,
  `ucenec` int(10) DEFAULT NULL,
  `avtor` varchar(50) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkrozekclan` */

/*Table structure for table `tabkrozki` */

DROP TABLE IF EXISTS `tabkrozki`;

CREATE TABLE `tabkrozki` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` varchar(50) DEFAULT NULL,
  `mentor` varchar(50) DEFAULT NULL,
  `orderlevel` int(10) DEFAULT NULL,
  `porocilo` text,
  `planirano` double DEFAULT NULL,
  `realizirano` double DEFAULT NULL,
  `obisk` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabkrozki` */

/*Table structure for table `tablevel` */

DROP TABLE IF EXISTS `tablevel`;

CREATE TABLE `tablevel` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdLevel` int(10) DEFAULT NULL,
  `Level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdLevel` (`IdLevel`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tablevel` */

insert  into `tablevel`(`Id`,`IdLevel`,`Level`) values (1,0,'Običajen uporabnik'),(2,1,'Razrednik'),(3,2,'Ravnatelj'),(4,3,'Administrator');

/*Table structure for table `tabmalica` */

DROP TABLE IF EXISTS `tabmalica`;

CREATE TABLE `tabmalica` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `mesec` int(10) DEFAULT NULL,
  `dan` int(10) DEFAULT NULL,
  `malica` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabmalica` */

/*Table structure for table `tabnaborizb` */

DROP TABLE IF EXISTS `tabnaborizb`;

CREATE TABLE `tabnaborizb` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` smallint(6) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `r9` bit(1) DEFAULT NULL,
  `r8` bit(1) DEFAULT NULL,
  `r7` bit(1) DEFAULT NULL,
  `r6` bit(1) DEFAULT NULL,
  `r5` bit(1) DEFAULT NULL,
  `r4` bit(1) DEFAULT NULL,
  `r3` bit(1) DEFAULT NULL,
  `r2` bit(1) DEFAULT NULL,
  `r1` bit(1) DEFAULT NULL,
  `delitev` smallint(6) DEFAULT NULL,
  `ur` smallint(6) DEFAULT NULL,
  `nabor` bit(1) DEFAULT NULL,
  `izbran` bit(1) DEFAULT NULL,
  `idsola` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;

/*Data for the table `tabnaborizb` */

/*Table structure for table `tabnadarjeni` */

DROP TABLE IF EXISTS `tabnadarjeni`;

CREATE TABLE `tabnadarjeni` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  `komentar` text,
  `cas` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `evidst` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnadarjeni` */

/*Table structure for table `tabnadomescanja` */

DROP TABLE IF EXISTS `tabnadomescanja`;

CREATE TABLE `tabnadomescanja` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `datumNad` varchar(50) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `paralelka` varchar(50) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `ura` int(10) DEFAULT NULL,
  `ucitelj1` int(10) DEFAULT NULL,
  `prostor1` int(10) DEFAULT NULL,
  `ucitelj2` int(10) DEFAULT NULL,
  `prostor2` int(10) DEFAULT NULL,
  `oblika` int(10) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnadomescanja` */

/*Table structure for table `tabnadomoblika` */

DROP TABLE IF EXISTS `tabnadomoblika`;

CREATE TABLE `tabnadomoblika` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nadomescanje` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tabnadomoblika` */

insert  into `tabnadomoblika`(`id`,`nadomescanje`) values (1,'Nadomeščanje'),(2,'Združi'),(3,'Nadzoruje'),(4,'Odpade');

/*Table structure for table `tabnapredovanja` */

DROP TABLE IF EXISTS `tabnapredovanja`;

CREATE TABLE `tabnapredovanja` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `iducitelj` int(10) DEFAULT NULL,
  `rmax` int(10) DEFAULT NULL,
  `rakt` int(10) DEFAULT NULL,
  `rdelmosn` int(10) DEFAULT NULL,
  `napredovanj` int(10) DEFAULT NULL,
  `datznapred` varchar(20) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `napredod` varchar(20) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `napreddo` varchar(20) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `aneks` varchar(50) COLLATE utf8_slovenian_ci DEFAULT NULL,
  `delm` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;

/*Data for the table `tabnapredovanja` */

/*Table structure for table `tabnarocilnica` */

DROP TABLE IF EXISTS `tabnarocilnica`;

CREATE TABLE `tabnarocilnica` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `ZapSt` int(10) DEFAULT NULL,
  `Izdajatelj` varchar(250) DEFAULT NULL,
  `Davcna` varchar(50) DEFAULT NULL,
  `Zavezanec` bit(1) NOT NULL,
  `Kraj` varchar(50) DEFAULT NULL,
  `DatumIzd` varchar(50) DEFAULT NULL,
  `Dobavitelj` varchar(250) DEFAULT NULL,
  `Naslovnik` varchar(250) DEFAULT NULL,
  `Narocil` varchar(50) DEFAULT NULL,
  `VrstaBlaga` text,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` varchar(50) DEFAULT NULL,
  `znesek` double DEFAULT NULL,
  `InterniNarocnik` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnarocilnica` */

/*Table structure for table `tabnatecaj` */

DROP TABLE IF EXISTS `tabnatecaj`;

CREATE TABLE `tabnatecaj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` varchar(50) DEFAULT NULL,
  `mentor` varchar(50) DEFAULT NULL,
  `orderlevel` int(10) DEFAULT NULL,
  `porocilo` text,
  `planirano` double DEFAULT NULL,
  `realizirano` double DEFAULT NULL,
  `obisk` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnatecaj` */

/*Table structure for table `tabnatecajclan` */

DROP TABLE IF EXISTS `tabnatecajclan`;

CREATE TABLE `tabnatecajclan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` int(10) DEFAULT NULL,
  `ucenec` int(10) DEFAULT NULL,
  `avtor` varchar(50) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnatecajclan` */

/*Table structure for table `tabnivoji` */

DROP TABLE IF EXISTS `tabnivoji`;

CREATE TABLE `tabnivoji` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Ucenec` int(10) DEFAULT NULL,
  `Leto` int(10) DEFAULT NULL,
  `Nivoji` int(10) DEFAULT NULL,
  `Datum` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnivoji` */

/*Table structure for table `tabnivojskipredmeti` */

DROP TABLE IF EXISTS `tabnivojskipredmeti`;

CREATE TABLE `tabnivojskipredmeti` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Oznaka` varchar(8) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  `Prioriteta` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnivojskipredmeti` */

/*Table structure for table `tabnpz` */

DROP TABLE IF EXISTS `tabnpz`;

CREATE TABLE `tabnpz` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `miza` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `idTermin` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idTermin` (`idTermin`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpz` */

/*Table structure for table `tabnpz6` */

DROP TABLE IF EXISTS `tabnpz6`;

CREATE TABLE `tabnpz6` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `npz` bit(1) NOT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpz6` */

/*Table structure for table `tabnpzocene` */

DROP TABLE IF EXISTS `tabnpzocene`;

CREATE TABLE `tabnpzocene` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `idPredmet` int(10) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `odstotek` int(10) DEFAULT NULL,
  `tock` int(10) DEFAULT NULL,
  `moznihTock` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idPredmet` (`idPredmet`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpzocene` */

/*Table structure for table `tabnpzpredmeti` */

DROP TABLE IF EXISTS `tabnpzpredmeti`;

CREATE TABLE `tabnpzpredmeti` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idPredmet` int(10) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `prednost` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idPredmet` (`idPredmet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpzpredmeti` */

/*Table structure for table `tabnpztermini` */

DROP TABLE IF EXISTS `tabnpztermini`;

CREATE TABLE `tabnpztermini` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idPredmet` int(10) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `termin` int(10) DEFAULT NULL,
  `idProstor` int(10) DEFAULT NULL,
  `idUcitelj1` int(10) DEFAULT NULL,
  `idUcitelj2` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idPredmet` (`idPredmet`),
  KEY `idProstor` (`idProstor`),
  KEY `idUcitelj1` (`idUcitelj1`),
  KEY `idUcitelj2` (`idUcitelj2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpztermini` */

/*Table structure for table `tabnpzucitelji` */

DROP TABLE IF EXISTS `tabnpzucitelji`;

CREATE TABLE `tabnpzucitelji` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabnpzucitelji` */

/*Table structure for table `tabobrazci` */

DROP TABLE IF EXISTS `tabobrazci`;

CREATE TABLE `tabobrazci` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `Naslov` varchar(250) DEFAULT NULL,
  `tip` int(10) DEFAULT NULL,
  `Datum` varchar(50) DEFAULT NULL,
  `avtor` varchar(50) DEFAULT NULL,
  `vsebina` text,
  `datoteka` varchar(250) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `Arhiv` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabobrazci` */

/*Table structure for table `tabobvestila` */

DROP TABLE IF EXISTS `tabobvestila`;

CREATE TABLE `tabobvestila` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `datum` timestamp NULL DEFAULT NULL,
  `naslov` varchar(255) DEFAULT NULL,
  `vsebina` text,
  `rok` varchar(255) DEFAULT NULL,
  `objavil` int(10) DEFAULT NULL,
  `cas` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabobvestila` */

/*Table structure for table `tabocene` */

DROP TABLE IF EXISTS `tabocene`;

CREATE TABLE `tabocene` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `IdPredmet` int(10) DEFAULT NULL,
  `OcenaS1P` text,
  `OcenaS1U` text,
  `OcenaS2P` text,
  `OcenaS2U` text,
  `Neocenjen` int(10) DEFAULT NULL,
  `Popravni` int(10) DEFAULT NULL,
  `OcenaKoncna` varchar(255) DEFAULT NULL,
  `OcenaPolletna` varchar(255) DEFAULT NULL,
  `Datum` timestamp NULL DEFAULT NULL,
  `Vpisovalec` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdPredmet` (`IdPredmet`),
  KEY `IdUcenec` (`IdUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabocene` */

/*Table structure for table `tabodsotnost` */

DROP TABLE IF EXISTS `tabodsotnost`;

CREATE TABLE `tabodsotnost` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stdelavca` varchar(7) DEFAULT NULL,
  `odsotnoststart` timestamp NULL DEFAULT NULL,
  `odsotnostend` timestamp NULL DEFAULT NULL,
  `sifraodsotnosti` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabodsotnost` */

/*Table structure for table `tabodsotnostuc` */

DROP TABLE IF EXISTS `tabodsotnostuc`;

CREATE TABLE `tabodsotnostuc` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `ura` int(10) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `ucitelj` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `opomba` varchar(255) DEFAULT NULL,
  `idDnevnik` int(10) DEFAULT NULL,
  `vpisal` int(10) DEFAULT NULL,
  `casvp` varchar(255) DEFAULT NULL,
  `spremenil` int(10) DEFAULT NULL,
  `casspr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idDnevnik` (`idDnevnik`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabodsotnostuc` */

/*Table structure for table `tabopb` */

DROP TABLE IF EXISTS `tabopb`;

CREATE TABLE `tabopb` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `juv` bit(1) NOT NULL,
  `juvcas` varchar(50) DEFAULT NULL,
  `pb1` bit(1) NOT NULL,
  `pb2` bit(1) NOT NULL,
  `pb3` bit(1) NOT NULL,
  `pb4` bit(1) NOT NULL,
  `pb5` bit(1) NOT NULL,
  `pb6` bit(1) NOT NULL,
  `pb7` bit(1) NOT NULL,
  `pb8` bit(1) NOT NULL,
  `pb9` bit(1) NOT NULL,
  `pb10` bit(1) NOT NULL,
  `pb11` bit(1) NOT NULL,
  `pb12` bit(1) NOT NULL,
  `pb13` bit(1) NOT NULL,
  `pb14` bit(1) NOT NULL,
  `pb15` bit(1) NOT NULL,
  `pbcas` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `idsola` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB AUTO_INCREMENT=2294 DEFAULT CHARSET=utf8;

/*Data for the table `tabopb` */

/*Table structure for table `tabopbucitelji` */

DROP TABLE IF EXISTS `tabopbucitelji`;

CREATE TABLE `tabopbucitelji` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `idPredmet` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idPredmet` (`idPredmet`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabopbucitelji` */

/*Table structure for table `tabopcilji` */

DROP TABLE IF EXISTS `tabopcilji`;

CREATE TABLE `tabopcilji` (
  `IdCilji` int(10) NOT NULL AUTO_INCREMENT,
  `Razred` int(10) DEFAULT NULL,
  `OpisCilja` varchar(250) DEFAULT NULL,
  `Predmet` int(10) DEFAULT NULL,
  PRIMARY KEY (`IdCilji`),
  KEY `IdCilji` (`IdCilji`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

/*Data for the table `tabopcilji` */

insert  into `tabopcilji`(`IdCilji`,`Razred`,`OpisCilja`,`Predmet`) values (1,1,'Govorno sporočanje',16),(2,1,'Pisno sporočanje',16),(3,1,'Spričevalo',16),(4,1,'Osnovni pojmi iz geometrije in merjenj',11),(5,1,'Aritmetika in algebra',11),(6,1,'Logika in jezik',11),(7,1,'Obdelava podatkov',11),(8,1,'Spričevalo',11),(9,1,'Likovni pojmi',9),(10,1,'Likovno izražanje',9),(11,1,'Doživljajske naravnanosti',9),(12,1,'Spričevalo',9),(13,1,'Glasbeno izvajanje',29),(14,1,'Glasbeno ustvarjanje',29),(15,1,'Poslušanje glasbe',29),(16,1,'Povezava glasbenih dejavnosti',29),(17,1,'Spričevalo',29),(18,1,'Kdo sem',49),(19,1,'Jaz in ti, mi in vi',49),(20,1,'Jaz in moja šola',49),(21,1,'Praznujemo',49),(22,1,'Bilo je nekoč',49),(23,1,'Jaz in narava',49),(24,1,'Jaz in zdravje',49),(25,1,'Pogledam naokrog',49),(26,1,'Kaj zmorem narediti',49),(27,1,'Spričevalo',49),(28,1,'Športna znanja',20),(29,1,'Spričevalo',20),(30,2,'Govorno sporočanje',16),(31,2,'Pisno sporočanje',16),(32,2,'Spričevalo',16),(33,2,'Osnovni pojmi iz geometrije in merjenj',11),(34,2,'Logika in jezik',11),(35,2,'Obdelava podatkov',11),(36,2,'Naravna števila in število nič',11),(37,2,'Spričevalo',11),(38,2,'Likovni pojmi',9),(39,2,'Likovno izražanje',9),(40,2,'Doživljajske naravnanosti',9),(41,2,'Spričevalo',9),(42,2,'Glasbeno izvajanje',29),(43,2,'Glasbeno ustvarjanje',29),(44,2,'Poslušanje glasbe',29),(45,2,'Povezava glasbenih dejavnosti',29),(46,2,'Spričevalo',29),(47,2,'Jaz in ti, mi in vi',49),(48,2,'Jaz in moja šola',49),(49,2,'Praznujemo',49),(50,2,'Bilo je nekoč',49),(51,2,'Jaz in narava',49),(52,2,'Jaz in zdravje',49),(53,2,'Pogledam naokrog',49),(54,2,'Kaj zmorem narediti',49),(55,2,'Kdo smo in kako živimo',49),(56,2,'Spričevalo',49),(57,2,'Športna znanja',20),(58,2,'Spričevalo',20),(59,3,'Govorno sporočanje',16),(60,3,'Pisno sporočanje',16),(61,3,'Spričevalo',16),(62,3,'Osnovni pojmi iz geometrije in merjenj',11),(63,3,'Aritmetika in algebra',11),(64,3,'Obdelava podatkov',11),(65,3,'Druge vsebine',11),(66,3,'Spričevalo',11),(67,3,'Likovni pojmi',9),(68,3,'Likovno izražanje',9),(69,3,'Doživljajske naravnanosti',9),(70,3,'Spričevalo',9),(71,3,'Glasbeno izvajanje',29),(72,3,'Glasbeno ustvarjanje',29),(73,3,'Povezava glasbenih dejavnosti',29),(74,3,'Glasbeno poslušanje',29),(75,3,'Spričevalo',29),(76,3,'Jaz in ti, mi in vi',49),(77,3,'Praznujemo',49),(78,3,'Bilo je nekoč',49),(79,3,'Jaz in narava',49),(80,3,'Jaz in zdravje',49),(81,3,'Pogledam naokrog',49),(82,3,'Kaj zmorem narediti',49),(83,3,'Kdo smo in kaj delamo',49),(84,3,'Kje živimo',49),(85,3,'Spričevalo',49),(86,3,'Športna znanja',20),(87,3,'Spričevalo',20);

/*Table structure for table `tabopciljin` */

DROP TABLE IF EXISTS `tabopciljin`;

CREATE TABLE `tabopciljin` (
  `IdCilji` int(10) NOT NULL AUTO_INCREMENT,
  `Razred` int(10) DEFAULT NULL,
  `OpisCilja` varchar(250) DEFAULT NULL,
  `Predmet` int(10) DEFAULT NULL,
  PRIMARY KEY (`IdCilji`),
  KEY `IdCilji` (`IdCilji`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

/*Data for the table `tabopciljin` */

insert  into `tabopciljin`(`IdCilji`,`Razred`,`OpisCilja`,`Predmet`) values (1,1,'Govorno sporočanje',16),(2,1,'Pisno sporočanje',16),(3,1,'Spričevalo',16),(4,1,'Osnovni pojmi iz geometrije in merjenj',11),(5,1,'Aritmetika in algebra',11),(6,1,'Logika in jezik',11),(7,1,'Obdelava podatkov',11),(8,1,'Spričevalo',11),(9,1,'Likovni pojmi',9),(10,1,'Likovno izražanje',9),(11,1,'Doživljajske naravnanosti',9),(12,1,'Spričevalo',9),(13,1,'Glasbeno izvajanje',29),(14,1,'Glasbeno ustvarjanje',29),(15,1,'Poslušanje glasbe',29),(16,1,'Povezava glasbenih dejavnosti',29),(17,1,'Spričevalo',29),(18,1,'Kdo sem',49),(19,1,'Jaz in ti, mi in vi',49),(20,1,'Jaz in moja šola',49),(21,1,'Praznujemo',49),(22,1,'Bilo je nekoč',49),(23,1,'Jaz in narava',49),(24,1,'Jaz in zdravje',49),(25,1,'Pogledam naokrog',49),(26,1,'Kaj zmorem narediti',49),(27,1,'Spričevalo',49),(28,1,'Športna znanja',20),(29,1,'Spričevalo',20),(30,2,'Govorno sporočanje',16),(31,2,'Pisno sporočanje',16),(32,2,'Spričevalo',16),(33,2,'Osnovni pojmi iz geometrije in merjenj',11),(34,2,'Logika in jezik',11),(35,2,'Obdelava podatkov',11),(36,2,'Naravna števila in število nič',11),(37,2,'Spričevalo',11),(38,2,'Likovni pojmi',9),(39,2,'Likovno izražanje',9),(40,2,'Doživljajske naravnanosti',9),(41,2,'Spričevalo',9),(42,2,'Glasbeno izvajanje',29),(43,2,'Glasbeno ustvarjanje',29),(44,2,'Poslušanje glasbe',29),(45,2,'Povezava glasbenih dejavnosti',29),(46,2,'Spričevalo',29),(47,2,'Jaz in ti, mi in vi',49),(48,2,'Jaz in moja šola',49),(49,2,'Praznujemo',49),(50,2,'Bilo je nekoč',49),(51,2,'Jaz in narava',49),(52,2,'Jaz in zdravje',49),(53,2,'Pogledam naokrog',49),(54,2,'Kaj zmorem narediti',49),(55,2,'Kdo smo in kako živimo',49),(56,2,'Spričevalo',49),(57,2,'Športna znanja',20),(58,2,'Spričevalo',20);

/*Table structure for table `tabopocene` */

DROP TABLE IF EXISTS `tabopocene`;

CREATE TABLE `tabopocene` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `OpOcena` int(10) DEFAULT NULL,
  `Tip` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdUcenec` (`IdUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabopocene` */

/*Table structure for table `tabopocenen` */

DROP TABLE IF EXISTS `tabopocenen`;

CREATE TABLE `tabopocenen` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `OpOcena` int(10) DEFAULT NULL,
  `Tip` int(10) DEFAULT NULL,
  `Ocena` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdUcenec` (`IdUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabopocenen` */

/*Table structure for table `tabopocucenec` */

DROP TABLE IF EXISTS `tabopocucenec`;

CREATE TABLE `tabopocucenec` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ucenec` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `slo` text,
  `mat` text,
  `spo` text,
  `lvz` text,
  `gvz` text,
  `svz` text,
  `nar` text,
  `dru` text,
  `tit` text,
  `gos` text,
  `rez` text,
  `vpisal` varchar(50) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabopocucenec` */

/*Table structure for table `tabopombeuc` */

DROP TABLE IF EXISTS `tabopombeuc`;

CREATE TABLE `tabopombeuc` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `datum` timestamp NULL DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `ura` int(10) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `ucitelj` varchar(255) DEFAULT NULL,
  `opomba` text,
  `idDnevnik` int(10) DEFAULT NULL,
  `vpisal` int(10) DEFAULT NULL,
  `casvp` varchar(255) DEFAULT NULL,
  `spremenil` int(10) DEFAULT NULL,
  `casspr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idDnevnik` (`idDnevnik`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabopombeuc` */

/*Table structure for table `tabopomini` */

DROP TABLE IF EXISTS `tabopomini`;

CREATE TABLE `tabopomini` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdUkrep` int(10) DEFAULT NULL,
  `Opis` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `TabOpominiIdUkrep` (`IdUkrep`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

/*Data for the table `tabopomini` */

insert  into `tabopomini`(`Id`,`IdUkrep`,`Opis`) values (1,1,'1. vzgojni opomin'),(2,2,'2. vzgojni opomin'),(3,3,'3. vzgojni opomin'),(4,4,'4. vzgojni opomin'),(5,5,'5. vzgojni opomin'),(6,6,'6. vzgojni opomin'),(7,7,'Pohvala - Bronasto Vegovo priznanje'),(8,8,'Pohvala - Srebrno Vegovo priznanje'),(9,9,'Pohvala - Zlato Vegovo priznanje'),(10,10,'Pohvala - Bronasto Cankarjevo priznanje'),(11,11,'Pohvala - Srebrno Cankarjevo priznanje'),(12,12,'Pohvala - Zlato Cankarjevo priznanje'),(13,13,'Pohvala - Bronasto priznanje iz zgodovine'),(14,14,'Pohvala - Srebrno priznanje iz zgodovine'),(15,15,'Pohvala - Zlato priznanje iz zgodovine'),(16,16,'Pohvala - Bronasto Preglovo priznanje'),(17,17,'Pohvala - Srebrno Preglovo priznanje'),(18,18,'Pohvala - Zlato Preglovo priznanje'),(19,19,'Pohvala - Bronasto Stefanovo priznanje'),(20,20,'Pohvala - Srebrno Stefanovo priznanje'),(21,21,'Pohvala - Zlato Stefanovo priznanje'),(22,22,'Pohvala - Bronasto priznanje iz logike'),(23,23,'Pohvala - Srebrno priznanje iz logike'),(24,24,'Pohvala - Zlato priznanje iz logike'),(25,25,'Pohvala - Bronasto priznanje iz znanja o sladkorni bolezni'),(26,26,'Pohvala - Srebrno priznanje iz znanja o sladkorni bolezni'),(27,27,'Pohvala - Zlato priznanje iz znanja o sladkorni bolezni'),(28,28,'Pohvala - Bronasto priznanje iz angleščine'),(29,29,'Pohvala - Srebrno priznanje iz angleščine'),(30,30,'Pohvala - Zlato priznanje iz angleščine'),(31,31,'Pohvala - Bronasto priznanje iz nemščine'),(32,32,'Pohvala - Srebrno priznanje iz nemščine'),(33,33,'Pohvala - Zlato priznanje iz nemščine'),(34,34,'Pohvala - Bronasto priznanje iz francoščine'),(35,35,'Pohvala - Srebrno priznanje iz francoščine'),(36,36,'Pohvala - Zlato priznanje iz francoščine'),(37,37,'Pohvala - Bronasto priznanje iz španščine'),(38,38,'Pohvala - Srebrno priznanje iz španščine'),(39,39,'Pohvala - Zlato priznanje iz španščine'),(40,40,'Pohvala - Bronasto Proteusovo priznanje'),(41,41,'Pohvala - Srebrno Proteusovo priznanje'),(42,42,'Pohvala - Zlato Proteusovo priznanje'),(43,43,'Pohvala - Bronasto priznanje iz geografije'),(44,44,'Pohvala - Srebrno priznanje iz geografije'),(45,45,'Pohvala - Zlato priznanje iz geografije'),(46,0,'Ni pohval in opominov');

/*Table structure for table `taboprema` */

DROP TABLE IF EXISTS `taboprema`;

CREATE TABLE `taboprema` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `prostor` varchar(50) DEFAULT NULL,
  `oznaka` varchar(50) DEFAULT NULL,
  `nosilec` varchar(50) DEFAULT NULL,
  `racunalnik` varchar(50) DEFAULT NULL,
  `tiskalnik` varchar(250) DEFAULT NULL,
  `projektor` varchar(50) DEFAULT NULL,
  `dodatno` varchar(250) DEFAULT NULL,
  `komentar` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `taboprema` */

/*Table structure for table `tabopznanje` */

DROP TABLE IF EXISTS `tabopznanje`;

CREATE TABLE `tabopznanje` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `IdZnanje` int(10) DEFAULT NULL,
  `IdCilji` int(10) DEFAULT NULL,
  `TipZnanja` int(10) DEFAULT NULL,
  `OpisZnanja` text,
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `IdZnanje` (`IdZnanje`),
  KEY `IdCilji` (`IdCilji`)
) ENGINE=InnoDB AUTO_INCREMENT=2588 DEFAULT CHARSET=utf8;

/*Data for the table `tabopznanje` */

insert  into `tabopznanje`(`ID`,`IdZnanje`,`IdCilji`,`TipZnanja`,`OpisZnanja`) values (1,1,1,0,'Preprosta sporočila izrazi z nebesednimi znamenji; iz nebesednih znamenj prepozna sporočilo in ga izrazi z besedami.'),(2,2,1,0,'Preprosta sporočila ob pomoči izrazi z nebesednimi znamenji; iz nebesednih znamenj s pomočjo prepozna sporočilo in ga izrazi z besedami.Preprosta sporočila še ne izrazi z nebesednimi znamenji; iz nebesednih znamenj s pomočjo prepozna sporočilo in ga izrazi z besedami.'),(3,3,1,0,'Preprosta sporočila še ne izrazi z nebesednimi znamenji; iz nebesednih znamenj s pomočjo prepozna sporočilo in ga izrazi z besedami.'),(4,4,1,0,'smiselno sodeluje v pogovoru z učiteljem in drugimi sogovorci; pri tem ustrezno uporablja spoštljive ogovore oseb, jih tika ali vika; uporablja vljudne izraze za izrekanje prošnje, zahvale, opravičila, voščila in priznanja;'),(5,5,1,0,'Smiselno sodeluje v pogovoru z učiteljem in drugimi sogovorci; pri tem ustrezno uporablja spoštljive ogovore oseb, jih tika ali vika.'),(6,6,1,0,'Smiselno sodeluje v pogovoru z učiteljem in drugimi sogovorci; pri tem občasno uporablja spoštljive ogovore oseb, jih tika ali vika.'),(7,7,1,0,'Smiselno sodeluje v pogovoru z učiteljem in drugimi sogovorci; pri tem še ne uporablja spoštljive ogovore oseb, jih tika ali vika.'),(8,8,1,0,'po poslušanju odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga utemeljuje; govori o svojih izkušnjah in občutkih ob besedilu; dopolni besedilo; ob ponovnem poslušanju spremenjenega besedila odpravi napake;'),(9,9,1,0,'Po poslušanju odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga utemeljuje; govori o svojih izkušnjah in občutkih ob besedilu.'),(10,10,1,0,'Po poslušanju ob spodbudi odgovarja na učiteljeva vprašanja, občasno pove svoje mnenje o besedilu ; govori o svojih izkušnjah in občutkih ob besedilu.'),(11,11,1,0,'Po poslušanju z besedo odgovarja na učiteljeva vprašanja, še ne pove svojega mnenja o besedilu in redko govori o svojih občutkih ob besedilu.'),(12,12,1,0,'govorno nastopa z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih ali samostojno opisuje sebe, žival ali predmet ter dogodek; govori čim bolj zborno, razločno, naravno;'),(13,13,1,0,'Govorno nastopa z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih opisuje sebe, žival, predmet ter dogodek.'),(14,14,1,0,'Govorno nastopa z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih opisuje sebe, žival, predmet ter dogodek.'),(15,15,1,0,'Govorno nastopa z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih skromno opisuje sebe, žival, predmet ter dogodek.'),(16,16,1,0,'po poslušanju učiteljevega pripovedovanja besedila, radijske igre ali ogledu lutkovne/gledališke predstave izraža svoje razumevanje umetnostnega besedila; govorno povzame vsebino besedila;'),(17,17,1,0,'po poslušanju učiteljevega pripovedovanja besedila, radijske igre ali ogledu lutkovne/gledališke predstave izraža svoje razumevanje umetnostnega besedila; govorno povzame vsebino besedila;'),(18,18,1,0,'Po poslušanju učiteljevega pripovedovanja besedila ali ogledu lutkovne predstave ob pomoči izraža svoje razumevanje besedila.'),(19,19,1,0,'Po poslušanju učiteljevega pripovedovanja besedila ali ogledu lutkovne predstave še ne izraža svojega razumevanje besedila.'),(20,20,1,0,'poistoveti se s književno osebo, pove, kako si predstavlja književno osebo in prostor ter primerja svoje predstave s predstavami sošolcev;'),(21,21,1,0,'Poistoveti se s književno osebo, pove, kako si predstavlja književno osebo in prostor ter primerja svoje predstave s predstavami sošolcev.'),(22,22,1,0,'Poistoveti se s književno osebo, občasno pove, kako si predstavlja književno osebo in prostor.'),(23,23,1,0,'Poistoveti se s književno osebo, z učiteljevo pomočjo pove, kako si predstavlja književno osebo in prostor.'),(24,24,1,0,'sodeluje v skupinski dramatizaciji besedila, izdeluje lutke;'),(25,25,1,0,'Sodeluje v skupinski dramatizaciji besedila, izdeluje lutke.'),(26,26,1,0,'Ob spodbudi sodeluje v skupinski dramatizaciji besedila, izdeluje lutke.'),(27,27,1,0,'Redko sodeluje v skupinski dramatizaciji besedila, ob pomoči izdeluje lutke.'),(28,28,1,0,'pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic;'),(29,29,1,0,'Samostojno pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(30,30,1,0,'Ob dodatni spodbudi pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(31,31,1,0,'S pomočjo učitelja pripoveduje znane pravljice in si izmišlja svoje.'),(32,32,1,0,'drugače govori o stvarnosti kot o domišljijskih svetovih ter tvori svoje domišljijske svetove;'),(33,33,1,0,'Drugače govori o stvarnosti kot o domišljijskih svetovih ter tvori svoje domišljijske svetove;'),(34,34,1,0,'Enako govori o stvarnosti kot o domišljijskih svetovih .'),(35,35,1,0,'poimenuje bitja/predmete na sliki; besedam najde protipomenke, tvori manjšalnice in ljubkovalnice, si izmišlja nove besede;'),(36,36,1,0,'Poimenuje bitja/predmete na sliki; besedam najde protipomenke, tvori manjšalnice in ljubkovalnice, si izmišlja nove besede.'),(37,37,1,0,'S pomočjo poimenuje bitja/predmete na sliki; tvori manjšalnice in ljubkovalnice, si izmišlja nove besede.'),(38,38,1,0,'Samostojno še ne poimenuje bitja in predmete na sliki; ob pomoči  tvori manjšalnice in ljubkovalnice, si izmišlja nove besede.'),(39,39,1,0,'sestavlja ritmična besedila, išče besede, ki se rimajo, memorira in deklamira pesmi s polnimi rimami, niza asociacije ob tematski besedi;'),(40,40,1,0,'Samostojno sestavlja ritmična besedila, išče besede, ki se rimajo, memorira in deklamira pesmi s polnimi rimami, niza asociacije ob tematski besedi.'),(41,41,1,0,'S pomočjo sestavlja ritmična besedila, išče besede, ki se rimajo, memorira in deklamira pesmi s polnimi rimami.'),(42,42,1,0,'Še ne sestavlja ritmičnih besedil, s pomočjo išče besede, ki se rimajo, memorira  pesmi s polnimi rimami.'),(43,43,1,0,'določi število bitij/predmetov/likov in njihov vrstni red; primerja njihove lastnosti, ugotavlja njihov položaj, opazuje njihovo gibanje;'),(44,44,1,0,'Samostojno določi število bitij/predmetov/likov in njihov vrstni red; primerja njihove lastnosti, ugotavlja njihov položaj, opazuje njihovo gibanje.'),(45,45,1,0,'S pomočjo določi število bitij/predmetov/likov in njihov vrstni red; primerja njihove lastnosti, ugotavlja njihov položaj, opazuje njihovo gibanje.'),(46,46,1,0,'S pomočjo določi število bitij/predmetov/likov in njihov vrstni red; primerja njihove lastnosti.'),(47,47,1,0,'pravilno uporablja časovno prislove (zdaj, prej, potem, včeraj, danes, jutri) in glagolske časovno oblike (sedanjik, preteklik, prihodnjik) ter določa zaporedje dejanj;'),(48,48,1,0,'Pravilno uporablja časovno prislove (zdaj, prej, potem, včeraj, danes, jutri) in glagolske časovne oblike (sedanjik, preteklik, prihodnjik) .'),(49,49,1,0,'Ob pomoči pravilno uporablja časovno prislove (zdaj, prej, potem, včeraj, danes, jutri) in glagolske časovno oblike (sedanjik, preteklik, prihodnjik).'),(50,50,1,0,'Nepravilno uporablja časovno prislove (zdaj, prej, potem, včeraj, danes, jutri) in glagolske časovno oblike (sedanjik, preteklik, prihodnjik).'),(51,51,1,0,'v izgovorjenih besedah prepozna število zlogov ter začetni zlog in glas.'),(52,52,1,0,'V izgovorjenih besedah samostojno prepozna število zlogov ter začetni zlog in glas.'),(53,53,1,0,'V izgovorjenih besedah s pomočjo prepozna število zlogov ter začetni zlog in glas.'),(54,54,1,0,'V izgovorjenih besedah še ne prepozna števila zlogov ter začetni zlog in glas.'),(55,55,2,0,'v knjigi in časopisu/reviji loči slikovni in črkovni del;'),(56,56,2,0,'V knjigi in časopisu/reviji loči slikovni in črkovni del.'),(57,57,2,0,'V knjigi in časopisu/reviji ne loči slikovni in črkovni del.'),(58,58,2,0,'ob slikah/ilustracijah sledi besedilu, ki ga posluša;'),(59,59,2,0,'Ob slikah/ilustracijah samostojno sledi besedilu, ki ga posluša.'),(60,60,2,0,'Ob slikah/ilustracijah občasno sledi besedilu, ki ga posluša,'),(61,61,2,0,'Ob slikah/ilustracijah z učiteljevo pomočjo sledi besedilu, ki ga posluša.'),(62,62,2,0,'ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora;'),(63,63,2,0,'Izvirno ilustrira besedilo, izrazi svojo domišjijskočutno predstavo dogajalnega prostora.'),(64,64,2,0,'Ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora.'),(65,65,2,0,'Ob spodbudi ilustrira besedilo in izrazi svojo domišljijskočutno predstavo dogajalnega prostora.'),(66,66,2,0,'prikaže književno dogajanje s sličicami;'),(67,67,2,0,'Izvirno prikaže književno dogajanje s sličicami.'),(68,68,2,0,'Občasno prikaže književno dogajanje s sličicami.'),(69,69,2,0,'Z učiteljevo pomočjo prikaže književno dogajanje s sličicami.'),(70,70,2,0,'glasno \"bere\" slike/ilustracije; \"bere\" pravljico ob nizu slik;'),(71,71,2,0,'Samostojno in pravilno glasno \"bere\" slike/ilustracije; \"bere\" pravljico ob nizu slik.'),(72,72,2,0,'Ob dodatni spodbudi glasno \"bere\" slike/ilustracije; \"bere\" pravljico ob nizu slik.'),(73,73,2,0,'Z učiteljevo pomočjo glasno \"bere\" slike/ilustracije; \"bere\" pravljico ob nizu slik.'),(74,74,2,0,'bere naslikane in tiskane zapovedi, prepovedi, opozorila in obvestila iz svojega okolja; pove, kaj sporoča piktogram/napis, kako je treba ob njem ravnati; pripoveduje o svojih izkušnjah in doživetjih ob podobnih piktogramih/napisih;'),(75,75,2,0,'Pravilno bere naslikane in tiskane zapovedi, opozorila in obvestila iz svojega okolja; pove, kaj sporoča in kako je treba ob njem ravnati.    '),(76,76,2,0,'S pomočjo bere naslikane in tiskane zapovedi, opozorila in obvestila iz svojega okolja; pove, kaj sporoča in kako je treba ob njem ravnati.'),(77,77,2,0,'S pomočjo pravilno bere naslikane in tiskane zapovedi, opozorila in obvestila iz svojega okolja.'),(78,78,2,0,'napiše svojo pravljico z nizanjem sličic;'),(79,79,2,0,'Samostojno napiše svojo pravljico z nizanjem sličic.'),(80,80,2,0,'Z učiteljevo pomočjo napiše svojo pravljico z nizanjem sličic.'),(81,81,2,0,'Še ne napiše svoje pravljice z nizanjem sličic.'),(82,82,2,0,'učitelju narekuje pravljico, ki jo dobro pozna oz. zna na pamet;'),(83,83,2,0,'Učitelju narekuje pravljico, ki jo dobro pozna oz. zna na pamet.'),(84,84,2,0,'Učitelju ne zna narekovati pravljice, ki jo dobro pozna .'),(85,85,2,0,'učitelju narekuje zapovedi, prepovedi, opozorila in obvestila iz svojega okolja oz. jih \"napiše\" sam;'),(86,86,2,0,'Učitelju samostojno narekuje zapovedi, prepovedi, opozorila in obvestila iz svojega okolja oz. jih napiše sam.'),(87,87,2,0,'Učitelju s pomočjo narekuje zapovedi, prepovedi, opozorila in obvestila iz svojega okolja oz. jih napiše sam.'),(88,88,2,0,'Učitelju s pomočjo narekuje zapovedi, prepovedi, opozorila in obvestila iz svojega okolja.'),(89,89,2,0,'obvlada pravilno držo telesa ter pravilno uporabo raznih pisal;'),(90,90,2,0,'Obvlada pravilno držo telesa ter pravilno uporabo raznih pisal.'),(91,91,2,0,'Še ne obvlada pravilne drže telesa ter pravilne uporabe raznih pisal.'),(92,92,2,0,'orientira se na svojem telesu, v prostoru in na papirju ter obvlada smer pisanja od leve proti desni in od zgoraj navzdol;'),(93,93,2,0,'Orientira se na svojem telesu, v prostoru in na papirju ter obvlada smer pisanja od leve proti desni in od zgoraj navzdol.'),(94,94,2,0,'Orientira se na svojem telesu, v prostoru in na papirju ter obvlada smer pisanja od leve proti desni.'),(95,95,2,0,'Orientira se na svojem telesu, v prostoru in na papirju ter še ne  obvlada smeri pisanja od leve proti desni.'),(96,96,2,0,'obvlada poteze, potrebne za pisanje črk in številk;'),(97,97,2,0,'Obvlada poteze, potrebne za pisanje črk in številk.'),(98,98,2,0,'Obvlada del potez, potrebnih za pisanje črk in številk.'),(99,99,2,0,'Ne obvlada potez, potrebnih za pisanje črk in številk.'),(100,100,2,0,'razvršča predmete/like (po enakosti ali podobnosti);'),(101,101,2,0,'Samostojno in pravilno razvršča predmete/like (po enakosti ali podobnosti).'),(102,102,2,0,'Ob dodatni spodbudi razvršča predmete/like (po enakosti ali podobnosti).'),(103,103,2,0,'Z učiteljevo pomočjo razvršča predmete/like (po enakosti ali podobnosti).'),(104,104,2,0,'v zapisani besedi ali v besednih dvojicah prepozna enake črke;'),(105,105,2,0,'V zapisani besedi ali v besednih dvojicah prepozna enake črke.'),(106,106,2,0,'V zapisani besedi ali v besednih dvojicah občasno prepozna enake črke.'),(107,107,2,0,'V zapisani besedi ali v besednih dvojicah ne prepozna enakih črk.'),(108,108,2,0,'preslikava preproste besede in črke; črke poveže z ustreznimi glasovi.'),(109,109,2,0,'Pravilno preslikava preproste besede in črke; črke poveže z ustreznimi glasovi.'),(110,110,2,0,'Z manjšimi napakami preslikava preproste besede in črke; črke poveže z ustreznimi glasovi.'),(111,111,2,0,'Z napakami preslikava preproste besede in črke.'),(112,112,3,1,'smiselno sodeluje v pogovoru, obvlada temeljna načela vljudnega pogovarjanja,'),(113,113,3,1,'Smiselno se vključuje in sodeluje v pogovoru. Ustrezno uporablja vljudnostne izraze.'),(114,114,3,1,'Vključuje se v razgovor, občasno ob spodbudi. Upošteva načela vljudnostnega pogovarjanja.'),(115,115,3,1,'Ob pomoči se vključi v pogovor in smiselno sodeluje. Upošteva načela vljudnosti.'),(116,116,3,1,'Smiselno se vključuje in sodeluje v pogovoru. Ustrezno uporablja vljudnostne izraze.'),(117,117,3,1,'razume govorjeno umetnostno in neumetnostno besedilo,'),(118,118,3,1,'Razume daljše umetnostno /neumetnostno  besedilo, ga obnovi in vsebino prikaže na različne načine.'),(119,119,3,1,'Po ponovnem poslušanju razume daljše umetnostno /neumetnostno besedilo in ga obnovi besedno ali slikovno.'),(120,120,3,1,'Razume krajše umetnostno /neumetnostno besedilo. Ob pomoči ga obnovi.'),(121,121,3,1,'Razume daljše umetnostno /neumetnostno  besedilo, ga obnovi in vsebino prikaže na različne načine.'),(122,122,3,1,'loči umetnostno besedilo od neumetnostnega,'),(123,123,3,1,'Po značilnostih posamezne zvrsti  loči umetnostno od neumetnostnega besedila. Poskuša ustvariti umetnostno /neumetnostno besedilo.'),(124,124,3,1,'Prepozna lastnosti umetnostnega /neumetnostnega besedila in jih glede na značilnosti razvrsti.'),(125,125,3,1,'Ne loči umetnostnega besedila od neumetnostnega.'),(126,126,3,1,'prepozna lastnosti književne osebe, se vanjo vživi in jo zaigra,'),(127,127,3,1,'Prepozna lastnosti književne osebe, se vanjo vživi in jo zaigra.'),(128,128,3,1,'Lastnosti književne osebe prepoznava. Ob spodbudi se identificira s književno  osebo.'),(129,129,3,1,'Prepozna književne osebe, ki so mu bližje. Ob spodbudi se poskuša vživeti v književno osebo.'),(130,130,3,1,'obnovi vsebino pravljice, pozna njene značilnosti, nariše svoje predstave besedilne stvarnosti,'),(131,131,3,1,'Samostojno obnovi vsebino znane, tudi nove pravljice. Pozna njene značilnosti ter nariše dogajanja v pravilnem zaporedju.'),(132,132,3,1,'Prepozna značilnosti pravljice. Obnovi pravljico ob slikah. Nariše svoje predstave.'),(133,133,3,1,'Ob slikah, s pomočjo vodenih vprašanj, obnovo vsebino pravljice. Nariše svoje predstave.'),(134,134,3,1,'zaznava zvočnost pesmi in niza asociacije ob tematski besedi,'),(135,135,3,1,'Tvori zvočne nize. Posnema in ustvarja različne vzorce. Ustvari pesem.'),(136,136,3,1,'Zazna zvočnost pesmi. Tvori rime. Ob pomoči ustvari pesem.'),(137,137,3,1,'Ob spodbudi zazna zvočnost pesmi. Tvori preproste rime. Sporočila pesmi ne razume.'),(138,138,3,1,'razume slušna in vidna nebesedna sporočila,'),(139,139,3,1,'Razume različne oblike nebesednih sporočil. Samostojno oblikuje in predstavi obliko nebesednega sporočila.'),(140,140,3,1,'Razume in predstavi nebesedno sporočilo.'),(141,141,3,1,'Navaja se na razumevanje nebesednega sporočila.'),(142,142,3,1,'govorno nastopi z vnaprej pripravljeno temo,'),(143,143,3,1,'Govorno nastopi v pogovorno-knjižnem je. Pripoved je izvirna in v smiselnem zaporedju. Govor je tekoč in podkrepljen z doživeto neverbalno komunikacijo.'),(144,144,3,1,'Pripoveduje v smiselnem zaporedju Izraža se v kratkih povedih. Uporablja neverbalno komunikacijo.'),(145,145,3,1,'Temo, ki mu je blizu, predstavi; občasno potrebuje pomoč učitelja. Izraža se v kratkih povedih. Neverbalno komunikacijo redko uporablja.'),(146,146,3,1,'prepozna okoliščine za rabo knjižnega in neknjižnega jezika,'),(147,147,3,1,'Glede na govorni položaj uporabi ustrezno zvrst jezika.'),(148,148,3,1,'Ob opozorilu uporabi ustrezno zvrst jezika.'),(149,149,3,1,'Izraža se samo v jeziku domačega okolja.'),(150,150,3,1,'ima razvite osnovne predpisalne spretnosti.'),(151,151,3,1,'Spretno izvaja poteze za pisanje črk, pri pisanju je zelo natančen.'),(152,152,3,1,'Izvaja poteze za pisanje črk, pri zapisu je natančen.'),(153,153,3,1,'Izvaja poteze za pisanje črk, zapise pogosto črta in popravlja.'),(154,154,3,1,'Spretno izvaja poteze za pisanje črk, pri pisanju je zelo natančen.'),(155,155,30,0,'smiselno sodeluje v pogovoru z raznimi sogovorci; pri tem upošteva načelo ustreznosti (vljudnosti); prepozna nevljudne izraze in jih zamenja z vljudnejšimi,'),(156,156,30,0,'Smiselno sodeluje v pogovoru z raznimi sogovorci; pri tem upošteva načelo ustreznosti (vljudnosti); prepozna nevljudne izraze in jih zamenja za vljudne.'),(157,157,30,0,'Sodeluje v pogovoru z raznimi sogovorci; pri tem upošteva načelo ustreznosti (vljudnosti); prepozna nevljudne izraze in jih zamenja za vljudne.'),(158,158,30,0,'V pogovoru sodeluje ob spodbudi; pri tem upošteva pravila in dogovore, če je kontroliran. Sodeluje ob njemu zanimivih in znanih temah.'),(159,159,30,0,'po poslušanju neumetnostnega besedila odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga zna utemeljiti, govori o svojih izkušnjah in občutkih ob besedilu,'),(160,160,30,0,'Po poslušanju neumetnostnega besedila odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga zna utemeljiti, govori o svojih izkušnjah.'),(161,161,30,0,'Po poslušanju neumetnostnega besedila na spodbudo učitelja odgovarja na vprašanja, pove svoje mnenje o besedilu ter ga utemelji, govori o svojih izkušnjah.'),(162,162,30,0,'Po poslušanju neumetnostnega besedila ob pomoči odgovarja na učiteljeva vprašanja,, govori o svojih izkušnjah.'),(163,163,30,0,'Po poslušanju neumetnostnega besedila odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga zna utemeljiti, govori o svojih izkušnjah.'),(164,164,30,0,'po poslušanju učiteljevega pripovedovanja besedila, radijske igre ali ogledu lutkovne/gledališke predstave ter po samostojnem branju krajših besedil govorno povzame vsebino besedila (skrčena obnova književnega dogajanja),'),(165,165,30,0,'Po poslušanju učiteljevega pripovedovanja besedila,  ogledu lutkovne/gledališke predstave, samostojno govorno povzame vsebino besedila.'),(166,166,30,0,'Po poslušanju učiteljevega pripovedovanja besedila,  ogledu lutkovne/gledališke predstave, s pomočjo vprašanj govorno povzame vsebino besedila.'),(167,167,30,0,'Po poslušanju učiteljevega pripovedovanja besedila,  ogledu lutkovne/gledališke predstave, ob dodatni pomoči  govorno povzame vsebino besedila.'),(168,168,30,0,'Po poslušanju učiteljevega pripovedovanja besedila,  ogledu lutkovne/gledališke predstave, samostojno govorno povzame vsebino besedila.'),(169,169,30,0,'prepozna in opiše dogajalni prostor in čas,'),(170,170,30,0,'Prepozna in opiše dogajalni prostor in čas.'),(171,171,30,0,'Občasno  prepozna in opiše dogajalni prostor in čas.'),(172,172,30,0,'S pomočjo vprašanj prepozna in opiše dogajalni prostor in čas.'),(173,173,30,0,'Prepozna in opiše dogajalni prostor in čas.'),(174,174,30,0,'poimenuje in označi književne osebe, opisuje književno dogajanje z zornega kota osebe, s katero se je identificiral,'),(175,175,30,0,'Poimenuje in označi književne osebe, opisuje književno dogajanje z zornega kota osebe, s katero se je identificiral.'),(176,176,30,0,'Občasno poimenuje in označi književne osebe, opisuje književno dogajanje z zornega kota osebe, s katero se je identificiral.'),(177,177,30,0,'S pomočjo vprašanj poimenuje in označi književne osebe,ki so mu bližje, opisuje književno dogajanje z zornega kota osebe, s katero se je identificiral.'),(178,178,30,0,'razloži, zakaj je kaka književna oseba kaj storila,'),(179,179,30,0,'Razloži, zakaj je kakšna književna oseba kaj storila.'),(180,180,30,0,'Ob pomoči učitelja  razloži, zakaj je kakšna književna oseba kaj storila.'),(181,181,30,0,'Ob pomoči učitelja občasno razloži, zakaj je kakšna književna oseba kaj storila.'),(182,182,30,0,'označi književno osebo s posebej oblikovanim govorom,'),(183,183,30,0,'Samostojno označi književno osebo s posebej oblikovanim govorom.'),(184,184,30,0,'Občasno  označi književno osebo s posebej oblikovanim govorom.'),(185,185,30,0,'S pomočjo vprašanj označi književno osebo s posebej oblikovanim govorom.'),(186,186,30,0,'besedilo povezuje s svojim izkušenjskim in čustvenim svetom;'),(187,187,30,0,'Besedilo povezuje s svojim izkušenjskim in čustvenim svetom.'),(188,188,30,0,'Občasno  besedilo povezuje s svojim izkušenjskim in čustvenim svetom.'),(189,189,30,0,'S pomočjo učiteljevih vprašanj   besedilo povezuje s svojim izkušenjskim in čustvenim svetom.'),(190,190,30,0,'Besedilo povezuje s svojim izkušenjskim in čustvenim svetom.'),(191,191,30,0,'pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic,'),(192,192,30,0,'Pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(193,193,30,0,'Pripoveduje znane pravljice in si izmišlja svoje, pri tem  občasno posnema značilno zgradbo pravljic.'),(194,194,30,0,'Ob učiteljevi pomoči  pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(195,195,30,0,'izraža zaznavanje zvočnosti in ritma, sestavlja ritmična besedila, se igra s črkami in besedami, išče besede, ki se rimajo,'),(196,196,30,0,'Izraža zaznavanje zvočnosti in ritma, sestavlja ritmična besedila, se igra s črkami in besedami, išče besede, ki se rimajo.'),(197,197,30,0,'Izraža zaznavanje zvočnosti in ritma, ob pomoči učitelja sestavlja ritmična besedila, se igra s črkami in besedami, išče besede, ki se rimajo.'),(198,198,30,0,'izrazi zaznavanje likovne oblikovanosti besedila ter besedilne slike,'),(199,199,30,0,'Izrazi zaznavanje likovne oblikovanosti besedila ter besedilne slike.'),(200,200,30,0,'Občasno  izrazi zaznavanje likovne oblikovanosti besedila ter besedilne slike.'),(201,201,30,0,'Ob učiteljevi pomoči izrazi zaznavanje likovne oblikovanosti besedila ter besedilne slike.'),(202,202,30,0,'memorira in deklamira pesmi, niza asociacije ob tematski besedi,'),(203,203,30,0,'Memorira in deklamira pesmi, niza asociacije ob tematski besedi,'),(204,204,30,0,'Memorira in deklamira pesmi, občasno niza asociacije ob tematski besedi,'),(205,205,30,0,'Ob pomoči memorira in deklamira pesmi, občasno niza asociacije ob tematski besedi,'),(206,206,30,0,'napoveduje nadaljevanje zgodbe pripoveduje nadaljevanje pravljice, tvori narobe pravljice in kombinacije dveh pravljic, pripoveduje realistično zgodbo,'),(207,207,30,0,'Napoveduje nadaljevanje zgodbe pripoveduje nadaljevanje pravljice, tvori narobe pravljice in kombinacije dveh pravljic, pripoveduje realistično zgodbo'),(208,208,30,0,'Napoveduje nadaljevanje zgodbe pripoveduje nadaljevanje pravljice,pripoveduje realistično zgodbo,'),(209,209,30,0,'Pripoveduje nadaljevanje pravljice, pripoveduje realistično zgodbo,'),(210,210,30,0,'sodeluje v domišljijski igri vlog,'),(211,211,30,0,'Pogosto  sodeluje v domišljijski igri vlog.'),(212,212,30,0,'Občasno sodeluje v domišljijski igri vlog.'),(213,213,30,0,'Na spodbudo učitelja sodeluje v domišljijski igri vlog.'),(214,214,30,0,'sodeluje v skupinski dramatizaciji besedila, izdeluje lutke,'),(215,215,30,0,'Vedno sodeluje v skupinski dramatizaciji besedila, izdeluje lutke,'),(216,216,30,0,'Občasno  sodeluje v skupinski dramatizaciji besedila, izdeluje lutke,'),(217,217,30,0,'Redkokdaj  sodeluje v skupinski dramatizaciji besedila, izdeluje lutke,'),(218,218,30,0,'našteje razlike med pravljico in risanko,'),(219,219,30,0,'Brez težav  našteje razlike med pravljico in risanko.'),(220,220,30,0,'Našteje nekaj razlik med pravljico in risanko.'),(221,221,30,0,'Z učiteljevo pomočjo našteje nekaj razlik med pravljico in risanko.'),(222,222,30,0,'o stvarnosti govori drugače kot o domišljijskih svetovih,'),(223,223,30,0,'O stvarnosti govori drugače kot o domišljijskih svetovih.'),(224,224,30,0,'O stvarnosti  ne govori drugače kot o domišljijskih svetovih.'),(225,225,30,0,'O stvarnosti govori drugače kot o domišljijskih svetovih.'),(226,226,30,0,'govorno nastopi z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih ali samostojno predstavi člana svoje družine, opiše svojo najljubšo knjigo/risanko ,prostor/zgradbo na sliki ter svoj delovni dan, pripoveduje o poljubnem dogodku'),(227,227,30,0,'Govorno nastopi z vnaprej pripravljeno stvarno temo, ob učiteljevih vprašanjih samostojno predstavi člana svoje družine, opiše svojo najljubšo knjigo.'),(228,228,30,0,'Pred razredom ob učiteljevih vprašanjih opiše svojo najljubšo knjigo, pripoveduje o poljubnem dogodku.'),(229,229,30,0,'Pred razredom ob učiteljevih vprašanjih predstavi člana svoje družine ter svoj delovni dan.'),(230,230,30,0,'najde protipomenke in sopomenke ter izraža svojino s svojilnim pridevnikom (nam. s svojilnim rodilnikom),'),(231,231,30,0,'Najde protipomenke in sopomenke ter izraža svojino s svojilnim pridevnikom (nam. s svojilnim rodilnikom),'),(232,232,30,0,'Občasno najde protipomenke in sopomenke ter izraža svojino s svojilnim pridevnikom (nam. s svojilnim rodilnikom),'),(233,233,30,0,'Ne najde protipomenke in sopomenke ter še ne  izraža svojino s svojilnim pridevnikom (nam. s svojilnim rodilnikom),'),(234,234,30,0,'pravilno uporablja časovne prislove in glagolske časovne oblike, zna določiti zaporedje dejanj,'),(235,235,30,0,'Pravilno uporablja časovne prislove in glagolske časovne oblike, zna določiti zaporedje dejanj.'),(236,236,30,0,'Pravilno uporablja časovne prislove in glagolske časovne oblike, s pomočjo zna določiti zaporedje dejanj.'),(237,237,30,0,'Nepravilno uporablja časovne prislove in glagolske časovne oblike, ne zna določiti zaporedje dejanj.'),(238,238,30,0,'v izgovorjenih besedah prepozna zaporedje in število glasov, v izgovorjenih povedih pa si zapomni zaporedje besed ter prepozna vrsto končne intonacije.'),(239,239,30,0,'V izgovorjenih besedah prepozna zaporedje in število glasov, v izgovorjenih povedih pa si zapomni zaporedje besed ter prepozna vrsto končne intonacije.'),(240,240,30,0,'V izgovorjenih besedah prepozna zaporedje in število glasov, v izgovorjenih povedih pa si  zapomni  zaporedje besed.'),(241,241,30,0,'V izgovorjenih besedah prepozna zaporedje in število glasov, v izgovorjenih povedih pa si  težko zapomni zaporedje besed.'),(242,242,31,0,'glasno bere krajša preprosta tiskana neumetnostna besedila,'),(243,243,31,0,'Brez napak glasno bere krajša preprosta tiskana neumetnostna besedila.'),(244,244,31,0,'Zatikajoče  glasno bere krajša preprosta tiskana neumetnostna besedila.'),(245,245,31,0,'Brez napak glasno bere krajša preprosta tiskana neumetnostna besedila.'),(246,246,31,0,'tiho in poltiho bere neznano krajše umetnostno besedilo (pesmi in znane pravljice), po poprejšnji pripravi bere glasno,'),(247,247,31,0,'Brez težav tiho in poltiho bere neznano krajše umetnostno besedilo (pesmi in znane pravljice), po poprejšnji pripravi bere glasno.'),(248,248,31,0,'Z napakami tiho in poltiho bere neznano krajše umetnostno besedilo (pesmi in znane pravljice), po poprejšnji pripravi bere glasno.'),(249,249,31,0,'po branju ustno in pisno odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu in ga zna utemeljiti, govori o svojih izkušnjah in občutkih ob besedilu,'),(250,250,31,0,'Po branju ustno in pisno odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu in ga zna utemeljiti, govori o svojih izkušnjah in občutkih.'),(251,251,31,0,'Po branju ustno in pisno odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu, govori o svojih izkušnjah in občutkih ob besedilu.'),(252,252,31,0,'Po branju ustno odgovarja na učiteljeva vprašanja, govori o svojih izkušnjah in občutkih ob besedilu.'),(253,253,31,0,'Po branju ustno in pisno odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu in ga zna utemeljiti, govori o svojih izkušnjah in občutkih'),(254,254,31,0,'zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami,'),(255,255,31,0,'Brez napak zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami.'),(256,256,31,0,'Z nekaj napakami zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami.'),(257,257,31,0,'  Z mnogimi napakami zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami.'),(258,258,31,0,'Brez napak zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami.'),(259,259,31,0,'prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi,'),(260,260,31,0,'Brez napak prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi.'),(261,261,31,0,'Z manjšimi napakami prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi.'),(262,262,31,0,'Z mnogimi napakami prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi.'),(263,263,31,0,'Brez napak prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi.'),(264,264,31,0,'samostojno napiše zapovedi, prepovedi in opozorila iz svojega okolja, pisno odgovarja na učiteljeva pisna vprašanja o sebi, o svojem okolju, o prebranem besedilu ter o tem, kar je doživel,'),(265,265,31,0,'Samostojno napiše zapovedi, prepovedi in opozorila iz svojega okolja, pisno odgovarja na učiteljeva pisna vprašanja o sebi, o svojem okolju, o prebranem besedilu ter o tem, kar je doživel.'),(266,266,31,0,'S pomočjo napiše zapovedi, prepovedi in opozorila iz svojega okolja, pisno odgovarja na učiteljeva ustna vprašanja o sebi, o svojem okolju, o prebranem besedilu ter o tem, kar je doživel.'),(267,267,31,0,'S pomočjo napiše prepovedi iz svojega okolja, pisno odgovarja na učiteljeva pisna vprašanja o sebi ter o tem, kar je doživel.'),(268,268,31,0,'pazi na čitljivost, estetskost in pravilnost zapisa, obvlada rabo velike začetnice na začetku povedi ter v osebnih lastnih imenih, obvlada rabo končnih ločil,'),(269,269,31,0,'Pazi na čitljivost, estetskost in pravilnost zapisa, obvlada rabo velike začetnice na začetku povedi ter v osebnih lastnih imenih, obvlada rabo končni'),(270,270,31,0,'Pazi na čitljivost, estetskost in pravilnost zapisa, obvlada rabo velike začetnice na začetku povedi. obvlada rabo končnih ločil'),(271,271,31,0,'Pazi na čitljivost, estetskost in pravilnost zapisa, pri rabi velike začetnice  in končnih ločil ima težave.'),(272,272,31,0,'ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora,'),(273,273,31,0,'Zelo izvirno ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora.'),(274,274,31,0,'Ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora.'),(275,275,31,0,'nariše svojo domišljijskočutno predstavo domišljijskega in realističnega dogajalnega prostora,'),(276,276,31,0,'Estetsko nariše svojo domišljijskočutno predstavo domišljijskega in realističnega dogajalnega prostora.'),(277,277,31,0,'prikaže književno dogajanje s sličicami,'),(278,278,31,0,'Brez težav prikaže književno dogajanje s sličicami.'),(279,279,31,0,'Občasno prikaže književno dogajanje s sličicami.'),(280,280,31,0,'S pomočjo prikaže književno dogajanje s sličicami.'),(281,281,31,0,'napiše svojo pravljico z nizanjem sličic,'),(282,282,31,0,'Hitro in brez težav napiše svojo pravljico z nizanjem sličic,'),(283,283,31,0,'Z učiteljevo pomočjo napiše svojo pravljico z nizanjem sličic,'),(284,284,31,0,'izraža se s kombinacijo risbe in zapisa (strip).'),(285,285,31,0,'Ima velik smisel za izražanje  s kombinacijo risbe in zapisa (strip).'),(286,286,31,0,'Izraža se s kombinacijo risbe in zapisa (strip).'),(287,287,31,0,'Ne izraža se rad s kombinacijo risbe in zapisa (strip).'),(288,288,32,1,'smiselno sodeluje v pogovoru ter obvlada temeljna načela vljudnega pogovarjanja,'),(289,289,32,1,'Smiselno se vključuje in sodeluje v pogovoru. Pravilno uporablja vljudnostne izraze. Upošteva pravila in dogovore.'),(290,290,32,1,'Sodeluje v pogovoru, še posebno se izkaže ob njemu priljubljenih temah. Upošteva načela vljudnostnega pogovarjanja.'),(291,291,32,1,'Sodeluje ob spodbudi. Upošteva pravila in dogovore, če je kontroliran. Sodeluje ob njemu zanimivih in znanih temah.'),(292,292,32,1,'Pogovoru sledi, vendar v njem ne sodeluje. Sogovorniku sega v besedo. Vljudnostnih izrazov ne uporablja.'),(293,293,32,1,'govorno nastopi z vnaprej pripravljeno temo,'),(294,294,32,1,'Domiselno sestavi zgodbo, jo govorno interpretira in doživeto predstavi.'),(295,295,32,1,'Tekoče obnovi vsebino zgodbe in izvede krajši govorni nastop.'),(296,296,32,1,'V pripravi na govorni nastop se posvetuje z učiteljem. Vsebino zgodbe obnovi ob vprašanjih.'),(297,297,32,1,'Pripravljeno temo, ki je njemu blizu, predstavi ob pomoči učitelja.'),(298,298,32,1,'loči umetnostno besedilo od neumetnostnega,'),(299,299,32,1,'Ob branju loči umetnostno besedilo od neumetnostnega in našteva razlike.'),(300,300,32,1,'Loči umetnostno besedilo od neumetnostnega in ob vprašanjih prepozna razlike.'),(301,301,32,1,'Ob pomoči loči umetnostno besedilo od neumetnostnega.'),(302,302,32,1,'Še ne loči umetnostno besedilo od neumetnostnega.'),(303,303,32,1,'samostojno glasno prebere krajše umetnostno in neumetnostno besedilo, ga obnovi,'),(304,304,32,1,'Tekoče bere. Razume prebrano besedilo. Obnovi besedilo.'),(305,305,32,1,'Bere vezano. Delno razume prebrano besedilo. Odgovarja na učiteljeva vprašanja v povedih.'),(306,306,32,1,'Bere po zlogih. Prebrano razume po večkratnem branju. Odgovarja v nepopolnih povedih.'),(307,307,32,1,'Besede črkuje. Prebranega še ne razume. Občasno odgovarja samo z besedo.'),(308,308,32,1,'prepozna lastnosti književne osebe, se vanjo vživi in jo zaigra,'),(309,309,32,1,'Vrednoti ravnanje književne osebe, se vanjo vživi in zaigra. Pove svoje mnenje o vsebini.'),(310,310,32,1,'Prepozna lastnosti književne osebe, se vanjo vživi in zaigra. Obnovi vsebino besedila.'),(311,311,32,1,'Prepozna lastnosti književne osebe, ob spodbudi se vživi vanjo in jo zaigra. Obnovi vsebino ob slikah.'),(312,312,32,1,'Prepozna književne osebe, ki so mu bližje, se vanje vživi ter zaigra. Obnovi vsebino ob slikah s pomočjo vprašanj.'),(313,313,32,1,'pozna značilnosti pravljice, loči pravljico od realističnih pripovedi,'),(314,314,32,1,'Domiselno sestavi pravljico in upošteva vse njene značilnosti. Vrednoti - prepozna lastnosti književnih oseb.'),(315,315,32,1,'Domiselno sestavi pravljico in upošteva vse njene značilnosti. Vrednoti ravnanje književne osebe.'),(316,316,32,1,'Pripoveduje svojo pravljico, opiše lastnosti književne osebe.'),(317,317,32,1,'Ob učiteljevi pomoči pripoveduje pravljico. Poimenuje književne osebe.'),(318,318,32,1,'Domiselno sestavi pravljico in upošteva vse njene značilnosti. Vrednoti - prepozna lastnosti književnih oseb.'),(319,319,32,1,'zazna zvočnost pesmi in niza asociacije ob tematski besedi,'),(320,320,32,1,'Zazna zvočnost pesmi. Samostojno sestavlja, oziroma dodaja rime.'),(321,321,32,1,'Zaznava zvočnost pesmi. Rime dopolnjuje z dodajanjem smiselnih besed.'),(322,322,32,1,'Zaznava zvočnost pesmi. Tvori preproste rime.'),(323,323,32,1,'Ob spodbudi zazna zvočnost pesmi. Ne razume sporočila pesmi. Občasno najde rimo.'),(324,324,32,1,'Zazna zvočnost pesmi. Samostojno sestavlja, oziroma dodaja rime.'),(325,325,32,1,'zazna osnovno razpoloženje besedila in ga ilustrira,'),(326,326,32,1,'Po poslušanju samostojno obnovi vsebino in jo ilustrira. Pove svoje mnenje in ga utemelji.'),(327,327,32,1,'Po poslušanju odgovarja na učiteljeva vprašanja v popolnih povedih. Vsebino ilustrira'),(328,328,32,1,'Po poslušanju odgovarja v nepopolnih povedih. Ilustrira po navodilih'),(329,329,32,1,'Pri poslušanju ni dovolj zbran. Potrebuje dodatno spodbudo. Odgovarja samo z besedo. Vsebino ilustrira po navodilu'),(330,330,32,1,'Po poslušanju samostojno obnovi vsebino in jo ilustrira. Pove svoje mnenje in ga utemelji.'),(331,331,32,1,'s tiskanimi črkami samostojno zapiše posamezne besede in enostavčne odgovore na učiteljeva vprašanja; pri tem upošteva prva pravopisna pravila,'),(332,332,32,1,'Samostojno oblikuje in zapiše enostavčne povedi. Pravilno zapiše veliko začetnico na začetku povedi, za piko, za osebna in lastna imena.'),(333,333,32,1,'Oblikuje in zapiše preproste povedi. Pravilno zapiše veliko začetnico v začetku in na koncu povedi. Pri osebnih in lastnih imenih pa, če je na to opozorjen.'),(334,334,32,1,'S pomočjo oblikuje preproste povedi in jih zapiše. Še ne upošteva pravopisnih pravil. Če je opozorjen , upošteva rabo velike začetnice.'),(335,335,32,1,'Pozna črke, vendar zapisuje le besede ob pomoči. Še ne upošteva velike začetnice'),(336,336,32,1,'Samostojno oblikuje in zapiše enostavčne povedi. Pravilno zapiše veliko začetnico na začetku povedi, za piko, za osebna in lastna imena.'),(337,337,32,1,'sledi počasnemu nareku in zapiše posamezne besede in enostavčne povedi,'),(338,338,32,1,'Samostojno oblikuje in zapiše smiselne odgovore. Pravilno prepiše krajše besedilo in piše po nareku. Piše čitljivo in pazi na estetski videz pisave.'),(339,339,32,1,'Zapiše in oblikuje preproste smiselne odgovore. Pri prepisu krajšega besedila in pri nareku občasno dela manjše napake. Piše razločno, vendar premalo'),(340,340,32,1,'S pomočjo oblikuje in zapiše odgovor. Pri krajšem prepisu in nareku spušča črke in besede. Zaradi slabše orientacije na ravnini pisava še ni čitljiva.'),(341,341,32,1,'Odgovor sestavi in zapiše samo ob pomoči učitelja. Pri krajšem prepisu spušča črke in besede. Pri nareku ima še velike težave, zlasti pri pisanju daljšega besedila.'),(342,342,32,1,'Samostojno oblikuje in zapiše smiselne odgovore. Pravilno prepiše krajše besedilo in piše po nareku. Piše čitljivo in pazi na estetski videz pisave.'),(343,343,32,1,'prepiše krajše tiskano besedilo,'),(344,344,32,1,'Brez napak  prepiše krajše tiskano besedilo.'),(345,345,32,1,'Z manjšimi napakami prepiše krajše tiskano besedilo.'),(346,346,32,1,'Z mnogimi napakami prepiše krajše tiskano besedilo.'),(347,347,32,1,'pazi na čitljivost in estetskost zapisanih besedil,'),(348,348,32,1,'Pazi na čitljivost in estetskost zapisanih besedil.'),(349,349,32,1,'Premalo pazi na čitljivost in estetskost zapisanih besedil.'),(350,350,32,1,'prepozna izraze knjižni in neknjižni jezik; materni in tuji jezik.'),(351,351,32,1,'Glede na govorni položaj uporabi ustrezno zvrst jezika.'),(352,352,32,1,'Ob opozorilu uporabi ustrezno zvrst jezika.'),(353,353,32,1,'Loči knjižni jezik od neknjižnega. Uporablja pogovorni jezik.'),(354,354,32,1,'Izraža se samo v jeziku domačega okolja.'),(355,355,59,0,'se pogovarja z raznimi sogovorci - smiselno se vključi v pogovor oz. se smiselno odzove na govorjenje drugega, izbere okoliščinam ustrezen pozdrav in odgovor, vljudno izrazi svojo željo ter pogovor ustrezno konča,'),(356,356,59,0,'Se pogovarja z raznimi sogovorci, smiselno se vključi v pogovor oz. se smiselno odzove na govorjenje drugega, izbere okoliščinam ustrezen pozdrav.'),(357,357,59,0,'Se pogovarja z raznimi sogovorci, občasno se smiselno vključi v pogovor oz. se smiselno odzove na govorjenje drugega.'),(358,358,59,0,'Ob spodbudah se vključi v pogovor.'),(359,359,59,0,'sodeluje v telefonskem pogovoru - pri tem upošteva njegove posebnosti,'),(360,360,59,0,'Sodeluje v telefonskem pogovoru - pri tem upošteva njegove posebnosti.'),(361,361,59,0,'Sodeluje v telefonskem pogovoru, a redko upošteva njegove posebnosti.'),(362,362,59,0,'Sodeluje v telefonskem pogovoru, a le ob opozorilu upošteva njegove posebnosti.'),(363,363,59,0,'govorno nastopi z vnaprej pripravljeno temo - tvori smiselno, povezano in zaokroženo besedilo,'),(364,364,59,0,'Govorno nastopi z vnaprej pripravljeno temo - tvori smiselno, povezano in zaokroženo besedilo.'),(365,365,59,0,'Govorno nastopi z vnaprej pripravljeno temo - ob vprašanjih učitelja tvori smiselno, povezano in zaokroženo besedilo.'),(366,366,59,0,'Govorno nastopi z vnaprej pripravljeno temo - tvori smiselno, a ne dovolj povezano in zaokroženo besedilo.'),(367,367,59,0,'pred javnostjo govori razločno, naravno in čim bolj zborno,'),(368,368,59,0,'Pred javnostjo govori razločno, naravno in čim bolj zborno.'),(369,369,59,0,'Pred javnostjo občasno govori razločno, naravno in zborno.'),(370,370,59,0,'Pred javnostjo govori razločno, naravno in zborno le ob predhodnem opozorilu,'),(371,371,59,0,'pozorno posluša neumetnostno besedilo, prepozna njegov namen in temo ter bistvene podatke in njihovo povezanost, izrazi svoje mnenje o besedilu, pripoveduje o svojih izkušnjah in občutkih ob besedilu; besedilo dopolni ali v njem prepozna napake in jih odpravi'),(372,372,59,0,'Pozorno posluša neumetnostno besedilo, s pomočjo vprašanj prepozna njegov namen in temo ter bistvene podatke in njihovo povezanost.'),(373,373,59,0,'Nepozorno posluša neumetnostno besedilo. Z učiteljevo pomočjo prepozna bistvene podatke.'),(374,374,59,0,'znanim besedam najde sopomenke, protipomenke, nadpomenke in podpomenke,'),(375,375,59,0,'Znanim besedam najde sopomenke, protipomenke, nadpomenke in podpomenke.'),(376,376,59,0,'Znanim besedam občasno najde sopomenke, protipomenke, nadpomenke in podpomenke.'),(377,377,59,0,'Znanim besedam le ob pomoči najde sopomenke, protipomenke, nadpomenke in podpomenke.'),(378,378,59,0,'tvori samostalniške izpeljanke iz glagola in pridevniške izpeljanke iz samostalnika ter prepozna njihov pomen v besednih zvezah,'),(379,379,59,0,'Tvori samostalniške izpeljanke iz glagola in pridevniške izpeljanke iz samostalnika ter prepozna njihov pomen v besednih zvezah.'),(380,380,59,0,'Tvori samostalniške izpeljanke iz glagola in pridevniške izpeljanke iz samostalnika ter občasno prepozna njihov pomen v besednih zvezah.'),(381,381,59,0,'Tvori samostalniške izpeljanke iz glagola in pridevniške izpeljanke iz samostalnika.'),(382,382,59,0,'uporablja glavne in vrstilne števnike, stopnjuje pridevnike, izbere pravi predlog ali krajevni prislov ter glagolsko časovno obliko,'),(383,383,59,0,'Uporablja glavne in vrstilne števnike, stopnjuje pridevnike, izbere pravi predlog ali krajevni prislov ter glagolsko časovno obliko.'),(384,384,59,0,'Dokaj pravilno uporablja glavne in vrstilne števnike, stopnjuje pridevnike, izbere pravi predlog ali krajevni prislov ter glagolsko časovno obliko.'),(385,385,59,0,'Ob pomoči učitelja uporablja glavne in vrstilne števnike, stopnjuje pridevnike, izbere pravi predlog ali krajevni prislov ter glagolsko časovno obliko'),(386,386,59,0,'prepozna zaporedje dejanj in ga zna ubesediti (tudi z ustreznimi časovnimi prislovi),'),(387,387,59,0,'Prepozna zaporedje dejanj in ga zna ubesediti (tudi z ustreznimi časovnimi prislovi).'),(388,388,59,0,'Ob pomoči prepozna zaporedje dejanj in ga zna ubesediti (tudi z ustreznimi časovnimi prislovi).'),(389,389,59,0,'ve, v katerem jeziku so v Republiki Sloveniji napisana javna obvestila; na dvojezičnem področju loči pojma državni in uradni jezik ter pozna imena jezikov, ki jih govorijo ljudje v njegovi/njeni okolici,'),(390,390,59,0,'Ve, v katerem jeziku so v Republiki Sloveniji napisana javna obvestila; na dvojezičnem področju loči pojma državni in uradni jezik.'),(391,391,59,0,'Ve, v katerem jeziku so v Republiki Sloveniji napisana javna obvestila. Na dvojezičnem področju  pozna imena jezikov.'),(392,392,59,0,'učenec prepozna govorni položaj poslušanja umetnostnega besedila; razume, kar sliši; po poslušanju pove, o čem je pripovedovalo književno besedilo, kje in kdaj se je dogajalo, našteje književne osebe in pojasni, zakaj se je kaj zgodilo,'),(393,393,59,0,'Prepozna govorni položaj poslušanja umetnostnega besedila; razume, kar sliši; po poslušanju pove, o čem je pripovedovalo književno besedilo.'),(394,394,59,0,'Občasno prepozna govorni položaj poslušanja umetnostnega besedila. Po poslušanju ob učiteljevi pomoči pove, o čem je pripovedovalo književno besedilo'),(395,395,59,0,'S pomočjo vprašanj prepozna govorni položaj poslušanja umetnostnega besedila. S pomočjo vprašanj pove, o čem je pripovedovalo besedilo.'),(396,396,59,0,'ob poslušanju se učenec identificira s književno osebo, ki mu je najbolj podobna; po poslušanju pove, katera je njegova književna oseba, opiše, kakšno si je predstavljal; književno dogajanje opiše z zornega kota svoje književne osebe.'),(397,397,59,0,'Ob poslušanju se  s književno osebo, ki mu je najbolj podobna; po poslušanju pove, katera je njegova književna oseba in jo opiše.'),(398,398,59,0,'Ob poslušanju se  ob spodbudah identificira s književno osebo, ki mu je najbolj podobna, jo opiše in ob pomoči književno dogajanje opiše z zornega kota svoje književne osebe.'),(399,399,59,0,'Ob poslušanju pove, katera književna oseba mu je najbolj podobna.'),(400,400,59,0,'razume in pojasni, zakaj je katera književna oseba kaj storila, pri čemer prepozna dve skupini motivov: \"dobra oseba\", \"slaba oseba\",'),(401,401,59,0,'Razume in pojasni, zakaj je katera književna oseba kaj storila ter pri tem prepozna dve skupini motivov: \"dobra oseba\", \"slaba oseba\".'),(402,402,59,0,'Ve, kaj je katera književna oseba storila.'),(403,403,59,0,'Ob pomoči pove, kaj je določena književna oseba storila.'),(404,404,59,0,'loči dva tipa dogajalnih prostorov: domišljijskega in realnega; po poslušanju nariše oz. pove, kakšen je bil domišljijski dogajalni prostor (ustvari ga tako, da besedilo dopolni z elementi svoje domišljije) in kakšen je bil realistični dogajalni prostor'),(405,405,59,0,'Loči dva tipa dogajalnih prostorov:domišljijskega in realnega.'),(406,406,59,0,'Ob pomoči loči dva tipa dogajalnega prostora: domišljijski in realistični.'),(407,407,59,0,'Ne loči domišljijskega in realističnega prostora.'),(408,408,59,0,'prepozna in doživi pravljico; po poslušanju pripoveduje strnjeno pravljično dogajanje; tvori svoje pravljice, pripoveduje narobe pravljice in kombinacije dveh pravljic,'),(409,409,59,0,'Prepozna in doživi pravljico; po poslušanju pripoveduje strnjeno pravljično dogajanje; tvori svoje pravljice, pripoveduje narobe pravljice.'),(410,410,59,0,'Prepozna in doživi pravljico in po poslušanju pripoveduje strnjeno pravljično dogajanje.'),(411,411,59,0,'S pomočjo vprašanj prepozna pravljico in ob pomoči pove kratko vsebino.'),(412,412,59,0,'doživi pesem; s posebej oblikovanim govorom ponazarja razpoloženje besedila, pesem doživeto deklamira,'),(413,413,59,0,'Doživi pesem; s posebej oblikovanim govorom ponazarja razpoloženje besedila, pesem doživeto deklamira.'),(414,414,59,0,'Doživi pesem; po opozorilu s posebej oblikovanim govorom ponazarja razpoloženje besedila ter pesem doživeto deklamira.'),(415,415,59,0,'ob ogledu gledališke/lutkovne predstave, risanke in otroškega filma ter ob poslušanju radijske igre spoznava prvine in značilnosti posameznega medija.'),(416,416,59,0,'Ob ogledu gledališke/lutkovne predstave, risanke in otroškega filma ter ob poslušanju radijske igre spoznava prvine in značilnosti posameznega medija.'),(417,417,59,0,'Z učiteljevo pomočjo spoznava značilnosti gledališke/lutkovne predstave, risanke in otroškega filma in radijske igre.'),(418,418,60,0,'glasno ali tiho prebere s pisanimi črkami napisano povezovalno ali pozivno besedilo; prepozna njegov namen in bistvene podatke, sporočevalca, naslovnika, kraj in čas sporočanje, predvidi naslovnikov odziv in določi okoliščine, v katerih tvorimo podobna besedila'),(419,419,60,0,'Glasno ali tiho prebere s pisanimi črkami napisano povezovalno ali pozivno besedilo; prepozna njegov namen in bistvene podatke.'),(420,420,60,0,'Glasno ali tiho prebere s pisanimi črkami napisano povezovalno ali pozivno besedilo in ob pomoči  prepozna njegov namen in bistvene podatke.'),(421,421,60,0,'glasno ali tiho prebere krajše prikazovalno neumetnostno besedilo; prepozna njegov namen in temo ter bistvene podatke in njihovo povezanost, izrazi svoje mnenje o besedilu ter ga skuša utemeljiti; besedilo dopolni ali v njem prepozna napake in jih odpravi'),(422,422,60,0,'Glasno ali tiho prebere krajše prikazovalno neumetnostno besedilo; prepozna njegov namen in temo ter bistvene podatke in njihovo povezanost.'),(423,423,60,0,'Glasno ali tiho prebere krajše prikazovalno neumetnostno besedilo, ob pomoči prepozna njegov namen in temo ter bistvene podatke in njihovo povezanost.'),(424,424,60,0,'Glasno ali tiho prebere krajše prikazovalno neumetnostno besedilo.'),(425,425,60,0,'glasno ali tiho prebere razne sezname, najde določen podatek, se znajde v seznamu,'),(426,426,60,0,'Glasno ali tiho prebere razne sezname, najde določen podatek, se znajde v seznamu.'),(427,427,60,0,'Glasno ali tiho prebere razne sezname, občasno najde določen podatek ter se znajde v seznamu.'),(428,428,60,0,'Glasno ali tiho prebere razne sezname, ob pomoči učitelja pa najde določen podatek ter  se znajde v seznamu.'),(429,429,60,0,'glasno bere tekoče, pravilno in čim bolj zborno,'),(430,430,60,0,'Glasno bere tekoče, pravilno in čim bolj zborno.'),(431,431,60,0,'Glasno bere počasneje, a tekoče , pravilno in čim bolj zborno.'),(432,432,60,0,'Glasno bere počasi, zatikajoče.'),(433,433,60,0,'ob prebranem zgledu napiše smiselno, povezano in zaokroženo besedilo,'),(434,434,60,0,'Ob prebranem zgledu napiše smiselno, povezano in zaokroženo besedilo.'),(435,435,60,0,'Ob prebranem zgledu napiše krajše smiselno, povezano in zaokroženo besedilo.'),(436,436,60,0,'Ob prebranem zgledu napiše krajše smiselno, a vsebinsko še nepovezano in nezaokroženo besedilo.'),(437,437,60,0,'piše čitljivo in pravilno - obvlada zapis zvočnikov in nezvočnikov v raznih položajih v besedi, obvlada rabo velike začetnice na začetku povedi ter v osebnih in bližnjih zemljepisnih lastnih imenih, zna postaviti vejico pri naštevanju,'),(438,438,60,0,'Piše čitljivo in pravilno, obvlada rabo velike začetnice na začetku povedi ter v osebnih in bližnjih zemljepisnih lastnih imenih in zna postaviti veji'),(439,439,60,0,'Piše čitljivo in pravilno, občasno pozabi zapisati veliko začetnico, zna postaviti vejico pri naštevanju.'),(440,440,60,0,'Piše čitljivo. Ima težave pri zapisu velike začetnice.'),(441,441,60,0,'v besedilu najde pravopisne napake in jih odpravi,'),(442,442,60,0,'V besedilu najde pravopisne napake in jih odpravi.'),(443,443,60,0,'V besedilu občasno najde pravopisne napake in jih odpravi.'),(444,444,60,0,'V besedilu ob pomoči najde pravopisne napake in jih odpravi.'),(445,445,60,0,'tiho in poltiho bere neznano umetnostno besedilo, daljše umetnostno besedilo bere glasno po poprejšnji pripravi,'),(446,446,60,0,'Tiho in poltiho bere neznano umetnostno besedilo, daljše umetnostno besedilo bere glasno po poprejšnji pripravi.'),(447,447,60,0,'Tiho in poltiho počasi bere neznano umetnostno besedilo, daljše umetnostno besedilo bere počasi glasno po poprejšnji pripravi.'),(448,448,60,0,'po branju umetnostnega besedila se identificira z eno od književnih oseb, prepozna glavne in stranske književne osebe, motive za njihovo ravnanje razume iz lastne izkušnje, pozna dogajalni prostor in čas ter zaznava razliko med dogajanjem v domišljijskem'),(449,449,60,0,'Po branju umetnostnega besedila se identificira z eno od književnih oseb, prepozna glavne in stranske književne osebe, pozna dogajalni čas in prostor.'),(450,450,60,0,'Po branju umetnostnega besedila  pozna glavne in stranske književne osebe, pozna dogajalni čas in prostor.'),(451,451,60,0,'Po branju umetnostnega besedila prepozna glavne književne junake.'),(452,452,60,0,'po branju pesmi zazna in doživlja njeno zvočnost, s posebej oblikovanim govorom ponazarja razpoloženje v njej, zaznava njen ritem, rimo in likovno oblikovanost, razume in pojasnjuje preproste primere; pesem doživeto deklamira, tematiko izraža z ilustriranjem'),(453,453,60,0,'Po branju pesmi zazna in doživlja njeno zvočnost, s posebej oblikovanim govorom ponazarja razpoloženje v njej, pesem doživeto deklamira.'),(454,454,60,0,'Po branju pesmi  s posebej oblikovanim govorom ponazarja razpoloženje v njej in jo deklamira.'),(455,455,60,0,'Določeno pesem se nauči na pamet.'),(456,456,60,0,'bere pravljice in pripovedi, prepoznava pravljično dogajanje in spoznava mejo med realnim in domišljijskim svetom; piše nadaljevanje pravljice in upošteva njene značilnosti, piše narobe pravljice oziroma povezuje več pravljic;'),(457,457,60,0,'Bere pravljice in pripovedi, prepoznava pravljično dogajanje in spoznava mejo med realnim in domišljijskim svetom; piše nadaljevanje pravljice.'),(458,458,60,0,'Bere pravljice in pripovedi, prepoznava pravljično dogajanje , piše nadaljevanje pravljice.'),(459,459,60,0,'Bere pravljice in pripovedi in jih s pomočjo vprašanj obnovi.'),(460,460,60,0,'tvori realistično pripoved z dogajanjem iz svojega okolja;'),(461,461,60,0,'Tvori realistično pripoved z dogajanjem iz svojega okolja.'),(462,462,60,0,'Ob pomoči tvori realistično pripoved z dogajanjem iz svojega okolja.'),(463,463,60,0,'Po vprašanjih tvori kratko realistično pripoved z dogajanjem iz svojega okolja.'),(464,464,60,0,'samostojno bere krajše dramsko besedilo po vlogah, v skupini dramatizira pesem ali prozno besedilo, spremembo razpoloženja izraža s spremembo glasu in gibom; piše dvogovore po vzorcu dramskih prizorov in dramatizira dele proznih besedil.'),(465,465,60,0,'Samostojno bere krajše dramsko besedilo po vlogah, v skupini dramatizira pesem ali prozno besedilo, spremembo razpoloženja izraža s spremembo glasu.'),(466,466,60,0,'Samostojno bere krajše dramsko besedilo po vlogah, v skupini dramatizira pesem ali prozno besedilo.'),(467,467,60,0,'Ob pomoči bere krajše dramsko besedilo po vlogah.'),(468,468,61,1,'obvlada temeljna načela pogovarjanja,'),(469,469,61,1,'Vsakodnevno v pogovoru uporablja vljudnostne izraze in uporablja ustrezne pozdrave.'),(470,470,61,1,'V pogovoru uporablja vljudnostne izraze, vendar jih občasno uporablja.'),(471,471,61,1,'Razume vljudnostne izraze in jih občasno uporablja ob spodbudi učitelja.'),(472,472,61,1,'govorno nastopi tvori smiselno, povezano in zaokroženo besedilo,'),(473,473,61,1,'Govori razločno, spontano uporablja knjižni jezik. Pripoveduje tekoče z vnaprej pripravljeno temo po lastnem izboru. Opiše predmet, žival, bitje.'),(474,474,61,1,'Govori razločno, večinoma uporablja zborni jezik, ob spodbudi knjižni jezik. Pripoveduje ob slikovnih pripomočkih. S pomočjo gradiv opiše predmet.'),(475,475,61,1,'V pogovoru uporablja narečne izraze. Pripoveduje ob spodbudi učitelja. Opiše predmet, žival s po močjo vprašanj in  podvprašanj.'),(476,476,61,1,'pozorno posluša ter glasno in tiho bere razna neumetnostna besedila - v besedilih prepozna namen in temo, bistvene podatke in razmerja med njimi,'),(477,477,61,1,'Razume prebrano besedilo, prepozna namen in temo, bistvene podatke in razmerje med njimi. Bere tekoče, pravilno, glasno. Upošteva ločila in jih bere.'),(478,478,61,1,'Po drugem branju odgovarja na učiteljeva vprašanja o bistvenih podatkih. Bere vezano, ločila delno upošteva'),(479,479,61,1,'Po večkratnem branju in ob spodbudi ali pomoči delno razume besedilo. Besede črkuje, prebere enozložne in znane besede.'),(480,480,61,1,'napiše krajše neumetnostno besedilo in obvlada osnovna pravopisna pravila,'),(481,481,61,1,'Pravilno prepiše besedilo in obvlada osnovna pravopisna pravila. Samostojno zapiše narek in neum. besedilo, pravilno rabi veliko začetnico in ločila.'),(482,482,61,1,'Prepiše besedilo v celoti, spušča ali zamenja črke, ločila in veliko začetnico. Zapiše narek in neum. besedilo, vendar s pravopisnimi napakami.'),(483,483,61,1,'Delno prepiše besedilo, spušča končna ločila, črke, besede in veliko začetnico. Ob pomoči delno zapiše narek. Ima težave s pravopisom.'),(484,484,61,1,'loči domišljijski svet od realnega in umetnostno besedilo od neumetnostnega,'),(485,485,61,1,'Loči domišljijski in realni svet in vsakega dopolni s pravimi elementi. Razlikuje um. in neum. besedilo in upošteva značilnosti obeh zvrsti.'),(486,486,61,1,'Loči domišljijski in realni svet, vendar pri tem ni najbolj zanesljiv in potrebuje dodatna pojasnila.'),(487,487,61,1,'Pri ločevanju domišljijskega in realnega sveta ima težave. Umetnostno besedilo od neumetnostnega ne loči vedno.'),(488,488,61,1,'prepozna glavne in stranske književne osebe in se identificira z eno od književnih oseb,'),(489,489,61,1,'Prepozna lastnosti glavne in stranske književne osebe. Identificira se z osebo, ki mu je najbolj podobna. Razume in pojasni motiv osebe.'),(490,490,61,1,'Identificira se z osebo, ki mu je najbolj podobna. Razume, zakaj je katera književna oseba kaj storila.'),(491,491,61,1,'Prepozna lastnosti književne osebe, ob spodbudi se vanjo vživi in jo zaigra. Razume ravnanje posamezne književne osebe.'),(492,492,61,1,'posluša, bere in razume umetnostna besedila,'),(493,493,61,1,'Glasno bere tekoče, pravilno in čim bolj zborno tudi daljše besedilo. Po branju razume besedilo, izrazi svoje mnenje in ga skuša utemeljiti.'),(494,494,61,1,'Glasno in poltiho bere tudi daljše besedilo, po opozorilu upošteva stavčno intonacijo. Vsebino besedila razume, po utemeljitvi je premalo samostojen.'),(495,495,61,1,'Bere počasi krajša besedila. Premalo upošteva stavčno intonacijo. Po ponovnem branju odgovarja na vprašanja. Ne izrazi svojega mnenja.'),(496,496,61,1,'prepozna in doživi pravljico in realistično pripoved,'),(497,497,61,1,'Prepozna in doživi pravljico. Tvori lastne pravljice. Pripoveduje strnjeno pravljično dogajanje,v katerega je vključil elemente svoje domišljije.'),(498,498,61,1,'Pozna značilnosti pravljice. Zna tvoriti lastne pravljice. Loči domišljijski in realni svet, vendar pri tem ni vedno zanesljiv.'),(499,499,61,1,'Pozna glavne značilnosti pravljice, a ima težave, ko jo loči od realistične pripovedi.'),(500,500,61,1,'zaznava in doživlja zvočnost pesmi,'),(501,501,61,1,'Pesem doživi. S posebej oblikovanim govorom ponazarja razpoloženje besedila.'),(502,502,61,1,'Doživlja zvočnost pesmi. Pri interpretaciji upošteva intonacijo.'),(503,503,61,1,'Ob spodbudi zaznava zvočnost pesmi. Težave ima pri razumevanju sporočila pesmi. Pesem deklamira, vendar premalo upošteva intonacijo.'),(504,504,61,1,'spozna prvine in značilnosti posameznega medija, pozna razlike med risanko in filmom.'),(505,505,61,1,'Spoznava značilnosti različnih medijev. Pozna značilnosti lutkovne predstave, risanke in otroškega filma.'),(506,506,61,1,'Spoznava značilnosti različnih medijev. Pozna razlike med risanko in filmom.'),(507,507,61,1,'Ob ogledu risanke ali otroškega filma spoznava značilnosti posameznega medija.'),(508,508,4,0,'Orientacija - opredeli položaj predmeta glede na sebe oz. na druge predmete,'),(509,509,4,0,'Opredeli položaj predmeta glede na sebe oz. na druge predmete.'),(510,510,4,0,'Opredeli položaj predmeta glede na sebe.'),(511,511,4,0,'S pomočjo opredeli položaj predmeta glede na sebe.'),(512,512,4,0,'Orientacija - se po navodilih premika po prostoru in na ravnini; navodilo tudi oblikuje.'),(513,513,4,0,'Orientacija -samostojno se po navodilih premika po prostoru in na ravnini; navodilo tudi oblikuje.'),(514,514,4,0,'Orientacija - samostojno se po navodilih premika po prostoru in na ravnini.'),(515,515,4,0,'Orientacija - s pomočjo se po navodilih premika po prostoru in na ravnini.'),(516,516,4,0,'Geometrijske oblike - prepozna osnovna geometrijska telesa in jih opiše z besedami iz svojega vsakdanjika,'),(517,517,4,0,'Geometrijske oblike - prepozna osnovna geometrijska telesa in jih opiše z besedami iz svojega vsakdanjika,'),(518,518,4,0,'Samostojno prepozna osnovna geometrijska telesa.'),(519,519,4,0,'Ob pomoči prepozna osnovna geometrijska telesa.'),(520,520,4,0,'Geometrijske oblike - prepozna geometrijske like (trikotnik, kvadrat, krog in pravokotnik) in jih poimenuje,'),(521,521,4,0,'Pravilno prepozna geometrijske like (trikotnik, kvadrat, krog in pravokotnik) in jih poimenuje.'),(522,522,4,0,'Občasno prepozna geometrijske like (trikotnik, kvadrat, krog in pravokotnik) in jih poimenuje.'),(523,523,4,0,'Z učiteljevo pomočjo prepozna geometrijske like (trikotnik, kvadrat, krog in pravokotnik) in jih poimenuje.'),(524,524,4,0,'Geometrijske oblike - prostoročno in s šablono riše črte ter like.'),(525,525,4,0,'Pravilno in natančno  prostoročno in s šablono riše črte ter like.'),(526,526,4,0,'Pravilno prostoročno in s šablono riše črte.'),(527,527,4,0,'Nenatančno prostoročno in s šablono riše črte ter like.'),(528,528,4,0,'Merjenje - primerja in ocenjuje (najkrajši, najdaljši, najtežji, najlažji, največja, najmanjša prostornina),'),(529,529,4,0,'Samostojno primerja in ocenjuje (najkrajši, najdaljši, najtežji, najlažji, največja, najmanjša prostornina).'),(530,530,4,0,'Ob spodbudi primerja in ocenjuje (najkrajši, najdaljši, najtežji, najlažji, največja, najmanjša prostornina).'),(531,531,4,0,'Z učiteljevo pomočjo primerja in ocenjuje (najkrajši, najdaljši, najtežji, najlažji, največja, najmanjša prostornina).'),(532,532,4,0,'Merjenje - izmeri dolžino z nestandardnimi enotami.'),(533,533,4,0,'Pravilno izmeri dolžino z nestandardnimi enotami.'),(534,534,4,0,'Ob pomoči  izmeri dolžino z nestandardnimi enotami.'),(535,535,5,0,'Naravna števila in število 0 - šteje do 20'),(536,536,5,0,'Naravna števila in število 0 - samostojno šteje do 20'),(537,537,5,0,'Naravna števila in število 0 - ob pomoči šteje do 20'),(538,538,5,0,'Naravna števila in število 0 - loči med glavnim in vrstilnim pomenom števila,'),(539,539,5,0,'Naravna števila in število 0 - loči med glavnim in vrstilnim pomenom števila.'),(540,540,5,0,'Naravna števila in število 0 - občasno loči med glavnim in vrstilnim pomenom števila.'),(541,541,5,0,'Naravna števila in število 0 -ne loči med glavnim in vrstilnim pomenom števila.'),(542,542,5,0,'Naravna števila in število 0 - uredi po velikosti množico naravnih števil do 20,'),(543,543,5,0,'Pravilno uredi po velikosti množico naravnih števil do 20,'),(544,544,5,0,'S pomočjo uredi po velikosti množico naravnih števil do 20,'),(545,545,5,0,'Ne zna urediti po velikosti množice naravnih števil do 20,'),(546,546,5,0,'Naravna števila in število 0 - določi predhodnik in naslednik danega števila,'),(547,547,5,0,'Zna določiti predhodnik in naslednik danega števila.'),(548,548,5,0,'S pomočjo določi predhodnik in naslednik danega števila.'),(549,549,5,0,'Ne zna določiti predhodnik in naslednik danega števila.'),(550,550,5,0,'Naravna števila in število 0 - prepozna, nadaljuje in oblikuje preprosta zaporedja,'),(551,551,5,0,'Samostojno prepozna, nadaljuje in oblikuje preprosta zaporedja.'),(552,552,5,0,'Občasno prepozna, nadaljuje in oblikuje preprosta zaporedja.'),(553,553,5,0,'Ob pomoči prepozna, nadaljuje in oblikuje preprosta zaporedja.'),(554,554,5,0,'Naravna števila in število 0 - primerja števila po velikosti: enako, večje, manjše.'),(555,555,5,0,'Pravilno primerja števila po velikosti: enako, večje, manjše.'),(556,556,5,0,'S pomočjo primerja števila po velikosti: enako, večje, manjše.'),(557,557,5,0,'Pri primerjanju števil po velikosti: enako, večje, manjše ima težave.'),(558,558,5,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 10 (tudi število 0),'),(559,559,5,0,'Pravilno sešteva in odšteva v množici naravnih števil do 10 (tudi število 0).'),(560,560,5,0,'Pravilno sešteva in odšteva v množici naravnih števil do 10.'),(561,561,5,0,'Pri seštevanju in odštevanju v množici naravnih števil do 10  ima težave.'),(562,562,5,0,'Računske operacije - uporabi računske operacije pri reševanju problemov.'),(563,563,5,0,'Zna uporabiti računske operacije pri reševanju problemov.'),(564,564,5,0,'Z učiteljevo pomočjo uporabi računske operacije pri reševanju problemov.'),(565,565,5,0,'Ne zna uporabiti računskih operacij pri reševanju problemov.'),(566,566,5,0,'Lastnosti operacij - ob konkretnih primerih ugotovi, da lahko vrstni red seštevancev zamenja.'),(567,567,5,0,'Ob konkretnih primerih ugotovi, da lahko vrstni red seštevancev zamenja.'),(568,568,5,0,'Ob konkretnih primerih še ne ugotovi, da lahko vrstni red seštevancev zamenja.'),(569,569,6,0,'razvršča predmete, telesa, like, števila,… po izbrani lastnosti,'),(570,570,6,0,'Samostojno razvršča predmete, telesa, like, števila,… po izbrani lastnosti.'),(571,571,6,0,'S pomočjo učitelja razvršča predmete, telesa, like, števila,… po izbrani lastnosti.'),(572,572,6,0,'Ne zna razvrščati predmetov, teles, likov, števil,… po izbrani lastnosti.'),(573,573,6,0,'odkrije in ubesedi lastnost, po kateri so bili predmeti, telesa, liki, števila, razvrščeni,'),(574,574,6,0,'Samostojno odkrije in ubesedi lastnost, po kateri so bili predmeti, telesa, liki, števila, razvrščeni.'),(575,575,6,0,'Občasno odkrije in ubesedi lastnost, po kateri so bili predmeti, telesa, liki, števila, razvrščeni.'),(576,576,6,0,'Z učiteljevo pomočjo odkrije lastnost, po kateri so bili predmeti, telesa, liki, števila, razvrščeni.'),(577,577,6,0,'razvrstitev predmetov (elementov) prikaže z različnimi diagrami (puščičnim, Carrollovim in drevesnim),'),(578,578,6,0,'Razvrstitev predmetov prikaže z različnimi diagrami (puščičnim, Carrollovim in drevesnim.'),(579,579,6,0,'Razvrstitev predmetov  s pomočjo prikaže z različnimi diagrami (puščičnim, Carrollovim in drevesnim).'),(580,580,6,0,'Razvrstitev predmetov še ne prikaže z različnimi diagrami (puščičnim, Carrollovim in drevesnim).'),(581,581,6,0,'uporablja izraze: večji, manjši, daljši, krajši, prej, potem,'),(582,582,6,0,'Pravilno uporablja izraze: večji, manjši, daljši, krajši, prej, potem.'),(583,583,6,0,'Občasno uporablja izraze: večji, manjši, daljši, krajši, prej, potem.'),(584,584,6,0,'Z učiteljevo pomočjo uporablja izraze: večji, manjši, daljši, krajši, prej, potem.'),(585,585,6,0,'zapiše odnos med predmeti in pojmi s puščičnim diagramom,'),(586,586,6,0,'Samostojno in pravilno zapiše odnos med predmeti in pojmi s puščičnim diagramom.'),(587,587,6,0,'Pravilno zapiše odnos med predmeti in pojmi s puščičnim diagramom.'),(588,588,6,0,'Samostojno še ne zapiše odnosa med predmeti in pojmi s puščičnim diagramom.'),(589,589,6,0,'uredi elemente po različnih kriterijih (od najdaljšega do najkrajšega, od največjega do najmanjšega).'),(590,590,6,0,'Samostojno uredi elemente po različnih kriterijih (od najdaljšega do najkrajšega, od največjega do najmanjšega).'),(591,591,6,0,'S pomočjo pravilno uredi elemente po različnih kriterijih (od najdaljšega do najkrajšega, od največjega do najmanjšega).'),(592,592,6,0,'Ob dodatni spodbudi uredi elemente po različnih kriterijih (od najdaljšega do najkrajšega, od največjega do najmanjšega).'),(593,593,6,0,'odkrije in ubesedi kriterije, po katerih so bili elementi urejeni,'),(594,594,6,0,'Samostojno odkrije in ubesedi kriterije, po katerih so bili elementi urejeni.'),(595,595,6,0,'S pomočjo učitelja odkrije in ubesedi kriterije, po katerih so bili elementi urejeni.'),(596,596,6,0,'prepozna, nadaljuje in oblikuje matematični vzorec.'),(597,597,6,0,'Pravilno prepozna, nadaljuje in oblikuje matematični vzorec.'),(598,598,6,0,'Samostojno prepozna, nadaljuje in oblikuje matematični vzorec.'),(599,599,6,0,'S pomočjo prepozna, nadaljuje in oblikuje matematični vzorec.'),(600,600,7,0,'Prikazi - predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci,'),(601,601,7,0,'Prikazi - predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci,'),(602,602,7,0,'S pomočjo predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci.'),(603,603,7,0,'S pomočjo predstavi preproste podatke s preglednico in figurnim prikazom.'),(604,604,7,0,'S pomočjo predstavi preproste podatke s preglednico.'),(605,605,7,0,'Prikazi - prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(606,606,7,0,'Pravilno prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(607,607,7,0,'S pomočjo prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(608,608,7,0,'S pomočjo prebere preprosto preglednico in figurni prikaz.'),(609,609,7,0,'S pomočjo prebere preprosto preglednico.'),(610,610,8,1,'opredeli položaj predmeta glede na sebe oziroma druge predmete in se pri opisu položajev pravilno izraža,'),(611,611,8,1,'Samostojno se orientira v prostoru in na ravnini. Pravilno opiše položaj predmetov.'),(612,612,8,1,'Orientira se v prostoru in na ravnini. Položaj predmetov opiše po svoji miselni shemi.'),(613,613,8,1,'V prostoru /ravnini se orientira glede na sebe; težave ima pri orientaciji na izbrani predmet. Pri opisu položaja predmetov se ne izraža natančno.'),(614,614,8,1,'V prostoru /ravnini se orientira s pomočjo učitelja. Pri opisu položaja ima težave; ne loči levo-desno.'),(615,615,8,1,'Samostojno se orientira v prostoru in na ravnini. Pravilno opiše položaj predmetov.'),(616,616,8,1,'v svoji okolici prepozna osnovna geometrijska telesa: kroglo, valj, kocko in kvader ter jih opiše,'),(617,617,8,1,'V svojem okolju prepozna osnovna geometrijska telesa, jih opiše, razvrsti in uredi. Geometrijska telesa poimenuje v matematičnem jeziku.'),(618,618,8,1,'Geometrijska telesa prepozna, opiše in uredi. Nekatera geom. telesa  poimenuje z besedami iz svojega okolja, nekatera v matem. jeziku.'),(619,619,8,1,'Prepozna geometrijska telesa. Opiše jih z besedami iz svojega okolja.'),(620,620,8,1,'Prepozna nekatera geometrijska telesa. Nekatera geometrijska telesa opiše z besedami iz svojega okolja'),(621,621,8,1,'Ne prepozna geometrijskih teles. Geometrijskih teles ne opiše.'),(622,622,8,1,'prepozna in poimenuje like: trikotnik, kvadrat, krog in pravokotnik: like in črte nariše prostoročno in s šablono,'),(623,623,8,1,'Poimenuje in samostojno opiše kvadrat, trikotnik, pravokotnik, krog.'),(624,624,8,1,'Poimenuje in opiše kvadrat, trikotnik, pravokotnik, krog.'),(625,625,8,1,'Prepozna geometrijske like.'),(626,626,8,1,'Prepoznava geometrijske like, a nekatere zamenjuje.'),(627,627,8,1,'Ne prepozna geometrijskih likov (prepozna – npr. krog).'),(628,628,8,1,'šteje do 20,'),(629,629,8,1,'Šteje, bere in zapiše števila do 20.'),(630,630,8,1,'Šteje, bere in zapiše števila do 20, a občasno zamenjuje števke.'),(631,631,8,1,'Šteje in bere števila do 20, nekatera tudi zapiše.'),(632,632,8,1,'Šteje do 10 in zapiše nekatera števila.'),(633,633,8,1,'Šteje do 10, števil ne zapiše.'),(634,634,8,1,'sešteva in odšteva v množici naravnih števil do 10,'),(635,635,8,1,'Na simbolnem nivoju sešteva in odšteva števila do 10.'),(636,636,8,1,'Sešteva in odšteva do 10 s pomočjo slikovnega materiala.'),(637,637,8,1,'Sešteva in odšteva do 10 s pomočjo konkretnega materiala.'),(638,638,8,1,'S pomočjo učitelja in konkretnega materiala sešteva (vendar ne zmore odštevati) do 10.'),(639,639,8,1,'Ne sešteva niti odšteva (zmore npr. do 5).'),(640,640,8,1,'razvrsti predmete, telesa, like, števila po dani lastnosti: razvrstitev prikaže z diagramom.'),(641,641,8,1,'Razvrsti telesa,... po svoji lastnosti (določi svoj kriterij). Razvrstitev prikaže z različnimi oblikami prikazov.'),(642,642,8,1,'Razvrsti predmete,... po dani lastnosti in ugotovi kriterij. Razvrstitev prikaže z nekaterimi oblikami prikazov (npr. stolpci).'),(643,643,8,1,'Razvršča like,... po dani lastnosti. Kriterij razvrščanja ugotovi s pomočjo učitelja. Ob pomoči prikaže razvrstitev s stolpci.'),(644,644,8,1,'Razvršča določene predmete ob pomoči učitelja Ne prikaže razvrstitve.'),(645,645,33,0,'Orientacija v prostoru - opredeli položaj predmeta glede na sebe oz. glede na druge predmete in se pri poimenovanje položajev pravilno izraža (nad/pod, zgoraj/spodaj, desno/levo),'),(646,646,33,0,'Orientacija v prostoru - samostojno opredeli položaj predmeta glede na sebe oz. glede na druge predmete in to pravilno poimenuje.'),(647,647,33,0,'Orientacija v prostoru - samostojno opredeli položaj predmeta glede na sebe oz. glede na druge predmete in to ob pomoči poimenuje.'),(648,648,33,0,'Orientacija v prostoru - ob pomoči opredeli položaj predmeta glede na sebe oz. glede na druge predmete in to s težavo poimenuje.'),(649,649,33,0,'Orientacija v prostoru - po navodilih se premika po prostoru in na ravnini (na listu papirja) ter navodilo tudi oblikuje.'),(650,650,33,0,'Orientacija v prostoru - po navodilih se samostojno premika po prostoru in na ravnini (na listu papirja) ter navodilo tudi oblikuje.'),(651,651,33,0,'Orientacija v prostoru - po navodilih se samostojno premika po prostoru in na ravnini (na listu papirja).'),(652,652,33,0,'Orientacija v prostoru - po navodilih se  ob pomoči premika po prostoru in na ravnini (na listu papirja).'),(653,653,33,0,'Geometrijske oblike - prepozna in poimenuje preprosta geometrijska telesa (krogla, valj, kvader, kocka) in geometrijske like (krog, trikotnik, pravokotnik, kvadrat),'),(654,654,33,0,'Geometrijske oblike - samostojno  prepozna in poimenuje preprosta geometrijska telesa  in geometrijske like.'),(655,655,33,0,'Geometrijske oblike - občasno  prepozna in poimenuje preprosta geometrijska telesa  in geometrijske like.'),(656,656,33,0,'Geometrijske oblike - ob pomoči prepozna in poimenuje preprosta geometrijska telesa  in geometrijske like.'),(657,657,33,0,'Geometrijske oblike - prepozna in nariše različne črte (ravne, krive, sklenjene, nesklenjene),'),(658,658,33,0,'Geometrijske oblike - samostojno prepozna in nariše različne črte (ravne, krive, sklenjene, nesklenjene).'),(659,659,33,0,'Geometrijske oblike - ob pomoči prepozna in nariše različne črte (ravne, krive, sklenjene, nesklenjene).'),(660,660,33,0,'Geometrijske oblike - ob pomoči prepozna in nariše različne črte (ravne, krive, sklenjene, nesklenjene).'),(661,661,33,0,'Geometrijske oblike - označi presečišče črt z veliko tiskano črko (točko).'),(662,662,33,0,'Geometrijske oblike -občasno označi presečišče črt z veliko tiskano črko (točko).'),(663,663,33,0,'Geometrijske oblike - nariše in označi točko z veliko tiskano črko.'),(664,664,33,0,'Geometrijske oblike - nariše in označi točko z veliko tiskano črko.'),(665,665,33,0,'Geometrijske oblike - občasno nariše in označi točko z veliko tiskano črko.'),(666,666,33,0,'Transformacije - prepozna simetrijo pri predmetih v svoji okolici,'),(667,667,33,0,'Transformacije - ne prepozna simetrijo pri predmetih v svoji okolici.'),(668,668,33,0,'Transformacije - izdela simetrične oblike z odtisi in s prepogibanjem ter simetrijo grafično prikaže (pobarva in nariše s pomočjo mreže).'),(669,669,33,0,'Transformacije -samostojno izdela simetrične oblike z odtisi in s prepogibanjem ter simetrijo grafično prikaže (pobarva in nariše s pomočjo mreže).'),(670,670,33,0,'Transformacije - občasno izdela simetrične oblike z odtisi in s prepogibanjem ter simetrijo grafično prikaže (pobarva in nariše s pomočjo mreže).'),(671,671,33,0,'Transformacije -ob pomoči izdela simetrične oblike z odtisi in s prepogibanjem ter simetrijo grafično prikaže (pobarva in nariše s pomočjo mreže).'),(672,672,33,0,'Uporaba geometrijskega orodja - potegne črte ob ravnilu,'),(673,673,33,0,'Uporaba geometrijskega orodja - samostojno potegne črte ob ravnilu.'),(674,674,33,0,'Uporaba geometrijskega orodja - s težavo potegne črte ob ravnilu.'),(675,675,33,0,'Uporaba geometrijskega orodja - s šablono riše like.'),(676,676,33,0,'Merjenje - oceni in izmeri dolžino z nestandardno (izbrano) enoto in s standardnimi enotami m, dm, cm,'),(677,677,33,0,'Merjenje - oceni in izmeri dolžino z nestandardno (izbrano) enoto in s standardnimi enotami m, dm, cm.'),(678,678,33,0,'Merjenje - oceni dolžino z nestandardno (izbrano) enoto in s standardnimi enotami m, dm, cm.'),(679,679,33,0,'Merjenje -  izmeri dolžino z nestandardno (izbrano) enoto in s standardnimi enotami m, dm, cm.'),(680,680,33,0,'Merjenje - izmeri maso z nestandardno in standardno enoto (kg),'),(681,681,33,0,'Merjenje -samostojno izmeri maso z nestandardno in standardno enoto (kg),'),(682,682,33,0,'Merjenje - s pomočjo izmeri maso z nestandardno in standardno enoto (kg),'),(683,683,33,0,'Merjenje - zapiše meritev z merskim številom in enoto (denar, masa, dolžina),'),(684,684,33,0,'Merjenje - samostojno zapiše meritev z merskim številom in enoto (denar, masa, dolžina).'),(685,685,33,0,'Merjenje -občasno zapiše meritev z merskim številom in enoto (denar, masa, dolžina).'),(686,686,33,0,'Merjenje -s pomočjo zapiše meritev z merskim številom in enoto (denar, masa, dolžina).'),(687,687,33,0,'Merjenje - sešteva in odšteva količine enakih enot (denar, masa, dolžina).'),(688,688,33,0,'Merjenje - samostojno in pravilno sešteva in odšteva količine enakih enot (denar, masa, dolžina).'),(689,689,33,0,'Merjenje - z učiteljevo pomočjo sešteva in odšteva količine enakih enot (denar, masa, dolžina).'),(690,690,33,0,'Merjenje -  z napakami sešteva in odšteva količine enakih enot (denar, masa, dolžina).'),(691,691,34,0,'razvrsti predmete, telesa, like, števila po največ dveh lastnostih,'),(692,692,34,0,'Samostojno razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(693,693,34,0,'Občasno razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(694,694,34,0,'Ob pomoči razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(695,695,34,0,'odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni,'),(696,696,34,0,'Brez težav odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(697,697,34,0,'Z učiteljevo pomočjo odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(698,698,34,0,'Počasi in s pomočjo odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(699,699,34,0,'prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(700,700,34,0,'Samostojno prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(701,701,34,0,'Občasno prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(702,702,34,0,'Ob pomoči prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(703,703,35,0,'predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci,'),(704,704,35,0,'Samostojno  in pravilno predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci.'),(705,705,35,0,'Občasno pravilno predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci.'),(706,706,35,0,'Ob pomoči in premalo natančno predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci.'),(707,707,35,0,'prebere preprosto preglednico, figurni prikaz in prikaz s stolpci,'),(708,708,35,0,'Pravilno prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(709,709,35,0,'Pogosto pravilno prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(710,710,35,0,'Le ob pomoči prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(711,711,35,0,'zbere in uredi podatke ter jih pregledno predstavi in prebere,'),(712,712,35,0,'Samostojno in pravilno zbere in uredi podatke ter jih pregledno predstavi in prebere.'),(713,713,35,0,'Občasno že samostojno zbere in uredi podatke ter jih pregledno predstavi in prebere.'),(714,714,35,0,'Samostojno še ne zbere in uredi podatke ter jih pregledno predstavi in prebere.'),(715,715,35,0,'nastavi in prešteje vse možne izide pri najpreprostejših kombinatornih situacijah (poišče razporedbe največ treh različnih predmetov).'),(716,716,35,0,'Samostojno nastavi in prešteje vse možne izide pri najpreprostejših kombinatornih situacijah (poišče razporedbe največ treh različnih predmetov).'),(717,717,35,0,'Ob pomoči nastavi in prešteje vse možne izide pri najpreprostejših kombinatornih situacijah (poišče razporedbe največ treh različnih predmetov).'),(718,718,35,0,'Napačno nastavi in prešteje vse možne izide pri najpreprostejših kombinatornih situacijah (poišče razporedbe največ treh različnih predmetov).'),(719,719,36,0,'Naravna števila - šteje, piše in bere števila do 100,'),(720,720,36,0,'Naravna števila - samostojno in pravilno šteje, piše in bere števila do 100.'),(721,721,36,0,'Naravna števila - pravilno šteje in  bere števila do 100.'),(722,722,36,0,'Naravna števila -  pravilno šteje,  ob pomoči pa piše in bere števila do 100.'),(723,723,36,0,'Naravna števila - razlikuje desetiške enote (enice, desetice),'),(724,724,36,0,'Naravna števila - razlikuje desetiške enote (enice, desetice).'),(725,725,36,0,'Naravna števila -  desetiške enote (enice, desetice) še zamenjuje.'),(726,726,36,0,'Naravna števila - uredi po velikosti množico naravnih števil do 100,'),(727,727,36,0,'Naravna števila -  pravilno uredi po velikosti množico naravnih števil do 100.'),(728,728,36,0,'Naravna števila -  s pomočjo uredi po velikosti množico naravnih števil do 100.'),(729,729,36,0,'Naravna števila -ne zmore še  urediti po velikosti množice naravnih števil do 100.'),(730,730,36,0,'Naravna števila - določi predhodnik in naslednik danega števila,'),(731,731,36,0,'Naravna števila - samostojno in pravilno določi predhodnik in naslednik danega števila.'),(732,732,36,0,'Naravna števila - ob pomoči določi predhodnik in naslednik danega števila.'),(733,733,36,0,'Naravna števila - oblikuje in nadaljuje preprosto zaporedje števil,'),(734,734,36,0,'Naravna števila - samostojno oblikuje in nadaljuje preprosto zaporedje števil.'),(735,735,36,0,'Naravna števila - občasno oblikuje in nadaljuje preprosto zaporedje števil.'),(736,736,36,0,'Naravna števila - z učiteljevo pomočjo oblikuje in nadaljuje preprosto zaporedje števil.'),(737,737,36,0,'Naravna števila - zapiše odnose med števili (<, >,=).'),(738,738,36,0,'Naravna števila -  samostojno in pravilno zapiše odnose med števili (<, >,=).'),(739,739,36,0,'Naravna števila -  ob pomoči zapiše odnose med števili (<, >,=).'),(740,740,36,0,'Naravna števila - z napakami zapiše odnose med števili (<, >,=).'),(741,741,36,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice),'),(742,742,36,0,'Računske operacije -  pravilno sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice).'),(743,743,36,0,'Računske operacije -z napakami  sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice).'),(744,744,36,0,'Računske operacije - s ponazorili sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice).'),(745,745,36,0,'Računske operacije -  s pogostimi napakami sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice).'),(746,746,36,0,'Računske operacije -  pravilno sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice).'),(747,747,36,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 100 (braz prehoda),'),(748,748,36,0,'Računske operacije - pravilno sešteva in odšteva v množici naravnih števil do 100 (brez prehoda).'),(749,749,36,0,'Računske operacije - z napakami sešteva in odšteva v množici naravnih števil do 100 (brez prehoda).'),(750,750,36,0,'Računske operacije -  s ponazorili sešteva in odšteva v množici naravnih števil do 100 (brez prehoda).'),(751,751,36,0,'Računske operacije - s pogostimi napakami sešteva in odšteva v množici naravnih števil do 100 (brez prehoda).'),(752,752,36,0,'Računske operacije - na konkretnem nivoju uporablja zakon o zamenjavi pri seštevanju v obsegu do 20,'),(753,753,36,0,'Računske operacije - na konkretnem nivoju  pravilno uporablja zakon o zamenjavi pri seštevanju v obsegu do 20.'),(754,754,36,0,'Računske operacije - na konkretnem nivoju ob pomoči uporablja zakon o zamenjavi pri seštevanju v obsegu do 20.'),(755,755,36,0,'Računske operacije - na konkretnem nivoju še ne  uporablja zakon o zamenjavi pri seštevanju v obsegu do 20.'),(756,756,36,0,'Računske operacije - v obsegu do 20 rešuje preproste enačbe a ± ? = b, ? ± a = b (poišče manjkajoči člen),'),(757,757,36,0,'Računske operacije - v obsegu do 20  samostojno in pravilno rešuje preproste enačbe (poišče manjkajoči člen).'),(758,758,36,0,'Računske operacije - v obsegu do 20 s pomočjo pravilno rešuje preproste enačbe  (poišče manjkajoči člen).'),(759,759,36,0,'Računske operacije - v obsegu do 20  s pomočjo in še z napakami rešuje preproste enačbe (poišče manjkajoči člen).'),(760,760,36,0,'Računske operacije - množi na konkretnem nivoju (s konkretnim materialom),'),(761,761,36,0,'Računske operacije - samostojno  množi na konkretnem nivoju (s konkretnim materialom).'),(762,762,36,0,'Računske operacije - z učiteljevo pomočjo množi na konkretnem nivoju (s konkretnim materialom).'),(763,763,36,0,'Računske operacije - zapiše vsoto enakih seštevancev v obliki produkta,'),(764,764,36,0,'Računske operacije -  samostojno zapiše vsoto enakih seštevancev v obliki produkta.'),(765,765,36,0,'Računske operacije -  občasno zapiše vsoto enakih seštevancev v obliki produkta.'),(766,766,36,0,'Računske operacije - ob pomoči zapiše vsoto enakih seštevancev v obliki produkta.'),(767,767,36,0,'Računske operacije - deli na konkretnem nivoju (s konkretnim materialom),'),(768,768,36,0,'Računske operacije -pravilno in samostojno  deli na konkretnem nivoju (s konkretnim materialom).'),(769,769,36,0,'Računske operacije -pravilno ob pomoči deli na konkretnem nivoju (s konkretnim materialom).'),(770,770,36,0,'Računske operacije - še ne deli na konkretnem nivoju (s konkretnim materialom).'),(771,771,36,0,'Računske operacije - pri reševanju problemov uporablja računske operacije.'),(772,772,36,0,'Računske operacije - pri reševanju problemov samostojno  uporablja računske operacije.'),(773,773,36,0,'Računske operacije - pri reševanju problemov občasno že uporablja računske operacije.'),(774,774,36,0,'Računske operacije - pri reševanju problemov samostojno še ne  uporablja računskih operacij.'),(775,775,36,0,'Lastnosti operacij - na konkretnem nivoju uporablja zakon o zamenjavi pri seštevanju,'),(776,776,36,0,'Lastnosti operacij - na konkretnem nivoju pravilno  uporablja zakon o zamenjavi pri seštevanju,'),(777,777,36,0,'Lastnosti operacij - na konkretnem nivoju občasno uporablja zakon o zamenjavi pri seštevanju,'),(778,778,36,0,'Lastnosti operacij - na konkretnem nivoju ob pomoči uporablja zakon o zamenjavi pri seštevanju,'),(779,779,36,0,'Lastnosti operacij - na konkretnem nivoju razume, da sta seštevanje in odštevanje nasprotni operaciji.'),(780,780,36,0,'Lastnosti operacij - na konkretnem nivoju  pravilno razume, da sta seštevanje in odštevanje nasprotni operaciji.'),(781,781,36,0,'Lastnosti operacij - na konkretnem nivoju s pomočjo  razume, da sta seštevanje in odštevanje nasprotni operaciji.'),(782,782,36,0,'Lastnosti operacij - na konkretnem nivoju še ne  razume, da sta seštevanje in odštevanje nasprotni operaciji.'),(783,783,37,1,'opredeli položaj predmeta v prostoru ter na ravnini in se po navodilih premika po prostoru in na ravnini (na listu),'),(784,784,37,1,'Razume navodila se orientira v prostoru in na ravnini. Pravilno opiše položaj predmeta. Oblikuje navodila za premikanje.'),(785,785,37,1,'V prostoru in na ravnini se delno orientira. Pri opisu položaja predmeta je premalo natančen.'),(786,786,37,1,'V prostoru in na ravnini se orientira ob pomoči. Menja še pojma levo-desno.'),(787,787,37,1,'prepozna, poimenuje in opiše osnovna geometrijska telesa in like,'),(788,788,37,1,'Poimenuje, opiše, razvrsti in uredi geometrijska telesa in like.'),(789,789,37,1,'Prepozna, delno opiše,  razvrsti in uredi geometrijska telesa in like.'),(790,790,37,1,'Prepozna nekatera geometrijska telesa in like. Razvrsti jih ob pomoči.'),(791,791,37,1,'oceni in izmeri dolžino z nestandardno in standardno enoto ter meritev zapiše z merskim številom in mersko enoto,'),(792,792,37,1,'Oceni in izmeri dolžino ter jo zapiše z merskim številom in mersko enoto.'),(793,793,37,1,'Izmeri dolžino in uporabi ustrezno mersko enoto.'),(794,794,37,1,'Meri dane dolžine. Pozabi mersko enoto ali jo zamenja.'),(795,795,37,1,'sešteva in odšteva v množici naravnih števil do 20,'),(796,796,37,1,'Sešteva in odšteva v množici naravnih števil do 20 s prehodom. Rešuje račune z dopolnjevanjem in zahtevnejše besedilne naloge.'),(797,797,37,1,'Sešteva in odšteva do 20 s prehodom. Pri dopolnjevanju računov se včasih zmoti. Rešuje enostavne besedilne naloge.'),(798,798,37,1,'Sešteva in odšteva do 20 s prehodom na konkreten način. Pri računanju se včasih zmoti. Pri dopolnjevanju računov in reševanju enostavnih besedilnih na'),(799,799,37,1,'šteje, zapiše in bere števila do 100,'),(800,800,37,1,'Šteje, bere, zapiše in uredi števila do 100. Razlikuje D in E.'),(801,801,37,1,'Šteje, bere in zapiše števila do 100. Primerja števila.'),(802,802,37,1,'Šteje, bere, a pri zapisu zamenjuje   števke števil do 100.'),(803,803,37,1,'sešteva in odšteva v množici naravnih števil do 100 (brez prehoda),'),(804,804,37,1,'Sešteva, odšteva in rešuje račune z dopolnjevanjem v množici nar. števil do 100 brez prehoda. Rešuje tudi zahtevnejše besedilne naloge'),(805,805,37,1,'Sešteva in odšteva do 100 brez prehoda in rešuje enostavne besedilne naloge.'),(806,806,37,1,'Sešteva in odšteva do 100 brez prehoda. Pri računanju se večkrat zmoti. Pri reševanju enostavnih besedilnih nalog potrebuje pomoč.'),(807,807,37,1,'razvrsti in opiše kriterije razvrščanja ter razvrstitev prikaže z različnimi diagrami,'),(808,808,37,1,'Razvršča like, predmete po danem kriteriju. Utemelji kriterij razvrščanja in razvrstitev prikaže z različnimi diagrami.'),(809,809,37,1,'Razvršča telesa, like po dveh lastnostih. Razvrstitev prikaže z diagramom.'),(810,810,37,1,'Ob pomoči razvršča in prikaže razvrstitev z diagramom.'),(811,811,37,1,'podatke prikaže s preglednico, figurnim prikazom in prikazom s stolpci ter jih tudi prebere.'),(812,812,37,1,'Zbere, uredi in prikaže podatke. Razloži prikaze.'),(813,813,37,1,'Zbere, uredi in prikaže podatke.'),(814,814,37,1,'Zbrane podatke prikaže.'),(815,815,62,0,'Orientacija v prostoru - bere preproste zemljevide (v obliki mreže),'),(816,816,62,0,'Bere preproste zemljevide v obliki mreže.'),(817,817,62,0,'Bere preproste zemljevide v obliki mreže, a ima še nekaj težav.'),(818,818,62,0,'Ob pomoči učitelja, bere preproste zemljevide v obliki mreže.'),(819,819,62,0,'Orientacija v prostoru - opredeli položaj predmeta glede na sebe oz. druge predmete in se pri opisu pravilno izraža,'),(820,820,62,0,'Opredeli položaj predmeta glede na sebe oz. druge predmete in se pri opisu pravilno izraža.'),(821,821,62,0,'Opredeli položaj predmeta glede na sebe oz. druge predmete, a ima še nekaj težav pri izražanju.'),(822,822,62,0,'Ob pomoči učitelja  opredeli položaj predmeta glede na sebe oz. druge predmete. Tudi pri izražanju potrebuje pomoč.'),(823,823,62,0,'Orientacija v prostoru - po navodilih se premika po prostoru in na ravnini (na listu papirja) ter navodilo oblikuje.'),(824,824,62,0,'Po navodilih se premika po prostoru in na ravnini (na listu papirja) ter navodilo oblikuje.'),(825,825,62,0,'Po navodilih se premika po prostoru in na ravnini (na listu papirja), a ima težave z oblikovanjem navodila.'),(826,826,62,0,'Ob pomoči se premika po prostoru in na ravnini (na listu papirja) in ima težave z oblikovanjem navodil.'),(827,827,62,0,'Geometrijske oblike - nariše večkotnik, označi oglišča in stranice ter večkotnik poimenuje,'),(828,828,62,0,'Nariše večkotnik, označi oglišča in stranice ter večkotnik poimenuje.'),(829,829,62,0,'Nariše večkotnik, označi oglišča in stranice ter večkotnik poimenuje,a še dela napake.'),(830,830,62,0,'Ob učiteljevi pomoči nariše večkotnik, označi oglišča in stranice ter večkotnik poimenuje.'),(831,831,62,0,'Geometrijske oblike - prepozna in nariše skladne like,'),(832,832,62,0,'Prepozna in nariše skladne like'),(833,833,62,0,'Prepozna in nariše skladne like, a se občasno še zmoti.'),(834,834,62,0,'S pomočjo aplikacij prepozna in nariše skladne like.'),(835,835,62,0,'Geometrijske oblike - prepozna in poimenuje geometrijska telesa; pri opisovanju modelov geometrijskih teles uporablja matematični jezik (ploskev, rob, oglišče).'),(836,836,62,0,'Prepozna in poimenuje geometrijskega telesa; pri opisovanju modelov geometrijskih teles uporablja matematični jezik.'),(837,837,62,0,'Prepozna in poimenuje geometrijsko telo; težave ima pri uporabi matematičnih izrazov.'),(838,838,62,0,'Prepozna  geometrijska telesa, a ima težave s poimenovanjem in opisovanjem ter uporabo matematičnega jezika.'),(839,839,62,0,'Transformacije - prepozna simetrijo pri predmetih v okolici in pri likih,'),(840,840,62,0,'Prepozna simetrijo pri predmetih v okolici in pri likih.'),(841,841,62,0,'Prepozna simetrijo pri predmetih v okolici in pri likih, a se občasno še zmoti.'),(842,842,62,0,'Težko prepozna simetrijo pri predmetih v okolici in pri likih.'),(843,843,62,0,'Transformacije - nariše simetrični lik s pomočjo mreže.'),(844,844,62,0,'Nariše simetričen lik s pomočjo mreže.'),(845,845,62,0,'Pri risanju simetričnega lika s pomočjo mreže ima še nekaj težav.'),(846,846,62,0,'Z veliko napakami nariše simetričen lik s pomočjo mreže.'),(847,847,62,0,'Merjenje - meri s standardnimi in  nestandardnimi enotami (dolžino: m, dm, cm; maso: kg, dag; prostornino: l, dl),'),(848,848,62,0,'Meri s standardnimi in nestandardnimi enotami (dolžimo, maso in prostornino)'),(849,849,62,0,'Meri s standardnimi in nestandardnimi enotami (dolžino, maso in prostornino), a ima ob tem še nekaj težav.'),(850,850,62,0,'Ob pomoči učitelja  meri s standardnimi in nestandardnimi enotami dolžino maso in prostornino.'),(851,851,62,0,'Merjenje - oceni, primerja, meri in zapiše meritev z merskim številom in enoto,'),(852,852,62,0,'Oceni, primerja, meri in zapiše meritev z merskim številom in enoto.'),(853,853,62,0,'Oceni, primerja, meri in zapiše meritev z merskim številom in enoto, a se občasno še zmoti.'),(854,854,62,0,'S težavami oceni, meri in zapiše meritev z merskim številom in enoto.'),(855,855,62,0,'Merjenje - računa s količinami enakih merskih enot.'),(856,856,62,0,'Računa s količinami enakih merskih enot.'),(857,857,62,0,'Računa s količinami enakih merskih enot, a se občasno še zmoti.'),(858,858,62,0,'Pri računanju s količinami enakih merskih enot ima še težave.'),(859,859,63,0,'Naravna števila - šteje, zapisuje in bere števila do 1000 (;,:,=),'),(860,860,63,0,'Šteje,zapisuje in bere števila do 1000.'),(861,861,63,0,'Šteje, zapisuje in bere števila do 1000, a se občasno še zmoti.'),(862,862,63,0,'S pomočjo aplikacij šteje, zapisuje in bere števila do 1000.'),(863,863,63,0,'Naravna števila - razlikuje desetiške enote (E, D, S),'),(864,864,63,0,'Razlikuje desetiške enote (E,D,S)'),(865,865,63,0,'Desetiške enote razlikuje (E,D,S), a občasno se še zmoti'),(866,866,63,0,'S pomočjo aplikacij razlikuje desetiške enote (E,D,S)'),(867,867,63,0,'Naravna števila - uredi po velikosti naravna števila do 1000,'),(868,868,63,0,'Uredi po velikosti naravna števila do 1000.'),(869,869,63,0,'Uredi po velikosti naravna števila do 1000, a ima še nekaj težav.'),(870,870,63,0,'Ob učiteljevi pomoči uredi po velikosti naravna števila do 1000.'),(871,871,63,0,'Naravna števila - določi predhodnik in naslednik števila,'),(872,872,63,0,'Določi predhodnik in naslednik števila.'),(873,873,63,0,'Določi predhodnik in naslednik števila, a se občasno še zmoti'),(874,874,63,0,'S pomočjo aplikacij določa predhodnik in naslednik števila.'),(875,875,63,0,'Naravna števila - nadaljuje in oblikuje preprosto zaporedje števil,'),(876,876,63,0,'Nadaljuje in oblikuje preprosto zaporedje števil.'),(877,877,63,0,'Nadaljuje in oblikuje preprosto zaporedje števil, a se občasno še zmoti.'),(878,878,63,0,'Ob učiteljevi pomoči nadaljuje in oblikuje preprosto zaporedje števil.'),(879,879,63,0,'Naravna števila - razlikuje soda in liha števila.'),(880,880,63,0,'Razlikuje soda in liha števila.'),(881,881,63,0,'Razlikuje soda in liha števila, a se še zmoti.'),(882,882,63,0,'Še ne razlikuje sodih in lihih števila.'),(883,883,63,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 100 (s prehodom),'),(884,884,63,0,'Sešteva in odšteva v množici naravnih števil do 100 s prehodom.'),(885,885,63,0,'Sešteva in odšteva v množici naravnih števil do 100 s prehodom,a se še zmoti.'),(886,886,63,0,'S pomočjo aplikacij sešteva in odšteva v množici naravnih števil do 100 s prehodom.'),(887,887,63,0,'Računske operacije - sešteva in odšteva naravna števila do 1000 (brez prehoda),'),(888,888,63,0,'Sešteva in odšteva naravna števila do 1000 brez prehoda.'),(889,889,63,0,'Sešteva in odšteva naravna števila do 1000 brez prehoda, a se občasno še zmoti.'),(890,890,63,0,'S pomočjo aplikacij sešteva in odšteva naravna števila do 1000 brez prehoda.'),(891,891,63,0,'Računske operacije - usvoji do avtomatizma produkte v obsegu do 10x10 (poštevanka),'),(892,892,63,0,'Usvoji do avtomatizma produkte v obsegu 10x10.'),(893,893,63,0,'Usvoji do avtomatizma produkte v obsegu 10x10, a se občasno še zmoti.'),(894,894,63,0,'Še ni avtomatiziral produkte v obsegu 10x10.'),(895,895,63,0,'Računske operacije - pozna pojem večkratnik števila,'),(896,896,63,0,'Pozna pojem večkratnik števila.'),(897,897,63,0,'Pozna pojem večkratnik števila, a se še zmoti.'),(898,898,63,0,'Še ne  pozna pojem večkratnik števila.'),(899,899,63,0,'Računske operacije - pozna pojem količnik,'),(900,900,63,0,'Pozna pojem količnik.'),(901,901,63,0,'Pozna pojem količnik, a se še zmoti.'),(902,902,63,0,'Še ne pozna pojma količnik.'),(903,903,63,0,'Računske operacije - pozna količnike, ki so vezani na poštevanko,'),(904,904,63,0,'Pozna količnike, ki so vezani na poštevanko.'),(905,905,63,0,'Pozna količnike, ki so vezani na poštevanko, a se še zmoti.'),(906,906,63,0,'Še ne pozna  količnikov, ki so vezani na poštevanko.'),(907,907,63,0,'Računske operacije - ugotovi, da sta množenje in deljenje obratni računski operaciji,'),(908,908,63,0,'Ugotovi, da sta množenje in deljenje obratni računski operaciji.'),(909,909,63,0,'S težavo ugotovi, da sta množenje in deljenje obratni računski operaciji.'),(910,910,63,0,'Še ni ugotovil, da sta množenje in deljenje obratni računski operaciji.'),(911,911,63,0,'Računske operacije - pri reševanju problemov uporablja računske operacije,'),(912,912,63,0,'Pri reševanju problemov uporablja računske operacije.'),(913,913,63,0,'Pri reševanju problemov uporablja računske operacije, a se še zmoti.'),(914,914,63,0,'Rešuje le lažje računske probleme.'),(915,915,63,0,'Računske operacije - oceni število predmetov.'),(916,916,63,0,'Oceni število predmetov.'),(917,917,63,0,'Pri ocenitvi predmetov ima še nekaj težav.'),(918,918,63,0,'Lastnosti operacij - pozna vlogo števil 0 in 1 pri množenju in deljenju s konkretnim materialom.'),(919,919,63,0,'Pozna vlogo števil 0 in1 pri množenju in deljenju s konkretnim materialom.'),(920,920,63,0,'Pozna vlogo števil 0 in 1 pri množenju in deljenju s konkretnim materialom, a se še zmoti.'),(921,921,63,0,'S pomočjo aplikacij pozna vlogo števil 0 in 1 pri množenju in deljenju s konkretnim materialom.'),(922,922,63,0,'Številski izrazi - izračuna vrednost številskega izraza z upoštevanjem vrstnega reda računskih operacij: 5 + 3 x 4 = ____ , 3 + 4 x 5 = ____ .'),(923,923,63,0,'Izračuna vrednost številskega izraza z upoštevanjem vrstnega reda računskih operacij.'),(924,924,63,0,'Izračuna vrednost številskega izraza z upoštevanjem vrstnega reda računskih operacij, a se občasno še zmoti.'),(925,925,63,0,'Z velikimi težavami izračuna vrednost izraza z upoštevanjem vrstnega reda računskih operacij,a se še zmoti.'),(926,926,63,0,'Racionalna števila - deli celoto na enake dele (na modelu in sliki določi polovico, tretjino…)'),(927,927,63,0,'Deli celoto na enake dele.'),(928,928,63,0,'Deli celoto na enake dele, a se še zmoti.'),(929,929,63,0,'S pomočjo aplikacij deli celoto na enake dele.'),(930,930,64,0,'Prikazi - predstavi preproste podatke s preglednico, s figurnim prikazom in prikazom s stolpci,'),(931,931,64,0,'Predstavi preproste podatke s preglednico, s figurnim prikazom in prikazom s stolpci.'),(932,932,64,0,'Pri predstavitvi preprostih podatkov s preglednico,s figurnim prikazom in prikazom s stolpci ima še nekaj težav.'),(933,933,64,0,'Še ne predstavi preprostih podatkov.'),(934,934,64,0,'Prikazi - prebere preprosto preglednico, figurni prikaz in prikaz s stolpci,'),(935,935,64,0,'Prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(936,936,64,0,'Ob pomoči prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(937,937,64,0,'Prikazi - reši preprost problem, ki zahteva, da učenka/učenec zbere in uredi podatke ter jih predstavi in prebere.'),(938,938,64,0,'Samostojno reši preprost problem, ki zahteva, da zbere in uredi podatke ter jih  predstavi in prebere.'),(939,939,64,0,'Ob pomoči reši preprost problem, ki zahteva, da zbere in uredi podatke ter jih predstavi in prebere.'),(940,940,64,0,'Še ne reši preprostega problema, ki zahteva, da zbere in uredi podatke ter jih predstavi in prebere.'),(941,941,64,0,'Kombinatorične situacije - nastavi in prešteje vse možne izide pri preprostih kombinatoričnih situacijah.'),(942,942,64,0,'Samostojno nastavi in prešteje vse možne izide pri preprostih kombinatoričnih situacijah.'),(943,943,64,0,'Ob pomoči nastavi in prešteje vse možne izide pri preprostih kombinatoričnih situacijah.'),(944,944,64,0,'V kombinatoričnih situacijah prešteje vse izide, nastaviti pa jih ne zna.'),(945,945,65,0,'Logika in jezik - razvrsti predmete, telesa, like, števila po največ dveh lastnostih,'),(946,946,65,0,'Razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(947,947,65,0,'Ob pomoči razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(948,948,65,0,'Logika in jezik - odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni,'),(949,949,65,0,'Odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(950,950,65,0,'Ob pomoči odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(951,951,65,0,'Še ne odkrije in težko ubesedi lastnosti, po katerih so bili predmeti, telesa, liki in števila razvrščeni.'),(952,952,65,0,'Logika in jezik - prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(953,953,65,0,'Prikaže razvrstitev predmetov z različnimi diagrami.'),(954,954,65,0,'Ob pomoči prikaže razvrstitev predmetov z različnimi diagrami.'),(955,955,65,0,'Še ne prikaže razvrstitev predmetov z različnimi diagrami.'),(956,956,66,1,'loči med geometrijskim telesom, likom in črto,'),(957,957,66,1,'Loči med geometrijskimi oblikami, jih opiše in poimenuje v  matematičnem jeziku.    '),(958,958,66,1,'Pozna geometrijske oblike, jih opiše, razvrsti in uredi. Primerja oblike med seboj. Nariše večkotnik, ga ustrezno označi in poimenuje.'),(959,959,66,1,'Prepozna geometrijske oblike v svoji okolici in jih poimenuje z besedami iz svojega jezikovnega okolja. Pri poimenovanju oglišča  se še moti.'),(960,960,66,1,'prepozna simetrijo,'),(961,961,66,1,'Natančno nariše simetrične oblike v mreži, zna pravilno označiti črto pregiba.'),(962,962,66,1,'Pri risanju simetričnih oblik v mreži ni dovolj  natančen, potrebuje pomoč.'),(963,963,66,1,'oceni, primerja, meri in računa z enoimenskimi merskimi enotami; zapiše meritev z merskim številom in enoto,'),(964,964,66,1,'Poišče primerno enoto za merjenje (m, dm, cm). Oceni in izmeri s standardno enoto, računa z merskimi enotami.'),(965,965,66,1,'Izmeri in zapiše meritev s standardnimi enotami (m, dm, cm). Računa z merskimi enotami.'),(966,966,66,1,'S pomočjo učitelja meri in zapiše meritev s standardnimi enotami (m, dm, cm)'),(967,967,66,1,'šteje in uredi po velikosti naravna števila do 1000,'),(968,968,66,1,'Šteje, bere in zapiše števila do 1000. Pozna desetiške enote. Uredi števila in nadaljuje zaporedja.'),(969,969,66,1,'Šteje in bere števila do 1000. Uredi števila po velikosti.'),(970,970,66,1,'Šteje števila do 1000. Pri zapisovanju ima včasih težave. Števila uredi po velikosti.'),(971,971,66,1,'sešteva in odšteva naravna števila do 100 s prehodom,'),(972,972,66,1,'Izračuna račun seštevanja in odštevanja v množici naravnih števil do 100 s prehodom.'),(973,973,66,1,'Sešteva do 100 s prehodom. Pri odštevanju D, E si pomaga s ponazorili.'),(974,974,66,1,'Sešteva in odšteva do 100 tudi sprehodom D in E s pomočjo konkretnega materiala.'),(975,975,66,1,'sešteva in odšteva naravna števila do 1000 (najpreprostejše primere brez prehoda),'),(976,976,66,1,'Izračuna račun seštevanja in odštevanja do 1000 brez prehoda.'),(977,977,66,1,'Sešteva in odšteva do 1000 brez prehoda. Pomaga si s ponazorili.'),(978,978,66,1,'Sešteva in odšteva do 1000 brez prehoda s pomočjo konkretnega materiala.'),(979,979,66,1,'usvoji poštevanko v obsegu do 10 x 10 in uporablja količnike,'),(980,980,66,1,'Produkte v obsegu 10 x 10 je usvojil do avtomatizma, prav tako količnike, ki so povezani s poštevankami.'),(981,981,66,1,'Produkte v obsegu 10 x10 je usvojil, a se občasno še zmoti, prav tako količnike, ki so povezani s poštevankami.'),(982,982,66,1,'Produkte v obsegu 10 x10 je delno usvojil, težave mu dela tudi deljenje.'),(983,983,66,1,'prepozna dele celote,'),(984,984,66,1,'Deli celote na enake dele, razloži postopek ter ga utemelji.'),(985,985,66,1,'Deli celoto na enake dele, a se občasno še zmoti.'),(986,986,66,1,'Dele celote prikaže na konkretnem predmetu.'),(987,987,66,1,'pri reševanju problemov uporablja računske operacije,'),(988,988,66,1,'Uporabi seštevanje, odštevanje, množenje in deljenje pri reševanju problemskih nalog.'),(989,989,66,1,'Rešuje enostavne problemske situacije, a se še zmoti.'),(990,990,66,1,'podatke zbere in predstavi s preglednico, s figurnim prikazom in prikazom s stolpci.'),(991,991,66,1,'Poišče podatke, jih zbere, uredi in prikaže s primerno obliko prikaza. Razloži ugotovitve.'),(992,992,66,1,'Zbrane podatke uredi in prikaže s ponujeno obliko prikaza. Ugotovitve razloži.'),(993,993,66,1,'Po navodilih in pomoči učitelja zbere podatke. Predstavi jih s primerno obliko prikaza. Pri podajanju ugotovitev ni povsem samostojen.'),(994,994,9,0,'loči različne vrste čutov,'),(995,995,9,0,'Loči različne vrste čutov.'),(996,996,9,0,'Še ne loči različne vrste čutov.'),(997,997,9,0,'besedno izrazi najosnovnejše posebnosti pike (točke) in črte (linije),'),(998,998,9,0,'Samostojno besedno izrazi najosnovnejše posebnosti pike (točke) in črte (linije).'),(999,999,9,0,'Občasno besedno izrazi najosnovnejše posebnosti pike (točke) in črte (linije).'),(1000,1000,9,0,'Z učiteljevo pomočjo besedno izrazi najosnovnejše posebnosti pike (točke) in črte (linije).'),(1001,1001,9,0,'poimenuje in loči barve,'),(1002,1002,9,0,'Pravilno poimenuje in loči barve.'),(1003,1003,9,0,'S pomočjo učitelja poimenuje in loči barve.'),(1004,1004,9,0,'loči najosnovnejše kiparske pojme,'),(1005,1005,9,0,'Samostojno loči najosnovnejše kiparske pojme.'),(1006,1006,9,0,'Občasno loči najosnovnejše kiparske pojme.'),(1007,1007,9,0,'Še ne oči najosnovnejših kiparskih pojmov.'),(1008,1008,9,0,'prepozna osnovne prostorske pojme in se orientira v prostoru,'),(1009,1009,9,0,'Pravilno prepozna osnovne prostorske pojme in se orientira v prostoru.'),(1010,1010,9,0,'Občasno prepozna osnovne prostorske pojme in se orientira v prostoru.'),(1011,1011,9,0,'Ob pomoči prepozna osnovne prostorske pojme in se orientira v prostoru.'),(1012,1012,9,0,'pozna pojma tiskanje in odtis,'),(1013,1013,9,0,'Pozna pojma tiskanje in odtis.'),(1014,1014,9,0,'Ne pozna pojmov tiskanje in odtis.'),(1015,1015,9,0,'po likovnih področjih loči osnovne materiale in orodja,'),(1016,1016,9,0,'Po likovnih področjih pravilno loči osnovne materiale in orodja.'),(1017,1017,9,0,'Po likovnih področjih še ne  loči osnovnih materialov in orodij.'),(1018,1018,9,0,'opiše rabo različnih podlag,'),(1019,1019,9,0,'Pravilno opiše rabo različnih podlag.'),(1020,1020,9,0,'S pomočjo opiše rabo različnih podlag.'),(1021,1021,9,0,'loči rastlinske, živalske, človeške in predmetne motive,'),(1022,1022,9,0,'Samostojno loči rastlinske, živalske, človeške in predmetne motive.'),(1023,1023,9,0,'S pomočjo loči rastlinske, živalske, človeške in predmetne motive.'),(1024,1024,9,0,'določi lego upodobljenih predmetov in figur na ploskvi,'),(1025,1025,9,0,'Pravilno določi lego upodobljenih predmetov in figur na ploskvi.'),(1026,1026,9,0,'Občasno določi lego upodobljenih predmetov in figur na ploskvi.'),(1027,1027,9,0,'S pomočjo določi lego upodobljenih predmetov in figur na ploskvi.'),(1028,1028,9,0,'poimenuje likovne ustvarjalce in njihove umetniške stvaritve,'),(1029,1029,9,0,'Pravilno poimenuje likovne ustvarjalce in njihove umetniške stvaritve.'),(1030,1030,9,0,'S pomočjo poimenuje likovne ustvarjalce in njihove umetniške stvaritve.'),(1031,1031,9,0,'prepozna likovne kulturne ustanove…'),(1032,1032,9,0,'Samostojno prepozna likovne kulturne ustanove.'),(1033,1033,9,0,'S pomočjo prepozna likovne kulturne ustanove.'),(1034,1034,9,0,'na lastnem izdelku in izdelkih vrstnikov po oblikovanih merilih poišče pravilnosti izvedene likovne naloge,'),(1035,1035,9,0,'Na lastnem izdelku in izdelkih vrstnikov po oblikovanih merilih poišče pravilnosti izvedene likovne naloge.'),(1036,1036,9,0,'Na lastnem izdelku  po oblikovanih merilih poišče pravilnosti izvedene likovne naloge.'),(1037,1037,9,0,'Na lastnem izdelku  po oblikovanih merilih poišče s pomočjo učitelja pravilnosti izvedene likovne naloge.'),(1038,1038,10,0,'se črtno (linijsko) izrazi z različnimi materiali in orodji,'),(1039,1039,10,0,'Se črtno (linijsko) izrazi z različnimi materiali in orodji.'),(1040,1040,10,0,'z različnimi črtami (linijami) obogati narisane površine,'),(1041,1041,10,0,'Z različnimi črtami (linijami) obogati narisane površine.'),(1042,1042,10,0,'se brez podrisavanja likovno izrazi na izrazno ploskev različnih formatov, velikosti in barv,'),(1043,1043,10,0,'Brez podrisavanja se likovno izrazi na izrazno ploskev različnih formatov, velikosti in barv.'),(1044,1044,10,0,'naslika sliko z barvno ploskvijo in črto,'),(1045,1045,10,0,'Izvirno naslika sliko z barvno ploskvijo in črto.'),(1046,1046,10,0,'Naslika sliko z barvno ploskvijo in črto.'),(1047,1047,10,0,'z barvo pokrije celotno slikovno površino,'),(1048,1048,10,0,'Z barvo pokrije celotno slikovno površino.'),(1049,1049,10,0,'Z barvo pokrije del slikovne površine.'),(1050,1050,10,0,'meša barve,'),(1051,1051,10,0,'Samostojno meša barve.'),(1052,1052,10,0,'Z učiteljevo pomočjo meša barve.'),(1053,1053,10,0,'Ne zna mešati barv.'),(1054,1054,10,0,'naniza različne oblike in velikosti oblik s črto (linijo), z barvno ploskvijo, z odtiskovanjem,'),(1055,1055,10,0,'Samostojno naniza različne oblike in velikosti oblik s črto , z barvno ploskvijo, z odtiskovanjem.'),(1056,1056,10,0,'S pomočjo učitelja naniza različne oblike in velikosti oblik s črto , z barvno ploskvijo, z odtiskovanjem.'),(1057,1057,10,0,'zmodelira preprosti statični kip (človeška in živalska figura),'),(1058,1058,10,0,'Zna zmodelirati preprosti statični kip (človeška in živalska figura).'),(1059,1059,10,0,'Z učiteljevo pomočjo zna zmodelirati preprosti statični kip (človeška in živalska figura).'),(1060,1060,10,0,'zmodelira kip iz enovitega kosa mehkega materiala,'),(1061,1061,10,0,'Samostojno zmodelira kip iz enovitega kosa mehkega materiala.'),(1062,1062,10,0,'S pomočjo zmodelira kip iz enovitega kosa mehkega materiala.'),(1063,1063,10,0,'izoblikuje kip iz naravnega ali odpadnega materiala,'),(1064,1064,10,0,'Izvirno izoblikuje kip iz naravnega ali odpadnega materiala.'),(1065,1065,10,0,'Izoblikuje kip iz naravnega ali odpadnega materiala.'),(1066,1066,10,0,'S pomočjo izoblikuje kip iz naravnega ali odpadnega materiala.'),(1067,1067,10,0,'zgradi preproste zaprte, polzaprte in polodprte prostorske tvorbe (s sestavljenkami in v peskovniku).'),(1068,1068,10,0,'Zgradi preproste zaprte, polzaprte in polodprte prostorske tvorbe (s sestavljenkami in v peskovniku).'),(1069,1069,10,0,'Ob pomoči zgradi preproste zaprte, polzaprte in polodprte prostorske tvorbe (s sestavljenkami in v peskovniku).'),(1070,1070,11,0,'se spontano likovno izrazi'),(1071,1071,11,0,'Vedno se spontano likovno izrazi.'),(1072,1072,11,0,'Občasno se spontano likovno izrazi.'),(1073,1073,11,0,'razišče izrazne možnosti različnih likovnih materialov in orodij,'),(1074,1074,11,0,'Pogosto razišče izrazne možnosti različnih likovnih materialov in orodij.'),(1075,1075,11,0,'Občasno razišče izrazne možnosti različnih likovnih materialov in orodij.'),(1076,1076,11,0,'Z učiteljevo pomočjo razišče izrazne možnosti različnih likovnih materialov in orodij.'),(1077,1077,11,0,'izkaže izvirnost pri reševanju likovnih problemov,'),(1078,1078,11,0,'Pogosto izkaže izvirnost pri reševanju likovnih problemov.'),(1079,1079,11,0,'Občasno izkaže izvirnost pri reševanju likovnih problemov.'),(1080,1080,11,0,'Redkokdaj izkaže izvirnost pri reševanju likovnih problemov.'),(1081,1081,11,0,'pri upodobitvi motiva izkaže likovni spomin in domišljijo.'),(1082,1082,11,0,'Pri upodobitvi motiva izkaže likovni spomin in domišljijo.'),(1083,1083,11,0,'Pri upodobitvi motiva izkaže likovni spomin.'),(1084,1084,11,0,'Pri upodobitvi motiva izkaže  domišljijo.'),(1085,1085,12,1,'loči in poimenuje najosnovnejše likovne pojme,'),(1086,1086,12,1,'Loči, poimenuje in poveže že znana spoznanja z novimi likovnimi pojmi. Poimenuje osnovne likovne tehnike.'),(1087,1087,12,1,'Ob učiteljevi pomoči loči in poimenuje likovne pojme, ki jih uporabi pri likovnem izražanju.'),(1088,1088,12,1,'Ne poimenuje osnovnih likovnih tehnik.'),(1089,1089,12,1,'opazuje in prepozna likovne elemente na predmetih in pojavih v okolju in naravi,'),(1090,1090,12,1,'Natančno opazuje, prepozna in uporabi likovne elemente.'),(1091,1091,12,1,'Opazuje in prepozna likovne elemente na predmetih in pojavih v okolju.'),(1092,1092,12,1,'Opazuje likovne elemente na predmetih in pojavih v okolju, a jih ne prepozna.'),(1093,1093,12,1,'se neposredno in sproščeno likovno izraža,'),(1094,1094,12,1,'Neposredno in sproščeno se likovno izraža. Je uspešen na vseh likovnih področjih.'),(1095,1095,12,1,'Pri likovnem izražanju naredi, kar je potrebno. Je uspešen na področju , npr. slikanja,  (risanja, kiparjenja,...)'),(1096,1096,12,1,'Pokaže malo pripravljenosti za likovno izražanje. Pri delu potrebuje spodbudo.'),(1097,1097,12,1,'pri likovnem izražanju uporablja likovni spomin, domišljijo in predstave,'),(1098,1098,12,1,'Izvirno in domiselno uporabi likovni motiv.'),(1099,1099,12,1,'Pri likovnem izražanju gaje potrebno spodbujati.'),(1100,1100,12,1,'Pri likovnem izražanju izkaže manj domišljije.'),(1101,1101,12,1,'prepozna osnovne likovne materiale in orodja,'),(1102,1102,12,1,'Likovni motiv uskladi z likovno nalogo; ustrezno uporabi likovni material in orodje.'),(1103,1103,12,1,'Izkaže manj izvirnosti pri uporabi likovnih materialov in orodij.'),(1104,1104,12,1,'Likovne materiale in orodja izbira s pomočjo učitelja.'),(1105,1105,12,1,'po predstavljenih postopkih izvaja preproste likovne tehnike,'),(1106,1106,12,1,'Po navodilu dosledno izvede likovno tehniko.'),(1107,1107,12,1,'Po navodilu izvede postopke likovne tehnike.'),(1108,1108,12,1,'Postopke likovne tehnike izvede ob delni učiteljevi pomoči.'),(1109,1109,12,1,'prepozna izrazna sredstva v likovnih stvaritvah,'),(1110,1110,12,1,'Prepozna izrazna sredstva v likovnih stvaritvah.'),(1111,1111,12,1,'Prepoznava izrazna sredstva v likovnih stvaritvah.'),(1112,1112,12,1,'Izrazna sredstva v likovnih stvaritvah prepoznava ob učiteljevi pomoči.'),(1113,1113,12,1,'na lastnih likovnih izdelkih in izdelkih vrstnikov poišče pravilnost izvedene likovne naloge po oblikovnih merilih.'),(1114,1114,12,1,'Po oblikovanih merilih kritično ovrednoti svoj in sošolčev izdelek.'),(1115,1115,12,1,'Ob spodbudi učitelja poišče pravilnost izvedene likovne naloge na svojem in sošolčevem izdelku.'),(1116,1116,12,1,'Spremlja vrednotenje likovnih izdelkov po oblikovanih merilih.'),(1117,1117,38,0,'loči najosnovnejše lastnosti črt (linij),'),(1118,1118,38,0,'Loči najosnovnejše lastnosti črt (linij).'),(1119,1119,38,0,'Našteje najosnovnejše lastnosti črt (linij).'),(1120,1120,38,0,'našteje zglede različnih črt v okolju in naravi,'),(1121,1121,38,0,'Našteje zglede različnih črt v okolju in naravi.'),(1122,1122,38,0,'Prepozna zglede različnih črt v okolju in naravi.'),(1123,1123,38,0,'obrazloži razporeditev upodobljenih podob po risalni površini,'),(1124,1124,38,0,'Samostojno obrazloži razporeditev upodobljenih podob po risalni površini.'),(1125,1125,38,0,'Ob pomoči učitelja obrazloži razporeditev upodobljenih podob po risalni površini.'),(1126,1126,38,0,'poimenuje barve ob opazovanju likovnih stvaritev in predmetov v okolju in naravi,'),(1127,1127,38,0,'Poimenuje barve ob opazovanju likovnih stvaritev in predmetov v okolju in naravi.'),(1128,1128,38,0,'S pomočjo poimenuje barve ob opazovanju likovnih stvaritev in predmetov v okolju in naravi.'),(1129,1129,38,0,'prepozna nemešano in mešano barvo,'),(1130,1130,38,0,'Samostojno prepozna nemešano in mešano barvo.'),(1131,1131,38,0,'Občasno prepozna nemešano in mešano barvo.'),(1132,1132,38,0,'Ob pomoči učitelja prepozna nemešano in mešano barvo.'),(1133,1133,38,0,'pojasni nastanek barvne ploskve,'),(1134,1134,38,0,'Pojasni nastanek barvne ploskve.'),(1135,1135,38,0,'Ob pomoči učitelja pojasni nastanek barvne ploskve.'),(1136,1136,38,0,'razvrsti barve po svetlosti,'),(1137,1137,38,0,'Samostojno razvrsti barve po svetlosti.'),(1138,1138,38,0,'Ob pomoči učitelja razvrsti barve po svetlosti,'),(1139,1139,38,0,'razlikuje najosnovnejše kiparske pojme,'),(1140,1140,38,0,'Dobro razlikuje najosnovnejše kiparske pojme,'),(1141,1141,38,0,'Razlikuje najosnovnejše kiparske pojme,'),(1142,1142,38,0,'Še ne razlikuje najosnovnejših kiparskih pojmov.'),(1143,1143,38,0,'opiše posebnosti postopka oblikovanja razgibanega obhodnega kipa,'),(1144,1144,38,0,'Opiše posebnosti postopka oblikovanja razgibanega obhodnega kipa.'),(1145,1145,38,0,'Ob pomoči opiše posebnosti postopka oblikovanja razgibanega obhodnega kipa.'),(1146,1146,38,0,'Še ne opiše posebnosti postopka oblikovanja razgibanega obhodnega kipa,'),(1147,1147,38,0,'pojasni osnovne značilnosti zunanjega in bivalnega prostora,'),(1148,1148,38,0,'Pojasni osnovne značilnosti zunanjega in bivalnega prostora.'),(1149,1149,38,0,'Ob pomoči pojasni osnovne značilnosti zunanjega in bivalnega prostora.'),(1150,1150,38,0,'Prepozna osnovne značilnosti zunanjega in bivalnega prostora.'),(1151,1151,38,0,'pojasni pojma tiskanje in odtis,'),(1152,1152,38,0,'Pojasni pojma tiskanje in odtis.'),(1153,1153,38,0,'S pomočjo učitelja pojasni pojma tiskanje in odtis.'),(1154,1154,38,0,'poimenuje umetniške ustvarjalce, njihova dela ter likovne kulturne ustanove,'),(1155,1155,38,0,'Pozna in poimenuje umetniške ustvarjalce, njihova dela ter likovne kulturne ustanove,'),(1156,1156,38,0,'Prepozna umetniške ustvarjalce, njihova dela ter likovne kulturne ustanove,'),(1157,1157,38,0,'Delno pozna umetniške ustvarjalce, njihova dela ter likovne kulturne ustanove,'),(1158,1158,38,0,'prepozna različne materiale in orodja po likovnih področjih,'),(1159,1159,38,0,'Prepozna različne materiale in orodja po likovnih področjih.'),(1160,1160,38,0,'Ob vodenem opazovanju prepozna različne materiale in orodja po likovnih področjih.'),(1161,1161,38,0,'po oblikovanih merilih pojasni izvedbo likovne naloge.'),(1162,1162,38,0,'Po oblikovanih merilih dosledno  pojasni izvedbo likovne naloge.'),(1163,1163,38,0,'Po oblikovanih merilih  s pomočjo učitelja pojasni izvedbo likovne naloge.'),(1164,1164,38,0,'Po oblikovanih merilih spremlja izvedbo likovne naloge.'),(1165,1165,39,0,'z različnimi risarskimi materiali nariše risbo brez podrisavanja,'),(1166,1166,39,0,'Z različnimi risarskimi materiali nariše risbo brez podrisavanja.'),(1167,1167,39,0,'Z različnimi risarskimi materiali  ob opozorilih učitelja nariše risbo brez podrisavanja.'),(1168,1168,39,0,'narisane površine obogati s črtami,'),(1169,1169,39,0,'Narisane površine ustvarjalno obogati s črtami.'),(1170,1170,39,0,'Narisane površine obogati s črtami.'),(1171,1171,39,0,'z uporabo različnih slikarskih materialov naslika sliko z barvnimi ploskvami,'),(1172,1172,39,0,'Z uporabo različnih slikarskih materialov ustvarjalno naslika sliko z barvnimi ploskvami.'),(1173,1173,39,0,'Z uporabo različnih slikarskih materialov nedosledno naslika sliko z barvnimi ploskvami.'),(1174,1174,39,0,'na spontan način meša barve,'),(1175,1175,39,0,'Na spontan način  samostojno meša barve.'),(1176,1176,39,0,'Na spontan način meša barve.'),(1177,1177,39,0,'svetli barve z belo in temni s črno barvo,'),(1178,1178,39,0,'Samostojno svetli barve z belo in temni s črno barvo.'),(1179,1179,39,0,'Ob pomoči učitelja svetli barve z belo in temni s črno barvo.'),(1180,1180,39,0,'upodobi izbrani motiv na podlage različnih velikosti, barv in kvalitet,'),(1181,1181,39,0,'Samostojno upodobi izbrani motiv na podlage različnih velikosti, barv in kvalitet.'),(1182,1182,39,0,'Ob pomoči učitelja upodobi izbrani motiv na podlage različnih velikosti, barv in kvalitet.'),(1183,1183,39,0,'izoblikuje statično in razgibano figuro iz enovitega kosa mehkega materiala,'),(1184,1184,39,0,'Ustvarjalno izoblikuje statično in razgibano figuro iz enovitega kosa mehkega materiala,'),(1185,1185,39,0,'Pod vodstvom učitelja izoblikuje statično in razgibano figuro iz enovitega kosa mehkega materiala,'),(1186,1186,39,0,'sestavi kiparsko obliko iz trdega materiala,'),(1187,1187,39,0,'Samostojno sestavi kiparsko obliko iz trdega materiala,'),(1188,1188,39,0,'Z učiteljevo pomočjo sestavi kiparsko obliko iz trdega materiala,'),(1189,1189,39,0,'naniza kiparske oblike iz ploskovitega upogibnega materiala,'),(1190,1190,39,0,'Naniza kiparske oblike iz ploskovitega upogibnega materiala.'),(1191,1191,39,0,'S pomočjo naniza kiparske oblike iz ploskovitega upogibnega materiala.'),(1192,1192,39,0,'zgradi različne oblike prostorov s sestavljenkami, z embalažnimi škatlicami in s peskom v peskovniku,'),(1193,1193,39,0,'Ustvarjalno zgradi različne oblike prostorov s sestavljenkami, z embalažnimi škatlicami in s peskom v peskovniku.'),(1194,1194,39,0,'Zgradi različne oblike prostorov s sestavljenkami, z embalažnimi škatlicami in s peskom v peskovniku.'),(1195,1195,39,0,'S pomočjo zgradi različne oblike prostorov s sestavljenkami, z embalažnimi škatlicami in s peskom v peskovniku.'),(1196,1196,39,0,'ritmično odtiskuje oblike v različnih velikostih in barvah.'),(1197,1197,39,0,'Samostojno ritmično odtiskuje oblike v različnih velikostih in barvah.'),(1198,1198,39,0,'Ob pomoči učitelja ritmično odtiskuje oblike v različnih velikostih in barvah.'),(1199,1199,40,0,'se neposredno in spontano likovno izrazi,'),(1200,1200,40,0,'Se neposredno in spontano likovno izrazi.'),(1201,1201,40,0,'Se neposredno likovno izrazi.'),(1202,1202,40,0,'Se  spontano likovno izrazi.'),(1203,1203,40,0,'se izrazi z lastno ustvarjalno idejo,'),(1204,1204,40,0,'Pogosto se izrazi z lastno ustvarjalno idejo.'),(1205,1205,40,0,'Občasno se izrazi z lastno ustvarjalno idejo.'),(1206,1206,40,0,'Pri izvajanju likovnih nalog posnema ideje sošolcev.'),(1207,1207,40,0,'pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave,'),(1208,1208,40,0,'Pogosto pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1209,1209,40,0,'Občasno pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1210,1210,40,0,'Ob pomoči učitelja pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1211,1211,40,0,'odkriva različne izrazne možnosti ob raznoliki uporabi likovnih materialov in njihovih orodij.'),(1212,1212,40,0,'Pogosto odkriva različne izrazne možnosti ob raznoliki uporabi likovnih materialov in njihovih orodij.'),(1213,1213,40,0,'Občasno odkriva različne izrazne možnosti ob raznoliki uporabi likovnih materialov in njihovih orodij.'),(1214,1214,40,0,'Ob pomoči odkriva različne izrazne možnosti ob raznoliki uporabi likovnih materialov in njihovih orodij.'),(1215,1215,41,1,'loči najosnovnejše likovne pojme posameznih likovnih področij,'),(1216,1216,41,1,'Natančno loči najosnovnejše likovne pojme posameznih likovnih področij.'),(1217,1217,41,1,'Občasno ne loči najosnovnejših likovnih pojmov posameznih likovnih področij.'),(1218,1218,41,1,'Ob dodatnem pojasnilu loči najosnovnejše likovne pojme posameznih likovnih področij.'),(1219,1219,41,1,'poišče zglede spoznanih likovnih pojmov na predmetih in pojavih v okolju in naravi,'),(1220,1220,41,1,'Poišče zglede likovnih pojmov na predmetih in pojavih v naravi.'),(1221,1221,41,1,'Poišče zglede likovnih pojmov na predmetih in pojavih v naravi ob spodbudi.'),(1222,1222,41,1,'Če je voden, poišče na predmetih in pojavih v okolju in naravi zglede likovnih pojmov.'),(1223,1223,41,1,'obrazloži spoznane likovne pojme,'),(1224,1224,41,1,'Na konkretnih primerih obrazloži spoznane likovne pojme. Se primerno izraža in opisuje.'),(1225,1225,41,1,'Na konkretnih primerih s pomočjo učitelja obrazloži spoznane likovne pojme. Pri opisovanju se skromno izraža'),(1226,1226,41,1,'Na konkretnih primerih s pomočjo učitelja obrazloži spoznane likovne pojme. Ob pomoči učiteljevih vprašanj opisuje likovne pojme.'),(1227,1227,41,1,'loči osnovne posebnosti različnih likovnih materialov in orodij,'),(1228,1228,41,1,'Natančno loči osnovne posebnosti različnih likovnih materialov in orodij. Z materialom in orodjem odgovorno in ustrezno ravna.'),(1229,1229,41,1,'Loči osnovne posebnosti različnih likovnih materialov in orodij. Z materialom in orodjem občasno ne odgovorno ravna.'),(1230,1230,41,1,'Ob pomoči loči osnovne posebnosti različnih likovnih materialov in orodij. Z materialom in orodjem ravna nespretno.'),(1231,1231,41,1,'po predstavljenih postopkih izvaja enostavne likovne tehnike,'),(1232,1232,41,1,'Po navodilih natančno in dosledno izvede likovno tehniko. Odkrije nove možnosti za izvedbo likovne tehnike.'),(1233,1233,41,1,'Po navodilu izvede postopke likovne tehnike. Občasno potrebuje pomoč.'),(1234,1234,41,1,'Postopke likovne tehnike izvede ob učiteljevi pomoči.'),(1235,1235,41,1,'razvija likovno domišljijo, spomin in predstave,'),(1236,1236,41,1,'Ima bogato likovno domišljijo, spomin in predstave. Izkaže originalnost. Je vztrajen in dosleden.'),(1237,1237,41,1,'Razvija likovno domišljijo , spomin in predstave. Občasno je izviren, vztrajen in dosleden.'),(1238,1238,41,1,'Ima delno razvito likovno domišljijo, spomin in predstave. Na šablonski način upodobi likovni motiv. Pri izvedbi je občasno nedosleden.'),(1239,1239,41,1,'se sproščeno in izvirno likovno izrazi,'),(1240,1240,41,1,'Sproščeno in ustvarjalno se likovno izraža. Je uspešen na vseh likovnih področjih.'),(1241,1241,41,1,'Se sproščeno likovno izraža , naredi kar je potrebno. Je uspešen na vseh likovnih področjih.'),(1242,1242,41,1,'Je uspešen pri ( slikanju) . Naredi kar je potrebno.'),(1243,1243,41,1,'prepozna likovne stvaritve umetnikov in likovne kulturne ustanove,'),(1244,1244,41,1,'Pozna in loči likovne stvaritve umetnikov. Kritično jih vrednoti. Pozna likovne kulturne ustanove in njihov pomen.'),(1245,1245,41,1,'Prepozna likovne stvaritve umetnikov. Če je voden, jih opiše. Pozna likovne kulturne ustanove.'),(1246,1246,41,1,'Po dodatnem pojasnilu prepozna likovne stvaritve umetnikov. Delno pozna likovne ustanove.'),(1247,1247,41,1,'po oblikovanih merilih pojasni izvedbo likovne naloge.'),(1248,1248,41,1,'Dosledno  ovrednoti glede na oblikovana merila svoj in izdelek sošolca.'),(1249,1249,41,1,'Glede na oblikovana merila ovrednoti svoj izdelek in izdelek sošolca s pomočjo učitelja.'),(1250,1250,41,1,'Spremlja vrednotenje likovnih izdelkov po oblikovanih merilih.'),(1251,1251,67,0,'razlikuje pojme risba, slika, kip in grafika,'),(1252,1252,67,0,'Razlikuje pojme risba, slika,kip in grafika.'),(1253,1253,67,0,'S pomočjo ponazoril razlikuje pojme risba, slika, kip in grafika.'),(1254,1254,67,0,'loči lastnosti črt…'),(1255,1255,67,0,'Loči lastnosti črt.'),(1256,1256,67,0,'Ob učiteljevi pomoči loči lastnosti črt.'),(1257,1257,67,0,'prepozna lastnosti trdih in tekočih risarskih materialov,'),(1258,1258,67,0,'Prepozna lastnosti trdih in tekočih risarskih materialov.'),(1259,1259,67,0,'Ob vodenem opazovanju prepozna lastnosti trdih in tekočih risarskih materialov.'),(1260,1260,67,0,'pojasni povezave med velikostjo formata in sledmi, ki jih puščajo različni risarski materiali,'),(1261,1261,67,0,'Zna pojasniti povezave med velikostjo formata in sledmi, ki jih puščajo različni risarski materiali.'),(1262,1262,67,0,'Ob pomoči učitelja pojasni povezave med velikostjo formata in sledmi, ki jih puščajo različni risarski materiali.'),(1263,1263,67,0,'pojasni nastanek svetlejše in temnejše črtne ploskve,'),(1264,1264,67,0,'Pojasni nastanek svetlejše in temnejše črtne ploskve.'),(1265,1265,67,0,'Nastanek svetlejše in temnejše črtne ploskve še ne zna pojasniti.'),(1266,1266,67,0,'pojasni prekrivanje barvnih ploskev,'),(1267,1267,67,0,'Pojasni prekrivanje barvnih ploskev.'),(1268,1268,67,0,'Še ne zna pojasniti prekrivanja barvnih ploskev.'),(1269,1269,67,0,'pojasni svetlenje in temnenje barv,'),(1270,1270,67,0,'Pojasni svetlenje in temnenje barv.'),(1271,1271,67,0,'Ob pomoči pojasni svetlenje in temnenje barv.'),(1272,1272,67,0,'prepozna lastnosti različnih slikarskih materialov in orodij,'),(1273,1273,67,0,'Prepozna lastnosti različnih slikarskih materialov in orodij.'),(1274,1274,67,0,'Ob učiteljevi pomoči prepozna lastnosti različnih slikarskih materialov in orodij.'),(1275,1275,67,0,'pozna osnovne kiparske materiale in orodja glede na njihove lastnosti,'),(1276,1276,67,0,'Pozna osnovne kiparske materiale in orodja glede na njihove lastnosti.'),(1277,1277,67,0,'Seznanjen je z osnovnimi kiparskimi materiali in orodji glede na njihove lastnosti.'),(1278,1278,67,0,'prepozna nekatere posebnosti kiparskih oblik (nizek, visok, vbočen, izbočen…),'),(1279,1279,67,0,'Prepozna nekatere posebnosti kiparskih oblik'),(1280,1280,67,0,'Opazi nekatere posebnosti kiparskih oblik.'),(1281,1281,67,0,'opiše oblike in sestavne dele prostorov,'),(1282,1282,67,0,'Opiše oblike in sestavne dele prostorov.'),(1283,1283,67,0,'Ob pomoči učitelja opiše oblike in sestavne dele prostorov.'),(1284,1284,67,0,'pojasni osnovne značilnosti grafike,'),(1285,1285,67,0,'Pojasni osnovne značilnosti grafike.'),(1286,1286,67,0,'Ob pomoči učitelja pojasni osnovne značilnosti grafike.'),(1287,1287,67,0,'po oblikovanih merilih pojasni pravilnost izvedene likovne naloge.'),(1288,1288,67,0,'Po oblikovanih merilih pojasni pravilnost izvedene likovne naloge.'),(1289,1289,67,0,'Ob pomoči učitelja pojasni pravilnost izvedene likovne naloge.'),(1290,1290,68,0,'z različnimi risarskimi materiali nariše risbo po postopku od celote k detajlom,'),(1291,1291,68,0,'Z različnimi risarskimi materiali nariše risbo po postopku od celote k detajlom.'),(1292,1292,68,0,'Z različnimi risarskimi materiali ob opozorilih učitelja nariše risbo po postopku od celote k detajlom.'),(1293,1293,68,0,'narisane površine obogati s črtami,'),(1294,1294,68,0,'Narisane površine ustvarjalno obogati s črtami.'),(1295,1295,68,0,'Narisane površine obogati s črtami.'),(1296,1296,68,0,'naslika sliko z uporabo različnih slikarskih materialov,'),(1297,1297,68,0,'Naslika sliko z uporabo različnih slikarskih materialov.'),(1298,1298,68,0,'Ob učiteljevih spodbudah naslika sliko z uporabo različnih slikarskih materialov.'),(1299,1299,68,0,'nameša barve po predstavljenih postopkih,'),(1300,1300,68,0,'Nameša barve po predstavljenih postopkih.'),(1301,1301,68,0,'Ob pomoči nameša barve po predstavljenih postopkih.'),(1302,1302,68,0,'naslika sliko s svetlenjem in temnenjem barv,'),(1303,1303,68,0,'Naslika sliko s svetlenjem in temnenjem barv.'),(1304,1304,68,0,'Naslika sliko, a mu svetlenje in temnenje barv povzročata težave.'),(1305,1305,68,0,'izoblikuje ritmično kompozicijo z barvnimi ploskvami,'),(1306,1306,68,0,'Izoblikuje ritmično kompozicijo z barvnimi ploskvami.'),(1307,1307,68,0,'Z velikimi težavami izoblikuje kompozicijo z barvnimi ploskvami.'),(1308,1308,68,0,'iz različnih materialov izoblikuje kiparske tvorbe,'),(1309,1309,68,0,'Iz različnih materialov izoblikuje kiparske tvorbe.'),(1310,1310,68,0,'Iz različnih materialov težko izoblikuje kiparske tvorbe.'),(1311,1311,68,0,'izoblikuje ritmične kiparske oblike,'),(1312,1312,68,0,'Izoblikuje ritmične kiparske oblike.'),(1313,1313,68,0,'Zelo površno izoblikuje ritmične kiparske oblike.'),(1314,1314,68,0,'zgradi različne prostorske oblike,'),(1315,1315,68,0,'Zgradi različne prostorske oblike.'),(1316,1316,68,0,'Ob pomoči učitelja zgradi različne prostorske oblike.'),(1317,1317,68,0,'likovno uredi notranji prostor,'),(1318,1318,68,0,'Likovno uredi notranji prostor.'),(1319,1319,68,0,'Ob pomoči učitelja likovno uredi notranji prostor.'),(1320,1320,68,0,'izdela matrice in pečatnike ter jih odtisne.'),(1321,1321,68,0,'Izdela matrice in pečatnike ter jih odtisne.'),(1322,1322,68,0,'Ob pomoči učitelja izdela matrice in pečatnike ter jih odtisne.'),(1323,1323,69,0,'se izrazi z lastno ustvarjalno idejo,'),(1324,1324,69,0,'Izrazi se z lastno ustvarjalno idejo.'),(1325,1325,69,0,'Pri izvajanju likovnih nalog posnema ideje sošolcev.'),(1326,1326,69,0,'si razvija vztrajnost in samostojnost,'),(1327,1327,69,0,'Pri izvedbi likovnih del je vztrajen in samostojen.'),(1328,1328,69,0,'Pri izvedbi likovnih del potrebuje spodbudo, da delo dokonča.'),(1329,1329,69,0,'pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1330,1330,69,0,'Pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1331,1331,69,0,'Pri upodobitvi motiva nesamostojno izkaže likovno domišljijo, spomin in predstave.'),(1332,1332,70,1,'opazuje in prepozna likovne elemente na predmetih in pojavih,'),(1333,1333,70,1,'Natančno in sistematično opazuje in prepozna likovne elemente na predmetih in pojavih.'),(1334,1334,70,1,'Pri opazovanju potrebuje oporne točke. Prepozna likovne elemente na predmetih in pojavih.'),(1335,1335,70,1,'Opazi le nekatere in najbolj očitne elemente na predmetih in pojavih.'),(1336,1336,70,1,'razlikuje pojme risba, slika, kip in grafika,'),(1337,1337,70,1,'S svojim izdelkom v celoti pokaže razumevanje pojmov.'),(1338,1338,70,1,'Pretežno pozna in uporablja likovne pojme.'),(1339,1339,70,1,'Pozna in razume le nekatere pojme.'),(1340,1340,70,1,'se neposredno in sproščeno likovno izrazi,'),(1341,1341,70,1,'Se neposredno in sproščeno likovno izrazi.'),(1342,1342,70,1,'Ob spodbudi se likovno izraža.'),(1343,1343,70,1,'pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave,'),(1344,1344,70,1,'Pri izvedbi likovnega motiva je ustvarjalen, izviren in domiseln.'),(1345,1345,70,1,'Pri izvedbi likovnega motiva je manj domiseln, ima pa dobro oblikovane predstave.'),(1346,1346,70,1,'Pri izvedbi likovnega motiva povzema ideje drugih.'),(1347,1347,70,1,'prepozna posebnosti osnovnih risarskih, slikarskih in kiparskih materialov,'),(1348,1348,70,1,'Izbere likovni material, ki ustreza likovni nalogi.'),(1349,1349,70,1,'Pri izbiri likovnih materialov potrebuje pomoč.'),(1350,1350,70,1,'si krepi spretnost in občutek za uporabo različnih likovnih materialov in orodij,'),(1351,1351,70,1,'Pri uporabi likovnih materialov in orodij je spreten.'),(1352,1352,70,1,'Pri nekaterih likovnih materialih in orodjih potrebuje pomoč.'),(1353,1353,70,1,'Pri uporabi večine  likovnih materialih in orodjih potrebuje pomoč.'),(1354,1354,70,1,'v umetniških delih in izdelkih učencev prepozna osnovna izrazna sredstva,'),(1355,1355,70,1,'V umetniških delih in izdelkih učencev prepozna osnovna izrazna sredstva.'),(1356,1356,70,1,'V umetniških delih in izdelkih učencev prepozna le nekatera izrazna sredstva.'),(1357,1357,70,1,'V umetniških delih in izdelkih učencev prepozna osnovna izrazna sredstva le s pomočjo učitelja.'),(1358,1358,70,1,'po oblikovanih merilih pojasni pravilnost izvedene likovne naloge.'),(1359,1359,70,1,'Pojasni pravilnost izvedene likovne naloge na podlagi danih kriterijev.'),(1360,1360,70,1,'Pojasni pravilnost izvedene likovne naloge na podlagi danih kriterijev.'),(1361,1361,70,1,'Poskuša prepoznati pravilnost izvedene likovne naloge.'),(1362,1362,13,0,'v svojem glasovnem obsegu poje krajše ljudske in umetne pesmi,'),(1363,1363,13,0,'V svojem glasovnem obsegu pravilno poje krajše ljudske in umetne pesmi.'),(1364,1364,13,0,'V svojem glasovnem obsegu delno pravilno poje krajše ljudske in umetne pesmi.'),(1365,1365,13,0,'V svojem glasovnem obsegu netočno poje krajše ljudske in umetne pesmi.'),(1366,1366,13,0,'ritmično izreka načrtovana otroška besedila,'),(1367,1367,13,0,'Pravilno ritmično izreka načrtovana otroška besedila.'),(1368,1368,13,0,'Pravilno ritmično izreka del načrtovanih otroških besedil.'),(1369,1369,13,0,'petje in ritmično izreko spremlja s posameznimi glasbili,'),(1370,1370,13,0,'Petje in ritmično izreko spremlja s posameznimi glasbili.'),(1371,1371,13,0,'petje in ritmično izreko spremlja z gibi in rajanjem,'),(1372,1372,13,0,'Petje in ritmično izreko sproščeno spremlja z gibi in rajanjem.'),(1373,1373,13,0,'Petje in ritmično izreko zadržano spremlja z gibi in rajanjem.'),(1374,1374,13,0,'Petje in ritmično izreko  spremlja z gibi in rajanjem.'),(1375,1375,14,0,'doživljajsko poustvarja pesmi in otroška besedila,'),(1376,1376,14,0,'Doživljajsko sproščeno poustvarja pesmi in otroška besedila.'),(1377,1377,14,0,'Doživljajsko zadržano  poustvarja pesmi in otroška besedila.'),(1378,1378,14,0,'z glasbili oblikuje spremljave k petju in ritmični izreki besedil,'),(1379,1379,14,0,'Izvirno z glasbili oblikuje spremljave k petju in ritmični izreki besedil.'),(1380,1380,14,0,'Zadržano z glasbili oblikuje spremljave k petju in ritmični izreki besedil.'),(1381,1381,14,0,'si izmišlja lastne zvočne vsebine,'),(1382,1382,14,0,'Sproščeno si izmišlja lastne zvočne vsebine.'),(1383,1383,14,0,'Ob dodatni spodbudi si izmišlja lastne zvočne vsebine.'),(1384,1384,14,0,'glasbena doživetja in predstave ustvarjalno izraža: gibalno, plesno, likovno ali besedno,'),(1385,1385,14,0,'Glasbena doživetja in predstave ustvarjalno izraža: gibalno, plesno, likovno ali besedno.'),(1386,1386,14,0,'Glasbena doživetja in predstave ustvarjalno izraža:  likovno ali besedno.'),(1387,1387,14,0,'Glasbena doživetja in predstave ustvarjalno izraža: gibalno, likovno ali besedno.'),(1388,1388,14,0,'Glasbena doživetja in predstave ustvarjalno izraža:  likovno ali besedno.'),(1389,1389,15,0,'zbrano posluša načrtovane skladbe,'),(1390,1390,15,0,'Zbrano posluša načrtovane skladbe.'),(1391,1391,15,0,'Nezbrano posluša načrtovane skladbe.'),(1392,1392,15,0,'ob poslušanju prepoznava posamezne inštrumente in pevske glasove,'),(1393,1393,15,0,'Ob poslušanju prepoznava posamezne inštrumente in pevske glasove.'),(1394,1394,15,0,'Ob poslušanju prepoznava posamezne  pevske glasove.'),(1395,1395,15,0,'Ob poslušanju prepoznava posamezne inštrumente.'),(1396,1396,15,0,'prepoznava različne zvoke: glasbene in druge,'),(1397,1397,15,0,'Prepoznava različne zvoke: glasbene in druge.'),(1398,1398,16,0,'si razvija temeljni melodični in ritmični posluh,'),(1399,1399,16,0,'Razvija si temeljni melodični in ritmični posluh.'),(1400,1400,16,0,'si razvija pevski glas ter spretnost inštrumentalne igre,'),(1401,1401,16,0,'Razvija si pevski glas ter spretnost inštrumentalne igre.'),(1402,1402,16,0,'Razvija si pevski glas.'),(1403,1403,16,0,'razume in uporablja načrtovan glasbeni besednjak,'),(1404,1404,16,0,'Razume in uporablja načrtovan glasbeni besednjak.'),(1405,1405,16,0,'Razume in uporablja del načrtovanega glasbenega besednjaka.'),(1406,1406,17,1,'poje načrtovan izbor pesmi v svojem obsegu,'),(1407,1407,17,1,'Pozna besedilo pesmi. Pesmi zapoje ritmično in melodično pravilno.'),(1408,1408,17,1,'Besedilo pesmi pozna. Pesmi poje melodično nenatančno.'),(1409,1409,17,1,'Besedila pesmi delno osvoji. Pesmi zapoje ritmično in melodično nenatančno. Za petje ga je potrebno dodatno motivirati.'),(1410,1410,17,1,'igra na izbrana glasbila,'),(1411,1411,17,1,'Izbere instrument, ga poimenuje in oblikuje ustrezno spremljavo.'),(1412,1412,17,1,'Prepozna glasbilo. Igra po vzorcu.'),(1413,1413,17,1,'Ob pomoči izbere ustrezen instrument. Spremljavo izvaja aritmično.'),(1414,1414,17,1,'si izmišlja spremljave in zvočne vsebine,'),(1415,1415,17,1,'Izmisli si zahtevnejšo spremljavo in zvočne vsebine.'),(1416,1416,17,1,'Oblikuje enostavno spremljavo in zvočne vsebine.'),(1417,1417,17,1,'Ne izkaže interesa za izmišljanje spremljave in zvočnih vsebin.'),(1418,1418,17,1,'posluša krajše skladbe,'),(1419,1419,17,1,'Zbrano posluša krajše skladbe in jih prepozna.'),(1420,1420,17,1,'Posluša krajše skladbe; nekatere prepozna.'),(1421,1421,17,1,'Za poslušanje ga je potrebno dodatno motivirati.'),(1422,1422,17,1,'prepozna posamezne glasove in glasbila,'),(1423,1423,17,1,'Prepozna znane glasove. Po zvoku prepozna instrumente in jih poimenuje.'),(1424,1424,17,1,'Prepozna nekatere glasove. Razlikuje le določene instrumente.'),(1425,1425,17,1,'Redko prepozna glasove in glasbila.'),(1426,1426,17,1,'glasbena doživetja izraža gibalno, lesno, likovno ali besedno,'),(1427,1427,17,1,'Glasbena doživetja izvirno izrazi na različne načine na  __, __,...  področju.'),(1428,1428,17,1,'Glasbena doživetja izraža s posnemanjem na plesnem, (likovnem,...) področju.'),(1429,1429,17,1,'Ne kaže interesa za glasbeno izražanje; po dodatni motivaciji jih skromno predstavi le na enem področju.'),(1430,1430,17,1,'si razvija ali poglablja melodični in ritmični posluh,'),(1431,1431,17,1,'Ustvari lastno ritmično  spremljavo. Poje z natančno intonacijo.'),(1432,1432,17,1,'Pesem, izštevanko,... spremlja po danem ritmičnem vzorcu. Melodijo pripeva v skupini.'),(1433,1433,17,1,'Posnema kratko ritmično spremljavo. Melodijo zapoje po svoje.'),(1434,1434,17,1,'razvija kakovost in spretnost igranja in petja,'),(1435,1435,17,1,'Izkaže pripravljenost za delo na glasbenem področju. Kakovost igranja in petja je na visoki ravni.'),(1436,1436,17,1,'Rad poje in igra.'),(1437,1437,17,1,'Za petje in igranje ga je potrebno spodbujati.'),(1438,1438,17,1,'pozna in uporablja načrtovan glasbeni besednjak.'),(1439,1439,17,1,'Pozna in uporablja ustrezne glasbene pojme.'),(1440,1440,17,1,'Pozna in uporablja le nekatere glasbene pojme'),(1441,1441,17,1,'Pozna nekatere izraze, a jih le redko smiselno uporabi.'),(1442,1442,42,0,'poje nov izbor ljudskih in umetnih pesmi,'),(1443,1443,42,0,'Pravilno poje nov izbor ljudskih in umetnih pesmi.'),(1444,1444,42,0,'Netočno poje nov izbor ljudskih in umetnih pesmi.'),(1445,1445,42,0,'Poje le del novega  izbora ljudskih in umetnih pesmi.'),(1446,1446,42,0,'ritmično izreka in ritmizira otroška ljudska in umetna besedila,'),(1447,1447,42,0,'Ritmično natančno izreka in ritmizira otroška ljudska in umetna besedila.'),(1448,1448,42,0,'Ritmično nenatančno izreka in ritmizira otroška ljudska in umetna besedila.'),(1449,1449,42,0,'Ritmično izreka in ritmizira le dele otroških ljudskih in umetnih besedil.'),(1450,1450,42,0,'petje in ritmično izreko spremlja z več različnimi vzorci (ostinati),'),(1451,1451,42,0,'Petje in ritmično izreko samostojno spremlja z več različnimi vzorci (ostinati).'),(1452,1452,42,0,'Petje in ritmično izreko ob pomoči učitelja spremlja z več različnimi vzorci (ostinati).'),(1453,1453,42,0,'petje in ritmično izreko spremlja z gibalno-plesnim ljudskim izročilom.'),(1454,1454,42,0,'Petje in ritmično izreko ustvarjalno spremlja z gibalno-plesnim ljudskim izročilom.'),(1455,1455,42,0,'Petje in ritmično izreko spremlja z gibalno-plesnim ljudskim izročilom.'),(1456,1456,42,0,'Petje in ritmično izreko ob spodbudah spremlja z gibalno-plesnim ljudskim izročilom.'),(1457,1457,43,0,'samostojneje doživljajsko izraža glasbene vsebine,'),(1458,1458,43,0,'Samostojneje doživljajsko izraža glasbene vsebine.'),(1459,1459,43,0,'Ob pomoči doživljajsko izraža glasbene vsebine.'),(1460,1460,43,0,'z glasom in glasbili oblikuje več vzorcev spremljav,'),(1461,1461,43,0,'Z glasom in glasbili domiselno  oblikuje več vzorcev spremljav.'),(1462,1462,43,0,'Z glasom in glasbili s pomočjo oblikuje več vzorcev spremljav.'),(1463,1463,43,0,'Z glasom in glasbili oblikuje  spremljavo,vendar pogosto posnema ideje sošolcev.'),(1464,1464,43,0,'pri izmišljanju zvočnih vsebin uporablja več izraznih sredstev,'),(1465,1465,43,0,'Pri izmišljanju zvočnih vsebin pogosto uporablja več izraznih sredstev.'),(1466,1466,43,0,'Pri izmišljanju zvočnih vsebin občasno uporablja več izraznih sredstev.'),(1467,1467,43,0,'Pri izmišljanju zvočnih vsebin ob pomoči uporablja več izraznih sredstev.'),(1468,1468,43,0,'glasbena doživetja in predstave izraža v različnih oblikah komunikacije.'),(1469,1469,43,0,'Glasbena doživetja in predstave ustvarjalno izraža v različnih oblikah komunikacije.'),(1470,1470,43,0,'Glasbena doživetja in predstave ob spodbudah izraža v različnih oblikah komunikacije.'),(1471,1471,43,0,'Glasbena doživetja in predstave skromno izraža le na enem področju.'),(1472,1472,44,0,'aktivno posluša nov izbor načrtovanih vokalnih in inštrumentalnih skladb in jih prepoznava,'),(1473,1473,44,0,'Aktivno posluša nov izbor načrtovanih vokalnih in inštrumentalnih skladb in jih prepoznava.'),(1474,1474,44,0,'Ob spodbudi posluša nov izbor načrtovanih vokalnih in inštrumentalnih skladb in jih delno prepoznava.'),(1475,1475,44,0,'Kratkotrajno posluša nov izbor načrtovanih vokalnih in inštrumentalnih skladb in jih delno prepoznava.'),(1476,1476,44,0,'ob poslušanju prepoznava skladbe in razlikuje izrazna sredstva (obravnavane inštrumente, orkester, pevski glas, otroški zbor),'),(1477,1477,44,0,'Ob poslušanju samostojno prepoznava skladbe in razlikuje izrazna sredstva (obravnavane inštrumente, orkester, pevski glas, otroški zbor).'),(1478,1478,44,0,'Ob poslušanju ob pomoči prepoznava skladbe in delno razlikuje izrazna sredstva (obravnavane inštrumente, orkester, pevski glas, otroški zbor).'),(1479,1479,44,0,'Ob poslušanju ob pomoči prepoznava skladbe in še ne razlikuje veliko izraznih sredstev (obravnavane inštrumente, orkester, pevski glas, otroški zbor).'),(1480,1480,44,0,'razlikuje zvoke in njihove lastnosti (glasnost, hitrost, barvo).'),(1481,1481,44,0,'Pozna in razlikuje zvoke in njihove lastnosti (glasnost, hitrost, barvo).'),(1482,1482,44,0,'Pozna zvoke in njihove lastnosti (glasnost, hitrost, barvo).'),(1483,1483,45,0,'poglablja melodični in ritmični posluh,'),(1484,1484,45,0,'Ima razvit melodični in ritmični posluh.'),(1485,1485,45,0,'Melodični in ritmični posluh sta še v razvoju.'),(1486,1486,45,0,'Ima razvit ritmični posluh, melodični je še v razvoju.'),(1487,1487,45,0,'razširi obseg pevskega glasu in stopnjuje kakovost pevske izreke in pevskega dihanja,'),(1488,1488,45,0,'Razširi obseg pevskega glasu in stopnjuje kakovost pevske izreke in pevskega dihanja.'),(1489,1489,45,0,'pozna pravilno držo in razvija tehniko igranja glasbil,'),(1490,1490,45,0,'Pozna pravilno držo in razvija tehniko igranja glasbil.'),(1491,1491,45,0,'Delno pozna pravilno držo in počasi razvija tehniko igranja glasbil.'),(1492,1492,45,0,'razume in uporablja načrtovane glasbene pojme in razširi glasbeni besednjak,'),(1493,1493,45,0,'Razume in uporablja načrtovane glasbene pojme in razširi glasbeni besednjak.'),(1494,1494,45,0,'Razume  načrtovane glasbene pojme in razširi glasbeni besednjak.'),(1495,1495,45,0,'Razume in delno uporablja  načrtovane glasbene pojme in razširi glasbeni besednjak.'),(1496,1496,45,0,'se orientira v slikovnem glasbenem zapisu.'),(1497,1497,45,0,'Samostojno se pravilno orientira v slikovnem glasbenem zapisu.'),(1498,1498,45,0,'Ob vodenju učitelja se pravilno orientira v slikovnem glasbenem zapisu.'),(1499,1499,45,0,'Ob vodenju učitelja sledi slikovnim glasbenim zapisom.'),(1500,1500,46,1,'poje načrtovan izbor pesmi,'),(1501,1501,46,1,'Pozna besedila pesmi in jih ritmično ter melodično pravilno zapoje.'),(1502,1502,46,1,'Delno pozna besedila pesmi. Ritmično in melodično pravilno zapoje.'),(1503,1503,46,1,'Še ne pozna besedil vseh pesmi. Ritmično in melodično pravilno zapoje le nekatere pesmi.'),(1504,1504,46,1,'igra na lastna, improvizirana in Orffova glasbila,'),(1505,1505,46,1,'Po barvi zvoka prepozna glasbila in jih poimenuje. Ritmično pravilno igra na glasbila in zahtevnejše ritmične vzorce.'),(1506,1506,46,1,'Po barvi zvoka prepozna večino glasbil, poimenuje le nekatere. Na glasbila izvaja enostavne ritmične vzorce.'),(1507,1507,46,1,'Prepozna in poimenuje le nekatera glasbila. Ritmične vzorce izvaja v lastnem tempu.'),(1508,1508,46,1,'ustvarja in si izmišlja vzorce spremljav in zvočne vsebine,'),(1509,1509,46,1,'Ustvarjalno oblikuje ritmične spremljave. Ustvarjalno si izmišlja melodije na dano besedilo.'),(1510,1510,46,1,'Oblikuje enostavne ritmične spremljave. Izmisli si enostavno melodijo na dano besedilo.'),(1511,1511,46,1,'Posnema dane vzorce spremljav. Ne kaže interesa za glasbeno ustvarjanje'),(1512,1512,46,1,'aktivno posluša izbor načrtovanih skladb,'),(1513,1513,46,1,'Zbrano posluša načrtovan izbor skladb.'),(1514,1514,46,1,'Ob spodbudi posluša načrtovan izbor skladb.'),(1515,1515,46,1,'Pri poslušanju glasbe je pozoren le kratek čas.'),(1516,1516,46,1,'prepoznava skladbe in načrtovana izrazna sredstva,'),(1517,1517,46,1,'Prepozna in loči izrazna sredstva.'),(1518,1518,46,1,'Prepozna le nekatere skladbe in izrazna sredstva.'),(1519,1519,46,1,'Še ne pozna vseh skladb in izraznih sredstev.'),(1520,1520,46,1,'glasbena doživetja izraža v različnih oblikah komunikacije,'),(1521,1521,46,1,'Ustvarjalno izraža glasbena doživetja v različnih oblikah komunikacije.'),(1522,1522,46,1,'Ob spodbudi izraža glasbena doživetja.'),(1523,1523,46,1,'Glasbena doživetja skromno predstavi le na enem področju.'),(1524,1524,46,1,'stopnjuje kakovost ritmičnega in melodičnega posluha,'),(1525,1525,46,1,'Ima razvit melodični in ritmični posluh.'),(1526,1526,46,1,'Ritmični in melodični posluh sta še v razvoju'),(1527,1527,46,1,'Ima razvit ritmični posluh, melodični posluh je še v razvoju.'),(1528,1528,46,1,'poglablja tehniko petja in igranja glasbil,'),(1529,1529,46,1,'Je osvojil tehniko petja in igranja glasbil.'),(1530,1530,46,1,'Osvaja tehniko petja in igranja glasbil.'),(1531,1531,46,1,'Še ni osvojil tehniko petja in igranja glasbil.'),(1532,1532,46,1,'pozna načrtovane pojme in uporablja širši glasbeni besednjak,'),(1533,1533,46,1,'Pozna in smiselno uporablja glasbeni besednjak.'),(1534,1534,46,1,'Pozna in občasno uporablja glasbeni besednjak.'),(1535,1535,46,1,'Pozna le nekatere pojme in le redko uporablja glasbeni besednjak.'),(1536,1536,46,1,'razume simboličnost slikovnega glasbenega zapisa.'),(1537,1537,46,1,'Razume slikovni glasbeni zapis in mu sledi ob petju.'),(1538,1538,46,1,'Delno razume slikovni glasbeni zapis in mu sledi.'),(1539,1539,46,1,'Še ne razume slikovnega glasbenega zapisa.'),(1540,1540,71,0,'ob spremljavi ali brez nje enoglasno poje ljudske in umetne pesmi,'),(1541,1541,71,0,'Ob spremljavi ali brez nje enoglasno poje ljudske in umetne pesmi.'),(1542,1542,71,0,'Ob spremljavi ali brez nje netočno enoglasno poje ljudske in umetna pesmi.'),(1543,1543,71,0,'Ob spremljavi ali brez nje zna enoglasno zapeti le nekatere dele ljudskih in umetnih pesmi.'),(1544,1544,71,0,'ritmično izreka otroška besedila,'),(1545,1545,71,0,'Ritmično izreka otroška besedila.'),(1546,1546,71,0,'Ritmično nenatančno izreka otroška besedila.'),(1547,1547,71,0,'petje in ritmično izreko spremlja z različnimi vzorci (ostinati),'),(1548,1548,71,0,'Petje in ritmično izreko spremlja z različnimi vzorci.'),(1549,1549,71,0,'Petje in ritmično izreko ob spodbudah spremlja z različnimi vzorci.'),(1550,1550,71,0,'na glasbilih (Orffovih, ljudskih) igra spremljave in krajše instrumentalne vsebine,'),(1551,1551,71,0,'Na glasbilih igra spremljave in krajše instrumentalne vsebine.'),(1552,1552,71,0,'Na glasbilih ob pomoči učitelja igra spremljave in krajše instrumentalne vsebine.'),(1553,1553,71,0,'pri petju in igranju na glasbila upošteva izvajalsko tehniko ter elemente estetskega oblikovanja,'),(1554,1554,71,0,'Pri petju in igranju na glasbila upošteva izvajalsko tehniko ter elemente estetskega oblikovanja.'),(1555,1555,71,0,'Pri petju in igranju na glasbila slabo upošteva izvajalsko tehniko ter elemente estetskega oblikovanja.'),(1556,1556,71,0,'petje in ritmično izreko spremlja z gibanjem in plesom.'),(1557,1557,71,0,'Petje in ritmično izreko spremlja z gibanjem in plesom.'),(1558,1558,71,0,'Petje in ritmično izreke ob spodbudah spremlja z gibanjem in plesom.'),(1559,1559,72,0,'doživljajsko in estetsko poustvarja naučene pesmi, ritmična besedila ter instrumentalne vsebine,'),(1560,1560,72,0,'Doživljajsko in estetsko poustvarja naučene pesmi, ritmična besedila ter instrumentalne vsebine.'),(1561,1561,72,0,'Poustvarja naučene pesmi,ritmična besedila ter instrumentalne vsebine.'),(1562,1562,72,0,'oblikuje spremljave za pesmi in besedila,'),(1563,1563,72,0,'Oblikuje spremljave za pesmi in besedila.'),(1564,1564,72,0,'Ob pomoči učitelja oblikuje spremljave za pesmi.'),(1565,1565,72,0,'izmišlja si melodije na dano besedilo,'),(1566,1566,72,0,'Izmišlja si melodije na dano besedilo.'),(1567,1567,72,0,'Ob pomoči učitelja si izmišlja melodije na dano besedilo.'),(1568,1568,72,0,'raziskuje zvočnost glasbil in zvočil ter oblikuje lastne zvočne vsebine,'),(1569,1569,72,0,'Raziskuje zvočnost glasbil in zvočil ter oblikuje lastne zvočne vsebine.'),(1570,1570,72,0,'Razlikuje zvočnost glasbil in zvočil. Ob pomoči učitelja oblikuje lastne zvočne vsebine.'),(1571,1571,72,0,'glasbena doživetja in predstave ustvarjalno izraža v gibanju, plesu, besedah in likovno.'),(1572,1572,72,0,'Glasbena doživetja in predstave ustvarjalno izraža v gibanju, plesu, besedah in likovno.'),(1573,1573,72,0,'Ob vodenju učitelja glasbena doživetja in predstave izraža v gibanju, plesu,besedah in likovno.'),(1574,1574,73,0,'poglablja točno intonacijo in točno ritmično izvajanje;'),(1575,1575,73,0,'Poglablja točno intonacijo in točno ritmično izvajanje.'),(1576,1576,73,0,'Razvija točno intonacijo in točno ritmično izvajanje.'),(1577,1577,73,0,'širi obseg pevskega glasu in stopnjuje kakovost pevske izreke in pevskega dihanje,'),(1578,1578,73,0,'Širi obseg pevskega glasu in stopnjuje kakovost pevske izreke in pevskega dihanje.'),(1579,1579,73,0,'Širi obseg pevskega glasu in ob spodbudah stopnjuje kakovost pevske izreke in dihanja.'),(1580,1580,73,0,'stopnjuje spretnost instrumentalne igre,'),(1581,1581,73,0,'Stopnjuje spretnost instrumentalne igre.'),(1582,1582,73,0,'Razvija instrumentalno igro.'),(1583,1583,73,0,'se navaja na sozvočja,'),(1584,1584,73,0,'Navaja se na sozvočja.'),(1585,1585,73,0,'Težje se navaja na sozvočja.'),(1586,1586,73,0,'ob petju in igranju glasbil poglablja sposobnost estetskega oblikovanja (artikulacija, fraziranje, jakost, hitrost),'),(1587,1587,73,0,'Ob petju in igranju glasbil poglablja sposobnost estetskega oblikovanja (artikulacija, fraziranje, jakost, hitrost).'),(1588,1588,73,0,'Ob petju in igranju glasbil razvija sposobnost estetskega oblikovanja (artikulacija, fraziranje, jakost, hitrost).'),(1589,1589,73,0,'poglablja glasbeni spomin,'),(1590,1590,73,0,'Poglablja glasbeni spomin.'),(1591,1591,73,0,'Razvija glasbeni spomin.'),(1592,1592,73,0,'pozna sredstva glasbenega jezika, zvoke, tone, in tišino ter zaznava temeljne lastnosti tona; glasnejši-tišji, višji-nižji, daljši-krajši,'),(1593,1593,73,0,'Pozna sredstva glasbenega jezika, zvoke, tone, in tišino ter zaznava temeljne lastnosti tona; glasnejši-tišji, višji-nižji, daljši-krajši.'),(1594,1594,73,0,'Razlikuje sredstva glasbenega jezika, zvoke, tone, in tišino ter zaznava temeljne lastnosti tona; glasnejši-tišji, višji-nižji, daljši-krajši.'),(1595,1595,73,0,'poimenuje posamezne inštrumente, uporablja glasbene pojme: glas, zvok, ton, tišina - pavza, melodija, mera; glasbeni spored; koračnica, ples, nagajivka, glasbena pravljica,'),(1596,1596,73,0,'Poimenuje posamezne inštrumente, uporablja glasbene pojme: glas, zvok, ton, tišina - pavza, melodija, mera; glasbeni spored; koračnica, ples, nagajivka, glasbena pravljica.'),(1597,1597,73,0,'Razlikuje posamezne inštrumente, uporablja glasbene pojme: glas, zvok, ton, tišina - pavza, melodija, mera; glasbeni spored; koračnica, ples, nagajivka, glasbena pravljica.'),(1598,1598,73,0,'se orientira v slikovnih glasbenih zapisih.'),(1599,1599,73,0,'Se orientira v slikovnih glasbenih zapisih.'),(1600,1600,73,0,'Ob vodenju učitelja sledi slikovnim zapisom.'),(1601,1601,74,0,'zbrano posluša krajše skladbe s programsko in absolutno vsebino,'),(1602,1602,74,0,'Zbrano posluša krajše skladbe s programsko in absolutno vsebino.'),(1603,1603,74,0,'Posluša krajše skladbe s programsko in absolutno vsebino.'),(1604,1604,74,0,'prepoznava načrtovan izbor vokalnih in instrumentalnih skladb,'),(1605,1605,74,0,'Prepoznava načrtovan izbor vokalnih in instrumentalnih skladb.'),(1606,1606,74,0,'Delno prepozna načrtovan izbor vokalnih in instrumentalnih skladb,'),(1607,1607,74,0,'pozorno sledi glasbeni prireditvi in izbranemu glasbenemu sporedu,'),(1608,1608,74,0,'Pozorno sledi glasbeni prireditvi in izbranemu glasbenemu sporedu.'),(1609,1609,74,0,'Sledi glasbeni prireditvi in izbranemu glasbenemu sporedu.'),(1610,1610,74,0,'spremlja glasbene dogodke v svojem okolju,'),(1611,1611,74,0,'Spremlja glasbene dogodke v svojem okolju.'),(1612,1612,74,0,'Ne spremlja glasbenih dogodkov v svojem okolju.'),(1613,1613,74,0,'razlikuje pevsko in instrumentalno glasbo,'),(1614,1614,74,0,'Razlikuje pevsko in instrumentalno glasbo.'),(1615,1615,74,0,'ob poslušanju prepoznava posamezne inštrumente, pevske glasove in zasedbe.'),(1616,1616,74,0,'Ob poslušanju prepoznava posamezne inštrumente, pevske glasove in zasedbe.'),(1617,1617,74,0,'Ob poslušanju delno prepoznava posamezne inštrumente, pevske glasove in zasedbe.'),(1618,1618,75,1,'izvaja načrtovan izbor pesmi in instrumentalnih vsebin,'),(1619,1619,75,1,'Z intonacijo posnema motive in fraze ter izvaja znane pesmi. Pesmi spremlja z instrumentalno in vokalno spremljavo.'),(1620,1620,75,1,'Izvaja znane pesmi, ter posnema ritmične motive in fraze,intonacija ni vedno natančna. Pesmi in ritmično izreko spremlja z ostinatno spremljavo.'),(1621,1621,75,1,'Pri izvajanju besedila in melodije pesmi je premalo natančen. Sodeluje pri izreki in ritmiziranju izštevanke.'),(1622,1622,75,1,'pri petju in igranju upošteva temeljno tehniko in prvine estetskega oblikovanja,'),(1623,1623,75,1,'Ob petju in igranju upošteva tehniko in prvine estetskega oblikovanja. Nedokončane in ritmično melodične vsebine dopolni v smiselno celoto.'),(1624,1624,75,1,'Ob petju in igranju upošteva tehniko in poskuša izvedbo estetsko oblikovati.'),(1625,1625,75,1,'Navaja se na prepoznavanje zaključenih ritmičnih in melodičnih celot.'),(1626,1626,75,1,'ustvarja in izvaja spremljave za pesmi, besedila in lastne zvočne vsebine,'),(1627,1627,75,1,'Pri ustvarjanju in izvajanju spremljav za pesmi, besedila in lastne zvočne vsebine je kreativen.'),(1628,1628,75,1,'V skupini ustvarja in izvaja spremljave za pesmi, besedila in lastne zvočne vsebine.'),(1629,1629,75,1,'Ob spodbudi ustvarja in izvaja spremljave za pesmi, besedila in lastne zvočne vsebine.'),(1630,1630,75,1,'pozorno posluša krajše skladbe in sledi glasbenemu sporedu,'),(1631,1631,75,1,'Pozorno posluša krajše skladbe in sledi glasbenemu sporedu.'),(1632,1632,75,1,'Pozorno posluša krajše skladbe in sledi glasbenemu sporedu.'),(1633,1633,75,1,'Prepozna nekatera glasbila.'),(1634,1634,75,1,'prepoznava načrtovan izbor skladb,'),(1635,1635,75,1,'Prepozna in poimenuje načrtovan izbor skladb.'),(1636,1636,75,1,'Prepozna nekatere skladbe in jih poimenuje.'),(1637,1637,75,1,'Ob pomoči prepozna nekatere skladbe.'),(1638,1638,75,1,'ustvarjalno izraža glasbena doživetja in predstave,'),(1639,1639,75,1,'Z inovativnimi načini (ples, risba...) izraža glasbena doživetja in predstave.'),(1640,1640,75,1,'Pri izražanju glasbenih doživetij in predstav se osredotoča na že videne rešitve.'),(1641,1641,75,1,'Ob spodbudi izraža glasbena doživetja in predstave.'),(1642,1642,75,1,'zaznava ter razlikuje temeljna sredstva glasbenega jezika in lastnosti tona,'),(1643,1643,75,1,'Zaznava, razlikuje in uvrsti temeljna sredstva glasbenega jezika in lastnosti tona.'),(1644,1644,75,1,'Prepozna temeljna sredstva glasbenega jezika in lastnosti tona.'),(1645,1645,75,1,'Prepozna le nekatera sredstva glasbenega jezika in lastnosti tona.'),(1646,1646,75,1,'se orientira v slikovnih glasbenih zapisih,'),(1647,1647,75,1,'Bere glasbene zapise in se v njih orientira.'),(1648,1648,75,1,'Pri orientaciji glasbenih zapisov se še zmoti.'),(1649,1649,75,1,'Ob pomoči se orientira in bere glasbene zapise.'),(1650,1650,75,1,'razume in uporablja načrtovan glasbeni besednjak,'),(1651,1651,75,1,'Razume in pravilno uporablja načrtovan glasbeni besednjak.'),(1652,1652,75,1,'Razume načrtovan glasbeni besednjak.'),(1653,1653,75,1,'Prepozna načrtovan glasbeni besednjak.'),(1654,1654,75,1,'stopnjuje kakovost glasbenega posluha in spomina.'),(1655,1655,75,1,'Stopnjuje kakovost glasbenega posluha in spomina, kar izkaže z lastno aktivnostjo.'),(1656,1656,75,1,'Postopno razvija glasbeni posluh in spomin.'),(1657,1657,18,0,'opiše podobnosti in razlike med ljudmi,'),(1658,1658,18,0,'Samostojno opiše podobnosti in razlike med ljudmi.'),(1659,1659,18,0,'Ob pomoči opiše podobnosti in razlike med ljudmi.'),(1660,1660,18,0,'Ob pomoči opiše podobnosti in razlike med ljudmi.'),(1661,1661,18,0,'Pravilno in samostojno se predstavi z osnovnimi osebnimi podatki.'),(1662,1662,18,0,'S pomočjo vprašanj se predstavi z osnovnimi osebnimi podatki.'),(1663,1663,18,0,'prepozna in opiše različne čustvene izraze pri sebi in drugih,'),(1664,1664,18,0,'Prepozna in opiše različne čustvene izraze pri sebi in drugih.'),(1665,1665,18,0,'Prepozna  različne čustvene izraze pri sebi in drugih.'),(1666,1666,18,0,'Z učiteljevo pomočjo prepozna  različne čustvene izraze pri sebi in drugih.'),(1667,1667,19,0,'se zaveda pomena sporazumevanja,'),(1668,1668,19,0,'Zaveda se pomena sporazumevanja.'),(1669,1669,19,0,'Ne  zaveda se pomena sporazumevanja.'),(1670,1670,19,0,'spoštuje in upošteva dogovor,'),(1671,1671,19,0,'Spoštuje in upošteva dogovor.'),(1672,1672,19,0,'Spoštuje  dogovor.'),(1673,1673,19,0,'Upošteva dogovor.'),(1674,1674,19,0,'prepozna in opiše družinske skupnosti,'),(1675,1675,19,0,'Samostojno prepozna in opiše družinske skupnosti.'),(1676,1676,19,0,'Prepozna in opiše družinske skupnosti.'),(1677,1677,19,0,'Prepozna  družinske skupnosti.'),(1678,1678,19,0,'S pomočjo učitelja prepozna  družinske skupnosti.'),(1679,1679,19,0,'poimenuje razmerja med člani v družini (npr. brat, sestra, sin, hči, starši, stari starši).'),(1680,1680,19,0,'Poimenuje razmerja med člani v družini (npr. brat, sestra, sin, hči, starši, stari starši).'),(1681,1681,19,0,'S pomočjo vprašanj poimenuje razmerja med člani v družini (npr. brat, sestra, sin, hči, starši, stari starši).'),(1682,1682,19,0,'Ob dodatni spodbudi poimenuje razmerja med člani v družini (npr. brat, sestra, sin, hči, starši, stari starši).'),(1683,1683,20,0,'predstavi osnovne podatke o svoji šoli in opiše delo, ki ga opravljajo zaposleni,'),(1684,1684,20,0,'Predstavi osnovne podatke o svoji šoli in opiše delo, ki ga opravljajo zaposleni.'),(1685,1685,20,0,'Predstavi osnovne podatke o svoji šoli in s pomočjo vprašanj opiše delo, ki ga opravljajo zaposleni.'),(1686,1686,20,0,'Predstavi osnovne podatke o svoji šoli.'),(1687,1687,20,0,'poimenuje različne prostore v šoli in pozna njihovo namembnost,'),(1688,1688,20,0,'Poimenuje različne prostore v šoli in pozna njihovo namembnost.'),(1689,1689,20,0,'Poimenuje različne prostore v šoli.'),(1690,1690,20,0,'upošteva osnovna šolska pravila,'),(1691,1691,20,0,'V celoti upošteva osnovna šolska pravila.'),(1692,1692,20,0,'Delno upošteva osnovna šolska pravila.'),(1693,1693,20,0,'Ne upošteva osnovnih šolskih pravil.'),(1694,1694,21,0,'pozna pomen praznovanja določenih dni (npr. rojstni dan, dan šole, dan državnosti) in jih opiše,'),(1695,1695,21,0,'Pozna pomen praznovanja določenih dni (npr. rojstni dan, dan šole, dan državnosti) in jih opiše.'),(1696,1696,21,0,'Pozna pomen praznovanja določenih dni in jih ob pomoči opiše.'),(1697,1697,21,0,'Pozna pomen praznovanja določenih dni.'),(1698,1698,21,0,'sodeluje pri pripravi praznovanj,'),(1699,1699,21,0,'Sodeluje pri pripravi praznovanj.'),(1700,1700,22,0,'razlikuje med preteklostjo in sedanjostjo v svojem življenju,'),(1701,1701,22,0,'Razlikuje med preteklostjo in sedanjostjo v svojem življenju.'),(1702,1702,22,0,'Z učiteljevo pomočjo razlikuje med preteklostjo in sedanjostjo v svojem življenju.'),(1703,1703,22,0,'Ne razlikuje med preteklostjo in sedanjostjo v svojem življenju.'),(1704,1704,22,0,'poimenuje in uporabi osnovne časovne izraze,'),(1705,1705,22,0,'Poimenuje in uporabi osnovne časovne izraze.'),(1706,1706,22,0,'Poimenuje in občasno uporabi osnovne časovne izraze.'),(1707,1707,22,0,'Poimenuje in še ne uporablja osnovnih časovnih izrazov.'),(1708,1708,22,0,'prepoznava drugačnost življenja v preteklosti,'),(1709,1709,22,0,'Prepoznava drugačnost življenja v preteklosti.'),(1710,1710,22,0,'Ne prepoznava drugačnost življenja v preteklosti.'),(1711,1711,23,0,'prepozna in opiše značilna okolja v bližnji okolici šole in doma,'),(1712,1712,23,0,'Samostojno prepozna in opiše značilna okolja v bližnji okolici šole in doma.'),(1713,1713,23,0,'Občasno prepozna in opiše značilna okolja v bližnji okolici šole in doma.'),(1714,1714,23,0,'Ob dodatni pomoči prepozna in opiše značilna okolja v bližnji okolici šole in doma.'),(1715,1715,23,0,'Ob dodatni pomoči prepozna  značilna okolja v bližnji okolici šole in doma.'),(1716,1716,23,0,'prepozna in opiše spremembe v živi in neživi naravi,'),(1717,1717,23,0,'Samostojno prepozna in opiše spremembe v živi in neživi naravi.'),(1718,1718,23,0,'Samostojno prepozna  spremembe v živi in neživi naravi.'),(1719,1719,23,0,'S pomočjo učitelja prepozna in opiše spremembe v živi in neživi naravi.'),(1720,1720,23,0,'S pomočjo učitelja prepozna spremembe v živi in neživi naravi.'),(1721,1721,23,0,'poimenuje najpogostejše živali in rastline v bližnjem okolju,'),(1722,1722,23,0,'Samostojno poimenuje najpogostejše živali in rastline v bližnjem okolju.'),(1723,1723,23,0,'Z učiteljevo pomočjo poimenuje najpogostejše živali in rastline v bližnjem okolju.'),(1724,1724,23,0,'poimenuje dele telesa živali in dele rastlin iz njihovega okolja,'),(1725,1725,23,0,'Samostojno poimenuje dele telesa živali in dele rastlin iz njihovega okolja.'),(1726,1726,23,0,'Poimenuje dele telesa živali  iz njihovega okolja.'),(1727,1727,23,0,'Poimenuje  dele rastlin iz njihovega okolja.'),(1728,1728,23,0,'Ob pomoči poimenuje dele telesa živali in dele rastlin iz njihovega okolja.'),(1729,1729,23,0,'ve, da živa bitja za svoje življenje potrebujejo prostor, zrak, vodo, svetlobo, primerno temperaturo in hrano,'),(1730,1730,23,0,'Ve, da živa bitja za svoje življenje potrebujejo prostor, zrak, vodo, svetlobo, primerno temperaturo in hrano.'),(1731,1731,23,0,'Zna našteti pogoje za življenje:zrak, vodo, hrano....'),(1732,1732,23,0,'Ob učiteljevi pomoči našteje pogoje za življenje: hrana, zrak, prostor....'),(1733,1733,23,0,'žival, človeka in rastlino umesti v ustrezno življenjsko okolje,'),(1734,1734,23,0,'Žival, človeka in rastlino samostojno umesti v ustrezno življenjsko okolje.'),(1735,1735,23,0,'Žival, človeka in rastlino s pomočjo učitelja umesti v ustrezno življenjsko okolje.'),(1736,1736,23,0,'Žival, človeka in rastlino ne zna umestiti v ustrezno življenjsko okolje.'),(1737,1737,24,0,'poimenuje snovi in organizme, ki škodujejo zdravju,'),(1738,1738,24,0,'Zna poimenovati snovi in organizme, ki škodujejo zdravju.'),(1739,1739,24,0,'Zna poimenovati nekaj snovi in organizmov, ki škodujejo zdravju.'),(1740,1740,24,0,'Poimenuje le nekaj snovi in organizmov, ki škodujejo zdravju.'),(1741,1741,24,0,'se zaveda, da uživanje različne zdrave hrane, telesne vaje, počitek in redna nega pomagajo ohranjati zdravje in dobro počutje,'),(1742,1742,24,0,'Zaveda se, da uživanje različne zdrave hrane, telesne vaje, počitek in redna nega pomagajo ohranjati zdravje in dobro počutje.'),(1743,1743,24,0,'pripravi napitek in preprosto jed,'),(1744,1744,24,0,'Samostojno pripravi napitek in preprosto jed,'),(1745,1745,24,0,'Pomaga pri pripravi napitek in preprosto jed,'),(1746,1746,25,0,'se orientira v šoli in njeni okolici,'),(1747,1747,25,0,'Zna se orientirati v šoli in njeni okolici.'),(1748,1748,25,0,'Z učiteljevo pomočjo se orientira v šoli in njeni okolici.'),(1749,1749,25,0,'Slabo se orientira v šoli in njeni okolici.'),(1750,1750,25,0,'poimenuje osnovne geografske značilnosti in pojme o površju v neposredni okolici šole,'),(1751,1751,25,0,'Poimenuje osnovne geografske značilnosti in pojme o površju v neposredni okolici šole.'),(1752,1752,25,0,'S pomočjo vprašanj poimenuje osnovne geografske značilnosti in pojme o površju v neposredni okolici šole.'),(1753,1753,25,0,'s svojimi besedami opiše, kako ljudje vplivajo na naravo,'),(1754,1754,25,0,'S svojimi besedami opiše, kako ljudje vplivajo na naravo.'),(1755,1755,25,0,'S pomočjo vprašanj s svojimi besedami opiše, kako ljudje vplivajo na naravo.'),(1756,1756,25,0,'Le ob pomoči opiše s svojimi besedami, kako ljudje vplivajo na naravo.'),(1757,1757,25,0,'prepozna in opiše pomembne prometne znake za pešce in kolesarje v okolici šole,'),(1758,1758,25,0,'Prepozna in opiše pomembne prometne znake za pešce in kolesarje v okolici šole.'),(1759,1759,25,0,'Prepozna  pomembne prometne znake za pešce in kolesarje v okolici šole.'),(1760,1760,25,0,'Opiše pomembne prometne znake za pešce in kolesarje v okolici šole.'),(1761,1761,25,0,'opiše varno pot v šolo ter prometna pravila, ki veljajo za pešce.'),(1762,1762,25,0,'Opiše varno pot v šolo ter prometna pravila, ki veljajo za pešce.'),(1763,1763,25,0,'Z učiteljevo pomočjo opiše varno pot v šolo ter prometna pravila, ki veljajo za pešce.'),(1764,1764,25,0,'Z učiteljevo pomočjo opiše varno pot v šolo.'),(1765,1765,26,0,'Snovi in telesa - opiše lastnosti teles in snovi in jih razvrsti glede na eno lastnost,'),(1766,1766,26,0,'Samostojno opiše lastnosti teles in snovi in jih razvrsti glede na eno lastnost.'),(1767,1767,26,0,'Z učiteljevo pomočjo opiše lastnosti teles in snovi in jih razvrsti glede na eno lastnost.'),(1768,1768,26,0,'Z učiteljevo pomočjo opiše lastnosti teles in snovi.'),(1769,1769,26,0,'Snovi in telesa - poimenuje in opiše lastnosti tekočin, jih preliva in našteje glagole, ki se uporabljajo pri dejavnostih s tekočinami,'),(1770,1770,26,0,'Poimenuje in opiše lastnosti tekočin, jih preliva in našteje glagole, ki se uporabljajo pri dejavnostih s tekočinami.'),(1771,1771,26,0,'Poimenuje  lastnosti tekočin, jih preliva in našteje glagole, ki se uporabljajo pri dejavnostih s tekočinami.'),(1772,1772,26,0,'Poimenuje  lastnosti tekočin in jih preliva.'),(1773,1773,26,0,'Snovi in telesa - prepozna različna gradiva, poimenuje orodja in jih uporabi pri izdelovanju izdelkov iz papirja, gline in naravnih materialov.'),(1774,1774,26,0,'Prepozna različna gradiva, poimenuje orodja in jih uporabi pri izdelovanju izdelkov iz papirja, gline in naravnih materialov.'),(1775,1775,26,0,'Prepozna različna gradiva in uporabi orodja  pri izdelovanju izdelkov iz papirja, gline in naravnih materialov.'),(1776,1776,26,0,'Uporabi orodja  pri izdelovanju izdelkov iz papirja, gline in naravnih materialov.'),(1777,1777,26,0,'Gibanje in sile - opiše in poimenuje lastno gibanje, gibanje živali in predmetov,'),(1778,1778,26,0,'Samostojno opiše in poimenuje lastno gibanje, gibanje živali in predmetov.'),(1779,1779,26,0,'Samostojno opiše  lastno gibanje, gibanje živali in predmetov.'),(1780,1780,26,0,'S pomočjo vprašanj opiše in poimenuje lastno gibanje, gibanje živali in predmetov.'),(1781,1781,26,0,'S pomočjo vprašanj opiše in poimenuje lastno gibanje, gibanje živali in predmetov.'),(1782,1782,26,0,'Gibanje in sile - povezuje gibanje s sledovi gibanja,'),(1783,1783,26,0,'Povezuje gibanje s sledovi gibanja.'),(1784,1784,26,0,'Še ne povezuje gibanja s sledovi gibanja.'),(1785,1785,26,0,'Gibanje in sile - sestavi in razstavi preprosto tehnično igračo ter razlikuje sestavne dele celote.'),(1786,1786,26,0,'Sestavi in razstavi preprosto tehnično igračo ter razlikuje sestavne dele celote.'),(1787,1787,26,0,'Sestavi  preprosto tehnično igračo ter razlikuje sestavne dele celote.'),(1788,1788,26,0,'Razstavi preprosto tehnično igračo ter razlikuje sestavne dele celote.'),(1789,1789,26,0,'Prenos informacij in urejanje podatkov - uredi potrebščine, igrače, orodja in delovni prostor po dogovorjenih merilih in po končanem delu pospravi prostor,'),(1790,1790,26,0,'Samostojno uredi potrebščine, igrače, orodja in delovni prostor po dogovorjenih merilih in po končanem delu pospravi prostor.'),(1791,1791,26,0,'Občasno uredi potrebščine, igrače, orodja in delovni prostor po dogovorjenih merilih in po končanem delu pospravi prostor.'),(1792,1792,26,0,'Ob dodatni spodbudi uredi potrebščine, igrače, orodja in delovni prostor po dogovorjenih merilih in po končanem delu pospravi prostor.'),(1793,1793,26,0,'Prenos informacij in urejanje podatkov - razlikuje različne načine prenosa podatkov (časopis, radio, televizija, internet).'),(1794,1794,26,0,'Razlikuje različne načine prenosa podatkov (časopis, radio, televizija, internet).'),(1795,1795,26,0,'Loči različne načine prenosa podatkov (časopis, radio, televizija, internet).'),(1796,1796,26,0,'S pomočjo učitelja razlikuje različne načine prenosa podatkov (časopis, radio, televizija, internet).'),(1797,1797,26,0,'Prenos informacij in urejanje podatkov - našteje in prepozna pomembne telefonske številke.'),(1798,1798,26,0,'Samostojno našteje in prepozna pomembne telefonske številke.'),(1799,1799,26,0,'Našteje  pomembne telefonske številke.'),(1800,1800,26,0,'Prepozna pomembne telefonske številke.'),(1801,1801,26,0,'Ob učiteljevi pomoči našteje in prepozna pomembne telefonske številke.'),(1802,1802,26,0,'Vreme - opiše vremensko stanje in vremenske pojave,'),(1803,1803,26,0,'Samostojno opiše vremensko stanje in vremenske pojave.'),(1804,1804,26,0,'Ob pomoči opiše vremensko stanje in vremenske pojave.'),(1805,1805,26,0,'Opiše vremensko stanje.'),(1806,1806,26,0,'Našteje vremenske pojave,'),(1807,1807,26,0,'Vreme - opiše vpliv vremena na živali in na ljudi.'),(1808,1808,26,0,'Samostojno opiše vpliv vremena na živali in na ljudi.'),(1809,1809,26,0,'S pomočjo učiteljevih vprašanj opiše vpliv vremena na živali in na ljudi.'),(1810,1810,27,1,'usmerjeno opazuje,'),(1811,1811,27,1,'Sistematično in natančno opazuje, raziskuje in predstavi rezultate.'),(1812,1812,27,1,'K natančnemu opazovanju ga je potrebno usmerjati.'),(1813,1813,27,1,'Opazuje in raziskuje ob pomoči. Pozoren je na posamezne elemente.'),(1814,1814,27,1,'Na načrtno opazovanje ga je potrebno navajati. Zazna le posamezne elemente in ne uvidi celote.'),(1815,1815,27,1,'razvršča predmete iz žive in nežive narave in snovi,'),(1816,1816,27,1,'Ugotovi kriterij razvrščanja in utemelji  svoje ugotovitve.'),(1817,1817,27,1,'Razvršča po eni lastnosti.'),(1818,1818,27,1,'Po navodilu razvršča.'),(1819,1819,27,1,'Pri razvrščanju potrebuje pomoč.'),(1820,1820,27,1,'opisuje snovi, predmete, gibanje, vreme, rastline, živali in okolico, pri tem uporablja ustrezno besedišče,'),(1821,1821,27,1,'Sistematično uporablja  naravoslovne pojme, s katerimi opiše snovi, predmete, gibanje, vreme, rastline, živali, okolico.'),(1822,1822,27,1,'Pri opisu snovi, predmetov, gibanja,... uporablja primerno besedišče.'),(1823,1823,27,1,'Pri opisu snovi, predmetov,... uporablja besedišče iz svojega okolja.'),(1824,1824,27,1,'Pri opisu snovi, predmetov,... ni samostojen.'),(1825,1825,27,1,'razume navodila in se po njih ravna,'),(1826,1826,27,1,'Razume in dosledno upošteva navodila'),(1827,1827,27,1,'Razume navodila in se po njih ravna.'),(1828,1828,27,1,'Razume preprosta navodila in se večinoma po njih ravna.'),(1829,1829,27,1,'Navodil ne razume; delo opravi ob pomoči.'),(1830,1830,27,1,'ravna po pravilih, ki veljajo za pešce v prometu,'),(1831,1831,27,1,'Ravna skladno s prometnimi pravili za pešce.'),(1832,1832,27,1,'Pozna prometna pravila za pešce in jih delno upošteva.'),(1833,1833,27,1,'Pozna nekatera prometna pravila za pešce in jih upošteva, ko čuti nadzor.'),(1834,1834,27,1,'Pozna nekatera prometna pravila za pešce, a jih ne upošteva.'),(1835,1835,27,1,'se predstavi z osnovnimi osebnimi podatki,'),(1836,1836,27,1,'Predstavi se z vsemi osebnimi podatki.'),(1837,1837,27,1,'Predstavi se z osnovnimi osebnimi podatki.'),(1838,1838,27,1,'Predstavi se z imenom in priimkom.'),(1839,1839,27,1,'prepozna in oriše družinske skupnosti, poimenuje družinske člane,'),(1840,1840,27,1,'Poimenuje in utemelji odnose v družini. Označi različne družinske skupnosti.'),(1841,1841,27,1,'Prepozna in poimenuje sorodstvene odnose v družini. Ve, da vse družinske skupnosti niso enake.'),(1842,1842,27,1,'Poimenuje družinske člane po imenu in sorodstvenih odnosih. Prepoznava različne družinske skupnosti.'),(1843,1843,27,1,'Našteje člane svoje družine. Ob pomoči prepoznava različne družinske skupnosti.'),(1844,1844,27,1,'se orientira v šoli, poimenuje šolske prostore,'),(1845,1845,27,1,'Pozna bistvene podatke o svoji šoli. Orientira se v šolski stavbi in njeni okolici.'),(1846,1846,27,1,'Pozna delavce šole in njihovo funkcijo. Orientira se v šolskih prostorih.'),(1847,1847,27,1,'Pozna tiste delavce šole, s katerimi ima stik. Ob usmeritvi se orientira v šolskih prostorih.'),(1848,1848,27,1,'Pozna učiteljico, vzgojiteljico,...Ob pomoči se orientira v šolskih prostorih.'),(1849,1849,27,1,'smiselno uporablja nekatere izraze za opredeljevanje časa.'),(1850,1850,27,1,'Je časovno orientiran'),(1851,1851,27,1,'Smiselno uporablja določene izraze za opredeljevanje časa.'),(1852,1852,27,1,'Razume časovne pojme, a jih vedno ne uporablja pravilno.'),(1853,1853,27,1,'Časovno je slabo orientiran'),(1854,1854,47,0,'razlikuje in opiše nekaj medsebojnih odnosov med različnimi ljudmi (spoštovanje, skrb, prijaznost, sodelovanje, prijateljstvo),'),(1855,1855,47,0,'Razlikuje in opiše nekaj medsebojnih odnosov med različnimi ljudmi (spoštovanje, skrb, prijaznost, sodelovanje, prijateljstvo).'),(1856,1856,47,0,'Razlikuje in s pomočjo vprašanj  opiše nekaj medsebojnih odnosov med različnimi ljudmi (spoštovanje, skrb, prijaznost, sodelovanje, prijateljstvo).'),(1857,1857,47,0,'Razlikuje  nekaj medsebojnih odnosov med različnimi ljudmi (spoštovanje, skrb, prijaznost, sodelovanje, prijateljstvo).'),(1858,1858,47,0,'pripoveduje o svojih dolžnostih,'),(1859,1859,47,0,'Samostojno pripoveduje o svojih dolžnostih.'),(1860,1860,47,0,'S pomočjo vprašanj pripoveduje o svojih dolžnostih.'),(1861,1861,47,0,'prepoznava in opiše različnost med ljudmi (glede na spol, barvo kože, govorico, zdravje, imetje) in se zaveda pomena strpnosti v povezavi z drugačnostjo.'),(1862,1862,47,0,'Prepoznava in opiše različnost med ljudmi  in se zaveda pomena strpnosti v povezavi z drugačnostjo.'),(1863,1863,47,0,'Prepoznava in s pomočjo vprašanj opiše različnost med ljudmi in se zaveda pomena strpnosti v povezavi z drugačnostjo.'),(1864,1864,47,0,'Z učiteljevo pomočjo prepoznava  različnost med ljudmi  in ve za pomembnost strpnosti v povezavi z drugačnostjo.'),(1865,1865,48,0,'našteje in opiše različne dejavnosti, ki poleg pouka potekajo v šoli,'),(1866,1866,48,0,'Samostojno našteje in opiše različne dejavnosti, ki poleg pouka potekajo v šoli.'),(1867,1867,48,0,'Našteje  različne dejavnosti, ki poleg pouka potekajo v šoli, opiše tiste, v katerih sodeluje.'),(1868,1868,48,0,'Ob pomoči opiše  dejavnosti, ki poleg pouka potekajo v šoli, vendar le tiste, v katerih sodeluje.'),(1869,1869,48,0,'opiše delo različnih delavcev na šoli (ravnatelja, učitelja, knjižničarja, tajnice, hišnika in drugih).'),(1870,1870,48,0,'Opiše delo različnih delavcev na šoli (ravnatelja, učitelja, knjižničarja, tajnice, hišnika in drugih).'),(1871,1871,48,0,'S pomočjo vprašanj opiše delo različnih delavcev na šoli (ravnatelja, učitelja, knjižničarja, tajnice, hišnika in drugih).'),(1872,1872,49,0,'našteje in opiše nekaj praznikov, ki jih pozna,'),(1873,1873,49,0,'Samostojno našteje in opiše nekaj praznikov, ki jih pozna.'),(1874,1874,49,0,'Našteje nekaj praznikov, ki jih pozna.'),(1875,1875,49,0,'Ob vprašanjih našteje in opiše nekaj praznikov, ki jih pozna.'),(1876,1876,49,0,'S pomočjo našteje nekaj praznikov, ki jih pozna.'),(1877,1877,49,0,'navede nekaj ljudskih običajev.'),(1878,1878,49,0,'Samostojno navede nekaj ljudskih običajev.'),(1879,1879,49,0,'Z učiteljevo pomočjo navede nekaj ljudskih običajev.'),(1880,1880,50,0,'opiše razvoj pripomočka, naprave ali orodja skozi čas,'),(1881,1881,50,0,'Opiše razvoj pripomočka, naprave ali orodja skozi čas.'),(1882,1882,50,0,'Ob vprašanjih opiše razvoj pripomočka, naprave ali orodja skozi čas.'),(1883,1883,50,0,'Ne zna opisati  razvoja pripomočka, naprave ali orodja skozi čas.'),(1884,1884,50,0,'uporablja časovne izraze (dan, teden, mesec, leto).'),(1885,1885,50,0,'Zna uporabljati časovne izraze (dan, teden, mesec, leto).'),(1886,1886,50,0,'Občasno uporablja časovne izraze (dan, teden, mesec, leto).'),(1887,1887,50,0,'Ob učiteljevemu opozorilu uporablja časovne izraze (dan, teden, mesec, leto).'),(1888,1888,51,0,'navede nekaj sprememb v naravi, ki jih sam opazi,'),(1889,1889,51,0,'Samostojno navede nekaj sprememb v naravi, ki jih sam opazi.'),(1890,1890,51,0,'Ob pomoči učitelja navede nekaj sprememb v naravi, ki jih sam opazi.'),(1891,1891,51,0,'povezuje živali z ustreznim okoljem,'),(1892,1892,51,0,'Pravilno povezuje živali z ustreznim okoljem.'),(1893,1893,51,0,'Prepozna in povezuje živali z ustreznim okoljem.'),(1894,1894,51,0,'S pomočjo povezuje živali z ustreznim okoljem.'),(1895,1895,51,0,'za nekaj preprostih primerov pove, kako se razlikujejo potomci od staršev in v čem so si podobni; ve da se živali postarajo in poginejo,'),(1896,1896,51,0,'Za nekaj preprostih primerov pove, kako se razlikujejo potomci od staršev in v čem so si podobni; ve da se živali postarajo in poginejo.'),(1897,1897,51,0,'Ob pomoči za nekaj preprostih primerov pove, kako se razlikujejo potomci od staršev in v čem so si podobni; ve da se živali postarajo in poginejo.'),(1898,1898,51,0,'Ob pomoči za nekaj preprostih primerov pove, kako se razlikujejo potomci od staršev in v čem so si podobni.'),(1899,1899,51,0,'našteje nekaj živali, katerih potomci so sprva zelo drugačni od staršev,'),(1900,1900,51,0,'Samostojno našteje nekaj živali, katerih potomci so sprva zelo drugačni od staršev.'),(1901,1901,51,0,'S pomočjo našteje nekaj živali, katerih potomci so sprva zelo drugačni od staršev.'),(1902,1902,51,0,'Prepozna nekaj živali, katerih potomci so sprva zelo drugačni od staršev.'),(1903,1903,51,0,'samostojno skrbi za rastline ali živali v učilnici ali na šoli in našteje, kaj potrebujejo rastline za rast,'),(1904,1904,51,0,'Samostojno skrbi za rastline ali živali v učilnici ali na šoli in našteje, kaj potrebujejo rastline za rast.'),(1905,1905,51,0,'S pomočjo drugih skrbi za rastline ali živali v učilnici ali na šoli in našteje, kaj potrebujejo rastline za rast.'),(1906,1906,51,0,'Ob pomoči skrbi za rastline ali živali v učilnici ali na šoli.'),(1907,1907,51,0,'navede nekaj primerov, kako razmnožujemo rastline (semena, čebulice, potaknjenci),'),(1908,1908,51,0,'Pozna in navede nekaj primerov, kako razmnožujemo rastline (semena, čebulice, potaknjenci).'),(1909,1909,51,0,'Prepozna in navede nekaj primerov, kako razmnožujemo rastline (semena, čebulice, potaknjenci).'),(1910,1910,51,0,'Prepozna nekaj primerov, kako razmnožujemo rastline (semena, čebulice, potaknjenci).'),(1911,1911,51,0,'prepozna in poimenuje nekaj najpogostejših vrtnin ali poljščin v svoji okolici,'),(1912,1912,51,0,'Samostojno prepozna in poimenuje nekaj najpogostejših vrtnin ali poljščin v svoji okolici.'),(1913,1913,51,0,'Ob pomoči prepozna in poimenuje nekaj najpogostejših vrtnin ali poljščin v svoji okolici.'),(1914,1914,51,0,'Ob pomoči prepozna nekaj najpogostejših vrtnin ali poljščin v svoji okolici.'),(1915,1915,51,0,'po navodilu samostojno pripravi preprosto jed,'),(1916,1916,51,0,'Po navodilu samostojno pripravi preprosto jed.'),(1917,1917,51,0,'Po navodilu s pomočjo pripravi preprosto jed.'),(1918,1918,51,0,'pripoveduje svoje zamisli, zakaj se hranimo ter kako in kje se hrana spreminja v telesu,'),(1919,1919,51,0,'Samostojno pripoveduje svoje zamisli, zakaj se hranimo ter kako in kje se hrana spreminja v telesu.'),(1920,1920,51,0,'S pomočjo vprašanj pripoveduje svoje zamisli, zakaj se hranimo ter kako in kje se hrana spreminja v telesu.'),(1921,1921,51,0,'Pripoveduje svoje zamisli, zakaj se hranimo.'),(1922,1922,51,0,'našteje nekaj čutil in primerov, kako nam čutila pomagajo pri različnih dejavnostih.'),(1923,1923,51,0,'Našteje nekaj čutil in primerov, kako nam čutila pomagajo pri različnih dejavnostih.'),(1924,1924,51,0,'Ob vprašanjih našteje nekaj čutil in primerov, kako nam čutila pomagajo pri različnih dejavnostih.'),(1925,1925,51,0,'S pomočjo našteje nekaj čutil iin ve, da nam čutila pomagajo pri različnih dejavnostih.'),(1926,1926,52,0,'navede nekaj dejavnosti za zdravo življenje (nega telesa, gibanje),'),(1927,1927,52,0,'Pozna in navede nekaj dejavnosti za zdravo življenje (nega telesa, gibanje).'),(1928,1928,52,0,'Prepozna in navede nekaj dejavnosti za zdravo življenje (nega telesa, gibanje).'),(1929,1929,52,0,'S pomočjo vprašanj navede nekaj dejavnosti za zdravo življenje (nega telesa, gibanje).'),(1930,1930,52,0,'sestavi in opiše nekaj obrokov, pri čemer upošteva raznovrstnost živil.'),(1931,1931,52,0,'Sestavi in opiše nekaj obrokov, pri čemer upošteva raznovrstnost živil.'),(1932,1932,52,0,'Sestavi nekaj obrokov, pri čemer upošteva raznovrstnost živil.'),(1933,1933,52,0,'S pomočjo sestavi nekaj obrokov, pri čemer upošteva raznovrstnost živil.'),(1934,1934,53,0,'razloži, zakaj je pomembna vidnost v prometu, kdaj je slaba vidljivost,'),(1935,1935,53,0,'Pozna in razloži, zakaj je pomembna vidnost v prometu, kdaj je slaba vidljivost.'),(1936,1936,53,0,'Prepozna in pove, zakaj je pomembna vidnost v prometu, kdaj je slaba vidljivost.'),(1937,1937,53,0,'Ob pomoči pove, zakaj je pomembna vidnost v prometu, kdaj je slaba vidljivost.'),(1938,1938,53,0,'prepozna in poimenuje nekatere geografske pojme v svoji okolici (hrib, gora, dolina, ravnina,…)'),(1939,1939,53,0,'Prepozna in poimenuje nekatere geografske pojme v svoji okolici (hrib, gora, dolina, ravnina,…).'),(1940,1940,53,0,'Ob pomoči prepozna in poimenuje nekatere geografske pojme v svoji okolici (hrib, gora, dolina, ravnina,…).'),(1941,1941,53,0,'Ob pomoči poimenuje nekatere geografske pojme v svoji okolici (hrib, gora, dolina, ravnina,…).'),(1942,1942,53,0,'našteje nekaj posegov v okolje v svoji okolici,'),(1943,1943,53,0,'Samostojno našteje nekaj posegov v okolje v svoji okolici.'),(1944,1944,53,0,'Ob pomoči našteje nekaj posegov v okolje v svoji okolici.'),(1945,1945,53,0,'Prepozna nekaj posegov v okolje v svoji okolici.'),(1946,1946,53,0,'naredi skico ali maketo opazovane pokrajine.'),(1947,1947,53,0,'Samostojno naredi skico ali maketo opazovane pokrajine.'),(1948,1948,53,0,'S pomočjo naredi skico ali maketo opazovane pokrajine.'),(1949,1949,53,0,'Ob spodbudi in pomoči naredi skico ali maketo opazovane pokrajine.'),(1950,1950,54,0,'Snovi in telesa - prepozna, poimenuje in našteje nekaj lastnosti snovi, iz katerih so različni izdelki,'),(1951,1951,54,0,'Snovi in telesa - samostojno prepozna, poimenuje in našteje nekaj lastnosti snovi, iz katerih so različni izdelki.'),(1952,1952,54,0,'Snovi in telesa -s pomočjo prepozna, poimenuje in našteje nekaj lastnosti snovi, iz katerih so različni izdelki.'),(1953,1953,54,0,'Snovi in telesa - prepozna in poimenuje  nekaj lastnosti snovi, iz katerih so različni izdelki.'),(1954,1954,54,0,'Snovi in telesa - prepozna nekaj lastnosti snovi, iz katerih so različni izdelki.'),(1955,1955,54,0,'Snovi in telesa - loči preprosto zmes na sestavine, opiše, kako se spremenijo zmesi in njihove lastnosti,'),(1956,1956,54,0,'Snovi in telesa - loči preprosto zmes na sestavine, opiše, kako se spremenijo zmesi in njihove lastnosti,'),(1957,1957,54,0,'Snovi in telesa -s pomočjo loči preprosto zmes na sestavine, opiše, kako se spremenijo zmesi in njihove lastnosti,'),(1958,1958,54,0,'Snovi in telesa - s pomočjo loči preprosto zmes na sestavine.'),(1959,1959,54,0,'Snovi in telesa - loči preprosto zmes na sestavine, s pomočjo opiše, kako se spremenijo zmesi in njihove lastnosti.'),(1960,1960,54,0,'Snovi in telesa - zna spremeniti tekočo vodo v led in obratno, poimenuje nekaj oblik vode v trdnem stanju (sneg, ivje, led),'),(1961,1961,54,0,'Snovi in telesa - zna spremeniti tekočo vodo v led in obratno, poimenuje nekaj oblik vode v trdnem stanju (sneg, ivje, led).'),(1962,1962,54,0,'Snovi in telesa -s pomočjo zna spremeniti tekočo vodo v led in obratno, poimenuje nekaj oblik vode v trdnem stanju (sneg, ivje, led).'),(1963,1963,54,0,'Snovi in telesa -s pomočjo zna spremeniti tekočo vodo v led in obratno.'),(1964,1964,54,0,'Snovi in telesa - povezuje lastnosti gradiv (les, papir, žica) z ogrodji in načini obdelave,'),(1965,1965,54,0,'Snovi in telesa - pozna in povezuje lastnosti gradiv (les, papir, žica) z ogrodji in načini obdelave,'),(1966,1966,54,0,'Snovi in telesa -s pomočjo povezuje lastnosti gradiv (les, papir, žica) z ogrodji in načini obdelave,'),(1967,1967,54,0,'Snovi in telesa - ustrezno ravna z odpadki, opisuje, katere odpadke lahko ponovno uporabimo.'),(1968,1968,54,0,'Snovi in telesa -pozna in ustrezno ravna z odpadki, opisuje, katere odpadke lahko ponovno uporabimo.'),(1969,1969,54,0,'Snovi in telesa -ob pomoči ustrezno ravna z odpadki, opisuje, katere odpadke lahko ponovno uporabimo.'),(1970,1970,54,0,'Snovi in telesa -ob pomoči ustrezno ravna z odpadki.'),(1971,1971,54,0,'Gibanje in sile - našteje nekaj vozil in pripomočkov za gibanje, opisuje, kaj vozila poganja, razlikuje med notranjim in zunanjim pogonom,'),(1972,1972,54,0,'Gibanje in sile - našteje nekaj vozil in pripomočkov za gibanje, opisuje, kaj vozila poganja, razlikuje med notranjim in zunanjim pogonom.'),(1973,1973,54,0,'Gibanje in sile - našteje nekaj vozil in pripomočkov za gibanje, opisuje, kaj vozila poganja.'),(1974,1974,54,0,'Gibanje in sile - našteje nekaj vozil in pripomočkov za gibanje.'),(1975,1975,54,0,'Gibanje in sile - opisuje, kako se z različnimi vozili ustaviš (kolo, rolke, deska), kako se ustavijo gibajoči predmeti (kotaleča žoga),'),(1976,1976,54,0,'Gibanje in sile - samostojno opisuje, kako se z različnimi vozili ustaviš (kolo, rolke, deska), kako se ustavijo gibajoči predmeti (kotaleča žoga).'),(1977,1977,54,0,'Gibanje in sile - ob pomoči opisuje, kako se z različnimi vozili ustaviš (kolo, rolke, deska), kako se ustavijo gibajoči predmeti (kotaleča žoga),'),(1978,1978,54,0,'Gibanje in sile -ob dodatni spodbudi pove, kako se z različnimi vozili ustaviš (kolo, rolke, deska).'),(1979,1979,54,0,'Gibanje in sile - naredi preprosto tehtnico in jo uravnovesi,'),(1980,1980,54,0,'Gibanje in sile - zna narediti  preprosto tehtnico in jo uravnovesi.'),(1981,1981,54,0,'Gibanje in sile -ob pomoči naredi preprosto tehtnico in jo uravnovesi.'),(1982,1982,54,0,'Gibanje in sile -ob pomoči zna narediti  preprosto tehtnico.'),(1983,1983,54,0,'Gibanje in sile - razlikuje med vrsto (vsebino) in trajanjem gibanja ali drugih pojavov,'),(1984,1984,54,0,'Gibanje in sile -zna razlikovati med vrsto (vsebino) in trajanjem gibanja ali drugih pojavov,'),(1985,1985,54,0,'Gibanje in sile -ob pomoči razlikuje med vrsto (vsebino) in trajanjem gibanja ali drugih pojavov,'),(1986,1986,54,0,'Zemlja in vesolje, prostor in čas - posnema navidezno gibanje sonca po nebu in ga povezuje z izrazi: zjutraj, dopoldan, popoldan, zvečer, noč, dan,'),(1987,1987,54,0,'Zemlja in vesolje, prostor in čas - posnema navidezno gibanje sonca po nebu in ga povezuje z izrazi: zjutraj, dopoldan, popoldan, zvečer, noč, dan.'),(1988,1988,54,0,'Zemlja in vesolje, prostor in čas -s pomočjo posnema navidezno gibanje sonca po nebu in ga povezuje s časovnimi izrazi.'),(1989,1989,54,0,'Zemlja in vesolje, prostor in čas -ne razume še gibanje sonca po nebu, pozna pa časovne izraze.'),(1990,1990,54,0,'Zemlja in vesolje, prostor in čas - opisuje razliko med dnevom in nočjo ter svoje dejavnosti v različnih časih dneva,'),(1991,1991,54,0,'Zemlja in vesolje, prostor in čas - samostojno opisuje razliko med dnevom in nočjo ter svoje dejavnosti v različnih časih dneva.'),(1992,1992,54,0,'Zemlja in vesolje, prostor in čas - ob pomoči opisuje razliko med dnevom in nočjo ter svoje dejavnosti v različnih časih dneva.'),(1993,1993,54,0,'Zemlja in vesolje, prostor in čas - ob dodatni spodbudi in pomoči opisuje razliko med dnevom in nočjo ter svoje dejavnosti v različnih časih dneva.'),(1994,1994,54,0,'Zemlja in vesolje, prostor in čas - poišče datum na koledarju, uporablja imena dni v tednu in izraze včeraj, danes, jutri,'),(1995,1995,54,0,'Zemlja in vesolje, prostor in čas -samostojno poišče datum na koledarju, uporablja imena dni v tednu in izraze včeraj, danes, jutri.'),(1996,1996,54,0,'Zemlja in vesolje, prostor in čas -ob učiteljevi pomoči poišče datum na koledarju, uporablja imena dni v tednu in izraze včeraj, danes, jutri.'),(1997,1997,54,0,'Zemlja in vesolje, prostor in čas - koledarja še ne pozna, uporablja pa imena dni v tednu in izraze včeraj, danes, jutri.'),(1998,1998,54,0,'Zemlja in vesolje, prostor in čas - opazuje vreme in ga označuje z ustreznimi znaki,'),(1999,1999,54,0,'Zemlja in vesolje, prostor in čas - samostojno opazuje vreme in ga označuje z ustreznimi znaki.'),(2000,2000,54,0,'Zemlja in vesolje, prostor in čas -če je voden, opazuje vreme in ga označuje z ustreznimi znaki.'),(2001,2001,54,0,'Zemlja in vesolje, prostor in čas -z dodatno pomočjo opazuje vreme in ga označuje z ustreznimi znaki.'),(2002,2002,54,0,'Zemlja in vesolje, prostor in čas - opisuje, kaj veter poganja ali premika,'),(2003,2003,54,0,'Zemlja in vesolje, prostor in čas - samostojno opisuje, kaj veter poganja ali premika.'),(2004,2004,54,0,'Zemlja in vesolje, prostor in čas -občasno opisuje, kaj veter poganja ali premika.'),(2005,2005,54,0,'Zemlja in vesolje, prostor in čas -s pomočjo vprašanj pove, kaj veter poganja ali premika.'),(2006,2006,54,0,'Zemlja in vesolje, prostor in čas - opisuje, kako pri različnih predmetih nastaja zvok,'),(2007,2007,54,0,'Zemlja in vesolje, prostor in čas -pravilno opisuje, kako pri različnih predmetih nastaja zvok.'),(2008,2008,54,0,'Zemlja in vesolje, prostor in čas - prepozna, kako pri različnih predmetih nastaja zvok.'),(2009,2009,54,0,'Zemlja in vesolje, prostor in čas - s pomočjo opisuje, kako pri različnih predmetih nastaja zvok.'),(2010,2010,54,0,'Zemlja in vesolje, prostor in čas - uporabi tabelo za vnos in branje podatkov,'),(2011,2011,54,0,'Zemlja in vesolje, prostor in čas - podatke zbere, uredi, jih primerja in ovrednoti.'),(2012,2012,54,0,'Zemlja in vesolje, prostor in čas - zbere podatke, jih uredi in predstavi.'),(2013,2013,54,0,'Zemlja in vesolje, prostor in čas - s pomočjo zbere, uredi in predstavi podatke.'),(2014,2014,54,0,'Zemlja in vesolje, prostor in čas - nariše pojav in preprost načrt izdelka.'),(2015,2015,54,0,'Zemlja in vesolje, prostor in čas -samostojno  nariše pojav in preprost načrt izdelka.'),(2016,2016,54,0,'Zemlja in vesolje, prostor in čas - s pomočjo nariše pojav in preprost načrt izdelka.'),(2017,2017,54,0,'Zemlja in vesolje, prostor in čas -če je voden, nariše pojav in preprost načrt izdelka.'),(2018,2018,55,0,'razlikuje različna obdobja človekovega življenja (otroštvo, mladost, zrela leta, starost) in razume, da se vsako življenje enkrat začne in nekoč konča,'),(2019,2019,55,0,'Pozna in razlikuje različna obdobja človekovega življenja in razume, da se vsako življenje enkrat začne in nekoč konča.'),(2020,2020,55,0,'Ob pomoči razlikuje različna obdobja človekovega življenja  in razume, da se vsako življenje enkrat začne in nekoč konča.'),(2021,2021,55,0,'Prepozna različna obdobja človekovega življenja  in razume, da se vsako življenje enkrat začne in nekoč konča.'),(2022,2022,55,0,'Prepozna različna obdobja človekovega življenja in ve, da se vsako življenje enkrat začne in nekoč konča.'),(2023,2023,55,0,'povezuje različne vrste zasvojenosti s posledicami neodgovornega ravnanja.'),(2024,2024,55,0,'Samostojno povezuje različne vrste zasvojenosti s posledicami neodgovornega ravnanja.'),(2025,2025,55,0,'Ob pomoči učitelja povezuje različne vrste zasvojenosti s posledicami neodgovornega ravnanja.'),(2026,2026,55,0,'Pozna različne vrste zasvojenosti in ve za posledice neodgovornega ravnanja.'),(2027,2027,56,1,'našteje in opiše različne dejavnosti, ki potekajo v šoli,'),(2028,2028,56,1,'Samostojno našteje in opiše različne dejavnosti, ki so na šoli in jih opiše.'),(2029,2029,56,1,'Našteje različne dejavnosti, ki potekajo na šoli. Opiše tisto, v kateri sodeluje.'),(2030,2030,56,1,'Opiše ( ob pomoči) dejavnosti v katerih sodeluje.'),(2031,2031,56,1,'opisuje različne odnose, v katerih sam sodeluje in pozitivno vrednoti razlike med ljudmi,'),(2032,2032,56,1,'Prepoznava in opisuje odnose med ljudmi. Sprejema različnost. Sproščeno komunicira z različnimi sogovorci.'),(2033,2033,56,1,'Prepoznava in opisuje odnose med ljudmi. Zaveda se različnosti med ljudmi. Komunicira z različnimi sogovorci ob spodbudi.'),(2034,2034,56,1,'Prepozna odnose med ljudmi, jih še ne opiše. Navaja se na različnost med ljudmi, komunicira le z ožjim krogom.'),(2035,2035,56,1,'razlikuje med zdravim in nezdravim načinom življenja,'),(2036,2036,56,1,'Pojasni razliko med zdravim in nezdravim načinom življenja. Pridobiva navade zdravega življenja.'),(2037,2037,56,1,'Razlikuje med zdravim in nezdravim načinom življenja.'),(2038,2038,56,1,'Našteje nekatere razlike med zdravim in nezdravim načinom življenja.'),(2039,2039,56,1,'opiše različna življenjska obdobja živih bitij,'),(2040,2040,56,1,'Pozna značilnosti živih bitij in opiše življenjsko obdobje posameznih bitij.'),(2041,2041,56,1,'Pozna nekatere značilnosti živih bitij in opiše njihovo življenjsko obdobje.'),(2042,2042,56,1,'Pozna nekatere značilnosti živih bitij in ob pomoči opiše njihovo življenjsko obdobje.'),(2043,2043,56,1,'opazuje in postavlja vprašanja o pojavih v njegovem okolju,'),(2044,2044,56,1,'Sistematično in natančno opazuje pojave ter o njih smiselno postavlja vprašanja'),(2045,2045,56,1,'Natančno opazuje pojave ter o njih postavlja vprašanja.'),(2046,2046,56,1,'Pojave opazuje in o njih le občasno postavlja vprašanja.'),(2047,2047,56,1,'opisuje snovi, predmete, gibanje, vreme, rastline, živali in okolico ter uporablja ustrezno besedišče,'),(2048,2048,56,1,'Opisuje pojme in pojave v naravi in pri tem uporablja ustrezno besedišče. Pojme in pojave v naravi razume in jih medsebojno povezuje.'),(2049,2049,56,1,'Pojme in pojave v naravi opisuje in pri tem uporablja ustrezno besedišče.'),(2050,2050,56,1,'Ob pomoči in s svojimi besedami opisuje pojme in pojave v naravi.'),(2051,2051,56,1,'povezuje opažanja in uporablja vzročne zveze,'),(2052,2052,56,1,'Povezuje opažanja, prepoznava vzročne zveze, jih razume in uporabi.'),(2053,2053,56,1,'Povezuje opažanja in prepozna vzročne zveze.'),(2054,2054,56,1,'Ob pomoči povezuje opažanja in prepozna vzročne zveze.'),(2055,2055,56,1,'povezuje lastnosti snovi z načini obdelave in njihovo uporabo,'),(2056,2056,56,1,'Pozna lastnosti snovi in izbere ustrezen način uporabe in obdelave ter samostojno praktično obdela snov.'),(2057,2057,56,1,'Pozna lastnosti snovi in izbere ustrezen način uporabe in obdelave.'),(2058,2058,56,1,'Opiše snov pred preoblikovanjem in končni izdelek. Po predlaganem načinu snov izbere in jo obdela.'),(2059,2059,56,1,'opisuje gibanje, ravnovesno lego in ustavljanje vozil,'),(2060,2060,56,1,'Gibanje natančno opiše. Poimenuje vzroke za gibanje in za ustavljanje vozil. Zna izbrati ustrezen pripomoček.'),(2061,2061,56,1,'Opiše gibanje ravnovesno lego in ustavljanje vozil. Poimenuje in uporabi pripomočke.'),(2062,2062,56,1,'Ve, da gibanje lahko ustavimo. Poimenuje nekatera stanja mirovanja, ne zna  pa jih še opisati. Poimenuje pripomočke za gibanje.'),(2063,2063,56,1,'povezuje navidezno gibanje sonca z ustreznimi časovnimi izrazi; uporablja koledar,'),(2064,2064,56,1,'Pozna, razume in pravilno uporablja časovne izraze. Znajde se na koledarju.'),(2065,2065,56,1,'Pozna in razume časovne izraze, uporablja koledar.'),(2066,2066,56,1,'Pozna časovne izraze, vendar jih še ne razume povsem. Na koledarju se še ne orientira.'),(2067,2067,56,1,'opisuje, kako pri različnih predmetih nastaja zvok,'),(2068,2068,56,1,'Pravilno opiše in razloži nastajanje zvoka pri različnih predmetih. Prepozna zvoke različnih predmetov.'),(2069,2069,56,1,'Opiše nastajanje zvoka pri različnih predmetih. Prepozna zvoke različnih predmetov'),(2070,2070,56,1,'S pomočjo opiše nastajanje zvoka pri različnih predmetih. Še ne prepozna zvokov različnih predmetov.'),(2071,2071,56,1,'uporabi tabele za vnos in branje podatkov.'),(2072,2072,56,1,'Podatke zbere, uredi, jih primerja in ovrednoti.'),(2073,2073,56,1,'Zbere podatke, jih uredi in predstavi.'),(2074,2074,56,1,'S pomočjo zbere, uredi in predstavi podatke.'),(2075,2075,76,0,'pozna pomen sodelovanja, sprejemanja drugačnosti in pomoči.'),(2076,2076,76,0,'Pozna pomen sodelovanja, sprejemanja drugačnosti in pomoči.'),(2077,2077,76,0,'Ve, da je sodelovanje, sprejemanje drugačnosti in pomoči pomembno.'),(2078,2078,76,0,'Prepozna  sodelovanje, sprejemanje drugačnosti in pomoči.'),(2079,2079,77,0,'pozna različna praznovanja in njihov pomen.'),(2080,2080,77,0,'Pozna različna praznovanja in njihov pomen.'),(2081,2081,77,0,'Pozna  nekaj praznovanj in njihov pomen.'),(2082,2082,77,0,'Z učiteljevo pomočjo prepozna nekaj praznovanj in njihov pomen.'),(2083,2083,78,0,'ve, da so nam nekatere stvari zapustili predniki,'),(2084,2084,78,0,'Ve, da so nam nekatere stvari zapustili predniki.'),(2085,2085,78,0,'Ob učiteljevi pomoči ugotovi, da so nam nekatere stvari zapustili predniki.'),(2086,2086,78,0,'uporablja časovne izraze za preteklost, sedanjost, prihodnost,'),(2087,2087,78,0,'Dosledno  in pravilno uporablja časovne izraze za preteklost, sedanjost, prihodnost.'),(2088,2088,78,0,'Občasno uporablja časovne izraze za preteklost, sedanjost, prihodnost.'),(2089,2089,78,0,'Ob opozorilu učitelja uporablja časovne izraze za preteklost, sedanjost, prihodnost.'),(2090,2090,78,0,'pozna kulturno zgodovinske značilnosti in znane osebe svojega kraja.'),(2091,2091,78,0,'Pozna kulturno zgodovinske značilnosti in znane osebe svojega kraja.'),(2092,2092,78,0,'Pozna  nekaj  kulturno zgodovinskih značilnosti in znanih  oseb svojega kraja.'),(2093,2093,78,0,'Z učiteljevo pomočjo prepozna kulturno zgodovinske značilnosti in znane osebe svojega kraja.'),(2094,2094,79,0,'razlikuje in opiše značilnosti ožje in širše okolice njegovega kraja,'),(2095,2095,79,0,'Razlikuje in opiše značilnosti ožje in širše okolice svojega kraja.'),(2096,2096,79,0,'Pozna značilnosti ožje in širše okolice svojega kraja.'),(2097,2097,79,0,'Ob učiteljevi pomoči našteje  značilnosti ožje in širše okolice svojega kraja.'),(2098,2098,79,0,'ve, da se vsa živa bitja razmnožujejo; imenuje glavne dele živih bitij in njihovo osnovno funkcijo,'),(2099,2099,79,0,'Ve, da se vsa živa bitja razmnožujejo; imenuje glavne dele živih bitij in njihovo osnovno funkcijo.'),(2100,2100,79,0,'Ob učiteljevi pomoči pove, da se vsa živa bitja razmnožujejo; imenuje glavne dele živih bitij in njihovo osnovno funkcijo.'),(2101,2101,79,0,'Ob učiteljevi pomoči pove, da se vsa živa bitja razmnožujejo. Ob učiteljevi pomoči imenuje glavne dele živih bitij in njihovo osnovno funkcijo.'),(2102,2102,79,0,'ve, da se otrok spočne v materi; razume skrb zanj, ko se rodi,'),(2103,2103,79,0,'Ve, da se otrok spočne v materi; razume skrb zanj, ko se rodi.'),(2104,2104,79,0,'Ob učiteljevi pomoči  pove, da se otrok spočne v materi; razume skrb zanj, ko se rodi.'),(2105,2105,79,0,'Ob učiteljevi pomoči pove,  da se otrok spočne v materi. Spoznava skrb zanj, ko se rodi.'),(2106,2106,79,0,'zna opisati spreminjanje narave v letnih časih,'),(2107,2107,79,0,'Zna opisati spreminjanje narave v letnih časih.'),(2108,2108,79,0,'Ob učiteljevi pomoči zna opisati spreminjanje narave v letnih časih'),(2109,2109,79,0,'Našteje spremembe narave v letnih časih.'),(2110,2110,79,0,'na primeru iz okolja pojasni povezanost živih bitij med seboj in z okoljem,'),(2111,2111,79,0,'Na primeru iz okolja pojasni povezanost živih bitij med seboj in z okoljem.'),(2112,2112,79,0,'S pomočjo vprašanj pojasni na primeru iz okolja  povezanost živih bitij med seboj in z okoljem.'),(2113,2113,79,0,'Pove primer povezanosti živih bitij z okoljem'),(2114,2114,79,0,'pozna potrebe živali in rastlin za rast in razvoj,'),(2115,2115,79,0,'Pozna potrebe živali in rastlin za rast in razvoj.'),(2116,2116,79,0,'Zna našteti eno izmed potreb živih bitij za življenje.'),(2117,2117,79,0,'Ob učiteljevih vprašanjih našteje potrebe živali in rastlin za rast in razvoj.'),(2118,2118,79,0,'ve, da spremembe v naravi lahko škodijo živim bitjem in se zavedajo pomembnosti ohranjanja okolja.'),(2119,2119,79,0,'Ve, da spremembe v naravi lahko škodijo živim bitjem in se zavedajo pomembnosti ohranjanja okolja.'),(2120,2120,79,0,'Ob učiteljevi pomoči pove, da spremembe v naravi lahko škodijo živim bitjem in se zavedajo pomembnosti ohranjanja okolja.'),(2121,2121,79,0,'Ve, da moramo za ohranjanje okolja skrbeti.'),(2122,2122,80,0,'opiše, kako skrbimo za svoje zdravje,'),(2123,2123,80,0,'Opiše, kako skrbimo za svoje zdravje.'),(2124,2124,80,0,'Ob vprašanjih opiše, kako skrbimo za svoje zdravje.'),(2125,2125,80,0,'ve, da nekatere bolezni preprečujemo s cepljenjem.'),(2126,2126,80,0,'Ve, da nekatere bolezni preprečujemo s cepljenjem.'),(2127,2127,80,0,'Ob pomoči pove, da nekatere bolezni preprečujemo s cepljenjem.'),(2128,2128,81,0,'pozna slovenske izdelke in izdelke iz uvoza ter jih razlikuje,'),(2129,2129,81,0,'Pozna slovenske izdelke in izdelke iz uvoza ter jih razlikuje.'),(2130,2130,81,0,'Pozna slovenske izdelke in izdelke iz uvoza.'),(2131,2131,81,0,'Ob pomoči našteje nekaj slovenskih izdelkov in posamezen izdelek iz tujine.'),(2132,2132,81,0,'opiše mestno in vaško življenje,'),(2133,2133,81,0,'Opiše mestno in vaško življenje.'),(2134,2134,81,0,'Ob pomoči opiše mestno in vaško življenje.'),(2135,2135,81,0,'Ob pomoči pove nekaj značilnosti mestnega in vaškega življenja.'),(2136,2136,81,0,'poveže posledice prometa z onesnaženostjo.'),(2137,2137,81,0,'Poveže posledice prometa z onesnaženostjo.'),(2138,2138,81,0,'Ob pomoči poveže posledice prometa z onesnaženostjo.'),(2139,2139,81,0,'Ve, da promet onesnažuje zrak.'),(2140,2140,82,0,'Snovi in telesa - na osnovi poskusa poroča, da se snovi v zraku, soncu ali vodi spremenijo,'),(2141,2141,82,0,'Na osnovi poskusa poroča, da se snovi v zraku, soncu ali vodi spremenijo.'),(2142,2142,82,0,'Z učiteljevo pomočjo na osnovi poskusa poroča, da se snovi v zraku, soncu ali vodi spremeni.'),(2143,2143,82,0,'Z učiteljevo pomočjo na osnovi poskusa pove eno  spremembo snovi v zraku, soncu ali vodi.'),(2144,2144,82,0,'Snovi in telesa - opiše lastnosti in napove spremembe snovi pred in po segrevanju,'),(2145,2145,82,0,'Opiše lastnosti in napove spremembe snovi pred in po segrevanju.'),(2146,2146,82,0,'Opiše lastnosti in ob učiteljevi pomoči napove spremembe snovi pred in po segrevanju.'),(2147,2147,82,0,'S pomočjo vprašanj opiše lastnosti  snovi pred in po segrevanju.'),(2148,2148,82,0,'Snovi in telesa - pozna lastnosti zraka in ve, kje se nahaja,'),(2149,2149,82,0,'Pozna lastnosti zraka in ve, kje se nahaja.'),(2150,2150,82,0,'Ob vprašanjih našteje in opiše lastnosti zraka in ve, kje se nahaja.'),(2151,2151,82,0,'Našteje lastnosti zraka.'),(2152,2152,82,0,'Snovi in telesa - opiše vzroke za onesnaženost zraka,'),(2153,2153,82,0,'Opiše vzroke za onesnaženost zraka.'),(2154,2154,82,0,'Našteje vzroke za onesnaženost zraka.'),(2155,2155,82,0,'Ve, da je zrak onesnažen.'),(2156,2156,82,0,'Snovi in telesa - pozna nekaj lastnosti kovin in ve, da ob uporabi nastanejo odpadki,'),(2157,2157,82,0,'Pozna nekaj lastnosti kovin in ve, da ob uporabi nastanejo odpadki.'),(2158,2158,82,0,'Našteje nekaj lastnosti kovin in pove, da ob uporabi nastanejo odpadki.'),(2159,2159,82,0,'Ob pomoči prepozna nekaj lastnosti kovin.'),(2160,2160,82,0,'Snovi in telesa - zaveda se pomembnosti ločenega zbiranja odpadkov,'),(2161,2161,82,0,'Zaveda se pomembnosti ločenega zbiranja odpadkov.'),(2162,2162,82,0,'Ve, da je ločeno zbiranje odpadkov pomembno.'),(2163,2163,82,0,'Pozna ločeno  zbiranje odpadkov.'),(2164,2164,82,0,'Snovi in telesa - izdela vetrnico, mlinček ali kakšen drug primeren izdelek.'),(2165,2165,82,0,'Izdela vetrnico, mlinček ali kakšen drug primeren izdelek.'),(2166,2166,82,0,'Ob pomoči izdela vetrnico, mlinček ali kakšen drug primeren izdelek.'),(2167,2167,82,0,'Gibanje in sile - izvede preprost poskus in napove spremembo gibanja glede na zunanji vpliv,'),(2168,2168,82,0,'Izvede preprost poskus in napove spremembo gibanja glede na zunanji vpliv.'),(2169,2169,82,0,'Ob učiteljevi pomoči izvede preprost poskus in napove spremembo gibanja glede na zunanji vpliv.'),(2170,2170,82,0,'Ob učiteljevi pomoči izvede preprost poskus.'),(2171,2171,82,0,'Gibanje in sile - časovno in krajevno opredeli gibanje,'),(2172,2172,82,0,'Časovno in krajevno opredeli gibanje.'),(2173,2173,82,0,'Občasno  časovno in krajevno opredeli gibanje.'),(2174,2174,82,0,'Ob učiteljevi pomoči  časovno in krajevno opredeli gibanje.'),(2175,2175,82,0,'Gibanje in sile - povezuje obliko in velikost telesa s hitrostjo gibanja.'),(2176,2176,82,0,'Povezuje obliko in velikost telesa s hitrostjo gibanja.'),(2177,2177,82,0,'Občasno povezuje obliko in velikost telesa s hitrostjo gibanja.'),(2178,2178,82,0,'Ob pomoči učitelja povezuje obliko in velikost telesa s hitrostjo gibanja.'),(2179,2179,82,0,'Zemlja in vesolje, prostor in čas - poveže čas dneva, dan in noč s položajem Sonca in Lune,'),(2180,2180,82,0,'Poveže čas dneva, dan in noč s položajem Sonca in Lune.'),(2181,2181,82,0,'Ob učiteljevi pomoči poveže čas dneva, dan in noč s položajem Sonca in Lune.'),(2182,2182,82,0,'Zemlja in vesolje, prostor in čas - opiše potek dogodka po časovnem zaporedju,'),(2183,2183,82,0,'Opiše potek dogodka po časovnem zaporedju.'),(2184,2184,82,0,'Občasno opiše potek dogodka po časovnem zaporedju.'),(2185,2185,82,0,'Ob  učiteljevi pomoči opiše potek dogodka po časovnem zaporedju.'),(2186,2186,82,0,'Zemlja in vesolje, prostor in čas - opiše kako človek zaznava svetlobo, kaj daje Sonce,'),(2187,2187,82,0,'Opiše kako človek zaznava svetlobo, kaj daje Sonce.'),(2188,2188,82,0,'Pove kako človek zaznava svetlobo, kaj daje Sonce.'),(2189,2189,82,0,'Ob vprašanjih pove kako človek zaznava svetlobo, kaj daje Sonce.'),(2190,2190,82,0,'Zemlja in vesolje, prostor in čas - uporablja časovne enote.'),(2191,2191,82,0,'Uporablja časovne enote.'),(2192,2192,82,0,'Občasno uporablja časovne enote.'),(2193,2193,82,0,'Po opozorilu uporablja časovne enote.'),(2194,2194,82,0,'Vreme - zna določiti smer vetra in poimenovati padavine.'),(2195,2195,82,0,'Zna določiti smer vetra in poimenovati padavine.'),(2196,2196,82,0,'Pozna smeri  vetra in poimenuje nekaj  padavin.'),(2197,2197,82,0,'Poimenuje le nekaj padavin.'),(2198,2198,82,0,'Zvok - zna pojasniti vzroke za različne jakosti zvoka,'),(2199,2199,82,0,'Zna pojasniti vzroke za različne jakosti zvoka.'),(2200,2200,82,0,'Pove  vzroke za različne jakosti zvoka.'),(2201,2201,82,0,'S pomočjo vprašanj našteje vzroke za različne jakosti zvoka.'),(2202,2202,82,0,'Zvok - zna skicirati preproste konstrukcije,'),(2203,2203,82,0,'Zna skicirati preproste konstrukcije.'),(2204,2204,82,0,'Z učiteljevo pomočjo zna skicirati preproste konstrukcije.'),(2205,2205,82,0,'Zvok - zna oblikovati in brati preglednice, podatke prikazovati s stolpci.'),(2206,2206,82,0,'Zna oblikovati in brati preglednice, podatke prikazovati s stolpci.'),(2207,2207,82,0,'Zna  brati preglednice, podatke prikazovati s stolpci.'),(2208,2208,82,0,'Ob pomoči zna  brati preglednice. Ob pomoči prikaže podatke  s stolpci.'),(2209,2209,83,0,'ve, zakaj je znanje potrebno in da je temu potrebno posvetiti čas,'),(2210,2210,83,0,'Ve, zakaj je znanje potrebno in da je temu potrebno posvetiti čas.'),(2211,2211,83,0,'Ob učiteljevi pomoči pove zakaj je znanje potrebno in  da je temu potrebno posvetiti čas.'),(2212,2212,83,0,'Ob učiteljevi pomoči  pove, zakaj je znanje potrebno in  ob učiteljevi pomoči pove, da je temu potrebno posvetiti čas.'),(2213,2213,83,0,'razlikuje med delom in prostočasnimi dejavnostmi,'),(2214,2214,83,0,'Razlikuje med delom in prostočasnimi dejavnostmi.'),(2215,2215,83,0,'Ob učiteljevih vprašanjih razlikuje med delom in prostočasnimi dejavnostmi.'),(2216,2216,83,0,'Ne razlikuje med delom in prostočasnimi dejavnostmi.'),(2217,2217,83,0,'pozna ustanove in dejavnosti v kraju,'),(2218,2218,83,0,'Pozna ustanove in dejavnosti v kraju.'),(2219,2219,83,0,'Pozna nekaj ustanov in dejavnosti v kraju.'),(2220,2220,83,0,'Ustanove in dejavnosti v kraju prepozna ob pomoči učitelja.'),(2221,2221,83,0,'pozna slovensko denarno enoto in ve, da obstajajo tudi druge; pozna pomen denarja.'),(2222,2222,83,0,'Pozna slovensko denarno enoto in ve, da obstajajo tudi druge. Pozna pomen denarja.'),(2223,2223,83,0,'Pozna slovensko denarno enoto in ob učiteljevi pomoči pove, da obstajajo tudi druge. Pozna pomen denarja.'),(2224,2224,83,0,'Pozna slovensko denarno enoto, a ne  ve, da obstajajo tudi druge. Ob učiteljevi pomoči prepozna  pomen denarja.'),(2225,2225,84,0,'ve, da je Slovenija država in jo prepozna na zemljevidu,'),(2226,2226,84,0,'Ve, da je Slovenija država in jo prepozna na zemljevidu.'),(2227,2227,84,0,'Ve, da je Slovenija država in  jo na zemljevidu prepozna ob pomoči učitelja.'),(2228,2228,84,0,'Ve, da je Slovenija država.'),(2229,2229,84,0,'prepozna nekatere simbole slovenske države.'),(2230,2230,84,0,'Prepozna nekatere simbole slovenske države.'),(2231,2231,84,0,'Prepozna posamezen simbol slovenske države.'),(2232,2232,84,0,'Ob učiteljevi pomoči prepozna posamezen simbol slovenske države.'),(2233,2233,85,1,'razlikuje in opiše značilna življenjska okolja v ožji in širši okolici,'),(2234,2234,85,1,'Razlikuje in opiše tipična življenjska okolja v ožji in širši okolici.'),(2235,2235,85,1,'Razlikuje tipična življenjska okolja v ožji in širši okolici.'),(2236,2236,85,1,'Prepozna značilna življenjska okolja v okolici šole.'),(2237,2237,85,1,'opiše spremembe v naravi, razlaga in povezuje opažanja,'),(2238,2238,85,1,'Predvideva in sklepa o spremembah v naravi.'),(2239,2239,85,1,'Ob konkretnem primeru razlaga spremembe v naravi.'),(2240,2240,85,1,'Opazi spremembo v naravi.'),(2241,2241,85,1,'na danem primeru opiše osnovne potrebe živih bitij, njihove začetke, razvoj in smrt,'),(2242,2242,85,1,'Razloži osnovne potrebe živih bitij (človeka, živali in rastlin), njihov začetek, rast in razvoj ter smrt.'),(2243,2243,85,1,'Opiše osnovne potrebe živih bitij (človeka, živali in rastlin), njihov začetek, rast in razvoj ter smrt.'),(2244,2244,85,1,'Pozna osnovne potrebe živih bitij. Ve, da se človek rodi, raste, se hrani razmnožuje in umre.'),(2245,2245,85,1,'se zaveda pomembnosti ohranjanja naravnega okolja,'),(2246,2246,85,1,'Zaveda se pomena ohranjanja naravnega okolja in se  vede temu primerno.'),(2247,2247,85,1,'Zaveda se pomena ohranjanja naravnega okolja.'),(2248,2248,85,1,'Navaja se na ohranjanje naravnega okolja.'),(2249,2249,85,1,'opiše skrb za svoje zdravje in ve, da nekatere bolezni preprečujemo s cepljenjem,'),(2250,2250,85,1,'Argumentira pomen zdravja in našteje bolezni, ki jih preprečujemo s cepljenjem.'),(2251,2251,85,1,'Opiše, kako sami skrbimo za zdravje.'),(2252,2252,85,1,'Pozna osnovno higieno in našteje nekaj bolezni.'),(2253,2253,85,1,'opiše lastnosti in spremembe snovi, vremena, gibanja ter zvoka,'),(2254,2254,85,1,'Opiše lastnosti in predvidi spremembe snovi, vremena, gibanja ter zvoka.'),(2255,2255,85,1,'Opiše lastnosti in spremembe snovi, vremena, gibanja ter zvoka.'),(2256,2256,85,1,'Pozna lastnosti snovi, različnih vremenskih stanj, gibanja ter zvoka.'),(2257,2257,85,1,'pozna delo svojih staršev in opiše druge pogoste poklice,'),(2258,2258,85,1,'Vrednoti poklic svojih staršev in najpogostejše poklice.'),(2259,2259,85,1,'Razlikuje med (delom) poklicem in prostim časom.'),(2260,2260,85,1,'Pripoveduje o delu svojih staršev in ob slikovnim materialu prepozna nekatere poklice.'),(2261,2261,85,1,'razlikuje naselja in pozna ustanove in dejavnosti v kraju,'),(2262,2262,85,1,'Primerja naselja in razlikuje ustanove in dejavnosti v kraju.'),(2263,2263,85,1,'Prepozna naselja in ustanove ter dejavnosti v kraju.'),(2264,2264,85,1,'Našteje nekatera naselja in ustanove v kraju.'),(2265,2265,85,1,'ve, da je Slovenija država in pozna njene simbole ter pomembne praznike,'),(2266,2266,85,1,'Pozna pomen praznikov in simbolov Slovenije, praznike datumsko uredi.'),(2267,2267,85,1,'Prepozna simbole naše države in našteje praznike. Ve, da je Slovenija naša država.'),(2268,2268,85,1,'Našteje nekatere praznike.'),(2269,2269,85,1,'pozna slovensko denarno enoto in ve, da obstajajo tudi druge,'),(2270,2270,85,1,'Državi priredi ustrezno denarno enoto.'),(2271,2271,85,1,'Pozna slovensko denarno enoto in našteje nekaj tujih državnih enot.'),(2272,2272,85,1,'Poimenuje denar naše države.'),(2273,2273,85,1,'zna skicirati in izdelati preproste izdelke,'),(2274,2274,85,1,'Zna skicirati in izdelati preprost izdelek.'),(2275,2275,85,1,'Ob pomoči zna skicirati in izdelati preprost izdelek.'),(2276,2276,85,1,'naredi in uporabi preglednico ter podatke prikaže s stolpci,'),(2277,2277,85,1,'Ugotovitve beleži ter podatke prikaže s stolpci.'),(2278,2278,85,1,'Zabeleži nekatere ugotovitve ter prikaže podatke s stolpci.'),(2279,2279,85,1,'V skupini spremlja ugotovitve ter naredi preglednico.'),(2280,2280,85,1,'uporablja uro, pozna smeri neba in se orientira.'),(2281,2281,85,1,'Pozna na uro in zapiše točen čas. Loči  glavne smeri neba, se pravilno orientira v naravi in na zemljevidu.'),(2282,2282,85,1,'Pozna na uro in zapiše točen čas. Prepozna glavne smeri neba. Pri orientaciji v naravi in na zemljevidu ni vedno zanesljiv.'),(2283,2283,85,1,'Na uro pozna, a se pri zapisu točnega časa še zmoti. Prepoznava glavne smeri neba, vendar pri orientaciji v naravi ali na zemljevidu ni zanesljiv.'),(2284,2284,28,0,'izvaja naravne oblike gibanja,'),(2285,2285,28,0,'Sproščeno izvaja naravne oblike gibanja.'),(2286,2286,28,0,'Ob spodbudi izvaja naravne oblike gibanja.'),(2287,2287,28,0,'Nesproščeno izvaja naravne oblike gibanja.'),(2288,2288,28,0,'posnema predmete, pojave in pojme v naravi,'),(2289,2289,28,0,'Sproščeno izvaja naravne oblike gibanja.'),(2290,2290,28,0,'Zadržano izvaja naravne oblike gibanja.'),(2291,2291,28,0,'Ob dodatni spodbudi izvaja naravne oblike gibanja.'),(2292,2292,28,0,'izvaja enostavnejša gibanja ob glasbeni spremljavi,'),(2293,2293,28,0,'Pogosto izvaja enostavnejša gibanja ob glasbeni spremljavi.'),(2294,2294,28,0,'Ob spodbudi izvaja enostavnejša gibanja ob glasbeni spremljavi.'),(2295,2295,28,0,'Ob vodenju zadržano izvaja enostavnejša gibanja ob glasbeni spremljavi.'),(2296,2296,28,0,'ravna z različnimi športnimi pripomočki,'),(2297,2297,28,0,'Pravilno ravna z različnimi športnimi pripomočki.'),(2298,2298,28,0,'Odgovorno ravna z različnimi športnimi pripomočki.'),(2299,2299,28,0,'Navaja se  na pravilno ravnanje z različnimi športnimi pripomočki.'),(2300,2300,28,0,'obvladuje svoje telo v različnih položajih,'),(2301,2301,28,0,'Spretno obvladuje svoje telo v različnih položajih.'),(2302,2302,28,0,'Vodeno obvladuje svoje telo v različnih položajih.'),(2303,2303,28,0,'z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z žogo,'),(2304,2304,28,0,'Z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z žogo.'),(2305,2305,28,0,'zapleše preproste otroške plese,'),(2306,2306,28,0,'Sproščeno zapleše preproste otroške plese.'),(2307,2307,28,0,'Ob vodenju zapleše preproste otroške plese.'),(2308,2308,28,0,'S posnemanjem zapleše preproste otroške plese.'),(2309,2309,28,0,'prilagodi se na vodo do stopnje drsenja,'),(2310,2310,28,0,'Prilagodi se na vodo do stopnje drsenja.'),(2311,2311,28,0,'Prilagaja  se na vodo do stopnje drsenja.'),(2312,2312,28,0,'spozna gibalne dejavnosti na snegu in ledu,'),(2313,2313,28,0,'Spozna  in izvaja gibalne dejavnosti na snegu in ledu.'),(2314,2314,28,0,'Ob dodatni spodbudi Izvaja gibalne dejavnosti na snegu in ledu.'),(2315,2315,28,0,'pozna osnovne položaje telesa, rok in nog,'),(2316,2316,28,0,'Pozna osnovne položaje telesa, rok in nog.'),(2317,2317,28,0,'Posnema osnovne položaje telesa, rok in nog.'),(2318,2318,28,0,'poimenuje različna športna orodja iin pripomočke,'),(2319,2319,28,0,'Samostojno poimenuje različna športna orodja in pripomočke.'),(2320,2320,28,0,'S pomočjo vprašanj poimenuje različna športna orodja in pripomočke.'),(2321,2321,28,0,'Prepozna različna športna orodja in pripomočke.'),(2322,2322,28,0,'razume in upošteva preprosta pravila elementarnih in drugih iger,'),(2323,2323,28,0,'Razume in upošteva preprosta pravila elementarnih in drugih iger.'),(2324,2324,28,0,'Razume  preprosta pravila elementarnih in drugih iger.'),(2325,2325,28,0,'Upošteva preprosta pravila elementarnih in drugih iger.'),(2326,2326,28,0,'pozna primerna športna oblačila in obutev,'),(2327,2327,28,0,'Pozna in uporablja primerna športna oblačila in obutev.'),(2328,2328,28,0,'Pozna primerna športna oblačila in obutev.'),(2329,2329,28,0,'pozna in upošteva osnovna pravila varnosti v telovadnici, na igrišču in v bazenu.'),(2330,2330,28,0,'Pozna in upošteva osnovna pravila varnosti v telovadnici, na igrišču in v bazenu.'),(2331,2331,28,0,'Pozna  osnovna pravila varnosti v telovadnici, na igrišču in v bazenu.'),(2332,2332,28,0,'Upošteva osnovna pravila varnosti v telovadnici, na igrišču in v bazenu.'),(2333,2333,29,1,'izvaja naravne oblike gibanja,'),(2334,2334,29,1,'Samostojno izvaja naravne oblike gibanja v različnih smereh. Gibi so usklajeni.'),(2335,2335,29,1,'Izvaja različne naravne oblike gibanja.'),(2336,2336,29,1,'Nekatere naravne oblike gibanja izvaja ob spodbudi. Gibanje rok in nog še ni usklajeno.'),(2337,2337,29,1,'posnema predmete, živali, pojave in pojme,'),(2338,2338,29,1,'Predmete,... posnema domiselno, sproščeno in natančno.'),(2339,2339,29,1,'Zadržano posnema pojave, predmete in pojme. Izvirno posnema _____(npr. živali).'),(2340,2340,29,1,'S predhodnim prikazom posnema enostavne gibe.'),(2341,2341,29,1,'ravna z različnimi športnimi pripomočki,'),(2342,2342,29,1,'Samostojno in pravilno ravna z različnimi športnimi pripomočki.'),(2343,2343,29,1,'Pravilno ravna z nekaterimi športnimi pripomočki.'),(2344,2344,29,1,'Ob učiteljevem vodenju uporablja športne pripomočke.'),(2345,2345,29,1,'teče, skače z enonožnim in sonožnim odrivom in meče žogico v daljino in cilj,'),(2346,2346,29,1,'Hitro teče, je spreten pri skokih in natančen pri metu žogice v cilj.'),(2347,2347,29,1,'Usklajeno teče in skače; tehniko odriva še osvaja. Ob večkratnih poskusih zadene cilj.'),(2348,2348,29,1,'Počasneje teče in skače. Tehniko odriva še spoznava. Lažje vrže žogico v daljino, kot zadene cilj.'),(2349,2349,29,1,'izvaja osnovne gimnastične prvine,'),(2350,2350,29,1,'izvaja osnovne gimnastične prvine,'),(2351,2351,29,1,'Po večkratnih poskusih pravilno izvaja osnovne gimnastične prvine.'),(2352,2352,29,1,'Ob pomoči izvaja osnovne gimnastične prvine.'),(2353,2353,29,1,'meče, podaja, lovi in vodi žogo,'),(2354,2354,29,1,'Spretno podaja, lovi in vodi žogo.'),(2355,2355,29,1,'Žogo poda, a je ne ulovi. Vodi jo na krajšo razdaljo.'),(2356,2356,29,1,'Neusklajeno podaja in lovi žogo. Žoge ne vodi.'),(2357,2357,29,1,'zapleše dva otroška plesa,'),(2358,2358,29,1,'Giblje se skladno z ritmom. Pravilno izvaja gibanje z vsemi elementi plesa.'),(2359,2359,29,1,'Težje uskladi gibanje z ritmiko plesa. Poskuša upoštevati elemente plesa.'),(2360,2360,29,1,'Ob pomoči zapleše del plesa.'),(2361,2361,29,1,'drsi z glavo v vodi,'),(2362,2362,29,1,'Drsi z glavo v vodi.'),(2363,2363,29,1,'Na vodo se prilagaja. V plitvi vodi izvaja elementarne vaje.'),(2364,2364,29,1,'Teče in hodi v plitvi vodi.'),(2365,2365,29,1,'pozna osnovne položaje telesa, rok in nog,'),(2366,2366,29,1,'Pozna osnovne položaje telesa, rok in nog. Pravilno se giblje po navodilu.'),(2367,2367,29,1,'Spoznava osnovne položaje rok in nog in jih ob vodenju izvaja.'),(2368,2368,29,1,'pozna primerna športna oblačila in obutev,'),(2369,2369,29,1,'Pozna in uporablja ustrezno športno opremo.'),(2370,2370,29,1,'Pozna športno opremo, a jo le občasno uporablja.'),(2371,2371,29,1,'Športne opreme ne uporablja.'),(2372,2372,29,1,'pozna preprosta pravila elementarnih iger.'),(2373,2373,29,1,'Razume in upošteva pravila elementarnih iger in upošteva soigralce.'),(2374,2374,29,1,'Pozna in upošteva pravila nekaterih elementarnih iger. Soigralcev ne upošteva vedno.'),(2375,2375,29,1,'Pozna nekatera pravila elementarnih iger in jih po opozorilu upošteva. Do soigralcev ni vedno strpen.'),(2376,2376,57,0,'izvaja naravne oblike gibanja v različnih pogojih,'),(2377,2377,57,0,'Sproščeno premaguje različne ovire in se koordinirano giblje.'),(2378,2378,57,0,'Izvaja naravne oblike gibanja v različnih pogojih. Gibanje še ni povsem koordinirano.'),(2379,2379,57,0,'Izvaja preproste naravne oblike gibanja. Gibanje je nekoordinirano.'),(2380,2380,57,0,'posnema predmete, živali, pojave in pojme v naravi,'),(2381,2381,57,0,'Sproščeno posnema predmete, živali, pojave in pojme v naravi.'),(2382,2382,57,0,'Ob pomoči posnema predmete, živali, pojave in pojme v naravi.'),(2383,2383,57,0,'Nesproščeno posnema predmete, živali, pojave in pojme v naravi.'),(2384,2384,57,0,'izvaja skladnejša gibanja ob glasbeni spremljavi,'),(2385,2385,57,0,'Sproščeno izvaja skladnejša gibanja ob glasbeni spremljavi.'),(2386,2386,57,0,'Nesproščeno izvaja skladnejša gibanja ob glasbeni spremljavi.'),(2387,2387,57,0,'Ob spodbudi izvaja skladnejša gibanja ob glasbeni spremljavi.'),(2388,2388,57,0,'ravna z različnimi športnimi pripomočki,'),(2389,2389,57,0,'Poimenuje in pravilno ravna z različnimi športnimi pripomočki.'),(2390,2390,57,0,'Pozna športne pripomočke in orodja ter z njimi pravilno ravna.'),(2391,2391,57,0,'Prepozna športne pripomočke in orodja ter se navaja na pravilno ravnanje z  njimi.'),(2392,2392,57,0,'z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z različnimi žogami,'),(2393,2393,57,0,'Z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z različnimi žogami.'),(2394,2394,57,0,'zapleše preproste otroške plese in plesne igre,'),(2395,2395,57,0,'Pozna in sproščeno zapleše preproste otroške plese in plesne igre.'),(2396,2396,57,0,'Vodeno zapleše preproste otroške plese in plesne igre.'),(2397,2397,57,0,'S posnemanjem in ob spodbudi zapleše preproste otroške plese in plesne igre.'),(2398,2398,57,0,'v eni od tehnik preplava 25 metrov,'),(2399,2399,57,0,'V eni od tehnik preplava 25 metrov.'),(2400,2400,57,0,'Drsi na vodi in se potaplja.'),(2401,2401,57,0,'Navaja se na vodo.'),(2402,2402,57,0,'spozna prvine nekaterih zimskih športov,'),(2403,2403,57,0,'Spozna prvine nekaterih zimskih športov.'),(2404,2404,57,0,'pozna različne položaje telesa,'),(2405,2405,57,0,'Pozna in pravilno izvaja različne položaje telesa.'),(2406,2406,57,0,'Delno pozna in izvaja različne položaje telesa.'),(2407,2407,57,0,'S posnemanjem izvaja različne položaje telesa-'),(2408,2408,57,0,'pozna različne športne naprave, orodja in pripomočke,'),(2409,2409,57,0,'Pozna in poimenuje različne športne naprave, orodja in pripomočke.'),(2410,2410,57,0,'Delno pozna različne športne naprave, orodja in pripomočke.'),(2411,2411,57,0,'Pravilno poimenuje nekaj različnih športnih naprav, orodij in pripomočkov.'),(2412,2412,57,0,'razume in upošteva preprosta pravila elementarnih in drugih iger,'),(2413,2413,57,0,'Razume in dosledno upošteva preprosta pravila elementarnih in drugih iger.'),(2414,2414,57,0,'Pozna  in delno upošteva preprosta pravila elementarnih in drugih iger.'),(2415,2415,57,0,'Preprosta pravila elementarnih in drugih iger mu je treba še ponoviti.'),(2416,2416,57,0,'pozna primerna športna oblačila in obutev,'),(2417,2417,57,0,'Pozna, poimenuje in uporablja primerna športna oblačila in obutev.'),(2418,2418,57,0,'Pozna, a ne uporablja redno primerna športna oblačila in obutev.'),(2419,2419,57,0,'Skozi šolsko leto se seznanja s primerno športno opremo, a jo le redko uporablja.'),(2420,2420,57,0,'pozna in upošteva osnovna pravila varnosti v telovadnici, na igrišču, v bazenu, na drsališču…'),(2421,2421,57,0,'Pozna in redno upošteva osnovna pravila varnosti v telovadnici, na igrišču, v bazenu, na drsališču…'),(2422,2422,57,0,'Pozna in občasno upošteva osnovna pravila varnosti v telovadnici, na igrišču, v bazenu, na drsališču…'),(2423,2423,57,0,'Pozna in redkokdaj upošteva osnovna pravila varnosti v telovadnici, na igrišču, v bazenu, na drsališču…'),(2424,2424,58,1,'izvaja naravne oblike gibanja v različnih pogojih,'),(2425,2425,58,1,'Sproščeno premaguje različne ovire in se koordinirano giblje'),(2426,2426,58,1,'Izvaja naravne oblike gibanja v različnih pogojih. Gibanje še ni povsem koordinirano.'),(2427,2427,58,1,'Izvaja preproste naravne oblike gibanja. Gibanje je nekoordinirano.'),(2428,2428,58,1,'ravna z različnimi športnimi pripomočki,'),(2429,2429,58,1,'Poimenuje in pravilno ravna z različnimi športnimi pripomočki.'),(2430,2430,58,1,'Pozna športne pripomočke in orodja ter z njimi pravilno ravna.'),(2431,2431,58,1,'Prepozna športne pripomočke in orodja ter se navaja na pravilno ravnanje z njimi.'),(2432,2432,58,1,'teče, skače z enonožnim in sonožnim odrivom in meče žogico v daljino in cilj,'),(2433,2433,58,1,'Koordinirano in sproščeno teče, zna skakati s sonožnim in enonožnim odrivom. Natančno meče žogico v daljino in cilj.'),(2434,2434,58,1,'Sproščeno teče in skače z enonožnim in sonožnim odrivom. Natančno meče žogico v daljino, po nekaj poskusih zadene žogico v cilj.'),(2435,2435,58,1,'Pri teku je nesproščen. Gibanje rok in nog še ni usklajeno. Seznanja se s tehniko skakanja v daljino z mesta in z zaletom. Žogico vrže v daljino, a le malo.'),(2436,2436,58,1,'izvaja osnovne gimnastične prvine,'),(2437,2437,58,1,'Pravilno izvaja osnovne gimnastične prvine ( preval naprej)'),(2438,2438,58,1,'Ob pomoči ustrezno izvaja osnovne gimnastične prvine.'),(2439,2439,58,1,'S pomočjo učitelja, vendar še vedno pomanjkljivo izvaja osnovne gimnastične prvine.'),(2440,2440,58,1,'meče, podaja, lovi, vodi žogo ter z njo zadeva različne cilje,'),(2441,2441,58,1,'Spretno meče, podaja, lovi in vodi žogo ter z njo natančno zadeva različne cilje.'),(2442,2442,58,1,'Meče, podaja, vodi žogo ter z njo zadeva različne cilje.'),(2443,2443,58,1,'Pri metanju, podajanju, lovljenju in vodenju žoge ter pri zadevanju različnih ciljev je manj spreten.'),(2444,2444,58,1,'zapleše dva otroška plesa,'),(2445,2445,58,1,'Pozna otroške plese in jih sproščeno zapleše.'),(2446,2446,58,1,'Vodeno pleše otroške plese.'),(2447,2447,58,1,'S posnemanjem in ob spodbudi zapleše otroške plese.'),(2448,2448,58,1,'preplava petindvajset metrov,'),(2449,2449,58,1,'Preplava 25 m v ustrezni tehniki.'),(2450,2450,58,1,'Drsi na vodi in se potaplja.'),(2451,2451,58,1,'Navaja se na vodo.'),(2452,2452,58,1,'pozna različne položaje telesa, rok in nog,'),(2453,2453,58,1,'Pozna in pravilno izvaja različne položaje telesa, rok in nog.'),(2454,2454,58,1,'Delno pozna in izvaja različne položaje telesa , rok in nog.'),(2455,2455,58,1,'S posnemanjem izvaja osnovne položaje telesa, rok in nog.'),(2456,2456,58,1,'pozna primerna športna oblačila in obutev,'),(2457,2457,58,1,'Poimenuje in uporablja primerna športna oblačila in obutev.'),(2458,2458,58,1,'Pozna, a ne uporablja redno primernih športnih oblačil in obutve.'),(2459,2459,58,1,'Skozi šolsko leto se seznanja s primerno športno opremo. A jo le redko uporablja.'),(2460,2460,58,1,'pozna in upošteva preprosta pravila elementarnih in drugih iger.'),(2461,2461,58,1,'Dosledno upošteva preprosta pravila elementarnih in drugih iger.'),(2462,2462,58,1,'Pozna preprosta pravila elementarnih in drugih iger, a jih večkrat ne upošteva.'),(2463,2463,58,1,'Navodila preprostih  elementarnih in drugih iger mu je potrebno še ponoviti.'),(2464,2464,86,0,'sproščeno in skladno z navodili izvaja naravne oblike gibanja v različnih pogojih,'),(2465,2465,86,0,'Sproščeno in skladno z navodili izvaja naravne oblike gibanja v različnih pogojih.'),(2466,2466,86,0,'Dokaj sproščeno in skladno z navodili izvaja naravne oblike gibanja v različnih pogojih.'),(2467,2467,86,0,'Nesproščeno in ne skladno z navodili izvaja naravne oblike gibanja v različnih pogojih.'),(2468,2468,86,0,'upošteva pravila moštvenih, štafetnih in drugih iger, sodeluje s sošolci,'),(2469,2469,86,0,'Upošteva pravila moštvenih, štafetnih in drugih iger ter sodeluje s sošolci.'),(2470,2470,86,0,'Ob opozorilih upošteva pravila moštvenih, štafetnih in drugih iger ter sodeluje s sošolci.'),(2471,2471,86,0,'Pogosto pozabi upoštevati  pravila moštvenih, štafetnih in drugih iger, s sošolci sodeluje le ob opozorilih. Sodeluje s sošolci,'),(2472,2472,86,0,'usvaja osnovne elemente atletike in gimnastike,'),(2473,2473,86,0,'Zelo uspešno usvaja osnovne elemente atletike in gimnastike.'),(2474,2474,86,0,'Uspešno usvaja osnovne elemente atletike in gimnastike.'),(2475,2475,86,0,'Dokaj uspešno usvaja osnovne elemente atletike in gimnastike.'),(2476,2476,86,0,'Dokaj uspešno usvaja osnovne elemente atletike in gimnastike.'),(2477,2477,86,0,'Uspešno prepoznava in pleše družabne in ljudske plese, povezuje gibanje z glasbeno spremljavo.  '),(2478,2478,86,0,'Ob učiteljevi pomoči prepoznava in pleše družabne in ljudske plese, povezuje gibanje z glasbeno spremljavo.'),(2479,2479,86,0,'Družabne in ljudske plese ne prepoznava in jih ne povezuje z glasbeno spremljavo.'),(2480,2480,86,0,'izvaja različna gibanja z različnimi žogami in jih uporablja v različnih igrah,'),(2481,2481,86,0,'Spretno in hitro izvaja različna gibanja z različnimi žogami in jih uporablja v različnih igrah.'),(2482,2482,86,0,'Dokaj hitro in spretno izvaja različna gibanja z različnimi žogami in jih uporablja v različnih igrah.'),(2483,2483,86,0,'Ob spodbudi izvaja različna gibanja z različnimi žogami in jih uporablja v različnih igrah.'),(2484,2484,86,0,'je prilagojen/a na vodo in preplava 25 metrov,'),(2485,2485,86,0,'Je prilagojen na vodo in preplava več kot 25 m.'),(2486,2486,86,0,'Je prilagojen na vodo in preplava 25 m.'),(2487,2487,86,0,'Je prilagojen na vodo, a preplava manj kot 25 m.'),(2488,2488,86,0,'poznajo športno opremo, pravila varne hoje in obnašanja v gorah,'),(2489,2489,86,0,'Pozna športno opremo, pravila varne hoje in obnašanja v gorah.'),(2490,2490,86,0,'Ob pomoči pozna športno opremo, pravila varne hoje in obnašanja v gorah.'),(2491,2491,86,0,'Ne pozna športne opreme, pravil varne hoje in obnašanja v gorah.'),(2492,2492,86,0,'spremlja razvoj gibalnih sposobnosti, spozna merske enote in postopke merjenja.'),(2493,2493,86,0,'Spremlja razvoj gibalnih sposobnosti, spozna merske enote in postopke merjenja.'),(2494,2494,86,0,'Ob spodbudi spremlja razvoj gibalnih sposobnosti, spozna merske enote in postopke merjenja.'),(2495,2495,86,0,'Ne spremlja razvoja gibalnih sposobnosti,  merskih  enot in postopkov merjenja.'),(2496,2496,86,0,'izvaja nekatere zimske športe,'),(2497,2497,86,0,'Pravilno in varno izvaja nekatere zimske športe.'),(2498,2498,86,0,'Ob učiteljevi pomoči izvaja nekatere zimske športe.'),(2499,2499,86,0,'Ne izvaja zimskih športov.'),(2500,2500,86,0,'spopolnjuje športna znanja (Zlati sonček, Ciciban planinec).'),(2501,2501,86,0,'Zelo uspešno spopolnjuje športna znanja (Zlati sonček, Ciciban planinec).'),(2502,2502,86,0,'Uspešno spopolnjuje športna znanja (Zlati sonček, Ciciban planinec).'),(2503,2503,86,0,'Dokaj uspešno spopolnjuje športna znanja (Zlati sonček, Ciciban planinec).'),(2504,2504,87,1,'sproščeno in skladno z navodili izvaja naravne oblike gibanja v različnih pogojih,'),(2505,2505,87,1,'Izvaja naravne oblike gibanja sproščeno in skladno.'),(2506,2506,87,1,'Sproščeno izvaja naravne oblike gibanja.'),(2507,2507,87,1,'Navaja se na skladno in sproščeno izvajanje naravnih oblik gibanja.'),(2508,2508,87,1,'neprekinjeno teče, do šest minut, pozna elemente visokega štarta, skače v daljino z mesta in s kratkim zaletom z enonožnim odrivom in sonožnim doskokom,'),(2509,2509,87,1,'Neprekinjeno teče 6 min., pozna elemente visokega starta, skače v daljino z mesta in s kratkim zaletom z enonožnim odrivom in sonožnim doskokom.'),(2510,2510,87,1,'Neprekinjeno teče 5 min., pozna elemente visokega starta, skače v daljino z mesta in s kratkim zaletom.'),(2511,2511,87,1,'Neprekinjeno teče 4 min., pozna elemente visokega starta, skače v daljino z mesta.'),(2512,2512,87,1,'pravilno izvaja preval naprej in nazaj, hodi po nizki gredi, obvlada naskok na skrinjo, prepleza dva metra, sonožno preskoči kolebnico osemkrat,'),(2513,2513,87,1,'Pravilno izvaja preval naprej in nazaj, hodi po nizki gredi, obvlada naskok na skrinjo, prepleza dva metra, sonožno preskoči kolebnico 8x.'),(2514,2514,87,1,'Pravilno izvaja preval naprej in nazaj, skače na skrinjo, prepleza en meter, sonožno preskoči kolebnico do 8x.'),(2515,2515,87,1,'Na žrdi se drži 6 sek., preskakuje kolebnico.'),(2516,2516,87,1,'pozna osnovne korake treh družabnih plesov, prepozna pet ljudskih plesov,'),(2517,2517,87,1,'Usvojil je korake več družabnih in prepozna pet ljudskih plesov.'),(2518,2518,87,1,'Pozna korake več družabnih in nekaj ljudskih plesov.'),(2519,2519,87,1,'Izvaja enostavne oblike gibanja ob glasbi.'),(2520,2520,87,1,'vodi, meče, podaja, lovi žogo, jo meče v daljino in cilj,'),(2521,2521,87,1,'Vodi, meče, podaja, lovi žogo, jo meče v daljino in cilj.'),(2522,2522,87,1,'Vodi, meče, podaja, lovi žogo, jo meče v daljino.'),(2523,2523,87,1,'Vodi, meče, podaja, lovi žogo, jo meče v daljino z obema rokama.'),(2524,2524,87,1,'preplava petindvajset metrov,'),(2525,2525,87,1,'Preplava 25 metrov.'),(2526,2526,87,1,'Preplava do 25 metrov.'),(2527,2527,87,1,'Plava, je prilagojen na vodo.'),(2528,2528,87,1,'pozna pravila varne hoje v gorah,'),(2529,2529,87,1,'Pozna pravila varne hoje v gorah.'),(2530,2530,87,1,'Ne pozna pravil varne hoje v gorah.'),(2531,2531,87,1,'ravna z različnimi športnimi pripomočki ter pozna postopke merjenja,'),(2532,2532,87,1,'Pravilno ravna s športnimi pripomočki in pozna postopke merjenja.'),(2533,2533,87,1,'Pravilno ravna z nekaterimi športnimi pripomočki in pozna  nekatere postopke merjenja.'),(2534,2534,87,1,'upošteva pravila elementarnih, moštvenih in drugih iger.'),(2535,2535,87,1,'Dosledno upošteva pravila elementarnih , moštvenih in drugih iger.'),(2536,2536,87,1,'Upošteva pravila elementarnih, moštvenih in drugih iger.'),(2537,2537,87,1,'Upošteva pravila iger dokler je v njih uspešen.'),(2538,2538,3,1,'Smiselno sodeluje v pogovoru, obvlada temeljna načela vljudnega pogovarjanja in sodeluje v igri vlog. '),(2539,2539,3,1,'Prepozna lastnosti književne osebe, se vanjo vživi in jo zaigra.'),(2540,2540,3,1,'Obnovi vsebino pravljice, jo pripoveduje(s pomočjo vprašanj), ve kdo so glavne književne osebe, kje in kdaj se je dogajalo (nekoč-danes) in odgovori na vprašanja o besedilu.'),(2541,2541,3,1,'Zmore poslušati in razume krajša neumetnostna besedila.'),(2542,2542,3,1,'Pravilno poimenuje bitja/predmete v svoji okolici ali na sliki.'),(2543,2543,3,1,'Samostojno doživeto deklamira pesem.'),(2544,2544,3,1,'Prepozna pomen in tvori smiselna in nazorna nebesedna sporočila.'),(2545,2545,3,1,'Poimenuje svoj prvi/materni jezik.'),(2546,2546,3,1,'Ima razvite osnovne predpisalne spretnosti.'),(2547,2547,3,1,'Prepozna in zapiše velike tiskane črke.'),(2548,2548,8,1,'Orientira se v prostoru in na ravnini.'),(2549,2549,8,1,'Pozna (prepozna) osnovne geometrijske oblike in jih opiše.'),(2550,2550,8,1,'Šteje, bere, zapiše in  primerja naravna števila do 20.'),(2551,2551,8,1,'Sešteva in odšteva v množici naravnih števil do 5.'),(2552,2552,8,1,'Sešteva in odšteva v množici naravnih števil do 10.'),(2553,2553,8,1,'Sešteva in odšteva v množici naravnih števil do 20, s preštevanjem tudi s prehodom čez 10.'),(2554,2554,8,1,'Pozna in uporablja računski operaciji seštevanje in odštevanje.'),(2555,2555,8,1,'Razporedi elemente po eni ali več lastnostih. Razporeditev prikaže v diagramu.'),(2556,2556,8,1,'Bere podatke iz preglednic in prikazov.'),(2557,2557,12,1,'Pozna in uporablja nekatere osnovne obravnavane likovne pojme (pika, črta,risanje, risarski materiali in pripomočki, risba, slikanje, slika, slikarski materiali in pripomočki,barva, ploskev, mešanje barv, svetle in temne barve, odtis, kip, gnetenje, valjanje, prostorske pojme: zunaj, znotraj, spredaj, zadaj, spodaj, zgoraj, naprej, nazaj, poševno, levo, desno).'),(2558,2558,12,1,'Se spontano, doživeto in igrivo likovno izraža.'),(2559,2559,12,1,'Izkazuje sposobnost opazovanja in v likovni izdelek vnaša podrobnosti.'),(2560,2560,12,1,'Uporabi obravnavane likovne materiale in orodja.'),(2561,2561,17,1,'V skupini sproščeno in doživeto poje otroške, ljudske in umetne pesmi in pesmi iz preteklosti. Upošteva glasno, tiho, počasneje, hitrejše izvajanje.'),(2562,2562,17,1,'Ritmično izreka izštevanke in otroška besedila.'),(2563,2563,17,1,'Z glasbili izvaja preproste ritmične vzorce.'),(2564,2564,17,1,'Prepozna, uporablja in razume glasbene pojme: pevec, solist, pesem, pevski zbor, zborovodja,skladba, orkester, dirigent.'),(2565,2565,17,1,'Zvočna doživetja ter glasbene predstave izraža z gibanjem, besedno in v likovni komunikaciji.'),(2566,2566,17,1,'Ustvarja spremljave in zvočne slike.'),(2567,2567,17,1,'Zbrano posluša krajše skladbe.'),(2568,2568,27,1,'Zna se predstaviti z osnovnimi podatki.'),(2570,2570,27,1,'Pozna dejavnike varnosti v prometu in pravila za pešce.'),(2571,2571,27,1,'Orientira se v svojem okolju.'),(2572,2572,27,1,'Pozna različne oblike družin in sorodstvene odnose v ožji družini.'),(2573,2573,27,1,'Spoštljivo ravna do sebe in drugih.'),(2574,2574,27,1,'Opiše, kaj živa bitja potrebujejo za življenje.'),(2575,2575,27,1,'Pozna nekaj lastnosti teles in snovi, zna jih razvrstiti po dani lastnosti.'),(2576,2576,27,1,'Zna časovno opredeliti dogodke in pojave.'),(2577,2577,27,1,'Vedo, da imajo nekateri dnevi v letu ( prazniki) poseben pomen.'),(2578,2578,27,1,'Razume pomen zdravja za človeka in načine ohranjanja zdravja.'),(2579,2579,27,1,'Pozna in opiše vremenska stanja.'),(2580,2580,27,1,'Ve, da moramo varovati naravno okolje. Ve kako lahko sam prispeva k rejenemu videzu okolice. Ve, da je treba ustrezno ravnati z odpadki.'),(2581,2581,29,1,'Upošteva pravila preprostih iger.'),(2582,2582,29,1,'Sproščeno in koordinirano teče na krajše razdalje iz visokega starta.'),(2583,2583,29,1,'Meče žogico z mesta v cilj in daljino.'),(2584,2584,29,1,'Hodi in skače po ožji površini (klop).'),(2585,2585,29,1,'Pozna rajalne igre, zapleše tri preproste otroške plese.'),(2586,2586,29,1,'Z eno roko vodi in podaja žogo.'),(2587,2587,29,1,'Učenec je prilagojen na vodo in preplava 15m.');

/*Table structure for table `tabopznanjen` */

DROP TABLE IF EXISTS `tabopznanjen`;

CREATE TABLE `tabopznanjen` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `IdZnanje` int(10) DEFAULT NULL,
  `IdCilji` int(10) DEFAULT NULL,
  `TipZnanja` int(10) DEFAULT NULL,
  `OpisZnanja` text,
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `IdZnanje` (`IdZnanje`),
  KEY `IdCilji` (`IdCilji`)
) ENGINE=InnoDB AUTO_INCREMENT=2465 DEFAULT CHARSET=utf8;

/*Data for the table `tabopznanjen` */

insert  into `tabopznanjen`(`ID`,`IdZnanje`,`IdCilji`,`TipZnanja`,`OpisZnanja`) values (1,1,1,0,'Preprosta sporočila izrazi z nebesednimi znamenji; iz nebesednih znamenj prepozna sporočilo in ga izrazi z besedami.'),(4,4,1,0,'Smiselno sodeluje v pogovoru z učiteljem in drugimi sogovorci; pri tem ustrezno uporablja spoštljive ogovore oseb, jih tika ali vika; uporablja vljudne izraze za izrekanje prošnje, zahvale, opravičila, voščila in priznanja;'),(9,9,1,0,'Po poslušanju odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga utemeljuje; govori o svojih izkušnjah in občutkih ob besedilu.'),(13,13,1,0,'Govorno nastopa z vnaprej pripravljeno stvarno temo - pred razredom ob učiteljevih vprašanjih opisuje sebe, žival, predmet ter dogodek.'),(18,18,1,0,'Po poslušanju učiteljevega pripovedovanja besedila ali ogledu lutkovne predstave izraža svoje razumevanje besedila.'),(21,21,1,0,'Poistoveti se s književno osebo, pove, kako si predstavlja književno osebo in prostor ter primerja svoje predstave s predstavami sošolcev.'),(25,25,1,0,'Sodeluje v skupinski dramatizaciji besedila, izdeluje lutke.'),(29,29,1,0,'Samostojno pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(33,33,1,0,'Drugače govori o stvarnosti kot o domišljijskih svetovih ter tvori svoje domišljijske svetove;'),(36,36,1,0,'Poimenuje bitja/predmete na sliki; besedam najde protipomenke, tvori manjšalnice in ljubkovalnice, si izmišlja nove besede.'),(40,40,1,0,'Samostojno sestavlja ritmična besedila, išče besede, ki se rimajo, memorira in deklamira pesmi s polnimi rimami, niza asociacije ob tematski besedi.'),(44,44,1,0,'Samostojno določi število bitij/predmetov/likov in njihov vrstni red; primerja njihove lastnosti, ugotavlja njihov položaj, opazuje njihovo gibanje.'),(48,48,1,0,'Pravilno uporablja časovno prislove (zdaj, prej, potem, včeraj, danes, jutri) in glagolske časovne oblike (sedanjik, preteklik, prihodnjik) .'),(52,52,1,0,'V izgovorjenih besedah samostojno prepozna število zlogov ter začetni zlog in glas.'),(56,56,2,0,'V knjigi in časopisu/reviji loči slikovni in črkovni del.'),(59,59,2,0,'Ob slikah/ilustracijah samostojno sledi besedilu, ki ga posluša.'),(63,63,2,0,'Izvirno ilustrira besedilo, izrazi svojo domišjijskočutno predstavo dogajalnega prostora.'),(67,67,2,0,'Izvirno prikaže književno dogajanje s sličicami.'),(71,71,2,0,'Samostojno in pravilno glasno \"bere\" slike/ilustracije; \"bere\" pravljico ob nizu slik.'),(75,75,2,0,'Pravilno bere naslikane in tiskane zapovedi, opozorila in obvestila iz svojega okolja; pove, kaj sporoča in kako je treba ob njem ravnati.    '),(79,79,2,0,'Samostojno napiše svojo pravljico z nizanjem sličic.'),(83,83,2,0,'Učitelju narekuje pravljico, ki jo dobro pozna oz. zna na pamet.'),(86,86,2,0,'Učitelju samostojno narekuje zapovedi, prepovedi, opozorila in obvestila iz svojega okolja oz. jih napiše sam.'),(90,90,2,0,'Obvlada pravilno držo telesa ter pravilno uporabo raznih pisal.'),(93,93,2,0,'Orientira se na svojem telesu, v prostoru in na papirju ter obvlada smer pisanja od leve proti desni in od zgoraj navzdol.'),(97,97,2,0,'Obvlada poteze, potrebne za pisanje črk in številk.'),(101,101,2,0,'Samostojno in pravilno razvršča predmete/like (po enakosti ali podobnosti).'),(105,105,2,0,'V zapisani besedi ali v besednih dvojicah prepozna enake črke.'),(109,109,2,0,'Pravilno preslikava preproste besede in črke; črke poveže z ustreznimi glasovi.'),(113,113,3,1,'Sodeluje v pogovoru, obvlada temeljna načela vljudnega pogovarjanja in sodeluje v igri vlog. '),(118,118,3,1,'Prepozna lastnosti književne osebe, se vanjo vživi in jo zaigra. '),(123,123,3,1,'Obnovi vsebino pravljice, jo pripoveduje, ve, kdo so glavne književne osebe, kje in kdaj se pravljica dogaja in odgovori na vprašanja o besedilu. \r\n'),(127,127,3,1,'Zmore poslušati in razume krajša neumetnostna besedila. '),(131,131,3,1,'Pravilno poimenuje bitja/predmete v svoji okolici ali na sliki. '),(135,135,3,1,'Samostojno in doživeto deklamira pesem. '),(139,139,3,1,'Prepozna pomen in tvori smiselna ter nazorna nebesedna sporočila. '),(143,143,3,1,'Poimenuje svoj prvi/materni jezik. '),(147,147,3,1,'Ima razvite osnovne predpisalne spretnosti (pravilna drža telesa in uporaba raznih pisal; obvlada poteze, potrebne za pisanje črk in številk; v izgovorjenih besedah prepozna število zlogov ter začetni zlog in glas; sliši prvi, zadnji glas ter posamezne glasove v besedi). '),(151,151,3,1,'Prepozna in zapiše velike tiskane črke. '),(156,156,30,0,'Smiselno sodeluje v pogovoru z raznimi sogovorci; pri tem upošteva načelo ustreznosti (vljudnosti); prepozna nevljudne izraze in jih zamenja za vljudne.'),(160,160,30,0,'Po poslušanju neumetnostnega besedila odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu ter ga zna utemeljiti, govori o svojih izkušnjah.'),(165,165,30,0,'Po poslušanju učiteljevega pripovedovanja besedila,  ogledu lutkovne/gledališke predstave, samostojno govorno povzame vsebino besedila.'),(170,170,30,0,'Prepozna in opiše dogajalni prostor in čas.'),(175,175,30,0,'Poimenuje in označi književne osebe, opisuje književno dogajanje z zornega kota osebe, s katero se je identificiral.'),(179,179,30,0,'Razloži, zakaj je kakšna književna oseba kaj storila.'),(183,183,30,0,'Samostojno označi književno osebo s posebej oblikovanim govorom.'),(187,187,30,0,'Besedilo povezuje s svojim izkušenjskim in čustvenim svetom.'),(192,192,30,0,'Pripoveduje znane pravljice in si izmišlja svoje, pri tem posnema značilno zgradbo pravljic.'),(196,196,30,0,'Izraža zaznavanje zvočnosti in ritma, sestavlja ritmična besedila, se igra s črkami in besedami, išče besede, ki se rimajo.'),(199,199,30,0,'Izrazi zaznavanje likovne oblikovanosti besedila ter besedilne slike.'),(203,203,30,0,'Memorira in deklamira pesmi, niza asociacije ob tematski besedi,'),(207,207,30,0,'Napoveduje nadaljevanje zgodbe pripoveduje nadaljevanje pravljice, tvori narobe pravljice in kombinacije dveh pravljic, pripoveduje realistično zgodbo'),(211,211,30,0,'Pogosto  sodeluje v domišljijski igri vlog.'),(215,215,30,0,'Vedno sodeluje v skupinski dramatizaciji besedila, izdeluje lutke,'),(219,219,30,0,'Brez težav  našteje razlike med pravljico in risanko.'),(223,223,30,0,'O stvarnosti govori drugače kot o domišljijskih svetovih.'),(227,227,30,0,'Govorno nastopi z vnaprej pripravljeno stvarno temo, ob učiteljevih vprašanjih samostojno predstavi člana svoje družine, opiše svojo najljubšo knjigo.'),(231,231,30,0,'Najde protipomenke in sopomenke ter izraža svojino s svojilnim pridevnikom (nam. s svojilnim rodilnikom),'),(235,235,30,0,'Pravilno uporablja časovne prislove in glagolske časovne oblike, zna določiti zaporedje dejanj.'),(239,239,30,0,'V izgovorjenih besedah prepozna zaporedje in število glasov, v izgovorjenih povedih pa si zapomni zaporedje besed ter prepozna vrsto končne intonacije.'),(243,243,31,0,'Brez napak glasno bere krajša preprosta tiskana neumetnostna besedila.'),(247,247,31,0,'Brez težav tiho in poltiho bere neznano krajše umetnostno besedilo (pesmi in znane pravljice), po poprejšnji pripravi bere glasno.'),(250,250,31,0,'Po branju ustno in pisno odgovarja na učiteljeva vprašanja, pove svoje mnenje o besedilu in ga zna utemeljiti, govori o svojih izkušnjah in občutkih.'),(255,255,31,0,'Brez napak zapiše glasove, besede in enostavčne povedi z velikimi in malimi tiskanimi črkami.'),(260,260,31,0,'Brez napak prepiše krajše besedilo s table ali iz knjige, sledi počasnemu nareku posameznih besed in enostavčnih povedi.'),(265,265,31,0,'Samostojno napiše zapovedi, prepovedi in opozorila iz svojega okolja, pisno odgovarja na učiteljeva pisna vprašanja o sebi, o svojem okolju, o prebranem besedilu ter o tem, kar je doživel.'),(269,269,31,0,'Pazi na čitljivost, estetskost in pravilnost zapisa, obvlada rabo velike začetnice na začetku povedi ter v osebnih lastnih imenih, obvlada rabo končni'),(273,273,31,0,'Zelo izvirno ilustrira besedilo, izrazi svojo domišljijskočutno predstavo dogajalnega prostora.'),(276,276,31,0,'Estetsko nariše svojo domišljijskočutno predstavo domišljijskega in realističnega dogajalnega prostora.'),(282,282,31,0,'Hitro in brez težav napiše svojo pravljico z nizanjem sličic,'),(283,283,31,0,'Z učiteljevo pomočjo napiše svojo pravljico z nizanjem sličic,'),(284,284,31,0,'izraža se s kombinacijo risbe in zapisa (strip).'),(285,285,31,0,'Ima velik smisel za izražanje  s kombinacijo risbe in zapisa (strip).'),(286,286,31,0,'Izraža se s kombinacijo risbe in zapisa (strip).'),(287,287,31,0,'Ne izraža se rad s kombinacijo risbe in zapisa (strip).'),(289,289,32,1,'Smiselno se vključuje in sodeluje v pogovoru. Pravilno uporablja vljudnostne izraze. Upošteva pravila in dogovore. '),(294,294,32,1,'Sestavi zgodbo, jo govorno interpretira in doživeto predstavi. '),(299,299,32,1,'Ob branju loči umetnostno besedilo od neumetnostnega in našteva razlike. '),(304,304,32,1,'Tekoče bere. Razume prebrano besedilo. Obnovi besedilo. '),(309,309,32,1,'Vrednoti ravnanje književne osebe, se vanjo vživi in zaigra. Pove svoje mnenje o vsebini. '),(314,314,32,1,'Sestavi pravljico in upošteva vse njene značilnosti. Vrednoti - prepozna lastnosti književnih oseb. '),(320,320,32,1,'Zazna zvočnost pesmi. Samostojno sestavlja, oziroma dodaja rime.'),(326,326,32,1,'Po poslušanju samostojno obnovi vsebino in jo ilustrira. Pove svoje mnenje in ga utemelji.'),(332,332,32,1,'Oblikuje in zapiše enostavčne povedi. Pravilno zapiše veliko začetnico na začetku povedi, za piko, za osebna in lastna imena. '),(338,338,32,1,'Oblikuje in zapiše smiselne odgovore. Pravilno prepiše krajše besedilo in piše po nareku. Piše čitljivo in pazi na estetski videz pisave. '),(344,344,32,1,'Prepiše krajše tiskano besedilo. '),(348,348,32,1,'Pazi na čitljivost in estetskost zapisanih besedil.'),(351,351,32,1,'Glede na govorni položaj uporabi ustrezno zvrst jezika.'),(508,508,4,0,'Orientacija - opredeli položaj predmeta glede na sebe oz. na druge predmete,'),(514,514,4,0,'Orientacija - samostojno se po navodilih premika po prostoru in na ravnini.'),(518,518,4,0,'Samostojno prepozna osnovna geometrijska telesa.'),(521,521,4,0,'Pravilno prepozna geometrijske like (trikotnik, kvadrat, krog in pravokotnik) in jih poimenuje.'),(525,525,4,0,'Pravilno in natančno  prostoročno in s šablono riše črte ter like.'),(528,528,4,0,'Merjenje - primerja in ocenjuje (najkrajši, najdaljši, najtežji, najlažji, največja, najmanjša prostornina),'),(532,532,4,0,'Merjenje - izmeri dolžino z nestandardnimi enotami.'),(535,535,5,0,'Naravna števila in število 0 - šteje do 20'),(538,538,5,0,'Naravna števila in število 0 - loči med glavnim in vrstilnim pomenom števila,'),(543,543,5,0,'Pravilno uredi po velikosti množico naravnih števil do 20,'),(547,547,5,0,'Zna določiti predhodnik in naslednik danega števila.'),(550,550,5,0,'Naravna števila in število 0 - prepozna, nadaljuje in oblikuje preprosta zaporedja,'),(554,554,5,0,'Naravna števila in število 0 - primerja števila po velikosti: enako, večje, manjše.'),(558,558,5,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 10 (tudi število 0),'),(562,562,5,0,'Računske operacije - uporabi računske operacije pri reševanju problemov.'),(566,566,5,0,'Lastnosti operacij - ob konkretnih primerih ugotovi, da lahko vrstni red seštevancev zamenja.'),(570,570,6,0,'Samostojno razvršča predmete, telesa, like, števila,… po izbrani lastnosti.'),(574,574,6,0,'Samostojno odkrije in ubesedi lastnost, po kateri so bili predmeti, telesa, liki, števila, razvrščeni.'),(578,578,6,0,'Razvrstitev predmetov prikaže z različnimi diagrami (puščičnim, Carrollovim in drevesnim.'),(582,582,6,0,'Pravilno uporablja izraze: večji, manjši, daljši, krajši, prej, potem.'),(586,586,6,0,'Samostojno in pravilno zapiše odnos med predmeti in pojmi s puščičnim diagramom.'),(590,590,6,0,'Samostojno uredi elemente po različnih kriterijih (od najdaljšega do najkrajšega, od največjega do najmanjšega).'),(594,594,6,0,'Samostojno odkrije in ubesedi kriterije, po katerih so bili elementi urejeni.'),(597,597,6,0,'Pravilno prepozna, nadaljuje in oblikuje matematični vzorec.'),(600,600,7,0,'Prikazi - predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci,'),(605,605,7,0,'Prikazi - prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(610,610,8,1,'Orientira se v prostoru in ravnini. '),(611,611,8,1,'Pozna (prepozna) osnovne geometrijska telesa (kocka, valj, kvader, krogla, stožec) in oblike - like (kvadrat, pravokotnik, trikotnik, krog) ter jih opiše. \r\n'),(612,612,8,1,'Šteje, bere, zapiše in primerja naravna števila do 20. '),(613,613,8,1,'Sešteva in odšteva v množici naravnih števil do 5. '),(614,614,8,1,'Sešteva in odšteva v množici naravnih števil do 10.'),(615,615,8,1,'Sešteva in odšteva v množici naravnih števil do 20, s preštevanjem tudi s prehodom čez 10. '),(616,616,8,1,'Pozna in uporablja računski operaciji seštevanje in odštevanje. '),(617,617,8,1,'Razporedi elemente po eni ali več lastnostih in to razporeditev prikaže v diagramu. \r\n'),(645,645,33,0,'Orientacija v prostoru - opredeli položaj predmeta glede na sebe oz. glede na druge predmete in se pri poimenovanje položajev pravilno izraža (nad/pod, zgoraj/spodaj, desno/levo),'),(649,649,33,0,'Orientacija v prostoru - po navodilih se premika po prostoru in na ravnini (na listu papirja) ter navodilo tudi oblikuje.'),(653,653,33,0,'Geometrijske oblike - prepozna in poimenuje preprosta geometrijska telesa (krogla, valj, kvader, kocka) in geometrijske like (krog, trikotnik, pravokotnik, kvadrat),'),(657,657,33,0,'Geometrijske oblike - prepozna in nariše različne črte (ravne, krive, sklenjene, nesklenjene),'),(661,661,33,0,'Geometrijske oblike - označi presečišče črt z veliko tiskano črko (točko).'),(666,666,33,0,'Transformacije - prepozna simetrijo pri predmetih v svoji okolici,'),(672,672,33,0,'Uporaba geometrijskega orodja - potegne črte ob ravnilu,'),(676,676,33,0,'Merjenje - oceni in izmeri dolžino z nestandardno (izbrano) enoto in s standardnimi enotami m, dm, cm,'),(680,680,33,0,'Merjenje - izmeri maso z nestandardno in standardno enoto (kg),'),(683,683,33,0,'Merjenje - zapiše meritev z merskim številom in enoto (denar, masa, dolžina),'),(687,687,33,0,'Merjenje - sešteva in odšteva količine enakih enot (denar, masa, dolžina).'),(692,692,34,0,'Samostojno razvrsti predmete, telesa, like, števila po največ dveh lastnostih.'),(696,696,34,0,'Brez težav odkrije in ubesedi lastnosti, po katerih so bili predmeti, telesa, liki, števila razvrščeni.'),(700,700,34,0,'Samostojno prikaže razvrstitev predmetov z različnimi diagrami (s puščičnim, Carrollovim, Euler-Venovim diagramom).'),(704,704,35,0,'Samostojno  in pravilno predstavi preproste podatke s preglednico, figurnim prikazom in prikazom s stolpci.'),(708,708,35,0,'Pravilno prebere preprosto preglednico, figurni prikaz in prikaz s stolpci.'),(712,712,35,0,'Samostojno in pravilno zbere in uredi podatke ter jih pregledno predstavi in prebere.'),(716,716,35,0,'Samostojno nastavi in prešteje vse možne izide pri najpreprostejših kombinatornih situacijah (poišče razporedbe največ treh različnih predmetov).'),(719,719,36,0,'Naravna števila - šteje, piše in bere števila do 100,'),(723,723,36,0,'Naravna števila - razlikuje desetiške enote (enice, desetice),'),(726,726,36,0,'Naravna števila - uredi po velikosti množico naravnih števil do 100,'),(730,730,36,0,'Naravna števila - določi predhodnik in naslednik danega števila,'),(734,734,36,0,'Naravna števila - samostojno oblikuje in nadaljuje preprosto zaporedje števil.'),(737,737,36,0,'Naravna števila - zapiše odnose med števili (<, >,=).'),(741,741,36,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 20 (prehod preko desetice),'),(747,747,36,0,'Računske operacije - sešteva in odšteva v množici naravnih števil do 100 (braz prehoda),'),(752,752,36,0,'Računske operacije - na konkretnem nivoju uporablja zakon o zamenjavi pri seštevanju v obsegu do 20,'),(756,756,36,0,'Računske operacije - v obsegu do 20 rešuje preproste enačbe a ± ? = b, ? ± a = b (poišče manjkajoči člen),'),(760,760,36,0,'Računske operacije - množi na konkretnem nivoju (s konkretnim materialom),'),(763,763,36,0,'Računske operacije - zapiše vsoto enakih seštevancev v obliki produkta,'),(767,767,36,0,'Računske operacije - deli na konkretnem nivoju (s konkretnim materialom),'),(771,771,36,0,'Računske operacije - pri reševanju problemov uporablja računske operacije.'),(775,775,36,0,'Lastnosti operacij - na konkretnem nivoju uporablja zakon o zamenjavi pri seštevanju,'),(779,779,36,0,'Lastnosti operacij - na konkretnem nivoju razume, da sta seštevanje in odštevanje nasprotni operaciji.'),(784,784,37,1,'Razume navodila se orientira v prostoru in na ravnini. Pravilno opiše položaj predmeta. Oblikuje navodila za premikanje.'),(788,788,37,1,'Poimenuje, opiše, razvrsti in uredi geometrijska telesa in like.'),(792,792,37,1,'Oceni in izmeri dolžino ter jo zapiše z merskim številom in mersko enoto.'),(796,796,37,1,'Sešteva in odšteva v množici naravnih števil do 20 s prehodom. Rešuje račune z dopolnjevanjem in zahtevnejše besedilne naloge.'),(801,801,37,1,'Šteje, bere in zapiše števila do 100. Primerja števila.'),(804,804,37,1,'Sešteva, odšteva in rešuje račune z dopolnjevanjem v množici nar. števil do 100 brez prehoda. Rešuje tudi zahtevnejše besedilne naloge'),(808,808,37,1,'Razvršča like, predmete po danem kriteriju. Utemelji kriterij razvrščanja in razvrstitev prikaže z različnimi diagrami.'),(812,812,37,1,'Zbere, uredi in prikaže podatke. Razloži prikaze.'),(995,995,9,0,'Loči različne vrste čutov.'),(998,998,9,0,'Samostojno besedno izrazi najosnovnejše posebnosti pike (točke) in črte (linije).'),(1002,1002,9,0,'Pravilno poimenuje in loči barve.'),(1005,1005,9,0,'Samostojno loči najosnovnejše kiparske pojme.'),(1009,1009,9,0,'Pravilno prepozna osnovne prostorske pojme in se orientira v prostoru.'),(1013,1013,9,0,'Pozna pojma tiskanje in odtis.'),(1016,1016,9,0,'Po likovnih področjih pravilno loči osnovne materiale in orodja.'),(1019,1019,9,0,'Pravilno opiše rabo različnih podlag.'),(1022,1022,9,0,'Samostojno loči rastlinske, živalske, človeške in predmetne motive.'),(1025,1025,9,0,'Pravilno določi lego upodobljenih predmetov in figur na ploskvi.'),(1029,1029,9,0,'Pravilno poimenuje likovne ustvarjalce in njihove umetniške stvaritve.'),(1032,1032,9,0,'Samostojno prepozna likovne kulturne ustanove.'),(1035,1035,9,0,'Na lastnem izdelku in izdelkih vrstnikov po oblikovanih merilih poišče pravilnosti izvedene likovne naloge.'),(1039,1039,10,0,'Se črtno (linijsko) izrazi z različnimi materiali in orodji.'),(1041,1041,10,0,'Z različnimi črtami (linijami) obogati narisane površine.'),(1043,1043,10,0,'Brez podrisavanja se likovno izrazi na izrazno ploskev različnih formatov, velikosti in barv.'),(1045,1045,10,0,'Izvirno naslika sliko z barvno ploskvijo in črto.'),(1048,1048,10,0,'Z barvo pokrije celotno slikovno površino.'),(1051,1051,10,0,'Samostojno meša barve.'),(1055,1055,10,0,'Samostojno naniza različne oblike in velikosti oblik s črto , z barvno ploskvijo, z odtiskovanjem.'),(1058,1058,10,0,'Zna zmodelirati preprosti statični kip (človeška in živalska figura).'),(1061,1061,10,0,'Samostojno zmodelira kip iz enovitega kosa mehkega materiala.'),(1064,1064,10,0,'Izvirno izoblikuje kip iz naravnega ali odpadnega materiala.'),(1068,1068,10,0,'Zgradi preproste zaprte, polzaprte in polodprte prostorske tvorbe (s sestavljenkami in v peskovniku).'),(1071,1071,11,0,'Vedno se spontano likovno izrazi.'),(1074,1074,11,0,'Pogosto razišče izrazne možnosti različnih likovnih materialov in orodij.'),(1078,1078,11,0,'Pogosto izkaže izvirnost pri reševanju likovnih problemov.'),(1082,1082,11,0,'Pri upodobitvi motiva izkaže likovni spomin in domišljijo.'),(1085,1085,12,1,'Pozna in uporablja nekatere osnovne  obravnavane likovne pojme (pika, črta, risarski materiali in pripomočki, risba, slikanje, slika, slikarski materiali in  pripomočki, barva, ploskev, mešanje  barv, svetle in temne barve, odtis, kip, gnetenje, valjanje, prostorske pojme: zunaj, znotraj, spredaj, zadaj, spodaj, zgoraj, naprej, nazaj, poševno, levo, desno). '),(1087,1087,12,1,'Se spontano, doživeto in igrivo likovno izraža. '),(1088,1088,12,1,'Izkazuje sposobnost opazovanja in v likovni izdelek vnaša podrobnosti. '),(1089,1089,10,0,'Uporabi obravnavane likovne materiale in orodja. '),(1118,1118,38,0,'Loči najosnovnejše lastnosti črt (linij).'),(1121,1121,38,0,'Našteje zglede različnih črt v okolju in naravi.'),(1124,1124,38,0,'Samostojno obrazloži razporeditev upodobljenih podob po risalni površini.'),(1127,1127,38,0,'Poimenuje barve ob opazovanju likovnih stvaritev in predmetov v okolju in naravi.'),(1130,1130,38,0,'Samostojno prepozna nemešano in mešano barvo.'),(1134,1134,38,0,'Pojasni nastanek barvne ploskve.'),(1137,1137,38,0,'Samostojno razvrsti barve po svetlosti.'),(1140,1140,38,0,'Dobro razlikuje najosnovnejše kiparske pojme,'),(1144,1144,38,0,'Opiše posebnosti postopka oblikovanja razgibanega obhodnega kipa.'),(1148,1148,38,0,'Pojasni osnovne značilnosti zunanjega in bivalnega prostora.'),(1152,1152,38,0,'Pojasni pojma tiskanje in odtis.'),(1155,1155,38,0,'Pozna in poimenuje umetniške ustvarjalce, njihova dela ter likovne kulturne ustanove,'),(1159,1159,38,0,'Prepozna različne materiale in orodja po likovnih področjih.'),(1162,1162,38,0,'Po oblikovanih merilih dosledno  pojasni izvedbo likovne naloge.'),(1166,1166,39,0,'Z različnimi risarskimi materiali nariše risbo brez podrisavanja.'),(1169,1169,39,0,'Narisane površine ustvarjalno obogati s črtami.'),(1172,1172,39,0,'Z uporabo različnih slikarskih materialov ustvarjalno naslika sliko z barvnimi ploskvami.'),(1175,1175,39,0,'Na spontan način  samostojno meša barve.'),(1178,1178,39,0,'Samostojno svetli barve z belo in temni s črno barvo.'),(1181,1181,39,0,'Samostojno upodobi izbrani motiv na podlage različnih velikosti, barv in kvalitet.'),(1184,1184,39,0,'Ustvarjalno izoblikuje statično in razgibano figuro iz enovitega kosa mehkega materiala,'),(1187,1187,39,0,'Samostojno sestavi kiparsko obliko iz trdega materiala,'),(1190,1190,39,0,'Naniza kiparske oblike iz ploskovitega upogibnega materiala.'),(1193,1193,39,0,'Ustvarjalno zgradi različne oblike prostorov s sestavljenkami, z embalažnimi škatlicami in s peskom v peskovniku.'),(1197,1197,39,0,'Samostojno ritmično odtiskuje oblike v različnih velikostih in barvah.'),(1200,1200,40,0,'Se neposredno in spontano likovno izrazi.'),(1204,1204,40,0,'Pogosto se izrazi z lastno ustvarjalno idejo.'),(1208,1208,40,0,'Pogosto pri upodobitvi motiva izkaže likovno domišljijo, spomin in predstave.'),(1212,1212,40,0,'Pogosto odkriva različne izrazne možnosti ob raznoliki uporabi likovnih materialov in njihovih orodij.'),(1216,1216,41,1,'Loči najosnovnejše likovne pojme posameznih likovnih področij. '),(1220,1220,41,1,'Poišče zglede likovnih pojmov na predmetih in pojavih v naravi. '),(1224,1224,41,1,'Na konkretnih primerih obrazloži spoznane likovne pojme. Se primerno izraža in opisuje. '),(1228,1228,41,1,'Loči osnovne posebnosti različnih likovnih materialov in orodij. Z materialom in orodjem odgovorno in ustrezno ravna. '),(1232,1232,41,1,'Natančno in dosledno izvede likovno tehniko. Odkrije nove možnosti za izvedbo likovne tehnike. '),(1236,1236,41,1,'Ima bogato likovno domišljijo, spomin in predstave. Izkaže originalnost. Je vztrajen in dosleden. '),(1240,1240,41,1,'Sproščeno in ustvarjalno se likovno izraža. Je uspešen na vseh likovnih področjih. '),(1244,1244,41,1,'Pozna in loči likovne stvaritve umetnikov. Kritično jih vrednoti. Pozna likovne kulturne ustanove in njihov pomen. '),(1248,1248,41,1,'Glede na oblikovana merila ovrednoti svoj in izdelek sošolca. '),(1363,1363,13,0,'V svojem glasovnem obsegu pravilno poje krajše ljudske in umetne pesmi.'),(1367,1367,13,0,'Pravilno ritmično izreka načrtovana otroška besedila.'),(1370,1370,13,0,'Petje in ritmično izreko spremlja s posameznimi glasbili.'),(1372,1372,13,0,'Petje in ritmično izreko sproščeno spremlja z gibi in rajanjem.'),(1376,1376,14,0,'Doživljajsko sproščeno poustvarja pesmi in otroška besedila.'),(1379,1379,14,0,'Izvirno z glasbili oblikuje spremljave k petju in ritmični izreki besedil.'),(1382,1382,14,0,'Sproščeno si izmišlja lastne zvočne vsebine.'),(1385,1385,14,0,'Glasbena doživetja in predstave ustvarjalno izraža: gibalno, plesno, likovno ali besedno.'),(1390,1390,15,0,'Zbrano posluša načrtovane skladbe.'),(1393,1393,15,0,'Ob poslušanju prepoznava posamezne inštrumente in pevske glasove.'),(1397,1397,15,0,'Prepoznava različne zvoke: glasbene in druge.'),(1399,1399,16,0,'Razvija si temeljni melodični in ritmični posluh.'),(1401,1401,16,0,'Razvija si pevski glas ter spretnost inštrumentalne igre.'),(1404,1404,16,0,'Razume in uporablja načrtovan glasbeni besednjak.'),(1406,1406,17,1,'V skupini sproščeno in doživeto poje otroške, ljudske in umetne pesmi in pesmi iz preteklosti. Upošteva glasno, tiho, počasno in hitro izvajanje. '),(1407,1407,17,1,'Ritmično izreka izštevanke in otroška besedila. '),(1408,1408,17,1,'Z glasbili samostojno izvaja preproste ritmične vzorce. '),(1409,1409,17,1,'Prepozna, uporablja in razume glasbene pojme: pevec, solist, pesem, pevski zbor, zborovodja, skladba, orkester, dirigent. '),(1410,1410,17,1,'Zvočna doživetja ter glasbene predstave izraža z gibanjem, besedno in v likovni komunikaciji. '),(1411,1411,17,1,'Prepozna posamezne zvoke, glasove in glasbila. '),(1412,1412,17,1,'Zbrano posluša krajše skladbe. '),(1443,1443,42,0,'Pravilno poje nov izbor ljudskih in umetnih pesmi.'),(1447,1447,42,0,'Ritmično natančno izreka in ritmizira otroška ljudska in umetna besedila.'),(1451,1451,42,0,'Petje in ritmično izreko samostojno spremlja z več različnimi vzorci (ostinati).'),(1454,1454,42,0,'Petje in ritmično izreko ustvarjalno spremlja z gibalno-plesnim ljudskim izročilom.'),(1458,1458,43,0,'Samostojneje doživljajsko izraža glasbene vsebine.'),(1461,1461,43,0,'Z glasom in glasbili domiselno  oblikuje več vzorcev spremljav.'),(1465,1465,43,0,'Pri izmišljanju zvočnih vsebin pogosto uporablja več izraznih sredstev.'),(1469,1469,43,0,'Glasbena doživetja in predstave ustvarjalno izraža v različnih oblikah komunikacije.'),(1473,1473,44,0,'Aktivno posluša nov izbor načrtovanih vokalnih in inštrumentalnih skladb in jih prepoznava.'),(1477,1477,44,0,'Ob poslušanju samostojno prepoznava skladbe in razlikuje izrazna sredstva (obravnavane inštrumente, orkester, pevski glas, otroški zbor).'),(1481,1481,44,0,'Pozna in razlikuje zvoke in njihove lastnosti (glasnost, hitrost, barvo).'),(1484,1484,45,0,'Ima razvit melodični in ritmični posluh.'),(1488,1488,45,0,'Razširi obseg pevskega glasu in stopnjuje kakovost pevske izreke in pevskega dihanja.'),(1490,1490,45,0,'Pozna pravilno držo in razvija tehniko igranja glasbil.'),(1493,1493,45,0,'Razume in uporablja načrtovane glasbene pojme in razširi glasbeni besednjak.'),(1497,1497,45,0,'Samostojno se pravilno orientira v slikovnem glasbenem zapisu.'),(1501,1501,46,1,'Pozna besedila pesmi in jih ritmično ter melodično pravilno zapoje. '),(1505,1505,46,1,'Po barvi zvoka prepozna glasbila in jih poimenuje. Ritmično pravilno igra na glasbila in zahtevnejše ritmične vzorce. '),(1509,1509,46,1,'Ustvarjalno oblikuje ritmične spremljave. Ustvarjalno si izmišlja melodije na dano besedilo. '),(1513,1513,46,1,'Zbrano posluša načrtovan izbor skladb. '),(1517,1517,46,1,'Prepozna in loči izrazna sredstva. '),(1521,1521,46,1,'Ustvarjalno izraža glasbena doživetja v različnih oblikah komunikacije. '),(1525,1525,46,1,'Ima razvit melodični in ritmični posluh. '),(1529,1529,46,1,'Je osvojil tehniko petja in igranja glasbil. '),(1533,1533,46,1,'Pozna in smiselno uporablja glasbeni besednjak. '),(1537,1537,46,1,'Razume slikovni glasbeni zapis in mu sledi ob petju. '),(1658,1658,18,0,'Samostojno opiše podobnosti in razlike med ljudmi.'),(1661,1661,18,0,'Pravilno in samostojno se predstavi z osnovnimi osebnimi podatki.'),(1664,1664,18,0,'Prepozna in opiše različne čustvene izraze pri sebi in drugih.'),(1668,1668,19,0,'Zaveda se pomena sporazumevanja.'),(1671,1671,19,0,'Spoštuje in upošteva dogovor.'),(1676,1676,19,0,'Prepozna in opiše družinske skupnosti.'),(1680,1680,19,0,'Poimenuje razmerja med člani v družini (npr. brat, sestra, sin, hči, starši, stari starši).'),(1684,1684,20,0,'Predstavi osnovne podatke o svoji šoli in opiše delo, ki ga opravljajo zaposleni.'),(1688,1688,20,0,'Poimenuje različne prostore v šoli in pozna njihovo namembnost.'),(1691,1691,20,0,'V celoti upošteva osnovna šolska pravila.'),(1695,1695,21,0,'Pozna pomen praznovanja določenih dni (npr. rojstni dan, dan šole, dan državnosti) in jih opiše.'),(1699,1699,21,0,'Sodeluje pri pripravi praznovanj.'),(1701,1701,22,0,'Razlikuje med preteklostjo in sedanjostjo v svojem življenju.'),(1705,1705,22,0,'Poimenuje in uporabi osnovne časovne izraze.'),(1709,1709,22,0,'Prepoznava drugačnost življenja v preteklosti.'),(1712,1712,23,0,'Samostojno prepozna in opiše značilna okolja v bližnji okolici šole in doma.'),(1717,1717,23,0,'Samostojno prepozna in opiše spremembe v živi in neživi naravi.'),(1722,1722,23,0,'Samostojno poimenuje najpogostejše živali in rastline v bližnjem okolju.'),(1725,1725,23,0,'Samostojno poimenuje dele telesa živali in dele rastlin iz njihovega okolja.'),(1730,1730,23,0,'Ve, da živa bitja za svoje življenje potrebujejo prostor, zrak, vodo, svetlobo, primerno temperaturo in hrano.'),(1734,1734,23,0,'Žival, človeka in rastlino samostojno umesti v ustrezno življenjsko okolje.'),(1738,1738,24,0,'Zna poimenovati snovi in organizme, ki škodujejo zdravju.'),(1742,1742,24,0,'Zaveda se, da uživanje različne zdrave hrane, telesne vaje, počitek in redna nega pomagajo ohranjati zdravje in dobro počutje.'),(1744,1744,24,0,'Samostojno pripravi napitek in preprosto jed,'),(1747,1747,25,0,'Zna se orientirati v šoli in njeni okolici.'),(1751,1751,25,0,'Poimenuje osnovne geografske značilnosti in pojme o površju v neposredni okolici šole.'),(1754,1754,25,0,'S svojimi besedami opiše, kako ljudje vplivajo na naravo.'),(1758,1758,25,0,'Prepozna in opiše pomembne prometne znake za pešce in kolesarje v okolici šole.'),(1762,1762,25,0,'Opiše varno pot v šolo ter prometna pravila, ki veljajo za pešce.'),(1765,1765,26,0,'Snovi in telesa - opiše lastnosti teles in snovi in jih razvrsti glede na eno lastnost,'),(1769,1769,26,0,'Snovi in telesa - poimenuje in opiše lastnosti tekočin, jih preliva in našteje glagole, ki se uporabljajo pri dejavnostih s tekočinami,'),(1773,1773,26,0,'Snovi in telesa - prepozna različna gradiva, poimenuje orodja in jih uporabi pri izdelovanju izdelkov iz papirja, gline in naravnih materialov.'),(1777,1777,26,0,'Gibanje in sile - opiše in poimenuje lastno gibanje, gibanje živali in predmetov,'),(1782,1782,26,0,'Gibanje in sile - povezuje gibanje s sledovi gibanja,'),(1785,1785,26,0,'Gibanje in sile - sestavi in razstavi preprosto tehnično igračo ter razlikuje sestavne dele celote.'),(1789,1789,26,0,'Prenos informacij in urejanje podatkov - uredi potrebščine, igrače, orodja in delovni prostor po dogovorjenih merilih in po končanem delu pospravi prostor,'),(1793,1793,26,0,'Prenos informacij in urejanje podatkov - razlikuje različne načine prenosa podatkov (časopis, radio, televizija, internet).'),(1797,1797,26,0,'Prenos informacij in urejanje podatkov - našteje in prepozna pomembne telefonske številke.'),(1802,1802,26,0,'Vreme - opiše vremensko stanje in vremenske pojave,'),(1807,1807,26,0,'Vreme - opiše vpliv vremena na živali in na ljudi.'),(1810,1810,27,1,'Predstavi se z osnovnimi osebnimi podatki. '),(1811,1811,27,1,'Orientira se v svojem okolju. '),(1812,1812,27,1,'Ravna se po pravilih, ki veljajo za pešce v prometu.  '),(1813,1813,27,1,'Pozna različne oblike družin in sorodstvene odnose v ožji družini. '),(1814,1814,27,1,'Spoštljivo ravna do sebe in drugih. '),(1815,1815,27,1,'Opiše, kaj živa bitja potrebujejo za življenje. '),(1816,1816,27,1,'Pozna nekaj lastnosti teles in snovi, zna jih razvrstiti po dani lastnosti. '),(1817,1817,27,1,'Zna časovno opredeliti dogodke in pojave. '),(1818,1818,27,1,'Ve, da imajo nekateri dnevi v letu (prazniki) poseben pomen. '),(1819,1819,27,1,'Razume pomen zdravja za človeka in načine ohranjanja zdravja. '),(1820,1820,27,1,'Pozna in opiše vremenska stanja. '),(1855,1855,47,0,'Razlikuje in opiše nekaj medsebojnih odnosov med različnimi ljudmi (spoštovanje, skrb, prijaznost, sodelovanje, prijateljstvo).'),(1859,1859,47,0,'Samostojno pripoveduje o svojih dolžnostih.'),(1862,1862,47,0,'Prepoznava in opiše različnost med ljudmi  in se zaveda pomena strpnosti v povezavi z drugačnostjo.'),(1866,1866,48,0,'Samostojno našteje in opiše različne dejavnosti, ki poleg pouka potekajo v šoli.'),(1870,1870,48,0,'Opiše delo različnih delavcev na šoli (ravnatelja, učitelja, knjižničarja, tajnice, hišnika in drugih).'),(1873,1873,49,0,'Samostojno našteje in opiše nekaj praznikov, ki jih pozna.'),(1878,1878,49,0,'Samostojno navede nekaj ljudskih običajev.'),(1881,1881,50,0,'Opiše razvoj pripomočka, naprave ali orodja skozi čas.'),(1885,1885,50,0,'Zna uporabljati časovne izraze (dan, teden, mesec, leto).'),(1889,1889,51,0,'Samostojno navede nekaj sprememb v naravi, ki jih sam opazi.'),(1892,1892,51,0,'Pravilno povezuje živali z ustreznim okoljem.'),(1896,1896,51,0,'Za nekaj preprostih primerov pove, kako se razlikujejo potomci od staršev in v čem so si podobni; ve da se živali postarajo in poginejo.'),(1900,1900,51,0,'Samostojno našteje nekaj živali, katerih potomci so sprva zelo drugačni od staršev.'),(1904,1904,51,0,'Samostojno skrbi za rastline ali živali v učilnici ali na šoli in našteje, kaj potrebujejo rastline za rast.'),(1908,1908,51,0,'Pozna in navede nekaj primerov, kako razmnožujemo rastline (semena, čebulice, potaknjenci).'),(1912,1912,51,0,'Samostojno prepozna in poimenuje nekaj najpogostejših vrtnin ali poljščin v svoji okolici.'),(1916,1916,51,0,'Po navodilu samostojno pripravi preprosto jed.'),(1921,1921,51,0,'Pripoveduje svoje zamisli, zakaj se hranimo.'),(1923,1923,51,0,'Našteje nekaj čutil in primerov, kako nam čutila pomagajo pri različnih dejavnostih.'),(1927,1927,52,0,'Pozna in navede nekaj dejavnosti za zdravo življenje (nega telesa, gibanje).'),(1931,1931,52,0,'Sestavi in opiše nekaj obrokov, pri čemer upošteva raznovrstnost živil.'),(1935,1935,53,0,'Pozna in razloži, zakaj je pomembna vidnost v prometu, kdaj je slaba vidljivost.'),(1939,1939,53,0,'Prepozna in poimenuje nekatere geografske pojme v svoji okolici (hrib, gora, dolina, ravnina,…).'),(1943,1943,53,0,'Samostojno našteje nekaj posegov v okolje v svoji okolici.'),(1947,1947,53,0,'Samostojno naredi skico ali maketo opazovane pokrajine.'),(1950,1950,54,0,'Snovi in telesa - prepozna, poimenuje in našteje nekaj lastnosti snovi, iz katerih so različni izdelki,'),(1955,1955,54,0,'Snovi in telesa - loči preprosto zmes na sestavine, opiše, kako se spremenijo zmesi in njihove lastnosti,'),(1960,1960,54,0,'Snovi in telesa - zna spremeniti tekočo vodo v led in obratno, poimenuje nekaj oblik vode v trdnem stanju (sneg, ivje, led),'),(1964,1964,54,0,'Snovi in telesa - povezuje lastnosti gradiv (les, papir, žica) z ogrodji in načini obdelave,'),(1967,1967,54,0,'Snovi in telesa - ustrezno ravna z odpadki, opisuje, katere odpadke lahko ponovno uporabimo.'),(1971,1971,54,0,'Gibanje in sile - našteje nekaj vozil in pripomočkov za gibanje, opisuje, kaj vozila poganja, razlikuje med notranjim in zunanjim pogonom,'),(1975,1975,54,0,'Gibanje in sile - opisuje, kako se z različnimi vozili ustaviš (kolo, rolke, deska), kako se ustavijo gibajoči predmeti (kotaleča žoga),'),(1979,1979,54,0,'Gibanje in sile - naredi preprosto tehtnico in jo uravnovesi,'),(1983,1983,54,0,'Gibanje in sile - razlikuje med vrsto (vsebino) in trajanjem gibanja ali drugih pojavov,'),(1986,1986,54,0,'Zemlja in vesolje, prostor in čas - posnema navidezno gibanje sonca po nebu in ga povezuje z izrazi: zjutraj, dopoldan, popoldan, zvečer, noč, dan,'),(1990,1990,54,0,'Zemlja in vesolje, prostor in čas - opisuje razliko med dnevom in nočjo ter svoje dejavnosti v različnih časih dneva,'),(1994,1994,54,0,'Zemlja in vesolje, prostor in čas - poišče datum na koledarju, uporablja imena dni v tednu in izraze včeraj, danes, jutri,'),(1998,1998,54,0,'Zemlja in vesolje, prostor in čas - opazuje vreme in ga označuje z ustreznimi znaki,'),(2002,2002,54,0,'Zemlja in vesolje, prostor in čas - opisuje, kaj veter poganja ali premika,'),(2006,2006,54,0,'Zemlja in vesolje, prostor in čas - opisuje, kako pri različnih predmetih nastaja zvok,'),(2010,2010,54,0,'Zemlja in vesolje, prostor in čas - uporabi tabelo za vnos in branje podatkov,'),(2014,2014,54,0,'Zemlja in vesolje, prostor in čas - nariše pojav in preprost načrt izdelka.'),(2019,2019,55,0,'Pozna in razlikuje različna obdobja človekovega življenja in razume, da se vsako življenje enkrat začne in nekoč konča.'),(2024,2024,55,0,'Samostojno povezuje različne vrste zasvojenosti s posledicami neodgovornega ravnanja.'),(2028,2028,56,1,'Našteje in opiše različne dejavnosti, ki so na šoli in jih opiše. '),(2032,2032,56,1,'Prepoznava in opisuje odnose med ljudmi. Sprejema različnost. Sproščeno komunicira z različnimi sogovorci. '),(2036,2036,56,1,'Pojasni razliko med zdravim in nezdravim načinom življenja. Pridobiva navade zdravega življenja. '),(2040,2040,56,1,'Pozna značilnosti živih bitij in opiše življenjsko obdobje posameznih bitij. '),(2044,2044,56,1,'Sistematično in natančno opazuje pojave ter o njih smiselno postavlja vprašanja. '),(2048,2048,56,1,'Opisuje pojme in pojave v naravi in pri tem uporablja ustrezno besedišče. Pojme in pojave v naravi razume in jih medsebojno povezuje. '),(2052,2052,56,1,'Povezuje opažanja, prepoznava vzročne zveze, jih razume in uporabi. '),(2056,2056,56,1,'Pozna lastnosti snovi in izbere ustrezen način uporabe in obdelave ter samostojno praktično obdela snov. '),(2060,2060,56,1,'Gibanje natančno opiše. Poimenuje vzroke za gibanje in za ustavljanje vozil. Zna izbrati ustrezen pripomoček. '),(2064,2064,56,1,'Pozna, razume in pravilno uporablja časovne izraze. Znajde se na koledarju. '),(2068,2068,56,1,'Pravilno opiše in razloži nastajanje zvoka pri različnih predmetih. Prepozna zvoke različnih predmetov. '),(2072,2072,56,1,'Podatke zbere, uredi, jih primerja in ovrednoti. '),(2285,2285,28,0,'Sproščeno izvaja naravne oblike gibanja.'),(2289,2289,28,0,'Sproščeno izvaja naravne oblike gibanja.'),(2293,2293,28,0,'Pogosto izvaja enostavnejša gibanja ob glasbeni spremljavi.'),(2297,2297,28,0,'Pravilno ravna z različnimi športnimi pripomočki.'),(2301,2301,28,0,'Spretno obvladuje svoje telo v različnih položajih.'),(2304,2304,28,0,'Z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z žogo.'),(2306,2306,28,0,'Sproščeno zapleše preproste otroške plese.'),(2310,2310,28,0,'Prilagodi se na vodo do stopnje drsenja.'),(2313,2313,28,0,'Spozna  in izvaja gibalne dejavnosti na snegu in ledu.'),(2316,2316,28,0,'Pozna osnovne položaje telesa, rok in nog.'),(2319,2319,28,0,'Samostojno poimenuje različna športna orodja in pripomočke.'),(2323,2323,28,0,'Razume in upošteva preprosta pravila elementarnih in drugih iger.'),(2327,2327,28,0,'Pozna in uporablja primerna športna oblačila in obutev.'),(2330,2330,28,0,'Pozna in upošteva osnovna pravila varnosti v telovadnici, na igrišču in v bazenu.'),(2333,2333,29,1,'Upošteva pravila preprostih iger. '),(2334,2334,29,1,'Sproščeno in koordinirano teče na krajše razdalje iz visokega starta. '),(2335,2335,29,1,'Hodi in skače po ožji površini (klop). '),(2336,2336,29,1,'Meče žogico z mesta v cilj in daljino. '),(2337,2337,29,1,'Pozna rajalne igre, zapleše tri preproste otroške plese. '),(2338,2338,29,1,'Z eno roko vodi in podaja žogo. '),(2339,2339,29,1,'Je prilagojen/a na vodo in preplava 15 metrov. '),(2377,2377,57,0,'Sproščeno premaguje različne ovire in se koordinirano giblje.'),(2381,2381,57,0,'Sproščeno posnema predmete, živali, pojave in pojme v naravi.'),(2385,2385,57,0,'Sproščeno izvaja skladnejša gibanja ob glasbeni spremljavi.'),(2389,2389,57,0,'Poimenuje in pravilno ravna z različnimi športnimi pripomočki.'),(2393,2393,57,0,'Z igro in naravnimi oblikami gibanja se uči osnovnih elementov atletike, gimnastike in gibanj z različnimi žogami.'),(2399,2399,57,0,'V eni od tehnik preplava 25 metrov.'),(2403,2403,57,0,'Spozna prvine nekaterih zimskih športov.'),(2405,2405,57,0,'Pozna in pravilno izvaja različne položaje telesa.'),(2409,2409,57,0,'Pozna in poimenuje različne športne naprave, orodja in pripomočke.'),(2413,2413,57,0,'Razume in dosledno upošteva preprosta pravila elementarnih in drugih iger.'),(2417,2417,57,0,'Pozna, poimenuje in uporablja primerna športna oblačila in obutev.'),(2421,2421,57,0,'Pozna in redno upošteva osnovna pravila varnosti v telovadnici, na igrišču, v bazenu, na drsališču…'),(2425,2425,58,1,'Sproščeno premaguje različne ovire in se koordinirano giblje'),(2429,2429,58,1,'Poimenuje in pravilno ravna z različnimi športnimi pripomočki. '),(2433,2433,58,1,'Koordinirano in sproščeno teče, zna skakati s sonožnim in enonožnim odrivom. Natančno meče žogico v daljino in cilj. '),(2437,2437,58,1,'Pravilno izvaja osnovne gimnastične prvine (preval naprej). '),(2441,2441,58,1,'Spretno meče, podaja, lovi in vodi žogo ter z njo natančno zadeva različne cilje. '),(2445,2445,58,1,'Pozna otroške plese in jih sproščeno zapleše. '),(2449,2449,58,1,'Preplava 25 m v ustrezni tehniki. '),(2453,2453,58,1,'Pozna in pravilno izvaja različne položaje telesa, rok in nog. '),(2457,2457,58,1,'Poimenuje in uporablja primerna športna oblačila in obutev. '),(2461,2461,58,1,'Dosledno upošteva preprosta pravila elementarnih in drugih iger. '),(2462,618,8,1,'Bere podatke iz preglednic in prikazov. '),(2463,1821,27,1,'Ve, da moramo varovati naravno okolje, ve kako lahko sam prispeva k urejenemu videzu okolice in ve, kako je treba ustrezno ravnati z odpadki. '),(2464,152,3,1,'Govorno nastopi z vnaprej pripravljeno temo. Govori čimbolj zborno, razločno, naravno. ');

/*Table structure for table `tabosoc` */

DROP TABLE IF EXISTS `tabosoc`;

CREATE TABLE `tabosoc` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idKriterij` int(10) DEFAULT NULL,
  `utemeljitev` text,
  `leto` int(10) DEFAULT NULL,
  `mesec` int(10) DEFAULT NULL,
  `ocena` double DEFAULT NULL,
  `idDelavca` int(10) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `ocenil` varchar(50) DEFAULT NULL,
  `casvpisa` varchar(50) DEFAULT NULL,
  `casocene` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idDelavca` (`idDelavca`),
  KEY `idKriterij` (`idKriterij`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabosoc` */

/*Table structure for table `tabostaledej` */

DROP TABLE IF EXISTS `tabostaledej`;

CREATE TABLE `tabostaledej` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `IdAktivnost` int(10) DEFAULT NULL,
  `Trajanje` varchar(50) DEFAULT NULL,
  `Datum` varchar(50) DEFAULT NULL,
  `Kraj` varchar(100) DEFAULT NULL,
  `Vsebina` varchar(250) DEFAULT NULL,
  `Vodja` varchar(250) DEFAULT NULL,
  `Udelezenci` text,
  `Spremljevalci` varchar(250) DEFAULT NULL,
  `Subvencija` text,
  `idRazred` int(10) DEFAULT NULL,
  `Neopraviceno` text,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdAktivnost` (`IdAktivnost`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabostaledej` */

/*Table structure for table `tabplavanje` */

DROP TABLE IF EXISTS `tabplavanje`;

CREATE TABLE `tabplavanje` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `stopnja` int(10) DEFAULT NULL,
  `komentar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabplavanje` */

/*Table structure for table `tabpogodbe` */

DROP TABLE IF EXISTS `tabpogodbe`;

CREATE TABLE `tabpogodbe` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdUcitelj` int(10) DEFAULT NULL,
  `IzobUstr` int(10) DEFAULT NULL,
  `IdDelo` int(10) DEFAULT NULL,
  `DelovniCas` int(10) DEFAULT NULL,
  `IdVzgojnoDelo` int(10) DEFAULT NULL,
  `Koef` double DEFAULT NULL,
  `DatumStart` varchar(15) DEFAULT NULL,
  `DatumEnd` varchar(15) DEFAULT NULL,
  `DopDelo` bit(1) NOT NULL,
  `Delodaj1` varchar(50) DEFAULT NULL,
  `Delodaj1mat` varchar(50) DEFAULT NULL,
  `Delodaj1naslov` varchar(100) DEFAULT NULL,
  `Delodaj2` varchar(50) DEFAULT NULL,
  `Delodaj2mat` varchar(50) DEFAULT NULL,
  `Delodaj2naslov` varchar(100) DEFAULT NULL,
  `Delodaj3` varchar(50) DEFAULT NULL,
  `Delodaj3mat` varchar(50) DEFAULT NULL,
  `Delodaj3naslov` varchar(100) DEFAULT NULL,
  `DatumPogodbe` varchar(50) DEFAULT NULL,
  `PolniDelCas` varchar(50) DEFAULT NULL,
  `RazlogDolCas` varchar(200) DEFAULT NULL,
  `PotrStrokUsp` varchar(100) DEFAULT NULL,
  `NazivDelMesta` varchar(250) DEFAULT NULL,
  `UrTeden` varchar(50) DEFAULT NULL,
  `Izmensko` bit(1) NOT NULL,
  `KrajDela` varchar(250) DEFAULT NULL,
  `KonkKlavz` bit(1) NOT NULL,
  `NacinPrenehanja` varchar(100) DEFAULT NULL,
  `Sistemizacija` varchar(255) DEFAULT NULL,
  `StPogodbe` varchar(255) DEFAULT NULL,
  `Obremen1` double DEFAULT NULL,
  `Obremen2` double DEFAULT NULL,
  `Obremen3` double DEFAULT NULL,
  `Obremen4` double DEFAULT NULL,
  `Obremen5` double DEFAULT NULL,
  `VpisM1` varchar(50) DEFAULT NULL,
  `IzpisM1` varchar(50) DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `cas` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `Opombe` text,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdVzgojnoDelo` (`IdVzgojnoDelo`),
  KEY `TabUciteljiIdDelo` (`IdDelo`),
  KEY `TabUciteljiIdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpogodbe` */

/*Table structure for table `tabporocilotip` */

DROP TABLE IF EXISTS `tabporocilotip`;

CREATE TABLE `tabporocilotip` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tip` varchar(100) DEFAULT NULL,
  `povezava` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

/*Data for the table `tabporocilotip` */

insert  into `tabporocilotip`(`id`,`tip`,`povezava`) values (1,'Pedagoško poročilo','PedPorocilo.php'),(2,'Vnos učencev za ISP, DSP, DOD, DOP','izborrazreda.php?id=dodpouk'),(3,'Vnos učencev za OPB','izborrazreda.php?id=opb'),(4,'Vnos prehrane učencev','izborrazreda.php?id=prehrana'),(5,'Vnos soglasij staršev','izborrazreda.php?id=izjave'),(6,'Prijave na NPZ - 6. razred','izborrazreda.php?id=prijavanpz'),(7,'Šola v naravi/Tabori','izborrazreda.php?id=tabor'),(8,'Vpis statusov, napredovanja, popravnih izpitov','izborrazreda.php?id=uspeh'),(9,'Vnos odsotnosti','izborrazreda.php?id=odsotnost'),(10,'Sodelovanje s starši','izborrazreda.php?id=govorilne'),(11,'Vnos izobraževanja','VnosIzobrazevanje.php'),(12,'Letno poročilo aktiva','IzborAktiviPorocilo.php?id=1a'),(13,'Program aktiva za naslednje šolsko leto','IzborAktiviPorocilo.php?id=1b'),(14,'Realizacija','IzborRealizacijeInd.php'),(15,'Vnos datumov pisnih ocenjevanj znanja','prijava.php'),(16,'Poročilo o interesni dejavnosti','tekmovanjakrozki.php?id=201'),(17,'Vnos rezultatov tekmovanj iz znanja','tekmovanjakrozki.php?id=101'),(18,'Vnos rezultatov šolskih športnih tekmovanj','tekmovanjakrozki.php?id=301'),(19,'Vnos dnevov dejavnosti','izborrazreda.php?id=dejavnosti'),(20,'Vnos mesečnega pregleda dela','IzborUcitelja.php'),(21,'Vnos redne delovne uspešnosti','prijava.php'),(22,'Vnos vzgojnih ukrepov','izborucenca.php?id=3'),(23,NULL,NULL);

/*Table structure for table `tabposdnevi` */

DROP TABLE IF EXISTS `tabposdnevi`;

CREATE TABLE `tabposdnevi` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(3) DEFAULT NULL,
  `IdDejavnost` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdDejavnost` (`IdDejavnost`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabposdnevi` */

/*Table structure for table `tabposebnepotrebe` */

DROP TABLE IF EXISTS `tabposebnepotrebe`;

CREATE TABLE `tabposebnepotrebe` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdPosebnePotrebe` int(10) DEFAULT NULL,
  `OpisPosebnePotrebe` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdPosebnePotrebe` (`IdPosebnePotrebe`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `tabposebnepotrebe` */

insert  into `tabposebnepotrebe`(`Id`,`IdPosebnePotrebe`,`OpisPosebnePotrebe`) values (1,1,'Nima posebnih potreb'),(2,2,'Slepi in slabovidni'),(3,3,'Gluhi in naglušni'),(4,4,'Otroci z govorno-jezikovnimi motnjami'),(5,5,'Otroci z vedenjskimi in osebnostnimi motnjami'),(6,6,'Gibalno ovirani otroci'),(7,7,'Dolgotrajno bolni otroci'),(8,8,'Otroci s primanjkljaji na posameznih področjih učenja'),(9,9,'Otroci z mejnimi intelektualnimi sposobnostmi'),(10,10,'Otroci z lažjimi motnjami v duševnem razvoju');

/*Table structure for table `tabpotninalog` */

DROP TABLE IF EXISTS `tabpotninalog`;

CREATE TABLE `tabpotninalog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `ZapSt` int(10) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `DanOdhoda` date DEFAULT NULL,
  `UraOdhoda` varchar(50) DEFAULT NULL,
  `Odlocba` varchar(50) DEFAULT NULL,
  `Kam` varchar(50) DEFAULT NULL,
  `Naloga` varchar(50) DEFAULT NULL,
  `DanPrihoda` date DEFAULT NULL,
  `Dni` int(10) DEFAULT NULL,
  `PrevSredstvo` varchar(50) DEFAULT NULL,
  `Placnik` varchar(50) DEFAULT NULL,
  `Dnevnica` double DEFAULT NULL,
  `Dodatki` double DEFAULT NULL,
  `Predujem` double DEFAULT NULL,
  `Odredbodajalec` varchar(50) DEFAULT NULL,
  `DanOdhodaObr` date DEFAULT NULL,
  `DanPrihodaObr` date DEFAULT NULL,
  `UraOdhodaObr` time DEFAULT NULL,
  `UraPrihodaObr` time DEFAULT NULL,
  `DniObr` int(10) DEFAULT NULL,
  `UrObr` int(10) DEFAULT NULL,
  `MinObr` int(10) DEFAULT NULL,
  `Dnevnic` int(10) DEFAULT NULL,
  `ProcentZnizanja` double DEFAULT NULL,
  `ZnizanjeOd` double DEFAULT NULL,
  `PrevStroskiTxt1` varchar(50) DEFAULT NULL,
  `PrevStroski1` double DEFAULT NULL,
  `PrevStroskiTxt2` varchar(50) DEFAULT NULL,
  `PrevStroski2` double DEFAULT NULL,
  `PrevStroskiTxt3` varchar(50) DEFAULT NULL,
  `PrevStroski3` double DEFAULT NULL,
  `PrevStroskiTxt4` varchar(50) DEFAULT NULL,
  `PrevStroski4` double DEFAULT NULL,
  `DrugiStroskiTxt1` varchar(50) DEFAULT NULL,
  `DrugiStroski1` double DEFAULT NULL,
  `DrugiStroskiTxt2` varchar(50) DEFAULT NULL,
  `DrugiStroski2` double DEFAULT NULL,
  `Priloge` varchar(50) DEFAULT NULL,
  `OdobrenoIzpl` double DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpotninalog` */

/*Table structure for table `tabpotrdila` */

DROP TABLE IF EXISTS `tabpotrdila`;

CREATE TABLE `tabpotrdila` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `priznanje` varchar(100) DEFAULT NULL,
  `PozXSola` int(10) DEFAULT NULL,
  `PozYSola` int(10) DEFAULT NULL,
  `PozXNaslov` int(10) DEFAULT NULL,
  `PozYNaslov` int(10) DEFAULT NULL,
  `PozXRavnatelj` int(10) DEFAULT NULL,
  `PozYRavnatelj` int(10) DEFAULT NULL,
  `PozXKraj` int(10) DEFAULT NULL,
  `PozYkraj` int(10) DEFAULT NULL,
  `PozXIzvajalec` int(10) DEFAULT NULL,
  `PozYIzvajalec` int(10) DEFAULT NULL,
  `PozXPriznanje` int(10) DEFAULT NULL,
  `PozYpriznanje` int(10) DEFAULT NULL,
  `PozXLine1` int(10) DEFAULT NULL,
  `PozYLine1` int(10) DEFAULT NULL,
  `PozXLine2` int(10) DEFAULT NULL,
  `PozYLine2` int(10) DEFAULT NULL,
  `PozXLine3` int(10) DEFAULT NULL,
  `PozYLine3` int(10) DEFAULT NULL,
  `PozXLine4` int(10) DEFAULT NULL,
  `PozYLine4` int(10) DEFAULT NULL,
  `PozXLine5` int(10) DEFAULT NULL,
  `PozYLine5` int(10) DEFAULT NULL,
  `PozXLine6` int(10) DEFAULT NULL,
  `PozYLine6` int(10) DEFAULT NULL,
  `PozXLine7` int(10) DEFAULT NULL,
  `PozYLine7` int(10) DEFAULT NULL,
  `PozXVsebina` int(10) DEFAULT NULL,
  `PozYVsebina` int(10) DEFAULT NULL,
  `PozXDatum` int(10) DEFAULT NULL,
  `PozYDatum` int(10) DEFAULT NULL,
  `PozXLogo` int(10) DEFAULT NULL,
  `PozYLogo` int(10) DEFAULT NULL,
  `PozXIme` int(10) DEFAULT NULL,
  `PozYIme` int(10) DEFAULT NULL,
  `PozX1Crta1` int(10) DEFAULT NULL,
  `PozY1Crta1` int(10) DEFAULT NULL,
  `PozX2Crta1` int(10) DEFAULT NULL,
  `PozY2Crta1` int(10) DEFAULT NULL,
  `PozX1Crta2` int(10) DEFAULT NULL,
  `PozY1Crta2` int(10) DEFAULT NULL,
  `PozX2Crta2` int(10) DEFAULT NULL,
  `PozY2Crta2` int(10) DEFAULT NULL,
  `PozX1Crta3` int(10) DEFAULT NULL,
  `PozY1Crta3` int(10) DEFAULT NULL,
  `PozX2Crta3` int(10) DEFAULT NULL,
  `PozY2Crta3` int(10) DEFAULT NULL,
  `LogoSize` int(10) DEFAULT NULL,
  `PorSola` int(10) DEFAULT NULL,
  `PorRavnatelj` int(10) DEFAULT NULL,
  `PorPriznanje` int(10) DEFAULT NULL,
  `PorLine1` int(10) DEFAULT NULL,
  `PorLine2` int(10) DEFAULT NULL,
  `PorLine3` int(10) DEFAULT NULL,
  `PorLine4` int(10) DEFAULT NULL,
  `PorLine5` int(10) DEFAULT NULL,
  `PorLine6` int(10) DEFAULT NULL,
  `PorLine7` int(10) DEFAULT NULL,
  `PorVsebina` int(10) DEFAULT NULL,
  `PorDatum` int(10) DEFAULT NULL,
  `PorIme` int(10) DEFAULT NULL,
  `PorNaslov` int(10) DEFAULT NULL,
  `PorKraj` int(10) DEFAULT NULL,
  `PorIzvajalec` int(10) DEFAULT NULL,
  `FSSola` int(10) DEFAULT NULL,
  `FSRavnatelj` int(10) DEFAULT NULL,
  `FSPriznanje` int(10) DEFAULT NULL,
  `FSLine1` int(10) DEFAULT NULL,
  `FSLine2` int(10) DEFAULT NULL,
  `FSLine3` int(10) DEFAULT NULL,
  `FSLine4` int(10) DEFAULT NULL,
  `FSLine5` int(10) DEFAULT NULL,
  `FSLine6` int(10) DEFAULT NULL,
  `FSLine7` int(10) DEFAULT NULL,
  `FSVsebina` int(10) DEFAULT NULL,
  `FSDatum` int(10) DEFAULT NULL,
  `FSIme` int(10) DEFAULT NULL,
  `FSNaslov` int(10) DEFAULT NULL,
  `FSKraj` int(10) DEFAULT NULL,
  `FSIzvajalec` int(10) DEFAULT NULL,
  `Font` varchar(20) DEFAULT NULL,
  `sola` varchar(100) DEFAULT NULL,
  `naslov` varchar(100) DEFAULT NULL,
  `diploma` varchar(100) DEFAULT NULL,
  `line1` varchar(100) DEFAULT NULL,
  `line2` varchar(100) DEFAULT NULL,
  `line3` varchar(100) DEFAULT NULL,
  `line4` varchar(100) DEFAULT NULL,
  `line5` varchar(100) DEFAULT NULL,
  `line6` varchar(100) DEFAULT NULL,
  `line7` varchar(100) DEFAULT NULL,
  `vsebina` varchar(100) DEFAULT NULL,
  `kraj` varchar(100) DEFAULT NULL,
  `izvajalec` varchar(50) DEFAULT NULL,
  `ravnatelj` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpotrdila` */

/*Table structure for table `tabpozvarnost` */

DROP TABLE IF EXISTS `tabpozvarnost`;

CREATE TABLE `tabpozvarnost` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpozvarnost` */

/*Table structure for table `tabpraksa` */

DROP TABLE IF EXISTS `tabpraksa`;

CREATE TABLE `tabpraksa` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Mentor` int(10) DEFAULT NULL,
  `Praksa` varchar(250) DEFAULT NULL,
  `Predmeti` text,
  `studentov` int(10) DEFAULT NULL,
  `ustanova` varchar(255) DEFAULT NULL,
  `hospitacije` text,
  `nastopi` text,
  `drugo` text,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpraksa` */

/*Table structure for table `tabpraznik` */

DROP TABLE IF EXISTS `tabpraznik`;

CREATE TABLE `tabpraznik` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datum` timestamp NULL DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `mesec` int(10) DEFAULT NULL,
  `dan` int(10) DEFAULT NULL,
  `opis` varchar(50) DEFAULT NULL,
  `kat` int(10) DEFAULT NULL,
  `trajanje` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8;

/*Data for the table `tabpraznik` */

insert  into `tabpraznik`(`id`,`datum`,`leto`,`mesec`,`dan`,`opis`,`kat`,`trajanje`) values (1,'2008-01-01 00:00:00',2008,1,1,'Novo leto',0,0),(2,'2008-01-02 00:00:00',2008,1,2,'Novo leto',0,0),(3,'2008-02-08 00:00:00',2008,2,8,'Slovenski kulturni praznik',0,0),(4,'2008-02-18 00:00:00',2008,2,18,'zimske počitnice',1,0),(5,'2008-02-19 00:00:00',2008,2,19,'zimske počitnice',1,0),(6,'2008-02-20 00:00:00',2008,2,20,'zimske počitnice',1,0),(7,'2008-02-21 00:00:00',2008,2,21,'zimske počitnice',1,0),(8,'2008-02-22 00:00:00',2008,2,22,'zimske počitnice',1,0),(9,'2008-03-24 00:00:00',2008,3,24,'Velikonočni ponedeljek',0,0),(10,'2008-04-27 00:00:00',2008,4,27,'Dan upora proti okupatorju',0,0),(11,'2008-04-28 00:00:00',2008,4,28,'prvomajske počitnice',1,0),(12,'2008-04-29 00:00:00',2008,4,29,'prvomajske počitnice',1,0),(13,'2008-04-30 00:00:00',2008,4,30,'prvomajske počitnice',1,0),(14,'2008-05-01 00:00:00',2008,5,1,'Praznik dela',0,0),(15,'2008-05-02 00:00:00',2008,5,2,'Praznik dela',0,0),(16,'2008-06-25 00:00:00',2008,6,25,'Dan državnosti',0,0),(17,'2008-07-07 00:00:00',2008,7,7,'poletne počitnice',1,0),(18,'2008-07-08 00:00:00',2008,7,8,'poletne počitnice',1,0),(19,'2008-07-09 00:00:00',2008,7,9,'poletne počitnice',1,0),(20,'2008-07-10 00:00:00',2008,7,10,'poletne počitnice',1,0),(21,'2008-07-11 00:00:00',2008,7,11,'poletne počitnice',1,0),(22,'2008-07-14 00:00:00',2008,7,14,'poletne počitnice',1,0),(23,'2008-07-15 00:00:00',2008,7,15,'poletne počitnice',1,0),(24,'2008-07-16 00:00:00',2008,7,16,'poletne počitnice',1,0),(25,'2008-07-17 00:00:00',2008,7,17,'poletne počitnice',1,0),(26,'2008-07-18 00:00:00',2008,7,18,'poletne počitnice',1,0),(27,'2008-07-21 00:00:00',2008,7,21,'poletne počitnice',1,0),(28,'2008-07-22 00:00:00',2008,7,22,'poletne počitnice',1,0),(29,'2008-07-23 00:00:00',2008,7,23,'poletne počitnice',1,0),(30,'2008-07-24 00:00:00',2008,7,24,'poletne počitnice',1,0),(31,'2008-07-25 00:00:00',2008,7,25,'poletne počitnice',1,0),(32,'2008-07-28 00:00:00',2008,7,28,'poletne počitnice',1,0),(33,'2008-07-29 00:00:00',2008,7,29,'poletne počitnice',1,0),(34,'2008-07-30 00:00:00',2008,7,30,'poletne počitnice',1,0),(35,'2008-07-31 00:00:00',2008,7,31,'poletne počitnice',1,0),(36,'2008-08-01 00:00:00',2008,8,1,'poletne počitnice',1,0),(37,'2008-08-04 00:00:00',2008,8,4,'poletne počitnice',1,0),(38,'2008-08-05 00:00:00',2008,8,5,'poletne počitnice',1,0),(39,'2008-08-06 00:00:00',2008,8,6,'poletne počitnice',1,0),(40,'2008-08-07 00:00:00',2008,8,7,'poletne počitnice',1,0),(41,'2008-08-08 00:00:00',2008,8,8,'poletne počitnice',1,0),(42,'2008-08-11 00:00:00',2008,8,11,'poletne počitnice',1,0),(43,'2008-08-12 00:00:00',2008,8,12,'poletne počitnice',1,0),(44,'2008-08-13 00:00:00',2008,8,13,'poletne počitnice',1,0),(45,'2008-08-14 00:00:00',2008,8,14,'poletne počitnice',1,0),(46,'2008-08-15 00:00:00',2008,8,15,'Marijino nebovzetje',0,0),(47,'2008-08-18 00:00:00',2008,8,18,'poletne počitnice',1,0),(48,'2008-08-19 00:00:00',2008,8,19,'poletne počitnice',1,0),(49,'2008-08-20 00:00:00',2008,8,20,'poletne počitnice',1,0),(50,'2008-08-21 00:00:00',2008,8,21,'poletne počitnice',1,0),(52,'2008-10-27 00:00:00',2008,10,27,'jesenske počitnice',1,0),(53,'2008-10-28 00:00:00',2008,10,28,'jesenske počitnice',1,0),(54,'2008-10-29 00:00:00',2008,10,29,'jesenske počitnice',1,0),(55,'2008-10-30 00:00:00',2008,10,30,'jesenske počitnice',1,0),(56,'2008-10-31 00:00:00',2008,10,31,'Dan reformacije',0,0),(57,'2008-11-01 00:00:00',2008,11,1,'Dan spomina na mrtve',0,0),(58,'2008-12-25 00:00:00',2008,12,25,'Božič',0,0),(59,'2008-12-26 00:00:00',2008,12,26,'Dan samostojnosti in enotnosti',0,0),(60,'2008-12-29 00:00:00',2008,12,29,'novoletne počitnice',1,0),(61,'2008-12-30 00:00:00',2008,12,30,'novoletne počitnice',1,0),(62,'2008-12-31 00:00:00',2008,12,31,'novoletne počitnice',1,0),(63,'2009-01-01 00:00:00',2009,1,1,'Novo leto',0,0),(64,'2009-01-02 00:00:00',2009,1,2,'Novo leto',0,0),(65,'2009-02-08 00:00:00',2009,2,8,'Slovenski kulturni praznik',0,0),(66,'2009-02-23 00:00:00',2009,2,23,'zimske počitnice',1,0),(67,'2009-02-24 00:00:00',2009,2,24,'zimske počitnice',1,0),(68,'2009-02-25 00:00:00',2009,2,25,'zimske počitnice',1,0),(69,'2009-02-26 00:00:00',2009,2,26,'zimske počitnice',1,0),(70,'2009-02-27 00:00:00',2009,2,27,'zimske počitnice',1,0),(71,'2009-04-13 00:00:00',2009,4,13,'Velikonočni ponedeljek',0,0),(72,'2009-04-27 00:00:00',2009,4,27,'Dan upora proti okupatorju',0,0),(73,'2009-04-28 00:00:00',2009,4,28,'prvomajske počitnice',1,0),(74,'2009-04-29 00:00:00',2009,4,29,'prvomajske počitnice',1,0),(75,'2009-04-30 00:00:00',2009,4,30,'prvomajske počitnice',1,0),(76,'2009-05-01 00:00:00',2009,5,1,'Praznik dela',0,0),(77,'2009-05-02 00:00:00',2009,5,2,'Praznik dela',0,0),(78,'2009-06-25 00:00:00',2009,6,25,'Dan državnosti',0,0),(79,'2009-07-06 00:00:00',2009,7,6,'poletne počitnice',1,0),(80,'2009-07-07 00:00:00',2009,7,7,'poletne počitnice',1,0),(81,'2009-07-08 00:00:00',2009,7,8,'poletne počitnice',1,0),(82,'2009-07-09 00:00:00',2009,7,9,'poletne počitnice',1,0),(83,'2009-07-10 00:00:00',2009,7,10,'poletne počitnice',1,0),(84,'2009-07-13 00:00:00',2009,7,13,'poletne počitnice',1,0),(85,'2009-07-14 00:00:00',2009,7,14,'poletne počitnice',1,0),(86,'2009-07-15 00:00:00',2009,7,15,'poletne počitnice',1,0),(87,'2009-07-16 00:00:00',2009,7,16,'poletne počitnice',1,0),(88,'2009-07-17 00:00:00',2009,7,17,'poletne počitnice',1,0),(89,'2009-07-20 00:00:00',2009,7,20,'poletne počitnice',1,0),(90,'2009-07-21 00:00:00',2009,7,21,'poletne počitnice',1,0),(91,'2009-07-22 00:00:00',2009,7,22,'poletne počitnice',1,0),(92,'2009-07-23 00:00:00',2009,7,23,'poletne počitnice',1,0),(93,'2009-07-24 00:00:00',2009,7,24,'poletne počitnice',1,0),(95,'2009-07-28 00:00:00',2009,7,28,'poletne počitnice',1,0),(96,'2009-07-29 00:00:00',2009,7,29,'poletne počitnice',1,0),(97,'2009-07-30 00:00:00',2009,7,30,'poletne počitnice',1,0),(98,'2009-07-31 00:00:00',2009,7,31,'poletne počitnice',1,0),(99,'2009-08-03 00:00:00',2009,8,3,'poletne počitnice',1,0),(100,'2009-08-04 00:00:00',2009,8,4,'poletne počitnice',1,0),(101,'2009-08-05 00:00:00',2009,8,5,'poletne počitnice',1,0),(102,'2009-08-06 00:00:00',2009,8,6,'poletne počitnice',1,0),(103,'2009-08-07 00:00:00',2009,8,7,'poletne počitnice',1,0),(104,'2009-08-10 00:00:00',2009,8,10,'poletne počitnice',1,0),(105,'2009-08-11 00:00:00',2009,8,11,'poletne počitnice',1,0),(106,'2009-08-12 00:00:00',2009,8,12,'poletne počitnice',1,0),(107,'2009-08-13 00:00:00',2009,8,13,'poletne počitnice',1,0),(108,'2009-08-15 00:00:00',2009,8,15,'Marijino nebovzetje',0,0),(109,'2009-08-14 00:00:00',2009,8,14,'poletne počitnice',1,0),(110,'2009-08-18 00:00:00',2009,8,18,'poletne počitnice',1,0),(111,'2009-08-19 00:00:00',2009,8,19,'poletne počitnice',1,0),(112,'2009-08-20 00:00:00',2009,8,20,'poletne počitnice',1,0),(113,'2009-08-21 00:00:00',2009,8,21,'poletne počitnice',1,0),(114,'2009-10-26 00:00:00',2009,10,26,'jesenske počitnice',1,0),(115,'2009-10-27 00:00:00',2009,10,27,'jesenske počitnice',1,0),(116,'2009-10-28 00:00:00',2009,10,28,'jesenske počitnice',1,0),(117,'2009-10-29 00:00:00',2009,10,29,'jesenske počitnice',1,0),(118,'2009-10-31 00:00:00',2009,10,31,'Dan reformacije',0,0),(119,'2009-11-01 00:00:00',2009,11,1,'Dan spomina na mrtve',0,0),(120,'2009-12-25 00:00:00',2009,12,25,'Božič',0,0),(121,'2009-12-26 00:00:00',2009,12,26,'Dan samostojnosti in enotnosti',0,0),(122,'2009-12-28 00:00:00',2009,12,28,'novoletne počitnice',1,0),(123,'2009-12-29 00:00:00',2009,12,29,'novoletne počitnice',1,0),(124,'2009-12-30 00:00:00',2009,12,30,'novoletne počitnice',1,0),(125,'2010-01-01 00:00:00',2010,1,1,'Novo leto',0,0),(126,'2010-01-02 00:00:00',2010,1,2,'Novo leto',0,0),(127,'2010-02-08 00:00:00',2010,2,8,'Slovenski kulturni praznik',0,0),(128,'2010-02-15 00:00:00',2010,2,15,'zimske počitnice',1,0),(129,'2010-02-16 00:00:00',2010,2,16,'zimske počitnice',1,0),(130,'2010-02-17 00:00:00',2010,2,17,'zimske počitnice',1,0),(131,'2010-02-18 00:00:00',2010,2,18,'zimske počitnice',1,0),(132,'2010-02-19 00:00:00',2010,2,19,'zimske počitnice',1,0),(133,'2010-04-05 00:00:00',2010,4,5,'Velikonočni ponedeljek',0,0),(134,'2010-04-27 00:00:00',2010,4,27,'Dan upora proti okupatorju',0,0),(135,'2010-04-28 00:00:00',2010,4,28,'prvomajske počitnice',1,0),(136,'2010-04-29 00:00:00',2010,4,29,'prvomajske počitnice',1,0),(137,'2010-04-30 00:00:00',2010,4,30,'prvomajske počitnice',1,0),(138,'2010-05-01 00:00:00',2010,5,1,'Praznik dela',0,0),(139,'2010-05-02 00:00:00',2010,5,2,'Praznik dela',0,0),(140,'2010-06-25 00:00:00',2010,6,25,'Dan državnosti',0,0),(141,'2010-07-05 00:00:00',2010,7,5,'poletne počitnice',1,0),(142,'2010-07-06 00:00:00',2010,7,6,'poletne počitnice',1,0),(143,'2010-07-07 00:00:00',2010,7,7,'poletne počitnice',1,0),(144,'2010-07-08 00:00:00',2010,7,8,'poletne počitnice',1,0),(145,'2010-07-09 00:00:00',2010,7,9,'poletne počitnice',1,0),(147,'2010-07-12 00:00:00',2010,7,12,'poletne počitnice',1,0),(148,'2010-07-13 00:00:00',2010,7,13,'poletne počitnice',1,0),(149,'2010-07-14 00:00:00',2010,7,14,'poletne počitnice',1,0),(150,'2010-07-15 00:00:00',2010,7,15,'poletne počitnice',1,0),(151,'2010-07-19 00:00:00',2010,7,19,'poletne počitnice',1,0),(152,'2010-07-20 00:00:00',2010,7,20,'poletne počitnice',1,0),(153,'2010-07-21 00:00:00',2010,7,21,'poletne počitnice',1,0),(154,'2010-07-22 00:00:00',2010,7,22,'poletne počitnice',1,0),(155,'2010-07-23 00:00:00',2010,7,23,'poletne počitnice',1,0),(156,'2010-07-26 00:00:00',2010,7,26,'poletne počitnice',1,0),(157,'2010-07-27 00:00:00',2010,7,27,'poletne počitnice',1,0),(158,'2010-07-28 00:00:00',2010,7,28,'poletne počitnice',1,0),(159,'2010-07-29 00:00:00',2010,7,29,'poletne počitnice',1,0),(160,'2010-07-30 00:00:00',2010,7,30,'poletne počitnice',1,0),(161,'2010-08-02 00:00:00',2010,8,2,'poletne počitnice',1,0),(162,'2010-08-03 00:00:00',2010,8,3,'poletne počitnice',1,0),(163,'2010-08-04 00:00:00',2010,8,4,'poletne počitnice',1,0),(164,'2010-08-05 00:00:00',2010,8,5,'poletne počitnice',1,0),(165,'2010-08-09 00:00:00',2010,8,9,'poletne počitnice',1,0),(166,'2010-08-10 00:00:00',2010,8,10,'poletne počitnice',1,0),(167,'2010-08-11 00:00:00',2010,8,11,'poletne počitnice',1,0),(168,'2010-08-12 00:00:00',2010,8,12,'poletne počitnice',1,0),(169,'2010-08-13 00:00:00',2010,8,13,'poletne počitnice',1,0),(170,'2010-08-15 00:00:00',2010,8,15,'Marijino nebovzetje',0,0),(171,'2010-08-16 00:00:00',2010,8,16,'poletne počitnice',1,0),(172,'2010-08-17 00:00:00',2010,8,17,'poletne počitnice',1,0),(173,'2010-08-18 00:00:00',2010,8,18,'poletne počitnice',1,0),(174,'2010-08-19 00:00:00',2010,8,19,'poletne počitnice',1,0),(175,'2010-08-20 00:00:00',2010,8,20,'poletne počitnice',1,0),(177,'2010-10-25 00:00:00',2010,10,25,'jesenske počitnice',1,0),(178,'2010-10-26 00:00:00',2010,10,26,'jesenske počitnice',1,0),(179,'2010-10-27 00:00:00',2010,10,27,'jesenske počitnice',1,0),(180,'2010-10-28 00:00:00',2010,10,28,'jesenske počitnice',1,0),(181,'2010-10-31 00:00:00',2010,10,31,'Dan reformacije',0,0),(182,'2010-11-01 00:00:00',2010,11,1,'Dan spomina na mrtve',0,0),(183,'2010-12-25 00:00:00',2010,12,25,'Božič',0,0),(184,'2010-12-26 00:00:00',2010,12,26,'Dan samostojnosti in enotnosti',0,0),(185,'2010-12-27 00:00:00',2010,12,27,'novoletne počitnice',1,0),(186,'2010-12-28 00:00:00',2010,12,28,'novoletne počitnice',1,0),(187,'2010-12-29 00:00:00',2010,12,29,'novoletne počitnice',1,0),(188,'2011-01-01 00:00:00',2011,1,1,'Novo leto',0,0),(189,'2011-01-02 00:00:00',2011,1,2,'Novo leto',0,0),(190,'2011-02-08 00:00:00',2011,2,8,'Slovenski kulturni praznik',0,0),(191,'2011-02-21 00:00:00',2011,2,21,'zimske počitnice',1,0),(192,'2011-02-22 00:00:00',2011,2,22,'zimske počitnice',1,0),(193,'2011-02-23 00:00:00',2011,2,23,'zimske počitnice',1,0),(194,'2011-02-24 00:00:00',2011,2,24,'zimske počitnice',1,0),(195,'2011-02-25 00:00:00',2011,2,25,'zimske počitnice',1,0),(196,'2011-04-25 00:00:00',2011,4,25,'Velikonočni ponedeljek',0,0),(197,'2011-04-27 00:00:00',2011,4,27,'Dan upora proti okupatorju',0,0),(198,'2011-04-28 00:00:00',2011,4,28,'prvomajske počitnice',1,0),(199,'2011-04-29 00:00:00',2011,4,29,'prvomajske počitnice',1,0),(201,'2011-05-01 00:00:00',2011,5,1,'Praznik dela',0,0),(202,'2011-05-02 00:00:00',2011,5,2,'Praznik dela',0,0),(203,'2011-06-25 00:00:00',2011,6,25,'Dan državnosti',0,0),(204,'2011-07-04 00:00:00',2011,7,4,'poletne počitnice',1,0),(205,'2011-07-05 00:00:00',2011,7,5,'poletne počitnice',1,0),(206,'2011-07-06 00:00:00',2011,7,6,'poletne počitnice',1,0),(207,'2011-07-07 00:00:00',2011,7,7,'poletne počitnice',1,0),(208,'2011-07-08 00:00:00',2011,7,8,'poletne počitnice',1,0),(210,'2011-07-11 00:00:00',2011,7,11,'poletne počitnice',1,0),(211,'2011-07-12 00:00:00',2011,7,12,'poletne počitnice',1,0),(212,'2011-07-13 00:00:00',2011,7,13,'poletne počitnice',1,0),(213,'2011-07-14 00:00:00',2011,7,14,'poletne počitnice',1,0),(214,'2011-07-18 00:00:00',2011,7,18,'poletne počitnice',1,0),(215,'2011-07-19 00:00:00',2011,7,19,'poletne počitnice',1,0),(216,'2011-07-20 00:00:00',2011,7,20,'poletne počitnice',1,0),(217,'2011-07-21 00:00:00',2011,7,21,'poletne počitnice',1,0),(218,'2011-07-22 00:00:00',2011,7,22,'poletne počitnice',1,0),(219,'2011-07-25 00:00:00',2011,7,25,'poletne počitnice',1,0),(220,'2011-07-26 00:00:00',2011,7,26,'poletne počitnice',1,0),(221,'2011-07-27 00:00:00',2011,7,27,'poletne počitnice',1,0),(222,'2011-07-28 00:00:00',2011,7,28,'poletne počitnice',1,0),(223,'2011-07-29 00:00:00',2011,7,29,'poletne počitnice',1,0),(224,'2011-08-01 00:00:00',2011,8,1,'poletne počitnice',1,0),(225,'2011-08-02 00:00:00',2011,8,2,'poletne počitnice',1,0),(226,'2011-08-03 00:00:00',2011,8,3,'poletne počitnice',1,0),(227,'2011-08-04 00:00:00',2011,8,4,'poletne počitnice',1,0),(228,'2011-08-05 00:00:00',2011,8,5,'poletne počitnice',1,0),(229,'2011-08-08 00:00:00',2011,8,8,'poletne počitnice',1,0),(230,'2011-08-09 00:00:00',2011,8,9,'poletne počitnice',1,0),(231,'2011-08-10 00:00:00',2011,8,10,'poletne počitnice',1,0),(232,'2011-08-11 00:00:00',2011,8,11,'poletne počitnice',1,0),(233,'2011-08-15 00:00:00',2011,8,15,'Marijino nebovzetje',0,0),(234,'2011-08-12 00:00:00',2011,8,12,'poletne počitnice',1,0),(235,'2011-08-16 00:00:00',2011,8,16,'poletne počitnice',1,0),(236,'2011-08-17 00:00:00',2011,8,17,'poletne počitnice',1,0),(237,'2011-08-18 00:00:00',2011,8,18,'poletne počitnice',1,0),(238,'2011-08-19 00:00:00',2011,8,19,'poletne počitnice',1,0),(239,'2010-12-31 00:00:00',2010,12,31,'novoletne počitnice',1,0),(240,'2010-10-29 00:00:00',2010,10,29,'jesenske počitnice',1,0),(241,'2010-12-30 00:00:00',2010,12,30,'novoletne počitnice',1,0),(243,'2009-07-27 00:00:00',2009,7,27,'poletne počitnice',1,0),(244,'2009-08-17 00:00:00',2009,8,17,'poletne počitnice',1,0),(245,'2007-10-29 00:00:00',2007,10,29,'jesenske počitnice',1,0),(246,'2007-10-30 00:00:00',2007,10,30,'jesenske počitnice',1,0),(247,'2007-10-31 00:00:00',2007,10,31,'Dan reformacije',0,0),(248,'2007-11-01 00:00:00',2007,11,1,'Dan spomina na mrtve',0,0),(249,'2007-11-02 00:00:00',2007,11,2,'jesenske počitnice',1,0),(250,'2007-12-24 00:00:00',2007,12,24,'novoletne počitnice',1,0),(251,'2007-12-25 00:00:00',2007,12,25,'Božič',0,0),(252,'2007-12-26 00:00:00',2007,12,26,'Dan samostojnosti in enostnosti',0,0),(253,'2007-12-27 00:00:00',2007,12,27,'novoletne počitnice',1,0),(254,'2007-12-28 00:00:00',2007,12,28,'novoletne počitnice',1,0),(255,'2007-12-29 00:00:00',2007,12,29,'novoletne počitnice',1,0),(256,'2007-12-30 00:00:00',2007,12,30,'novoletne počitnice',1,0),(257,'2007-12-31 00:00:00',2007,12,31,'novoletne počitnice',1,0),(258,'2009-12-31 00:00:00',2009,12,31,'novoletne počitnice',1,0),(259,'2010-08-06 00:00:00',2010,8,6,'poletne počitnice',1,0),(260,'2010-07-16 00:00:00',2010,7,16,'poletne počitnice',1,0),(261,'2011-07-15 00:00:00',2011,7,15,'poletne počitnice',1,0),(262,'2009-10-30 00:00:00',2009,9,30,'Jesenske počitnice',1,0),(263,'2010-04-10 00:00:00',2010,4,10,'Pomladni dan',2,0),(264,'2010-04-26 00:00:00',2010,4,26,'Nadomeščen dan 10.4.',3,0),(265,'2011-02-07 00:00:00',2011,2,7,'Dela prost dan, nad. 16.4. ',3,0),(266,'2011-04-16 00:00:00',2011,4,16,'Pomladni sejem',2,0),(267,'2011-04-26 00:00:00',2011,4,26,'Pouka prosto, nadom. 7.5.',3,0),(268,'2011-05-07 00:00:00',2011,5,7,'Ob žici',2,0),(269,'2011-11-02 00:00:00',2011,11,2,'jesenske počitnice',1,0),(270,'2011-11-03 00:00:00',2011,11,3,'jesenske počitnice',1,0),(271,'2011-11-04 00:00:00',2011,11,4,'jesenske počitnice',1,0),(274,'2011-10-31 00:00:00',2011,10,31,'Dan reformacije',0,0),(275,'2011-11-01 00:00:00',2011,11,1,'Dan spomina na mrtve',0,0),(276,'2011-12-25 00:00:00',2011,12,25,'Božič',0,0),(277,'2011-12-26 00:00:00',2011,12,26,'Dan samostojnosti in enotnosti',0,0),(278,'2011-12-27 00:00:00',2011,12,27,'novoletne počitnice',1,0),(279,'2011-12-28 00:00:00',2011,12,28,'novoletne počitnice',1,0),(280,'2011-12-29 00:00:00',2011,12,29,'novoletne počitnice',1,0),(281,'2011-12-30 00:00:00',2011,12,30,'novoletne počitnice',1,0),(283,'2012-01-01 00:00:00',2012,1,1,'Novo leto',0,0),(284,'2012-01-02 00:00:00',2012,1,2,'Novo leto',0,0),(286,'2012-02-08 00:00:00',2012,2,8,'Slovenski kulturni praznik',0,0),(287,'2012-02-20 00:00:00',2012,2,20,'zimske počitnice',1,0),(288,'2012-02-21 00:00:00',2012,2,21,'zimske počitnice',1,0),(289,'2012-02-22 00:00:00',2012,2,22,'zimske počitnice',1,0),(290,'2012-02-23 00:00:00',2012,2,23,'zimske počitnice',1,0),(291,'2012-02-24 00:00:00',2012,2,24,'zimske počitnice',1,0),(293,'2012-04-09 00:00:00',2012,4,9,'Velikonočni ponedeljek',0,0),(295,'2012-04-27 00:00:00',2012,4,27,'Dan upora proti okupatorju',0,0),(296,'2012-04-30 00:00:00',2012,4,30,'prvomajske počitnice',1,0),(298,'2012-05-01 00:00:00',2012,5,1,'Praznik dela',0,0),(299,'2012-05-02 00:00:00',2012,5,2,'Praznik dela',0,0),(301,'2012-06-25 00:00:00',2012,6,25,'Dan državnosti',0,0),(305,'2012-07-05 00:00:00',2012,7,5,'poletne počitnice',1,0),(306,'2012-07-06 00:00:00',2012,7,6,'poletne počitnice',1,0),(307,'2012-07-09 00:00:00',2012,7,9,'poletne počitnice',1,0),(308,'2012-07-10 00:00:00',2012,7,10,'poletne počitnice',1,0),(309,'2012-07-11 00:00:00',2012,7,11,'poletne počitnice',1,0),(310,'2012-07-12 00:00:00',2012,7,12,'poletne počitnice',1,0),(311,'2012-07-13 00:00:00',2012,7,13,'poletne počitnice',1,0),(312,'2012-07-16 00:00:00',2012,7,16,'poletne počitnice',1,0),(313,'2012-07-17 00:00:00',2012,7,17,'poletne počitnice',1,0),(314,'2012-07-18 00:00:00',2012,7,18,'poletne počitnice',1,0),(315,'2012-07-19 00:00:00',2012,7,19,'poletne počitnice',1,0),(316,'2012-07-20 00:00:00',2012,7,20,'poletne počitnice',1,0),(317,'2012-07-23 00:00:00',2012,7,23,'poletne počitnice',1,0),(318,'2012-07-24 00:00:00',2012,7,24,'poletne počitnice',1,0),(319,'2012-07-25 00:00:00',2012,7,25,'poletne počitnice',1,0),(320,'2012-07-26 00:00:00',2012,7,26,'poletne počitnice',1,0),(321,'2012-07-27 00:00:00',2012,7,27,'poletne počitnice',1,0),(322,'2012-07-30 00:00:00',2012,7,30,'poletne počitnice',1,0),(323,'2012-07-31 00:00:00',2012,7,31,'poletne počitnice',1,0),(324,'2012-08-01 00:00:00',2012,8,1,'poletne počitnice',1,0),(325,'2012-08-02 00:00:00',2012,8,2,'poletne počitnice',1,0),(326,'2012-08-03 00:00:00',2012,8,3,'poletne počitnice',1,0),(327,'2012-08-06 00:00:00',2012,8,6,'poletne počitnice',1,0),(328,'2012-08-07 00:00:00',2012,8,7,'poletne počitnice',1,0),(329,'2012-08-08 00:00:00',2012,8,8,'poletne počitnice',1,0),(330,'2012-08-09 00:00:00',2012,8,9,'poletne počitnice',1,0),(331,'2012-08-10 00:00:00',2012,8,10,'poletne počitnice',1,0),(332,'2012-08-15 00:00:00',2012,8,15,'Marijino nebovzetje',0,0),(333,'2012-08-13 00:00:00',2012,8,13,'poletne počitnice',1,0),(334,'2012-08-14 00:00:00',2012,8,14,'poletne počitnice',1,0),(335,'2012-08-16 00:00:00',2012,8,16,'poletne počitnice',1,0),(336,'2012-08-17 00:00:00',2012,8,17,'poletne počitnice',1,0),(337,'2012-08-20 00:00:00',2012,8,20,'poletne počitnice',1,0),(338,'2012-08-21 00:00:00',2012,8,21,'poletne počitnice',1,0),(343,'2012-10-29 00:00:00',2012,10,29,'jesenske počitnice',1,0),(344,'2012-10-30 00:00:00',2012,10,30,'jesenske počitnice',1,0),(345,'2012-11-02 00:00:00',2012,11,2,'jesenske počitnice',1,0),(348,'2012-10-31 00:00:00',2012,10,31,'Dan reformacije',0,0),(349,'2012-11-01 00:00:00',2012,11,1,'Dan spomina na mrtve',0,0),(350,'2012-12-25 00:00:00',2012,12,25,'Božič',0,0),(351,'2012-12-26 00:00:00',2012,12,26,'Dan samostojnosti in enotnosti',0,0),(352,'2012-12-27 00:00:00',2012,12,27,'novoletne počitnice',1,0),(353,'2012-12-28 00:00:00',2012,12,28,'novoletne počitnice',1,0),(355,'2012-12-31 00:00:00',2012,12,31,'novoletne počitnice',1,0),(356,'2012-07-02 00:00:00',2012,7,2,'poletne počitnice',1,0),(357,'2012-07-03 00:00:00',2012,7,3,'poletne počitnice',1,0),(358,'2012-07-04 00:00:00',2012,7,4,'poletne počitnice',1,0),(359,'2012-02-11 00:00:00',2012,2,11,'pomladni sejem',2,0),(360,'2013-01-01 00:00:00',2013,1,1,'Novo leto',0,0),(361,'2013-02-08 00:00:00',2013,2,8,'Slovenski kulturni praznik',0,0),(362,'2013-02-25 00:00:00',2013,2,25,'zimske počitnice',1,0),(363,'2013-02-26 00:00:00',2013,2,26,'zimske počitnice',1,0),(364,'2013-02-27 00:00:00',2013,2,27,'zimske počitnice',1,0),(365,'2013-02-28 00:00:00',2013,2,28,'zimske počitnice',1,0),(366,'2013-03-01 00:00:00',2013,3,1,'zimske počitnice',1,0),(367,'2013-04-01 00:00:00',2013,4,1,'Velikonočni ponedeljek',0,0),(368,'2013-04-27 00:00:00',2013,4,27,'Dan upora proti okupatorju',0,0),(369,'2013-04-30 00:00:00',2013,4,30,'prvomajske počitnice',1,0),(370,'2013-05-01 00:00:00',2013,5,1,'Praznik dela',0,0),(371,'2013-05-02 00:00:00',2013,5,2,'Praznik dela',0,0),(372,'2013-06-25 00:00:00',2013,6,25,'Dan državnosti',0,0),(373,'2013-07-01 00:00:00',2013,7,1,'poletne počitnice',1,0),(374,'2013-07-02 00:00:00',2013,7,2,'poletne počitnice',1,0),(375,'2013-07-03 00:00:00',2013,7,3,'poletne počitnice',1,0),(376,'2013-07-04 00:00:00',2013,7,4,'poletne počitnice',1,0),(377,'2013-07-05 00:00:00',2013,7,5,'poletne počitnice',1,0),(378,'2013-07-08 00:00:00',2013,7,8,'poletne počitnice',1,0),(379,'2013-07-09 00:00:00',2013,7,9,'poletne počitnice',1,0),(380,'2013-07-10 00:00:00',2013,7,10,'poletne počitnice',1,0),(381,'2013-07-11 00:00:00',2013,7,11,'poletne počitnice',1,0),(382,'2013-07-12 00:00:00',2013,7,12,'poletne počitnice',1,0),(383,'2013-07-15 00:00:00',2013,7,15,'poletne počitnice',1,0),(384,'2013-07-16 00:00:00',2013,7,16,'poletne počitnice',1,0),(385,'2013-07-17 00:00:00',2013,7,17,'poletne počitnice',1,0),(386,'2013-07-18 00:00:00',2013,7,18,'poletne počitnice',1,0),(387,'2013-07-19 00:00:00',2013,7,19,'poletne počitnice',1,0),(388,'2013-07-22 00:00:00',2013,7,22,'poletne počitnice',1,0),(389,'2013-07-23 00:00:00',2013,7,23,'poletne počitnice',1,0),(390,'2013-07-24 00:00:00',2013,7,24,'poletne počitnice',1,0),(391,'2013-07-25 00:00:00',2013,7,25,'poletne počitnice',1,0),(392,'2013-07-26 00:00:00',2013,7,26,'poletne počitnice',1,0),(393,'2013-07-29 00:00:00',2013,7,29,'poletne počitnice',1,0),(394,'2013-07-30 00:00:00',2013,7,30,'poletne počitnice',1,0),(395,'2013-07-31 00:00:00',2013,7,31,'poletne počitnice',1,0),(396,'2013-08-01 00:00:00',2013,8,1,'poletne počitnice',1,0),(397,'2013-08-02 00:00:00',2013,8,2,'poletne počitnice',1,0),(398,'2013-08-05 00:00:00',2013,8,5,'poletne počitnice',1,0),(399,'2013-08-06 00:00:00',2013,8,6,'poletne počitnice',1,0),(400,'2013-08-07 00:00:00',2013,8,7,'poletne počitnice',1,0),(401,'2013-08-08 00:00:00',2013,8,8,'poletne počitnice',1,0),(402,'2013-08-09 00:00:00',2013,8,9,'poletne počitnice',1,0),(403,'2013-08-12 00:00:00',2013,8,12,'poletne počitnice',1,0),(404,'2013-08-13 00:00:00',2013,8,13,'poletne počitnice',1,0),(405,'2013-08-15 00:00:00',2013,8,15,'Marijino nebovzetje',0,0),(406,'2013-08-14 00:00:00',2013,8,14,'poletne počitnice',1,0),(407,'2013-08-16 00:00:00',2013,8,16,'poletne počitnice',1,0),(408,'2013-08-19 00:00:00',2013,8,19,'poletne počitnice',1,0),(409,'2013-08-20 00:00:00',2013,8,20,'poletne počitnice',1,0),(410,'2013-10-29 00:00:00',2013,10,29,'jesenske počitnice',1,0),(411,'2013-10-30 00:00:00',2013,10,30,'jesenske počitnice',1,0),(412,'2013-10-31 00:00:00',2013,10,31,'Dan reformacije',0,0),(413,'2013-11-01 00:00:00',2013,11,1,'Dan spomina na mrtve',0,0),(414,'2013-10-28 00:00:00',2013,10,28,'jesenske počitnice',1,0),(415,'2013-12-25 00:00:00',2013,12,25,'Božič',0,0),(416,'2013-12-26 00:00:00',2013,12,26,'Dan samostojnosti in enotnosti',0,0),(417,'2013-12-27 00:00:00',2013,12,27,'novoletne počitnice',1,0),(418,'2013-12-30 00:00:00',2013,12,30,'novoletne počitnice',1,0),(419,'2013-12-31 00:00:00',2013,12,31,'novoletne počitnice',1,0),(420,'2013-04-29 00:00:00',2013,4,29,'prvomajske počitnice',1,0),(421,'2014-01-01 00:00:00',2014,1,1,'Novo leto',0,0),(422,'2014-02-08 00:00:00',2014,2,8,'Slovenski kulturni praznik',0,0),(423,'2014-02-17 00:00:00',2014,2,17,'zimske počitnice',1,0),(424,'2014-02-18 00:00:00',2014,2,18,'zimske počitnice',1,0),(425,'2014-02-19 00:00:00',2014,2,19,'zimske počitnice',1,0),(426,'2014-02-20 00:00:00',2014,2,20,'zimske počitnice',1,0),(427,'2014-02-21 00:00:00',2014,2,21,'zimske počitnice',1,0),(428,'2014-04-21 00:00:00',2014,4,21,'Velikonočni ponedeljek',0,0),(429,'2014-04-27 00:00:00',2014,4,27,'Dan upora proti okupatorju',0,0),(430,'2014-04-30 00:00:00',2014,4,30,'prvomajske počitnice',1,0),(431,'2014-05-01 00:00:00',2014,5,1,'Praznik dela',0,0),(432,'2014-05-02 00:00:00',2014,5,2,'Praznik dela',0,0),(433,'2014-06-25 00:00:00',2014,6,25,'Dan državnosti',0,0),(434,'2014-07-02 00:00:00',2014,7,2,'poletne počitnice',1,0),(435,'2014-07-03 00:00:00',2014,7,3,'poletne počitnice',1,0),(436,'2014-07-04 00:00:00',2014,7,4,'poletne počitnice',1,0),(437,'2014-07-07 00:00:00',2014,7,7,'poletne počitnice',1,0),(438,'2014-07-08 00:00:00',2014,7,8,'poletne počitnice',1,0),(439,'2014-07-09 00:00:00',2014,7,9,'poletne počitnice',1,0),(440,'2014-07-10 00:00:00',2014,7,10,'poletne počitnice',1,0),(441,'2014-07-11 00:00:00',2014,7,11,'poletne počitnice',1,0),(442,'2014-07-14 00:00:00',2014,7,14,'poletne počitnice',1,0),(443,'2014-07-15 00:00:00',2014,7,15,'poletne počitnice',1,0),(444,'2014-07-16 00:00:00',2014,7,16,'poletne počitnice',1,0),(445,'2014-07-17 00:00:00',2014,7,17,'poletne počitnice',1,0),(446,'2014-07-18 00:00:00',2014,7,18,'poletne počitnice',1,0),(447,'2014-07-21 00:00:00',2014,7,21,'poletne počitnice',1,0),(448,'2014-07-22 00:00:00',2014,7,22,'poletne počitnice',1,0),(449,'2014-07-23 00:00:00',2014,7,23,'poletne počitnice',1,0),(450,'2014-07-24 00:00:00',2014,7,24,'poletne počitnice',1,0),(451,'2014-07-25 00:00:00',2014,7,25,'poletne počitnice',1,0),(452,'2014-07-28 00:00:00',2014,7,28,'poletne počitnice',1,0),(453,'2014-07-29 00:00:00',2014,7,29,'poletne počitnice',1,0),(454,'2014-07-30 00:00:00',2014,7,30,'poletne počitnice',1,0),(455,'2014-07-31 00:00:00',2014,7,31,'poletne počitnice',1,0),(456,'2014-08-01 00:00:00',2014,8,1,'poletne počitnice',1,0),(457,'2014-08-04 00:00:00',2014,8,4,'poletne počitnice',1,0),(458,'2014-08-05 00:00:00',2014,8,5,'poletne počitnice',1,0),(459,'2014-08-06 00:00:00',2014,8,6,'poletne počitnice',1,0),(460,'2014-08-07 00:00:00',2014,8,7,'poletne počitnice',1,0),(461,'2014-08-08 00:00:00',2014,8,8,'poletne počitnice',1,0),(462,'2014-08-11 00:00:00',2014,8,11,'poletne počitnice',1,0),(463,'2014-08-12 00:00:00',2014,8,12,'poletne počitnice',1,0),(464,'2014-08-15 00:00:00',2014,8,15,'Marijino nebovzetje',0,0),(465,'2014-08-13 00:00:00',2014,8,13,'poletne počitnice',1,0),(466,'2014-08-14 00:00:00',2014,8,14,'poletne počitnice',1,0),(467,'2014-08-18 00:00:00',2014,8,18,'poletne počitnice',1,0),(468,'2014-08-19 00:00:00',2014,8,19,'poletne počitnice',1,0),(469,'2014-10-29 00:00:00',2014,10,29,'jesenske počitnice',1,0),(470,'2014-10-30 00:00:00',2014,10,30,'jesenske počitnice',1,0),(471,'2014-10-31 00:00:00',2014,10,31,'Dan reformacije',0,0),(472,'2014-11-01 00:00:00',2014,11,1,'Dan spomina na mrtve',0,0),(473,'2014-10-28 00:00:00',2014,10,28,'jesenske počitnice',1,0),(474,'2014-12-25 00:00:00',2014,12,25,'Božič',0,0),(475,'2014-12-26 00:00:00',2014,12,26,'Dan samostojnosti in enotnosti',0,0),(476,'2014-12-27 00:00:00',2014,12,27,'novoletne počitnice',1,0),(477,'2014-12-30 00:00:00',2014,12,30,'novoletne počitnice',1,0),(478,'2014-12-31 00:00:00',2014,12,31,'novoletne počitnice',1,0),(479,'2014-04-29 00:00:00',2014,4,29,'prvomajske počitnice',1,0),(480,'2014-04-28 00:00:00',2014,4,28,'prvomajske počitnice',1,0),(481,'2014-08-20 00:00:00',2014,8,20,'poletne počitnice',1,0),(482,'2014-08-21 00:00:00',2014,8,21,'poletne počitnice',1,0),(483,'2014-08-22 00:00:00',2014,8,22,'poletne počitnice',1,0),(484,'2012-12-24 00:00:00',2012,12,24,'ni pouka',3,0),(485,'2012-09-29 00:00:00',2012,9,29,'nadomeščanje 24.12.',2,0),(486,'2013-05-03 00:00:00',2013,5,3,'ni pouka',3,0),(487,'2013-04-06 00:00:00',2013,4,6,'pomladni sejem',2,0),(488,'2012-04-06 00:00:00',2012,4,6,'ni pouka',3,0),(489,'2014-04-12 00:00:00',2014,4,12,'Pomladni sejem',2,0),(490,'2014-04-25 00:00:00',2014,4,25,'Dela prost dan',3,0);

/*Table structure for table `tabpredmeti` */

DROP TABLE IF EXISTS `tabpredmeti`;

CREATE TABLE `tabpredmeti` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Oznaka` varchar(8) DEFAULT NULL,
  `Opis` varchar(100) DEFAULT NULL,
  `Prioriteta` int(10) DEFAULT NULL,
  `VrstniRed` int(10) DEFAULT NULL,
  `SifraMSS` int(10) DEFAULT NULL,
  `PredmetIdMSS` varchar(10) DEFAULT NULL,
  `KodaMSS` varchar(5) DEFAULT NULL,
  `OpisMSS` varchar(100) DEFAULT NULL,
  `OpisLopolis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8;

/*Data for the table `tabpredmeti` */

insert  into `tabpredmeti`(`Id`,`Oznaka`,`Opis`,`Prioriteta`,`VrstniRed`,`SifraMSS`,`PredmetIdMSS`,`KodaMSS`,`OpisMSS`,`OpisLopolis`) values (1,'BIO','Biologija',0,13,1353,'BIO9o','BIO','Biologija',NULL),(2,'EID','Etika in družba',2,10,1324,'ED_8o','EID','Etika in družba',NULL),(3,'DOD','Dodatni pouk',3,100,-1,'DO_8o','DO','Dodatni pouk',NULL),(4,'DOP','Dopolnilni pouk',3,100,-1,'DP_8o','DP','Dopolnilni pouk',NULL),(5,'DDE','Drž. in dom. vzgoja ter etika',0,10,1520,'DDE9o','DDE','Državljanska in domovinska vzgoja ter etika',NULL),(6,'FIZ','Fizika',0,11,1342,'FIZ9o','FIZ','Fizika',NULL),(7,'GEO','Geografija',0,8,1332,'GEO9o','GEO','Geografija',NULL),(8,'KEM','Kemija',0,12,1350,'KEM9o','KEM','Kemija',NULL),(9,'LVZ','Likovna vzgoja',0,5,1369,'LVZ9o','LVZ','Likovna vzgoja',NULL),(10,'LV8','Likovna vzgoja-osemletka',2,21,NULL,NULL,NULL,NULL,NULL),(11,'MAT','Matematika',0,2,1340,'MAT9o','MAT','Matematika',NULL),(12,'MME','Multimedija',1,31,1634,'MMEIZ','MME','Multimedia /i/','Multimedija'),(13,'NAR','Naravoslovje',0,14,1583,'NAR9o','NAR','Naravoslovje',NULL),(14,'NIT','Naravoslovje in tehnika',0,15,1584,'NIT9o','NIT','Naravoslovje in tehnika',NULL),(15,'RAČ','Računalništvo',3,32,1877,'RACIZ','RPP','Računalništvo (v OŠPP) /i/',NULL),(16,'SLJ','Slovenščina',0,1,1304,'SLO9o','SLJ','Slovenščina',NULL),(17,'DRU','Družba',0,7,1521,'DRU9o','DRU','Družba',NULL),(18,'SPN','Spoznavanje narave',2,14,1358,'SN_8o','SPN','Spoznavanje narave',NULL),(19,'ŠSPa','Šport za sprostitev',1,33,1564,'ŠSPIZ','ŠSP','Šport za sprostitev /i/','Šport za sprostitev'),(20,'ŠVZ','Športna vzgoja',0,18,1346,'ŠVZ9o','ŠVZ','Športna vzgoja',NULL),(21,'ŠV8','Športna vzgoja-osemletka',2,23,NULL,NULL,NULL,NULL,NULL),(22,'THV','Tehnična vzgoja',2,16,NULL,NULL,NULL,NULL,NULL),(23,'TIF','Francoščina',0,4,NULL,NULL,NULL,NULL,NULL),(24,'TIN','Nemščina',0,4,NULL,NULL,NULL,NULL,NULL),(25,'TIT','Tehnika in tehnologija',0,16,1622,'TIT9o','TIT','Tehnika in tehnologija',NULL),(26,'TJA','Angleščina',0,3,1487,'TJA9o','TJA','Angleščina',NULL),(27,'UBE','Urejanje besedil',1,34,1636,'UBEIZ','UBE','Urejanje besedil /i/','Urejanje besedil'),(28,'ZGO','Zgodovina',0,9,1319,'ZGO9o','ZGO','Zgodovina',NULL),(29,'GVZ','Glasbena vzgoja',0,6,1372,'GVZ9o','GVZ','Glasbena vzgoja',NULL),(30,'GV8','Glasbena vzgoja-osemletka',2,22,NULL,NULL,NULL,NULL,NULL),(31,'FI1','Francoščina 1',1,35,1493,'FI1IZ','FI1','Francoščina I /i/','Francoščina I'),(32,'FI2','Francoščina 2',1,35,1501,'FI2IZ','FI2','Francoščina II /i/','Francoščina II'),(33,'FI3','Francoščina 3',1,35,1502,'FI3IZ','FI3','Francoščina III /i/','Francoščina III'),(34,'TEV','Vzgoja za medije-televizija',1,36,1541,'TEVIZ','TEV','Televizija /i/','Televizija'),(35,'RAD','Vzgoja za medije-radio',1,37,1540,'RADIZ','RAD','Radio /i/','Radio'),(36,'SPH','Sodobna priprava hrane',1,38,1786,'SPHIZ','SPH','Sodobna priprava hrane /i/','Sodobna priprava hrane'),(37,'LI1','Latinščina 1',1,39,1495,'LI1IZ','LI1','Latinščina I /i/','Latinščina I'),(38,'LI2','Latinščina 2',1,39,1505,'LI2IZ','LI2','Latinščina II /i/','Latinščina II'),(39,'LI3','Latinščina 3',1,39,1506,'LI3IZ','LI3','Latinščina III /i/','Latinščina III'),(40,'HI1','Hrvaščina 1',1,40,1498,'HI1IZ','HI1','Hrvaščina I /i/','Hrvaščina I'),(41,'ŠHO','Šahovske osnove',1,41,1835,'ŠAOIZ','ŠHO','Šahovske osnove /i/','Šahovske osnove'),(42,'IŠPo1','Izbrani šport-odbojka',1,42,1563,'IŠ1IZ','IŠP','Izbrani šport /i/','Izbrani šport ODBOJKA'),(43,'ŠZZa','Šport za zdravje',1,43,1562,'ŠZZIZ','ŠZZ','Šport za zdravje /i/','Šport za zdravje'),(44,'ROMa','Računalniška omrežja',1,44,1635,'ROMIZ','ROM','Računalniška omrežja /i/','Računalniška omrežja'),(45,'ZVE','Zvezde in vesolje',1,45,1588,'ZVEIZ','ZVE','Zvezde in vesolje /i/','Zvezde in vesolje'),(46,'TIS','Vzgoja za medije-tisk',1,46,1539,'TISIZ','TIS','Tisk /i/','Tisk'),(47,'LS2','Likovno snovanje 2',1,47,1645,'LS2IZ','LS2','Likovno snovanje 2 /i/','Likovno snovanje II'),(48,'LS1','Likovno snovanje 1',1,47,1644,'LS1IZ','LS1','Likovno snovanje 1 /i/','Likovno snovanje I'),(49,'SPO','Spoznavanje okolja',0,7,1533,'SPO9o','SPO','Spoznavanje okolja',NULL),(50,'RAZ','Razredništvo',3,100,-1,'RUO9o','RU','Oddelčna skupnost',NULL),(51,'GOS','Gospodinjstvo',0,17,1382,'GOS9o','GOS','Gospodinjstvo',NULL),(52,'OPB','Podaljšano bivanje',3,100,-1,NULL,NULL,NULL,NULL),(53,'DSP','Dodatna strokovna pomoč',3,100,-1,'POP9o','POP','Pomoč otrokom s posebnimi potrebami',NULL),(54,'HI2','Hrvaščina 2',1,40,1511,'HI2IZ','HI2','Hrvaščina 2 /i/','Hrvaščina II'),(55,'HI3','Hrvaščina 3',1,40,1512,'HI3IZ','HI3','Hrvaščina 3 /i/','Hrvaščina III'),(56,'KOL','Kolesarski izpit',3,100,-1,NULL,NULL,NULL,NULL),(57,'ŠHK','Šahovsko kombiniranje',1,41,1836,'ŠAKIZ','ŠHK','Šahovsko kombiniranje /i/','Šahovsko kombiniranje'),(58,'ŠHS','Šahovska strategija',1,41,1837,'ŠASIZ','ŠHS','Šahovske strategije /i/','Šahovske strategije'),(59,'TVZ','Turistična vzgoja',1,48,1456,'TVZIZ','TVZ','Turistična vzgoja /i/','Turistična vzgoja'),(60,'VZG','Vzgojitelj',3,100,1543,'RP29o','RP2','Razredni pouk (2. učitelj)',NULL),(61,'Rn','Nadomestni razrednik',3,100,-1,NULL,NULL,NULL,NULL),(62,'JUV','Jutranje varstvo',3,100,-1,NULL,NULL,NULL,NULL),(63,'OGD','Organizacija gospodinjskih dni',3,100,-1,NULL,NULL,NULL,NULL),(64,'NI1','Nemščina 1',1,49,1496,'NI1IZ','NI1','Nemščina 1 /i/','Nemščina I'),(65,'NI1b','Nemščina 1',1,49,1496,'NI1IZ','NI1','Nemščina 1 /i/','Nemščina I'),(66,'UBEb','Urejanje besedil',1,34,1636,'UBEIZ','UBE','Urejanje besedil /i/','Urejanje besedil'),(67,'MMEb','Multimedija',1,31,1634,'MMEIZ','MME','Multimedia /i/','Multimedija'),(68,'ROMb','Računalniška omrežja',1,44,1635,'ROMIZ','ROM','Računalniška omrežja /i/','Računalniška omrežja'),(69,'IŠPk1','Izbrani šport-košarka',1,42,1563,'IŠ2IZ','IŠP','Izbrani šport /i/','Izbrani šport - KOŠARKA'),(70,'SLZ','Sonce, Luna in Zemlja',1,45,1586,'SLZIZ','SLZ','Sonce, Luna in Zemlja /i/','Sonce, Luna in Zemlja'),(71,'PRE','Vodenje prehrane',3,100,-1,NULL,NULL,NULL,NULL),(72,'ŠNO','Šolsko novinarstvo',1,48,1515,'ŠNOIZ','ŠNO','Šolsko novinarstvo /i/','Šolsko novinarstvo'),(73,'LS3','Likovno snovanje 3',1,47,1646,'LS3IZ','LS3','Likovno snovanje 3 /i/','Likovno snovanje III'),(74,'OPZ','Otroški pevski zbor',3,100,NULL,NULL,NULL,NULL,NULL),(75,'MPZ','Mladinski pevski zbor',3,100,NULL,NULL,NULL,NULL,NULL),(76,'NI2','Nemščina 2',1,49,1507,'NI2IZ','NI2','Nemščina II /i/','Nemščina II'),(77,'NI3','Nemščina 3',1,49,1508,'NI3IZ','NI3','Nemščina III /i/','Nemščina III'),(78,'PB01','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(79,'PB02','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(80,'PB03','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(81,'PB04','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(82,'PB05','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(83,'PB06','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(84,'PB07','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(85,'PB08','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(86,'PB09','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(87,'PB10','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(88,'PB11','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(89,'PB12','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(90,'PB13','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(91,'PB14','Podaljšano bivanje',3,100,NULL,NULL,NULL,NULL,NULL),(92,'LO1','Logika 1',1,45,1556,'LO1IZ','LO1','Logika I /i/','Logika I'),(93,'LO2','Logika 2',1,45,1557,'LO2IZ','LO2','Logika II /i/','Logika II'),(94,'LO3','Logika 3',1,45,1558,'LO3IZ','LO3','Logika III /i/','Logika III'),(95,'NPH','Načini prehranjevanja',1,46,1787,'NPHIZ','NPH','Načini prehranjevanja /i/','Načini prehranjevanja'),(96,'NI2b','Nemščina 2',1,49,1507,'NI2IZ','NI2','Nemščina II /i/','Nemščina II'),(97,'NI3b','Nemščina 3',1,49,1508,'NI3IZ','NI3','Nemščina III /i/','Nemščina III'),(98,'ŠI1','Španščina 1',1,50,1497,'ŠI1IZ','ŠI1','Španščina I /i/','Španščina I'),(99,'ŠI2','Španščina 2',1,50,1509,'ŠI2IZ','ŠI2','Španščina II /i/','Španščina II'),(100,'ŠI3','Španščina 3',1,50,1510,'ŠI3IZ','ŠI3','Španščina III /i/','Španščina III'),(101,'POK','Poskusi v kemiji',1,51,1838,'POKIZ','POK','Poskusi v kemiji /i/','Poskusi v kemiji'),(102,'OGL','Obdelava gradiv: les',1,52,1619,'OGLIZ','OGL','Obdelava gradiv: les /i/','Obdelava gradiv - LES'),(103,'OGU','Obdelava gradiv: um. snovi',1,52,1620,'OGUIZ','OGU','Obdelava gradiv: umetne snovi /i/','Obdelava gradiv - UMETNE SNOVI'),(104,'OGK','Obdelava gradiv: kovine',1,52,1621,'OGKIZ','OGK','Obdelava gradiv: kovine /i/','Obdelava gradiv - KOVINE'),(105,'NPHb','Načini prehranjevanja',1,46,1787,'NPHIZ','NPH','Načini prehranjevanja /i/','Načini prehranjevanja'),(106,'RET','Retorika',1,46,1517,'RETIZ','RET','Retorika /i/','Retorika'),(107,'DIP','Daljnogledi in planeti',1,46,1587,'DIPIZ','DIP','Daljnogledi in planeti /i/','Daljnogledi in planeti'),(108,'ISP','Ind. in skup. učna pomoč',3,100,-1,'POP9o','POP','Pomoč otrokom s posebnimi potrebami',NULL),(109,'ID','Interesna dejavnost',3,100,NULL,NULL,NULL,NULL,NULL),(110,'ŽUU','Življenje upod. v umetnosti',1,50,1653,'ŽUUIZ','ŽUU','Življenje upodobljeno v umetnosti /i/','Življenje upodob. V umetnosti'),(111,'SPD','Spoznavanje družbe',0,15,NULL,NULL,NULL,NULL,NULL),(112,'LAB','Laborant',3,102,NULL,NULL,NULL,NULL,NULL),(113,'KNJ','Knjižničar',3,102,NULL,NULL,NULL,NULL,NULL),(114,'ŠZZb','Šport za zdravje',1,43,1562,'ŠZZIZ','ŠZZ','Šport za zdravje /i/','Šport za zdravje'),(115,'ŠZZc','Šport za zdravje',1,43,1562,'ŠZZIZ','ŠZZ','Šport za zdravje /i/','Šport za zdravje'),(116,'ŠSPb','Šport za sprostitev',1,33,1564,'ŠSPIZ','ŠSP','Šport za sprostitev /i/','Šport za sprostitev'),(117,'ŠSPc','Šport za sprostitev',1,33,1564,'ŠSPIZ','ŠSP','Šport za sprostitev /i/','Šport za sprostitev'),(118,'SPHb','Sodobna priprava hrane',1,38,1786,'SPHIZ','SPH','Sodobna priprava hrane /i/','Sodobna priprava hrane'),(119,'IŠPo2','Izbrani šport-odbojka',1,42,1563,'IŠ1IZ','IŠP','Izbrani šport /i/','Izbrani šport ODBOJKA'),(120,'IŠPk2','Izbrani šport-košarka',1,42,1563,'IŠ2IZ','IŠP','Izbrani šport /i/','Izbrani šport - KOŠARKA'),(121,'POKb','Poskusi v kemiji',1,51,1838,'POKIZ','POK','Poskusi v kemiji /i/','Poskusi v kemiji'),(122,'GKL','Gledališki klub',1,43,1516,'GKLIZ','GKL','Gledališki klub /i/','Gledališki klub'),(123,'RVT','Robotika v tehniki',1,44,1632,'RVTIZ','RVT','Robotika v tehniki /i/','Robotika v tehniki'),(124,'EZR','Elektronika z robotiko',1,44,1630,'EZRIZ','EZR','Elektronika z robotiko /i/','Elektronika z robotiko'),(125,'RVTb','Robotika v tehniki',1,44,1632,'RVTIZ','RVT','Robotika v tehniki /i/','Robotika v tehniki'),(126,'II1','Italijanščina 1',1,42,1494,'II1IZ','II1','Italijanščina I /i/','Italijanščina I'),(127,'II2','Italijanščina 2',1,43,1503,'II2IZ','II2','Italijanščina II /i/','Italijanščina II'),(128,'II3','Italijanščina 3',1,44,1504,'II3IZ','II3','Italijanščina III /i/','Italijanščina III'),(129,'RI1','Ruščina 1',1,42,2155,'RU1IZ','RU1','Ruščina I /i/','Ruščina I'),(130,'RI2','Ruščina 2',1,43,2156,'RU2IZ','RU2','Ruščina II /i/','Ruščina II'),(131,'RI3','Ruščina 3',1,44,2157,'RU3IZ','RU3','Ruščina III /i/','Ruščina III'),(132,'LIK','Literarni klub',1,45,1513,'LIKIZ','LIK','Literarni klub /i/','Literarni klub'),(133,'FIK','Filozofija za otroke: Kritično mišljenje',1,46,1327,'FIKIZ','FIK','Filozofija za otroke: Kritično mišljenje /i/','Filozofija za otroke - Kritično mišljenje'),(134,'FIE','Filozofija za otroke: Etična raziskovanja',1,47,1526,'FIEIZ','FIE','Filozofija za otroke: Etično raziskovanje /i/','Filozofija za otroke - Etično raziskovanje'),(135,'FIJ','Filozofija za otroke: Jaz in drugi',1,48,1527,'FIJIZ','FIJ','Filozofija za otroke: Jaz in drugi /i/','Filozofija za otroke - Jaz in drugi'),(136,'KR1','Klaviatura in računalnik 1',1,42,1670,'KR1IZ','KR1','Klaviatura in računalnik I /i/','Klaviatura in računalnik I'),(137,'KR2','Klaviatura in računalnik 2',1,43,1671,'KR2IZ','KR2','Klaviatura in računalnik II /i/','Klaviatura in računalnik II'),(138,'VE1','Verstva in etika 1',1,42,1522,'VE1IZ','VE1','Verstva in etika 1 /i/','Verstva in etika I'),(139,'VE2','Verstva in etika 2',1,43,1523,'VE2IZ','VE2','Verstva in etika 2 /i/','Verstva in etika II'),(140,'VE3','Verstva in etika 3',1,43,1524,'VE3IZ','VE3','Verstva in etika 3 /i/','Verstva in etika III'),(141,'ČEB','Čebelarstvo',1,42,1597,'ČEBIZ','ČEB','Čebelarstvo /i/','Čebelarstvo'),(142,'DKT','Državljanska kultura',1,43,1525,'DKTIZ','DKT','Državljanska kultura /i/','Državljanska kultura'),(143,'EZRb','Elektronika z robotiko',1,44,1630,'EZRIZ','EZR','Elektronika z robotiko /i/','Elektronika z robotiko'),(144,'ELE','Elektrotehnika',1,42,1631,'ELEIZ','ELE','Elektrotehnika /i/','Elektrotehnika'),(145,'GEN','Genetika',1,43,1577,'GENIZ','GEN','Genetika /i/','Genetika'),(146,'ŽČZ','Življenje človeka na zemlji',1,42,1334,'ŽČZIZ','ŽČZ','Življenje človeka na zemlji /i/','Življenje človeka na zemlji'),(148,'KEO','Kemija v okolju',1,42,1839,'KEOIZ','KEO','Kemija v okolju /i/','Kemija v okolju'),(149,'KEŽ','Kemija v življenju',1,43,1840,'KEŽIZ','KEŽ','Kemija v življenju /i/','Kemija v življenju'),(150,'PFT','Projekti iz fizike in tehnike',1,42,1559,'PFTIZ','PFT','Projekti iz fizike in tehnike /i/','Projekti iz fizike in tehnike'),(151,'PFE','Projekti iz fizike in ekologije',1,43,1560,'PFEIZ','PFE','Projekti iz fizike in ekologije /i/','Projekti iz fizike in ekologije'),(152,'MD7','Matematične delavnice 1',1,42,1553,'MD7IZ','MD7','Matematične delavnice 7 /i/','Matematične delavnice 7'),(153,'MD8','Matematične delavnice 2',1,43,1554,'MD8IZ','MD8','Matematične delavnice 8 /i/','Matematične delavnice 8'),(154,'MD9','Matematične delavnice 3',1,44,1555,'MD9IZ','MD9','Matematične delavnice 9 /i/','Matematične delavnice 9'),(155,'ONA','Organizmi v naravi in umetnem okolju',1,42,1575,'ONAIZ','ONA','Organizmi v naravi in umetnem okolju /i/','Organizmi v naravi in umetnem okolju'),(156,'RČL','Rastline in človek',1,42,1576,'RČLIZ','RČL','Rastline in človek /i/','Rastline in človek'),(157,'RDO','Raziskovanje domače okolice',1,43,1574,'RDOIZ','RDO','Raziskovanje domače okolice /i/','Raziskovanje domače okolice'),(158,'SRD','Sodobnosti z razsežnostmi dediščine',1,44,1538,'SRDIZ','SRD','Sodobnosti z razsežnostmi dediščine /i/','Sodobnosti z razsežnostmi dediščine'),(159,'SSK','Srečanja s kulturami in načini življenja',1,45,1537,'SSKIZ','SSK','Srečanja s kulturami in načini življenja /i/','Srečanja s kulturami in načini življenja'),(160,'ANI','Ansambelska igra',1,42,1667,'ANIIZ','ANI','Ansambelska igra /i/','Ansambelska igra'),(161,'GLD','Glasbena dela',1,43,1668,'GLDIZ','GLD','Glasbena dela /i/','Glasbena dela'),(162,'GLP','Glasbeni projekt',1,44,1669,'GLPIZ','GLP','Glasbeni projekt /i/','Glasbeni projekti'),(163,'INO','Informacijsko opismenjevanje',1,42,1633,'INOIZ','INO','Informacijsko opismenjevanje /i/','Informacijsko opismenjevanje'),(164,'OTK','Osnovne tehnike klekljanja',1,43,1647,'OTKIZ','OTK','Klekljanje: Osnovne tehnike klekljanja /i/','Klekljanje - Osnovne tehnike klekljanja'),(165,'TTČ','Temeljne tehnike v slovenski čipki',1,44,1648,'TTČIZ','TTČ','Klekljanje: Temeljne tehnike v slovenski čipki /i/','Klekljanje - Temeljne tehnike v slovenski čipki'),(166,'ŠIR','Široki ris',1,45,1649,'ŠIRIZ','ŠIR','Klekljanje: Široki ris /i/','Klekljanje - Široki ris'),(167,'KID','Kmetijska dela',1,42,1594,'KIDIZ','KID','Kmetijska dela /i/','Kmetijska dela'),(168,'KIK','Sodobno kmetijstvo',1,43,1595,'KIKIZ','KIK','Sodobno kmetijstvo /i/','Sodobno kmetijstvo'),(169,'KIG','Kmetijsko gospodarstvo',1,44,1596,'KIGIZ','KIG','Kmetijsko gospodarstvo /i/','Kmetijsko gospodarstvo'),(170,'OV1','Okoljska vzgoja 1',1,42,1534,'OV1IZ','OV1','Okoljska vzgoja I /i/','Okoljska vzgoja I'),(171,'OV2','Okoljska vzgoja 2',1,43,1535,'OV2IZ','OV2','Okoljska vzgoja II /i/','Okoljska vzgoja II'),(172,'OV3','Okoljska vzgoja 3',1,44,1536,'OV3IZ','OV3','Okoljska vzgoja III /i/','Okoljska vzgoja III'),(173,'LPL','Ljudski plesi',1,42,1665,'LPLIZ','LPL','Ljudski plesi /i/','Ljudski plesi'),(174,'PLE','Ples',1,43,1664,'PLEIZ','PLE','Ples /i/','Ples'),(175,'SDP','Starinski in družabni plesi',1,44,1666,'SDPIZ','SDP','Starinski in družabni plesi /i/','Starinski in družabni plesi'),(176,'RGT','Risanje v geometriji in tehniki',1,45,1561,'RGTIZ','RGT','Risanje v geometriji in tehniki /i/','Risanje v geometriji in tehniki'),(177,'KGU','Kaj nam govorijo umetnine',1,46,1652,'KGUIZ','KGU','Kaj nam govorijo umetnine /i/','Kaj nam govorijo umetnine'),(178,'OBS','Oblika in slog',1,42,1654,'OBSIZ','OBS','Oblike in slog /i/','Oblike in slog'),(180,'DD','Dodatni in dopolnilni pouk',3,100,1071,'DDP9o','DDP','Dopolnilni in dodatni pouk',NULL),(181,'JuSe','Jutranji sestanek',3,100,NULL,NULL,NULL,NULL,NULL),(182,'Pu','Pogovorna ura',3,100,NULL,NULL,NULL,NULL,NULL),(183,'ped','Pedagog',4,100,NULL,NULL,NULL,NULL,NULL),(184,'KEO2','Kemija v okolju',1,42,1839,'KEOIZ','KEO','Kemija v okolju /i/','Kemija v okolju'),(185,'BZ','Bralna značka',3,110,0,NULL,NULL,NULL,NULL),(186,'DU1','Drugi učitelj v 1. razredu',3,100,0,NULL,NULL,NULL,NULL),(187,'DrDe','Dan dejavnosti',3,100,0,NULL,NULL,NULL,NULL),(188,'IŠPn','Izbrani šport-nogomet',1,42,1563,'IŠ4IZ','IŠP','Izbrani šport /i/',NULL),(189,'GLŠ','Glasbena šola',1,43,0,NULL,NULL,'Glasbena šola /i/',NULL),(190,'GUM','Glasbena umetnost',0,6,1372,'GUM9o','GUM','Glasbena umetnost','Glasbena umetnost'),(191,'LUM','Likovna umetnost',0,5,1369,'LUM9o','LUM','Likovna umetnost','Likovna umetnost'),(192,'DKE','Dom. in drž. kultura in etika',0,10,1520,'DKE9o','DKE','Domovinska in državljanska kultura in etika','Domovinska in državljanska kultura in etika'),(193,'ŠPO','Šport',0,18,1346,'ŠPO9o','ŠPO','Šport','Šport'),(194,'VNN','Varstvo pred naravnimi nesrečami',1,46,3761,'VNNIZ','VNN','Varstvo pred naravnimi nesrečami /i/',NULL),(195,'VEO','Osnovni vbodi in tehnike vezenja',1,46,3386,'OVEIZ','OVE','Osnovni vbodi in tehnike vezenja /i/',NULL),(196,'Folk','Folklora',3,100,NULL,NULL,NULL,NULL,NULL),(197,'A-M','Aktiv matematikov',3,100,NULL,NULL,NULL,NULL,NULL),(198,'A-A','Aktiv anglistov',3,100,NULL,NULL,NULL,NULL,NULL),(199,'A-S','Aktiv slavistov',3,100,NULL,NULL,NULL,NULL,NULL),(200,'A-N','Aktiv naravoslovja',3,100,NULL,NULL,NULL,NULL,NULL),(201,'A-D','Aktiv družboslovja',3,100,NULL,NULL,NULL,NULL,NULL),(202,'A-PB','Aktiv PB',3,100,NULL,NULL,NULL,NULL,NULL),(203,'A-Š','Aktiv športnikov',3,100,NULL,NULL,NULL,NULL,NULL),(204,'IA2','Angleščina',1,81,NULL,'IA2NI','IA2','Angleščina /ni/',NULL),(205,'IN2','Nemščina',1,82,0,'IN2NI','IN2','Nemščina /ni/',NULL),(206,'IF2','Francoščina',1,83,NULL,'IF2NI','IF2','Francoščina /ni/',NULL),(207,'II2','Italijanščina',1,84,NULL,'II2NI','II2','Italijanščina /ni/',NULL),(208,'IM2','Madžarščina',1,85,NULL,'IM2NI','IM2','Madžarščina /ni/',NULL),(209,'IH2','Hrvaščina',1,86,NULL,'IH2NI','IH2','Hrvaščina /ni/',NULL),(210,'INR','Računalništvo',1,90,NULL,'INRNI','INR','Računalništvo /ni/',NULL),(211,'INU','Umetnost',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(212,'INŠ','Šport',1,92,NULL,'INŠNI','INŠ','Šport /ni/',NULL),(213,'INT','Tehnika',1,93,NULL,'INTNI','INT','Tehnika /ni/',NULL),(214,'INA','Angleščina',1,94,NULL,'INANI','INA','Angleščina /ni/',NULL),(215,'INN','Nemščina',1,95,NULL,'INNNI','INN','Nemščina /ni/',NULL),(216,'INUg','Umetnost - glasbena igra',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(217,'INUč','Umetnost - ustvarjajmo s čebelo',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(218,'INUl','Umetnost - likovna ustvarjalnost',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(219,'INUp','Umetnost - ples',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(220,'INUt','Umetnost - gledališče',1,91,NULL,'INUNI','INU','Umetnost /ni/',NULL),(221,'INŠ2','Šport',1,92,0,NULL,'INŠ','Šport /ni/',NULL);

/*Table structure for table `tabpregleddela` */

DROP TABLE IF EXISTS `tabpregleddela`;

CREATE TABLE `tabpregleddela` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdUcitelj` int(10) DEFAULT NULL,
  `Leto` int(10) DEFAULT NULL,
  `Mesec` int(10) DEFAULT NULL,
  `PlaniraneUre` double DEFAULT NULL,
  `NerealiziraneUre` double DEFAULT NULL,
  `SolaVNaravi` int(10) DEFAULT NULL,
  `Izobrazevanje` double(24,2) DEFAULT NULL,
  `IzobrazevanjePD` double(24,2) DEFAULT NULL,
  `NadomescanjeRU` double(24,2) DEFAULT NULL,
  `NadomescanjeOPB` double(24,2) DEFAULT NULL,
  `Dezurstva` double(24,2) DEFAULT NULL,
  `SpremstvaDD` double(24,2) DEFAULT NULL,
  `SpremstvaPD` double(24,2) DEFAULT NULL,
  `GovUreD` double(24,2) DEFAULT NULL,
  `GovUreP` double(24,2) DEFAULT NULL,
  `RodSest` double(24,2) DEFAULT NULL,
  `Inventura` double(24,2) DEFAULT NULL,
  `DezurstvoP` double(24,2) DEFAULT NULL,
  `ObcasniTimi` double(24,2) DEFAULT NULL,
  `SolTekme` double DEFAULT NULL,
  `Komisije` double(24,2) DEFAULT NULL,
  `BralnaZnacka` double(24,2) DEFAULT NULL,
  `DelSestanki` double(24,2) DEFAULT NULL,
  `NivojskiSestanki` double(24,2) DEFAULT NULL,
  `Zpz` double(24,2) DEFAULT NULL,
  `DezurstvoMalice` double(24,2) DEFAULT NULL,
  `KoriscenDopust` int(10) DEFAULT NULL,
  `Predure` double(24,2) DEFAULT NULL,
  `NerealiziranePU` double(24,2) DEFAULT NULL,
  `NerealiziraneOPB` double(24,2) DEFAULT NULL,
  `Interesne` double(24,2) DEFAULT NULL,
  `CasVnosa` timestamp NULL DEFAULT NULL,
  `IdVnosa` varchar(15) DEFAULT NULL,
  `KomentUcitelja` text,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdUcitelj` (`IdUcitelj`),
  KEY `IdVnosa` (`IdVnosa`)
) ENGINE=InnoDB AUTO_INCREMENT=1125 DEFAULT CHARSET=utf8;

/*Data for the table `tabpregleddela` */

insert  into `tabpregleddela`(`Id`,`IdUcitelj`,`Leto`,`Mesec`,`PlaniraneUre`,`NerealiziraneUre`,`SolaVNaravi`,`Izobrazevanje`,`IzobrazevanjePD`,`NadomescanjeRU`,`NadomescanjeOPB`,`Dezurstva`,`SpremstvaDD`,`SpremstvaPD`,`GovUreD`,`GovUreP`,`RodSest`,`Inventura`,`DezurstvoP`,`ObcasniTimi`,`SolTekme`,`Komisije`,`BralnaZnacka`,`DelSestanki`,`NivojskiSestanki`,`Zpz`,`DezurstvoMalice`,`KoriscenDopust`,`Predure`,`NerealiziranePU`,`NerealiziraneOPB`,`Interesne`,`CasVnosa`,`IdVnosa`,`KomentUcitelja`) values (475,115,2007,8,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2007-08-31 08:40:07','osnovni',''),(476,116,2007,8,0,0,0,0.00,0.00,2.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2007-08-31 12:27:33','avelkavrh','Ni upoštevana 1 PU'),(477,92,2007,9,0,0,0,3.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-05 10:11:57','avelkavrh',''),(478,29,2007,9,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-05 09:41:07','avelkavrh',''),(479,26,2007,9,0,0,0,3.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 07:47:06','avelkavrh','2 uri za sestavo nivojskih skupin za matematiko, slovenščino in angleščino\r\n15 min. - izr. sest. 8.a\r\n15 min. - izr. sest. Maša Zadravec\r\n1 ura za aktiv-MAT'),(480,107,2007,9,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-19 11:45:45','admin',''),(481,79,2007,9,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,4,0.00,0.00,0.00,0.00,1.50,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:44:34','avelkavrh','Tekmovanje iz logike:\r\n2 uri - nadzor\r\n2 uri - popravljanje nalog\r\nIzredni sestanki:(popravek prejšnjega vnosa)\r\n15 min - Matija Škofljanec  7d\r\n15 min - za oddelek 8a\r\n1 ura - aktiv MAT'),(482,102,2007,9,0,0,0,2.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-24 09:23:33','tancnik',''),(483,108,2007,9,0,0,0,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,90.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 12:34:40','avelkavrh','Utemeljitev:\r\nDrugo: 15 ur - razredništvo, 1 ura mesečno - aktiv TJA\r\nObčasni timi: \r\n1. Maša Gruden (IP), \r\n3 ure - mediacija'),(484,106,2007,9,0,0,0,0.00,0.00,0.00,60.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 10:53:09','tancnik','\r\n\r\n\r\n'),(485,53,2007,9,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-27 22:33:26','mmalensek',''),(486,66,2007,9,0,0,0,2.00,0.00,12.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 10:58:31','tancnik',''),(487,23,2007,9,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,90.00,0.00,'2007-11-07 09:48:43','tancnik',''),(488,51,2007,9,0,0,25,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,17.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 09:44:09','avelkavrh','2 uri - izr. rod sest.\r\n15 ur za razredne ure\r\n2-ozvočenje sprejem prvošolcev'),(489,112,2007,9,0,0,0,0.00,0.00,0.00,50.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-25 17:58:54','mrupnik',''),(490,77,2007,9,0,0,0,4.00,0.00,0.00,460.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,95.00,0.00,'2007-09-25 18:13:36','npraznik',''),(491,56,2007,9,0,0,0,0.00,0.00,0.00,90.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-25 19:10:08','imargan',''),(492,105,2007,9,0,0,0,3.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:51:45','avelkavrh','3 ure - mediacija\r\n1 ura - aktiv SLO'),(493,76,2007,9,0,0,0,0.00,0.00,0.00,0.00,180.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-26 08:20:13','rpodborsek','24.9.07 svet staršev od 17.45 do 20.45'),(494,84,2007,9,0,0,30,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,16.75,0.00,0,0.00,0.00,0.00,0.00,'2008-07-04 13:04:51','avelkavrh','15 ur razredništva\r\n1,75- priprava športnih rekvizitov za Pacug:goli za vatepolo'),(495,16,2007,9,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-26 12:43:25','bdekleva',''),(496,101,2007,9,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:31:21','tancnik',''),(497,78,2007,9,0,0,0,0.00,0.00,51.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,37.00,0.00,0.00,'2007-11-07 10:58:29','tancnik',''),(498,60,2007,9,0,0,0,3.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,2.00,0.00,0.00,'2007-11-14 08:03:49','avelkavrh','3 ure - mediacija\r\nVsak teden pridem v razred pol ure prej zaradi razredne ure v 4.a.'),(499,11,2007,9,0,0,0,0.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.50,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:51:09','avelkavrh','drugo delo -15 ur za razredne ure,\r\nobčasni timi: evalvacija mediacije 1h15min, aktiv 1h, evalv. sesta. Marko Borovnjak 15min'),(500,44,2007,9,0,3,0,0.00,0.00,0.00,0.00,180.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-12 11:09:46','rpodborsek','24.9.2007 svet staršev, 17.45 do 20.45\r\n28.9.2007, koristila od 7.00 do 10.00 ure'),(501,63,2007,9,0,0,0,0.00,0.00,2.00,820.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,3,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 11:08:56','tancnik','15 ur za razredništvo'),(502,83,2007,9,0,0,0,0.00,0.00,12.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,0.00,0.00,'2007-10-24 12:23:55','avelkavrh','sestanek za Marka Borovnjaka; sestanek za 8.a'),(503,57,2007,9,0,0,0,5.00,0.00,1.00,970.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-03 22:40:33','pmavsar',''),(504,8,2007,9,0,3,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2007-11-05 11:49:52','admin','2,5 ure za svet staršev\r\n-3 DU, ker je bilo nadomeščanje med del. časom. '),(505,67,2007,9,0,0,0,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,3.00,0,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,'2007-11-14 07:31:07','avelkavrh','3 ure - mediacija'),(506,72,2007,9,0,4,0,11.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,18.50,0.00,0,0.00,0.00,0.00,0.00,'2008-07-02 13:12:09','avelkavrh','15 ur - razredništvo\r\n1 ura - aktiv SLO\r\n2 uri - svet staršev\r\n11 ur - mreža'),(507,47,2007,9,0,0,0,3.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-28 08:01:29','zlavbicsaje','izredni dopust ob smrti v družini'),(508,98,2007,9,0,0,0,0.00,0.00,15.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,28.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-25 13:08:49','avelkavrh','28 ur - lanski dopust'),(509,35,2007,9,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-24 12:11:34','avelkavrh',''),(510,58,2007,9,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-28 10:53:43','amedic',''),(511,43,2007,9,0,0,0,0.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,2,0.00,6.00,0.00,0.00,'2007-11-05 15:14:36','avelkavrh','Ne vem, ali se studijski dopust - ministrov dan steje pod koriscen dopust?'),(512,86,2007,9,0,0,0,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-28 11:47:29','msrsa','7- izobraževanje po 13. uri,3- svet staršev 24.9.2007'),(513,73,2007,9,0,0,0,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.50,0.00,0,0.00,0.00,0.00,0.00,'2007-12-17 12:14:13','avelkavrh','predavanje za devete razrede o izbiri poklica\r\n3 ure - mediacija'),(514,6,2007,9,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-09-28 14:33:10','obergant',''),(515,62,2007,9,0,0,0,3.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 13:13:42','avelkavrh','3 ure - mediacija'),(516,26,2007,10,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,11,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,8.00,0.00,0.00,'2007-11-07 07:47:52','avelkavrh','8 ur - obrazložitev:  2 uri - nadzor v razredu; 2 uri - popravljanje izdelkov; 4 ure - priprava tekmovanja (bilo jih je še več)\r\n3 ure - državno tekmovanje\r\n1 ura - izr. ped. konf.\r\n1 ura za aktiv-MAT'),(517,1,2007,9,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-03 11:11:24','sancnik',''),(518,37,2007,10,0,0,0,2.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,3,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,3.00,0.00,0.00,'2007-11-07 07:43:16','avelkavrh','3 ure drž tekm.\r\n1 ura za aktiv-MAT'),(519,46,2007,10,0,0,0,0.00,0.00,3.00,60.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-24 09:36:08','tancnik',''),(520,5,2007,9,0,0,0,3.50,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-03 12:50:11','bbartol','občasni timi: aktiv, evalv. sest.Dorijan Kogovšek'),(521,81,2007,9,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.75,2,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,1.00,0.00,0.00,'2007-10-25 14:01:07','avelkavrh','3 evalvacijski sestanki B. Bilič, M. Zadravec, M. Borovnjak, 2 uri - nadzor šolsko tekmovanje logika, 15 ur - razredne ure'),(522,97,2007,10,0,0,0,2.00,0.00,3.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,6.00,0.00,0.00,'2007-11-14 07:59:30','avelkavrh','1 ura - aktiv TJA\r\n2 x 15 min = 0,5 ure - izredna pedagoška konferenca (22. 10.) in izreden sestanek za podaljevanje statusov (15. 10.)\r\n2 uri - mediacija'),(523,75,2007,10,0,0,30,17.00,0.00,2.00,135.00,0.00,10.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:40:52','avelkavrh','15 ur - razredništvo\r\n1 ura - izredna ped. konf 22. 10.\r\n16 ur - izobraževanje 26. in 27. 10.'),(524,30,2007,10,0,0,30,1.00,16.00,0.00,0.00,0.00,3.50,0.00,0.00,0.00,2.00,0.00,0.00,0.00,3,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,1.00,0.00,0.00,'2007-11-14 08:06:49','avelkavrh','15 ur - razredništvo\r\n2 uri izr. rod. sestanek;\r\n3 ure - tekmovanje iz logike \r\n16 ur - izobraževanje 26. in 27. 10.'),(525,4,2007,9,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,120.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 15:59:59','avelkavrh','aktiv slavistov - 1\r\nsestanek za B. Stojanovića - 0,25'),(526,97,2007,9,0,0,0,3.00,11.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.75,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-14 07:58:36','avelkavrh','Občasni timi -> 3 x 15 minut sestanek oddelčnega učiteljskega zbora za učence: Matijo Škofljana, Mašo Zadravec in Bruna Bilića. K temu še 1 ura za dejavnosti aktiva anglistov.\r\n\r\nDelovne in druge obveznosti, ki se štejejo za opravljene ure dela: 15 ur letno za razredništvo.\r\n\r\n3 ure - mediacija'),(527,87,2007,9,0,0,30,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 15:00:17','avelkavrh','15- ur razredništvo'),(528,42,2007,9,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-24 13:42:42','avelkavrh',''),(529,84,2007,10,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:46:40','avelkavrh','dopust za otroka??!!\r\n22.11. - izr. ped konf.'),(530,43,2007,10,0,0,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-22 11:11:41','skrapez',''),(531,118,2007,9,0,0,0,0.00,0.00,23.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:14:18','tancnik',''),(532,9,2007,10,0,0,0,2.00,16.00,0.00,30.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,3.5,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:43:44','tancnik','22.10. izredna konferenca'),(533,34,2007,10,0,0,0,2.00,0.00,0.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,3.5,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:18:26','tancnik','22. 10. izrdna konferenca'),(534,16,2007,10,0,0,0,2.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:06:06','tancnik','2 uri JV, 26.10.izredna konferenca, 22.10.'),(535,96,2007,10,0,0,0,2.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:42:51','tancnik','22.10. izredna konferenca'),(536,52,2007,10,0,0,0,2.00,0.00,0.00,450.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:45:45','tancnik','22.10. izredna konferenca'),(537,70,2007,10,0,0,0,2.00,0.00,0.00,90.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:44:36','tancnik','22.10. izredna konferenca'),(538,1,2007,10,0,0,0,2.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:02:05','tancnik','izredna konferenca,22.10.'),(539,28,2007,10,0,0,0,2.00,16.00,0.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:41:40','tancnik','22. 10. izredna konferenca'),(540,56,2007,10,0,0,0,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:04:58','tancnik','Prosim ce popravite dan opravljanja str. izpiti, ker je navedeni dandan, ko sem diplomiral, str. izpita pa še nimam. Hvala\r\n1 ura JV, 26.10.'),(541,21,2007,10,0,0,0,2.00,16.00,1.00,580.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:39:10','tancnik','22.10. izredna konferenca'),(542,53,2007,10,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,1,0.00,6.00,0.00,0.00,'2007-11-05 15:15:37','avelkavrh','5 ur /15 ur za razredništvo - (1/3 ur) za izplačilo + 1 ura nadom.'),(543,64,2007,10,0,0,0,2.00,16.00,0.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,40.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:39:56','avelkavrh','izredna konferenca,22.10.\r\n16 ur - izobraževanje 26. in 27. 10.'),(544,77,2007,10,0,0,0,2.50,0.00,4.00,400.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,2.00,95.00,0.00,'2007-11-07 09:10:29','tancnik','2,5 ure - priprava na kostanjev piknik.izredna konferenca, 22.10.'),(545,16,2007,3,0,0,0,2.00,0.00,2.00,0.00,0.00,3.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-23 08:33:22','bdekleva','3 polne ure za izdelovanje buč in razstavo po pouku in 2 uri za jutranje varstvo'),(546,8,2007,10,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,0.00,0.00,0.00,'2007-10-30 08:13:21','mbernotsotensek','2,5 ure pedagoška konferenca 18.10.\r\n1 ura izredna pedagoška konfernca 22.10.'),(547,33,2007,10,0,0,0,2.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:19:18','tancnik','izredna konferenca, 22. 10.'),(548,39,2007,10,0,0,0,0.00,16.00,0.00,130.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:30:31','tancnik','izredna konferenca, 22. 10.'),(549,102,2007,10,0,0,0,0.00,16.00,0.00,0.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:35:36','tancnik','2,5 za pripravo na kostanjev piknik\r\n22.10. izrdna konferenca'),(550,80,2007,10,0,0,0,2.00,0.00,0.00,500.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:37:33','tancnik','V letni doprinos ste poleg ur, ki jih moramo nadomestiti všteli tudi 30 minut za malico na dan. Kako boste pri doprinašanju teh 30 minut upoštevali? Ali 250 minut dela v OPB pomeni 8 delovnih ur?\r\n1 ura izredna konferenca, 22.10.'),(551,111,2007,10,0,0,0,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,50.00,0.00,'2007-11-07 09:20:38','tancnik','Izobraževanje 16 ur: Korzika. Občasni timi...: 1 ura konferenca 22. 10. Delovne in druge obveznosti...: 2,5 ure priprava za kostanjev piknik, 2,5 ure teden otroka - igraj se z mano.\r\n'),(552,85,2007,10,0,0,0,2.00,0.00,0.00,65.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,60.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:34:03','tancnik','1 ura JV, izredna konferenca, 22.10.'),(553,35,2007,10,0,0,0,0.00,16.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2007-11-05 10:07:16','avelkavrh','Izredna konferenca 22. 10.\r\n16 ur - izobraževanje 26. in 27. 10.'),(554,83,2007,10,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,3,0.00,0.00,0.00,0.00,30.00,0.00,0,0.00,9.00,0.00,10.00,'2007-10-27 07:30:50','psimcic','izredna konferenca, 22. 10.; 30 ur - prenos iz lanskega leta'),(555,11,2007,10,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,6.00,0.00,0.00,'2007-10-24 13:05:03','avelkavrh','22. 10. izredna konferenca\r\n1 ura - aktiv\r\n'),(556,42,2007,10,0,0,0,0.00,16.00,15.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-05 09:58:59','avelkavrh','16 ur - izobraževanje 26. in 27. 10.'),(557,10,2007,10,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,160.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-24 14:03:21','avelkavrh','160 ur - 20 dni lanskega dopusta'),(558,60,2007,10,0,0,0,4.50,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-14 09:21:23','avelkavrh','16 ur - izobraževanje 26. in 27. 10.\r\n1 ura izredna konferenca\r\n2 - uri mediacija\r\n2,5 ure - pollen'),(559,108,2007,10,0,0,0,2.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,7.00,0.00,0.00,'2007-11-28 12:34:06','avelkavrh','Aktiv TJA - oktober 1DU\r\n10.10.-Avbelj Gašper\r\n1 ura - izr. ped. konf\r\n2 uri - mediacija'),(560,57,2007,10,0,0,0,0.00,16.00,1.00,1005.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:37:59','avelkavrh','5. 10. eval. sest. za učenca G. Petriča od 7.30 do 8.00, izredna konferenca\r\n16 ur - izobraževanje 26. in 27. 10.'),(561,86,2007,10,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,0.00,0.00,0.00,'2007-10-25 10:44:55','msrsa','Pedagoška konferenca, 18.10.2007, 2,5 ure\r\nIzredna pedagoška konferenca,22.10.2007, 1 ura'),(562,98,2007,10,0,0,0,4.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-25 13:08:16','avelkavrh','15 ur - razredništvo\r\n1 ura - izr. ped 22. 10.'),(563,81,2007,10,0,0,0,3.00,0.00,8.00,220.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,8.00,0.00,0.00,'2007-10-25 14:05:53','avelkavrh','1 - izr. ped konf. 22.10.'),(564,66,2007,10,0,0,0,0.00,0.00,7.00,55.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 10:57:55','tancnik','2,5 ure smo porabili za pripravo na kostanjev piknik.\r\n1 ura za izredno konferenco'),(565,112,2007,10,0,0,0,4.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2007-10-25 18:12:43','mrupnik','delovne in druge obveznosti: 2.5h - kostanjev piknik; 2,5h teden otroka; občasni titmi;1 ura- izredni sestanek učiteljskega zbora'),(566,63,2007,10,0,0,0,0.00,16.00,2.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:39:14','avelkavrh','22.10. izredna konferenca\r\n16 ur - izobraževanje 26. in 27. 10.'),(567,23,2007,10,0,0,10,2.50,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:54:09','tancnik','Prosim, ce izbrisete 3 nerealizirane pu, ker sem se zmotila. Hvala!!!\r\n3 ure kostanjev piknik plus plakat\r\n22.10. izredna konferenca'),(568,78,2007,10,0,0,0,0.00,0.00,15.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,4.00,0.00,0.00,'2007-11-07 10:58:11','tancnik','kostanjev piknik\r\n22.10. izredna konferenca'),(569,38,2007,10,0,0,0,0.00,0.00,8.00,0.00,0.00,4.50,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 11:22:19','tancnik','izredna konferenca, 22.10.'),(570,6,2007,10,0,0,0,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,0.00,0.00,0.00,'2007-10-30 09:01:08','obergant','2,5 ure pedagoška konferenca 18.10.\r\n1 ura izredna pedag. konferenca 22.10.'),(571,73,2007,10,0,10,0,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,0.00,0.00,0.00,'2007-12-17 12:16:46','avelkavrh','Konferenca 18.10. od 15:30-18:00 in 22.10. od 16-17\r\n2 uri - mediacija\r\n22. 10.  - izr. ped. konf'),(572,29,2007,10,0,0,0,0.00,0.00,0.00,495.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 11:03:18','tancnik','1 ura - izr. ped. konf. 22. 10.'),(573,4,2007,12,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,200.00,0.00,0.00,1.00,0.00,0,0.00,1.00,0.00,0.00,'2008-03-06 21:31:53','avelkavrh','1 ura - aktiv SLO'),(574,4,2007,11,0,0,0,5.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,200.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:31:42','avelkavrh','1 ura - akriv SLO'),(575,51,2007,12,0,0,0,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 22:02:32','avelkavrh','3- Mreža2\r\n4-ozvočenje'),(576,30,2007,12,0,0,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 22:01:37','avelkavrh',''),(577,62,2007,10,0,0,0,11.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,8.00,0.00,0.00,'2008-05-08 07:10:20','avelkavrh','2 uri - mediacija\r\n1 ura - 22.10 izr. konf\r\n8 ur - 19.10. - izobraževanje na PeF'),(578,37,2007,11,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,15.00,0.00,0.00,'2007-12-07 13:35:50','avelkavrh','29.11. - Veronika P.\r\n1 ura - aktiv MAT'),(579,87,2007,11,0,0,0,3.00,0.00,2.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,14.00,0.00,0.00,'2008-05-21 13:08:40','avelkavrh','29.11. - Veronika P.'),(580,26,2007,11,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,4.00,0.00,0.00,'2007-12-07 13:33:09','avelkavrh','20.11. - sest. za 8.a\r\n2 uri - urnik II. polletje \r\n1 ura - aktiv MAT\r\n15 min-izr.sest.Bruno B.'),(581,58,2007,10,0,0,0,0.00,0.00,7.00,0.00,0.00,25.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 11:00:11','tancnik',''),(582,37,2007,9,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,5,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 07:44:42','avelkavrh','2 uri nadzor v razredu\r\n3 ure popravljanje\r\n1 ura za aktiv-MAT\r\n1 ura izr. ped. konf.'),(583,118,2007,10,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 09:16:44','tancnik','2,5 ur za kostanjev piknik, 2,5 ur za teden otroka, 1 ura za izrdno konferenco 22. 10.'),(584,51,2007,10,0,0,0,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 10:25:59','avelkavrh','16 ur - izobraževanje 26. in 27. 10.\r\n1 ura izr. ped. konf'),(585,106,2007,10,0,0,0,0.00,0.00,4.00,0.00,0.00,11.30,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,3.00,'2007-11-07 10:52:24','tancnik','Šmarna gora-02. 10. -4h\r\nTeden otroka - 03.10 -3h30min.\r\nŽival. vrt - 11. 10.-4h\r\nKostanj.piknik- 12.10. 2,5h\r\n1 ura izredna konferenca, 22.10.'),(586,17,2007,9,0,0,30,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-07 10:54:16','avelkavrh','15 ur - razredništvo'),(587,17,2007,10,0,0,20,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.25,0.00,0,0.00,1.00,0.00,0.00,'2007-11-26 13:57:25','avelkavrh','22.10. - izr. ped. konf\r\n15 min - Maša Zadravec'),(588,65,2007,10,0,0,0,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 10:47:19','tancnik','izredna konferenca, 22.10.\r\n15 ur razredništvo'),(589,50,2007,9,0,0,0,0.00,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 11:27:02','tancnik',''),(590,50,2007,10,0,0,0,0.00,0.00,0.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 11:27:31','tancnik','2,5 kostanjev piknik; izredna konferenca'),(591,101,2007,10,0,0,10,0.00,16.00,0.00,500.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 11:33:59','avelkavrh','izredna konferenca'),(592,92,2007,11,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:44:06','avelkavrh',''),(593,92,2007,10,0,0,0,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:43:09','avelkavrh','16 ur - izobraževanje 26. in 27. 10.'),(594,104,2007,9,0,0,0,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:45:51','avelkavrh','3 ure - izobraževanje'),(595,104,2007,10,0,0,0,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-08 12:46:16','avelkavrh','16 ur - izobraževanje 26. in 27. 10.'),(596,73,2007,11,0,3,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-17 12:28:31','avelkavrh','6.11.(1 ura)- seminar vzg.načrt šole\r\n13.11.konferenca (3 ure)\r\n16.11.2007 od 9.00 do 10.30 ure\r\n23.11.2007 od 9.00 do 10.30 ure\r\n3 ure - mediacija\r\n28.11.- CSD (Borovnjak)'),(597,105,2007,10,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.25,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 08:01:24','avelkavrh','2 uri - Rokus\r\n2 uri - mediacija\r\n1 ura - aktiv SLO\r\n22.10. izr. ped konf. \r\n0,25 - Maša Gruden'),(598,67,2007,10,0,0,0,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-14 07:31:38','avelkavrh','2 uri - mediacija'),(599,100,2007,9,0,0,0,3.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 13:21:57','avelkavrh','3 ure - mediacija\r\n26.9.-B.B\r\n18.9.-M.Bor.'),(600,100,2007,10,0,0,0,2.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2007-12-19 13:41:02','avelkavrh','2 uri- mediacija'),(601,4,2007,10,0,0,0,2.00,16.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,1.00,0.00,0,0.00,8.00,0.00,0.00,'2008-03-06 21:31:23','avelkavrh','2 uri  - izob. rokus\r\n1 ura  - aktiv SLO\r\n16 ur - izobraževanje 26. in 27. 10.'),(602,16,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,13.15,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 14:05:41','bdekleva','Pregled in predlogi za posodobitev učnih načrtov'),(603,52,2007,11,0,0,0,0.00,0.00,0.00,250.00,0.00,28.00,0.00,0.00,0.00,0.00,0.00,0.00,4.00,0,0.00,180.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 08:08:51','tancnik','Razredništvo, 4 ure Mreža UN'),(604,70,2007,11,0,0,0,0.00,0.00,0.00,450.00,0.00,22.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 08:55:21','tancnik','razredništvo, 4 ure Mreža UN'),(605,96,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 08:57:34','tancnik','razredništvo, 4 ure Mreža UN'),(606,78,2007,11,0,0,0,1.50,0.00,25.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,7.00,0.00,'2007-11-22 12:39:19','spusnar',''),(607,85,2007,11,0,0,0,7.00,0.00,0.00,320.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:10:07','tancnik','razredništvo, 4 ure Mreža UN\r\nizobrazevanje - pollen'),(608,102,2007,11,0,0,0,0.00,0.00,8.00,0.00,0.00,7.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:11:37','tancnik',''),(609,64,2007,11,0,0,0,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,200.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:07:16','tancnik','izobraževanje - pollen\r\nrazredništvo, 4ure Mreža UN'),(610,98,2007,11,0,0,0,0.00,0.00,11.00,75.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:32:23','avelkavrh','Sestanek za 8.a trajal je 2 uri\r\n29.11. - Veronika P.'),(611,8,2007,11,0,6,0,0.00,0.00,6.00,0.00,0.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-29 12:56:55','avelkavrh','13.11.2007 pedagoška konferenca\r\n24.11.2007 državno tekmovanje iz znanja o sladkorni bolezni (Šempeter pri Gorici)'),(612,112,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,7.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,90.00,0.00,'2007-12-21 13:24:36','tancnik',''),(613,33,2007,11,0,0,0,4.00,0.00,0.00,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-23 14:03:03','pjerman','4 ure - pregled in predlogi za posodobitev UN, 15 ur - razredništvo = 19 ur'),(614,9,2007,11,0,0,0,7.00,0.00,0.00,0.00,0.00,16.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:50:07','tancnik','delovne obveznosti: 4 ure pregled in predlogi za posodobitev učnih načrtov, 15 ur razredništvo'),(615,63,2007,11,0,0,0,0.00,0.00,1.00,255.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 07:36:18','amohar',''),(616,56,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 14:41:20','imargan','Spremstvo otrok na plavanje (1 ura) in pregled predlogov posodobljenega učnega načrta (4 ure)'),(617,75,2007,11,0,0,0,7.00,0.00,0.00,45.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,95.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 14:56:01','avelkavrh','3 ure - Pollen, PeF3 \r\n4 ure - Pollen, PeF\r\n23.11. - izdelava smrečice\r\n'),(618,57,2007,11,0,0,0,0.00,0.00,2.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 12:28:21','avelkavrh',''),(619,43,2007,11,0,0,0,0.00,0.00,25.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 12:41:09','skrapez',''),(620,47,2007,10,0,0,0,4.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2007-11-26 13:34:02','avelkavrh','23.10. - študijska skupina\r\n22.10. izr. ped. konf'),(621,17,2007,11,0,0,0,0.00,0.00,4.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2007-11-26 14:44:51','avelkavrh',''),(622,60,2007,11,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 18:08:19','mmihelcic','Izobraževanje - Pollen'),(623,97,2007,11,0,0,0,6.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.25,1,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-07 13:39:16','avelkavrh','Občasni timi: izredni sestanek oddelčnega učiteljskega zbora (20. 11. 07 - Bruno Bilič)--> 2 uri\r\nŠolska tekmovanja: 26. 11. 07; angleško šolsko tekmovanje --> 1 ura\r\nDrugo: popravljanje testov za šolsko angleško tekmovanje --> 2 uri\r\n29.11. - Veronika P.\r\n1 ura aktiv TJA'),(624,80,2007,11,0,0,0,4.00,0.00,0.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-26 21:03:11','lrenko','22.11.07, 4 ure, Pollen\r\nv času plavalnega tečaja 10x15 min zjutraj in 7 ur pouka popoldne, skupaj 8 ur\r\nrazredništvo, 15 ur\r\npredlogi za posodobitev učnih načrtov MAT, 4 ure'),(625,77,2007,11,0,0,0,1.50,0.00,0.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,65.00,0.00,'2007-11-27 10:16:39','npraznik',''),(626,46,2007,11,0,0,0,3.00,0.00,6.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 13:13:49','mkump',''),(627,11,2007,11,0,3,0,4.00,0.00,6.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:51:29','avelkavrh','2 uri - pop. nalog, tekmovanje angl.\r\nštudijska skupina \r\n20.11. 4 ure\r\n1 ura - aktiv TJA\r\n'),(628,5,2007,10,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 13:20:30','avelkavrh','22. 11. - izr. ped. konf.'),(629,5,2007,11,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:19:58','avelkavrh','27.11. - Veronika P'),(630,67,2007,11,0,0,0,8.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.15,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-07 13:45:57','avelkavrh','5 ur - obč. aktiv\r\n3 ure - mediacija'),(631,47,2007,11,0,3,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,18.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 13:39:01','avelkavrh','10. 11.- debatni turnir (9 DU)\r\n29. 11.- debatni turnir (9 DU)'),(632,21,2007,11,0,0,0,4.00,0.00,0.00,0.00,0.00,15.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:17:13','tancnik','pregled in predlogi novega ucnega nacrta'),(633,39,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,15.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 14:06:19','sklemen','pregled in predlogi za posodobitev učnega načrta'),(634,34,2007,11,0,0,0,4.00,0.00,0.00,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 08:46:31','tancnik','15 ur razredništvo, 4 ure za pregled in predloge za posodobitev učnih načrtov'),(635,28,2007,11,0,0,0,0.00,0.00,0.00,385.00,0.00,22.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,19.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:53:03','tancnik','15 ur razredništvo, 4 ure mreža UN, 1 ura Šolski sklad'),(636,23,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 16:14:08','agrom','občasni timi 1 ura: sestanek šolskega sklada ob 7.15!!!'),(637,108,2007,11,0,0,0,7.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0.00,0.00,0.00,2,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 12:33:18','avelkavrh','Izobraževanje - mediacija (3 ure, študijska (4)\r\n2 uri tekmovanje in pop. TJA\r\n\r\nIzredni RS, 6.11., glej zapisnik oddelka    1, 5\r\n\r\nAktiv TJA - 1 '),(638,58,2007,11,0,0,0,0.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-27 20:12:25','amedic',''),(639,105,2007,11,0,0,0,8.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-07 13:43:46','avelkavrh','1 ura - aktiv SLO\r\n5 ur - obč aktiv\r\n3 ure - mediacija'),(640,76,2007,11,0,2,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 10:07:41','rpodborsek','27.11.2007, od 13.00 do 15.00 ure'),(641,83,2007,11,0,0,0,4.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 15:14:40','avelkavrh','4 ure- 15.11. DZS'),(642,62,2007,11,0,0,0,3.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 15:17:35','avelkavrh','3 ure - mediacija'),(643,30,2007,11,0,0,0,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-28 15:22:21','avelkavrh','6 ur - izdelava novoletnih smerečic'),(644,81,2007,11,0,0,0,0.00,8.00,7.00,0.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.25,1,0.00,0.00,0.00,0.00,9.50,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 14:31:16','avelkavrh','20.11. - izr sest.\r\n15.11. - pogovor z zderavnico ooddelku\r\n9 ur - raziskava Rok'),(645,10,2007,11,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,100.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-29 12:40:23','avelkavrh','4 ure - doprinos FI'),(646,35,2007,11,0,0,0,3.50,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-29 12:45:46','avelkavrh',''),(647,1,2007,11,0,0,0,0.00,0.00,0.00,55.00,0.00,22.00,0.00,0.00,0.00,0.00,0.00,0.00,4.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 08:11:13','tancnik','15 ur razredništvo, 4 ure Mreža UN'),(648,50,2007,11,0,0,0,0.00,0.00,18.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 11:28:27','tancnik',''),(649,29,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:04:28','tancnik','izredni sestanek 8.a'),(650,54,2007,9,0,0,30,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,1.00,0.00,0.00,'2008-05-20 08:07:58','avelkavrh','15 ur - razredništvo\r\n30 ur - ŠVN\r\n15 min - Avbelj\r\n15 min - Stojanović'),(651,54,2007,10,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,7.00,0.00,0.00,'2007-11-30 09:48:48','avelkavrh','22. 10 - izr. ped. konf.'),(652,54,2007,11,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 09:50:17','avelkavrh','15 min - Bilić'),(653,86,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:18:07','tancnik','13.11. - pedagoška konferenca'),(654,42,2007,11,0,0,0,0.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:34:09','avelkavrh','29.11. - Veronika P.'),(655,72,2007,11,0,5,0,8.25,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-10 13:19:47','avelkavrh','1 ura - aktiv SLO\r\nštudijska skupina (5 ur). Delovne obveznosti, tj. 3 navadne ure za izdelavo smrečice.'),(656,6,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:41:38','obergant','pedagoška konferenca, 13.11.2007 '),(657,72,2007,10,0,2,0,2.50,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-02 12:59:19','avelkavrh','22. 10 - izr. ped. konf.\r\n1 ura - aktiv SLO\r\n2,5 ure - Izob. Rokus'),(658,79,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:44:47','avelkavrh','1 ura - aktiv MAT'),(659,79,2007,10,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2007-11-30 11:43:53','avelkavrh','1 ura - aktiv\r\n22.11.- izr.ped. konf.'),(660,84,2007,11,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,8.00,0.00,0.00,'2007-12-07 14:17:16','avelkavrh','20.11. - B.B. '),(661,100,2007,11,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 13:48:28','avelkavrh',''),(662,87,2007,10,0,0,20,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,1.00,0.00,0.00,'2007-12-07 07:18:02','avelkavrh','22. 10. - izr. ped. konf.'),(663,97,2007,12,0,0,20,3.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 16:49:40','avelkavrh','3 -izdelava jelke\r\n3 - mreža 2\r\n1 - aktiv TJA'),(664,60,2007,12,0,0,0,4.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,13.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-21 10:15:47','tancnik','izobrazevanje -  seminar Pollen\r\n13 - novoletna okrasitev šole'),(665,8,2007,12,0,31,0,0.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,2,0.00,0.00,0.00,0.00,'2008-01-29 10:04:54','rpodborsek','27.12.2007-31.12.2007-3dni'),(666,73,2007,12,0,32,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-17 12:32:45','avelkavrh','24.12.-31.12.2007- 4dni\r\n4.12.- izr. sest. s starši (droge)\r\n18.12 - PF'),(667,76,2007,12,0,1,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-17 08:21:10','rpodborsek','14.12.2007, 14.00-15.00'),(668,86,2007,12,0,4,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 12:00:03','msrsa','24.12.2007, dopust\r\n18.12.2007, ped.konferenca'),(669,92,2007,12,0,32,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:27:33','avelkavrh','24.12.2007-31.12.2007-dopust\r\n4. 12.- izr.sest.droge'),(670,108,2007,12,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,4.00,0.00,0.00,'2008-01-13 15:22:28','avelkavrh','29.11. nerealizirana IU\r\nAktiv TJA 1 ura\r\n4.12. izredni RS (zapisnik, dnevnik 9.a)'),(671,1,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 07:55:46','sancnik','pregled in predlogi za posodobitev učnega načrta - ZZŠ'),(672,70,2007,12,0,0,0,0.00,0.00,0.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 10:37:29','tancnik',''),(673,96,2007,12,0,0,0,0.00,0.00,0.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 10:39:02','tancnik',''),(674,10,2007,12,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,460.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 11:03:14','avelkavrh',''),(675,65,2007,11,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 10:46:31','tancnik','Pregled in dopolnitev UN - mreža'),(676,65,2007,12,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 10:26:15','tnisavic','Razredništvo'),(677,106,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,2.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-18 13:54:31','tancnik','krasitev 5. 12 50 min.\r\nkulturni dan 6. 12.'),(678,84,2007,12,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 16:39:24','avelkavrh','4.12.-izr.rod.sest.\r\ndroga (1 ura)'),(679,105,2007,12,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 16:54:13','avelkavrh','15 ur-proslava\r\n1 ura-aktiv SLO'),(680,42,2007,12,0,0,20,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.25,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:26:04','avelkavrh','4.12.- sest. V. Pečar'),(681,64,2007,12,0,0,0,0.00,0.00,0.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 12:47:41','tancnik',''),(682,16,2007,12,0,0,0,0.00,0.00,1.00,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2007-12-21 13:09:48','tancnik',''),(683,63,2007,12,0,0,0,2.00,0.00,1.00,225.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 22:10:14','avelkavrh','3 ure - izdelava smreke\r\n2 uri izobraževanja - seminar Pamet je boljša kot žamet (MK)'),(684,29,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 13:19:06','tancnik','Učence sem peljala na predstavo Rdečega križa.'),(685,23,2007,12,0,0,0,0.00,0.00,0.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 11:54:25','agrom','6 ur barvanja stekel na sš z zimskimi motivi'),(686,28,2007,12,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 12:04:38','tancnik',''),(687,118,2007,12,0,0,0,0.00,0.00,2.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 13:07:38','tancnik','18.12.-spremstvo v Šentjakobsko gl.'),(688,9,2007,12,0,0,0,0.00,0.00,0.00,200.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 12:56:50','tbitenc','spremstvo 4 ure: nadomescanje bolniske v jutranjem varstvu'),(689,57,2007,12,0,0,0,2.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-19 13:43:03','pmavsar',''),(690,100,2007,12,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,0.00,0.00,'2008-01-13 16:46:39','avelkavrh',''),(691,46,2007,12,0,0,0,2.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,3.50,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 22:05:45','avelkavrh','3 - novoletna smrečica\r\n30 minut - likovna delavnica'),(692,37,2007,12,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,3.00,0.00,0.00,'2008-01-13 15:17:35','avelkavrh','1ura - aktiv MAT'),(693,26,2007,12,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:09:09','avelkavrh','1-aktiv\r\n4-delavnica 13.12.-izdelava čestitk'),(694,101,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 16:51:47','avelkavrh','2 - spremstvo učencev na božično pred. - RK'),(695,81,2007,12,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:06:39','avelkavrh','raziskovalna naloga Rok Sraka - eksperimentalno delo\r\n1 - izr. RS 4. 12.'),(696,102,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-25 10:31:02','bzavec',''),(697,21,2007,12,0,0,0,0.00,0.00,0.00,90.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 13:12:03','tancnik',''),(698,80,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,180.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 13:17:02','tancnik',''),(699,85,2007,12,0,0,0,0.00,0.00,0.00,110.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 13:18:22','tancnik',''),(700,111,2007,12,0,0,0,0.00,0.00,7.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-21 15:27:01','stursic','Delovne in druge obveznosti ... : 1 ura jutranjega varstva'),(701,38,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2007-12-28 20:12:19','tkavsek',''),(702,50,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:59:36','tancnik','1 ura krasitev šole'),(703,77,2007,12,0,0,0,0.00,0.00,0.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,1.00,0.00,0.00,'2007-12-21 13:26:19','tancnik','risanje na steklo na SŠ, okraševanje NŠ in SŠ'),(704,112,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,131.54,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:36:18','tancnik','vodena ročno zaradi specifike - del. raz. do 30 . 6. 2008'),(705,5,2007,12,0,5,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 11:00:14','avelkavrh',''),(706,11,2007,12,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-01-13 14:53:15','avelkavrh','1 - aktiv TJA'),(707,17,2007,12,0,0,0,0.00,0.00,14.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,9.00,0.00,0,0.00,3.00,0.00,0.00,'2008-01-25 11:37:27','avelkavrh','1 - izr. RS 4. 12.\r\n3 - spremstvo na zdr. pregled\r\n3 - nov. smrečice\r\n3 - izdelo9vanje novoletne smrečice'),(708,35,2007,12,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:13:53','avelkavrh','1 - spremstvo na zdr. preg.'),(709,43,2007,1,0,40,0,0.00,0.00,40.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:31:16','avelkavrh',''),(710,43,2007,12,0,35,0,0.00,0.00,40.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-30 20:43:23','avelkavrh',''),(711,53,2007,12,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,0.00,0.00,'2008-01-14 07:58:13','avelkavrh','4. 12.  - izr. RS'),(712,54,2007,1,0,0,20,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:57:52','avelkavrh',''),(713,54,2007,12,0,0,20,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 15:58:36','avelkavrh',''),(714,62,2007,12,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-01 12:57:02','avelkavrh',''),(715,67,2007,12,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-01-13 16:05:24','avelkavrh','1 - aktiv SLO'),(716,72,2007,12,0,5,0,3.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,7.00,0.00,0.00,'2008-01-13 16:19:33','avelkavrh','3 - mreža 2\r\n1 - aktiv SLO'),(717,79,2007,12,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,3.00,0.00,0.00,'2008-01-13 16:23:01','avelkavrh','1 - aktiv MAT'),(718,47,2007,12,0,0,0,2.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,12.00,0.00,0,0.00,4.00,0.00,0.00,'2008-01-13 16:34:19','avelkavrh','9 - spremstvo na debatni turnir\r\n3 - novoletna jelka'),(719,83,2007,12,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,6.00,0.00,0.00,'2008-01-13 16:37:32','avelkavrh','4 - spremstvo na tekmovanje'),(720,87,2007,12,0,0,20,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,1.00,0.00,0.00,'2008-05-21 13:08:54','avelkavrh','1 - izr RS 4.12.\r\n3 - izdelovanje smrečic'),(721,98,2007,12,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-01-13 16:59:41','avelkavrh','1 - 4.12.'),(722,6,2007,12,0,1,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 07:31:54','avelkavrh','3 - pedagoška konferenca'),(723,58,2007,12,0,0,0,0.00,0.00,3.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-13 22:09:23','avelkavrh',''),(724,105,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,3.00,0.00,0.00,'2008-02-04 22:17:37','avelkavrh','2 uri - Cankarjevo tkemovanje\r\n1 ura - aktiv'),(725,67,2007,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2,0.00,0.00,0.00,0.00,11.00,0.00,0,0.00,3.00,0.00,0.00,'2008-01-23 12:04:31','avelkavrh','1 - aktiv SLO\r\n2  Cankarjevo tekmovanje\r\n10 - popravljanje spisov'),(726,67,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2,0.00,0.00,0.00,0.00,11.00,0.00,0,0.00,3.00,0.00,0.00,'2008-02-04 22:00:43','avelkavrh','1 - aktiv SLO\r\n2 - tekmovanja Cank.\r\n10 - popravljanje tek.nalog'),(727,108,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,1.00,0.00,0.00,'2008-02-04 21:47:30','avelkavrh','15.1.timski sestanek Gašper Avbelj\r\n17.1. timski sestanek 8.b, Jelenko Vasić \r\nAktiv TJA'),(728,60,2008,1,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,3.00,0.00,0.00,'2008-02-04 21:59:08','avelkavrh',''),(729,63,2008,1,0,0,0,0.00,0.00,2.00,15.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-25 08:35:19','avelkavrh',''),(730,80,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,180.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-24 21:55:28','lrenko',''),(731,96,2008,1,0,0,0,0.00,0.00,0.00,550.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-25 07:32:25','avojska',''),(732,57,2009,1,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-25 08:33:19','avelkavrh',''),(733,46,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-25 08:35:54','avelkavrh',''),(734,87,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 23:00:15','avelkavrh','16 ur - Pacug (sobota, nedelja)'),(735,98,2008,1,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:18:51','avelkavrh','nadzor tekmovanja iz kemije 1 ura'),(736,17,2008,1,0,0,0,0.00,16.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,23.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 22:59:15','avelkavrh','16 - ljudski plesi sem.\r\n7 ur - inventura\r\n16 ur - Pacug (sobota, nedelja)'),(737,1,2008,1,0,0,10,0.00,0.00,0.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-25 13:10:52','sancnik',''),(738,101,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,3.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:14:16','avelkavrh','področni aktiv specialnih pedagogov;\r\n2 PU - Mihajlo'),(739,72,2008,1,0,5,0,0.00,0.00,5.00,0.00,60.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,1.00,0.00,0.00,'2008-07-02 13:03:45','avelkavrh','1 - aktiv SLO\r\n'),(740,97,2008,1,0,0,0,1.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,3.00,0.00,0.00,'2008-02-04 22:13:17','avelkavrh','15. 1. 08 --> Sestanek razrednega učiteljskega zbora za Gašperja Avblja.\r\n7 ur - inventura'),(741,78,2008,1,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,13.00,0.00,0,0.00,2.00,0.00,0.00,'2008-01-29 08:45:02','tancnik','13 ur - okraševanje šole v decembru'),(742,66,2008,12,0,0,0,0.00,0.00,3.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 11:03:25','tancnik','3 ure - okraševanje šole'),(743,23,2008,1,0,0,0,0.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.50,0.00,0,0.00,0.00,0.00,0.00,'2008-02-01 08:25:59','tancnik','7. 1. predstavitev izbirnih predmetov 0,5 ure; INVENTURA 7 UR'),(744,16,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,340.00,0.00,'2008-01-29 08:46:59','tancnik',''),(745,30,2008,1,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,250.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 16:41:05','ejalsovec',''),(746,77,2008,1,0,0,0,0.00,0.00,0.00,420.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-28 19:21:13','npraznik',''),(747,52,2008,1,0,0,10,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 07:49:57','bmacek',''),(748,29,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,10.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-01 08:26:50','tancnik','Območni aktiv na OŠ Stična - 23.1.\r\nInventura - 7 ur'),(749,28,2008,1,0,0,10,6.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 08:24:40','tancnik',''),(750,70,2008,1,0,0,10,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 08:29:07','tancnik',''),(751,9,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,14.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 08:32:25','tancnik','14 ur - individualna pomoč'),(752,39,2008,1,0,0,0,0.00,0.00,17.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,35.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-01-29 12:51:25','tancnik',''),(753,102,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,10.50,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-31 16:35:38','bzavec',''),(754,65,2008,1,0,0,10,0.00,0.00,0.00,375.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:25:03','tancnik',''),(755,38,2008,1,0,0,0,0.00,0.00,17.00,0.00,0.00,2.75,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 11:40:38','tkavsek',''),(756,8,2008,1,0,7,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,1,0.00,0.00,0.00,0.00,'2008-02-04 22:21:20','avelkavrh','31.1.08 od 7.00 do 9.00 in 14.1. od 14.00 do 15.00\r\n30.1. pedagoška konferenca 2 uri'),(757,11,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,6,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:52:23','avelkavrh','28.1. - pazila na šolskem tekmovanju iz kemije;\r\n24.1. spremstvo na državno tekmovanje iz angleščine, sodelovanje pri tekmovanju in popravljanje nalog državnega tekmovanja: odhod iz šole 12.45, prihod 18.30 (otroke so prišli iskat starši)\r\n1 - aktiv TJA'),(758,118,2008,1,0,0,0,4.00,0.00,14.00,50.00,0.00,2.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,305.00,0.00,'2008-01-29 11:59:17','tancnik',''),(759,66,2008,1,0,0,0,0.00,0.00,7.00,60.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,14.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 11:23:48','tancnik','3 ure - okraševanje šole v decembru\r\n7 ur - inventura, 4 ure Študijska'),(760,56,2008,1,0,0,0,0.00,0.00,135.00,520.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-29 12:36:54','imargan',''),(761,21,2008,1,0,0,0,0.00,0.00,1.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-30 13:32:51','tancnik','4 ure - JV'),(762,85,2008,1,0,0,0,2.00,0.00,0.00,460.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-30 11:01:06','tancnik',''),(763,35,2008,1,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-30 11:11:59','tancnik',''),(764,111,2008,1,0,0,0,0.00,0.00,21.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-30 12:44:02','tancnik',''),(765,26,2008,1,0,0,0,1.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,1.00,0.00,0.00,'2008-02-04 21:39:56','avelkavrh','1-aktiv\r\n2,5-urnik'),(766,6,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-31 08:44:34','obergant','Ocen. in pedagoška konferenca, 30.1.08'),(767,73,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-31 09:48:04','rpenezor','redovalna konferenca'),(768,86,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-01-31 11:20:43','tancnik','9.1. - 1ura kolegij, 28.1. - 2 uri konferenca\r\n30.1. - 2 uri konferenca'),(769,81,2008,1,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,7,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:06:28','avelkavrh','sestanek J. Vasić 17. 1., šolsko tekmovanje iz kemije 28. 1. (7 ur - priprava in popravljanje nalog), novoletna smreka 1 ura'),(770,43,2008,1,0,8,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-15 10:27:22','avelkavrh','7ur - inventura'),(771,54,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,23.00,0.00,0,0.00,1.00,0.00,0.00,'2008-02-06 22:57:33','avelkavrh','7 ur - inventura\r\n16 ur - Pacug (sobota, nedelja)'),(772,79,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 15:50:33','avelkavrh','7ur - inventura'),(773,13,2008,1,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 15:54:49','avelkavrh','1 ura- inventura'),(774,37,2008,1,0,0,0,2.00,6.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,2.00,0.00,0.00,'2008-02-04 21:46:12','avelkavrh','1 ura - inventura\r\n1 ura - aktiv MAT'),(775,4,2008,1,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,200.00,0.00,0.00,1.00,0.00,0,0.00,4.00,0.00,0.00,'2008-03-06 21:32:04','avelkavrh','1 ura - aktiv SLO'),(776,5,2008,1,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 21:21:14','avelkavrh',''),(777,10,2008,1,0,0,0,8.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,735.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-02-04 21:31:36','avelkavrh',''),(778,42,2008,1,0,0,0,0.00,0.00,1.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,1,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 21:50:28','avelkavrh','1 ura - varovanje na tekmovanju iz kemije'),(779,53,2008,1,0,0,0,0.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 19:59:49','avelkavrh','11 ur - Matic je OGL z dovoljenjem ravn. individualiziral za 2 učenca'),(780,62,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-04-01 12:58:56','avelkavrh',''),(781,47,2008,1,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-02-04 22:09:07','avelkavrh','8 ur - sremstvo na debatni turnir'),(782,84,2008,1,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,4.00,0.00,0.00,'2008-02-06 22:58:27','avelkavrh','16 ur - Pacug (sobota, nedelja)'),(783,100,2008,1,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.50,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-26 12:30:48','avelkavrh','6 ur - beneške maske'),(784,83,2008,2,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,31.00,0.00,0.00,'2008-03-17 07:02:42','avelkavrh','izredni sestanek za Jana Horvata - 26. 2. 08 od 13.30 do 14.30'),(785,92,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:23:35','avelkavrh',''),(786,92,2008,1,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:23:10','avelkavrh',''),(787,57,2008,2,0,0,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-28 14:25:48','pmavsar',''),(788,58,2008,1,0,0,0,0.00,0.00,3.00,0.00,0.00,1.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-04 22:27:28','avelkavrh',''),(789,50,2008,1,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-06 11:34:32','tancnik',''),(790,76,2008,2,0,1,0,0.00,0.00,0.00,0.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 09:08:57','rpodborsek','28.2.2008 koristila 1 uro od 14.00 do 15.00 \r\nSVET STARŠEV-11.2.2008 od 18.00 do 20.30 '),(791,73,2008,2,0,4,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-02-26 08:24:47','rpenezor','13.2.2008, od 7.00 do 10.00 ure\r\n14.2.2008 od 14.00 do 15.00 ure;4,5= svet staršev + vpis v 1. razred'),(792,26,2008,2,0,0,0,4.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,3.50,0.00,0,0.00,1.00,0.00,0.00,'2008-03-06 21:44:30','avelkavrh','1 ura-26.2.evalv.s.J.H.\r\n11.2.-svet staršev 2,5 h\r\n1 ura-aktiv MA'),(793,63,2008,2,0,0,0,4.00,0.00,2.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-14 22:17:20','amohar','Izobraževanje: Učenje je lahko zabavno, 13. 2. 2007, 14.00-19.00'),(794,8,2008,2,0,2,0,1.50,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.50,0.00,0,0.00,0.00,0.00,0.00,'2008-03-20 08:14:42','rpodborsek','11.2.2008 svet staršev'),(795,6,2008,2,0,16,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-18 10:57:44','rpodborsek','20.2.08-21.2.2008 koristila dopust'),(796,52,2008,2,0,0,0,0.00,0.00,0.00,410.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:30:27','tancnik',''),(797,46,2008,2,0,0,0,4.00,0.00,3.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-25 13:11:15','mkump',''),(798,64,2008,2,0,0,10,0.00,0.00,0.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-26 07:41:12','mnedizevec',''),(799,96,2008,2,0,0,10,0.00,0.00,0.00,205.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-26 07:54:57','avojska',''),(800,47,2008,2,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,5,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 18:03:54','avelkavrh','2 uri - tekmovanje ZGO\r\n3 ure - poprvljanje'),(801,97,2008,2,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 18:20:11','avelkavrh','1 ura - 26.2.2008 sest. za Jana Horvata'),(802,100,2008,2,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 18:26:43','avelkavrh','2 - beneške maske\r\n1 - Jan H.'),(803,17,2008,2,0,0,0,0.00,5.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-02-26 12:42:04','avelkavrh',''),(804,108,2008,2,0,0,0,5.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.50,0.00,0,0.00,4.00,0.00,0.00,'2008-03-06 22:00:53','avelkavrh','3 - dežurszvo v jedilnici\r\n1 - aktiv TJA\r\n1,5 - pomoč učencem pri popravljanju ocen (8.r)'),(805,80,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,80.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-26 14:53:48','lrenko','12. 02. 2008\r\nVpis prvošolcev za šol. leto 2008/09'),(806,105,2008,2,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-10 18:26:05','avelkavrh','1 ura - Aktiv'),(807,34,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-02-27 07:23:32','djersin','Svet staršev(11.02.2008),vpis prvošolcev(12.02.2008)'),(808,9,2008,2,0,0,0,0.00,0.00,0.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,24.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:50:57','tancnik','8 ur priprava predstave ob vpisu prvošolcev\r\n2 uri vpis prvošolcev\r\n14 ur individualna učna pomoč'),(809,1,2008,2,0,0,0,0.00,0.00,0.00,340.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-27 07:39:42','sancnik',''),(810,98,2008,2,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,5,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,1.00,0.00,0.00,'2008-03-10 18:29:44','avelkavrh','Šolsko zgodovinsko tekmovanje: nadzor in popravljanje testov\r\nValentinov ples: varovanje učencev na plesu od 17. do 19. ure'),(811,70,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-27 07:50:20','iomercevic',''),(812,28,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,10.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:52:19','tancnik','8 ur - priprava igrice za prvošolce, 2 uri - vpis 1.r'),(813,66,2008,2,0,0,0,0.00,0.00,4.00,0.00,0.00,8.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,250.00,0.00,'2008-03-05 10:58:31','tancnik','Organizacija in izvedba pustovanja.\r\nDelavnica za otroke ob vpisu v prvi razred.'),(814,106,2008,2,0,0,0,0.00,0.00,6.00,0.00,0.00,9.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,250.00,0.00,'2008-03-05 10:48:32','tancnik','Izvedba pustovanja. '),(815,29,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:41:19','tancnik','Evalvacijski sestanek za Jana Horvata, 26.2.2008 od 13.30 do 15.00\r\n\r\n2 uri - vpis prvošolčkov, 12.2.2008 od 17.00 do 19.00\r\n\r\n'),(816,38,2008,2,0,0,0,0.00,0.00,4.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:33:16','tancnik','2 uri-vpis 1.r'),(817,102,2008,2,0,0,0,0.00,0.00,4.00,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-27 12:02:41','bzavec',''),(818,39,2008,2,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,100.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:38:55','tancnik','2 uri jutranje varstvo\r\n2 uri vpis prvosolcev\r\n'),(819,16,2008,2,0,0,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-27 12:58:19','bdekleva','12.2.2008 vpis prvošolcev'),(820,11,2008,2,0,0,0,2.00,8.00,3.00,0.00,0.00,1.50,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-06 21:53:22','avelkavrh','1 ura-26.2.evalv.s.J.H.\r\n1 - aktiv TJA'),(821,50,2008,2,0,0,0,0.00,0.00,21.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,750.00,0.00,'2008-02-28 09:20:19','alovsin','Delovne in druge obveznosti:Pustovanje in vpis v prvi razred.'),(822,87,2008,2,0,0,0,0.00,0.00,3.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,6,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-05-21 13:10:21','avelkavrh','1- spremstvo na zdravniški pregled\r\n6- polfinale, državno prvenstvo kanvas'),(823,60,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.75,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 22:07:19','avelkavrh','6 - izdelava pustne dekoracije'),(824,30,2008,2,0,0,0,0.00,0.00,0.00,360.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-28 13:42:26','avelkavrh',''),(825,101,2008,2,0,0,0,4.00,0.00,3.00,0.00,0.00,4.50,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 18:22:41','avelkavrh','0,5 ure- 2 evalvacijska sestanka\r\n2 uri - vpis\r\n4 ure- študijska skupina'),(826,23,2008,2,0,0,0,0.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:42:21','tancnik','Vpis prvošolcev'),(827,58,2008,2,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-28 19:04:42','amedic',''),(828,72,2008,2,0,2,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 17:44:31','avelkavrh','1 - aktiv SLO'),(829,37,2008,2,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-31 20:01:29','avelkavrh','1H-aktiv matematika,\r\n1H-učna pomoč učencem 8.razreda(negativni)\r\n3 ure - dež. pri kosilu'),(830,86,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.30,0.00,0,0.00,0.00,0.00,0.00,'2008-02-29 10:03:28','msrsa','11.2.2008 Svet staršev\r\n12.2.2008 Vpisi 1. razred'),(831,83,2008,1,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-29 10:40:14','psimcic',''),(832,21,2008,2,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-02-29 12:59:25','tgarvas','Druge obveznosti - sprejem prvošolcev'),(833,81,2008,2,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.25,2,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,1.00,0.00,0.00,'2008-03-10 18:19:38','avelkavrh','sestanki za nadarjene (Drofenik, Valič, Jager, Kumer, Križanič), \r\n1 ura - sestanek Jan Horvat 26. 2. \r\nnadzor tekmovanja iz ZGO\r\n3ure - Šolski ples 14. 2.'),(834,77,2008,2,0,0,0,0.00,0.00,4.00,230.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,150.00,0.00,'2008-03-05 10:37:17','tancnik','5 ur - pustovanje\r\n2 uri - vpis 1.r'),(835,118,2008,3,0,0,0,0.00,0.00,0.00,70.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.50,0.00,0,0.00,0.00,290.00,0.00,'2008-03-28 11:06:41','tancnik','Pomoč pri tehniškem dnevu 2x'),(836,111,2008,2,0,0,0,0.00,0.00,14.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:34:29','tancnik','2 uri-vpis 1.r'),(837,118,2008,2,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,60.00,0.00,'2008-03-05 10:35:11','tancnik',''),(838,85,2008,2,0,0,10,0.00,0.00,0.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-05 10:43:27','tancnik',''),(839,65,2008,5,0,0,0,0.00,0.00,2.00,95.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 14:02:38','tancnik',''),(840,35,2008,2,0,2.5,0,0.00,0.00,5.00,0.00,0.00,0.00,2.50,0.00,0.00,0.00,0.00,0.00,0.00,2,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:46:56','avelkavrh',''),(841,71,2008,2,0,0,0,14.50,0.00,0.00,550.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-15 08:52:20','tancnik',''),(846,43,2008,2,0,6,0,0.00,8.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,18.00,0.00,0.00,'2008-04-03 21:12:23','avelkavrh','3-dežurstvo pri kosilu'),(847,4,2008,2,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-06 21:32:15','avelkavrh','1 ura - aktiv SLO'),(848,5,2008,3,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 19:31:00','avelkavrh',''),(849,5,2008,2,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-06 21:41:28','avelkavrh',''),(850,54,2008,2,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-06 22:10:34','avelkavrh',''),(851,67,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,19.50,0.00,0,0.00,2.00,0.00,0.00,'2008-03-31 19:55:32','avelkavrh','1 ura-26.2.evalv.s.J.H.\r\n4,5 ure-dež. pri kosilu\r\n3 ure-priprava recutacij za komemoracijo\r\n2 uri-proslava PUST\r\n10 ur-Cankarjevo tek.'),(852,62,2008,2,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-04-01 12:59:18','avelkavrh','1 ura-26.2.evalv.s.J.H.'),(853,73,2008,3,0,1,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-14 07:11:07','rpenezor','7.3.2008 koristil 1 uro 0d 14.00 do 15.00; 11.3. ped. konf. 2 uri in svet staršev 1 ura'),(854,79,2008,3,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,2.00,0.00,0.00,'2008-03-10 17:47:13','avelkavrh','1 - aktiv MAT'),(855,84,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,1.00,0.00,0.00,'2008-03-10 18:09:09','avelkavrh','4 ure - šolski ples'),(856,51,2008,2,0,0,0,0.00,0.00,1.00,375.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 19:49:04','avelkavrh',''),(857,75,2008,2,0,0,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-10 19:52:07','avelkavrh',''),(858,76,2008,3,0,0,0,0.00,0.00,0.00,0.00,60.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-13 11:51:25','rpodborsek','svet staršev, 11.3.2008'),(859,122,2008,3,0,0,0,0.00,0.00,1.00,0.00,3840.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-09 15:05:03','avelkavrh','2-dežurstvo pri kosilu'),(860,57,2008,3,0,0,0,4.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,-1.50,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 20:24:13','avelkavrh',''),(861,46,2008,3,0,0,0,4.00,0.00,6.00,45.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-01 14:38:56','avelkavrh','3 -popoldanska delavnica za Pomladni sejem'),(862,52,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:02:17','tancnik',''),(863,9,2008,3,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,11.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:16:01','tancnik','Individualna učna pomoč'),(864,34,2008,3,0,0,0,0.00,0.00,0.00,450.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 07:38:10','djersin',''),(865,96,2008,3,0,0,0,0.00,0.00,0.00,765.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 07:42:16','avojska',''),(866,106,2008,3,0,0,0,5.50,0.00,4.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-02 08:35:02','tancnik','spremstvo na zdravniški pregled 3.a- 4ure in 10 min.'),(867,38,2008,3,0,0,0,5.50,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-02 08:33:29','tancnik',''),(868,56,2008,3,0,0,0,0.00,0.00,0.00,140.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 11:35:38','imargan',''),(869,23,2008,3,0,0,0,0.00,0.00,14.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:10:50','tancnik',''),(870,63,2008,3,0,0,0,4.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 18:33:41','amohar','Izobraževanje: 5. 3. POLLEN, 4 ure\r\nDelovne in druge obveznosti:\r\n-Likovna delavnica(sejem)2 uri\r\n- Mat. kenguru: vpisala 1 uro namesto 50 min zaradi vpisovanja podatkov v urah'),(871,80,2008,3,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-25 21:31:59','lrenko','18.03.2008 OPB-1.a'),(872,77,2008,3,0,0,0,7.00,0.00,3.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,3.00,0.00,0.00,'2008-04-02 08:37:40','tancnik','3 ure - okraševanje NŠ'),(873,21,2008,3,0,0,0,0.00,0.00,2.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.40,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 10:45:12','tancnik','15 min v JV'),(874,66,2008,3,0,0,0,5.50,0.00,0.00,100.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-02 08:34:29','tancnik',''),(875,64,2008,3,0,0,0,0.00,0.00,0.00,450.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-26 17:42:06','mnedizevec',''),(876,1,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,200.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 10:40:45','tancnik',''),(877,16,2008,3,0,0,0,0.00,0.00,3.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-31 10:15:24','tancnik',''),(878,102,2008,3,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-28 11:29:51','bzavec',''),(879,39,2008,3,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,10.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 10:56:51','tancnik','3 ure JV'),(880,28,2008,3,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 10:59:37','tancnik',''),(881,86,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:11:23','mgajski','11.3.2008-Pedagoška konferenca\r\n11.3.2008- Svet staršev  '),(882,70,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,120.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:11:58','tancnik',''),(883,50,2008,3,0,0,0,5.50,0.00,2.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.50,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 12:45:19','tancnik','4.3.08 - sodišče'),(884,111,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,35.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:20:09','tancnik',''),(885,65,2008,3,0,0,0,0.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:24:24','tancnik',''),(886,78,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 11:35:17','tancnik','3 ur - okraševanje šole pust'),(887,85,2008,3,0,0,0,0.00,0.00,0.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 12:07:12','tancnik',''),(888,29,2008,3,0,0,0,0.00,5.00,0.00,555.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-27 12:10:46','tancnik','1 ura diagnostika, 1 ura branje z učencem'),(889,97,2008,3,0,0,0,16.00,0.00,0.00,0.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,600.00,0.00,0.00,2.00,0.00,0,0.00,11.00,0.00,0.00,'2008-03-31 18:13:01','avelkavrh','Delovne in druge obveznosti --> 20. 3. 08 --> pazil učence na matematičnem tekmovanju'),(890,81,2008,3,0,0,0,4.50,0.00,1.00,0.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,1.00,1,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-03-28 08:36:26','avelkavrh','29.2;19.3;21.3. - raz. naloga Rok Sraka (4,5 ur)\r\n1 - ura nadzor BZ angl.\r\n4×0,25 sest. za nadarjene\r\n3 - državno tek. iz kemije (spremstvo)'),(891,35,2008,3,0,6,0,8.00,0.00,18.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-05-16 10:36:33','avelkavrh',''),(892,6,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-28 14:05:53','obergant',''),(893,105,2008,3,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-25 11:00:36','avelkavrh','1 ura - aktiv\r\n3 ure - lektoriranje seminarske naloge'),(894,11,2008,3,0,0,15,15.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0,0.00,0.00,0.00,0.00,4.00,0.00,0,10.50,9.00,0.00,0.00,'2008-04-03 09:00:50','avelkavrh','14.3.teamski sestanek svetov. služba (Pia, Klara, Žan, MAriša -7.a)\r\n1,5 DU\r\naktiv 1DU\r\nseminar o ocenjevanju Celje 12. in 13.3. 1x7, 1×8 ur\r\ndruge obveznosti: 3 PU dopolnilnega pouka za Suzano Maksimović in Marka Borovnjaka 6.,7. in 10.3.'),(895,58,2008,3,0,0,0,0.00,0.00,6.00,0.00,0.00,15.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-30 17:41:10','amedic',''),(896,26,2008,3,0,0,0,23.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,11.5,0.00,0.00,0.00,0.00,6.00,0.00,0,1.00,6.00,0.00,0.00,'2008-04-03 14:36:34','avelkavrh','Izobraževanje:\r\n2x6 ur+1x5 ur - urnik\r\n6 ur - Učenje je lahko zabavno\r\nTekmovanje:\r\n3 ure - vnos vseh učencev 1.razreda v Infoserver, izpis izjav za skoraj vse tekmovalce (preko 400 tekmovalcev)\r\n4 ure-organizacija tekmovanja\r\n4,5 ure-nadzor v učilnici, vnos rezultatov v Infoserver, vnos vseh tekmovalcev v Kadre\r\nDrugo:\r\n2 uri-delavnica o učenju za 9.razred\r\n1 ura-aktiv MA\r\n3 ure-študijska skupina\r\n1 - priprava urnika'),(897,37,2008,3,0,0,0,3.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,5.5,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-31 20:00:45','avelkavrh','1,5ure - mat.tekmovanje\r\n3ure - popravljanje\r\n1ure - tekmovanje španščina\r\n3ure - učna pomoč učencem 8.razreda z negativnimi ocenami\r\n1ura - aktiv MAT\r\n3 - dežurstvo pri kosilu'),(898,47,2008,3,0,0,0,3.00,0.00,0.00,0.00,3.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,6.00,3,0.00,0.00,0.00,0.00,0.00,0.00,0,1.00,0.00,0.00,0.00,'2008-04-03 10:26:09','avelkavrh','-mednar.debatni turnir\r\n-program za nadarjene\r\n- drž. zgodov. tekm.\r\n1 - svet staršev'),(899,43,2008,3,0,9,0,0.00,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-03 21:13:07','avelkavrh','3-dežurstvo pri kosilu'),(900,78,2008,3,0,0,0,0.00,0.00,19.00,110.00,0.00,0.00,12.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,100.00,0.00,0.00,0.00,0.00,0,0.00,6.00,4.00,10.00,'2008-04-02 08:36:25','tancnik','okraševanje šole'),(901,4,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-31 13:57:27','avelkavrh',''),(902,42,2008,3,0,0,0,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,70.25,0.00,0,2.00,0.50,0.00,0.00,'2008-04-10 19:52:35','avelkavrh','2 - razredništvo februar\r\n0,5 PU - preveč plačane v feb.'),(903,30,2008,3,0,0,0,11.50,0.00,1.00,325.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,5.00,0.00,0.00,'2008-03-31 20:04:23','avelkavrh',''),(904,10,2008,3,0,0,0,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,130.00,0.00,0.00,0.00,0.00,0,88.25,0.00,0.00,0.00,'2008-04-10 19:33:43','avelkavrh','8 ur - fr. BZ'),(905,87,2008,3,0,0,0,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2008-03-31 18:44:22','avelkavrh',''),(906,17,2008,3,0,0,0,7.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,-45.75,0.00,0,0.00,3.00,0.00,0.00,'2008-04-24 10:37:34','avelkavrh','45,75ur- je bilo že izplačanih v pretekljih mesecih.'),(907,75,2008,3,0,0,0,3.50,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,150.00,0.00,0.00,-15.77,0.00,0,0.00,4.00,240.00,0.00,'2008-04-10 20:20:49','avelkavrh',''),(908,98,2008,3,0,0,0,3.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,3,0.00,0.00,0.00,0.00,0.00,0.00,0,1.50,0.00,0.00,0.00,'2008-04-03 21:27:26','avelkavrh','3ure - drž. tekm. iz zgodovine'),(909,72,2008,3,0,0,15,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-01 11:29:17','avelkavrh','1ura- aktiv SLO\r\n15ur- ŠVN\r\n0,25- sest.s starši J.K.'),(910,92,2008,3,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-03-31 19:49:11','avelkavrh',''),(911,67,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 20:09:23','avelkavrh','4,5 ure - varstvo otrok 7 uro'),(912,122,2008,4,0,0,0,2.00,0.00,5.00,360.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,16.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-08 10:46:54','avelkavrh','12 ur delovnih in drugih obveznosti sem doprinesel s proslavo za SKB banko in za proslavo 25.04.2008. Dve uri pri občasnih timih sem doprinesel 10.04, ko smo imeli sestanek za razred 8.b \r\n4 ure - dežzrstvo pri kosilu'),(913,62,2008,3,0,0,0,8.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,15.5,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,5.00,0.00,0.00,'2008-05-08 07:09:12','avelkavrh','1,5 - tekmovanje\r\n10 - popravljanje tek. nalog\r\n8 ur - Pef \r\n4 - regijsko tekmovanje'),(914,108,2008,3,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,6,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-01 13:24:24','avelkavrh','1 - Avbelj\r\n4 - dop pouk TJA\r\n6 - popravljanje tekmovanj (72 učencev po 5 min)\r\n1 - aktiv TJA\r\n4 - dežurstvo pri kosilu'),(915,100,2008,3,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-01 13:52:34','avelkavrh',''),(916,51,2008,3,0,0,0,1.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,3.00,0.00,0.00,0.00,'2008-05-20 12:17:31','avelkavrh','3 - ozvočenje'),(917,60,2008,3,0,0,15,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-03 14:33:44','avelkavrh','3 - okraševanje šole v tednu pred sejmom'),(918,101,2008,3,0,0,0,0.00,0.00,3.00,0.00,0.00,4.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-04 11:06:48','avelkavrh','3-ure Mihajlo'),(919,26,2008,4,0,0,0,11.50,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,3,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,4.00,0.00,0.00,'2008-04-23 12:37:18','bhorvat','4.4.-seminar Urnik\r\n7.4.-seminar LIF\r\n2.4.-spremstvo in popravljanje nalog na regijskem tekmovanju\r\n22.4.-delavnica o učenju (LIF)-1 ura\r\n24.4.-delavnica LIF-1 ura\r\naktiv MA-1 ura'),(920,53,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,-128.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 10:07:21','avelkavrh',''),(921,54,2008,3,0,0,15,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 20:05:11','avelkavrh',''),(922,84,2008,3,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-10 20:13:41','avelkavrh',''),(923,87,2008,4,0,0,0,0.00,0.00,1.00,0.00,0.00,11.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,20.00,0.00,0.00,'2008-05-21 13:10:40','avelkavrh','4 - drž prv. gimn.\r\n5 - šol. plesni festival - Bolero\r\n2,5 - CIPS'),(924,71,2008,1,0,0,0,8.00,6.50,0.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-15 08:49:51','tancnik','4 ure za pripravo pohoda na Dobeno'),(925,71,2008,3,0,0,0,14.50,0.00,0.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-15 08:52:53','tancnik',''),(926,14,2008,3,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,72.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-15 09:09:54','tancnik','72 ur sem dodala zato, da sem prišla na trenutno stanje - porodniška'),(927,73,2008,4,0,1,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-15 11:46:20','rpodborsek','9.4.2008 od 14.00 do 15.00 koristil 1 uro'),(928,34,2008,4,0,0,0,5.00,0.00,0.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,440.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-17 07:36:52','djersin',''),(929,52,2008,4,0,0,0,5.00,0.00,0.00,250.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:03:24','tancnik','2.4. sem bila v JV.'),(930,44,2008,4,0,1.5,0,0.00,0.00,0.00,0.00,540.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-17 11:41:12','rpodborsek','Delala po 15.00 uri(nadomeščanje Mojce Bernot S.), plus ure je podpisala ga.Zgonc\r\n15.4.08 je od 7.00 do 8.30 koristila 1,5 ure.'),(931,16,2008,4,0,0,0,7.50,0.00,3.00,550.00,0.00,0.25,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:16:02','tancnik','spremstvo v zdravstveni dom.'),(932,64,2008,4,0,0,0,5.00,0.00,0.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-17 18:20:09','mnedizevec',''),(933,9,2008,4,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,440.00,0.00,0.00,7.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:26:54','tancnik','7 ur individualna učna pomoč'),(934,33,2008,4,0,0,0,5.00,0.00,0.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,260.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 07:38:18','pjerman',''),(935,70,2008,4,0,0,0,2.00,0.00,0.00,630.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,9.32,0.00,0.00,0.00,'2008-07-03 08:27:55','tancnik',''),(936,66,2008,4,0,0,0,1.00,8.00,16.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,250.00,0.00,'2008-05-28 11:21:12','tancnik',''),(937,124,2008,4,0,0,0,0.00,0.00,9.00,0.00,3360.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-24 10:06:41','avelkavrh','6 - priprava in izvedba proslave 1. maj\r\n1 - dežurstvo v jedilnici'),(938,1,2008,4,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,3.00,0.00,0.00,0.00,'2008-07-03 08:06:19','avelkavrh',''),(939,39,2008,4,0,0,0,5.00,0.00,3.00,420.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 08:54:04','tancnik',''),(940,102,2008,4,0,0,0,0.00,0.00,0.00,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 10:59:54','tancnik',''),(941,29,2008,4,0,0,0,0.00,9.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-19 10:58:41','admin','Portorož, 18.-19.4.2008'),(942,96,2008,4,0,0,0,17.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:06:09','tancnik',''),(943,28,2008,4,0,0,0,17.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,260.00,0.00,0.00,0.00,0.00,0,15.64,0.00,0.00,0.00,'2008-07-03 08:18:55','tancnik',''),(944,85,2008,4,0,0,0,14.00,0.00,0.00,700.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,20.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:10:49','tancnik',''),(945,65,2008,4,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,200.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 11:13:20','tancnik',''),(946,111,2008,4,0,0,0,0.00,0.00,13.00,55.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,50.00,0.00,'2008-04-18 11:20:04','tancnik',''),(947,86,2008,4,0,0,0,9.50,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-18 12:36:46','tancnik',''),(948,80,2008,4,0,0,0,7.00,0.00,0.00,500.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.50,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 08:53:28','tancnik','08.04. predstavitev učbeniškega kompleta za SPO, Izotech, 2 uri\r\n09.04. študijska skupina za 1. triletje 1,5 ure\r\n10.04. predstavitev SLO za 1. triletje, Izolit, 2,5 ure\r\n17.04. Izobraževanje nad 8 ur, 0,5 ure'),(949,92,2008,4,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,10,0.00,0.00,0.00,0.00,0.00,0.00,0,17.50,0.00,0.00,0.00,'2008-07-03 10:21:39','avelkavrh','10 - državni debatni turnir (sobota)'),(950,38,2008,4,0,0,0,0.00,0.00,17.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 11:33:29','tkavsek',''),(951,6,2008,4,0,8,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 12:07:46','rpodborsek','30.4.08 koristila 8 ur(dopust)'),(952,21,2008,4,0,0,0,2.00,0.00,4.00,680.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 12:43:22','tancnik',''),(953,50,2008,4,0,0,0,0.00,0.00,5.00,100.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 12:44:55','tancnik',''),(954,14,2008,4,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 12:45:50','tancnik',''),(955,77,2008,4,0,0,0,4.50,24.50,2.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,9.50,0.00,0,0.00,0.00,115.00,0.00,'2008-04-21 13:23:43','tancnik','17.4. - 4 ure, šahovsko tekmovanje; 18.4. - 5,5 ur, raziskovalne naloge'),(956,71,2008,4,0,0,0,0.00,0.00,0.00,210.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-21 13:26:50','tancnik',''),(957,23,2008,4,0,0,0,0.00,0.00,2.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,4,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-22 08:29:46','tancnik',''),(958,106,2008,4,0,0,0,1.00,7.50,0.00,250.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-22 08:31:20','tancnik',''),(959,78,2008,4,0,0,0,0.00,0.00,17.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,200.00,0.00,'2008-04-22 12:09:03','spusnar',''),(960,100,2008,4,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,26.00,0.00,0,0.00,2.00,0.00,0.00,'2008-04-22 12:24:50','avelkavrh','2 - 8.d\r\n8 - Velenje\r\n8 - priprava prireditve\r\n10 - vaje za proslavo'),(961,46,2008,4,0,0,0,4.00,0.00,2.00,330.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-22 12:41:53','mkump',''),(962,47,2008,4,0,0,0,0.00,0.00,2.00,0.00,0.00,2.00,10.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-05-17 17:14:46','avelkavrh','10 - 19.4 - državno tekmovanje iz retorike'),(963,67,2008,4,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,9.00,0.00,0.00,10.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-22 16:02:35','tnovak1','varovanje:2.4.,16.4.,23.4.=3 ure;Priprava uč. na zun. prev. znanja (odobrila ga. )rav. :1.4.,8.4.,17.4.,22.4.=4 ure; priprava okvirnrga načrta za šolsko proslavo in deklamacije za krajevno skupnost- vaje z učenkami=3 ure'),(964,51,2008,4,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-23 07:23:19','avelkavrh','1,5 - nadarjeni\r\n2 - ozvočenje (prometno tekmovanje, proslava)'),(965,98,2008,4,0,0,0,0.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,0.00,0.00,'2008-04-23 11:47:36','avelkavrh',''),(966,4,2008,4,0,0,0,4.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1015.00,0.00,0.00,1.00,0.00,0,15.00,0.00,0.00,0.00,'2008-04-25 10:59:50','avelkavrh','4 - študijska skupina\r\n1 - SLO\r\n12DU - zlata BZ (od 7.00 - 19.00)'),(967,79,2008,4,0,0,0,0.00,0.00,2.00,660.00,0.00,0.00,0.50,0.00,0.00,0.00,0.00,0.00,0.00,3.5,0.00,0.00,0.00,0.00,17.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-23 14:39:21','iravbarbacic','šolsko tekmovanje:\r\n- 2 šolski uri nadzor\r\n- 2 uri vnos rezultatov\r\npodročno tekmovanje:\r\n- 3 ure popravljanje nalog\r\ndržavno tekmovanje:\r\n- 0,5 ure spremstvo\r\n- 2 uri nadzor\r\naktiv (februar,april)2 ura\r\ndežurstvo jedilnica(februar, marec, april) 10 ur'),(968,42,2008,4,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,15.00,1.00,0.00,0.00,'2008-04-24 09:30:25','avelkavrh','4 - plavanje v okviru ŠZZ'),(969,63,2008,4,0,0,0,4.00,0.00,4.00,80.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,140.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2008-04-23 18:35:31','amohar','28. 3. - nerealizirane PU(zdravniški pregled)\r\n9. 4. - 2 uri (študijska skupina)\r\n10. 4. - 2 uri (seminar na šoli - Izolit)'),(970,57,2008,4,0,0,0,4.00,0.00,3.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-24 10:23:40','pmavsar',''),(971,17,2008,4,0,0,0,0.00,0.00,3.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,5.00,0.00,0.00,'2008-04-24 10:36:37','avelkavrh','4 - spremstvo raz. naloge'),(972,101,2008,4,0,0,0,9.50,5.00,11.00,145.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,11.00,0.00,0.00,'2008-04-24 11:33:17','mzakrajsek','4 ure- Mihajlo, 2 uri- Franci Z., 3 ure Jan H., 1 ura Žan K., 1 ura - 9.a (zgod.)'),(973,11,2008,4,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,900.00,0.00,0.00,1.00,0.00,0,15.00,3.00,0.00,0.00,'2008-04-24 13:43:16','avelkavrh','1 - aktiv TJA'),(974,72,2008,4,0,1,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,1335.00,0.00,0.00,0.25,0.00,0,1.50,0.00,0.00,0.00,'2008-07-02 13:06:18','avelkavrh','1 ura - aktiv SLO\r\n0,25 - sestanek Zoran'),(975,37,2008,4,0,0,0,0.00,0.00,7.00,180.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,4.00,0.00,0.00,'2008-04-24 21:24:22','bkastelic','PK 8.b 10.4. (od13.30 - 15.30)-2uri\r\n1. ura - aktiv matematika\r\n3. ure-nadzor v jedilnici'),(976,97,2008,4,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-04-25 07:26:53','mvrcko','Občasni timi - sestanek za Dorijana Kogovška 15. 4. 08'),(977,60,2008,4,0,0,0,5.00,0.00,15.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-25 09:28:56','mmihelcic','seminar ZALOŽBA ROKUS\r\nseminar POLLEN'),(978,30,2008,4,0,0,0,7.00,0.00,2.00,180.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,400.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-04-25 19:49:48','ejalsovec',''),(979,81,2008,4,0,0,0,2.00,0.00,4.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,2.25,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,3.00,0.00,0.00,'2008-05-17 17:12:38','avelkavrh','7.4. sestanek spor med skupinami učencev, 10.4. sestanek 8.b '),(980,58,2008,4,0,0,0,0.00,0.00,4.00,0.00,0.00,1.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-04 17:37:26','avelkavrh',''),(981,62,2008,5,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,0.00,0.00,'2008-06-04 18:33:22','avelkavrh',''),(982,6,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-14 11:49:45','obergant','pedagoška konferenca, 13. 5. 2008'),(983,29,2008,5,0,0,0,0.00,0.00,1.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,13.50,0.00,0,0.00,0.00,0.00,0.00,'2008-06-05 09:40:57','throvat','13.5. - 7.00 - 8.00 Spremstvo 7. c na tehniški dan\r\n14.5. - Študijska skupina OŠ Nove Jarše\r\n29.5. - Raziskovalne naloge - tekmovanje v MS\r\n\r\n'),(984,62,2008,4,0,0,0,0.00,8.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,1.00,0.00,0.00,'2008-05-16 10:51:58','avelkavrh','4 - spremstvo na matematično tekmovanje\r\n8 - PeF'),(985,5,2008,4,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-16 07:08:05','avelkavrh',''),(986,108,2008,4,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.50,0.00,0,0.00,1.00,0.00,0.00,'2008-05-16 10:39:53','avelkavrh','1 - aktiv TJA\r\n4 - dežurstvo pri kosilu\r\n1 - Maša Gruden'),(987,10,2008,4,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,60.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-16 10:20:14','avelkavrh',''),(988,53,2008,4,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-16 10:47:31','avelkavrh',''),(989,54,2008,4,0,0,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-16 10:49:20','avelkavrh','4 - spremstvo plavanje'),(990,105,2008,4,0,0,0,0.00,4.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,560.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-17 17:20:34','avelkavrh',''),(991,75,2008,4,0,0,0,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-17 17:25:17','avelkavrh',''),(992,76,2008,5,0,1,0,0.00,0.00,0.00,0.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-21 11:36:21','rpodborsek','14.5.2008 svet staršev plus 2 uri, 16.5.2008 koristila 1 uro od 14.00 do 15.00 ure'),(993,33,2008,2,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,40.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-20 08:28:02','tancnik','Strjena bolniška, tudi med zimskimi počitnicami'),(994,108,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,24.25,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 10:20:41','avelkavrh','Dežustvo v jedilnici\r\n5.5.\r\n'),(995,78,2008,5,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 11:14:35','tancnik','NPZ (2x po 60 min)\r\nŠtudijska skupina (4 ure), 2 uri EKO dan'),(996,23,2008,5,0,0,0,8.00,0.00,12.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,250.00,0.00,'2008-05-29 10:25:58','tancnik','2 uri za pripravo eko dneva'),(997,50,2008,5,0,0,0,4.00,0.00,0.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,50.00,0.00,'2008-05-28 13:43:41','tancnik','15.5.2008 Študijska skupina /4ure/, 2 uri EKO dan'),(998,106,2008,5,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 10:53:35','tancnik','2 uri EKO dan\r\n2. študijska skupina 15.5'),(999,66,2008,5,0,0,0,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 11:24:38','tancnik','15.5.2008-študijska skupina (4 ure, 2 uri EKO dan'),(1000,34,2008,5,0,0,10,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-20 13:49:47','djersin',''),(1001,9,2008,5,0,0,10,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 10:56:43','tancnik','8 h - individualna učna pomoč'),(1002,33,2008,5,0,0,10,0.00,0.00,0.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 13:46:24','tancnik',''),(1003,84,2008,5,0,0,20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 10:25:03','avelkavrh','bojan stojanović-razredni izpit'),(1004,43,2008,5,0,5,0,4.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 12:14:28','avelkavrh','Prva pomoc 4h (16h-20h)\r\n4- spremstvo TD\r\n4- dež pri kosilu\r\n'),(1005,47,2008,5,0,0,20,0.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-23 13:39:16','avelkavrh','7 - IP Stojanović, Dedić\r\n3 - debatne delavnice'),(1006,101,2008,5,0,0,20,0.00,0.00,7.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-23 17:33:42','mzakrajsek','2 PU - Mihajlo, 4 PU -Jan H., 1 PU Damir S., 4 ure - študijska skupina, 1 ura - NPZ\r\n '),(1007,63,2008,5,0,0,20,4.00,0.00,0.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,15.00,0.00,50.00,0.00,'2008-05-29 10:50:11','avelkavrh','Izobraževanje: 12. 5. - Prva pomoč od 16.00-20.00\r\nPB - 15. 5.- nerealizirano zaradi zdr. pregleda'),(1008,77,2008,5,0,0,0,4.00,0.00,0.00,420.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,24.00,0.00,0,0.00,3.00,540.00,0.00,'2008-05-29 12:10:11','tancnik','21.-23.5. festival ustvarjalnosti - 24 ur'),(1009,38,2008,5,0,0,0,4.00,0.00,3.00,0.00,0.00,8.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,350.00,0.00,'2008-06-06 11:29:39','tancnik','drugo 4h študijska \r\n      2h eko dan'),(1010,105,2008,5,0,0,0,4.00,0.00,2.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-26 13:05:11','avelkavrh','3,5 - spremstvo Piramida\r\n1- aktiv SLO'),(1011,97,2008,5,0,0,0,1.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.75,0,0.00,0.00,0.00,0.00,3.00,0.00,0,0.00,10.00,0.00,0.00,'2008-05-29 10:27:25','avelkavrh','Občasni timi --> sestanek glede Dorijana Kogovška z deloavko z CSD-ja.\r\nDruge obveznosti --> NPZ - 3 ure'),(1012,80,2008,5,0,0,0,11.00,0.00,0.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,4.00,0.00,0.00,'2008-05-28 10:20:20','tancnik','12.5.2008 so šli učenci 1.a za 3 dni na tabor v Faro. Neopravljene pedagoške ure teh dni sem opravila s prerazporeditvijo po navodilih ga. Ančnik - spremstvo tretješolcev na zdravniški pregled, spremstvo na avtobusu in aktivnosti povezane z zadnjim dnem tabora.\r\nIzobraževanje: MODUL 6, 7.,8. in 16. maj 2008'),(1013,96,2008,5,0,0,0,0.00,0.00,0.00,55.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-27 07:25:38','avojska',''),(1014,73,2008,5,0,2,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 11:30:23','rpodborsek','13.5. - konferenca 2 ,5 uri; 14.5.08 svet staršev 2 uri\r\n28.5.2008 koristil 2 uri od 13.00 do 15.00'),(1015,14,2008,5,0,0,0,0.00,0.00,5.00,65.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,11.00,0.00,0.00,'2008-05-28 10:07:30','tancnik','individualna učna pomoč'),(1016,64,2008,5,0,0,0,0.00,0.00,0.00,500.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,10.50,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 10:26:32','tancnik','Individualne ure\r\nDežurstvo'),(1017,102,2008,5,0,0,0,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 12:04:13','tancnik','2 uri EKO dan'),(1018,85,2008,5,0,0,0,6.00,0.00,5.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 11:07:29','tancnik',''),(1019,37,2008,5,0,0,0,0.00,0.00,15.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,10.00,0.00,0.00,'2008-05-28 13:50:55','avelkavrh','1ura-aktiv MAT\r\n3 ure-nadzor v jedilnici\r\n2- dopolnitev znanj za učence 8.b'),(1020,16,2008,5,0,0,10,5.00,0.00,8.00,200.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 10:34:13','tancnik',''),(1021,25,2008,5,0,0,0,0.00,0.00,0.00,0.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 09:18:41','rpodborsek','14.5.2008 svet šole, 2 uri'),(1022,25,2008,3,0,0,0,0.00,0.00,0.00,0.00,60.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 09:20:49','rpodborsek','11.3.2008 svet šole, 1 ura'),(1023,60,2008,5,0,0,0,4.00,0.00,10.00,0.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,750.00,0.00,'2008-05-28 09:32:38','mmihelcic','izobraževanje: PRVA POMOČ'),(1024,111,2008,5,0,0,0,4.00,0.00,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,50.00,0.00,'2008-05-28 11:00:28','tancnik','4 ure študijska skupina, 2 uri EKO dan'),(1025,21,2008,5,0,0,10,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 10:37:50','tancnik',''),(1026,98,2008,5,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,6.00,150.00,0.00,'2008-05-28 11:48:34','avelkavrh',''),(1027,51,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,575.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 11:54:40','avelkavrh',''),(1028,43,2008,4,0,25,0,0.00,0.00,37.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,9.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-28 12:18:22','avelkavrh','4- kosilo\r\n5- spremstvo CIPS'),(1029,118,2008,5,0,0,0,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,15.59,0.00,0.00,0.00,'2008-07-03 08:34:28','tancnik','2 uri EKO dan. 4 ure študijska skupina'),(1030,86,2008,5,0,4,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.50,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 11:32:05','rpodborsek','13.5.08- Pedegoška konferenca\r\n14.5.08 - Svet staršev\r\n30.5.08 koristila 4 ure'),(1031,124,2008,5,0,0,0,0.00,1.50,26.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,0.00,1.00,0.00,0.00,'2008-05-28 12:28:34','avelkavrh','12 - nadom3ščanj\r\n10 - IP Bojan\r\n2- IP Žiher, Orel\r\n2 - IPŠarec, Peterlin, Ramovš\r\n1- dež. rek. odmor\r\n7-dež pri kosilu'),(1032,39,2008,5,0,0,10,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,4.22,0.00,0.00,0.00,'2008-07-03 08:22:03','tancnik',''),(1033,11,2008,5,0,0,0,4.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,10.00,0.00,0,15.00,7.00,0.00,0.00,'2008-05-29 13:03:44','avelkavrh','Občasni timi: 1 h aktiv, 2 h svet staršev 14.5.; Druge obv.: NPZ \r\nizven delovneg časa 12.5. 2h, Kulralt 29.5. 1h; izredna IP za Mašo Gruden 16. in 19.5.; 4 ure za dodatno popravljanje testov razredov Jane Knez\r\n\r\n'),(1034,122,2008,5,0,0,0,0.00,0.00,9.00,0.00,0.00,4.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.50,0.00,0,0.00,1.00,0.00,0.00,'2008-05-28 14:00:25','avelkavrh','4,5- spremstvo ŠD\r\n3,5- spremstvo revija\r\n4- PU dodatne ure zbor\r\n3- dež pri koilu\r\n'),(1035,4,2008,5,0,0,0,4.00,0.00,5.00,0.00,0.00,0.00,3.50,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,9.00,0.00,0.00,'2008-05-28 14:07:33','avelkavrh','1- Slo'),(1036,26,2008,5,0,0,0,0.00,0.00,11.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,13.00,0.00,16.00,'2008-05-29 09:23:45','avelkavrh','1 ura-aktiv MA'),(1037,44,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 07:22:46','zkrivic','svet staršev 14.5.2008'),(1038,42,2008,5,0,0,20,0.00,0.00,6.00,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,15.00,1.00,0.00,0.00,'2008-06-06 09:10:34','avelkavrh','1- NPZ\r\n2- prva pomoč MEPI'),(1039,17,2008,5,0,0,0,0.00,0.00,3.00,0.00,0.00,8.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,3.00,6.00,0.00,0.00,'2008-05-29 10:01:28','avelkavrh','5- atletika\r\n3,5- atletika\r\n3- NPZ'),(1040,53,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-28 08:12:51','avelkavrh',''),(1041,67,2008,5,0,0,0,8.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1963.00,0.00,0.00,5.00,0.00,0,1.00,1.00,0.00,0.00,'2008-06-03 08:01:15','avelkavrh','1- aktiv TJA\r\n4- varovanje 7.ura\r\n1- NPZ (vpogled staršem)'),(1042,30,2008,5,0,0,0,4.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 10:52:12','avelkavrh','4- PP- Za življenje'),(1043,87,2008,5,0,0,0,0.00,0.00,9.00,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-05-29 13:05:18','avelkavrh','5- atletika\r\n3- atletika'),(1044,10,2008,5,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,35.00,0.00,0.00,0.00,0.00,0,0.00,7.00,0.00,0.00,'2008-06-28 07:26:49','avelkavrh','2- individualni pouk'),(1045,58,2008,5,0,0,0,4.00,0.00,1.00,60.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.50,0.00,0,0.00,5.00,0.00,0.00,'2008-06-13 10:39:42','tancnik','1,5- podaljšano dežurstvo\r\n4-študijska skupina\r\n2- eko dan\r\n7- spremstvo:CD, Pohod\r\n'),(1046,81,2008,5,0,0,0,4.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-05 14:38:10','avelkavrh','seminar Prva pomoč 12.5. '),(1047,46,2008,5,0,0,20,4.00,0.00,0.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-02 08:14:06','avelkavrh',''),(1048,57,2008,5,0,0,20,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,240.00,0.00,0.00,0.00,0.00,0,30.00,0.00,0.00,0.00,'2008-06-02 08:12:45','avelkavrh',''),(1049,35,2008,5,0,8,20,4.00,0.00,25.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-06-04 18:30:22','avelkavrh',''),(1050,35,2008,4,0,7,0,0.00,0.00,18.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-02 10:14:58','avelkavrh',''),(1051,71,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-02 13:44:54','tancnik',''),(1052,71,2008,5,0,0,20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-02 13:44:24','tancnik','4 ure - priprava kulinaričnega večera'),(1053,5,2008,5,0,0,0,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-06-04 18:24:33','avelkavrh',''),(1054,54,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,2.00,0.00,0.00,'2008-06-06 09:05:06','avelkavrh','3,5- atletika finale\r\n1,5- ŽZZ\r\n'),(1055,79,2008,6,0,0,0,0.00,0.00,30.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,11.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-28 08:34:21','avelkavrh','IP Tina Jakopec 8c 4h\r\nIP Miha Petrinič, Matic Pucko 7c 5h\r\nIP Damir Simetić 6h\r\nučna pomoč Janja Balant, Tea Uranjik 5b  4h\r\nizpit komisija Bojan Stojanović 2h\r\nakademija spremstvo 2h\r\naktiv maj in junij 2h\r\njedilnica dežurstvo maj in junij 7h\r\n6-priprava na pop.izpit Iris Novak\r\n1DU-komisija'),(1056,29,2008,6,0,0,0,0.00,0.00,8.00,0.00,0.00,21.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-24 13:03:37','tancnik','Jutranje varstvo 5 ur\r\nV izpitni komisiji GEO 1 ura\r\nSpremstvo učencev v Gardaland\r\nSpremstvo učencev v Izolo\r\nEvalvacijski sestanek za učence, ki imajo IP'),(1057,84,2008,6,0,0,0,0.00,0.00,14.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-07 09:54:55','avelkavrh','4- Bojan Stojanovič priprave na pop. izpit, pop. izpit\r\n4DU- svet šole\r\n\r\n18.6. spremstvo v hišo eksperimentov (4)\r\n23.6. izlet zlati maks (3)\r\n9PU- priprava gradiva za zbornik\r\n'),(1058,38,2008,6,0,0,0,0.00,0.00,2.00,0.00,0.00,7.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.45,0.00,0.00,0.00,'2008-07-03 08:21:30','tancnik','pozdrav poletju 2 h'),(1059,58,2008,6,0,0,0,0.00,0.00,5.00,0.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.75,0.00,0,0.00,0.00,0.00,0.00,'2008-06-26 11:36:23','avelkavrh','6.6.-spremstvo v Kolosej;\r\n10.6.-spremstvo v KD Črnuče;\r\npodaljšano dežurstvo;\r\n12.6.-nadomeščanje v 3.a'),(1060,44,2008,6,0,4.5,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-16 08:23:47','rpodborsek','13.6.08 koristila 4,5 ur od 10.30 do 15.00 ure'),(1061,51,2008,6,0,0,0,0.00,0.00,7.50,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.25,0,0.00,0.00,0.00,0.00,19.17,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 10:28:23','avelkavrh','Redne ure:\r\n- 4 ure ind. pouk z Aleksom Pajsarjem;\r\n2,5PU-priprava zbornika\r\n- 1 ura ponavljanje kolesarskega izpita 11.6.\r\nDelovne in druge obveznosti:\r\n- 5 ur dodatno dež. v jedilnici;\r\n- 4 ure ozvočevanja v KUL.DOMU 11.6;\r\n- 6 ur ozvočevanja valeta\r\n12.6.\r\n2-delo na akad. izven pouka\r\n1,25- delo z nadarjenimi timski set.\r\n2-uri svet šole'),(1062,33,2008,6,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:37:44','tancnik',''),(1063,85,2008,6,0,0,0,16.00,0.00,5.00,50.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,4.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,5.56,0.00,0.00,0.00,'2008-07-03 08:30:50','tancnik','Izobrazevanje - glina 16 ur\r\n4.ure-študijska 3. srecanje'),(1064,52,2008,6,0,0,0,16.00,0.00,0.00,450.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.00,0.00,0,5.06,0.00,0.00,0.00,'2008-07-03 08:25:05','tancnik','Izvedla sem 5 dodatnih ur dopolnilnega pouka.'),(1065,64,2008,6,0,0,0,16.00,0.00,5.00,50.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-24 13:51:09','tancnik','Individualne ure\r\nŠtudijska skupina'),(1066,65,2008,6,0,0,0,16.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,19.95,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:26:51','tancnik','študijska skupina\r\n15,95 - popis in ureditev vseh učnih pripomočkov in učil po razredih in kabinetu'),(1067,96,2008,6,0,0,0,16.00,0.00,5.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,10.35,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:31:48','tancnik','Študijska skupina - 3. srečanje (spletna učilnica): 30. 5. 2008\r\n6,35 - pospravljanje kabineta učil na SŠ'),(1068,37,2008,6,0,0,0,0.00,0.00,19.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,0.00,2.00,0.00,0.00,'2008-06-26 11:16:10','avelkavrh','1ura-8.b(oddelčna konferenca)\r\n3ure-nadzor v jedilnici\r\n1uraaktiv matematika\r\n3ure-Luka Orel (8.a)\r\n6ur-Stojanović\r\n2uri-Vasić\r\n5ur-8.b(delu z učenci)\r\n2-komosija pop.izpit Horvat J.'),(1069,102,2008,6,0,0,0,4.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,6.00,0.00,250.00,0.00,'2008-07-03 08:32:24','tancnik','KIPARSTVO\r\nPOZDRAV POLETJU'),(1070,25,2008,6,0,2,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-20 12:20:43','rpodborsek','16.6.2008 koristila 2 uri od 10.00 do 12.00'),(1071,86,2008,6,0,8,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-04 10:55:45','rpodborsek','23.6. in 24.6.2008 koristila ure\r\n19.6.2008 ocenjevalna konferenca'),(1072,6,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-30 10:45:50','obergant','19. 6. 2008 pedagoška konferenca'),(1073,16,2008,6,0,0,0,0.00,0.00,10.00,360.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-20 13:50:09','bdekleva',''),(1074,106,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,8.00,0.00,0,18.86,0.00,0.00,0.00,'2008-07-03 08:32:55','tancnik','tečaj keramike 03.junij 4h\r\n3. srečanje študij. skupin 4h\r\npozdrav poletju ? ur!!!'),(1075,34,2008,6,0,0,0,16.00,0.00,8.00,310.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,11.71,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:20:19','tancnik','5.6.2008,6.6.2008,20.6.22008-GLINA,30.5.2008-spremstvo Orle\r\n8,71 - pospravljanje športnih kabinetov na SŠ'),(1076,46,2008,6,0,0,0,0.00,0.00,1.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.84,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:23:59','tancnik','urejanje kabineta'),(1077,77,2008,6,0,0,0,0.00,0.00,4.00,300.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,17.54,1.00,180.00,0.00,'2008-07-03 08:28:29','tancnik',''),(1078,60,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-06-23 14:37:49','mmihelcic',''),(1079,14,2008,6,0,0,0,16.00,0.00,7.00,735.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-24 12:58:50','tancnik',''),(1080,67,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1.00,0,0.00,0.00,0.00,0.00,7.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-23 15:37:30','tnovak1','varovanje: 4.6,11.6.,18.6.;učna pomoč Damirju Simetiču: 3.6.,5.6.,10.6.; komisija za popravni izpit slov. Bojanu:6.6.(7.uro)- skupaj 7 ur. '),(1081,23,2008,6,0,0,0,4.00,0.00,16.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,8.26,0.00,0.00,0.00,'2008-07-03 08:18:03','tancnik','Izobraževanje: seminar oblikovanje gline (4 ure)\r\n2 uri: priprava na pozdrav poletju'),(1082,35,2008,6,0,22,0,0.00,0.00,22.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-28 08:52:03','avelkavrh','Izredni sestanek za 8.b/9'),(1083,98,2008,6,0,8,0,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,7.20,1.00,0.00,0.00,'2008-06-28 09:04:59','avelkavrh','12.5.- PP\r\n9.6. - izr. konf.8.b\r\n8-koriščenje ur'),(1084,21,2008,6,0,0,0,0.00,0.00,14.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.90,0.00,0.00,0.00,'2008-07-03 08:17:20','tancnik',''),(1085,124,2008,6,0,0,0,0.00,0.00,8.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,20.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-09 12:31:06','avelkavrh','B. Stojanović-6 ur\r\n1 - komisija pri raz izpitu\r\n2- član komisije pri pop. izpitu\r\n2- spremstvo akademija\r\n7- dežurstvo pri kosilu\r\n1- dežurstvo rek. od.\r\n7-prireditev pozdrav poletju(pevski zbori in rec.)'),(1086,50,2008,6,0,0,0,0.00,0.00,4.00,0.00,0.00,3.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,6.80,0.00,0.00,0.00,'2008-07-03 08:24:36','tancnik','4 ure študijska stupina, 2 uri pozdrav poletju'),(1087,9,2008,6,0,0,0,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,26.01,0.00,0.00,0.00,'2008-07-03 08:16:19','tancnik',''),(1088,80,2008,6,0,0,0,9.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,11.67,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:30:18','tancnik','urejanje in pospravljanje učil in didaktičnih pripomočkov na SŠ'),(1089,111,2008,6,0,0,0,4.00,0.00,5.00,270.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,5.37,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:33:53','tancnik','popis igrač in ureditev le teh za PB in JV'),(1090,66,2008,6,0,0,0,4.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,6.00,0.00,0,17.55,0.00,290.00,0.00,'2008-07-03 08:27:27','tancnik','4 ure študijske skupine, 2 uri pozdrav poletju'),(1091,78,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,100.00,0.00,0.00,0.00,0.00,0,26.71,0.00,0.00,0.00,'2008-07-03 08:29:05','tancnik',''),(1092,47,2008,6,0,0,0,0.00,0.00,6.00,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,19.55,0.00,0.00,0.00,'2008-06-28 08:02:22','avelkavrh','2-sest.8.b\r\n3-IP za 8.b (skupina učencev ZGO)'),(1093,26,2008,6,0,16,0,0.00,0.00,25.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,3.00,0.00,0,9.25,3.00,0.00,9.00,'2008-06-28 07:37:39','avelkavrh','1 ura-aktiv MA\r\n6 ur nadomeščanja-Žiga Hanc, Iris Novak\r\n4 ure-Jure Šestič, Žan Kajtna\r\n12 ur-Jan Horvat-dopolnilni pouk +2-krat popravni izpit\r\n1-spremstvo na akademijo\r\n1-oblikovanje skupin za urnik\r\n2-pop.izpit Iris Novak\r\n16DU-bo barbara potrebovala v avgustu za potovanje v Ameriko'),(1094,57,2008,6,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,13.55,0.00,0.00,0.00,'2008-06-28 08:24:07','avelkavrh',''),(1095,63,2008,6,0,0,0,0.00,6.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,8.84,0.00,0.00,0.00,'2008-06-28 08:58:51','avelkavrh','14. 6. 2008 - seminar za družbo: Državljanska vzgoja in etika, 9.00 - 15. 00\r\n1PU je že za izplačilo.'),(1096,10,2008,6,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,35.00,0.00,0.00,9.83,0.00,0,0.00,7.00,0.00,0.00,'2008-07-03 10:17:38','avelkavrh','Pod delovne in druge obveznosti sem štela individualne ure, ki sem jih imela z Žigo Hancem 13.6. in 16.6.\r\n7,83DU-priprava biltena'),(1097,105,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,480.00,0.00,0.00,1.00,0.00,0,16.83,1.00,0.00,0.00,'2008-06-28 09:52:00','avelkavrh','1-slo'),(1098,87,2008,6,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,7.77,1.00,0.00,0.00,'2008-06-28 09:50:20','avelkavrh','2-valeta od 17-19\r\n2-sest.8.b'),(1099,73,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-26 12:18:04','rpenezor','19.6.2008 - red. konf. - 3 ure;; 11.6.2008 - konf. za devet. razred. - 1 ura'),(1100,75,2008,6,0,8,0,0.00,0.00,6.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,130.00,0.00,0.00,4.00,0.00,0,12.17,0.00,0.00,0.00,'2008-06-30 12:58:40','avelkavrh','4-tečajPP 12.5.'),(1101,42,2008,6,0,0,0,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,25.50,0.00,0.00,0.00,'2008-06-28 07:46:18','avelkavrh','2-8.b izr. set.'),(1102,122,2008,6,0,0,0,11.00,0.00,13.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,15.00,0.00,0,4.86,0.00,0.00,0.00,'2008-06-28 08:44:01','avelkavrh','11 ur sem bil na izobraževanju z naslovom GLASBA V 8. RAZREDU OSNOVNE ŠOLE, in sicer 17. 06. 2008 in 26. 06. 2008.\r\n\r\n4 ure delovnih in drugih obveznosti sem pridobil z dežuranjem med kosilom.\r\n1 uro sem pridobil kot član komisije na popravnem izpitu 19. 06.2008.\r\n2 uri sem pridobil na sestanku za 8.b razred 09. 06. 2008\r\n8 ur delovnih in drugih obveznosti pa sem pridobil z organizacijo in izvedbo zaključne prireditve pevskih zborov naše šole 11. 06. 2008'),(1103,4,2008,6,0,0,0,0.00,0.00,7.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,18.67,0.00,0.00,0.00,'2008-06-28 07:38:25','avelkavrh','2-8.b\r\n2-Stojanović(pop. izpit)\r\n1-aktiv TJA\r\n4-priprva 9.razredov\r\n'),(1104,11,2008,6,0,0,0,0.00,0.00,18.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,36.50,0.00,0.00,0.00,'2008-06-28 07:39:27','avelkavrh','12-ind. ure za pomoč učencem\r\n2-8.b\r\n1-tja aktiv\r\n4-popravni izpit iz TJA\r\n2DU-komisija'),(1105,17,2008,6,0,0,0,0.00,0.00,2.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,10.00,0.00,0.00,0.00,'2008-06-28 07:39:57','avelkavrh','4-atletika\r\n2-valeta od17-19'),(1106,97,2008,6,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,1.50,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,15.75,0.00,0,0.00,3.00,0.00,0.00,'2008-07-03 10:32:09','avelkavrh','Izredni roditeljski sestanki - 9. 6. sestanke oddelčnega učiteljskega zbora za 8. b\r\nDrugo: \r\nČlan komisije za popravne oz. razredne izpite:\r\n- 20. 6. 30 min(S. Maksimovič)\r\n- 26. 6. 30 min (M. Kočar)\r\n- 27. 6. 30 min (Ž. Hanc)\r\n- 27. 6. 30 min (I. Mitrovič)\r\n- 27. 6. 45 min (pisni izpit Hanc in Mitrovič)\r\n\r\nPriprave za popravne oz. razredne izpite:\r\n- 17. 6. 1 PU (B. Stojanovič)\r\n- 23. 6. 1 PU (Hanc in Mitrovič)\r\n- 24. 6. 2 PU (Hanc in Mitrovič)\r\n- 26. 6. 2 PU (Hanc in Mitrovič)\r\n- 27. 6. 2 PU (Hanc in Mitrovič)\r\n\r\nVse skupaj: 14,75 ur\r\n1 DU-svet šole'),(1107,62,2008,6,0,0,0,0.00,0.00,22.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-06-28 09:43:36','avelkavrh','2- 8.b\r\n2-komisija pop. izpiti\r\n10- individualne ure fizike\r\n6- priprave na pop. izpit Suzana Maksimović\r\n1- popravni izpit\r\n5-nadomeščanje pouk'),(1108,100,2008,6,0,0,0,0.00,0.00,7.00,0.00,0.00,4.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,19.50,0.00,0,0.00,0.00,0.00,0.00,'2008-06-27 11:48:05','avelkavrh','17- scena za valeto\r\n4- Bojan Stojanovič priprave na pop. izpit\r\n1- razstava KD\r\n2-8.b\r\n1,5- urejanje učilnice'),(1109,81,2008,6,0,0,0,0.00,0.00,8.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,1.00,0.00,0.00,'2008-06-28 09:48:24','avelkavrh','sestanek 8.b 9.6.2008; nadomeščanje 4 ure ind. ure v 8.b, 4 ure dop. pouk Denis Žiher'),(1110,43,2008,6,0,0,0,0.00,0.00,11.00,180.00,240.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,9.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:21:54','avelkavrh','3- varstvo pri kosilu\r\n5- IP Jelenku Vasiču\r\n6DU-vnos ocen v redovalnico\r\n'),(1111,5,2008,6,0,0,0,0.00,0.00,0.00,0.00,1.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:25:48','avelkavrh','2- spremstvo na akademijo'),(1112,30,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,8.32,0.00,0.00,0.00,'2008-06-28 07:42:11','avelkavrh',''),(1113,53,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,10.00,0.00,0,15.00,0.00,0.00,0.00,'2008-06-28 08:15:17','avelkavrh','10du - pomoč pri urniku'),(1114,54,2008,6,0,0,0,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,2.75,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 07:59:48','avelkavrh','2,75- prevzem novih čolnov(so nam jih zamenjali za stare, ki so spustili po šivih)'),(1115,101,2008,6,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,8.50,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,4.23,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 10:33:55','avelkavrh','1 PU- Franci Zarnik, 2 PU - Jan Horvat\r\n1,25-urejanje dokumentacije 3.7.2008'),(1116,72,2008,5,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,1.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-02 13:10:14','avelkavrh','1- aktiv SLO'),(1117,72,2008,7,0,111.25,0,0.00,0.00,0.00,0.00,120.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 13:50:40','rpodborsek','ure je koristila julija 2008 za dopust'),(1118,45,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,80.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:23:17','tancnik','bolniška'),(1119,61,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,144.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 08:29:46','avelkavrh',''),(1120,27,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,-76.00,0.00,0.00,0.00,'2008-07-03 10:11:50','avelkavrh',''),(1121,86,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-04 10:56:04','rpodborsek',''),(1122,55,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,40.00,0.00,0,0.00,0.00,0.00,0.00,'2008-07-03 10:24:55','avelkavrh',''),(1123,124,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,11.50,0.00,0,0.00,0.00,0.00,0.00,'2008-07-09 12:36:28','avelkavrh','11,5 du - doprinos ur'),(1124,76,2008,7,0,0,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,'2008-08-04 10:22:03','rpodborsek','2.7.2008, svet šole');

/*Table structure for table `tabpregleddelan` */

DROP TABLE IF EXISTS `tabpregleddelan`;

CREATE TABLE `tabpregleddelan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Datum` timestamp NULL DEFAULT NULL,
  `Leto` smallint(5) DEFAULT NULL,
  `Mesec` smallint(5) DEFAULT NULL,
  `Dan` smallint(5) DEFAULT NULL,
  `Rubrika` smallint(5) DEFAULT NULL,
  `Komentar` text,
  `Enot` double DEFAULT NULL,
  `EnotPotrjeno` bit(1) NOT NULL,
  `DatVnosa` timestamp NULL DEFAULT NULL,
  `Ucitelj` int(10) DEFAULT NULL,
  `Vpisal` varchar(30) DEFAULT NULL,
  `Potrdil` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpregleddelan` */

/*Table structure for table `tabprehrana` */

DROP TABLE IF EXISTS `tabprehrana`;

CREATE TABLE `tabprehrana` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `zajtrk` bit(1) NOT NULL,
  `malica` bit(1) NOT NULL,
  `kosilo` bit(1) NOT NULL,
  `popmalica` bit(1) NOT NULL,
  `regresmalica` bit(1) NOT NULL,
  `regreskosilo` bit(1) NOT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `opombe` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprehrana` */

/*Table structure for table `tabprejemnikiobvestil` */

DROP TABLE IF EXISTS `tabprejemnikiobvestil`;

CREATE TABLE `tabprejemnikiobvestil` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idObvestilo` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idObvestilo` (`idObvestilo`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprejemnikiobvestil` */

/*Table structure for table `tabpreverjanje` */

DROP TABLE IF EXISTS `tabpreverjanje`;

CREATE TABLE `tabpreverjanje` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `paralelka` varchar(50) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  `predmet` int(10) DEFAULT NULL,
  `ZapSt` varchar(50) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idRazred` (`idRazred`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabpreverjanje` */

/*Table structure for table `tabprihodi` */

DROP TABLE IF EXISTS `tabprihodi`;

CREATE TABLE `tabprihodi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `SIFRA` varchar(10) DEFAULT NULL,
  `DATUMPRIH` timestamp NULL DEFAULT NULL,
  `LETOPR` varchar(4) DEFAULT NULL,
  `MESECPR` varchar(2) DEFAULT NULL,
  `DANPR` varchar(2) DEFAULT NULL,
  `URAPRIH` int(10) DEFAULT NULL,
  `MINPRIH` int(10) DEFAULT NULL,
  `VRSTAPRIH` varchar(4) DEFAULT NULL,
  `DATUMODH` timestamp NULL DEFAULT NULL,
  `LETODH` varchar(4) DEFAULT NULL,
  `MESECODH` varchar(2) DEFAULT NULL,
  `DANODH` varchar(2) DEFAULT NULL,
  `URAODH` int(10) DEFAULT NULL,
  `MINODH` int(10) DEFAULT NULL,
  `MINUT` int(10) DEFAULT NULL,
  `PMINUT` int(10) DEFAULT NULL,
  `VSTOPMEST` varchar(3) DEFAULT NULL,
  `SIFDELPOP` varchar(10) DEFAULT NULL,
  `ZAPSTVPIS` int(10) DEFAULT NULL,
  `POZICIJA` int(10) DEFAULT NULL,
  `OZNAKSPREM` int(10) DEFAULT NULL,
  `SISTEMDAT` timestamp NULL DEFAULT NULL,
  `USALDO` int(10) DEFAULT NULL,
  `MSALDO` int(10) DEFAULT NULL,
  `PRIPOMBA` varchar(60) DEFAULT NULL,
  `SSIFRA` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprihodi` */

/*Table structure for table `tabprimeridobrerabe` */

DROP TABLE IF EXISTS `tabprimeridobrerabe`;

CREATE TABLE `tabprimeridobrerabe` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `Naslov` varchar(250) DEFAULT NULL,
  `Skupina` text,
  `Predmet` varchar(50) DEFAULT NULL,
  `Tema` text,
  `Cilji` text,
  `avtor` varchar(50) DEFAULT NULL,
  `opis` text,
  `Pripomocki` text,
  `Povezave` text,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprimeridobrerabe` */

/*Table structure for table `tabprisotnost` */

DROP TABLE IF EXISTS `tabprisotnost`;

CREATE TABLE `tabprisotnost` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Mesec` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `Opraviceno` int(10) DEFAULT NULL,
  `Neopraviceno` int(10) DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `Datum` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdUcenec` (`IdUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprisotnost` */

/*Table structure for table `tabprogram` */

DROP TABLE IF EXISTS `tabprogram`;

CREATE TABLE `tabprogram` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sifra` varchar(50) DEFAULT NULL,
  `opis` varchar(250) DEFAULT NULL,
  `opisLopolis` varchar(50) DEFAULT NULL,
  `Opomba` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `tabprogram` */

insert  into `tabprogram`(`id`,`sifra`,`opis`,`opisLopolis`,`Opomba`) values (1,'3803','Program devetletne osnovne šole','SLO','Slovenska šola'),(2,'3804','Program devetletne osnovne šole /si/',NULL,NULL),(3,'3805','Program devetletne osnovne šole /is/',NULL,NULL),(4,'3806','Program devetletne osnovne šole /d/',NULL,NULL),(5,'3813','Prilagojeni program devetletne osnovne šole',NULL,NULL),(6,'4219','Osnovna šola za odrasle',NULL,NULL);

/*Table structure for table `tabprogrammss` */

DROP TABLE IF EXISTS `tabprogrammss`;

CREATE TABLE `tabprogrammss` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `odDatum` varchar(25) DEFAULT NULL,
  `doDatum` varchar(25) DEFAULT NULL,
  `program` varchar(255) DEFAULT NULL,
  `uspeh` varchar(25) DEFAULT NULL,
  `opomba` text,
  PRIMARY KEY (`ID`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprogrammss` */

/*Table structure for table `tabprojekti` */

DROP TABLE IF EXISTS `tabprojekti`;

CREATE TABLE `tabprojekti` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Mentor` int(10) DEFAULT NULL,
  `Projekt` varchar(250) DEFAULT NULL,
  `Sodelavci` text,
  `razseznost` varchar(50) DEFAULT NULL,
  `vkljuceni` text,
  `dosezki` text,
  `porocilo` text,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprojekti` */

/*Table structure for table `tabprostor` */

DROP TABLE IF EXISTS `tabprostor`;

CREATE TABLE `tabprostor` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdProstor` int(10) DEFAULT NULL,
  `Stevilka` varchar(5) DEFAULT NULL,
  `Oznaka` varchar(5) DEFAULT NULL,
  `Opis` varchar(50) DEFAULT NULL,
  `StMiz` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdProstor` (`IdProstor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabprostor` */

/*Table structure for table `tabracunovodstvo` */

DROP TABLE IF EXISTS `tabracunovodstvo`;

CREATE TABLE `tabracunovodstvo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `sifra` varchar(50) DEFAULT NULL,
  `kolicnik` double DEFAULT NULL,
  `placRazred` int(10) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `pl1` double DEFAULT NULL,
  `pl2` double DEFAULT NULL,
  `pl3` double DEFAULT NULL,
  `pl4` double DEFAULT NULL,
  `pl5` double DEFAULT NULL,
  `pl6` double DEFAULT NULL,
  `pl7` double DEFAULT NULL,
  `pl8` double DEFAULT NULL,
  `pl9` double DEFAULT NULL,
  `pl10` double DEFAULT NULL,
  `pl11` double DEFAULT NULL,
  `pl12` double DEFAULT NULL,
  `pldec` double DEFAULT NULL,
  `rdu1` double(24,2) DEFAULT NULL,
  `rdu2` double DEFAULT NULL,
  `rdu3` double DEFAULT NULL,
  `rdu4` double DEFAULT NULL,
  `rdu5` double DEFAULT NULL,
  `rdu6` double DEFAULT NULL,
  `rdu7` double DEFAULT NULL,
  `rdu8` double DEFAULT NULL,
  `rdu9` double DEFAULT NULL,
  `rdu10` double DEFAULT NULL,
  `rdu11` double DEFAULT NULL,
  `rdu12` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabracunovodstvo` */

/*Table structure for table `tabrazdat` */

DROP TABLE IF EXISTS `tabrazdat`;

CREATE TABLE `tabrazdat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `razred` int(10) DEFAULT NULL,
  `oznaka` varchar(50) DEFAULT NULL,
  `leto` int(10) DEFAULT NULL,
  `prostor` int(10) DEFAULT NULL,
  `osemdevet` int(10) DEFAULT NULL,
  `idsola` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8;

/*Data for the table `tabrazdat` */

/*Table structure for table `tabrazred` */

DROP TABLE IF EXISTS `tabrazred`;

CREATE TABLE `tabrazred` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `osemdevet` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `Uspeh` double DEFAULT NULL,
  `UspehPol` int(10) DEFAULT NULL,
  `Ponavljalec` int(10) DEFAULT NULL,
  `Napredovanje` int(10) DEFAULT NULL,
  `RazredniIzpit` int(10) DEFAULT NULL,
  `Nadarjen` int(10) DEFAULT NULL,
  `StatusSport` int(10) DEFAULT NULL,
  `StatusKult` int(10) DEFAULT NULL,
  `LetoSolanja` int(10) DEFAULT NULL,
  `IdUcitelj` int(10) DEFAULT NULL,
  `IdVzgojitelj` int(10) DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `DatumVpisa` timestamp NULL DEFAULT NULL,
  `EvidSt` varchar(50) DEFAULT NULL,
  `DatumIzdaje` varchar(50) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  `Opomba` text,
  `slika` text,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`),
  KEY `IdUcenec` (`IdUcenec`),
  KEY `IdVzgojitelj` (`IdVzgojitelj`),
  KEY `TabRazredIdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB AUTO_INCREMENT=6882 DEFAULT CHARSET=utf8;

/*Data for the table `tabrazred` */

/*Table structure for table `tabrazrednikpor` */

DROP TABLE IF EXISTS `tabrazrednikpor`;

CREATE TABLE `tabrazrednikpor` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Razrednik` int(10) DEFAULT NULL,
  `Komentar` text,
  `UcnoVzgDelo` text,
  `Pohvale` text,
  `VzgUkrepi` text,
  `Uspehi` text,
  `Priporocila` text,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `opb` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabrazrednikpor` */

/*Table structure for table `tabrazrednikpork` */

DROP TABLE IF EXISTS `tabrazrednikpork`;

CREATE TABLE `tabrazrednikpork` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Razrednik` int(10) DEFAULT NULL,
  `Komentar` text,
  `UcnoVzgDelo` text,
  `Pohvale` text,
  `VzgUkrepi` text,
  `Uspehi` text,
  `Priporocila` text,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `opb` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabrazrednikpork` */

/*Table structure for table `tabrealizacija` */

DROP TABLE IF EXISTS `tabrealizacija`;

CREATE TABLE `tabrealizacija` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Predmet` int(10) DEFAULT NULL,
  `PlanPol` double DEFAULT NULL,
  `RealizacijaPol` double DEFAULT NULL,
  `Plan` double DEFAULT NULL,
  `Realizacija` double DEFAULT NULL,
  `PlanNL` double DEFAULT NULL,
  `RealizacijaNL` double DEFAULT NULL,
  `Plan3` double DEFAULT NULL,
  `Realizacija3` double DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `Referenca` int(10) DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `Datum` timestamp NULL DEFAULT NULL,
  `Ucenje` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabrealizacija` */

/*Table structure for table `tabregistracije` */

DROP TABLE IF EXISTS `tabregistracije`;

CREATE TABLE `tabregistracije` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `registracija` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabregistracije` */

/*Table structure for table `tabsifrantdrzav` */

DROP TABLE IF EXISTS `tabsifrantdrzav`;

CREATE TABLE `tabsifrantdrzav` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sifra` varchar(50) DEFAULT NULL,
  `drzava` varchar(50) DEFAULT NULL,
  `drzava1` varchar(50) DEFAULT NULL,
  `drzavljan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantdrzav` */

insert  into `tabsifrantdrzav`(`id`,`sifra`,`drzava`,`drzava1`,`drzavljan`) values (1,'4','Afganistan','Afghanistan','Afganistana'),(2,'8','Albanija','Albania','Albanije'),(3,'10','Antarktika','Antarctica','Antarktike'),(4,'12','Alžirija','Algeria','Alžirije'),(5,'16','Ameriška Samoa','American Samoa','Ameriške Samoe'),(6,'20','Andora','Andorra','Andore'),(7,'24','Angola','Angola','Angole'),(8,'28','Antigva in Barbuda','Antigua and Barbuda','Antigve in Barbude'),(9,'31','Azerbajdžan','Azerbaijan','Azerbajdžana'),(10,'32','Argentina','Argentina','Argentine'),(11,'36','Avstralija','Australia','Avstralije'),(12,'40','Avstrija','Austria','Avstrije'),(13,'44','Bahami','Bahamas','Bahamov'),(14,'48','Bahrajn','Bahrain','Bahrajna'),(15,'50','Bangladeš','Bangladesh','Bangladeša'),(16,'51','Armenija','Armenia','Armenije'),(17,'52','Barbados','Barbados','Barbadosa'),(18,'56','Belgija','Belgium','Belgije'),(19,'60','Bermudi','Bermuda','Bermudov'),(20,'64','Butan','Bhutan','Butana'),(21,'68','Bolivija','Bolivia','Bolivije'),(22,'70','Bosna in Hercegovina','Bosnia and Herzegovina','Bosne in Hercegovine'),(23,'72','Bocvana','Botswana','Bocvane'),(24,'74','Bouvetov otok','Bouvet Island','Bouvetovega otoka'),(25,'76','Brazilija','Brazil','Brazilije'),(26,'84','Belize','Belize','Belizeja'),(27,'86','Britansko ozemlje Indijskega oceana','British Indian Ocean Territory','Britanskega ozemlja Ind. Oceana'),(28,'90','Salomonovi otoki','Solomon Islands','Salomonovih otokov'),(29,'92','Deviški otoki (britanski)','Virgin Islands, British','Deviških otokov (Britanskih)'),(30,'96','Brunej, Država','Brunei Darussalam','Države Brunej'),(31,'100','Bolgarija','Bulgaria','Bolgarije'),(32,'104','Mjanmar','Myanmar','Mjanmara'),(33,'108','Burundi','Burundi','Burundija'),(34,'112','Belorusija','Belarus','Belorusije'),(35,'116','Kambodža','Cambodia','Kambodže'),(36,'120','Kamerun','Cameroon','Kameruna'),(37,'124','Kanada','Canada','Kanade'),(38,'132','Zelenortski otoki','Cape Verde','Zelenortskih otokov'),(39,'136','Kajmanski otoki','Cayman Islands','Kajmanskih otokov'),(40,'140','Srednjeafriška republika','Central African Republic','Srednjeafriške republike'),(41,'144','Šrilanka','Sri Lanka','Šrilanke'),(42,'148','Čad','Chad','Čada'),(43,'152','Čile','Chile','Čila'),(44,'156','Kitajska','China','Kitajske'),(45,'158','Tajvan, Provinca Kitajske','Taiwan, province of China','Tajvana, Province Kitajske'),(46,'162','Božični otok','Christmas Island','Božičnih otokov'),(47,'166','Kokosovi (Keeling) otoki','Cocos (Keeling) Islands','Kokosovih (Keeling) otokov'),(48,'170','Kolumbija','Colombia','Kolumbije'),(49,'174','Komori','Comoros','Komora'),(50,'175','Mayotte','Mayotte','Mayotta'),(51,'178','Kongo','Congo','Konga'),(52,'180','Kongo, Demokratična republika','Congo, the Democratic Republic of the','Demokratične Republike Kongo'),(53,'184','Cookovi otoki','Cook Islands','Cookovih otokov'),(54,'188','Kostarika','Costa Rica','Kostarike'),(55,'191','Hrvaška','Croatia','Hrvaške'),(56,'192','Kuba','Cuba','Kube'),(57,'196','Ciper','Cyprus','Cipra'),(58,'203','Češka republika','Czech Republic','Češke Republike'),(59,'204','Benin','Benin','Benina'),(60,'208','Danska','Denmark','Danske'),(61,'212','Dominika','Dominica','Dominike'),(62,'214','Dominikanska republika','Dominican Republic','Dominikanske Republike'),(63,'218','Ekvador','Ecuador','Ekvadorja'),(64,'222','Salvador','El Salvador','Salvadorja'),(65,'226','Ekvatorialna Gvineja','Equatorial Guinea','Ekvatorialne Gvineje'),(66,'231','Etiopija','Ethiopia','Etiopije'),(67,'232','Eritreja','Eritrea','Eritreje'),(68,'233','Estonija','Estonia','Estonije'),(69,'234','Ferski otoki','Faroe Islands','Ferskih otokov'),(70,'238','Falklandski otoki (Malvini)','Falkland Islands (Malvinas)','Falklandskih otokov (Malvinija)'),(71,'239','Južna Georgia in otoki Južni Sandwich','South Georgia and the South Sandwich Islands','J. Georgie in ot. Sandwicha'),(72,'242','Fidži','Fiji','Fidžija'),(73,'246','Finska','Finland','Finske'),(74,'248','Aland otoki','Aland Islands','Finske - Aland Otoki'),(75,'250','Francija','France','Francije'),(76,'254','Francoska Gvajana','French Guiana','Francoske Gvajane'),(77,'258','Francoska Polinezija','French Polynesia','Francoske Polinezije'),(78,'260','Francosko južno ozemlje','French Southern Territories','Francoskega Južnega Ozemlja'),(79,'262','Džibuti','Djibouti','Džibutija'),(80,'266','Gabon','Gabon','Gabona'),(81,'268','Gruzija','Georgia','Gruzije'),(82,'270','Gambija','Gambia','Gambije'),(83,'275','Palestinsko ozemlje, zasedeno','Palestinian Territory, Occupied','Palestinskega ozemlja'),(84,'276','Nemčija','Germany','Nemčije'),(85,'288','Gana','Ghana','Gane'),(86,'292','Gibraltar','Gibraltar','Gibraltarja'),(87,'296','Kiribati','Kiribati','Kiribatija'),(88,'300','Grčija','Greece','Grčije'),(89,'304','Grenlandija','Greenland','Grenlandije'),(90,'308','Grenada','Grenada','Grenade'),(91,'312','Guadeloupe','Guadeloupe','Guadelupeja'),(92,'316','Guam','Guam','Guama'),(93,'320','Gvatemala','Guatemala','Gvatemale'),(94,'324','Gvineja','Guinea','Gvineje'),(95,'328','Gvajana','Guyana','Gvajane'),(96,'332','Haiti','Haiti','Haitija'),(97,'334','Heardov otok in McDonaldovi otoki','Heard Island and McDonald Islands','Heardobega ot. In Mcdonaldovih ot.'),(98,'336','Sveti sedež (Vatikanska mestna država)','Holy See (Vatican City State)','Sv. Sedeža (Vatikanske Mestn.D.)'),(99,'340','Honduras','Honduras','Hondurasa'),(100,'344','Hongkong','Hong Kong','Hongkonga'),(101,'348','Madžarska','Hungary','Madžarske'),(102,'352','Islandija','Iceland','Islandije'),(103,'356','Indija','India','indije'),(104,'360','Indonezija','Indonesia','Indonezije'),(105,'364','Iran (Islamska republika)','Iran, Islamic Republic of','Irana (Islamske Republike)'),(106,'368','Irak','Iraq','Iraka'),(107,'372','Irska','Ireland','Irske'),(108,'376','Izrael','Israel','Izraela'),(109,'380','Italija','Italy','Italije'),(110,'384','Slonokoščena obala','Cote D\'Ivoire','Slonokoščene obale'),(111,'388','Jamajka','Jamaica','Jamajke'),(112,'392','Japonska','Japan','Japonske'),(113,'398','Kazahstan','Kazakhstan','Kazahstana'),(114,'400','Jordanija','Jordan','Jordanije'),(115,'404','Kenija','Kenya','Kenije'),(116,'408','Koreja, Demokratična ljudska republika','Korea, Democratic People\'s Republic of','Koreje,Demokra. Ljud. R.'),(117,'410','Koreja, Republika','Korea, Republic of','Koreje, Republike'),(118,'414','Kuvajt','Kuwait','Kuvajta'),(119,'417','Kirgizistan','Kyrgyzstan','Kirgizistana'),(120,'418','Laoška ljudska demokratična republika','Lao People\'s Democratic Republic','Laoške Ljudske Demokr. Rep.'),(121,'422','Libanon','Lebanon','Libanona'),(122,'426','Lesoto','Lesotho','Lesota'),(123,'428','Latvija','Latvia','Latvije'),(124,'430','Liberija','Liberia','Liberije'),(125,'434','Libijska arabska džamahirija','Libyan Arab Jamahiriya','Libijske Arabske Džamahirije'),(126,'438','Lihtenštajn','Liechtenstein','Lihtenšteina'),(127,'440','Litva','Lithuania','Litve'),(128,'442','Luksemburg','Luxembourg','Luksemburga'),(129,'446','Macau','Macao','Macaua'),(130,'450','Madagaskar','Madagascar','Madagaskarja'),(131,'454','Malavi','Malawi','malavija'),(132,'458','Malezija','Malaysia','Malezije'),(133,'462','Maldivi','Maldives','Maldivov'),(134,'466','Mali','Mali','Malija'),(135,'470','Malta','Malta','Malte'),(136,'474','Martinik','Martinique','Martinika'),(137,'478','Mavretanija','Mauritania','Mavretanije'),(138,'480','Mauritius','Mauritius','Mauritiusa'),(139,'484','Mehika','Mexico','Mehike'),(140,'492','Monako','Monaco','Monaka'),(141,'496','Mongolija','Mongolia','mongolije'),(142,'498','Moldavija, Republika','Moldova, Republic of','Moldavije, Republike'),(143,'499','Črna Gora','Montenegro','Črne gore'),(144,'500','Montserrat','Montserrat','Montserrata'),(145,'504','Maroko','Morocco','Maroka'),(146,'508','Mozambik','Mozambique','Mozambika'),(147,'512','Oman','Oman','Omana'),(148,'516','Namibija','Namibia','Namibije'),(149,'520','Nauru','Nauru','Nauruja'),(150,'524','Nepal','Nepal','Nepala'),(151,'528','Nizozemska','Netherlands','Nizozemske'),(152,'530','Nizozemski Antili','Netherlands Antilles','Nizozemskih Antilov'),(153,'533','Aruba','Aruba','Arube'),(154,'540','Nova Kaledonija','New Caledonia','Nove Kaledonije'),(155,'548','Vanuatu','Vanuatu','Vanuatua'),(156,'554','Nova Zelandija','New Zealand','Nove Zelandije'),(157,'558','Nikaragva','Nicaragua','Nikaragve'),(158,'562','Niger','Niger','Nigra'),(159,'566','Nigerija','Nigeria','Nigerije'),(160,'570','Niue','Niue','Niua'),(161,'574','Norfolški otok','Norfolk Island','Norfolških otokov'),(162,'578','Norveška','Norway','Norveške'),(163,'580','Severni Marianski otoki','Northern Mariana Islands','Severnih Marianskih otokov'),(164,'581','Stranski zunanji otoki Združenih držav','United States Minor Outlying Islands','Stranskih Zunanjih Ot. Zdr. Dr.'),(165,'583','Mikronezija (Federativne države)','Micronesia, Federated states of','Mikronezije (Federat. Države)'),(166,'584','Marshallovi otoki','Marshall Islands','Marshallovih otokov'),(167,'585','Palau','Palau','Palaua'),(168,'586','Pakistan','Pakistan','Pakistana'),(169,'591','Panama','Panama','Paname'),(170,'598','Papua Nova Gvineja','Papua New Guinea','Papue Nove Gvineje'),(171,'600','Paragvaj','Paraguay','Paragvaja'),(172,'604','Peru','Peru','Peruja'),(173,'608','Filipini','Philippines','Filipinov'),(174,'612','Pitcairn','Pitcairn','Pitcairna'),(175,'616','Poljska','Poland','Poljske'),(176,'620','Portugalska','Portugal','Portugalske'),(177,'624','Gvineja Bissau','Guinea-Bissau','Gvineje Bissau'),(178,'626','Vzhodni Timor','Timor-Leste','Vzhodnega Timorja'),(179,'630','Portoriko','Puerto Rico','Portorika'),(180,'634','Katar','Qatar','Katarja'),(181,'638','Reunion','Reunion','Reuniona'),(182,'642','Romunija','Romania','Romunije'),(183,'643','Ruska federacija','Russian federation','Ruske Federacije'),(184,'646','Ruanda','Rwanda','Ruande'),(185,'654','Saint Helena','Saint Helena','Svete Helene'),(186,'659','Saint Kitts in Nevis','Saint Kitts and Nevis','Svetega Krištofa in Nevisa'),(187,'660','Angvila','Anguilla','Angvile'),(188,'662','Saint Lucia','Saint Lucia','Svete Lucije'),(189,'666','Saint Pierre in Miquelon','Saint Pierre and Miquelon','Saint Pierre in Miquelon'),(190,'670','Saint Vincent in Grenadine','Saint Vincent and the Grenadines','Svetega Vincenca in Grenadine'),(191,'674','San Marino','San Marino','San marina'),(192,'678','Sao Tome in Principe','Sao Tome and Principe','Sao Tomeja in Principe'),(193,'682','Saudova Arabija','Saudi Arabia','Saudove Arabije'),(194,'686','Senegal','Senegal','Senegala'),(195,'688','Srbija','Serbia','Srbije'),(196,'690','Sejšeli','Seychelles','Sejšelov'),(197,'694','Sierra Leone','Sierra Leone','Sierra Leoneja'),(198,'702','Singapur','Singapore','Singapurja'),(199,'703','Slovaška','Slovakia','Slovaške'),(200,'704','Vietnam','Viet Nam','Vietnama'),(201,'705','Slovenija','Slovenia','Slovenije'),(202,'706','Somalija','Somalia','Somalije'),(203,'710','Južna Afrika','South Africa','Južne Afrike'),(204,'716','Zimbabve','Zimbabwe','Zimbabveja'),(205,'724','Španija','Spain','Španije'),(206,'732','Zahodna Sahara','Western Sahara','Zahodne Sahare'),(207,'736','Sudan','Sudan','Sudana'),(208,'740','Surinam','Suriname','Surinama'),(209,'744','Svalbard in Jan Mayen','Svalbard and Jan Mayen','Svalbarda in Jan Mayena'),(210,'748','Svazi','Swaziland','Svazija'),(211,'752','Švedska','Sweden','Švedske'),(212,'756','Švica','Switzerland','Švice'),(213,'760','Sirska arabska republika','Syrian Arab republic','Sirske Arabske Republike'),(214,'762','Tadžikistan','Tajikistan','Tadžikistana'),(215,'764','Tajska','Thailand','Tajske'),(216,'768','Togo','Togo','Toga'),(217,'772','Tokelau','Tokelau','Tokelaua'),(218,'776','Tonga','Tonga','Tonge'),(219,'780','Trinidad in Tobago','Trinidad and Tobago','Trinidada in Tobaga'),(220,'784','Združeni arabski emirati','United Arab Emirates','Združenih Arabskih Emiratov'),(221,'788','Tunizija','Tunisia','Tunizije'),(222,'792','Turčija','Turkey','Turčije'),(223,'795','Turkmenistan','Turkmenistan','Turkmenistana'),(224,'796','Otoki Turks in Caicos','Turks and Caicos Islands','Otokov Trks in Caicos'),(225,'798','Tuvalu','Tuvalu','Tuvaluja'),(226,'800','Uganda','Uganda','Ugande'),(227,'804','Ukrajina','Ukraine','Ukrajine'),(228,'807','Makedonija, Nekdanja jugoslovanska republika','Macedonia, the Former Yugoslav Republic of','Makedonije, Nekdanje Jug. R.'),(229,'818','Egipt','Egypt','Egipta'),(230,'826','Združeno kraljestvo','United Kingdom','Združenega Kraljestva'),(231,'831','Guernsey','Guernsey','Guernseya'),(232,'832','Jersey','Jersey','Jerseya'),(233,'833','Otok Man','Isle of Man','Otoka Man'),(234,'834','Tanzanija, Združena republika','Tanzania, United Republic of','Tanzanije, Združene Republike'),(235,'840','Združene države','United States','Združenih Držav'),(236,'850','Deviški otoki (ZDA)','Virgin Islands, U.S.','Deviških otokov (ZDA)'),(237,'854','Burkina Faso','Burkina Faso','Burkine Faso'),(238,'858','Urugvaj','Uruguay','Urugvaja'),(239,'860','Uzbekistan','Uzbekistan','Uzbekistana'),(240,'862','Venezuela','Venezuela','Venezuele'),(241,'876','Otoki Wallis in Futuna','Wallis and Futuna','otokov Wallis in Futuna'),(242,'882','Samoa','Samoa','Samoe'),(243,'887','Jemen','Yemen','Jemna'),(244,'894','Zambija','Zambia','Zambije'),(245,'999','NERAZVRŠČENO','NOT CLASSIFIED','NERAZVRŠČENO'),(246,'991','Prenehalo','Prenehalo','Prenehalo'),(247,'992','Brez državljanstva','Brez državljanstva','Brez državljanstva'),(248,'993','Ni državljan RS','Ni državljan RS','Ni državljan RS'),(249,'994','V postopku','V postopku','V postopku'),(250,'995','Palestina','Palestina','Palestine'),(251,'996','Ni rezident druge članice EU','Ni rezident druge članice EU','Ni rezident druge članice EU'),(252,'998','Tujina','Tujina','Tujina');

/*Table structure for table `tabsifrantobvestil` */

DROP TABLE IF EXISTS `tabsifrantobvestil`;

CREATE TABLE `tabsifrantobvestil` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idObvestilo` int(10) DEFAULT NULL,
  `opis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idObvestilo` (`idObvestilo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantobvestil` */

insert  into `tabsifrantobvestil`(`ID`,`idObvestilo`,`opis`) values (1,0,'ni prebrano'),(2,1,'pomembno'),(3,2,'še kaži'),(4,3,'prebrano'),(5,4,'briši');

/*Table structure for table `tabsifrantodsuc` */

DROP TABLE IF EXISTS `tabsifrantodsuc`;

CREATE TABLE `tabsifrantodsuc` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idodsotnost` int(10) DEFAULT NULL,
  `odsotnost` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idodsotnost` (`idodsotnost`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantodsuc` */

insert  into `tabsifrantodsuc`(`ID`,`idodsotnost`,`odsotnost`) values (1,0,'ni vneseno'),(2,1,'opravičeno'),(3,2,'neopravičeno'),(4,3,'izbrisano');

/*Table structure for table `tabsifrantprogram` */

DROP TABLE IF EXISTS `tabsifrantprogram`;

CREATE TABLE `tabsifrantprogram` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `program` varchar(25) DEFAULT NULL,
  `opis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantprogram` */

insert  into `tabsifrantprogram`(`ID`,`program`,`opis`) values (1,'83250301','Vzgojno-izobraževalni program osnovne šole'),(2,'63366101','Prilagojen program devetletne osnovne šole z nižjim izobrazbenim standardom'),(3,'77382201','Posebni program vzgoje in izobraževanja');

/*Table structure for table `tabsifrantskupin` */

DROP TABLE IF EXISTS `tabsifrantskupin`;

CREATE TABLE `tabsifrantskupin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idSkupina` int(10) DEFAULT NULL,
  `skupina` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idSkupina` (`idSkupina`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantskupin` */

insert  into `tabsifrantskupin`(`id`,`idSkupina`,`skupina`) values (1,1,'vsi učitelji'),(2,2,'razredniki'),(3,3,'učitelji na razredni stopnji'),(4,4,'učitelji na predmetni stopnji'),(5,5,'učitelji prve triade'),(6,6,'učitelji druge triade'),(7,7,'učitelji tretje triade'),(8,8,'učitelji OPB'),(9,9,'vodje aktivov'),(10,10,'določeni učitelji'),(11,0,'nedoločeno'),(12,11,'razredniki druge triade'),(13,12,'razredniki tretje triade');

/*Table structure for table `tabsifrantstatusure` */

DROP TABLE IF EXISTS `tabsifrantstatusure`;

CREATE TABLE `tabsifrantstatusure` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idStatusUre` int(10) DEFAULT NULL,
  `opis` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idStatusUre` (`idStatusUre`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifrantstatusure` */

insert  into `tabsifrantstatusure`(`ID`,`idStatusUre`,`opis`) values (1,0,'redna ura'),(2,1,'nadomeščanje'),(3,2,'združena ura'),(4,3,'odpadla ura'),(5,4,'športni dan'),(6,5,'kulturni dan'),(7,6,'naravoslovni dan'),(8,7,'tehniški dan'),(9,8,'šola v naravi'),(10,9,'ekskurzija'),(11,10,'proslava'),(12,11,'drugo');

/*Table structure for table `tabsifranttekm` */

DROP TABLE IF EXISTS `tabsifranttekm`;

CREATE TABLE `tabsifranttekm` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `idTekmovanja` int(10) DEFAULT NULL,
  `opis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idTekmovanja` (`idTekmovanja`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifranttekm` */

insert  into `tabsifranttekm`(`ID`,`idTekmovanja`,`opis`) values (1,0,'ni izbran'),(2,1,'Tekmovanja v znanju'),(3,2,'Projekti'),(4,3,'Natečaji'),(5,4,'Raziskovalne naloge'),(6,5,'Seminarske naloge'),(7,6,'Druga tekmovanja');

/*Table structure for table `tabsifraodsotnosti` */

DROP TABLE IF EXISTS `tabsifraodsotnosti`;

CREATE TABLE `tabsifraodsotnosti` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sifra` int(10) DEFAULT NULL,
  `odsotnost` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifraodsotnosti` */

insert  into `tabsifraodsotnosti`(`id`,`sifra`,`odsotnost`) values (1,1,'Službena odsotnost'),(2,2,'Bolniška odsotnost'),(3,3,'Službeno potovanje'),(4,4,'Izobraževanje'),(5,5,'Redni dopust'),(6,6,'Izredni dopust'),(7,7,'Neplačan dopust'),(8,8,'Tabor/šola v naravi'),(9,9,'Spremljanje učencev'),(10,10,'Neopravičena odsotnost'),(11,11,'Pozabljena kartica'),(12,12,'Drugo'),(13,13,'Bolniška odsotnost 4 ure'),(14,14,'Porodniški dopust'),(15,15,'Varstvo, nega otroka'),(16,16,'Koriščenje ur');

/*Table structure for table `tabsifreobcin` */

DROP TABLE IF EXISTS `tabsifreobcin`;

CREATE TABLE `tabsifreobcin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sifra` varchar(50) DEFAULT NULL,
  `obcina` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

/*Data for the table `tabsifreobcin` */

insert  into `tabsifreobcin`(`id`,`sifra`,`obcina`) values (1,'001','Ajdovščina'),(2,'195','Apače'),(3,'002','Beltinci'),(4,'148','Benedikt'),(5,'149','Bistrica ob Sotli'),(6,'003','Bled'),(7,'150','Bloke'),(8,'004','Bohinj'),(9,'005','Borovnica'),(10,'006','Bovec'),(11,'151','Braslovče'),(12,'007','Brda'),(13,'008','Brezovica'),(14,'009','Brežice'),(15,'152','Cankova'),(16,'011','Celje'),(17,'012','Cerklje na Gorenjskem'),(18,'013','Cerknica'),(19,'014','Cerkno'),(20,'153','Cerkvenjak'),(21,'196','Cirkulane'),(22,'015','Črenšovci'),(23,'016','Črna na Koroškem'),(24,'017','Črnomelj'),(25,'018','Destrnik'),(26,'019','Divača'),(27,'154','Dobje'),(28,'020','Dobrepolje'),(29,'155','Dobrna'),(30,'021','Dobrova - Polhov Gradec'),(31,'156','Dobrovnik/Dobronak'),(32,'022','Dol pri Ljubljani'),(33,'157','Dolenjske Toplice'),(34,'023','Domžale'),(35,'024','Dornava'),(36,'025','Dravograd'),(37,'026','Duplek'),(38,'027','Gorenja vas - Poljane'),(39,'028','Gorišnica'),(40,'207','Gorje'),(41,'029','Gornja Radgona'),(42,'030','Gornji Grad'),(43,'031','Gornji Petrovci'),(44,'158','Grad'),(45,'032','Grosuplje'),(46,'159','Hajdina'),(47,'160','Hoče - Slivnica'),(48,'161','Hodoš/Hodos'),(49,'162','Horjul'),(50,'034','Hrastnik'),(51,'035','Hrpelje - Kozina'),(52,'036','Idrija'),(53,'037','Ig'),(54,'038','Ilirska Bistrica'),(55,'039','Ivančna Gorica'),(56,'040','Izola/Isola'),(57,'041','Jesenice'),(58,'163','Jezersko'),(59,'042','Juršinci'),(60,'043','Kamnik'),(61,'044','Kanal'),(62,'045','Kidričevo'),(63,'046','Kobarid'),(64,'047','Kobilje'),(65,'048','Kočevje'),(66,'049','Komen'),(67,'164','Komenda'),(68,'050','Koper/Capodistria'),(69,'197','Kostanjevica na Krki'),(70,'165','Kostel'),(71,'051','Kozje'),(72,'052','Kranj'),(73,'053','Kranjska Gora'),(74,'166','Križevci'),(75,'054','Krško'),(76,'055','Kungota'),(77,'056','Kuzma'),(78,'057','Laško'),(79,'058','Lenart'),(80,'059','Lendava/Lendva'),(81,'060','Litija'),(82,'061','Ljubljana'),(83,'062','Ljubno'),(84,'063','Ljutomer'),(85,'208','Log - Dragomer'),(86,'064','Logatec'),(87,'065','Loška dolina'),(88,'066','Loški Potok'),(89,'167','Lovrenc na Pohorju'),(90,'067','Luče'),(91,'068','Lukovica'),(92,'069','Majšperk'),(93,'198','Makole'),(94,'070','Maribor'),(95,'168','Markovci'),(96,'071','Medvode'),(97,'072','Mengeš'),(98,'073','Metlika'),(99,'074','Mežica'),(100,'169','Miklavž na Dravskem polju'),(101,'075','Miren - Kostanjevica'),(102,'170','Mirna Peč'),(103,'076','Mislinja'),(104,'199','Mokronog - Trebelno'),(105,'077','Moravče'),(106,'078','Moravske Toplice'),(107,'079','Mozirje'),(108,'080','Murska Sobota'),(109,'081','Muta'),(110,'082','Naklo'),(111,'083','Nazarje'),(112,'084','Nova Gorica'),(113,'085','Novo mesto'),(114,'086','Odranci'),(115,'171','Oplotnica'),(116,'087','Ormož'),(117,'088','Osilnica'),(118,'089','Pesnica'),(119,'090','Piran/Pirano'),(120,'091','Pivka'),(121,'092','Podčetrtek'),(122,'172','Podlehnik'),(123,'093','Podvelka'),(124,'200','Poljčane'),(125,'173','Polzela'),(126,'094','Postojna'),(127,'174','Prebold'),(128,'095','Preddvor'),(129,'175','Prevalje'),(130,'096','Ptuj'),(131,'097','Puconci'),(132,'098','Rače - Fram'),(133,'099','Radeče'),(134,'100','Radenci'),(135,'101','Radlje ob Dravi'),(136,'102','Radovljica'),(137,'103','Ravne na Koroškem'),(138,'176','Razkrižje'),(139,'209','Rečica ob Savinji'),(140,'201','Renče - Vogrsko'),(141,'104','Ribnica'),(142,'177','Ribnica na Pohorju'),(143,'106','Rogaška Slatina'),(144,'105','Rogašovci'),(145,'107','Rogatec'),(146,'108','Ruše'),(147,'178','Selnica ob Dravi'),(148,'109','Semič'),(149,'110','Sevnica'),(150,'111','Sežana'),(151,'112','Slovenj Gradec'),(152,'113','Slovenska Bistrica'),(153,'114','Slovenske Konjice'),(154,'179','Sodražica'),(155,'180','Solčava'),(156,'202','Središče ob Dravi'),(157,'115','Starše'),(158,'203','Straža'),(159,'181','Sveta Ana'),(160,'204','Sveta Trojica v Slov. goricah'),(161,'182','Sveti Andraž v Slov. goricah'),(162,'116','Sveti Jurij'),(163,'210','Sveti Jurij v Slov. goricah'),(164,'205','Sveti Tomaž'),(165,'033','Šalovci'),(166,'183','Šempeter - Vrtojba'),(167,'117','Šenčur'),(168,'118','Šentilj'),(169,'119','Šentjernej'),(170,'120','Šentjur'),(171,'211','Šentrupert'),(172,'121','Škocjan'),(173,'122','Škofja Loka'),(174,'123','Škofljica'),(175,'124','Šmarje pri Jelšah'),(176,'206','Šmarješke Toplice'),(177,'125','Šmartno ob Paki'),(178,'194','Šmartno pri Litiji'),(179,'126','Šoštanj'),(180,'127','Štore'),(181,'184','Tabor'),(182,'010','Tišina'),(183,'128','Tolmin'),(184,'129','Trbovlje'),(185,'130','Trebnje'),(186,'185','Trnovska vas'),(187,'186','Trzin'),(188,'131','Tržič'),(189,'132','Turnišče'),(190,'133','Velenje'),(191,'187','Velika Polana'),(192,'134','Velike Lašče'),(193,'188','Veržej'),(194,'135','Videm'),(195,'136','Vipava'),(196,'137','Vitanje'),(197,'138','Vodice'),(198,'139','Vojnik'),(199,'189','Vransko'),(200,'140','Vrhnika'),(201,'141','Vuzenica'),(202,'142','Zagorje ob Savi'),(203,'143','Zavrč'),(204,'144','Zreče'),(205,'190','Žalec'),(206,'146','Železniki'),(207,'191','Žetale'),(208,'147','Žiri'),(209,'192','Žirovnica'),(210,'193','Žužemberk'),(211,'000','Tujina'),(212,'999','Nedoločeno');

/*Table structure for table `tabsistemizacija` */

DROP TABLE IF EXISTS `tabsistemizacija`;

CREATE TABLE `tabsistemizacija` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idSistemizacija` int(10) DEFAULT NULL,
  `Opis` varchar(100) DEFAULT NULL,
  `Povezava` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idSistemizacija` (`idSistemizacija`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

/*Data for the table `tabsistemizacija` */

insert  into `tabsistemizacija`(`id`,`idSistemizacija`,`Opis`,`Povezava`) values (1,1,'Ravnatelj OŠ','RavnateljOS.pdf'),(2,2,'Pomočnik ravnatelja','PomocnikRavnatelja.pdf'),(3,3,'Poslovni sekretar VI','PoslovniSekretarVI.pdf'),(4,4,'Računovodja VI','RacunovodjaVI.pdf'),(5,5,'Spremljevalec gibalno oviranih učencev','Spremljevalec.pdf'),(6,6,'Hišnik IV','Hisnik.pdf'),(7,7,'Čistilka II','Cistilka.pdf'),(8,8,'Kuhar IV','KuharIV.pdf'),(9,9,'Kuhinjski pomočnik III','KuhPomocnikIII.pdf'),(10,10,'Kuharski pomočnik II','KuhPomocnikII.pdf'),(11,11,'Svetovalni delavec','SvetovalniDel.pdf'),(12,12,'Knjižničar','Knjiznicar.pdf'),(13,13,'Računalnikar organizator informacijskih dejavnosti','Racunalnicar.pdf'),(14,14,'Organizator šolske prehrane','OrgPrehrane.pdf'),(15,15,'Laborant III','LaborantIII.pdf'),(16,16,'Učitelj razrednega pouka','UciteljRaz.pdf'),(17,17,'Drugi učitelj v prvem razredu','DrugiUc.pdf'),(18,18,'Učitelj slovenščine','Slovenscina.pdf'),(19,19,'Učitelj matematike','Matematika.pdf'),(20,20,'Učitelj angleščine','Anglescina.pdf'),(21,21,'Učitelj likovne vzgoje','Likovni.pdf'),(22,22,'Učitelj glasbene vzgoje','Glasba.pdf'),(23,23,'Učitelj geografije','Geografija.pdf'),(24,24,'Učitelj zgodovine','Zgodovina.pdf'),(25,25,'Učitelj državljanske vzgoje in etike','DrzVzgoja.pdf'),(26,26,'Učitelj fizike','fizika.pdf'),(27,27,'Učitelj kemije','Kemija.pdf'),(28,28,'Učitelj biologije','Biologija.pdf'),(29,29,'Učitelj naravoslovja','Naravoslovje.pdf'),(30,30,'Učitelj gospodinjstva','Gospodinjstvo.pdf'),(31,31,'Učitelj tehnike in tehnologije','Tehnika.pdf'),(32,32,'Učitelj športne vzgoje','Sport.pdf'),(33,33,'Učitelj izbirnega predmeta multimedija','mme.pdf'),(34,34,'Učitelj izbirnega predmeta nemščina','Nemscina.pdf'),(35,35,'Učitelj izbirnega predmeta francoščina','Francoscina.pdf'),(36,36,'Učitelj izbirnega predmeta obdelava gradiv - les','ogl.pdf'),(37,37,'Učitelj izbirnega predmeta računalniška omrežja','rom.pdf'),(38,38,'Učitelj izbirnega predmeta sodobna priprava hrane','sph.pdf'),(39,39,'Učitelj izbirnega predmeta šport za sprostitev','ssp.pdf'),(40,40,'Učitelj izbirnega predmeta šport za zdravje','szz.pdf'),(41,41,'Učitelj izbirnega predmeta izbrani šport','isp.pdf'),(42,42,'Učitelj izbirnega predmeta turistična vzgoja','tvz.pdf'),(43,43,'Učitelj izbirnega predmeta likovno snovanje','ls.pdf'),(44,44,'Učitelj izbirnega predmeta urejanje besedil','ube.pdf'),(45,45,'Učitelj izbirnega predmeta gledališki klub','gkl.pdf'),(46,46,'Učitelj izbirnega predmeta šolsko novinarstvo','sno.pdf'),(47,47,'Učitelj izbirnega predmeta poskusi v kemiji','pok.pdf'),(48,48,'Učitelj v oddelku podaljšanega bivanja','opb.pdf'),(49,49,'Učitelj individualne in skupinske pomoči','ucisp.pdf'),(50,50,'Učitelj dodatnega in dopolnilnega pouka','dod.pdf'),(51,51,'Učitelj za dodatno strokovno pomoč','dsp.pdf'),(52,52,'Strokovni delavec v jutranjem varstvu za učence 1. razreda','juv.pdf'),(53,53,'Učitelj latinščine','latinscina.pdf'),(54,54,'Učitelj španščine','spanscina.pdf'),(55,55,'Učitelj italijanščine','italijanscina.pdf'),(56,56,'Učitelj tujega jezika','tujjezik.pdf');

/*Table structure for table `tabsola` */

DROP TABLE IF EXISTS `tabsola`;

CREATE TABLE `tabsola` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Sola` varchar(100) DEFAULT NULL,
  `Naslov` varchar(100) DEFAULT NULL,
  `Posta` varchar(50) DEFAULT NULL,
  `Kraj` varchar(50) DEFAULT NULL,
  `Ravnatelj` varchar(50) DEFAULT NULL,
  `SolaKratko` varchar(50) DEFAULT NULL,
  `UstanovaID` int(10) DEFAULT NULL,
  `UstanovaIDmin` varchar(50) DEFAULT NULL,
  `Obcina` varchar(50) DEFAULT NULL,
  `pomocnik_ID1` int(10) DEFAULT NULL,
  `pomocnik_ID2` int(10) DEFAULT NULL,
  `ravnatelj_ID` int(10) DEFAULT NULL,
  `NPZSifra` varchar(50) DEFAULT NULL,
  `TipSole` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `internet` varchar(50) DEFAULT NULL,
  `ddv_ID` varchar(50) DEFAULT NULL,
  `zavezanecDDV` varchar(50) DEFAULT NULL,
  `trr` varchar(50) DEFAULT NULL,
  `telefon` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `SifraMSS` varchar(5) DEFAULT NULL,
  `Program` varchar(50) DEFAULT NULL,
  `MaticnaSola` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ddv_ID` (`ddv_ID`),
  KEY `Id` (`Id`),
  KEY `ravnatelj_ID` (`ravnatelj_ID`),
  KEY `UstanovaID` (`UstanovaID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `tabsola` */

insert  into `tabsola`(`Id`,`Sola`,`Naslov`,`Posta`,`Kraj`,`Ravnatelj`,`SolaKratko`,`UstanovaID`,`UstanovaIDmin`,`Obcina`,`pomocnik_ID1`,`pomocnik_ID2`,`ravnatelj_ID`,`NPZSifra`,`TipSole`,`email`,`internet`,`ddv_ID`,`zavezanecDDV`,`trr`,`telefon`,`fax`,`SifraMSS`,`Program`,`MaticnaSola`) values (1,'','','0','','','',0,'','999',0,0,0,'','Slovenska šola','','','','','','','','','3803','');

/*Table structure for table `tabsst` */

DROP TABLE IF EXISTS `tabsst`;

CREATE TABLE `tabsst` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `krozek` varchar(50) DEFAULT NULL,
  `stopnja` int(10) DEFAULT NULL,
  `mentor` varchar(50) DEFAULT NULL,
  `porocilo` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabsst` */

/*Table structure for table `tabsstclan` */

DROP TABLE IF EXISTS `tabsstclan`;

CREATE TABLE `tabsstclan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `mentor1` varchar(50) DEFAULT NULL,
  `mentor2` varchar(50) DEFAULT NULL,
  `datum` varchar(15) DEFAULT NULL,
  `tekmovanje` varchar(50) DEFAULT NULL,
  `idtekmovanje` int(10) DEFAULT NULL,
  `priznanje` varchar(50) DEFAULT NULL,
  `napredovanje` bit(1) NOT NULL,
  `stopnja` varchar(50) DEFAULT NULL,
  `kraj` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `idDogodek` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idtekmovanje` (`idtekmovanje`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabsstclan` */

/*Table structure for table `tabstatus` */

DROP TABLE IF EXISTS `tabstatus`;

CREATE TABLE `tabstatus` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdStatus` int(10) DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdStatus` (`IdStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `tabstatus` */

insert  into `tabstatus`(`Id`,`IdStatus`,`Status`) values (1,0,'Ni več aktiven'),(2,1,'Zaposlen na šoli (nedoločen čas)'),(3,2,'Zaposlen na šoli in gostuje še na drugih šolah (nedoločen čas)'),(4,3,'Pripravnik'),(5,10,'Zaposlen na drugi šoli in gostuje na tej'),(6,4,'Zaposlen na šoli (določen čas)'),(7,5,'Zaposlen na šoli in gostuje še na drugih šolah (določen čas)');

/*Table structure for table `tabsvet` */

DROP TABLE IF EXISTS `tabsvet`;

CREATE TABLE `tabsvet` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Ime` varchar(50) DEFAULT NULL,
  `Priimek` varchar(50) DEFAULT NULL,
  `Naslov` varchar(255) DEFAULT NULL,
  `Posta` varchar(50) DEFAULT NULL,
  `Opomba` varchar(250) DEFAULT NULL,
  `Funkcija` int(10) DEFAULT NULL,
  `Telefon` varchar(250) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `ZacMandata` varchar(50) DEFAULT NULL,
  `KonMandata` varchar(50) DEFAULT NULL,
  `SvetStarsev` bit(1) NOT NULL,
  `SvetSole` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabsvet` */

/*Table structure for table `tabsvetstarsev` */

DROP TABLE IF EXISTS `tabsvetstarsev`;

CREATE TABLE `tabsvetstarsev` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `svet` int(10) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabsvetstarsev` */

/*Table structure for table `tabtabordata` */

DROP TABLE IF EXISTS `tabtabordata`;

CREATE TABLE `tabtabordata` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `razred` int(10) DEFAULT NULL,
  `paralelka` varchar(50) DEFAULT NULL,
  `DatumZac` varchar(50) DEFAULT NULL,
  `DatumKon` varchar(50) DEFAULT NULL,
  `Kraj` varchar(50) DEFAULT NULL,
  `Vrsta` varchar(50) DEFAULT NULL,
  `Znesek` double DEFAULT NULL,
  `Spremljevalci` varchar(50) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabtabordata` */

/*Table structure for table `tabtabori` */

DROP TABLE IF EXISTS `tabtabori`;

CREATE TABLE `tabtabori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `Udelezba` bit(1) NOT NULL,
  `Brezplacno` bit(1) NOT NULL,
  `Subvencija` bit(1) NOT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `Opomba` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabtabori` */

/*Table structure for table `tabtekmovanja` */

DROP TABLE IF EXISTS `tabtekmovanja`;

CREATE TABLE `tabtekmovanja` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idUcenec` int(10) DEFAULT NULL,
  `mentor1` int(10) DEFAULT NULL,
  `mentor2` int(10) DEFAULT NULL,
  `datum` varchar(15) DEFAULT NULL,
  `tekmovanje` varchar(50) DEFAULT NULL,
  `idtekmovanje` int(10) DEFAULT NULL,
  `priznanje` varchar(50) DEFAULT NULL,
  `napredovanje` int(10) DEFAULT NULL,
  `stopnja` varchar(50) DEFAULT NULL,
  `kraj` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `idDogodek` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idtekmovanje` (`idtekmovanje`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabtekmovanja` */

/*Table structure for table `tabtujci` */

DROP TABLE IF EXISTS `tabtujci`;

CREATE TABLE `tabtujci` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  `listina` varchar(250) DEFAULT NULL,
  `drzavaListine` varchar(50) DEFAULT NULL,
  `UstanovaListine` varchar(100) DEFAULT NULL,
  `datumListine` varchar(50) DEFAULT NULL,
  `izobProgram` varchar(250) DEFAULT NULL,
  `komentar` text,
  `cas` varchar(50) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `evidst` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabtujci` */

/*Table structure for table `tabucenci` */

DROP TABLE IF EXISTS `tabucenci`;

CREATE TABLE `tabucenci` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `IdUcenec` int(10) DEFAULT NULL,
  `Priimek` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Ime` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `DatRoj` date DEFAULT NULL,
  `KrajRoj` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `DrzavaRoj` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Drzavljanstvo` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `emso` varchar(13) DEFAULT NULL,
  `MaticniList` varchar(10) DEFAULT NULL,
  `MaticnaKnjiga` varchar(20) DEFAULT NULL,
  `Naslov` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Posta` int(10) DEFAULT NULL,
  `Kraj` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `NaslovZac` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `PostaZac` int(10) DEFAULT NULL,
  `KrajZac` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `TelefonDoma` varchar(50) DEFAULT NULL,
  `oce` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `ocenaslov` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `ocekontakt` varchar(100) DEFAULT NULL,
  `oceGSM` varchar(50) DEFAULT NULL,
  `oceSluzba` varchar(50) DEFAULT NULL,
  `oceemail` varchar(100) DEFAULT NULL,
  `mati` varchar(255) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `matinaslov` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `matikontakt` varchar(100) DEFAULT NULL,
  `matiGSM` varchar(50) DEFAULT NULL,
  `matiSluzba` varchar(50) DEFAULT NULL,
  `matiemail` varchar(100) DEFAULT NULL,
  `Aktivnost` int(10) DEFAULT NULL,
  `LetoRoj` int(10) DEFAULT NULL,
  `IdKrajBivanja` int(10) DEFAULT NULL,
  `IdKrajBivanjaZac` int(10) DEFAULT NULL,
  `Spol` varchar(1) DEFAULT NULL,
  `IdPosebnePotrebe` int(10) DEFAULT NULL,
  `Bivanje` int(10) DEFAULT NULL,
  `Rom` int(10) DEFAULT NULL,
  `ZacSolanja` varchar(50) DEFAULT NULL,
  `KonSolanja` varchar(50) DEFAULT NULL,
  `ZacSolanjaSola` varchar(50) DEFAULT NULL,
  `KonSolanjaSola` varchar(50) DEFAULT NULL,
  `Skrbniki` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `SkrbnikiNaslov` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `SkrbnikiKontakt` varchar(100) DEFAULT NULL,
  `SkrbnikiEmail` varchar(100) DEFAULT NULL,
  `Placnik` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `PlacnikNaslov` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `PlacnikKontakt` varchar(100) DEFAULT NULL,
  `Opombe` text,
  `OSObveza` varchar(12) DEFAULT NULL,
  `SolskiOkolis` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `OtrokZiviPri` int(10) DEFAULT NULL,
  `geslo` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `ocezacnasl` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `matizacnasl` varchar(100) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IdKrajBivanja` (`IdKrajBivanja`),
  KEY `IdKrajBivanjaZac` (`IdKrajBivanjaZac`),
  KEY `IdPosebnePotrebe` (`IdPosebnePotrebe`),
  KEY `IdUcenec` (`IdUcenec`)
) ENGINE=InnoDB AUTO_INCREMENT=1958 DEFAULT CHARSET=utf8;

/*Data for the table `tabucenci` */

/*Table structure for table `tabucenje` */

DROP TABLE IF EXISTS `tabucenje`;

CREATE TABLE `tabucenje` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdUcitelj` int(10) DEFAULT NULL,
  `Predmet` int(10) DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `osemdevet` int(10) DEFAULT NULL,
  `Planirano` double DEFAULT NULL,
  `Zdruzeno` int(10) DEFAULT NULL,
  `Realizirano` int(10) DEFAULT NULL,
  `MSS` int(10) DEFAULT NULL,
  `Obcina` int(10) DEFAULT NULL,
  `Drugi` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`),
  KEY `IdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabucenje` */

/*Table structure for table `tabucitelji` */

DROP TABLE IF EXISTS `tabucitelji`;

CREATE TABLE `tabucitelji` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdUcitelj` int(10) DEFAULT NULL,
  `Priimek` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Ime` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Dekliski` varchar(255) DEFAULT NULL,
  `Spol` varchar(1) DEFAULT NULL,
  `DatRoj` date DEFAULT NULL,
  `LetoRoj` int(10) DEFAULT NULL,
  `EMSO` varchar(13) DEFAULT NULL,
  `Naslov` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Posta` int(10) DEFAULT NULL,
  `Kraj` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Izobrazba` int(10) DEFAULT NULL,
  `IzobOpis` varchar(250) DEFAULT NULL,
  `IzobUstr` int(10) DEFAULT NULL,
  `IdDelo` int(10) DEFAULT NULL,
  `DelovniCas` int(10) DEFAULT NULL,
  `IdVzgojnoDelo` int(10) DEFAULT NULL,
  `DelDobaLet` int(10) DEFAULT NULL,
  `DopustNaDD` int(10) DEFAULT NULL,
  `DopustNaIz` int(10) DEFAULT NULL,
  `DopustNaOt` int(10) DEFAULT NULL,
  `DopustNaSta` int(10) DEFAULT NULL,
  `DopustNaInv` int(10) DEFAULT NULL,
  `DopustNaVod` int(10) DEFAULT NULL,
  `DopustStari` int(10) DEFAULT NULL,
  `DopustVzgoja` int(10) DEFAULT NULL,
  `Koef` double DEFAULT NULL,
  `Uporabnik` varchar(25) DEFAULT NULL,
  `Geslo` varchar(50) DEFAULT NULL,
  `NivoDostopa` int(10) DEFAULT NULL,
  `Komentar` text,
  `Status` int(10) DEFAULT NULL,
  `DatumStart` varchar(15) DEFAULT NULL,
  `DatumEnd` varchar(15) DEFAULT NULL,
  `DelDobaSol` int(10) DEFAULT NULL,
  `PedIzobr` varchar(15) DEFAULT NULL,
  `StrokIzpit` varchar(15) DEFAULT NULL,
  `Mentor` varchar(15) DEFAULT NULL,
  `Svetovalec` varchar(15) DEFAULT NULL,
  `Svetnik` varchar(15) DEFAULT NULL,
  `ZdrPregled` varchar(50) DEFAULT NULL,
  `PeriodaLet` double DEFAULT NULL,
  `Prevoz` double DEFAULT NULL,
  `PozVarnost` varchar(50) DEFAULT NULL,
  `PeriodaPV` int(10) DEFAULT NULL,
  `VarstvoDelo` varchar(50) DEFAULT NULL,
  `PeriodaVD` int(10) DEFAULT NULL,
  `Davcna` varchar(10) DEFAULT NULL,
  `Obcina` varchar(50) DEFAULT NULL,
  `Drzava` varchar(50) DEFAULT NULL,
  `drzavljanstvo` varchar(50) DEFAULT NULL,
  `KrajRoj` varchar(50) DEFAULT NULL,
  `DrzavaRoj` varchar(50) DEFAULT NULL,
  `NaslovZac` varchar(50) DEFAULT NULL,
  `PostaZac` varchar(50) DEFAULT NULL,
  `KrajZac` varchar(50) DEFAULT NULL,
  `ObcinaZac` varchar(50) DEFAULT NULL,
  `DrzavaZac` varchar(50) DEFAULT NULL,
  `Invalid` bit(1) NOT NULL,
  `KatInvalid` varchar(50) DEFAULT NULL,
  `DelnoUpokojen` varchar(50) DEFAULT NULL,
  `DopDelo` bit(1) NOT NULL,
  `Delodaj1` varchar(50) DEFAULT NULL,
  `Delodaj1mat` varchar(50) DEFAULT NULL,
  `Delodaj1naslov` varchar(100) DEFAULT NULL,
  `Delodaj2` varchar(50) DEFAULT NULL,
  `Delodaj2mat` varchar(50) DEFAULT NULL,
  `Delodaj2naslov` varchar(100) DEFAULT NULL,
  `Delodaj3` varchar(50) DEFAULT NULL,
  `Delodaj3mat` varchar(50) DEFAULT NULL,
  `Delodaj3naslov` varchar(100) DEFAULT NULL,
  `DatumPogodbe` varchar(50) DEFAULT NULL,
  `PolniDelCas` varchar(50) DEFAULT NULL,
  `RazlogDolCas` varchar(200) DEFAULT NULL,
  `PotrStrokUsp` varchar(100) DEFAULT NULL,
  `NazivDelMesta` varchar(250) DEFAULT NULL,
  `UrTeden` varchar(50) DEFAULT NULL,
  `Izmensko` bit(1) NOT NULL,
  `KrajDela` varchar(250) DEFAULT NULL,
  `KonkKlavz` bit(1) NOT NULL,
  `NacinPrenehanja` varchar(100) DEFAULT NULL,
  `Starejsi` bit(1) NOT NULL,
  `DojecaMati` bit(1) NOT NULL,
  `Sistemizacija` varchar(255) DEFAULT NULL,
  `Doprinasanje` bit(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdVzgojnoDelo` (`IdVzgojnoDelo`),
  KEY `KatInvalid` (`KatInvalid`),
  KEY `TabUciteljiIdDelo` (`IdDelo`),
  KEY `TabUciteljiIdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8;

/*Data for the table `tabucitelji` */

insert  into `tabucitelji`(`Id`,`IdUcitelj`,`Priimek`,`Ime`,`Dekliski`,`Spol`,`DatRoj`,`LetoRoj`,`EMSO`,`Naslov`,`Posta`,`Kraj`,`Izobrazba`,`IzobOpis`,`IzobUstr`,`IdDelo`,`DelovniCas`,`IdVzgojnoDelo`,`DelDobaLet`,`DopustNaDD`,`DopustNaIz`,`DopustNaOt`,`DopustNaSta`,`DopustNaInv`,`DopustNaVod`,`DopustStari`,`DopustVzgoja`,`Koef`,`Uporabnik`,`Geslo`,`NivoDostopa`,`Komentar`,`Status`,`DatumStart`,`DatumEnd`,`DelDobaSol`,`PedIzobr`,`StrokIzpit`,`Mentor`,`Svetovalec`,`Svetnik`,`ZdrPregled`,`PeriodaLet`,`Prevoz`,`PozVarnost`,`PeriodaPV`,`VarstvoDelo`,`PeriodaVD`,`Davcna`,`Obcina`,`Drzava`,`drzavljanstvo`,`KrajRoj`,`DrzavaRoj`,`NaslovZac`,`PostaZac`,`KrajZac`,`ObcinaZac`,`DrzavaZac`,`Invalid`,`KatInvalid`,`DelnoUpokojen`,`DopDelo`,`Delodaj1`,`Delodaj1mat`,`Delodaj1naslov`,`Delodaj2`,`Delodaj2mat`,`Delodaj2naslov`,`Delodaj3`,`Delodaj3mat`,`Delodaj3naslov`,`DatumPogodbe`,`PolniDelCas`,`RazlogDolCas`,`PotrStrokUsp`,`NazivDelMesta`,`UrTeden`,`Izmensko`,`KrajDela`,`KonkKlavz`,`NacinPrenehanja`,`Starejsi`,`DojecaMati`,`Sistemizacija`,`Doprinasanje`) values (1,0,'Ni izbran','','','M','1900-01-01',1900,'0101900500000','',0,'',1,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,'','',0,'',0,'1.1.1900','1.1.1900',0,'','','','','','',1,0,'',1,'',1,'','999','999','','','','','','','999','999','','','Ne','','','','','','','','','','','','Ne','','','','0','','','','','','','',''),(2,1,'Administrator','Admin','','M','1900-01-01',1900,'0101900500001','',0,'',1,'',1,0,0,0,0,0,0,0,0,0,0,0,0,0,'admin','7b9e45b3ac46fa81e7aa42dd6576a54f',3,' ',0,'1.1.1900','1.1.1900',0,'','','','','','',1,0,'',1,'',1,'','999','999','','','','','','','999','999','\0','','','\0','','','','','','','','','','','Ne','','','','0','','','','','\0','\0','0','');

/*Table structure for table `tabucnipripomocki` */

DROP TABLE IF EXISTS `tabucnipripomocki`;

CREATE TABLE `tabucnipripomocki` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `InvSt` varchar(50) DEFAULT NULL,
  `OsnSredstvo` varchar(50) DEFAULT NULL,
  `DodatniOpis` varchar(50) DEFAULT NULL,
  `DatumVpisa` varchar(50) DEFAULT NULL,
  `DatumInv` varchar(50) DEFAULT NULL,
  `idProstor` int(10) DEFAULT NULL,
  `Status` int(10) DEFAULT NULL,
  `Opomba` varchar(50) DEFAULT NULL,
  `Prevzel` int(10) DEFAULT NULL,
  `DatumPrevzem` varchar(50) DEFAULT NULL,
  `Prevzemnica` varchar(250) DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabucnipripomocki` */

/*Table structure for table `tabuntisizbirni` */

DROP TABLE IF EXISTS `tabuntisizbirni`;

CREATE TABLE `tabuntisizbirni` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ucenec` varchar(255) DEFAULT NULL,
  `pouk` double DEFAULT NULL,
  `predmet` varchar(255) DEFAULT NULL,
  `nadomime` varchar(255) DEFAULT NULL,
  `razred` varchar(255) DEFAULT NULL,
  `statozn` varchar(255) DEFAULT NULL,
  `stuc` varchar(255) DEFAULT NULL,
  `rez1` varchar(255) DEFAULT NULL,
  `rez2` varchar(255) DEFAULT NULL,
  `poukalt` double DEFAULT NULL,
  `predmetalt` varchar(255) DEFAULT NULL,
  `rez3` varchar(255) DEFAULT NULL,
  `prioriteta` double DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntisizbirni` */

/*Table structure for table `tabuntispredm` */

DROP TABLE IF EXISTS `tabuntispredm`;

CREATE TABLE `tabuntispredm` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idPredmet` int(10) DEFAULT NULL,
  `PredmetUntis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idPredmet` (`idPredmet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntispredm` */

/*Table structure for table `tabuntisprostor` */

DROP TABLE IF EXISTS `tabuntisprostor`;

CREATE TABLE `tabuntisprostor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idProstor` int(10) DEFAULT NULL,
  `ProstorUntis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idProstor` (`idProstor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntisprostor` */

/*Table structure for table `tabuntisucenci` */

DROP TABLE IF EXISTS `tabuntisucenci`;

CREATE TABLE `tabuntisucenci` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcenec` int(10) DEFAULT NULL,
  `UcenecUntis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcenec` (`idUcenec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntisucenci` */

/*Table structure for table `tabuntisucitelj` */

DROP TABLE IF EXISTS `tabuntisucitelj`;

CREATE TABLE `tabuntisucitelj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `UciteljUntis` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntisucitelj` */

/*Table structure for table `tabuntisurnik` */

DROP TABLE IF EXISTS `tabuntisurnik`;

CREATE TABLE `tabuntisurnik` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `pouk` double DEFAULT NULL,
  `razred` varchar(255) DEFAULT NULL,
  `ucitelj` varchar(255) DEFAULT NULL,
  `predmet` varchar(255) DEFAULT NULL,
  `prostor` varchar(255) DEFAULT NULL,
  `dan` double DEFAULT NULL,
  `ura` double DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabuntisurnik` */

/*Table structure for table `taburnik` */

DROP TABLE IF EXISTS `taburnik`;

CREATE TABLE `taburnik` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `Ucitelj` int(10) DEFAULT NULL,
  `Predmet` int(10) DEFAULT NULL,
  `Nivo` int(10) DEFAULT NULL,
  `Razred` int(10) DEFAULT NULL,
  `Paralelka` varchar(50) DEFAULT NULL,
  `VrstaOS` int(10) DEFAULT NULL,
  `DanVTednu` int(10) DEFAULT NULL,
  `Ura` int(10) DEFAULT NULL,
  `Prostor` int(10) DEFAULT NULL,
  `idRazred` int(10) DEFAULT NULL,
  `od` int(10) DEFAULT NULL,
  `do` int(10) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `idRazred` (`idRazred`)
) ENGINE=InnoDB AUTO_INCREMENT=59395 DEFAULT CHARSET=utf8;

/*Data for the table `taburnik` */

/*Table structure for table `tabvarstvodelo` */

DROP TABLE IF EXISTS `tabvarstvodelo`;

CREATE TABLE `tabvarstvodelo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabvarstvodelo` */

/*Table structure for table `tabvodjeaktivov` */

DROP TABLE IF EXISTS `tabvodjeaktivov`;

CREATE TABLE `tabvodjeaktivov` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `idAktiv` int(10) DEFAULT NULL,
  `idUcitelj` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idAktiv` (`idAktiv`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabvodjeaktivov` */

/*Table structure for table `tabvzgdelo` */

DROP TABLE IF EXISTS `tabvzgdelo`;

CREATE TABLE `tabvzgdelo` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdVzgojnoDelo` int(10) DEFAULT NULL,
  `VzgojnoDelo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdVzgojnoDelo` (`IdVzgojnoDelo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

/*Data for the table `tabvzgdelo` */

insert  into `tabvzgdelo`(`Id`,`IdVzgojnoDelo`,`VzgojnoDelo`) values (1,1,'Učitelj/-ica'),(2,2,'Vzgojitelj/-ica'),(3,3,'Čistilka'),(4,4,'Hišnik'),(5,5,'Računalničar/-ka'),(6,6,'Knjižničar/-ka'),(7,7,'Psiholog/-inja'),(8,8,'Socialni/-a delavec/-ka'),(9,9,'Spremljevalec/-ka'),(10,10,'Poslovni/-a sekretar/-ka'),(11,11,'Blagajničar/-ka'),(12,12,'Računovodja/-kinja'),(13,13,'Ravnatelj/-ica'),(14,14,'Pomočnik/-ca ravnatelja/-ice'),(15,15,'Kuhar/-ica'),(16,16,'Drugo'),(17,17,'Pripravnik/-ica (2. člen)'),(18,18,'Zunanji/-a sodelavec/-ka'),(19,19,'Pripravnik/-ica (47. člen)'),(20,20,'Laborant/-ka'),(21,0,'Nedoločeno');

/*Table structure for table `tabvzgojitelji` */

DROP TABLE IF EXISTS `tabvzgojitelji`;

CREATE TABLE `tabvzgojitelji` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `IdUcitelj` int(10) DEFAULT NULL,
  `Priimek` varchar(50) DEFAULT NULL,
  `Ime` varchar(50) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `Spol` varchar(1) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `DatRoj` date DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `TabUciteljiIdUcitelj` (`IdUcitelj`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8;

/*Data for the table `tabvzgojitelji` */

insert  into `tabvzgojitelji`(`Id`,`IdUcitelj`,`Priimek`,`Ime`,`Spol`,`DatRoj`) values (1,0,'Ni izbran','','M','1900-01-01'),(2,1,'Administrator','Admin','M','1900-01-01');

/*Table structure for table `tabvzgukrepi` */

DROP TABLE IF EXISTS `tabvzgukrepi`;

CREATE TABLE `tabvzgukrepi` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Leto` int(10) DEFAULT NULL,
  `IdUcenec` int(10) DEFAULT NULL,
  `IdUkrep` int(10) DEFAULT NULL,
  `DatIzreka` varchar(20) DEFAULT NULL,
  `podlaga` varchar(100) DEFAULT NULL,
  `obrazlozitev` text,
  `Datum` varchar(50) DEFAULT NULL,
  `Vpisal` varchar(50) DEFAULT NULL,
  `stdokumenta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`),
  KEY `IdUcenec` (`IdUcenec`),
  KEY `TabVzgUkrepiIdUkrep` (`IdUkrep`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabvzgukrepi` */

/*Table structure for table `tabzapisnik` */

DROP TABLE IF EXISTS `tabzapisnik`;

CREATE TABLE `tabzapisnik` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `leto` int(10) DEFAULT NULL,
  `Naslov` varchar(250) DEFAULT NULL,
  `tip` int(10) DEFAULT NULL,
  `Datum` varchar(50) DEFAULT NULL,
  `avtor` varchar(50) DEFAULT NULL,
  `vsebina` text,
  `datoteka` varchar(250) DEFAULT NULL,
  `cas` timestamp NULL DEFAULT NULL,
  `vpisal` varchar(50) DEFAULT NULL,
  `Arhiv` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabzapisnik` */

/*Table structure for table `tabzapisniktip` */

DROP TABLE IF EXISTS `tabzapisniktip`;

CREATE TABLE `tabzapisniktip` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tip` varchar(250) DEFAULT NULL,
  `povezava` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

/*Data for the table `tabzapisniktip` */

insert  into `tabzapisniktip`(`id`,`tip`,`povezava`) values (1,'Zapisnik sestanka aktiva','VnosZapisnik.php'),(2,'Zapisnik timskega sestanka','VnosZapisnik.php'),(3,'Zapisnik oddelčnega učiteljskega zbora','VnosZapisnik.php'),(4,'Zapisnik roditeljskega sestanka','VnosZapisnik.php'),(5,'Zapisnik o ponavljanju kontrolne naloge','VnosZapisnik.php'),(6,'Zapisnik pedagoške konference','VnosZapisnik.php'),(7,'Zapisnik nivojske skupine','VnosZapisnik.php'),(8,'Letno poročilo','VnosZapisnik.php'),(9,'Poročilo o sodelovanju na natečajih','VnosZapisnik.php'),(10,'Poročilo o izvedbi prireditve in akcije za starše in učence','VnosZapisnik.php'),(11,'Poročilo  o izvedbi športnega dneva','VnosZapisnik.php'),(12,'Poročilo o izvedbi kulturnega dneva','VnosZapisnik.php'),(13,'Poročilo o izvedbi naravoslovnega dneva','VnosZapisnik.php'),(14,'Poročilo o izvedbi tehničnega dneva','VnosZapisnik.php'),(15,'Poročilo - drugo','VnosZapisnik.php'),(16,'Zapisnik - drugo','VnosZapisnik.php'),(17,'Poročilo o izvedenem izobraževanju, seminarju','VnosZapisnik.php'),(18,'Zapisnik jutranjega sestanka','VnosZapisnik.php'),(19,'Poročilo o šoli v naravi','VnosZapisnik.php'),(20,'Poročilo o projektih','VnosZapisnik.php'),(21,'Poročilo o sodelovanju pri raziskovalnih nalogah','VnosZapisnik.php');

/*Table structure for table `tabzascsr` */

DROP TABLE IF EXISTS `tabzascsr`;

CREATE TABLE `tabzascsr` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `DelHaljaM` bit(1) NOT NULL,
  `DatDelHaljaM` varchar(50) DEFAULT NULL,
  `PerDelHaljaM` int(10) DEFAULT NULL,
  `OrtCevlji` bit(1) NOT NULL,
  `DatOrtCevlji` varchar(50) DEFAULT NULL,
  `PerOrtCevlji` int(10) DEFAULT NULL,
  `RokG` bit(1) NOT NULL,
  `DatRokG` varchar(50) DEFAULT NULL,
  `PerRokG` int(10) DEFAULT NULL,
  `DelCevlji` bit(1) NOT NULL,
  `DatDelCevlji` varchar(50) DEFAULT NULL,
  `PerDelCevlji` int(10) DEFAULT NULL,
  `SkornjiG` bit(1) NOT NULL,
  `DatSkornjiG` varchar(50) DEFAULT NULL,
  `PerSkornjiG` int(10) DEFAULT NULL,
  `RokU` bit(1) NOT NULL,
  `DatRokU` varchar(50) DEFAULT NULL,
  `PerRokU` int(10) DEFAULT NULL,
  `DelHaljaHlB` bit(1) NOT NULL,
  `DatDelHaljaHlB` varchar(50) DEFAULT NULL,
  `PerDelHaljaHlB` int(10) DEFAULT NULL,
  `HlaceB` bit(1) NOT NULL,
  `DatHlaceB` varchar(50) DEFAULT NULL,
  `PerHlaceB` int(10) DEFAULT NULL,
  `KapaB` bit(1) NOT NULL,
  `DatKapaB` varchar(50) DEFAULT NULL,
  `PerKapaB` int(10) DEFAULT NULL,
  `PredpB` bit(1) NOT NULL,
  `DatPredpB` varchar(50) DEFAULT NULL,
  `PerPredpB` int(10) DEFAULT NULL,
  `Cevlji` bit(1) NOT NULL,
  `DatCevlji` varchar(50) DEFAULT NULL,
  `PerCevlji` int(10) DEFAULT NULL,
  `TShirt` bit(1) NOT NULL,
  `DatTShirt` varchar(50) DEFAULT NULL,
  `PerTShirt` int(10) DEFAULT NULL,
  `PoloMajica` bit(1) NOT NULL,
  `DatPoloMajica` varchar(50) DEFAULT NULL,
  `PerPoloMajica` int(10) DEFAULT NULL,
  `PredpPis` bit(1) NOT NULL,
  `DatPredpPis` varchar(50) DEFAULT NULL,
  `PerPredpPis` int(10) DEFAULT NULL,
  `Tunika` bit(1) NOT NULL,
  `DatTunika` varchar(50) DEFAULT NULL,
  `PerTunika` int(10) DEFAULT NULL,
  `DelHaljaB` bit(1) NOT NULL,
  `DatDelHaljaB` varchar(50) DEFAULT NULL,
  `PerDelHaljaB` int(10) DEFAULT NULL,
  `RokaviceK` bit(1) NOT NULL,
  `DatRokaviceK` varchar(50) DEFAULT NULL,
  `PerRokaviceK` int(10) DEFAULT NULL,
  `Ocala` bit(1) NOT NULL,
  `DatOcala` varchar(50) DEFAULT NULL,
  `PerOcala` int(10) DEFAULT NULL,
  `Trenirka` bit(1) NOT NULL,
  `DatTrenirka` varchar(50) DEFAULT NULL,
  `PerTrenirka` int(10) DEFAULT NULL,
  `Superge` bit(1) NOT NULL,
  `DatSuperge` varchar(50) DEFAULT NULL,
  `PerSuperge` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabzascsr` */

/*Table structure for table `tabzdrpregledi` */

DROP TABLE IF EXISTS `tabzdrpregledi`;

CREATE TABLE `tabzdrpregledi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `idUcitelj` int(10) DEFAULT NULL,
  `datum` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idUcitelj` (`idUcitelj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabzdrpregledi` */

/*Table structure for table `tabzetoni` */

DROP TABLE IF EXISTS `tabzetoni`;

CREATE TABLE `tabzetoni` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datum` varchar(50) DEFAULT NULL,
  `kolicina` double DEFAULT NULL,
  `namen` varchar(50) DEFAULT NULL,
  `nakup` bit(1) NOT NULL,
  `oznaka` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tabzetoni` */

/*Table structure for table `tg_whos_online` */

DROP TABLE IF EXISTS `tg_whos_online`;

CREATE TABLE `tg_whos_online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `timestamp1` int(10) DEFAULT NULL,
  `ip1` varchar(40) DEFAULT NULL,
  `file1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `file` (`file1`),
  KEY `id` (`id`),
  KEY `ip` (`ip1`),
  KEY `timestamp` (`timestamp1`)
) ENGINE=InnoDB AUTO_INCREMENT=5122 DEFAULT CHARSET=utf8;

/*Data for the table `tg_whos_online` */

insert  into `tg_whos_online`(`id`,`timestamp1`,`ip1`,`file1`) values (5116,2013,'::1',''),(5117,2013,'::1',''),(5118,2013,'::1',''),(5119,2013,'::1',''),(5120,2013,'::1',''),(5121,2013,'::1','');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
