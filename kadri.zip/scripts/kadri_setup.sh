#!/bin/bash
#
#virtual mashine, ubuntu 14-04-server
clear

echo "Nastavljanje uporabniškega imena:"
read -p "Vpišite uporabniško ime za sistemskega uporabnika (webkadri): " uporabnik
if [ ${#uporabnik} = 0 ]
then
	uporabnik=webkadri
fi
echo "Uporabniško ime je $uporabnik"

read -p "Ali želite dodati to sistemsko uporabniško ime (d/n)? " korak1
if [ $korak1 = d ]
then
    #doda uporabnika
    adduser $uporabnik
    #uporabnika doda skupini www-data
    usermod -a -G www-data $uporabnik
fi
echo ""
#lastništvo map in datotek na spletnem mestu
echo "Nastavljam lastništvo datotek v /var/www/html na www-data."
chown -hR www-data:www-data /var/www/html

#nastavitev lastnosti mape /var/www/html
echo "Nastavljam lastnosti map in datotek na 770."
chmod -R 770 /var/www/html
echo ""
echo "Naredite naslednje spremembe v php.ini (/etc/php5/apache2/php.ini ali /etc/php/7.0/apache2/php.ini):"
echo "max_execution_time = 300"
echo "max_input_vars = 50000"
echo "upload_max_filesize = 64M"
echo "max_file_uploads = 40"

echo ""
echo "Nastavljanje MySQL"
read -p "Ali želite nastaviti uporabnika, geslo in bazo za MySQL (d/n)? " korak2
if [ $korak2 = d ]
then
    #nastavitve MySQL
    read -p "Vnesite uporabniško ime za MySQL bazo (kuser): " mysqluporabnik
    if [ ${#mysqluporabnik}=0 ]
    then
	mysqluporabnik="kuser"
    fi
    echo "$mysqluporabnik"
    read -p "Vnesite geslo za MySQL uporabnika (kSQLgeslo): " mysqlgeslo
    if [ ${#mysqlgeslo}=0 ] 
    then
	mysqlgeslo="kSQLgeslo"
    fi
    echo "$mysqlgeslo"
    read -p "Vnesite ime vaše baze (sola): " mysqlbaza
    echo "$mysqlbaza"
    if [ ${#mysqlbaza}=0 ] 
    then
	mysqlbaza="sola"
    fi

    Q1="CREATE DATABASE IF NOT EXISTS $mysqlbaza DEFAULT CHARACTER SET utf8 COLLATE utf8_slovenian_ci;"
    #echo "$Q1"
    Q2="GRANT ALL ON *.* TO '$mysqluporabnik'@'localhost' IDENTIFIED BY '$mysqlgeslo';"
    Q2a="GRANT ALL ON *.* TO '$mysqluporabnik'@'%' IDENTIFIED BY '$mysqlgeslo';"
    Q3="FLUSH PRIVILEGES;"
    SQL="${Q1}${Q2}${Q3}"
    SQL2="${Q1}${Q2a}${Q3}"

    echo "$SQL"

    read -p "Vpišite root geslo za MySQL: " rootgeslo
    mysql --user=root --password=$rootgeslo -e "$SQL"
    echo ""
    read -p "Naj dovolim tudi dostop z zunanjih strežnikov (d/n): " dovoli

    if [ $dovoli = d ]
    then
        echo "$SQL2"
	mysql --user=root --password=$rootgeslo -e "$SQL2"
	echo "Pozor: na požarnem zidu omogočite dostop do porta 3306 le določenim IP!"
	echo "V /etc/mysql/my.cnf ali /etc/mysql/mysql.conf.d/mysqld.cnf nastavite:"
	echo "bind-address = 0.0.0.0"
    fi
    echo ""
    #restore baze (prvi vnos baze)
    echo "Inicializiram podatkovno bazo za Kadre in učence..."
    mysql --user=$mysqluporabnik --password=$mysqlgeslo $mysqlbaza < /var/www/html/scripts/kadri_osnova.sql

    if [ ${#uporabnik} = 0 ]
    then
        cp /var/www/html/scripts/kadri_osnova.sql /home/$uporabnik/
	echo "Odstranjujem /var/www/html/scripts/kadri_osnova.sql, da ne bi prišlo do prepisovanja baze!"
        rm /var/www/html/scripts/kadri_osnova.sql
    fi
    echo ""
    echo "V datoteki /etc/mysql/mysql.cnf  ali /etc/mysql/mysql.conf.d/mysqld.cnf dodajte vrstico v razdelku [mysqld]"
    echo "lower_case_table_names=1"
    echo ""

    echo ""
    read -p "Naj inicializiram tudi koledar zasedenosti prostorov (d/n)? " prostori
    if [ $prostori = d ]
    then
        Q4="CREATE DATABASE IF NOT EXISTS mrbs DEFAULT CHARACTER SET utf8 COLLATE utf8_slovenian_ci;"
        mysql --user=$mysqluporabnik --password=$mysqlgeslo -e "$Q4"
        mysql --user=$mysqluporabnik --password=$mysqlgeslo mrbs < /var/www/html/mrbs/tables.my.sql
        cp /var/www/html/mrbs/tables.my.sql /home/$uporabnik/
	echo "Odstranjujem /var/www/html/mrbs/tables.my.sql, da ne bi prišlo do prepisovanja baze!"
        rm /var/www/html/mrbs/tables.my.sql
	echo ""
	echo "Potrebna so spremembe v nastavitveni datoteki /var/www/html/mrbs/config.inc.php:"
	echo "db_login = $mysqluporabnik"
	echo "db_password = $mysqlgeslo"
	echo "mrbs_admin_email = \"vaš email\""
	echo "mrbs_company = \"Ime vaše šole\""
	echo "url_base = \"https://kadri.sola.si/mrbs\""
	echo "auth['db_ext']['db_username'] = '$mysqluporabnik'"
	echo "auth['db_ext']['db_password'] = '$mysqlgeslo'"
	echo "auth['db_ext']['db_name'] = '$mysqlbaza'"
	echo "mail_settings['from'] = 'vaš email'"
	echo ""
    fi
fi

echo ""
echo "Prednastavljeni prijavni podatki za Kadre: uporabniško ime: admin, geslo: adminkadri"

echo ""
echo "Nastavljanje Apache strežnika na https."
read -p "Ali želite nastaviti https strežnik in kreirati samopodpisan certifikat (d/n)? " korak3
if [ $korak3 = d ]
then
    #nastavitev https
    a2enmod ssl
    service apache2 restart
    
    echo "Kreiranje samopodpisanih certifikatov za 2 leti. Common name naj bo IP ali ime vaše domene (kadri.sola.si)"
    mkdir /etc/apache2/ssl
    openssl req -x509 -nodes -days 730 -newkey rsa:2048 -keyout /etc/apache2/ssl/apache.key -out /etc/apache2/ssl/apache.crt

    echo "Odprite SSL config datoteko /etc/apache2/sites-available/default-ssl.conf"
    echo "Naredite naslednje spremembe:"
    echo "<VirtualHost *:443>"
    echo "ServerName kadri.sola.si:443"
    echo ""
    echo "kadri.sola.si mora biti isto kot pri kreiranju certifikata ali IP naslov."
    echo "DirectoryIndex index.php index.html index.htm"
    echo ""
    echo "SSLEngine on"
    echo "SSLCertificateFile /etc/apache2/ssl/apache.crt"
    echo "SSLCertificateKeyFile /etc/apache2/ssl/apache.key"
    echo ""
    echo "Shranite datoteko."
    
    #
    #Aktiviranje novega virtualnega gostitelja
    a2ensite default-ssl
    #ponovni zagon apache
    service apache2 reload
fi

#avtomatsko pošiljanje arhivske baze na oddaljen strežnik, brez vnosa gesla (nastavitve strežnikov)
#http://www.tecmint.com/ssh-passwordless-login-using-ssh-keygen-in-5-easy-steps/
#[tecmint@tecmint.com ~]$ ssh-keygen -t rsa
#
#Generating public/private rsa key pair.
#Enter file in which to save the key (/home/tecmint/.ssh/id_rsa): [Press enter key]
#Created directory '/home/tecmint/.ssh'.
#Enter passphrase (empty for no passphrase): [Press enter key]
#Enter same passphrase again: [Press enter key]
#Your identification has been saved in /home/tecmint/.ssh/id_rsa.
#Your public key has been saved in /home/tecmint/.ssh/id_rsa.pub.
#The key fingerprint is:
#af:bc:25:72:d4:04:65:d9:5d:11:f0:eb:1d:89:50:4c tecmint@tecmint.com
#The key's randomart image is:
#+--[ RSA 2048]----+
#|        ..oooE.++|
#|         o. o.o  |
#|          ..   . |
#|         o  . . o|
#|        S .  . + |
#|       . .    . o|
#|      . o o    ..|
#|       + +       |
#|        +.       |
#+-----------------+
#
#[tecmint@tecmint ~]$ ssh sheena@192.168.1.2 mkdir -p .ssh
#
#The authenticity of host '192.168.1.2 (192.168.1.2)' can't be established.
#RSA key fingerprint is d6:53:94:43:b3:cf:d7:e2:b0:0d:50:7b:17:32:29:2a.
#Are you sure you want to continue connecting (yes/no)? yes
#Warning: Permanently added '192.168.1.2' (RSA) to the list of known hosts.
#sheena@192.168.1.2's password: [Enter Your Password Here]
#
#[tecmint@tecmint ~]$ cat .ssh/id_rsa.pub | ssh -p 22 sheena@192.168.1.2 'cat >> .ssh/authorized_keys'
#
#sheena@192.168.1.2's password: [Enter Your Password Here]
#
#[tecmint@tecmint ~]$ ssh -p 22 sheena@192.168.1.2 "chmod 700 .ssh; chmod 640 .ssh/authorized_keys"
#
#sheena@192.168.1.2's password: [Enter Your Password Here]
#
#[tecmint@tecmint ~]$ ssh sheena@192.168.1.2
#
#kopiranje na oddaljen strežnik
#scp -P 22 /home/webkadri/kadri-backup solabackup@www.alelektronik-ad.si:/home/solabackup/
#
#nastavitev vsftpd na ssl prenos
# cd /etc/vsftpd/
# /usr/bin/openssl req -x509 -nodes -days 365 -newkey rsa:1024 -keyout vsftpd.pem -out vsftpd.pem
#
# Sample output:
#Generating a 1024 bit RSA private key
#.......++++++
#........................................++++++
#writing new private key to '/etc/vsftpd/vsftpd.pem'
#-----
#You are about to be asked to enter information that will be incorporated
#into your certificate request.
#What you are about to enter is what is called a Distinguished Name or a DN.
#There are quite a few fields but you can leave some blank
#For some fields there will be a default value,
#If you enter '.', the field will be left blank.
#-----
#Country Name (2 letter code) [GB]:IN
#State or Province Name (full name) [Berkshire]:Maharashtra 
#Locality Name (eg, city) [Newbury]:Pune
#Organization Name (eg, company) [My Company Ltd]:nixCraft Ltd
#Organizational Unit Name (eg, section) []:IT
#Common Name (eg, your name or your server's hostname) []:ftp.nixcraft.net.in
#Email Address []:vivek@nixcraft.net.in
#
#vsftpd.pem se skopira v /etc/ssl/private/
#
#Edit the vsftpd configuration file, enter:
# vi vsftpd.conf
# Add or correct the following configuration option:
# Turn on SSL
#ssl_enable=YES
# Allow anonymous users to use secured SSL connections
#allow_anon_ssl=YES
# All non-anonymous logins are forced to use a secure SSL connection in order to
# send and receive data on data connections.
#force_local_data_ssl=YES
# All non-anonymous logins are forced to use a secure SSL connection in order to send the password.
#force_local_logins_ssl=YES
# Permit TLS v1 protocol connections. TLS v1 connections are preferred
#ssl_tlsv1=YES
# Permit SSL v2 protocol connections. TLS v1 connections are preferred
#ssl_sslv2=YES
# permit SSL v3 protocol connections. TLS v1 connections are preferred
#ssl_sslv3=YES
# Specifies the location of the RSA certificate to use for SSL encrypted connections
#rsa_cert_file=/etc/vsftpd/vsftpd.pem
#
#

echo ""
echo "Spremenite crontab datoteko (/etc/crontab). Na koncu dodajte vrstici:"
echo "#backup kadri"
echo "25 1	* * *	root	/etc/cron.d/backup_kadri.sh > /home/$uporabnik/bk.log"
echo ""
echo "To pomeni, da se bo izvedlo avtomatsko backupiranje ob 1:25 uri."
echo ""
read -p "Naj prenesem backup scripte na ustrezna mesta (d/n)? " korak4
if [ $korak4 = d ]
then
    cp /var/www/html/scripts/crontab /home/$uporabnik
    cp /var/www/html/scripts/backup_kadri.sh /home/$uporabnik
    cp /home/$uporabnik/backup_kadri.sh /etc/cron.d
    rm /var/www/html/scripts/backup_kadri.sh
    rm /var/www/html/scripts/crontab
    chmod 700 /etc/cron.d/backup_kadri.sh
    mkdir /home/$uporabnik/arhiv

    echo "Popravite datoteko /etc/cron.d/backup_kadri.sh tako, da bo vsebovala vaše prijavne podatke za MySQL:"
    echo "mysqldump -u $mysqluporabnik -h localhost -p$mysqlgeslo $mysqlbaza | gzip -9 /home/$uporabnik/arhiv/$mysqlbaza-backup-$(date +%Y-%m-%d).sql.gz"
fi

echo ""
echo "Podporni modul PHP za kreiranje PDF poročil."
read -p "Ali želite namestiti modul PHP za podporo PDF in XML poročil (d/n)? " korak5
if [ $korak5 = d ]
then
    #za podporo GIF slik pri oblikovanju PDF poročil
    apt-get install php7.0-gd
    apt-get install php7.0-xml
fi

echo ""
echo "Namestitev je zaključena!"
echo "V spletnem brskalniku se povežite na stran in ob prvem zagonu nastavite parametre programa."
echo ""
