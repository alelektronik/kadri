#!/bin/bash
mysqldump -u kadri -h localhost -pkadriSQL sola | gzip -9 > /home/webkadri/arhiv/sola-backup-$(date +%Y-%m-%d).sql.gz
#scp -P 1022 /home/webkadri/arhiv/sola-backup-$(date +%Y-%m-%d).sql.gz solabackup@www.alelektronik-ad.si:/home/solabackup/arhiv/osmp/sola_sola.sql.gz
rm /var/www/html/dato/*
