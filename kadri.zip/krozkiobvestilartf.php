<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Obvestila
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j. n. Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

function To437($txt){
    $txt=str_replace("Č","^",$txt);
    $txt=str_replace("č","~",$txt);
    $txt=str_replace("Š","[",$txt);
    $txt=str_replace("š","{",$txt);
    $txt=str_replace("Ž","@",$txt);
    $txt=str_replace("ž","`",$txt);
    $txt=str_replace("Ć","]",$txt);
    $txt=str_replace("ć","}",$txt);
    $txt=str_replace("Đ","\\",$txt);
    $txt=str_replace("đ","|",$txt);
    return $txt;
}

$VFile="obvestilaodejavnostih.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}

if ($VecSol > 0){
    $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $idsola=$R["idsola"];
    }else{
        $idsola=1;
    }
    
    $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VSola=$R["Sola"];
        $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
        $VSolaKraj=$R["Kraj"];
        $VRavnatelj=$R["Ravnatelj"];
        $TipSole=$R["TipSole"];
        $RavnateljID=$R["ravnatelj_ID"];
    }else{
        $VSola=" ";
        $VRavnatelj=" ";
        $RavnateljID=0;
        $VSolaNaslov="";
        $VSolaKraj="";
        $TipSole=0;
    }
}else{
    $SQL = "SELECT * FROM tabsola";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VSola=$R["Sola"];
        $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
        $VSolaKraj=$R["Kraj"];
        $VRavnatelj=$R["Ravnatelj"];
        $TipSole=$R["TipSole"];
        $RavnateljID=$R["ravnatelj_ID"];
    }else{
        $VSola=" ";
        $VRavnatelj=" ";
        $RavnateljID=0;
        $VSolaNaslov="";
        $VSolaKraj="";
        $TipSole=0;
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $SpolRavnatelj=$R["Spol"];
}else{
    $SpolRavnatelj="M";
}

fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1\\deff1\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\f1\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}{\\f35\\fswiss\\fcharset0\\fprq2{\\*\\panose 020b0a04020102020204}Arial Black;}{\\f453\\froman\\fcharset0\\fprq2 Times New Roman;}{\\f452\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
fwrite ($fh,"{\\f454\\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f455\\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f456\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f457\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
fwrite ($fh,"{\\f458\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f459\\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f463\\fswiss\\fcharset0\\fprq2 Arial;}{\\f462\\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f464\\fswiss\\fcharset161\\fprq2 Arial Greek;}"."\n");
fwrite ($fh,"{\\f465\\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f466\\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f467\\fswiss\\fcharset178\\fprq2 Arial (Arabic);}{\\f468\\fswiss\\fcharset186\\fprq2 Arial Baltic;}{\\f469\\fswiss\\fcharset163\\fprq2 Arial (Vietnamese);}}"."\n");
fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;"."\n");
fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red137\\green119\\blue186;}{\\stylesheet{\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{\\s1\\qj \\li0\\ri0\\sb240\\sa120\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\b\\shad\\f35\\fs36\\lang1033\\langfe1033\\kerning28\\cgrid\\langnp1033\\langfenp1033 \\sbasedon0 \\snext0 \\styrsid14375190 heading 1;}{\\s2\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar"."\n");
fwrite ($fh,"\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 \\sautoupd \\styrsid4161200 heading 2;}{\\s3\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel2\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\b\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 heading 3;}{\\*\\cs10 \\additive \\ssemihidden Default Paragraph Font;}{\\*"."\n");
fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\snext11 \\ssemihidden Normal Table;}{\\s15\\qc \\li0\\ri0\\sb60\\sa60\\sl-140\\slmult0"."\n");
fwrite ($fh,"\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\b\\f1\\fs14\\lang1024\\langfe1024\\cgrid\\noproof\\langnp1060\\langfenp1060 \\sbasedon0 \\snext15 Mesto;}{\\*\\cs16 \\additive \\b\\i\\f1\\fs24\\lang1060\\langfe1033\\langnp1060\\langfenp1033 \\sbasedon10 "."\n");
fwrite ($fh,"Naslov 2 Znak Znak Znak Znak Znak;}{\\s17\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\shad\\f35\\fs28\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext17 \\styrsid2692378 Slog Arial Black 24 pt Sen\\'e8eno Na sredini Polje: (Enojen Samo...;}{\\s18\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\f35\\fs48\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext18 \\styrsid14375190 "."\n");
fwrite ($fh,"Slog Arial Black 24 pt modra Sen\\'e8eno Na sredini Polje: (Enoje...;}{\\s19\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon2 \\snext19 \\styrsid14375190 Slog Naslov 2 + rde\\'e8a;}{"."\n");
fwrite ($fh,"\\s20\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\b\\shad\\f35\\fs28\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 \\sbasedon1 \\snext20 \\sautoupd \\styrsid2692378 Slog1;}{\\s21\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb"."\n");
fwrite ($fh,"\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\caps\\f1\\fs24\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 "."\n");
fwrite ($fh,"\\sbasedon1 \\snext21 \\sautoupd \\styrsid2692378 Slog Naslov 1,Naslov 1 Znak Znak Znak Znak + Arial 12 pt Ne Krep...;}{\\s22\\ql \\li0\\ri0\\sb100\\sa100\\sbauto1\\saauto1\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext22 \\styrsid5715400 Normal (Web);}{\\*\\ts23\\tsrowd\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\sbasedon11 \\snext23 \\styrsid5715400 Table Grid;}}{\\*\\latentstyles\\lsdstimax156\\lsdlockeddef0}{\\*\\listtable"."\n");
fwrite ($fh,"{\\list\\listtemplateid-1051832236{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow1\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 }{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2"."\n");
fwrite ($fh,"\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s2}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s3}{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0"."\n");
fwrite ($fh,"{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0"."\n");
fwrite ($fh,"\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}"."\n");
fwrite ($fh,"{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listname ;}\\listid327027276}}{\\*\\listoverridetable{\\listoverride\\listid327027276"."\n");
fwrite ($fh,"\\listoverridecount0\\ls1}}{\\*\\pgptbl {\\pgp\\ipgp0\\itap0\\li0\\ri0\\sb0\\sa0}}{\\*\\rsidtbl \\rsid882357\\rsid2692378\\rsid4161200\\rsid5715400\\rsid6759903\\rsid10756800\\rsid14375190\\rsid15216063\\rsid15866154}{\\*\\generator Microsoft Word 11.0.5604;}{\\info"."\n");
fwrite ($fh,"{\\title }{\\creatim\\yr2009\\mo2\\dy27\\hr7\\min33}{\\revtim\\yr2009\\mo2\\dy27\\hr7\\min52}{\\version2}{\\edmins16}{\\nofpages3}{\\nofwords874}{\\nofchars4985}"."\n");
fwrite ($fh,"{\\nofcharsws5848}{\\vern24689}}\\margl1440\\margr1440\\margt1440\\margb1440 \\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\hyphcaps0\\formshade\\horzdoc\\dgmargin\\dghspace187\\dgvspace127\\dghorigin1701\\dgvorigin1984"."\n");
fwrite ($fh,"\\dghshow0\\dgvshow2\\jexpand\\viewkind4\\viewscale150\\pgbrdrhead\\pgbrdrfoot\\bdrrlswsix\\nolnhtadjtbl\\nojkernpunct\\rsidroot5715400 \\fet0\\sectd \\linex0\\headery709\\footery709\\colsx708\\sectlinegrid254\\sectdefaultcl\\sftnbj {\\*\\pnseclvl1"."\n");
fwrite ($fh,"\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5"."\n");
fwrite ($fh,"\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang "."\n");
fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}\\pard\\plain "."\n");

    $SQL = "SELECT tabucitelji.priimek, tabucitelji.ime,tabucitelji.spol FROM ";
    $SQL = $SQL . "tabrazred INNER JOIN tabucitelji ON tabrazred.idUcitelj=tabucitelji.idUcitelj ";
    $SQL = $SQL . "WHERE tabrazred.idRazred=".$VRazred;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VRazrednik=$R["ime"]." ".$R["priimek"];
        $SpolRazrednik=$R["spol"];
    }else{
        $VRazrednik="";
        $SpolRazrednik="M";
    }
    
    $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabucenci.spol FROM ";
    $SQL = $SQL."(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
    $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL."WHERE tabrazred.idRazred=".$VRazred;
    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
    
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $Ucenci[$Indx][0]=$R["iducenec"];
        $Ucenci[$Indx][1]=$R["ime"]." ".$R["priimek"];
        $Ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
        $Ucenci[$Indx][3]=$R["datroj"];
        $Ucenci[$Indx][4]=$R["spol"];
        $Indx=$Indx+1;
    }
    $StUcencev=$Indx-1;

    for ($IndxUcenec=1;$IndxUcenec <= $StUcencev;$IndxUcenec++){
        for ($Indx=1;$Indx <= 20;$Indx++){
            $VKrozek[$Indx][0]="";
            $VKrozek[$Indx][1]="";
            $VPohvala[$Indx]="";
        }
        
        $SQL    = "SELECT tabkrozki.krozek,tabkrozki.mentor FROM tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
        $SQL = $SQL ."WHERE ucenec=".$Ucenci[$IndxUcenec][0]." AND tabkrozekclan.leto=".$VLeto." AND tabkrozki.leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tabkrozki.krozek";
        $result = mysqli_query($link,$SQL);
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $VKrozek[$Indx][0]=$R["krozek"];
            $VKrozek[$Indx][1]=", mentor: ".$R["mentor"];
            $Indx=$Indx+1;
        }
        $StKrozkov=$Indx-1;

        $SQL    = "SELECT DISTINCT tabtekmovanja.tekmovanje,tabtekmovanja.priznanje FROM tabtekmovanja ";
        $SQL = $SQL ."WHERE idUcenec=".$Ucenci[$IndxUcenec][0]." AND tabtekmovanja.leto=".$VLeto." AND priznanje <> ''";
        $SQL = $SQL ." ORDER BY tekmovanje,priznanje";
        $result = mysqli_query($link,$SQL);
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $VPohvala[$Indx]=$R["tekmovanje"]." - ".mb_strtolower($R["priznanje"],$encoding)." priznanje";
            $Indx=$Indx+1;
        }
        $StPohval=$Indx-1;
        
        $SQL    = "SELECT * FROM tabdrtekmclan ";
        $SQL = $SQL ."WHERE idUcenec=".$Ucenci[$IndxUcenec][0]." AND leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tekmovanje,priznanje";
        $result = mysqli_query($link,$SQL);
        
        $Indx=$StPohval+1;
        while ($R = mysqli_fetch_array($result)){
            if (strlen($R["priznanje"]) > 0){
                $VPohvala[$Indx]=$R["tekmovanje"]." (".mb_strtolower($R["stopnja"],$encoding).") - ".mb_strtolower($R["priznanje"],$encoding).", mentor: ".$R["mentor1"];
            }else{
                $VPohvala[$Indx]=$R["tekmovanje"]." (".mb_strtolower($R["stopnja"],$encoding)."), mentor: ".$R["mentor1"];
            }
            $Indx=$Indx+1;
        }
        $StPohval=$Indx-1;

        for ($Indx=1;$Indx <= 100;$Indx++){
            $VKrozekT[$Indx][0]="";
            $VKrozekT[$Indx][1]="";
            $VKrozekT[$Indx][2]="";
            $VKrozekT[$Indx][3]="";
            $VKrozekT[$Indx][4]="";
            $VKrozekT[$Indx][5]="";
            $VKrozekT[$Indx][6]="";
            $VPohvalaT[$Indx]="";
        }
        
        $SQL = "SELECT tabsstclan.* FROM tabsstclan WHERE idUcenec=".$Ucenci[$IndxUcenec][0]." AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $VKrozekT[$Indx][0]=$R["tekmovanje"]; //'disciplina/tekmovanje
            $VKrozekT[$Indx][1]=$R["mentor1"];
            $VKrozekT[$Indx][2]=$R["datum"];
            $VKrozekT[$Indx][3]=mb_strtolower($R["stopnja"],$encoding);
            $VKrozekT[$Indx][4]=$R["kraj"];
            $VKrozekT[$Indx][5]=$R["priznanje"];
            $VKrozekT[$Indx][6]=$R["napredovanje"];
            $Indx=$Indx+1;
        }
        $StKrozkovT=$Indx-1;
        
        fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
        fwrite ($fh,"\\f1\\fs22\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        
        //'glava šole
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VSola)."}{\\insrsid10756800 \\par }"."\n");        
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VSolaNaslov)."}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

        fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
        fwrite ($fh,"\\f1\\fs28\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("OBVESTILO O SODELOVANJU PRI INTERESNIH IN DRUGIH DEJAVNOSTIH ŠOLE V ŠOLSKEM LETU ".$VLeto."/".($VLeto+1))."}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        
        fwrite ($fh,"{\\f1\\fs32\\b\\insrsid5715400\\charrsid5715400 ".ToRTF($Ucenci[$IndxUcenec][1]).",}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

        fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
        fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        $Datum=new DateTime(isDate($Ucenci[$IndxUcenec][3]));
        if ($Ucenci[$IndxUcenec][4]=="M"){
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("rojen ".$Datum->format('j. n. Y').", učenec ".$Ucenci[$IndxUcenec][2]." razreda, je v šolskem letu ".$VLeto."/".($VLeto+1).":")."}{\\insrsid10756800 \\par }"."\n");
        }else{
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("rojena ".$Datum->format('j. n. Y').", učenka ".$Ucenci[$IndxUcenec][2]." razreda, je v šolskem letu ".$VLeto."/".($VLeto+1).":")."}{\\insrsid10756800 \\par }"."\n");
        }
        fwrite ($fh,"{\\f1\\fs12\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\f1\\fs24\\insrsid10756800 \\par }"."\n");
        
        //'izpis udeležbe v interesnih dejavnostih
        
        if ($Ucenci[$IndxUcenec][4]=="M"){
            if ($StKrozkov > 0){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- obiskoval naslednje interesne dejavnosti: ")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni obiskoval interesnih dejavnosti, ")."}{\\insrsid10756800 \\par }"."\n");
            }
        }else{
            if ($StKrozkov > 0){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- obiskovala naslednje interesne dejavnosti: ")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni obiskovala interesnih dejavnosti, ")."}{\\insrsid10756800 \\par }"."\n");
            }
        }
        fwrite ($fh,"{\\f1\\fs12\\insrsid10756800 \\par }"."\n");
        for ($Indx=1;$Indx <= $StKrozkov;$Indx++){
            fwrite ($fh,"\\pard \\ltrpar\\qj \\li709\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin709\\itap0\\pararsid6436526 {\\f1\\fs22\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid5715400\\charrsid5715400 \\tab - ".ToRTF($VKrozek[$Indx][0].$VKrozek[$Indx][1]));
            if ($Indx < $StKrozkov){
                fwrite ($fh,",}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
            }else{
                fwrite ($fh,";}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
            }
        }

        fwrite ($fh,"{\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid10756800 \\par }"."\n");
        
        //'izpis udeležbe na tekmovanjih v znanju
        if ($StPohval > 0) {
            if ($Ucenci[$IndxUcenec][4]=="M"){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- sodeloval na naslednjih tekmovanjih v znanju:")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- sodelovala na naslednjih tekmovanjih v znanju:")."}{\\insrsid10756800 \\par }"."\n");
            }
            fwrite ($fh,"{\\f1\\fs12\\insrsid10756800 \\par }"."\n");
            
            for ($Indx=1;$Indx <= $StPohval;$Indx++){
                fwrite ($fh,"\\pard \\ltrpar\\qj \\li709\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin709\\itap0\\pararsid6436526 {\\f1\\fs22\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid5715400\\charrsid5715400 \\tab - ".ToRTF($VPohvala[$Indx]));
                if ($Indx < $StPohval){
                    fwrite ($fh,",}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
                }else{
                    fwrite ($fh,";}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
                }
            }
        }else{
            if ($Ucenci[$IndxUcenec][4]=="M"){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni sodeloval na tekmovanjih v znanju,")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni sodelovala na tekmovanjih v znanju,")."}{\\insrsid10756800 \\par }"."\n");
            }
        }
        fwrite ($fh,"{\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid10756800 \\par }"."\n");

        //'izpis udeležbe na šolskih športnih tekmovanjih
        if ($StKrozkovT > 0){
            if ($Ucenci[$IndxUcenec][4]=="M"){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- sodeloval na naslednjih šolskih športnih tekmovanjih:")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- sodelovala na naslednjih šolskih športnih tekmovanjih:")."}{\\insrsid10756800 \\par }"."\n");
            }
            fwrite ($fh,"{\\f1\\fs12\\insrsid10756800 \\par }"."\n");
            
            for ($Indx=1;$Indx <= $StKrozkovT;$Indx++){
                fwrite ($fh,"\\pard \\ltrpar\\qj \\li709\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin709\\itap0\\pararsid6436526 {\\f1\\fs22\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid5715400\\charrsid5715400 \\tab - ".ToRTF($VKrozekT[$Indx][0]." (".$VKrozekT[$Indx][3]."), "));
                if (strlen($VKrozekT[$Indx][5]) > 0){
                    fwrite ($fh,ToRTF($VKrozekT[$Indx][5]).", ");
                }
                if (strlen($VKrozekT[$Indx][4]) > 0){
                    fwrite ($fh,ToRTF($VKrozekT[$Indx][4]).", ");
                }
                if (strlen($VKrozekT[$Indx][2]) > 0){
                    fwrite ($fh,ToRTF($VKrozekT[$Indx][2]).",");
                }
                fwrite ($fh," mentor: ".ToRTF($VKrozekT[$Indx][1]));
                if ($Indx < $StKrozkovT){
                    fwrite ($fh,",}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
                }else{
                    fwrite ($fh,".}{\\insrsid10756800 \\par }\\pard \\ltrpar\\qj \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
                }
            }
        }else{
            if ($Ucenci[$IndxUcenec][4]=="M"){
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni sodeloval na šolskih športnih tekmovanjih.")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("- ni sodelovala na šolskih športnih tekmovanjih.")."}{\\insrsid10756800 \\par }"."\n");
            }
        }
        fwrite ($fh,"{\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VSolaKraj.", ". $PrintDay)."}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

        fwrite ($fh,"\\pard \\qj \\li0\\ri0\\widctlpar\\tx6414\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid2763354 {\\insrsid5715400\\charrsid5715400 ");
        if ($SpolRazrednik=="M"){
            fwrite ($fh,"Razrednik: \\tab ");
        }else{
            fwrite ($fh,"Razredni\\'e8arka: \\tab ");
        }
        if ($SpolRavnatelj=="M"){
            fwrite ($fh,"Ravnatelj:");
        }else{
            fwrite ($fh,"Ravnateljica:");
        }
        fwrite ($fh,"}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\f1\\fs12\\insrsid10756800 \\par }"."\n");
        
        fwrite ($fh,"{\\f1\\fs24\\insrsid5715400\\charrsid5715400 ".ToRTF($VRazrednik)." \\tab ".ToRTF($VRavnatelj)."}{\\insrsid10756800 \\par}"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par}"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 _____________________ \\tab ______________________}{\\insrsid10756800 \\par}"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par } \\pard"."\n");
        fwrite ($fh,"{\\insrsid16406371 \\page }    "."\n");
    }    
        
fwrite ($fh," }"."\n");
echo "<h2><a href='dato".$FileSep.$VFile."'>Odpri obvestila o obiskovanju interesnih dejavnosti in pohvalah</a></h2>";
echo "<a href='izpisredovalnice.php?id=4&razred=$VRazred&solskoleto=$VLeto'>Na razredno redovalnico</a>";
?>

</body>
</html>