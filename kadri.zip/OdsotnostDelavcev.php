<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odsotnosti
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>

<?php
$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    function LeadZero($x){
        if (strlen($x) < 2){
            $x="0".$x;
        }
        return $x;
    }

    $VDelavec = $_POST["delavec"];
    $VLeto = $_POST["leto"];
    $VMesec = $_POST["mesec"];
    $VDan = $_POST["dan"];
    $VLetoEnd = $_POST["LetoEnd"];
    $VMesecEnd = $_POST["MesecEnd"];
    $VDanEnd = $_POST["DanEnd"];
    $Odsotnost = $_POST["odsotnost"];

    if (!checkdate ($VMesec, $VDan ,$VLeto)){
         header("Location: VpisOdsotnostiDelavcev.php");
    }else{
        if (!checkdate ($VMesecEnd, $VDanEnd ,$VLetoEnd)){
             header("Location: VpisOdsotnostiDelavcev.php");
        }else{
            $DatumStart=new DateTime($VLeto."-".$VMesec."-".$VDan);
            $DatumEnd=new DateTime($VLetoEnd."-".$VMesecEnd."-".$VDanEnd);
            $Interval=$DatumStart->diff($DatumEnd);
            if ($Interval->invert ==1){
	            header("Location: VpisOdsotnostiDelavcev.php");
            }else{

                $SQL = "INSERT INTO tabodsotnost (stdelavca,odsotnoststart,odsotnostend,sifraodsotnosti) VALUES ('".$VDelavec."','".$DatumStart->format('Y-m-d')."','".$DatumEnd->format('Y-m-d')."',".$Odsotnost.")";
                $result = mysqli_query($link,$SQL);

                header("Location: VpisOdsotnostiDelavcev.php");
            }
        }
    }
}
?>
<a href="prijava.asp">Nazaj na glavni meni</a><br />


</body>
</html>
