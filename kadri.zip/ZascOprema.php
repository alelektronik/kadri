<?php
/*
Program ureja zaščitna sredstva delavcev: vpis, popravljanje, izpis prevzemnic.
Izpis podatkov v obrazcu, kjer se nastavlja:
    - ali delavec zadolžuje določeno sredstvo
    - datum prevzema
    - obnovo sredstev (novo sredstvo) po izteku števila mesecev (perioda)
Tabele na katere vpliva:
    tabzascsr
Izhodni podatki:
    - kreira prevzemnico v RTF, kjer so vsa zaščitna sredstva delavca in datumi prevzemov
*/
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Zaščitna oprema
</title>
</head>
<body>

<?php
function Vsebuje($a,$s){
    $x=explode(",",$s);
    return (in_array($a,$x));
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$VLetoPregled=$VLeto;

/*
if request("submit")="Prevzemnice" then
	VZapisi=""
	for indx=1 to int(request("StZapisov"))
		if request("prevzemnica_"&indx)="on" then
			if VZapisi <> "" then
				VZapisi=VZapisi&","&request("ucitelj_"&indx)
			else
				VZapisi=request("ucitelj_"&indx)
			end if
		end if
	next
	
	SQL = "SELECT * FROM tabsola"
	set R = conn.execute(SQL,,adcmdtext)
	If Not R.EOF Then
		VSola=R("Sola")
		VNaslov=R("Naslov")
		VRavnatelj=R("Ravnatelj")
		VKraj=R("Posta")&" "&R("Kraj")
	else
		VSola=" "
		VNaslov=" "
		VRavnatelj=" "
		VKraj=" "
	end if
	
	if VZapisi <> "" then
		' Use this line when using the full version of PDFBuilderASP...
		Set objPDF = Server.CreateObject("PDFBuilderASP.PDFSvrDoc")

		' ...or this line when using the trial version of PDFBuilderASP
		'Set objPDF = Server.CreateObject("PDFBuilderASPTrial.PDFSvrDoc")

		' Configure the page size, the units of measure and add a single page to the document
		objPDF.DefaultPageSize = 1   ' A4 Portrait
		objPDF.Units = 3   ' Millimetres
		objPDF.AddPage 1
		Arial=objPDF.AddFont(Server.MapPath("Arial.ttf"))
		objPDF.EmbedFont(Arial) = True
		ArialBold=objPDF.AddFont(Server.MapPath("Arialbd.ttf"))
		objPDF.EmbedFont(ArialBold) = True
		Times=objPDF.AddFont(Server.MapPath("Times.ttf"))
		objPDF.EmbedFont(Times) = True
		TimesBold=objPDF.AddFont(Server.MapPath("Timesb.ttf"))
		objPDF.EmbedFont(TimesBold) = True

		Indx1=0
		FontSize=12

		SQL = "SELECT TabZascSr.*,tabucitelji.* FROM TabZascSr "
		SQL = SQL & "INNER JOIN tabucitelji ON TabZascSr.idUcitelj=tabucitelji.idUcitelj "
		SQL = SQL & "WHERE TabZascSr.idUcitelj IN ("&VZapisi&")"
		SQL = SQL & " ORDER BY tabucitelji.priimek,tabucitelji.ime"
		set R = conn.execute(SQL,,adcmdtext)
		
		Indx=1
		Do
			if NOT R.EOF then
				if indx > 1 then
					objPDF.AddPage 0
				end if
				Logo = objPDF.AddImageFile(Server.MapPath("logo1.gif"))
				LogoIndex = objPDF.ApplyResource(indx, Logo)
				objPDF.Locate indx, LogoIndex, 35, 280.0
				objPDF.ScaleObject indx, LogoIndex, 30.0

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = ArialBold
				objPDF.TextSize = 18
				objPDF.TextAlign = 1
				objPDF.TextMaxWidth = 80
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437(VSola)
				objPDF.WriteText To437(VNaslov)
				objPDF.WriteText To437(VKraj)
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 142.0, 272.0
				Indx1=Indx1+1

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = 14
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				if R("spol")="M" then
					objPDF.WriteText To437("S to prevzemnico delavec "&R("ime")&" "&R("priimek")&" potrjuje prevzem naslednjih za??itnih sredstev:")
				else
					objPDF.WriteText To437("S to prevzemnico delavka "&R("ime")&" "&R("priimek")&" potrjuje prevzem naslednjih za??itnih sredstev:")
				end if
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 20.0, 210.0
				Indx1=Indx1+1

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = ArialBold
				objPDF.TextSize = 18
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("Prevzemnica")
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 20.0, 232.0
				Indx1=Indx1+1

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = 12
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("Datum izdaje: "&day(now)&"."&month(now)&"."&year(now))
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 20.0, 224.0
				Indx1=Indx1+1

				YPoz=190
				
				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = FontSize
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 170
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("Za??itno sredstvo in datum prevzema:")

				i1=1
				if R("DelHaljaM") then
					objPDF.WriteText To437(i1&". Delovna halja ("&R("DatDelHaljaM")&")")
					i1=i1+1
				end if
				if R("OrtCevlji") then
					objPDF.WriteText To437(i1&". Ortopedski ?evlji ("&R("DatOrtCevlji")&")")
					i1=i1+1
				end if
				if R("RokG") then
					objPDF.WriteText To437(i1&". Gumi rokavice ("&R("DatRokG")&")")
					i1=i1+1
				end if
				if R("DelCevlji") then
					objPDF.WriteText To437(i1&". Delovni ?evlji ("&R("DatDelCevlji")&")")
					i1=i1+1
				end if
				if R("SkornjiG") then
					objPDF.WriteText To437(i1&". Gumi ?kornji ("&R("DatSkornjiG")&")")
					i1=i1+1
				end if
				if R("RokU") then
					objPDF.WriteText To437(i1&". Za??itne usnjene rokavice ("&R("DatRokU")&")")
					i1=i1+1
				end if
				if R("DelHaljaHlB") then
					objPDF.WriteText To437(i1&". Delovne hla?e ("&R("DatDelHaljaHlB")&")")
					i1=i1+1
				end if
				if R("HlaceB") then
					objPDF.WriteText To437(i1&". Delovne hla?e ("&R("DatHlaceB")&")")
					i1=i1+1
				end if
				if R("KapaB") then
					objPDF.WriteText To437(i1&". Ruta ali kapa - bela ("&R("DatKapaB")&")")
					i1=i1+1
				end if
				if R("PredpB") then
					objPDF.WriteText To437(i1&". Predpasnik - beli ("&R("DatPredpB")&")")
					i1=i1+1
				end if
				if R("Cevlji") then
					objPDF.WriteText To437(i1&". Za??itni ?evlji ("&R("DatCevlji")&")")
					i1=i1+1
				end if
				if R("DelHaljaB") then
					objPDF.WriteText To437(i1&". Delovna halja - bela ("&R("DatDelHaljaB")&")")
					i1=i1+1
				end if
				if R("RokaviceK") then
					objPDF.WriteText To437(i1&". Rokavice za delo s kislinami ("&R("RokaviceK")&")")
					i1=i1+1
				end if
				if R("Ocala") then
					objPDF.WriteText To437(i1&". Za??itna o?ala ("&R("DatOcala")&")")
					i1=i1+1
				end if
				if R("Trenirka") then
					objPDF.WriteText To437(i1&". Trenirka ("&R("DatTrenirka")&")")
					i1=i1+1
				end if
				if R("Superge") then
					objPDF.WriteText To437(i1&". Telovadni copati ("&R("DatSuperge")&")")
					i1=i1+1
				end if
				if R("TShirt") then
					objPDF.WriteText To437(i1&". T-shirt majica ("&R("DatTShirt")&")")
					i1=i1+1
				end if
				if R("PoloMajica") then
					objPDF.WriteText To437(i1&". Polo majica ("&R("DatPoloMajica")&")")
					i1=i1+1
				end if
				if R("PredpPis") then
					objPDF.WriteText To437(i1&". Predpasnik-pisani ("&R("DatPredpPis")&")")
					i1=i1+1
				end if
				if R("Tunika") then
					objPDF.WriteText To437(i1&". Tunika s kratkimi rokavi ("&R("DatTunika")&")")
					i1=i1+1
				end if
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 20.0, YPoz
				Indx1=Indx1+1
				
				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = 12
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("Izdajatelj: ___________________")
				objPDF.WriteText " "
				objPDF.WriteText To437("Podpis: _____________________")
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 20.0, 45.0
				Indx1=Indx1+1

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = 12
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("Prevzemnik: _________________")
				objPDF.WriteText " "
				objPDF.WriteText To437("Podpis: _____________________")
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 120.0, 45.0
				Indx1=Indx1+1

				Besedilo(Indx1) = objPDF.CreateText
				objPDF.TextFont = Arial
				objPDF.TextSize = 12
				objPDF.TextAlign = 0
				objPDF.TextMaxWidth = 180
				objPDF.TextColor = vbBlack
				objPDF.WriteText To437("?ig: ")
				BesediloIndx(Indx1) = objPDF.ApplyResource(indx, Besedilo(Indx1))
				objPDF.Locate indx, BesediloIndx(Indx1), 100.0, 35.0
				Indx1=Indx1+1
			else
				Exit Do
			end if
			R.MoveNext
			indx=indx+1
		Loop
		
		conn.close
		Set Conn=nothing

		' Finally, stream the document to the browser for display
'	objPDF.SaveToFile BaseDir&"KrozkiObvestila.pdf"
		objPDF.StreamInline = True
		objPDF.StreamFileName = "Prevzemnica.pdf"
		objPDF.BinaryWrite

		Set objPDF = Nothing
	end if
else
%>
*/

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

function To437($txt){
    $txt=str_replace("Č","^",$txt);
    $txt=str_replace("č","~",$txt);
    $txt=str_replace("Š","[",$txt);
    $txt=str_replace("š","{",$txt);
    $txt=str_replace("Ž","@",$txt);
    $txt=str_replace("ž","`",$txt);
    $txt=str_replace("Ć","]",$txt);
    $txt=str_replace("ć","}",$txt);
    $txt=str_replace("Đ","\\",$txt);
    $txt=str_replace("đ","|",$txt);
    return $txt;
}
//detektira, če je bil poslan obrazec
if (isset($_POST["submit"])) {
    $Poslano= $_POST["submit"];
}else{
    $Poslano="";
}
switch ($Poslano){
    case "Prevzemnice":    
        //v primeru zahteve po izpisu prevzemnice, kreira rtf dokument
        $Vid="0";
        $VFile="prevzemnice.rtf";
        $MyFile = "dato".$FileSep.$VFile;
        $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

        fwrite ($fh,"{\\rtf1\\adeflang1025\\ansi\\ansicpg1250\\uc1\\adeff31507\\deff0\\stshfdbch31506\\stshfloch31506\\stshfhich31506\\stshfbi31507\\deflang1060\\deflangfe1060\\themelang1060\\themelangfe0\\themelangcs0{\\fonttbl{\\f1\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}{\\f34\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria Math;}");
        fwrite ($fh,"{\\f37\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}{\\flomajor\\f31500\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}");
        fwrite ($fh,"{\\fdbmajor\\f31501\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fhimajor\\f31502\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria;}");
        fwrite ($fh,"{\\fbimajor\\f31503\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\flominor\\f31504\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}");
        fwrite ($fh,"{\\fdbminor\\f31505\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fhiminor\\f31506\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}");
        fwrite ($fh,"{\\fbiminor\\f31507\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f473\\fbidi \\fswiss\\fcharset0\\fprq2 Arial;}{\\f472\\fbidi \\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f474\\fbidi \\fswiss\\fcharset161\\fprq2 Arial Greek;}");
        fwrite ($fh,"{\\f475\\fbidi \\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f476\\fbidi \\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f477\\fbidi \\fswiss\\fcharset178\\fprq2 Arial (Arabic);}{\\f478\\fbidi \\fswiss\\fcharset186\\fprq2 Arial Baltic;}");
        fwrite ($fh,"{\\f479\\fbidi \\fswiss\\fcharset163\\fprq2 Arial (Vietnamese);}{\\f803\\fbidi \\froman\\fcharset0\\fprq2 Cambria Math;}{\\f802\\fbidi \\froman\\fcharset204\\fprq2 Cambria Math Cyr;}{\\f804\\fbidi \\froman\\fcharset161\\fprq2 Cambria Math Greek;}");
        fwrite ($fh,"{\\f805\\fbidi \\froman\\fcharset162\\fprq2 Cambria Math Tur;}{\\f808\\fbidi \\froman\\fcharset186\\fprq2 Cambria Math Baltic;}{\\f809\\fbidi \\froman\\fcharset163\\fprq2 Cambria Math (Vietnamese);}{\\f833\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}");
        fwrite ($fh,"{\\f832\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}{\\f834\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\f835\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}{\\f838\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}");
        fwrite ($fh,"{\\f839\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\flomajor\\f31510\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flomajor\\f31509\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
        fwrite ($fh,"{\\flomajor\\f31511\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\flomajor\\f31512\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flomajor\\f31513\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}");
        fwrite ($fh,"{\\flomajor\\f31514\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\flomajor\\f31515\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flomajor\\f31516\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}");
        fwrite ($fh,"{\\fdbmajor\\f31520\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fdbmajor\\f31519\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbmajor\\f31521\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}");
        fwrite ($fh,"{\\fdbmajor\\f31522\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fdbmajor\\f31523\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbmajor\\f31524\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
        fwrite ($fh,"{\\fdbmajor\\f31525\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fdbmajor\\f31526\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhimajor\\f31530\\fbidi \\froman\\fcharset0\\fprq2 Cambria;}");
        fwrite ($fh,"{\\fhimajor\\f31529\\fbidi \\froman\\fcharset204\\fprq2 Cambria Cyr;}{\\fhimajor\\f31531\\fbidi \\froman\\fcharset161\\fprq2 Cambria Greek;}{\\fhimajor\\f31532\\fbidi \\froman\\fcharset162\\fprq2 Cambria Tur;}");
        fwrite ($fh,"{\\fhimajor\\f31535\\fbidi \\froman\\fcharset186\\fprq2 Cambria Baltic;}{\\fhimajor\\f31536\\fbidi \\froman\\fcharset163\\fprq2 Cambria (Vietnamese);}{\\fbimajor\\f31540\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}");
        fwrite ($fh,"{\\fbimajor\\f31539\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fbimajor\\f31541\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbimajor\\f31542\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}");
        fwrite ($fh,"{\\fbimajor\\f31543\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fbimajor\\f31544\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbimajor\\f31545\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}");
        fwrite ($fh,"{\\fbimajor\\f31546\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\flominor\\f31550\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flominor\\f31549\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
        fwrite ($fh,"{\\flominor\\f31551\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\flominor\\f31552\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flominor\\f31553\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}");
        fwrite ($fh,"{\\flominor\\f31554\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\flominor\\f31555\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flominor\\f31556\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}");
        fwrite ($fh,"{\\fdbminor\\f31560\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fdbminor\\f31559\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbminor\\f31561\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}");
        fwrite ($fh,"{\\fdbminor\\f31562\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fdbminor\\f31563\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbminor\\f31564\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
        fwrite ($fh,"{\\fdbminor\\f31565\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fdbminor\\f31566\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhiminor\\f31570\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}");
        fwrite ($fh,"{\\fhiminor\\f31569\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}{\\fhiminor\\f31571\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\fhiminor\\f31572\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}");
        fwrite ($fh,"{\\fhiminor\\f31575\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}{\\fhiminor\\f31576\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\fbiminor\\f31580\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}");
        fwrite ($fh,"{\\fbiminor\\f31579\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fbiminor\\f31581\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbiminor\\f31582\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}");
        fwrite ($fh,"{\\fbiminor\\f31583\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fbiminor\\f31584\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbiminor\\f31585\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}");
        fwrite ($fh,"{\\fbiminor\\f31586\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f463\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\f462\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
        fwrite ($fh,"{\\f464\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f465\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f466\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f467\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
        fwrite ($fh,"{\\f468\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f469\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}}{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;");
        fwrite ($fh,"\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;}");
        fwrite ($fh,"{\\*\\defchp \\f31506\\fs22\\lang1060\\langfe1033\\langfenp1033 }{\\*\\defpap \\ql \\li0\\ri0\\sa200\\sl276\\slmult1\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 }\\noqfpromote {\\stylesheet{");
        fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\snext0 \\sqformat \\spriority0 \\styrsid84957 Normal;}{\\*");
        fwrite ($fh,"\\cs10 \\additive \\ssemihidden \\sunhideused \\spriority1 Default Paragraph Font;}{\\*");
        fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\trcbpat1\\trcfpat1\\tblind0\\tblindtype3\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv \\ql \\li0\\ri0\\sa200\\sl276\\slmult1");
        fwrite ($fh,"\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\snext11 \\ssemihidden \\sunhideused Normal Table;}}");
        fwrite ($fh,"{\\*\\rsidtbl \\rsid84957\\rsid284499\\rsid2643828\\rsid14885343}{\\mmathPr\\mmathFont34\\mbrkBin0\\mbrkBinSub0\\msmallFrac0\\mdispDef1\\mlMargin0\\mrMargin0\\mdefJc1\\mwrapIndent1440\\mintLim0\\mnaryLim1}{\\info");
        fwrite ($fh,"{\\creatim\\yr2013\\mo4\\dy27\\hr13\\min49}{\\revtim\\yr2013\\mo4\\dy27\\hr14}{\\version1}{\\edmins11}{\\nofpages1}{\\nofwords63}{\\nofchars360}{\\nofcharsws422}{\\vern49275}}{\\*\\xmlnstbl {\\xmlns1 http://schemas.microsoft.com/office/word/2003/wordml}}");
        fwrite ($fh,"\\paperw11906\\paperh16838\\margl1417\\margr1417\\margt1417\\margb1417\\gutter0\\ltrsect ");
        fwrite ($fh,"\\deftab708\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\trackmoves0\\trackformatting1\\donotembedsysfont1\\relyonvml0\\donotembedlingdata0\\grfdocevents0\\validatexml1\\showplaceholdtext0\\ignoremixedcontent0\\saveinvalidxml0");
        fwrite ($fh,"\\showxmlerrors1\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dgmargin\\dghspace180\\dgvspace180\\dghorigin1417\\dgvorigin1417\\dghshow1\\dgvshow1");
        fwrite ($fh,"\\jexpand\\viewkind1\\viewscale100\\pgbrdrhead\\pgbrdrfoot\\splytwnine\\ftnlytwnine\\htmautsp\\nolnhtadjtbl\\useltbaln\\alntblind\\lytcalctblwd\\lyttblrtgr\\lnbrkrule\\nobrkwrptbl\\snaptogridincell\\allowfieldendsel\\wrppunct");
        fwrite ($fh,"\\asianbrkrule\\rsidroot14885343\\newtblstyruls\\nogrowautofit\\usenormstyforlist\\noindnmbrts\\felnbrelev\\nocxsptable\\indrlsweleven\\noafcnsttbl\\afelev\\utinl\\hwelev\\spltpgpar\\notcvasp\\notbrkcnstfrctbl\\notvatxbx\\krnprsnet\\cachedcolbal \\nouicompat \\fet0");
        fwrite ($fh,"{\\*\\wgrffmtfilter 2450}\\nofeaturethrottle1\\ilfomacatclnup0\\ltrpar \\sectd \\ltrsect\\linex0\\headery708\\footery708\\colsx708\\endnhere\\sectlinegrid360\\sectdefaultcl\\sftnbj {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2");
        fwrite ($fh,"\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6");
        fwrite ($fh,"\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang ");
        fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\faauto\\rin0\\lin0\\itap0\\pararsid14885343 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 ");

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VRavnatelj=$R["Ravnatelj"];
            $VKraj=$R["Kraj"];
            $VNaslov=$R["Naslov"];
            $VPosta=$R["Posta"]." ".$VKraj;
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $VKraj=" ";
            $VNaslov=" ";
            $VPosta=" ";
        }
        if (isset($_SESSION["DayToPrint"])){
        $PrintDay=$_SESSION["DayToPrint"];
        }else{
            $PrintDay=$Danes->format('j.n.Y');
        }
        if (isset($_SESSION["RefStFix"])){
            $RefStFix = $_SESSION["RefStFix"];
        }else{
            $RefStFix = "";
        }
        if (isset($_SESSION["RefStVar"])){
            $RefStVar = $_SESSION["RefStVar"];
        }else{
            $RefStVar = "";
        }

        for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
            if (isset($_POST["prevzemnica_".$Indx])) {
                
                //izpis imena šole
                fwrite ($fh,"{\\rtlch\\fcs1 \\ab\\af1\\afs36 \\ltrch\\fcs0 \\b\\f1\\fs36\\insrsid14885343\\charrsid14885343 ".ToRTF($VSola));
                
                //izpis ulice
                fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\ab\\af1\\afs36 \\ltrch\\fcs0 \\b\\f1\\fs36\\insrsid14885343 ".ToRTF($VNaslov));
                
                //izpis pošte
                fwrite ($fh,"\\par ".ToRTF($VPosta)."}{\\rtlch\\fcs1 \\ab\\af1\\afs36 \\ltrch\\fcs0 \\b\\f1\\fs36\\insrsid14885343\\charrsid14885343 ");
                fwrite ($fh,"\\par ");
                
                //Prevzemnica
                fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\ab\\af1\\afs36 \\ltrch\\fcs0 \\b\\f1\\fs36\\insrsid14885343\\charrsid14885343 Prevzemnica");
                
                //Datum izdaje
                fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 Datum izdaje: ".$PrintDay);
                fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ");

                $SQL = "SELECT TabZascSr.*,tabucitelji.* FROM TabZascSr ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON TabZascSr.idUcitelj=tabucitelji.IdUcitelj ";
                $SQL = $SQL . "WHERE TabZascSr.idUcitelj =".$_POST["ucitelj_".$Indx];
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    //Besedilo
                    if ($R["Spol"]=="M"){
                        fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343\\charrsid14885343 S to prevzemnico delavec }");
                    }else{
                        fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343\\charrsid14885343 S to prevzemnico delavka }");
                    }
                    
                    //delavec
                    fwrite ($fh,"{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\b\\f1\\fs28\\insrsid14885343\\charrsid2643828 ".ToRTF($R["Ime"]." ".$R["Priimek"])."}");
                    
                    //nadaljevanje besedila
                    fwrite ($fh,"{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343\\charrsid14885343  potrjuje prevzem}{\\rtlch\\fcs1 \\af1\\afs28 ");
                    fwrite ($fh,"\\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343  }{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343\\charrsid14885343 naslednjih za}{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343 \\'9a\\'e8}{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 ");
                    fwrite ($fh,"\\f1\\fs28\\insrsid14885343\\charrsid14885343 itnih sredstev:}{\\rtlch\\fcs1 \\af1\\afs28 \\ltrch\\fcs0 \\f1\\fs28\\insrsid14885343\\charrsid14885343 ");
                    fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ");
                    fwrite ($fh,"\\par }");
                    
                    //zaščitna sredstva
                    fwrite ($fh,"{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\b\\f1\\insrsid14885343\\charrsid2643828 Za}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\b\\f1\\insrsid14885343\\charrsid2643828 \\'9a\\'e8}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\b\\f1\\insrsid14885343\\charrsid2643828 ");
                    fwrite ($fh,"itno sredstvo in datum prevzema:");
                    fwrite ($fh,"\\par }");
                    
                    //naštevanje
                    $i=1;
                    fwrite ($fh,"{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ");
                    if ($R["DelHaljaM"]) {
                        $i_str=$i.(ToRTF(". Delovna halja (".$R["DatDelHaljaM"])).")\\par ";
                        fwrite ($fh,$i_str);
                        $i++;
                    }
                    if ($R["OrtCevlji"]) {
                        fwrite ($fh,$i.ToRTF(". Ortopedski čevlji (".$R["DatOrtCevlji"]).")\\par ");
                        $i++;
                    }
                    if ($R["RokG"]) {
                        fwrite ($fh,$i.ToRTF(". Gumi rokavice (".$R["DatRokG"]).")\\par ");
                        $i++;
                    }
                    if ($R["DelCevlji"]) {
                        $i_str=$i.(ToRTF(". Delovni čevlji (".$R["DatDelCevlji"])).")\\par ";
                        fwrite ($fh,$i_str);
                        $i++;
                    }
                    if ($R["SkornjiG"]) {
                        fwrite ($fh,$i.ToRTF(". Gumi škornji (".$R["DatSkornjiG"]).")\\par ");
                        $i++;
                    }
                    if ($R["RokU"]) {
                        fwrite ($fh,$i.ToRTF(". Zaščitne usnjene rokavice (".$R["DatRokU"]).")\\par ");
                        $i++;
                    }
                    if ($R["DelHaljaHlB"]) {
                        fwrite ($fh,$i.ToRTF(". Delovne hlače (".$R["DatDelHaljaHlB"]).")\\par ");
                        $i++;
                    }
                    if ($R["HlaceB"]) {
                        fwrite ($fh,$i.ToRTF(". Delovne hlače (".$R["DatHlaceB"]).")\\par ");
                        $i++;
                    }
                    if ($R["KapaB"]) {
                        fwrite ($fh,$i.ToRTF(". Ruta ali kapa - bela (".$R["DatKapaB"]).")\\par ");
                        $i++;
                    }
                    if ($R["PredpB"]) {
                        fwrite ($fh,$i.ToRTF(". Predpasnik - beli (".$R["DatPredpB"]).")\\par ");
                        $i++;
                    }
                    if ($R["Cevlji"]) {
                        fwrite ($fh,$i.ToRTF(". Zaščitni čevlji (".$R["DatCevlji"]).")\\par ");
                        $i++;
                    }
                    if ($R["DelHaljaB"]) {
                        fwrite ($fh,$i.ToRTF(". Delovna halja - bela (".$R["DatDelHaljaB"]).")\\par ");
                        $i++;
                    }
                    if ($R["RokaviceK"]) {
                        fwrite ($fh,$i.ToRTF(". Rokavice za delo s kislinami (".$R["RokaviceK"]).")\\par ");
                        $i++;
                    }
                    if ($R["Ocala"]) {
                        fwrite ($fh,$i.ToRTF(". Zaščitna očala (".$R["DatOcala"]).")\\par ");
                        $i++;
                    }
                    if ($R["Trenirka"]) {
                        fwrite ($fh,$i.ToRTF(". Trenirka (".$R["DatTrenirka"]).")\\par ");
                        $i++;
                    }
                    if ($R["Superge"]) {
                        fwrite ($fh,$i.ToRTF(". Telovadni copati (".$R["DatSuperga"]).")\\par ");
                        $i++;
                    }
                    if ($R["TShirt"]) {
                        fwrite ($fh,$i.ToRTF(". T-shirt majica (".$R["DatTShirt"]).")\\par ");
                        $i++;
                    }
                    if ($R["PoloMajica"]) {
                        fwrite ($fh,$i.ToRTF(". Polo majica (".$R["DatPoloMajica"]).")\\par ");
                        $i++;
                    }
                    if ($R["PredpPis"]) {
                        fwrite ($fh,$i.ToRTF(". Predpasnik - pisani (".$R["DatPredpPis"]).")\\par ");
                        $i++;
                    }
                    if ($R["Tunika"]) {
                        fwrite ($fh,$i.ToRTF(". Tunika s kratkimi rokavi (".$R["DatTunika"]).")\\par ");
                        $i++;
                    }
                    
                    fwrite ($fh,"}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343 ");
                }
                //podpisi
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\tx5103\\wrapdefault\\faauto\\rin0\\lin0\\itap0\\pararsid14885343 {\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 Izdajatelj: ___________________}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 ");
                fwrite ($fh,"\\f1\\insrsid14885343 \\tab }{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 Prevzemnik: _________________");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\faauto\\rin0\\lin0\\itap0\\pararsid14885343 {\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\tx4253\\tx5103\\wrapdefault\\faauto\\rin0\\lin0\\itap0\\pararsid14885343 {\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 Podpis: _____________________}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 ");
                fwrite ($fh,"\\f1\\insrsid14885343 \\tab \\'8e}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ig:}{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343 \\tab }{\\rtlch\\fcs1 \\af1\\afs24 \\ltrch\\fcs0 \\f1\\insrsid14885343\\charrsid14885343 ");
                fwrite ($fh,"Podpis: _____________________}{\\rtlch\\fcs1 \\af1 \\ltrch\\fcs0 \\f1\\insrsid284499\\charrsid14885343 ");
                fwrite ($fh,"\\par }");
                fwrite ($fh,"{\\page }");
            }
        }
        fwrite ($fh,"}");
        fclose($fh);
        echo "<h2><a href='".$MyFile."'>Prevzemnice</a></h2>";
        break;
    default:
        //preveri, če gre za običajen izpis (0) zaščitnih sredstev
        if ($ZascSre==0){
            switch ($Vid){
                //v primeru spreminjanja podatkov, jih vpiše v bazo
	            case "1":
		            for ($Indx=1;$Indx <=$_POST["StZapisov"];$Indx++){
                        if ($_POST["ucitelj_".$Indx] > 0){
			                $SQL = "SELECT * FROM TabZascSr WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
			                $result = mysqli_query($link,$SQL);

				            if ($R = mysqli_fetch_array($result)){
					            $SQL = "UPDATE TabZascSr SET ";

					            $PeriodaPV=$_POST["PerDelHaljaM_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaM_".$Indx])){
						            $SQL = $SQL . "DelHaljaM=true,";
					            }else{
						            $SQL = $SQL . "DelHaljaM=false,";
					            }
					            $SQL = $SQL . "DatDelHaljaM='".$_POST["DatDelHaljaM_".$Indx]."',";
					            $SQL = $SQL . "PerDelHaljaM=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerOrtCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["OrtCevlji_".$Indx])){
						            $SQL = $SQL . "OrtCevlji=true,";
					            }else{
						            $SQL = $SQL . "OrtCevlji=false,";
					            }
					            $SQL = $SQL . "DatOrtCevlji='".$_POST["DatOrtCevlji_".$Indx]."',";
					            $SQL = $SQL . "PerOrtCevlji=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerRokG_".$Indx];
					            if (!is_numeric($PeriodaPV)){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokG_".$Indx])){
						            $SQL = $SQL . "RokG=true,";
					            }else{
						            $SQL = $SQL . "RokG=false,";
					            }
					            $SQL = $SQL . "DatRokG='".$_POST["DatRokG_".$Indx]."',";
					            $SQL = $SQL . "PerRokG=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelCevlji_".$Indx])){
						            $SQL = $SQL . "DelCevlji=true,";
					            }else{
						            $SQL = $SQL . "DelCevlji=false,";
					            }
					            $SQL = $SQL . "DatDelCevlji='".$_POST["DatDelCevlji_".$Indx]."',";
					            $SQL = $SQL . "PerDelCevlji=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerSkornjiG_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["SkornjiG_".$Indx])){
						            $SQL = $SQL . "SkornjiG=true,";
					            }else{
						            $SQL = $SQL . "SkornjiG=false,";
					            }
					            $SQL = $SQL . "DatSkornjiG='".$_POST["DatSkornjiG_".$Indx]."',";
					            $SQL = $SQL . "PerSkornjiG=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerRokU_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokU_".$Indx])){
						            $SQL = $SQL . "RokU=true,";
					            }else{
						            $SQL = $SQL . "RokU=false,";
					            }
					            $SQL = $SQL . "DatRokU='".$_POST["DatRokU_".$Indx]."',";
					            $SQL = $SQL . "PerRokU=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelHaljaHlB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaHlB_".$Indx])){
						            $SQL = $SQL . "DelHaljaHlB=true,";
					            }else{
						            $SQL = $SQL . "DelHaljaHlB=false,";
					            }
					            $SQL = $SQL . "DatDelHaljaHlB='".$_POST["DatDelHaljaHlB_".$Indx]."',";
					            $SQL = $SQL . "PerDelHaljaHlB=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerKapaB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["KapaB_".$Indx])){
						            $SQL = $SQL . "KapaB=true,";
					            }else{
						            $SQL = $SQL . "KapaB=false,";
					            }
					            $SQL = $SQL . "DatKapaB='".$_POST["DatKapaB_".$Indx]."',";
					            $SQL = $SQL . "PerKapaB=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPredpB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PredpB_".$Indx])){
						            $SQL = $SQL . "PredpB=true,";
					            }else{
						            $SQL = $SQL . "PredpB=false,";
					            }
					            $SQL = $SQL . "DatPredpB='".$_POST["DatPredpB_".$Indx]."',";
					            $SQL = $SQL . "PerPredpB=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Cevlji_".$Indx])){
						            $SQL = $SQL . "Cevlji=true,";
					            }else{
						            $SQL = $SQL . "Cevlji=false,";
					            }
					            $SQL = $SQL . "DatCevlji='".$_POST["DatCevlji_".$Indx]."',";
					            $SQL = $SQL . "PerCevlji=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelHaljaB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaB_".$Indx])){
						            $SQL = $SQL . "DelHaljaB=true,";
					            }else{
						            $SQL = $SQL . "DelHaljaB=false,";
					            }
					            $SQL = $SQL . "DatDelHaljaB='".$_POST["DatDelHaljaB_".$Indx]."',";
					            $SQL = $SQL . "PerDelHaljaB=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerRokaviceK_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokaviceK_".$Indx])){
						            $SQL = $SQL . "RokaviceK=true,";
					            }else{
						            $SQL = $SQL . "RokaviceK=false,";
					            }
					            $SQL = $SQL . "DatRokaviceK='".$_POST["DatRokaviceK_".$Indx]."',";
					            $SQL = $SQL . "PerRokaviceK=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerOcala_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Ocala_".$Indx])){
						            $SQL = $SQL . "Ocala=true,";
					            }else{
						            $SQL = $SQL . "Ocala=false,";
					            }
					            $SQL = $SQL . "DatOcala='".$_POST["DatOcala_".$Indx]."',";
					            $SQL = $SQL . "PerOcala=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTShirt_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["TShirt_".$Indx])){
						            $SQL = $SQL . "TShirt=true,";
					            }else{
						            $SQL = $SQL . "TShirt=false,";
					            }
					            $SQL = $SQL . "DatTShirt='".$_POST["DatTShirt_".$Indx]."',";
					            $SQL = $SQL . "PerTShirt=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPoloMajica_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PoloMajica_".$Indx])){
						            $SQL = $SQL . "PoloMajica=true,";
					            }else{
						            $SQL = $SQL . "PoloMajica=false,";
					            }
					            $SQL = $SQL . "DatPoloMajica='".$_POST["DatPoloMajica_".$Indx]."',";
					            $SQL = $SQL . "PerPoloMajica=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPredpPis_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PredpPis_".$Indx])){
						            $SQL = $SQL . "PredpPis=true,";
					            }else{
						            $SQL = $SQL . "PredpPis=false,";
					            }
					            $SQL = $SQL . "DatPredpPis='".$_POST["DatPredpPis_".$Indx]."',";
					            $SQL = $SQL . "PerPredpPis=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTunika_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Tunika_".$Indx])){
						            $SQL = $SQL . "Tunika=true,";
					            }else{
						            $SQL = $SQL . "Tunika=false,";
					            }
					            $SQL = $SQL . "DatTunika='".$_POST["DatTunika_".$Indx]."',";
					            $SQL = $SQL . "PerTunika=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTrenirka_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Trenirka_".$Indx])){
						            $SQL = $SQL . "Trenirka=true,";
					            }else{
						            $SQL = $SQL . "Trenirka=false,";
					            }
					            $SQL = $SQL . "DatTrenirka='".$_POST["DatTrenirka_".$Indx]."',";
					            $SQL = $SQL . "PerTrenirka=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerHlaceB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["HlaceB_".$Indx])){
						            $SQL = $SQL . "HlaceB=true,";
					            }else{
						            $SQL = $SQL . "HlaceB=false,";
					            }
					            $SQL = $SQL . "DatHlaceB='".$_POST["DatHlaceB_".$Indx]."',";
					            $SQL = $SQL . "PerHlaceB=".$PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerSuperge_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Superge_".$Indx])){
						            $SQL = $SQL . "Superge=true,";
					            }else{
						            $SQL = $SQL . "Superge=false,";
					            }
					            $SQL = $SQL . "DatSuperge='".$_POST["DatSuperge_".$Indx]."',";
					            $SQL = $SQL . "PerSuperge=".$PeriodaPV;
					            
					            $SQL = $SQL . " WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
				            }else{
					            $SQL = "INSERT INTO TabZascSr (idUcitelj,";
					            $SQL = $SQL . "DelHaljaM,DatDelHaljaM,PerDelHaljaM,";
					            $SQL = $SQL . "OrtCevlji,DatOrtCevlji,PerOrtCevlji,";
					            $SQL = $SQL . "RokG,DatRokG,PerRokG,";
					            $SQL = $SQL . "DelCevlji,DatDelCevlji,PerDelCevlji,";
					            $SQL = $SQL . "SkornjiG,DatSkornjiG,PerSkornjiG,";
					            $SQL = $SQL . "RokU,DatRokU,PerRokU,";
					            $SQL = $SQL . "DelHaljaHlB,DatDelHaljaHlB,PerDelHaljaHlB,";
					            $SQL = $SQL . "HlaceB,DatHlaceB,PerHlaceB,";
					            $SQL = $SQL . "KapaB,DatKapaB,PerKapaB,";
					            $SQL = $SQL . "PredpB,DatPredpB,PerPredpB,";
					            $SQL = $SQL . "Cevlji,DatCevlji,PerCevlji,";
					            $SQL = $SQL . "DelHaljaB,DatDelHaljaB,PerDelHaljaB,";
					            $SQL = $SQL . "RokaviceK,DatRokaviceK,PerRokaviceK,";
					            $SQL = $SQL . "Ocala,DatOcala,PerOcala,";
					            $SQL = $SQL . "TShirt,DatTShirt,PerTShirt,";
					            $SQL = $SQL . "PoloMajica,DatPoloMajica,PerPoloMajica,";
					            $SQL = $SQL . "PredpPis,DatPredpPis,PerPredpPis,";
					            $SQL = $SQL . "Tunika,DatTunika,PerTunika,";
					            $SQL = $SQL . "Trenirka,DatTrenirka,PerTrenirka,";
					            $SQL = $SQL . "Superge,DatSuperge,PerSuperge";
					            $SQL = $SQL . ") VALUES (".$_POST["ucitelj_".$Indx].",";

					            $PeriodaPV=$_POST["PerDelHaljaM_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaM_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatDelHaljaM_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerOrtCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["OrtCevlji_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatOrtCevlji_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerRokG_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokG_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatRokG_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelCevlji_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatDelCevlji_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerSkornjiG_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["SkornjiG_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatSkornjiG_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerRokU_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokU_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatRokU_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelHaljaHlB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaHlB_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatDelHaljaHlB_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerKapaB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["KapaB_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatKapaB_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPredpB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PredpB_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatPredpB_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerCevlji_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Cevlji_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatCevlji_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerDelHaljaB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["DelHaljaB_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatDelHaljaB_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerHlaceB_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["HlaceB_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
                                if (isset($_POST["HlaceB_".$Indx])){
					                $SQL = $SQL . "'".$_POST["HlaceB_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
					            $SQL = $SQL . $PeriodaPV.",";

					            $PeriodaPV=$_POST["PerRokaviceK_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["RokaviceK_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatRokaviceK_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerOcala_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Ocala_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatOcala_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTShirt_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["TShirt_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatTShirt_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPoloMajica_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PoloMajica_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatPoloMajica_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerPredpPis_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["PredpPis_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatPredpPis_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTunika_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Tunika_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatTunika_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerTrenirka_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Trenirka_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatTrenirka_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV.",";
					            
					            $PeriodaPV=$_POST["PerSuperge_".$Indx];
					            if (!is_numeric($PeriodaPV) ){
						            $PeriodaPV=0;
					            }
					            if (isset($_POST["Superge_".$Indx])){
						            $SQL = $SQL . "true,";
					            }else{
						            $SQL = $SQL . "false,";
					            }
					            $SQL = $SQL . "'".$_POST["DatSuperge_".$Indx]."',";
					            $SQL = $SQL . $PeriodaPV;
					            
					            $SQL = $SQL . ")";
				            }
				            $result = mysqli_query($link,$SQL);
			            }
                    }
            }
            //izpis zaščitnih sredstev
            $SQL = "SELECT tabucitelji.*, TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo, TabStatus.Status,TabZascSr.* FROM ";
            $SQL = $SQL . "((TabVzgDelo INNER JOIN ";
            $SQL = $SQL . "(TabDelo INNER JOIN tabucitelji ON TabDelo.IdDelo=tabucitelji.IdDelo) ON TabVzgDelo.IdVzgojnoDelo=tabucitelji.IdVzgojnoDelo) ";
            $SQL = $SQL . "INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus) ";
            $SQL = $SQL . "LEFT JOIN TabZascSr ON tabucitelji.idUcitelj=TabZascSr.idUcitelj ";
            $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.Status < 10 ";
            $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
            //Response.Write "<br>" . $SQL . "<br>"
            $result = mysqli_query($link,$SQL);

            $Indx=1;

            echo "<h2>Pregled zaščitnih sredstev</h2>";
            echo "Pri zaščitnih sredstvih se da kljukico pri zaščitnem sredstvu, ki ga delavec uporablja. V naslednjem oknu se vpiše datum prevzema in zraven še na koliko časa (v mesecih) delavcu pripada novo zašč. sredstvo.<br>če rok poteče, je polje obarvano rdeče.";
            echo "<form name='form_ZascSr' method=post action='ZascOprema.php'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<input name='submit' type='submit' value='Prevzemnice'>";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan><th>Št.</th><th>Delavec</th>";
            echo "<th>Naziv del. mesta</th>";
            echo "<th>Prevzemnica</th>";
            echo "<th>Del. halja</th>";
            echo "<th>Ortopedski<br>čevlji</th>";
            echo "<th>Gumi rokavice</th>";
            echo "<th>Delovni<br>čevlji</th>";
            echo "<th>Gumi<br>škornji</th>";
            echo "<th>Zašč. usnjene<br>rokavice</th>";
            echo "<th>Del. hlače</th>";
            echo "<th>Del. hlače<br>(bele)</th>";
            echo "<th>Delavec</th>";
            echo "<th>Ruta ali <br>kapa (bela)</th>";
            echo "<th>Predpasnik<br>(beli)</th>";
            echo "<th>Zašč.<br>čevlji</th>";
            echo "<th>T-shirt<br>majica</th>";
            echo "<th>Polo<br>majica</th>";
            echo "<th>Predpasnik<br>(pisani)</th>";
            echo "<th>Tunika<br>(kratki rok.)</th>";
            echo "<th>Delavec</th>";
            echo "<th>Del. halja<br>(bela)</th>";
            echo "<th>Rokavice <br>za kislino</th>";
            echo "<th>Zašč.<br>očala</th>";
            echo "<th>Trenirka</th>";
            echo "<th>Tel.<br>copati</th>";
            echo "</tr>";
            $ColorChange=true;

            while ($R = mysqli_fetch_array($result)){
	            if ($ColorChange ){
		            echo "<tr bgcolor=lightyellow>";
	            }else{
		            echo "<tr bgcolor=#FFFFCC>";
	            }
	            $ColorChange=!$ColorChange;
                
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
                
	            echo "<td>".$Indx."</td>";
	            echo "<td><input name='ucitelj_".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</td>";
	            echo "<td>".$oUcitelj->getDelMesto()."&nbsp;</td>";
	            echo "<td align=center><input name='prevzemnica_".$Indx."' type='checkbox'></td>";
	            if (isset($R["DelHaljaM"]) && $R["DelHaljaM"]){
		            if (!isDate($R["DatDelHaljaM"])){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerDelHaljaM"])){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerDelHaljaM"];
			            }
                        $Datum=new DateTime(isDate($R["DatDelHaljaM"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='DelHaljaM_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatDelHaljaM_".$Indx."' type='text' value='".$R["DatDelHaljaM"]."' size='8'>";
                    echo "<input name='PerDelHaljaM_".$Indx."' type='text' value='".$R["PerDelHaljaM"]."' size='1'>";
	            }else{
		            echo "<td><input name='DelHaljaM_".$Indx."' type='checkbox'>";
                    echo "<input name='DatDelHaljaM_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerDelHaljaM_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["OrtCevlji"]) && ($R["OrtCevlji"]) ){
		            if (!isDate($R["DatOrtCevlji"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerOrtCevlji"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerOrtCevlji"];
			            }
                        $Datum=new DateTime(isDate($R["DatOrtCevlji"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='OrtCevlji_".$Indx."' type='checkbox' checked>";
	            }else{
		            echo "<td><input name='OrtCevlji_".$Indx."' type='checkbox'>";
	            }
	            echo "<input name='DatOrtCevlji_".$Indx."' type='text' value='".$R["DatOrtCevlji"]."' size='8'>";
	            echo "<input name='PerOrtCevlji_".$Indx."' type='text' value='".$R["PerOrtCevlji"]."' size='1'>";
	            echo "</td>";

	            if (isset($R["RokG"]) && $R["RokG"] ){
		            if (!isDate($R["DatRokG"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerRokG"]) ){
				            $PeriodaPV=0;
			            }else{
				            $PeriodaPV=$R["PerRokG"];
			            }
			            echo "<td>";
		            }
		            echo "<input name='RokG_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatRokG_".$Indx."' type='text' value='".$R["DatRokG"]."' size='8'>";
                    echo "<input name='PerRokG_".$Indx."' type='text' value='".$R["PerRokG"]."' size='1'>";
	            }else{
		            echo "<td><input name='RokG_".$Indx."' type='checkbox'>";
                    echo "<input name='DatRokG_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerRokG_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["DelCevlji"]) && $R["DelCevlji"] ){
		            if (!isDate($R["DatDelCevlji"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerDelCevlji"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerDelCevlji"];
			            }
                        $Datum=new DateTime(isDate($R["DatDelCevlji"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='DelCevlji_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatDelCevlji_".$Indx."' type='text' value='".$R["DatDelCevlji"]."' size='8'>";
                    echo "<input name='PerDelCevlji_".$Indx."' type='text' value='".$R["PerDelCevlji"]."' size='1'>";
	            }else{
		            echo "<td><input name='DelCevlji_".$Indx."' type='checkbox'>";
                    echo "<input name='DatDelCevlji_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerDelCevlji_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";

	            if (isset($R["SkornjiG"]) && $R["SkornjiG"]){
		            if (!isDate($R["DatSkornjiG"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerSkornjiG"]) ){
				            $PeriodaPV=36;
			            }else{
				            $PeriodaPV=$R["PerSkornjiG"];
			            }
                        $Datum=new DateTime(isDate($R["DatSkornjiG"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='SkornjiG_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatSkornjiG_".$Indx."' type='text' value='".$R["DatSkornjiG"]."' size='8'>";
                    echo "<input name='PerSkornjiG_".$Indx."' type='text' value='".$R["PerSkornjiG"]."' size='1'>";
	            }else{
		            echo "<td><input name='SkornjiG_".$Indx."' type='checkbox'>";
                    echo "<input name='DatSkornjiG_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerSkornjiG_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["RokU"]) && $R["RokU"]){
		            if (!isDate($R["DatRokU"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerRokU"]) ){
				            $PeriodaPV=0;
			            }else{
				            $PeriodaPV=$R["PerRokU"];
			            }
			            echo "<td>";
		            }
		            echo "<input name='RokU_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatRokU_".$Indx."' type='text' value='".$R["DatRokU"]."' size='8'>";
                    echo "<input name='PerRokU_".$Indx."' type='text' value='".$R["PerRokU"]."' size='1'>";
	            }else{
		            echo "<td><input name='RokU_".$Indx."' type='checkbox'>";
                    echo "<input name='DatRokU_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerRokU_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["DelHaljaHlB"] )&& $R["DelHaljaHlB"]){
		            if (!isDate($R["DatDelHaljaHlB"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerDelHaljaHlB"]) ){
				            $PeriodaPV=6;
			            }else{
				            $PeriodaPV=$R["PerDelHaljaHlB"];
			            }
                        $Datum=new DateTime(isDate($R["DatDelHaljaHlB"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='DelHaljaHlB_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatDelHaljaHlB_".$Indx."' type='text' value='".$R["DatDelHaljaHlB"]."' size='8'>";
                    echo "<input name='PerDelHaljaHlB_".$Indx."' type='text' value='".$R["PerDelHaljaHlB"]."' size='1'>";
	            }else{
		            echo "<td><input name='DelHaljaHlB_".$Indx."' type='checkbox'>";
                    echo "<input name='DatDelHaljaHlB_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerDelHaljaHlB_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["HlaceB"]) && $R["HlaceB"]){
		            if (!isDate($R["DatHlaceB"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerHlaceB"]) ){
				            $PeriodaPV=6;
			            }else{
				            $PeriodaPV=$R["PerHlaceB"];
			            }
                        $Datum=new DateTime(isDate($R["DatHlaceB"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='HlaceB_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatHlaceB_".$Indx."' type='text' value='".$R["DatHlaceB"]."' size='8'>";
                    echo "<input name='PerHlaceB_".$Indx."' type='text' value='".$R["PerHlaceB"]."' size='1'>";
	            }else{
		            echo "<td><input name='HlaceB_".$Indx."' type='checkbox'>";
                    echo "<input name='DatHlaceB_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerHlaceB_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            echo "<td>".$R["Priimek"].", ".$R["Ime"]."</td>";
	            
	            if (isset($R["KapaB"]) && $R["KapaB"]){
		            if (!isDate($R["DatKapaB"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerKapaB"]) ){
				            $PeriodaPV=6;
			            }else{
				            $PeriodaPV=$R["PerKapaB"];
			            }
                        $Datum=new DateTime(isDate($R["DatKapaB"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='KapaB_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatKapaB_".$Indx."' type='text' value='".$R["DatKapaB"]."' size='8'>";
                    echo "<input name='PerKapaB_".$Indx."' type='text' value='".$R["PerKapaB"]."' size='1'>";
	            }else{
		            echo "<td><input name='KapaB_".$Indx."' type='checkbox'>";
                    echo "<input name='DatKapaB_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerKapaB_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["PredpB"])&& $R["PredpB"] ){
		            if (!isDate($R["DatPredpB"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerPredpB"]) ){
				            $PeriodaPV=6;
			            }else{
				            $PeriodaPV=$R["PerPredpB"];
			            }
                        $Datum=new DateTime(isDate($R["DatPredpB"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='PredpB_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatPredpB_".$Indx."' type='text' value='".$R["DatPredpB"]."' size='8'>";
                    echo "<input name='PerPredpB_".$Indx."' type='text' value='".$R["PerPredpB"]."' size='1'>";
	            }else{
		            echo "<td><input name='PredpB_".$Indx."' type='checkbox'>";
                    echo "<input name='DatPredpB_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerPredpB_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["Cevlji"]) && $R["Cevlji"]){
		            if (!isDate($R["DatCevlji"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerCevlji"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerCevlji"];
			            }
                        $Datum=new DateTime(isDate($R["DatCevlji"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='Cevlji_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatCevlji_".$Indx."' type='text' value='".$R["DatCevlji"]."' size='8'>";
                    echo "<input name='PerCevlji_".$Indx."' type='text' value='".$R["PerCevlji"]."' size='1'>";
	            }else{
		            echo "<td><input name='Cevlji_".$Indx."' type='checkbox'>";
                    echo "<input name='DatCevlji_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerCevlji_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["TShirt"])&& $R["TShirt"] ){
		            if (!isDate($R["DatTShirt"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerTShirt"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerTShirt"];
			            }
                        $Datum=new DateTime(isDate($R["DatTShirt"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='TShirt_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatTShirt_".$Indx."' type='text' value='".$R["DatTShirt"]."' size='8'>";
                    echo "<input name='PerTShirt_".$Indx."' type='text' value='".$R["PerTShirt"]."' size='1'>";
	            }else{
		            echo "<td><input name='TShirt_".$Indx."' type='checkbox'>";
                    echo "<input name='DatTShirt_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerTShirt_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["PoloMajica"]) && $R["PoloMajica"]){
		            if (!isDate($R["DatPoloMajica"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerPoloMajica"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerPoloMajica"];
			            }
                        $Datum=new DateTime(isDate($R["DatPoloMajica"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='PoloMajica_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatPoloMajica_".$Indx."' type='text' value='".$R["DatPoloMajica"]."' size='8'>";
                    echo "<input name='PerPoloMajica_".$Indx."' type='text' value='".$R["PerPoloMajica"]."' size='1'>";
	            }else{
		            echo "<td><input name='PoloMajica_".$Indx."' type='checkbox'>";
                    echo "<input name='DatPoloMajica_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerPoloMajica_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["PredpPis"])&& $R["PredpPis"] ){
		            if (!isDate($R["DatPredpPis"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerPredpPis"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerPredpPis"];
			            }
                        $Datum=new DateTime(isDate($R["DatPredpPis"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='PredpPis_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatPredpPis_".$Indx."' type='text' value='".$R["DatPredpPis"]."' size='8'>";
                    echo "<input name='PerPredpPis_".$Indx."' type='text' value='".$R["PerPredpPis"]."' size='1'>";
	            }else{
		            echo "<td><input name='PredpPis_".$Indx."' type='checkbox'>";
                    echo "<input name='DatPredpPis_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerPredpPis_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["Tunika"])&& $R["Tunika"] ){
		            if (!isDate($R["DatTunika"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerTunika"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerTunika"];
			            }
                        $Datum=new DateTime(isDate($R["DatTunika"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='Tunika_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatTunika_".$Indx."' type='text' value='".$R["DatTunika"]."' size='8'>";
                    echo "<input name='PerTunika_".$Indx."' type='text' value='".$R["PerTunika"]."' size='1'>";
	            }else{
		            echo "<td><input name='Tunika_".$Indx."' type='checkbox'>";
                    echo "<input name='DatTunika_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerTunika_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";

	            echo "<td>".$R["Priimek"].", ".$R["Ime"]."</td>";
	            
	            if (isset($R["DelHaljaB"]) && $R["DelHaljaB"]){
		            if (!isDate($R["DatDelHaljaB"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerDelHaljaB"]) ){
				            $PeriodaPV=36;
			            }else{
				            $PeriodaPV=$R["PerDelHaljaB"];
			            }
                        $Datum=new DateTime(isDate($R["DatDelHaljaB"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='DelHaljaB_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatDelHaljaB_".$Indx."' type='text' value='".$R["DatDelHaljaB"]."' size='8'>";
                    echo "<input name='PerDelHaljaB_".$Indx."' type='text' value='".$R["PerDelHaljaB"]."' size='1'>";
	            }else{
		            echo "<td><input name='DelHaljaB_".$Indx."' type='checkbox'>";
                    echo "<input name='DatDelHaljaB_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerDelHaljaB_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["RokaviceK"])&& $R["RokaviceK"]){
		            if (!isDate($R["DatRokaviceK"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerRokaviceK"]) ){
				            $PeriodaPV=60;
			            }else{
				            $PeriodaPV=$R["PerRokaviceK"];
			            }
                        $Datum=new DateTime(isDate($R["DatRokaviceK"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='RokaviceK_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatRokaviceK_".$Indx."' type='text' value='".$R["DatRokaviceK"]."' size='8'>";
                    echo "<input name='PerRokaviceK_".$Indx."' type='text' value='".$R["PerRokaviceK"]."' size='1'>";
	            }else{
		            echo "<td><input name='RokaviceK_".$Indx."' type='checkbox'>";
                    echo "<input name='DatRokaviceK_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerRokaviceK_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["Ocala"])&& $R["Ocala"]){
		            if (!isDate($R["DatOcala"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!isNumeric($R["PerOcala"]) ){
				            $PeriodaPV=12;
			            }else{
				            $PeriodaPV=$R["PerOcala"];
			            }
                        $Datum=new DateTime(isDate($R["DatOcala"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='Ocala_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatOcala_".$Indx."' type='text' value='".$R["DatOcala"]."' size='8'>";
                    echo "<input name='PerOcala_".$Indx."' type='text' value='".$R["PerOcala"]."' size='1'>";
	            }else{
		            echo "<td><input name='Ocala_".$Indx."' type='checkbox'>";
                    echo "<input name='DatOcala_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerOcala_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["Trenirka"])&& $R["Trenirka"]){
		            if (!isDate($R["DatTrenirka"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerTrenirka"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerTrenirka"];
			            }
                        $Datum=new DateTime(isDate($R["DatTrenirka"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='Trenirka_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatTrenirka_".$Indx."' type='text' value='".$R["DatTrenirka"]."' size='8'>";
                    echo "<input name='PerTrenirka_".$Indx."' type='text' value='".$R["PerTrenirka"]."' size='1'>";
	            }else{
		            echo "<td><input name='Trenirka_".$Indx."' type='checkbox'>";
                    echo "<input name='DatTrenirka_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerTrenirka_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            if (isset($R["Superge"])&& $R["Superge"] ){
		            if (!isDate($R["DatSuperge"]) ){
			            echo "<td bgcolor=lightsalmon>";
		            }else{
			            if (!is_numeric($R["PerSuperge"]) ){
				            $PeriodaPV=24;
			            }else{
				            $PeriodaPV=$R["PerSuperge"];
			            }
                        $Datum=new DateTime(isDate($R["DatSuperge"]));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                            echo "<td bgcolor='lightsalmon'>";
                        }else{
                            echo "<td>";
                        }
		            }
		            echo "<input name='Superge_".$Indx."' type='checkbox' checked>";
                    echo "<input name='DatSuperge_".$Indx."' type='text' value='".$R["DatSuperge"]."' size='8'>";
                    echo "<input name='PerSuperge_".$Indx."' type='text' value='".$R["PerSuperge"]."' size='1'>";
	            }else{
		            echo "<td><input name='Superge_".$Indx."' type='checkbox'>";
                    echo "<input name='DatSuperge_".$Indx."' type='text' value='' size='8'>";
                    echo "<input name='PerSuperge_".$Indx."' type='text' value='' size='1'>";
	            }
	            echo "</td>";
	            
	            echo "</tr>";
                $oUcitelj=null;
                if ($Indx % 10 == 0){
                    echo "<tr bgcolor=lightcyan><th>Št.</th><th>Delavec</th>";
                    echo "<th>Naziv del. mesta</th>";
                    echo "<th>Prevzemnica</th>";
                    echo "<th>Del. halja</th>";
                    echo "<th>Ortopedski<br>čevlji</th>";
                    echo "<th>Gumi rokavice</th>";
                    echo "<th>Delovni<br>čevlji</th>";
                    echo "<th>Gumi<br>škornji</th>";
                    echo "<th>Zašč. usnjene<br>rokavice</th>";
                    echo "<th>Del. hlače</th>";
                    echo "<th>Del. hlače<br>(bele)</th>";
                    echo "<th>Delavec</th>";
                    echo "<th>Ruta ali <br>kapa (bela)</th>";
                    echo "<th>Predpasnik<br>(beli)</th>";
                    echo "<th>Zašč.<br>čevlji</th>";
                    echo "<th>T-shirt<br>majica</th>";
                    echo "<th>Polo<br>majica</th>";
                    echo "<th>Predpasnik<br>(pisani)</th>";
                    echo "<th>Tunika<br>(kratki rok.)</th>";
                    echo "<th>Delavec</th>";
                    echo "<th>Del. halja<br>(bela)</th>";
                    echo "<th>Rokavice <br>za kislino</th>";
                    echo "<th>Zašč.<br>očala</th>";
                    echo "<th>Trenirka</th>";
                    echo "<th>Tel.<br>copati</th>";
                    echo "</tr>";
                }
                $Indx=$Indx+1;
            }
            echo "</table>";
            echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<input name='submit' type='submit' value='Prevzemnice'>";
            echo "</form>";
        }else{
            //izpis na drug način (1) - OŠ Bežigrad
            switch($Vid){
                case "1":
            //vpiše spremembe
                        for ($Indx=1;$Indx <= intval($_POST["StZapisov"]);$Indx++){
                            $SQL = "SELECT * FROM TabZascSr WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE TabZascSr SET ";

                                if (isset($_POST["PerDelHaljaM_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaM_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if ($PeriodaPV==""){
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["DelHaljaM_".$Indx])){
                                        $SQL = $SQL . "DelHaljaM=true,";
                                    }else{
                                        $SQL = $SQL . "DelHaljaM=false,";
                                    }
                                    $SQL = $SQL . "DatDelHaljaM='".$_POST["DatDelHaljaM_".$Indx]."',";
                                    $SQL = $SQL . "PerDelHaljaM=".$PeriodaPV.",";
                                }
                                if (isset($_POST["PerOrtCevlji_".$Indx])){
                                    $PeriodaPV=$_POST["PerOrtCevlji_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["OrtCevlji_".$Indx])){
                                        $SQL = $SQL . "OrtCevlji=true,";
                                    }else{
                                        $SQL = $SQL . "OrtCevlji=false,";
                                    }
                                    $SQL = $SQL . "DatOrtCevlji='".$_POST["DatOrtCevlji_".$Indx]."',";
                                    $SQL = $SQL . "PerOrtCevlji=".$PeriodaPV.",";
                                }
                                if (isset($_POST["PerRokG_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokG_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["RokG_".$Indx])){
                                        $SQL = $SQL . "RokG=true,";
                                    }else{
                                        $SQL = $SQL . "RokG=false,";
                                    }
                                    $SQL = $SQL . "DatRokG='".$_POST["DatRokG_".$Indx]."',";
                                    $SQL = $SQL . "PerRokG=".$PeriodaPV.",";
                                }
                                if (isset($_POST["PerDelCevlji_".$Indx])){                                
                                    $PeriodaPV=$_POST["PerDelCevlji_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["DelCevlji_".$Indx])){
                                        $SQL = $SQL . "DelCevlji=true,";
                                    }else{
                                        $SQL = $SQL . "DelCevlji=false,";
                                    }
                                    $SQL = $SQL . "DatDelCevlji='".$_POST["DatDelCevlji_".$Indx]."',";
                                    $SQL = $SQL . "PerDelCevlji=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerSkornjiG_".$Indx])){
                                    $PeriodaPV=$_POST["PerSkornjiG_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["SkornjiG_".$Indx])){
                                        $SQL = $SQL . "SkornjiG=true,";
                                    }else{
                                        $SQL = $SQL . "SkornjiG=false,";
                                    }
                                    $SQL = $SQL . "DatSkornjiG='".$_POST["DatSkornjiG_".$Indx]."',";
                                    $SQL = $SQL . "PerSkornjiG=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerRokU_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokU_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["RokU_".$Indx])){
                                        $SQL = $SQL . "RokU=true,";
                                    }else{
                                        $SQL = $SQL . "RokU=false,";
                                    }
                                    $SQL = $SQL . "DatRokU='".$_POST["DatRokU_".$Indx]."',";
                                    $SQL = $SQL . "PerRokU=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerDelHaljaHlB_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaHlB_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["DelHaljaHlB_".$Indx])){
                                        $SQL = $SQL . "DelHaljaHlB=true,";
                                    }else{
                                        $SQL = $SQL . "DelHaljaHlB=false,";
                                    }
                                    $SQL = $SQL . "DatDelHaljaHlB='".$_POST["DatDelHaljaHlB_".$Indx]."',";
                                    $SQL = $SQL . "PerDelHaljaHlB=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerKapaB_".$Indx])){
                                    $PeriodaPV=$_POST["PerKapaB_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["KapaB_".$Indx])){
                                        $SQL = $SQL . "KapaB=true,";
                                    }else{
                                        $SQL = $SQL . "KapaB=false,";
                                    }
                                    $SQL = $SQL . "DatKapaB='".$_POST["DatKapaB_".$Indx]."',";
                                    $SQL = $SQL . "PerKapaB=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerPredpB_".$Indx])){
                                    $PeriodaPV=$_POST["PerPredpB_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["PredpB_".$Indx])){
                                        $SQL = $SQL . "PredpB=true,";
                                    }else{
                                        $SQL = $SQL . "PredpB=false,";
                                    }
                                    $SQL = $SQL . "DatPredpB='".$_POST["DatPredpB_".$Indx]."',";
                                    $SQL = $SQL . "PerPredpB=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerCevlji_".$Indx])){
                                    $PeriodaPV=$_POST["PerCevlji_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["Cevlji_".$Indx])){
                                        $SQL = $SQL . "Cevlji=true,";
                                    }else{
                                        $SQL = $SQL . "Cevlji=false,";
                                    }
                                    $SQL = $SQL . "DatCevlji='".$_POST["DatCevlji_".$Indx]."',";
                                    $SQL = $SQL . "PerCevlji=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerDelHaljaB_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaB_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["DelHaljaB_".$Indx])){
                                        $SQL = $SQL . "DelHaljaB=true,";
                                    }else{
                                        $SQL = $SQL . "DelHaljaB=false,";
                                    }
                                    $SQL = $SQL . "DatDelHaljaB='".$_POST["DatDelHaljaB_".$Indx]."',";
                                    $SQL = $SQL . "PerDelHaljaB=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerRokaviceK_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokaviceK_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["RokaviceK_".$Indx])){
                                        $SQL = $SQL . "RokaviceK=true,";
                                    }else{
                                        $SQL = $SQL . "RokaviceK=false,";
                                    }
                                    $SQL = $SQL . "DatRokaviceK='".$_POST["DatRokaviceK_".$Indx]."',";
                                    $SQL = $SQL . "PerRokaviceK=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerOcala_".$Indx])){
                                    $PeriodaPV=$_POST["PerOcala_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["Ocala_".$Indx])){
                                        $SQL = $SQL . "Ocala=true,";
                                    }else{
                                        $SQL = $SQL . "Ocala=false,";
                                    }
                                    $SQL = $SQL . "DatOcala='".$_POST["DatOcala_".$Indx]."',";
                                    $SQL = $SQL . "PerOcala=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerTrenirka_".$Indx])){
                                    $PeriodaPV=$_POST["PerTrenirka_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["Trenirka_".$Indx])){
                                        $SQL = $SQL . "Trenirka=true,";
                                    }else{
                                        $SQL = $SQL . "Trenirka=false,";
                                    }
                                    $SQL = $SQL . "DatTrenirka='".$_POST["DatTrenirka_".$Indx]."',";
                                    $SQL = $SQL . "PerTrenirka=".$PeriodaPV.",";
                                }
                                
                                if (isset($_POST["PerSuperge_".$Indx])){
                                    $PeriodaPV=$_POST["PerSuperge_".$Indx];
                                    if (!is_numeric($PeriodaPV)){
                                        $PeriodaPV=0;
                                    }
                                    if (strlen($PeriodaPV)==0){ 
                                        $PeriodaPV=0;
                                    }
                                    if (isset($_POST["Superge_".$Indx])){
                                        $SQL = $SQL . "Superge=true,";
                                    }else{
                                        $SQL = $SQL . "Superge=false,";
                                    }
                                    $SQL = $SQL . "DatSuperge='".$_POST["DatSuperge_".$Indx]."',";
                                    $SQL = $SQL . "PerSuperge=".$PeriodaPV.",";
                                }
                                
                                $SQL = $SQL . " iducitelj=".$_POST["ucitelj_".$Indx]." WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
                            }else{
                                $SQL = "INSERT INTO TabZascSr (idUcitelj,";
                                $SQL = $SQL . "DelHaljaM,DatDelHaljaM,PerDelHaljaM,";
                                $SQL = $SQL . "OrtCevlji,DatOrtCevlji,PerOrtCevlji,";
                                $SQL = $SQL . "RokG,DatRokG,PerRokG,";
                                $SQL = $SQL . "DelCevlji,DatDelCevlji,PerDelCevlji,";
                                $SQL = $SQL . "SkornjiG,DatSkornjiG,PerSkornjiG,";
                                $SQL = $SQL . "RokU,DatRokU,PerRokU,";
                                $SQL = $SQL . "DelHaljaHlB,DatDelHaljaHlB,PerDelHaljaHlB,";
                                $SQL = $SQL . "KapaB,DatKapaB,PerKapaB,";
                                $SQL = $SQL . "PredpB,DatPredpB,PerPredpB,";
                                $SQL = $SQL . "Cevlji,DatCevlji,PerCevlji,";
                                $SQL = $SQL . "DelHaljaB,DatDelHaljaB,PerDelHaljaB,";
                                $SQL = $SQL . "RokaviceK,DatRokaviceK,PerRokaviceK,";
                                $SQL = $SQL . "Ocala,DatOcala,PerOcala,";
                                $SQL = $SQL . "Trenirka,DatTrenirka,PerTrenirka,";
                                $SQL = $SQL . "Superge,DatSuperge,PerSuperge";
                                $SQL = $SQL . ") VALUES (".$_POST["ucitelj_".$Indx].",";

                                if (isset($_POST["PerDelHaljaM_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaM_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["DelHaljaM_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatDelHaljaM_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatDelHaljaM_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerOrtCevlji_".$Indx])){
                                    $PeriodaPV=$_POST["PerOrtCevlji_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["OrtCevlji_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatOrtCevlji_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatOrtCevlji_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerRokG_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokG_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["RokG_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatRokG_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatRokG_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerDelCevlji_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelCevlji_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["DelCevlji_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatDelCevlji_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatDelCevlji_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerSkornjiG_".$Indx])){
                                    $PeriodaPV=$_POST["PerSkornjiG_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["SkornjiG_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatSkornjiG_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatSkornjiG_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerRokU_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokU_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["RokU_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatRokU_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatRokU_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerDelHaljaHlB_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaHlB_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["DelHaljaHlB_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatDelHaljaHlB_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatDelHaljaHlB_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerKapaB_".$Indx])){
                                    $PeriodaPV=$_POST["PerKapaB_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["KapaB_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatKapaB_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatKapaB_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerPredpB_".$Indx])){
                                    $PeriodaPV=$_POST["PerPredpB_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["PredpB_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatPredpB_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatPredpB_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerCevlji_".$Indx])){
                                    $PeriodaPV=$_POST["PerCevlji_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["Cevlji_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatCevlji_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatCevlji_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerDelHaljaB_".$Indx])){
                                    $PeriodaPV=$_POST["PerDelHaljaB_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["DelHaljaB_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatDelHaljaB_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatDelHaljaB_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerRokaviceK_".$Indx])){
                                    $PeriodaPV=$_POST["PerRokaviceK_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["RokaviceK_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatRokaviceK_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatRokaviceK_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerOcala_".$Indx])){
                                    $PeriodaPV=$_POST["PerOcala_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["Ocala_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatOcala_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatOcala_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerTrenirka_".$Indx])){
                                    $PeriodaPV=$_POST["PerTrenirka_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["Trenirka_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatTrenirka_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatTrenirka_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV.",";
                                
                                if (isset($_POST["PerSuperge_".$Indx])){
                                    $PeriodaPV=$_POST["PerSuperge_".$Indx];
                                }else{
                                    $PeriodaPV="";
                                }
                                if (!is_numeric($PeriodaPV)){
                                    $PeriodaPV=0;
                                }
                                if (strlen($PeriodaPV)==0){ 
                                    $PeriodaPV=0;
                                }
                                if (isset($_POST["Superge_".$Indx])){
                                    $SQL = $SQL . "true,";
                                }else{
                                    $SQL = $SQL . "false,";
                                }
                                if (isset($_POST["DatSuperge_".$Indx])){
                                    $SQL = $SQL . "'".$_POST["DatSuperge_".$Indx]."',";
                                }else{
                                    $SQL = $SQL . "'',";
                                }
                                $SQL = $SQL . $PeriodaPV;
                                
                                $SQL = $SQL . ")";
                            }
            //'                    echo $SQL."<br>"
                            $result = mysqli_query($link,$SQL);
                        }
            }
            //izpis zaščitnih sredstev
            $SQL = "SELECT tabucitelji.iducitelj,TabZascSr.* FROM ";
            $SQL = $SQL . "(TabUcitelji INNER JOIN TabStatus ON TabUcitelji.Status=TabStatus.IdStatus) ";
            $SQL = $SQL . "LEFT JOIN TabZascSr ON TabUcitelji.idUcitelj=TabZascSr.idUcitelj ";
            $SQL = $SQL . "WHERE TabUcitelji.Status > 0 ";
            $SQL = $SQL . "ORDER BY TabUcitelji.Priimek, TabUcitelji.Ime";
            //echo "<br>" . $SQL . "<br>"
            $result = mysqli_query($link,$SQL);

            $Indx=1;

            echo "<h2>Pregled zaščitnih sredstev</h2>";
            echo "Pri zaščitnih sredstvih se da kljukico pri zaščitnem sredstvu, ki ga delavec uporablja. V naslednjem oknu se vpiše datum prevzema in v zraven še na koliko časa (v mesecih) delavcu pripada novo zašč. sredstvo.<br />Če rok poteče, je polje obarvano rdeče.";
            echo "<form name='form_ZascSr' method=post action='ZascOprema.php'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<input name='submit' type='submit' value='Prevzemnice'><br />";

            while ($R = mysqli_fetch_array($result)){
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSe($R["iducitelj"],$VLetoPregled,$VLeto);
                $napis=$oUcitelj->getSistemizacijaU();
                if (Vsebuje(6,$oUcitelj->getSistemizacijaU()) or Vsebuje(7,$oUcitelj->getSistemizacijaU()) or Vsebuje(8,$oUcitelj->getSistemizacijaU()) or Vsebuje(9,$oUcitelj->getSistemizacijaU()) or Vsebuje(10,$oUcitelj->getSistemizacijaU()) or Vsebuje(14,$oUcitelj->getSistemizacijaU()) or Vsebuje(27,$oUcitelj->getSistemizacijaU()) or Vsebuje(47,$oUcitelj->getSistemizacijaU()) or Vsebuje(31,$oUcitelj->getSistemizacijaU()) or Vsebuje(32,$oUcitelj->getSistemizacijaU())){
                    echo "<br /><input name='prevzemnica_".$Indx."' type='checkbox'>";
                    echo "<b><input name='ucitelj_".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()."</b>, ";
                    //'echo $R["NazivDelMesta")."</br>"

                    echo "<table border=1 cellspacing=0>";
                        //'hišnik
                    if (Vsebuje(6,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Del. halja<br />(modra)</th>";
                            echo "<th>Delovni<br />čevlji</th>";
                            echo "<th>Gumi<br />škornji</th>";
                            echo "<th>Zašč. usnjene<br />rokavice</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerDelHaljaM"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaM"];
                            }
                            if (!isDate($R["DatDelHaljaM"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaM"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaM_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaM_".$Indx."' type='text' value='".$R["DatDelHaljaM"]."' size='8'>";
                        echo "<input name='PerDelHaljaM_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerDelCevlji"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerDelCevlji"];
                            }
                            if (!isDate($R["DatDelCevlji"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelCevlji"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelCevlji_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelCevlji_".$Indx."' type='text' value='".$R["DatDelCevlji"]."' size='8'>";
                        echo "<input name='PerDelCevlji_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";

                            if (!is_numeric($R["PerSkornjiG"])){
                                $PeriodaPV=36;
                            }else{
                                $PeriodaPV=$R["PerSkornjiG"];
                            }
                            if (!isDate($R["DatSkornjiG"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatSkornjiG"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='SkornjiG_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatSkornjiG_".$Indx."' type='text' value='".$R["DatSkornjiG"]."' size='8'>";
                        echo "<input name='PerSkornjiG_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerRokU"])){
                                $PeriodaPV=0;
                            }else{
                                $PeriodaPV=$R["PerRokU"];
                            }
                        if (!isDate($R["DatRokU"])){
                                echo "<td bgcolor=lightsalmon>";
        //'                    }else{
        //'                    if DateDiff("d",$R["PerRokU"),day(now).".".month(now).".".year(now)) > $PeriodaPV*30){
        //'                    echo "<td bgcolor=lightsalmon>"
                        }else{
                                    echo "<td>";
        //'                }
                        }
                            echo "<input name='RokU_".$Indx."' type='checkbox' checked>";
                        echo "<input name='DatRokU_".$Indx."' type='text' value='".$R["DatRokU"]."' size='8'>";
                        echo "<input name='PerRokU_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    
                        //'čistilka
                    if (Vsebuje(7,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Del. halja<br />(modra)</th>";
                            echo "<th>Ortopedski<br />čevlji</th>";
                            echo "<th>Gumi rokavice</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerDelHaljaM"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaM"];
                            }
                            if (!isDate($R["DatDelHaljaM"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaM"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaM_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaM_".$Indx."' type='text' value='".$R["DatDelHaljaM"]."' size='8'>";
                        echo "<input name='PerDelHaljaM_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerOrtCevlji"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerOrtCevlji"];
                            }
                            if (!isDate($R["DatOrtCevlji"])){
                                echo "<td bgcolor=lightsalmon>";
        //'                echo "Ni datum!<br />"
                            }else{
                                $Datum=new DateTime(isDate($R["DatOrtCevlji"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='OrtCevlji_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatOrtCevlji_".$Indx."' type='text' value='".$R["DatOrtCevlji"]."' size='8'>";
                        echo "<input name='PerOrtCevlji_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";

                            if (!is_numeric($R["PerRokG"])){
                                $PeriodaPV=0;
                            }else{
                                $PeriodaPV=$R["PerRokG"];
                            }
                            if (!isDate($R["DatRokG"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
        //'                if DateDiff("d",$R["PerRokG"),day(now).".".month(now).".".year(now)) > $PeriodaPV*30){
        //'                    echo "<td bgcolor=lightsalmon>"
        //'                }else{
                                    echo "<td>";
        //'                }
                            }
                            echo "<input name='RokG_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatRokG_".$Indx."' type='text' value='".$R["DatRokG"]."' size='8'>";
                        echo "<input name='PerRokG_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    
                        //'kuharji in pomočniki
                    if (Vsebuje(8,$oUcitelj->getSistemizacijaU()) or Vsebuje(9,$oUcitelj->getSistemizacijaU()) or Vsebuje(10,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Ortopedski<br />čevlji</th>";
                            echo "<th>Gumi rokavice</th>";
                            echo "<th>Del. halja in<br />hlače (bela)</th>";
                            echo "<th>Ruta ali <br />kapa (bela)</th>";
                            echo "<th>Predpasnik<br />(beli)</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerOrtCevlji"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerOrtCevlji"];
                            }
                            if (!isDate($R["DatOrtCevlji"])){
                                echo "<td bgcolor=lightsalmon>";
        //'                echo "Ni datum!<br />"
                            }else{
                                $Datum=new DateTime(isDate($R["DatOrtCevlji"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='OrtCevlji_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatOrtCevlji_".$Indx."' type='text' value='".$R["DatOrtCevlji"]."' size='8'>";
                        echo "<input name='PerOrtCevlji_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";

                            if (!is_numeric($R["PerRokG"])){
                                $PeriodaPV=0;
                            }else{
                                $PeriodaPV=$R["PerRokG"];
                            }
                            if (!isDate($R["DatRokG"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
        //'                if DateDiff("d",$R["PerRokG"),day(now).".".month(now).".".year(now)) > $PeriodaPV*30){
        //'                    echo "<td bgcolor=lightsalmon>"
        //'                }else{
                                    echo "<td>";
        //'                }
                            }
                            echo "<input name='RokG_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatRokG_".$Indx."' type='text' value='".$R["DatRokG"]."' size='8'>";
                        echo "<input name='PerRokG_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerDelHaljaHlB"])){
                                $PeriodaPV=6;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaHlB"];
                            }
                            if (!isDate($R["DatDelHaljaHlB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaHlB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaHlB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaHlB_".$Indx."' type='text' value='".$R["DatDelHaljaHlB"]."' size='8'>";
                        echo "<input name='PerDelHaljaHlB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerKapaB"])){
                                $PeriodaPV=6;
                            }else{
                                $PeriodaPV=$R["PerKapaB"];
                            }
                            if (!isDate($R["DatKapaB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatKapaB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='KapaB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatKapaB_".$Indx."' type='text' value='".$R["DatKapaB"]."' size='8'>";
                        echo "<input name='PerKapaB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerPredpB"])){
                                $PeriodaPV=6;
                            }else{
                                $PeriodaPV=$R["PerPredpB"];
                            }
                            if (!isDate($R["DatPredpB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatPredpB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='PredpB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatPredpB_".$Indx."' type='text' value='".$R["DatPredpB"]."' size='8'>";
                        echo "<input name='PerPredpB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                        //'vodja prehrane
                    if (Vsebuje(14,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Del. halja in<br />hlače (bela)</th>";
                            echo "<th>Ruta ali <br />kapa (bela)</th>";
                            echo "<th>Zašč.<br />čevlji</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerDelHaljaHlB"])){
                                $PeriodaPV=6;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaHlB"];
                            }
                            if (!isDate($R["DatDelHaljaHlB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaHlB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaHlB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaHlB_".$Indx."' type='text' value='".$R["DatDelHaljaHlB"]."' size='8'>";
                        echo "<input name='PerDelHaljaHlB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerKapaB"])){
                                $PeriodaPV=6;
                            }else{
                                $PeriodaPV=$R["PerKapaB"];
                            }
                            if (!isDate($R["DatKapaB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatKapaB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='KapaB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatKapaB_".$Indx."' type='text' value='".$R["DatKapaB"]."' size='8'>";
                        echo "<input name='PerKapaB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerCevlji"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerCevlji"];
                            }
                            if (!isDate($R["DatCevlji"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatCevlji"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='Cevlji_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatCevlji_".$Indx."' type='text' value='".$R["DatCevlji"]."' size='8'>";
                        echo "<input name='PerCevlji_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                        //'kemija
                    if (Vsebuje(27,$oUcitelj->getSistemizacijaU()) or Vsebuje(47,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Gumi rokavice</th>";
                            echo "<th>Del. halja<br />(bela)</th>";
                            echo "<th>Rokavice <br />za kislino</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerRokG"])){
                                $PeriodaPV=0;
                            }else{
                                $PeriodaPV=$R["PerRokG"];
                            }
                            if (!isDate($R["DatRokG"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
        //'                if DateDiff("d",$R["PerRokG"),day(now).".".month(now).".".year(now)) > $PeriodaPV*30){
        //'                    echo "<td bgcolor=lightsalmon>"
        //'                }else{
                                    echo "<td>";
        //'                }
                            }
                            echo "<input name='RokG_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatRokG_".$Indx."' type='text' value='".$R["DatRokG"]."' size='8'>";
                        echo "<input name='PerRokG_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerDelHaljaB"])){
                                $PeriodaPV=36;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaB"];
                            }
                            if (!isDate($R["DatDelHaljaB"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaB"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaB_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaB_".$Indx."' type='text' value='".$R["DatDelHaljaB"]."' size='8'>";
                        echo "<input name='PerDelHaljaB_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerRokaviceK"])){
                                $PeriodaPV=60;
                            }else{
                                $PeriodaPV=$R["PerRokaviceK"];
                            }
                            if (!isDate($R["DatRokaviceK"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatRokaviceK"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='RokaviceK_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatRokaviceK_".$Indx."' type='text' value='".$R["DatRokaviceK"]."' size='8'>";
                        echo "<input name='PerRokaviceK_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                        //'tehnika
                    if (Vsebuje(31,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Del. halja<br />(modra)</th>";
                            echo "<th>Zašč. usnjene<br />rokavice</th>";
                            echo "<th>Zašč.<br />očala</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerDelHaljaM"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerDelHaljaM"];
                            }
                            if (!isDate($R["DatDelHaljaM"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatDelHaljaM"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='DelHaljaM_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatDelHaljaM_".$Indx."' type='text' value='".$R["DatDelHaljaM"]."' size='8'>";
                        echo "<input name='PerDelHaljaM_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerRokU"])){
                                $PeriodaPV=0;
                            }else{
                                $PeriodaPV=$R["PerRokU"];
                            }
                            if (!isDate($R["DatRokU"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
        //'                if DateDiff("d",$R["PerRokU"),day(now).".".month(now).".".year(now)) > $PeriodaPV*30){
        //'                    echo "<td bgcolor=lightsalmon>"
        //'                }else{
                                    echo "<td>";
        //'                }
                            }
                            echo "<input name='RokU_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatRokU_".$Indx."' type='text' value='".$R["DatRokU"]."' size='8'>";
                        echo "<input name='PerRokU_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerOcala"])){
                                $PeriodaPV=12;
                            }else{
                                $PeriodaPV=$R["PerOcala"];
                            }
                            if (!isDate($R["DatOcala"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatOcala"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='Ocala_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatOcala_".$Indx."' type='text' value='".$R["DatOcala"]."' size='8'>";
                        echo "<input name='PerOcala_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }
                        //'ŠVZ
                    if (Vsebuje(32,$oUcitelj->getSistemizacijaU())){
                            echo "<tr>";
                            echo "<th>Trenirka</th>";
                            echo "<th>Tel.<br />copati</th>";
                            echo "</tr>";
                            echo "<tr>";
                            if (!is_numeric($R["PerTrenirka"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerTrenirka"];
                            }
                            if (!isDate($R["DatTrenirka"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatTrenirka"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='Trenirka_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatTrenirka_".$Indx."' type='text' value='".$R["DatTrenirka"]."' size='8'>";
                        echo "<input name='PerTrenirka_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        
                            if (!is_numeric($R["PerSuperge"])){
                                $PeriodaPV=24;
                            }else{
                                $PeriodaPV=$R["PerSuperge"];
                            }
                            if (!isDate($R["DatSuperge"])){
                                echo "<td bgcolor=lightsalmon>";
                            }else{
                                $Datum=new DateTime(isDate($R["DatSuperge"]));
                                $Interval=$Datum->diff($Danes);
                                if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*30)){
                                    echo "<td bgcolor=lightsalmon>";
                                }else{
                                    echo "<td>";
                                }
                            }
                            echo "<input name='Superge_".$Indx."' type='checkbox' checked='checked'>";
                        echo "<input name='DatSuperge_".$Indx."' type='text' value='".$R["DatSuperge"]."' size='8'>";
                        echo "<input name='PerSuperge_".$Indx."' type='text' value='".$PeriodaPV."' size='1'>";
                        echo "</td>";
                        echo "</tr>";
                    }    
                    echo "</table>";
                    
                    $Indx=$Indx+1;
                }
            }
            echo "</table>";
            echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "<input name='submit' type='submit' value='Prevzemnice'>";
            echo "</form>";
        }
}
echo "</body>";
echo "</html>";
?>

