<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Potrjevanje
</title>
<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>
</head>
<body>

<?php
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo1",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}
if (isset($_POST["Ucitelj"])){
    $ucitelj=$_POST["Ucitelj"];
}else{
    if (isset($_GET["Ucitelj"])){
        $ucitelj=$_GET["Ucitelj"];
    }else{
        $ucitelj=0;
    }
}
if (isset($_POST["potrdi"])){
    $VEnotPotrjeno=$_POST["potrdi"];
}else{
    if (isset($_GET["potrdi"])){
        $VEnotPotrjeno=$_GET["potrdi"];
    }else{
        $VEnotPotrjeno=0;
    }
}
if (isset($_POST["mesec"])){
    $VMesec=$_POST["mesec"];
}else{
    if (isset($_GET["mesec"])){
        $VMesec=$_GET["mesec"];
    }else{
        $VMesec="";
    }
}
if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        $VLeto="";
    }
}
if (isset($_POST["spisek"])){
    $VSpisek=$_POST["spisek"];
}else{
    if (isset($_GET["spisek"])){
        $VSpisek=$_GET["spisek"];
    }else{
        $VSpisek="0";
    }
}

if (isset($_POST["StZapisov"])){
    for ($i=1;$i <= $_POST["StZapisov"];$i++){
        if (isset($_POST["br_".$i])){
            $SQL = "DELETE FROM tabpregleddelan WHERE Id =" . $_POST["brisi_".$i];
            $result = mysqli_query($link,$SQL);
        }
    }
}
if (isset($_POST["submit"])){
    $VSubmit=$_POST["submit"];
}else{
    $VSubmit="";
}
if ($VSubmit=="Potrdi"){
	if (isset($_POST["StZapisov"])){
		$StZapisov=$_POST["StZapisov"];
		for ($Indx=1;$Indx <= $StZapisov;$Indx++){
			if (isset($_POST["EnotPotrjeno".$Indx])){
				$SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=true,Potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["id".$Indx];
			}else{
				$SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=false,Potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["id".$Indx];
			}
			$result = mysqli_query($link,$SQL);
		}
		echo "<h2>Poslali ste nove potrditve!</h2>";
	}else{
	    echo "<form name='vnosi' method='post' action='PotrjevanjeRubrikPDN.php'>";
	    echo "<h2>Izberite leto in mesec za pregled vnosov ur</h2><br />";
	    echo "<table border='0'>";
	    echo "<tr>";
		echo "<td>Leto: </td>";
		echo "<td><select name='leto'>";
		$VLeto=$Danes->format('Y');
		echo "<option value='" .$VLeto  . "' selected>" .$VLeto ."</option>";
		echo "<option value='" .($VLeto-1). "'>" .($VLeto -1). "</option>";
		echo "<option value='" .($VLeto +1) . "'>" .($VLeto +1).  "</option>";
		echo "</select></td>";
	    echo "</tr>";
	    echo "<tr>";
		echo "<td><font color='red'><b>Mesec:</b></font> </td><td><select name='mesec'>";
		$VMesec=$Danes->format('n');
		for ($Indx=1;$Indx <= 12;$Indx++){
			if ($Indx==$VMesec){
				echo "<option value=".$Indx." selected>".$Indx."</option>";
			}else{
				echo "<option value=".$Indx.">".$Indx."</option>";
			}
		}
		echo "</select>";
		echo "</td>";
	    echo "</tr>";
	    echo "<tr>";
		echo "<td>";
		echo "<b>Spisek:</b> </td><td><select name='spisek'>";
		echo "<option value='0'>Vse rubrike</option>";
		echo "<option value='1'>Le nepotrjene rubrike</option>";
		echo "<option value='2'>Le potrjene rubrike</option>";
		echo "<option value='3'>Le vse rubrike, ki jih vnašajo delavci</option>";
		echo "<option value='4'>Le nepotrjene rubrike, ki jih vnašajo delavci</option>";
		echo "</select>";
	    echo "</select></td>";
	    echo "</tr>";
	    echo "</table>";
	    echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
	}
}

if (($VMesec=="") && ($VLeto=="")){
    echo "<form name='vnosi' method='post' action='PotrjevanjeRubrikPDN.php'>";
    echo "<h2>Izberite leto in mesec za pregled vnosov ur</h2><br />";
    echo "<table border='0'>";
    echo "<tr>";
    echo "<td>Leto: </td>";
    echo "<td><select name='leto'>";
    $VLeto=$Danes->format('Y');
    echo "<option value='" .$VLeto  . "' selected>" .$VLeto ."</option>";
    echo "<option value='" .($VLeto-1). "'>" .($VLeto -1). "</option>";
    echo "<option value='" .($VLeto +1) . "'>" .($VLeto +1).  "</option>";
    echo "</select></td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td><font color='red'><b>Mesec:</b></font> </td><td><select name='mesec'>";
    $VMesec=$Danes->format('n');
    for ($Indx=1;$Indx <= 12;$Indx++){
        if ($Indx==$VMesec){
            echo "<option value=".$Indx." selected>".$Indx."</option>";
        }else{
            echo "<option value=".$Indx.">".$Indx."</option>";
        }
    }
    echo "</select>";
    echo "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>";
    echo "<b>Spisek:</b> </td><td><select name='spisek'>";
    echo "<option value='0'>Vse rubrike</option>";
    echo "<option value='1'>Le nepotrjene rubrike</option>";
    echo "<option value='2'>Le potrjene rubrike</option>";
    echo "<option value='3'>Le vse rubrike, ki jih vnašajo delavci</option>";
    echo "<option value='4'>Le nepotrjene rubrike, ki jih vnašajo delavci</option>";
    echo "</select>";
    echo "</select></td>";
    echo "</tr>";
    echo "</table>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";
}else{
    $SQL = "SELECT tabpregleddelan.*,tabpregleddelan.id AS pid,tabpregleddelan.komentar AS pkomentar,TabDoprinos.*,tabucitelji.* FROM ";
	$SQL = $SQL . "(tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos) ";
	$SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.ucitelj=tabucitelji.idUcitelj ";
	$SQL = $SQL . "WHERE tabpregleddelan.leto=".$VLeto." AND mesec = ".$VMesec." ORDER BY tabucitelji.priimek,tabucitelji.ime,tabpregleddelan.datum";
	$result = mysqli_query($link,$SQL);
	
	echo "<form name='potrjevanje' method='post' action='PotrjevanjeRubrikPDN.php'>";
	echo "<h2>Potrjevanje mesečnih dejavnosti delavcev</h2>";
    switch ($VMesec){
        case 1:
            echo "<a href='PotrjevanjeRubrikPDN.php?leto=".($VLeto-1)."&mesec=12&spisek=".$VSpisek."'>Prejšnji</a> | <a href='PotrjevanjeRubrikPDN.php?leto=".$VLeto."&mesec=".($VMesec+1)."&spisek=".$VSpisek."'>Naslednji</a><br />";
            break;
        case 12:
            echo "<a href='PotrjevanjeRubrikPDN.php?leto=".$VLeto."&mesec=".($VMesec-1)."&spisek=".$VSpisek."'>Prejšnji</a> | <a href='PotrjevanjeRubrikPDN.php?leto=".($VLeto+1)."&mesec=1&spisek=".$VSpisek."'>Naslednji</a><br />";
            break;
        default:
            echo "<a href='PotrjevanjeRubrikPDN.php?leto=".$VLeto."&mesec=".($VMesec-1)."&spisek=".$VSpisek."'>Prejšnji</a> | <a href='PotrjevanjeRubrikPDN.php?leto=".$VLeto."&mesec=".($VMesec+1)."&spisek=".$VSpisek."'>Naslednji</a><br />";
    }
	echo "<table border='1'>";
	echo "<tr><th>Št.</th><th>Ime</th><th>Datum</th><th width='250'>Rubrika</th><th>čas</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
	$Indx=0;
	while ($R = mysqli_fetch_array($result)){
		switch ($VSpisek){
			case "0": // 'vse
				$Indx=$Indx+1;
				echo "<tr>";
				echo "<td>".$Indx."</td>";
				echo "<td><input name='id".$Indx."' type='hidden' value='".$R["pid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
                $Datum=new DateTime($R["Datum"]);
				echo "<td>".$Datum->format('d.m.Y')."</td>";
				echo "<td>".$R["OblikaDela"]."</td>";
				if ($R["uramin"] > 1 ){
					echo "<td>".$R["Enot"]." min</td>";
				}else{
					if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
						echo "<td>".$R["Enot"]." dni</td>";
					}else{
						echo "<td>".$R["Enot"]." ur</td>";
					}
				}
				echo "<td>".$R["pkomentar"]."</td>";
				if ($R["EnotPotrjeno"] ){
					echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox' checked></td>";
				}else{
					echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox'></td>";
				}
				echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."&odkod=1'>Popravi</a></td>";
                echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
				//echo "<td><a href='brisiPDN.php?id=".$R["pid"]."&back=potrjevanje&leto=".$VLeto."&mesec=".$VMesec."&spisek=".$VSpisek."'>Briši</td>";
				echo "</tr>";
                break;
			case "1": //'samo nepotrjene
				if (!$R["EnotPotrjeno"]){
					$Indx=$Indx+1;
					echo "<tr>";
					echo "<td>".$Indx."</td>";
                    echo "<td><input name='id".$Indx."' type='hidden' value='".$R["pid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime($R["Datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["OblikaDela"]."</td>";
                    if ($R["uramin"] > 1 ){
                        echo "<td>".$R["Enot"]." min</td>";
                    }else{
                        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
                            echo "<td>".$R["Enot"]." dni</td>";
                        }else{
                            echo "<td>".$R["Enot"]." ur</td>";
                        }
                    }
                    echo "<td>".$R["pkomentar"]."</td>";
                    if ($R["EnotPotrjeno"] ){
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox' checked></td>";
                    }else{
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox'></td>";
                    }
                    echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."&odkod=1'>Popravi</a></td>";
                    echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
                    //echo "<td><a href='brisiPDN.php?id=".$R["pid"]."&back=potrjevanje&leto=".$VLeto."&mesec=".$VMesec."&spisek=".$VSpisek."'>Briši</td>";
                    echo "</tr>";
				}
                break;
			case "2": //'samo potrjene
				if ($R["EnotPotrjeno"]){
                    $Indx=$Indx+1;
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='id".$Indx."' type='hidden' value='".$R["pid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime($R["Datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["OblikaDela"]."</td>";
                    if ($R["uramin"] > 1 ){
                        echo "<td>".$R["Enot"]." min</td>";
                    }else{
                        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
                            echo "<td>".$R["Enot"]." dni</td>";
                        }else{
                            echo "<td>".$R["Enot"]." ur</td>";
                        }
                    }
                    echo "<td>".$R["pkomentar"]."</td>";
                    if ($R["EnotPotrjeno"] ){
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox' checked></td>";
                    }else{
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox'></td>";
                    }
                    echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."&odkod=1'>Popravi</a></td>";
                    echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
                    //echo "<td><a href='brisiPDN.php?id=".$R["pid"]."&back=potrjevanje&leto=".$VLeto."&mesec=".$VMesec."&spisek=".$VSpisek."'>Briši</td>";
                    echo "</tr>";
				}
                break;
			case "4": //'nepotrjene  delavcev
				if ((!$R["EnotPotrjeno"]) && ($R["aktivno"]==1) ){
                    $Indx=$Indx+1;
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='id".$Indx."' type='hidden' value='".$R["pid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime($R["Datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["OblikaDela"]."</td>";
                    if ($R["uramin"] > 1 ){
                        echo "<td>".$R["Enot"]." min</td>";
                    }else{
                        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
                            echo "<td>".$R["Enot"]." dni</td>";
                        }else{
                            echo "<td>".$R["Enot"]." ur</td>";
                        }
                    }
                    echo "<td>".$R["pkomentar"]."</td>";
                    if ($R["EnotPotrjeno"] ){
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox' checked></td>";
                    }else{
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox'></td>";
                    }
                    echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."&odkod=1'>Popravi</a></td>";
                    echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
                    //echo "<td><a href='brisiPDN.php?id=".$R["pid"]."&back=potrjevanje&leto=".$VLeto."&mesec=".$VMesec."&spisek=".$VSpisek."'>Briši</td>";
                    echo "</tr>";
				}
                break;
			case "3": // 'vse, delavci
				if ($R["aktivno"]==1){
                    $Indx=$Indx+1;
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td><input name='id".$Indx."' type='hidden' value='".$R["pid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    $Datum=new DateTime($R["Datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td>".$R["OblikaDela"]."</td>";
                    if ($R["uramin"] > 1 ){
                        echo "<td>".$R["Enot"]." min</td>";
                    }else{
                        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
                            echo "<td>".$R["Enot"]." dni</td>";
                        }else{
                            echo "<td>".$R["Enot"]." ur</td>";
                        }
                    }
                    echo "<td>".$R["pkomentar"]."</td>";
                    if ($R["EnotPotrjeno"] ){
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox' checked></td>";
                    }else{
                        echo "<td align=center><input name='EnotPotrjeno".$Indx."' type='checkbox'></td>";
                    }
                    echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."&odkod=1'>Popravi</a></td>";
                    echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
                    //echo "<td><a href='brisiPDN.php?id=".$R["pid"]."&back=potrjevanje&leto=".$VLeto."&mesec=".$VMesec."&spisek=".$VSpisek."'>Briši</td>";
                    echo "</tr>";
				}
		}
	}
	echo "</table><br />";
	echo "<input type='hidden' name='spisek' value='".$VSpisek."'>";
	echo "<input type='hidden' name='StZapisov' value='".$Indx."'>";
    echo "<input type='hidden' name='mesec' value='".$VMesec."'>";
    echo "<input type='hidden' name='leto' value='".$VLeto."'>";
//	echo "<input name='submit' type='submit' value='Pošlji'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Odznači vse' onClick='BrisiVse(this.form)'><br />";
    echo "<input name='submit' type='submit' value='Potrdi'><input name='gumb' type='submit' value='Briši'><input name='gumbreset' type='button' value='Odznači vse' onClick='BrisiVse(this.form)'><br />";
}

?>
<br/>
<a href='PotrjevanjeRubrikPDN.php'>Potrjevanje rubrik za vnesene mesečne podatke</a><br />
<a href="pravilnik.htm">Pravilnik</a><br />
</body>
</html>
