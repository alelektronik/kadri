<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Ocene
</title>
<style>
.break { page-break-before: always; }
input.groovybutton
{
   font-size:8px;
   font-weight:bold;
   width:18px;
}
</style>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
    };
</script>

<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VIdRazrednik=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        function ClearBlank($x){
            if (strlen($x) > 0){
                $x=str_replace("&nbsp;","",$x);
            }
            return $x;
        }

        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = 0;
            }
        }
        
        
        if (isset($_POST["razred"])){
            $VRazred = $_POST["razred"];
        }else{
            if (isset($_GET["razred"])){
                $VRazred=$_GET["razred"];
            }else{
                if (isset($_SESSION["razred"])){
                    $VRazred=$_SESSION["razred"];
                }else{
                    $VRazred = 0;
                }
            }
        }

        function Vsebuje($a,$s){
            $x=explode(",",$s);
            for($Indx=0;$Indx < count($x);$Indx++){
                if ($x[$Indx]==$a){
                    return true;
                }
            }
            return false;
        }

        switch ($Vid){
            case "2":
                break;
            default:
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
                if ($VRazred > 0) {
                    echo "<a href='posebnidnevi.php?id=4&solskoleto=".$VLeto."&razred=".$VRazred."'>Izpis dnevov dejavnosti s prisotnostjo</a><br />";
                }
                echo "<a href='posebnidnevi.php?id=5&solskoleto=".$VLeto."&razred=".$VRazred."'>Koledar izvedenih dnevov dejavnosti</a><br />";
                echo "<a href='posebnidnevi.php?id=6&solskoleto=".$VLeto."&razred=".$VRazred."'>Spisek izvedenih dnevov dejavnosti po mesecih</a><br />";
                echo "<a href='posebnidnevi.php?id=7&solskoleto=".$VLeto."'>Spisek izvedenih dnevov dejavnosti - vsi</a><br />";
        }
        switch ($Vid){
            case "1": //vnos posebnih dni
                if (isset($_GET["zapis"])){
                    $VZapis=$_GET["zapis"];
                }else{
                    $VZapis=0;
                }
                switch ($VZapis){
                    case 0:
				        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VRazred1=$R["razred"];
                            $VParalelka=$R["oznaka"];
				        }else{
					        $VRazred1=0;
					        $VParalelka="";
				        }
				        
                        $SQL = "SELECT tabostaledej.*,tabostaledej.id AS did, tabaktivnosti.*,tabrazdat.* FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE idRazred=".$VRazred;
                        $SQL = $SQL . " ORDER BY tabaktivnosti.IdAktivnost";
                        $result = mysqli_query($link,$SQL);

                        echo "<h2>Vnos dnevov dejavnosti</h2>";
                        echo "<table border=1 cellspacing=0>";
                        echo "<tr><th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum<br />DD.MM.LLLL</th><th>Trajanje<br />čas od-do</th><th>Vodja</th><th>Cena [EUR]<br />na učenca</th><th>Subvencija<br />ministrstva [EUR]</th><th>Briši</th><th>Popravi/Ogled<br />Tiskanje</th></tr>";

                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            $VRazred1=$R["razred"];
                            $VParalelka=$R["oznaka"];
                            echo "<tr>";
                            echo "<td>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                            echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "<td>".$R["Opis"]."</td>";
                            echo "<td>".$R["Vsebina"]."</td>";
                            echo "<td>".$R["Kraj"]."</td>";
                            echo "<td>".$R["Datum"]."</td>";
                            echo "<td>".$R["Trajanje"]."</td>";
                            echo "<td>".$R["Vodja"]."</td>";
                            echo "<td>".$R["cena"]."</td>";
                            echo "<td>".$R["subvmss"]."</td>";
                            echo "<td><a href='posebnidnevi.php?id=8&zapis=".$R["did"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                            echo "<td><a href='posebnidnevi.php?id=1&zapis=".$R["did"]."'><img src='img/m_poglej1.gif' border='0' alt='Ogled'></a></td>";
                            echo "</tr>";
                            $Indx = $Indx+1;
                        }
                            
                        echo "<tr><td> </td></tr>";

                        echo "<form name='form_PosebniDnevi' method=post action='posebnidnevi.php'>";
                        echo "<input name='id' type='hidden' value='2'>";

                        echo "<tr>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        echo "<td>".$VRazred1.". ".$VParalelka."</td>";
                        echo "<td><select name='aktivnost'>";

                        $SQL = "SELECT * FROM tabaktivnosti";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value=".$R["IdAktivnost"].">".$R["Opis"]."</option>";
                        }

                        echo "</select></td>";
                        echo "<td><input name='vsebina' type='text'></td>";
                        echo "<td><input name='kraj' type='text' size='15'></td>";
                        //echo "<td><input name='datum1' type='text' size='10' id='dat01'></td>";
                        echo "<td><input name='datum1' type='text' size='10'></td>";
                        echo "<td><input name='trajanje' type='text' size='8'></td>";
                        echo "<td><input name='vodja' type='text'></td>";
                        echo "<td><input name='cena' type='text'></td>";
                        echo "<td><input name='subvmss' type='text'></td>";
                        echo "</tr>";
                        echo "</table><br />";
                        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                        echo "<input name='paralelka' type='hidden' value='".$VParalelka."'>";
                        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";

                        $SQL = "SELECT tabrazred.*,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE idRazred=".$VRazred;
                        $SQL = $SQL . " ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);

                        echo "<table border=1>";
                        echo "<tr><th>Št.</th><th>Razred</th><th>Ime</th><th>Udeleženec<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></th><th>Subvencija<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,2)'></th><th>Neopravičeno<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,3)'></th></tr>";
                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."<input name='uc".$Indx."' type='hidden' value='".$R["IdUcenec"]."'></td>";
                            echo "<td align='center'><input id='dan_1' name='udel".$Indx."' type='checkbox' checked></td>";
                            echo "<td align='center'><input id='dan_2' name='subv".$Indx."' type='checkbox'></td>";
                            echo "<td align='center'><input id='dan_3' name='neop".$Indx."' type='checkbox'></td>";
                            echo "</tr>";
                            $Indx=$Indx+1;
                        }

                        echo "</table><br />";
                        echo "<input type='hidden' name='stucencev' value='".($Indx-1)."'>";
                        
                        $Spremljevalec=array(0,0,0,0,0,0,0,0);
                        $StSpremljevalcev=0;

                        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status IN (1,2,3,4,5,6,10) ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VUcitelji[$Indx][0]=$R["iducitelj"];
                            $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                            $Indx=$Indx+1;
                        }
                        $VUcitelji[$Indx][0]=0;
                        $VUcitelji[$Indx][1]="Ni izbran";
                        $StUciteljev=$Indx;
                        
                        echo "Spremljevalci:<br />";
                        for ($Indx=1;$Indx <= 7;$Indx++){
                            echo "<select name='spremljevalec".$Indx."'>";
                            for ($i1=1;$i1 <= $StUciteljev;$i1++){
                                if ($VUcitelji[$i1][0]==$Spremljevalec[$Indx] ){
                                    echo "<option value='".$VUcitelji[$i1][0]."' selected='selected'>".$VUcitelji[$i1][1]."</option>";
                                }else{
                                    echo "<option value='".$VUcitelji[$i1][0]."'>".$VUcitelji[$i1][1]."</option>";
                                }
                            }
                            echo "</select><br />";
                        }
                            
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "</form>";
                        break;
                    default:
                        $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
                        $result = mysqli_query($link,$SQL);
                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            $Razredi[$Indx][0]=$R["id"];
                            $Razredi[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                            $Indx=$Indx+1;
                        }
                        $StRazredov=$Indx-1;
                        
                        $SQL = "SELECT tabostaledej.*, tabaktivnosti.*,tabrazdat.*,tabrazdat.id AS rid FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabostaledej.id=".$VZapis;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VRazred1=$R["razred"];
                            $VRazred=$R["rid"];
                            $VParalelka=$R["oznaka"];
                            $VLeto=$R["leto"];
                            $VVsebina=$R["Vsebina"];
                            $VKraj=$R["Kraj"];
                            $VDatum=$R["Datum"];
                            $VTrajanje=$R["Trajanje"];
                            $VVodja=$R["Vodja"];
                            $VCena=$R["cena"];
                            $VSubvMSS=$R["subvmss"];
                            $VUdelezenci=$R["Udelezenci"];
                            $VSubvencija=$R["Subvencija"];
                            $VNeopraviceno=$R["Neopraviceno"];
                            $VAktivnost=$R["IdAktivnost"];
                            $VSpremljevalci=$R["Spremljevalci"];
                            if (strlen($VSpremljevalci) == 0){ 
                                $VSpremljevalci="0,0,0,0,0,0,0";
                            }
                            
                            echo "<h2>Dan dejavnosti</h2>";
                            echo "<form name='popravi_PosebniDnevi' method=post action='posebnidnevi.php'>";
                            echo "<input name='id' type='hidden' value='2'>";
                            echo "<table border=1 cellspacing=0>";
                            //echo "<tr><th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum<br />DD.MM.LLLL</th><th>Trajanje<br />čas od-do</th><th>Vodja</th></tr>";
                            echo "<tr><th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum<br />DD.MM.LLLL</th><th>Trajanje<br />čas od-do</th><th>Vodja</th><th>Cena [EUR]<br />na učenca</th><th>Subvencija<br />ministrstva [EUR]</th></tr>";
                            echo "<tr>";
                            echo "<td><input name='solskoleto' type='hidden' value='".$R["leto"]."'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                            echo "<td>";
                            echo "<select name='razred'>";
                                for ($Indx=0;$Indx <= $StRazredov;$Indx++){
                                    if ($Razredi[$Indx][0]==$VRazred ){
                                        echo "<option value='".$Razredi[$Indx][0]."' selected='selected'>".$Razredi[$Indx][1]."</option>";
                                    }else{
                                        echo "<option value='".$Razredi[$Indx][0]."'>".$Razredi[$Indx][1]."</option>";
                                    }
                                }
                            echo "</select>";
                            echo "</td>";
                            echo "<td><select name='aktivnost'>";

                            $SQL = "SELECT * FROM tabaktivnosti";
                            $result = mysqli_query($link,$SQL);

                            while ($R = mysqli_fetch_array($result)){
                                if ($VAktivnost==$R["IdAktivnost"] ){
                                    echo "<option value='".$R["IdAktivnost"]."' selected='selected'>".$R["Opis"]."</option>";
                                }else{
                                    echo "<option value='".$R["IdAktivnost"]."'>".$R["Opis"]."</option>";
                                }
                            }

                            echo "</select></td>";
                            echo "<td><input name='vsebina' type='text' value='".$VVsebina."'></td>";
                            echo "<td><input name='kraj' type='text' size='15' value='".$VKraj."'></td>";
                            //echo "<td><input name='datum1' type='text' size='10' value='".$VDatum."' id='dat02'></td>";
                            echo "<td><input name='datum1' type='text' size='10' value='".$VDatum."'></td>";
                            echo "<td><input name='trajanje' type='text' size='8' value='".$VTrajanje."'></td>";
                            echo "<td><input name='vodja' type='text' value='".$VVodja."'></td>";
                            echo "<td><input name='cena' type='text' value='".$VCena."'></td>";
                            echo "<td><input name='subvmss' type='text' value='".$VSubvMSS."'></td>";
                            echo "</tr>";
                            echo "</table><br />";

                            $SQL = "SELECT tabrazred.*,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE tabrazred.idRazred=".$VRazred;
                            $SQL = $SQL . " ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);

                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Razred</th><th>Ime</th><th>Udeleženec</th><th>Subvencija</th><th>Neopravičeno</th></tr>";
                            $Indx=1;
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."<input name='uc".$Indx."' type='hidden' value='".$R["IdUcenec"]."'></td>";
                                if (Vsebuje($R["IdUcenec"],$VUdelezenci) ){
                                    echo "<td><input name='udel".$Indx."' type='checkbox' checked></td>";
                                }else{
                                    echo "<td><input name='udel".$Indx."' type='checkbox'></td>";
                                }
                                if (Vsebuje($R["IdUcenec"],$VSubvencija) ){
                                    echo "<td><input name='subv".$Indx."' type='checkbox' checked></td>";
                                }else{
                                    echo "<td><input name='subv".$Indx."' type='checkbox'></td>";
                                }
                                if (Vsebuje($R["IdUcenec"],$VNeopraviceno) ){
                                    echo "<td><input name='neop".$Indx."' type='checkbox' checked></td>";
                                }else{
                                    echo "<td><input name='neop".$Indx."' type='checkbox'></td>";
                                }
                                echo "</tr>";
                                $Indx=$Indx+1;
                            }

                            echo "</table><br />";
                            echo "<input type='hidden' name='stucencev' value='".($Indx-1)."'>";
                            
                            for ($Indx=1;$Indx <= 7;$Indx++){
                                $Spremljevalec[$Indx]=0;
                            }
                            if (strlen($VSpremljevalci) > 0){
                                $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj IN (".$VSpremljevalci.")";
                                $result = mysqli_query($link,$SQL);
                                
                                $Indx=1;
                                while ($R = mysqli_fetch_array($result)){
                                    $Spremljevalec[$Indx]=$R["IdUcitelj"];
                                    if ($Spremljevalec[$Indx] > 0 ){
                                        $Indx=$Indx+1;
                                    }
                                }
                            }
                            $StSpremljevalcev=$Indx-1;

                            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status IN (1,2,3,4,5,6) ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);

                            $Indx=1;
                            while ($R = mysqli_fetch_array($result)){
                                $VUcitelji[$Indx][0]=$R["iducitelj"];
                                $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                                $Indx=$Indx+1;
                            }
                            $VUcitelji[$Indx][0]=0;
                            $VUcitelji[$Indx][1]="Ni izbran";
                            $StUciteljev=$Indx;
                            
                            echo "Spremljevalci:<br />";
                            for ($Indx=1;$Indx <= 7;$Indx++){
                                echo "<select name='spremljevalec".$Indx."'>";
                                for ($i1=1;$i1 <= $StUciteljev;$i1++){
                                    if ($VUcitelji[$i1][0]==$Spremljevalec[$Indx] ){
                                        echo "<option value='".$VUcitelji[$i1][0]."' selected='selected'>".$VUcitelji[$i1][1]."</option>";
                                    }else{
                                        echo "<option value='".$VUcitelji[$i1][0]."'>".$VUcitelji[$i1][1]."</option>";
                                    }
                                }
                                echo "</select><br />";
                            }
                            
                            echo "<input type='hidden' name='zapis' value='".$VZapis."'>";
                            echo "<input name='submit' type='submit' value='Pošlji'><input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'>";
                            echo "</form>";
                        }
                }
                //echo "<br /><a href='VnosPosebniDnevi.php'>Vnos kulturnih, naravoslovnih, tehniških in športnih dni</a>"

                echo "<a href='posebnidnevi.php?id=4&solskoleto=".$VLeto."&razred=".$VRazred."'>Izpis dnevov dejavnosti s prisotnostjo</a><br />";
                break;
            case "2": //vpis posebnih dni
                $VVsebina = $_POST["vsebina"];
                $VAktivnost = $_POST["aktivnost"];
                $VTrajanje = $_POST["trajanje"];
                $VDatum = $_POST["datum1"];
                if (!isDate($VDatum)){
                    $VDatum=$Danes->format('d.m.Y');
                }
                $VKraj = $_POST["kraj"];
                $VVodja = $_POST["vodja"];
                $VCena = $_POST["cena"];
                $VSubvMSS = $_POST["subvmss"];
                $VStUcencev = $_POST["stucencev"];
                $VSpremljevalec = "";
                for ($Indx=1;$Indx <= 7;$Indx++){
                    if ($Indx > 1){
                        $VSpremljevalec=$VSpremljevalec.",".$_POST["spremljevalec".$Indx];
                    }else{
                        $VSpremljevalec=$_POST["spremljevalec".$Indx];
                    }
                }

                if ($VRazred > 0){
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                    }
                }
                $VUdelezenci="";
                for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                    if (isset($_POST["udel".$Indx])){
                        if (strlen($VUdelezenci)==0 ){
                            $VUdelezenci=$_POST["uc".$Indx];
                        }else{
                            $VUdelezenci=$VUdelezenci.",".$_POST["uc".$Indx];
                        }
                    }
                }

                $VSubvencija="";
                for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                    if (isset($_POST["subv".$Indx])){
                        if (strlen($VSubvencija)==0 ){
                            $VSubvencija=$_POST["uc".$Indx];
                        }else{
                            $VSubvencija=$VSubvencija.",".$_POST["uc".$Indx];
                        }
                    }
                }

                $VNeopraviceno="";
                for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                    if (isset($_POST["neop".$Indx])){
                        if (strlen($VNeopraviceno)==0 ){
                            $VNeopraviceno=$_POST["uc".$Indx];
                        }else{
                            $VNeopraviceno=$VNeopraviceno.",".$_POST["uc".$Indx];
                        }
                    }
                }

                //Vpiše oz. popravi uspeh
                if (isset($_POST["zapis"])){
                    $VZapis=$_POST["zapis"];
                }else{
                    if (isset($_GET["zapis"])){
                        $VZapis=$_GET["zapis"];
                    }else{
                        $VZapis=0;
                    }
                }
                switch ($VZapis){
                    case 0:  //nov vpis
                        if ($VRazred < 0){ //splošen planski vpis za naslednje leto - za vse paralelke hkrati
                            $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred=".abs($VRazred);
                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                $VRazred=$R["id"];
                                $VRazred1=$R["razred"];
                                $VParalelka=$R["oznaka"];
                                $SQL = "INSERT INTO tabostaledej (Leto,Razred,Paralelka,IdAktivnost,Trajanje,Datum,Kraj,Vsebina,vodja,udelezenci,spremljevalci,subvencija,idRazred,neopraviceno,cena,subvmss) ";
                                $SQL = $SQL."values (" . $VLeto . "," . $VRazred1 . ",'" . $VParalelka . "'," . $VAktivnost . ",'" . $VTrajanje . "','" . $VDatum . "','" . $VKraj . "','".$VVsebina."','".$VVodja."','','','',".$VRazred.",'','".$VCena."','".$VSubvMSS."')";
                                $result1 = mysqli_query($link,$SQL);
                            }
                        }else{
                            $SQL = "INSERT INTO tabostaledej (Leto,Razred,Paralelka,IdAktivnost,Trajanje,Datum,Kraj,Vsebina,vodja,udelezenci,spremljevalci,subvencija,idRazred,neopraviceno,cena,subvmss) ";
                            $SQL = $SQL."values (" . $VLeto . "," . $VRazred1 . ",'" . $VParalelka . "'," . $VAktivnost . ",'" . $VTrajanje . "','" . $VDatum . "','" . $VKraj . "','".$VVsebina."','".$VVodja."','".$VUdelezenci."','".$VSpremljevalec."','".$VSubvencija."',".$VRazred.",'".$VNeopraviceno."','".$VCena."','".$VSubvMSS."')";
                            $result = mysqli_query($link,$SQL);
                        }
                        break;
                    default: //vpis popravka
                        $SQL = "UPDATE tabostaledej SET ";
                        $SQL = $SQL . "leto=".$VLeto.", ";
                        $SQL = $SQL . "razred=".$VRazred1.", ";
                        $SQL = $SQL . "paralelka='".$VParalelka."', ";
                        $SQL = $SQL . "idAktivnost=".$VAktivnost.", ";
                        $SQL = $SQL . "trajanje='".$VTrajanje."', ";
                        $SQL = $SQL . "datum='".$VDatum."', ";
                        $SQL = $SQL . "kraj='".$VKraj."', ";
                        $SQL = $SQL . "vsebina='".$VVsebina."', ";
                        $SQL = $SQL . "vodja='".$VVodja."', ";
                        $SQL = $SQL . "udelezenci='".$VUdelezenci."', ";
                        $SQL = $SQL . "subvencija='".$VSubvencija."', ";
                        $SQL = $SQL . "neopraviceno='".$VNeopraviceno."', ";
                        $SQL = $SQL . "spremljevalci='".$VSpremljevalec."', ";
                        $SQL = $SQL . "cena='".$VCena."', ";
                        $SQL = $SQL . "subvmss='".$VSubvMSS."', ";
                        $SQL = $SQL . "idRazred=".$VRazred." ";
                        $SQL = $SQL . "WHERE id=".$VZapis;
                        
                        $result = mysqli_query($link,$SQL);
                }

                if ($Opravila==1 ){
                    $SQL = "SELECT tabdogodek.*,tabdeldogodek.*,tabdeldogodek.id AS did FROM ";
                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos dnevov dejavnosti' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VDogodki[$Indx]=$R["did"];
                        $Indx=$Indx+1;
                    }
                    $StDogodkov=$Indx-1;

                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }
                header ("Location: posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto);
                //echo "<a href='posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na spisek dnevov dejavnosti</a><br />";
                break;
            case "3": //vnos posebnih dni - aktivi
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT tabostaledej.*,tabostaledej.id AS oid, tabaktivnosti.*,tabrazdat.* FROM ";
                $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=".$VRazred;
                $SQL = $SQL ." ORDER BY tabaktivnosti.IdAktivnost";
                $result = mysqli_query($link,$SQL);

                echo "Če izberete razred brez paralelka, bo vsebina vpisana vsem razredom v paralelki.<br />";
                echo "<table border=1 cellspacing=0>";
                //echo "<th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum</th><th>Trajanje</th><th>Vodja</th><th>Briši</th>";
                echo "<tr><th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum<br />DD.MM.LLLL</th><th>Trajanje<br />čas od-do</th><th>Vodja</th><th>Cena [EUR]<br />na učenca</th><th>Subvencija<br />ministrstva [EUR]</th><th>Briši</th></tr>";

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>".$R["Opis"]."</td>";
                    echo "<td>".$R["Vsebina"]."</td>";
                    echo "<td>".$R["Kraj"]."</td>";
                    echo "<td>".$R["Datum"]."</td>";
                    echo "<td>".$R["Trajanje"]."</td>";
                    echo "<td>".$R["Vodja"]."</td>";
                    echo "<td>".$R["cena"]."</td>";
                    echo "<td>".$R["subvmss"]."</td>";
                    echo "<td><a href='posebnidnevi.php?id=8&zapis=".$R["oid"]."&razred=".$VRazred."&solskoleto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx = $Indx+1;
                }
                    
                echo "<tr><td> </td></tr>";

                echo "<form name='form_PosebniDnevi' method=post action='posebnidnevi.php'>";
                echo "<td><input name='id' type='hidden' value='2'></td>";

                echo "<tr>";
                echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                echo "<td><select name='razred'>";
                $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                echo "<option value='0' selected='selected'>Ni izbran</option>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                for ($i=1;$i <= 9;$i++){
                    echo "<option value='-".$i."'>".$i."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='aktivnost'>";

                $SQL = "SELECT * FROM tabaktivnosti";
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    echo "<option value=".$R["IdAktivnost"].">".$R["Opis"]."</option>";
                }

                echo "</select></td>";
                echo "<td><input name='vsebina' type='text'></td>";
                echo "<td><input name='kraj' type='text'></td>";
                //echo "<td><input name='datum1' type='text' id='dat03'></td>";
                echo "<td><input name='datum1' type='text'></td>";
                echo "<td><input name='trajanje' type='text'></td>";
                echo "<td><input name='vodja' type='text'></td>";
                echo "<td><input name='cena' type='text'></td>";
                echo "<td><input name='subvmss' type='text'></td>";
                echo "</tr>";
                echo "</table>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";

                //echo "<br /><a href='VnosPosebniDnevi.php'>Vnos kulturnih, naravoslovnih, tehniških in športnih dni</a>"
                break;
            case "4": //izpis posebni dnevi
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazred.idRazred=".$VRazred;
                $SQL = $SQL . " ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcenci[$Indx][0]=$R["iducenec"];
                    $VUcenci[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;

                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE STATUS IN (1,2,3,4,5,6,10) ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcitelji[$Indx][0]=$R["iducitelj"];
                    $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $Indx=$Indx+1;
                }
                $StUciteljev=$Indx-1;
                    
                $SQL = "SELECT tabostaledej.*, tabaktivnosti.*,tabrazdat.*,tabrazdat.id AS rid FROM ";
                $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE idRazred=".$VRazred;
                $SQL = $SQL . " ORDER BY tabaktivnosti.IdAktivnost";
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VRazred=$R["rid"];
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VLeto=$R["leto"];
                    echo "<h2>Izpis dnevov dejavnosti - ".$VRazred1.". ".$VParalelka." - ".$VLeto."/".($VLeto+1)."</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<tr><th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum</th><th>Trajanje</th><th>Vodja</th><th>Cena [EUR]<br />na učenca</th><th>Subvencija<br />ministrstva [EUR]</th></tr>";
                }

                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>".$R["Opis"]."</td>";
                    echo "<td>".$R["Vsebina"]."</td>";
                    echo "<td>".$R["Kraj"]."</td>";
                    echo "<td>".$R["Datum"]."</td>";
                    echo "<td>".$R["Trajanje"]."</td>";
                    echo "<td>".$R["Vodja"]."</td>";
                    echo "<td>".$R["cena"]."</td>";
                    echo "<td>".$R["subvmss"]."</td>";
                    echo "</tr>";
                    $VDejavnost[$Indx][0]=$R["kratica"];
                    $VDejavnost[$Indx][1]=$R["Datum"];
                    $VDejavnost[$Indx][2]=$R["Udelezenci"];
                    $VDejavnost[$Indx][3]=$R["Spremljevalci"];
                    $VDejavnost[$Indx][4]=$R["Subvencija"];
                    $VDejavnost[$Indx][5]=$R["Neopraviceno"];
                    $Indx = $Indx+1;
                }
                $StDejavnosti=$Indx-1;
                    
                echo "</table><br />";

                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Ime</th>";
                for ($Indx=1;$Indx <= $StDejavnosti;$Indx++){
                    echo "<th>".$VDejavnost[$Indx][0]."<br />".$VDejavnost[$Indx][1]."<br />U S N</th>";
                }
                echo "</tr>";

                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$VUcenci[$Indx][1]."</td>";
                    for ($i1=1;$i1 <= $StDejavnosti;$i1++){
                        if (Vsebuje($VUcenci[$Indx][0],$VDejavnost[$i1][2]) ){
                            echo "<td><input type='checkbox' checked='checked'>";
                        }else{
                            echo "<td><input type='checkbox'>";
                        }
                        if (Vsebuje($VUcenci[$Indx][0],$VDejavnost[$i1][4]) ){
                            echo "<input type='checkbox' checked='checked'>";
                        }else{
                            echo "<input type='checkbox'>";
                        }
                        if (Vsebuje($VUcenci[$Indx][0],$VDejavnost[$i1][5]) ){
                            echo "<input type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<input type='checkbox'></td>";
                        }
                    }
                    echo "</tr>";
                }
                echo "<tr><td>&nbsp;</td></tr>";
                $i2=1;
                for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                    $IzpisUcitelja=false;
                    for ($i1=1;$i1 <= $StDejavnosti;$i1++){
                        if ($VUcitelji[$Indx][0] > 0 ){
                            if (Vsebuje($VUcitelji[$Indx][0],$VDejavnost[$i1][3]) ){
                                $VDejavnost[$i1][4]=true;
                                $IzpisUcitelja=true;
                            }else{
                                $VDejavnost[$i1][4]=false;
                            }
                        }
                    }
                    if ($IzpisUcitelja){
                        echo "<tr>";
                        echo "<td>".$i2."</td>";
                        echo "<td>".$VUcitelji[$Indx][1]."</td>";
                        for ($i1=1;$i1 <= $StDejavnosti;$i1++){
                            if ($VUcitelji[$Indx][0] > 0 ){
                                if ($VDejavnost[$i1][4] ){
                                    echo "<td><input type='checkbox' checked='checked'></td>";
                                }else{
                                    echo "<td><input type='checkbox'></td>";
                                }
                            }
                        }
                        echo "</tr>";
                        $i2=$i2+1;
                    }
                }
                echo "</table><br />";
                echo "<a href='posebnidnevi.php?id=1&solskoleto=".$VLeto."&razred=".$VRazred."'>Vnos dnevov dejavnosti</a><br />";
                break;
            case "5": //dnevi dejavnosti koledar
                $SQL = "SELECT datum,kat FROM TabPraznik WHERE (leto=".$VLeto." AND mesec > 8) OR (leto=".($VLeto+1)." AND mesec < 9)";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    $Praznik[$Indx][1]=$R["kat"];
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;

                if (($VLeto+1) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                echo "<h2>Šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<table border=1 cellspacing=0>";
                echo "<tr><th></th>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    echo "<th>".$Indx."</th>";
                }
                echo "</tr>";
                for ($Indx=9;$Indx <= 12;$Indx++){
                    echo "<tr><td>".$Indx."</td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7;
                                echo "<td bgcolor=lightsalmon>";
                                break;
                            default:
                                switch (CheckPraznik($Datum)){
                                    case 0:
                                        echo "<td>";
                                        break;
                                    case 1:
                                        echo "<td bgcolor=lightgreen>";
                                        break;
                                    case 2:
                                        echo "<td bgcolor=lightblue>";
                                }
                        }
                        $SQL = "SELECT tabostaledej.id,tabostaledej.datum,tabostaledej.idrazred,tabaktivnosti.kratica,tabrazdat.razred,tabrazdat.oznaka FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . " WHERE tabostaledej.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY tabostaledej.IdAktivnost,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if (isDate($R["datum"])){
                                $DatComp=new DateTime(isDate($R["datum"]));
                                if ($Datum->format('d.m.Y')==$DatComp->format('d.m.Y')){
                                    echo "<a href='posebnidnevi.php?id=2&zapis=".$R["id"]."&razred=".$R["idrazred"]."&solskoleto=".$VLeto."'>".mb_substr($R["kratica"],0,2,$encoding)." - ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                                }
                            }
                        }
                        
                        echo "&nbsp;";
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                for ($Indx=1;$Indx <= 8;$Indx++){
                    echo "<tr><td>".$Indx."</td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime(($VLeto+1)."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7;
                                echo "<td bgcolor=lightsalmon>";
                                break;
                            default:
                                switch (CheckPraznik($Datum)){
                                    case 0:
                                        echo "<td>";
                                        break;
                                    case 1:
                                        echo "<td bgcolor=lightgreen>";
                                        break;
                                    case 2:
                                        echo "<td bgcolor=lightblue>";
                                }
                        }
                        $SQL = "SELECT tabostaledej.id,tabostaledej.datum,tabostaledej.idrazred,tabaktivnosti.kratica,tabrazdat.razred,tabrazdat.oznaka FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . " WHERE tabostaledej.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY tabostaledej.IdAktivnost,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if (isDate($R["datum"])){
                                $DatComp=new DateTime(isDate($R["datum"]));
                                if ($Datum->format('d.m.Y')==$DatComp->format('d.m.Y')){
                                    echo "<a href='posebnidnevi.php?id=2&zapis=".$R["id"]."&razred=".$R["idrazred"]."&solskoleto=".$VLeto."'>".mb_substr($R["kratica"],0,2,$encoding)." - ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                                }
                            }
                        }
                        
                        echo "&nbsp;";
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<a href='posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na spisek dnevov dejavnosti</a><br />";
                break;
            case "6": //dnevi dejavnosti leto - spisek
                $SQL = "SELECT * FROM TabPraznik WHERE (leto=".$VLeto." AND mesec > 8) OR (leto=".($VLeto+1)." AND mesec < 9)";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    $Praznik[$Indx][1]=$R["kat"];
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;

                if (($VLeto+1) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                echo "<h2>Šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<table border=1 cellspacing=0>";
                echo "<tr><th>Datum</th><th>Dejavnost, razred</th></tr>";
                for ($Indx=9;$Indx <= 12;$Indx++){
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7:
                                echo "<tr bgcolor='lightsalmon'><td>".$Indx1.".".$Indx.".</td>";
                                break;
                            default;
                                switch (CheckPraznik($Datum)){
                                    case 0:
                                        echo "<tr><td>".$Indx1.".".$Indx.".</td>";
                                        break;
                                    case 1:
                                        echo "<tr bgcolor='lightgreen'><td>".$Indx1.".".$Indx.".</td>";
                                        break;
                                    case 2:
                                        echo "<tr bgcolor='lightblue'><td>".$Indx1.".".$Indx.".</td>";
                                }
                        }
                        echo "<td>";
                        $SQL = "SELECT tabostaledej.*,tabostaledej.id AS did,tabaktivnosti.kratica,tabrazdat.* FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . " WHERE tabostaledej.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY tabostaledej.IdAktivnost,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if (isDate($R["Datum"])){
                                $DatComp=new DateTime(isDate($R["Datum"]));
                                if ($Datum->format('d.m.Y')==$DatComp->format('d.m.Y')){
                                    echo "<a href='posebnidnevi.php?id=2&zapis=".$R["did"]."&razred=".$R["idRazred"]."&solskoleto=".$VLeto."'>".mb_substr($R["kratica"],0,2,$encoding)." - ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                                }
                            }
                        }
                        
                        echo "&nbsp;";
                        echo "</td>";
                        echo "</tr>";
                    }
                }
                for ($Indx=1;$Indx <= 8;$Indx++){
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime(($VLeto+1)."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7:
                                echo "<tr bgcolor='lightsalmon'><td>".$Indx1.".".$Indx.".</td>";
                                break;
                            default;
                                switch (CheckPraznik($Datum)){
                                    case 0:
                                        echo "<tr><td>".$Indx1.".".$Indx.".</td>";
                                        break;
                                    case 1:
                                        echo "<tr bgcolor='lightgreen'><td>".$Indx1.".".$Indx.".</td>";
                                        break;
                                    case 2:
                                        echo "<tr bgcolor='lightblue'><td>".$Indx1.".".$Indx.".</td>";
                                }
                        }
                        echo "<td>";
                        $SQL = "SELECT tabostaledej.*,tabostaledej.id AS did,tabaktivnosti.kratica,tabrazdat.* FROM ";
                        $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                        $SQL = $SQL . " WHERE tabostaledej.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY tabostaledej.IdAktivnost,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if (isDate($R["Datum"])){
                                $DatComp=new DateTime(isDate($R["Datum"]));
                                if ($Datum->format('d.m.Y')==$DatComp->format('d.m.Y')){
                                    echo "<a href='posebnidnevi.php?id=2&zapis=".$R["did"]."&razred=".$R["idRazred"]."&solskoleto=".$VLeto."'>".mb_substr($R["kratica"],0,2,$encoding)." - ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                                }
                            }
                        }
                        
                        echo "&nbsp;";
                        echo "</td>";
                        echo "</tr>";
                    }
                }
                echo "</table><br />";
                echo "<a href='posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na spisek dnevov dejavnosti</a><br />";
                break;
            case "7": //dnevi dejavnosti - pregled
                $SQL = "SELECT tabostaledej.*,tabostaledej.id AS oid, tabaktivnosti.*,tabrazdat.* FROM ";
                $SQL = $SQL . "(tabostaledej INNER JOIN tabaktivnosti ON tabostaledej.IdAktivnost=tabaktivnosti.IdAktivnost) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabostaledej.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabostaledej.leto=".$VLeto." AND tabrazdat.leto=".$VLeto;
                $SQL = $SQL . " ORDER BY tabaktivnosti.IdAktivnost,tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);

                echo "<h2>Vnos dnevov dejavnosti</h2>";
                echo "<table border=1 cellspacing=0>";
                echo "<tr>";
                echo "<th>Leto</th><th>Razred</th><th>Aktivnost</th><th>Vsebina</th><th>Kraj</th><th>Datum<br />DD.MM.LLLL</th><th>Trajanje<br />čas od-do</th><th>Vodja</th><th>Cena [EUR]<br />na učenca</th><th>Subvencija<br />ministrstva [EUR]</th>";
                if ($VLevel > 1 ){
                    echo "<th>Briši</th><th>Popravi/Ogled<br />Tiskanje</th>";
                }
                echo "</tr>";

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    echo "<tr>";
                    echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>".$R["Opis"]."</td>";
                    echo "<td>".$R["Vsebina"]."</td>";
                    echo "<td>".$R["Kraj"]."</td>";
                    echo "<td>".$R["Datum"]."</td>";
                    echo "<td>".$R["Trajanje"]."</td>";
                    echo "<td>".$R["Vodja"]."</td>";
                    echo "<td>".$R["cena"]."</td>";
                    echo "<td>".$R["subvmss"]."</td>";
                    if ($VLevel > 1 ){
                        echo "<td><a href='posebnidnevi.php?id=8&zapis=".$R["oid"]."&razred=".$R["idRazred"]."&solskoleto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                        echo "<td><a href='posebnidnevi.php?id=1&zapis=".$R["oid"]."&razred=".$R["idRazred"]."&solskoleto=".$VLeto."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                    }
                    echo "</tr>";
                    $Indx = $Indx+1;
                }
                echo "</table><br />";
                echo "<a href='posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na spisek dnevov dejavnosti</a><br />";
                break;
            case "8": //brisanje
                $SQL = "DELETE FROM tabostaledej WHERE id=".$_GET["zapis"];
                $result = mysqli_query($link,$SQL);
                echo "<a href='posebnidnevi.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Nazaj na spisek dnevov dejavnosti</a><br />";
                break;
            
        }    
    }    
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
<script language="JavaScript">

function OznaciStolpec(obr,n){
    var vrstica=obr.elements['dan_'+n]
    
    if (vrstica != null) {
        for (i=0; i < vrstica.length; i++) {
            if (vrstica[i].checked){
                vrstica[i].checked=false;
            }else{
                vrstica[i].checked=true;
            }
        }
    }
}
</script>

</body>
</html>
