<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prenos
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }

        $uploaded=false;
        $allowedExts = array("txt", "csv");
        $Preneseno=$_FILES["file"];
        $extension = explode(".", $Preneseno["name"]);
        $extension = end($extension);
        $extension = strtolower($extension);
        if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain"))
            && ($_FILES["file"]["size"] < 500000)
            && in_array($extension, $allowedExts)){
                if ($_FILES["file"]["error"] > 0){
                    echo "Koda napake: " . $_FILES["file"]["error"] . "<br />";
                }else{
                    echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                    echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                    echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                    echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
             
                    if (file_exists("dato/" . $_FILES["file"]["name"])){
                        echo $_FILES["file"]["name"] . " že obstaja. <br />";
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }else{
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }
               }
        }else{
            echo "Napačna datoteka!";
        }
        echo "<br />";
        if ($uploaded){
            $myFile = "dato/".$_FILES["file"]["name"];
            $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
            $indx=0;
            while(!feof($fh)){
               //echo fgets($file). "<br />";
               $Vrstica[$indx]=fgets($fh);
               $indx=$indx+1;
            }
            $StVrstic=$indx-1;
            fclose($fh);

            $brisi = array("\"","\r\n");
            $i1=0;
            $indx0=0;
            while ($indx0 <= $StVrstic){
                if (mb_strlen($Vrstica[$indx0],$encoding) > 0){  //izpusti prazne vrstice
                    $VUcenec[$i1]=explode(";",$Vrstica[$indx0]);
                    for ($i=0;$i < count($VUcenec[$i1]);$i++){
                        $VUcenec[$i1][$i]=str_replace($brisi,"",$VUcenec[$i1][$i]);
                    }
                    $i1++;
                }
                $indx0++;
            }
            $StVrstic=$i1-1;

            //'pobriše stare izbirne in nivoje
            $SQL = "DELETE FROM TabIzbirni WHERE leto=".$VLeto;
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri brisanju podatkov o izbirnih predmetov!<br />$SQL<br />");
            }
            $SQL = "DELETE FROM TabNivoji WHERE leto=".$VLeto;
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri brisanju podatkov o nivojskih predmetih/skupinah!<br />$SQL<br />");
            }

            for ($indx=0;$indx <= $StVrstic;$indx++){
	            //'izpiše učenca
	            for ($indx0=0;$indx0 <= 10;$indx0++){
	                echo $VUcenec[$indx][$indx0].", ";
	            }
	            echo "<br />";
	            
	            //'prilagoditev podatkov
	            //'razred
	            if (mb_strlen($VUcenec[$indx][4],$encoding) > 0){
		            $VUcenec[$indx][17]=mb_substr($VUcenec[$indx][4],0,1,$encoding);
	            }else{
		            $VUcenec[$indx][17]=0;
	            }
	            //'paralelka
	            if (mb_strlen($VUcenec[$indx][4],$encoding)){
		            $VUcenec[$indx][18]=mb_substr($VUcenec[$indx][4],-(mb_strlen($VUcenec[$indx][4],$encoding)-1));
	            }else{
		            $VUcenec[$indx][18]="";
	            }
	            
	            //'predmet
	            switch ($VUcenec[$indx][2]){
		            case "1SLJ":
                    case "2SLJ":
                    case "3SLJ":
                    case "4SLJ":
                    case "5SLJ":
                    case "6SLJ":
                    case "1SLO":
                    case "2SLO":
                    case "3SLO":
                    case "4SLO":
                    case "5SLO":
                    case "6SLO":
			            $VIzbirni=mb_substr($VUcenec[$indx][2],0,1,$encoding)+5;
			            if ($VIzbirni > 8){
				            $VIzbirni=$VIzbirni+7;
			            }
			            $VUcenec[$indx][15]=$VIzbirni;
			            $VUcenec[$indx][16]=1; //' nivojski predmet
                        break;
		            case "1MAT":
                    case "2MAT":
                    case "3MAT":
                    case "4MAT":
                    case "5MAT":
                    case "6MAT":
			            $VIzbirni=mb_substr($VUcenec[$indx][2],0,1,$encoding)+1;
			            if ($VIzbirni > 4){
				            $VIzbirni=$VIzbirni+8;
			            }
			            $VUcenec[$indx][15]=$VIzbirni;
			            $VUcenec[$indx][16]=1; //' nivojski predmet
                        break;
		            case "1TJA":
                    case "2TJA":
                    case "3TJA":
                    case "4TJA":
                    case "5TJA":
                    case "6TJA":
			            $VIzbirni=mb_substr($VUcenec[$indx][2],0,1,$encoding)+9;
			            if ($VIzbirni > 12){
				            $VIzbirni=$VIzbirni+6;
			            }
			            $VUcenec[$indx][15]=$VIzbirni;
			            $VUcenec[$indx][16]=1; //' nivojski predmet
                        break;
		            default:
			            $SQL = "SELECT * FROM TabUntisPredm WHERE PredmetUntis='".$VUcenec[$indx][2]."'";
			            $result = mysqli_query($link,$SQL);
			            if ($R = mysqli_fetch_array($result)){
				            $VUcenec[$indx][15]=$R["idPredmet"];
				            $VUcenec[$indx][16]=0; //' izbirni predmet
			            }else{
				            echo "<font color='red'>Ne najdem predmeta: ".$VUcenec[$indx][2]."</font><br />";
				            $VUcenec[$indx][15]=0;
				            $VUcenec[$indx][16]=0; //' izbirni predmet
			            }
	            }
	            if (!is_numeric($VUcenec[$indx][15])){
		            $VUcenec[$indx][15]="0";
	            }

	            //'učenec
	            $SQL = "SELECT * FROM TabUntisUcenci WHERE UcenecUntis='".$VUcenec[$indx][0]."'";
	            $result = mysqli_query($link,$SQL);
                $niucenca=true;
	            while ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT iducenec FROM tabrazred WHERE leto=".$VLeto." AND iducenec=".$R["idUcenec"];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        $niucenca=false;
		                $VUcenec[$indx][14]=$R["idUcenec"];
	                
	                    if ($VUcenec[$indx][16]==1){
		                    //'nivojski predmet
		                    $SQL = "SELECT * FROM TabNivoji WHERE ucenec=".$VUcenec[$indx][14]." AND Nivoji=".$VUcenec[$indx][15]." AND leto=".$VLeto;
		                    $result1 = mysqli_query($link,$SQL);
		                    
		                    if ($R = mysqli_fetch_array($result1)){
			                    echo "Skupina je že vpisana!<br />";
		                    }else{
                                if ($VUcenec[$indx][15] > 0 && $VUcenec[$indx][14] > 0){
			                        $SQL = "INSERT INTO TabNivoji (Ucenec,Leto,Nivoji,Datum) VALUES (";
			                        $SQL = $SQL . $VUcenec[$indx][14].",";
			                        $SQL = $SQL . $VLeto.",";
			                        $SQL = $SQL . $VUcenec[$indx][15].",";
			                        $SQL = $SQL . "'".$Danes->format('Y-m-d H:i:s')."'";
			                        $SQL = $SQL .")";
			                        if (!($result2 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu: <br />".$SQL . "<br />";
                                    }
                                }
		                    }
	                    }else{
		                    //'izbirni predmet
		                    $SQL = "SELECT * FROM TabIzbirni WHERE ucenec=".$VUcenec[$indx][14]." AND Izbirni=".$VUcenec[$indx][15]." AND leto=".$VLeto;
		                    $result1 = mysqli_query($link,$SQL);
		                    
		                    if ($R = mysqli_fetch_array($result1)){
			                    echo "Izbirni je že vpisan!<br />";
		                    }else{
                                if ($VUcenec[$indx][15] > 0 && $VUcenec[$indx][14] > 0){
			                        $SQL = "INSERT INTO TabIzbirni (Ucenec,Leto,Izbirni) VALUES (";
			                        $SQL = $SQL . $VUcenec[$indx][14].",";
			                        $SQL = $SQL . $VLeto.",";
			                        $SQL = $SQL . $VUcenec[$indx][15];
			                        $SQL = $SQL .")";
                                    if (!($result2 = mysqli_query($link,$SQL))){
                                        echo "Napaka pri vpisu: <br />".$SQL . "<br />";
                                    }
                                }
		                    }
	                    }
                    }
                }
                if ($niucenca){
                    $VUcenec[$indx][14]=0;
                    echo "<font color='red'>Ne najdem učenca: ".$VUcenec[$indx][1]."</font><br />";
                }
	            
        //	    echo $SQL . "<br />";
            }
            echo "<h2>Izbirni in nivojski predmeti so uvoženi!</h2>";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>

</body>
</html>
