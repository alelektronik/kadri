<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Korekcija
</title>
</head>
<body>
<?php

$SQL = "SELECT * FROM tabucitelji";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    if (isset($R["EMSO"])){
        $DatRoj="-".substr($R["EMSO"],2,2) . "-".substr($R["EMSO"],0,2);
        if (intval(substr($R["EMSO"],4,3)) < 900 ){
            $DatRoj="2".substr($R["EMSO"],4,3).$DatRoj;
        }else{
            $DatRoj="1".substr($R["EMSO"],4,3).$DatRoj;
        }
        $SQL = "UPDATE tabucitelji SET DatRoj='".$DatRoj."' WHERE id=".$R["Id"];
        $result1 = mysqli_query($link,$SQL);
        echo "popravljeno vrstic - učitelji ".$DatRoj." (".$R["Id"]."): ".mysqli_affected_rows($link)."<br />";
    }
}
echo "<br />";
$SQL = "SELECT * FROM tabucenci";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    if (isset($R["emso"])){
        $DatRoj="-".substr($R["emso"],2,2) . "-".substr($R["emso"],0,2);
        if (intval(substr($R["emso"],4,3)) < 900 ){
            $DatRoj="2".substr($R["emso"],4,3).$DatRoj;
        }else{
            $DatRoj="1".substr($R["emso"],4,3).$DatRoj;
        }
        $SQL = "UPDATE tabucenci SET DatRoj='".$DatRoj."' WHERE id=".$R["ID"];
        $result1 = mysqli_query($link,$SQL);
        echo "popravljeno vrstic - učenci ".$DatRoj." (".$R["ID"]."): ".mysqli_affected_rows($link)."<br />";
    }
}

?>
</body>
</html>
