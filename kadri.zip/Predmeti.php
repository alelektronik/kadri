<?php
require ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vpisovanje predmetov in učiteljev za razrede
</title>
</head>
<body>
<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
//    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
echo "<br />";
echo "<a href='IzborUcitelja.php'>Izbor učitelja</a><br />";
echo "<a href='nacrtovanjedela.php'>Pregled po razredih</a><br />";

if (!CheckDostop("VnosSist",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["ZaPrikaz"])){
        $ucitelj = $_POST["ZaPrikaz"];
        if ($ucitelj == ""){
            if (isset($_SESSION["UciteljPredmet"])){
                $ucitelj=$_SESSION["UciteljPredmet"];
            }else{
                $ucitelj=0;
            }
        }
    }else{
        if (isset($_SESSION["UciteljPredmet"])){
            $ucitelj = $_SESSION["UciteljPredmet"];
        }else{
            $ucitelj = 0;
        }
    }
    if (isset($_GET["ucitelj"])){
        $ucitelj=$_GET["ucitelj"];
    }
    if (isset($_GET["dodanpredmet"])){
        $DodanPredmet = $_GET["dodanpredmet"];
    }else{
        if (isset($_SESSION["DodanPredmet"])){
            $DodanPredmet = $_SESSION["DodanPredmet"];
        }else{
            $DodanPredmet = 0;
        }
    }
    if (isset($_GET["dodanrazred"])){
        $VRazred = $_GET["dodanrazred"];
    }else{
        if (isset($_SESSION["DodanRazred"])){
            $VRazred = $_SESSION["DodanRazred"];
        }else{
            $VRazred = 0;
        }
    }
    if (isset($_SESSION["DodanaParalelka"])){
        $VParalelka = $_SESSION["DodanaParalelka"];
    }else{
        $VParalelka = "";
    }
    if (isset($_SESSION["DodanaDevetletka"])){
        $VDevetletka = $_SESSION["DodanaDevetletka"];
    }else{
        $VDevetletka = 9;
    }
    if (isset($_SESSION["DodanaIzvedba"])){
        $Izvedba = $_SESSION["DodanaIzvedba"];
    }else{
        $Izvedba = "";
    }
    if (isset($_SESSION["DodaneSkupine"])){
        $VSkupina = $_SESSION["DodaneSkupine"];
    }else{
        $VSkupina = "";
    }
    if (isset($_GET["dodaneure"])){
        $Ure=$_GET["dodaneure"];
    }else{
        if (isset($_SESSION["DodaneUre"])){
            $Ure=$_SESSION["DodaneUre"];
        }else{
            $Ure=0;
        }
    }
    if (isset($_SESSION["DodanMss"])){
        $mss = $_SESSION["DodanMss"];
    }else{
        $mss = 100;
    }
    if (isset($_SESSION["DodanObcina"])){
        $obcina = $_SESSION["DodanObcina"];
    }else{
        $obcina = 0;
    }
    if (isset($_SESSION["DodanDrugi"])){
        $drugi = $_SESSION["DodanDrugi"];
    }else{
        $drugi = 0;
    }
    if (isset($_GET["idsola"])){
        $VIdSola=$_GET["idsola"];
    }else{
        if (isset($_SESSION["idsola"])){
            $VIdSola = $_SESSION["idsola"];
        }else{
            $VIdSola = 1;
        }
    }
    echo "Učitelj: ".$ucitelj."<br />";

    if (isset($_POST["id"])){
        $id = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $id=$_GET["id"];
        }else{
            $id = 0;
        }
    }

    switch ($id){
        case 1: //dodaj nov zapis/-e
            $VLeto=$_POST["leto"];
            $VPredmet=$_POST["predmet"];
            $ucitelj=$_POST["ucitelj"];
            $VRazred=$_POST["razred"];
            //$VParalelka=$_POST["paralelka"];
            $VDevetletka=$_POST["vrstaos"];
            $VZdruzeno=$_POST["zdruzeno"];
            $VPlanirano=$_POST["planirano"];
            $VSkupina=$_POST["skupina"];
            $mss=$_POST["mss"];
            $obcina=$_POST["obcina"];
            $drugi=$_POST["drugi"];
            if (isset($_POST["idsola"])){
                $VIdSola=$_POST["idsola"];
            }else{
                $VIdSola=1;
            }
            
            if (!is_numeric($mss) ){ 
                $mss=0;
            }
            if (!is_numeric($obcina) ){ 
                $obcina=0;
            }
            if (!is_numeric($drugi)){ 
                $drugi=0;
            }
            if ($obcina==0 && $drugi==0) { 
                $mss=100;
            }

            $VPlanirano=str_replace(",",".",$VPlanirano);

            if ($VRazred > 0 ){
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VRazred=$R["id"];
                    $VIdSola=$R["idsola"];
                }else{
                    $VRazred1=$VRazred;
                    $VParalelka="";
                    $VRazred=0;
                }
                $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," . $ucitelj . "," . $VPredmet . "," . $VRazred1 . ",'" . $VParalelka . "'," . $VPlanirano . "," . $VZdruzeno . ",".$VDevetletka.",".$VSkupina.",".$mss.",".$obcina.",".$drugi.",".$VRazred.")";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die("Napaka pri vpisu podatkov:<br /> $SQL <br />".mysqli_error($link));
                }
            }else{
                //skupinsko vpisovanje, ko je označen cel letnik
                if (intval($VRazred) != 0){
                    //ko je izbran letnik: 1 - 9
                    $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred=".abs($VRazred)." AND idsola=".$VIdSola;
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                        $VRazred=$R["id"];
                        $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," . $ucitelj . "," . $VPredmet . "," . $VRazred1 . ",'" . $VParalelka . "'," . $VPlanirano . "," . $VZdruzeno . ",".$VDevetletka.",".$VSkupina.",".$mss.",".$obcina.",".$drugi.",".$VRazred.")";
                        $result1 = mysqli_query($link,$SQL);
                        if (!$result1){
                            die("Napaka pri vpisu podatkov:<br /> $SQL <br />".mysqli_error($link));
                        }
                    }
                }else{
                    //ko gre za dejavnost za celo šolo - 0
                    $VRazred1=abs($VRazred);
                    $VParalelka="";
                    $VRazred=0;
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," . $ucitelj . "," . $VPredmet . "," . $VRazred1 . ",'" . $VParalelka . "'," . $VPlanirano . "," . $VZdruzeno . ",".$VDevetletka.",".$VSkupina.",".$mss.",".$obcina.",".$drugi.",".$VRazred.")";
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov:<br /> $SQL <br />".mysqli_error($link));
                    }
                }
            }


            $_SESSION["zdruzeno"]=$VZdruzeno;
            $_SESSION["DodaneUre"]=$VPlanirano;
            $_SESSION["DodanaIzvedba"]=$VZdruzeno;
            $_SESSION["idsola"]=$VIdSola;
            $Izvedba=$VZdruzeno;
            $Ure=$VPlanirano;
            
            $VPlanirano="0.5";
            $VZdruzeno="1.5";
            
            //'primer razrednistva
            
            //stare vrednosti predmetov
            $sport=20;
            $lum=9;
            $gum=29;
            $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='ŠPO' AND opis='Šport'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $sport=$R["id"];
            }
            $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='LUM'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $lum=$R["id"];
            }
            $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='GUM'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $gum=$R["id"];
            }

            if ($VPredmet == 50 ){
                switch ($VRazred1){
                case 1:
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 16 . "," .$VRazred1 . ",'" .$VParalelka . "',6," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SLO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 11 . "," .$VRazred1 . ",'" .$VParalelka . "',4," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'MAT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 49 . "," .$VRazred1 . ",'" .$VParalelka . "',3," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SPO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $sport . "," .$VRazred1 . ",'" .$VParalelka . "',3," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $lum . "," .$VRazred1 . ",'" .$VParalelka . "',2," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'LVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $gum . "," .$VRazred1 . ",'" .$VParalelka . "',2," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'GVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 4 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOP
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 3 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOD
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    break;
                case 2:
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 16 . "," .$VRazred1 . ",'" .$VParalelka . "',7," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SLO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 11 . "," .$VRazred1 . ",'" .$VParalelka . "',4," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'MAT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 49 . "," .$VRazred1 . ",'" .$VParalelka . "',3," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SPO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $sport . "," .$VRazred1 . ",'" .$VParalelka . "',3," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $lum . "," .$VRazred1 . ",'" .$VParalelka . "',2," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'LVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $gum . "," .$VRazred1 . ",'" .$VParalelka . "',2," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'GVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 4 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOP
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 3 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOD
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    break;
                case 3:
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 16 . "," .$VRazred1 . ",'" .$VParalelka . "',7," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SLO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 11 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 5 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'MAT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 49 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SPO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $sport . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $lum . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'LVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $gum . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'GVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 4 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOP
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 3 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOD
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    break;
                case 4:
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 16 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 5 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SLO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 11 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 5 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'MAT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $lum . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'LVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 17 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DRU
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 14 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'NIT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $gum . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VZdruzeno . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'GVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 26 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'TJA
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $sport . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 4 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOP
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 3 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOD
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    break;
                case 5:
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 16 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 5 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SLO
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 11 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 4 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'MAT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $lum . "," .$VRazred1 . ",'" .$VParalelka . "'," . 2 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'LVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 17 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DRU
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 14 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'NIT
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $gum . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VZdruzeno . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'GVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 26 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'TJA
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . $sport . "," .$VRazred1 . ",'" .$VParalelka . "'," . 3 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 51 . "," .$VRazred1 . ",'" .$VParalelka . "'," . 1 . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'SVZ
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 4 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOP
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    $SQL = "INSERT INTO tabucenje (Leto,IdUcitelj,Predmet,Razred,Paralelka,Planirano,Zdruzeno,osemdevet,realizirano,mss,obcina,drugi,idRazred) values (" . $VLeto . "," .$ucitelj . "," . 3 . "," .$VRazred1 . ",'" .$VParalelka . "'," .$VPlanirano . "," . 0 . ",".$VDevetletka.",".$VSkupina.",100,0,0,".$VRazred.")";  //'DOD
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error($link));
                    }
                    break;
                }
            }

            //'response.write "<br>Uspešno ste vnesli podatke!<br>"
            $DodanPredmet=$VPredmet;
            $_SESSION["leto"]=$VLeto;
            $_SESSION["UciteljPredmet"]=$ucitelj;
            $_SESSION["DodanPredmet"]=$VPredmet;
            $_SESSION["DodanRazred"]=$VRazred;
            $_SESSION["DodanaParalelka"]=$VParalelka;
            $_SESSION["DodanaDevetletka"]=$VDevetletka;
            $_SESSION["DodaneSkupine"]=$VSkupina;
            $_SESSION["DodanMss"]=$mss;
            $_SESSION["DodanObcina"]=$obcina;
            $_SESSION["DodanDrugi"]=$drugi;
            break;
        case 2: //briši
            if (isset($_GET["id1"])){
                $id1=$_GET["id1"];
                $SQL = "SELECT tabucenje.* FROM tabucenje ";
                $SQL = $SQL . "WHERE id=".$id1;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VLeto = $R["Leto"];
                    $ucitelj = $R["IdUcitelj"];
                    $VDodanPredmet = $R["Predmet"];
                    $VRazred1 = $R["Razred"];
                    $VParalelka = $R["Paralelka"];
                    $VDevetletka = 9;
                    $Izvedba = $R["Zdruzeno"];
                    $VSkupina = $R["Realizirano"];
                    $Ure = $R["Planirano"];
                    $mss = $R["MSS"];
                    $obcina = $R["Obcina"];
                    $drugi = $R["Drugi"];
                    $VRazred = $R["idRazred"];
                }
                $_SESSION["leto"]=$VLeto;
                $_SESSION["UciteljPredmet"]=$ucitelj;
                $_SESSION["DodanPredmet"]=$VDodanPredmet;
                $_SESSION["DodanRazred"]=$VRazred;
                $_SESSION["DodanaParalelka"]=$VParalelka;
                $_SESSION["DodanaDevetletka"]=$VDevetletka;
                $_SESSION["DodaneSkupine"]=$VSkupina;
                $_SESSION["DodanMss"]=$mss;
                $_SESSION["DodanObcina"]=$obcina;
                $_SESSION["DodanDrugi"]=$drugi;

                $SQL = "DELETE FROM tabucenje WHERE id=".$id1;
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die("Napaka pri brisanju podatkov: ".mysqli_error($link));
                }
            }
            break;
        case 3: //popravi - obrazec
            if (isset($_GET["id1"])){
                $id1=$_GET["id1"];
                $SQL = "SELECT tabucenje.* FROM tabucenje ";
                $SQL = $SQL . "WHERE id=".$id1;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VLeto = $R["Leto"];
                    $ucitelj = $R["IdUcitelj"];
                    $DodanPredmet = $R["Predmet"];
                    $VRazred1 = $R["Razred"];
                    $VParalelka = $R["Paralelka"];
                    $VDevetletka = 9;
                    $Izvedba = $R["Zdruzeno"];
                    $VSkupina = $R["Realizirano"];
                    $Ure = $R["Planirano"];
                    $mss = $R["MSS"];
                    $obcina = $R["Obcina"];
                    $drugi = $R["Drugi"];
                    $VRazred = $R["idRazred"];
                }
            }
            break;
        case 4: //popravi obstoječe podatke
            if (isset($_POST["id1"])){
                $id1=$_POST["id1"];
                $VLeto=$_POST["leto"];
                $VPredmet=$_POST["predmet"];
                $ucitelj=$_POST["ucitelj"];
                $VRazred=$_POST["razred"];
                //$VParalelka=$_POST["paralelka"];
                $VDevetletka=$_POST["vrstaos"];
                $VZdruzeno=$_POST["zdruzeno"];
                $VPlanirano=$_POST["planirano"];
                $VSkupina=$_POST["skupina"];
                $mss=$_POST["mss"];
                $obcina=$_POST["obcina"];
                $drugi=$_POST["drugi"];
                if (isset($_POST["idsola"])){
                    $VIdSola=$_POST["idsola"];
                }else{
                    $VIdSola=1;
                }
                
                if (!is_numeric($mss) ){ 
                    $mss=0;
                }
                if (!is_numeric($obcina) ){ 
                    $obcina=0;
                }
                if (!is_numeric($drugi)){ 
                    $drugi=0;
                }
                if ($obcina==0 && $drugi==0) { 
                    $mss=100;
                }

                $VPlanirano=str_replace(",",".",$VPlanirano);
                if ($VRazred > 0 ){
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                        $VRazred=$R["id"];
                        $VIdSola=$R["idsola"];
                    }else{
                        $VRazred1=$VRazred;
                        $VParalelka="";
                        $VRazred=0;
                        $VIdSola=1;
                    }
                }else{
//                    $VRazred1=abs($VRazred)+($VIdSola-1)*10;
                    $VRazred1=abs($VRazred);
                    $VParalelka="";
                    $VRazred=0;
                }

                $SQL = "UPDATE tabucenje SET Leto=";
                $SQL = $SQL .$VLeto.",IdUcitelj=".$ucitelj.",Predmet=".$VPredmet.",Razred=".$VRazred1.",Paralelka='".$VParalelka."',Planirano=".$VPlanirano.",Zdruzeno=".$VZdruzeno.",osemdevet=".$VDevetletka.",realizirano=".$VSkupina.",mss=".$mss.",obcina=".$obcina.",drugi=".$drugi.",idRazred=".$VRazred." WHERE id=".$id1;
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    echo $SQL."<br />";
                    die("Napaka pri zapisu popravljenih podatkov: ".mysqli_error($link));
                }
                $Ure=$VPlanirano;
                $Izvedba=$VZdruzeno;
                $DodanPredmet=$VPredmet;
                $_SESSION["leto"]=$VLeto;
                $_SESSION["UciteljPredmet"]=$ucitelj;
                $_SESSION["DodanPredmet"]=$VPredmet;
                $_SESSION["DodaneUre"]=$VPlanirano;
                $_SESSION["DodanRazred"]=$VRazred;
                $_SESSION["DodanaParalelka"]=$VParalelka;
                $_SESSION["DodanaDevetletka"]=$VDevetletka;
                $_SESSION["DodaneSkupine"]=$VSkupina;
                $_SESSION["DodanaIzvedba"]=$VZdruzeno;
                $_SESSION["DodanMss"]=$mss;
                $_SESSION["DodanObcina"]=$obcina;
                $_SESSION["DodanDrugi"]=$drugi;
                $_SESSION["idsola"]=$VIdSola;
            }
            break;
        case 5: //prenese podatke enega učitelja drugemu
            if (isset($_POST["rubrik"])){
                $ucitelj=$_POST["ucitelj"];
                for ($i=1;$i <= $_POST["rubrik"];$i++){
                    if (isset($_POST["c_$i"])){
                        $SQL = "UPDATE tabucenje SET iducitelj=".$_POST["ucitelj"]." WHERE id=".$_POST["n_$i"];
                        $result = mysqli_query($link,$SQL);
                        if (!$result){
                            echo $SQL."<br />";
                            die("Napaka pri zapisu popravljenih podatkov: ".mysqli_error($link));
                        }
                    }
                }
            }
            break;
    }
    //'Izpis osebnih podatkov

    $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
    //'echo "<br>" & $SQL & "<br>"
    $Indx1=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
	    $VUcitelji[$Indx1][0] = $R["IdUcitelj"];
	    $VUcitelji[$Indx1][1] = $R["Priimek"];
	    $VUcitelji[$Indx1][2] = $R["Ime"];
	    $Indx1=$Indx1+1;
    }
    $VStUciteljev=$Indx1-1;
    
    $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." ORDER BY idsola,razred,oznaka";
    $indx=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
	    $VRazredi[$indx][0]=$R["id"];
	    $VRazredi[$indx][1]=$R["razred"];
	    $VRazredi[$indx][2]=$R["oznaka"];
	    $VRazredi[$indx][3]=$R["leto"];
        $VRazredi[$indx][4]=$R["solakratko"];
        $VRazredi[$indx][5]=$R["idsola"];
	    $indx=$indx+1;
    }
    $VStRazredov=$indx-1;

    $SQL = "SELECT * FROM tabpredmeti  ORDER BY Opis";
    $Indx=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
	    $VPredmeti[$Indx][0] = $R["Id"];
	    $VPredmeti[$Indx][1] = $R["Oznaka"];
	    $VPredmeti[$Indx][2] = $R["Opis"];
	    $VPredmeti[$Indx][3] = $R["Prioriteta"];
	    $Indx=$Indx+1;
    }
    $VStPredmetov=$Indx-1;
    
    $SQL = "SELECT id,solakratko FROM tabsola";
    $Indx=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        $sola[$Indx][0] = $R["id"];
        $sola[$Indx][1] = $R["solakratko"];
        $Indx=$Indx+1;
    }
    $VStSol=$Indx-1;
    
    if ($VRazred > 0){
        $SQL = "SELECT idsola FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VIdSola=$R["idsola"];
        }else{
            $VIdSola=1;
        }
    }
    
    echo "<h2>Vpis predmetnika po razredih</h2>";
    echo "<form accept-charset='utf-8'  name='Predmetnik' method=post action='Predmeti.php'>";
    echo "Pokaži učitelja: <select name='ZaPrikaz' onchange='this.form.submit()'>";
    echo "<option value='0'>Ni izbran</option>";
    for ($Indx2=0;$Indx2 <= $VStUciteljev;$Indx2++){
	    if ($VUcitelji[$Indx2][0] == $ucitelj ) {
		    echo "<option value=" . $VUcitelji[$Indx2][0] . " selected='selected'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
	    }else{
		    echo "<option value=" . $VUcitelji[$Indx2][0] . ">" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
	    }
    }
    echo "</select>";
    //echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form><br />";
    echo "Izbor <b>nivojski</b> predmet pomeni, da se bodo dodeljene ure štele enkrat, ko bodo dodeljene dvema razredoma. Pri <b>izbirnih</b> predmetih pa velja, da se štejejo enkrat ne glede na to, koliko razredom ste predmet dodelili.<br /><b>Druge</b> dejavnosti uporabite za predmete, ki niso glavni in izbirni (OPB, razredne ure, ...).<br />";
    echo "Če ne morete izbrati razredov (paralelk), jih morate najprej <a href='VpisiRazred.php'>dodati</a>.<br />";
    echo "Razred 0. je mišljeno, da se dogaja splošno za vse (knjižničar, računalnikar, vodja prehrane, ... - za tiste, ki imajo delež zaposlitve).<br />";
    //echo " Izbira razreda brez paralelka je namenjena za tiste dejavnosti, ki so namenjene vsem paralelkam (dodatni in dopolnilni pouk, ...).<br />";
    echo " V primeru izbire razreda brez paralelka, se bo pouk vpisal vsem paralelkam izbranega letnika.<br />";
    echo "<br />";
    
    echo "<form accept-charset='utf-8'  name='Predmetnik' method='post' action='Predmeti.php'>";
    echo "<table border='1'>";
    echo "<th>Leto</th><th>Učitelj</th><th>Predmet</th><th>Razred</th>";
    echo "<tr>";
    echo "<td><select name='leto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select></td>";
    echo "<td><select name='ucitelj'>";
    echo "<option value='0'>Ni izbran</option>";
    for ($Indx2=0;$Indx2 <= $VStUciteljev;$Indx2++){
	    if ($VUcitelji[$Indx2][0]==$ucitelj ) {
            echo "<option value=" . $VUcitelji[$Indx2][0] . " selected='selected'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
	    }else{
            echo "<option value=" . $VUcitelji[$Indx2][0] . ">" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
	    }
    }
    echo "</select></td>";
    echo "<td><select name='predmet'>";
    for ($Indx1=0;$Indx1 <= $VStPredmetov;$Indx1++){
	    if ($VPredmeti[$Indx1][0]==$DodanPredmet ) {
		    echo "<option value=" . $VPredmeti[$Indx1][0] . " selected='selected'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
	    }else{
            echo "<option value=" . $VPredmeti[$Indx1][0] . ">" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
	    }
    }
    echo "</select></td>";

    echo "<td><select name='razred'>";
    if ($VecSol > 0){
        for ($indx=0;$indx <= $VStRazredov;$indx++){
	        if ($VRazred==$VRazredi[$indx][0] ) {
		        echo "<option value='".$VRazredi[$indx][0]."' selected='selected'>".$VRazredi[$indx][1].". ".$VRazredi[$indx][2]." - ".$VRazredi[$indx][4]."</option>";
	        }else{
                echo "<option value='".$VRazredi[$indx][0]."'>".$VRazredi[$indx][1].". ".$VRazredi[$indx][2]." - ".$VRazredi[$indx][4]."</option>";
	        }
        }
    }else{
        for ($indx=0;$indx <= $VStRazredov;$indx++){
            if ($VRazred==$VRazredi[$indx][0] ) {
                echo "<option value='".$VRazredi[$indx][0]."' selected='selected'>".$VRazredi[$indx][1].". ".$VRazredi[$indx][2]."</option>";
            }else{
                echo "<option value='".$VRazredi[$indx][0]."'>".$VRazredi[$indx][1].". ".$VRazredi[$indx][2]."</option>";
            }
        }
    }
    for ($indx=0;$indx <= 9;$indx++){
	    if ($VRazred == -$indx ) {
		    echo "<option value='".(-$indx)."' selected='selected'>".$indx.". </option>";
	    }else{
		    echo "<option value='".(-$indx)."'>".$indx.". </option>";
	    }
    }
    echo "</select><input name='vrstaos' type='hidden' value='9'></td>";

    if ($VecSol > 0){
        echo "<td><select name='idsola'>";
        for ($Indx1=0;$Indx1 <= $VStSol;$Indx1++){
            if ($sola[$Indx1][0]==$VIdSola ) {
                echo "<option value=" . $sola[$Indx1][0] . " selected='selected'>" . $sola[$Indx1][1] ."</option>";
            }else{
                echo "<option value=" . $sola[$Indx1][0] . ">" . $sola[$Indx1][1] . "</option>";
            }
        }
        
        echo "</select></td>";
    }
    
    echo "</tr></table><br />";
    echo "<table border='1'>";
    echo "<th>Planirane ure</th><th>Izvedba pouka</th><th>Skupine</th><th>%MŠŠ</th><th>%Občina</th><th>%Drugi</th>";
    echo "<tr>";

    echo "<td><input name='planirano' type='text' size='5' value='".$Ure."'></td>";
    echo "<td><select name='zdruzeno'>";

    if ($Izvedba == 0){
        echo "<option value='0' selected='selected'>Samostojen predmet</option>";
    }else{
        echo "<option value='0'>Samostojen predmet</option>";
    }
    if ($Izvedba == 1){
            echo "<option value='1' selected='selected'>Nivojski predmet</option>";
    }else{
            echo "<option value='1'>Nivojski predmet</option>";
    }
    if ($Izvedba == 2){
            echo "<option value='2' selected='selected'>Izbirni predmet</option>";
    }else{
            echo "<option value='2'>Izbirni predmet</option>";
    }
    if ($Izvedba == 3){
            echo "<option value='3' selected='selected'>Druge dejavnosti</option>";
    }else{
            echo "<option value='3'>Druge dejavnosti</option>";
    }
    if ($Izvedba == 4){
            echo "<option value='4' selected='selected'>1. nivo</option>";
    }else{
            echo "<option value='4'>1. nivo</option>";
    }
    if ($Izvedba == 5){
            echo "<option value='5' selected='selected'>2. nivo</option>";
    }else{
            echo "<option value='5'>2. nivo</option>";
    }
    if ($Izvedba == 6){
            echo "<option value='6' selected='selected'>3. nivo</option>";
    }else{
            echo "<option value='6'>3. nivo</option>";
    }
    if ($Izvedba == 7){
            echo "<option value='7' selected='selected'>Drugi učitelj</option>";
    }else{
            echo "<option value='7'>Drugi učitelj</option>";
    }
    echo "</select></td>";

    echo "<td><select name='skupina'>";

    switch ($VSkupina){
	    case 0:
		    echo "<option value='0' selected>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 1:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1' selected='selected'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 2:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2' selected='selected'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 3:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3' selected='selected'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 4:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4' selected='selected'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 5:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5' selected='selected'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
            break;
	    case 6:
		    echo "<option value='0'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6' selected='selected'>6. skupina</option>";
            break;
	    default:
		    echo "<option value='0' selected='selected'>Ni skupin</option>";
		    echo "<option value='1'>1. skupina</option>";
		    echo "<option value='2'>2. skupina</option>";
		    echo "<option value='3'>3. skupina</option>";
		    echo "<option value='4'>4. skupina</option>";
		    echo "<option value='5'>5. skupina</option>";
		    echo "<option value='6'>6. skupina</option>";
    }
    echo "</select></td>";
    echo "<td><input name='mss' type=text size=3 value=".$mss."></td>";
    echo "<td><input name='obcina' type=text size=3 value=".$obcina."></td>";
    echo "<td><input name='drugi' type=text size=3 value=".$drugi."></td>";
    echo "</tr></table>";
    switch ($id){
        case 3:
            echo "<input name='id' type='hidden' value='4'>";
            echo "<input name='id1' type='hidden' value='".$id1."'>";
            echo "<input name='submit' type='submit' value='Popravi'>";
            break;
        default:
            echo "<input name='id' type='hidden' value='1'>";
            echo "<input name='submit' type='submit' value='Dodaj'>";
    }
    echo "</form>";    

    if ($ucitelj > 0 ) {	
	    echo "<br><br>";

        echo "<form accept-charset='utf-8'  name='Predmetnik2' method='post' action='Predmeti.php'>";
        echo "<input type='hidden' name='id' value='5'>";
        echo "<input type='hidden' name='uciteljod' value='$ucitelj'>";
        echo "<table border='1' cellspacing='0'>";
        if ($VLevel < 2) {
            echo "<tr bgcolor='lightcyan'><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th></tr>";
        }else{
            echo "<tr bgcolor='lightcyan'><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th><th>Briši</th><th>Popravi</th><th>Prenesi</th></tr>";
        }

        $SkupajUre=0;
        $BZdruzevanje=false;
        $BZdruzevanje1=false;
        $StEnakih=30;
        for ($Indx=0;$Indx <= $StEnakih;$Indx++){
            $izbirni[$Indx]=0;
            $Nivoji[1][$Indx]=0;
            $Nivoji[2][$Indx]=0;
            $Nivoji[3][$Indx]=0;
            $Nivoji[4][$Indx]=0;
            $Nivoji[5][$Indx]=0;
            $Nivoji[6][$Indx]=0;
        }

        $StIzbirni=0;

        $ColorChange1=true;
        $Indx=1;
        $SQL = "SELECT tabucenje.*, tabpredmeti.Oznaka, tabpredmeti.Opis FROM tabpredmeti ";
        $SQL .= "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet ";
        $SQL .= "WHERE iducitelj=" . $ucitelj ." AND leto=".$VLeto;
        $SQL .= " ORDER BY  tabpredmeti.Oznaka,tabucenje.Razred,tabucenje.Paralelka,tabucenje.osemdevet";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($ColorChange1 ){
                echo "<tr bgcolor='lightyellow'><td>" . $R["Oznaka"] ." - " . $R["Opis"] ."</td>";
                if ($VecSol > 0){
                    if (strlen($R["Paralelka"]) > 0){
                        echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"];
                        //če je vezano na razred
                        $SQL = "SELECT solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.id=".$R["idRazred"];
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo " - ".$R1["solakratko"];
                        }
                    }else{
                        //če je vezano na skupino razredov ali šolo
                        $VIdSola=intval($R["Razred"]/10+1);
                        $razred=$R["Razred"] % 10;
                        $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo "<td align='right'>" . $razred . ". ";
                            echo " - ".$R1["solakratko"];
                        }
                    }
                    echo "</td>";
                }else{
                    echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td>";
                }
                echo "<td align='right'>" . $R["Planirano"] ."</td>";
            }else{
                echo "<tr bgcolor=#FFFFCC><td>" . $R["Oznaka"] ." - " . $R["Opis"] ."</td>";
                if ($VecSol > 0){
                    if (strlen($R["Paralelka"]) > 0){
                        echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"];
                        //če je vezano na razred
                        $SQL = "SELECT solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.id=".$R["idRazred"];
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo " - ".$R1["solakratko"];
                        }
                    }else{
                        //če je vezano na skupino razredov ali šolo
                        $VIdSola=intval($R["Razred"]/10+1);
                        $razred=$R["Razred"] % 10;
                        $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo "<td align='right'>" . $razred . ". ";
                            echo " - ".$R1["solakratko"];
                        }
                    }
                    echo "</td>";
                }else{
                    echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td>";
                }
                echo "<td align='right'>" . $R["Planirano"] ."</td>";
            }
            $ColorChange1=!$ColorChange1;
            switch ($R["Zdruzeno"]){
                case 1:
                    echo "<td>Združevanje/nivoji</td>";
                    $BZdruzevanje= !$BZdruzevanje;
                    if ($BZdruzevanje){
                        $SkupajUre=$SkupajUre-$R["Planirano"];
                     }
                     break;
                case 2;
                    echo "<td>Izbirne vsebine</td>";
                    $StIzbirni=0;
                    while ($StIzbirni < $StEnakih){
                        if ($izbirni[$StIzbirni]==$R["Predmet"]."_".$R["Realizirano"] ){
                            $SkupajUre=$SkupajUre-$R["Planirano"];
                            break;
                        }
                        $StIzbirni=$StIzbirni+1;
                    }
                    if ($StIzbirni==$StEnakih){
                        $StIzbirni=0;
                        while ($StIzbirni < $StEnakih){
                            if ($izbirni[$StIzbirni]==0 ){
                                $izbirni[$StIzbirni]=$R["Predmet"]."_".$R["Realizirano"];
                                break;
                            }
                            $StIzbirni=$StIzbirni+1;
                        }
                    }
                    break;
                case 4:
                case 5:
                case 6:
                    if ($R["Realizirano"] > 0 ){
                        echo "<td>".($R["Zdruzeno"]-3).". nivo, skupina ".$R["Realizirano"]."</td>";
                    }else{
                        echo "<td>".($R["Zdruzeno"]-3).". nivo</td>";
                    }            
                    $StNivoji[$R["Zdruzeno"]]=0;
                    while ($StNivoji[$R["Zdruzeno"]] < $StEnakih ){
                        if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==$R["Predmet"].$R["Realizirano"] ){
                            $SkupajUre=$SkupajUre-$R["Planirano"];
                            break;
                        }
                        $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                    }
                    if ($StNivoji[$R["Zdruzeno"]]==$StEnakih ){
                        $StNivoji[$R["Zdruzeno"]]=0;
                        while ($StNivoji[$R["Zdruzeno"]] < $StEnakih ){
                            if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==0 ){
                                $Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]=$R["Predmet"].$R["Realizirano"];
                                break;
                            }
                            $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                        }
                    }
                    break;
                case 0:
                    echo "<td>&nbsp;</td>";
                    break;
                case 3;
                    echo "<td>&nbsp;</td>";
                    break;
                case 7:
                    echo "<td>Drugi učitelj</td>";
            }
                
            echo "<td>".$R["Realizirano"]."</td>";   //skupina

            if ($VLevel > 1 ){
                echo "<td align='center'><a href='Predmeti.php?id=2&id1=".$R["Id"]."'>B</a></td>";
                echo "<td align='center'><a href='Predmeti.php?id=3&id1=".$R["Id"]."'>P</a></td>";
                echo "<td align='center'><input type='checkbox' name='c_$Indx'><input type='hidden' name='n_$Indx' value='".$R["Id"]."'></td>";
            }
            echo "</tr>";
            $SkupajUre=$SkupajUre+$R["Planirano"];
            $Indx=$Indx+1;
        }
        echo "<tr bgcolor='lightgrey'><td>Skupaj ur</td><td></td><td align='right'><b>" . $SkupajUre . "</b></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>";

        echo "<select name='ucitelj'>";
        echo "<option value='0'>Ni izbran</option>";
        for ($Indx2=0;$Indx2 <= $VStUciteljev;$Indx2++){
            echo "<option value=" . $VUcitelji[$Indx2][0] . ">" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
        }
        echo "</select><br />";
        
        echo "<input type='hidden' name='rubrik' value='".($Indx-1)."'>";
        echo "<input type='submit' name='submit' value='Dodeli'></td></tr>";
        echo "</table><br />";
        echo "</form>";    

        if ($EvidencaPrisotnosti==1){
            echo "<br>";
            echo "Sistemizacija del in nalog:<br />";
            $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$ucitelj;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if (strlen($R["Sistemizacija"]) > 0 ){
                    $SQL = "SELECT * FROM TabSistemizacija WHERE idSistemizacija IN (".$R["Sistemizacija"].") ORDER BY idSistemizacija";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        echo "<a href='".$R["Povezava"]."' target='_blank'>".$R["Opis"]."</a><br />";
                    }
                }
            } 
            echo "<br />";
        }
        
    }
}	
?>

</body>
</html>
