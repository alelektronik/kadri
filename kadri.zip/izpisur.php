<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Urnik
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            //dateFormat:"%Y%m%d",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2012,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            //dateFormat:"%Y%m%d",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2012,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

if (isset($_POST["predmet"])){
    $predmet=$_POST["predmet"];
}else{
    $predmet=0;
}
$SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
$result = mysqli_query($link,$SQL);

$Indx=0;
while ($R = mysqli_fetch_array($result)){
    $VPredmeti[$Indx][0] = $R["id"];
    $VPredmeti[$Indx][1] = $R["oznaka"];
    $VPredmeti[$Indx][2] = $R["opis"];
    $VPredmeti[$Indx][3] = $R["prioriteta"];
    $Indx=$Indx+1;
}
$StPredmetov=$Indx-1;

$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
//echo "<br />" & SQL & "<br />"
$result = mysqli_query($link,$SQL);
$Indx1=0;
while ($R = mysqli_fetch_array($result)){
    $VUcitelji[$Indx1][0] = $R["iducitelj"];
    $VUcitelji[$Indx1][1] = $R["priimek"];
    $VUcitelji[$Indx1][2] = $R["ime"];
    $Indx1=$Indx1+1;
}
$StUciteljev=$Indx1-1;
echo "<br /><form  name='Urnik' method=post action='izpisur.php'>";
echo "<input type=hidden name='id' value='1'>";
echo "<select name='predmet' onchange='this.form.submit()'>";
echo "<option value='0'>Ni izbran</option>";
for ($i=0;$i <= $StPredmetov;$i++){
    if ($predmet==$VPredmeti[$i][0]){
        echo "<option value='".$VPredmeti[$i][0]."' selected='selected'>".$VPredmeti[$i][1]." - ".$VPredmeti[$i][2]."</option>";
    }else{
        echo "<option value='".$VPredmeti[$i][0]."'>".$VPredmeti[$i][1]." - ".$VPredmeti[$i][2]."</option>";
    }
}
echo "</select><br />";
echo "</form>";

$SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.idrazred,tabpredmeti.oznaka,tabpredmeti.opis,tabucitelji.ime,tabucitelji.priimek FROM (taburnik ";
$SQL .= "INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id) ";
$SQL .= "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.iducitelj ";
$SQL .= "WHERE od <= ".$Danes->format('Ymd')." AND do >= ".$Danes->format('Ymd')." AND predmet=".$predmet;
$SQL .= " ORDER BY priimek,ime,danvtednu,ura";
$result = mysqli_query($link,$SQL);
$Indx=1;
echo "<table border='1' cellspacing='1' cellpadding='0'>";
echo "<tr><th>št.</th><th>učitelj</th><th>predmet</th><th>dan</th><th>ura</th><th>razred</th></tr>";
while ($R = mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>$Indx</td>";
    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
    echo "<td>".$R["oznaka"]."</td>";
    echo "<td>".Int2Dan($R["danvtednu"])."</td>";
    echo "<td>".$R["ura"]."</td>";
    if ($R["idrazred"] > 0){
        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=".$R["idrazred"];
        $result1 = mysqli_query($link,$SQL);
        if ($R1 = mysqli_fetch_array($result1)){
            echo "<td>".$R1["razred"].$R1["oznaka"]."</td>";
        }
    }
    echo "</tr>";
    $Indx++;
}
echo "</table>";
?>

</body>
</html>
