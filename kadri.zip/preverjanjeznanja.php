<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
    };
</script>
<title>Preverjanje znanja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_POST["idd"])){
    $Vnos = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $Vnos=$_GET["idd"];
    }else{
        $Vnos = "1";
    }
}
$izvedi=true;
if ($Vnos=="1"){
    if (isset($_SESSION["Uporabnik"])){
        $VUporabnik = $_SESSION["Uporabnik"];
    }else{
        $VUporabnik = "";
    }
    if (isset($_SESSION["Geslo"])){
        $VGeslo = $_SESSION["Geslo"];
    }else{
        $VGeslo = "";
    }
    if (isset($_SESSION["Level"])){
        $VLevel = $_SESSION["Level"];
    }else{
        $VLevel = 0;
    }

    if ($VUporabnik == ""){
        $izvedi=false;
        header("Location: nepooblascen.htm");
    }else{
    
        $SQL = "SELECT IdUcitelj,Ime,Priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $Prijavljeni=$R["IdUcitelj"];
            $VIdRazrednik=$R["IdUcitelj"];
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
            //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
            //echo "Bil sem tu!";
        }else{
            echo "Nimate potrebnih pooblastil za ogled strani!";
            $izvedi=false;
            header("Location: nepooblascen.htm");
        }
    }
}
if ($izvedi){

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = "";
        }
    }

    if (isset($_POST["razred"])){
        $VRazred = $_POST["razred"];
    }else{
        if (isset($_GET["razred"])){
            $VRazred=$_GET["razred"];
        }else{
            if (isset($_SESSION["razred"])){
                $VRazred=$_SESSION["razred"];
            }else{
                $VRazred = 0;
            }
        }
    }

    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VRazred1=$R["razred"];
        $VParalelka=$R["oznaka"];
    }

    switch ($Vnos){
        case "1":
            if (CheckDostop("VnosUcDat",$VUporabnik) ) {
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='preverjanjeznanja.php?idd=2'>Izpis datumov pisnega ocenjevanja znanja</a><br>";

                switch($Vid){ 
                    case "1": //vpis preverjanja
                        $Ucitelj=$_POST["ucitelj"];
                        $VPredmet=$_POST["predmet"];
                        if (isset($_POST["datum"])){
                            $VDatum=$_POST["datum"];
                        }else{
                            $VDatum=$Danes->format('d.m.Y');
                        }
                        $VZapSt=$_POST["ZapSt"];
                        $_SESSION["kontrolkaucitelj"]=$Ucitelj;
                        $_SESSION["kontrolkapredmet"]=$VPredmet;
                        $_SESSION["kontrolkarazred"]=$VRazred;
                        
                        $SQL = "SELECT id FROM tabpreverjanje WHERE idRazred=".$VRazred." AND predmet=".$VPredmet." AND ZapSt='".$VZapSt."' AND idUcitelj=".$Ucitelj;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            if (($VLevel > 1) or (($VLevel < 2) && ($VUporabnik=$R["vpisal"]))){
                                if (isDate($VDatum)){
                                    $Datum=new DateTime(isDate($VDatum));
                                    $SQL="UPDATE tabpreverjanje SET datum='".$Datum->format('d.m.Y')."' WHERE id=".$R["id"];
                                    $result = mysqli_query($link,$SQL);
                                }else{
                                    echo "Format datuma ni pravilen: DD.MM.LLLL <br />";
                                }
                            }else{
                                echo "Nimate pravice spreminjati te podatke!<br />";
                            }
                        }else{
                            if (strlen($VZapSt)==0){ 
                                $VZapSt="1";
                            }
                            if (isDate($VDatum)){
                                $Datum=new DateTime(isDate($VDatum));
                                $SQL="INSERT INTO tabpreverjanje (leto,razred,paralelka,predmet,ZapSt,idUcitelj,datum,vpisal,cas,idRazred) VALUES (".$VLeto.",".$VRazred1.",'".$VParalelka."',".$VPredmet.",'".$VZapSt."',".$Ucitelj.",'".$Datum->format('d.m.Y')."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VRazred.")";
                                $result = mysqli_query($link,$SQL);
                            }else{
                                echo "Format datuma ni pravilen: DD.MM.LLLL <br />";
                            }
                            
                            if ($Opravila==1){
                                $SQL = "SELECT tabdeldogodek.id AS did FROM ";
                                $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                                $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos datumov pisnih ocenjevanj znanja' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                                $result = mysqli_query($link,$SQL);

                                $Indx=1;
                                while ($R = mysqli_fetch_array($result)){
                                    $VDogodki[$Indx]=$R["did"];
                                    $Indx=$Indx+1;
                                }
                                $StDogodkov=$Indx-1;

                                for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                                    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                                    $result = mysqli_query($link,$SQL);
                                }
                            }
                        }
                        break;
                    case "2": //popravljanje vnosa
                        $SQL = "SELECT tabpreverjanje.iducitelj,tabpreverjanje.predmet,tabpreverjanje.zapst,tabpreverjanje.datum,tabpreverjanje.id AS pid,tabrazdat.id AS rid,tabrazdat.razred,tabrazdat.oznaka FROM ";
                        $SQL = $SQL . "tabpreverjanje INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabpreverjanje.id=".$_GET["popravi"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VRazred1=$R["razred"];
                            $VRazred=$R["rid"];
                            $Ucitelj=$R["iducitelj"];
                            $VParalelka=$R["oznaka"];
                            $VPredmet=$R["predmet"];
                            $VZapSt=$R["zapst"];
                            $Vidprev=$R["pid"];
                            $VDatum=$R["datum"];
                        }
                        $_SESSION["kontrolkaucitelj"]=$Ucitelj;
                        $_SESSION["kontrolkapredmet"]=$VPredmet;
                        $_SESSION["kontrolkarazred"]=$VRazred;
                        
                        echo "<form name='form_PopraviPreverjanja' method=post action='preverjanjeznanja.php'>";
                        echo "<input name='idd' type='hidden' value='1'>";
                        echo "<table border=1 cellspacing=0>";
                        echo "<tr><th>Leto</th><th>Razred</th><th>Predmet</th><th>Zap.št.<br />preverjanja</th><th>Učitelj</th><th>Datum</th></tr>";
                        echo "<tr>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        
                        echo "<td><select name='razred'>";
                        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ";
                        $SQL .= "tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL .= "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($VecSol > 0){
                                if ($VRazred==$R["id"]){
                                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }else{
                                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }
                            }else{
                                if ($VRazred==$R["id"]){
                                    echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                                }else{
                                    echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                                }
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='predmet'>";
                        $SQL = "SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($VPredmet==$R["id"]){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["opis"]." (".$R["oznaka"].")"."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")"."</option>";
                            }
                        }
                        echo "</select></td>";
                        
                        echo "<td><input name='ZapSt' type='text' size='2' value='".$VZapSt."'></td>";

                        echo "<td><select name='ucitelj'>";
                        $SQL = "SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($Ucitelj==$R["iducitelj"]){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }
                        echo "</select></td>";

                        if (isDate($VDatum)){
                            $Datum=new DateTime(isDate($VDatum));
                            echo "<td><input id='dat01' name='datum' type='text' size='10' value='".$Datum->format('d.m.Y')."' /></td>";
                            //echo "<td><input name='datum' type='text' size='10' value='".$Datum->format('d.m.Y')."' /></td>";
                        }else{
                            echo "<td><input id='dat01' name='datum' type='text' size='10' value='' /></td>";
                            //echo "<td><input name='datum' type='text' size='10' value='' /></td>";
                        }
                        echo "</tr>";
                        echo "</table>";
                        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                        echo "<input name='id' type='hidden' value='4'>";
                        echo "<input name='idprev' type='hidden' value='".$Vidprev."'>";
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form>";
                        break;
                    case "3": //brisanje preverjanja
                        $SQL = "SELECT tabpreverjanje.*,TabUcitelji.uporabnik FROM tabpreverjanje INNER JOIN TabUcitelji ON tabpreverjanje.idUcitelj=TabUcitelji.idUcitelj WHERE tabpreverjanje.id=".$_GET["brisi"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            if (($VLevel >1) or (($VLevel < 2) && ($VUporabnik==$R["uporabnik"]))){
                                $SQL = "DELETE FROM tabpreverjanje WHERE id=".$_GET["brisi"];
                                $result = mysqli_query($link,$SQL);
                            }else{
                                echo "Nimate pravice brisanja!<br />";
                            }
                        }else{
                            echo "Zapis ne obstaja!<br />";
                        }
                        break;
                    case "4": //popravljanje preverjanja
                        $SQL = "SELECT tabpreverjanje.id,tabpreverjanje.vpisal FROM tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=TabUcitelji.idUcitelj WHERE tabpreverjanje.id=".$_POST["idprev"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$_POST["ucitelj"];
                            $VPredmet=$_POST["predmet"];
                            $Vidprev=$_POST["idprev"];
                            $VDatum=$_POST["datum"];
                            $_SESSION["kontrolkaucitelj"]=$Ucitelj;
                            $_SESSION["kontrolkapredmet"]=$VPredmet;
                            $_SESSION["kontrolkarazred"]=$VRazred;
                            if (isDate($VDatum)){
                                $Datum=new DateTime(isDate($VDatum));
                                if (($VLevel >1) or (($VLevel < 2) && ($VUporabnik==$R["vpisal"]))){
                                    $SQL="UPDATE tabpreverjanje SET predmet=".$VPredmet.",idUcitelj=".$Ucitelj.",leto=".$VLeto.",ZapSt='".$_POST["ZapSt"]."',datum='".$Datum->format('d.m.Y')."',razred=".$VRazred1.",paralelka='".$VParalelka."',idRazred=".$VRazred." WHERE id=".$Vidprev;
                                    $result = mysqli_query($link,$SQL);
                                }else{
                                    echo "Nimate dovoljenja za spreminjanje podatkov!<br />";
                                }
                            }else{
                                echo "Napačen datum!<br />";
                            }
                        }else{
                            echo "Zapis ne obstaja!<br />";
                        }
                }

                if ($Vid != 2){
                    echo "<h2>Vnos datumov pisnega ocenjevanja znanja</h2>";
                    echo "<form name='form_Preverjanja' method='post' action='preverjanjeznanja.php'>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<th>Leto</th><th>Razred</th><th>Predmet</th><th>Zap. št.<br />ocenjevanja</th><th>Učitelj</th><th>Datum</th><th></th>";

                    echo "<input name='idd' type='hidden' value='1' />";

                    echo "<tr>";
                    echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                    echo "<td><select name='razred'>";
                    $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM ";
                    $SQL .= "tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL .= "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                    $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
                    $result = mysqli_query($link,$SQL);
                    if (isset($_SESSION["kontrolkarazred"])){
                        $VRazred=$_SESSION["kontrolkarazred"];
                    }
                    while ($R = mysqli_fetch_array($result)){
                        if ($VecSol > 0){
                            if ($VRazred==$R["id"]){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }
                        }else{
                            if ($VRazred==$R["id"]){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                    }
                    echo "</select></td>";

                    if (isset($_SESSION["kontrolkapredmet"])){
                        $VPredmet=$_SESSION["kontrolkapredmet"];
                    }else{
                        $VPredmet=0;
                    }
                    echo "<td><select name='predmet'>";
                    $SQL = "SELECT id,opis,oznaka FROM TabPredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,vrstnired,opis";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["id"]==$VPredmet){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["opis"]." (".$R["oznaka"].")"."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")"."</option>";
                        }
                    }
                    echo "</select></td>";
                    
                    echo "<td><input name='ZapSt' type='text' size='2' value='' /></td>";

                    if (isset($_SESSION["kontrolkaucitelj"])){
                        $Ucitelj=$_SESSION["kontrolkaucitelj"];
                    }else{
                        $Ucitelj=0;
                    }
                    echo "<td><select name='ucitelj'>";
                    echo "<option value='0'>Ni izbran</option>";
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["iducitelj"]==$Ucitelj){
                            echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                        }else{
                            echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                        }
                    }
                    echo "</select></td>";

                    echo "<td><input id='dat01' name='datum' type='text' size='10' value='".$Danes->format('d.m.Y')."' /></td>";
                    //echo "<td><input name='datum' type='text' size='10' value='".$Danes->format('d.m.Y')."' /></td>";
                    echo "<td><input name='solskoleto' type='hidden' value='".$VLeto."' />";
                    echo "<input name='id' type='hidden' value='1' />";
                    echo "<input name='submit' type='submit' value='Pošlji' />";
                    echo "</td></tr></table>";
                    echo "</form>";

                    echo "<h2>Spisek datumov pisnega ocenjevanja znanja</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<th>Leto</th><th>Razred</th><th>Predmet</th><th>Zap. št.<br />ocenjevanja</th><th>Učitelj</th><th>Datum</th><th>Popravi</th><th>Briši</th>";
                    
                    $SQL = "SELECT tabpreverjanje.leto,tabpreverjanje.id,tabpreverjanje.zapst,tabpreverjanje.datum,";
                    $SQL = $SQL."tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
                    $SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
                    $SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
                    $SQL = $SQL."WHERE tabrazdat.leto=".$VLeto." ";
                    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.opis";
                    
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                        echo "<td>".$R["razred"].". ".$R["roznaka"]."</td>";
                        echo "<td>".$R["opis"]."(".$R["poznaka"].")"."</td>";
                        echo "<td align=center>".$R["zapst"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        $Datum=new DateTime(isDate($R["datum"]));
                        echo "<td>".$Datum->format('d.m.Y')."</td>";
                        echo "<td><a href='preverjanjeznanja.php?idd=1&id=2&popravi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'>Popravi</a></td>";
                        echo "<td><a href='preverjanjeznanja.php?idd=1&id=3&brisi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'>Briši</a></td>";
                        echo "</tr>";
                        $Indx = $Indx+1;
                    }
                        
                    echo "</table><br /><br />";
                    echo "<a href='preverjanjeznanja.php?idd=2'>Izpis datumov pisnega ocenjevanja znanja</a><br />";
                }
            }else{
                //header("Location: nepooblascen.htm");
                $Vnos="2";
            }
            //break;
        case "2": //izpisi  (prosto dostopni)
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            $i=1;
            $sole=array();
            while ($R = mysqli_fetch_array($result)){
                $sole[$i][0]=$R["id"];
                $sole[$i][1]=$R["solakratko"];
                $i += 1;
            }
            $StSol=$i-1;
            $raz=$VRazred;
            for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                echo "<h2>".$sole[$IndxSola][1]."</h2>";
            
                echo "<form name='rezultati1' method='post' action='preverjanjeznanja.php'>";
                //echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<input name='idd' type='hidden' value='2'>";
                $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL .= "WHERE leto=".$VLeto." AND razred > 0 AND idsola=".$sole[$IndxSola][0];
                $SQL .= " ORDER BY idsola,razred,oznaka";
                $result = mysqli_query($link,$SQL);

                echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
                echo "<option value='0'>Vsi</option>";
                $Indx=1;
                if ($VecSol > 0){
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }else{
                    while ($R = mysqli_fetch_array($result)){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                }
                echo "</select>";
                //echo "<input name='id' type='hidden' value='0'>";
                //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                //echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            
                echo "<h2>Spisek datumov pisnih preverjanj znanja</h2>";
                
                $SQL = "SELECT DISTINCT tabpreverjanje.predmet FROM tabpreverjanje WHERE leto=".$VLeto." ORDER BY predmet";
                $result = mysqli_query($link,$SQL);
                
                $StPredmetov=0;
                while ($R = mysqli_fetch_array($result)){
                    $StPredmetov=$StPredmetov+1;
                    $Predmeti[$StPredmetov]=$R["predmet"];
                }

                switch ($raz){
                    case 0:
                        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 AND idsola=".$sole[$IndxSola][0]." ORDER BY razred,oznaka";
                        break;
                    default:
                        $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND id = $raz AND idsola=".$sole[$IndxSola][0]." ORDER BY razred,oznaka";
                }
                
                $result = mysqli_query($link,$SQL);
                
                $StRazredov=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["razred"] >= 0){
                        $StRazredov=$StRazredov+1;
                        $Razredi[$StRazredov]=$R["razred"].". ".$R["oznaka"];
                    }
                }
                
                for ($Indx=0;$Indx <= 50;$Indx++){
                    for ($i1=0;$i1 <= 50;$i1++){
                        $Termin[$Indx][$i1]="";
                    }
                }
                
                $SQL = "SELECT id,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1)";
                $result = mysqli_query($link,$SQL);
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $StrPredmet[$R["id"]]=$R["oznaka"];
                }
                
                $SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
                $SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
                $SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
                $SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
                $SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.opis,year(datum),month(datum),day(datum)";
                $result = mysqli_query($link,$SQL);

                if (mysqli_num_rows($result) > 0){
                    echo "<h2>Pisna preverjanja znanja za 1. polletje</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<tr bgcolor=lightcyan><th></th>";
                    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                        echo "<th>".$Razredi[$Indx]."</th>";
                    }
                    echo "</tr>";
                    
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            for ($i1=1;$i1 <= $StRazredov;$i1++){
                                $VRazred=$R["razred"].". ".$R["roznaka"];
                                if (($VRazred==$Razredi[$i1]) && ($R["pid"]==$Predmeti[$Indx])){
                                    $Datum=new DateTime(isDate($R["datum"]));
                                    switch(intval($Datum->format('n'))){
                                        case 9:
                                        case 10:
                                        case 11:
                                        case 12:
                                        case 1:
                                            $Termin[$Indx][$i1]=$Termin[$Indx][$i1].$Datum->format('j.n.')." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)"."<br />";
                                    }
                                }
                            }
                        }
                    }
                    
                    for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                        echo "<tr bgcolor=lightyellow>";
                        echo "<td bgcolor=khaki>".$StrPredmet[$Predmeti[$Indx]]."</td>";
                        for ($i1=1;$i1 <= $StRazredov;$i1++){
                            if (strlen($Termin[$Indx][$i1]) > 0){
                                echo "<td>".$Termin[$Indx][$i1]."</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                        }
                        echo "</tr>";
                    }
                    echo "</table><br />";

                    $result = mysqli_query($link,$SQL);
                    for ($Indx=0;$Indx <= 50;$Indx++){
                        for ($i1=0;$i1 <= 50;$i1++){
                            $Termin[$Indx][$i1]="";
                        }
                    }
                    
                    $SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
                    $SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
                    $SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
                    $SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";
                    $SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.opis,year(datum),month(datum),day(datum)";
                    $result = mysqli_query($link,$SQL);

                    if (mysqli_num_rows($result) > 0){
                        echo "<h2>Pisna preverjanja znanja za 2. polletje</h2>";
                        echo "<table border=1 cellspacing=0>";
                        echo "<tr bgcolor=lightcyan><th></th>";
                        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                            echo "<th>".$Razredi[$Indx]."</th>";
                        }
                        echo "</tr>";
                        
                        while ($R = mysqli_fetch_array($result)){
                            for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                                for ($i1=1;$i1 <= $StRazredov;$i1++){
                                    $VRazred=$R["razred"].". ".$R["roznaka"];
                                    if (($VRazred==$Razredi[$i1]) && ($R["pid"]==$Predmeti[$Indx])){
                                        $Datum=new DateTime(isDate($R["datum"]));
                                        switch(intval($Datum->format('n'))){
                                            case 2:
                                            case 3:
                                            case 4:
                                            case 5:
                                            case 6:
                                                $Termin[$Indx][$i1]=$Termin[$Indx][$i1].$Datum->format('j.n.')." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)"."<br />";
                                        }
                                    }
                                }
                            }
                        }
                        
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            echo "<tr bgcolor=lightyellow>";
                            echo "<td bgcolor=khaki>".$StrPredmet[$Predmeti[$Indx]]."</td>";
                            for ($i1=1;$i1 <= $StRazredov;$i1++){
                                if (strlen($Termin[$Indx][$i1]) > 0){
                                    echo "<td>".$Termin[$Indx][$i1]."</td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                }
                            }
                            echo "</tr>";
                        }
                        echo "</table><br />";
                    }
                }
                
                $SQL = "SELECT datum,kat FROM tabpraznik WHERE leto IN (".$VLeto.",".($VLeto+1).") ORDER BY leto,mesec,dan";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime($R["datum"]);
                    $Praznik[$Indx][1]=$R["kat"];
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;

                $SQL = "SELECT tabpreverjanje.id,tabpreverjanje.datum,";
                $SQL = $SQL."tabpredmeti.id AS pid,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabucitelji.priimek,tabucitelji.ime,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
                $SQL = $SQL."((tabpreverjanje INNER JOIN tabucitelji ON tabpreverjanje.idUcitelj=tabucitelji.idUcitelj) ";
                $SQL = $SQL."INNER JOIN tabpredmeti ON tabpreverjanje.predmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabpreverjanje.idRazred=tabrazdat.id ";

                switch ($raz){
                    case 0:
                        $SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                        break;
                    default:
                        $SQL = $SQL."WHERE tabpreverjanje.leto=".$VLeto." AND tabrazdat.id = $raz AND tabrazdat.idsola=".$sole[$IndxSola][0];
                }

                $SQL = $SQL." ORDER BY year(datum),month(datum),day(datum),tabrazdat.razred,tabrazdat.oznaka,opis";
                $result = mysqli_query($link,$SQL);
                
                $CompDate="";
                for ($Indx=1;$Indx <= 300;$Indx++){
                    $DanPouka[$Indx][0]=""; //'datum
                    $DanPouka[$Indx][1]=""; //'zapisi
                }
                
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Datum=new DateTime($R["datum"]);
                    if ($CompDate != $Datum->format('d.m.Y')){
                        $CompDate=$Datum->format('d.m.Y');
                        $Indx=$Indx+1;
                        $DanPouka[$Indx][0]=new DateTime($Datum->format('Y-m-d'));
                        $DanPouka[$Indx][1]=$R["razred"].".".$R["roznaka"]." ".$R["poznaka"]." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)<br />";
                    }else{
                        $DanPouka[$Indx][1]=$DanPouka[$Indx][1].$R["razred"].".".$R["roznaka"]." ".$R["poznaka"]." (".mb_substr($R["priimek"],0,1,$encoding).".".mb_substr($R["ime"],0,1,$encoding).".)<br />";
                    }
                }
                $StKontrolk=$Indx;
                
                if (($VLeto+1) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }
                $MonthName=array('','januar','februar','marec','april','maj','junij','julij','avgust','september','oktober','november','december');

                echo "<h2>Koledar za leto ".$VLeto."/".($VLeto+1)."</h2>";

                if ($Danes->format('n') > 8){
                    for ($Indx=$Danes->format('n');$Indx <= 12;$Indx++){
                        echo $MonthName[$Indx]."<br />";
                        echo "<table class='small' border=1>";
                        echo "<tr bgcolor=lightcyan>";
                        for ($i1=0;$i1 <= 6;$i1++){
                            echo "<th width='80'>".Int2Dan($i1)."</th>";
                        }
                        echo "</tr>";
                        echo "<tr>";
                        $Datum=new DateTime($VLeto."-".$Indx."-01");
                        for ($i1=1;$i1 <= $Datum->format('w');$i1++){
                            echo "<td>&nbsp;</td>";
                        }
                        for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                            $TekDatum=new DateTime($VLeto."-".$Indx."-".$Indx1);
                            switch(intval($TekDatum->format('w'))){
                                case 0:
                                case 7:
                                    echo "<tr><td bgcolor=lightsalmon>".$Indx1."</td>";
                                    break;
                                case 6:
                                    echo "<td bgcolor=lightsalmon>".$Indx1."</td></tr>";
                                    break;
                                default:
                                    switch(CheckPraznik($TekDatum)){
                                        case 1:
                                            echo "<td bgcolor=lightgreen>".$Indx1."</td>";
                                            break;
                                        case 2:
                                        case 4:
                                            echo "<td bgcolor=lightblue>".$Indx1."</td>";
                                            break;
                                        default:
                                            $Izpis="&nbsp;";
                                            for ($i1=1;$i1 <= $StKontrolk;$i1++){
                                                if ($DanPouka[$i1][0]->format('Y-m-d')==$TekDatum->format('Y-m-d')){
                                                    $Izpis=$DanPouka[$i1][1];
                                                    break;
                                                }
                                            }
                                            echo "<td bgcolor=lightyellow>".$Indx1."<br /><b>".$Izpis."</b></td>";
                                            break;
                                    }
                            }
                        }
                        $KonMeseca=new DateTime($VLeto."-".$Indx."-".$MesecDni[$Indx]);
                        if (intval($KonMeseca->format('w')) != 0){
                            echo "</tr>";
                        }
                        echo "</table><br />";
                    }
                }
                if ($Danes->format('n') < 7){
                    $j=$Danes->format('n');
                }else{
                    $j=1;
                }
                for ($Indx=$j;$Indx <= 6;$Indx++){
                    echo $MonthName[$Indx]."<br />";
                    echo "<table class='small' border=1>";
                    echo "<tr bgcolor=lightcyan>";
                    for ($i1=0;$i1 <= 6;$i1++){
                        echo "<th width='80'>".Int2Dan($i1)."</th>";
                    }
                    echo "</tr>";
                    echo "<tr>";
                    $Datum=new DateTime(($VLeto+1)."-".$Indx."-01");
                    for ($i1=1;$i1 <= $Datum->format('w');$i1++){
                        echo "<td>&nbsp;</td>";
                    }
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $TekDatum=new DateTime(($VLeto+1)."-".$Indx."-".$Indx1);
                        switch(intval($TekDatum->format('w'))){
                            case 0:
                            case 7:
                                echo "<tr><td bgcolor=lightsalmon>".$Indx1."</td>";
                                break;
                            case 6:
                                echo "<td bgcolor=lightsalmon>".$Indx1."</td></tr>";
                                break;
                            default:
                                switch(CheckPraznik($TekDatum)){
                                    case 1:
                                        echo "<td bgcolor=lightgreen>".$Indx1."</td>";
                                        break;
                                    case 2:
                                    case 4:
                                        echo "<td bgcolor=lightblue>".$Indx1."</td>";
                                        break;
                                    default:
                                        $Izpis="&nbsp;";
                                        for ($i1=1;$i1 <= $StKontrolk;$i1++){
                                            if ($DanPouka[$i1][0]->format('Y-m-d')==$TekDatum->format('Y-m-d')){
                                                $Izpis=$DanPouka[$i1][1];
                                                break;
                                            }
                                        }
                                        echo "<td bgcolor=lightyellow>".$Indx1."<br /><b>".$Izpis."</b></td>";
                                        break;
                                }
                        }
                    }
                    $KonMeseca=new DateTime(($VLeto+1)."-".$Indx."-".$MesecDni[$Indx]);
                    if (intval($KonMeseca->format('w')) != 0){
                        echo "</tr>";
                    }
                    echo "</table><br />";
                }
        }
        break;
    }
}
?>

</body>
</html>
