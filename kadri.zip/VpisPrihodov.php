<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Vpis prihodov in odhodov
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
/*
if (!CheckDostop("DelKontr",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
$VLeto=$Danes->format('Y');
if (isset($_GET["prikaz"])){
    $prikaz=$_GET["prikaz"];
}else{
    $prikaz=0;
}
echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrihodDelavcev.php'>";
echo "<h2>Vpis prihoda/odhoda</h2><br />";
echo "<table border=0>";
echo "<tr>";
    echo "<td>";
        echo "Delavec:<select name='delavec'>";
        echo "<option value='0'>Ni izbran</option>";
        $SQL = "SELECT emso,priimime FROM kadrovi ORDER BY priimime";
        $result = mysqli_query($link,$SQL);
        
        while ($R = mysqli_fetch_array($result)){
            //echo $R["EMSO"]." ".$ucitelj." ".$_POST["prikaz"]." ".$R["STDELAVCA"]." ".$R["PRIIMIME"]."<br />" ;
            if (strlen($R["priimime"]) > 0 ){
                if ($VLevel > 1 ){
                    if ($Vid=="1" ){
                        if ($R["emso"]==$prikaz ){
                            echo "<option value=".$R["emso"]." selected='selected'>".$R["priimime"]."</option>";
                        }else{
                            echo "<option value=".$R["emso"].">".$R["priimime"]."</option>";
                        }
                    }else{
                        if ($R["emso"]==$ucitelj){
                            echo "<option value=".$R["emso"]." selected='selected'>".$R["priimime"]."</option>";
                        }else{
                            echo "<option value=".$R["emso"].">".$R["priimime"]."</option>";
                        }
                    }
                }else{
                    if ($R["emso"]==$ucitelj){
                        echo "<option value=".$R["emso"]." selected='selected'>".$R["priimime"]."</option>";
                    }
                }
            }
        }

        echo "</select>";
    echo "</td>";
echo "</tr>";
echo "</table>";
echo "<table border=0>";
echo "<tr>";
    echo "<td>Datum:</td>";
    /*
    echo "<td>";
        echo "Dan:<select name='dan'>";
        echo "<option selected='selected'>" . $Danes->format('j') . "</option>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
    echo "</td>";
    echo "<td>";
        echo "Mesec:<select name='mesec'>";
        echo "<option selected='selected'>" . $Danes->format('n') . "</option>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
    echo "</td>";
    echo "<td>";
        echo "Leto: <select name='leto'>";
        echo "<option value='" .  $VLeto  . "' selected='selected'>" . $VLeto . "</option>";
        echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "</option>";
        echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "</option>";
        echo "</select>";
    echo "</td>";
    */
    echo "<td colspan='3'><input id='dat01' name='datum' type='text' value='".$Danes->format('d.m.Y')."'></td>";
echo "</tr>";
echo "<tr>";
    echo "<td>Čas:</td>";
    echo "<td>";
        echo "Ura:<select name='ura'>";
        echo "<option selected='selected'>" . $Danes->format('H') . "</option>";
        for ($Indx=0;$Indx <= 23;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
    echo "</td>";
    echo "<td>";
        echo "Minuta:<select name='minuta'>";
        echo "<option selected='selected'>" . $Danes->format('i') . "</option>";
        for ($Indx=0;$Indx <= 59;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
    echo "</td>";
    echo "<td>";
        echo "Tip: <select name='tip'>";
        echo "<option value='1001' selected='selected'>Prihod</option>";
        echo "<option value='3001'>Odhod z dela</option>";
        echo "<option value='3002'>Službeni izhod</option>";
        echo "<option value='3010'>Izhod - malica</option>";
        echo "</select>";
    echo "</td>";
echo "</tr>";
echo "</table>";
echo "<input name='id' type='hidden' value='1'>";

echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>";
        if ($Vid=="1" ){
            $SQL = "SELECT kadrovi.*,tabprihodi.* FROM tabprihodi INNER JOIN kadrovi ON tabprihodi.sifra=kadrovi.stdelavca ";
            $SQL = $SQL . "WHERE ((tabprihodi.letopr='".$Danes->format('Y')."' AND tabprihodi.mesecpr='".$Danes->format('n')."') OR (tabprihodi.letodh='".$Danes->format('Y')."' AND tabprihodi.mesecodh='".$Danes->format('n')."')) AND kadrovi.emso='".$prikaz."' ORDER BY tabprihodi.id DESC";
        }else{
            $SQL = "SELECT kadrovi.*,tabprihodi.* FROM tabprihodi INNER JOIN kadrovi ON tabprihodi.sifra=kadrovi.stdelavca ";
            $SQL = $SQL . "WHERE ((tabprihodi.letopr='".$Danes->format('Y')."' AND tabprihodi.mesecpr='".$Danes->format('n')."') OR (tabprihodi.letodh='".$Danes->format('Y')."' AND tabprihodi.mesecodh='".$Danes->format('n')."')) AND kadrovi.emso='".$ucitelj."' ORDER BY tabprihodi.id DESC";
        }
        $result = mysqli_query($link,$SQL);
        
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Ime</th>";
        echo "<th>Datum</th>";
        echo "<th>Čas</th>";
        echo "<th>Prihod</th>";
        echo "<th>Odhod</th>";
        echo "<th>Briši</th>";
        echo "</tr>";
        
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["PRIIMIME"]."</td>";
            if (isset($R["LETOPR"])){
                echo "<td>".$R["DANPR"].".".$R["MESECPR"].".".$R["LETOPR"]."</td>";
				if (intval($R["MINPRIH"]) < 10){
					echo "<td align='right'>".$R["URAPRIH"].":0".$R["MINPRIH"]."</td>";
				}else{
					echo "<td align='right'>".$R["URAPRIH"].":".$R["MINPRIH"]."</td>";
				}
                echo "<td align='center'>".$R["VRSTAPRIH"]."</td><td>&nbsp;</td>";
            }else{
                echo "<td>".$R["DANODH"].".".$R["MESECODH"].".".$R["LETODH"]."</td>";
				if (intval($R["MINODH"]) < 10){
					echo "<td align='right'>".$R["URAODH"].":0".$R["MINODH"]."</td>";
				}else{
					echo "<td align='right'>".$R["URAODH"].":".$R["MINODH"]."</td>";
				}
                echo "<td>&nbsp;</td><td align='center'>".$R["VRSTAPRIH"]."</td>";
            }
            if ($Vid=="1" ){
                echo "<td><a href='brisiPrihodDel.php?prikaz=".$prikaz."&nacin=1&id=".$R["id"]."'>Briši</a></td>";
            }else{
                echo "<td><a href='brisiPrihodDel.php?prikaz=".$ucitelj."&nacin=1&id=".$R["id"]."'>Briši</a></td>";
            }
            echo "</tr>";
        }
    echo "</table>";
?>

</body>
</html>
