<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VUporabnikIme=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("DelPregl",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    ?>

    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="pragma" content="no-cache" > 
    <link rel="stylesheet" type="text/css" href="osmj.css"> 
    <title>Naslovi šol
    </title>
    </head>
    <body>

    <?php

    if (isset($_POST["iducitelj"])){
        $ucitelj=$_POST["iducitelj"];
    }else{
        if (isset($_GET["iducitelj"])){
            $ucitelj=$_GET["iducitelj"];
        }else{
            $ucitelj="";
        }
    }

    switch ($Vid){
        case "2":
            break;
        default:
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
    }
        
    switch ($Vid){
	    case "4":
		    echo "<pre>".chr(34)."Name".chr(34).",".chr(34)."E-mail address".chr(34)."<br />";
		    
		    $SQL = "SELECT obcina,naziv,email FROM tabzavodi ";
		    $SQL = $SQL . " ORDER BY obcina,naziv";
		    $result = mysqli_query($link,$SQL);
		    
            while ($R = mysqli_fetch_array($result)){
			    if (strlen($R["email"]) >0) {
				    echo chr(34).$R["naziv"].chr(34).",";
				    echo chr(34).$R["email"].chr(34)."<br />";
			    }
		    }
		    echo "</pre>";
            break;
	    default:
		    echo "<form name='obrazec' method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
		    echo "<table border='1'>";
            echo "<tr><th>Št.</th><th>Pošlji</th><th>Regija</th><th>Očina</th><th>Naziv</th><th>E-mail</th><th>telefon</th></tr>";
		    
		    $SQL = "SELECT * FROM tabzavodi ";
		    $SQL = $SQL . " ORDER BY obcina,naziv";
		    $result = mysqli_query($link,$SQL);
		    
		    $indx=0;
            while ($R = mysqli_fetch_array($result)){
			    $indx=$indx+1;
			    echo "<tr>";
			    echo "<td>".$indx."</td>";
                echo "<td><input name='uc_".$indx."' type='hidden' value='".$R["email"]."'><input name='em_".$indx."' type='checkbox'></td>";
			    echo "<td>".$R["regija"]."</td>";
                echo "<td>".$R["obcina"]."</td>";
                echo "<td><a href='".$R["splet"]."' target='_blank'>".$R["naziv"]."</td>";
		        echo "<td><a href='mailto:".$R["email"]."'>".$R["email"]."</a>&nbsp;</td>";
                echo "<td>".$R["tel"]."</td>";
			    echo "</tr>";
		    }
		    echo "</table>";
		    echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
		    echo "<br /><input name='Stevilo' type='hidden' value='".$indx."'>";
		    echo "<input name='id' type='hidden' value='3'>";
		    echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
		    echo "<b>Sporočilo:</b><br><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
		    echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
		    echo "<input name='Povezava' type='hidden' value='/'>";
		    echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
		    echo "<input name='submit' type='submit' value='Pošlji e-mail'><br />";
		    echo "</form>";
    }	
}
if ($Vid != "4"){
	echo "<br />";
	echo "<a href='naslovisol.php?id=4'>Podatki za uvoz v Outlookove stike<br />";
	echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

	?>
	<script language="JavaScript">
	function OznaciVse(form){
		for (i=1; i < form.elements.length; i++) {
			form.elements[i].checked=true;
		}
	}
	function BrisiVse(form){
		for (i=1; i < form.elements.length; i++) {
			form.elements[i].checked=false;
		}
	}
	</script>

	</body>
	</html>
<?php
}
?>