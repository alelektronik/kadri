<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Realizacija
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("PreglReal",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

$SQL = "SELECT id FROM tabpredmeti ORDER BY id DESC LIMIT 0,1";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $NPredmetov=$R["id"];
}else{
    $NPredmetov=0;
}

$CelotenPlanUr=0;
$CelotnaIzvedbaUr=0;
for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
    $CelotnaRealIzbirni[$Indx]=0;
    $CelotnaRealNeobvezni[$Indx]=0;
}

$SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
$result = mysqli_query($link,$SQL);

$Indx=0;
while ($R = mysqli_fetch_array($result)){
    $Razredi[$Indx][0] = $R["razred"];
    $Razredi[$Indx][1] = $R["oznaka"];
    $Razredi[$Indx][2] = $R["osemdevet"];
    $Razredi[$Indx][3] = $R["id"];
    $Indx=$Indx+1;
}
$StRazredov=$Indx;

$UcneUreVse[0]=0; //plan polletje
$UcneUreVse[1]=0; //izvedba polletje
$UcneUreVse[2]=0; //plan celoletno
$UcneUreVse[3]=0; //izvedba celoletno
for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
    $UcneUreRedni[$Indx][0]=0;
    $UcneUreIzbirni[$Indx][0]=0;
    $UcneUreRedni[$Indx][1]=0;
    $UcneUreIzbirni[$Indx][1]=0;
    
    $UcneUreNeobvezni[$Indx][0]=0;
    $UcneUreNeobvezni[$Indx][1]=0;

    $UcneUreRedniP[$Indx][0]=0;
    $UcneUreIzbirniP[$Indx][0]=0;
    $UcneUreRedniP[$Indx][1]=0;
    $UcneUreIzbirniP[$Indx][1]=0;

    $UcneUreNeobvezniP[$Indx][0]=0;
    $UcneUreNeobvezniP[$Indx][1]=0;
}
$CelotenPlanUrP=0;
$CelotnaIzvedbaUrP=0;

for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
    $VRazred=$Razredi[$IndxRazred][3];
    $VRazred1=$Razredi[$IndxRazred][0];
    $VParalelka=$Razredi[$IndxRazred][1];
    $VDevetletka=$Razredi[$IndxRazred][2];
    
    $SQL = "SELECT TabRazred.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, TabVzgojitelji.Priimek AS vpriimek, TabVzgojitelji.Ime AS vime, ";
    $SQL = $SQL . "tabrazdat.razred AS rrazred,tabrazdat.idsola,TabUcenci.*,tabrazdat.* FROM ";
    $SQL = $SQL . "((TabVzgojitelji INNER JOIN (TabRazred INNER JOIN tabucitelji ON TabRazred.IdUcitelj=tabucitelji.IdUcitelj) ON TabVzgojitelji.IdUcitelj=TabRazred.IdVzgojitelj) ";
    $SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.IdUcenec=TabUcenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
    $SQL = $SQL ." ORDER BY TabUcenci.Priimek, TabUcenci.Ime";

    //'Response.Write "<br>" . $SQL . "<br>"

    $result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
        if ($VecSol > 0){
            $SQL = "SELECT solakratko FROM tabsola WHERE id=".$R["idsola"];
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                $solakratko=$R1["solakratko"];
            }else{
                $solakratko="";
            }
            echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $R["rrazred"] . ". " . $R["oznaka"] . " ".$solakratko."</b><br />";
        }else{
            echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $R["rrazred"] . ". " . $R["oznaka"] . "</b><br />";
        }
        $Ucitelj = $R["ucpriimek"]  . " " . $R["ucime"];
        $IdUcitelj=$R["IdUcitelj"];
        $Vzgojitelj =     $R["vpriimek"]  . " " . $R["vime"];
        $IdVzgojitelj=$R["IdVzgojitelj"];

        echo "Učitelj: <b>" . $Ucitelj . "</b><br />";
        if ($VRazred1 < 2 ){
            echo "Drugi učitelj: <b>" . $Vzgojitelj . "</b><br />";
        }else{
            echo "Učitelj OPB: <b>" . $Vzgojitelj . "</b><br />";
        }
    }

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $ucenci[$Indx][0]=$R["IdUcenec"];
        $ucenci[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
        $ucenci[$Indx][2]=$R["rrazred"].". ".$R["oznaka"];
        $ucenci[$Indx][3]=$R["DatRoj"];
        $Indx=$Indx+1;
    }
    $StUcencev=$Indx;

    $SQL = "SELECT DISTINCT tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,tabucenje.Predmet,tabucenje.razred,tabucenje.paralelka,tabucenje.leto FROM ";
    $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE ((tabrazdat.id=".$VRazred.") OR ((tabrazdat.razred=".$VRazred1.") AND (paralelka='')) AND Prioriteta IN (0,1)) ";
    $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
    $result = mysqli_query($link,$SQL);

    $UcneUre[0]=0; //plan polletje
    $UcneUre[1]=0; //izvedba polletje
    $UcneUre[2]=0; //plan celoletno
    $UcneUre[3]=0; //izvedba celoletno

    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $UcneUrePredmeti[$Indx][0]=0;
        $UcneUrePredmeti[$Indx][1]=0;
        $UcneUrePredmeti[$Indx][2]=0;
        $UcneUrePredmeti[$Indx][3]=0;
        $UcneUrePredmeti[$Indx][4]=0;
        $UcneUrePredmeti[$Indx][5]=0;
        $UcneUrePredmeti[$Indx][6]=0;
        $UcneUrePredmeti[$Indx][7]="";
        $UcneUrePredmeti[$Indx][8]=0;
        $UcneUrePredmeti[$Indx][9]=0;
        $Predmeti[$Indx][0]=0;
        $Predmeti[$Indx][1]=0;
    }

    $StPredmetov=0;

    while ($R = mysqli_fetch_array($result)){
        $Predmeti[$StPredmetov][0]=$R["Predmet"];
        $Predmeti[$StPredmetov][1]=$R["Oznaka"];
        $StPredmetov=$StPredmetov+1;
    }

    //'Realizacija ur
    $SQL = "SELECT TabRealizacija.*,tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.kodamss,tabpredmeti.opismss,tabucitelji.priimek,tabucitelji.ime,TabRealizacija.id AS rid,tabucenje.zdruzeno,tabucenje.realizirano FROM ";
    $SQL = $SQL . "((TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
    $SQL = $SQL . "INNER JOIN tabucitelji ON TabRealizacija.Referenca=tabucitelji.idUcitelj) ";
    $SQL .= "INNER JOIN tabucenje ON tabrealizacija.ucenje=tabucenje.id ";
    $SQL = $SQL . "WHERE TabRealizacija.leto=".$VLeto." AND TabRealizacija.razred=".$VRazred1." AND (tabrealizacija.paralelka='".$VParalelka."' OR tabrealizacija.paralelka='".strtoupper($VParalelka)."' OR tabrealizacija.paralelka='".strtolower($VParalelka)."' OR tabrealizacija.paralelka='') AND tabpredmeti.prioriteta IN (0,1) ORDER BY tabpredmeti.VrstniRed,tabucenje.zdruzeno,tabucenje.realizirano";
    $result = mysqli_query($link,$SQL);

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
        $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
        switch ($R["prioriteta"]){
        case 0:
            if ($R["zdruzeno"] == "1"){
                $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"]/2;
                $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"]/2;
            }else{
                $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"];
                $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"];
            }
            if ($R["zdruzeno"] == "1"){
                $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"]/2;
                $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"]/2;
            }else{
                $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"];
                $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
            }
            break;
        case 1:
            if (strpos($R["opismss"],"/ni/") > 0){ //neobvezni izbirni
                if ($R["kodamss"]=="N1A"){ //v primeru izbirne angleščine v 1. razredu, šteje vse
                    $UcneUreNeobvezni[$R["Predmet"]][0]=$UcneUreNeobvezni[$R["Predmet"]][0]+$R["Plan"];
                    $UcneUreNeobvezni[$R["Predmet"]][1]=$UcneUreNeobvezni[$R["Predmet"]][1]+$R["Realizacija"];
                    $UcneUreNeobvezniP[$R["Predmet"]][0]=$UcneUreNeobvezniP[$R["Predmet"]][0]+$R["PlanPol"];
                    $UcneUreNeobvezniP[$R["Predmet"]][1]=$UcneUreNeobvezniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                }else{
                    if ($UcneUreNeobvezni[$R["Predmet"]][1] == 0 ){    //izbirne ure šteje samo enkrat
                        $UcneUreNeobvezni[$R["Predmet"]][0]=$UcneUreNeobvezni[$R["Predmet"]][0]+$R["Plan"];
                        $UcneUreNeobvezni[$R["Predmet"]][1]=$UcneUreNeobvezni[$R["Predmet"]][1]+$R["Realizacija"];
                    }
                    if ($UcneUreNeobvezniP[$R["Predmet"]][1] == 0 ){   //izbirne ure šteje samo enkrat
                        $UcneUreNeobvezniP[$R["Predmet"]][0]=$UcneUreNeobvezniP[$R["Predmet"]][0]+$R["PlanPol"];
                        $UcneUreNeobvezniP[$R["Predmet"]][1]=$UcneUreNeobvezniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                    }
                }
            }else{ //obvezni izbirni
                if ($UcneUreIzbirni[$R["Predmet"]][1] == 0 ){    //izbirne ure šteje samo enkrat
                    $UcneUreIzbirni[$R["Predmet"]][0]=$UcneUreIzbirni[$R["Predmet"]][0]+$R["Plan"];
                    $UcneUreIzbirni[$R["Predmet"]][1]=$UcneUreIzbirni[$R["Predmet"]][1]+$R["Realizacija"];
                }
                if ($UcneUreIzbirniP[$R["Predmet"]][1] == 0 ){   //izbirne ure šteje samo enkrat
                    $UcneUreIzbirniP[$R["Predmet"]][0]=$UcneUreIzbirniP[$R["Predmet"]][0]+$R["PlanPol"];
                    $UcneUreIzbirniP[$R["Predmet"]][1]=$UcneUreIzbirniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                }
            }
        }
        $UcneUre[2]=$UcneUre[2]+$R["Plan"];
        $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
        $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
        $UcneUrePredmeti[$Indx][1]=$R["oznaka"];
        $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
        $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
        $UcneUrePredmeti[$Indx][4]=$R["Plan"];
        $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
        $UcneUrePredmeti[$Indx][6]=$R["prioriteta"];
        $UcneUrePredmeti[$Indx][7]=$R["priimek"]." ".$R["ime"];
        $UcneUrePredmeti[$Indx][8]=$R["rid"];
        $UcneUrePredmeti[$Indx][9]=$R["Ucenje"];
        $Indx=$Indx+1;
    }
    $StPredmetovUcneUre=$Indx;

    $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];   //plan polletje
    $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];   //izvedba polletje
    $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];   //plan celoletno
    $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];   //izvedba celoletno

    if ($Vid == "1"){
        if ($UcneUre[0] > 0 ){
            $CelotenPlanUrP=$CelotenPlanUrP+$UcneUre[0];
            $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUre[1];
            if ($UcneUre[1]/$UcneUre[0] < 0.95 ){
                echo "<br />Realizacija učnih ur - 1. obdobje: <b><font color=red>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%</font></b><br />";
            }else{
                if ($UcneUre[1]/$UcneUre[0] > 1 ){
                    echo "<br />Realizacija učnih ur - 1. obdobje: <b><font color=green>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%</font></b><br />";
                }else{
                    echo "<br />Realizacija učnih ur - 1. obdobje: <b>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."</b><br />";
                }
            }
        }

        //'Izpis realizacije po predmetih-začetek

        if ($UcneUre[0] > 0 ){
            echo "<table border='1'>";
            if ($VLevel > 2 ){
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th></tr>";
            }
            for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
                echo "<tr><td>".$UcneUrePredmeti[$Indx][1]." - ".$UcneUrePredmeti[$Indx][7]." (".$UcneUrePredmeti[$Indx][9].")</td>";
                if ($UcneUrePredmeti[$Indx][2] > 0 ){
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][2]."</td>";
                    if ($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2] < 0.95 ){
                        echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center><font color=red>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</font></td>";
                    }else{
                        if ($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2] > 1 ){
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center><font color=green>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</font></td>";
                        }else{
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</td>";
                        }
                    }
                }else{
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td></td>";
                }
                if ($VLevel > 2 ){
                    echo "<td><a href='BrisiRealizacijo.php?id=".$UcneUrePredmeti[$Indx][8]."'>Briši</a></td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        //'Izpis realizacije po predmetih-konec
    }

    if ($Vid=="2" ){
        If ($UcneUre[2] > 0 ){
            $CelotenPlanUr=$CelotenPlanUr+$UcneUre[2];
            $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUre[3];
            if ($UcneUre[3]/$UcneUre[2] < 0.95 ){
                echo "<br />Realizacija učnih ur: <b><font color=red>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%</font></b><br />";
            }else{
                if ($UcneUre[3]/$UcneUre[2] > 1 ){
                    echo "<br />Realizacija učnih ur: <b><font color=green>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%</font></b><br />";
                }else{
                    echo "<br />Realizacija učnih ur: <b>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."</b><br />";
                }
            }
        }

        //'Izpis realizacije po predmetih-začetek

        If ($UcneUre[2] > 0 ){
            echo "<table border=1>";
            if ($VLevel > 2 ){
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th></tr>";
            }
            for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
                echo "<tr><td>".$UcneUrePredmeti[$Indx][1]." - ".$UcneUrePredmeti[$Indx][7]." (".$UcneUrePredmeti[$Indx][9].")</td>";
                if ($UcneUrePredmeti[$Indx][4] > 0 ){
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][4]."</td>";
                    if ($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4] < 0.95 ){
                        echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center><font color=red>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</font></td>";
                    }else{
                        if ($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4] > 1 ){
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center><font color=green>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</font></td>";
                        }else{
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</td>";
                        }
                    }
                }else{
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td></td>";
                }
                if ($VLevel > 2 ){
                    echo "<td><a href='BrisiRealizacijo.php?id=".$UcneUrePredmeti[$Indx][8]."'>Briši</a></td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        //'Izpis realizacije po predmetih-konec
    }
echo "<br /><hr><br />";

}


//'------------------------------ 1. polletje
if ($Vid=="1" ){
    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++ ){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreRedniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreRedniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur rednih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur rednih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreIzbirniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreIzbirniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreNeobvezniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreNeobvezniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur neobveznih izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur neobveznih izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreIzbirniP[$Indx][1]+$UcneUreRedniP[$Indx][1]+$UcneUreNeobvezniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreIzbirniP[$Indx][0]+$UcneUreRedniP[$Indx][0]+$UcneUreNeobvezniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur - vse (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur - vse (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }
    echo "<br />";
}

if ($Vid="2" ){
    //'------------------------------- končno
    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreRedni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreRedni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur rednih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur rednih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreIzbirni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreIzbirni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreNeobvezni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreNeobvezni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur neobveznih izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur neobveznih izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreIzbirni[$Indx][1]+$UcneUreRedni[$Indx][1]+$UcneUreNeobvezni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreIzbirni[$Indx][0]+$UcneUreRedni[$Indx][0]+$UcneUreNeobvezni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur (vse): <b>".$CelotenPlanUr."</b>, izvedenih ur (vse): <b>".$CelotnaIzvedbaUr."</b>, realizacija (vse): <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur (vse): <b>".$CelotenPlanUr."</b>, izvedenih ur (vse): <b>".$CelotnaIzvedbaUr."</b>, realizacija (vse): <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }
}

//Izpis realizacij ostalih dejavnosti - začetek

echo "<hr><h1>Realizacija ostalih dejavnosti</h1>";

$UcneUreVse[0]=0;
$UcneUreVse[1]=0;
$UcneUreVse[2]=0;
$UcneUreVse[3]=0;
for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
    $UcneUreRedni[$Indx][0]=0;
    $UcneUreIzbirni[$Indx][0]=0;
    $UcneUreRedni[$Indx][1]=0;
    $UcneUreIzbirni[$Indx][1]=0;
    $UcneUreRedniP[$Indx][0]=0;
    $UcneUreIzbirniP[$Indx][0]=0;
    $UcneUreRedniP[$Indx][1]=0;
    $UcneUreIzbirniP[$Indx][1]=0;
}

for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
    $VRazred=$Razredi[$IndxRazred][3];
    $VRazred1=$Razredi[$IndxRazred][0];
    $VParalelka=$Razredi[$IndxRazred][1];
    $VDevetletka=$Razredi[$IndxRazred][2];
    
    $SQL = "SELECT TabRazred.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, TabVzgojitelji.Priimek AS vpriimek, TabVzgojitelji.Ime AS vime, ";
    $SQL = $SQL . "tabrazdat.razred AS rrazred,TabUcenci.*,tabrazdat.* FROM ";
    $SQL = $SQL . "((TabVzgojitelji INNER JOIN (TabRazred INNER JOIN tabucitelji ON TabRazred.IdUcitelj=tabucitelji.IdUcitelj) ON TabVzgojitelji.IdUcitelj=TabRazred.IdVzgojitelj) ";
    $SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.IdUcenec=TabUcenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
    $SQL = $SQL ." ORDER BY TabUcenci.Priimek, TabUcenci.Ime";

    //'Response.Write "<br>" . $SQL . "<br>"

    $result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
        echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $R["rrazred"] . ". " . $R["oznaka"] . "</b><br />";
        $Ucitelj = $R["ucpriimek"]  . " " . $R["ucime"];
        $IdUcitelj=$R["IdUcitelj"];
        $Vzgojitelj =     $R["vpriimek"]  . " " . $R["vime"];
        $IdVzgojitelj=$R["IdVzgojitelj"];

        echo "Učitelj: <b>" . $Ucitelj . "</b><br />";
        if ($VRazred1 < 2 ){
            echo "Drugi učitelj: <b>" . $Vzgojitelj . "</b><br />";
        }else{
            echo "Učitelj OPB: <b>" . $Vzgojitelj . "</b><br />";
        }
    }

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $ucenci[$Indx][0]=$R["IdUcenec"];
        $ucenci[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
        $ucenci[$Indx][2]=$R["rrazred"].". ".$R["oznaka"];
        $ucenci[$Indx][3]=$R["DatRoj"];
        $Indx=$Indx+1;
    }
    $StUcencev=$Indx;

    $SQL = "SELECT DISTINCT tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,tabucenje.Predmet,tabucenje.razred,tabucenje.paralelka,tabucenje.leto FROM ";
    $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE ((tabrazdat.id=".$VRazred.") OR ((tabrazdat.razred=".$VRazred1.") AND (paralelka='')) AND Prioriteta IN (3,4)) ";
    $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
    $result = mysqli_query($link,$SQL);

    $UcneUre[0]=0;
    $UcneUre[1]=0;
    $UcneUre[2]=0;
    $UcneUre[3]=0;

    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $UcneUrePredmeti[$Indx][0]=0;
        $UcneUrePredmeti[$Indx][1]=0;
        $UcneUrePredmeti[$Indx][2]=0;
        $UcneUrePredmeti[$Indx][3]=0;
        $UcneUrePredmeti[$Indx][4]=0;
        $UcneUrePredmeti[$Indx][5]=0;
        $UcneUrePredmeti[$Indx][6]=0;
        $UcneUrePredmeti[$Indx][7]="";
        $UcneUrePredmeti[$Indx][8]=0;
        $UcneUrePredmeti[$Indx][9]=0;
        $Predmeti[$Indx][0]=0;
        $Predmeti[$Indx][1]=0;
    }

    $StPredmetov=0;

    while ($R = mysqli_fetch_array($result)){
        $Predmeti[$StPredmetov][0]=$R["Predmet"];
        $Predmeti[$StPredmetov][1]=$R["Oznaka"];
        $StPredmetov=$StPredmetov+1;
    }

    //'Realizacija ur
    $SQL = "SELECT TabRealizacija.*,tabpredmeti.oznaka,tabpredmeti.prioriteta,tabucitelji.priimek,tabucitelji.ime,TabRealizacija.id AS rid FROM ";
    $SQL = $SQL . "((TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
    $SQL = $SQL . "INNER JOIN tabucitelji ON TabRealizacija.Referenca=tabucitelji.idUcitelj) ";
    $SQL = $SQL . "WHERE TabRealizacija.leto=".$VLeto." AND TabRealizacija.razred=".$VRazred1." AND (paralelka='".$VParalelka."' OR paralelka='".strtoupper($VParalelka)."' OR paralelka='".strtolower($VParalelka)."' OR paralelka='') AND tabpredmeti.prioriteta IN (3,4) ORDER BY VrstniRed";
    $result = mysqli_query($link,$SQL);

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
        $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
        switch ($R["prioriteta"]){
        case 0:
            if ($R["zdruzeno"] == "1"){
                $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"]/2;
                $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"]/2;
            }else{
                $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"];
                $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"];
            }
            if ($R["zdruzeno"] == "1"){
                $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"]/2;
                $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"]/2;
            }else{
                $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"];
                $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
            }
            break;
        case 1:
            if ($UcneUreIzbirni[$R["Predmet"]][1] == 0 ){
                $UcneUreIzbirni[$R["Predmet"]][0]=$UcneUreIzbirni[$R["Predmet"]][0]+$R["Plan"];
                $UcneUreIzbirni[$R["Predmet"]][1]=$UcneUreIzbirni[$R["Predmet"]][1]+$R["Realizacija"];
            }
            if ($UcneUreIzbirniP[$R["Predmet"]][1] == 0 ){
                $UcneUreIzbirniP[$R["Predmet"]][0]=$UcneUreIzbirniP[$R["Predmet"]][0]+$R["PlanPol"];
                $UcneUreIzbirniP[$R["Predmet"]][1]=$UcneUreIzbirniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
            }
        }
        $UcneUre[2]=$UcneUre[2]+$R["Plan"];
        $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
        $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
        $UcneUrePredmeti[$Indx][1]=$R["oznaka"];
        $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
        $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
        $UcneUrePredmeti[$Indx][4]=$R["Plan"];
        $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
        $UcneUrePredmeti[$Indx][6]=$R["prioriteta"];
        $UcneUrePredmeti[$Indx][7]=$R["priimek"]." ".$R["ime"];
        $UcneUrePredmeti[$Indx][8]=$R["rid"];
        $UcneUrePredmeti[$Indx][9]=$R["Ucenje"];
        $Indx=$Indx+1;
    }
    $StPredmetovUcneUre=$Indx;

    $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
    $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
    $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
    $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

    if ($Vid == "1"){
        if ($UcneUre[0] > 0 ){
            $CelotenPlanUrP=$CelotenPlanUrP+$UcneUre[0];
            $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUre[1];
            if ($UcneUre[1]/$UcneUre[0] < 0.95 ){
                echo "<br />Realizacija učnih ur - 1. obdobje: <b><font color=red>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%</font></b><br />";
            }else{
                if ($UcneUre[1]/$UcneUre[0] > 1 ){
                    echo "<br />Realizacija učnih ur - 1. obdobje: <b><font color=green>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%</font></b><br />";
                }else{
                    echo "<br />Realizacija učnih ur - 1. obdobje: <b>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."</b><br />";
                }
            }
        }

        //'Izpis realizacije po predmetih-začetek

        if ($UcneUre[0] > 0 ){
            echo "<table border='1'>";
            if ($VLevel > 2 ){
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th></tr>";
            }
            for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
                echo "<tr><td>".$UcneUrePredmeti[$Indx][1]." - ".$UcneUrePredmeti[$Indx][7]." (".$UcneUrePredmeti[$Indx][9].")</td>";
                if ($UcneUrePredmeti[$Indx][2] > 0 ){
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][2]."</td>";
                    if ($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2] < 0.95 ){
                        echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center><font color=red>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</font></td>";
                    }else{
                        if ($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2] > 1 ){
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center><font color=green>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</font></td>";
                        }else{
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</td>";
                        }
                    }
                }else{
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][3]."</td><td></td>";
                }
                if ($VLevel > 2 ){
                    echo "<td><a href='BrisiRealizacijo.php?id=".$UcneUrePredmeti[$Indx][8]."'>Briši</a></td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        //'Izpis realizacije po predmetih-konec
    }

    if ($Vid=="2" ){
        If ($UcneUre[2] > 0 ){
            $CelotenPlanUr=$CelotenPlanUr+$UcneUre[2];
            $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUre[3];
            if ($UcneUre[3]/$UcneUre[2] < 0.95 ){
                echo "<br />Realizacija učnih ur: <b><font color=red>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%</font></b><br />";
            }else{
                if ($UcneUre[3]/$UcneUre[2] > 1 ){
                    echo "<br />Realizacija učnih ur: <b><font color=green>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%</font></b><br />";
                }else{
                    echo "<br />Realizacija učnih ur: <b>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."</b><br />";
                }
            }
        }

        //'Izpis realizacije po predmetih-začetek

        If ($UcneUre[2] > 0 ){
            echo "<table border=1>";
            if ($VLevel > 2 ){
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Predmet</th><th>Plan. ure</th><th>Real. ure</th><th>Procent</th></tr>";
            }
            for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
                echo "<tr><td>".$UcneUrePredmeti[$Indx][1]." - ".$UcneUrePredmeti[$Indx][7]." (".$UcneUrePredmeti[$Indx][9].")</td>";
                if ($UcneUrePredmeti[$Indx][4] > 0 ){
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][4]."</td>";
                    if ($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4] < 0.95 ){
                        echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center><font color=red>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</font></td>";
                    }else{
                        if ($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4] > 1 ){
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center><font color=green>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</font></td>";
                        }else{
                            echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</td>";
                        }
                    }
                }else{
                    echo "<td align=center>".$UcneUrePredmeti[$Indx][5]."</td><td></td>";
                }
                if ($VLevel > 2 ){
                    echo "<td><a href='BrisiRealizacijo.php?id=".$UcneUrePredmeti[$Indx][8]."'>Briši</a></td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        //'Izpis realizacije po predmetih-konec
    }
echo "<br /><hr><br />";

}


//Izpis realizacij ostalih dejavnosti - konec

?>


</body>
</html>
