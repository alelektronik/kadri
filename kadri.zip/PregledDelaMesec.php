<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Mesečni pregled dela
</title>
<style type="text/css">
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
function CheckDoprinosRubrika($d,$r){
    global $Doprinosi,$StDoprinosov;
    $Suma=0;
    for ($Indx=1;$Indx <= $StDoprinosov;$Indx++){
        if (($Doprinosi[$Indx][0]->format('Y-m-d')==$d->format('Y-m-d')) && ($Doprinosi[$Indx][1]==$r)){
            $Suma=$Suma+$Doprinosi[$Indx][7];
        }
    }
    return $Suma;
}

function ImeMeseca($m){
    switch ($m){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
    if (isset($_POST["idUcitelj"])){
        $ucitelj=$_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj=$_GET["idUcitelj"];
        }else{
            $ucitelj=0;
        }
    }

    if ($VLevel < 2){
        if ($UciteljComp != $ucitelj){
            if (!CheckDostop("DelKontr",$VUporabnik)){
                header("Location: nepooblascen.htm");
            }
        }
    }

    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    $VLetoPregled=$VLeto;

    if (isset($_POST["mesec"])){
        $VMesec=$_POST["mesec"];
    }else{
        if (isset($_GET["mesec"])){
            $VMesec=$_GET["mesec"];
        }else{
            $VMesec=$Danes->format('m');
        }
    }
    if (($VLetoPregled) % 4 == 0 ) {
        $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
    }else{
        $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
    }

    if ($ucitelj == 0){
        $SQL = "SELECT IdUcitelj FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        $i=0;
        while ($R = mysqli_fetch_array($result)){
            $i++;
            $Ucitelji[$i]=$R["IdUcitelj"];
        }
    }else{
        $i=1;
        $Ucitelji[1]=$ucitelj;
    }
    $StUciteljev=$i; 
    $_SESSION["Ucitelj"] = $ucitelj;

    $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto." ORDER BY datum";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    $ProstiDnevi=0;
    while ($R = mysqli_fetch_array($result)){
        $Praznik[$Indx][0]=new DateTime($R["datum"]);
        $Praznik[$Indx][1]=$R["kat"];
        if ($Praznik[$Indx][1]==1){
            $ProstiDnevi=$ProstiDnevi+1;
        }
        $Indx=$Indx+1;
    }
    $StPraznikov=$Indx-1;

    $SQL = "SELECT * FROM TabDoprinos WHERE aktivno > 0 ORDER BY sortiranje";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $rubrika[$Indx][0]=$R["idDoprinos"];
        $rubrika[$Indx][1]=$R["OblikaDela"];
        $rubrika[$Indx][2]=$R["addsub"];
        $rubrika[$Indx][3]=$R["uramin"];
        $rubrika[$Indx][4]=$R["koeficient"];
        $rubrika[$Indx][5]=$R["aktivno"];
        $Indx=$Indx+1;
    }
    $StRubrik=$Indx-1;
       
    for ($i=1;$i <= $StUciteljev;$i++){   
        $oUcitelj=new RUcitelj();
        $oUcitelj->PreberiSe($Ucitelji[$i],$VLetoPregled,$VLeto);

        $oUcitelj->PodatkiZaposlenega();
        $Delavec=$Ucitelji[$i];
        $ucitelj=$Ucitelji[$i];

        $SQL = "SELECT * FROM TabDoprinos";
        $result = mysqli_query($link,$SQL);
	    while ($R = mysqli_fetch_array($result)){
		    $OznakaDneva[$R["aktivno"]]=$R["OblikaDelaOznaka"];
        }

        for ($Indx=1;$Indx <= 31;$Indx++){
	        $DneviDopusta[$Indx][0]=0;
	        $DneviDopusta[$Indx][1]=0;
        }
        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.* FROM tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.Rubrika=TabDoprinos.idDoprinos WHERE tabpregleddelan.leto=".$VLeto." AND mesec=".$VMesec." AND Ucitelj=".$ucitelj;
        $result = mysqli_query($link,$SQL);

	    while ($R = mysqli_fetch_array($result)){
		    switch ($R["aktivno"]){
			    case 2:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 18:
				    $DneviDopusta[$R["Dan"]][0]=$DneviDopusta[$R["Dan"]][0]+1;
                    break;
			    case 5:
				    $DneviDopusta[$R["Dan"]][1]=$DneviDopusta[$R["Dan"]][1]+1;
		    }
        }
        if ($i > 1){
            echo "<h2 class='break'>Prisotnost na delovnem mestu za mesec ".$VMesec."/".$VLeto."</h2>";
        }else{
            echo "<h2>Prisotnost na delovnem mestu za mesec ".$VMesec."/".$VLeto."</h2>";
        }
        echo "<table border='1'>";
        echo "<tr><th></th>";
        for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
	        echo "<th>".$Indx."</th>";
        }
        echo "<th>Skupaj</th></tr>";
        $TotalDoprinos=0;

        $oUcitelj->ResetPrisotnost();
        $oUcitelj->IzracunPrisotnostiMesec($VLetoPregled,$VMesec,2);
        $oUcitelj->IzpisMesecaPrisotnosti($VLetoPregled,$VMesec,1);
        $CountDay=$oUcitelj->getCountDay();
        $MesecneUre=$oUcitelj->getMesecneUre();

        $Doprinosi=$oUcitelj->getDoprinosiDelavca();
        $StDoprinosov=$oUcitelj->getStDoprinosov();

        for ($Indx=1;$Indx <= $StRubrik;$Indx++){
	        $SumRubrika[$Indx]=0;
	        echo "<tr>";
	        echo "<td>".$rubrika[$Indx][1]."</td>";
	        for ($i1=1;$i1 <= $MesecDni[$VMesec];$i1++){
			    $Datum=new DateTime($VLeto."-".$VMesec."-".$i1);
		        switch ($rubrika[$Indx][0]){
			        case 46: // 'praznik
				        switch ($Datum->format('w')+1){
					        case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
						        if (CheckPraznik($Datum)==1){
							        echo "<td bgcolor='orange' align='right'>1</td>";
							        $SumRubrika[$Indx]=$SumRubrika[$Indx]+1;
						        }else{
							        echo "<td align='right'>0</td>";
						        }
                                break;
					        default:
						        echo "<td align='right'>0</td>";
				        }
                        break;
			        case 34:
				        if ($DneviDopusta[$i1][1] != 0){
					        echo "<td bgcolor='orange' align='right'>1</td>";
					        $SumRubrika[$Indx]=$SumRubrika[$Indx]+1;
				        }else{
					        echo "<td align='right'>0</td>";
				        }
                        break;
			        case 35:
				        if ($DneviDopusta[$i1][0] != 0){
					        echo "<td bgcolor='orange' align='right'>1</td>";
					        $SumRubrika[$Indx]=$SumRubrika[$Indx]+1;
				        }else{
					        echo "<td align='right'>0</td>";
				        }
                        break;
			        default:
				        $ZacVrednost=CheckDoprinosRubrika($Datum,$rubrika[$Indx][0]);
				        if ($ZacVrednost != 0){
					        echo "<td bgcolor='orange' align='right'>".$ZacVrednost."</td>";
					        $SumRubrika[$Indx]=$SumRubrika[$Indx]+$ZacVrednost;
				        }else{
					        echo "<td align='right'>".$ZacVrednost."</td>";
				        }
		        }
	        }
	        echo "<td align='right' bgcolor='lightgreen'>".$SumRubrika[$Indx]."</td>";
	        echo "</tr>";
        }

        echo "</table><br />";

        echo "Počitnice: ".$oUcitelj->getObveza()." dni<br />";
        /*
        if ($Danes->format('Y') > $VLeto){
	        echo "Koeficient dela: "&FormatNumber(oUcitelj.Koeficient("31.12."&VLeto),2)&"<br>"
        else
	        echo "Koeficient dela: "&FormatNumber(oUcitelj.Koeficient(day(now)&"."&month(now)&"."&year(now)),2)&"<br>"
        end if
        'echo "Realiziran doprinos: "&TotalDoprinos&"<br>"
        */
        echo "<table border='1'>";
        echo "<tr><th>Mesec</th><th>Del. dni</th><th>Real. Ure</th><th>Višek ur</th>";
        for ($Indx=2;$Indx <= $DodatnihRubrik;$Indx++){
	        echo "<th>".$OznakaDneva[$Indx]."</th>";
        }
        echo "</tr>";
        $Indx=$VMesec;
        echo "<tr>";
        echo "<td>".ImeMeseca($Indx)."</td><td align=center>".$MesecneUre[$Indx][1] ."</td><td align=right>".number_format($MesecneUre[$Indx][0],1)."</td><td align=right>".number_format($MesecneUre[$Indx][2],1)."</td>";
        for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
	        echo "<td align=right>".$CountDay[$Indx][$i1] ."</td>";
        }
        echo "</tr>";
        echo "</table><br>";

        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.uramin,TabDoprinos.OblikaDela,TabDoprinos.koeficient FROM tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos WHERE (tabpregleddelan.leto=".$VLeto." AND mesec =".$VMesec.") AND ucitelj=".$ucitelj." ORDER BY datum";
        $result = mysqli_query($link,$SQL);

        echo "<a name='spisek'></a><br /><table border='1'>";
        echo "<tr><th>Št.</th><th>Datum</th><th width='250'>Rubrika</th><th>čas</th><th width='250'>Komentar</th><th>Potrjeno</th></tr>";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
		    echo "<tr>";
		    echo "<td>".$Indx."</td>";
            $Datum=new DateTime($R["Datum"]);
		    echo "<td>".$Datum->format('d.m.Y')."</td>";
		    echo "<td>".$R["OblikaDela"]."</td>";
		    if ($R["uramin"] > 1){
			    echo "<td>".$R["Enot"]." min</td>";
		    }else{
			    if ($R["koeficient"]==8 or $R["koeficient"]==0){
				    echo "<td>".$R["Enot"]." dni</td>";
			    }else{
				    echo "<td>".$R["Enot"]." ur</td>";
			    }
		    }
		    echo "<td>".$R["Komentar"]."</td>";
            
		    if ($R["EnotPotrjeno"]){
			    echo "<td align=center><input name='potrjeno' type='checkbox' checked></td>";
		    }else{
			    echo "<td align=center><input name='potrjeno' type='checkbox'></td>";
		    }
            /*
		    echo "<td><a href='PregledDela.asp?id=".$R["id"]."&idUcitelj=".$ucitelj."'>Popravi</a></td>";
		    echo "<td><a href='brisiPDN.asp?brisi=".$R["id"]."'>Briši</td>";
            */
		    echo "</tr>";
	        $Indx=$Indx+1;
        }
        echo "</table><br />";
    }

    echo "<h3>Legenda:</h3>";
    $SQL = "SELECT * FROM TabDoprinos WHERE aktivno > 2 ORDER BY aktivno";
    $result = mysqli_query($link,$SQL);

    echo "<table border='0'>";
    echo "<tr><th>Oznaka</th><th>Pomen</th></tr>";
    while ($R = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>".$R["OblikaDelaOznaka"]."</td>";
        echo "<td> - ".$R["OblikaDela"]."</td>";
        echo "</tr>";
    }
    echo "<tr><td bgcolor='lightsalmon'>&nbsp;</td><td> - sobote in nedelje</td></tr>";
    echo "<tr><td bgcolor='lightgreen'>&nbsp;</td><td> - prazniki</td></tr>";
    echo "<tr><td bgcolor='lightblue'>&nbsp;</td><td> - počitnice brez delovne obveznosti</td></tr>";
    echo "<tr><td bgcolor='lightgrey'>&nbsp;</td><td> - počitnice z delovno obveznostjo</td></tr>";
    echo "<tr><td bgcolor='lightcyan'>&nbsp;</td><td> - dopust na običajen delovni dan</td></tr>";
    echo "<tr><td bgcolor='lightyellow'>&nbsp;</td><td> - bolniška odsotnost</td></tr>";
    echo "<tr><td bgcolor='lime'>&nbsp;</td><td> - spremstvo (dnevi dejavnosti, tabori, šola v naravi)</td></tr>";
    echo "<tr><td bgcolor='lightpink'>&nbsp;</td><td> - tečaj, izobraževanje</td></tr>";
    echo "<tr><td bgcolor='blue'>&nbsp;</td><td> - neopravičena odsotnost</td></tr>";
    echo "</table><br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>
<br />
<a href="prijava.php">Nazaj na glavni meni</a><br />
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
