<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Sistemizacija
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto;
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
	    $Vrazredi[$Indx][1]=$R["razred"].$R["oznaka"];
	    $Vrazredi[$Indx][2]=$R["id"];
	    $Indx=$Indx+1;
    }
    $StRazredov=$Indx-1;

    $SQL = "SELECT * FROM tabucenje WHERE leto=".$VLeto." AND idRazred=0";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
	    $VUcenje[$Indx][1]=$R["Razred"].$R["Paralelka"];
	    $VUcenje[$Indx][2]=$R["Id"];
	    $VUcenje[$Indx][3]=$R["IdUcitelj"]." ".$R["Predmet"];
	    $Indx=$Indx+1;
    }
    $StUcenj=$Indx-1;

    if ($StUcenj > 0){
        for ($Indx=1;$Indx <= $StUcenj;$Indx++){
	        for ($Indx1=1; $Indx1 <= $StRazredov;$Indx1++){
		        if (($VUcenje[$Indx][1]==$Vrazredi[$Indx1][1]) or (strtolower($VUcenje[$Indx][1])==strtolower($Vrazredi[$Indx1][1]))) {
			        $SQL = "UPDATE tabucenje SET idRazred=".$Vrazredi[$Indx1][2]." WHERE id=".$VUcenje[$Indx][2];
			        $result = mysqli_query($link,$SQL);
			        echo $VUcenje[$Indx][3]." ".$Vrazredi[$Indx1][1]."<br />";
		        }
	        }
        }
    }else{
        echo "<h2>Ni neusklajenih podatkov</h2>";
    }
}
?>

</body>
</html>
