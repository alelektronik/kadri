<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pedagoško poročilo
</title>
</head>
<body>

<?php
function ToOPB($x){
    switch ($x){
        case 52:
            return "OPB";
        case 78:
            return "PB01";
        case 79:
            return "PB02";
        case 80:
            return "PB03";
        case 81:
            return "PB04";
        case 82:
            return "PB05";
        case 83:
            return "PB06";
        case 84:
            return "PB07";
        case 85:
            return "PB08";
        case 86:
            return "PB09";
        case 87:
            return "PB10";
        case 88:
            return "PB11";
        case 89:
            return "PB12";
        case 90:
            return "PB13";
        case 91:
            return "PB14";
        default:
            return "---";
    }
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $VUporabnikId=$IdUcitelj;
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
/*    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    */
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = $UciteljComp;
        }
    }
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_GET["razred"])){
    $Razredi[0][0]=$_GET["razred"];
}else{
    $Razredi[0][0]=0;
}
if ($Razredi[0][0] == 0){
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
    $result = mysqli_query($link,$SQL);
    $ir=0;
    while ($R = mysqli_fetch_array($result)){
        $Razredi[$ir][0]=$R["id"];
        $ir++;
    }
    $StRazredov=$ir;
}else{
    $StRazredov=1;
}

$UcneUreVse[0]=0;
$UcneUreVse[1]=0;
$UcneUreVse[2]=0;
$UcneUreVse[3]=0;

for ($ir=0;$ir < $StRazredov;$ir++){
	$SQL = "SELECT * FROM tabrazdat WHERE id=".$Razredi[$ir][0];
	$result = mysqli_query($link,$SQL);
	if ($R = mysqli_fetch_array($result)){
		$VRazred1=$R["razred"];
		$VParalelka=$R["oznaka"];
		$VRazred=$R["id"];
        $VIdSola=$R["idsola"];
	}
	
	$SQL = "SELECT TabRazred.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, TabVzgojitelji.Priimek AS vpriimek, TabVzgojitelji.Ime AS vime, TabUcenci.*,tabrazdat.* FROM ";
	$SQL = $SQL . "((TabVzgojitelji INNER JOIN (TabRazred INNER JOIN tabucitelji ON TabRazred.IdUcitelj=tabucitelji.IdUcitelj) ON TabVzgojitelji.IdUcitelj=TabRazred.IdVzgojitelj) ";
	$SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.IdUcenec=TabUcenci.IdUcenec) ";
	$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
	$SQL = $SQL . "WHERE idRazred=" . $VRazred;
	$SQL = $SQL . " ORDER BY TabUcenci.Priimek, TabUcenci.Ime";
	$result = mysqli_query($link,$SQL);

    if ($VecSol > 0){
        $SQL1 = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
        $result1 = mysqli_query($link,$SQL1);
        if ($R1 = mysqli_fetch_array($result1)){
            echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $VRazred1 . ". " . $VParalelka . " - ".$R1["solakratko"]."</b><br />";
        }else{
            echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $VRazred1 . ". " . $VParalelka . "</b><br />";
        }
    }else{
        echo "Šolsko leto: <b>" . $VLeto . "/" . ($VLeto+1) . "</b>, Razred: <b>" . $VRazred1 . ". " . $VParalelka . "</b><br />";
    }

	if ($R = mysqli_fetch_array($result)){
		$Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
		$IdUcitelj=$R["IdUcitelj"];
		$Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
		$IdVzgojitelj=$R["IdVzgojitelj"];

		echo "Učitelj: <b>" . $Ucitelj . "</b><br />";
		if ($VRazred1 < 2){
			echo "Drugi učitelj: <b>" . $Vzgojitelj . "</b><br />";
		}else{
			if ($VRazred1 < 6){
				echo "Učitelj OPB: <b>" . $Vzgojitelj . "</b><br />";
			}else{
				echo "<br />";
			}
		}
	}

    $result = mysqli_query($link,$SQL);

	$Indx=0;
	while ($R = mysqli_fetch_array($result)){
		$ucenci[$Indx][0]=$R["IdUcenec"];
		$ucenci[$Indx][1]=$R["Priimek"].", ".$R["Ime"];
		$ucenci[$Indx][2]=$VRazred1.$VParalelka;
		$ucenci[$Indx][3]=$R["DatRoj"];
		$Indx=$Indx+1;
	}
	$StUcencev=$Indx;

	//'Realizacija ur
	$SQL = "SELECT TabRealizacija.*,tabpredmeti.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
	$SQL = $SQL . "(TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
    $SQL = $SQL . "INNER JOIN tabucitelji ON TabRealizacija.referenca=tabucitelji.idUcitelj ";
    $SQL = $SQL . "WHERE Razred=".$VRazred1." AND paralelka='".$VParalelka."' AND leto=".$VLeto." ORDER BY VrstniRed";
	$result = mysqli_query($link,$SQL);


	$UcneUre[0]=0;
	$UcneUre[1]=0;
	$UcneUre[2]=0;
	$UcneUre[3]=0;

	for ($Indx=0;$Indx <= 100;$Indx++){
		$UcneUrePredmeti[$Indx][0]=0;
		$UcneUrePredmeti[$Indx][1]=0;
		$UcneUrePredmeti[$Indx][2]=0;
		$UcneUrePredmeti[$Indx][3]=0;
		$UcneUrePredmeti[$Indx][4]=0;
		$UcneUrePredmeti[$Indx][5]=0;
        $UcneUrePredmeti[$Indx][6]="";
		$Predmeti[$Indx][0]=0;
		$Predmeti[$Indx][1]=0;
	}

	$Indx=0;
	while ($R = mysqli_fetch_array($result)){
		$UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
		$UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
		$UcneUre[2]=$UcneUre[2]+$R["Plan"];
		$UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
		$UcneUrePredmeti[$Indx][0]=$R["Predmet"];
		$UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
		$UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
		$UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
		$UcneUrePredmeti[$Indx][4]=$R["Plan"];
		$UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
        $UcneUrePredmeti[$Indx][6]=$R["Priimek"]." ".$R["Ime"];
		$Indx=$Indx+1;
	}
	$StPredmetovUcneUre=$Indx;

	$UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
	$UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
	$UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
	$UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

	If ($UcneUre[0] > 0){
		echo "<br />Realizacija učnih ur (1. obdobje): <b>".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%</b><br />";
	}
	If ($UcneUre[2] > 0){
		echo "<br />Realizacija učnih ur: <b>".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%</b><br />";
	}

	//'skupna statistika razreda po spolu - zacetek

	$SQL = "SELECT TabUcenci.spol FROM ";
	$SQL = $SQL . "(TabUcenci INNER JOIN TabRazred ON TabUcenci.IdUcenec=TabRazred.IdUcenec) ";
	$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
	$SQL = $SQL . "WHERE idRazred=".$VRazred;
	$SQL = $SQL ." ORDER BY tabrazdat.Razred,tabrazdat.oznaka,Priimek,Ime";
	$result = mysqli_query($link,$SQL);
	
	$StUcencevM=0;
	$StUcencevW=0;
	while ($R = mysqli_fetch_array($result)){
		if ($R["spol"]=="M"){
			$StUcencevM=$StUcencevM+1;
		}else{
			$StUcencevW=$StUcencevW+1;
		}
	}
	
	
	$SQL = "SELECT TabUcenci.*,TabRazred.*,TabOcene.*,tabrazdat.* FROM ";
	$SQL = $SQL . "((TabUcenci INNER JOIN TabRazred ON TabUcenci.IdUcenec=TabRazred.IdUcenec) ";
	$SQL = $SQL . "INNER JOIN TabOcene ON TabUcenci.IdUcenec=TabOcene.IdUcenec) ";
	$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id ";
	$SQL = $SQL . "WHERE idRazred=".$VRazred." AND tabocene.leto=".$VLeto;
	$SQL = $SQL ." ORDER BY tabrazdat.Razred,tabrazdat.oznaka,Priimek,Ime";
	$result = mysqli_query($link,$SQL);

	$StUcencevMNeg=0;
	$StUcencevWNeg=0;
	$StUcencevMNegPol=0;
	$StUcencevWNegPol=0;
	$NegativniUc=0;
	if (mysqli_num_rows($result) > 0){
		while ($R = mysqli_fetch_array($result)){
			if (($R["OcenaKoncna"] == "1") or ($R["OcenaKoncna"] == "Ni opravil")){
				if ($R["IdUcenec"] != $NegativniUc){
					if ($R["Spol"]=="M"){
						$StUcencevMNeg=$StUcencevMNeg+1;
					}else{
						$StUcencevWNeg=$StUcencevWNeg+1;
					}
					$NegativniUc=$R["IdUcenec"];
				}
			}
		}

        $result = mysqli_query($link,$SQL);
        $NegativniUc=0;
		while ($R = mysqli_fetch_array($result)){
			if (($R["OcenaPolletna"] == "1") or ($R["OcenaPolletna"] == "Ni opravil")){
                if ($R["IdUcenec"] != $NegativniUc){
				    if ($R["Spol"]=="M"){
					    $StUcencevMNegPol=$StUcencevMNegPol+1;
				    }else{
					    $StUcencevWNegPol=$StUcencevWNegPol+1;
				    }
                    $NegativniUc=$R["IdUcenec"];
                }
			}
		}
	}
//	'skupna statistika razreda po spolu - konec

//	'negativne ocene učencev pri predmetih-zacetek

	$SQL = "SELECT DISTINCT tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,";
	$SQL = $SQL . "tabucenje.Predmet,tabucenje.Razred,tabucenje.Paralelka,tabucenje.Leto ";
	$SQL = $SQL . "FROM tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet ";
	$SQL = $SQL . "WHERE idRazred=".$VRazred." AND  Prioriteta< 3 ";
	$SQL = $SQL . "ORDER BY tabpredmeti.VrstniRed";
	$result = mysqli_query($link,$SQL);

	$StPredmetov=0;

    while ($R = mysqli_fetch_array($result)){
		$Predmeti[$StPredmetov][0]=$R["Predmet"];
		$Predmeti[$StPredmetov][1]=$R["Oznaka"];
		$StPredmetov=$StPredmetov+1;
	}


	$IndxUcN=0;
	$IndxUcNP=0;
    $IndxNeoc=0;

	for ($Indx=0;$Indx <= 100;$Indx++){
		$PredmetNegativno[$Indx]=0;
		$PredmetNegativnoPol[$Indx]=0;
	}
	for ($Indx=0;$Indx <= 30;$Indx++){
		$UcenciNegativni[$Indx][0]=0;
		$UcenciNegativni[$Indx][1]=0;
		$UcenciNegativni[$Indx][2]=0;
		$UcenciNegativniPol[$Indx][0]=0;
		$UcenciNegativniPol[$Indx][1]=0;
		$UcenciNegativniPol[$Indx][2]=0;
		$UcenciNezadostni[$Indx]=0;
		$UcenciNezadostniPol[$Indx]=0;
	}

	for ($IndxUc=0;$IndxUc <= ($StUcencev-1);$IndxUc++){
		$UcenciNezadostni[$IndxUc]=0;
		$UcenciNezadostniPol[$IndxUc]=0;
		for ($Indx1= 0;$Indx <= ($StPredmetov-1);$Indx++){
			$Ocene[$Indx1][4]="";
			$Ocene[$Indx1][5]="";
		}

		$SQL = "SELECT  * FROM TabOcene WHERE IdUcenec=".$ucenci[$IndxUc][0]." AND leto=".$VLeto;
		$result = mysqli_query($link,$SQL);
		$Indx=0;
	    while ($R = mysqli_fetch_array($result)){
			for ($Indx1=0;$Indx1 <= ($StPredmetov-1);$Indx1++){
				if ($R["IdPredmet"]==$Predmeti[$Indx1][0]){
					$Ocene[$Indx1][4]=$R["OcenaKoncna"];
					$Ocene[$Indx1][5]=$R["OcenaPolletna"];
                    $Neocenjen[$Indx1]=$R["Neocenjen"];
					if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
						$PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
						$UcenciNegativni[$IndxUcN][0]=$ucenci[$IndxUc][0];
						$UcenciNegativni[$IndxUcN][1]=$ucenci[$IndxUc][1];
						$UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
						$IndxUcN=$IndxUcN+1;
						$UcenciNezadostni[$IndxUc]=1;
					}
					if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
						$PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
						$UcenciNegativniPol[$IndxUcNP][0]=$ucenci[$IndxUc][0];
						$UcenciNegativniPol[$IndxUcNP][1]=$ucenci[$IndxUc][1];
						$UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
						$IndxUcNP=$IndxUcNP+1;
						$UcenciNezadostniPol[$IndxUc]=1;
					}
                    if ($Neocenjen[$Indx1]==1){
                        $UcenciNeocenjeni[$IndxNeoc][0]=$ucenci[$IndxUc][0];
                        $UcenciNeocenjeni[$IndxNeoc][1]=$ucenci[$IndxUc][1];
                        $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                        $IndxNeoc=$IndxNeoc+1;
                    }
					
				}
			}
			$Indx=$Indx+1;
		}
	}

	$Nezadostnih=0;
	$NezadostnihPol=0;
	for ($Indx=0;$Indx <= ($StUcencev-1);$Indx++){
		$Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
		$NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
	}

	echo "Uspeh (polletni): <b>".number_format((($StUcencev-$NezadostnihPol)/$StUcencev)*100,2)."%</b><br />";
	echo "Uspeh: <b>".number_format((($StUcencev-$Nezadostnih)/$StUcencev)*100,2)."</b><br />";

	echo "<br />Polletni uspeh";
	echo "<table border=1>";
	echo "<tr><th>Razred</th><th>Učenci</th><th></th><th>Učenke</th><th></th><th>Skupaj</th><th></th></tr>";
	echo "<tr>&nbsp;<td></td><td>Št.</td><td>%</td><td>Št.</td><td>%</td><td>Št.</td><td>%</td></tr>";
	echo "<tr>";
	echo "<td>v razredu</td>";
	echo "<td align=center>".$StUcencevM."</td><td align=right>".number_format($StUcencevM/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".$StUcencevW."</td><td align=right>".number_format($StUcencevW/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevM+$StUcencevW)."</td><td align=right>".number_format((($StUcencevM+$StUcencevW)/$StUcencev)*100,0)."%</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>pozitivnih</td>";
	echo "<td align=center>".($StUcencevM-$StUcencevMNegPol)."</td><td align=right>".number_format(($StUcencevM-$StUcencevMNegPol)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevW-$StUcencevWNegPol)."</td><td align=right>".number_format(($StUcencevW-$StUcencevWNegPol)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevM+$StUcencevW-$StUcencevMNegPol-$StUcencevWNegPol)."</td><td align=right>".number_format(($StUcencevM+$StUcencevW-$StUcencevMNegPol-$StUcencevWNegPol)/$StUcencev*100,0)."%</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>negativnih</td>";
	echo "<td align=center>".$StUcencevMNegPol."</td><td align=right>".number_format(($StUcencevMNegPol)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".$StUcencevWNegPol."</td><td align=right>".number_format(($StUcencevWNegPol)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevMNegPol+$StUcencevWNegPol)."</td><td align=right>".number_format(($StUcencevMNegPol+$StUcencevWNegPol)/$StUcencev*100,0)."%</td>";
	echo "</tr>";
	echo "</table><br />";

	echo "Končni uspeh";
	echo "<table border=1>";
	echo "<tr><th>Razred</th><th>Učenci</th><th></th><th>Učenke</th><th></th><th>Skupaj</th><th></th></tr>";
	echo "<tr>&nbsp;<td></td><td>Št.</td><td>%</td><td>Št.</td><td>%</td><td>Št.</td><td>%</td></tr>";
	echo "<tr>";
	echo "<td>v razredu</td>";
	echo "<td align=center>".$StUcencevM."</td><td align=right>".number_format($StUcencevM/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".$StUcencevW."</td><td align=right>".number_format($StUcencevW/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevM+$StUcencevW)."</td><td align=right>".number_format(($StUcencevM+$StUcencevW)/$StUcencev*100,0)."%</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>pozitivnih</td>";
	echo "<td align=center>".($StUcencevM-$StUcencevMNeg)."</td><td align=right>".number_format(($StUcencevM-$StUcencevMNeg)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevW-$StUcencevWNeg)."</td><td align=right>".number_format(($StUcencevW-$StUcencevWNeg)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)."</td><td align=right>".number_format(($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)/$StUcencev*100,0)."%</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>negativnih</td>";
	echo "<td align=center>".$StUcencevMNeg."</td><td align=right>".number_format(($StUcencevMNeg)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".$StUcencevWNeg."</td><td align=right>".number_format(($StUcencevWNeg)/($StUcencev)*100,0)."%</td>";
	echo "<td align=center>".($StUcencevMNeg+$StUcencevWNeg)."</td><td align=right>".number_format(($StUcencevMNeg+$StUcencevWNeg)/$StUcencev*100,0)."%</td>";
	echo "</tr>";
	echo "</table><br />";
	
	echo "<br />Število negativnih učencev pri predmetih (učenci, ki niso dosegli minimalnega znanja) - polletje<br />";
	echo "<table border=0>";
	echo "<tr>";
	for ($Indx=0;$Indx <= ($StPredmetov-1);$Indx++){
		echo "<td><table border=1><th>".$Predmeti[$Indx][1]."</th><tr><td width=44 height=15 align=center>".$PredmetNegativnoPol[$Indx]."</td></tr></table></td>";
		if ((($Indx+1) % 11)==0){
			echo "</tr><tr>";
		}
	}
	echo "</tr></table>";

	echo "<br />Število negativnih učencev pri predmetih (učenci, ki niso dosegli minimalnega znanja)<br />";
	echo "<table border=0>";
	echo "<tr>";
	for ($Indx=0;$Indx <= ($StPredmetov-1);$Indx++){
		echo "<td><table border=1><th>".$Predmeti[$Indx][1]."</th><tr><td width=44 height=15 align=center>".$PredmetNegativno[$Indx]."</td></tr></table></td>";
		if ((($Indx+1) % 11)==0){
			echo "</tr><tr>";
		}
	}
	echo "</tr></table>";

	echo "<br />Učenci z negativnimi ocenami (prevladujejo negativne ocene) - polletje<br />";
	echo "<table border=1>";
	echo "<th width=20>Št.</th><th width=310>Učenec</th><th width=280>Predmet</th>";
	for ($Indx=0;$Indx < $IndxUcNP;$Indx++){
		echo "<tr><td align=center>".($Indx+1)."</td><td>".$UcenciNegativniPol[$Indx][1]."</td><td>".$UcenciNegativniPol[$Indx][2]."</td></tr>";
	}
	echo "</table>";

	echo "<br />Učenci z negativnimi ocenami (prevladujejo negativne ocene)<br />";
	echo "<table border=1>";
	echo "<th width=20>Št.</th><th width=310>Učenec</th><th width=280>Predmet</th>";
	for ($Indx=0;$Indx < $IndxUcN;$Indx++){
		echo "<tr><td align=center>".($Indx+1)."</td><td>".$UcenciNegativni[$Indx][1]."</td><td>".$UcenciNegativni[$Indx][2]."</td></tr>";
	}
	echo "</table>";

	//'negativne ocene učencev pri predmetih-konec

	//'Izpis realizacije po predmetih-začetek

	If ($UcneUre[0] > 0){
		echo "<br />Realizacija učnih ur (1. obdobje): ".number_format(($UcneUre[1]/$UcneUre[0])*100,2)."%<br />";

		echo "<table border='1'>";
        echo "<tr><th>Predmet / učitelj</th><th>Realizirano</th><th>Procent</th></tr>";
		for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
            echo "<tr>";
			echo "<td>".$UcneUrePredmeti[$Indx][1]." / ".$UcneUrePredmeti[$Indx][6]."</td>";
			if ($UcneUrePredmeti[$Indx][2] > 0){
				echo "<td align=center>".$UcneUrePredmeti[$Indx][3]." / ".$UcneUrePredmeti[$Indx][2]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][3]/$UcneUrePredmeti[$Indx][2])*100,2)."%</td>";
			}else{
				echo "<td align=center>".$UcneUrePredmeti[$Indx][3]." / ".$UcneUrePredmeti[$Indx][2]."</td><td></td>";
			}
            echo "</tr>";
		}
		echo "</table>";
		if ($StPredmetovUcneUre < $StPredmetov){
			echo "<br /><font color=red>Manjkajo še realizacije za št. predmetov: ".$StPredmetov-$StPredmetovUcneUre."</font><br />";
		}
	}

	If ($UcneUre[2] > 0){
		echo "<br />Realizacija učnih ur: ".number_format(($UcneUre[3]/$UcneUre[2])*100,2)."%<br />";

		echo "<table border=0>";
        echo "<tr><th>Predmet / učitelj</th><th>Realizirano</th><th>Procent</th></tr>";
//		for ($Indx=0;$Indx < $StPredmetov;$Indx++){
        for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
			echo "<tr>";
            echo "<td>".$UcneUrePredmeti[$Indx][1]." / ".$UcneUrePredmeti[$Indx][6]."</td>";
			if ($UcneUrePredmeti[$Indx][4] > 0){
				echo "<td align=center>".$UcneUrePredmeti[$Indx][5]." / ".$UcneUrePredmeti[$Indx][4]."</td><td align=center>".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%</td>";
			}else{
				echo "<td align=center>".$UcneUrePredmeti[$Indx][5]." / ".$UcneUrePredmeti[$Indx][4]."</td><td></td>";
			}
			echo "</tr>";
		}
		echo "</table>";
	}
//	'Izpis realizacije po predmetih-konec

//	'Izpis vzgojnih ukrepov-začetek

	echo "<br />Izrečeni vzgojni ukrepi: ";
	echo "<br /><table border=1>";
	echo "<th width=20>Št.</th><th width=310>Učenec</th><th width=280>Ukrep</th>";

	$Indx2=0;

	for ($Indx1 = 0;$Indx1 <= 30;$Indx1++){
		if (isset($ucenci[$Indx1][0])){
			$SQL = "SELECT TabVzgUkrepi.*, TabOpomini.Opis FROM ";
			$SQL = $SQL . "TabOpomini INNER JOIN TabVzgUkrepi ON TabOpomini.IdUkrep = TabVzgUkrepi.IdUkrep ";
			$SQL = $SQL . "WHERE TabVzgUkrepi.IdUcenec=" .$ucenci[$Indx1][0] . " AND leto=".$VLeto." AND TabVzgUkrepi.idUkrep < 7";

			$result = mysqli_query($link,$SQL);

			$Indx=0;
			while ($R = mysqli_fetch_array($result)){
				$Indx2=$Indx2+1;
				echo "<tr><td width=20 align=center>".$Indx2."</td><td width=280>".$ucenci[$Indx1][1]."</td><td width=280>".$R["Opis"]."</td></tr>";
				$Indx = $Indx+1;
			} 
		}
	}	
	echo "</table>";
	//'Izpis vzgojnih ukrepov-konec

	//'Izpis dnevov dejavnosti-začetek
	$SQL = "SELECT TabOstaleDej.*, TabAktivnosti.* FROM TabOstaleDej INNER JOIN TabAktivnosti ON TabOstaleDej.IdAktivnost=TabAktivnosti.IdAktivnost WHERE idRazred=".$VRazred." ORDER BY TabAktivnosti.IdAktivnost";
	$result = mysqli_query($link,$SQL);

	echo "<br />Dnevi dejavnosti:<br />";
	echo "<table border=1 cellspacing=0>";
	echo "<tr><th width=20>Št.</th><th width=100>Aktivnost</th><th width=180>Opis</th><th width=80>Datum</th><th width=140>Kraj</th><th width=70>Trajanje</th><th width=70>Vodja</th><th>Cena EUR<br /> na učenca</th></tr>";

	$Indx=0;
	while ($R = mysqli_fetch_array($result)){
		echo "<tr>";
		echo "<td align=center>".($Indx+1)."</td>";
		echo "<td>".$R["Opis"]."</td>";
		echo "<td>".$R["Vsebina"]."</td>";
		echo "<td align=center>".$R["Datum"]."</td>";
		echo "<td>".$R["Kraj"]."</td>";
		echo "<td align=center>".$R["Trajanje"]."</td>";
		echo "<td>".$R["Vodja"]."</td>";
        echo "<td>".$R["cena"]."</td>";
		echo "</tr>";
		$Indx = $Indx+1;
	}
		
	echo "</table>";

	//'Izpis dnevov dejavnosti-konec

	//'Izpis komentarja razrednika - zacetek
	$SQL = "SELECT TabRazrednikPor.*,tabucitelji.Priimek,tabucitelji.Ime FROM TabRazrednikPor INNER JOIN tabucitelji ON TabRazrednikPor.Razrednik=tabucitelji.IdUcitelj WHERE idRazred=".$VRazred;
	$result = mysqli_query($link,$SQL);

	while ($R = mysqli_fetch_array($result)){
		echo "<h3>Polletno poročilo učitelja - ".$R["Ime"]." ".$R["Priimek"]."</h3>";
		echo "<p><b>Uspeh oddelka in rezultati učno vzgojnega dela</b>: <br />".str_replace("\n","<br />",$R["Komentar"])."</p>";
		echo "<p><b>Rezultati učno vzgojnega dela (OPB)</b>: <br />".str_replace("\n","<br />",$R["UcnoVzgDelo"])."</p>";
		echo "<p><b>Vzgojna problematika in socialna klima oddelka</b>: <br />".str_replace("\n","<br />",$R["VzgUkrepi"])."</p>";
		echo "<p><b>Priporočila, razmišljanja za naslednje ocenjevalno obdobje</b>: <br />".str_replace("\n","<br />",$R["Priporocila"])."</p>";
        //echo "<p><b>Analiza pedagoškega dela v učnih skupinah</b>: <br />".str_replace("\n","<br />",$R["Uspehi"])."</p>";
		echo "<p><b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b>: <br />".str_replace("\n","<br />",$R["Pohvale"])."</p>";
	}
	//'Izpis komentarja razrednika - konec

	//'Izpis končnega komentarja razrednika - zacetek
	$SQL = "SELECT TabRazrednikPorK.*,tabucitelji.Priimek,tabucitelji.Ime FROM TabRazrednikPorK INNER JOIN tabucitelji ON TabRazrednikPorK.Razrednik=tabucitelji.IdUcitelj WHERE idRazred=".$VRazred;
	$result = mysqli_query($link,$SQL);

	while ($R = mysqli_fetch_array($result)){
		echo "<h3>Končno poročilo učitelja - ".$R["Ime"]." ".$R["Priimek"]."</h3>";
		echo "<p><b>Uspeh oddelka in rezultati učno vzgojnega dela</b>: <br />".str_replace("\n","<br />",$R["Komentar"])."</p>";
		echo "<p><b>Vzgojna problematika in socialna klima oddelka</b>: <br />".str_replace("\n","<br />",$R["VzgUkrepi"])."</p>";
		echo "<p><b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b>: <br />".str_replace("\n","<br />",$R["Pohvale"])."</p>";
		echo "<p><b>Sestanki oddelčnega učiteljskega (razrednega, celotnega učiteljskega zbora)</b>: <br />".str_replace("\n","<br />",$R["UcnoVzgDelo"])."</p>";
		echo "<p><b>Priporočila, razmišljanja za naslednje šolsko leto</b>: <br />".str_replace("\n","<br />",$R["Priporocila"])."</p>";
        //echo "<p><b>Analiza pedagoškega dela v učnih skupinah</b>: <br />".str_replace("\n","<br />",$R["Uspehi"])."</p>";
		//echo "<p><b>Drugo</b>: <br />".str_replace("\n","<br />",$R["Uspehi"])."</p>";
	}
	//'Izpis komentarja razrednika - konec
	echo "<br /><hr><br />";

}
If ($UcneUreVse[0] > 0){
	echo "<br />Realizacija učnih ur (1. obdobje): <b>".number_format(($UcneUreVse[1]/$UcneUreVse[0])*100,2)."%</b><br />";
}
If ($UcneUreVse[2] > 0){
	echo "<br />Realizacija vseh učnih ur: <b>".number_format(($UcneUreVse[3]/$UcneUreVse[2])*100,2)."%</b><br />";
}

echo "<br /><a href='IzpisRealizacij.php'>Realizacije po predmetih in skupaj</a><br />";
?>

</body>
</html>
