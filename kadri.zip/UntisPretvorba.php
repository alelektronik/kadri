<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Urnik
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%Y%m%d",
            yearsRange:[2012,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%Y%m%d",
            yearsRange:[2012,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}

$RazsirjenVnos=true;

$SQL = "SELECT iducitelj,ime,priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    //echo "Pozdravljeni " . $R["ime"]  . " " . $R["priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
$result = mysqli_query($link,$SQL);
$indx=0;
while ($R = mysqli_fetch_array($result)){
	$VRazredi[$indx][0]=$R["id"];
	$VRazredi[$indx][1]=$R["razred"];
	$VRazredi[$indx][2]=$R["oznaka"];
	$indx=$indx+1;
}
$VStRazredov=$indx;

switch ($Vid){
	case "1": // 'pretvorba učiteljev
		echo "<form accept-charset='utf-8'  name='urnik' method='post' action='UntisPretvorba.php'>";
		$SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabuntisucitelj.uciteljuntis FROM tabucitelji ";
		$SQL = $SQL . "LEFT JOIN TabUntisUcitelj ON tabucitelji.idUcitelj=TabUntisUcitelj.idUcitelj ";
		$SQL = $SQL . "WHERE tabucitelji.status > 0 ";
		$SQL = $SQL . "ORDER BY priimek,ime";
		$result = mysqli_query($link,$SQL);
		
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Ime</th><th>Ime Untis</th></tr>";
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td><input name='uc_".$indx."' type='hidden' value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</td>";
			echo "<td><input name='untis_".$indx."' type='text' size='10' value='".$R["uciteljuntis"]."'></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='1a'>";
		echo "<input name='zapisov' type='hidden' value='".($indx-1)."'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "1a": //	'vpis pretvorb učiteljev
		for ($indx=1;$indx <= $_POST["zapisov"];$indx++){
			$SQL = "SELECT id FROM tabuntisucitelj WHERE idUcitelj=".$_POST["uc_".$indx];
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$SQL = "UPDATE TabUntisUcitelj SET UciteljUntis='".$_POST["untis_".$indx]."' WHERE id=".$R["id"];
			}else{
				$SQL = "INSERT INTO TabUntisUcitelj (idUcitelj,UciteljUntis) VALUES (".$_POST["uc_".$indx].",'".$_POST["untis_".$indx]."')";
			}
			$result = mysqli_query($link,$SQL);
			//echo $SQL."<br />";
		}
		echo "<h2>Pretvorbe vpisane!</h2>";
        break;
	case "2":  //'pretvorba predmetov
		echo "<form accept-charset='utf-8'  name='urnik' method='post' action='UntisPretvorba.php'>";
		$SQL = "SELECT tabpredmeti.id,tabpredmeti.oznaka,tabpredmeti.opis,tabuntispredm.predmetuntis FROM tabpredmeti ";
		$SQL = $SQL . "LEFT JOIN TabUntisPredm ON tabpredmeti.id=TabUntisPredm.idPredmet ";
		$SQL = $SQL . "ORDER BY oznaka";
		$result = mysqli_query($link,$SQL);
		
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Predmet</th><th>Predmet Untis</th></tr>";
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td><input name='pr_".$indx."' type='hidden' value='".$R["id"]."'>".$R["oznaka"]." - ".$R["opis"]."</td>";
			echo "<td><input name='untis_".$indx."' type='text' size='5' value='".$R["predmetuntis"]."'></td>";
			echo "</tr>";
			$indx=$indx+1;;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='2a'>";
		echo "<input name='zapisov' type='hidden' value='".($indx-1)."'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "2a":	//'vpis pretvorb predmetov
		for ($indx=1;$indx <=$_POST["zapisov"];$indx++){
			$SQL = "SELECT id FROM tabuntispredm WHERE idPredmet=".$_POST["pr_".$indx];
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$SQL = "UPDATE TabUntisPredm SET PredmetUntis='".$_POST["untis_".$indx]."' WHERE id=".$R["id"];
			}else{
				$SQL = "INSERT INTO TabUntisPredm (idPredmet,PredmetUntis) VALUES (".$_POST["pr_".$indx].",'".$_POST["untis_".$indx]."')";
			}
			$result = mysqli_query($link,$SQL);
			//echo $SQL."<br />";
		}
		echo "<h2>Pretvorbe vpisane!</h2>";
        break;
	case "3": // 'pretvorba prostorov
		echo "<form accept-charset='utf-8'  name='urnik' method='post' action='UntisPretvorba.php'>";
		$SQL = "SELECT tabprostor.idprostor,tabprostor.oznaka,tabprostor.opis,tabprostor.stevilka,tabuntisprostor.prostoruntis FROM tabprostor ";
		$SQL = $SQL . "LEFT JOIN TabUntisProstor ON tabprostor.idProstor=TabUntisProstor.idProstor ";
		$SQL = $SQL . "ORDER BY oznaka";
		$result = mysqli_query($link,$SQL);
		
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Prostor</th><th>Prostor Untis</th></tr>";
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td><input name='pr_".$indx."' type='hidden' value='".$R["idprostor"]."'>".$R["oznaka"]." - ".$R["opis"]."(".$R["stevilka"].")</td>";
			echo "<td><input name='untis_".$indx."' type='text' size='5' value='".$R["prostoruntis"]."'></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='3a'>";
		echo "<input name='zapisov' type='hidden' value='".($indx-1)."'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "3a":	//'vpis pretvorb predmetov
		for ($indx=1;$indx <= $_POST["zapisov"];$indx++){
			$SQL = "SELECT id FROM tabuntisprostor WHERE idProstor=".$_POST["pr_".$indx];
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$SQL = "UPDATE TabUntisProstor SET ProstorUntis='".$_POST["untis_".$indx]."' WHERE id=".$R["id"];
			}else{
				$SQL = "INSERT INTO TabUntisProstor (idProstor,ProstorUntis) VALUES (".$_POST["pr_".$indx].",'".$_POST["untis_".$indx]."')";
			}
			$result = mysqli_query($link,$SQL);
			//echo $SQL."<br />";
		}
		echo "<h2>Pretvorbe vpisane!</h2>";
        break;
	case "4": //uvozni obrazec za urnik
		echo "<form accept-charset='utf-8'  name='urnik' ENCTYPE='multipart/form-data' method='post' action='UvozUntisUrnika.php'>";
		echo "<h2>Import urnika za šolsko leto (GPU001.txt)</h2>";
		echo "<select name='LetoUrnik'>";
		echo "<option value='".$VLeto."' selected>".$VLeto."/".($VLeto+1)."</option>";
		echo "<option value='".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</option>";
		echo "</select><br />";
        echo "Velja od: <input name='od' type='text' size='8' id='dat01' value=''><br />";
        echo "Velja do: <input name='do' type='text' size='8' id='dat02' value=''><br />";
		echo "Oznaka za preduro: <select name='zacetek'>";
		echo "<option value='0' selected>0</option>";
		echo "<option value='1'>1</option>";
		echo "</select><br />";
		echo "Datoteka: <input name='file' type='file' size='40'><br />";
		echo "<input name='Povezava' type='hidden' value='/'>";
		echo "<input name='id' type='hidden' value='4a'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "7": //'uvoz sistemizacije
		echo "<form accept-charset='utf-8'  name='urnik' ENCTYPE='multipart/form-data' method='post' action='UvozUntisPouka.php'>";
		echo "<h2>Uvoz sistemizacije za šolsko leto (GPU002.txt)</h2>";
		echo "<select name='LetoUrnik'>";
		echo "<option value='".$VLeto."' selected>".$VLeto."/".($VLeto+1)."</option>";
		echo "<option value='".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</option>";
		echo "</select><br />";
		echo "Datoteka: <input name='file' type='file' size='40'><br />";
		echo "<input name='Povezava' type='hidden' value='/'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "5": //'pretvorba učencev
		echo "<form accept-charset='utf-8'  name='urnik' method='post' action='UntisPretvorba.php'>";
		$SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabuntisucenci.ucenecuntis FROM (TabRazred ";
		$SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.idUcenec=TabUcenci.idUcenec) ";
		$SQL = $SQL . "LEFT JOIN TabUntisUcenci ON TabRazred.idUcenec=TabUntisUcenci.idUcenec ";
		$SQL = $SQL . "WHERE TabRazred.razred >= 0 AND TabRazred.leto=".$VLeto;
		$SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime";
		$result = mysqli_query($link,$SQL);
		echo "<h2>Učenci v 1.-9. razredu ".$VLeto."/".($VLeto+1)."</h2>";
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Ime</th><th>Ime Untis</th></tr>";
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td><input name='uc_".$indx."' type='hidden' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"]." (".$R["razred"].". ".mb_strtolower($R["paralelka"],$encoding).")</td>";
			if ($R["ucenecuntis"] != ""){
				echo "<td><input name='untis_".$indx."' type='text' size='10' value='".$R["ucenecuntis"]."'></td>";
			}else{
				echo "<td><input name='untis_".$indx."' type='text' size='10' value='".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."'></td>";
			}
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='5a'>";
		echo "<input name='zapisov' type='hidden' value='".($indx-1)."'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "5a":	//'vpis pretvorb učencev
		for ($indx=1;$indx <= $_POST["zapisov"];$indx++){
			$SQL = "SELECT id FROM tabuntisucenci WHERE idUcenec=".$_POST["uc_".$indx];
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$SQL = "UPDATE TabUntisUcenci SET UcenecUntis='".$_POST["untis_".$indx]."' WHERE id=".$R["id"];
			}else{
				$SQL = "INSERT INTO TabUntisUcenci (idUcenec,UcenecUntis) VALUES (".$_POST["uc_".$indx].",'".$_POST["untis_".$indx]."')";
			}
			$result = mysqli_query($link,$SQL);
			//echo $SQL."<br />"
		}
		echo "<h2>Pretvorbe vpisane!</h2>";
        break;
	case "6":
		echo "<form accept-charset='utf-8'  name='urnik' ENCTYPE='multipart/form-data' method='post' action='UvozUntisSkupine.php'>";
		echo "<h2>Uvoz podatkov o izbirnih in nivojskih predmetih (GPU015.txt)</h2>";
		echo "<select name='LetoUrnik'>";
		echo "<option value='".$VLeto."' selected>".$VLeto."/".($VLeto+1)."</option>";
		echo "<option value='".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</option>";
		echo "</select><br />";
		echo "Datoteka: <input name='file' type='file' size='40'><br />";
		echo "<input name='Povezava' type='hidden' value='/'>";
		echo "<input name='id' type='hidden' value='6a'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
	case "8":
		echo "<form accept-charset='utf-8'  name='urnik' ENCTYPE='multipart/form-data' method='post' action='UntisPretvorba.php'>";
		echo "<h2>Uvoz nadomeščanj (GPU014.txt)</h2>";
		echo "<b>Od (vključno)</b> <select name='odDan'>";
		for ($indx=1;$indx <= 31;$indx++){
			if ($Danes->format('j')==$indx){
				echo "<option value='".$indx."' selected>".$indx."</option>";
			}else{
				echo "<option value='".$indx."'>".$indx."</option>";
			}
		}
		echo "</select>";
		echo "<select name='odMesec'>";
		for ($indx=1;$indx <= 12;$indx++){
			if ($Danes->format('n')==$indx){
				echo "<option value='".$indx."' selected>".$indx."</option>";
			}else{
				echo "<option value='".$indx."'>".$indx."</option>";
			}
		}
		echo "</select>";
		echo "<select name='odLeto'>";
		echo "<option value='".$Danes->format('Y')."' selected>".$Danes->format('Y')."</option>";
		echo "<option value='".($Danes->format('Y')-1)."'>".($Danes->format('Y')-1)."</option>";
		echo "<option value='".($Danes->format('Y')+1)."'>".($Danes->format('Y')+1)."</option>";
		echo "</select><br />";
		echo "<b>Do (vključno)</b> <select name='DoDan'>";
		for ($indx=1;$indx <= 31;$indx++){
            if ($Danes->format('j')==$indx){
                echo "<option value='".$indx."' selected>".$indx."</option>";
            }else{
                echo "<option value='".$indx."'>".$indx."</option>";
            }
		}
		echo "</select>";
		echo "<select name='DoMesec'>";
        for ($indx=1;$indx <= 12;$indx++){
            if ($Danes->format('n')==$indx){
                echo "<option value='".$indx."' selected>".$indx."</option>";
            }else{
                echo "<option value='".$indx."'>".$indx."</option>";
            }
        }
		echo "</select>";
		echo "<select name='DoLeto'>";
        echo "<option value='".$Danes->format('Y')."' selected>".$Danes->format('Y')."</option>";
        echo "<option value='".($Danes->format('Y')-1)."'>".($Danes->format('Y')-1)."</option>";
        echo "<option value='".($Danes->format('Y')+1)."'>".($Danes->format('Y')+1)."</option>";
		echo "</select><br />";
        echo "<input name='sprosceno' type='checkbox' checked='checked'>Ne uvažaj sproščenih ur<br />";
		echo "<b>Datoteka:</b> <input name='file' type='file' size='40'><br />";
		echo "<input name='Povezava' type='hidden' value='/'>";
		echo "<input name='id' type='hidden' value='8a'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br />";
        break;
    case "8a":
        $uploaded=false;
        $allowedExts = array("TXT", "txt", "csv", "CSV");
        $Preneseno=$_FILES["file"];
        $extension = explode(".", $Preneseno["name"]);
        $extension = end($extension);
        $extension = strtolower($extension);
        if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain"))
            && ($_FILES["file"]["size"] < 500000)
            && in_array($extension, $allowedExts)){
                if ($_FILES["file"]["error"] > 0){
                    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                }else{
                    echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                    echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                    echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                    echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
             
                    if (file_exists("dato/" . $_FILES["file"]["name"])){
                        echo $_FILES["file"]["name"] . " že obstaja. ";
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno kot: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }else{
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno kot: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }
                    echo "<br />";
               }
        }else{
            echo "Napačna datoteka (tip, velikost)<br />";
        }

        if ($uploaded){
            $myFile = "dato/".$_FILES["file"]["name"];
            $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
            $indx=0;
            while(!feof($fh)){
               //echo fgets($file). "<br />";
               $Vrstica[$indx]=fgets($fh);
               $indx=$indx+1;
            }
            $StVrstic=$indx-1;
            fclose($fh);

            $brisi = array("\"","\r\n");
            $i1=0;
            $indx0=0;
            while ($indx0 <= $StVrstic){
                if (mb_strlen($Vrstica[$indx0],$encoding) > 0){  //izpusti prazne vrstice
                    $VNadom[$i1]=explode(";",$Vrstica[$indx0]);
                    for ($i=0;$i < count($VNadom[$i1]);$i++){
                        $VNadom[$i1][$i]=str_replace($brisi,"",$VNadom[$i1][$i]);
                    }
                    $i1++;
                }
                $indx0++;
            }
            $StVrstic=$i1-1;
            $NeSproscenaUra=false;
            if (isset($_POST["sproscena"])){
                $NeSproscenaUra=true;
            }
            
            for($i=1;$i <= $StVrstic;$i++){
                $Datum=new DateTime(substr($VNadom[$i][1],0,4)."-".substr($VNadom[$i][1],4,2)."-".substr($VNadom[$i][1],6,2));
                $od=new DateTime($_POST["odLeto"]."-".$_POST["odMesec"]."-".$_POST["odDan"]);
                $do=new DateTime($_POST["DoLeto"]."-".$_POST["DoMesec"]."-".$_POST["DoDan"]);
                if (!(!$NeSproscenaUra && ($VNadom[$i][19] == "L"))){
                    if (($Datum->format('Ymd') >= $od->format('Ymd')) && ($Datum->format('Ymd') <= $do->format('Ymd'))){
                        $SQL = "SELECT * FROM tabnadomescanja WHERE iduntis=".$VNadom[$i][0]." AND datumnad='".$Datum->format('d.m.Y')."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){ //obstaja zapis o nadomeščanju
                            //preveri, če gre za iste osebe v zapisu
                            $odsotni=0;
                            if (strlen($VNadom[$i][5]) > 0){
                                $SQL = "SELECT iducitelj FROM tabuntisucitelj WHERE uciteljuntis='".$VNadom[$i][5]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $odsotni=$R1["iducitelj"];
                                }
                            }
                            $nadomestni=0;
                            if (strlen($VNadom[$i][6]) > 0){
                                $SQL = "SELECT iducitelj FROM tabuntisucitelj WHERE uciteljuntis='".$VNadom[$i][6]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $nadomestni=$R1["iducitelj"];
                                }
                            }
                            $nadomestni1="";
                            if ($VNadom[$i][6]=="ZDR"){
                                //pogleda, kateri priimeki učiteljev so navedeni in pridobi njihove id številke
                                $zdruzi=explode(",",$VNadom[$i][16]); //tekst k nadomeščanju
                                for($j=0;$j < count($zdruzi);$j++){
                                    $SQL = "SELECT iducitelj FROM tabucitelji WHERE priimek LIKE '%".trim($zdruzi[$j])."%'";
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        if (strlen($nadomestni1) > 0){
                                            $nadomestni1 .= ",".$R1["iducitelj"];
                                        }else{
                                            $nadomestni1 .= $R1["iducitelj"];
                                        }
                                    }
                                }
                                $nadomestni2=explode(",",$nadomestni1);
                                $nadomestni=intval($nadomestni2[0]);
                            }
                            $ura=$VNadom[$i][2];
                            $predmet=0;
                            if (strlen($VNadom[$i][7]) > 0){
                                $SQL = "SELECT idpredmet,predmetuntis FROM tabuntispredm WHERE predmetuntis='".$VNadom[$i][7]."'";
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){ 
                                    if ($R1["predmetuntis"]==$VNadom[$i][7]){
                                        $predmet=$R1["idpredmet"];
                                    }
                                }
                            }
                            $prostor1=0;
                            if (strlen($VNadom[$i][11]) > 0){
                                $SQL = "SELECT idprostor FROM tabuntisprostor WHERE prostoruntis='".$VNadom[$i][11]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $prostor1=$R1["idprostor"];
                                }
                            }
                            $prostor2=-1;
                            if (strlen($VNadom[$i][12]) > 0){
                                $SQL = "SELECT idprostor FROM tabuntisprostor WHERE prostoruntis='".$VNadom[$i][12]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $prostor2=$R1["idprostor"];
                                }
                            }
                            $razred=$VNadom[$i][14]; //prebere vse razrede
                            //prebere samo prvi razred
                            $rr=intval(substr($VNadom[$i][14],0,1));
                            $rp=substr($VNadom[$i][14],1,1);
                            $ri=0;
                            $SQL = "SELECT id FROM tabrazdat WHERE leto=".$R["leto"]." AND razred=".$rr." AND oznaka='".$rp."'";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){ 
                                $ri=$R1["id"];
                            }
                            $tekst=$VNadom[$i][16];
                            switch ($VNadom[$i][19]){
                                case "C": //odpadla
                                case "L": //sproščena
                                    $vrstanadom=4;
                                    break;
                                case "S": //nadzor
                                    $vrstanadom=3;
                                    break;
                                case "":
                                case "P":
                                    if ($VNadom[$i][6]=="ZDR"){
                                        $vrstanadom=2;
                                    }else{
                                        $vrstanadom=1;
                                    }
                                    break;
                                default:
                                    $vrstanadom=4;
                            }
                            //če so osebe spremenjene, popravi zapis
                            if (!(($R["ucitelj1"] == $odsotni) && (vsebuje($R["ucitelj2"],$nadomestni1)))){
                                $SQL = "UPDATE tabnadomescanja SET ";
                                $SQL .= "razred=".$rr;
                                $SQL .= ",paralelka='".$rp."'";
                                $SQL .= ",predmet=".$predmet;
                                $SQL .= ",ura=".$ura;
                                $SQL .= ",ucitelj1=".$odsotni;
                                $SQL .= ",prostor1=".$prostor1;
                                $SQL .= ",ucitelj2=".$nadomestni;
                                $SQL .= ",prostor2=".$prostor2;
                                $SQL .= ",oblika=".$vrstanadom;
                                $SQL .= ",vpisal='".$VUporabnik."'";
                                $SQL .= ",cas='".$Danes->format('Y-m-d H:i:s')."'";
                                $SQL .= ",idrazred=".$ri;
                                $SQL .= ",iduntis=".$VNadom[$i][0];
                                $SQL .= ",potrjeno=false";
                                $SQL .= " WHERE id=".$R["id"];
                                if (!($result1 = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu!<br />$SQL <br />");
                                }
                            }
                        }else{ //ne obstaja zapis o nadomeščanju
                            $odsotni=0;
                            if (strlen($VNadom[$i][5]) > 0){
                                $SQL = "SELECT iducitelj FROM tabuntisucitelj WHERE uciteljuntis='".$VNadom[$i][5]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $odsotni=$R1["iducitelj"];
                                }
                            }
                            $nadomestni=0;
                            if (strlen($VNadom[$i][6]) > 0){
                                $SQL = "SELECT iducitelj FROM tabuntisucitelj WHERE uciteljuntis='".$VNadom[$i][6]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $nadomestni=$R1["iducitelj"];
                                }
                            }
                            if ($VNadom[$i][6]=="ZDR"){
                                //pogleda, kateri priimeki učiteljev so navedeni in pridobi njihove id številke
                                $nadomestni1="";
                                $zdruzi=explode(",",$VNadom[$i][16]); //tekst k nadomeščanju
                                for($j=0;$j < count($zdruzi);$j++){
                                    $SQL = "SELECT iducitelj FROM tabucitelji WHERE priimek LIKE '%".trim($zdruzi[$j])."%'";
                                    $result1 = mysqli_query($link,$SQL);
                                    if ($R1 = mysqli_fetch_array($result1)){
                                        if (strlen($nadomestni1) > 0){
                                            $nadomestni1 .= ",".$R1["iducitelj"];
                                        }else{
                                            $nadomestni1 .= $R1["iducitelj"];
                                        }
                                    }
                                }
                                $nadomestni2=explode(",",$nadomestni1);
                                $nadomestni=intval($nadomestni2[0]);
                            }
                            $ura=$VNadom[$i][2];
                            $predmet=0;
                            if (strlen($VNadom[$i][7]) > 0){
                                $SQL = "SELECT idpredmet,predmetuntis FROM tabuntispredm WHERE predmetuntis='".$VNadom[$i][7]."'";
                                $result1 = mysqli_query($link,$SQL);
                                while ($R1 = mysqli_fetch_array($result1)){ 
                                    if ($R1["predmetuntis"]==$VNadom[$i][7]){
                                        $predmet=$R1["idpredmet"];
                                    }
                                }
                            }
                            if ($predmet==0 && strlen($VNadom[$i][7]) > 0){ //gre za skupine
                                switch ($VNadom[$i][7]){
                                    case "1TJA":
                                    case "2TJA":
                                    case "3TJA":
                                    case "4TJA":
                                    case "5TJA":
                                    case "6TJA":
                                    case "TJAn":
                                        $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='TJA'";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){ 
                                            $predmet=$R1["id"];
                                        }
                                        break;
                                    case "1MAT":
                                    case "2MAT":
                                    case "3MAT":
                                    case "4MAT":
                                    case "5MAT":
                                    case "6MAT":
                                    case "MATn":
                                        $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='MAT'";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){ 
                                            $predmet=$R1["id"];
                                        }
                                        break;
                                    case "1SLJ":
                                    case "2SLJ":
                                    case "3SLJ":
                                    case "4SLJ":
                                    case "5SLJ":
                                    case "6SLJ":
                                    case "SLJn":
                                        $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='SLJ'";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){ 
                                            $predmet=$R1["id"];
                                        }
                                        break;
                                    case "TIT1":
                                    case "TIT2":
                                        $SQL = "SELECT id FROM tabpredmeti WHERE oznaka='TIT'";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){ 
                                            $predmet=$R1["id"];
                                        }
                                        break;
                                    case "ŠPOf":
                                    case "ŠPOd":
                                        $SQL = "SELECT id FROM tabpredmeti WHERE opis='Šport'";
                                        $result1 = mysqli_query($link,$SQL);
                                        if ($R1 = mysqli_fetch_array($result1)){ 
                                            $predmet=$R1["id"];
                                        }
                                        break;
                                }
                            }
                            $prostor1=0;
                            if (strlen($VNadom[$i][11]) > 0){
                                $SQL = "SELECT idprostor FROM tabuntisprostor WHERE prostoruntis='".$VNadom[$i][11]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $prostor1=$R1["idprostor"];
                                }
                            }
                            $prostor2=-1;
                            if (strlen($VNadom[$i][12]) > 0){
                                $SQL = "SELECT idprostor FROM tabuntisprostor WHERE prostoruntis='".$VNadom[$i][12]."'";
                                $result1 = mysqli_query($link,$SQL);
                                if ($R1 = mysqli_fetch_array($result1)){ 
                                    $prostor2=$R1["idprostor"];
                                }
                            }
                            $razred=$VNadom[$i][14]; //prebere vse razrede
                            //prebere samo prvi razred
                            $rr=intval(substr($VNadom[$i][14],0,1));
                            $rp=substr($VNadom[$i][14],1,1);
                            $ri=0;
                            if ($Datum->format('n') > 8){
                                $SQL = "SELECT id FROM tabrazdat WHERE leto=".$Datum->format('Y')." AND razred=".$rr." AND oznaka='".$rp."'";
                            }else{
                                $SQL = "SELECT id FROM tabrazdat WHERE leto=".($Datum->format('Y')-1)." AND razred=".$rr." AND oznaka='".$rp."'";
                            }
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){ 
                                $ri=$R1["id"];
                            }
                            $tekst=$VNadom[$i][16];
                            switch ($VNadom[$i][19]){
                                case "C": //odpadla
                                case "L": //sproščena
                                    $vrstanadom=4;
                                    break;
                                case "S": //nadzor
                                    $vrstanadom=3;
                                    break;
                                case "":
                                case "P":
                                    if ($VNadom[$i][6]=="ZDR"){
                                        $vrstanadom=2;
                                    }else{
                                        $vrstanadom=1;
                                    }
                                    break;
                                default:
                                    $vrstanadom=4;
                            }
                            if ($rr > 0) {
                                if ($odsotni != $nadomestni){
                                    $SQL = "INSERT INTO tabnadomescanja (leto,datumnad,razred,paralelka,predmet,ura,ucitelj1,prostor1,ucitelj2,prostor2,oblika,vpisal,cas,idrazred,iduntis,potrjeno) VALUES (";
                                    if ($Datum->format('n') > 8){
                                        $SQL .= $Datum->format('Y');
                                    }else{
                                        $SQL .= $Datum->format('Y')-1;
                                    }
                                    $SQL .= ",'".$Datum->format('d.m.Y')."'";
                                    $SQL .= ",".$rr;
                                    $SQL .= ",'".$rp."'";
                                    $SQL .= ",".$predmet;
                                    $SQL .= ",".$ura;
                                    $SQL .= ",".$odsotni;
                                    $SQL .= ",".$prostor1;
                                    $SQL .= ",".$nadomestni;
                                    $SQL .= ",".$prostor2;
                                    $SQL .= ",".$vrstanadom;
                                    $SQL .= ",'".$VUporabnik."'";
                                    $SQL .= ",'".$Danes->format('Y-m-d H:i:s')."'";
                                    $SQL .= ",".$ri;
                                    $SQL .= ",".$VNadom[$i][0];
                                    $SQL .= ",false";
                                    $SQL .= ")";
                                    if (!($result1 = mysqli_query($link,$SQL))){
                                        die("Napaka pri vpisu!<br />$SQL <br />");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            echo "<h2>Opravljeno</h2>";
            echo "<a href='VnosNadomescanje.php?id=7'>Izpis nadomeščanj</a><br />";
            echo "<a href='VnosNadomescanje.php?id=1'>Urejanje nadomeščanj</a><br />";
        }
        break;
}

?>
<br />

</body>
</html>
