<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function vsebuje($s,$a){
    //ali niz števil ločenih z vejico $s vsebuje število $a
    $sarr=explode(",",$s);
    for ($i=0;$i < count($sarr);$i++){
        if (intval($a)==intval($sarr[$i])){
            return true;
        }
    }
    return false;
}
function Arr2Str($a){
    $s="";
    for ($i=0;$i < count($a);$i++){
        if (strlen($s) == 0){
            $s=$a[$i];
        }else{
            $s=$s.",".$a[$i];
        }
    }
    return $s;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj,ime,priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["iducitelj"];
    $Ucitelj=$R["ime"]." ".$R["priimek"];
    $VUporabnikId=$Prijavljeni;
    $VIdRazrednik=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
switch ($Vid){
    case "1":
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Projekti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        break;
    case "3":
    case "5":
        break;
    default:
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Projekti";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        if (intval($Vid) > 1){
            echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
            echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";
        }
}
/*
        $SQL = "SELECT sola,naslov,kraj,solakratko FROM TabSola";
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $sole[$i][2]=$R["sola"];
            $sole[$i][3]=$R["naslov"];
            $sole[$i][4]=$R["kraj"];
            $i += 1;
        }
        $StSol=$i-1;
        for ($i=1;$i <= $StSol;$i++){
*/
switch ($Vid){
    case "1": // 'izpis projekta
        if (isset($_GET["projekt"])){
            $VProjekt=$_GET["projekt"];
        }else{
            if (isset($_POST["projekt"])){
                $VProjekt=$_POST["projekt"];
            }else{
                $VProjekt=0;
            }
        }
        if ($VecSol > 0){
            $SQL = "SELECT idsola FROM TabProjekti WHERE TabProjekti.id=".$VProjekt;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $idsola=$R["idsola"];
            }else{
                $idsola=1;
            }
            
            $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VNaslovSole=$R["Naslov"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola=" ";
                $VNaslovSole="";
                $VKraj="";
            }
        }else{
            $SQL = "SELECT * FROM tabsola WHERE id=1";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VSola=$R["Sola"];
                $VNaslovSole=$R["Naslov"];
                $VKraj=$R["Kraj"];
            }else{
                $VSola=" ";
                $VNaslovSole="";
                $VKraj="";
            }
        }

        $SQL = "SELECT TabProjekti.* FROM TabProjekti INNER JOIN TabUcitelji ON TabProjekti.mentor=TabUcitelji.idUcitelj WHERE TabProjekti.id=".$VProjekt;
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            $VLeto=$R["Leto"];
            $VMentor=$R["Mentor"];
            $VProjekt=$R["Projekt"];
            $VSodelavci=$R["Sodelavci"];
            $VRazseznost=$R["razseznost"];
            $VVkljuceni=$R["vkljuceni"];
            $VDosezki=$R["dosezki"];
            $VPorocilo=$R["porocilo"];
        }
        
        echo "<table class='graf' border='0' width='700'>";
        echo "<tr class='graf'><td class='graf'>";
        echo "<table class='graf' border='0'>";
        echo "<tr class='graf'><td class='graf' width='250'><img src='logo1.gif' height=150></td><td class='graf' align=center><h2>".$VSola."<br>".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
        echo "</table>";

        echo $VRazseznost." projekt:<br/>";
        echo "<h1>".$VProjekt."</h1>";
        
        echo "<h3>Mentor: ";
        if ($VMentor > 0){
            $SQL="SELECT ime,priimek FROM TabUcitelji WHERE idUcitelj=".$VMentor;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo $R["ime"]." ".$R["priimek"];
            }
        }
        echo "&nbsp;</h3>";
        
        echo "<p><b>Sodelavci:</b><br />";
        if ($VSodelavci != "" ){
            $SQL="SELECT ime,priimek FROM TabUcitelji WHERE idUcitelj IN (".$VSodelavci.") ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo $R["ime"]." ".$R["priimek"]."<br />";
            }
        }
        echo "</p>";
        
        echo "<p><b>Vključeni v projekt:</b><br />";
        echo $VVkljuceni."</p>";
        echo "<p><b>Dosežki:</b><br />";
        echo $VDosezki."</p>";
        echo "<p><b>Poročilo:</b><br />";
        echo $VPorocilo."</p>";
        
        echo "</td></tr></table><br />";
        break;
    case "2": // 'briši
        if (isset($_GET["projekt"])){
            $VProjekt=$_GET["projekt"];
        }else{
            if (isset($_POST["projekt"])){
                $VProjekt=$_POST["projekt"];
            }else{
                $VProjekt=0;
            }
        }
        $SQL = "SELECT id FROM TabProjekti WHERE id=".$VProjekt;
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            if (($VLevel > 1) or ($R["Mentor"]==$IdUcitelj) ){
                $SQL = "DELETE FROM TabProjekti WHERE id=".$VProjekt;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju projekta (".$SQL.")<br />");
                }else{
                    echo "Projekt je bil uspešno izbrisan.<br />";
                }
            }
        }
        echo "<a href='Projekti.php'>Projekti</a><br />";
        break;
    case "3": // 'vpis novega projekta
        $Vidsola=$_POST["idsola"];
        $VLeto=$_POST["solskoleto"];
        $VMentor=$_POST["mentor"];
        $VProjekt=$_POST["projekt"];
        $VSodelavci=Arr2Str($_POST["sodelavci"]);
        $VRazseznost=$_POST["razseznost"];
        $VVkljuceni=$_POST["vkljuceni"];
        if (strlen($VVkljuceni) > 0){
            $VVkljuceni=str_replace("'","",$VVkljuceni);
            $VVkljuceni=str_replace(chr(34),"",$VVkljuceni);
        }
        $VDosezki=$_POST["dosezki"];
        if (strlen($VDosezki) > 0 ){
            $VDosezki=str_replace("'","",$VDosezki);
            $VDosezki=str_replace(chr(34),"",$VDosezki);
        }
        $VPorocilo=$_POST["porocilo"];
        if (strlen($VPorocilo) > 0){
            $VPorocilo=str_replace("'","",$VPorocilo);
            $VPorocilo=str_replace(chr(34),"",$VPorocilo);
        }
        
        $SQL = "INSERT INTO TabProjekti (leto,mentor,projekt,sodelavci,razseznost,vkljuceni,dosezki,porocilo,cas,vpisal,idsola) VALUES (";
        $SQL = $SQL . $VLeto;
        $SQL = $SQL . ",".$VMentor;
        $SQL = $SQL . ",'".$VProjekt."'";
        $SQL = $SQL . ",'".$VSodelavci."'";
        $SQL = $SQL . ",'".$VRazseznost."'";
        $SQL = $SQL . ",'".$VVkljuceni."'";
        $SQL = $SQL . ",'".$VDosezki."'";
        $SQL = $SQL . ",'".$VPorocilo."'";
        $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
        $SQL = $SQL . ",'".$VUporabnik."'";
        $SQL = $SQL . ",".$Vidsola;
        $SQL = $SQL .")";
        //'echo $SQL . "<br />"
        if (!($result = mysqli_query($link,$SQL))){
            die("Napaka pri vpisu projekta. (".$SQL.")<br />");
        }
        
        header("Location: Projekti.php");
        break;
    case "4": // 'popravi projekt
        if (isset($_POST["projekt"])){
            $VProjekt=$_POST["projekt"];
        }else{
            if (isset($_GET["projekt"])){
                $VProjekt=$_GET["projekt"];
            }else{
                $VProjekt=0;
            }
        }
        $SQL="SELECT * FROM TabProjekti WHERE id=".$VProjekt;
        $result = mysqli_query($link,$SQL);
        
        while ($R = mysqli_fetch_array($result)){
            $VLeto=$R["Leto"];
            $VMentor=$R["Mentor"];
            $VProjekt=$R["Projekt"];
            $VSodelavci=$R["Sodelavci"];
            $VRazseznost=$R["razseznost"];
            $VVkljuceni=$R["vkljuceni"];
            $VDosezki=$R["dosezki"];
            $VPorocilo=$R["porocilo"];
            $Vidsola=$R["idsola"];
        }
        
        $SQL="SELECT ime,priimek FROM TabUcitelji WHERE idUcitelj=".$VMentor;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $Ucitelj=$R["priimek"]." ".$R["ime"];
        }else{
            $Ucitelj="Napaka!!!";
        }
        
        echo "<h2>Popravi projekt - ".$Ucitelj.":</h2>";
        echo "<form name='form_novProjekt' method=post action='Projekti.php'>";
        echo "<input type='hidden' name='projektID' value='".$_POST["projekt"]."'>";
        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
        echo "<input type='hidden' name='id' value='5'>";

        echo "<b>Ime projekta:</b> <input name='projekt' type='text' size='60' value='".$VProjekt."'><br /><br />";
        
        if ($VecSol > 0){
            echo "Šola: <select name='idsola'>";
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result1 = mysqli_query($link,$SQL);
            while ($R1 = mysqli_fetch_array($result1)){
                if ($R1["id"] == $Vidsola){
                    echo "<option value='".$R1["id"]."' selected='selected'>".$R1["solakratko"]."</option>";
                }else{
                    echo "<option value='".$R1["id"]."'>".$R1["solakratko"]."</option>";
                }
            }
            echo "</select><br />";
        }else{
            echo "<input name='idsola' type='hidden' value='1'>";
        }
        echo "<b>Razsežnost:</b> <select name='razseznost'>";
        echo "<option value='".$VRazseznost."' selected='selected'>".$VRazseznost."</option>";
        echo "<option value='šolski'>šolski</option>";
        echo "<option value='regijski'>regijski</option>";
        echo "<option value='državni'>državni</option>";
        echo "<option value='mednarodni'>mednarodni</option>";
        echo "</select><br /><br />";
        
        echo "<b>Mentor:</b> ";
        if ($VLevel > 1 ){
            $SQL="SELECT iducitelj,ime,priimek FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            echo "<select name='mentor'>";
            echo "<option value='0'>Ni izbran</option>";
            while ($R = mysqli_fetch_array($result)){
                if ($R["iducitelj"]==$VMentor ){
                    echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                }else{
                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                }
            }
            echo "</select><br /><br />";
        }else{
            echo "<select name='mentor'>";
            echo "<option value='0'>Ni izbran</option>";
            echo "<option value='".$VMentor."' selected='selected'>".$Ucitelj."</option>";
            echo "</select><br /><br />";
        }
        
        $SQL="SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);
        echo "Sodelavci:<br /><select name='sodelavci[]' size='15' multiple='multiple'>";
        while ($R = mysqli_fetch_array($result)){
            if (vsebuje($VSodelavci,$R["iducitelj"]) ){
                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
            }else{
                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
            }
        }
        echo "</select><br /><br/ >";
        
        echo "<b>Vključeni v projekt:</b><br /><textarea name='vkljuceni' cols='80' rows='10'>".$VVkljuceni."</textarea><br />";
        echo "<b>Dosežki:</b><br /><textarea name='dosezki' cols='80' rows='10'>".$VDosezki."</textarea><br />";
        echo "<b>Poročilo:</b><br /><textarea name='porocilo' cols='80' rows='10'>".$VPorocilo."</textarea><br />";

        echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
        echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
        echo "<input name='level' type='hidden' value='".$VLevel."'>";
        echo "<input name='submit' type='submit' value='Pošlji popravek'>";
        echo "</form>";
        echo "<a href='Projekti.php'>Projekti</a><br />";
        break;
    case "5": // 'vpis popravljenih podatkov
        $Vidsola=$_POST["idsola"];
        $VLeto=$_POST["solskoleto"];
        $VMentor=$_POST["mentor"];
        $VProjekt=$_POST["projekt"];
        $VSodelavci=Arr2Str($_POST["sodelavci"]);
        $VRazseznost=$_POST["razseznost"];
        $VVkljuceni=$_POST["vkljuceni"];
        if (strlen($VVkljuceni) > 0){
            $VVkljuceni=str_replace("'","",$VVkljuceni);
            $VVkljuceni=str_replace(chr(34),"",$VVkljuceni);
        }
        $VDosezki=$_POST["dosezki"];
        if (strlen($VDosezki) > 0 ){
            $VDosezki=str_replace("'","",$VDosezki);
            $VDosezki=str_replace(chr(34),"",$VDosezki);
        }
        $VPorocilo=$_POST["porocilo"];
        if (strlen($VPorocilo) > 0){
            $VPorocilo=str_replace("'","",$VPorocilo);
            $VPorocilo=str_replace(chr(34),"",$VPorocilo);
        }
    
        $SQL = "SELECT * FROM TabProjekti WHERE id=".$_POST["projektID"];
        $result = mysqli_query($link,$SQL);
        
        while ($R = mysqli_fetch_array($result)){
            $SQL = "UPDATE TabProjekti SET ";
            $SQL = $SQL . "mentor=".$VMentor;
            $SQL = $SQL . ",projekt='".$VProjekt."'";
            $SQL = $SQL . ",sodelavci='".$VSodelavci."'";
            $SQL = $SQL . ",razseznost='".$VRazseznost."'";
            $SQL = $SQL . ",vkljuceni='".$VVkljuceni."'";
            $SQL = $SQL . ",dosezki='".$VDosezki."'";
            $SQL = $SQL . ",porocilo='".$VPorocilo."'";
            $SQL = $SQL . ",cas='".$Danes->format('Y-m-d H:i:s')."'";
            $SQL = $SQL . ",vpisal='".$VUporabnik."'";
            $SQL = $SQL . ",idsola=".$Vidsola;
            $SQL = $SQL . " WHERE id=".$R["Id"];
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu popravka projekta. (".$SQL.")<br />");
            }
        }
        header("Location: Projekti.php");
        break;
    default:
        $SQL = "SELECT TabProjekti.*,TabUcitelji.ime,tabucitelji.priimek,tabsola.solakratko FROM (TabProjekti ";
        $SQL .= "INNER JOIN TabUcitelji ON TabProjekti.Mentor=TabUcitelji.idUcitelj) ";
        $SQL .= "INNER JOIN tabsola ON tabprojekti.idsola=tabsola.id ";
        $SQL .= "WHERE TabProjekti.leto=".$VLeto;
        $SQL .= " ORDER BY tabprojekti.idsola,TabProjekti.projekt";
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result) > 0){
            $Indx=0;
            echo "<form name='form_projekt' method=post action='Projekti.php'>";
            echo "<h2>Izbor projekta za popravljanje</h2>";
            echo "<select name='projekt'>";
            while ($R = mysqli_fetch_array($result)){
                if (($R["Mentor"]==$IdUcitelj) or ($VLevel > 1) ){
                    echo "<option value='".$R["Id"]."'>".$R["Projekt"]." - ".$R["priimek"]." ".$R["ime"]."</option>";
                }
            }
            echo "</select>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input type='hidden' name='id' value='4'>";
            echo "<input name='submit' type='submit' value='Izberi projekt'>";
            echo "</form>";
            
            $result = mysqli_query($link,$SQL);
            echo "<h2>Pregled projektov</h2>";
            echo "<table border=1>";
            if ($VecSol > 0){
                echo "<tr><th>Šola</th><th>Projekt</th><th>Mentor</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Projekt</th><th>Mentor</th><th>Briši</th></tr>";
            }
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                if ($VecSol > 0){
                    echo "<td>".$R["solakratko"]."</td>";
                }
                echo "<td><a href='Projekti.php?projekt=".$R["Id"]."&id=1'>".$R["Projekt"]."</a></td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td><a href='Projekti.php?projekt=".$R["Id"]."&id=2'>Briši</a></td>";
                echo "</tr>";
            }
            echo "</table><br /><hr>";
            
            echo "<h2>Nov projekt - ".$Ucitelj.":</h2>";
            echo "<form name='form_novProjekt' method='post' action='Projekti.php'>";
//'            echo "<input type='hidden' name='mentor' value='".IdUcitelj."'>"
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "<input type='hidden' name='id' value='3'>";

            if ($VecSol > 0){
                echo "Šola: <select name='idsola'>";
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($R1["id"] == 1){
                        echo "<option value='".$R1["id"]."' selected='selected'>".$R1["solakratko"]."</option>";
                    }else{
                        echo "<option value='".$R1["id"]."'>".$R1["solakratko"]."</option>";
                    }
                }
                echo "</select><br />";
            }else{
                echo "<input name='idsola' type='hidden' value='1'>";
            }
            echo "Ime projekta: <input name='projekt' type='text' size='60'><br /><br />";
            
            echo "Razsežnost: <select name='razseznost'>";
            echo "<option value='šolski'>šolski</option>";
            echo "<option value='regijski'>regijski</option>";
            echo "<option value='državni'>državni</option>";
            echo "<option value='mednarodni'>mednarodni</option>";
            echo "</select><br /><br />";
            
            echo "Mentor: ";
            if ($VLevel > 1 ){
                $SQL="SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                echo "<select name='mentor'>";
                echo "<option value='0'>Ni izbran</option>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                }
                echo "</select><br /><br />";
            }else{
                echo "<select name='mentor'>";
                echo "<option value='0'>Ni izbran</option>";
                echo "<option value='".$IdUcitelj."' selected='selected'>".$Ucitelj."</option>";
                echo "</select><br /><br />";
            }
            
            $SQL="SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            echo "Sodelavci:<br /><select name='sodelavci[]' size='15' multiple='multiple'>";
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
            }
            echo "</select><br /><br />";
            
            echo "<b>Vključeni v projekt:</b><br /><textarea name='vkljuceni' cols='80' rows='10'></textarea><br />";
            echo "<b>Dosežki:</b><br /><textarea name='dosezki' cols='80' rows='10'></textarea><br />";
            echo "<b>Poročilo:</b><br /><textarea name='porocilo' cols='80' rows='10'></textarea><br />";

            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='submit' type='submit' value='Pošlji nov projekt'>";
            echo "</form>";
            echo "<a href='Projekti.php'>Projekti</a><br />";
        }else{
            echo "<h2>Nov projekt - ".$Ucitelj.":</h2>";
            echo "<form name='form_novProjekt' method=post action='Projekti.php'>";
//'            echo "<input type='hidden' name='mentor' value='".IdUcitelj."'>"
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "<input type='hidden' name='id' value='3'>";

            echo "Ime projekta: <input name='projekt' type='text' size='60'><br /><br />";
            
            if ($VecSol > 0){
                echo "Šola: <select name='idsola'>";
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($R1["id"] == 1){
                        echo "<option value='".$R1["id"]."' selected='selected'>".$R1["solakratko"]."</option>";
                    }else{
                        echo "<option value='".$R1["id"]."'>".$R1["solakratko"]."</option>";
                    }
                }
                echo "</select><br />";
            }else{
                echo "<input name='idsola' type='hidden' value='1'>";
            }
            echo "Razsežnost: <select name='razseznost'>";
            echo "<option value='šolski'>šolski</option>";
            echo "<option value='regijski'>regijski</option>";
            echo "<option value='državni'>državni</option>";
            echo "<option value='mednarodni'>mednarodni</option>";
            echo "</select><br /><br />";
            
            echo "Mentor: ";
            if ($VLevel > 1 ){
                $SQL="SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                echo "<select name='mentor'>";
                echo "<option value='0'>Ni izbran</option>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                }
                echo "</select><br /><br />";
            }else{
                echo "<select name='mentor'>";
                echo "<option value='0'>Ni izbran</option>";
                echo "<option value='".$IdUcitelj."' selected='selected'>".$Ucitelj."</option>";
                echo "</select><br /><br />";
            }
            
            $SQL="SELECT iducitelj,priimek,ime FROM TabUcitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            echo "Sodelavci:<br /><select name='sodelavci[]' size='15' multiple='multiple'>";
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
            }
            echo "</select><br /><br />";
            
            echo "<b>Vključeni v projekt:</b><br /><textarea name='vkljuceni' cols='80' rows='10'></textarea><br />";
            echo "<b>Dosežki:</b><br /><textarea name='dosezki' cols='80' rows='10'></textarea><br />";
            echo "<b>Poročilo:</b><br /><textarea name='porocilo' cols='80' rows='10'></textarea><br />";

            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='submit' type='submit' value='Pošlji nov projekt'>";
            echo "</form>";
            echo "<a href='Projekti.php'>Projekti</a><br />";
        }
}

?>
</body>
</html>
