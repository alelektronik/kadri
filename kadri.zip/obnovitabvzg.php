<?php
require("const.php");

echo "<h2>Obnova TabVzgojitelji</h2>";
$SQL = "DELETE FROM tabvzgojitelji WHERE id > 0";
$result = mysqli_query($link,$SQL);
echo "Izbrisani stari podatki<br />";

$SQL = "SELECT * from tabucitelji";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
     $SQL = "INSERT INTO tabvzgojitelji (iducitelj,priimek,ime,spol,datroj) values (".$R["IdUcitelj"].",'".$R["Priimek"]."','".$R["Ime"]."','".$R["Spol"]."','".$R["DatRoj"]."')";
     $result1 = mysqli_query($link,$SQL);
}  
echo "Podatki so obnovljeni.<br />";
?>
