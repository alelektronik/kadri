<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
ini_set('max_execution_time', 3600); 
 
function ToCSZ($in)
 {
   $CONV = array();
   $CONV['c4']['8c'] = chr(0xc8);
   $CONV['c4']['8d'] = chr(0xe8);
   $CONV['c5']['a0'] = chr(0x8a);
   $CONV['c5']['a1'] = chr(0x9a);
   $CONV['c5']['bd'] = chr(0x8e);
   $CONV['c5']['be'] = chr(0x9e);
   $CONV['c4']['90'] = chr(0xd0);
   $CONV['c4']['91'] = chr(0xf0);
   $CONV['c4']['86'] = chr(0xc6);
   $CONV['c4']['87'] = chr(0xe6);
 
  $i=0;
   $out = '';
   while($i<strlen($in))
   {
     if(array_key_exists(bin2hex($in[$i]), $CONV))
     {
       $out .= $CONV[bin2hex($in[$i])][bin2hex($in[$i+1])];
       $i += 2;
     }
     else
     {
       $out .= $in[$i];
       $i += 1;
     }
   }
 
  return $out;
 }
 

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pošiljanje mailov
</title>
</head>
<body>

<?php
$Danes=new DateTime("now");
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

if ($VUporabnik == ""){
    header("Location: nepooblascen.htm");
}else{
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');

    $SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $UciteljComp=$R["iducitelj"];
        //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
        //    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

        /*
        $allowedExts = array("jpg", "jpeg", "gif", "png");
        $extension = end(explode(".", $_FILES["file"]["name"]));
        if ((($_FILES["file"]["type"] == "image/gif")
        || ($_FILES["file"]["type"] == "image/jpeg")
        || ($_FILES["file"]["type"] == "image/png")
        || ($_FILES["file"]["type"] == "image/pjpeg"))
        && ($_FILES["file"]["size"] < 20000)
        && in_array($extension, $allowedExts))
        {
        */
        $CasStart=new DateTime("now");
        if ($_FILES["attachment"]["error"] > 0){
            //echo "Napaka: " . $_FILES["attachment"]["error"] . "<br />";
            echo "Priponka/datoteka ni bila poslana na strežnik<br />";
            $Datoteka="";
        }else{
             echo "Naloženo: " . $_FILES["attachment"]["name"] . "<br />";
             echo "Tip: " . $_FILES["attachment"]["type"] . "<br />";
             echo "Velikost: " . ($_FILES["attachment"]["size"] / 1024) . " kB<br />";
             echo "Temp file: " . $_FILES["attachment"]["tmp_name"] . "<br />";
         
             if (file_exists("dato/" . $_FILES["attachment"]["name"])){
                 echo $_FILES["attachment"]["name"] . " že obstaja. <br />";
             }else{
                 move_uploaded_file($_FILES["attachment"]["tmp_name"],"dato/" . $_FILES["attachment"]["name"]);
                 echo "Shranjeno v: " . "dato/" . $_FILES["attachment"]["name"]. "<br />";
             }
             $Datoteka="dato".$FileSep. $_FILES["attachment"]["name"];
        }
        /*
        }
        else
        {
        echo "Invalid file";
        }
        */
           
        echo "<br />";
        
        if ((strlen($mail_host1) > 0) && (strlen($mail_user1) > 0) && (strlen($mail_pass1) > 0)){
            require_once('class.phpmailer.php');
            //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded
            $bodyAlt = $_POST["bodytext"];
            $body = $_POST["bodytext"];
            $body = str_replace("\n","<br />",$body);
            //$body = ToCSZ($body);

            $mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
            $mail->CharSet='UTF-8';
            $mail->IsSMTP(); // telling the class to use SMTP
            $PosiljateljFrom="mail.kadri.send@gmail.com";

            try {
                /*
              $mail->Host       = "mail.gmail.com"; // SMTP server
              $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
              $mail->SMTPAuth   = true;                  // enable SMTP authentication
              $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
              $mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
              $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
              $mail->Username   = "mail.kadri.send@gmail.com";  // GMAIL username
              $mail->Password   = "k4dr1S3ndm41l";            // GMAIL password
                  */
              $mail->Host       = $mail_host1; // SMTP server
              $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
              $mail->SMTPAuth   = true;                  // enable SMTP authentication
              $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
              $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
              $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
              $mail->Username   = $mail_user1;  // GMAIL username
              $mail->Password   = $mail_pass1;            // GMAIL password
              
            //  $mail->AddAddress('whoto@otherdomain.com', 'John Doe');
            //  $mail->SetFrom('name@yourdomain.com', 'First Last');
            //  $mail->AddReplyTo('name@yourdomain.com', 'First Last');
              
              $mail->Subject = $_POST["subject"];
              if (strlen($Datoteka) > 0){
                $mail->AddAttachment($Datoteka);      // attachment
              }
              
              $mail->AltBody = $bodyAlt; // optional - MsgHTML will create an alternate automatically
              
              $mail->MsgHTML($body);
              
                $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabkontakti.* FROM tabkontakti INNER JOIN tabucitelji ON tabkontakti.idUcitelj=tabucitelji.idUcitelj WHERE tabkontakti.idUcitelj=".$UciteljComp;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    if (strpos($R["email"],"@") > 0){
                        if (strpos($R["email"],";") > 0){
                            $s=explode(";",$R["email"]);
                            $Posiljatelj=$s[0];
                        }else{
                            $Posiljatelj=$R["email"];
                        }
                        $PosiljateljFrom=$Posiljatelj;
                        $mail->SetFrom($PosiljateljFrom, $R["Ime"]." ".$R["Priimek"]);
                        $mail->AddAddress($Posiljatelj, $R["Ime"]." ".$R["Priimek"]);
                        $mail->AddReplyTo($Posiljatelj, $R["Ime"]." ".$R["Priimek"]);
                    }
                }
               
                $mail->Send();
                echo "Sporočilo poslano pošiljatelju: ".$Posiljatelj."<br />\n";
            } catch (phpmailerException $e) {
              echo $e->errorMessage(); //Pretty error messages from PHPMailer
            } catch (Exception $e) {
              echo $e->getMessage(); //Boring error messages from anything else!
            }

            $mail=null;
            echo "<br />";
            $Naslovnikom="";
            $Stevilo=$_POST["Stevilo"];
            $i=0;
            for ($indx=1;$indx <= $Stevilo;$indx++){
                 if (isset($_POST["em_".$indx])){
                     $i++;
                     if (strpos($_POST["uc_".$indx],";") > 0){
                         $s=explode(";",$_POST["uc_".$indx]);
                         $Prejemnik[$i]=$s[0];
                     }else{
                         $Prejemnik[$i]=$_POST["uc_".$indx];
                     }
                 }
            }
            $Stevilo=$i;
            $Poslanih=0;
            for ($indx=1;$indx <= $Stevilo;$indx++){
                if (strpos($Prejemnik[$indx],"@") > 0){
                    $mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
		            $mail->CharSet='UTF-8';

                    $mail->IsSMTP(); // telling the class to use SMTP

                    try {
                      switch ($indx % 4){
                          case 1:
                              if ((strlen($mail_host2) > 0) && (strlen($mail_user2) > 0) && (strlen($mail_pass2) > 0)){
                                  $mail->Host       = $mail_host2; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host2;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user2;  // GMAIL username
                                  $mail->Password   = $mail_pass2;            // GMAIL password
                              }else{
                                  $mail->Host       = $mail_host1; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user1;  // GMAIL username
                                  $mail->Password   = $mail_pass1;            // GMAIL password
                              }
                              break;
                          case 2:
                              if ((strlen($mail_host3) > 0) && (strlen($mail_user3) > 0) && (strlen($mail_pass3) > 0)){
                                  $mail->Host       = $mail_host3; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host3;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user3;  // GMAIL username
                                  $mail->Password   = $mail_pass3;            // GMAIL password
                              }else{
                                  $mail->Host       = $mail_host1; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user1;  // GMAIL username
                                  $mail->Password   = $mail_pass1;            // GMAIL password
                              }
                              break;
                          case 3:
                              if ((strlen($mail_host4) > 0) && (strlen($mail_user4) > 0) && (strlen($mail_pass4) > 0)){
                                  $mail->Host       = $mail_host4; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host4;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user4;  // GMAIL username
                                  $mail->Password   = $mail_pass4;            // GMAIL password
                              }else{
                                  $mail->Host       = $mail_host1; // SMTP server
                                  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                  $mail->SMTPAuth   = true;                  // enable SMTP authentication
                                  $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                                  $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                                  $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                                  $mail->Username   = $mail_user1;  // GMAIL username
                                  $mail->Password   = $mail_pass1;            // GMAIL password
                              }
                              break;
                          default:
                              $mail->Host       = $mail_host1; // SMTP server
                              $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                              $mail->SMTPAuth   = true;                  // enable SMTP authentication
                              $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                              $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                              $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                              $mail->Username   = $mail_user1;  // GMAIL username
                              $mail->Password   = $mail_pass1;            // GMAIL password
                              break;
                      }
                      
                    //  $mail->AddAddress('whoto@otherdomain.com', 'John Doe');
                    //  $mail->SetFrom('name@yourdomain.com', 'First Last');
                    //  $mail->AddReplyTo('name@yourdomain.com', 'First Last');
                      
                      $mail->Subject = $_POST["subject"];
                      if (strlen($Datoteka) > 0){
                        $mail->AddAttachment($Datoteka);      // attachment
                      }
                      
                      $mail->AltBody = $bodyAlt; // optional - MsgHTML will create an alternate automatically
                      
                      $mail->MsgHTML($body);
                      
                      $PosiljateljFrom=$Posiljatelj;
                      $mail->AddAddress($Prejemnik[$indx],$Prejemnik[$indx]);
                      $mail->SetFrom($PosiljateljFrom, $PosiljateljFrom);
                      $mail->AddReplyTo($Posiljatelj, $Posiljatelj);
                      
                      $mail->Send();
                      $Poslanih=$Poslanih+1;
                      echo $Poslanih." Sporočilo poslano prejemniku: ".$Prejemnik[$indx]."<br />\n";
                      $Naslovnikom .= $Poslanih." Sporočilo poslano prejemniku: ".$Prejemnik[$indx]."<br />";
                    } catch (phpmailerException $e) {
                      echo $e->errorMessage(); //Pretty error messages from PHPMailer
                      echo "Prejemnik: ".$Prejemnik[$indx]."<br />\n";
                      $Naslovnikom .= $e->errorMessage()." Prejemnik: ".$Prejemnik[$indx]."<br />";
                    } catch (Exception $e) {
                      echo $e->getMessage(); //Boring error messages from anything else!
                      echo "Prejemnik: ".$Prejemnik[$indx]."<br />\n";
                      $Naslovnikom .= $e->getMessage()." Prejemnik: ".$Prejemnik[$indx]."<br />";
                    }
                    $mail=null;
                }
            }
            $CasKonec=new DateTime("now");
            $Interval=$CasStart->diff($CasKonec);
            if ($Interval->s < 10){
                echo "Porabljen čas: ".$Interval->i.":0".$Interval->s."<br />";
                $Naslovnikom .= "<br />Porabljen čas: ".$Interval->i.":0".$Interval->s."<br />";
            }else{
                echo "Porabljen čas: ".$Interval->i.":".$Interval->s."<br />";
                $Naslovnikom .= "<br />Porabljen čas: ".$Interval->i.":".$Interval->s."<br />";
            }

            //pošlje še poročilo, komu je bilo poslano
            $Naslovnikom = str_replace("\n","<br />",$Naslovnikom);
            //$Naslovnikom = str_replace("@","(a)",$Naslovnikom);

            $mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
            $mail->CharSet='UTF-8';
            $mail->IsSMTP(); // telling the class to use SMTP

            try {
              $mail->Host       = $mail_host1; // SMTP server
              $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
              $mail->SMTPAuth   = true;                  // enable SMTP authentication
              $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
              $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
              $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
              $mail->Username   = $mail_user1;  // GMAIL username
              $mail->Password   = $mail_pass1;            // GMAIL password
              
            //  $mail->AddAddress('whoto@otherdomain.com', 'John Doe');
            //  $mail->SetFrom('name@yourdomain.com', 'First Last');
            //  $mail->AddReplyTo('name@yourdomain.com', 'First Last');
              
              $mail->Subject = "Poslano: ".$_POST["subject"];
              
              $mail->AltBody = $bodyAlt; // optional - MsgHTML will create an alternate automatically
              
              $mail->MsgHTML($Naslovnikom);
              
                $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabkontakti.* FROM tabkontakti INNER JOIN tabucitelji ON tabkontakti.idUcitelj=tabucitelji.idUcitelj WHERE tabkontakti.idUcitelj=".$UciteljComp;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    if (strpos($R["email"],"@") > 0){
                        if (strpos($R["email"],";") > 0){
                            $s=explode(";",$R["email"]);
                            $Posiljatelj=$s[0];
                        }else{
                            $Posiljatelj=$R["email"];
                        }
                        $PosiljateljFrom=$Posiljatelj;
                        $mail->SetFrom($PosiljateljFrom, $R["Ime"]." ".$R["Priimek"]);
                        $mail->AddAddress($Posiljatelj, $R["Ime"]." ".$R["Priimek"]);
                        $mail->AddReplyTo($Posiljatelj, $R["Ime"]." ".$R["Priimek"]);
                    }
                }
               
                $mail->Send();
                echo "<br />Poročilo o pošiljanju poslano pošiljatelju: ".$Posiljatelj."<br />\n";
            } catch (phpmailerException $e) {
              echo $e->errorMessage(); //Pretty error messages from PHPMailer
            } catch (Exception $e) {
              echo $e->getMessage(); //Boring error messages from anything else!
            }

            $mail=null;

            echo "<h2>Opravljeno!</h2>";
        }else{
            echo "<h2>Nimate nastavljenih računov za pošiljanje e-pošte!</h2>";
        }  
    }   
}
 ?> 
 
</body>
</html>
