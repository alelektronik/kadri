<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}

echo "<html>";
echo "<head>";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
echo "<meta http-equiv='pragma' content='no-cache' > ";
echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
echo "<title>Geslo";
echo "</title>";
echo "</head>";
echo "<body>";
echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
echo "Za geslo uporabite velike in male črke ter številke (NE posebnih znakov!)<br />";

if (isset($_POST["StGeslo"])){
    $VStGeslo = md5($_POST["StGeslo"]);
}else{
    $VStGeslo = "1";
}
if (isset($_POST["NGeslo"])){
    $VNGeslo = md5($_POST["NGeslo"]);
}else{
    $VNGeslo = "2";
}
if (isset($_POST["RGeslo"])){
    $VRGeslo = md5($_POST["RGeslo"]);
}else{
    $VRGeslo = "3";
}

if ($VGeslo == $VStGeslo){
    if ($VNGeslo == $VRGeslo){
        $SQL = "SELECT ime,priimek FROM tabucitelji WHERE Uporabnik ='" . $VUporabnik . "' AND  Geslo='" . $VGeslo . "'";

//Response.Write "<br>" & SQL & "<br>"

        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            echo "<h2>Pozdravljeni : <b>" . $R["ime"]  . " " . $R["priimek"] . "</b></h2><br />";
            $SQL  = "UPDATE tabucitelji SET Geslo='" . $VNGeslo . "' WHERE Uporabnik='" . $VUporabnik . "'";
            $result = mysqli_query($link,$SQL);
            echo "Vaše geslo je bilo spremenjeno!<br />";
            echo "<a href='index.php'>Nazaj na ponovno prijavo</a><br />";
        }else{
            echo "Vaše uporabniško ime ali geslo je nepravilno!<br /><br />";
            echo "<a href='index.php'>Nazaj na vnos uporabniškega imena in gesla</a><br />";
        }
    }else{
        echo "Vaše novo in ponovljeno geslo sta različna!<br /><br />";
        echo "<a href='SpremeniGeslo.asp'>Nazaj na spremembo gesla</a><br />";
    }
}else{
    echo "Vnesli ste nepravilno staro geslo!<br /><br />";
    echo "<a href='index.php'>Nazaj na vnos uporabniškega imena in gesla</a><br />";
}

?>

</body>
</html>
