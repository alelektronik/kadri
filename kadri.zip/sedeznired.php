<?php
/*
Program za obdelavo sedežnih redov
1. vpis splošnih podatkov sedežnega reda in določitev učencev
2. vpis učencev v sedežni red
default obrazec za vnos sedežnega reda: razpored, učitelj, predmet, razredi, prostor

Tabele:
tabucenci
tabucitelji
tabrazred
tabrazdat
tabpredmeti
tabsedred
tabsedredu
    
*/

require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Sedežni red
</title>
<style>
.break { page-break-before: always; }
</style>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2010,2080],
            limitToToday:false
        });
    };
</script>
<script>
    var isRecycled = false;
    function appStatus(msg){
        document.getElementById('app_status').innerHTML = msg;
    }
    function allowDrop(ev)
    {
        ev.preventDefault();
    }

    function drag(ev)
    {
        appStatus("Vlečete "+ev.target.getAttribute('id'));
        ev.dataTransfer.setData("Text",ev.target.getAttribute('id'));
    }

    function drop(ev)
    {
        ev.preventDefault();
        var data=ev.dataTransfer.getData("Text");
        appStatus("Spustili ste "+data+" v "+ev.target.getAttribute('id'));
        //ev.target.appendChild(document.getElementById(data));
        ev.target.value=data;
        isRecycled = true;
        document.getElementById(data).removeAttribute("draggable");
    }
    function drag_enter(e) {
        appStatus("Vlečete preko "+e.target.getAttribute('id'));
    }
    function drag_leave(e) {
        appStatus("Zapustili ste "+e.target.getAttribute('id'));
    }
    function drag_end(e) {
        var status = document.getElementById('app_status');
        if(isRecycled == false){
            appStatus("Spustili ste "+e.target.getAttribute('id')+".");
        }
    }
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$UrNaDan=10;
$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE uporabnik='". $VUporabnik . "' AND geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["priimek"]." ".$R["ime"];
    $IdUcitelj=$R["iducitelj"];
    $VUporabnikId=$IdUcitelj;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Redov",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if ($VLeto > 2012){
    $OznakaSport="20";
    $SQL = "SELECT id,oznaka FROM tabpredmeti WHERE oznaka like 'ŠPO%'";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if (mb_substr($R["oznaka"],0,3,$encoding)=="ŠPO"){
            $OznakaSport=$R["id"];
        }
    }
}else{
    $OznakaSport="20";
}
function ClearBlank($x){
    if (strlen($x) > 0){
        $x=str_replace("&nbsp;","",$x);
    }
    return $x;
}
function vsebuje($s,$a){
    //ali niz števil ločenih z vejico $s vsebuje število $a
    $sarr=explode(",",$s);
    for ($i=0;$i < count($sarr);$i++){
        if (intval($a)==intval($sarr[$i])){
            return true;
        }
    }
    return false;
}
function Arr2Str($a){
    $s="";
    if (is_array($a)){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }else{
        return $a;
    }
    return $s;
}
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["razredi"])){
    $VRazred = Arr2Str($_POST["razredi"]);
}else{
    $VRazred = 0;
}

if (isset($_POST["ucitelj"])){
    $VUcitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $VUcitelj=$_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){
            $VUcitelj=$_SESSION["ucitelj"];
        }else{
            $VUcitelj = 0;
        }
    }
}

switch ($Vid){
    case "4":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}    

switch ($Vid){
    case "1":  //vpis splošnih podatkov o sedežnem redu
        $SQL = "SELECT id FROM tabsedred WHERE opomba='".$_POST["opis"]."' AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            //zapis že obstaja
            if ($R = mysqli_fetch_array($result)){
                $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
                $SQL = $SQL . "WHERE tabsedred.id=".$R["id"];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>".$R["opomba"]."</h2>";
                    echo "<div>Učitelj: ".$R["priimek"]." ".$R["ime"]."</div>";
                    echo "<div>Predmet: ".$R["oznaka"]."</div>";
                    echo "<div>Prostor: ".$R["poznaka"]." - ".$R["stevilka"]."</div>";
                    $vrst=$R["vrst"];
                    $kolon=$R["kolon"];
                    $iducenci=$R["iducenci"];
                }

                echo "<form  name='sedeznired' method='post' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='2'>";
                echo "<input name='iducenci' type='hidden' value='".$iducenci."'>";
                echo "<input name='vrst' type='hidden' value='".$vrst."'>";
                echo "<input name='kolon' type='hidden' value='".$kolon."'>";
                echo "<h3 id='app_status'>Povleci & spusti je pripravljen ...</h3>";
                echo "<p>Ob klopi napišite številko učenca ali povlecite ime učenca na ustrezno klop.</p>";
                
                echo "<table class='hide'><tr class='hide'><td class='hide' valign='top'>";

                echo "<table border='0'>";
                echo "<tr>";
                $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka FROM ((tabsedredu ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabsedredu.iducenci=".$iducenci." AND tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto;
                $SQL = $SQL . " ORDER BY razred,oznaka,priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                $razred=0;
                while ($R = mysqli_fetch_array($result)){
                    echo "<td valign='top'>";
                    if ($razred != $R["id"]){
                        $razred=$R["id"];
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.slika FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE idrazred=".$R["id"]." ORDER BY priimek,ime";
                        $result1 = mysqli_query($link,$SQL);
                        $i=1;
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo "<div id='".$Indx."' draggable='true' ondragstart='drag(event)' ondragend='drag_end(event)'>";
                            echo "<table class='hide'><tr class='hide'>";

                            echo "<td class='hide'><input name='uc_".$Indx."' type='hidden' value='".$R1["iducenec"]."'>";
                            //echo "<img src='".$R1["slika"]."' width='30'>";
                            echo "</td>";
                            if ($Indx % 2 == 0){
                                echo "<td class='hide' style='background-color:lightskyblue' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                            }else{
                                echo "<td class='hide' style='background-color:lightgreen' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                            }
                            $Ucenci[$Indx]=$R1["iducenec"];
                            echo "</tr></table>";
                            echo "</div>";
                            $Indx=$Indx+1;
                        }
                        echo "</td>";
                    }
                }
                $StUcencev=$Indx-1;
                echo "<input name='stuc' type='hidden' value='".($Indx-1)."'>";
                echo "</tr>";
                echo "</table>";
                
                echo "</td><td valign='top' class='hide'>";
                
                echo "<table border='1'>";
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT iducenec FROM tabsedredu WHERE iducenci=".$iducenci." AND sedez=".($kolon*($i-1)+$j);
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            for($Indx=1;$Indx <= $StUcencev;$Indx++){
                                if ($Ucenci[$Indx]==$R1["iducenec"]){
                                    $SQL = "SELECT slika FROM tabrazred WHERE leto=".$VLeto." AND iducenec=".$Ucenci[$Indx];
                                    $result2 = mysqli_query($link,$SQL);
                                    if ($R2 = mysqli_fetch_array($result2)){
                                        if (file_exists($R2["slika"])){
                                            echo "<div ><img src='".$R2["slika"]."' width='60'></div>";
                                        }else{
                                            echo "<div>&nbsp;</div>";
                                        }
                                    }else{
                                        echo "<div ><img src='img/miza.png' width='80'></div>";
                                    }
                                    echo "<input id='kl_".($kolon*($i-1)+$j)."' name='izbkl_".($kolon*($i-1)+$j)."' type='text' size='4' value='".$Indx."' ondragenter='drag_enter(event)' ondragover='return false' ondragleave='drag_leave(event)' ondrop='drop(event)' ondragover='allowDrop(event)' />";
                                    break;
                                }
                            }
                        }else{
                            echo "<div ><img src='img/miza.png' width='80'></div>";
                            echo "<input id='kl_".($kolon*($i-1)+$j)."' name='izbkl_".($kolon*($i-1)+$j)."' type='text' size='4' value='' ondragenter='drag_enter(event)' ondragover='return false' ondragleave='drag_leave(event)' ondrop='drop(event)' ondragover='allowDrop(event)' />";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<input name='submit' type='submit' value='Pošlji'>";

                echo "</td></tr></table>";

                echo "</form>";
            }
        }else{
            //nov zapis
            $SQL = "INSERT INTO tabsedred (leto,iducitelj,idpredmet,idprostor,iducenci,vrst,kolon,vpisal,datum,opomba) VALUES (";
            $SQL = $SQL . $VLeto;
            $SQL = $SQL . ",".$VUcitelj;
            $SQL = $SQL . ",".$_POST["predmet"];
            $SQL = $SQL . ",".$_POST["prostor"];
            $iducenci=time();
            $SQL = $SQL . ",".$iducenci;
            $SQL = $SQL . ",".$_POST["vrst"];
            $SQL = $SQL . ",".$_POST["kolon"];
            $SQL = $SQL . ",'".$VUporabnik."'";
            $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
            $SQL = $SQL . ",'".$_POST["opis"]."')";
            if ($result = mysqli_query($link,$SQL)){
                echo "<h2>Sedežni red je vpisan!</h2>";
            }else{
                echo "<h2>Ni vpisano - napaka!</h2>";
            }
            echo "<h3 id='app_status'>Povleci & spusti je pripravljen ...</h3>";

            $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
            $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
            $SQL = $SQL . "WHERE tabsedred.iducenci=".$iducenci;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>".$R["opomba"]."</h2>";
                echo "<div>Učitelj: ".$R["priimek"]." ".$R["ime"]."</div>";
                echo "<div>Predmet: ".$R["oznaka"]."</div>";
                echo "<div>Prostor: ".$R["poznaka"]." - ".$R["stevilka"]."</div>";
            }

            echo "<form  name='sedeznired' method='post' action='sedeznired.php'>";
            echo "<input name='id' type='hidden' value='2'>";
            echo "<input name='iducenci' type='hidden' value='".$iducenci."'>";
            echo "<p>Ob klopi napišite številko učenca ali povlecite ime učenca na ustrezno klop.</p>";
            
            echo "<table class='hide'><tr class='hide'><td class='hide' valign='center'>";
            
            echo "<table border='1'>";
            $vrst=intval($_POST["vrst"]);
            $kolon=intval($_POST["kolon"]);
            echo "<input name='vrst' type='hidden' value='".$vrst."'>";
            echo "<input name='kolon' type='hidden' value='".$kolon."'>";
            for ($i=$vrst;$i >= 1;$i--){
                echo "<tr>";
                for ($j=1;$j <= $kolon;$j++){
                    echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                    echo "<div ><img src='img/miza.png' width='80'></div>";
                    echo "<input id='kl_".($kolon*($i-1)+$j)."' name='izbkl_".($kolon*($i-1)+$j)."' type='text' size='4' value='' ondragenter='drag_enter(event)' ondragover='return false' ondragleave='drag_leave(event)' ondrop='drop(event)' ondragover='allowDrop(event)' />";
                    echo "</td>";
                }
                echo "</tr>";
            }
            echo "</table><br />";
            
            echo "<input name='submit' type='submit' value='Pošlji'>";
            
            echo "</td><td valign='top' class='hide'>";
            
            echo "<table border='0'>";
            echo "<tr>";
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE id IN (".$VRazred.")";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<td valign='top'>";
                //echo "<input name='raz_".$Indx."' type='hidden' value='".$R["id"]."'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.slika FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE idrazred=".$R["id"]." ORDER BY priimek,ime";
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    echo "<div id='".$Indx."' draggable='true' ondragstart='drag(event)' ondragend='drag_end(event)'>";
                    echo "<table class='hide'><tr class='hide'>";
                    echo "<td class='hide'><input name='uc_".$Indx."' type='hidden' value='".$R1["iducenec"]."'>";
                    if (file_exists($R1["slika"])){
                        echo "<img src='".$R1["slika"]."' width='30'>";
                    }
                    echo "</td>";
                    if ($Indx % 2 == 0){
                        echo "<td class='hide' style='background-color:lightskyblue' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    }else{
                        echo "<td class='hide' style='background-color:lightgreen' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    }
                    echo "</tr></table>";
                    echo "</div>";
                    $Indx=$Indx+1;
                }
                echo "</td>";
            }
            echo "<input name='stuc' type='hidden' value='".($Indx-1)."'>";
            echo "</tr>";
            echo "</table>";
            
            echo "</td></tr></table>";
            
            echo "</form>";
        }
        break;
    case "2":  //vpis podatkov o učencih
        if (isset($_POST["stuc"])){
            for ($i=1;$i <= intval($_POST["vrst"])*intval($_POST["kolon"]);$i++){
                if (isset($_POST["izbkl_".$i])){
                    if (intval($_POST["izbkl_".$i]) > 0){
                        $Indx=$_POST["uc_".$_POST["izbkl_".$i]];
                        $SQL = "SELECT id FROM tabsedredu WHERE iducenci=".$_POST["iducenci"]." AND iducenec=".$Indx;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabsedredu SET sedez=".$i." WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabsedredu (iducenci,iducenec,sedez) VALUES (".$_POST["iducenci"].",".$Indx.",".$i.")";
                        }
                        if (!$result1 = mysqli_query($link,$SQL)){
                            echo "Napaka pri vpisu v tabelo!<br />";
                        }
                    }else{
                        $SQL = "SELECT id FROM tabsedredu WHERE iducenci=".$_POST["iducenci"]." AND sedez=".$i;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "DELETE FROM tabsedredu WHERE id=".$R["id"];
                            if (!$result1 = mysqli_query($link,$SQL)){
                                echo "Napaka pri vpisu v tabelo!<br />";
                            }else{
                                echo "Učenec je bil odstranje s sedežnega reda!<br />";
                            }
                        }
                    }
                }
            }
        }
        //izpis sedežnega reda
        $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
        $SQL = $SQL . "WHERE tabsedred.iducenci=".$_POST["iducenci"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["opomba"]."</h2>";
            echo "<div>Učitelj: ".$R["priimek"]." ".$R["ime"]."</div>";
            echo "<div>Predmet: ".$R["oznaka"]."</div>";
            echo "<div>Prostor: ".$R["poznaka"]." - ".$R["stevilka"]."</div>";
            $vrst=$R["vrst"];
            $kolon=$R["kolon"];
            $iducenci=$R["iducenci"];
            $Zapis=$R["id"];
        }
        echo "<table border='1'>";
        echo "<tr><td bgcolor='lightseagreen'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=1'>Osnovno</a></td><td bgcolor='orange'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=2'>Odsotnosti</a></td><td bgcolor='cyan'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=3'>Opombe</a></td><td bgcolor='yellow'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=4'>Redovalnica</a></td></tr>";
        echo "</table><br />";
        echo "<table border='1'>";
        for ($i=$vrst;$i >= 1;$i--){
            echo "<tr>";
            for ($j=1;$j <= $kolon;$j++){
                echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsedredu.iducenec,tabsedredu.sedez FROM ((tabsedredu ";
                $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci." AND tabsedredu.sedez=".($kolon*($i-1)+$j);
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                    if (file_exists("slike/".$VLeto."_".$R["iducenec"].".jpg")){
                        echo "<img src='slike/".$VLeto."_".$R["iducenec"].".jpg' width='80'>";
                    }
                }else{
                    echo "<img src='img/miza.png' width='80'>";
                }
                echo "</td>";
            }
            echo "</tr>";
        }
        echo "</table><br />";
        
        break;
    case "3":  //popravi sedežni red
        if (isset($_POST["zapis"])){
            $VZapis=intval($_POST["zapis"]);
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=intval($_GET["zapis"]);
            }else{
                $VZapis=0;
            }
        }
        if ($VZapis > 0){
            $DovoljenVpis=false;
            $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabsedred.iducitelj,tabsedred.vpisal,tabucitelji.priimek,tabsedred.idpredmet,tabucitelji.ime,tabsedred.idprostor FROM (tabsedred ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
            $SQL = $SQL . "WHERE tabsedred.id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($VLevel < 3){
                    if ($VUporabnik==$R["vpisal"]){
                        $DovoljenVpis=true;
                    }
                }else{
                    $DovoljenVpis=true;
                }
                if ($DovoljenVpis){
                    echo "<h2>Sedežni red - popravi</h2>";
                    echo "<form  name='sedeznired' method='post' action='sedeznired.php'>";
                    echo "<input name='id' type='hidden' value='6'>";
                    echo "<input name='zapis' type='hidden' value='".$VZapis."'>";
                    
                    echo "<p>Za opis sedežnega reda vpišite enoumne podatke npr: MAT 8a 1 (pomen: matematika 8.a 1. skupina).<br />Pri razredih s Ctrl+klik označite razrede v katerih so vaši učenci.</p>";
                    echo "<table border='1'>";
                    echo "<tr><th>Št.</th><th>Sed. red - opis</th><th>Učitelj</th><th>Predmet</th><th>Prostor</th><th>Vrst</th><th>Kolon</th><th>Učenci</th><th></th></tr>";
                    echo "<tr>";
                    echo "<td>&nbsp;</td>";
                    echo "<td><input name='opis' type='text' value='".$R["opomba"]."'></td>";
                    $IdUcitelj=$R["iducitelj"];
                    echo "<td><input name='ucitelj' type='hidden' value='".$IdUcitelj."'>".$R["priimek"]." ".$R["ime"]."</td>";

                    echo "<td><select name='predmet'>";
                    echo "<option value='0' selected='selected'>Ni izbran</option>";
                    $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabucenje INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id WHERE iducitelj=".$IdUcitelj." AND tabucenje.leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["id"]==$R["idpredmet"]){
                            echo "<option value='".$R1["id"]."' selected='selected'>".$R1["opis"]." - ".$R1["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R1["id"]."'>".$R1["opis"]." - ".$R1["oznaka"]."</option>";
                        }
                    }        
                    echo "</select></td>";
                    
                    echo "<td><select name='prostor'>";
                    echo "<option value='0' selected='selected'>Ni izbran</option>";
                    $SQL = "SELECT idprostor,stevilka,oznaka FROM tabprostor WHERE stmiz > 0";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["idprostor"]==$R["idprostor"]){
                            echo "<option value='".$R1["idprostor"]."' selected='selected'>".$R1["oznaka"]." - ".$R1["stevilka"]."</option>";
                        }else{
                            echo "<option value='".$R1["idprostor"]."'>".$R1["oznaka"]." - ".$R1["stevilka"]."</option>";
                        }
                    }        
                    echo "</select></td>";
                    
                    echo "<td>";
                    echo "<select name='vrst'>";
                    for ($i=1;$i <= 9;$i++){
                        if ($i==$R["vrst"]){
                            echo "<option value='".$i."' selected='selected'>".$i."</option>";
                        }else{
                            echo "<option value='".$i."'>".$i."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td>";
                    
                    echo "<td>";
                    echo "<select name='kolon'>";
                    for ($i=1;$i <= 9;$i++){
                        if ($i==$R["kolon"]){
                            echo "<option value='".$i."' selected='selected'>".$i."</option>";
                        }else{
                            echo "<option value='".$i."'>".$i."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td>";

                    $SQL = "SELECT DISTINCT tabrazred.idrazred FROM tabsedredu ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabsedredu.iducenec=tabrazred.iducenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabsedredu.iducenci=".$R["iducenci"];
                    $result1 = mysqli_query($link,$SQL);
                    $razredi="";
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($razredi) > 0){
                            $razredi=$razredi.",".$R1["idrazred"];
                        }else{
                            $razredi=$R1["idrazred"];
                        }
                    }
                    echo "<td>";
                    echo "<select name='razredi[]' multiple='multiple'>";
                    $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (vsebuje($razredi,$R1["id"])){
                            echo "<option value='".$R1["id"]."' selected='selected'>".$R1["razred"].". ".$R1["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R1["id"]."'>".$R1["razred"].". ".$R1["oznaka"]."</option>";
                        }
                    }        
                    echo "</select>";
                    echo "</td>";
                    
                    echo "<td>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</td>";
                    
                    echo "</tr></table>";
                }else{
                    echo "Nimate dovoljenja za popravljanje tega sedežnega reda!<br />";
                }
            }
        }
        break;
    case "4":  //briši sedežni red
        if (isset($_POST["zapis"])){
            $VZapis=intval($_POST["zapis"]);
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=intval($_GET["zapis"]);
            }else{
                $VZapis=0;
            }
        }
        if ($VZapis > 0){
            $SQL = "SELECT id,iducenci,opomba,vpisal FROM tabsedred WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($VLevel < 3){
                    if ($VUporabnik==$R["vpisal"]){
                        $SQL = "DELETE FROM tabsedredu WHERE iducenci=".$R["iducenci"];
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "Izbrisani so podatki o učencih v sedežnem redu ".$R["opomba"]."!<br />";
                        }else{
                            echo "Napaka pri brisanju učencev iz sedežnega reda!<br />";
                        }
                        $SQL = "DELETE FROM tabsedred WHERE id=".$R["id"];
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "Izbrisani so podatki o sedežnem redu ".$R["opomba"]."!<br />";
                        }else{
                            echo "Napaka pri brisanju sedežnega reda!<br />";
                        }
                        $SQL = "UPDATE tabdnevnik SET idsedred=0 WHERE idsedred=".$R["id"];
                        if ($result1 = mysqli_query($link,$SQL)){
                            echo "Izbrisani so podatki o sedežnem redu ".$R["opomba"]." v e-dnevniku!<br />";
                        }else{
                            echo "Napaka pri brisanju sedežnega reda iz e-dnevnika!<br />";
                        }
                    }
                }else{
                    $SQL = "DELETE FROM tabsedredu WHERE iducenci=".$R["iducenci"];
                    if ($result1 = mysqli_query($link,$SQL)){
                        echo "Izbrisani so podatki o učencih v sedežnem redu ".$R["opomba"]."!<br />";
                    }else{
                        echo "Napaka pri brisanju učencev iz sedežnega reda!<br />";
                    }
                    $SQL = "DELETE FROM tabsedred WHERE id=".$R["id"];
                    if ($result1 = mysqli_query($link,$SQL)){
                        echo "Izbrisani so podatki o sedežnem redu ".$R["opomba"]."!<br />";
                    }else{
                        echo "Napaka pri brisanju sedežnega reda!<br />";
                    }
                    $SQL = "UPDATE tabdnevnik SET idsedred=0 WHERE idsedred=".$R["id"];
                    if ($result1 = mysqli_query($link,$SQL)){
                        echo "Izbrisani so podatki o sedežnem redu ".$R["opomba"]." v e-dnevniku!<br />";
                    }else{
                        echo "Napaka pri brisanju sedežnega reda iz e-dnevnika!<br />";
                    }
                }
            }
        }
        echo "<br /><a href='sedeznired.php'>Na sedežni red</a><br />";
        break;
    case "5":  //poglej sedežni red
        if (isset($_POST["zapis"])){
            $Zapis=$_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $Zapis=$_GET["zapis"];
            }else{
                $Zapis=0;
            }
        }
        if (isset($_POST["tip"])){
            $Tip=$_POST["tip"];
        }else{
            if (isset($_GET["tip"])){
                $Tip=$_GET["tip"];
            }else{
                $Tip="1";
            }
        }
        //izpis sedežnega reda
        $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabsedred.idpredmet,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
        $SQL = $SQL . "WHERE tabsedred.id=".$Zapis;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["opomba"]."</h2>";
            echo "<div>Učitelj: ".$R["priimek"]." ".$R["ime"]."</div>";
            echo "<div>Predmet: ".$R["oznaka"]."</div>";
            echo "<div>Prostor: ".$R["poznaka"]." - ".$R["stevilka"]."</div>";
            $vrst=$R["vrst"];
            $kolon=$R["kolon"];
            $iducenci=$R["iducenci"];
            $VPredmet=$R["idpredmet"];
        }
        echo "<table border='1'>";
        echo "<tr><td bgcolor='lightseagreen'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=1'>Osnovno</a></td><td bgcolor='orange'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=2'>Odsotnosti</a></td><td bgcolor='cyan'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=3'>Opombe</a></td><td bgcolor='yellow'><a href='sedeznired.php?zapis=".$Zapis."&id=5&tip=4'>Redovalnica</a></td></tr>";
        echo "</table><br />";
        
        switch ($Tip){
            case "2": //vnos odsotnosti
                $VAktMin=$Danes->format('H')*60+$Danes->format('i');
                if (isset($_POST["ura"])){
                    $VUra = $_POST["ura"];
                }else{
                    if (isset($_GET["ura"])){
                        $VUra=$_GET["ura"];
                    }else{
                        $VUra = -1;
                    }
                }
                if (isset($_POST["datum"])){
                    if (isDate($_POST["datum"])){
                        $VDatum = new DateTime(isDate($_POST["datum"]));
                    }else{
                        $VDatum = new DateTime($Danes->format('Y-m-d'));
                    }
                }else{
                    if (isset($_GET["datum"])){
                        if (isDate($_GET["datum"])){
                            $VDatum=new DateTime(isDate($_GET["datum"]));
                        }else{
                            $VDatum = new DateTime($Danes->format('Y-m-d'));
                        }    
                    }else{
                        $VDatum = new DateTime($Danes->format('Y-m-d'));
                    }
                }
                
                if ($VUra < 0){
                    $SQL = "SELECT ura FROM tabdnevnikure WHERE zacetek >= ".$VAktMin." AND konec <= ".$VAktMin;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VUra=$R["ura"];
                    }else{
                        if ($Danes->format('H') >= 7){
                            $VUra=$Danes->format('H')-7;
                        }else{
                            $VUra=0;
                        }
                    }
                }
                if (isset($_POST["stuc"])){ //vpiše, če so bile poslane odsotnosti
                    if (isDate($_POST["datum"])){
                        $VDatum=new DateTime(isDate($_POST["datum"]));
                        for($i=1;$i <= intval($_POST["stuc"]);$i++){
                            if (intval($_POST["opid_".$i]) > 0){
                                $SQL = "SELECT id,status FROM tabodsotnostuc WHERE id=".$_POST["opid_".$i];
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    switch ($R["status"]){
                                        case 3: //pobrisan status
                                            if (isset($_POST["op_".$i])){
                                                $SQL = "UPDATE tabodsotnostuc SET status=0,spremenil=".$IdUcitelj.",casspr='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];  //nastavi odsotnost
                                                $result1 = mysqli_query($link,$SQL);
                                            }
                                            break;
                                        default:
                                            $SQL = "UPDATE tabodsotnostuc SET status=3,spremenil=".$IdUcitelj.",casspr='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];  //nastavi pobrisano odsotnost
                                            $result1 = mysqli_query($link,$SQL);
                                    }
                                }
                            }else{
                                if (isset($_POST["op_".$i])){
                                    $SQL = "INSERT INTO tabodsotnostuc (leto,datum,iducenec,ura,predmet,ucitelj,status,vpisal,casvp) VALUES ";
                                    $SQL = $SQL ."(".$VLeto.",'".$VDatum->format('Y-m-d')."',".$_POST["ime_".$i].",".$VUra.",".$VPredmet.",".$IdUcitelj.",0,".$IdUcitelj.",'".$Danes->format('Y-m-d H:i:s')."')";
                                    $result1 = mysqli_query($link,$SQL);
                                }
                            }
                        }
                    }
                }
                echo "<form name='vnoscasa' method='POST' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='5'>";
                echo "<input name='tip' type='hidden' value='2'>";
                echo "<input name='zapis' type='hidden' value='".$Zapis."'>";
                echo "<table border='0'>";
                echo "<tr><td>Datum</td><td>";
                echo "<input name='datum' type='text' id='dat01' value='".$VDatum->format('j.n.Y')."' size='8'>";
                echo "</td></tr>";
                
                $VDanVTednu=$VDatum->format('w'); //'1. dan je ponedeljek
                $VOpombe="";
                $VStatusUre=0;
                
                echo "<tr><td>Ura v urniku</td><td>"; //<b>".Int2Dan($VDanVTednu)."</b>&nbsp;";
                echo "<select name=\"ura\" onchange=\"this.form.submit()\">";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    if ($Indx==$VUra){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."'>".$Indx."</option>";
                    }
                }
                echo "</select><input name='submit' type='submit' value='Izberi'>";
                echo "</td></tr>";
                echo "</table><br />";
                echo "</form>";
                
                echo "<div id='sedred_izost'>";
                echo "<form name='vnosopomb' method='POST' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='5'>";
                echo "<input name='tip' type='hidden' value='2'>";
                echo "<input name='zapis' type='hidden' value='".$Zapis."'>";
                echo "<input name='datum' type='hidden' value='".$VDatum->format('j.n.Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<table border='1'>";
                $indxu=0;
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsedredu.iducenec,tabsedredu.sedez FROM ((tabsedredu ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci." AND tabsedredu.sedez=".($kolon*($i-1)+$j);
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $indxu=$indxu+1;
                            echo "<a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'><b>".$R["ime"]."</b><br />".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                            if (file_exists("slike/".$VLeto."_".$R["iducenec"].".jpg")){
                                echo "<img src='slike/".$VLeto."_".$R["iducenec"].".jpg' height='60'><br />";
                            }
                            
                            $aktopid=0; //aktualna odsotnost
                            $aktopstat=-1;
//                            $SQL = "SELECT id,ura FROM tabodsotnostuc WHERE datum='".$VDatum->format('Y-m-d')."' AND iducenec=".$R["iducenec"]." ORDER BY ura";
                            $SQL = "SELECT id,ura,status FROM tabodsotnostuc WHERE year(datum)=".$VDatum->format('Y')." AND month(datum)=".$VDatum->format('n')." AND day(datum)=".$VDatum->format('j')." AND iducenec=".$R["iducenec"]." ORDER BY ura";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                if ($R1["status"] < 3){
                                    echo $R1["ura"]." ";
                                }
                                if ($R1["ura"]==$VUra){
                                    $aktopid=$R1["id"];
                                    $aktopstat=$R1["status"];
                                }
                            }
                            echo "<br />";
                            echo "<input name='ime_".$indxu."' type='hidden' value='".$R["iducenec"]."'>";
                            echo "<input name='opid_".$indxu."' type='hidden' value='".$aktopid."'>";
                            if ($aktopid > 0){
                                if ($aktopstat < 3){
                                    echo "<input name='op_".$indxu."' type='checkbox' checked='checked'>"." ".$VUra;
                                }else{
                                    echo "<input name='op_".$indxu."' type='checkbox'>"." ".$VUra;
                                }
                            }else{
                                echo "<input name='op_".$indxu."' type='checkbox'>"." ".$VUra;
                            }
                        }else{
                            echo "<img src='img/miza.png' width='80'>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<input name='stuc' type='hidden' value='".$indxu."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></td></tr>";
                echo "</form><br>";
                echo "</div>";
                break;
            case "3": //vnos opomb
                $VAktMin=$Danes->format('H')*60+$Danes->format('i');
                if (isset($_POST["ura"])){
                    $VUra = $_POST["ura"];
                }else{
                    if (isset($_GET["ura"])){
                        $VUra=$_GET["ura"];
                    }else{
                        $VUra = -1;
                    }
                }
                if (isset($_POST["datum"])){
                    if (isDate($_POST["datum"])){
                        $VDatum = new DateTime(isDate($_POST["datum"]));
                    }else{
                        $VDatum = new DateTime($Danes->format('Y-m-d'));
                    }
                }else{
                    if (isset($_GET["datum"])){
                        if (isDate($_GET["datum"])){
                            $VDatum=new DateTime(isDate($_GET["datum"]));
                        }else{
                            $VDatum = new DateTime($Danes->format('Y-m-d'));
                        }    
                    }else{
                        $VDatum = new DateTime($Danes->format('Y-m-d'));
                    }
                }
                
                if ($VUra < 0){
                    $SQL = "SELECT ura FROM tabdnevnikure WHERE zacetek >= ".$VAktMin." AND konec <= ".$VAktMin;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VUra=$R["ura"];
                    }else{
                        if ($Danes->format('H') >= 7){
                            $VUra=$Danes->format('H')-7;
                        }else{
                            $VUra=0;
                        }
                    }
                }
                if (isset($_POST["stuc"])){ //vpiše, če so bile poslane opombe
                    if (isDate($_POST["datum"])){
                        $VDatum=new DateTime(isDate($_POST["datum"]));
                        for($i=1;$i <= intval($_POST["stuc"]);$i++){
                            if (intval($_POST["opid_".$i]) > 0){
                                $SQL = "SELECT id,status FROM tabodsotnostuc WHERE id=".$_POST["opid_".$i];
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    $SQL = "UPDATE tabodsotnostuc SET opomba='".$_POST["op_".$i]."',spremenil=".$IdUcitelj.",casspr='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];  //prepiše 
                                    $result1 = mysqli_query($link,$SQL);
                                }
                            }else{
                                if (strlen($_POST["op_".$i]) > 0){
                                    $SQL = "INSERT INTO tabopombeuc (leto,datum,iducenec,ura,predmet,ucitelj,opomba,vpisal,casvp) VALUES ";
                                    $SQL = $SQL ."(".$VLeto.",'".$VDatum->format('Y-m-d')."',".$_POST["ime_".$i].",".$VUra.",".$VPredmet.",".$IdUcitelj.",'".$_POST["op_".$i]."',".$IdUcitelj.",'".$Danes->format('Y-m-d H:i:s')."')";
                                    $result1 = mysqli_query($link,$SQL);
                                }
                            }
                        }
                    }
                }
                
                echo "<form name='vnoscasa' method='POST' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='5'>";
                echo "<input name='tip' type='hidden' value='3'>";
                echo "<input name='zapis' type='hidden' value='".$Zapis."'>";
                echo "<table border='0'>";
                echo "<tr><td>Datum</td><td>";
                echo "<input name='datum' type='text' id='dat01' value='".$VDatum->format('j.n.Y')."' size='8'>";
                echo "</td></tr>";
                
                $VDanVTednu=$VDatum->format('w'); //'1. dan je ponedeljek
                $VOpombe="";
                $VStatusUre=0;
                
                echo "<tr><td>Ura v urniku</td><td>"; //<b>".Int2Dan($VDanVTednu)."</b>&nbsp;";
                echo "<select name='ura'>";
                for ($Indx=0;$Indx <= $UrNaDan;$Indx++){
                    if ($Indx==$VUra){
                        echo "<option value='".$Indx."' selected='selected'>".$Indx."</option>";
                    }else{
                        echo "<option value='".$Indx."'>".$Indx."</option>";
                    }
                }
                echo "</select><input name='submit' type='submit' value='Izberi'>";
                echo "</td></tr>";
                echo "</table><br />";
                echo "</form>";

                echo "<form name='vnosopomb' method='POST' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='5'>";
                echo "<input name='tip' type='hidden' value='3'>";
                echo "<input name='zapis' type='hidden' value='".$Zapis."'>";
                echo "<input name='datum' type='hidden' value='".$VDatum->format('j.n.Y')."'>";
                echo "<input name='ura' type='hidden' value='".$VUra."'>";
                echo "<table border='1'>";
                $indxu=0;
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsedredu.iducenec,tabsedredu.sedez FROM ((tabsedredu ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci." AND tabsedredu.sedez=".($kolon*($i-1)+$j);
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $indxu=$indxu+1;
                            echo "<a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'><b>".$R["ime"]."</b><br />".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                            if (file_exists("slike/".$VLeto."_".$R["iducenec"].".jpg")){
                                echo "<img src='slike/".$VLeto."_".$R["iducenec"].".jpg' height='60'><br />";
                            }
                            
                            $aktop=""; //aktualna opomba
                            $aktopid=0;
//                            $SQL = "SELECT id,ura,opomba FROM tabopombeuc WHERE datum='".$VDatum->format('Y-m-d')."' ORDER BY ura";
                            $SQL = "SELECT id,ura,opomba FROM tabopombeuc WHERE year(datum)=".$VDatum->format('Y')." AND month(datum)=".$VDatum->format('n')." AND day(datum)=".$VDatum->format('j')." AND iducenec=".$R["iducenec"]." ORDER BY ura";
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["ura"].". ".$R1["opomba"]."<br />";
                                if ($R1["ura"]==$VUra){
                                    $aktop=$R1["opomba"];
                                    $aktopid=$R1["id"];
                                }
                            }
                            echo "<input name='ime_".$indxu."' type='hidden' value='".$R["iducenec"]."'>";
                            echo "<input name='opid_".$indxu."' type='hidden' value='".$aktopid."'>";
                            echo "<textarea name='op_".$indxu."' cols='10' rows='2'>".$aktop."</textarea>";
                        }else{
                            echo "<img src='img/miza.png' width='80'>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<input name='stuc' type='hidden' value='".$indxu."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></td></tr>";
                echo "</form><br>";
                break;
            case "4": //vnos redovalnice
                if (isset($_POST["stuc"])){  //vpiše, če so bile poslane ocene
                    for($i=1;$i <= intval($_POST["stuc"]);$i++){
                        if (intval($_POST["opid_".$i]) > 0){
                            $SQL = "SELECT id,ocenas1p,ocenas1u,ocenas2p,ocenas2u FROM tabocene WHERE id=".$_POST["opid_".$i];
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                if (($R["ocenas1p"] != $_POST["s1p_".$i]) or ($R["ocenas1u"] != $_POST["s1u_".$i]) or ($R["ocenas2p"] != $_POST["s2p_".$i]) or ($R["ocenas2u"] != $_POST["s2u_".$i])){
                                    $SQL = "UPDATE tabocene SET ocenas1p='".$_POST["s1p_".$i]."'";
                                    $SQL = $SQL . ",ocenas1u='".$_POST["s1u_".$i]."'";
                                    $SQL = $SQL . ",ocenas2p='".$_POST["s2p_".$i]."'";
                                    $SQL = $SQL . ",ocenas2u='".$_POST["s2u_".$i]."'";
                                    $SQL = $SQL .",vpisovalec='".$VUporabnik."',datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];  //prepiše 
                                    $result1 = mysqli_query($link,$SQL);
                                }
                            }
                        }else{
                            $SQL = "INSERT INTO tabocene (leto,iducenec,idpredmet,ocenas1p,ocenas1u,ocenas2p,ocenas2u,neocenjen,popravni,ocenakoncna,ocenapolletna,datum,vpisovalec) VALUES ";
                            $SQL = $SQL ."(".$VLeto.",".$_POST["ime_".$i].",".$VPredmet.",'".$_POST["s1p_".$i]."','".$_POST["s1u_".$i]."','".$_POST["s2p_".$i]."','".$_POST["s2u_".$i]."',0,0,'','','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                            $result1 = mysqli_query($link,$SQL);
                        }
                    }
                }
                
                echo "<form name='vnosopomb' method='POST' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='5'>";
                echo "<input name='tip' type='hidden' value='4'>";
                echo "<input name='zapis' type='hidden' value='".$Zapis."'>";

                echo "<table border='1'>";
                $indxu=0;
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsedredu.iducenec,tabsedredu.sedez FROM ((tabsedredu ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci." AND tabsedredu.sedez=".($kolon*($i-1)+$j);
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $indxu=$indxu+1;
                            echo "<a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'><b>".$R["ime"]."</b><br />".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                            if (file_exists("slike/".$VLeto."_".$R["iducenec"].".jpg")){
                                echo "<img src='slike/".$VLeto."_".$R["iducenec"].".jpg' height='60'><br />";
                            }
                            
                            echo "<input name='ime_".$indxu."' type='hidden' value='".$R["iducenec"]."'>";
                            $SQL = "SELECT id,ocenas1p,ocenas1u,ocenas2p,ocenas2u,ocenapolletna,ocenakoncna FROM tabocene WHERE iducenec=".$R["iducenec"]." AND leto=".$VLeto." AND idpredmet=".$VPredmet;
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo "<input name='opid_".$indxu."' type='hidden' value='".$R1["id"]."'>";
                                echo "<table border='0'>";
                                echo "<tr><th>Pisno</th><th>Ustno</th></tr>";
                                echo "<tr>";
                                echo "<td>1. <input name='s1p_".$indxu."' type='text' size='4' value='".$R1["ocenas1p"]."'></td>";
                                echo "<td><input name='s1u_".$indxu."' type='text' size='4' value='".$R1["ocenas1u"]."'></td>";
                                echo "</tr>";
                                echo "<tr>";
                                echo "<td>2. <input name='s2p_".$indxu."' type='text' size='4' value='".$R1["ocenas2p"]."'></td>";
                                echo "<td><input name='s2u_".$indxu."' type='text' size='4' value='".$R1["ocenas2u"]."'></td>";
                                echo "</tr>";
                                echo "</table>";
                            }else{
                                echo "<input name='opid_".$indxu."' type='hidden' value='0'>";
                                echo "<table border='0'>";
                                echo "<tr><th>Pisno</th><th>Ustno</th></tr>";
                                echo "<tr>";
                                echo "<td>1. <input name='s1p_".$indxu."' type='text' size='4' value=''></td>";
                                echo "<td><input name='s1u_".$indxu."' type='text' size='4' value=''></td>";
                                echo "</tr>";
                                echo "<tr>";
                                echo "<td>2. <input name='s2p_".$indxu."' type='text' size='4' value=''></td>";
                                echo "<td><input name='s2u_".$indxu."' type='text' size='4' value=''></td>";
                                echo "</tr>";
                                echo "</table>";
                            }
                        }else{
                            echo "<img src='img/miza.png' width='80'>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<input name='stuc' type='hidden' value='".$indxu."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></td></tr>";
                echo "</form><br>";
                break;
            default: //osnovni prikaz s povezavami na učence
                echo "<table border='1'>";
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsedredu.iducenec,tabsedredu.sedez FROM ((tabsedredu ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci." AND tabsedredu.sedez=".($kolon*($i-1)+$j);
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</a><br />";
                            if (file_exists("slike/".$VLeto."_".$R["iducenec"].".jpg")){
                                echo "<img src='slike/".$VLeto."_".$R["iducenec"].".jpg' width='80'>";
                            }
                        }else{
                            echo "<img src='img/miza.png' width='80'>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
        }
        break;
    case "6": //vpis popravka sedežnega reda
        if (isset($_POST["zapis"])){
            $SQL = "SELECT id,opomba FROM tabsedred WHERE id=".$_POST["zapis"];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                //zapis obstaja
                $SQL = "UPDATE tabsedred SET ";
                $SQL = $SQL . "idpredmet=".$_POST["predmet"];
                $SQL = $SQL . ",idprostor=".$_POST["prostor"];
                $SQL = $SQL . ",vrst=".$_POST["vrst"];
                $SQL = $SQL . ",kolon=".$_POST["kolon"];
                $SQL = $SQL . ",opomba='".$_POST["opis"]."' ";
                $SQL = $SQL . " WHERE id=".$_POST["zapis"];
                if ($result1 = mysqli_query($link,$SQL)){
                    echo "Popravek sedežnega reda ".$R["opomba"]." je vpisan!<br />";
                }else{
                    echo "Popravek sedežnega reda ".$R["opomba"]." NI vpisan!<br />";
                }
                
                //izpis sedežnega reda
                $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
                $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
                $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
                $SQL = $SQL . "WHERE tabsedred.id=".$R["id"];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>".$R["opomba"]."</h2>";
                    echo "<div>Učitelj: ".$R["priimek"]." ".$R["ime"]."</div>";
                    echo "<div>Predmet: ".$R["oznaka"]."</div>";
                    echo "<div>Prostor: ".$R["poznaka"]." - ".$R["stevilka"]."</div>";
                    $vrst=$R["vrst"];
                    $kolon=$R["kolon"];
                    $iducenci=$R["iducenci"];
                }

                echo "<form  name='sedeznired' method='post' action='sedeznired.php'>";
                echo "<input name='id' type='hidden' value='2'>";
                echo "<input name='iducenci' type='hidden' value='".$iducenci."'>";
                echo "<input name='vrst' type='hidden' value='".$vrst."'>";
                echo "<input name='kolon' type='hidden' value='".$kolon."'>";
                echo "<h3 id='app_status'>Povleci & spusti je pripravljen ...</h3>";
                echo "<p>Ob klopi napišite številko učenca ali povlecite ime učenca na ustrezno klop.</p>";
                
                echo "<table class='hide'><tr class='hide'><td class='hide' valign='top'>";

                echo "<table border='0'>";
                echo "<tr>";
                //če v izboru razredov ni razreda iz prejšnjega sedežnega reda, potem tiste razrede doda spisku
                $SQL = "SELECT DISTINCT tabrazred.idrazred FROM tabsedredu ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabsedredu.iducenec=tabrazred.iducenec ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabsedredu.iducenci=".$iducenci;
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    if (!vsebuje($VRazred,$R1["idrazred"])){
                        $VRazred=$VRazred.",".$R1["idrazred"];
                    }
                }
                
                $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE id IN (".$VRazred.")";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                $razred=0;
                while ($R = mysqli_fetch_array($result)){
                    echo "<td valign='top'>";
                    if ($razred != $R["id"]){
                        $razred=$R["id"];
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.slika FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE tabrazred.leto=".$VLeto." AND idrazred=".$R["id"]." ORDER BY priimek,ime";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
                            echo "<div id='".$Indx."' draggable='true' ondragstart='drag(event)' ondragend='drag_end(event)'>";
                            echo "<table class='hide'><tr class='hide'>";
                            echo "<td class='hide'><input name='uc_".$Indx."' type='hidden' value='".$R1["iducenec"]."'>";
                            //echo "<img src='".$R1["slika"]."' width='30'>";
                            echo "</td>";
                            if ($Indx % 2 == 0){
                                echo "<td class='hide' style='background-color:lightskyblue' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                            }else{
                                echo "<td class='hide' style='background-color:lightgreen' width='100'>".$Indx.". <b>".$R1["ime"]."</b><br />".$R1["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                            }
                            $Ucenci[$Indx]=$R1["iducenec"];
                            echo "</tr></table>";
                            echo "</div>";
                            $Indx=$Indx+1;
                        }
                        echo "</td>";
                    }
                }
                $StUcencev=$Indx-1;
                echo "<input name='stuc' type='hidden' value='".($Indx-1)."'>";
                echo "</tr>";
                echo "</table>";
                
                echo "</td><td valign='center' class='hide'>";
                
                echo "<table border='1'>";
                for ($i=$vrst;$i >= 1;$i--){
                    echo "<tr>";
                    for ($j=1;$j <= $kolon;$j++){
                        echo "<td valign='top'>".($kolon*($i-1)+$j)."<br />";
                        $SQL = "SELECT iducenec FROM tabsedredu WHERE iducenci=".$iducenci." AND sedez=".($kolon*($i-1)+$j);
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            for($Indx=1;$Indx <= $StUcencev;$Indx++){
                                if ($Ucenci[$Indx]==$R1["iducenec"]){
                                    $SQL = "SELECT slika FROM tabrazred WHERE leto=".$VLeto." AND iducenec=".$Ucenci[$Indx];
                                    $result2 = mysqli_query($link,$SQL);
                                    if ($R2 = mysqli_fetch_array($result2)){
                                        if (file_exists($R2["slika"])){
                                            echo "<div ><img src='".$R2["slika"]."' width='60'></div>";
                                        }else{
                                            echo "<div>&nbsp;</div>";
                                        }
                                    }else{
                                        echo "<div ><img src='img/miza.png' width='80'></div>";
                                    }
                                    echo "<input id='kl_".($kolon*($i-1)+$j)."' name='izbkl_".($kolon*($i-1)+$j)."' type='text' size='4' value='".$Indx."' ondragenter='drag_enter(event)' ondragover='return false' ondragleave='drag_leave(event)' ondrop='drop(event)' ondragover='allowDrop(event)' />";
                                    break;
                                }
                            }
                        }else{
                            echo "<div ><img src='img/miza.png' width='80'></div>";
                            echo "<input id='kl_".($kolon*($i-1)+$j)."' name='izbkl_".($kolon*($i-1)+$j)."' type='text' size='4' value='' ondragenter='drag_enter(event)' ondragover='return false' ondragleave='drag_leave(event)' ondrop='drop(event)' ondragover='allowDrop(event)' />";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<input name='submit' type='submit' value='Pošlji'>";

                echo "</td></tr></table>";

                echo "</form>";
            }
        }    
        break;
    default:
        //obrazec za vnos sedežnega reda
        echo "<h2>Sedežni red</h2>";
        echo "<form  name='sedeznired' method='post' action='sedeznired.php'>";
        echo "<input name='id' type='hidden' value='1'><br />";
        
        echo "<p>Za opis sedežnega reda vpišite enoumne podatke npr: MAT 8a 1 (pomen: matematika 8.a 1. skupina).<br />Pri razredih s Ctrl+klik označite razrede v katerih so vaši učenci.</p>";
        echo "<table border='1'>";
        echo "<tr><th>Št.</th><th>Sed. red - opis</th><th>Učitelj</th><th>Predmet</th><th>Prostor</th><th>Vrst</th><th>Kolon</th><th>Učenci</th><th></th></tr>";
        echo "<tr>";
        echo "<td>&nbsp;</td>";
        echo "<td><input name='opis' type='text' value=''></td>";
        echo "<td><input name='ucitelj' type='hidden' value='".$IdUcitelj."'>".$Ucitelj."</td>";

        echo "<td><select name='predmet'>";
        echo "<option value='0' selected='selected'>Ni izbran</option>";
        $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.opis,tabpredmeti.oznaka FROM tabucenje INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id WHERE iducitelj=".$IdUcitelj." AND tabucenje.leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["id"]."'>".$R["opis"]." - ".$R["oznaka"]."</option>";
        }        
        echo "</select></td>";
        
        echo "<td><select name='prostor'>";
        echo "<option value='0' selected='selected'>Ni izbran</option>";
        $SQL = "SELECT idprostor,stevilka,oznaka FROM tabprostor WHERE stmiz > 0";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["idprostor"]."'>".$R["oznaka"]." - ".$R["stevilka"]."</option>";
        }        
        echo "</select></td>";
        
        echo "<td>";
        echo "<select name='vrst'>";
        for ($i=1;$i <= 9;$i++){
            echo "<option value='".$i."'>".$i."</option>";
        }
        echo "</select>";
        echo "</td>";
        
        echo "<td>";
        echo "<select name='kolon'>";
        for ($i=1;$i <= 9;$i++){
            echo "<option value='".$i."'>".$i."</option>";
        }
        echo "</select>";
        echo "</td>";

        echo "<td>";
        echo "<select name='razredi[]' multiple='multiple'>";
        $SQL = "SELECT id,razred,oznaka,idsola FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $SQL1 = "SELECT solakratko FROM tabsola WHERE id=".$R["idsola"];
            $result1 = mysqli_query($link,$SQL1);
            if ($R1 = mysqli_fetch_array($result1)){
                $sola=$R1["solakratko"];
            }else{
                $sola="";
            }
            if ($VecSol > 0){
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$sola."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }
        }        
        echo "</select>";
        echo "</td>";
        
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        
        echo "</tr>";
        
        $SQL = "SELECT tabsedred.id,tabsedred.leto,tabsedred.vrst,tabsedred.kolon,tabsedred.opomba,tabsedred.iducenci,tabucitelji.priimek,tabucitelji.ime,tabpredmeti.opis,tabpredmeti.oznaka,tabprostor.oznaka AS poznaka,tabprostor.stevilka FROM (((tabsedred ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabsedred.iducitelj=tabucitelji.iducitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabsedred.idpredmet=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON tabsedred.idprostor=tabprostor.idprostor) ";
        if ($VLevel > 2){
            $SQL = $SQL . "WHERE tabsedred.leto=".$VLeto;
        }else{
            $SQL = $SQL . "WHERE tabsedred.leto=".$VLeto." AND tabucitelji.iducitelj=".$IdUcitelj;
        }
        $SQL = $SQL . " ORDER BY tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='sedeznired.php?id=5&zapis=".$R["id"]."'>".$R["opomba"]."</a></td>";
            echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
            echo "<td>".$R["oznaka"]."</td>";
            echo "<td>".$R["poznaka"]." - ".$R["stevilka"]."</td>";
            echo "<td>".$R["vrst"]."</td>";
            echo "<td>".$R["kolon"]."</td>";
            echo "<td><select>";
            $SQL = "SELECT tabucenci.priimek,tabucenci.ime FROM tabsedredu INNER JOIN tabucenci ON tabsedredu.iducenec=tabucenci.iducenec WHERE iducenci=".$R["iducenci"]." ORDER BY tabucenci.priimek,tabucenci.ime";
            $result1 = mysqli_query($link,$SQL);
            while ($R1 = mysqli_fetch_array($result1)){
                echo "<option>".$R1["priimek"]." ".$R1["ime"]."</option>";
            }
            echo "</select></td>";
            
            echo "<td>";
            echo "<a href='sedeznired.php?id=3&zapis=".$R["id"]."'>Popravi</a>&nbsp;";
            echo "<a href='sedeznired.php?id=4&zapis=".$R["id"]."'>Briši</a>";
            echo "</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        $StSedRedov=$Indx-1;
        echo "</table>";
        echo "</form>";
}
?>

</body>
</html>
