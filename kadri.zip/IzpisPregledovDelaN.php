<?php
include('const.php');
//ini_set('max_execution_time', 600); 
include('razredi.php');
include('iskanje.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis vnesenih pregledov dela
</title>
</head>
<body>
<?php
if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        $VLeto=intval($Danes->format('Y'));
    }
}
$VLetoPregled=$VLeto;

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik="";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo="";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel=0;
}


$SQL = "SELECT iducitelj,ime,priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["ime"] . " " . $R["priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    if (isset($_POST["id"])){
        $id = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $id = $_GET["id"];
        }else{
            $id=0;
        }
    }

    switch ($id){
        case "1":  //prenos podatkov
            //pobriše stare dopuste
            if (mb_strpos($_POST["submit"],"star dopust",0,$encoding) > 0){
                if (isset($_POST["StUciteljev"])){
                    for ($Indx=1;$Indx <= intval($_POST["StUciteljev"]);$Indx++){
                        $SQL = "UPDATE tabdopust SET dopuststari=0 WHERE iducitelj=".$_POST["ime_".$Indx]." AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                    }
                    echo "<h2>Stari dopusti ".$VLeto." so pobrisani!</h2><br />";
                }
            }
            
            //prenese dopuste v naslednje leto
            if (mb_strpos($_POST["submit"],"dopusta",0,$encoding) > 0){
                if (isset($_POST["StUciteljev"])){
                    for ($Indx=1;$Indx <= intval($_POST["StUciteljev"]);$Indx++){
                        $SQL = "SELECT id FROM tabdopust WHERE iducitelj=".$_POST["ime_".$Indx]." AND leto=".($VLeto+1);
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabdopust SET dopuststari=".$_POST["dop_".$Indx]." WHERE id=".$R["id"];
                            $result1 = mysqli_query($link,$SQL);
                        }
                    }
                    echo "<h2>Prenos dopustov v novo leto je bil opravljen!</h2><br />";
                }
            }
            
            //prenese ure v naslednje leto
            if (mb_strpos($_POST["submit"],"ur",0,$encoding) > 0){
                if (isset($_POST["StUciteljev"])){
                    for ($Indx=1;$Indx <= intval($_POST["StUciteljev"]);$Indx++){
                        $doprinos=-floatval($_POST["SeUr_".$Indx]);
                        $doprinos=str_replace(",",".",$doprinos);
                        $SQL = "SELECT id,ucitelj FROM tabpregleddelan WHERE ucitelj=".$_POST["ime_".$Indx]." AND leto=".($VLeto+1)." AND mesec=1 AND dan=1 AND komentar='prenos ur'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabpregleddelan SET rubrika=25,enot=".str_replace(",",".",round($doprinos,2)).",vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."',enotpotrjeno=true,komentar='prenos ur' WHERE id=".$R["id"];
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu v bazo (".$_POST["SeUr_".$Indx].", $doprinos)<br />");
                            }else{
                                echo $R["ucitelj"].", ".round($doprinos,2)."<br />";
                            }
                        }else{
                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,komentar,enot,enotpotrjeno,datvnosa,ucitelj,vpisal,potrdil,cas) VALUES ";
                            $SQL = $SQL . "('".($VLeto+1)."-01-01',".($VLeto+1).",1,1,25,'prenos ur',".str_replace(",",".",round($doprinos,2)).",true,'".$Danes->format('Y-m-d H:i:s')."',".$_POST["ime_".$Indx].",'".$VUporabnik."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                            //$result1 = mysqli_query($link,$SQL);
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu v bazo<br />");
                            }else{
                                echo $R["ucitelj"].", ".round($doprinos,2)."<br />";
                            }
                        }
                    }
                    echo "<h2>Prenos ur v novo leto je bil opravljen!</h2><br />";
                }
            }
            break;
        default:
            $PomladniDel=0;
            $JesenskiDel=0;
            $SQL = "SELECT datum,kat FROM TabPraznik WHERE leto=".$VLetoPregled." ORDER BY datum";
            $Indx=1;
            $ProstiDnevi=0;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                /*/novo - začetek
                switch ($R["kat"]){
                    case 1:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 2; //'prost dan
                    case 0:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 1; //'praznik
                    case 2:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 3; //'delovni dan - sobota
                    case 3:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 4; //'dela prost dan
                    case 4:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 4; //'dela prost dan
                    default:
                        $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]= 0; //'ni v bazi/delovni dan
                }
                //novo - konec
                */
                // staro
                $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
	            $Praznik[$Indx][1]=$R["kat"];
                
	            if ($R["kat"]==1){
		            $ProstiDnevi=$ProstiDnevi+1;
                    $Datum=new DateTime(isDate($R["datum"]));
		            switch ($Datum->format('n')){
			            case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 8:
				            $PomladniDel=$PomladniDel+1;
                            break;
			            default:
				            $JesenskiDel=$JesenskiDel+1;
		            }
	            }
	            $Indx=$Indx+1;
            }
            $StPraznikov=$Indx-1;

            //echo "Leto: ".$VLeto."<br />";
            echo "<a href='IzpisPregledovDelaN.php?leto=".($VLeto-1)."'>Leto-1</a> <a href='IzpisPregledovDelaN.php?leto=".($VLeto+1)."'>Leto+1</a><br>";

            $SumaDoprinosov=0;
            $SumaDoprinosovPotrjeno=0;
            $SumaObveznosti=0;
            $SumaObveznostiPotrjeno=0;
            $SumaSuplenc=0;
            $SumaOstalo=0;

            $StartTime=new DateTime("now");
            echo "<h2>Mesečni pregledi dela za leto ".$VLeto."</h2>";
            echo "<form accept-charset='utf-8' name='form_realizacija' method='post' action='IzpisPregledovDelaN.php'>";
            echo "<table border='1'>";
            echo "<tr><th>Delavec</th><th>% zaposl.</th><th>Leto</th>";
            for ($indx=1;$indx <= 12;$indx++){
	            echo "<th>".$indx."</th>";
            }
            echo "<th>Potrebno</th><th>Že ur</th><th>Že ur<br>potrjeno</th><th>Še ur</th><th>Še ur<br>potrjeno</th><th>Še dopusta</th><th>Potrebnih<br />suplenc</th><th>Potrebnih<br />ostalih ur</th></tr>";

            $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
            $Indx=1;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
	            $Ucitelji[$Indx]=$R["IdUcitelj"];
	            $Indx=$Indx+1;
            }
            $StUciteljev=$Indx-1;

            //%1\$.2f
            for ($indx=1;$indx <= $StUciteljev;$indx++){
	            $oUcitelj = new RUcitelj;
	            $oUcitelj->PreberiSe($Ucitelji[$indx],$VLetoPregled,$VLeto);
	            $oUcitelj->IzracunPrisotnosti($VLetoPregled);
	            $MesUre=$oUcitelj->getMesecneUre();
	            echo "<tr><td><a href='IzpisUcitelja.php?idUcitelj=".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."</a></td><td align=center>".round($oUcitelj->getProcZapLetno($VLetoPregled),1)."</td><td>".$VLeto."</td>";	//'ime, % zaposl, leto
	            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
		            echo str_replace(".",",",sprintf("<td align='right'>%1\$.2f</td>",round($MesUre[$Indx0][2],2)));	//'mesečne ure
	            }
	            echo "<td align='center'>(".$oUcitelj->getObveza().") ".round($oUcitelj->getDoprinos(),1)."</td>";

                //pogleda procent zaposljenosti za tekoče leto (po pogodbah)
                $ProcZaposl=$oUcitelj->getProcZapLetno($VLetoPregled);
                
                //razlika med Koriščenimi dnevi in obvezo
                $VKorUre=$oUcitelj->getDopust()+$oUcitelj->getDopustStari()+$oUcitelj->getCountDayPos(0,5) - $oUcitelj->getObveza();
                if ($oUcitelj->getCountDayPos(0,5) > 0){
                    if ($oUcitelj->getDoprinos() > 0){
                        $VKorUre=$oUcitelj->getDopust()+$oUcitelj->getDopustStari()+$oUcitelj->getCountDayPos(0,5) - $oUcitelj->getObveza();
                    }else{
                        $VKorUre=$oUcitelj->getCountDayPos(0,5);
                    }
                }else{
                    $VKorUre=0;
                }
                
                if ($ObracunajDu == 1){
                    if ($oUcitelj->getUcenje() == 1) {
                        if ($ProcZaposl < 100){
                            $PreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos() + $VKorUre*8*$ProcZaposl/100;
                            $PotrjenoPreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos() + $VKorUre*8*$ProcZaposl/100;
                        }else{
                            $PreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos() + $VKorUre*8;
                            $PotrjenoPreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos() + $VKorUre*8;
                        }
                    }else{
                        $PreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos();
                        $PotrjenoPreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos();
                    }
                }else{
                    $PreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos();
                    $PotrjenoPreseganjeObveze = $oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos();
                }
	            
	            echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($oUcitelj->getRealiziranDoprinos(),2)));	//'?e ur
	            echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($oUcitelj->getPotrjenRealiziranDoprinos(),2)));	//'?e ur potrjeno
                /*
	            if ($oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos() <= 0 ){	//'?e ur
		            echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos(),2)));
	            }else{
		            echo str_replace(".",",",sprintf("<td align='right'><font color='red'><b>%1\$.2f</b></font></td>",round($oUcitelj->getDoprinos()-$oUcitelj->getRealiziranDoprinos(),2)));
	            }
	            if ($oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos() <= 0 ){	//'?e ur potrjeno
		            echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos(),2)));
	            }else{
		            echo str_replace(".",",",sprintf("<td align='right'><font color='red'><b>%1\$.2f</b></font></td>",round($oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos(),2)));
	            }
                */
                if ($PreseganjeObveze <= 0 ){    //'še ur
                    echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($PreseganjeObveze,2)));
                }else{
                    echo str_replace(".",",",sprintf("<td align='right'><font color='red'><b>%1\$.2f</b></font></td>",round($PreseganjeObveze,2)));
                }
                if ($PotrjenoPreseganjeObveze <= 0 ){    //'še ur potrjeno
                    echo str_replace(".",",",sprintf("<td align='right'><b>%1\$.2f</b></td>",round($PotrjenoPreseganjeObveze,2)));
                }else{
                    echo str_replace(".",",",sprintf("<td align='right'><font color='red'><b>%1\$.2f</b></font></td>",round($PotrjenoPreseganjeObveze,2)));
                }
                
	            $SumaDoprinosov=$SumaDoprinosov+$oUcitelj->getRealiziranDoprinos();
	            $SumaObveznosti=$SumaObveznosti+$oUcitelj->getObveza()-$oUcitelj->getRealiziranDoprinos();
	            $SumaDoprinosovPotrjeno=$SumaDoprinosovPotrjeno+$oUcitelj->getPotrjenRealiziranDoprinos();
	            $SumaObveznostiPotrjeno=$SumaObveznostiPotrjeno+$oUcitelj->getObveza()-$oUcitelj->getPotrjenRealiziranDoprinos();
	            echo "<td align='center'><b>".$oUcitelj->getPreostaliDopust()."</b></td>";	//'?e dopusta
                
                //potrebne suplence
                if ($oUcitelj->getObveza() > 0){
                    echo str_replace(".",",",sprintf("<td align='right'>%1\$.2f</td>",round((($oUcitelj->getObveza()-$oUcitelj->getDopust())*4.4),2)));
                    $SumaSuplenc += (($oUcitelj->getObveza()-$oUcitelj->getDopust())*4.4);
                    echo str_replace(".",",",sprintf("<td align='right'>%1\$.2f</td>",(round($oUcitelj->getDoprinos(),1)-round((($oUcitelj->getObveza()-$oUcitelj->getDopust())*4.4),2))));
                    $SumaOstalo += (round($oUcitelj->getDoprinos(),1)-($oUcitelj->getObveza()-$oUcitelj->getDopust())*4.4);
                }else{
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                }
	            echo "</tr>";

	            echo "<input name='ime_".$indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'>";
	            echo "<input name='SeUr_".$indx.str_replace(",",".",sprintf("' type='hidden' value='%1\$.2f'>",round(($oUcitelj->getDoprinos()-$oUcitelj->getPotrjenRealiziranDoprinos()),2)));
	            echo "<input name='dop_".$indx."' type='hidden' value='".$oUcitelj->getPreostaliDopust()."'>";
            }

            echo "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
            echo "<td align=right>". str_replace(".",",",round($SumaDoprinosov,2))."</td>";
            echo "<td align=right>". str_replace(".",",",round($SumaDoprinosovPotrjeno,2))."</td>";
            echo "<td align=right>". str_replace(".",",",round($SumaObveznosti,2))."</td>";
            echo "<td align=right>". str_replace(".",",",round($SumaObveznostiPotrjeno,2))."</td>";
            echo "<td></td>";
            echo str_replace(".",",",sprintf("<td align=right>%1\$.2f</td>",round($SumaSuplenc,2)));
            echo str_replace(".",",",sprintf("<td align=right>%1\$.2f</td>",round($SumaOstalo,2)));
            echo "</tr>";
            /*
            echo "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
            echo "<td align=right>".round($SumaDoprinosov/($SumaDoprinosov+$SumaObveznosti+0.01),1)."</td>";
            echo "<td align=right>".round($SumaDoprinosovPotrjeno/($SumaDoprinosovPotrjeno+$SumaObveznostiPotrjeno+0.01),1)."</td>";
            echo "<td align=right>".round($SumaObveznosti/($SumaDoprinosov+$SumaObveznosti+0.01),1)."</td>";
            echo "<td align=right>".round($SumaObveznostiPotrjeno/($SumaDoprinosovPotrjeno+$SumaObveznostiPotrjeno+0.01),1)."</td>";
            echo "<td></td></tr>";
            */
            echo "</table><br />";

            echo "<input name='leto' type='hidden' value='".$VLeto."'>";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<input name='StUciteljev' type='hidden' value='".$StUciteljev."'>";
            echo "Če želite prenesti skupni doprinos in dopuste v naslednje leto, kliknite na spodnji gumb.<br />";
            echo "<input name='submit' type='submit' value='Prenos ur v leto ".($VLeto+1)."'><br />";
            echo "<input name='submit' type='submit' value='Prenos preostalih dni dopusta v leto ".($VLeto+1)."'><br />";
            echo "<input name='submit' type='submit' value='Briši star dopust v letu ".$VLeto."'><br />";
            echo "</form><br /><br />";

            $EndTime=new DateTime("now");
            $interval=$StartTime->diff($EndTime);
            echo "Porabljen čas ".$interval->format('%i:%S')." <br />";
    }
}
?>
<a href="prijava.php">Nazaj na glavni meni</a><br>
<a href="pravilnik.htm">Pravilnik</a><br>

</body>
</html>
