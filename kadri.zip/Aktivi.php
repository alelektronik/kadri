<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Aktivi
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosAktivi",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}
switch ($Vid){
    case "2":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

function Vsebuje($a,$s){
    $x=explode(",",$s);
    return (in_array($a,$x));
}

echo "<a href='Aktivi.php?solskoleto=".($VLeto-1)."&id=".$Vid."'>".($VLeto-1)."/".$VLeto."</a> ".$VLeto."/".($VLeto+1)." <a href='Aktivi.php?solskoleto=".($VLeto+1)."&id=".$Vid."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";

switch ($Vid){
	case "1";
		echo "<form accept-charset='utf-8' name='aktivi' method=post action='Aktivi.php'>";
		
		$SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		$result = mysqli_query($link,$SQL);
		
		$indx=1;
		while ($R = mysqli_fetch_array($result)){
			$Ucitelji[$indx][0]=$R["IdUcitelj"];
			$Ucitelji[$indx][1]=$R["Priimek"]." ".$R["Ime"];
			$indx=$indx+1;
		}
		$Ucitelji[0][0]=0;
		$Ucitelji[0][1]="Ni izbran";
		$StUciteljev=$indx-1;
		
		echo "<table border=1 cellspacing=0>";
		echo "<tr><th>Aktiv</th><th>Vodja aktiva</th></tr>";
		
		$SQL = "SELECT TabAktiv.*,TabVodjeAktivov.* FROM ";
		$SQL = $SQL . "TabAktiv LEFT JOIN TabVodjeAktivov ON TabAktiv.id=TabVodjeAktivov.idAktiv ";
		$SQL = $SQL . "WHERE TabVodjeAktivov.leto=".$VLeto." ";
		$SQL = $SQL . "ORDER BY TabAktiv.orderlevel";
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$TekoceLeto=true;
		}else{
			$TekoceLeto=false;
		}

		if ($TekoceLeto){
			$SQL = "SELECT *,TabAktiv.id AS aid FROM ";
			$SQL = $SQL . "TabAktiv LEFT JOIN TabVodjeAktivov ON TabAktiv.id=TabVodjeAktivov.idAktiv ";
			$SQL = $SQL . "WHERE TabVodjeAktivov.leto=".$VLeto." ";
			$SQL = $SQL . "ORDER BY TabAktiv.orderlevel";
			$result = mysqli_query($link,$SQL);
		}else{
			$SQL = "SELECT TabAktiv.* FROM TabAktiv ";
			$SQL = $SQL . "ORDER BY TabAktiv.orderlevel";
			$result = mysqli_query($link,$SQL);
		}
		
		$i1=1;
		if ($TekoceLeto){	
			while ($R = mysqli_fetch_array($result)){
				echo "<tr><td><input name='aktiv_".$i1."' type='hidden' value='".$R["aid"]."'>".$R["Aktiv"]."</td>";
				echo "<td><select name='ucitelj_".$i1."'>";
				for ($indx=0;$indx <= $StUciteljev;$indx++){
					if ($R["idUcitelj"]==$Ucitelji[$indx][0]){
						echo "<option value='".$Ucitelji[$indx][0]."' selected>".$Ucitelji[$indx][1]."</option>";
					}else{
						echo "<option value='".$Ucitelji[$indx][0]."'>".$Ucitelji[$indx][1]."</option>";
					}
				}
				echo "</select></td></tr>";
				$i1=$i1+1;
			}
		}else{
			while ($R = mysqli_fetch_array($result)){
				echo "<tr><td><input name='aktiv_".$i1."' type='hidden' value='".$R["id"]."'>".$R["Aktiv"]."</td>";
				echo "<td><select name='ucitelj_".$i1."'>";
				for ($indx=0;$indx <= $StUciteljev;$indx++){
					if ($indx==0){
						echo "<option value='".$Ucitelji[0][0]."' selected>".$Ucitelji[0][1]."</option>";
					}else{
						echo "<option value='".$Ucitelji[$indx][0]."'>".$Ucitelji[$indx][1]."</option>";
					}
				}
				echo "</select></td></tr>";
				$i1=$i1+1;
			}
		}
		echo "</table><br />";
		echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
		echo "<input name='StAktivov' type='hidden' value='".($i1-1)."'>";
		echo "<input name='id' type='hidden' value='2'></td>";
		echo "<td><input name='submit' type='submit' value='Pošlji'>";
		echo "</form>";
        break;
	case "2":
		for ($indx=1;$indx <=$_POST["StAktivov"];$indx++){
				$SQL = "SELECT * FROM TabVodjeAktivov WHERE leto=".$_POST["solskoleto"]." AND idAktiv=".$_POST["aktiv_".$indx]; //'." AND idUcitelj=".request("ucitelj_".$indx);
				$result = mysqli_query($link,$SQL);
				
				if ($R = mysqli_fetch_array($result)){
					$SQL = "UPDATE TabVodjeAktivov SET leto=".$_POST["solskoleto"].",idAktiv=".$_POST["aktiv_".$indx].",idUcitelj=".$_POST["ucitelj_".$indx]." WHERE id=".$R["id"];
				}else{
					$SQL = "INSERT INTO TabVodjeAktivov (leto,idAktiv,idUcitelj) VALUES (".$_POST["solskoleto"].",".$_POST["aktiv_".$indx].",".$_POST["ucitelj_".$indx].")";
				}
				$result = mysqli_query($link,$SQL);
		}
	    header("Location: Aktivi.php?solskoleto=$VLeto");
        break;
	default:
		echo "<h2>Aktivi učiteljev v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
		echo "<table border=1 cellspacing=0>";
		echo "<tr><th>Leto</th><th>Aktiv</th><th>Vodja</th></tr>";

		$SQL = "SELECT * FROM ";
		$SQL = $SQL . "(TabVodjeAktivov INNER JOIN tabucitelji ON TabVodjeAktivov.idUcitelj=tabucitelji.idUcitelj) ";
		$SQL = $SQL . "INNER JOIN TabAktiv ON TabVodjeAktivov.idAktiv=TabAktiv.id ";
		$SQL = $SQL . "WHERE TabVodjeAktivov.leto=".$VLeto;
		$SQL = $SQL . " ORDER BY TabAktiv.orderlevel";
		$result = mysqli_query($link,$SQL);
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
			echo "<td>".$R["Aktiv"]."</td>";
			echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			echo "</tr>";
		}
		echo "</table><br />";
}


if (CheckDostop("VnosSist",$VUporabnik) ) {
	echo "<a href='Aktivi.php?id=1&solskoleto=".$VLeto."'>Vnos vodij aktivov</a><br />";
}

?>

</body>
</html>
