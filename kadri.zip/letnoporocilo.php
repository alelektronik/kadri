<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Realizacija
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$ImeMes=array("jan","feb","mar","apr","maj","jun","jul","avg","sep","okt","nov","dec");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("LetnPor",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
function ToStopnja($x){
    switch ($x){
        case 0:
            return "Šolsko";
        case 1:
            return "Občinsko";
        case 2:
            return "Medobčinsko";
        case 3:
            return "Področno";
        case 4:
            return "Regijsko";
        case 5:
            return "Mestno";
        case 7:
            return "Državno četrfinale";
        case 8:
            return "Državno polfinale";
        case 9:
            return "Državno finale";
        case 10:
            return "Državno";
    }
}
function Povprecje($idUcenec,$razred){
    global $link,$VLeto;
    
    if ($razred < 4){
        $Povprecje=5;
    }else{
        $SQL = "SELECT ocenakoncna FROM tabocene INNER JOIN TabPredmeti ON tabocene.idPredmet=TabPredmeti.id WHERE idUcenec=".$idUcenec." AND TabPredmeti.prioriteta=0 AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        
        $i=0;
        $vsota=0;
        $nez=false;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                $vsota=$vsota+intval($R["ocenakoncna"]);
                if ($R["ocenakoncna"]==1){ 
                    $nez=true;
                }
                $i=$i+1;
            }
        }
        if ($i > 0){
            if ($nez){
                $Povprecje=1;
            }else{
                $Povprecje=($vsota/$i);
            }
        }else{
            $Povprecje=0;
        }
    }
    return $Povprecje;
}

function displayverticalgraph($strtitle,$strytitle,$strxtitle,$avalues,$alabels){
    /*
    '************************************************************************
    '           user customizeable values for different formats
    '            of the graph
    '             FREEWARE!!
    '    Just tell me if you are going to use it - info@cool.co.za
    '************************************************************************
    */
    $GRAPH_HEIGHT     = 300; //              'set up the graph height
    $GRAPH_WIDTH     = 400; //           'set up the graph width
    $GRAPH_SPACING     = 1;    
    $GRAPH_BORDER     = 0; //             'if you would like to see the borders to align things differently    
    $GRAPH_BARS     = 10; //             'loops through different colored bars e.g. 2 bars = gold,blue,gold,blue
    $USELOWVALUE     = FALSE; //         'this uses the low value of the array as the value of origin (default = 0)
    $SHOWLABELS     = TRUE; //          'set this to toggle whether or not the labels are shown
    $L_LABEL_SEPARATOR = " "; //            ' |Label
    $R_LABEL_SEPARATOR = " "; //            ' Label|
    $LABELSIZE     = -4; //            
    $GRAPHBORDERSIZE     = 1; //
    $INTIMGBORDER     = 1; //               'border around the bars
    $ALT_TEXT        = 3; //            'Changes the format of the alternate text of the bar image
    /*                        '1 = Labels ,2 = Values , 3 = Labels + Values , 4 = Percent

    '************************************************************************
    'array of different bars to loop through
    'you can change the order of these 
    'Count = 10 
    '"dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple"
    'cut and paste from here and insert into the agraph_bars array below Make sure the 
    'number specified in the const GRAPH_BARS is the same as or less than that in the array 
    ' 7 graph_bars <= 7 elements in array
    '************************************************************************
    */
    $agraph_bars = array("dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple");

    $intmax = 0;

    $ZgMeja=0;
    for ($i=0;$i < count($alabels);$i++){
        if (strlen($alabels[$i]) > 0){
            $ZgMeja=$ZgMeja+1;
        }
    }
    $ZgMeja=$ZgMeja-1;
    //'find the maximum value of the values array
    for ($i = 0;$i <= $ZgMeja;$i++){
        if ($intmax < $avalues[$i]){
            $intmax = $avalues[$i]; 
        }
    }
    if ($USELOWVALUE){
        $intmin = $avalues[0];
        for ($i = 0;$i <= $ZgMeja;$i++){
            if  ($intmin > $avalues[$i]){
                $intmin = $avalues[$i]; 
            }
        }
    }
    //'establish the graph multiplier
    if ($intmax==0) $intmax=1;
    $graphmultiplier = round($GRAPH_HEIGHT-100/$intmax);

    if ($ZgMeja == -1){
        $imgwidth=16;
    }else{
        $imgwidth = round(300/($ZgMeja+1));
    }
    if ($imgwidth > 16) $imgwidth = 16;

    echo "<table class='graf' border ='".$GRAPH_BORDER."' width='".$GRAPH_WIDTH."' height='".$GRAPH_HEIGHT."'>";
        echo "<tr class='graf'>";
            echo "<td class='graf' rowspan='3' valign='middle'>".$strytitle."</td>";
            echo "<td class='graf' colspan='".($ZgMeja+2)."' height='50' align='center'><h4>".$strtitle."</h4></td>";
        echo "</tr>";
        $count = 0;
        echo "<tr class='graf'>";
            echo "<td class='graf'>";
                echo "<table class='graf' border='".$GRAPH_BORDER."' cellpadding = '0' cellspacing = '".$GRAPH_SPACING."'>";
                    echo "<tr class='graf'>";
                        echo "<TD class='graf' height='100%'>";
                            echo "<table class='graf' border='".$GRAPH_BORDER."' height='100%'>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='top' align='right'>".number_format($intmax,2)."</td>";
                                echo "</tr>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='bottom' align='right'>";
                                     
                                    if ($USELOWVALUE){
                                        echo number_format($intmin,2);
                                    }else{
                                        echo "0";
                                    }
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                        echo "</td>";
                        echo "<td class='graf' valign='bottom' align='right'><img src='leftbord.gif' width='2' height='".($graphmultiplier+8)."'></td>";
                        
                    //    echo "<td class='graf' ><table class='graf' border=".$GRAPH_BORDER." height='100%'>";
                    //    echo "<tr>";
                                     
                        //             '*******************MAIN PART OF THE CHART************************************
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            $strgraph = $agraph_bars[$count];
                            if ($ALT_TEXT == 1){
                                $stralt = $alabels[$i];
                            }else{
                                if ($ALT_TEXT == 2){
                                    $stralt = $avalues[$i];
                                }else{
                                    if ($ALT_TEXT == 3){
                                        $stralt = $alabels[$i] ." - "  .$avalues[$i];
                                    }else{
                                        if ($ALT_TEXT == 4){
                                            $stralt = round($avalues[$i] /$intmax  *100,2) ."%";
                                        }
                                    }
                                }
                            }

                            if ($USELOWVALUE){
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round(($avalues[$i]-$intmin)/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            }else{
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round($avalues[$i]/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            } 
                                
                            if ($count == $GRAPH_BARS-1){
                                $count = 0;
                            }else{
                                $count = $count + 1;
                            }        
                        }
                    //    echo "</tr></table></td>";          
                        //            'write out the border at the bottom of the bars also leave a blank cell for spacing on the right
                        echo "<td class='graf' width='50'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr class='graf'>";
                        echo "<td class='graf' width='8'>&nbsp;</td>";
                        echo "<td class='graf'>&nbsp;</td>";
                        echo "<td class='graf' colspan='" .($ZgMeja+1) ."' valign='top'>"."<img src='botbord.gif' width='100%' height='2'></td>";
                    echo "</tr>";
                    if ($SHOWLABELS){
                        echo "<tr class='graf'>";
                            echo "<th class='graf' width='8' height='1'>&nbsp;</th>";
                            echo "<th class='graf'>&nbsp;</th>";
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            echo "<th class='graf' valign='top' align='center' width='".$imgwidth."'><font size='".$LABELSIZE."'>".$L_LABEL_SEPARATOR.$alabels[$i].$R_LABEL_SEPARATOR."</font></th>";
                        }
                        echo "</tr>";
                    }
                    echo "<tr class='graf'><td class='graf' colspan='".($ZgMeja+3)."' height='50' align='center'>".$strxtitle."</td>";
                    echo "</tr>";
                echo "</table>";
            echo "</td>";
        echo "</tr>";
        echo "<tr class='graf'>";
            echo "<td class='graf'></td>";
        echo"</tr>";
    echo "</table>";
}

//'-------------------------------------------realizacija - zacetek --------------------------------
$SQL = "SELECT id FROM tabpredmeti ORDER BY id DESC LIMIT 0,1";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $NPredmetov=$R["id"];
}else{
    $NPredmetov=0;
}

$CelotenPlanUr=0;
$CelotnaIzvedbaUr=0;
for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
    $CelotnaRealIzbirni[$Indx]=0;
}
$SQL = "SELECT id,solakratko FROM tabsola";
$result = mysqli_query($link,$SQL);
$i=1;
$sole=array();
while ($R = mysqli_fetch_array($result)){
    $sole[$i][0]=$R["id"];
    $sole[$i][1]=$R["solakratko"];
    $i += 1;
}
$StSol=$i-1;
for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
    echo "<h2>".$sole[$IndxSola][1]."</h2>";

    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 AND idsola=".$sole[$IndxSola][0]." ORDER BY razred,oznaka";
    $result = mysqli_query($link,$SQL);

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $Razredi[$Indx][0] = $R["razred"];
        $Razredi[$Indx][1] = $R["oznaka"];
        $Razredi[$Indx][2] = $R["osemdevet"];
        $Razredi[$Indx][3] = $R["id"];
        $Indx=$Indx+1;
    }
    $StRazredov=$Indx;

    $UcneUreVse[0]=0;
    $UcneUreVse[1]=0;
    $UcneUreVse[2]=0;
    $UcneUreVse[3]=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $UcneUreRedni[$Indx][0]=0;
        $UcneUreIzbirni[$Indx][0]=0;
        $UcneUreRedni[$Indx][1]=0;
        $UcneUreIzbirni[$Indx][1]=0;

        $UcneUreNeobvezni[$Indx][0]=0;
        $UcneUreNeobvezni[$Indx][1]=0;

        $UcneUreRedniP[$Indx][0]=0;
        $UcneUreIzbirniP[$Indx][0]=0;
        $UcneUreRedniP[$Indx][1]=0;
        $UcneUreIzbirniP[$Indx][1]=0;

        $UcneUreNeobvezniP[$Indx][0]=0;
        $UcneUreNeobvezniP[$Indx][1]=0;
    }

    for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
        $VRazred=$Razredi[$IndxRazred][3];
        $VRazred1=$Razredi[$IndxRazred][0];
        $VParalelka=$Razredi[$IndxRazred][1];
        $VDevetletka=$Razredi[$IndxRazred][2];
        
        $SQL = "SELECT DISTINCT tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,tabucenje.Predmet,tabucenje.razred,tabucenje.paralelka,tabucenje.leto FROM ";
        $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE ((tabrazdat.id=".$VRazred.") OR ((tabrazdat.razred=".($VRazred1+(intval($sole[$IndxSola][0])-1)*10).") AND (paralelka='')) AND Prioriteta IN (0,1)) ";
        $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
        $result = mysqli_query($link,$SQL);

        $UcneUre[0]=0;
        $UcneUre[1]=0;
        $UcneUre[2]=0;
        $UcneUre[3]=0;

        for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
            $UcneUrePredmeti[$Indx][0]=0;
            $UcneUrePredmeti[$Indx][1]=0;
            $UcneUrePredmeti[$Indx][2]=0;
            $UcneUrePredmeti[$Indx][3]=0;
            $UcneUrePredmeti[$Indx][4]=0;
            $UcneUrePredmeti[$Indx][5]=0;
            $UcneUrePredmeti[$Indx][6]=0;
            $UcneUrePredmeti[$Indx][7]="";
            $UcneUrePredmeti[$Indx][8]=0;
            $UcneUrePredmeti[$Indx][9]=0;
            $Predmeti[$Indx][0]=0;
            $Predmeti[$Indx][1]=0;
        }

        $StPredmetov=0;

        while ($R = mysqli_fetch_array($result)){
            $Predmeti[$StPredmetov][0]=$R["Predmet"];
            $Predmeti[$StPredmetov][1]=$R["Oznaka"];
            $StPredmetov=$StPredmetov+1;
        }
        /*
        //'Realizacija ur
        $SQL = "SELECT TabRealizacija.*,tabpredmeti.*,tabucitelji.*,TabRealizacija.id AS rid FROM ";
        $SQL = $SQL . "((TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON TabRealizacija.Referenca=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "WHERE TabRealizacija.leto=".$VLeto." AND tabrealizacija.idrazred=".$VRazred." OR (TabRealizacija.razred=".($VRazred1+(intval($sole[$IndxSola][0])-1)*10)." AND paralelka='') AND tabpredmeti.prioriteta IN (0,1) ORDER BY VrstniRed";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
            $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
            switch ($R["Prioriteta"]){
            case 0:
                $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"];
                $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"];
                $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"];
                $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                break;
            case 1:
                if ($UcneUreIzbirni[$R["Predmet"]][1] == 0 ){
                    $UcneUreIzbirni[$R["Predmet"]][0]=$UcneUreIzbirni[$R["Predmet"]][0]+$R["Plan"];
                    $UcneUreIzbirni[$R["Predmet"]][1]=$UcneUreIzbirni[$R["Predmet"]][1]+$R["Realizacija"];
                }
                if ($UcneUreIzbirniP[$R["Predmet"]][1] == 0 ){
                    $UcneUreIzbirniP[$R["Predmet"]][0]=$UcneUreIzbirniP[$R["Predmet"]][0]+$R["PlanPol"];
                    $UcneUreIzbirniP[$R["Predmet"]][1]=$UcneUreIzbirniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                }
            }
            $UcneUre[2]=$UcneUre[2]+$R["Plan"];
            $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
            $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
            $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
            $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
            $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
            $UcneUrePredmeti[$Indx][4]=$R["Plan"];
            $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
            $UcneUrePredmeti[$Indx][6]=$R["Prioriteta"];
            $UcneUrePredmeti[$Indx][7]=$R["Priimek"]." ".$R["Ime"];
            $UcneUrePredmeti[$Indx][8]=$R["rid"];
            $UcneUrePredmeti[$Indx][9]=$R["Ucenje"];
            $Indx=$Indx+1;
        }
        $StPredmetovUcneUre=$Indx;
        */
        
        //'Realizacija ur
        $SQL = "SELECT TabRealizacija.*,tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.kodamss,tabpredmeti.opismss,tabucitelji.priimek,tabucitelji.ime,TabRealizacija.id AS rid,tabucenje.zdruzeno,tabucenje.realizirano FROM ";
        $SQL = $SQL . "((TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON TabRealizacija.Referenca=tabucitelji.idUcitelj) ";
        $SQL .= "INNER JOIN tabucenje ON tabrealizacija.ucenje=tabucenje.id ";
        $SQL = $SQL . "WHERE TabRealizacija.leto=".$VLeto." AND TabRealizacija.razred=".$VRazred1." AND (tabrealizacija.paralelka='".$VParalelka."' OR tabrealizacija.paralelka='".strtoupper($VParalelka)."' OR tabrealizacija.paralelka='".strtolower($VParalelka)."' OR tabrealizacija.paralelka='') AND tabpredmeti.prioriteta IN (0,1) ORDER BY tabpredmeti.VrstniRed,tabucenje.zdruzeno,tabucenje.realizirano";
        //$SQL = $SQL . "WHERE TabRealizacija.leto=".$VLeto." AND tabrealizacija.idrazred=".$VRazred." OR (TabRealizacija.razred=".($VRazred1+(intval($sole[$IndxSola][0])-1)*10)." AND paralelka='') AND tabpredmeti.prioriteta IN (0,1) ORDER BY VrstniRed";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
            $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
            switch ($R["prioriteta"]){
            case 0:
                if ($R["zdruzeno"] == "1"){
                    $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"]/2;
                    $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"]/2;
                }else{
                    $UcneUreRedni[$R["Predmet"]][0]=$UcneUreRedni[$R["Predmet"]][0]+$R["Plan"];
                    $UcneUreRedni[$R["Predmet"]][1]=$UcneUreRedni[$R["Predmet"]][1]+$R["Realizacija"];
                }
                if ($R["zdruzeno"] == "1"){
                    $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"]/2;
                    $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"]/2;
                }else{
                    $UcneUreRedniP[$R["Predmet"]][0]=$UcneUreRedniP[$R["Predmet"]][0]+$R["PlanPol"];
                    $UcneUreRedniP[$R["Predmet"]][1]=$UcneUreRedniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                }
                break;
            case 1:
                if (strpos($R["opismss"],"/ni/") > 0){ //neobvezni izbirni
                    if ($R["kodamss"]=="N1A"){ //v primeru izbirne angleščine v 1. razredu, šteje vse
                        $UcneUreNeobvezni[$R["Predmet"]][0]=$UcneUreNeobvezni[$R["Predmet"]][0]+$R["Plan"];
                        $UcneUreNeobvezni[$R["Predmet"]][1]=$UcneUreNeobvezni[$R["Predmet"]][1]+$R["Realizacija"];
                        $UcneUreNeobvezniP[$R["Predmet"]][0]=$UcneUreNeobvezniP[$R["Predmet"]][0]+$R["PlanPol"];
                        $UcneUreNeobvezniP[$R["Predmet"]][1]=$UcneUreNeobvezniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                    }else{
                        if ($UcneUreNeobvezni[$R["Predmet"]][1] == 0 ){    //izbirne ure šteje samo enkrat
                            $UcneUreNeobvezni[$R["Predmet"]][0]=$UcneUreNeobvezni[$R["Predmet"]][0]+$R["Plan"];
                            $UcneUreNeobvezni[$R["Predmet"]][1]=$UcneUreNeobvezni[$R["Predmet"]][1]+$R["Realizacija"];
                        }
                        if ($UcneUreNeobvezniP[$R["Predmet"]][1] == 0 ){   //izbirne ure šteje samo enkrat
                            $UcneUreNeobvezniP[$R["Predmet"]][0]=$UcneUreNeobvezniP[$R["Predmet"]][0]+$R["PlanPol"];
                            $UcneUreNeobvezniP[$R["Predmet"]][1]=$UcneUreNeobvezniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                        }
                    }
                }else{ //obvezni izbirni
                    if ($UcneUreIzbirni[$R["Predmet"]][1] == 0 ){    //izbirne ure šteje samo enkrat
                        $UcneUreIzbirni[$R["Predmet"]][0]=$UcneUreIzbirni[$R["Predmet"]][0]+$R["Plan"];
                        $UcneUreIzbirni[$R["Predmet"]][1]=$UcneUreIzbirni[$R["Predmet"]][1]+$R["Realizacija"];
                    }
                    if ($UcneUreIzbirniP[$R["Predmet"]][1] == 0 ){   //izbirne ure šteje samo enkrat
                        $UcneUreIzbirniP[$R["Predmet"]][0]=$UcneUreIzbirniP[$R["Predmet"]][0]+$R["PlanPol"];
                        $UcneUreIzbirniP[$R["Predmet"]][1]=$UcneUreIzbirniP[$R["Predmet"]][1]+$R["RealizacijaPol"];
                    }
                }
            }
            $UcneUre[2]=$UcneUre[2]+$R["Plan"];
            $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
            $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
            $UcneUrePredmeti[$Indx][1]=$R["oznaka"];
            $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
            $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
            $UcneUrePredmeti[$Indx][4]=$R["Plan"];
            $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
            $UcneUrePredmeti[$Indx][6]=$R["prioriteta"];
            $UcneUrePredmeti[$Indx][7]=$R["priimek"]." ".$R["ime"];
            $UcneUrePredmeti[$Indx][8]=$R["rid"];
            $UcneUrePredmeti[$Indx][9]=$R["Ucenje"];
            $Indx=$Indx+1;
        }
        $StPredmetovUcneUre=$Indx;
        
        $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
        $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
        $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
        $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];
    }


    //'------------------------------ 1. polletje
    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++ ){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreRedniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreRedniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur rednih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur rednih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreIzbirniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreIzbirniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreNeobvezniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreNeobvezniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur neobveznih izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur neobveznih izbirnih predmetov (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUrP=0;
    $CelotenPlanUrP=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUrP=$CelotnaIzvedbaUrP+$UcneUreIzbirniP[$Indx][1]+$UcneUreRedniP[$Indx][1];
        $CelotenPlanUrP=$CelotenPlanUrP+$UcneUreIzbirniP[$Indx][0]+$UcneUreRedniP[$Indx][0];
    }
    if ($CelotenPlanUrP > 0 ){
        if ($CelotnaIzvedbaUrP/$CelotenPlanUrP > 0.979 ){
            echo "Celoten plan ur - vse (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur - vse (1. obdobje): <b>".$CelotenPlanUrP."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUrP."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUrP/$CelotenPlanUrP)*100,2)."%</font></b><br />";
        }
    }
    echo "<br />";
    
    //'------------------------------- končno
    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreRedni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreRedni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur rednih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur rednih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreIzbirni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreIzbirni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreNeobvezni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreNeobvezni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur neobveznih izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur neobveznih izbirnih predmetov: <b>".$CelotenPlanUr."</b>, izvedenih ur: <b>".$CelotnaIzvedbaUr."</b>, realizacija: <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }

    $CelotnaIzvedbaUr=0;
    $CelotenPlanUr=0;
    for ($Indx=0;$Indx <= $NPredmetov;$Indx++){
        $CelotnaIzvedbaUr=$CelotnaIzvedbaUr+$UcneUreIzbirni[$Indx][1]+$UcneUreRedni[$Indx][1];
        $CelotenPlanUr=$CelotenPlanUr+$UcneUreIzbirni[$Indx][0]+$UcneUreRedni[$Indx][0];
    }
    if ($CelotenPlanUr > 0 ){
        if ($CelotnaIzvedbaUr/$CelotenPlanUr > 0.979 ){
            echo "Celoten plan ur (vse): <b>".$CelotenPlanUr."</b>, izvedenih ur (vse): <b>".$CelotnaIzvedbaUr."</b>, realizacija (vse): <b><font color=green>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }else{
            echo "Celoten plan ur (vse): <b>".$CelotenPlanUr."</b>, izvedenih ur (vse): <b>".$CelotnaIzvedbaUr."</b>, realizacija (vse): <b><font color=red>".number_format(($CelotnaIzvedbaUr/$CelotenPlanUr)*100,2)."%</font></b><br />";
        }
    }
    //'-------------------------------------------realizacija - konec --------------------------------

    //'--------------------------------------------------------- Pohvale in priznanja - zacetek ---------------------------
    echo "<h2>Pohvale in priznanja v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
    if ($VLeto <= 2008 ){
        $SQL = "SELECT tabvzgukrepi.*,tabopomini.*,tabopomini.idukrep AS oidukrep,,tabucenci.*,tabrazred.* FROM ((tabvzgukrepi INNER JOIN tabopomini ON tabvzgukrepi.IdUkrep=tabopomini.IdUkrep) INNER JOIN tabucenci ON tabvzgukrepi.IdUcenec=tabucenci.IdUcenec) INNER JOIN tabrazred ON tabvzgukrepi.IdUcenec=tabrazred.IdUcenec WHERE tabvzgukrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabopomini.Opis LIKE 'Pohvala%' ORDER BY tabopomini.id";
        $result = mysqli_query($link,$SQL);

        For ($Indx=0;$Indx <= 200;$Indx++){
            $CountPohvala[$Indx]=0;
        }

        while ($R = mysqli_fetch_array($result)){
            $CountPohvala[$R["oidukrep"]]=$CountPohvala[$R["oidukrep"]]+1;
        }

        $CompPohvala="";
        echo "<table border=0>";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($CompPohvala != $R["Opis"] ){
                echo "<tr><th>".$R["Opis"]."</th></tr>";
                $CompPohvala=$R["Opis"];
                if (is_numeric(strpos($R["Opis"],"Bronasto"))){
                    switch ( $CountPohvala[$R["oidukrep"]]){
                        case 1;
                            echo "<tr><td align=center>1 učenec</td></tr>";
                            break;
                        case 2:
                            echo "<tr><td align=center>2 učenca</td></tr>";
                            break;
                        case 3:
                        case 4:
                            echo "<tr><td align=center>".$CountPohvala[$R["oidukrep"]]." učenci</td></tr>";
                            break;
                        default:
                            echo "<tr><td align=center>".$CountPohvala[$R["oidukrep"]]." učencev</td></tr>";
                    }
                }
            }
            if (is_numeric(strpos($R["Opis"],"Zlato"))){
                echo "<tr><td align=center>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
            }else{
                if (is_numeric(strpos($R["Opis"],"Srebrno"))){
                    echo "<tr><td align=center>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                }
            }
        }
        echo "</table><br />";
    }
        
    $SQL = "SELECT DISTINCT tip,krozek FROM tabdrtekm WHERE leto=".$VLeto." ORDER BY tip,krozek";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $CountTekmovanja[$Indx]=$R["krozek"];
        $Indx=$Indx+1;
    }
    $StDrTekm=$Indx-1;

    For ($Indx=0;$Indx <= 200;$Indx++){
        $CountPohvalaDrT[$Indx][1]=0;
        $CountPohvalaDrT[$Indx][2]=0;
        $CountPohvalaDrT[$Indx][3]=0;
    }

    $SQL = "SELECT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.*,tabdrtekm.*,tabsifranttekm.* FROM ((((tabdrtekmclan ";
    $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
    $SQL = $SQL . "INNER JOIN tabdrtekm ON tabdrtekmclan.idTekmovanje=tabdrtekm.id) ";
    $SQL = $SQL . "INNER JOIN tabsifranttekm ON tabdrtekm.tip=tabsifranttekm.idTekmovanja) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]." ";
    $SQL = $SQL . "ORDER BY tabdrtekm.tip,tabdrtekmclan.Tekmovanje,tabdrtekmclan.priznanje,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";

    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        for ($Indx=1;$Indx <= $StDrTekm;$Indx++){
            if ($CountTekmovanja[$Indx]==$R["tekmovanje"] ){
                if (is_numeric(strpos($R["priznanje"],"Zlat")) or (is_numeric(strpos($R["priznanje"],"zlat")))){
                    $CountPohvalaDrT[$Indx][1]=$CountPohvalaDrT[$Indx][1]+1;
                }
                if (is_numeric(strpos($R["priznanje"],"Srebrn")) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                    $CountPohvalaDrT[$Indx][2]=$CountPohvalaDrT[$Indx][2]+1;
                }
                if (is_numeric(strpos($R["priznanje"],"Bronast")) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                    $CountPohvalaDrT[$Indx][3]=$CountPohvalaDrT[$Indx][3]+1;
                }
            }
        }
    }

    $result = mysqli_query($link,$SQL);
    $CompPohvala="";
    $CompDrTekm=0;
    $CompTip=0;
    echo "<table border=0>";
    while ($R = mysqli_fetch_array($result)){
        if ($CompTip != $R["tip"] ){
            echo "</table><br />";
            echo "<h2>".$R["opis"]."</h2>";
            echo "<table border=0>";
            $CompTip=$R["tip"];
        }
        if ($CompPohvala != $R["tekmovanje"]){
            echo "<tr><th>".$R["tekmovanje"]."</th></tr>";
            $CompPohvala=$R["tekmovanje"];
            for ($Indx=1;$Indx <= $StDrTekm;$Indx++){
                if ($CompPohvala == $CountTekmovanja[$Indx]){
                    $CompDrTekm=$Indx;
                }
            }
            if (is_numeric(strpos($R["priznanje"],"Bronast")) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                switch ( $CountPohvalaDrT[$CompDrTekm][3]){
                    case 1:
                        echo "<tr><td align=center>1 učenec - bronasto priznanje</td></tr>";
                        break;
                    case 2:
                        echo "<tr><td align=center>2 učenca - bronasto priznanje</td></tr>";
                        break;
                    case 3:
                    case 4:
                        echo "<tr><td align=center>".$CountPohvalaDrT[$CompDrTekm][3]." učenci - bronasto priznanje</td></tr>";
                        break;
                    default:
                        echo "<tr><td align=center>".$CountPohvalaDrT[$CompDrTekm][3]." učencev - bronasto priznanje</td></tr>";
                }
            }
        }
        if (is_numeric(strpos($R["priznanje"],"Zlat")) or (is_numeric(strpos($R["priznanje"],"zlat")))){
            echo "<tr><td align=center><font color='blue'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]." - zlato priznanje</font></td></tr>";
        }else{
            if (is_numeric(strpos($R["priznanje"],"Srebrn")) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                echo "<tr><td align=center><font color='green'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]." - srebrno priznanje</font></td></tr>";
            }
        }
    }
    echo "</table><br />";
        

    //'--------------------------------------------------------- Pohvale in priznanja - konec ---------------------------

    //'---------------------------------------------------------Tekmovanja v znanju - začetek -------------------------
    echo "<h2>Tekmovanja v znanju v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
    echo "<table border=1 cellspacing=0>";
    echo "<tr>";
    echo "<th>Št.</th>";
    echo "<th>Tekmovanje</th>";
    echo "<th>Mentor</th>";
    echo "<th>Stopnja</th>";
    echo "<th>Kraj</th>";
    echo "<th>Datum</th>";
    echo "<th>Udeležencev</th>";
    //echo "<th>Briši</th>";
    //echo "<th>Popravi</th>";
    echo "</tr>";

    $SQL = "SELECT tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabdrtekm.leto, tabdrtekmclan.idTekmovanje,tabdrtekmclan.datum,tabdrtekmclan.kraj, Count(tabdrtekmclan.idTekmovanje) AS countofkrozek,tabrazred.leto,tabrazdat.idsola ";
    $SQL = $SQL."FROM ((tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.idTekmovanje = tabdrtekm.id) " ;
    $SQL .= "INNER JOIN tabrazred ON tabrazred.iducenec=tabdrtekmclan.iducenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL .= "GROUP BY tabdrtekm.leto, tabdrtekmclan.idTekmovanje, tabdrtekmclan.datum,tabdrtekmclan.kraj,tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabrazred.leto,tabrazdat.idsola ";
    $SQL .= " HAVING (tabdrtekm.leto=".$VLeto.") ";
    $SQL .=" AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL .= " ORDER BY tabdrtekm.krozek";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    $VCount[0][0]=0;
    while ($R = mysqli_fetch_array($result)){
        $VTekmovanje[$Indx]=$R["id"];
        $VCount[0][0]=$VCount[0][0]+$R["countofkrozek"];
        echo "<tr>";
        echo "<td>".$Indx."</td>";
        echo "<td><a href='tekmovanjakrozki.php?id=110&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
        echo "<td>".$R["mentor"]."</td>";
        echo "<td>".ToStopnja($R["stopnja"])."</td>";
        echo "<td>".$R["kraj"]."</td>";
        echo "<td>".$R["datum"]."</td>";
        echo "<td align=center>".$R["countofkrozek"]."</td>";
        //echo "<td><a href='tekmovanjakrozki.php?id=111&idtekm=".$R["id"]."'>Briši</a></td>";
        //echo "<td><a href='tekmovanjakrozki.php?id=102&idtekm=".$R["id"]."'>Popravi</a></td>";
        echo "</tr>";
        $Indx=$Indx+1;
    }
    $StTekmovanj=$Indx-1;
            for ($i=0;$i <= $StTekmovanj;$i++){
            for ($j=0;$j <= 7;$j++){
                $VCount[$i][$j]=0;
            }
        }
        if ($VecSol > 0){
            echo "<tr><td></td><td>Skupaj</td><td></td><td></td><td></td><td></td><td></td><td align=center>".$VCount[0][0]."</td></tr>";
        }else{
            echo "<tr><td></td><td>Skupaj</td><td></td><td></td><td></td><td></td><td align=center>".$VCount[0][0]."</td></tr>";
        }
        echo "</table><br />";

        $SQL = "SELECT DISTINCT tabdrtekm.leto,tabdrtekmclan.leto,tabdrtekm.krozek,Count(tabdrtekmclan.tekmovanje) AS countofkrozek FROM ";
        $SQL = $SQL . "tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.Tekmovanje = tabdrtekm.krozek GROUP BY tabdrtekm.leto,tabdrtekm.krozek,tabdrtekmclan.leto HAVING tabdrtekm.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto;
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        $VCount[0][0]=0;
        while ($R = mysqli_fetch_array($result)){
            $VTekmovanje[$Indx]=$R["krozek"];
            $VCount[0][0]=$VCount[0][0]+$R["countofkrozek"];
            $Indx=$Indx+1;
        }
        $StTekmovanj=$Indx-1;

        $SQL = "SELECT tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabdrtekm.leto, tabdrtekmclan.idTekmovanje,tabdrtekmclan.datum,tabdrtekmclan.kraj, Count(tabdrtekmclan.idTekmovanje) AS countofkrozek " ;
        $SQL = $SQL."FROM tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.idTekmovanje = tabdrtekm.id " ;
        $SQL = $SQL."WHERE (((tabdrtekm.leto)=".$VLeto.")) ";
        $SQL = $SQL."GROUP BY tabdrtekm.leto, tabdrtekmclan.idTekmovanje, tabdrtekmclan.datum,tabdrtekmclan.kraj,tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor ";
        $SQL = $SQL." ORDER BY tabdrtekm.krozek";
        $result = mysqli_query($link,$SQL);

        for ($Indx=1;$Indx <= $StTekmovanj;$Indx++){
            $SQL = "SELECT * FROM tabdrtekmclan WHERE Tekmovanje='".$VTekmovanje[$Indx]."' AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            
            while ($R = mysqli_fetch_array($result)){
                $VCount[$Indx][0]=$R["tekmovanje"];
                if ((is_numeric(strpos($R["priznanje"],"Bronast"))) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                    $VCount[$Indx][1]=$VCount[$Indx][1]+1;
                }
                if ((is_numeric(strpos($R["priznanje"],"Srebrn"))) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                    $VCount[$Indx][2]=$VCount[$Indx][2]+1;
                }
                if ((is_numeric(strpos($R["priznanje"],"Zlat"))) or (is_numeric(strpos($R["priznanje"],"zlat")))){
                    $VCount[$Indx][3]=$VCount[$Indx][3]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Šolsko"))){
                    $VCount[$Indx][4]=$VCount[$Indx][4]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Regijsko"))){
                    $VCount[$Indx][5]=$VCount[$Indx][5]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Področno"))){
                    $VCount[$Indx][6]=$VCount[$Indx][6]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Državno"))){
                    $VCount[$Indx][7]=$VCount[$Indx][7]+1;
                }
            }
        }

        echo "<h2>Preglednica osvojenih priznanj in udeležbe na tekmovanjih</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Tekmovanje</th>";
        echo "<th>Bronasto</th>";
        echo "<th>Srebrno</th>";
        echo "<th>Zlato</th>";
        echo "<th>Šolsko</th>";
        echo "<th>Regijsko</th>";
        echo "<th>Področno</th>";
        echo "<th>Državno</th>";
        echo "<th>Sodelovalo</th>";
        echo "</tr>";

        $VCount[0][0]=0;
        for ($Indx=1;$Indx <= $StTekmovanj;$Indx++){
            $VCount[0][0]=$VCount[0][0]+Max($VCount[$Indx]);
            $VCount[0][1]=$VCount[0][1]+$VCount[$Indx][1];
            $VCount[0][2]=$VCount[0][2]+$VCount[$Indx][2];
            $VCount[0][3]=$VCount[0][3]+$VCount[$Indx][3];
            $VCount[0][4]=$VCount[0][4]+$VCount[$Indx][4];
            $VCount[0][5]=$VCount[0][5]+$VCount[$Indx][5];
            $VCount[0][6]=$VCount[0][6]+$VCount[$Indx][6];
            $VCount[0][7]=$VCount[0][7]+$VCount[$Indx][7];
            echo "<tr>";
            echo "<td>".$VCount[$Indx][0]."</td>";
            echo "<td align=right>".$VCount[$Indx][1]."</td>";
            echo "<td align=right>".$VCount[$Indx][2]."</td>";
            echo "<td align=right>".$VCount[$Indx][3]."</td>";
            echo "<td align=right>".$VCount[$Indx][4]."</td>";
            echo "<td align=right>".$VCount[$Indx][5]."</td>";
            echo "<td align=right>".$VCount[$Indx][6]."</td>";
            echo "<td align=right>".$VCount[$Indx][7]."</td>";
            echo "<td align=right>".Max($VCount[$Indx])."</td>";
            echo "</tr>";
        }
        echo "<tr>";
        echo "<td>Skupaj</td>";
        echo "<td align=right>".$VCount[0][1]."</td>";
        echo "<td align=right>".$VCount[0][2]."</td>";
        echo "<td align=right>".$VCount[0][3]."</td>";
        echo "<td align=right>".$VCount[0][4]."</td>";
        echo "<td align=right>".$VCount[0][5]."</td>";
        echo "<td align=right>".$VCount[0][6]."</td>";
        echo "<td align=right>".$VCount[0][7]."</td>";
        echo "<td align=right>".$VCount[0][0]."</td>";
        echo "</tr>";

    echo "</table><br />";

    //'---------------------------------------------------------Tekmovanja v znanju - konec -------------------------


    //'--------------------------------------------------------- Ucenci in razredniki po razredih -zacetek ---------------------------
    echo "<h2>Razredi in razredniki za šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";

    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
    $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
    $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabucenje.predmet=50 AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";

    $result = mysqli_query($link,$SQL);

    if (mysqli_num_rows($result) > 0){
        //'Izpis v obliki spiska - zacetek -----------------------------------------------------------------------------------------------------------------------------------
        $IndxRazrednik=0;
        while ($R = mysqli_fetch_array($result)){
            $Razredniki[$IndxRazrednik][0]=$R["priimek"].", ".$R["ime"];
            $Razredniki[$IndxRazrednik][1]=$R["razred"] . ". " . $R["oznaka"];
            $Razredniki[$IndxRazrednik][2]=$R["razred"];
            $Razredniki[$IndxRazrednik][3]=$R["oznaka"];
            $Razredniki[$IndxRazrednik][5]=$R["id"];
            $Razredniki[$IndxRazrednik][4]=$R["iducitelj"];
            $Razredniki[$IndxRazrednik][6]="&nbsp";
            $IndxRazrednik=$IndxRazrednik+1;
        }

        //ugotovi nadomestne razrednike
        $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
        $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
        $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabucenje.predmet=61 AND tabrazdat.idsola=".$sole[$IndxSola][0];
        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                if ($R["id"]==$Razredniki[$Indx][5]){
                    $Razredniki[$Indx][6]=$R["priimek"].", ".$R["ime"];
                }
            }
        }

        for ($Indx= 0;$Indx < $IndxRazrednik;$Indx++){
            $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabucenci.spol,COUNT(tabucenci.spol) AS stuc,tabrazred.leto ";
            $SQL = $SQL ."FROM ((tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL = $SQL ."INNER JOIN tabucitelji ON tabrazred.iducitelj=tabucitelji.iducitelj) ";
            $SQL = $SQL ."INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL ."GROUP BY tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabucenci.spol,tabrazred.leto ";
            $SQL = $SQL ."HAVING tabrazred.leto=$VLeto AND tabrazdat.id=".$Razredniki[$Indx][5];
            $SQL = $SQL ." ORDER BY tabucenci.spol";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["spol"]=="M"){
                    $CountF[$Indx]=$R["stuc"];
                }
                if ($R["spol"]=="F"){
                    $CountD[$Indx]=$R["stuc"];
                }
            }
        }
        if (isset($CountF)){
            echo "<table border=1 cellspacing=0 cellpadding=5>";
            echo "<tr bgcolor=lightcyan><th>Št.</th><th>Razred</th><th>Skupaj</th><th>Učencev</th><th>Učenk</th><th>Razrednik</th><th>Nadomestni<br />razrednik</th></tr>";
            $Skupaj[0]=0;
            $Skupaj[1]=0;
            $Skupaj[2]=0;
            $ColorChange=true;
            $RazredCompare=$Razredniki[0][2];
            $SkupajR[0][0]=0;
            $SkupajR[0][1]=0;
            $SkupajR[0][2]=0;
            $SkupajR[1][0]=0;
            $SkupajR[1][1]=0;
            $SkupajR[1][2]=0;
            for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                if ($RazredCompare != $Razredniki[$Indx][2]){
                    echo "<tr bgcolor=lightgreen>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                    echo "</tr>";
                    $RazredCompare=$Razredniki[$Indx][2];
                    $SkupajR[$RazredCompare][0]=0;
                    $SkupajR[$RazredCompare][1]=0;
                    $SkupajR[$RazredCompare][2]=0;
                }
                if ($ColorChange){
                    echo "<tr bgcolor=lightyellow>";
                }else{
                    echo "<tr bgcolor=#FFFFCC>";
                }
                $ColorChange=!$ColorChange;
                $SkupajR[$RazredCompare][0]=$SkupajR[$RazredCompare][0]+$CountD[$Indx]+$CountF[$Indx];
                $SkupajR[$RazredCompare][1]=$SkupajR[$RazredCompare][1]+$CountF[$Indx];
                $SkupajR[$RazredCompare][2]=$SkupajR[$RazredCompare][2]+$CountD[$Indx];
                
                echo "<td>".($Indx+1)."</td>";
                echo "<td>".$Razredniki[$Indx][1]."</td>";
                echo "<td align=center>".($CountF[$Indx]+$CountD[$Indx])."</td>";
                echo "<td align=center>".$CountF[$Indx]."</td>";
                echo "<td align=center>".$CountD[$Indx]."</td>";
                echo "<td>".$Razredniki[$Indx][0]."</td>";
                echo "<td>".$Razredniki[$Indx][6]."</td>";
                echo "</tr>";
                $Skupaj[1]=$Skupaj[1]+$CountF[$Indx];
                $Skupaj[2]=$Skupaj[2]+$CountD[$Indx];
                $Skupaj[0]=$Skupaj[0]+$CountF[$Indx]+$CountD[$Indx];
            }

            echo "<tr bgcolor=lightgreen>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
            echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
            echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";

            echo "<tr bgcolor=lightgrey>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;</td>";
            echo "<td align=center>".$Skupaj[0]."</td>";
            echo "<td align=center>".$Skupaj[1]."</td>";
            echo "<td align=center>".$Skupaj[2]."</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";

            echo "</table><br />";
        }
    }
    echo "<br />";
    //'--------------------------------------------------------- Ucenci in razredniki po razredih - konec ---------------------------

    //'--------------------------------------------------------- Ucenci po razredih in uspehu - zacetek ---------------------------
    $SQL = "SELECT tabrazred.napredovanje,tabucenci.spol,tabrazdat.razred,tabrazdat.oznaka FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    //Vrste oddelkov in učenci v njih - začetek
    for ($i=1;$i <= 3;$i++){
        for ($j=1;$j <= 4;$j++){
            $CountOddelki1[$i][$j]=0;
            $CountUcenci1[$i][$j]=0;
        }
    }

    $StrRazred="";
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $StrRazred1=$R["razred"].$R["oznaka"];
        switch ($R["razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                    $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                    $CountOddelki1[2][1]=$CountOddelki1[2][1]+1;
                    $CountOddelki1[2][3]=$CountOddelki1[2][3]+1;
                    $StrRazred=$StrRazred1;
                }
                $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                $CountUcenci1[2][2]=$CountUcenci1[2][2]+1;
                $CountUcenci1[2][4]=$CountUcenci1[2][4]+1;
                break;
            case 7:
            case 8:
            case 9:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                    $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                    $CountOddelki1[3][1]=$CountOddelki1[3][1]+1;
                    $CountOddelki1[3][3]=$CountOddelki1[3][3]+1;
                    $StrRazred=$StrRazred1;
                }
                $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                $CountUcenci1[3][2]=$CountUcenci1[3][2]+1;
                $CountUcenci1[3][4]=$CountUcenci1[3][4]+1;
        }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj (2+3)";
    $Rubrike14[2]="1.-6. razred";
    $Rubrike14[3]="7.-9. razred";
    echo "<b>1. Vrste oddelkov in učenci v njih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>ODDELKI</th><th>Št.</th><th>Skupaj</th><th></th><th>Čisti (nekombinirani)</th><th></th><th>kombinirani</th>";
    echo "<tr><td align=center></td><td></td><td align=center>Oddelki (3+5)</td><td align=center>Učenci (4+6)</td><td align=center>oddelki</td><td align=center>učenci</td><td align=center>oddelki</td><td align=center>učenci</td></tr>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
    for ($Indx=1;$Indx <= 3;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$CountOddelki1[$Indx][1]."</td><td align=center>".$CountUcenci1[$Indx][2]."</td><td align=center>".$CountOddelki1[$Indx][3]."</td><td align=center>".$CountUcenci1[$Indx][4]."</td><td></td><td></td></tr>";
    }
    echo "</table><br />";
    //Vrste oddelkov in učenci v njih - konec    

    //Učenci po razredih v programu 9-letne OŠ - začetek    
    $result = mysqli_query($link,$SQL);
    $StrRazred="";
    $Indx=0;
    for ($i=1;$i <= 20;$i++){
        for ($j=1;$j <= 10;$j++){
            $CountOddelki3[$i][$j]=0;
            $CountUcenci3[$i][$j]=0;
        }
    }
    while ($R = mysqli_fetch_array($result)){
        $StrRazred1=$R["razred"].$R["oznaka"];
        switch ($R["razred"]){
            case 1:
                if ($StrRazred != $StrRazred1){  //'oddelki
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1; //'vsi
                    $CountOddelki3[3][1]=$CountOddelki3[3][1]+1; // 'prvi razredi
                    $StrRazred=$StrRazred1;
                }
                
                switch ($R["napredovanje"]){
                    case 0: // 'napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[4][3]=$CountUcenci3[4][3]+1; //učenke - 1. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[4][2]=$CountUcenci3[4][2]+1; //učenke - 1. razred - skupaj
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                            $CountUcenci3[4][9]=$CountUcenci3[4][9]+1; // učenke - opisno - 1. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[3][3]=$CountUcenci3[3][3]+1; //vsi - 1. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[3][2]=$CountUcenci3[3][2]+1; //vsi - 1. razred - skupaj
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                        $CountUcenci3[3][9]=$CountUcenci3[3][9]+1; //vsi - opisno - 1. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["Spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[4][3]=$CountUcenci3[4][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[4][2]=$CountUcenci3[4][2]+1;
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                            $CountUcenci3[4][9]=$CountUcenci3[4][9]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[3][3]=$CountUcenci3[3][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[3][2]=$CountUcenci3[3][2]+1;
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                        $CountUcenci3[3][9]=$CountUcenci3[3][9]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[4][10]=$CountUcenci3[4][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[3][10]=$CountUcenci3[3][10]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci3[4][2]=$CountUcenci3[4][2]+1;
                        }
                        $CountUcenci3[3][2]=$CountUcenci3[3][2]+1;
                }
                break;
            case 2:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[5][1]=$CountOddelki3[5][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[6][3]=$CountUcenci3[6][3]+1; //učenke - 2. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[6][2]=$CountUcenci3[6][2]+1; //učenke - 2. razred - skupaj
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                            $CountUcenci3[6][9]=$CountUcenci3[6][9]+1; // učenke - opisno - 2. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[5][3]=$CountUcenci3[5][3]+1; //vsi - 2. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[5][2]=$CountUcenci3[5][2]+1; //vsi - 2. razred - skupaj
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                        $CountUcenci3[5][9]=$CountUcenci3[5][9]+1; //vsi - opisno - 2. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[6][3]=$CountUcenci3[6][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[6][2]=$CountUcenci3[6][2]+1;
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                            $CountUcenci3[6][9]=$CountUcenci3[6][9]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[5][3]=$CountUcenci3[5][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[5][2]=$CountUcenci3[5][2]+1;
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                        $CountUcenci3[5][9]=$CountUcenci3[5][9]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[6][10]=$CountUcenci3[6][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[5][10]=$CountUcenci3[5][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[6][2]=$CountUcenci3[6][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[5][2]=$CountUcenci3[5][2]+1;
                }
                break;
            case 3:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[7][1]=$CountOddelki3[7][1]+1;
                    $StrRazred=$StrRazred1;
                }
                
                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[8][3]=$CountUcenci3[8][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[8][2]=$CountUcenci3[8][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                            $CountUcenci3[8][9]=$CountUcenci3[8][9]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[7][3]=$CountUcenci3[7][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[7][2]=$CountUcenci3[7][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                        $CountUcenci3[7][9]=$CountUcenci3[7][9]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[8][3]=$CountUcenci3[8][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[8][2]=$CountUcenci3[8][2]+1;
                            $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                            $CountUcenci3[8][9]=$CountUcenci3[8][9]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[7][3]=$CountUcenci3[7][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[7][2]=$CountUcenci3[7][2]+1;
                        $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                        $CountUcenci3[7][9]=$CountUcenci3[7][9]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[8][10]=$CountUcenci3[8][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[7][10]=$CountUcenci3[7][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[8][2]=$CountUcenci3[8][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[7][2]=$CountUcenci3[7][2]+1;
                }
                break;
            case 4:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[9][1]=$CountOddelki3[9][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[10][3]=$CountUcenci3[10][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[10][2]=$CountUcenci3[10][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[10][4]=$CountUcenci3[10][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[9][3]=$CountUcenci3[9][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[9][2]=$CountUcenci3[9][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[9][4]=$CountUcenci3[9][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[10][3]=$CountUcenci3[10][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[10][2]=$CountUcenci3[10][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[10][4]=$CountUcenci3[10][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[9][3]=$CountUcenci3[9][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[9][2]=$CountUcenci3[9][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[9][4]=$CountUcenci3[9][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[10][10]=$CountUcenci3[10][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[9][10]=$CountUcenci3[9][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[10][2]=$CountUcenci3[10][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[9][2]=$CountUcenci3[9][2]+1;
                }
                break;
            case 5:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[11][1]=$CountOddelki3[11][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[12][3]=$CountUcenci3[12][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[12][2]=$CountUcenci3[12][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[12][4]=$CountUcenci3[12][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[11][3]=$CountUcenci3[11][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[11][2]=$CountUcenci3[11][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[11][4]=$CountUcenci3[11][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[12][3]=$CountUcenci3[12][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[12][2]=$CountUcenci3[12][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[12][4]=$CountUcenci3[12][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[11][3]=$CountUcenci3[11][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[11][2]=$CountUcenci3[11][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[11][4]=$CountUcenci3[11][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[12][10]=$CountUcenci3[12][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[11][10]=$CountUcenci3[11][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[12][2]=$CountUcenci3[12][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[11][2]=$CountUcenci3[11][2]+1;
                }
                break;
            case 6:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[13][1]=$CountOddelki3[13][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[14][3]=$CountUcenci3[14][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[14][2]=$CountUcenci3[14][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[14][4]=$CountUcenci3[14][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[13][3]=$CountUcenci3[13][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[13][2]=$CountUcenci3[13][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[13][4]=$CountUcenci3[13][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[14][3]=$CountUcenci3[14][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[14][2]=$CountUcenci3[14][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[14][4]=$CountUcenci3[14][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[13][3]=$CountUcenci3[13][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[13][2]=$CountUcenci3[13][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[13][4]=$CountUcenci3[13][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[14][10]=$CountUcenci3[14][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[13][10]=$CountUcenci3[13][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[14][2]=$CountUcenci3[14][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[13][2]=$CountUcenci3[13][2]+1;
                }
                break;
            case 7:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[15][1]=$CountOddelki3[15][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[16][3]=$CountUcenci3[16][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[16][2]=$CountUcenci3[16][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[16][4]=$CountUcenci3[16][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[15][3]=$CountUcenci3[15][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[15][2]=$CountUcenci3[15][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[15][4]=$CountUcenci3[15][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[16][3]=$CountUcenci3[16][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[16][2]=$CountUcenci3[16][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[16][4]=$CountUcenci3[16][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[15][3]=$CountUcenci3[15][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[15][2]=$CountUcenci3[15][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[15][4]=$CountUcenci3[15][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[16][10]=$CountUcenci3[16][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[15][10]=$CountUcenci3[15][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[16][2]=$CountUcenci3[16][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[15][2]=$CountUcenci3[15][2]+1;
                }
                break;
            case 8:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[17][1]=$CountOddelki3[17][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[18][3]=$CountUcenci3[18][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[18][2]=$CountUcenci3[18][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[18][4]=$CountUcenci3[18][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[17][3]=$CountUcenci3[17][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[17][2]=$CountUcenci3[17][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[17][4]=$CountUcenci3[17][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[18][3]=$CountUcenci3[18][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[18][2]=$CountUcenci3[18][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[18][4]=$CountUcenci3[18][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[17][3]=$CountUcenci3[17][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[17][2]=$CountUcenci3[17][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[17][4]=$CountUcenci3[17][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[18][10]=$CountUcenci3[18][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[17][10]=$CountUcenci3[17][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[18][2]=$CountUcenci3[18][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[17][2]=$CountUcenci3[17][2]+1;
                }
                break;
            case 9:
                if ($StrRazred != $StrRazred1){
                    $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                    $CountOddelki3[19][1]=$CountOddelki3[19][1]+1;
                    $StrRazred=$StrRazred1;
                }

                switch ($R["napredovanje"]){
                    case 0: //napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                            $CountUcenci3[20][3]=$CountUcenci3[20][3]+1; //učenke - 3. razred - izdelali skupaj
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                            $CountUcenci3[20][2]=$CountUcenci3[20][2]+1; //učenke - 3. razred - skupaj
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                            $CountUcenci3[20][4]=$CountUcenci3[20][4]+1; // učenke - opisno - 3. razred
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                        $CountUcenci3[19][3]=$CountUcenci3[19][3]+1; //vsi - 3. razred - izdelali skupaj
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                        $CountUcenci3[19][2]=$CountUcenci3[19][2]+1; //vsi - 3. razred - skupaj
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                        $CountUcenci3[19][4]=$CountUcenci3[19][4]+1; //vsi - opisno - 3. razred
                        break;
                    case 1: //napreduje z negativno
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            $CountUcenci3[20][3]=$CountUcenci3[20][3]+1;
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                            $CountUcenci3[20][2]=$CountUcenci3[20][2]+1;
                            $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                            $CountUcenci3[20][4]=$CountUcenci3[20][4]+1;
                        }
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        $CountUcenci3[19][3]=$CountUcenci3[19][3]+1;
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[19][2]=$CountUcenci3[19][2]+1;
                        $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        $CountUcenci3[19][4]=$CountUcenci3[19][4]+1;
                        break;
                    case 2: //ne napreduje
                        if ($R["spol"]=="F"){
                            $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                            $CountUcenci3[20][10]=$CountUcenci3[19][10]+1;
                        }
                        $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                        $CountUcenci3[19][10]=$CountUcenci3[19][10]+1;
                        if ($R["spol"]=="F"){
                        //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                            $CountUcenci3[20][2]=$CountUcenci3[20][2]+1;
                        }
                        //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                        $CountUcenci3[19][2]=$CountUcenci3[19][2]+1;
                }
            }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj - Vsi";
    $Rubrike14[2]="Skupaj - učenke";
    $Rubrike14[3]="1. razred - vsi";
    $Rubrike14[4]="učenke";
    $Rubrike14[5]="2. razred - vsi";
    $Rubrike14[6]="učenke";
    $Rubrike14[7]="3. razred - vsi";
    $Rubrike14[8]="učenke";
    $Rubrike14[9]="4. razred - vsi";
    $Rubrike14[10]="učenke";
    $Rubrike14[11]="5. razred - vsi";
    $Rubrike14[12]="učenke";
    $Rubrike14[13]="6. razred - vsi";
    $Rubrike14[14]="učenke";
    $Rubrike14[15]="7. razred - vsi";
    $Rubrike14[16]="učenke";
    $Rubrike14[17]="8. razred - vsi";
    $Rubrike14[18]="učenke";
    $Rubrike14[19]="9. razred - vsi";
    $Rubrike14[20]="učenke";
    echo "<b>2. Učenci po razredih in uspehu ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>RAZREDI</th><th>Št.</th><th>Število čistih oddelkov</th><th>Učenci - skupaj<br />v čistih in <br />kombiniranih oddelkih)<br /> (3+5)</th><th>Napredujejo</th><th></th><th>Ne napredujejo</th>";
    echo "<tr><td align=center></td><td></td><td align=center></td><td align=center></td><td align=center>skupaj</td><td align=center>od tega z negativno oceno</td><td></td></tr>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
    for ($Indx=1;$Indx <= 20;$Indx++){
        echo "<tr><td align='right'>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".$Indx."</td>";
        echo "<td align=center>".$CountOddelki3[$Indx][1]."</td>"; //oddelki
        echo "<td align=center>".$CountUcenci3[$Indx][2]."</td>"; //vsi učenci
        echo "<td align=center>".$CountUcenci3[$Indx][3]."</td>"; //izdelali razred - skupaj
        echo "<td align=center>".$CountUcenci3[$Indx][8]."</td>"; //zadostni z negativno
        echo "<td align=center>".$CountUcenci3[$Indx][10]."</td>"; //niso izdelali
        echo "</tr>";
    }
    echo "</table><br />";
    //Učenci po razredih v programu 9-letne OŠ - konec

    //Učenci zaključnega razreda s popravnim izpitom - začetek    
    $SQL = "SELECT tabocene.leto,tabocene.iducenec,tabocene.popravni,count(tabocene.popravni) as stpopravcev,tabrazred.razred,tabrazred.uspeh,tabrazdat.idsola FROM ";
    $SQL = $SQL . "(tabocene INNER JOIN tabrazred ON tabocene.IdUcenec=tabrazred.IdUcenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL = $SQL . "GROUP BY tabocene.leto,tabrazred.Razred,tabrazred.uspeh,tabocene.IdUcenec,tabocene.Popravni,tabrazdat.idsola ";
    $SQL = $SQL . "HAVING tabocene.leto=".$VLeto." AND tabocene.Popravni=1 AND tabrazred.Razred=9 AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $result = mysqli_query($link,$SQL);
    $Indx=0;
    for ($i=1;$i <= 2;$i++){
        for ($j=1;$j <= 6;$j++){
            $CountUcenci5[$i][$j]=0;
        }
    }
    while ($R = mysqli_fetch_array($result)){
        switch ($R["stpopravcev"]){
            case 1:
                $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                $CountUcenci5[2][2]=$CountUcenci5[2][2]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                }
                break;
            case 2:
                $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                $CountUcenci5[2][3]=$CountUcenci5[2][3]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                }
                break;
            case 3:
                $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                $CountUcenci5[2][4]=$CountUcenci5[2][4]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                }
                break;
            default:
                $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                $CountUcenci5[2][5]=$CountUcenci5[2][5]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                }
        }
        $Indx=$Indx+1;
    }
    $Rubrike14[1]=" ";
    $Rubrike14[2]="Skupaj";
    echo "<b>4. Učenci zaključnega razreda s popravnim izpitom ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th></th><th>Št.</th><th>Imajo popravni izpit</th><th></th><th></th><th></th><th></th><th>Opravili popravni izpit</th>";
    echo "<tr><td align=center></td><td></td><td align=center>Skupaj (2 do 5)</td><td align=center>Iz 1 predmeta</td><td align=center>Iz 2 predmetov</td><td align=center>Iz 3 predmetov</td><td align=center>Iz 4 ali več predmetov</td></tr>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
    for ($Indx=2;$Indx <= 2;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".($Indx-1)."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][1]."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][2]."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][3]."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][4]."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][5]."</td>";
        echo "<td align=center>".$CountUcenci5[$Indx][6]."</td>";
        echo "</tr>";
    }
    echo "</table><br />";

    //Učenci zaključnega razreda s popravnim izpitom - konec

    //Učenci s posebnimi potrebami - začetek    
    $SQL = "SELECT tabrazred.uspeh,tabucenci.idposebnepotrebe,tabrazdat.razred FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    for ($i=1;$i <= 18;$i++){
        for ($j=1;$j <= 10;$j++){
            $CountUcenci7[$i][$j]=0;
        }
    }
    $StrRazred="";
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        switch ($R["razred"]){
            case 1:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][2]=$CountUcenci7[2][2]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][2]=$CountUcenci7[1][2]+1;
                    }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][2]=$CountUcenci7[4][2]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][2]=$CountUcenci7[3][2]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][2]=$CountUcenci7[6][2]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][2]=$CountUcenci7[5][2]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][2]=$CountUcenci7[8][2]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][2]=$CountUcenci7[7][2]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][2]=$CountUcenci7[10][2]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][2]=$CountUcenci7[9][2]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][2]=$CountUcenci7[12][2]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][2]=$CountUcenci7[11][2]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][2]=$CountUcenci7[14][2]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][2]=$CountUcenci7[13][2]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][2]=$CountUcenci7[16][2]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][2]=$CountUcenci7[15][2]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][2]=$CountUcenci7[18][2]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][2]=$CountUcenci7[17][2]+1;
                    }
                break;
            case 2:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][3]=$CountUcenci7[2][3]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][3]=$CountUcenci7[1][3]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][3]=$CountUcenci7[4][3]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][3]=$CountUcenci7[3][3]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][3]=$CountUcenci7[6][3]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][3]=$CountUcenci7[5][3]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][3]=$CountUcenci7[8][3]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][3]=$CountUcenci7[7][3]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][3]=$CountUcenci7[10][3]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][3]=$CountUcenci7[9][3]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][3]=$CountUcenci7[12][3]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][3]=$CountUcenci7[11][3]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][3]=$CountUcenci7[14][3]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][3]=$CountUcenci7[13][3]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][3]=$CountUcenci7[16][3]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][3]=$CountUcenci7[15][3]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][3]=$CountUcenci7[18][3]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][3]=$CountUcenci7[17][3]+1;
                }
                break;
            case 3:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][4]=$CountUcenci7[2][4]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][4]=$CountUcenci7[1][4]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][4]=$CountUcenci7[4][4]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][4]=$CountUcenci7[3][4]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][4]=$CountUcenci7[6][4]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][4]=$CountUcenci7[5][4]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][4]=$CountUcenci7[8][4]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][4]=$CountUcenci7[7][4]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][4]=$CountUcenci7[10][4]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][4]=$CountUcenci7[9][4]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][4]=$CountUcenci7[12][4]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][4]=$CountUcenci7[11][4]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][4]=$CountUcenci7[14][4]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][4]=$CountUcenci7[13][4]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][4]=$CountUcenci7[16][4]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][4]=$CountUcenci7[15][4]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][4]=$CountUcenci7[18][4]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][4]=$CountUcenci7[17][4]+1;
                }
                break;
            case 4:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][5]=$CountUcenci7[2][5]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][5]=$CountUcenci7[1][5]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][5]=$CountUcenci7[4][5]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][5]=$CountUcenci7[3][5]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][5]=$CountUcenci7[6][5]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][5]=$CountUcenci7[5][5]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][5]=$CountUcenci7[8][5]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][5]=$CountUcenci7[7][5]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][5]=$CountUcenci7[10][5]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][5]=$CountUcenci7[9][5]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][5]=$CountUcenci7[12][5]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][5]=$CountUcenci7[11][5]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][5]=$CountUcenci7[14][5]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][5]=$CountUcenci7[13][5]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][5]=$CountUcenci7[16][5]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][5]=$CountUcenci7[15][5]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][5]=$CountUcenci7[18][5]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][5]=$CountUcenci7[17][5]+1;
                }
                break;
            case 5:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][6]=$CountUcenci7[2][6]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][6]=$CountUcenci7[1][6]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][6]=$CountUcenci7[4][6]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][6]=$CountUcenci7[3][6]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][6]=$CountUcenci7[6][6]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][6]=$CountUcenci7[5][6]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][6]=$CountUcenci7[8][6]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][6]=$CountUcenci7[7][6]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][6]=$CountUcenci7[10][6]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][6]=$CountUcenci7[9][6]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][6]=$CountUcenci7[12][6]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][6]=$CountUcenci7[11][6]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][6]=$CountUcenci7[14][6]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][6]=$CountUcenci7[13][6]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][6]=$CountUcenci7[16][6]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][6]=$CountUcenci7[15][6]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][6]=$CountUcenci7[18][6]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][6]=$CountUcenci7[17][6]+1;
                }
                break;
            case 6:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][7]=$CountUcenci7[2][7]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][7]=$CountUcenci7[1][7]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][7]=$CountUcenci7[4][7]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][7]=$CountUcenci7[3][7]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][7]=$CountUcenci7[6][7]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][7]=$CountUcenci7[5][7]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][7]=$CountUcenci7[8][7]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][7]=$CountUcenci7[7][7]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][7]=$CountUcenci7[10][7]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][7]=$CountUcenci7[9][7]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][7]=$CountUcenci7[12][7]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][7]=$CountUcenci7[11][7]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][7]=$CountUcenci7[14][7]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][7]=$CountUcenci7[13][7]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][7]=$CountUcenci7[16][7]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][7]=$CountUcenci7[15][7]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][7]=$CountUcenci7[18][7]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][7]=$CountUcenci7[17][7]+1;
                }
                break;
            case 7:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][8]=$CountUcenci7[2][8]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][8]=$CountUcenci7[1][8]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][8]=$CountUcenci7[4][8]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][8]=$CountUcenci7[3][8]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][8]=$CountUcenci7[6][8]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][8]=$CountUcenci7[5][8]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][8]=$CountUcenci7[8][8]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][8]=$CountUcenci7[7][8]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][8]=$CountUcenci7[10][8]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][8]=$CountUcenci7[9][8]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][8]=$CountUcenci7[12][8]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][8]=$CountUcenci7[11][8]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][8]=$CountUcenci7[14][8]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][8]=$CountUcenci7[13][8]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][8]=$CountUcenci7[16][8]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][8]=$CountUcenci7[15][8]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][8]=$CountUcenci7[18][8]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][8]=$CountUcenci7[17][8]+1;
                }
                break;
            case 8:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][9]=$CountUcenci7[2][9]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][9]=$CountUcenci7[1][9]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][9]=$CountUcenci7[4][9]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][9]=$CountUcenci7[3][9]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][9]=$CountUcenci7[6][9]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][9]=$CountUcenci7[5][9]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][9]=$CountUcenci7[8][9]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][9]=$CountUcenci7[7][9]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][9]=$CountUcenci7[10][9]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][9]=$CountUcenci7[9][9]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][9]=$CountUcenci7[12][9]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][9]=$CountUcenci7[11][9]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][9]=$CountUcenci7[14][9]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][9]=$CountUcenci7[13][9]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][9]=$CountUcenci7[16][9]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][9]=$CountUcenci7[15][9]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][9]=$CountUcenci7[18][9]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][9]=$CountUcenci7[17][9]+1;
                }
                break;
            case 9:
                if ($R["idposebnepotrebe"] > 1){
                    if ($R["uspeh"] > 1){
                        $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                        $CountUcenci7[2][10]=$CountUcenci7[2][10]+1;
                    }
                    $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                    $CountUcenci7[1][10]=$CountUcenci7[1][10]+1;
                }
                switch ($R["idposebnepotrebe"]){
                    case 2:    //slepi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                            $CountUcenci7[4][10]=$CountUcenci7[4][10]+1;
                        }
                        $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                        $CountUcenci7[3][10]=$CountUcenci7[3][10]+1;
                        break;
                    case 3:    //gluhi
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                            $CountUcenci7[6][10]=$CountUcenci7[6][10]+1;
                        }
                        $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                        $CountUcenci7[5][10]=$CountUcenci7[5][10]+1;
                        break;
                    case 4:    //govorne motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                            $CountUcenci7[8][10]=$CountUcenci7[8][10]+1;
                        }
                        $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                        $CountUcenci7[7][10]=$CountUcenci7[7][10]+1;
                        break;
                    case 5:    //vedenjske motnje
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                            $CountUcenci7[10][10]=$CountUcenci7[10][10]+1;
                        }
                        $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                        $CountUcenci7[9][10]=$CountUcenci7[9][10]+1;
                        break;
                    case 6:    //gibalno ovirani
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                            $CountUcenci7[12][10]=$CountUcenci7[12][10]+1;
                        }
                        $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                        $CountUcenci7[11][10]=$CountUcenci7[11][10]+1;
                        break;
                    case 7:    //dolgotrajno bolni
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                            $CountUcenci7[14][10]=$CountUcenci7[14][10]+1;
                        }
                        $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                        $CountUcenci7[13][10]=$CountUcenci7[13][10]+1;
                        break;
                    case 8:    //primanjkljaj
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                            $CountUcenci7[16][10]=$CountUcenci7[16][10]+1;
                        }
                        $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                        $CountUcenci7[15][10]=$CountUcenci7[15][10]+1;
                        break;
                    case 9:    //mejne intelektualne sposobnosti
                        if ($R["uspeh"] > 1){
                            $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                            $CountUcenci7[18][10]=$CountUcenci7[18][10]+1;
                        }
                        $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                        $CountUcenci7[17][10]=$CountUcenci7[17][10]+1;
                }
            }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj - vsi";
    $Rubrike14[2]="napredujejo";
    $Rubrike14[3]="Slepi in slabovidni - vsi";
    $Rubrike14[4]="napredujejo";
    $Rubrike14[5]="Gluhi in naglušni - vsi";
    $Rubrike14[6]="napredujejo";
    $Rubrike14[7]="Otroci z govorno-jezikovnimi motnjami - vsi";
    $Rubrike14[8]="napredujejo";
    $Rubrike14[9]="Otroci s čustvenimi in vedenjskimi motnjami - vsi";
    $Rubrike14[10]="napredujejo";
    $Rubrike14[11]="Gibalno ovirani otroci - vsi";
    $Rubrike14[12]="napredujejo";
    $Rubrike14[13]="Dolgotrajno bolni otroci - vsi";
    $Rubrike14[14]="napredujejo";
    $Rubrike14[15]="Otroci s primanjkljaji na posameznih področjih - vsi";
    $Rubrike14[16]="napredujejo";
    $Rubrike14[17]="Otroci z mejnimi intelektualnimi sposobnostmi - vsi";
    $Rubrike14[18]="napredujejo";
    echo "<b>6. Učenci s posebnimi potrebami, ki so vključeni v prilagojeno izvajanje z dodatno strokovno pomočjo v redne oddelke programov 8-letne in 9-letne OŠ ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>UČENCI GLEDE NA VRSTO MOTNJE</th><th>Št.</th><th>Skupaj (2-10)</th><th>1. razred<th>2. razred</th><th>3. razred</th><th>4. razred</th><th>5. razred</th><th>6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td></tr>";
    for ($Indx=1;$Indx <= 18;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".$Indx."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][1]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][2]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][3]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][4]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][5]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][6]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][7]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][8]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][9]."</td>";
        echo "<td align=center>".$CountUcenci7[$Indx][10]."</td>";
        echo "</tr>";
    }
    echo "</table><br />";
    //Učenci s posebnimi potrebami - konec

    //Učenci, ki so obiskovali šolo deveto leto, po razredih  - začetek    
    $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja in (8,9) AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    for ($i=1;$i <= 3;$i++){
        for ($j=1;$j <= 6;$j++){
            $CountUcenci9[$i][$j]=0;
        }
    }
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        switch ($R["razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                $CountUcenci9[1][3]=$CountUcenci9[1][3]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                    $CountUcenci9[2][3]=$CountUcenci9[2][3]+1;
                }else{
                    $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                    $CountUcenci9[3][3]=$CountUcenci9[3][3]+1;
                }
                break;
            case 7:
                $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                $CountUcenci9[1][4]=$CountUcenci9[1][4]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                    $CountUcenci9[2][4]=$CountUcenci9[2][4]+1;
                }else{
                    $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                    $CountUcenci9[3][4]=$CountUcenci9[3][4]+1;
                }
                break;
            case 8:
                $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                $CountUcenci9[1][5]=$CountUcenci9[1][5]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                    $CountUcenci9[2][5]=$CountUcenci9[2][5]+1;
                }else{
                    $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                    $CountUcenci9[3][5]=$CountUcenci9[3][5]+1;
                }
                break;
            case 9:
                $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                $CountUcenci9[1][6]=$CountUcenci9[1][6]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                    $CountUcenci9[2][6]=$CountUcenci9[2][6]+1;
                }else{
                    $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                    $CountUcenci9[3][6]=$CountUcenci9[3][6]+1;
                }
        }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
    $Rubrike14[2]="napredujejo";
    $Rubrike14[3]="ne napredujejo";
    $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
    echo "<b>7. Učenci, ki so obiskovali šolo devet let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
    for ($Indx=1;$Indx <= 3;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".$Indx."</td>";
        echo "<td align=center>".$CountUcenci9[$Indx][1]."</td>";
        echo "<td align=center>".$CountUcenci9[$Indx][3]."</td>";
        echo "<td align=center>".$CountUcenci9[$Indx][4]."</td>";
        echo "<td align=center>".$CountUcenci9[$Indx][5]."</td>";
        echo "<td align=center>".$CountUcenci9[$Indx][6]."</td>";
        echo "</tr>";
    }
    echo "<tr><td>".$Rubrike14[4]."</td>";
    echo "<td align='center'>4</td>";
    echo "<td align=center>".$CountUcenci9[3][1]."</td>";
    echo "<td align=center>".$CountUcenci9[3][3]."</td>";
    echo "<td align=center>".$CountUcenci9[3][4]."</td>";
    echo "<td align=center>".$CountUcenci9[3][5]."</td>";
    echo "<td align=center>".$CountUcenci9[3][6]."</td>";
    echo "</tr>";
    echo "</table><br />";
    //Učenci, ki so obiskovali šolo deveto leto, po razredih - konec

    //Učenci, ki so obiskovali šolo deseto leto, po razredih  - začetek    
    $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja=10 AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    for ($i=1;$i <= 3;$i++){
        for ($j=1;$j <= 6;$j++){
            $CountUcenci10[$i][$j]=0;
        }
    }
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        switch ($R["razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                $CountUcenci10[1][3]=$CountUcenci10[1][3]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                    $CountUcenci10[2][3]=$CountUcenci10[2][3]+1;
                }else{
                    $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                    $CountUcenci10[3][3]=$CountUcenci10[3][3]+1;
                }
                break;
            case 7:
                $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                $CountUcenci10[1][4]=$CountUcenci10[1][4]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                    $CountUcenci10[2][4]=$CountUcenci10[2][4]+1;
                }else{
                    $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                    $CountUcenci10[3][4]=$CountUcenci10[3][4]+1;
                }
                break;
            case 8:
                $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                $CountUcenci10[1][5]=$CountUcenci10[1][5]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                    $CountUcenci10[2][5]=$CountUcenci10[2][5]+1;
                }else{
                    $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                    $CountUcenci10[3][5]=$CountUcenci10[3][5]+1;
                }
                break;
            case 9:
                $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                $CountUcenci10[1][6]=$CountUcenci10[1][6]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                    $CountUcenci10[2][6]=$CountUcenci10[2][6]+1;
                }else{
                    $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                    $CountUcenci10[3][6]=$CountUcenci10[3][6]+1;
                }
            }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
    $Rubrike14[2]="napredujejo";
    $Rubrike14[3]="ne napredujejo";
    $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
    echo "<b>8. Učenci, ki so obiskovali šolo deset let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
    for ($Indx=1;$Indx <= 3;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".$Indx."</td>";
        echo "<td align=center>".$CountUcenci10[$Indx][1]."</td>";
        echo "<td align=center>".$CountUcenci10[$Indx][3]."</td>";
        echo "<td align=center>".$CountUcenci10[$Indx][4]."</td>";
        echo "<td align=center>".$CountUcenci10[$Indx][5]."</td>";
        echo "<td align=center>".$CountUcenci10[$Indx][6]."</td>";
        echo "</tr>";
    }
    echo "<tr><td>".$Rubrike14[4]."</td>";
    echo "<td align=center>4</td>";
    echo "<td align=center>".$CountUcenci10[3][1]."</td>";
    echo "<td align=center>".$CountUcenci10[3][3]."</td>";
    echo "<td align=center>".$CountUcenci10[3][4]."</td>";
    echo "<td align=center>".$CountUcenci10[3][5]."</td>";
    echo "<td align=center>".$CountUcenci10[3][6]."</td>";
    echo "</tr>";
    echo "</table><br />";
    //Učenci, ki so obiskovali šolo deseto leto, po razredih - konec

    //Učenci, ki so obiskovali šolo enajsto leto, po razredih  - začetek    
    $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja=11 AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    for ($i=1;$i <= 3;$i++){
        for ($j=1;$j <= 6;$j++){
            $CountUcenci8[$i][$j]=0;
        }
    }
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
       switch ($R["razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                $CountUcenci8[1][3]=$CountUcenci8[1][3]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                    $CountUcenci8[2][3]=$CountUcenci8[2][3]+1;
                }else{
                    $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                    $CountUcenci8[3][3]=$CountUcenci8[3][3]+1;
                }
                break;
            case 7:
                $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                $CountUcenci8[1][4]=$CountUcenci8[1][4]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                    $CountUcenci8[2][4]=$CountUcenci8[2][4]+1;
                }else{
                    $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                    $CountUcenci8[3][4]=$CountUcenci8[3][4]+1;
                }
                break;
            case 8:
                $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                $CountUcenci8[1][5]=$CountUcenci8[1][5]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                    $CountUcenci8[2][5]=$CountUcenci8[2][5]+1;
                }else{
                    $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                    $CountUcenci8[3][5]=$CountUcenci8[3][5]+1;
                }
                break;
            case 9:
                $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                $CountUcenci8[1][6]=$CountUcenci8[1][6]+1;
                if ($R["uspeh"] > 1){
                    $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                    $CountUcenci8[2][6]=$CountUcenci8[2][6]+1;
                }else{
                    $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                    $CountUcenci8[3][6]=$CountUcenci8[3][6]+1;
                }
            }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
    $Rubrike14[2]="napredujejo";
    $Rubrike14[3]="ne napredujejo";
    $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
    echo "<b>9. Učenci, ki so obiskovali šolo enajst let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
    for ($Indx=1;$Indx <= 3;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td>";
        echo "<td align=center>".$Indx."</td>";
        echo "<td align=center>".$CountUcenci8[$Indx][1]."</td>";
        echo "<td align=center>".$CountUcenci8[$Indx][3]."</td>";
        echo "<td align=center>".$CountUcenci8[$Indx][4]."</td>";
        echo "<td align=center>".$CountUcenci8[$Indx][5]."</td>";
        echo "<td align=center>".$CountUcenci8[$Indx][6]."</td>";
        echo "</tr>";
    }
    echo "<tr><td>".$Rubrike14[4]."</td>";
    echo "<td align=center>4</td>";
    echo "<td align=center>".$CountUcenci8[3][1]."</td>";
    echo "<td align=center>".$CountUcenci8[3][3]."</td>";
    echo "<td align=center>".$CountUcenci8[3][4]."</td>";
    echo "<td align=center>".$CountUcenci8[3][5]."</td>";
    echo "<td align=center>".$CountUcenci8[3][6]."</td>";
    echo "</tr>";
    echo "</table><br />";
    //Učenci, ki so obiskovali šolo enajsto leto, po razredih - konec

        //Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika - začetek    
            $SQL = "SELECT DISTINCT tabucenje.razred,tabpredmeti.kodamss,tabrazred.iducenec FROM (((tabucenje ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenje.idrazred=tabrazred.idrazred) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL = $SQL . "INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec) ";
            $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabpredmeti.kodamss IN ('TJA','TJN')"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 4;$i++){
                for ($j=1;$j <= 10;$j++){
                    $CountUcenci12[$i][$j]=0;
                }
            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["kodamss"])){
                    switch ($R["razred"]){
                        case 1:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[4][2]=$CountUcenci12[4][2]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[2][2]=$CountUcenci12[2][2]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[3][2]=$CountUcenci12[3][2]+1;
                            }
                            break;
                        case 2:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[4][3]=$CountUcenci12[4][3]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[2][3]=$CountUcenci12[2][3]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[3][3]=$CountUcenci12[3][3]+1;
                            }
                            break;
                        case 3:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[4][4]=$CountUcenci12[4][4]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[2][4]=$CountUcenci12[2][4]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[3][4]=$CountUcenci12[3][4]+1;
                            }
                            break;
                        case 4:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[4][5]=$CountUcenci12[4][5]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[2][5]=$CountUcenci12[2][5]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[3][5]=$CountUcenci12[3][5]+1;
                            }
                            break;
                        case 5:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[4][6]=$CountUcenci12[4][6]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[2][6]=$CountUcenci12[2][6]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[3][6]=$CountUcenci12[3][6]+1;
                            }
                            break;
                        case 6:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[4][7]=$CountUcenci12[4][7]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[2][7]=$CountUcenci12[2][7]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[3][7]=$CountUcenci12[3][7]+1;
                            }
                            break;
                        case 7:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[4][8]=$CountUcenci12[4][8]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[2][8]=$CountUcenci12[2][8]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[3][8]=$CountUcenci12[3][8]+1;
                            }
                            break;
                        case 8:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[4][9]=$CountUcenci12[4][9]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[2][9]=$CountUcenci12[2][9]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[3][9]=$CountUcenci12[3][9]+1;
                            }
                            break;
                        case 9:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[4][10]=$CountUcenci12[4][10]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[2][10]=$CountUcenci12[2][10]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[3][10]=$CountUcenci12[3][10]+1;
                            }
                    }
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="1. tuji jezik";
            $Rubrike14[2]="Angleščina";
            $Rubrike14[3]="Nemščina";
            $Rubrike14[4]="Slovenščina kot jezik okolja";
            $Rubrike14[5]="Italijanščina kot jezik okolja";
            $Rubrike14[6]="Madžarščina kot jezik okolja";
            $Rubrike14[7]="Skupaj jeziki okolja";
            echo "<b>11. Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>JEZIKI</th><th>Št.</th><th>Skupaj (2-10)</th><th>1. razred</th><th>2. razred</th><th>3. razred</th><th>4. razred</th><th>5. razred</th><th>6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td></tr>";

            echo "<tr><td>".$Rubrike14[1]."</td>";
            echo "<td align=center>1</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";
            for ($Indx=2;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][6]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][7]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][8]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][9]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][10]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika - konec

        //Učenci, ki se učijo v 9-letni osnovni šoli tuji jezik kot izbirni predmet - začetek    
            $SQL = "SELECT tabizbirni.izbirni,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabpredmeti.kodamss FROM ";
            $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabizbirni.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
            $SQL = $SQL ." AND tabpredmeti.KodaMSS IN ('FI1','FI2','FI3','NI1','NI2','NI3','ŠI1','ŠI2','ŠI3','LI1','LI2','LI3','HI1','HI2','HI3','II1','II2','II3','IF2','IN2','IM2','IH2','IA2','INA','INN')";
            $SQL = $SQL . " ORDER BY tabrazred.Razred,tabrazred.Paralelka,tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 8;$i++){
                for ($j=1;$j <= 8;$j++){
                    $CountUcenci13[$i][$j]=0;
                }
            }
            $UcenecIzbirni="";
            $Indx=1;
            $Indx1=1;
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["kodamss"])){
                    if ($UcenecIzbirni == $R["priimek"]." ".$R["ime"]){
                        $Ucenci[$Indx][$Indx1]=$R["kodamss"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Ucenci[$Indx][0]=$R["razred"];
                        $Ucenci[$Indx][$Indx1]=$R["kodamss"];
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $UcenecIzbirni = $R["priimek"]." ".$R["ime"];
                    }
                }
            }
            $Ucencev=$Indx-1;
            
            for ($Indx=1;$Indx <= $Ucencev;$Indx++){
                $Drugi=false;
                switch ($Ucenci[$Indx][0]){
                case 7:
                    switch ($Ucenci[$Indx][1]){
                    case "IF2":
                    case "FI1":
                    case "FI2":
                    case "FI3": //FI1][FI2][FI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                        $Drugi=True;
                        break;
                    case "LI1":
                    case "LI2":
                    case "LI3": //LI1][LI2][LI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                        $Drugi=True;
                        break;
                    case "II1":
                    case "II2":
                    case "II3": //italijanščina
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                        $Drugi=True;
                        break;
                    case "IH2":
                    case "HI1":
                    case "HI2":
                    case "HI3": //HI1][HI2][HI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                        $Drugi=True;
                        break;
                    case "NI1":
                    case "NI2":
                    case "NI3":
                    case "IN2":
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                        $Drugi=True;
                        break;
                    case "ŠI1":
                    case "ŠI2":
                    case "ŠI3": //ŠI1
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                        $Drugi=True;
                    }

                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[3][5]=$CountUcenci13[3][5]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[7][5]=$CountUcenci13[7][5]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[4][5]=$CountUcenci13[4][5]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[8][5]=$CountUcenci13[8][5]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[5][5]=$CountUcenci13[5][5]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[6][5]=$CountUcenci13[6][5]+1;
                            }
                        }

                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[3][5]=$CountUcenci13[3][5]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[7][5]=$CountUcenci13[7][5]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[4][5]=$CountUcenci13[4][5]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[8][5]=$CountUcenci13[8][5]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[5][5]=$CountUcenci13[5][5]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[6][5]=$CountUcenci13[6][5]+1;
                            }
                        }
                    }
                    break;
                case 8:
                    switch ($Ucenci[$Indx][1]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                            $Drugi=True;
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                            $Drugi=True;
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                            $Drugi=True;
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                            $Drugi=True;
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                            $Drugi=True;
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                            $Drugi=True;
                        }
                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[3][6]=$CountUcenci13[3][6]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[7][6]=$CountUcenci13[7][6]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[4][6]=$CountUcenci13[4][6]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[8][6]=$CountUcenci13[8][6]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[5][6]=$CountUcenci13[5][6]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[6][6]=$CountUcenci13[6][6]+1;
                            }
                        }
                    }
                    if (isset($Ucenci[$Indx][3])){
                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[3][6]=$CountUcenci13[3][6]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[7][6]=$CountUcenci13[7][6]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[4][6]=$CountUcenci13[4][6]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[8][6]=$CountUcenci13[8][6]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[5][6]=$CountUcenci13[5][6]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[6][6]=$CountUcenci13[6][6]+1;
                            }
                        }
                    }
                    break;
                case 9:
                    switch ($Ucenci[$Indx][1]){
                    case "IF2":
                    case "FI1":
                    case "FI2":
                    case "FI3": //FI1][FI2][FI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                        $Drugi=True;
                        break;
                    case "LI1":
                    case "LI2":
                    case "LI3": //LI1][LI2][LI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                        $Drugi=True;
                        break;
                    case "II1":
                    case "II2":
                    case "II3": //italijanščina
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                        $Drugi=True;
                        break;
                    case "IH2":
                    case "HI1":
                    case "HI2":
                    case "HI3": //HI1][HI2][HI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                        $Drugi=True;
                        break;
                    case "NI1":
                    case "NI2":
                    case "NI3":
                    case "IN2":
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                        $Drugi=True;
                        break;
                    case "ŠI1":
                    case "ŠI2":
                    case "ŠI3": //SI1
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                        $Drugi=True;
                    }
                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[3][7]=$CountUcenci13[3][7]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[7][7]=$CountUcenci13[7][7]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[4][7]=$CountUcenci13[4][7]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[8][7]=$CountUcenci13[8][7]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[5][7]=$CountUcenci13[5][7]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[6][7]=$CountUcenci13[6][7]+1;
                            }
                        }
                    }
                    if (isset($Ucenci[$Indx][3])){
                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[3][7]=$CountUcenci13[3][7]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[7][7]=$CountUcenci13[7][7]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[4][7]=$CountUcenci13[4][7]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[8][7]=$CountUcenci13[8][7]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[5][7]=$CountUcenci13[5][7]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[6][7]=$CountUcenci13[6][7]+1;
                            }
                        }
                    }
                }
            }
            
            $Rubrike14[1]="Angleški jezik";
            $Rubrike14[2]="Francoski jezik";
            $Rubrike14[3]="Italijanski jezik";
            $Rubrike14[4]="Nemški jezik";
            $Rubrike14[5]="Španski jezik";
            $Rubrike14[6]="Latinski jezik";
            $Rubrike14[7]="Hrvaški jezik";
            $Rubrike14[8]="Drug tuj jezik";
            echo "<b>12. Učenci, ki se učijo tuji jezik kot izbirni predmet ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>JEZIKI</th><th>Št.</th><th>Skupaj (2-7)</th><th>Kot 2. tuji jezik</th><th></th><th></th><th>Kot 3. tuji jezik</th>";
            echo "<tr><td></td><td></td><td></td><td>7. razred</td><td>8. razred</td><td>9. razred</td><td>7. razred</td><td>8. razred</td><td>9. razred</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td></tr>";
            for ($Indx=2;$Indx <= 8;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx-1]."</td>";
                echo "<td align=center>".($Indx-1)."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][6]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][7]."</td>";
                echo "</tr>";
            }
            echo "<tr><td>".$Rubrike14[8]."</td>";
            echo "<td align=center>8</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";
            echo "</table><br />";
        //Učenci, ki se učijo v 9-letni osnovni šoli tuji jezik kot izbirni predmet - konec

    //Učenci pri dopolnilnem in dodatnem pouku po razredih - začetek    
    $SQL = "SELECT tabdodpouk.pomoc,tabrazred.razred FROM ";
    $SQL = $SQL . "((tabdodpouk INNER JOIN tabucenci ON tabdodpouk.idUcenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.IdUcenec=tabrazred.idUcenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (3,4) AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabrazred.Razred,tabrazred.Paralelka";
    $result = mysqli_query($link,$SQL);

    for ($i=1;$i <= 1;$i++){
        for ($j=1;$j <= 5;$j++){
            $CountUcenci12[$i][$j]=0;
        }
    }
    while ($R = mysqli_fetch_array($result)){
        switch ($R["razred"]){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                switch ($R["pomoc"]){
                    case 4: // 'dop
                        $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                        $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                        break;
                    case 3: // 'dod
                        $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                        $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                }
                break;
            case 7:
            case 8:
            case 9:
                switch ($R["pomoc"]){
                    case 4: // 'dop
                        $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                        $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                        break;
                    case 3: // 'dod
                        $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                        $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                }
        }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Skupaj";
    echo "<b>14. Učenci pri dopolnilnem in dodatnem pouku, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<tr><th>UČENCI, VKLJUČENI V<br />DOP. IN DOD. POUK</th><th>Št.</th><th>Skupaj (2-5)</th><th>Dopolnilni pouk</th><th></th><th>Dodatni pouk</th><th></th></tr>";
    echo "<tr><td></td><td></td><td></td><td>1.-6. razred</td><td>7.-9. razred</td><td>1.-6. razred</td><td>7.-9. razred</td></tr>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
    echo "<tr><td>".$Rubrike14[1]."</td>";
    echo "<td align=center>1</td>";
    echo "<td align=center>".$CountUcenci13[1][1]."</td>";
    echo "<td align=center>".$CountUcenci13[1][2]."</td>";
    echo "<td align=center>".$CountUcenci13[1][3]."</td>";
    echo "<td align=center>".$CountUcenci13[1][4]."</td>";
    echo "<td align=center>".$CountUcenci13[1][5]."</td>";
    echo "</tr>";
    echo "</table><br />";
    //Učenci pri dopolnilnem in dodatnem pouku po razredih - konec

    $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabrazred.ponavljalec,tabucenci.spol,tabucenci.letoroj,tabucenci.bivanje FROM tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0 ORDER BY razred,paralelka";
    //Učenci po letu rojstva in razredih, v programu 9-letne OŠ - začetek
    for ($Indx=1;$Indx <= 11;$Indx++){
        $LetaRoj[$Indx]=$VLeto-5-$Indx;
    }
    for ($i=1;$i <= 20;$i++){
        for ($j=1;$j <= 14;$j++){
            $CountUcenci2[$i][$j]=0;
        }
    }
    $StrRazred="";
    $Indx=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        $StrRazred1=$R["razred"].$R["paralelka"];
        $CountUcenci2[1][1]=$CountUcenci2[1][1]+1;
        if ($R["spol"]=="F"){
            $CountUcenci2[2][1]=$CountUcenci2[2][1]+1;
        }
        switch ($R["letoroj"]){
        case $LetaRoj[1]:
        case ($LetaRoj[1]+1):
            $CountUcenci2[1][2]=$CountUcenci2[1][2]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][2]=$CountUcenci2[2][2]+1;
            }
            break;
        case $LetaRoj[2]:
            $CountUcenci2[1][3]=$CountUcenci2[1][3]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][3]=$CountUcenci2[2][3]+1;
            }
            break;
        case $LetaRoj[3]:
            $CountUcenci2[1][4]=$CountUcenci2[1][4]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][4]=$CountUcenci2[2][4]+1;
            }
            break;
        case $LetaRoj[4]:
            $CountUcenci2[1][5]=$CountUcenci2[1][5]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][5]=$CountUcenci2[2][5]+1;
            }
            break;
        case $LetaRoj[5]:
            $CountUcenci2[1][6]=$CountUcenci2[1][6]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][6]=$CountUcenci2[2][6]+1;
            }
            break;
        case $LetaRoj[6]:
            $CountUcenci2[1][7]=$CountUcenci2[1][7]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][7]=$CountUcenci2[2][7]+1;
            }
            break;
        case $LetaRoj[7]:
            $CountUcenci2[1][8]=$CountUcenci2[1][8]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][8]=$CountUcenci2[2][8]+1;
            }
            break;
        case $LetaRoj[8]:
            $CountUcenci2[1][9]=$CountUcenci2[1][9]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][9]=$CountUcenci2[2][9]+1;
            }
            break;
        case $LetaRoj[9]:
            $CountUcenci2[1][10]=$CountUcenci2[1][10]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][10]=$CountUcenci2[2][10]+1;
            }
            break;
        case $LetaRoj[10]:
            $CountUcenci2[1][11]=$CountUcenci2[1][11]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][11]=$CountUcenci2[2][11]+1;
            }
            break;
        default:
            $CountUcenci2[1][12]=$CountUcenci2[1][12]+1;
            if ($R["spol"]=="F"){
                $CountUcenci2[2][12]=$CountUcenci2[2][12]+1;
            }
        }
        
        switch ($R["razred"]){
            case 1:
                $CountUcenci2[3][1]=$CountUcenci2[3][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[4][1]=$CountUcenci2[4][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[3][2]=$CountUcenci2[3][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][2]=$CountUcenci2[4][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[3][3]=$CountUcenci2[3][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][3]=$CountUcenci2[4][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[3][4]=$CountUcenci2[3][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][4]=$CountUcenci2[4][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[3][5]=$CountUcenci2[3][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][5]=$CountUcenci2[4][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[3][6]=$CountUcenci2[3][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][6]=$CountUcenci2[4][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[3][7]=$CountUcenci2[3][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][7]=$CountUcenci2[4][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[3][8]=$CountUcenci2[3][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][8]=$CountUcenci2[4][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[3][9]=$CountUcenci2[3][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][9]=$CountUcenci2[4][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[3][10]=$CountUcenci2[3][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][10]=$CountUcenci2[4][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[3][11]=$CountUcenci2[3][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][11]=$CountUcenci2[4][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[3][12]=$CountUcenci2[3][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[4][12]=$CountUcenci2[4][12]+1;
                    }
                }
                break;
            case 2:
                $CountUcenci2[5][1]=$CountUcenci2[5][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[6][1]=$CountUcenci2[6][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[5][2]=$CountUcenci2[5][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][2]=$CountUcenci2[6][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[5][3]=$CountUcenci2[5][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][3]=$CountUcenci2[6][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[5][4]=$CountUcenci2[5][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][4]=$CountUcenci2[6][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[5][5]=$CountUcenci2[5][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][5]=$CountUcenci2[6][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[5][6]=$CountUcenci2[5][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][6]=$CountUcenci2[6][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[5][7]=$CountUcenci2[5][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][7]=$CountUcenci2[6][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[5][8]=$CountUcenci2[5][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][8]=$CountUcenci2[6][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[5][9]=$CountUcenci2[5][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][9]=$CountUcenci2[6][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[5][10]=$CountUcenci2[5][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][10]=$CountUcenci2[6][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[5][11]=$CountUcenci2[5][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][11]=$CountUcenci2[6][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[5][12]=$CountUcenci2[5][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[6][12]=$CountUcenci2[6][12]+1;
                    }
                }
                break;
            case 3:
                $CountUcenci2[7][1]=$CountUcenci2[7][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[8][1]=$CountUcenci2[8][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[7][2]=$CountUcenci2[7][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][2]=$CountUcenci2[8][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[7][3]=$CountUcenci2[7][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][3]=$CountUcenci2[8][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[7][4]=$CountUcenci2[7][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][4]=$CountUcenci2[8][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[7][5]=$CountUcenci2[7][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][5]=$CountUcenci2[8][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[7][6]=$CountUcenci2[7][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][6]=$CountUcenci2[8][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[7][7]=$CountUcenci2[7][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][7]=$CountUcenci2[8][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[7][8]=$CountUcenci2[7][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][8]=$CountUcenci2[8][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[7][9]=$CountUcenci2[7][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][9]=$CountUcenci2[8][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[7][10]=$CountUcenci2[7][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][10]=$CountUcenci2[8][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[7][11]=$CountUcenci2[7][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][11]=$CountUcenci2[8][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[7][12]=$CountUcenci2[7][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[8][12]=$CountUcenci2[8][12]+1;
                    }
                }
                break;
            case 4:
                $CountUcenci2[9][1]=$CountUcenci2[9][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[10][1]=$CountUcenci2[10][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case $LetaRoj[1]+1:
                    $CountUcenci2[9][2]=$CountUcenci2[9][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][2]=$CountUcenci2[10][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[9][3]=$CountUcenci2[9][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][3]=$CountUcenci2[10][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[9][4]=$CountUcenci2[9][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][4]=$CountUcenci2[10][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[9][5]=$CountUcenci2[9][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][5]=$CountUcenci2[10][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[9][6]=$CountUcenci2[9][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][6]=$CountUcenci2[10][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[9][7]=$CountUcenci2[9][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][7]=$CountUcenci2[10][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[9][8]=$CountUcenci2[9][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][8]=$CountUcenci2[10][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[9][9]=$CountUcenci2[9][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][9]=$CountUcenci2[10][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[9][10]=$CountUcenci2[9][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][10]=$CountUcenci2[10][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[9][11]=$CountUcenci2[9][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][11]=$CountUcenci2[10][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[9][12]=$CountUcenci2[9][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[10][12]=$CountUcenci2[10][12]+1;
                    }
                }
                break;
            case 5:
                $CountUcenci2[11][1]=$CountUcenci2[11][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[12][1]=$CountUcenci2[12][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case $LetaRoj[1]+1:
                    $CountUcenci2[11][2]=$CountUcenci2[11][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][2]=$CountUcenci2[12][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[11][3]=$CountUcenci2[11][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][3]=$CountUcenci2[12][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[11][4]=$CountUcenci2[11][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][4]=$CountUcenci2[12][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[11][5]=$CountUcenci2[11][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][5]=$CountUcenci2[12][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[11][6]=$CountUcenci2[11][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][6]=$CountUcenci2[12][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[11][7]=$CountUcenci2[11][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][7]=$CountUcenci2[12][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[11][8]=$CountUcenci2[11][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][8]=$CountUcenci2[12][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[11][9]=$CountUcenci2[11][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][9]=$CountUcenci2[12][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[11][10]=$CountUcenci2[11][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][10]=$CountUcenci2[12][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[11][11]=$CountUcenci2[11][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][11]=$CountUcenci2[12][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[11][12]=$CountUcenci2[11][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[12][12]=$CountUcenci2[12][12]+1;
                    }
                }
                break;
            case 6:
                $CountUcenci2[13][1]=$CountUcenci2[13][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[14][1]=$CountUcenci2[14][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[13][2]=$CountUcenci2[13][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][2]=$CountUcenci2[14][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[13][3]=$CountUcenci2[13][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][3]=$CountUcenci2[14][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[13][4]=$CountUcenci2[13][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][4]=$CountUcenci2[14][4]+1;
                    }




                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[13][5]=$CountUcenci2[13][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][5]=$CountUcenci2[14][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[13][6]=$CountUcenci2[13][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][6]=$CountUcenci2[14][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[13][7]=$CountUcenci2[13][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][7]=$CountUcenci2[14][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[13][8]=$CountUcenci2[13][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][8]=$CountUcenci2[14][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[13][9]=$CountUcenci2[13][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][9]=$CountUcenci2[14][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[13][10]=$CountUcenci2[13][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][10]=$CountUcenci2[14][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[13][11]=$CountUcenci2[13][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][11]=$CountUcenci2[14][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[13][12]=$CountUcenci2[13][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[14][12]=$CountUcenci2[14][12]+1;
                    }
                }
                break;
            case 7:
                $CountUcenci2[15][1]=$CountUcenci2[15][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[16][1]=$CountUcenci2[16][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[15][2]=$CountUcenci2[15][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][2]=$CountUcenci2[16][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[15][3]=$CountUcenci2[15][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][3]=$CountUcenci2[16][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[15][4]=$CountUcenci2[15][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][4]=$CountUcenci2[16][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[15][5]=$CountUcenci2[15][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][5]=$CountUcenci2[16][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[15][6]=$CountUcenci2[15][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][6]=$CountUcenci2[16][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[15][7]=$CountUcenci2[15][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][7]=$CountUcenci2[16][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[15][8]=$CountUcenci2[15][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][8]=$CountUcenci2[16][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[15][9]=$CountUcenci2[15][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][9]=$CountUcenci2[16][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[15][10]=$CountUcenci2[15][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][10]=$CountUcenci2[16][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[15][11]=$CountUcenci2[15][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][11]=$CountUcenci2[16][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[15][12]=$CountUcenci2[15][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[16][12]=$CountUcenci2[16][12]+1;
                    }
                }
                break;
            case 8:
                $CountUcenci2[17][1]=$CountUcenci2[17][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[18][1]=$CountUcenci2[18][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[17][2]=$CountUcenci2[17][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][2]=$CountUcenci2[18][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[17][3]=$CountUcenci2[17][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][3]=$CountUcenci2[18][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[17][4]=$CountUcenci2[17][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][4]=$CountUcenci2[18][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[17][5]=$CountUcenci2[17][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][5]=$CountUcenci2[18][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[17][6]=$CountUcenci2[17][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][6]=$CountUcenci2[18][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[17][7]=$CountUcenci2[17][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][7]=$CountUcenci2[18][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[17][8]=$CountUcenci2[17][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][8]=$CountUcenci2[18][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[17][9]=$CountUcenci2[17][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][9]=$CountUcenci2[18][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[17][10]=$CountUcenci2[17][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][10]=$CountUcenci2[18][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[17][11]=$CountUcenci2[17][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][11]=$CountUcenci2[18][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[17][12]=$CountUcenci2[17][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[18][12]=$CountUcenci2[18][12]+1;
                    }
                }
                break;
            case 9:
                $CountUcenci2[19][1]=$CountUcenci2[19][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[20][1]=$CountUcenci2[20][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1);
                    $CountUcenci2[19][2]=$CountUcenci2[19][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][2]=$CountUcenci2[20][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[19][3]=$CountUcenci2[19][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][3]=$CountUcenci2[20][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[19][4]=$CountUcenci2[19][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][4]=$CountUcenci2[20][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[19][5]=$CountUcenci2[19][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][5]=$CountUcenci2[20][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[19][6]=$CountUcenci2[19][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][6]=$CountUcenci2[20][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[19][7]=$CountUcenci2[19][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][7]=$CountUcenci2[20][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[19][8]=$CountUcenci2[19][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][8]=$CountUcenci2[20][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[19][9]=$CountUcenci2[19][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][9]=$CountUcenci2[20][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[19][10]=$CountUcenci2[19][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][10]=$CountUcenci2[20][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[19][11]=$CountUcenci2[19][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][11]=$CountUcenci2[20][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[19][12]=$CountUcenci2[19][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[20][12]=$CountUcenci2[20][12]+1;
                    }
                }
        }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Vsi";
    $Rubrike14[2]="učenke";
    $Rubrike14[3]="1. razred - vsi";
    $Rubrike14[4]="učenke";
    $Rubrike14[5]="2. razred - vsi";
    $Rubrike14[6]="učenke";
    $Rubrike14[7]="3. razred - vsi";
    $Rubrike14[8]="učenke";
    $Rubrike14[9]="4. razred - vsi";
    $Rubrike14[10]="učenke";
    $Rubrike14[11]="5. razred - vsi";
    $Rubrike14[12]="učenke";
    $Rubrike14[13]="6. razred - vsi";
    $Rubrike14[14]="učenke";
    $Rubrike14[15]="7. razred - vsi";
    $Rubrike14[16]="učenke";
    $Rubrike14[17]="8. razred - vsi";
    $Rubrike14[18]="učenke";
    $Rubrike14[19]="9. razred - vsi";
    $Rubrike14[20]="učenke";
    echo "<b>52. Učenci po letu rojstva in razredih, v programu 9-letne OŠ ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>RAZREDI</th><th>Št.</th><th>Učenci rojeni leta</th>";
    echo "<tr><td align=center></td><td></td><td align=center>Skupaj (2 do 12)</td>";
    for ($Indx=1;$Indx <= 11;$Indx++){
        if ($Indx==1){
            echo "<td>".$LetaRoj[$Indx]." in kasneje</td>";
        }
        if ($Indx==11){
            echo "<td>".$LetaRoj[$Indx]." in prej</td>";
        }
        if (($Indx > 1) && ($Indx < 11)){
            echo "<td>".$LetaRoj[$Indx]."</td>";
        }
    }
    echo "</tr>";
    echo "<tr><td align=center>a</td><td></td>";
    for ($Indx=1;$Indx <= 12;$Indx++){
        echo "<td align=center>".$Indx."</td>";
    }
    echo "</tr>";
    for ($Indx=1;$Indx <= 20;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
        for ($Indx0=1;$Indx0 <= 12;$Indx0++){
            echo "<td align=center>".$CountUcenci2[$Indx][$Indx0]."</td>";
        }
        echo "</tr>";
    }
    echo "</table><br />";
    //Učenci po letu rojstva in razredih, v programu 9-letne OŠ - konec    

    //Učenci, ki ponavljajo razred, po spolu in razredih - začetek
    for ($i=1;$i <= 10;$i++){
        for ($j=1;$j <= 4;$j++){
            $CountUcenci3[$i][$j]=0;
        }
    }
    $result = mysqli_query($link,$SQL);
    $StrRazred="";
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $StrRazred1=$R["razred"].$R["paralelka"];
            if ($R["ponavljalec"] > 0){
                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                }
            }
            switch ($R["razred"]){
            case 1:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[2][4]=$CountUcenci3[2][4]+1;
                    }
                }
                break;
            case 2:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[3][3]=$CountUcenci3[3][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[3][4]=$CountUcenci3[3][4]+1;
                    }
                }
                break;
            case 3:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[4][3]=$CountUcenci3[4][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[4][4]=$CountUcenci3[4][4]+1;
                    }
                }
                break;
            case 4:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[5][3]=$CountUcenci3[5][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[5][4]=$CountUcenci3[5][4]+1;
                    }
                }
                break;
            case 5:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[6][3]=$CountUcenci3[6][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[6][4]=$CountUcenci3[6][4]+1;
                    }
                }
                break;
            case 6:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[7][3]=$CountUcenci3[7][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[7][4]=$CountUcenci3[7][4]+1;
                    }
                }
                break;
            case 7:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[8][3]=$CountUcenci3[8][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[8][4]=$CountUcenci3[8][4]+1;
                    }
                }
                break;
            case 8:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[9][3]=$CountUcenci3[9][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[9][4]=$CountUcenci3[9][4]+1;
                    }
                }
                break;
            case 9:
                if ($R["ponavljalec"] > 0){
                    $CountUcenci3[10][3]=$CountUcenci3[10][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci3[10][4]=$CountUcenci3[10][4]+1;
                    }
                }
            }
        $Indx=$Indx+1;
    }

    $Rubrike14[1]="Vsi";
    $Rubrike14[2]="1. razred";
    $Rubrike14[3]="2. razred";
    $Rubrike14[4]="3. razred";
    $Rubrike14[5]="4. razred";
    $Rubrike14[6]="5. razred";
    $Rubrike14[7]="6. razred";
    $Rubrike14[8]="7. razred";
    $Rubrike14[9]="8. razred";
    $Rubrike14[10]="9. razred";
    echo "<b>53. Učenci, ki ponavljajo razred, po spolu in razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>RAZREDI</th><th>Št.</th><th>9-letna OŠ</th>";
    echo "<tr><td align=center></td><td></td><td align=center>ponavljajo, skupaj</td><td align=center>od tega učenke</td></tr>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td></tr>";
    for ($Indx=1;$Indx <= 10;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
        for ($Indx0=3;$Indx0 <= 4;$Indx0++){
            echo "<td align=center>".$CountUcenci3[$Indx][$Indx0]."</td>";
        }
        echo "</tr>";
    }
    echo "</table><br />";

    //Učenci, ki ponavljajo razred, po spolu in razredih - konec    

    //Učenci po kraju bivanja, po razredih - začetek
    $result = mysqli_query($link,$SQL);
    $StrRazred="";
    for ($Indx=1;$Indx <= 5;$Indx++){
        for ($Indx0=1;$Indx0 <= 3;$Indx0++){
            $CountUcenci4[$Indx][$Indx0]=0;
        }
    }
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $StrRazred1=$R["razred"];
        switch ($R["bivanje"]){
            case 0:
            case 4:
            case 8:
            case 9: //    'doma
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci4[2][2]=$CountUcenci4[2][2]+1;
                        break;
                    default:
                        $CountUcenci4[2][3]=$CountUcenci4[2][3]+1;
                }
                break;
            case 1:
            case 3: //    'pri sorodnikih
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci4[3][2]=$CountUcenci4[3][2]+1;
                        break;
                    default:
                        $CountUcenci4[3][3]=$CountUcenci4[3][3]+1;
                }
                break;
            case 6: //    'v domovih za učence
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci4[4][2]=$CountUcenci4[4][2]+1;
                        break;
                    default:
                        $CountUcenci4[4][3]=$CountUcenci4[4][3]+1;
                }
                break;
            default:  //  'drugje
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci4[5][2]=$CountUcenci4[5][2]+1;
                        break;
                    default:
                        $CountUcenci4[5][3]=$CountUcenci4[5][3]+1;
                }
        }
        $Indx=$Indx+1;
    }
    for ($Indx=2;$Indx <= 5;$Indx++){
        for ($Indx0=2;$Indx0 <= 3;$Indx0++){
            $CountUcenci4[$Indx][1]=$CountUcenci4[$Indx][1]+$CountUcenci4[$Indx][$Indx0];
        }
        $CountUcenci4[1][2]=$CountUcenci4[1][2]+$CountUcenci4[$Indx][2];
        $CountUcenci4[1][3]=$CountUcenci4[1][3]+$CountUcenci4[$Indx][3];
    }
    $CountUcenci4[1][1]=$CountUcenci4[1][2]+$CountUcenci4[1][3];

    $Rubrike14[1]="Skupaj";
    $Rubrike14[2]="Doma";
    $Rubrike14[3]="Pri sorodnikih";
    $Rubrike14[4]="V domovih za učence";
    $Rubrike14[5]="Drugod (npr. rejniške družine)";
    echo "<b>54. Učenci po kraju bivanja, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
    echo "<table border=1>";
    echo "<th>KRAJ BIVANJA</th><th>Št.</th><th>SKUPAJ (2+3)</th><th>1.-6. razred</th><th>7.-9. razred</th>";
    echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td>";
    for ($Indx=1;$Indx <= 5;$Indx++){
        echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
        for ($Indx0=1;$Indx0 <= 3;$Indx0++){
            echo "<td align=center>".$CountUcenci4[$Indx][$Indx0]."</td>";
        }
        echo "</tr>";
    }
    echo "</table><br />";

    //Učenci po kraju bivanja, po razredih - konec    
            
    //'--------------------------------------------------------- Ucenci po razredih in uspehu - zacetek ---------------------------

    //'--------------------------------------------------------- Vzgojni ukrepi - zacetek ---------------------------
    echo "<h2>Vzgojni ukrepi ".$VLeto."/".($VLeto+1)."</h2>";

    for ($Indx=0;$Indx <= 50;$Indx++){
        $razred[$Indx]="";
        for ($Indx0=0;$Indx0 <= 8;$Indx0++){
            $VzgUkrepi[$Indx][$Indx0]=0;
        }
    }

    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 AND idsola=".$sole[$IndxSola][0]." ORDER BY razred,oznaka";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $razred[$Indx]=$R["razred"].". ".$R["oznaka"];
        $Indx=$Indx+1;
    }

    $SQL = "SELECT tabvzgukrepi.idukrep,tabrazred.razred,tabrazred.paralelka FROM (tabvzgukrepi ";
    $SQL .= "INNER JOIN tabrazred ON tabvzgukrepi.IdUcenec=tabrazred.IdUcenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL .= "WHERE tabvzgukrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL .= " ORDER BY tabrazred.Razred,tabrazred.Paralelka";
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        for ($Indx=1;$Indx <= 50;$Indx++){
            if ($razred[$Indx]==$R["razred"].". ".$R["paralelka"]){
                switch ($R["idukrep"]){
                    case 1:
                        $VzgUkrepi[$Indx][1]=$VzgUkrepi[$Indx][1]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][1]=$VzgUkrepi[0][1]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        break;
                    case 2:
                        $VzgUkrepi[$Indx][2]=$VzgUkrepi[$Indx][2]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][2]=$VzgUkrepi[0][2]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        break;
                    case 3:
                        $VzgUkrepi[$Indx][3]=$VzgUkrepi[$Indx][3]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][3]=$VzgUkrepi[0][3]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        break;
                    case 4:
                        $VzgUkrepi[$Indx][4]=$VzgUkrepi[$Indx][4]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][4]=$VzgUkrepi[0][4]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        break;
                    case 5:
                        $VzgUkrepi[$Indx][5]=$VzgUkrepi[$Indx][5]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][5]=$VzgUkrepi[0][5]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        break;
                    case 6:
                        $VzgUkrepi[$Indx][6]=$VzgUkrepi[$Indx][6]+1;
                        $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                        $VzgUkrepi[0][6]=$VzgUkrepi[0][6]+1;
                        $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                }
            }
        }
    }

    echo "<table border=1 cellspacing=0>";
    echo "<tr bgcolor=cyan><th>Razred</th><th>I.</th><th>II.</th><th>III.</th><th>Skupaj</th></tr>";
    $i1=0;
    for ($Indx=1;$Indx <= 50;$Indx++){
        if (strlen($razred[$Indx]) > 0){
            echo "<tr bgcolor='lightyellow'>";
            echo "<td align=center bgcolor=khaki>".$razred[$Indx]."</td>";
            echo "<td align=center>".$VzgUkrepi[$Indx][1]."</td>";
            echo "<td align=center>".$VzgUkrepi[$Indx][2]."</td>";
            echo "<td align=center>".$VzgUkrepi[$Indx][3]."</td>";
            echo "<td align=center>".$VzgUkrepi[$Indx][0]."</td>";
            echo "</tr>";
            $aMonthValues[$i1]=$VzgUkrepi[$Indx][0];
            $aMonthNames[$i1]=$razred[$Indx];
            $i1=$i1+1;
        }
    }
    echo "<tr bgcolor='lightgreen'>";
    echo "<td align=center>Skupaj</td>";
    echo "<td align=center>".$VzgUkrepi[0][1]."</td>";
    echo "<td align=center>".$VzgUkrepi[0][2]."</td>";
    echo "<td align=center>".$VzgUkrepi[0][3]."</td>";
    echo "<td align=center>".$VzgUkrepi[0][0]."</td>";
    echo "</tr>";
    echo "</table><br />";

    //'--------------------------------------------------------- Vzgojni ukrepi - konec ---------------------------

    //'-----------------------Tabori - začetek
    $SQL = "SELECT tabtabordata.* FROM tabtabordata ";
    $SQL .= "INNER JOIN tabrazdat ON tabtabordata.idrazred=tabrazdat.id ";
    $SQL .= "WHERE tabtabordata.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL .= " ORDER BY tabtabordata.razred,tabtabordata.paralelka";
    $result = mysqli_query($link,$SQL);

    if (mysqli_num_rows($result) > 0){
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $TaborDat[$Indx][1]=$R["razred"].". ".$R["paralelka"];
            $TaborDat[$Indx][2]=$R["DatumZac"]." - ".$R["DatumKon"];
            $TaborDat[$Indx][3]=$R["Kraj"];
            $TaborDat[$Indx][4]=$R["Vrsta"];
            $TaborDat[$Indx][5]=$R["Znesek"];
            $TaborDat[$Indx][6]=$R["razred"];
            $TaborDat[$Indx][7]=$R["paralelka"];
            $TaborDat[$Indx][8]=$R["DatumZac"];
            $TaborDat[$Indx][9]=$R["DatumKon"];
            $TaborDat[$Indx][10]=$R["leto"];
            $TaborDat[$Indx][11]=$R["idRazred"];
            $Indx=$Indx+1;
        }
        $StRazredov=$Indx-1;

        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            $countT[$Indx][0]=0;
            $countT[$Indx][1]=0;
            $countT[$Indx][2]=0;
            $countT[$Indx][3]=0;
            $countT[$Indx][4]=0;
            $countT[$Indx][5]=0;
        }

        $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabtabori.* FROM ";
        $SQL = $SQL."(tabrazred INNER JOIN tabtabori ON tabrazred.idUcenec=tabtabori.idUcenec) ";
        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL = $SQL ."WHERE tabrazred.leto=".$VLeto." AND tabtabori.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
        $SQL = $SQL ." ORDER BY tabrazred.razred,tabrazred.paralelka";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        $CompRazred=$TaborDat[$Indx][1];
        while ($R = mysqli_fetch_array($result)){
            $VRazred=$R["razred"].". ".$R["paralelka"];
            if ($VRazred != $CompRazred){
                $Indx=$StRazredov+1;
                for ($i1=1;$i1 <= $StRazredov;$i1++){
                    if ($VRazred==$TaborDat[$i1][1]){
                        $Indx=$i1;
                    }
                }
                $countT[$Indx][0]=$VRazred;
                if ($R["Udelezba"]){    $countT[$Indx][1]=1;}
                if ($R["Brezplacno"]){    $countT[$Indx][3]=1;}
                if ($R["Subvencija"]){    $countT[$Indx][4]=1;}
                $countT[$Indx][5]=1;
                $CompRazred=$VRazred;
            }else{
                if ($R["Udelezba"]){    $countT[$Indx][1]=$countT[$Indx][1]+1;}
                if ($R["Brezplacno"]){    $countT[$Indx][3]=$countT[$Indx][3]+1;}
                if ($R["Subvencija"]){    $countT[$Indx][4]=$countT[$Indx][4]+1;}
                $countT[$Indx][5]=$countT[$Indx][5]+1;
            }
        }

        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            $countT[$Indx][2]=$countT[$Indx][5]-$countT[$Indx][1];
        }

        for ($Indx=1;$Indx <= 5;$Indx++){
            $CountSum[$Indx]=0;
        }

        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            $CountSum[1]=$CountSum[1]+$countT[$Indx][1];
            $CountSum[2]=$CountSum[2]+$countT[$Indx][2];
            $CountSum[3]=$CountSum[3]+$countT[$Indx][3];
            $CountSum[4]=$CountSum[4]+$countT[$Indx][4];
            $CountSum[5]=$CountSum[5]+$countT[$Indx][5];
        }

        echo "<h2>Šola v naravi/Tabori - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr bgcolor=lightcyan><th>Razred</th><th>Datum</th><th>Kraj</th><th>Vrsta</th><th>udeležencev</th><th>niso se udeležili</th><th>znesek plačila</th><th>Brezplačnih</th><th>Subvencij</th></tr>";
        for ($Indx=1;$Indx <= $StRazredov;$Indx++){
            echo "<tr bgcolor=lightyellow>";
            echo "<td align=center bgcolor=khaki><a href='vnosispiski.php?idd=112&solskoleto=".$VLeto."&razred=".$TaborDat[$Indx][11]."'>".$TaborDat[$Indx][1]."</a></td>";
            echo "<td align=center>".$TaborDat[$Indx][2]."</td>";
            echo "<td align=center>".$TaborDat[$Indx][3]."</td>";
            echo "<td align=center>".$TaborDat[$Indx][4]."</td>";
            echo "<td align=center>".$countT[$Indx][1]."</td>";
            echo "<td align=center>".$countT[$Indx][2]."</td>";
            echo "<td align=center>".number_format($TaborDat[$Indx][5],2)."</td>";
            echo "<td align=center>".$countT[$Indx][3]."</td>";
            echo "<td align=center>".$countT[$Indx][4]."</td>";
            //echo "<td><a href='vnosispiski.php?idd=113&id=2&kraj=".$TaborDat[$Indx][3]."&zacetek=".$TaborDat[$Indx][8]."&konec=".$TaborDat[$Indx][9]."&leto=".$TaborDat[$Indx][10]."'>Spisek</a></td>";
            echo "</tr>";
        }
        echo "<tr bgcolor=lightgreen><td>Skupaj</td>";
        echo "<td></td>";
        echo "<td></td>";
        echo "<td></td>";
        echo "<td align=center>".$CountSum[1]."</td>";
        echo "<td align=center>".$CountSum[2]."</td>";
        echo "<td></td>";
        echo "<td align=center>".$CountSum[3]."</td>";
        echo "<td align=center>".$CountSum[4]."</td>";
        echo "</tr>";
        echo "</table><br />";
    }
    //'-----------------------Tabori - konec

    //'------------------------------Prehrana - začetek
    for ($i=0;$i < 50;$i++){
        for ($j=0;$j < 10;$j++){
            $countT[$i][$j]=0;
        }
    }
        
    $SQL = "SELECT tabprehrana.*,tabrazdat.*,tabrazdat.id AS rid FROM ";
    $SQL = $SQL . "(tabrazred INNER JOIN tabprehrana ON tabrazred.idUcenec=tabprehrana.idUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabprehrana.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    $Indx=0;
    $CompRazred="";
    while ($R = mysqli_fetch_array($result)){
        $VRazred=$R["razred"].". ".$R["oznaka"];
        if ($VRazred != $CompRazred){
            $Indx=$Indx+1;
            $countT[$Indx][0]=$VRazred;
            $countT[$Indx][7]=$R["razred"];
            $countT[$Indx][8]=$R["oznaka"];
            $countT[$Indx][9]=$R["rid"];
            if ($R["zajtrk"]){    $countT[$Indx][1]=1;}
            if ($R["malica"]){    $countT[$Indx][2]=1;}
            if ($R["kosilo"]){    $countT[$Indx][3]=1;}
            if ($R["popmalica"]){    $countT[$Indx][4]=1;}
            if ($R["regresmalica"]){    $countT[$Indx][5]=1;}
            if ($R["regreskosilo"]){    $countT[$Indx][6]=1;}
            $CompRazred=$VRazred;
        }else{
            if ($R["zajtrk"]){    $countT[$Indx][1]=$countT[$Indx][1]+1;}
            if ($R["malica"]){    $countT[$Indx][2]=$countT[$Indx][2]+1;}
            if ($R["kosilo"]){    $countT[$Indx][3]=$countT[$Indx][3]+1;}
            if ($R["popmalica"]){    $countT[$Indx][4]=$countT[$Indx][4]+1;}
            if ($R["regresmalica"]){    $countT[$Indx][5]=$countT[$Indx][5]+1;}
            if ($R["regreskosilo"]){    $countT[$Indx][6]=$countT[$Indx][6]+1;}
        }
    }
    $StRazredov=$Indx;

    for ($Indx=1;$Indx <= 6;$Indx++){
        $CountSum[$Indx]=0;
    }

    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        $CountSum[1]=$CountSum[1]+$countT[$Indx][1];
        $CountSum[2]=$CountSum[2]+$countT[$Indx][2];
        $CountSum[3]=$CountSum[3]+$countT[$Indx][3];
        $CountSum[4]=$CountSum[4]+$countT[$Indx][4];
        $CountSum[5]=$CountSum[5]+$countT[$Indx][5];
        $CountSum[6]=$CountSum[6]+$countT[$Indx][6];
    }

    echo "<h2>Prehrana - ".$VLeto."/".($VLeto+1)."</h2>";
    echo "<table border=1 cellspacing=0>";
    echo "<tr bgcolor=lightcyan><th>Razred</th><th>zajtrk</th><th>malica</th><th>kosilo</th><th>pop. malica</th><th>št. subv. malic</th><th>št. subv. kosil</th></tr>";
    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
        echo "<tr bgcolor=lightyellow>";
        for ($i1=0;$i1 <= 6;$i1++){
            if ($i1==0){
                echo "<td align=center bgcolor=khaki><a href='vnosispiski.php?idd=105&solskoleto=".$VLeto."&razred=".$countT[$Indx][9]."'>".$countT[$Indx][$i1]."</a></td>";
            }else{
                echo "<td align=center>".$countT[$Indx][$i1]."</td>";
            }
        }
        echo "</tr>";
    }
    echo "<tr bgcolor=lightgreen><td>Skupaj</td>";
    for ($Indx=1;$Indx <= 6;$Indx++){
        echo "<td align=center>".$CountSum[$Indx]."</td>";
    }
    echo "</tr>";
    echo "</table><br />";

    //'------------------------------Prehrana - konec

    //'------------------------------Odsotnost - začetek
    echo "<h3>Odsotnost na nivoju šole - ".$VLeto."/".($VLeto+1)."</h3>";
    echo "Opravičene ure<br />";
    $SQL = "SELECT tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.opraviceno) AS countn,tabrazred.leto,tabrazdat.idsola FROM (tabprisotnost ";
    $SQL .= "INNER JOIN tabrazred ON tabprisotnost.iducenec=tabrazred.iducenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL .= "GROUP BY tabprisotnost.leto,tabprisotnost.mesec,tabrazred.leto,tabrazdat.idsola ";
    $SQL .= "HAVING tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $result = mysqli_query($link,$SQL);

    $aMonthNames=null;

    $VSum=0;
    for ($Indx=0;$Indx <= 11;$Indx++){
        if ($Indx < 8){
            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
        }else{
            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
        }
        $aMonthValues[$Indx]=0;
    }

    while ($R = mysqli_fetch_array($result)){
        $VSum=$VSum+$R["countn"];
        if ($R["mesec"] < 8){
            $aMonthValues[$R["mesec"]+3]=$R["countn"];
        }else{
            $aMonthValues[$R["mesec"]-9]=$R["countn"];
        }
    }
    displayverticalgraph ("Opravičena odsotnost - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);

    echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";

    echo "<br />Neopravičene ure<br />";

    $SQL = "SELECT leto,mesec,sum(neopraviceno) AS countn FROM tabprisotnost GROUP BY leto,mesec HAVING leto=".$VLeto;
    $result = mysqli_query($link,$SQL);

    for ($Indx=0;$Indx <= 11;$Indx++){
        if ($Indx < 8){
            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
        }else{
            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
        }
        $aMonthValues[$Indx]=0;
    }

    $VSum=0;
    while ($R = mysqli_fetch_array($result)){
        $VSum=$VSum+$R["countn"];
        if ($R["mesec"] < 8){
            $aMonthValues[$R["mesec"]+3]=$R["countn"];
        }else{
            $aMonthValues[$R["mesec"]-9]=$R["countn"];
        }
    }
    displayverticalgraph ("Neopravičena odsotnost - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);

    echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";

    //'------------------------------Odsotnost - konec

    //'--------------------------------------------------------- Statistika zaposlenih - zacetek ---------------------------
        //inicializacija polj
        for ($i=0;$i <= 14;$i++){
            for($j=0;$j <= 14;$j++){
                $Count16[$i][$j]=0;
                $Count17[$i][$j]=0;
                $Count18[$i][$j]=0;
                $Count19[$i][$j]=0;
                $Count20[$i][$j]=0;
            }
        }
        for ($i=0;$i <= 400;$i++){
            for($j=0;$j <= 14;$j++){
                $DelPog[$i][$j]="";
                $Delavec[$i][$j]="";
            }
        }

        $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabucitelji.letoroj,tabucitelji.izobrazba,tabucitelji.spol, TabStatus.status FROM ";
        $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
        //$SQL = $SQL . "WHERE tabucitelji.Status IN (1,2,3,4,5,6)";
        $SQL = $SQL . "WHERE tabucitelji.Status < 10 ";
        $SQL = $SQL . " ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Delavec[$Indx][0]=$R["iducitelj"];
            $Delavec[$Indx][1]=$R["priimek"]." ".$R["ime"];
            $Delavec[$Indx][2]=$R["letoroj"];
            $Delavec[$Indx][3]=$R["izobrazba"];
            $Delavec[$Indx][7]=$R["status"];
            $Delavec[$Indx][11]=$R["spol"];
            $Indx=$Indx+1;
        }
        $StDelavcev=$Indx-1;

        echo "Število delavcev ".$StDelavcev."<br />";

        $DatumPreveri=new DateTime(($VLeto+1)."-06-30");
        echo "<h2>Statistika zaposlenih na ".$DatumPreveri->format('d.m.Y')."</h2>";
        for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
            //'gleda glavne pogodbe (z večjim deležem, če so enaki, vzame prvega)
            $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$Delavec[$Indx][0]." ORDER BY UrTeden DESC";
            $result = mysqli_query($link,$SQL);
            $i2=1;
            while ($R = mysqli_fetch_array($result)){
                if (isDate($R["DatumStart"]) ){
                    $Datum=new DateTime(isDate($R["DatumStart"]));
                    $DelPog[$i2][2]=$Datum->format('d.m.Y');
                }else{
                    //$DelPog[$i2][2]=$DatumPreveri->format('d.m.Y');
                    //če nima vpisanega začetka pogodbe, ga vzame kot, da je to danes
                    $DelPog[$i2][2]=$Danes->format('d.m.Y');
                }
                if (isDate($R["DatumEnd"])) {
                    $Datum=new DateTime(isDate($R["DatumEnd"]));
                    $DelPog[$i2][3]=$Datum->format('d.m.Y');
                }else{
                    $DelPog[$i2][3]=$DatumPreveri->format('d.m.Y');
                }
                $DatumStart=new DateTime(isDate($DelPog[$i2][2]));
                $DatumEnd=new DateTime(isDate($DelPog[$i2][3]));
                $Interval1=$DatumStart->diff($DatumPreveri);
                $Interval2=$DatumEnd->diff($DatumPreveri);
                if (($Interval1->invert == 0) && (($Interval2->invert > 0) or (($Interval2->invert ==0) && ($Interval2->days==0)))){
                    $DelPog[$i2][1]=1;
                    $DelPog[$i2][0]=$R["UrTeden"];
                    
        //'                $DelPog[$i2][4]=$R["SkupinaDela"]
        //'                $DelPog[$i2][5]=$R["OpisDela"]
        //'                $DelPog[$i2][6]=$R["VzgojnoDelo"]
                    $DelPog[$i2][8]=$R["DelovniCas"];
                    $DelPog[$i2][9]=$DelPog[$i2][2];
                    $DelPog[$i2][10]=$DelPog[$i2][3];
                    $DelPog[$i2][12]=$R["IdDelo"];
                    $DelPog[$i2][13]=$R["IzobUstr"];
                }else{
                    $i2=$i2-1;
                }
                $i2=$i2+1;
            }
            $StDelPogodba=$i2-1;
            
            if ($StDelPogodba > 0 ){
        //'        $Delavec[$Indx,4)=$DelPog[1,4)    'SkupinaDela
        //'        $Delavec[$Indx,5)=$DelPog[1,5)    'OpisDela
        //'        $Delavec[$Indx,6)=$DelPog[1,6)    'VzgojnoDelo
                $Delavec[$Indx][8]=$DelPog[1][8];    //'DelovniCas
                $Delavec[$Indx][9]=$DelPog[1][9];    //'DatumStart
                $Delavec[$Indx][10]=$DelPog[1][10];    //'DatumEnd
                $Delavec[$Indx][12]=$DelPog[1][12];    //'IdDelo
                $Delavec[$Indx][13]=$DelPog[1][13];    //'IzobUstr
            }
            
            //'pogleda ure, ki jih delavci učijo v določenih razredih - redne in izbirne predmete
            $SQL = "SELECT tabucenje.*,tabpredmeti.* FROM tabucenje ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE leto=".$VLeto." AND idUcitelj=".$Delavec[$Indx][0]." AND prioriteta IN (0,1)";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                switch ($R["Razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $Count16[3][4]=$Count16[3][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count16[4][4]=$Count16[4][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        }
                        break;
                    case 7:
                    case 8:
                    case 9:
                        $Count16[5][4]=$Count16[5][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count16[6][4]=$Count16[6][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        }
                }
            }
            
            //'pogleda ure, ki jih delavci učijo v določenih razredih - OPB
            $SQL = "SELECT tabucenje.*,tabpredmeti.* FROM tabucenje ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE leto=".$VLeto." AND idUcitelj=".$Delavec[$Indx][0]." AND oznaka IN ('OPB','PB01','PB02','PB03','PB04','PB05','PB06','PB07','PB08','PB09','PB10','PB11','PB12','PB13','PB14')";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $Count16[7][4]=$Count16[7][4]+$R["Planirano"]/$ObremenitevPB;
                if ($Delavec[$Indx][11]=="F" ){
                    $Count16[8][4]=$Count16[8][4]+$R["Planirano"]/$ObremenitevPB;
                }
            }
            
        //'    VDelovniCas=$Delavec[$Indx,8)  '1-krajši
        /*    VZacDela=$Delavec[$Indx,9)
            if VZacDela ="" ){
                VZacDela=Danes
            }
            VKonecDela=$Delavec[$Indx,10)
            if VKonecDela="" ){
                VkonecDela="31.12.".$VLeto+1
            }
        */    
            if ($StDelPogodba > 0 ){
                //'i1=i1+1
                switch ($Delavec[$Indx][12]){  //iddelo
                    case 1:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[4][1]=$Count16[4][1]+1;
                                $Count16[4][3]=$Count16[4][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[3][1]=$Count16[3][1]+1;
                            $Count16[3][3]=$Count16[3][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[4][1]=$Count16[4][1]+1;
                                $Count16[4][2]=$Count16[4][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[3][1]=$Count16[3][1]+1;
                            $Count16[3][2]=$Count16[3][2]+1;
                        }
                        break;
                    case 2:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[6][1]=$Count16[6][1]+1;
                                $Count16[6][3]=$Count16[6][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[5][1]=$Count16[5][1]+1;
                            $Count16[5][3]=$Count16[5][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[6][1]=$Count16[6][1]+1;
                                $Count16[6][2]=$Count16[6][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[5][1]=$Count16[5][1]+1;
                            $Count16[5][2]=$Count16[5][2]+1;
                        }
                        break;
                    case 3:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[8][1]=$Count16[8][1]+1;
                                $Count16[8][3]=$Count16[8][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[7][1]=$Count16[7][1]+1;
                            $Count16[7][3]=$Count16[7][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[8][1]=$Count16[8][1]+1;
                                $Count16[8][2]=$Count16[8][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[7][1]=$Count16[7][1]+1;
                            $Count16[7][2]=$Count16[7][2]+1;
                        }
                        break;
                    case 4:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[10][1]=$Count16[10][1]+1;
                                $Count16[10][3]=$Count16[10][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[9][1]=$Count16[9][1]+1;
                            $Count16[9][3]=$Count16[9][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[10][1]=$Count16[10][1]+1;
                                $Count16[10][2]=$Count16[10][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[9][1]=$Count16[9][1]+1;
                            $Count16[9][2]=$Count16[9][2]+1;
                        }
                        break;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[12][1]=$Count16[12][1]+1;
                                $Count16[12][3]=$Count16[12][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[11][1]=$Count16[11][1]+1;
                            $Count16[11][3]=$Count16[11][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[12][1]=$Count16[12][1]+1;
                                $Count16[12][2]=$Count16[12][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[11][1]=$Count16[11][1]+1;
                            $Count16[11][2]=$Count16[11][2]+1;
                        }
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[14][1]=$Count16[14][1]+1;
                                $Count16[14][3]=$Count16[14][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[13][1]=$Count16[13][1]+1;
                            $Count16[13][3]=$Count16[13][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[14][1]=$Count16[14][1]+1;
                                $Count16[14][2]=$Count16[14][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[13][1]=$Count16[13][1]+1;
                            $Count16[13][2]=$Count16[13][2]+1;
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 1:  // učitelj I in II triada
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    //}
                                    break;
                                case 5: //srednja
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][3]=$Count17[4][3]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                                    */
                                    break;
                                case 6: //višja
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][4]=$Count17[4][4]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                                    break;
                                default: //visoka
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][5]=$Count17[4][5]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){    //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                //}
                                break;
                            case 5: //srednja
                                //if ($Delavec[$Indx][13]==1 ){   //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][3]=$Count17[3][3]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                                */
                                break;
                            case 6: //višja
                                if ($Delavec[$Indx][13]==1 ){  //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][4]=$Count17[3][4]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                                break;
                            default: //visoka
                                if ($Delavec[$Indx][13]==1 ){  //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][5]=$Count17[3][5]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                        }
                        break;
                    case 2:  //učitelj III. triada
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][3]=$Count17[6][3]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][4]=$Count17[6][4]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][5]=$Count17[6][5]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            //if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            //}
                            break;
                        case 5:
                            //if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                                /*
                            }else{
                                $Count17[1][3]=$Count17[1][3]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][3]=$Count17[5][3]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                            */
                            break;
                        case 6:
                            if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }else{
                                $Count17[1][4]=$Count17[1][4]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][4]=$Count17[5][4]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                            break;
                        default:
                            if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }else{
                                $Count17[1][5]=$Count17[1][5]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][5]=$Count17[5][5]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                        }
                        break;
                    case 3: //PB
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][3]=$Count17[8][3]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][4]=$Count17[8][4]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][5]=$Count17[8][5]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][3]=$Count17[7][3]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][4]=$Count17[7][4]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                                break;
                            case 7:
                            case 8:
                            case 9:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][5]=$Count17[7][5]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                        }
                        break;
                    case 4:  //vodstveni
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][3]=$Count17[10][3]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][4]=$Count17[10][4]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][5]=$Count17[10][5]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][3]=$Count17[9][3]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][4]=$Count17[9][4]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][5]=$Count17[9][5]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                        }
                        break;
                    case 5: //pedagog
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 6: //psiholog
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 7: //socialni del.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 8: //specialni ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 9: //soc. ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 10: //drugi
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][3]=$Count17[12][3]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][4]=$Count17[12][4]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][5]=$Count17[12][5]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 11: //mob. spec. ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    breka;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 12: //knjiž.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 13: //ROID
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 14: //org. prehrana
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 15: //drugi strok. del.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 5:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][2]=$Count18[2][2]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][2]=$Count18[1][2]+1;
                        break;
                    case 6:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][3]=$Count18[2][3]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][3]=$Count18[1][3]+1;
                        break;
                    case 7:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][4]=$Count18[2][4]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][4]=$Count18[1][4]+1;
                        break;
                    case 8:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][5]=$Count18[2][5]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][5]=$Count18[1][5]+1;
                        break;
                    case 9:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][6]=$Count18[2][6]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][6]=$Count18[1][6]+1;
                        break;
                    case 10:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][7]=$Count18[2][7]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][7]=$Count18[1][7]+1;
                        break;
                    case 11:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][9]=$Count18[2][9]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][9]=$Count18[1][9]+1;
                        break;
                    case 12:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][10]=$Count18[2][10]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][10]=$Count18[1][10]+1;
                        break;
                    case 13:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][11]=$Count18[2][11]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][11]=$Count18[1][11]+1;
                        break;
                    case 14:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][12]=$Count18[2][12]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][12]=$Count18[1][12]+1;
                        break;
                    case 15:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][13]=$Count18[2][13]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][13]=$Count18[1][13]+1;
                }
                
                switch ($Delavec[$Indx][12]){
                    case 1:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][2]=$Count19[4][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][2]=$Count19[3][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][3]=$Count19[4][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][3]=$Count19[3][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][4]=$Count19[4][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][4]=$Count19[3][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][5]=$Count19[4][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][5]=$Count19[3][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][6]=$Count19[4][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][6]=$Count19[3][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][7]=$Count19[4][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][7]=$Count19[3][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][8]=$Count19[4][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][8]=$Count19[3][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][9]=$Count19[4][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][9]=$Count19[3][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][10]=$Count19[4][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][10]=$Count19[3][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][11]=$Count19[4][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][11]=$Count19[3][11]+1;
                        }
                        break;
                    case 2:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][2]=$Count19[6][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][2]=$Count19[5][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][3]=$Count19[6][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][3]=$Count19[5][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][4]=$Count19[6][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][4]=$Count19[5][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][5]=$Count19[6][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][5]=$Count19[5][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][6]=$Count19[6][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][6]=$Count19[5][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][7]=$Count19[6][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][7]=$Count19[5][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][8]=$Count19[6][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][8]=$Count19[5][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][9]=$Count19[6][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][9]=$Count19[5][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][10]=$Count19[6][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][10]=$Count19[5][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][11]=$Count19[6][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][11]=$Count19[5][11]+1;
                        }
                        break;
                    case 3:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][2]=$Count19[8][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][2]=$Count19[7][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][3]=$Count19[8][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][3]=$Count19[7][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][4]=$Count19[8][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][4]=$Count19[7][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][5]=$Count19[8][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][5]=$Count19[7][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][6]=$Count19[8][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][6]=$Count19[7][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][7]=$Count19[8][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][7]=$Count19[7][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][8]=$Count19[8][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][8]=$Count19[7][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][9]=$Count19[8][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][9]=$Count19[7][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][10]=$Count19[8][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][10]=$Count19[7][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][11]=$Count19[8][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][11]=$Count19[7][11]+1;
                        }
                        break;
                    case 4:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][2]=$Count19[10][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][2]=$Count19[9][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][3]=$Count19[10][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][3]=$Count19[9][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][4]=$Count19[10][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][4]=$Count19[9][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][5]=$Count19[10][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][5]=$Count19[9][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][6]=$Count19[10][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][6]=$Count19[9][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][7]=$Count19[10][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][7]=$Count19[9][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][8]=$Count19[10][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][8]=$Count19[9][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][9]=$Count19[10][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][9]=$Count19[9][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][10]=$Count19[10][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][10]=$Count19[9][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][11]=$Count19[10][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][11]=$Count19[9][11]+1;
                        }
                        break;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][2]=$Count19[12][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][2]=$Count19[11][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][3]=$Count19[12][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][3]=$Count19[11][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][4]=$Count19[12][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][4]=$Count19[11][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][5]=$Count19[12][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][5]=$Count19[11][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][6]=$Count19[12][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][6]=$Count19[11][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][7]=$Count19[12][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][7]=$Count19[11][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][8]=$Count19[12][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][8]=$Count19[11][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][9]=$Count19[12][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][9]=$Count19[11][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][10]=$Count19[12][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][10]=$Count19[11][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][11]=$Count19[12][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][11]=$Count19[11][11]+1;
                        }
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][2]=$Count19[14][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][2]=$Count19[13][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][3]=$Count19[14][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][3]=$Count19[13][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][4]=$Count19[14][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][4]=$Count19[13][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][5]=$Count19[14][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][5]=$Count19[13][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][6]=$Count19[14][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][6]=$Count19[13][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][7]=$Count19[14][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][7]=$Count19[13][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][8]=$Count19[14][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][8]=$Count19[13][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][9]=$Count19[14][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][9]=$Count19[13][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][10]=$Count19[14][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][10]=$Count19[13][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][11]=$Count19[14][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][11]=$Count19[13][11]+1;
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 16:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][4]=$Count20[1][4]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][3]=$Count20[1][3]+1;
                        break;
                    case 17:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][6]=$Count20[1][6]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][5]=$Count20[1][5]+1;
                        break;
                    case 18:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][8]=$Count20[1][8]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][7]=$Count20[1][7]+1;
                }
            }
        }

            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="od tega ženske";
            $Rubrike14[3]="Učitelji v I. in II. triadi 9-letne OŠ";
            $Rubrike14[4]="od tega ženske";
            $Rubrike14[5]="Učitelji v III. triadi 9-letne OŠ";
            $Rubrike14[6]="od tega ženske";
            $Rubrike14[7]="Učitelji v oddelkih PB - vsi";
            $Rubrike14[8]="od tega ženske";
            $Rubrike14[9]="Vodstveni delavci - vsi";
            $Rubrike14[10]="od tega ženske";
            $Rubrike14[11]="Svetovalni delavci - vsi";
            $Rubrike14[12]="od tega ženske";
            $Rubrike14[13]="Drugi strokovni delavci - vsi";
            $Rubrike14[14]="od tega ženske";
            echo "<b>15. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po delovnem razmerju ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Skupaj</th><th>Polni delovni čas</th><th>Krajši delovni čas</th><th>Ekvivalent polnega delovnega časa</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                if ($Count16[$Indx][4] > 0 ){
                    echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count16[$Indx][1]."</td><td align=center>".$Count16[$Indx][2]."</td><td align=center>".$Count16[$Indx][3]."</td><td align=center>".number_format($Count16[$Indx][4],1)."</td></tr>";
                }else{
                    echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count16[$Indx][1]."</td><td align=center>".$Count16[$Indx][2]."</td><td align=center>".$Count16[$Indx][3]."</td><td align=center>".$Count16[$Indx][4]."</td></tr>";
                }    
            }
            echo "</table><br />";

            
            echo "<b>16. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po izobrazbi ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Skupaj (2+6)</th><th>Skupaj (3+4+5)</th><th>S srednjo izobrazbo</th><th>Z višjo</th><th>Z visoko</th><th>Z neustrezno</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count17[$Indx][1]."</td><td align=center>".$Count17[$Indx][2]."</td><td align=center>".$Count17[$Indx][3]."</td><td align=center>".$Count17[$Indx][4]."</td><td align=center>".$Count17[$Indx][5]."</td><td align=center>".$Count17[$Indx][6]."</td></tr>";
            }
            echo "</table><br />";

        //'Svetovalni in drugi strokovni delavec - zacetek

            echo "<b>17. Svetovalni in drugi strokovni delavci ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Vsi (2-7)</th><th>pedagog</th><th>psiholog</th><th>socialni delavec</th><th>specialni pedagog</th><th>socialni pedagog</th><th>drugi</th><th>Vsi (9-13)</th><th>mobilni specialni pedagog</th><th>knjižničar</th><th>organizator informacijske dejavnosti</th><th>organizator prehrane</th><th>drugi</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td><td align=center>11</td><td align=center>12</td><td align=center>13</td></tr>";
            for ($Indx=1;$Indx <= 2;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count18[$Indx][1]."</td><td align=center>".$Count18[$Indx][2]."</td><td align=center>".$Count18[$Indx][3]."</td><td align=center>".$Count18[$Indx][4]."</td>";
                echo "<td align=center>".$Count18[$Indx][5]."</td>";
                echo "<td align=center>".$Count18[$Indx][6]."</td>";
                echo "<td align=center>".$Count18[$Indx][7]."</td>";
                echo "<td align=center>".$Count18[$Indx][8]."</td>";
                echo "<td align=center>".$Count18[$Indx][9]."</td>";
                echo "<td align=center>".$Count18[$Indx][10]."</td>";
                echo "<td align=center>".$Count18[$Indx][11]."</td>";
                echo "<td align=center>".$Count18[$Indx][12]."</td>";
                echo "<td align=center>".$Count18[$Indx][13]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //'Svetovalni in drugi strokovni delavci - konec    
            
            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="od tega ženske";
            $Rubrike14[3]="Učitelji v I. in II. triadi 9-letne OŠ";
            $Rubrike14[4]="od tega ženske";
            $Rubrike14[5]="Učitelji v III. triadi 9-letne OŠ";
            $Rubrike14[6]="od tega ženske";
            $Rubrike14[7]="Učitelji v oddelkih PB - vsi";
            $Rubrike14[8]="od tega ženske";
            $Rubrike14[9]="Vodstveni delavci - vsi";
            $Rubrike14[10]="od tega ženske";
            $Rubrike14[11]="Svetovalni delavci - vsi";
            $Rubrike14[12]="od tega ženske";
            $Rubrike14[13]="Drugi strokovni delavci - vsi";
            $Rubrike14[14]="od tega ženske";
            echo "<b>18. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po starostnih razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Vsi [2-11]</th><th>Mlajši od 25 let</th><th>25-29 let</th><th>30-34 let</th><th>35-39 let</th><th>40-44 let</th><th>45-49 let</th><th>50-54 let</th><th>55-59 let</th><th>60-64 let</th><th>65 let in starejši</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td><td align=center>11</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count19[$Indx][1]."</td><td align=center>".$Count19[$Indx][2]."</td><td align=center>".$Count19[$Indx][3]."</td><td align=center>".$Count19[$Indx][4]."</td><td align=center>".$Count19[$Indx][5]."</td><td align=center>".$Count19[$Indx][6]."</td><td align=center>".$Count19[$Indx][7]."</td><td align=center>".$Count19[$Indx][8]."</td><td align=center>".$Count19[$Indx][9]."</td><td align=center>".$Count19[$Indx][10]."</td><td align=center>".$Count19[$Indx][11]."</td></tr>";
            }
            echo "</table><br />";

        //'Drugi svetovalni delavci - zacetek

            echo "<b>19. Drugi zaposleni delavci ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Drugi zaposleni</th><th>Št.</th><th>Vsi (3+5+7)</th><th>Ženske (4+6+8)</th><th>Administrativni in računovodski delavci</th><th></th><th>Tehnični delavci</th><th></th><th>Drugi delavci</th><th></th>";
            echo "<tr><td align=center></td><td></td><td align=center></td><td align=center></td><td align=center>skupaj</td><td align=center>ženske</td><td align=center>skupaj</td><td align=center>ženske</td><td align=center>skupaj</td><td align=center>ženske</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td></tr>";
            $Indx=1;
            echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
            echo "<td align=center>".$Count20[$Indx][1]."</td>";
            echo "<td align=center>".$Count20[$Indx][2]."</td>";
            echo "<td align=center>".$Count20[$Indx][3]."</td>";
            echo "<td align=center>".$Count20[$Indx][4]."</td>";
            echo "<td align=center>".$Count20[$Indx][5]."</td>";
            echo "<td align=center>".$Count20[$Indx][6]."</td>";
            echo "<td align=center>".$Count20[$Indx][7]."</td>";
            echo "<td align=center>".$Count20[$Indx][8]."</td>";
            echo "</tr>";
            echo "</table><br />";
    //'Drugi zaposleni delavci - konec    


    //inicializacija polj
    for ($i=0;$i <= 300;$i++){
        $SkupinaDela[$i]=0;
        $VzgDelo[$i]=0;
        $Delo[$i]=0;
        for($j=0;$j <= 30;$j++){
            $IzobrazbaSkupina[$i][$j]=0;
            $IzobrazbaDelo[$i][$j]=0;
            $IzobrazbaVzgDelo[$i][$j]=0;
            $Starost[$i][$j]=0;
        }
    }
    for ($i=0;$i <= 400;$i++){
        for($j=0;$j <= 25;$j++){
            $DelPog[$i][$j]="";
            $Delavec[$i][$j]="";
        }
    }

    $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabucitelji.letoroj,tabucitelji.izobrazba,tabucitelji.spol";
    $SQL = $SQL . ",tabucitelji.status,tabucitelji.mentor,tabucitelji.svetovalec,tabucitelji.svetnik,tabucitelji.nivodostopa, tabstatus.status AS sstatus FROM ";
    $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
    $SQL = $SQL . "WHERE tabucitelji.Status < 10 ";
    $SQL = $SQL . " ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $Delavec[$Indx][0]=$R["iducitelj"];
        $Delavec[$Indx][1]=$R["priimek"]." ".$R["ime"];
        $Delavec[$Indx][2]=$R["letoroj"];
        $Delavec[$Indx][3]=$R["izobrazba"];
    //'        $Delavec[$Indx][4]=$R["SkupinaDela"];
    //'        $Delavec[$Indx][5]=$R["OpisDela"];
    //'        $Delavec[$Indx][6]=$R["VzgojnoDelo"];
        $Delavec[$Indx][7]=$R["sstatus"];
    //'        $Delavec[$Indx][8]=$R["DelovniCas"];
    //'        $Delavec[$Indx][9]=$R["DatumStart"];
    //'        $Delavec[$Indx][10]=$R["DatumEnd"];
        $Delavec[$Indx][11]=$R["spol"];
    //'        $Delavec[$Indx][12]=$R["IdDelo"];
    //'        $Delavec[$Indx][13]=$R["IzobUstr"];
        $Delavec[$Indx][21]=$R["mentor"];
        $Delavec[$Indx][22]=$R["svetovalec"];
        $Delavec[$Indx][23]=$R["svetnik"];
        $Delavec[$Indx][24]=$R["nivodostopa"];
        $Delavec[$Indx][25]=$R["status"];
        $Indx=$Indx+1;
    }
    $StDelavcev=$Indx-1;

    //echo "Število delavcev ".$StDelavcev."<br />";

    $DatumPreveri=new DateTime(($VLeto+1)."-06-30");
    echo "<h2>Statistika zaposlenih na ".$DatumPreveri->format('d.m.Y')."</h2>";

    $SQL = "SELECT DISTINCT SkupinaDela FROM TabDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $NSkupinaDela[$Indx]=$R["SkupinaDela"];
        $Indx=$Indx+1;
    }
    $StSkupinDela=$Indx-1;

    $SQL = "SELECT VzgojnoDelo FROM TabVzgDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $TipVzgojnoDelo[$Indx]=$R["VzgojnoDelo"];
        $Indx=$Indx+1;
    }
    $StTipovVzgDelo=$Indx-1;

    $SQL = "SELECT OpisDela FROM TabDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $TipDelo[$Indx]=$R["OpisDela"];
        $Indx=$Indx+1;
    }
    $StOpisovDela=$Indx-1;

    for ($Indx=0;$Indx <= 20;$Indx++){
        $count[$Indx]=0;
    }

    for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
        $SQL = "SELECT tabpogodbe.*,TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo FROM ";
        $SQL = $SQL . "(tabpogodbe INNER JOIN TabDelo ON tabpogodbe.idDelo=TabDelo.idDelo) ";
        $SQL = $SQL . "INNER JOIN TabVzgDelo ON tabpogodbe.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo ";
        $SQL = $SQL . "WHERE idUcitelj=".$Delavec[$Indx][0]." ORDER BY UrTeden DESC";
        $result = mysqli_query($link,$SQL);
        $i2=1;
        while ($R = mysqli_fetch_array($result)){
            if (isDate($R["DatumStart"]) ){
                $Datum=new DateTime(isDate($R["DatumStart"]));
                $DelPog[$i2][2]=$Datum->format('d.m.Y');
            }else{
                $DelPog[$i2][2]=$Danes->format('d.m.Y');
            }
            if (isDate($R["DatumEnd"])) {
                $Datum=new DateTime(isDate($R["DatumEnd"]));
                $DelPog[$i2][3]=$Datum->format('d.m.Y');
            }else{
                $DelPog[$i2][3]=$DatumPreveri->format('d.m.Y');
            }
            $DatumStart=new DateTime(isDate($DelPog[$i2][2]));
            $DatumEnd=new DateTime(isDate($DelPog[$i2][3]));
            $Interval1=$DatumStart->diff($DatumPreveri);
            $Interval2=$DatumEnd->diff($DatumPreveri);
            if (($Interval1->invert == 0) && (($Interval2->invert > 0) or (($Interval2->invert ==0) && ($Interval2->days==0)))){
                $DelPog[$i2][1]=1;
                $DelPog[$i2][0]=$R["UrTeden"];
                
                $DelPog[$i2][4]=$R["SkupinaDela"];
                $DelPog[$i2][5]=$R["OpisDela"];
                $DelPog[$i2][6]=$R["VzgojnoDelo"];
                
                $DelPog[$i2][8]=$R["DelovniCas"];
                $DelPog[$i2][9]=$DelPog[$i2][2];
                $DelPog[$i2][10]=$DelPog[$i2][3];
                $DelPog[$i2][12]=$R["IdDelo"];
                $DelPog[$i2][13]=$R["IzobUstr"];
                $DelPog[$i2][14]=$R["IdVzgojnoDelo"];
                $DelPog[$i2][15]=$R["PolniDelCas"];
                $DelPog[$i2][18]=$R["DopDelo"];
                $DelPog[$i2][20]=$R["Izmensko"];
            }else{
                $i2=$i2-1;
            }
            $i2=$i2+1;
        }
        $StDelPogodba=$i2-1;
        
        if ($StDelPogodba > 0 ){
            $Delavec[$Indx][4]=$DelPog[1][4];    //'SkupinaDela
            $Delavec[$Indx][5]=$DelPog[1][5];    //'OpisDela
            $Delavec[$Indx][6]=$DelPog[1][6];    //'VzgojnoDelo
            $Delavec[$Indx][8]=$DelPog[1][8];    //'DelovniCas
            $Delavec[$Indx][9]=$DelPog[1][9];    //'DatumStart
            $Delavec[$Indx][10]=$DelPog[1][10];    //'DatumEnd
            $Delavec[$Indx][12]=$DelPog[1][12];    //'IdDelo
            $Delavec[$Indx][13]=$DelPog[1][13];    //'IzobUstr
            $Delavec[$Indx][14]=$DelPog[1][14];    //'idVzgojnoDelo
            $Delavec[$Indx][15]=$DelPog[1][15];    //'PolniDelCas
            $Delavec[$Indx][18]=$DelPog[1][18];    //'DopDelo
            $Delavec[$Indx][20]=$DelPog[1][20];    //'Izmensko
        }
        
        if ($StDelPogodba > 0 ){
            switch ( $Delavec[$Indx][4]){
                case $NSkupinaDela[1];
                    $SkupinaDela[1]=$SkupinaDela[1]+1;
                    $IzobrazbaSkupina[1][$Delavec[$Indx][3]]=$IzobrazbaSkupina[1][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[2];
                    $SkupinaDela[2]=$SkupinaDela[2]+1;
                    $IzobrazbaSkupina[2][$Delavec[$Indx][3]]=$IzobrazbaSkupina[2][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[3]:
                    $SkupinaDela[3]=$SkupinaDela[3]+1;
                    $IzobrazbaSkupina[3][$Delavec[$Indx][3]]=$IzobrazbaSkupina[3][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[4]:
                    $SkupinaDela[4]=$SkupinaDela[4]+1;
                    $IzobrazbaSkupina[4][$Delavec[$Indx][3]]=$IzobrazbaSkupina[4][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[5]:
                    $SkupinaDela[5]=$SkupinaDela[5]+1;
                    $IzobrazbaSkupina[5][$Delavec[$Indx][3]]=$IzobrazbaSkupina[5][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[6]:
                    $SkupinaDela[6]=$SkupinaDela[6]+1;
                    $IzobrazbaSkupina[6][$Delavec[$Indx][3]]=$IzobrazbaSkupina[6][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[7]:
                    $SkupinaDela[7]=$SkupinaDela[7]+1;
                    $IzobrazbaSkupina[7][$Delavec[$Indx][3]]=$IzobrazbaSkupina[7][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[8]:
                    $SkupinaDela[8]=$SkupinaDela[8]+1;
                    $IzobrazbaSkupina[8][$Delavec[$Indx][3]]=$IzobrazbaSkupina[8][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[9]:
                    $SkupinaDela[9]=$SkupinaDela[9]+1;
                    $IzobrazbaSkupina[9][$Delavec[$Indx][3]]=$IzobrazbaSkupina[9][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
            }
            if ($Delavec[$Indx][14] > 0 ){
                $VzgDelo[$Delavec[$Indx][14]]=$VzgDelo[$Delavec[$Indx][14]]+1;
            }
            $VzgDelo[0]=$VzgDelo[0]+1;
            if ($Delavec[$Indx][12] > 0 ){
                $Delo[$Delavec[$Indx][12]]=$Delo[$Delavec[$Indx][12]]+1;
            }
            $Delo[0]=$Delo[0]+1;
            if ($Delavec[$Indx][12] > 0 ){
                $IzobrazbaDelo[$Delavec[$Indx][12]][$Delavec[$Indx][3]]=$IzobrazbaDelo[$Delavec[$Indx][12]][$Delavec[$Indx][3]]+1;
            }
            $IzobrazbaDelo[0][$Delavec[$Indx][3]]=$IzobrazbaDelo[0][$Delavec[$Indx][3]]+1;
            if ($Delavec[$Indx][14] > 0 ){
                $IzobrazbaVzgDelo[$Delavec[$Indx][14]][$Delavec[$Indx][3]]=$IzobrazbaVzgDelo[$Delavec[$Indx][14]][$Delavec[$Indx][3]]+1;
            }
            $IzobrazbaVzgDelo[0][$Delavec[$Indx][3]]=$IzobrazbaVzgDelo[0][$Delavec[$Indx][3]]+1;
            switch ( $VLeto-$Delavec[$Indx][2]){
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                    $Starost[1][$Delavec[$Indx][25]]=$Starost[1][$Delavec[$Indx][25]]+1;
                    break;
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                    $Starost[2][$Delavec[$Indx][25]]=$Starost[2][$Delavec[$Indx][25]]+1;
                    break;
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                    $Starost[3][$Delavec[$Indx][25]]=$Starost[3][$Delavec[$Indx][25]]+1;
                    break;
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                    $Starost[4][$Delavec[$Indx][25]]=$Starost[4][$Delavec[$Indx][25]]+1;
                    break;
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    $Starost[5][$Delavec[$Indx][25]]=$Starost[5][$Delavec[$Indx][25]]+1;
                    break;
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                    $Starost[6][$Delavec[$Indx][25]]=$Starost[6][$Delavec[$Indx][25]]+1;
                    break;
                default:
                    $Starost[7][$Delavec[$Indx][25]]=$Starost[7][$Delavec[$Indx][25]]+1;
            }
        
            $count[16]=$count[16]+1;
            if ($Delavec[$Indx][15]=="Da" ){ 
                $count[0]=$count[0]+1;
            }
            if ($Delavec[$Indx][15]=="Ne" ){ 
                $count[1]=$count[1]+1;
            }
            if ($Delavec[$Indx][16] ){ 
                $count[2]=$count[2]+1;
            }
            if (is_numeric(strpos($Delavec[$Indx][17],"Da"))){ 
                $count[3]=$count[3]+1;
            }
            if ($Delavec[$Indx][18] ){ 
                $count[4]=$count[4]+1;
            }
            if (strlen($Delavec[$Indx][19]) > 0){ 
                $count[5]=$count[5]+1;
            }
            if ($Delavec[$Indx][20]){ 
                $count[18]=$count[18]+1;
            }
            if (strlen($Delavec[$Indx][21]) > 0){
                if (strlen($Delavec[$Indx][22]) > 0){
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[7]=$count[7]+1;
                    }
                }else{
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[6]=$count[6]+1;
                    }
                }
            }else{
                if (strlen($Delavec[$Indx][22]) > 0){
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[7]=$count[7]+1;
                    }
                }else{
                    if (strlen($Delavec[$Indx][23]) > 0 ){
                        $count[8]=$count[8]+1;
                    }
                }
            }
            switch ( $Delavec[$Indx][24]){
                case 0:
                    $count[9]=$count[9]+1;
                    break;
                case 1:
                    $count[10]=$count[10]+1;
                    break;
                case 2:
                    $count[11]=$count[11]+1;
                    break;
                case 3:
                    $count[12]=$count[12]+1;
            }
            switch ( $Delavec[$Indx][25]){
                case 3:
                    $count[13]=$count[13]+1;
                    break;
                case 6:
                    $count[14]=$count[14]+1;
                    break;
                case 10:
                    $count[15]=$count[15]+1;
            }
            
            $count[17]=$count[17]+1;
        }
    }

    echo "<table border=1>";
    echo "<tr><th>Delovno mesto</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StOpisovDela;$Indx++){
        if (strlen($TipDelo[$Indx]) > 0){
            echo "<tr>";
            echo "<td>&nbsp;".$TipDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$Delo[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$Delo[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][10]."</td>";
            echo "</tr>";
    echo "</table>";

    echo "<br />";

    echo "<table border=1>";
    echo "<tr><th>Delo</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StTipovVzgDelo;$Indx++){
        if (strlen($TipVzgojnoDelo[$Indx]) > 0 ){
            echo "<tr>";
            echo "<td>&nbsp;".$TipVzgojnoDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$VzgDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$VzgDelo[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][10]."</td>";
            echo "</tr>";
            echo "<tr>";
    echo "</table>";

    echo "<br />";

    echo "<table border=1>";
    echo "<tr><th>Delovne skupine</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StSkupinDela;$Indx++){
        if (strlen($NSkupinaDela[$Indx]) > 0){
            echo "<tr>";
            echo "<td>&nbsp;".$NSkupinaDela[$Indx]."</td>";
            echo "<td>&nbsp;".$SkupinaDela[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$SkupinaDela[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][10]."</td>";
            echo "</tr>";
    echo "</table>";

    echo "<br>";

    $StrStarost[1]="do 29 let";
    $StrStarost[2]="30-34 let";
    $StrStarost[3]="35-39 let";
    $StrStarost[4]="40-44 let";
    $StrStarost[5]="45-49 let";
    $StrStarost[6]="50-55 let";
    $StrStarost[7]=" nad 55 let";

    echo "<table border=1>";
    echo "<th>Starostna skupina</th><th>Redno</th><th>Na več šolah</th><th>Pripravnik</th>";
    for ($Indx=1;$Indx <= 7;$Indx++){
            echo "<tr>";
            echo "<td>&nbsp;".$StrStarost[$Indx]."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][1]+$Starost[$Indx][4])."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][2]+$Starost[$Indx][5])."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][3]+$Starost[$Indx][6])."</td>";
            echo "</tr>";
    }
    echo "</table>";

        echo "<br><table border=1>";
        echo "<tr><th>zaposleni</th><th>število</th></tr>";
        echo "<tr><td>Skupaj zaposlenih</td><td align=center>".$count[16]."</td></tr>";
        echo "<tr><td>Polni delovni čas</td><td align=center>".$count[0]."</td></tr>";
        echo "<tr><td>Skrajšan delovni čas</td><td align=center>".$count[1]."</td></tr>";
        echo "<tr><td>Invalid</td><td align=center>".$count[2]."</td></tr>";
        echo "<tr><td>Delno upokojen</td><td align=center>".$count[3]."</td></tr>";
        echo "<tr><td>Dopolnjuje delo</td><td align=center>".$count[4]."</td></tr>";
        echo "<tr><td>Izmensko delo</td><td align=center>".$count[18]."</td></tr>";
        echo "<tr><td>Začasno bivališče</td><td align=center>".$count[5]."</td></tr>";
        echo "<tr><td>Mentor</td><td align=center>".$count[6]."</td></tr>";
        echo "<tr><td>Svetovalec</td><td align=center>".$count[7]."</td></tr>";
        echo "<tr><td>Svetnik</td><td align=center>".$count[8]."</td></tr>";
        echo "<tr><td>Običajen dostop</td><td align=center>".$count[9]."</td></tr>";
        echo "<tr><td>Razredniški dostop</td><td align=center>".$count[10]."</td></tr>";
        echo "<tr><td>Ravnateljski dostop</td><td align=center>".$count[11]."</td></tr>";
        echo "<tr><td>Administratorski dostop</td><td align=center>".$count[12]."</td></tr>";
        echo "<tr><td>Pripravnik</td><td align=center>".$count[13]."</td></tr>";
        echo "<tr><td>Volunterski pripravnik</td><td align=center>".$count[14]."</td></tr>";
        echo "<tr><td>Gostujoči učitelji</td><td align=center>".$count[15]."</td></tr>";
        echo "</table>";

    //'--------------------------------------------------------- Statistika zaposlenih - konec ---------------------------

    //'--------------------------------------------------------- Statistika ocen - zacetek ---------------------------
            echo "<h2>Statistika zaključnih ocen ".$VLeto."/".($VLeto+1)."</h2>";

            for ($Indx=0;$Indx <= 50;$Indx++){
                $Razred[$Indx]="";
            }
            for ($Indx=0;$Indx <= 400;$Indx++){
                for ($Indx0=0;$Indx0 <= 6;$Indx0++){
                    $Ocena[$Indx][$Indx0]=0;
                }
            }
            $SQL = "SELECT id,oznaka,prioriteta,vrstnired FROM tabpredmeti WHERE Prioriteta IN (0,1) ORDER BY VrstniRed,id";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmet[$Indx][0]=$R["id"];
                $Predmet[$Indx][1]=$R["oznaka"];
                $Predmet[$Indx][2]=$R["prioriteta"];
                $Predmet[$Indx][3]=$R["vrstnired"];
                $Indx=$Indx+1;
            }

            $SQL = "SELECT tabocene.ocenakoncna,tabocene.idpredmet FROM ";
            $SQL = $SQL."((tabocene INNER JOIN tabpredmeti ON tabocene.IdPredmet=tabpredmeti.Id) ";
            $SQL .= "INNER JOIN tabrazred ON tabocene.iducenec=tabrazred.iducenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL."WHERE tabocene.leto=".$VLeto." AND tabpredmeti.Prioriteta IN (0,1) AND tabrazdat.idsola=".$sole[$IndxSola][0];
            $SQL = $SQL." ORDER BY tabpredmeti.id";
            $result = mysqli_query($link,$SQL);

            $Indx0=1;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["ocenakoncna"]){
                    case "5":
                        $Ocena[$R["idpredmet"]][5]=$Ocena[$R["idpredmet"]][5]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "4":
                        $Ocena[$R["idpredmet"]][4]=$Ocena[$R["idpredmet"]][4]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "3":
                        $Ocena[$R["idpredmet"]][3]=$Ocena[$R["idpredmet"]][3]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "2":
                        $Ocena[$R["idpredmet"]][2]=$Ocena[$R["idpredmet"]][2]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "1":
                    case "Ni opravil":
                        $Ocena[$R["idpredmet"]][1]=$Ocena[$R["idpredmet"]][1]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "ZU":
                        $Ocena[$R["idpredmet"]][5]=$Ocena[$R["idpredmet"]][5]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "U":
                        $Ocena[$R["idpredmet"]][4]=$Ocena[$R["idpredmet"]][4]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "MU":
                        $Ocena[$R["idpredmet"]][2]=$Ocena[$R["idpredmet"]][2]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "Opravil":
                        $Ocena[$R["idpredmet"]][6]=$Ocena[$R["idpredmet"]][6]+1;
                }
                $Indx0=$Indx0+1;
            }

            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=cyan><th>Predmet</th><th>5</th><th>4</th><th>3</th><th>2</th><th>NMS</th><th>Skupaj</th><th>Povprečje</th></tr>";
            $i1=0;
            for ($Indx=0;$Indx <= 400;$Indx++){
                if (isset($Predmet[$Indx][0]) && ($Ocena[$Predmet[$Indx][0]][0] > 0)){
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td bgcolor=khaki>".$Predmet[$Indx][1]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][5]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][4]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][3]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][2]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][1]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][0]."</td>";
                    if ($Ocena[$Predmet[$Indx][0]][0] > 0){
                        echo "<td align=right>".number_format(($Ocena[$Predmet[$Indx][0]][5]*5+$Ocena[$Predmet[$Indx][0]][4]*4+$Ocena[$Predmet[$Indx][0]][3]*3+$Ocena[$Predmet[$Indx][0]][2]*2+$Ocena[$Predmet[$Indx][0]][1])/$Ocena[$Predmet[$Indx][0]][0],2)."</td>";
                    }else{
                        echo "<td>&nbsp;</td>";
                    }
                    echo "</tr>";
                    $aMonthValues[$i1]=number_format(($Ocena[$Predmet[$Indx][0]][5]*5+$Ocena[$Predmet[$Indx][0]][4]*4+$Ocena[$Predmet[$Indx][0]][3]*3+$Ocena[$Predmet[$Indx][0]][2]*2+$Ocena[$Predmet[$Indx][0]][1])/$Ocena[$Predmet[$Indx][0]][0],2);
                    $aMonthNames[$i1]=$Predmet[$Indx][1];
                    $i1=$i1+1;
                }
            }
            echo "</table><br />";
            if ($i1 > 0){
                displayverticalgraph ("Povprečje zaključnih ocen - ".$VLeto."/".($VLeto+1)." ","Ocena","Predmeti",$aMonthValues,$aMonthNames);
            }
    //'--------------------------------------------------------- Statistika ocen - konec ---------------------------

    //'--------------------------------------------------------- Realizacije po predmetih - zacetek ---------------------------

    echo "<h2>Realizacija pri predmetih po razredih ".$VLeto."/".($VLeto+1)."</h2>";

    for ($i=0;$i <= 51;$i++){
        $RazrediR[$i]="";
        for ($j=0;$j <= 400;$j++){
            $Realizacija[$i][$j]="";
        }
    }
    $SQL = "SELECT tabrealizacija.plan,tabrealizacija.realizacija,tabrealizacija.predmet,tabpredmeti.oznaka AS poznaka,tabpredmeti.prioriteta,tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
    $SQL = $SQL . "(tabRealizacija INNER JOIN tabpredmeti ON tabrealizacija.Predmet=tabpredmeti.Id) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrealizacija.idRazred=TabRazDat.id ";
    $SQL = $SQL . "WHERE tabrealizacija.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
    $result = mysqli_query($link,$SQL);

    $RazredComp="";
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        if ($RazredComp != $R["razred"].". ".$R["roznaka"]){
            $Indx=$Indx+1;
            $RazredComp=$R["razred"].". ".$R["roznaka"];
            $RazrediR[$Indx]=$RazredComp;
        }
        if ($R["plan"] > 0){
            $Realizacija[$Indx][$R["predmet"]]=number_format(($R["realizacija"]/$R["plan"])*100,2);
        }else{
            $Realizacija[$Indx][$R["predmet"]]=0;
        }
        $Realizacija[0][$R["predmet"]]=$R["poznaka"];
        $Realizacija[51][$R["predmet"]]=$R["prioriteta"];
    }

    echo "<table border=1 cellspacing=0>";
    for ($Indx0=0;$Indx0 <= $Indx;$Indx0++){
        if ($Indx0==0){
            echo "<tr bgcolor=cyan><td>&nbsp;</td>";
        }else{
            echo "<tr bgcolor=lightyellow><td bgcolor=khaki>".$RazrediR[$Indx0]."</td>";
        }
        for ($Indx1=1;$Indx1 <= 400;$Indx1++){
            if (($Realizacija[51][$Indx1] == 0) or ($Realizacija[51][$Indx1] == 2)){
                if ($Indx0==0){
                    if ($Realizacija[0][$Indx1] != ""){
                        echo "<th>".$Realizacija[$Indx0][$Indx1]."</th>";
                    }
                }else{
                    if ($Realizacija[0][$Indx1] != ""){
                        if (isset($Realizacija[$Indx0][$Indx1])){
                            echo "<td align='right'>".$Realizacija[$Indx0][$Indx1]."</td>";
                        }
                    }
                }
            }
        }
        echo "</tr>";
    }
    echo "</table><br>";

    echo "<h2>Realizacija pri izbirnih predmetih po razredih ".$VLeto."/".($VLeto+1)."</h2>";

    echo "<table border=1 cellspacing=0>";
    for ($Indx0=0;$Indx0 <= $Indx;$Indx0++){
        if ((substr($RazrediR[$Indx0],0,1)=="7") or (substr($RazrediR[$Indx0],0,1)=="8") or (substr($RazrediR[$Indx0],0,1)=="9") or ($Indx0==0)){
            if ($Indx0==0){
                echo "<tr bgcolor=cyan><td>&nbsp;</td>";
            }else{
                echo "<tr bgcolor=lightyellow><td bgcolor=khaki>".$RazrediR[$Indx0]."</td>";
            }
            for ($Indx1=1;$Indx1 <= 200;$Indx1++){
                if ($Realizacija[51][$Indx1] == 1){
                    if ($Indx0==0){
                        if ($Realizacija[0][$Indx1] != ""){
                            echo "<th>".$Realizacija[$Indx0][$Indx1]."</th>";
                        }
                    }else{
                        if ($Realizacija[0][$Indx1] != ""){
                            if (isset($Realizacija[$Indx0][$Indx1])){
                                echo "<td align='right'>".$Realizacija[$Indx0][$Indx1]."</td>";
                            }
                        }
                    }
                }
            }
            echo "</tr>";
        }
    }
    echo "</table><br>";
    //'--------------------------------------------------------- Realizacije po predmetih - konec ---------------------------

    //'--------------------------------------------------------- Uspeh po razredih - zacetek ---------------------------
            echo "<h2>Uspeh po razredih - ".$VLeto."/".($VLeto+1)."</h2>";

            if ($VLeto < 2008){
                $SQL = "SELECT tabrazred.uspeh,tabrazred.napredovanje,tabrazdat.razred,tabrazdat.oznaka FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto;
                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);

                for ($Indx = 0;$Indx <= 100;$Indx++){
                    for ($i1=0;$i1 <= 10;$i1++){
                        $CountUsp[$Indx][$i1]=0;
                    }
                }

                $Indx=1;
                if ($R = mysqli_fetch_array($result)){
                    $RazredComp=$R["razred"].". ".$R["oznaka"];
                }

                echo "<table border=1>";
                echo "<tr><th>Razred</th><th>Učencev</th><th>4.51-5.00</th><th>3.51-4.50</th><th>2.51-3.50</th><th>1.51-2.50</th><th>Nezadostni</th><th>Napredujejo</th><th>Napredujejo<br />z nezadostno</th><th>Ne napredujejo</th></tr>";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($RazredComp != $R["razred"].". ".$R["oznaka"]){
                        if (intval(substr($RazredComp,0,1)) < 4){
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][1]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][2]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][3]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][4]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][5]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][7]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                            echo "</tr>";
                        }
                        $Indx=$Indx+1;
                        $RazredComp=$R["razred"].". ".$R["oznaka"];
                        
                        $CountUsp[$Indx][0]=$CountUsp[$Indx][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        switch ($R["uspeh"]){
                            case 5:
                                $CountUsp[$Indx][1]=$CountUsp[$Indx][1]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][1]=$CountUsp[0][1]+1;
                                }
                                break;
                            case 4:
                                $CountUsp[$Indx][2]=$CountUsp[$Indx][2]+1;
                                $CountUsp[0][2]=$CountUsp[0][2]+1;
                                break;
                            case 3:
                                $CountUsp[$Indx][3]=$CountUsp[$Indx][3]+1;
                                $CountUsp[0][3]=$CountUsp[0][3]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][4]=$CountUsp[$Indx][4]+1;
                                $CountUsp[0][4]=$CountUsp[0][4]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][5]=$CountUsp[$Indx][5]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][5]=$CountUsp[0][5]+1;
                                }
                        }
                        switch ($R["napredovanje"]){
                            case 0:
                                $CountUsp[$Indx][6]=$CountUsp[$Indx][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][7]=$CountUsp[$Indx][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][8]=$CountUsp[$Indx][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }else{
                        $CountUsp[$Indx][0]=$CountUsp[$Indx][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        switch ($R["uspeh"]){
                            case 5:
                                $CountUsp[$Indx][1]=$CountUsp[$Indx][1]+1;
                                if ($R["tabrazdat.razred"] > 3){
                                    $CountUsp[0][1]=$CountUsp[0][1]+1;
                                }
                                break;
                            case 4:
                                $CountUsp[$Indx][2]=$CountUsp[$Indx][2]+1;
                                $CountUsp[0][2]=$CountUsp[0][2]+1;
                                break;
                            case 3:
                                $CountUsp[$Indx][3]=$CountUsp[$Indx][3]+1;
                                $CountUsp[0][3]=$CountUsp[0][3]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][4]=$CountUsp[$Indx][4]+1;
                                $CountUsp[0][4]=$CountUsp[0][4]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][5]=$CountUsp[$Indx][5]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][5]=$CountUsp[0][5]+1;
                                }
                        }
                        switch ($R["napredovanje"]){
                            case 0:
                                $CountUsp[$Indx][6]=$CountUsp[$Indx][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][7]=$CountUsp[$Indx][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][8]=$CountUsp[$Indx][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }
                }
                echo "<tr>";
                echo "<td>".$RazredComp."</td>";
                echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][1]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][2]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][3]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][4]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][5]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][7]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>Skupaj</td>";
                echo "<td align=center>".$CountUsp[0][0]."</td>";
                echo "<td align=center>".$CountUsp[0][1]."</td>";
                echo "<td align=center>".$CountUsp[0][2]."</td>";
                echo "<td align=center>".$CountUsp[0][3]."</td>";
                echo "<td align=center>".$CountUsp[0][4]."</td>";
                echo "<td align=center>".$CountUsp[0][5]."</td>";
                echo "<td align=center>".$CountUsp[0][6]."</td>";
                echo "<td align=center>".$CountUsp[0][7]."</td>";
                echo "<td align=center>".$CountUsp[0][8]."</td>";
                echo "</tr>";

                echo "</table>";
            }else{
                $SQL = "SELECT tabrazred.iducenec,tabrazred.napredovanje,tabrazred.id,tabrazdat.razred,tabrazdat.oznaka FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 AND tabrazdat.idsola=".$sole[$IndxSola][0];
                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenec[$Indx][0]=$R["iducenec"];
                    $Ucenec[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                    $Ucenec[$Indx][2]=$R["napredovanje"];
                    $Ucenec[$Indx][4]=$R["razred"];
                    $Ucenec[$Indx][5]=$R["id"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;
                
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $Ucenec[$Indx][3]=Povprecje($Ucenec[$Indx][0],$Ucenec[$Indx][4]);
                    $SQL = "UPDATE tabrazred SET uspeh='".$Ucenec[$Indx][3]."' WHERE id=".$Ucenec[$Indx][5];
                    $result = mysqli_query($link,$SQL);
                }
                for ($Indx = 0;$Indx <= 100;$Indx++){
                    for ($i1=0;$i1 <= 10;$i1++){
                        $CountUsp[$Indx][$i1]=0;
                    }
                }

                $i1=1;
                $RazredComp=$Ucenec[1][1];

                echo "<table border=1>";
                echo "<tr><th>Razred</th><th>Učencev</th><th>4.6-5.0</th><th>3.6-4.5</th><th>2.6-3.5</th><th>1.6-2.5</th><th>Nezadostni</th><th>Napredujejo</th><th>Napredujejo<br />z nezadostno</th><th>Ne napredujejo</th><th>% uspeha</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if ($RazredComp != $Ucenec[$Indx][1]){
                        if (intval(substr($RazredComp,0,1)) < 3){
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                            if ($CountUsp[$i1][0] > 0){
                                echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                            echo "</tr>";


                        }else{
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][1]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][2]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][3]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][4]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][5]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][7]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                            if ($CountUsp[$i1][0] > 0){
                                echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                            echo "</tr>";
                        }
                        $RazredComp=$Ucenec[$Indx][1];
                        $i1=$i1+1;
                        $CountUsp[$i1][0]=$CountUsp[$i1][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        if ($Ucenec[$Indx][3] >= 4.6){
                            $CountUsp[$i1][1]=$CountUsp[$i1][1]+1;
                            if ($Ucenec[$Indx][4] > 3){    
                                $CountUsp[0][1]=$CountUsp[0][1]+1;
                            }
                        }
                        if (($Ucenec[$Indx][3] >= 3.6) && ($Ucenec[$Indx][3] < 4.6)){
                            $CountUsp[$i1][2]=$CountUsp[$i1][2]+1;
                            $CountUsp[0][2]=$CountUsp[0][2]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 2.6) && ($Ucenec[$Indx][3] < 3.6)){
                            $CountUsp[$i1][3]=$CountUsp[$i1][3]+1;
                            $CountUsp[0][3]=$CountUsp[0][3]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 1.6) && ($Ucenec[$Indx][3] < 2.6)){
                            $CountUsp[$i1][4]=$CountUsp[$i1][4]+1;
                            $CountUsp[0][4]=$CountUsp[0][4]+1;
                        }
                        if ($Ucenec[$Indx][3] < 1.6){
                            $CountUsp[$i1][5]=$CountUsp[$i1][5]+1;
                            if ($Ucenec[$Indx][4] > 3){ 
                                $CountUsp[0][5]=$CountUsp[0][5]+1;
                            }
                        }
                        
                        switch ($Ucenec[$Indx][2]){
                            case 0:
                                $CountUsp[$i1][6]=$CountUsp[$i1][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$i1][7]=$CountUsp[$i1][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$i1][8]=$CountUsp[$i1][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }else{
                        $CountUsp[$i1][0]=$CountUsp[$i1][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        if ($Ucenec[$Indx][3] >= 4.6){
                            $CountUsp[$i1][1]=$CountUsp[$i1][1]+1;
                            if ($Ucenec[$Indx][4] > 3){    
                                $CountUsp[0][1]=$CountUsp[0][1]+1;
                            }
                        }
                        if (($Ucenec[$Indx][3] >= 3.6) && ($Ucenec[$Indx][3] < 4.6)){
                            $CountUsp[$i1][2]=$CountUsp[$i1][2]+1;
                            $CountUsp[0][2]=$CountUsp[0][2]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 2.6) && ($Ucenec[$Indx][3] < 3.6)){
                            $CountUsp[$i1][3]=$CountUsp[$i1][3]+1;
                            $CountUsp[0][3]=$CountUsp[0][3]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 1.6) && ($Ucenec[$Indx][3] < 2.6)){
                            $CountUsp[$i1][4]=$CountUsp[$i1][4]+1;
                            $CountUsp[0][4]=$CountUsp[0][4]+1;
                        }
                        if ($Ucenec[$Indx][3] < 1.6){
                            $CountUsp[$i1][5]=$CountUsp[$i1][5]+1;
                            if ($Ucenec[$Indx][4] > 3){ 
                                $CountUsp[0][5]=$CountUsp[0][5]+1;
                            }
                        }
                        switch ($Ucenec[$Indx][2]){
                            case 0:
                                $CountUsp[$i1][6]=$CountUsp[$i1][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$i1][7]=$CountUsp[$i1][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$i1][8]=$CountUsp[$i1][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }
                }
                echo "<tr>";
                echo "<td>".$RazredComp."</td>";
                echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                echo "<td align=center>".$CountUsp[$i1][1]."</td>";
                echo "<td align=center>".$CountUsp[$i1][2]."</td>";
                echo "<td align=center>".$CountUsp[$i1][3]."</td>";
                echo "<td align=center>".$CountUsp[$i1][4]."</td>";
                echo "<td align=center>".$CountUsp[$i1][5]."</td>";
                echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                echo "<td align=center>".$CountUsp[$i1][7]."</td>";
                echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                if ($CountUsp[$i1][0] > 0){
                    echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                echo "<tr>";
                echo "<td>Skupaj</td>";
                echo "<td align=center>".$CountUsp[0][0]."</td>";
                echo "<td align=center>".$CountUsp[0][1]."</td>";
                echo "<td align=center>".$CountUsp[0][2]."</td>";
                echo "<td align=center>".$CountUsp[0][3]."</td>";
                echo "<td align=center>".$CountUsp[0][4]."</td>";
                echo "<td align=center>".$CountUsp[0][5]."</td>";
                echo "<td align=center>".$CountUsp[0][6]."</td>";
                echo "<td align=center>".$CountUsp[0][7]."</td>";
                echo "<td align=center>".$CountUsp[0][8]."</td>";
                if ($CountUsp[0][0] > 0){
                    echo "<td align='right'>".number_format($CountUsp[0][6]/$CountUsp[0][0]*100,2)."%</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";

                echo "</table>";

            }
    //'--------------------------------------------------------- Uspeh po razredih - konec ---------------------------

    //'--------------------------------------------------------- Udelezba pri izbirnih predmetih - zacetek ---------------------------
    echo "<h2>Izbirni predmeti</h2>";

    $SQL = "SELECT tabpredmeti.oznaka,tabpredmeti.opis FROM ";
    $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
    $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE tabizbirni.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL = $SQL . " ORDER BY tabpredmeti.Oznaka,tabucenci.Priimek,tabucenci.Ime";

    $result = mysqli_query($link,$SQL);

    echo "<table border=1 cellspacing=0>";
    echo "<tr bgcolor=cyan><th>Predmet</th><th>Učencev</th>";

    $ColorChange=true;
    if ($R = mysqli_fetch_array($result)){
        $PredmetIzbirni=$R["oznaka"]." - ".$R["opis"];
        echo "</tr><tr bgcolor=lightyellow>";
        echo "<td bgcolor=khaki>".$R["oznaka"]." - ".$R["opis"]."</td>";
    }
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        if ($PredmetIzbirni != $R["oznaka"]." - ".$R["opis"]){
            echo "<td align=right>".($Indx-1)."</td></tr><tr bgcolor=lightyellow>";
            echo "<td bgcolor=khaki>".$R["oznaka"]." - ".$R["opis"]."</td>";
            $Indx=1;
            $PredmetIzbirni = $R["oznaka"]." - ".$R["opis"];
        }
        $Indx=$Indx+1;
    }
    echo "<td align=right>".($Indx-1)."</td></tr>";
    echo "</table><br>";
    //'--------------------------------------------------------- Udelezba pri izbirnih predmetih - konec ---------------------------


    //'--------------------------------------------------------- Poročila interesnih dejavnosti - začetek ---------------------------

    $SQL = "SELECT tabkrozki.id, tabkrozki.krozek AS kkrozek, tabkrozki.mentor,tabkrozki.leto,tabkrozekclan.krozek,  Count(tabkrozekclan.krozek) AS nkrozek,tabrazred.leto,tabrazdat.idsola "; 
    $SQL = $SQL."FROM ((tabkrozki LEFT JOIN tabkrozekclan ON tabkrozekclan.krozek = tabkrozki.id) " ;
    $SQL .= "INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.iducenec) ";
    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
    $SQL = $SQL."GROUP BY tabkrozki.leto, tabkrozekclan.krozek, tabkrozki.id, tabkrozki.krozek, tabkrozki.mentor,tabrazred.leto,tabrazdat.idsola ";
    $SQL = $SQL."HAVING (((tabkrozki.leto)=".$VLeto.")) AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
    $SQL .= " ORDER BY tabkrozki.krozek";
    $result = mysqli_query($link,$SQL);

    echo "<h2>Poročilo o interesnih dejavnostih - ".$VLeto."/".($VLeto+1)."</h2>";
    echo "<table border=1 cellspacing=0>";
    echo "<tr><th>Št.</th><th>Krožek</th><th>Mentor</th><th>Vpisanih</th></tr>";
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
            if ($R["nkrozek"] > 0){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["kkrozek"]."</td>";
                echo "<td>".$R["mentor"]."</td>";
                echo "<td align=center>".$R["nkrozek"]."</td>";
                echo "</tr>";
            }
        $Indx=$Indx+1;
    }
    echo "</table><br>";

    $SQL = "SELECT krozek,porocilo,mentor FROM tabkrozki WHERE leto=".$VLeto;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if (strlen($R["porocilo"]) > 0){
            echo "<h3>".$R["krozek"]." - ".$R["mentor"]."</h3>";
            echo str_replace("\n","<br />",$R["porocilo"])."<br />";
            //echo "<hr>";
        }
        $Indx=$Indx+1;
    }


    //'--------------------------------------------------------- Poročila interesnih dejavnosti - konec ---------------------------
}
//skupni del
//'--------------------------------------------------------- Poročila aktivov - začetek ---------------------------
        $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM ";
        $SQL .= "TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id ";
        $SQL .= "WHERE TabAktivPorocilo.leto=".$VLeto;
        $SQL .= " ORDER BY TabAktiv.id";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Poročila o delu aktivov</h2>";

        while ($R = mysqli_fetch_array($result)){
            for ($Indx=1;$Indx <= 9;$Indx++){
                $VRazred[$Indx]=$R["razred".$Indx];
            }

            $VLeto = $R["leto"];
            $Vaktiv = $R["aaktiv"];
            $VAktivId = $R["aid"];
            $VprogramDela = $R["programDela"];
            $VdneviDejavnosti = $R["dneviDejavnosti"];
            $VdopolnilniPouk = $R["dopolnilniPouk"];
            $VindividualniPouk = $R["individualniPouk"];
            $VinteresneDejavnosti = $R["interesneDejavnosti"];
            $VroditeljskiSestanki = $R["roditeljskiSestanki"];
            $VstudijskaSkupina = $R["studijskaSkupina"];
            $Vizobrazevanje = $R["izobrazevanje"];
            $Vprojekti = $R["projekti"];
            $Vdrugo = $R["drugo"];

            echo "<h3>".$Vaktiv."</b>, ".$VLeto."/".($VLeto+1)."</h3>";
            
            echo "<b>Velja za naslednje razrede:</b> ";
            for ($Indx=1;$Indx <= 9;$Indx++){
                if ($VRazred[$Indx]==1 ){
                    echo $Indx."&nbsp;";
                }
            }
            echo "<br />";
            
            if (strlen($VprogramDela) > 0){
                echo "<br /><b>Program dela</b><br />";
                echo str_replace("\n","<br />",$VprogramDela)."<br />";
            }

            if (strlen($VdneviDejavnosti) > 0){
                echo "<br /><b>Dnevi dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VdneviDejavnosti)."<br />";
            }

            if (strlen($VdopolnilniPouk) > 0){
                echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
                echo str_replace("\n","<br />",$VdopolnilniPouk)."<br />";
            }

            if (strlen($VindividualniPouk) > 0){
                echo "<br /><b>Individualni pouk</b><br />";
                echo str_replace("\n","<br />",$VindividualniPouk)."<br />";
            }

            if (strlen($VinteresneDejavnosti) > 0){
                echo "<br /><b>Interesne dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VinteresneDejavnosti)."<br />";
            }

            if (strlen($VroditeljskiSestanki) > 0){
                echo "<br /><b>Roditeljski sestanki</b><br />";
                echo str_replace("\n","<br />",$VroditeljskiSestanki)."<br />";
            }

            if (strlen($VstudijskaSkupina) > 0){
                echo "<br /><b>Delo v študijski skupini</b><br />";
                echo str_replace("\n","<br />",$VstudijskaSkupina)."<br />";
            }

            if (strlen($Vizobrazevanje) > 0){
                echo "<br /><b>Izobraževanje</b><br />";
                echo str_replace("\n","<br />",$Vizobrazevanje)."<br />";
            }

            if (strlen($Vprojekti) > 0){
                echo "<br /><b>Projekti</b><br />";
                echo str_replace("\n","<br />",$Vprojekti)."<br />";
            }

            if (strlen($Vdrugo) > 0){
                echo "<br /><b>Drugo ...</b><br />";
                echo str_replace("\n","<br />",$Vdrugo)."<br />";
            }
            echo "<br />";
        }

//'--------------------------------------------------------- Poročila aktivov - konec ---------------------------

//'------------------------------------ Poročila o projektih ---------------------------
        
        $SQL = "SELECT * FROM TabProjekti WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            echo "<h2>Poročila o projektih</h2>";
        }
        while ($R = mysqli_fetch_array($result)){
        
            if ($VecSol > 0){
                $idsola=$R["idsola"];
                
                $SQL = "SELECT * FROM tabsola WHERE id=".$idsola;
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    $VSola=$R1["Sola"];
                    $VNaslovSole=$R1["Naslov"];
                    $VKraj=$R1["Kraj"];
                }else{
                    $VSola=" ";
                    $VNaslovSole="";
                    $VKraj="";
                }
            }else{
                $SQL = "SELECT * FROM tabsola WHERE id=1";
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    $VSola=$R1["Sola"];
                    $VNaslovSole=$R1["Naslov"];
                    $VKraj=$R1["Kraj"];
                }else{
                    $VSola=" ";
                    $VNaslovSole="";
                    $VKraj="";
                }
            }

            $VLeto=$R["Leto"];
            $VMentor=$R["Mentor"];
            $VProjekt=$R["Projekt"];
            $VSodelavci=$R["Sodelavci"];
            $VRazseznost=$R["razseznost"];
            $VVkljuceni=$R["vkljuceni"];
            $VDosezki=$R["dosezki"];
            $VPorocilo=$R["porocilo"];
            
            echo "<table class='graf' border='0' width='700'>";
            echo "<tr class='graf'><td class='graf'>";

            echo "<h3>".$VRazseznost." projekt: ".$VProjekt."</h3>";
            
            echo "<p>Mentor: ";
            $SQL="SELECT ime,priimek FROM TabUcitelji WHERE idUcitelj=".$VMentor;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo $R["ime"]." ".$R["priimek"];
            }
            echo "&nbsp;</p>";
            
            echo "<p><b>Sodelavci:</b><br />";
            if ($VSodelavci != "" ){
                $SQL="SELECT ime,priimek FROM TabUcitelji WHERE idUcitelj IN (".$VSodelavci.") ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo $R["ime"]." ".$R["priimek"]."<br />";
                }
            }
            echo "</p>";
            
            echo "<p><b>Vključeni v projekt:</b><br />";
            echo $VVkljuceni."</p>";
            echo "<p><b>Dosežki:</b><br />";
            echo $VDosezki."</p>";
            echo "<p><b>Poročilo:</b><br />";
            echo $VPorocilo."</p>";
            
            echo "</td></tr></table><br />";
        }

//'--------------------------------------------------------- Poročila o projektih - konec ---------------------------

//'------------------------------------ Poročila o natečajih ---------------------------
    
        $SQL = "SELECT * FROM tabnatecaj WHERE leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            echo "<h2>Poročila o sodelovanju na natečajih</h2>";
        }
        while ($R = mysqli_fetch_array($result)){
            echo "<h3>".$R["krozek"]."</h3>";
            echo "<p>Mentor: ".$R["mentor"]."<br />";
            echo $R["porocilo"]."</p>";
        }

//'--------------------------------------------------------- Poročila o natečajih - konec ---------------------------

//'------------------------------------ Letna poročila ---------------------------
        $SQL = "SELECT tabzapisnik.vsebina,tabzapisnik.avtor,tabzapisnik.naslov FROM tabzapisnik ";
        $SQL = $SQL . "INNER JOIN tabzapisniktip ON tabzapisnik.tip=tabzapisniktip.id ";
        $SQL = $SQL . "WHERE tabzapisnik.tip=8 AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result) > 0){
            echo "<h2>Letna poročila:</h2>";
        }

        while ($R = mysqli_fetch_array($result)){
            $VVsebina = $R["vsebina"];
            $VAvtor = $R["avtor"];
            echo "<h3>".$R["naslov"]."</h3>";
            echo str_replace("\n","<br />",$VVsebina)."<br />";
            echo "Zapisal/-a: ".$VAvtor."<br /><br />";
        }

//'------------------------------------ Konec - letna poročila -------------------

echo "<hr>Poročilo je končano";
echo "</body>";
echo "</html>";
?>