<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odsotnosti
</title>
</head>
<body>

<?php
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

$VLeto=$_POST["leto"];
$VMesec=$_POST["mesec"];

$SQL = "SELECT kadrovi.*,tabodsotnost.*,tabsifraodsotnosti.* FROM (tabodsotnost INNER JOIN kadrovi ON tabodsotnost.stdelavca=kadrovi.stdelavca) INNER JOIN tabsifraodsotnosti ON tabodsotnost.sifraodsotnosti=tabsifraodsotnosti.sifra  ORDER BY kadrovi.priimime,tabodsotnost.sifraodsotnosti,tabodsotnost.odsotnoststart";
$result = mysqli_query($link,$SQL);

echo "<h2>Odsotnost delavcev - ".$VMesec."/".$VLeto."</h2>";

echo "<table border=1>";
echo "<tr bgcolor=lightcyan>";
echo "<th>Ime</th>";
echo "<th>Začetek</th>";
echo "<th>Konec</th>";
echo "<th>Tip</th>";
echo "</tr>";

$DatComp1=$VLeto.LeadZero($VMesec)."01";
$DatComp2=$VLeto.LeadZero($VMesec)."31";
$CompareName="";
$ChangeColor=false;
while ($R = mysqli_fetch_array($result)){
    $DatumSt=new DateTime($R["odsotnoststart"]);
    $DatComp3=$DatumSt->format('Ymd');
    $DatumE=new DateTime($R["odsotnostend"]);
    $DatComp4=$DatumE->format('Ymd');
    if ((($DatComp1 <= $DatComp3) && ($DatComp2 >= $DatComp3)) or (($DatComp1 <= $DatComp4) && ($DatComp2 >= $DatComp4))){
        if ($CompareName != $R["PRIIMIME"]){
            $ChangeColor=!$ChangeColor;
            $CompareName=$R["PRIIMIME"];
        } 
        if ($ChangeColor){
            echo "<tr bgcolor=lightyellow>";
        }else{
            echo "<tr bgcolor=#FFFFCC>";
        }
        echo "<td>".$R["PRIIMIME"]."</td>";
        echo "<td>".$DatumSt->format('d.m.Y')."</td>";
        echo "<td>".$DatumE->format('d.m.Y')."</td>";
        echo "<td>".$R["odsotnost"]."</td>";
        echo "</tr>";
    }
}
echo "</table>";
?>

</body>
</html>
