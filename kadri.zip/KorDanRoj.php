<?php
    
require("const.php");

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
    if ($VLeto == "" ) {
        if (isset($_SESSION["leto"])){
            $VLeto=$_SESSION["leto"];
            if ($VLeto == "" ) {
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }else{
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }    
        }
    }
}else{
    if ($ActualMonth > 8 ) {
        $VLeto = $ActualYear;
    }else{
        if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
            $VLeto = $ActualYear;
        }else{
            $VLeto=$ActualYear-1;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
  	echo "Pozdravljeni " . iconv("windows-1250", "utf-8//TRANSLIT", $R["Ime"]  . " " . $R["Priimek"]) . "<br>";
}else{
 	echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik)) {
    header("Location: nepooblascen.htm");
}

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Korekcija datumov rojstev delavcev
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>
<?php
//$id=$_POST["id"];

$SQL = "SELECT id,Priimek,Ime,EMSO,DatRoj FROM tabucitelji";

$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
		if (isDate($R["DatRoj"])){
			echo "OK: ".iconv("windows-1250", "utf-8//TRANSLIT",$R["Priimek"]." ".$R["Ime"].", ".$R["EMSO"].", ".$R["DatRoj"])."<br />";
		}else{
			if (isset($R["EMSO"]) ) {
				if (strlen($R["EMSO"]) > 0 ) {
					$SQL = "UPDATE tabucitelji SET DatRoj='"."1".substr($R["EMSO"],5-1,3)."-".substr($R["EMSO"],3-1,2)."-".substr($R["EMSO"],0,2)." 00:00:00' WHERE id=".$R["id"];
//'					SQL = "UPDATE tabucitelji SET datRoj='"&left(R("EMSO"),2)&"."&mid(R("EMSO"),3,2)&".1"&mid(R("EMSO"),5,3)&"' WHERE id="&R("id")
                    if ($resultU = mysqli_query($link,$SQL)){
					    echo "Popravljeno: ".$R["Priimek"]." ".$R["Ime"].", ".$R["EMSO"].", 1".substr($R["EMSO"],5-1,3)."-".substr($R["EMSO"],3-1,2)."-".substr($R["EMSO"],0,2)."<br />";
                    }else{
                        die("Ni popravljeno!<br />");
                    }
                }else{
					echo "Ni emšo2: ".$R["Priimek"]." ".$R["Ime"].", ".$R["EMSO"].", ".$R["DatRoj"]."<br />";
				}
			}else{
				echo "Ni emšo1: ".$R["Priimek"]." ".$R["Ime"].", ".$R["EMSO"].", ".$R["DatRoj"]."<br />";
			}
		}
}


?>
</body>
</html>
