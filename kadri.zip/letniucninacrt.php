<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Letni učni načrt
</title>
<style>
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
$UrNaDan=10;
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["Ime"]." ".$R["Priimek"];
    $IdUcitelj=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    
    if (!CheckDostop("Redov",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        function ClearBlank($x){
            if (strlen($x) > 0){
                $x=str_replace("&nbsp;","",$x);
            }
            return $x;
        }
        function vsebuje($s,$a){
            //ali niz števil ločenih z vejico $s vsebuje število $a
            $sarr=explode(",",$s);
            for ($i=0;$i < count($sarr);$i++){
                if (intval($a)==intval($sarr[$i])){
                    return true;
                }
            }
            return false;
        }
        function Arr2Str($a){
            $s="";
            if (is_array($a)){
                for ($i=0;$i < count($a);$i++){
                    if (strlen($s) == 0){
                        $s=$a[$i];
                    }else{
                        $s=$s.",".$a[$i];
                    }
                }
            }else{
                return $a;
            }
            return $s;
        }
        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = 0;
            }
        }
        if (isset($_POST["vpis"])){
            $VVpis = $_POST["vpis"];
        }else{
            if (isset($_GET["vpis"])){
                $VVpis=$_GET["vpis"];
            }else{
                $VVpis = "";
            }
        }

        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Letni učni načrti";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";

        /*
        if ($VVpis != "5"){
            echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        }
        */

        switch ($VVpis){
            case "2":
                $SQL = "SELECT tabletninacrt.* FROM tabletninacrt WHERE tabletninacrt.id=".$Vid;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VLeto = $R["leto"];
                    $VVsebina = $R["vsebina"];
                    $VNaslov = $R["naslov"];
                    $VDatum = $R["datum"];
                    $VAvtor = $R["avtor"];
                    $VFile = $R["datoteka"];
                }
                break;
            case "1":
                $Vid="";
                $VVsebina = "";
                $VNaslov = "";
                $VDatum = "";
                $VAvtor = $Ucitelj;
                $VFile = "";
                break;
            case "3": //popravljanje zapisa
                $VVsebina = $_POST["vsebina"];
                $VNaslov = $_POST["naslov"];
                $VVsebina = str_replace("'","",$VVsebina);
                $VVsebina = str_replace(chr(34),"",$VVsebina);
                $VDatum = $_POST["datum"];
                $VAvtor = $_POST["avtor"];
                //$VFile = $_POST["file"];

                $SQL = "SELECT * FROM tabletninacrt WHERE id=".$Vid;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    if ($VLevel < 2){
                        if ($R["vpisal"] != $VUporabnik){
                            echo "<h2>Nimate pravic za popravljanje!</h2>";
                        }else{
                            $SQL = "UPDATE tabletninacrt SET avtor='".$VAvtor."',datum='".$VDatum."',naslov='".$VNaslov."', vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$Vid;
                        }
                    }else{
                        $SQL = "UPDATE tabletninacrt SET avtor='".$VAvtor."',datum='".$VDatum."',naslov='".$VNaslov."', vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$Vid;
                    }
                }
                $result = mysqli_query($link,$SQL);
                $Vid="";
                $VVsebina = "";
                $VNaslov = "";
                $VDatum = "";
                $VAvtor = $Ucitelj;
                $VFile = "";
                break;
            case "4":  //brisanje zapisa
                $SQL = "SELECT * FROM tabletninacrt WHERE id=".$Vid;
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    if ($VLevel < 2){
                        if (($R["vpisal"] != $VUporabnik) or ($R["arhiv"]==true)){
                            echo "<h2>Nimate pravic za brisanje!</h2>";
                        }else{
                            $SQL = "DELETE FROM tabletninacrt WHERE id=".$Vid;
                        }
                    }else{
                        $SQL = "DELETE FROM tabletninacrt WHERE id=".$Vid;
                    }
                }
                $result = mysqli_query($link,$SQL);
                $Vid="";
                $VVsebina = "";
                $VNaslov = "";
                $VDatum = "";
                $VAvtor = $Ucitelj;
                $VFile = "";
                break;
            case "5":
                $SQL = "SELECT * FROM tabsola";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VSola=$R["Sola"];
                    $VNaslovSole=$R["Naslov"];
                    $VKraj=$R["Kraj"];
                }else{
                    $VSola="";
                    $VNaslov="";
                    $VKraj="";
                }
                
                $SQL = "SELECT tabletninacrt.* FROM tabletninacrt WHERE tabletninacrt.id=".$Vid;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VLeto = $R["leto"];
                    $VVsebina = $R["vsebina"];
                    $VNaslov = $R["naslov"];
                    $VDatum = $R["datum"];
                    $VAvtor = $R["avtor"];
                    $VFile = $R["datoteka"];
                }
                
                echo "<table border='0' width='700'>";
                if (strlen($VFile) > 0){
                    echo "<font size=3>Za ogled načrta kliknite na spodnjo povezavo:<br />";
                    echo "<a href='upload/letninacrti/".$VFile."'>".$VFile."</a><br /><br /></font>";
                }
                break;
            case "6":
                $VStZapisov=$_POST["stzapisov"];
                
                for ($Indx=1;$Indx <= $VStZapisov;$Indx++){
                    $VZapis=$_POST["zapis".$Indx];
                    if (isset($_POST["pisno".$Indx])){
                        $SQL = "UPDATE tabletninacrt SET arhiv=true WHERE id=".$VZapis;
                    }else{
                        $SQL = "UPDATE tabletninacrt SET arhiv=false WHERE id=".$VZapis;
                    }
                    $result = mysqli_query($link,$SQL);
                }
                break;
            case "7":
                echo "<form name='Iskanje' method=post action='letniucninacrt.php'>";
                echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
                echo "<input name='vpis' type='hidden' value='7'>";
                echo "<input name='submit' type='submit' value='Išči'>";
                echo "</form>";
                
                echo "<h2>Spisek učnih načrtov - ".$_POST["iskanje"]."</h2>";
                echo "<form name='arhiv' method='post' action='letniucninacrt.php'>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Datum</th><th>Avtor</th><th>Datoteka</th><th>Opis</th><th>Popravi</th><th>Briši</th></tr>";

                $SQL = "SELECT tabletninacrt.* FROM tabletninacrt WHERE ";
                $SQL = $SQL . "(tip LIKE '%".$_POST["iskanje"]."%'";
                $SQL = $SQL . " OR avtor LIKE '%".$_POST["iskanje"]."%'";
                $SQL = $SQL . " OR naslov LIKE '%".$_POST["iskanje"]."%')";
                $SQL = $SQL ." ORDER BY tabletninacrt.naslov";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td align=right>".$R["datum"]."</td>";
                    echo "<td>".$R["avtor"]."</td>";
                    echo "<td><a href='upload/letninacrti/".$R["datoteka"]."'>".$R["datoteka"]."</a></td>";
                    echo "<td>".$R["vsebina"]."</td>";
                    echo "<td><a href='letniucninacrt.php?vpis=2&id=".$R["id"]."'>Popravi</a></td>";
                    echo "<td><a href='letniucninacrt.php?vpis=4&id=".$R["id"]."'>Briši</a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='stzapisov' type='hidden' value='".($Indx-1)."'>";
                echo "</form><br />";
                break;
            case "9": //prenos datoteke
                $uploaded=false;
                $allowedExts = array("txt","doc","docx","rtf","pdf","ppt","pptx");
                $Preneseno=$_FILES["file"];
                $extension = explode(".", $Preneseno["name"]);
                $extension = end($extension);
                $extension = strtolower($extension);
                $novoIme="";
                if (($_FILES["file"]["size"] < 5000000)
                    && in_array($extension, $allowedExts)){
                        if ($_FILES["file"]["error"] > 0){
                            echo "Napaka: " . $_FILES["file"]["error"] . "<br />";
                        }else{
                            echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                            echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                            echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                            echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
                            $novoIme=iconv("UTF-8", "ISO-8859-1//TRANSLIT", $_FILES["file"]["name"]);
                            if (file_exists("upload/letninacrti/" . $novoIme)){
                                echo $novoIme . " že obstaja. <br />";
                                $novoIme= $Danes->format('ymdHms_').$novoIme;
                                echo "Datoteka preimenovana v ".$novoIme;
                                move_uploaded_file($_FILES["file"]["tmp_name"],"upload/letninacrti/" . $novoIme);
                                echo "<h2>Shranjeno v: " . "upload/letninacrti/" . $novoIme."</h2>";
                                $uploaded=true;
                            }else{
                                move_uploaded_file($_FILES["file"]["tmp_name"],"upload/letninacrti/" . $novoIme);
                                echo "<h2>Shranjeno v: " . "upload/letninacrti/" . $novoIme."</h2>";
                                $uploaded=true;
                            }
                       }
                }else{
                    echo "Napačna datoteka";
                }
                echo "<br />";
                if ($uploaded){
                    $VVsebina = $_POST["vsebina"];
                    $VNaslov = $_POST["naslov"];
                    $VVsebina = str_replace("'","",$VVsebina);
                    $VVsebina = str_replace(chr(34),"",$VVsebina);
                    if (isDate($_POST["datum"])){
                        $VDatum=new DateTime(isDate($_POST["datum"]));
                    }else{
                        $VDatum=new DateTime($Danes->format('Y-m-d'));
                    }
                    $VAvtor = $_POST["avtor"];
                    $VFile = $novoIme;
                    
                    $SQL = "SELECT * FROM tabletninacrt WHERE naslov='".$VNaslov."' AND avtor='".$VAvtor."' AND datum='".$VDatum->format('d.m.Y')."'"; 
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        if ($VLevel < 2){
                            if (($R["vpisal"] != $VUporabnik) or ($R["arhiv"]==true)){
                                echo "<h2>Nimate pravic za popravljanje!</h2>";
                            }else{
                                $SQL = "UPDATE tabletninacrt SET vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$R["id"];
                            }
                        }else{
                            $SQL = "UPDATE tabletninacrt SET vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$R["id"];
                        }
                        $result = mysqli_query($link,$SQL);
                    }else{
                        $SQL = "INSERT INTO tabletninacrt (leto,naslov,datum,avtor,vsebina,cas,vpisal,datoteka) VALUES (".$VLeto.",'".$VNaslov."','".$VDatum->format('d.m.Y')."','".$VAvtor."','".$VVsebina."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."','".$VFile."')";
                        $result = mysqli_query($link,$SQL);
                    }
                    $VDatum=$VDatum->format('d.m.Y');
                }
                break;
            default:
                $VVsebina = "";
                $VNaslov = "";
                $VDatum = "";
                $VAvtor = $Ucitelj;
                $VFile = "";
        }

        switch ($VVpis){
            case "5":
            case "7":
                echo "<br />";
                echo "<a href='letniucninacrt.php'>Na učne načrte</a><br />";
                break;
            default:
                if ($VLevel >= 1){
                    echo "<h2>Vnos letnih učnih načrtov</h2>";
                    echo "V izogib ponavljanju imen datotek, velja naslednje pravilo poimenovanja naslovov in datotek:<br />";
                    echo "primer:<br />";
                    echo "<b>2015-NAR-5r-ImePriimek.doc</b><br />";
                    echo "<br />";
                    echo "pomen:<br />";
                    echo "začetno leto šolskega leta-tričrkovna standardna oznaka predmeta-razred (lahko splošno (r) ali paralelka (a, b, c...))-ime in priimek avtorja.podaljšek<br />";
                    echo "Če je veljavnost učnega načrta za več razredov, vpišite vse. Npr: 2015-TVZ-789-ImePriimek.pdf<br />";
                    echo "Program pri imenih datotek avtomatsko pretvori šumnike v znake brez strešic. Pri tem lahko pride do istega imena datoteke za Spoznavanje okolja (SPO) in šport (ŠPO).<br />";
                    echo "Za šport zato uporabite kar celo ime ŠPORT.<br />";
                    echo "<br />";
                    echo "Strežnik sprejema datoteke do velikosti 5 MByte s podaljški: pdf, doc, docx, ppt, pptx, rtf, txt<br />";
                    echo "<br />";
                    echo "<form method='post' accept-charset='utf-8' ENCTYPE='multipart/form-data' action='letniucninacrt.php'>";
                    //echo "<input name='vpis' type='hidden' value='9'>";

                    echo "<table border=0><tr>";

                    echo "<td>Šolsko leto:</td><td><a href='letniucninacrt.php?leto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> ".$VLeto."/".($VLeto+1)." <a href='letniucninacrt.php?leto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a></td></tr>";
                    echo "<input type=hidden name='leto' value='".$VLeto."'>";
                    echo "<td>Naslov:</td><td><input name='naslov' type='text' size='40' value='".$VNaslov."'></td></tr>";
                    echo "<td>Datum:</td><td><input name='datum' type='text' size='10' value='".$VDatum."'></td></tr>";
                    echo "<td>Avtor:</td><td><input name='avtor' type='text' size='25' value='".$VAvtor."'></td></tr>";
                    echo "<td>Datoteka:</td><td><input name='file' type='file' size='40' value='".$VFile."'></td></tr>";
                    echo "<input name='povezava' type='hidden' value='/'>";
                    echo "</table>";

                    echo "<br /><b>Opis</b><br />";
                    
                    echo "<textarea name='vsebina' cols='80' rows='5'>".$VVsebina."</textarea><br />";
                    if ($Vid != ""){
                        echo "<input type='hidden' name='vpis' value='3'>"; // 'popravi
                        echo "<input type='hidden' name='id' value='".$Vid."'>"; // 'popravi
                    }else{
                        echo "<input type='hidden' name='vpis' value='9'>"; // 'nov vpis
                    }
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form><br /><br />";
                }
                echo "<form name='Iskanje' method=post action='letniucninacrt.php'>";
                echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
                echo "<input name='vpis' type='hidden' value='7'>";
                echo "<input name='submit' type='submit' value='Išči'>";
                echo "</form>";
                
                echo "<h2>Spisek letnih učnih načrtov</h2>";
                echo "<form name='arhiv' method='post' action='letniucninacrt.php'>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Datum</th><th>Naslov</th><th>Avtor</th><th>Datoteka</th><th>Opis</th><th>Popravi</th><th>Briši</th></tr>";

                $SQL = "SELECT tabletninacrt.* FROM tabletninacrt WHERE leto=$VLeto ORDER BY tabletninacrt.naslov";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td align=right>".$R["datum"]."</td>";
                    echo "<td>".$R["naslov"]."</td>";
                    echo "<td>".$R["avtor"]."</td>";
                    echo "<td><a href='upload/letninacrti/".$R["datoteka"]."' target='_blank'>".$R["datoteka"]."</a></td>";
                    echo "<td>".$R["vsebina"]."</td>";
                    echo "<td><a href='letniucninacrt.php?vpis=2&id=".$R["id"]."'>Popravi</a></td>";
                    echo "<td><a href='letniucninacrt.php?vpis=4&id=".$R["id"]."'>Briši</a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='stzapisov' type='hidden' value='".($Indx-1)."'>";
                echo "</form><br />";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
echo "</body>";
echo "</html>";
?>
