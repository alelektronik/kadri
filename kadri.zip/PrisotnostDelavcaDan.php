<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Prisotnost
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}


$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

function Koda2Str($x){
    switch ($x){
        case "1001":
            return "Prihod";
        case "3001":
            return "Odhod z dela";
        case "3002":
            return "Službeni izhod";
        case "3010";
            return "Malica";
        case "5002":
            return "Najava bolniške";
        case "5004":
            return "Najava plačanega dopusta";
    }
}

if (isset($_POST["datum"])){
    if (isDate($_POST["datum"])){
        $datum=new DateTime($_POST["datum"]);
        $VLeto=$datum->format('Y');
        $VMesec=$datum->format('n');
        $VDan=$datum->format('j');
    }else{
        $VLeto=$Danes->format('Y');
        $VMesec=$Danes->format('n');
        $VDan=$Danes->format('j');
    }
}else{
    $VLeto=$Danes->format('Y');
    $VMesec=$Danes->format('n');
    $VDan=$Danes->format('j');
}
/*
$SQL = "SELECT iducitelj FROM tabucitelji WHERE (status > 0) ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $oUcitelj=new RUcitelj();
    $oUcitelj->PreberiSeGlavno($R["iducitelj"],$VLeto,$VLeto);
    if ($oUcitelj->getZaposlen($Danes)) {
        $UciteljZaObdelavo[$Indx]=$R["iducitelj"];
        $Indx=$Indx+1;
    }
}
$StUciteljevZaObdelavo=$Indx-1;

for ($Indx=1;$Indx <= 1000;$Indx++){
    $DelavecDat[$Indx][1]="";
    $DelavecDat[$Indx][2]="";
    $DelavecDat[$Indx][3]="";
}
*/
    switch ( $VMesec){
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            $MesecDni=31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            $MesecDni=30;
            break;
        case 2:
            if ($VLeto % 4 == 0){
                $MesecDni=29;
            }else{
                $MesecDni=28;
            }
    }

$SQL = "SELECT kadrovi.priimime,kadrovi.stdelavca,kadrovi.emso FROM kadrovi INNER JOIN tabucitelji ON kadrovi.emso=tabucitelji.iducitelj WHERE tabucitelji.status > 0 ORDER BY priimime";    
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $DelavecDat[$Indx][1]=$R["priimime"];
    $DelavecDat[$Indx][2]=$R["stdelavca"];
    $DelavecDat[$Indx][3]=$R["emso"];
    $Indx=$Indx+1;
}
$StDelavcev=$Indx-1;

echo "<br /><form accept-charset='utf-8' name='PregledDela' method='post' action='PrisotnostDelavcaDan.php'>";

$DatumOd=new DateTime($VLeto."-".$VMesec."-".$VDan);
echo "<input name='datum' type='text' size='10' value='".$DatumOd->format('d.m.Y')."' id='dat01'>";
echo "<input name='submit' type='submit' value='Izberi'>";
echo "</form>";
             
echo "<h2>Prisotnost delavcev - ".$VDan.".".$VMesec.".".$VLeto."</h2>";

echo "<table border=0>";
echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>";
echo "<img src='5.gif'>";
echo "<img src='6.gif'>";
echo "<img src='7.gif'>";
echo "<img src='8.gif'>";
echo "<img src='9.gif'>";
echo "<img src='10.gif'>";
echo "<img src='11.gif'>";
echo "<img src='12.gif'>";
echo "<img src='13.gif'>";
echo "<img src='14.gif'>";
echo "<img src='15.gif'>";
echo "<img src='16.gif'>";
echo "<img src='17.gif'>";
echo "<img src='18.gif'>";
echo "<img src='19.gif'>";
echo "<img src='20.gif'>";
echo "</td></tr>";
echo "<tr><td>Št.</td><td>Delavec</td>";
echo "<td>";
for ($Indx=1;$Indx <= 192;$Indx++){
    if ($Indx % 12 == 0 ){
        echo "<img src='r5.gif'>";
    }else{
        if (($Indx > 24) && ($Indx < 120) ){
            echo "<img src='g5.gif'>";
        }else{
            echo "<img src='m5.gif'>";
        }
    }
}
echo "</td></tr>";
echo "<tr>";

for ($Indx0=1;$Indx0 <= $StDelavcev;$Indx0++){
    /*
    $izpisi=false;
    for($i=1;$i <= $StUciteljevZaObdelavo;$i++){
        if ($DelavecDat[$Indx0][3]==$UciteljZaObdelavo[$i] ){
            $izpisi=true;
            break;
        }
    }
    */
    $SQL = "SELECT odsotnoststart,odsotnostend,sifraodsotnosti FROM tabodsotnost WHERE stdelavca='".$DelavecDat[$Indx0][2]."'";
    $result = mysqli_query($link,$SQL);
    $Odsotnost[$VDan]=0;
    $DatumComp=$Danes->format('Ymd');
    while ($R = mysqli_fetch_array($result)){
        $Datum=new DateTime(isDate($R["odsotnoststart"]));
        $DCompS=$Datum->format('Ymd');
        $Datum=new DateTime(isDate($R["odsotnostend"]));
        $DCompE=$Datum->format('Ymd');
        if (($DatumComp >= $DCompS) && ($DatumComp <= $DCompE) ){
            $Odsotnost[$VDan]=$R["sifraodsotnosti"]+10;
        }
    }

    for ($IndxMin=0;$IndxMin <= 192;$IndxMin++){
        if ($Odsotnost[$VDan] > 0 ){
            $Delavec[$IndxMin]=$Odsotnost[$VDan];
        }else{
            $Delavec[$IndxMin]=0;
        }
    }
    $Prisotnost[1]=0;
    $DelaNaDan[1][1]=0;
    $DelaNaDan[1][2]=0;

    //'Obdelava ročnih vpisov
    $SQL = "SELECT tabprihodi.letopr,tabprihodi.uraprih,tabprihodi.minprih,tabprihodi.vrstaprih,tabprihodi.uraodh,tabprihodi.minodh FROM tabprihodi INNER JOIN kadrovi ON tabprihodi.sifra=kadrovi.stdelavca ";
    $SQL = $SQL ."WHERE tabprihodi.sifra='".$DelavecDat[$Indx0][2]."' AND ((tabprihodi.letopr='".$VLeto."' AND tabprihodi.mesecpr='".$VMesec."' AND tabprihodi.danpr='".$VDan."') OR (tabprihodi.letodh='".$VLeto."' AND tabprihodi.mesecodh='".$VMesec."' AND tabprihodi.danodh='".$VDan."')) ORDER BY tabprihodi.sistemdat,tabprihodi.minut";
    $result = mysqli_query($link,$SQL);

    if (mysqli_num_rows($result) > 0){
        while ($R = mysqli_fetch_array($result)){
            if (isset($R["letopr"])){
                $Dan=1;
                $Delavec[round(($R["uraprih"]*60+$R["minprih"])/5) -60]=1;
            }else{
                $Dan=1;
                switch ( $R["vrstaprih"]){
                    case "3001":
                        $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=10;
                        break;
                    case "3002":
                        $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=9;
                        break;
                    case "3010":
                        $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=8;
                }
            }
        }
    }

    //'Obdelava avtomatskih vpisov
    $SQL = "SELECT promet1.letopr,promet1.uraprih,promet1.minprih,promet1.vrstaprih,promet1.uraodh,promet1.minodh FROM promet1 INNER JOIN kadrovi ON promet1.sifra=kadrovi.stdelavca ";
    $SQL = $SQL . "WHERE promet1.sifra='".$DelavecDat[$Indx0][2]."' AND ((promet1.letopr='".$VLeto."' AND promet1.mesecpr='".$VMesec."' AND promet1.danpr='".$VDan."') OR (promet1.letodh='".$VLeto."' AND promet1.mesecodh='".$VMesec."' AND promet1.danodh='".$VDan."')) ORDER BY promet1.sistemdat,promet1.minut";
    $result = mysqli_query($link,$SQL);
    $DanPrihoda="";
    if (mysqli_num_rows($result)){
         while ($R = mysqli_fetch_array($result)){
            if (isset($R["letopr"])){
                if ($R["letopr"] > 2000){
                    $Dan=1;
                    $Delavec[round(($R["uraprih"]*60+$R["minprih"])/5) -60]=1;
                }else{
                    $Dan=1;
                    switch ( $R["vrstaprih"]){
                        case "3001":
                            $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=10;
                            break;
                        case "3002":
                            $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=9;
                            break;
                        case "3010":
                            $Delavec[round(($R["uraodh"]*60+$R["minodh"])/5)-60]=8;
                    }
                }
            }
        }
    }

 //   if ($izpisi){
        if (strlen($DelavecDat[$Indx0][1]) > 0 ){
            for ($IndxMin=1;$IndxMin <= 192;$IndxMin++){
                if ($Delavec[$IndxMin]==1 ){
                    $Prisotnost[1]=1;
                    $Delavec[0]=1;
                }    
                if ($Delavec[$IndxMin]==10 ){
                    $Prisotnost[1]=0;
                    $Delavec[0]=1;
                }    
                if ($Delavec[$IndxMin] == 0 ){
                    if ($Prisotnost[1] > 0 ){
                        $Delavec[$IndxMin]=2;
                    }else{
                        $Delavec[$IndxMin]=0;
                    }
                }
            }
            echo "<td align='center'>".$Indx0."</td><td><a href='PrisotnostMesec5.php?leto=".$VLeto."&mesec=".$VMesec."&delavec=".$DelavecDat[$Indx0][3]."'>".$DelavecDat[$Indx0][1]."</a></td>";
            echo "<td>";
            for ($IndxMin=1;$IndxMin <= 192;$IndxMin++){
                switch ( $Delavec[$IndxMin]){
                    case 1:
                        echo "<img src='g5.gif'>";
                        break;
                    case 2:
                        echo "<img src='m5.gif'>";
                        break;
                    case 8: // 'sluzbeni
                        echo "<img src='mo5.gif'>";
                        break;
                    case 9: // 'malica
                        echo "<img src='p5.gif'>";
                        break;
                    case 10:
                        echo "<img src='r5.gif'>";
                        break;
                    case 11: // ' sluzbena odsotnost - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 12: // ' bolniska odsotnost - 
                        echo "<img src='ze5_3.gif'>";
                        break;
                    case 13: // ' sluzbeno potovanje - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 14: // ' izobrazevanje - 
                        echo "<img src='ze5_2.gif'>";
                        break;
                    case 15: // ' redni dopust - 
                        echo "<img src='ze5_4.gif'>";
                        break;
                    case 16: //' izredni dopust - 
                        echo "<img src='ze5_4.gif'>";
                        break;
                    case 17: // ' neplacan dopust - 
                        echo "<img src='ze5_4.gif'>";
                        break;
                    case 18: // ' Tabor - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 19: // ' spremljanje ucencev - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 20: // ' neopravicena odsotnost - 
                        echo "<img src='ze5_5.gif'>";
                        break;
                    case 21: // 'pozabljena kartica - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 22: // ' drugo - 
                        echo "<img src='ze5_1.gif'>";
                        break;
                    case 23: //' bolniška 4 ure - 
                        echo "<img src='ze5_3.gif'>";
                        break;
                    case 24: // ' porodniški - 
                        echo "<img src='ze5_3.gif'>";
                        break;
                    case 25: // ' varstvo, nega otroka - 
                        echo "<img src='ze5_3.gif'>";
                        break;
                    case 26: // ' Koriščenje ur - 
                        echo "<img src='ze5_4.gif'>";
                        break;
                    default:
                        echo "<img src='ru5.gif'>";
                }
            }
            echo "</td></tr>";
        }
    //}
}
echo "</table>";

echo "Legenda:<br />";
echo "<img src='g5.gif'> - Prihod<br />";
echo "<img src='m5.gif'> - Prisotnost<br />";
echo "<img src='mo5.gif'> - Službeni izhod<br />";
echo "<img src='p5.gif'> - Izhod - malica<br />";
echo "<img src='r5.gif'> - Odhod<br /><br />";

echo "<img src='ze5_1.gif'> - službena odsotnost, službeno potovanje, tabor, spremljanje učencev, pozabljena kartica, drugo<br />";
echo "<img src='ze5_3.gif'> - bolniška odsotnost<br />";
echo "<img src='ze5_2.gif'> - izobraževanje<br />";
echo "<img src='ze5_4.gif'> - redni, izredni in neplačani dopust<br />";
echo "<img src='ze5_5.gif'> - neopravičena odsotnost<br />";

?>
<br />

</body>
</html>
