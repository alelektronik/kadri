<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pedagoško poročilo
</title>
</head>
<body>

<?php
function ToOPB($x){
    switch ($x){
        case 52:
            return "OPB";
        case 78:
            return "PB01";
        case 79:
            return "PB02";
        case 80:
            return "PB03";
        case 81:
            return "PB04";
        case 82:
            return "PB05";
        case 83:
            return "PB06";
        case 84:
            return "PB07";
        case 85:
            return "PB08";
        case 86:
            return "PB09";
        case 87:
            return "PB10";
        case 88:
            return "PB11";
        case 89:
            return "PB12";
        case 90:
            return "PB13";
        case 91:
            return "PB14";
        default:
            return "---";
    }
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}

$RazsirjenVnos=true;
$zamenjaj = array("\"","'","<");

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $VUporabnikId=$IdUcitelj;
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
//    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = $UciteljComp;
        }
    }
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["zapis"])){
    $VZapis=$_POST["zapis"];
}else{
    if (isset($_GET["zapis"])){
        $VZapis=$_GET["zapis"];
    }else{
        $VZapis=0;
    }
}
if (intval($VZapis) == 0){
    if (isset($_POST["razred"])){
        $VRazredIzbran=$_POST["razred"];
    }else{
        if (isset($_GET["razred"])){
            $VRazredIzbran=$_GET["razred"];
        }else{
            $VRazredIzbran=0;
        }
    }
}else{
    if (strpos($Vid,"a") > 0){
        $SQL = "SELECT idrazred FROM tabrazrednikpor WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazredIzbran=$R["idrazred"];
        }
    }else{
        $SQL = "SELECT idrazred FROM tabrazrednikpork WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazredIzbran=$R["idrazred"];
        }
    }
}

$ZaZamenjat=array("\"","\'","<",">");

$SQL = "SELECT TabRazred.idUcitelj,tabrazdat.*,tabucitelji.Priimek,tabucitelji.Ime FROM (TabRazred ";
$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.idRazred=tabrazdat.id) ";
$SQL = $SQL . "INNER JOIN tabucitelji ON TabRazred.idUcitelj=tabucitelji.IdUcitelj ";
//$SQL = $SQL . " WHERE tabrazdat.leto=".$VLeto." AND TabRazred.idUcitelj=".$Ucitelj;
$SQL = $SQL . " WHERE tabrazdat.id=".$VRazredIzbran;
$result = mysqli_query($link,$SQL);

if ($R = mysqli_fetch_array($result)){
	$VidRazred=$R["id"];
	$VidRazred1=$R["razred"];
	$VidParalelka=$R["oznaka"];
	$VidRazrednik=$R["idUcitelj"];
    $VImeRazrednika=$R["Priimek"]." ".$R["Ime"];
    $VIdSola=$R["idsola"];
}else{
	$VidRazred=0;
    $VidRazred1=0;
	$VidParalelka="A";
    $VidRazrednik=0;
    $VImeRazrednika="Ni izbran";
    $VIdSola=1;
}

$SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
$result = mysqli_query($link,$SQL);
$Indx=0;
while ($R = mysqli_fetch_array($result)){
	$Razredi[$Indx][0]=$R["id"];
	$Razredi[$Indx][1]=$R["razred"];
	$Razredi[$Indx][2]=$R["oznaka"];
    $Razredi[$Indx][3]=$R["solakratko"];
	$Indx=$Indx+1;
}
$StRazredov=$Indx-1;

switch ($Vid){
    case "1a1":
    case "2a":
    case "3a1":
    case "1b1":
    case "2b":
    case "3b1":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
    
}

switch ($Vid){
	case "1a": //	'vnos novega poročila
		echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
		echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";
        if ($VRazredIzbran == 0){
            $SQL = "SELECT * FROM TabRazrednikPor WHERE razrednik=".$Ucitelj." AND leto=".$VLeto;
        }else{
		    $SQL = "SELECT * FROM TabRazrednikPor WHERE idRazred=".$_POST["razred"];
        }
		$result = mysqli_query($link,$SQL);
		if (mysqli_num_rows($result) > 0){
			echo "<h1>Podatki za ta razred so že vpisani!</h1>";
			if (($IdUcitelj==$R["razrednik"]) or ($VLevel > 1) ){
				echo "<h1><a href='PedPorocilo.php?id=3a&zapis=".$R["id"]."'>Popravi poročilo</a></h1>";
			}
		}else{
            if ($VRazredIzbran == 0){
                $SQL = "SELECT * FROM TabRazred WHERE idUcitelj=".$Ucitelj." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$R["idRazred"];
                    $VRazredIzbr=$R["idRazred"];
                }else{
                    $SQL = "SELECT * FROM tabrazdat WHERE id=0";
                    $VRazredIzbr=0;
                }
            }else{
                $VRazredIzbr=$_POST["razred"];
			    $SQL = "SELECT * FROM tabrazdat WHERE id=".$_POST["razred"];
            }
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				if (($VidRazrednik==$IdUcitelj) or ($VLevel > 1 )){
                    if ($VRazredIzbran == 0){
                        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VImeRazrednika=$R["Priimek"]." ".$R["Ime"];
                            $VidRazrednik=$R["IdUcitelj"];
                        }
                        echo "<h2>Novo polletno pedagoško poročilo - ".$VImeRazrednika.":</h2>";
                        echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
                        echo "<input type='hidden' name='razrednik' value='".$VidRazrednik."'>";
                        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    }else{
					    echo "<h2>Novo polletno pedagoško poročilo - ".$VImeRazrednika.":</h2>";
					    echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
					    echo "<input type='hidden' name='razrednik' value='".$VidRazrednik."'>";
					    echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    }

					echo "<table border=0><tr>";
					echo "<td>Razred:</td>";
					$SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazredIzbr;
					$result = mysqli_query($link,$SQL);
					if ($R = mysqli_fetch_array($result)){
						echo "<td><input name='razred' type='hidden' value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"];
						echo "</td>";
						echo "</tr>";

						echo "<input name='vrstaos' type='hidden' value='9'><input name='opb' type='hidden' value='0'></td></tr>";

						echo "</table>";

						echo "Uspeh oddelka in rezultati učno vzgojnega dela<br />";
						echo "<textarea name='komentar' cols='80' rows='10'>";
						echo "- Učenci, ki ne dosegajo minimalnih standardov znanja\n";
						echo "- Ponavljalci\n";
						echo "- Tujci\n";
						echo "- Učenci z odločbo o usmeritvi\n";
						echo "- Učenci, ki so učno zelo uspešni, pohvale in vidnejši uspehi\n";
						echo "</textarea><br />";

						echo "Rezultati učno vzgojnega dela (OPB)<br />";
						echo "<textarea name='ucnoVzgDelo' cols='80' rows='10'></textarea><br />";

						echo "Vzgojna problematika in socialna klima oddelka<br />";
						echo "<textarea name='vzgUkrepi' cols='80' rows='10'>";
						echo "- izrečeni vzgojni ukrepi in poravnave\n";
						echo "- socialna klima, oddelčne prireditve (kino, bazar, ...)\n";
						echo "- delovne navade: opravljanje DN, aktivnost učencev pri pouku\n";
						echo "- izostanki - opis stanja (opravičeni, neopravičeni, narava izostankov - strnjeni, nestrnjeni, posamezniki ali več učencev)\n";
						echo "</textarea><br />";

                        echo "Priporočila, razmišljanja za naslednje ocenjevalno obdobje<br />";
                        echo "<textarea name='priporocila' cols='80' rows='10'>";
                        echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
                        echo "B Cilji, ki sem jih kot razrednik želel/-a doseči na učnem/vzgojnem področju\n";
                        echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
                        echo "D Kje smo?\n";
                        echo "E Načrti in priporočila za naslednje ocenjevalno obdobje\n";
                        echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
                        echo "</textarea><br />";
                        
                        /*
                        echo "Analiza pedagoškega dela v učnih skupinah<br />";
                        echo "<textarea name='uspehi' cols='80' rows='10'>";
                        echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
                        echo "B Cilji, ki sem jih kot učitelj želel/-a doseči na učnem/vzgojnem področju\n";
                        echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
                        echo "D Kje smo?\n";
                        echo "E Načrti in priporočila za naslednje ocenjevalno obdobje\n";
                        echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
                        echo "</textarea><br />";
                        */
						echo "Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora<br />";
						echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";

						echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
						echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
						echo "<input name='level' type='hidden' value='".$VLevel."'>";
						echo "<input name='id' type='hidden' value='1a1'>";
						echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
						echo "</form>";
					}else{
						echo "<h1>Niste izbrali razreda.</h1>";
					}
				}else{
					echo "<h1>Poročilo lahko vpiše le razrednik.</h1>";
				}
			}
		}
        break;
	case "1a1": //vpis poročila v bazo
		$Ucitelj=$_POST["razrednik"];
		$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VRazrednik=$R["Priimek"]." ".$R["Ime"];
		}
		$VKomentar = str_replace($zamenjaj," ",$_POST["komentar"]);
        
		$VPohvale = str_replace($zamenjaj," ",$_POST["pohvale"]);
        
		if ($VLevel < 2 ){
			if (!(strpos($VPohvale,"(".$VRazrednik.")"))){
				$VPohvale=$VPohvale."\n(".$VRazrednik.")\n";
			}
		}
		$VVzgUkrepi = str_replace($zamenjaj," ",$_POST["vzgUkrepi"]);
        
		if (isset($_POST["uspehi"])){
            $VUspehi = str_replace($zamenjaj," ",$_POST["uspehi"]);
        }else{
            $VUspehi = "";
        }
		$VPriporocila = str_replace($zamenjaj," ",$_POST["priporocila"]);
        
		$VUcnoVzgDelo = str_replace($zamenjaj," ",$_POST["ucnoVzgDelo"]);
        
		$VRazred = $_POST["razred"];
		if (!is_numeric($VRazred)){
			$VRazred = 0;
		}
		//$VParalelka = $_POST["Paralelka"];
		if (isset($_POST["opb"])){
            $Vopb = str_replace($zamenjaj," ",$_POST["opb"]);
		}else{
			$Vopb = 0;
		}
		$VDevetletka = $_POST["vrstaos"];
        if (isset($_POST["lokacija"])){
		    $VLokacija = $_POST["lokacija"];
        }else{
            $VLokacija="";
        }
		$SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VRazred1=$R["razred"];
			$VParalelka=$R["oznaka"];
		}

        $SQL = "SELECT * FROM TabRazrednikPor WHERE idRazred=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) == 0){  //vpiše le novo poročilo
        	$SQL = "INSERT INTO TabRazrednikPor (leto,razrednik,komentar,pohvale,vzgUkrepi,Uspehi,Priporocila,UcnoVzgDelo,razred,paralelka,opb,idRazred) VALUES (".$VLeto.",".$Ucitelj.",'".$VKomentar."','".$VPohvale."','".$VVzgUkrepi."','".$VUspehi."','".$VPriporocila."','".$VUcnoVzgDelo."',".$VRazred1.",'".$VParalelka."',".$Vopb.",".$VRazred.")";
		    $result = mysqli_query($link,$SQL);
        }

		if ($Opravila==1 ){
			$SQL = "SELECT tabdeldogodek.id FROM ";
			$SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
			$SQL = $SQL . "WHERE tabdogodek.Dogodek='Pedagoško poročilo' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
			$result = mysqli_query($link,$SQL);

			$Indx=1;
			while ($R = mysqli_fetch_array($result)){
				$VDogodki[$Indx]=$R["id"];
				$Indx=$Indx+1;
			}
			$StDogodkov=$Indx-1;

			for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
				$SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
				$result = mysqli_query($link,$SQL);
			}
		}
        header("Location: PedPorocilo.php?id=0a");
	    break;
	case "2a": // 'brisanje poročila
		if (!CheckDostop("PreglPoroc",$VUporabnik)){ 
            header("Location: nepooblascen.htm");
        }
		$SQL = "DELETE FROM TabRazrednikPor WHERE id=".$VZapis;
		$result = mysqli_query($link,$SQL);
		//'echo "Izbrisali ste zapis ".Vzapis."<br />"
		header("Location: PedPorocilo.php?id=0a");
        break;
	case "3a": //'popravljanje poročila
		$SQL = "SELECT TabrazrednikPor.*,tabucitelji.ime,tabucitelji.priimek FROM ";
		$SQL = $SQL . "TabRazrednikPor INNER JOIN tabucitelji ON TabRazrednikPor.razrednik=tabucitelji.idUcitelj ";
		$SQL = $SQL . "WHERE TabRazrednikPor.id=".$VZapis;
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			if (($VidRazrednik==$R["Razrednik"]) or ($VLevel > 1 )){
				echo "<h2>Pedagoško poročilo - ".$R["priimek"]." ".$R["ime"].":</h2>";
				echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
				echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
				echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
				echo "<input name='level' type='hidden' value='".$VLevel."'>";
				echo "<input type='hidden' name='razrednik' value='".$R["Razrednik"]."'>";
				echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
				echo "<input type='hidden' name='id' value='3a1'>";
				echo "<input type='hidden' name='zapis' value='".$R["Id"]."'>";

				echo "<table border=0><tr>";
				echo "<td>Razred:</td>";
				echo "<td><input name='razred' type='hidden' value='".$R["idRazred"]."'>".$R["Razred"].". ".$R["Paralelka"];
				echo "</td>";
				echo "</tr>";
				echo "</table>";

				echo "Uspeh oddelka in rezultati učno vzgojnega dela<br />";
				echo "<textarea name='komentar' cols='80' rows='10'>".$R["Komentar"]."</textarea><br />";

				echo "Rezultati učno vzgojnega dela (OPB)<br />";
				echo "<textarea name='ucnoVzgDelo' cols='80' rows='10'>".$R["UcnoVzgDelo"]."</textarea><br />";

				echo "Vzgojna problematika in socialna klima oddelka<br />";
				echo "<textarea name='vzgUkrepi' cols='80' rows='10'>".$R["VzgUkrepi"]."</textarea><br />";

				echo "Priporočila, razmišljanja za naslednje ocenjevalno obdobje<br />";
				echo "<textarea name='priporocila' cols='80' rows='10'>".$R["Priporocila"]."</textarea><br />";
                /*
                echo "Analiza pedagoškega dela v učnih skupinah<br />";
                echo "<textarea name='uspehi' cols='80' rows='10'>".$R["Uspehi"]."</textarea><br />";
                */
				echo "Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora<br />";
				echo "<textarea name='pohvale' cols='80' rows='10'>".$R["Pohvale"]."</textarea><br />";

				echo "<input name='submit' type='submit' value='Pošlji popravek'>";
				echo "</form>";
			}
		}
        break;
	case "3a1": // 'vpiši popravek
		$Ucitelj=$_POST["razrednik"];
		$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VRazrednik=$R["Priimek"]." ".$R["Ime"];
		}
		$VKomentar = str_replace($zamenjaj," ",$_POST["komentar"]);
		$VPohvale = str_replace($zamenjaj," ",$_POST["pohvale"]);
		if ($VLevel < 2 ){
            if (!(strpos($VPohvale,"(".$VRazrednik.")"))){
				$VPohvale=$VPohvale."\n(".$VRazrednik.")\n";
			}
		}
		$VVzgUkrepi = str_replace($zamenjaj," ",$_POST["vzgUkrepi"]);
        if (isset($_POST["uspehi"])){
            $VUspehi = str_replace($zamenjaj," ",$_POST["uspehi"]);
        }else{
            $VUspehi = "";
        }
        $VPriporocila = str_replace($zamenjaj," ",$_POST["priporocila"]);
        $VUcnoVzgDelo = str_replace($zamenjaj," ",$_POST["ucnoVzgDelo"]);
        $VRazred = $_POST["razred"];
        if (!is_numeric($VRazred)){
            $VRazred = 0;
        }
        if (isset($_POST["opb"])){
            $Vopb = str_replace($zamenjaj," ",$_POST["opb"]);
        }else{
            $Vopb = 0;
        }
        $VDevetletka = $_POST["vrstaos"];
        if (isset($_POST["lokacija"])){
            $VLokacija = $_POST["lokacija"];
        }else{
            $VLokacija="";
        }
		$VDevetletka = $_POST["vrstaos"];

		$SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VRazred1=$R["razred"];
			$VParalelka=$R["oznaka"];
		}

		$SQL = "UPDATE  TabRazrednikPor SET Komentar='" . $VKomentar . "',Pohvale='".$VPohvale."',VzgUkrepi='".$VVzgUkrepi."',Uspehi='".$VUspehi."',Priporocila='".$VPriporocila."',UcnoVzgDelo='".$VUcnoVzgDelo."',razred=".$VRazred1.",paralelka='".$VParalelka."',opb=".$Vopb.",idRazred=".$VRazred." WHERE Id=".$VZapis;
		$result = mysqli_query($link,$SQL);

		if ($Opravila==1 ){
			$SQL = "SELECT tabdeldogodek.id FROM ";
			$SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
			$SQL = $SQL . "WHERE tabdogodek.Dogodek='Pedagoško poročilo' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
			$result = mysqli_query($link,$SQL);

			$Indx=1;
			while ($R = mysqli_fetch_array($result)){
				$VDogodki[$Indx]=$R["id"];
				$Indx=$Indx+1;
			}
			$StDogodkov=$Indx-1;

			for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
				$SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
				$result = mysqli_query($link,$SQL);
			}
		}
        header("Location: PedPorocilo.php?id=0a");
        break;
	case "4a": // 'dodaj mnenje
		$SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$VZapis;
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			echo "<form accept-charset='utf-8' name='form_porociloDod' method=post action='PedPorocilo.php'>";
			echo "<p>";
			echo "<b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b><br />";
			
			echo "<h2>Oddana mnenja za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

			echo "<p>";
			echo str_replace("\n","<br />",$R["Pohvale"]);
			echo "</p>";
			echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
			echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";
			echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
			echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
			echo "<input name='level' type='hidden' value='".$VLevel."'>";
			echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
			echo "<input name='id' type='hidden' value='4a1'>";
			echo "<p>Pozor: Napačno poslano mnenje bo lahko popravil le razrednik.</p>";
			echo "<input name='submit' type='submit' value='Pošlji dodatek'>";
			echo "</form>";
		}
        echo "<a href='PedPorocilo.php?id=0a'>Nazaj na poročila</a>";
        break;
	case "4a1":	//'vpiše dodatno mnenje
		$SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$_POST["porocilo"];
		$result = mysqli_query($link,$SQL);
		
		if ($R = mysqli_fetch_array($result)){
			$VPohvale=$R["Pohvale"]."\n";
			if (!(strpos($VPohvale,$_POST["pohvale"]."\n"."(".$ImeUcitelja.")")) ){
				$VPohvale=$VPohvale."\n".$_POST["pohvale"]."\n(".$ImeUcitelja.")\n";
			}
			$VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
			$SQL = "UPDATE TabRazrednikPor SET Pohvale='".$VPohvale."' WHERE id=".$R["Id"];
			$result = mysqli_query($link,$SQL);
			
			echo "<p><b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b><br />";
			
			echo str_replace("\n","<br />",$VPohvale);
			echo "</p><br /><br />";
			echo "<a href='PedPorocilo.php?id=0a'>Nazaj na poročila</a>";
		}
        break;
	case "5a": //'dodaj opb poročilo
		$SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$VZapis;
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			echo "<form accept-charset='utf-8' name='form_porociloDod' method=post action='PedPorocilo.php'>";
			echo "<p>";
			echo "<b>Poročilo učitelja PB</b><br />";
			
			echo "<h2>Oddana poročila za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

			echo "<p>";
			echo str_replace("\n","<br />",$R["UcnoVzgDelo"]);
			echo "</p>";
			echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
			echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";
			echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
			echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
			echo "<input name='level' type='hidden' value='".$VLevel."'>";
			echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
			echo "<input name='id' type='hidden' value='5a1'>";
			echo "<p>Pozor: Napačno poslano poročilo bo lahko popravil le razrednik.</p>";
			echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
			echo "</form>";
		}
        break;
	case "5a1": //	'vpiši poročilo opb
		$SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$_POST["porocilo"];
		$result = mysqli_query($link,$SQL);
		
		if ($R = mysqli_fetch_array($result)){
			$VPohvale=$R["UcnoVzgDelo"]."\n";
            if (!(strpos($VPohvale,$_POST["pohvale"]."\n"."(".$ImeUcitelja.")")) ){
                $VPohvale=$VPohvale."\n".$_POST["pohvale"]."\n(".$ImeUcitelja.")\n";
			}
			$VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
			$SQL = "UPDATE TabRazrednikPor SET UcnoVzgDelo='".$VPohvale."' WHERE id=".$R["Id"];
			$result = mysqli_query($link,$SQL);
			
			echo "<p><b>Poročila učiteljev PB:</b><br />";
			
			echo str_replace("\n","<br />",$VPohvale);
			echo "</p><br /><br />";
			echo "<a href='PedPorocilo.php?id=0a'>Nazaj na poročila</a>";
		}
        break;
    case "6a": // 'dodaj mnenje
        $SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<form accept-charset='utf-8' name='form_skupine' method=post action='PedPorocilo.php'>";
            echo "<p>";
            echo "<b>Analiza pedagoškega dela v učnih skupinah</b><br />";
            
            echo "<h2>Oddana poročila za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

            echo "<p>";
            echo str_replace("\n","<br />",$R["Uspehi"]);
            echo "</p>";
            echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
            echo "<textarea name='uspehi' cols='80' rows='10'>";
            echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
            echo "B Cilji, ki sem jih kot učitelj želel/-a doseči na učnem/vzgojnem področju\n";
            echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
            echo "D Kje smo?\n";
            echo "E Načrti in priporočila za naslednje ocenjevalno obdobje\n";
            echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
            echo "</textarea><br />";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
            echo "<input name='id' type='hidden' value='6a1'>";
            echo "<p>Pozor: Napačno poslano mnenje bo lahko popravil le razrednik.</p>";
            echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
            echo "</form>";
        }
        break;
    case "6a1":    //'vpiše dodatno mnenje
        $SQL = "SELECT * FROM TabRazrednikPor WHERE id=".$_POST["porocilo"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VUspehi=$R["Uspehi"]."\n";
            if (!(strpos($VUspehi,$_POST["uspehi"]."\n"."(".$ImeUcitelja.")")) ){
                $VUspehi=$VUspehi."\n".str_replace($zamenjaj," ",$_POST["uspehi"])."\n(".$ImeUcitelja.")\n";
            }
            //$VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
            $SQL = "UPDATE TabRazrednikPor SET uspehi='".$VUspehi."' WHERE id=".$R["Id"];
            $result = mysqli_query($link,$SQL);
            
            echo "<p><b>Analiza pedagoškega dela v učnih skupinah</b><br />";
            
            echo str_replace("\n","<br />",$VUspehi);
            echo "</p><br /><br />";
            echo "<a href='PedPorocilo.php?id=0a'>Nazaj na poročila</a>";
        }
        break;
	case "0a":	//'spisek polletnih poročil;
		echo "<h2>Pregled polletnih poročil</h2>";
		echo "<p>Razredniki lahko za začetek pošljete tudi prazna poročila in na ta način drugim omogočite vnos njihovih komentarjev.</p>";
		echo "<table border=1>";
        //echo "<tr><th>Razred</th><th>Razrednik</th><th>OPB</th><th>Mnenja<br />učiteljev</th><th>Analiza<br />skupin</th><th width='20'><img src='img/m_poglej1.gif'></th><th width='20'><img src='img/m_edit1.gif'></th><th width='20'><img src='img/m_delete.gif'></th></tr>";
        echo "<tr><th>Razred</th><th>Razrednik</th><th>OPB</th><th>Mnenja<br />učiteljev</th><th width='20'><img src='img/m_poglej1.gif'></th><th width='20'><img src='img/m_edit1.gif'></th><th width='20'><img src='img/m_delete.gif'></th></tr>";

		$SQL = "SELECT TabRazrednikPor.id AS rid,tabucitelji.priimek,tabucitelji.ime,tabrazdat.*,tabsola.solakratko FROM ";
		$SQL = $SQL . "(((TabRazrednikPor LEFT JOIN tabpredmeti ON TabRazrednikPor.opb=tabpredmeti.id) ";
		$SQL = $SQL . "INNER JOIN tabucitelji ON TabRazrednikPor.razrednik=tabucitelji.idUcitelj) ";
		$SQL = $SQL . "INNER JOIN tabrazdat ON TabRazrednikPor.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
		$SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
		$result = mysqli_query($link,$SQL);

		if (mysqli_num_rows($result) > 0){
			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				//'razred
                if ($VecSol > 0){
				    echo "<td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                }else{
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                }
				//'učitelj
				echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
				//'OPB
                if ($R["razred"] < 6){
                    echo "<td align='center'><a href='PedPorocilo.php?id=5a&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                }else{
                    echo "<td align='center'>&nbsp;</td>";
                }
                //'Mnenja učiteljev
                echo "<td align='center'><a href='PedPorocilo.php?id=4a&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                //'Analiza skupin
                /*
                echo "<td align='center'><a href='PedPorocilo.php?id=6a&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                */
                //'Poglej
                echo "<td align='center'><a href='PorociloRazrednikaPregled.php?razred=".$R["id"]."&paralelka=".$R["oznaka"]."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'></a></td>";
                //'Popravi
                echo "<td align='center'><a href='PedPorocilo.php?id=3a&zapis=".$R["rid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                //'Briši
                if ($VLevel > 1){
                    echo "<td align='center'><a href='PedPorocilo.php?id=2a&zapis=".$R["rid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                }else{
                    echo "<td align='center'>&nbsp;</td>";
                }
    			echo "</tr>";
			}
		}
		//'vrstica za dodajanje
		echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
		echo "<tr>";
		//'razred
		echo "<td><select name='razred'>";
		echo "<option value='0' selected='selected'>&nbsp;</option>";
        if ($VecSol > 0){
            for ($Indx=0;$Indx <= $StRazredov;$Indx++){
                echo "<option value='".$Razredi[$Indx][0]."'>".$Razredi[$Indx][1].". ".$Razredi[$Indx][2]." - ".$Razredi[$Indx][3]."</option>";
            }
        }else{
            for ($Indx=0;$Indx <= $StRazredov;$Indx++){
                echo "<option value='".$Razredi[$Indx][0]."'>".$Razredi[$Indx][1].". ".$Razredi[$Indx][2]."</option>";
            }
        }
		echo "</select></td>";
		//'učitelj
		if ($VLevel < 2 ){
			echo "<td><input name='ucitelj' type='hidden' value='".$Ucitelj."'>".$VImeRazrednika."</td>";
		}else{
			echo "<td><select name='ucitelj'>";
			echo "<option value='0' selected='selected'>&nbsp;</option>";
			$SQL = "SELECT * FROM tabucitelji WHERE status > 0";
			$result = mysqli_query($link,$SQL);
			while ($R = mysqli_fetch_array($result)){
				echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			}
			echo "</select></td>";
		}
		//'OPB
		//echo "<td>&nbsp;</td>";
		//'Mnenja učiteljev
		//echo "<td>&nbsp;</td>";
		//'Poglej
		//echo "<td>&nbsp;</td>";
		//'Popravi
		echo "<td colspan='5'><input name='submit' type='submit' value='Novo poročilo'></td>";
		//'Briši
		//echo "<td>&nbsp;</td>";
		echo "</tr>";
		echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
		echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
		echo "<input name='level' type='hidden' value='".$VLevel."'>";
		echo "<input name='id' type='hidden' value='1a'>";
		echo "</form>";
		echo "</table><br />";
        break;
	case "1b":	//'vnos novega poročila
        echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
        echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";
        if ($VRazredIzbran == 0){
            $SQL = "SELECT * FROM TabRazrednikPorK WHERE razrednik=".$Ucitelj." AND leto=".$VLeto;
        }else{
            $SQL = "SELECT * FROM TabRazrednikPorK WHERE idRazred=".$_POST["razred"];
        }
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            echo "<h1>Podatki za ta razred so že vpisani!</h1>";
            if (($IdUcitelj==$R["razrednik"]) or ($VLevel > 1) ){
                echo "<h1><a href='PedPorocilo.php?id=3a&zapis=".$R["id"]."'>Popravi poročilo</a></h1>";
            }
        }else{
            if ($VRazredIzbran == 0){
                $SQL = "SELECT * FROM TabRazred WHERE idUcitelj=".$Ucitelj." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$R["idRazred"];
                    $VRazredIzbr=$R["idRazred"];
                }else{
                    $SQL = "SELECT * FROM tabrazdat WHERE id=0";
                    $VRazredIzbr=0;
                }
            }else{
                $VRazredIzbr=$_POST["razred"];
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$_POST["razred"];
            }
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if (($VidRazrednik==$IdUcitelj) or ($VLevel > 1 )){
                    if ($VRazredIzbran == 0){
                        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VImeRazrednika=$R["Priimek"]." ".$R["Ime"];
                            $VidRazrednik=$R["IdUcitelj"];
                        }
                        echo "<h2>Novo končno pedagoško poročilo - ".$VImeRazrednika.":</h2>";
                        echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
                        echo "<input type='hidden' name='razrednik' value='".$VidRazrednik."'>";
                        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    }else{
                        echo "<h2>Novo končno pedagoško poročilo - ".$VImeRazrednika.":</h2>";
                        echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
                        echo "<input type='hidden' name='razrednik' value='".$VidRazrednik."'>";
                        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    }

                    echo "<table border=0><tr>";
                    echo "<td>Razred:</td>";
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazredIzbr;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<td><input name='razred' type='hidden' value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"];
                        echo "</td>";
                        echo "</tr>";

                        echo "<input name='vrstaos' type='hidden' value='9'><input name='opb' type='hidden' value='0'></td></tr>";

                        echo "</table>";

                        echo "Uspeh oddelka in rezultati učno vzgojnega dela<br />";
                        echo "<textarea name='komentar' cols='80' rows='10'>";
                        echo "- Učenci, ki ne dosegajo minimalnih standardov znanja\n";
                        echo "- Ponavljalci\n";
                        echo "- Tujci\n";
                        echo "- Učenci z odločbo o usmeritvi\n";
                        echo "- Učenci, ki so učno zelo uspešni, pohvale in vidnejši uspehi\n";
                        echo "</textarea><br />";

                        echo "Rezultati učno vzgojnega dela (OPB)<br />";
                        echo "<textarea name='ucnoVzgDelo' cols='80' rows='10'></textarea><br />";

                        echo "Vzgojna problematika in socialna klima oddelka<br />";
                        echo "<textarea name='vzgUkrepi' cols='80' rows='10'>";
                        echo "- izrečeni vzgojni ukrepi in poravnave\n";
                        echo "- socialna klima, oddelčne prireditve (kino, bazar, ...)\n";
                        echo "- delovne navade: opravljanje DN, aktivnost učencev pri pouku\n";
                        echo "- izostanki - opis stanja (opravičeni, neopravičeni, narava izostankov - strnjeni, nestrnjeni, posamezniki ali več učencev)\n";
                        echo "</textarea><br />";

                        echo "Priporočila, razmišljanja za naslednje šolsko leto<br />";
                        echo "<textarea name='priporocila' cols='80' rows='10'>";
                        echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
                        echo "B Cilji, ki sem jih kot razrednik želel/-a doseči na učnem/vzgojnem področju\n";
                        echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
                        echo "D Kje smo?\n";
                        echo "E Načrti in priporočila za naslednje šolsko leto\n";
                        echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
                        echo "</textarea><br />";
                        /*
                        echo "Analiza pedagoškega dela v učnih skupinah<br />";
                        echo "<textarea name='uspehi' cols='80' rows='10'>";
                        echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
                        echo "B Cilji, ki sem jih kot učitelj želel/-a doseči na učnem/vzgojnem področju\n";
                        echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
                        echo "D Kje smo?\n";
                        echo "E Načrti in priporočila za naslednje šolsko leto\n";
                        echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
                        echo "</textarea><br />";
                        */
                        echo "Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora<br />";
                        echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";

                        echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                        echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                        echo "<input name='level' type='hidden' value='".$VLevel."'>";
                        echo "<input name='id' type='hidden' value='1b1'>";
                        echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
                        echo "</form>";
                    }else{
                        echo "<h1>Niste izbrali razreda.</h1>";
                    }
                }else{
                    echo "<h1>Poročilo lahko vpiše le razrednik.</h1>";
                }
            }
        }
        break;
    case "1b1": //vpis poročila v bazo
        $Ucitelj=$_POST["razrednik"];
        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazrednik=$R["Priimek"]." ".$R["Ime"];
        }
        $VKomentar = str_replace($zamenjaj," ",$_POST["komentar"]);
        
        $VPohvale = str_replace($zamenjaj," ",$_POST["pohvale"]);
        if ($VLevel < 2 ){
            if (!(strpos($VPohvale,"(".$VRazrednik.")"))){
                $VPohvale=$VPohvale."\n(".$VRazrednik.")\n";
            }
        }
        $VVzgUkrepi = str_replace($zamenjaj," ",$_POST["vzgUkrepi"]);
        
        if (isset($_POST["uspehi"])){
            $VUspehi = str_replace($zamenjaj," ",$_POST["uspehi"]);
        }else{
            $VUspehi = "";
        }
        $VPriporocila = str_replace($zamenjaj," ",$_POST["priporocila"]);
        
        $VUcnoVzgDelo = str_replace($zamenjaj," ",$_POST["ucnoVzgDelo"]);
        
        $VRazred = $_POST["razred"];
        if (!is_numeric($VRazred)){
            $VRazred = 0;
        }
        //$VParalelka = $_POST["Paralelka"];
        if (isset($_POST["opb"])){
            $Vopb = str_replace($zamenjaj," ",$_POST["opb"]);
        }else{
            $Vopb = 0;
        }
        $VDevetletka = $_POST["vrstaos"];
        if (isset($_POST["lokacija"])){
            $VLokacija = $_POST["lokacija"];
        }else{
            $VLokacija="";
        }
        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "INSERT INTO TabRazrednikPorK (leto,razrednik,komentar,pohvale,vzgUkrepi,Uspehi,Priporocila,UcnoVzgDelo,razred,paralelka,opb,idRazred) VALUES (".$VLeto.",".$Ucitelj.",'".$VKomentar."','".$VPohvale."','".$VVzgUkrepi."','".$VUspehi."','".$VPriporocila."','".$VUcnoVzgDelo."',".$VRazred1.",'".$VParalelka."',".$Vopb.",".$VRazred.")";
        if (!($result = mysqli_query($link,$SQL))){
            die("Napaka pri vpisu poročila!<br />$SQL <br />");
        }

        if ($Opravila==1 ){
            $SQL = "SELECT tabdeldogodek.id FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Pedagoško poročilo' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["id"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        header("Location: PedPorocilo.php?id=0b");
        break;
    case "2b": // 'brisanje poročila
        if (!CheckDostop("PreglPoroc",$VUporabnik)){ 
            header("Location: nepooblascen.htm");
        }
        $SQL = "DELETE FROM TabRazrednikPorK WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);
        //'echo "Izbrisali ste zapis ".Vzapis."<br />"
        header("Location: PedPorocilo.php?id=0b");
        break;
    case "3b": //'popravljanje poročila
        $SQL = "SELECT TabRazrednikPorK.*,tabucitelji.ime,tabucitelji.priimek FROM ";
        $SQL = $SQL . "TabRazrednikPorK INNER JOIN tabucitelji ON TabRazrednikPorK.razrednik=tabucitelji.idUcitelj ";
        $SQL = $SQL . "WHERE TabRazrednikPorK.id=".$VZapis;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            if (($VidRazrednik==$R["Razrednik"]) or ($VLevel > 1 )){
                echo "<h2>Pedagoško poročilo - ".$R["priimek"]." ".$R["ime"].":</h2>";
                echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
                echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                echo "<input name='level' type='hidden' value='".$VLevel."'>";
                echo "<input type='hidden' name='razrednik' value='".$R["Razrednik"]."'>";
                echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<input type='hidden' name='id' value='3b1'>";
                echo "<input type='hidden' name='zapis' value='".$R["Id"]."'>";

                echo "<table border=0><tr>";
                echo "<td>Razred:</td>";
                echo "<td><input name='razred' type='hidden' value='".$R["idRazred"]."'>".$R["Razred"].". ".$R["Paralelka"];
                echo "</td>";
                echo "</tr>";
                echo "</table>";

                echo "Uspeh oddelka in rezultati učno vzgojnega dela<br />";
                echo "<textarea name='komentar' cols='80' rows='10'>".$R["Komentar"]."</textarea><br />";

                echo "Rezultati učno vzgojnega dela (OPB)<br />";
                echo "<textarea name='ucnoVzgDelo' cols='80' rows='10'>".$R["UcnoVzgDelo"]."</textarea><br />";

                echo "Vzgojna problematika in socialna klima oddelka<br />";
                echo "<textarea name='vzgUkrepi' cols='80' rows='10'>".$R["VzgUkrepi"]."</textarea><br />";

                echo "Priporočila, razmišljanja za naslednje šolsko leto<br />";
                echo "<textarea name='priporocila' cols='80' rows='10'>".$R["Priporocila"]."</textarea><br />";
                /*
                echo "Analiza pedagoškega dela v učnih skupinah<br />";
                echo "<textarea name='uspehi' cols='80' rows='10'>".$R["Uspehi"]."</textarea><br />";
                */
                echo "Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora<br />";
                echo "<textarea name='pohvale' cols='80' rows='10'>".$R["Pohvale"]."</textarea><br />";

                echo "<input name='submit' type='submit' value='Pošlji popravek'>";
                echo "</form>";
            }
        }
        break;
    case "3b1": // 'vpiši popravek
        $Ucitelj=$_POST["razrednik"];
        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$Ucitelj;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazrednik=$R["Priimek"]." ".$R["Ime"];
        }
        $VKomentar = str_replace($zamenjaj," ",$_POST["komentar"]);
        $VPohvale = str_replace($zamenjaj," ",$_POST["pohvale"]);
        if ($VLevel < 2 ){
            if (!(strpos($VPohvale,"(".$VRazrednik.")"))){
                $VPohvale=str_replace($zamenjaj," ",$VPohvale)."\n(".$VRazrednik.")\n";
            }
        }
        $VVzgUkrepi = $_POST["vzgUkrepi"];
        if (isset($_POST["uspehi"])){
            $VUspehi = str_replace($zamenjaj," ",$_POST["uspehi"]);
        }else{
            $VUspehi = "";
        }
        $VPriporocila = str_replace($zamenjaj," ",$_POST["priporocila"]);
        $VUcnoVzgDelo = str_replace($zamenjaj," ",$_POST["ucnoVzgDelo"]);
        $VRazred = $_POST["razred"];
        if (!is_numeric($VRazred)){
            $VRazred = 0;
        }
        if (isset($_POST["opb"])){
            $Vopb = str_replace($zamenjaj," ",$_POST["opb"]);
        }else{
            $Vopb = 0;
        }
        $VDevetletka = $_POST["vrstaos"];
        if (isset($_POST["lokacija"])){
            $VLokacija = $_POST["lokacija"];
        }else{
            $VLokacija="";
        }
        $VDevetletka = $_POST["vrstaos"];

        $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VRazred1=$R["razred"];
            $VParalelka=$R["oznaka"];
        }

        $SQL = "UPDATE  TabRazrednikPorK SET Komentar='" . $VKomentar . "',Pohvale='".$VPohvale."',VzgUkrepi='".$VVzgUkrepi."',Uspehi='".$VUspehi."',Priporocila='".$VPriporocila."',UcnoVzgDelo='".$VUcnoVzgDelo."',razred=".$VRazred1.",paralelka='".$VParalelka."',opb=".$Vopb.",idRazred=".$VRazred." WHERE Id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        if ($Opravila==1 ){
            $SQL = "SELECT tabdeldogodek.id FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Pedagoško poročilo' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["id"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        header("Location: PedPorocilo.php?id=0b");
        break;
    case "4b": // 'dodaj mnenje
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<form accept-charset='utf-8' name='form_porociloDod' method=post action='PedPorocilo.php'>";
            echo "<p>";
            echo "<b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b><br />";
            
            echo "<h2>Oddana mnenja za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

            echo "<p>";
            echo str_replace("\n","<br />",$R["Pohvale"]);
            echo "</p>";
            echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
            echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
            echo "<input name='id' type='hidden' value='4b1'>";
            echo "<p>Pozor: Napačno poslano mnenje bo lahko popravil le razrednik.</p>";
            echo "<input name='submit' type='submit' value='Pošlji dodatek'>";
            echo "</form>";
        }
        break;
    case "4b1":    //'vpiše dodatno mnenje
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$_POST["porocilo"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VPohvale=$R["Pohvale"]."\n";
            if (!(strpos($VPohvale,$_POST["pohvale"]."\n"."(".$ImeUcitelja.")")) ){
                $VPohvale=$VPohvale."\n".str_replace($zamenjaj," ",$_POST["pohvale"])."\n(".$ImeUcitelja.")\n";
            }
            //$VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
            $SQL = "UPDATE TabRazrednikPorK SET Pohvale='".$VPohvale."' WHERE id=".$R["Id"];
            $result = mysqli_query($link,$SQL);
            
            echo "<p><b>Mnenje šolske svetovalne službe in oddelčnega učiteljskega zbora</b><br />";
            
            echo str_replace("\n","<br />",$VPohvale);
            echo "</p><br /><br />";
            echo "<a href='PedPorocilo.php?id=0b'>Nazaj na poročila</a>";
        }
        break;
    case "5b": //'dodaj opb poročilo
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<form accept-charset='utf-8' name='form_porociloDod' method=post action='PedPorocilo.php'>";
            echo "<p>";
            echo "<b>Poročilo učitelja PB</b><br />";
            
            echo "<h2>Oddana poročila za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

            echo "<p>";
            echo str_replace("\n","<br />",$R["UcnoVzgDelo"]);
            echo "</p>";
            echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
            echo "<textarea name='pohvale' cols='80' rows='10'></textarea><br />";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
            echo "<input name='id' type='hidden' value='5b1'>";
            echo "<p>Pozor: Napačno poslano poročilo bo lahko popravil le razrednik.</p>";
            echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
            echo "</form>";
        }
        break;
    case "5b1": //    'vpiši poročilo opb
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$_POST["porocilo"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VPohvale=$R["UcnoVzgDelo"]."\n";
            if (!(strpos($VPohvale,$_POST["pohvale"]."\n"."(".$ImeUcitelja.")")) ){
                $VPohvale=$VPohvale."\n".$_POST["pohvale"]."\n(".$ImeUcitelja.")\n";
            }
            $VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
            $SQL = "UPDATE TabRazrednikPorK SET UcnoVzgDelo='".$VPohvale."' WHERE id=".$R["Id"];
            $result = mysqli_query($link,$SQL);
            
            echo "<p><b>Poročila učiteljev PB:</b><br />";
            
            echo str_replace("\n","<br />",$VPohvale);
            echo "</p><br /><br />";
            echo "<a href='PedPorocilo.php?id=0b'>Nazaj na poročila</a>";
        }
        break;
    case "6b": // 'dodaj mnenje
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$VZapis;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<form accept-charset='utf-8' name='form_skupine' method=post action='PedPorocilo.php'>";
            echo "<p>";
            echo "<b>Analiza pedagoškega dela v učnih skupinah</b><br />";
            
            echo "<h2>Oddana poročila za ".$R["Razred"].". ".$R["Paralelka"]."</h2>";

            echo "<p>";
            echo str_replace("\n","<br />",$R["Uspehi"]);
            echo "</p>";
            echo "Dodaj poročilo: (ne uporabljajte narekovajev!)<br />";
            echo "<textarea name='uspehi' cols='80' rows='10'>";
            echo "A Zaznana problematika oddelka na začetku šolskega leta\n";
            echo "B Cilji, ki sem jih kot učitelj želel/-a doseči na učnem/vzgojnem področju\n";
            echo "C Kaj sem naredil-a, da bi cilje dosegel/-la (dejavnosti, kriteriji, merila …)\n";
            echo "D Kje smo?\n";
            echo "E Načrti in priporočila za naslednje ocenjevalno obdobje\n";
            echo "F Izpostavite problematiko posameznih – izstopajočih učencev (učenec, problem, cilj, načrtovane in realizirane dejavnosti, doseženost ciljev, predlogi za naprej)\n";
            echo "</textarea><br />";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            echo "<input name='porocilo' type='hidden' value='".$R["Id"]."'>";
            echo "<input name='id' type='hidden' value='6b1'>";
            echo "<p>Pozor: Napačno poslano mnenje bo lahko popravil le razrednik.</p>";
            echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
            echo "</form>";
        }
        break;
    case "6b1":    //'vpiše dodatno mnenje
        $SQL = "SELECT * FROM TabRazrednikPorK WHERE id=".$_POST["porocilo"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VUspehi=$R["Uspehi"]."\n";
            if (!(strpos($VUspehi,$_POST["uspehi"]."\n"."(".$ImeUcitelja.")")) ){
                $VUspehi=$VUspehi."\n".str_replace($zamenjaj," ",$_POST["uspehi"])."\n(".$ImeUcitelja.")\n";
            }
            //$VPohvale=str_replace($ZaZamenjat,"",$VPohvale);
            $SQL = "UPDATE TabRazrednikPorK SET uspehi='".$VUspehi."' WHERE id=".$R["Id"];
            $result = mysqli_query($link,$SQL);
            
            echo "<p><b>Analiza pedagoškega dela v učnih skupinah</b><br />";
            
            echo str_replace("\n","<br />",$VUspehi);
            echo "</p><br /><br />";
            echo "<a href='PedPorocilo.php?id=0b'>Nazaj na poročila</a>";
        }
        break;
    case "0b":    //'spisek letnih poročil;
        echo "<h2>Pregled končnih poročil</h2>";
		echo "<p>Razredniki lahko za začetek pošljete tudi prazna poročila in na ta način drugim omogočite vnos njihovih komentarjev.</p>";
        echo "<table border=1>";
//        echo "<tr><th>Razred</th><th>Razrednik</th><th>OPB</th><th>Mnenja<br />učiteljev</th><th>Analiza<br />skupin</th><th width='20'><img src='img/m_poglej1.gif'></th><th width='20'><img src='img/m_edit1.gif'></th><th width='20'><img src='img/m_delete.gif'></th></tr>";
        echo "<tr><th>Razred</th><th>Razrednik</th><th>OPB</th><th>Mnenja<br />učiteljev</th><th width='20'><img src='img/m_poglej1.gif'></th><th width='20'><img src='img/m_edit1.gif'></th><th width='20'><img src='img/m_delete.gif'></th></tr>";

        $SQL = "SELECT TabRazrednikPorK.id AS rid,tabucitelji.priimek,tabucitelji.ime,tabrazdat.*,tabsola.solakratko FROM ";
        $SQL = $SQL . "(((TabRazrednikPorK LEFT JOIN tabpredmeti ON TabRazrednikPorK.opb=tabpredmeti.id) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON TabRazrednikPorK.razrednik=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON TabRazrednikPorK.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                //'razred
                if ($VecSol > 0){
                    echo "<td>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                }else{
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                }
                //'učitelj
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                //'OPB
                if ($R["razred"] < 6){
                    echo "<td align='center'><a href='PedPorocilo.php?id=5b&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                }else{
                    echo "<td align='center'>&nbsp;</td>";
                }
                //'Mnenja učiteljev
                echo "<td align='center'><a href='PedPorocilo.php?id=4b&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                //'Analiza skupin
                //echo "<td align='center'><a href='PedPorocilo.php?id=6b&zapis=".$R["rid"]."'><img src='img/m_edit2.gif' border='0' alt='Dodaj'></a></td>";
                //'Poglej
                echo "<td align='center'><a href='PorociloRazrednikaPregled.php?razred=".$R["id"]."&paralelka=".$R["oznaka"]."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'></a></td>";
                //'Popravi
                echo "<td align='center'><a href='PedPorocilo.php?id=3b&zapis=".$R["rid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                //'Briši
                if ($VLevel > 1){
                    echo "<td align='center'><a href='PedPorocilo.php?id=2b&zapis=".$R["rid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                }else{
                    echo "<td align='center'>&nbsp;</td>";
                }
                echo "</tr>";
            }
        }
        //'vrstica za dodajanje
        echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='PedPorocilo.php'>";
        echo "<tr>";
        //'razred
        echo "<td><select name='razred'>";
        echo "<option value='0' selected='selected'>&nbsp;</option>";
        if ($VecSol > 0){
            for ($Indx=0;$Indx <= $StRazredov;$Indx++){
                echo "<option value='".$Razredi[$Indx][0]."'>".$Razredi[$Indx][1].". ".$Razredi[$Indx][2]." - ".$Razredi[$Indx][3]."</option>";
            }
        }else{
            for ($Indx=0;$Indx <= $StRazredov;$Indx++){
                echo "<option value='".$Razredi[$Indx][0]."'>".$Razredi[$Indx][1].". ".$Razredi[$Indx][2]."</option>";
            }
        }
        echo "</select></td>";
        //'učitelj
        if ($VLevel < 2 ){
            echo "<td><input name='ucitelj' type='hidden' value='".$Ucitelj."'>".$VImeRazrednika."</td>";
        }else{
            echo "<td><select name='ucitelj'>";
            echo "<option value='0' selected='selected'>&nbsp;</option>";
            $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY Priimek,Ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }
            echo "</select></td>";
        }
        //'OPB
        //echo "<td>&nbsp;</td>";
        //'Mnenja učiteljev
        //echo "<td>&nbsp;</td>";
        //'Poglej
        //echo "<td>&nbsp;</td>";
        //'Popravi
        echo "<td colspan='5'><input name='submit' type='submit' value='Novo poročilo'></td>";
        //'Briši
        //echo "<td>&nbsp;</td>";
        echo "</tr>";
        echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
        echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
        echo "<input name='level' type='hidden' value='".$VLevel."'>";
        echo "<input name='id' type='hidden' value='1b'>";
        echo "</form>";
        echo "</table><br />";
        break;
}
echo "<h2><a href='PedPorocilo.php?id=0a'>Polletna pedagoška poročila</a></h2>";
echo "<h2><a href='PedPorocilo.php?id=0b'>Končna pedagoška poročila</a></h2>";
?>

</body>
</html>
