<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izbor meseca in leta
</title>
</head>
<body>

<?php
$VLeto=intval($Danes->format('Y'));
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik="";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo="";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel=0;
}

$RazsirjenVnos=true;

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $VUporabnikId=$UciteljComp;
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }
    if (isset($_POST["mesec"])){
        $VMesec=$_POST["mesec"];
    }else{
        if (isset($_GET["mesec"])){
            $VMesec=$_GET["mesec"];
        }else{
            $VMesec=$ActualMonth;
        }
    }
    echo "<br />";
    switch ($Vid) {
	    case "1":
		    echo "<form name='cas' method='post' action='PregledDelaMesec.php'>";
            break;
	    case "2":
		    echo "<form name='racunovodstvo' method='post' action='PregledDelaRacunovodstvo.php'>";
            echo "<input name='vkljucidneve' type='checkbox'>Prikaži tudi podatke o dnevih (poleg ur)<br />";
            break;
	    case "3":
		    echo "<form name='casVsi' method='post' action='PDMVsi.php'>";
            break;
	    case "4":
		    echo "<form name='casVsi' method='post' action='PDMVsiMinusi.php'>";
    }
}
?>
<h2>Izberite leto in mesec</h2><br />
<table border='0'>
<tr>
	<td>
		Leto: 
	</td>
	<td>
		<select name="leto">
		<?php  
        echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) ."</option>";
		echo "<option value='" .  $VLeto  . "' selected>" . $VLeto ."</option>";
		echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) ."</option>";
        echo "<option value='" .  ($VLeto-2)  . "'>" . ($VLeto -2) ."</option>";
        echo "<option value='" .  ($VLeto-3)  . "'>" . ($VLeto -3) ."</option>";
        echo "<option value='" .  ($VLeto-4)  . "'>" . ($VLeto -4) ."</option>";
        echo "<option value='" .  ($VLeto-5)  . "'>" . ($VLeto -5) ."</option>";
		?>
		</select>
	</td>
</tr>
<tr>
	<td>
		<?php
		echo "<b>Mesec:</b></td><td><select name='mesec'>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			if ($Indx==$VMesec){
				echo "<option value=".$Indx." selected='selected'>".$Indx."</option>";
			}else{
				echo "<option value=".$Indx.">".$Indx."</option>";
			}
		}
		echo "</select><br />";
		
		?>
	</td>
</tr>
<tr>
	<td>
		<?php  
		if ($_GET["id"]=="2"){
			echo "Cena prehrane:</td><td> <input name='prehrana' type='text' size='8'>";
		}
		?>
	</td>
</tr>
<tr>
	<td>
		<input name="submit" type="submit" value="Pošlji">
	</td>
</tr>
</table>
</form>
</body>
</html>
