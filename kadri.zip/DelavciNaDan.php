<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis delavcev
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

if (isset($_POST["mesec"])){
    $VMesec=$_POST["mesec"];
}else{
    $VMesec=$Danes->format('n');
}
if (isset($_POST["dan"])){
	$VDan=$_POST["dan"];
}else{
	$VDan=$Danes->format('j');
}

echo "<h2>Delavci zaposleni na dan</h2>";
echo "<form accept-charset='utf-8' name='casVsi' method=post action='DelavciNaDan.php'>";
echo "Dan: <select name='dan'>";
for ($Indx=1;$Indx <= 31;$Indx++){
	if ($Indx==$VDan){
		echo "<option value=".$Indx." selected>".$Indx."</option>";
	}else{
		echo "<option value=".$Indx.">".$Indx."</option>";
	}
}
echo "</select>";
echo " Mesec: <select name='mesec'>";
for ($Indx=1;$Indx <= 12;$Indx++){
	if ($Indx==$VMesec ){
		echo "<option value=".$Indx." selected>".$Indx."</option>";
	}else{
		echo "<option value=".$Indx.">".$Indx."</option>";
	}
}
echo "</select>";
echo " Leto: ";
echo "<select name='leto'>";
echo "<option value='" .  $VLeto  . "' selected>" . $VLeto ."</option>";
echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) ."</option>";
echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) ."</option>";
echo "</select>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form><br />";

$SQL = "SELECT tabucitelji.*, tabstatus.Status,tabstatus.Status AS sstatus,tabucitelji.Status AS ustatus FROM tabucitelji";
$SQL = $SQL . " INNER JOIN tabstatus ON tabucitelji.Status=tabstatus.IdStatus WHERE tabucitelji.iducitelj > 0";
$SQL = $SQL . " ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
$result = mysqli_query($link,$SQL);

$DanPregleda=new DateTime($VLeto."-".$VMesec."-".$VDan);
$VLetoPregled=$VLeto;
$Indx=1;
while ($R = mysqli_fetch_array($result)){
	$oUcitelj=New RUcitelj;
	$oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
	
	$Delavec[$Indx][0]=$oUcitelj->getIdUcitelj();
	$Delavec[$Indx][1]=$oUcitelj->getPriimek()." ".$oUcitelj->getIme();
	$Delavec[$Indx][2]=$oUcitelj->getDatRoj()->format('Y');
	$Delavec[$Indx][3]=$oUcitelj->getIzobrazba();
	
	$Delavec[$Indx][4]=$oUcitelj->getDelMesto();
	$Delavec[$Indx][7]=$oUcitelj->getStatusDelavca();
	$Delavec[$Indx][9]=$oUcitelj->getDatumStart()->format('d.m.Y');
	$Delavec[$Indx][10]=$oUcitelj->getDatumEnd()->format('d.m.Y');
	$Delavec[$Indx][11]=$oUcitelj->getZaposlen($DanPregleda);
	$oUcitelj=null;
	$Indx=$Indx+1;
}
$StDelavcev=$Indx-1;

echo "<table border=1 cellspacing=0>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek in ime</th><th>Starost</th><th>Stopnja izobrazbe</th>";
echo "<th>Opis dela</th><th>Status</th><th>Od</th><th>Do</th>";
echo "</tr>";

$ColorChange=true;
$i1=0;
for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
	if ($Delavec[$Indx][11] ){
		$i1=$i1+1;
		if ($ColorChange ){
			echo "<tr bgcolor=lightyellow>";
		}else{
			echo "<tr bgcolor=#FFFFCC>";
		}
		$ColorChange=!$ColorChange;

		echo "<td>".$i1."</td>";
		echo "<td><a href='IzpisUcitelja.php?idUcitelj=".$Delavec[$Indx][0]."&leto=".$VLeto."'>".$Delavec[$Indx][1]."</a></td>";
		echo "<td align=center>".($VLeto-$Delavec[$Indx][2])."</td>";
		echo "<td align=center>".$Delavec[$Indx][3]."&nbsp;</td>";
		echo "<td>".$Delavec[$Indx][4]."&nbsp;</td>";
		echo "<td>".$Delavec[$Indx][7]."&nbsp;</td>";
		echo "<td>".$Delavec[$Indx][9]."&nbsp;</td>";
		echo "<td>".$Delavec[$Indx][10]."&nbsp;</td>";
		echo "</tr>";
	}
}
echo "</table><br /><br />";

?>
<a href="prijava.php">Nazaj na glavni meni</a><br />

</body>
</html>
