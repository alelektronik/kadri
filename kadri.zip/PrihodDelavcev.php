<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vpis prihodov in odhodov
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>

<?php
$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
/*
if (!CheckDostop("DelKontr",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
function LeadZero($x){
	if (strlen($x) < 2){
		$x="0".$x;
	}
	return $x;
}

$VDelavec = $_POST["delavec"];
if (isset($_POST["datum"])){
    if (isDate($_POST["datum"])){
        $Datum=new DateTime(isDate($_POST["datum"]));
        $VLeto=$Datum->format('Y');
        $VMesec=$Datum->format('n');
        $VDan=$Datum->format('j');
    }else{
        $VLeto=$Danes->format('Y');
        $VMesec=$Danes->format('n');
        $VDan=$Danes->format('j');
    }
}else{
    $VLeto = $_POST["leto"];
    $VMesec = $_POST["mesec"];
    $VDan = $_POST["dan"];
}
$VUra = $_POST["ura"];
$VMinuta = $_POST["minuta"];
$Vtip = $_POST["tip"];

if (!isDate($VDan.".".$VMesec.".".$VLeto)) {
    if ($Vid != "1") {
        header("Location: VpisPrihodaDelavcev.php");
    }else{
        header("Location: VpisPrihodov.php?id=1&prikaz=".$VDelavec);
    }
}else{
    $DatumStart=new DateTime($VLeto."-".$VMesec."-".$VDan." ".$VUra.":".$VMinuta.":00");
    $DatumStart1=$DatumStart->format('Ymd');
    $SQL = "SELECT stdelavca FROM kadrovi WHERE EMSO='".$VDelavec."'";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $ZaVpis=$R["stdelavca"];
    }else{
        $ZaVpis="0000";
    }
    switch ($Vtip){
	    case "1001":
		    $SQL = "INSERT INTO tabprihodi (sifra,datumprih,letopr,mesecpr,danpr,uraprih,minprih,vrstaprih,minut,sistemdat,pripomba) VALUES ('".$ZaVpis."','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",'".$Vtip."',".($VUra*60+$VMinuta).",'".$DatumStart->format('Y-m-d H:i:s')."','".$VUporabnik."')";
            break;
	    case "3001":
		    $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$ZaVpis."','".$Vtip."','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$DatumStart->format('Y-m-d H:i:s')."','".$VUporabnik."')";
            break;
	    case "3002":
		    $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$ZaVpis."','".$Vtip."','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$DatumStart->format('Y-m-d H:i:s')."','".$VUporabnik."')";
            break;
	    case "3010":
		    $SQL = "INSERT INTO tabprihodi (sifra,vrstaprih,datumodh,letodh,mesecodh,danodh,uraodh,minodh,minut,sistemdat,pripomba) VALUES ('".$ZaVpis."','".$Vtip."','".$DatumStart->format('Y-m-d')."','".$VLeto."','".$VMesec."','".$VDan."',".$VUra.",".$VMinuta.",".($VUra*60+$VMinuta).",'".$DatumStart->format('Y-m-d H:i:s')."','".$VUporabnik."')";
    }
    $result = mysqli_query($link,$SQL);

    if ($Vid != "1") {
        header("Location: VpisPrihodaDelavcev.php");
    }else{
        header("Location: VpisPrihodov.php?id=1&prikaz=".$VDelavec);
    }
}
?>
<a href="prijava.php">Nazaj na glavni meni</a><br />

</body>
</html>
