<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Doprinašanje
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}

if (isset($_POST["idUcitelj"])){
    $ucitelj = $_POST["idUcitelj"];
}else{
    if (isset($_GET["idUcitelj"])){
        $ucitelj = $_GET["idUcitelj"];
    }else{
        if (isset($_SESSION["idUcitelj"])){ 
            $ucitelj = $_SESSION["idUcitelj"];
        }else{
            $ucitelj = 0;
        }
    }
}

if ($UciteljComp <> $ucitelj ) {
    if (!CheckDostop("DelKontr",$VUporabnik)) { 
        header("Location: nepooblascen.htm");
    }
}
	
if (isset($_POST["id"])){    
    switch ($_POST["id"]){
	    case 1:
		    for ($Indx=1;$Indx <=$_POST["StZapisov"];$Indx++){
                if (isset($_POST["doprin".$Indx])){
				    $Zacasno="true";
                }else{
                    $Zacasno="false";
			    }
			    $SQL = "UPDATE tabucitelji SET Doprinasanje=".$Zacasno." WHERE idUcitelj=".$_POST["ucitelj".$Indx];
                $result = mysqli_query($link,$SQL);
		    }
    }
}
$SQL = "SELECT tabucitelji.* FROM tabucitelji ";
$SQL = $SQL . " WHERE tabucitelji.Status > 0 ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
$result = mysqli_query($link,$SQL);

$Indx=1;

echo "<h2>Določanje doprinašanja ur</h2>";
echo "<form name='form_zdrpregledi' method=post action='Doprinasanje.php'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "<table border=1 cellspacing=0>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek Ime</th><th>Delo</th>";
echo "<th>Doprinašanje</th>";
echo "</tr>";

while ($R = mysqli_fetch_array($result)){
    $oUcitelj = new RUcitelj;
    $oUcitelj->PreberiSe($R["IdUcitelj"],$VLetoPregled,$VLeto);
	echo "<tr>";
	echo "<td>".$Indx."</td>";
	echo "<td><input name='ucitelj".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
	echo "<td>".$oUcitelj->getDelMesto()."</td>";
			if ($R["Doprinasanje"]){
				echo "<td><input name='doprin".$Indx."' type='checkbox' checked='checked'></td>";
			}else{
				echo "<td><input name='doprin".$Indx."' type='checkbox'></td>";
			}
	echo "</tr>";
	$Indx=$Indx+1;
}
echo "</table>";
echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>";

?>

</body>
</html>
