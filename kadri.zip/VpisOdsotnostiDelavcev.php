<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odsotnosti
</title>
</head>
<body>

<?php
$Danes=new DateTime("now");
$VLeto=$Danes->format('Y');
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

echo "<form accept-charset='utf-8' name='rezultati' method='post' action='OdsotnostDelavcev.php'>";
echo "<h2>Vpis odsotnosti delavcev</h2><br>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>";
echo "        Delavec:<select name='delavec'>";
echo "<option value=0>Ni izbran</option>";
$SQL = "SELECT * FROM kadrovi ORDER BY priimime";
$result = mysqli_query($link,$SQL);

while ($R = mysqli_fetch_array($result)){
    if (strlen($R["PRIIMIME"]) > 0 ){
        echo "<option value=".$R["STDELAVCA"].">".$R["PRIIMIME"]."</option>";
    }
}

echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "</table>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>Začetek:</td>";
echo "    <td>";
echo "        Dan:<select name='dan'>";
echo "<option selected>" . $Danes->format('j') . "</option>";
for ($Indx=1;$Indx <= 31;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Mesec:<select name='mesec'>";
echo "<option selected>" . $Danes->format('n') . "</option>";
for ($Indx=1;$Indx <= 12;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Leto: <select name='leto'>";
echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "</option>";
echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "</option>";
echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "</option>";
echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "<tr>";
echo "    <td>Konec (vključno):</td>";
echo "    <td>";
echo "        Dan:<select name='DanEnd'>";
echo "<option selected>" . $Danes->format('j') . "</option>";
for ($Indx=1;$Indx <= 31;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Mesec:<select name='MesecEnd'>";
echo "<option selected>" . $Danes->format('n') . "</option>";
for ($Indx=1;$Indx <= 12;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Leto: <select name='LetoEnd'>";
echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "</option>";
echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "</option>";
echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "</option>";
echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "</table>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>";
echo "        Tip odsotnosti:<select name='odsotnost'>";
$SQL = "SELECT * FROM tabsifraodsotnosti";
$result = mysqli_query($link,$SQL);

while ($R = mysqli_fetch_array($result)){
    echo "<option value=".$R["sifra"].">".$R["odsotnost"]."</option>";
}

echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "</table>";

echo "<input name='submit' type='submit' value='Pošlji'><br />";
echo "</form><br />";

$SQL = "SELECT kadrovi.priimime,tabodsotnost.odsotnoststart,tabodsotnost.odsotnostend,tabsifraodsotnosti.odsotnost,tabodsotnost.id AS oid FROM (tabodsotnost ";
$SQL .= "INNER JOIN kadrovi ON tabodsotnost.stdelavca=kadrovi.stdelavca) ";
$SQL .= "INNER JOIN tabsifraodsotnosti ON tabodsotnost.sifraodsotnosti=tabsifraodsotnosti.sifra ";
$SQL .= "WHERE year(tabodsotnost.odsotnostend) = ".$Danes->format('Y')." OR year(tabodsotnost.odsotnoststart) = ".$Danes->format('Y');
$SQL .= " ORDER BY kadrovi.priimime,tabsifraodsotnosti.Sifra,tabodsotnost.odsotnoststart DESC ";
$result = mysqli_query($link,$SQL);

echo "<form accept-charset='utf-8' name='odsotnosti' method='post' action='brisiOdsotnostDel.php'>";
echo "<input name='submit' type='submit' value='Briši'><br />";
echo "<table border=1>";
echo "<tr>";
echo "<th>Ime</th>";
echo "<th>Začetek</th>";
echo "<th>Konec</th>";
echo "<th>Tip</th>";
echo "<th>Briši</th>";
echo "</tr>";
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>".$R["priimime"]."</td>";
    //$Datum=new DateTime(isDate($R["odsotnoststart"]));
    $Datum=new DateTime($R["odsotnoststart"]);
    echo "<td>".$Datum->format('d.m.Y')."</td>";
    //$Datum=new DateTime(isDate($R["odsotnostend"]));
    $Datum=new DateTime($R["odsotnostend"]);
    echo "<td>".$Datum->format('d.m.Y')."</td>";
    echo "<td>".$R["odsotnost"]."</td>";
    echo "<td align='center'>";
    echo "<input name='ods_".$Indx."' type='checkbox'><input name='br_".$Indx."' type='hidden' value='".$R["oid"]."'>";
    //echo "<a href='brisiOdsotnostDel.php?id=".$R["oid"]."'>Briši</a>";
    echo "</td>";
    echo "</tr>";
    $Indx += 1;
}
echo "</table><br />";
echo "<input name='stevilo' type='hidden' value='".($Indx-1)."'>";
echo "<input name='submit' type='submit' value='Briši'>";
echo "</form>";
?>

</body>
</html>
