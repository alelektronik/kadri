<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Delovni dnevi po mesecih
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Prazniki",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
	case "1": // 'vnos števila delovnih dni

		$SQL = "SELECT * FROM TabDniPouka ORDER BY leto DESC";
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			$ActualYear=$R["leto"];
		}else{
			$ActualYear=$Danes->format('Y')-1;
		}
		
		echo "<h2>Vnos dni pouka po mesecih</h2>";
		echo "<form name='DneviPouka' method='post' action='VnosDniPouka.php'>";
		echo "<table border='1'>";
		echo "<tr><th>Leto</th><th>sep</th><th>okt</th><th>nov</th><th>dec</th><th>jan</th><th>feb</th><th>mar</th><th>apr</th><th>maj</th><th>jun</th><th>jun/9r</th><th>Skupaj</th><th>Briši</th></tr>";
		
		echo "<tr>";
		echo "<td>";
		echo "<select name='leto'>";
		for ($indx=($Danes->format('Y')-1);$indx <= ($Danes->format('Y')+3);$indx++){
			if ($indx==($ActualYear+1)){
				echo "<option selected>".$indx."</option>";
			}else{
				echo "<option>".$indx."</option>";
			}
		}
		echo "</select>";
		echo "</td>";
		for ($indx=1;$indx <= 10;$indx++){
			echo "<td><select name='m".$indx."'>";
			for ($indx1=0;$indx1 <= 25;$indx1++){
				if ($indx1==0){
					echo "<option value='".$indx1."' selected='selected'>&nbsp;</option>";
				}else{
					echo "<option value='".$indx1."'>".$indx1."</option>";
				}
			}
			echo "</select></td>";
		}
		//'dodatno za junij - 9r
		echo "<td><select name='m109'>";
		for ($indx1=0;$indx1 <= 25;$indx1++){
			if ($indx1==0){
				echo "<option value='".$indx1."' selected='selected'>&nbsp;</option>";
			}else{
				echo "<option value='".$indx1."'>".$indx1."</option>";
			}
		}
		echo "</select></td>";
		echo "<td>&nbsp;</td><td><input name='submit' type='submit' value='Pošlji'></td>";
        
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			$VsotaDni=$R["m1"]+$R["m2"]+$R["m3"]+$R["m4"]+$R["m5"]+$R["m6"]+$R["m7"]+$R["m8"]+$R["m9"];
			echo "<tr>";
			echo "<td>".$R["leto"]."</td>";
			echo "<td>".$R["m1"]."</td>";
			echo "<td>".$R["m2"]."</td>";
			echo "<td>".$R["m3"]."</td>";
			echo "<td>".$R["m4"]."</td>";
			echo "<td>".$R["m5"]."</td>";
			echo "<td>".$R["m6"]."</td>";
			echo "<td>".$R["m7"]."</td>";
			echo "<td>".$R["m8"]."</td>";
			echo "<td>".$R["m9"]."</td>";
			echo "<td>".$R["m10"]."</td>";
			echo "<td>".$R["m109"]."</td>";
			echo "<td>".($VsotaDni+$R["m10"])."/".($VsotaDni+$R["m109"])."</td>";
			echo "<td><a href='VnosDniPouka.php?id=3&zapis=".$R["id"]."'>Briši</a></td>";
			echo "</tr>";
		}
		
		echo "</table>";
		echo "<input name='id' type='hidden' value='2'>";
		echo "</form>";
        break;
	case "2": // 'vpis zapisa
		$SQL = "SELECT * FROM TabDniPouka WHERE leto=".$_POST["leto"];
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			$SQL = "UPDATE TabDniPouka SET ";
			$SQL = $SQL . "m1=".$_POST["m1"];
			$SQL = $SQL .", m2=".$_POST["m2"];
			$SQL = $SQL .", m3=".$_POST["m3"];
			$SQL = $SQL .", m4=".$_POST["m4"];
			$SQL = $SQL .", m5=".$_POST["m5"];
			$SQL = $SQL .", m6=".$_POST["m6"];
			$SQL = $SQL .", m7=".$_POST["m7"];
			$SQL = $SQL .", m8=".$_POST["m8"];
			$SQL = $SQL .", m9=".$_POST["m9"];
			$SQL = $SQL .", m10=".$_POST["m10"];
			$SQL = $SQL .", m109=".$_POST["m109"];
			$SQL = $SQL ." WHERE id=".$R["id"];
		}else{
			$SQL = "INSERT INTO TabDniPouka (leto,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m109) VALUES ";
			$SQL = $SQL . "(".$_POST["leto"].",";
			$SQL = $SQL . $_POST["m1"].",";
			$SQL = $SQL . $_POST["m2"].",";
			$SQL = $SQL . $_POST["m3"].",";
			$SQL = $SQL . $_POST["m4"].",";
			$SQL = $SQL . $_POST["m5"].",";
			$SQL = $SQL . $_POST["m6"].",";
			$SQL = $SQL . $_POST["m7"].",";
			$SQL = $SQL . $_POST["m8"].",";
			$SQL = $SQL . $_POST["m9"].",";
			$SQL = $SQL . $_POST["m10"].",";
			$SQL = $SQL . $_POST["m109"].")";
		}
		$result = mysqli_query($link,$SQL);
        
		header ("Location: VnosDniPouka.php?id=1");
        break;
	case "3": //brisanje
		$SQL = "DELETE FROM TabDniPouka WHERE id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);
		
		header ("Location: VnosDniPouka.php?id=1");
}

?>

</body>
</html>
