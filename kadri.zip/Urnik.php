<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Urnik
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

function dvomestno($x){
    if ($x < 10){
        return "0".$x;
    }else{
        return "".$x;
    }
}

$RazsirjenVnos=true;

$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');

    if (isset($_POST["od"])){
        $od=intval($_POST["od"]);
    }else{
        if (isset($_GET["od"])){
            $od=intval($_GET["od"]);
        }else{
            $SQL = "SELECT od,do FROM taburnik ORDER BY id DESC LIMIT 0,1";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $od=$R["od"];
            }else{
                $Datum=new DateTime($VLeto."-09-01");
                $od=intval($Datum->format('Ymd'));
            }
        }
    }
    echo "<form  name='Urnik' method=post action='Urnik.php'>";
    echo "<select name='od'>";
    $SQL = "SELECT DISTINCT od,do FROM taburnik WHERE leto=".$VLeto;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        if ($od == $R["od"]){
            echo "<option value='".$R["od"]."' selected='selected'>".$R["od"]." - ".$R["do"]."</option>";
        }else{
            echo "<option value='".$R["od"]."'>".$R["od"]." - ".$R["do"]."</option>";
        }
    }
    echo "</select>";
    echo "<input name='submit' type='submit' value='Izberi'>";
    echo "</form>";

    echo "<a href='Prijava.php'>Nazaj na glavni meni</a><br />";
    /*
    echo "<a href='UrnikUciteljiPDF.php' target='new_win'>Urnik učiteljev (PDF ČB)</a> <a href='UrnikUciteljiBPDF.php' target='new_win'> (PDF Barvno)</a><br />";
    echo "<a href='UrnikRazrediPDF.php' target='new_win'>Urnik razredov (PDF ČB)</a> <a href='UrnikRazrediBPDF.php' target='new_win'> (PDF Barvno)</a><br />";
    echo "<a href='UrnikProstoriPDF.php' target='new_win'>Urnik prostorov (PDF ČB)</a> <a href='UrnikProstoriBPDF.php' target='new_win'> (PDF Barvno)</a><br />";
    echo "<a href='UrnikUciteljiVSIBPDF.php' target='new_win'>Urnik učiteljev-predmetna stopnja (PDF Barvno)</a><br />";
    echo "<a href='UrnikUciteljiRBPDF.php' target='new_win'>Urnik učiteljev-razredna stopnja (PDF Barvno)</a><br />";
    echo "<a href='UrnikUciteljiP10BPDF.php' target='new_win'>Urnik učiteljev-predmetna stopnja/10 (PDF Barvno)</a><br />";
    echo "<a href='UrnikUciteljiR10BPDF.php' target='new_win'>Urnik učiteljev-razredna stopnja/10 (PDF Barvno)</a><br />";
    echo "<a href='UrnikRazrediPBPDF.php' target='new_win'>Urnik razredov predmetne stopnje (PDF Barvno)</a><br />";
    echo "<a href='UrnikRazrediRBPDF.php' target='new_win'>Urnik razredov razredne stopnje (PDF Barvno)</a><br />";
    echo "<a href='UrnikProstori10BPDF.php' target='new_win'>Urnik prostorov (PDF Barvno)</a><br />";
    echo "<br />";
    */
    echo "<a href='Urnik.php?id=1&od=".$od."'>Urnik po učiteljih - 1</a><br />";
    echo "<a href='Urnik.php?id=2&od=".$od."'>Urnik po razredih - 1</a><br />";
    echo "<a href='Urnik.php?id=3&od=".$od."'>Urnik po prostorih - 1</a><br />";
    echo "<a href='Urnik.php?id=4&od=".$od."'>Urnik po učiteljih - 2</a><br />";
    echo "<a href='Urnik.php?id=5&od=".$od."'>Urnik po razredih - 2</a><br />";
    echo "<a href='Urnik.php?id=6&od=".$od."'>Urnik po prostorih - 2</a><br />";
    echo "<a href='Urnik.php?id=7&od=".$od."'>Pogovorne ure</a><br />";

    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            $Vid=1;
        }
    }
    $ColorChange=false;

    //'Izpis osebnih podatkov
    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
    //'echo "<br />" & $SQL & "<br />"
    $result = mysqli_query($link,$SQL);
	    $Indx1=0;
	    while ($R = mysqli_fetch_array($result)){
		    $VUcitelji[$Indx1][0] = $R["iducitelj"];
		    $VUcitelji[$Indx1][1] = $R["priimek"];
		    $VUcitelji[$Indx1][2] = $R["ime"];
		    $Indx1=$Indx1+1;
	    }
	    $StUciteljev=$Indx1-1;

	    $SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
	    $result = mysqli_query($link,$SQL);
	    
	    $Indx=0;
	    while ($R = mysqli_fetch_array($result)){
		    $VPredmeti[$Indx][0] = $R["id"];
		    $VPredmeti[$Indx][1] = $R["oznaka"];
		    $VPredmeti[$Indx][2] = $R["opis"];
		    $VPredmeti[$Indx][3] = $R["prioriteta"];
		    $Indx=$Indx+1;
	    }
	    $StPredmetov=$Indx-1;
	    
	    $SQL = "SELECT idprostor,stevilka,oznaka,opis FROM tabprostor  ORDER BY IdProstor";
	    $result = mysqli_query($link,$SQL);
	    
	    $Indx=0;
	    while ($R = mysqli_fetch_array($result)){
		    $VProstor[$R["idprostor"]][0] = $R["idprostor"];
		    $VProstor[$R["idprostor"]][1] = $R["stevilka"];
		    $VProstor[$R["idprostor"]][2] = $R["oznaka"];
		    $VProstor[$R["idprostor"]][3] = $R["opis"];
		    $Indx=$Indx+1;
	    }
	    $StProstorov=$Indx-1;

    switch ($Vid){
        case "1":
            //'izpis urnika po uciteljih
            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,tabrazdat.idsola,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY tabucitelji.Priimek,tabucitelji.Ime,taburnik.DanVTednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            for ($Indx2=0;$Indx2 <= 150;$Indx2++){
	            $Obremenitev[$Indx2]=0;
	            for ($Indx=0;$Indx <= 5;$Indx++){
		            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
		            }
	            }
            }

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
		            $IzbraniUcitelj=$StUciteljev+1;
		            for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
			            if ($R["iducitelj"]==$VUcitelji[$Indx2][0] ){
				            $IzbraniUcitelj=$Indx2;
			            }
		            }
                    if ($VecSol > 0){
		                switch ($R["nivo"]){
			                case 1:
                            case 2:
                            case 3:
				                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
                                break;
			                case 7:
                            case 8:
                            case 9:
				                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
                                break;
			                default:
				                if ($R["razred"]==0 ){
					                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'></td></tr>";
				                }else{
					                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
				                }
		                }
                    }else{
                        switch ($R["nivo"]){
                            case 1:
                            case 2:
                            case 3:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                break;
                            case 7:
                            case 8:
                            case 9:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                break;
                            default:
                                if ($R["razred"]==0 ){
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'></td></tr>";
                                }else{
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                }
                        }
                    }
	            $Indx=$Indx+1;
            }

            for ($Indx2=0;$Indx2 <= 150;$Indx2++){
	            for ($Indx=0;$Indx <= 5;$Indx++){
		            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            if ($UrnikUcitelj[$Indx2][$Indx][$Indx0] != "" ){
				            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
			            }
		            }
	            }
            }
            echo "<a name='1'></a>";
            echo "<h2>Urnik po učiteljih (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
            echo "<th>Učitelj</th>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            echo "<th>".Int2Dan($Indx)."</th>";
	            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
		            echo "<th></th>";
	            }
            }
            echo "<th>Skupaj ur</th>";
            echo "<tr bgcolor='cyan'><td></td>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
		            echo "<td>".$Indx0."</td>";
	            }
            }
            echo "<td></td></tr>";

            $ColorChange=true;
            for ($Indx=0;$Indx <= $StUciteljev;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            if ($ColorChange ){
			            echo "<tr bgcolor='lightyellow'>";
		            }else{
			            echo "<tr bgcolor='#FFFFCC'>";
		            }
		            $ColorChange=!$ColorChange;
		            echo "<td><a href='IzpisUcitelja.php?idUcitelj=".$VUcitelji[$Indx][0]."'>".$VUcitelji[$Indx][1].", ".$VUcitelji[$Indx][2]."</a></td>";
		            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
			            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
				            if ($UrnikUcitelj[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
		            }
		            echo "<td>".$Obremenitev[$Indx]."</td>";
	            }
            }

            echo "</table>";
            break;
        case "2":
            //'izpis urnika po razredih
            for ($Indx2=0;$Indx2 <= 50;$Indx2++){
	            $Obremenitev[$Indx2]=0;
	            for ($Indx=0;$Indx <= 5;$Indx++){
		            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            $UrnikRazred[$Indx2][$Indx][$Indx0]="";
		            }
	            }
            }

            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,tabrazdat.idsola,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.vrstaos,taburnik.DanVTednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            $IzbraniRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
	            if ($R["razred"].$R["paralelka"].$R["idsola"] != $IzbraniRazred ){
		            $Indx=$Indx+1;
		            $IzbraniRazred=$R["razred"].$R["paralelka"].$R["idsola"];
                    if ($VecSol > 0){
		                $VRazred[$Indx]=$R["razred"].". ".$R["paralelka"].$R["idsola"];
                    }else{
                        $VRazred[$Indx]=$R["razred"].". ".$R["paralelka"];
                    }
		            $VRazredDat[$Indx][0]=$R["razred"];
		            $VRazredDat[$Indx][1]=$R["paralelka"];
		            $VRazredDat[$Indx][2]=$R["vrstaos"];
		            $VRazredDat[$Indx][3]=$R["idrazred"];
	            }
	            switch ($R["nivo"]){
		            case 1:
                    case 2:
                    case 3:
			            $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                        break;
		            case 7:
                    case 8:
                    case 9:
			            $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                        break;
		            default:
			            $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
	            }
            }
            $StRazredov=$Indx;

            for ($Indx2=0;$Indx2 <= 50;$Indx2++){
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            if ($UrnikRazred[$Indx2][$Indx][$Indx0] != "" ){
				            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
			            }
		            }
	            }
            }

            echo "<a name='2'></a>";
            echo "<br /><h2>Urnik po razredih (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
            echo "<th>Razred</th>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            echo "<th>".Int2Dan($Indx)."</th>";
	            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
		            echo "<th></th>";
	            }
            }
            echo "<th>Skupaj ur</th>";
            echo "<tr bgcolor='cyan'><td></td>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
		            echo "<td>".$Indx0."</td>";
	            }
            }
            echo "<td></td></tr>";

            $ColorChange=true;
            for ($Indx=1;$Indx <= 50;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            if ($ColorChange ){
			            echo "<tr bgcolor='lightyellow'>";
		            }else{
			            echo "<tr bgcolor='#FFFFCC'>";
		            }
		            $ColorChange=!$ColorChange;
		            echo "<td><a href='IzpisRedovalnice.php?SolskoLeto=".$VLeto."&razred=".$VRazredDat[$Indx][3]."&paralelka=".$VRazredDat[$Indx][1]."&vrstaos=".$VRazredDat[$Indx][2]."'>".$VRazred[$Indx]."</a></td>";
		            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
			            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
				            if ($UrnikRazred[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikRazred[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
		            }
		            echo "<td>".$Obremenitev[$Indx]."</td>";
	            }
            }

            echo "</table>";
            break;
        case "3":
            //'zasedenost ucilnic
            for ($Indx2=0;$Indx2 <= 100;$Indx2++){
	            $Obremenitev[$Indx2]=0;
	            for ($Indx=0;$Indx <= 5;$Indx++){
		            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            $UrnikProstorov[$Indx2][$Indx][$Indx0]="";
		            }
	            }
            }

            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,tabrazdat.idsola,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.idprostor,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY tabprostor.IdProstor,taburnik.danvtednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            $IzbraniProstor="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($VecSol > 0){
	                switch ($R["nivo"]){
		                case 1:
                        case 2:
                        case 3:
			                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
		                case 7:
                        case 8:
                        case 9:
			                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
		                default:
			                if ($R["razred"]==0 ){
				                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
			                }else{
				                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
			                }
	                }
                }else{
                    switch ($R["nivo"]){
                        case 1:
                        case 2:
                        case 3:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        case 7:
                        case 8:
                        case 9:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        default:
                            if ($R["razred"]==0 ){
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }else{
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }
                    }
                }
	            $Indx=$Indx+1;
            }
            $StProstorov=$Indx;

            for ($Indx2=0;$Indx2 <= 100;$Indx2++){
	            $Obremenitev[$Indx2]=0;
	            for ($Indx=0;$Indx <= 5;$Indx++){
		            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			            if ($UrnikProstorov[$Indx2][$Indx][$Indx0] != "" ){
				            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
			            }
		            }
	            }
            }

            echo "<a name='3'></a>";
            echo "<br /><h2>Zasedenost prostorov (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
            echo "<th>Prostor</th>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            echo "<th>".Int2Dan($Indx)."</th>";
	            for ($Indx0=1;$Indx0 <= 12;$Indx0++){
		            echo "<th></th>";
	            }
            }
            echo "<th>Skupaj ur</th>";
            echo "<tr bgcolor='cyan'><td></td>";
            for ($Indx=1;$Indx <= 5;$Indx++){
	            for ($Indx0=0;$Indx0 <= 12;$Indx0++){
    	            echo "<td>".$Indx0."</td>";
	            }
            }
            echo "<td></td></tr>";

            $ColorChange=true;
            for ($Indx=0;$Indx <= 100;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            if ($ColorChange ){
			            echo "<tr bgcolor='lightyellow'>";
		            }else{
			            echo "<tr bgcolor='#FFFFCC'>";
		            }
		            $ColorChange=!$ColorChange;
		            echo "<td>".$VProstor[$Indx][3]." - ".$VProstor[$Indx][1]." (".$VProstor[$Indx][2].")</td>";
		            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
			            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
				            if ($UrnikProstorov[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikProstorov[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
		            }
		            echo "<td>".$Obremenitev[$Indx]."</td>";
	            }
            }

            echo "</table>";
            break;
        case "4":
            //'izpis urnika po uciteljih - 2
            for ($Indx2=0;$Indx2 <= 150;$Indx2++){
                $Obremenitev[$Indx2]=0;
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
                    }
                }
            }

            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,tabrazdat.idsola,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY tabucitelji.Priimek,tabucitelji.Ime,taburnik.danvtednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                    $IzbraniUcitelj=$StUciteljev+1;
                    for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
                        if ($R["iducitelj"]==$VUcitelji[$Indx2][0] ){
                            $IzbraniUcitelj=$Indx2;
                        }
                    }
                    if ($VecSol > 0){
                        switch ($R["nivo"]){
                            case 1:
                            case 2:
                            case 3:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
                                break;
                            case 7:
                            case 8:
                            case 9:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
                                break;
                            default:
                                if ($R["razred"]==0 ){
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'></td></tr>";
                                }else{
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td></tr>";
                                }
                        }
                    }else{
                        switch ($R["nivo"]){
                            case 1:
                            case 2:
                            case 3:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                break;
                            case 7:
                            case 8:
                            case 9:
                                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                break;
                            default:
                                if ($R["razred"]==0 ){
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'></td></tr>";
                                }else{
                                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></td></tr>";
                                }
                        }
                    }
                $Indx=$Indx+1;
            }

            for ($Indx2=0;$Indx2 <= 150;$Indx2++){
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        if ($UrnikUcitelj[$Indx2][$Indx][$Indx0] != "" ){
                            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                        }
                    }
                }
            }

            echo "<a name='4'></a>";
            echo "<br /><h2>Urnik po učiteljih (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
            $ColorChange=true;
            for ($Indx=0;$Indx <= $StUciteljev;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            echo "<tr bgcolor='cyan'><td><b>".$VUcitelji[$Indx][1].", ".$VUcitelji[$Indx][2]."</b></td>";
		            echo "<td>".$Obremenitev[$Indx]."</td>";
		            for ($Indx2=1;$Indx2 <= 5;$Indx2++){
			            echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
		            }
		            echo "</tr>";
		            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
			            if ($ColorChange ){
				            echo "<tr bgcolor='lightyellow'>";
			            }else{
				            echo "<tr bgcolor='#FFFFCC'>";
			            }
			            echo "<td></td><td>".$Indx2."</td>";
			            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
				            if ($UrnikUcitelj[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
			            echo "</tr>";
		            }
		            $ColorChange=!$ColorChange;
	            }
            }

            echo "</table>";
            break;
        case "5":
            //'izpis urnika po razredih - 2
            for ($Indx2=0;$Indx2 <= 50;$Indx2++){
                $Obremenitev[$Indx2]=0;
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        $UrnikRazred[$Indx2][$Indx][$Indx0]="";
                    }
                }
            }

            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,tabrazdat.idsola,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.vrstaos,taburnik.danvtednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            $IzbraniRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["razred"].$R["paralelka"].$R["idsola"] != $IzbraniRazred ){
                    $Indx=$Indx+1;
                    $IzbraniRazred=$R["razred"].$R["paralelka"].$R["idsola"];
                    if ($VecSol > 0){
                        $VRazred[$Indx]=$R["razred"].". ".$R["paralelka"].$R["idsola"];
                    }else{
                        $VRazred[$Indx]=$R["razred"].". ".$R["paralelka"];
                    }
                    $VRazredDat[$Indx][0]=$R["razred"];
                    $VRazredDat[$Indx][1]=$R["paralelka"];
                    $VRazredDat[$Indx][2]=$R["vrstaos"];
                    $VRazredDat[$Indx][3]=$R["idrazred"];
                }
                switch ($R["nivo"]){
                    case 1:
                    case 2:
                    case 3:
                        $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                        break;
                    case 7:
                    case 8:
                    case 9:
                        $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                        break;
                    default:
                        $UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]=$UrnikRazred[$Indx][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                }
            }
            $StRazredov=$Indx;

            for ($Indx2=0;$Indx2 <= 50;$Indx2++){
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        if ($UrnikRazred[$Indx2][$Indx][$Indx0] != "" ){
                            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                        }
                    }
                }
            }

            echo "<a name='5'></a>";
            echo "<br /><h2>Urnik po razredih (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border='1' cellspacing='0' bgcolor='lightyellow'>";
            $ColorChange=false;
            for ($Indx=1;$Indx <= 50;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            echo "<tr bgcolor='cyan'><td><b>".$VRazred[$Indx]."</b></td>";
		            echo "<td>".$Obremenitev[$Indx]."</td>";
		            for ($Indx2=1;$Indx2 <= 5;$Indx2++){
			            echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
		            }
		            echo "</tr>";
		            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
			            if ($ColorChange ){
				            echo "<tr bgcolor='lightyellow'>";
			            }else{
				            echo "<tr bgcolor='#FFFFCC'>";
			            }
			            echo "<td></td><td>".$Indx2."</td>";
			            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
				            if ($UrnikRazred[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikRazred[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
			            echo "</tr>";
		            }
		            $ColorChange=!$ColorChange;
	            }
            }

            echo "</table>";
            break;
        case "6":
            //'zasedenost ucilnic - 2
            for ($Indx2=0;$Indx2 <= 100;$Indx2++){
                $Obremenitev[$Indx2]=0;
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        $UrnikProstorov[$Indx2][$Indx][$Indx0]="";
                    }
                }
            }

            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,tabrazdat.idsola,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.idprostor,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM (((taburnik "; 
            $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
            $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) " ;
            $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." ORDER BY tabprostor.IdProstor,taburnik.danvtednu,taburnik.Ura";
            $result = mysqli_query($link,$SQL);

            $IzbraniProstor="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($VecSol > 0){
                    switch ($R["nivo"]){
                        case 1:
                        case 2:
                        case 3:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        case 7:
                        case 8:
                        case 9:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        default:
                            if ($R["razred"]==0 ){
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }else{
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }
                    }
                }else{
                    switch ($R["nivo"]){
                        case 1:
                        case 2:
                        case 3:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        case 7:
                        case 8:
                        case 9:
                            $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        default:
                            if ($R["razred"]==0 ){
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }else{
                                $UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]=$UrnikProstorov[$R["idprostor"]][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["razred"].$R["paralelka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."</font></td></tr>";
                            }
                    }
                }
                $Indx=$Indx+1;
            }
            $StProstorov=$Indx;

            for ($Indx2=0;$Indx2 <= 100;$Indx2++){
                $Obremenitev[$Indx2]=0;
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        if ($UrnikProstorov[$Indx2][$Indx][$Indx0] != "" ){
                            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                        }
                    }
                }
            }

            echo "<a name='6'></a>";
            echo "<br /><h2>Zasedenost prostorov (".$VLeto."/".($VLeto+1)."):</h2>";
            echo "<table border='1' cellspacing='0' bgcolor='lightyellow'>";

            for ($Indx=0;$Indx <= 100;$Indx++){
	            if ($Obremenitev[$Indx] > 0 ){
		            echo "<tr bgcolor='cyan'><td>".$VProstor[$Indx][3]." - ".$VProstor[$Indx][1]." (".$VProstor[$Indx][2].")</td>";
		            echo "<td>".$Obremenitev[$Indx]."</td>";
		            for ($Indx2=1;$Indx2 <= 5;$Indx2++){
			            echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
		            }
		            echo "</tr>";
		            for ($Indx2=0;$Indx2 <= 12;$Indx2++){
			            if ($ColorChange ){
				            echo "<tr bgcolor='lightyellow'>";
			            }else{
				            echo "<tr bgcolor='#FFFFCC'>";
			            }
			            echo "<td></td><td>".$Indx2."</td>";
			            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
				            if ($UrnikProstorov[$Indx][$Indx1][$Indx2] != "" ){
					            echo "<td valign='top'>";
					            echo "<table class='hide'>";
					            echo $UrnikProstorov[$Indx][$Indx1][$Indx2];
					            echo "</table>";
					            echo "</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
			            }
			            echo "</tr>";
		            }
		            $ColorChange=!$ColorChange;
	            }
            }

            echo "</table>";
            break;
        case "7":
            //'izpis pogovornih ur
            $SQL = "SELECT taburnik.danvtednu,taburnik.ura,tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabprostor.idprostor,tabprostor.opis,tabprostor.stevilka,tabdnevnikure.zacetek,tabdnevnikure.konec FROM (((taburnik ";
            $SQL .= "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.iducitelj) ";
            $SQL .= "INNER JOIN tabprostor ON taburnik.prostor=tabprostor.idprostor) ";
            $SQL .= "INNER JOIN tabdnevnikure ON taburnik.ura=tabdnevnikure.ura) ";
            $SQL .= "INNER JOIN tabpredmeti ON taburnik.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." AND tabpredmeti.oznaka='Pu' ORDER BY tabucitelji.priimek,tabucitelji.ime";
            $result = mysqli_query($link,$SQL);
            echo "<br />";
            echo "<table>";
            echo "<tr><th>Št.</th><th>Učitelj/-ica</th><th>Dan</th><th>Ura</th><th>Prostor</th></tr>";
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$i."</td>";
                echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
                echo "<td>".Int2Dan($R["danvtednu"])."</td>";
                $SQL = "SELECT count(ura) AS stur FROM taburnik ";
                $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od=".$od." AND ucitelj=".$R["iducitelj"]." AND (ura=0 AND ura=".$R["ura"].") AND danvtednu=".$R["danvtednu"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    if ($R1["stur"] > 1){
                        echo "<td>".$R["ura"]." (7:00 - 7:30)</td>";
                    }else{
                        echo "<td>".$R["ura"]." (".intval($R["zacetek"]/60).":".dvomestno($R["zacetek"] % 60)." - ".intval($R["konec"]/60).":".dvomestno($R["konec"] % 60).")</td>";
                    }
                }else{
                    echo "<td>".$R["ura"]." (".intval($R["zacetek"]/60).":".dvomestno($R["zacetek"] % 60)." - ".intval($R["konec"]/60).":".dvomestno($R["konec"] % 60).")</td>";
                }
                
                if (isset($R["opis"])){
                    echo "<td>".$R["stevilka"]." - ".$R["opis"]."</td>";
                }else{
                    echo "<td>Govorilnica</td>";
                }
                echo "</tr>";
                $i += 1;
            }
            echo "</table>";
            echo "<br />";
            break;
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
/*
echo "<a href='UrnikUciteljiPDF.php' target='new_win'>Urnik učiteljev (PDF)</a><br />";
echo "<a href='UrnikRazrediPDF.php' target='new_win'>Urnik razredov (PDF)</a><br />";
echo "<a href='UrnikProstoriPDF.php' target='new_win'>Urnik prostorov (PDF)</a><br />";
*/
//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

?>

</body>
</html>
