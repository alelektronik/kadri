<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pregled dela za računovodstvo
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik="";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo="";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel=0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

function Int2Mesec($x){
    switch ($x){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

//$DodatnihRubrik=19;

$DelavecCasi=array();

function Menjava($Indx,$Indx1){
    global $DelavecCasi;
    $DelavecCasi[0][1]= $DelavecCasi[$Indx][1];
    $DelavecCasi[0][2]= $DelavecCasi[$Indx][2];
    $DelavecCasi[0][3]= $DelavecCasi[$Indx][3];
    $DelavecCasi[0][4]= $DelavecCasi[$Indx][4];
    $DelavecCasi[0][5]= $DelavecCasi[$Indx][5];
    $DelavecCasi[0][6]= $DelavecCasi[$Indx][6];
    $DelavecCasi[0][7]= $DelavecCasi[$Indx][7];
    $DelavecCasi[0][8]= $DelavecCasi[$Indx][8];
    $DelavecCasi[0][9]= $DelavecCasi[$Indx][9];
    $DelavecCasi[0][10]=$DelavecCasi[$Indx][10];
    $DelavecCasi[0][11]=$DelavecCasi[$Indx][11];
    $DelavecCasi[0][12]=$DelavecCasi[$Indx][12];
        
    $DelavecCasi[$Indx][1]=$DelavecCasi[$Indx1][1];
    $DelavecCasi[$Indx][2]=$DelavecCasi[$Indx1][2];
    $DelavecCasi[$Indx][3]=$DelavecCasi[$Indx1][3];
    $DelavecCasi[$Indx][4]=$DelavecCasi[$Indx1][4];
    $DelavecCasi[$Indx][5]=$DelavecCasi[$Indx1][5];
    $DelavecCasi[$Indx][6]=$DelavecCasi[$Indx1][6];
    $DelavecCasi[$Indx][7]=$DelavecCasi[$Indx1][7];
    $DelavecCasi[$Indx][8]=$DelavecCasi[$Indx1][8];
    $DelavecCasi[$Indx][9]=$DelavecCasi[$Indx1][9];
    $DelavecCasi[$Indx][10]=$DelavecCasi[$Indx1][10];
    $DelavecCasi[$Indx][11]=$DelavecCasi[$Indx1][11];
    $DelavecCasi[$Indx][12]=$DelavecCasi[$Indx1][12];
    
    $DelavecCasi[$Indx1][1]=$DelavecCasi[0][1];
    $DelavecCasi[$Indx1][2]=$DelavecCasi[0][2];
    $DelavecCasi[$Indx1][3]=$DelavecCasi[0][3];
    $DelavecCasi[$Indx1][4]=$DelavecCasi[0][4];
    $DelavecCasi[$Indx1][5]=$DelavecCasi[0][5];
    $DelavecCasi[$Indx1][6]=$DelavecCasi[0][6];
    $DelavecCasi[$Indx1][7]=$DelavecCasi[0][7];
    $DelavecCasi[$Indx1][8]=$DelavecCasi[0][8];
    $DelavecCasi[$Indx1][9]=$DelavecCasi[0][9];
    $DelavecCasi[$Indx1][10]=$DelavecCasi[0][10];
    $DelavecCasi[$Indx1][11]=$DelavecCasi[0][11];
    $DelavecCasi[$Indx1][12]=$DelavecCasi[0][12];
}

function PrisotnostZaMalico($VLeto,$VMesec,$zaposlen){
    global $link,$DelavecCasi;
    
    $VDelavec=$zaposlen;
    
    for ($IndxDan=0;$IndxDan <= 32;$IndxDan++){
        $Odsotnost[$IndxDan]=0;
    }
    for ($IndxDan=0;$IndxDan <= 16;$IndxDan++){
        $CountOdsotnostPos[$IndxDan]=0;
        $CountOdsotnost[$IndxDan]=0;
    }
    $OdsotnostJe=false;

    for ($Indx=0;$Indx <= 186;$Indx++){
        $DelavecCasi[$Indx][1]=""; //    'ime
        $DelavecCasi[$Indx][2]=""; //    'stdelavca
        $DelavecCasi[$Indx][3]=""; //    'letopr
        $DelavecCasi[$Indx][4]=""; //    'danpr
        $DelavecCasi[$Indx][5]=0; //    'uraprih
        $DelavecCasi[$Indx][6]=0; //    'minprih
        $DelavecCasi[$Indx][7]=""; //    'danodh
        $DelavecCasi[$Indx][8]=0; //    'uraodh
        $DelavecCasi[$Indx][9]=0; //    'minodh
        $DelavecCasi[$Indx][10]=""; //    'vrstaprih
        $DelavecCasi[$Indx][11]=0; //    'minut
        $DelavecCasi[$Indx][12]=""; //    'sistemdat
    }

    $DelavecDat[1]="";
    $DelavecDat[2]="";
    for ($IndxDan=0;$IndxDan <= 32;$IndxDan++){
        $Prisotnost[$IndxDan]=0;
        for ($indx=0;$indx <= 16;$indx++){
            $DelaNaDan[$IndxDan][$indx]=0;
        }
    }

    switch ($VMesec){
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            $MesecDni=31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            $MesecDni=30;
            break;
        case 2:
            if ($VLeto % 4 == 0){
                $MesecDni=29;
            }else{
                $MesecDni=28;
            }
    }

    //'-----------------------------
    //'preberem vrednosti prihodov in odhodov iz obeh tabel    
    $SQL = "SELECT TabPrihodi.*,kadrovi.* FROM TabPrihodi INNER JOIN kadrovi ON TabPrihodi.sifra=kadrovi.stdelavca WHERE kadrovi.emso='".$VDelavec."' AND ((TabPrihodi.letopr='".$VLeto."' AND TabPrihodi.mesecpr='".$VMesec."') OR (TabPrihodi.letodh='".$VLeto."' AND TabPrihodi.mesecodh='".$VMesec."')) ORDER BY TabPrihodi.sistemdat,TabPrihodi.minut";
    $result = mysqli_query($link,$SQL);
    
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $Indx=$Indx+1;
        $DelavecCasi[$Indx][1]=$R["PRIIMIME"]; //    'ime
        $DelavecCasi[$Indx][2]=$R["STDELAVCA"]; //    'stdelavca
        $DelavecCasi[$Indx][3]=$R["LETOPR"]; //    'letopr
        $DelavecCasi[$Indx][4]=$R["DANPR"]; //    'danpr
        $DelavecCasi[$Indx][5]=$R["URAPRIH"]; //    'uraprih
        $DelavecCasi[$Indx][6]=$R["MINPRIH"]; //    'minprih
        $DelavecCasi[$Indx][7]=$R["DANODH"]; //    'danodh
        $DelavecCasi[$Indx][8]=$R["URAODH"]; //    'uraodh
        $DelavecCasi[$Indx][9]=$R["MINODH"]; //    'minodh
        $DelavecCasi[$Indx][10]=$R["VRSTAPRIH"]; //    'vrstaprih
        $DelavecCasi[$Indx][11]=$R["MINUT"]; //    'minut
        $Datum = new DateTime($R["SISTEMDAT"]);
        $DelavecCasi[$Indx][12]=$Datum->format('Ymd');//    'sistemdat
    }

    $SQL = "SELECT promet1.*,kadrovi.* FROM promet1 INNER JOIN kadrovi ON promet1.sifra=kadrovi.stdelavca WHERE kadrovi.emso='".$VDelavec."' AND ((promet1.letopr='".$VLeto."' AND promet1.mesecpr='".$VMesec."') OR (promet1.letodh='".$VLeto."' AND promet1.mesecodh='".$VMesec."')) ORDER BY promet1.sistemdat,promet1.minut";
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        $Indx=$Indx+1;
        $DelavecCasi[$Indx][1]=$R["PRIIMIME"]; //    'ime
        $DelavecCasi[$Indx][2]=$R["STDELAVCA"]; //    'stdelavca
        $DelavecCasi[$Indx][3]=$R["LETOPR"]; //    'letopr
        $DelavecCasi[$Indx][4]=$R["DANPR"]; //    'danpr
        $DelavecCasi[$Indx][5]=$R["URAPRIH"]; //    'uraprih
        $DelavecCasi[$Indx][6]=$R["MINPRIH"]; //    'minprih
        $DelavecCasi[$Indx][7]=$R["DANODH"]; //    'danodh
        $DelavecCasi[$Indx][8]=$R["URAODH"]; //    'uraodh
        $DelavecCasi[$Indx][9]=$R["MINODH"]; //    'minodh
        $DelavecCasi[$Indx][10]=$R["VRSTAPRIH"]; //    'vrstaprih
        $DelavecCasi[$Indx][11]=$R["MINUT"]; //    'minut
        $Datum = new DateTime($R["SISTEMDAT"]);
        $DelavecCasi[$Indx][12]=$Datum->format('Ymd');//    'sistemdat
    }
    $StDogodkov=$Indx;
//'posortiram prihode in odhode glede na minuto dogodka
    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
        for ($Indx1=1;$Indx1 <= $StDogodkov;$Indx1++){
            if ($Indx != $Indx1){
                if ($DelavecCasi[$Indx][12] < $DelavecCasi[$Indx1][12]){
                    //'različen dan
                    Menjava($Indx,$Indx1);
                }else{
                    if ($DelavecCasi[$Indx][12] == $DelavecCasi[$Indx1][12]){
                        //'isti dan
                        if ($DelavecCasi[$Indx][11] < $DelavecCasi[$Indx1][11]){
                            //'manjši čas
                            Menjava($Indx,$Indx1);
                        }else {
                            if ($DelavecCasi[$Indx][11] == $DelavecCasi[$Indx1][11]){
                                //'enak čas
                                if ($DelavecCasi[$Indx][10] < $DelavecCasi[$Indx1][10]){
                                    //'prihod/odhod
                                    Menjava($Indx,$Indx1);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    $DelavecDat[1]=$DelavecCasi[1][1];
    $DelavecDat[2]=$DelavecCasi[1][2];
    
    $DanPrihoda="";
    for ($indx=0;$indx <= 32;$indx++){
        $indxCas[$indx]=1;
    }
    if ($DelavecCasi[1][11] > 0){
        //'če ima delavec vpisane prihode/odhode
        //'response.write "<br><h3>"&DelavecCasi(1,1)&" ("&DelavecCasi(1,2)&")</h3>"
        //'response.write "<table border=1>"
        //'response.write "<tr bgcolor=lightcyan><th>Dan</th><th>Prihod</th><th>Odhod</th><th>Koda prih/odh</th><th>Opis kode</th><th>Prisotnost</th></tr>"
        $Indx=0;
        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
            if ($DelavecCasi[$Indx][3] != ""){
                //'če ima vpisan prihod
                $Dan=$DelavecCasi[$Indx][4];
            }else{
                //'če je vpisan odhod
                $Dan=$DelavecCasi[$Indx][7];
            }
            
            //'Preveri kako so bili štemplani prihodi in odhodi in jih dopolni s 15 minutnimi časi: na lihih številkah so prihodi, na sodih pa odhodi
            
            if ($indxCas[$Dan] % 2 == 1){
                //'vpi?e prihod
                if ($DelavecCasi[$Indx][10]=="1001"){
                    //'?e je prihod
                    $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11];
                }else{
                    //'če je prihod izpuščen, šteje prejšnji čas (vpiše prihod in odhod)
                    if ($indxCas[$Dan] > 1){
                        $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelaNaDan[$Dan][$indxCas[$Dan]-1];    //'vpiše prejšnji prihod
                    }else{
                        $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11]-15;
                    }
                    $indxCas[$Dan]=$indxCas[$Dan]+1;
                    $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11];
                }
                $indxCas[$Dan]=$indxCas[$Dan]+1;
            }else{
                //'vpiše odhod
                if ($DelavecCasi[$Indx][10] != "1001"){
                    //'če je odhod
                    $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11];
                }else{
                    //'če je odhod izpuščen, šteje 15 min (vpiše prihod in odhod)
                    if ($indxCas[$Dan] > 1){
                        $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11]; // 'vpiše isti čas za prihod kot odhod
                    }else{
                        $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11]-15; // 'kot da je šel ven pred 15 minutami
                    }
                    $indxCas[$Dan]=$indxCas[$Dan]+1;
                    $DelaNaDan[$Dan][$indxCas[$Dan]]=$DelavecCasi[$Indx][11];
                }
                $indxCas[$Dan]=$indxCas[$Dan]+1;
            }
            
        }
        //'pogleda, če je zadnji parni čas vpisan (odhod), sicer vpiše čas za 15 min večji od prihoda
        for ($indx=1;$indx <= 31;$indx++){
            if ($DelaNaDan[$indx][1] > 0 ) {
                if (($indxCas[$indx] % 2 == 0) && ($DelaNaDan[$indx][$indxCas[$indx]]==0) ) {
                    $DelaNaDan[$indx][$indxCas[$indx]]=$DelaNaDan[$indx][$indxCas[$indx]-1]+15;
                }
            }
        }
        
        $DeloSum=0;
        for ($indx=1;$indx <= 31;$indx++){
            $Vsota=0;
            for ($indx1=1;$indx1 <= 15;$indx1=$indx1+2){
                $Vsota=$Vsota+$DelaNaDan[$indx][$indx1+1]-$DelaNaDan[$indx][$indx1];
            }
            if ($Vsota >= 240 ) {
                $DeloSum=$DeloSum+1;    //'poveča števec prisotnosti na delu (s pravico do povračila malice)
            }
        }
    }else{
        $DeloSum=0;
    }
    return $DeloSum;
}

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

if (isset($_POST["iducitelj"])){
    $ucitelj=$_POST["iducitelj"];
}else{
    if (isset($_GET["iducitelj"])){
        $ucitelj=$_GET["iducitelj"];
    }else{
        $ucitelj="";
    }
}
if (isset($_POST["mesec"])){
    $VMesec=$_POST["mesec"];
}else{
    if (isset($_GET["mesec"])){
        $VMesec=$_GET["mesec"];
    }else{
        $VMesec="";
    }
}
if (isset($_POST["prehrana"])){
    $Prehrana=$_POST["prehrana"];
}else{
    if (isset($_GET["prehrana"])){
        $Prehrana=$_GET["prehrana"];
    }else{
        $Prehrana="";
    }
}

$Prehrana=str_replace(",",".",$Prehrana);
if (!is_numeric($Prehrana)) {
    $Prehrana=0;
}

$StartTime=new DateTime("now");

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    //echo "<a href='PregledDelaRacunovodstvo.php?id=1&leto=".$VLeto."&mesec=".$VMesec."&prehrana=".$Prehrana."'>Vnos šifer, količnikov in razredov</a><br />";
    echo "<a href='PrevozniStroski.php'>Vnos prevoznih stroškov</a><br />";

    //'echo "Leto: "&VLeto&"/"&VLeto+1&"<br>"

    $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) AND (status < 10) ORDER BY priimek,ime";
    //'$SQL = "SELECT * FROM tabucitelji WHERE (status >= 0) AND (status < 10) AND idUcitelj=159 ORDER BY priimek,ime"
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
    /*	$VKonecDela=$R["DatumEnd"];
	    if ($VKonecDela=="" ) {
		    $VKonecDela="31.12.".year(now)+2
	    }
	    
    //		'if DateDiff("m",VKonecDela,"28."&VMesec&"."&VLeto) <= 0 ) {
    */
	    $UciteljZaObdelavo[$Indx]=$R["IdUcitelj"];
	    $Indx=$Indx+1;
	    //'}
    }
    $StUciteljevZaObdelavo=$Indx-1;

    $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto." ORDER BY datum";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    $ProstiDnevi=0;
    while ($R = mysqli_fetch_array($result)){
	    $Praznik[$Indx][0] = new DateTime($R["datum"]);
	    $Praznik[$Indx][1]=$R["kat"];
    //'		echo "Praznik "&Praznik(Indx,0)&" "&Praznik(Indx,1)&"<br>"
	    if ($Praznik[$Indx][1]==1 ) {
		    $ProstiDnevi=$ProstiDnevi+1;
	    }
	    $Indx=$Indx+1;
    }
    $StPraznikov=$Indx-1;

    switch ($Vid){
	    case "1":
	    case "2";
            echo "RDU ne obračunava več<br />";
            break;
	    default:
		    $SQL = "SELECT * FROM TabDoprinos";
		    $result = mysqli_query($link,$SQL);
		    while ($R = mysqli_fetch_array($result)){
			    $OznakaDneva[$R["aktivno"]]=$R["OblikaDelaOznaka"];
		    }

		    if ($VMesec > 1 ) {
			    echo "<a href='PregledDelaRacunovodstvo.php?leto=".$VLeto."&mesec=".($VMesec-1)."&prehrana=".$Prehrana."'>Mesec-1</a>";
		    }else{
			    echo "<a href='PregledDelaRacunovodstvo.php?leto=".($VLeto-1)."&mesec=12&prehrana=".$Prehrana."'>Mesec-1</a>";
		    }
		    switch ($VMesec){
			    case 12:
				    echo " <a href='PregledDelaRacunovodstvo.php?leto=".($VLeto+1)."&mesec=1&prehrana=".$Prehrana."'>Mesec+1</a><br />";
                    break;
			    default:
				    echo " <a href='PregledDelaRacunovodstvo.php?leto=".$VLeto."&mesec=".($VMesec+1)."&prehrana=".$Prehrana."'>Mesec+1</a><br />";
		    }

		    //'Število dni praznikov
		    $SQL = "SELECT * FROM TabPraznik WHERE mesec=".$VMesec." AND leto=".$VLeto." AND kat=0";
		    $result = mysqli_query($link,$SQL);
		    $StPraznikovM=0;
		    while ($R = mysqli_fetch_array($result)){
                $datum= new DateTime($R["datum"]);
                if (($datum->format('w')+1 > 1) && ($datum->format('w')+1) < 7) {
			        $StPraznikovM=$StPraznikovM+1;
                }
		    }
		    
    //		'if VMesec < 9 ) {
    //		'	echo "<h2>Pregled dela delavcev za mesec "&MonthName(VMesec)&"/"&VLeto+1&"</h2>"
    //		'}else{
			    echo "<h2>Pregled dela delavcev za mesec ".int2Mesec($VMesec)."/".$VLeto." - ".$Danes->format('d.m.Y')."</h2>";
    //		'}

		    echo "<table border='1'>";
		    echo "<tr>";
		    echo "<th>Št.</th>";
		    //echo "<th>Šifra</th>";
		    echo "<th>Ime</th>";
		    echo "<th>Prevoz</th>";
		    echo "<th>Prehrana</th>";
		    if ($EvidencaPrisotnosti==1 ) {
			    echo "<th>Prehrana<br />po evidenci</th>";
		    }
		    echo "<th>Skupaj<br>prev.+prehr.</th>";
		    if ($EvidencaPrisotnosti==1 ) {
			    echo "<th>Skupaj<br />prev.+prehr.<br /> po evidenci</th>";
		    }
            if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>pl. dopust</th>";
		    echo "<th>Skupaj<br />pl. dopust ur</th>";
            echo "<th>Skupaj<br />Du</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>nepl. dopust</th>";
		    echo "<th>Skupaj<br />nepl. dopust ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>bolniška</th>";
		    echo "<th>Skupaj<br />bolniška ur</th>";

            if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>boln.-nega</th>";
            echo "<th>Skupaj<br />boln.-nega ur</th>";

		    if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>bolniška 50%</th>";
		    echo "<th>Skupaj<br />bolniška 50% ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Skupaj<br>bolniška ?%</th>";
		    echo "<th>Skupaj<br />bolniška ?% ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Izobr.<br>dnevnice</th>";
		    echo "<th>Izobr.<br />dnevnice ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Sprem.<br>dnevnice</th>";
		    echo "<th>Sprem.<br />dnevnice ur</th>";
            echo "<th>Izobr. dod.<br />prevoz ur</th>";
            echo "<th>Spr. dod.<br />prevoz ur</th>";
		    echo "<th>Del. ur</th>";
		    echo "<th>Del. dni</th>";
    //'		echo "<th>Real. Ure</th>";
    //'		echo "<th>Višek ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Prazniki</th>";
		    echo "<th>Prazniki ur</th>";
		    echo "<th>Obračunano ur</th>";
		    if (isset($_POST["vkljucidneve"])) echo "<th>Obračunano dni</th>";
		    
		    echo "</tr>";

            if (($VLeto) % 4 == 0 ) {
                $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
            }else{
                $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
            }

		    for ($IndxObdelava=1;$IndxObdelava <= $StUciteljevZaObdelavo;$IndxObdelava++){
                set_time_limit(0);
			    $oUcitelj= new RUcitelj;
			    $oUcitelj->PreberiSe ($UciteljZaObdelavo[$IndxObdelava],$VLeto,$VLeto);
			    //$oUcitelj->IzracunPrisotnosti($VLeto);
                $oUcitelj->IzracunPrisotnostiMesec($VLeto,$VMesec,2);
			    $CountDay=$oUcitelj->getCountDay();
			    $MesecneUre=$oUcitelj->getMesecneUre();
			    $DneviBolniske=$CountDay[$VMesec][3];
                $DneviBolniskeNega=$CountDay[$VMesec][22];
			    $DneviBolniske50=$CountDay[$VMesec][4];
			    $DneviBolniskeProc=$CountDay[$VMesec][19];
                $DneviDodPrevoz=$CountDay[$VMesec][20];
                $DneviSprDodPrevoz=$CountDay[$VMesec][21];
			    $DneviKorUr=$CountDay[$VMesec][5]+$CountDay[$VMesec][23];
			    $DneviPlDop=$CountDay[$VMesec][2]+$CountDay[$VMesec][6]+$CountDay[$VMesec][7]+$CountDay[$VMesec][10]+$CountDay[$VMesec][11]+$CountDay[$VMesec][18];
//                $DneviPlDop=$CountDay[$VMesec][2]+$DneviKorUr+$CountDay[$VMesec][6]+$CountDay[$VMesec][7]+$CountDay[$VMesec][10]+$CountDay[$VMesec][11]+$CountDay[$VMesec][18];
			    $DneviNePlDop=$CountDay[$VMesec][8]+$CountDay[$VMesec][9]+$CountDay[$VMesec][12];
			    $DneviDnevnic=$CountDay[$VMesec][13]+$CountDay[$VMesec][15];
				$IzobrDnevnice=$CountDay[$VMesec][13];
				$SpremDnevnice=$CountDay[$VMesec][15];
//			    $DneviDela=$MesecneUre[$VMesec][1]-($DneviBolniske+$DneviPlDop+$DneviNePlDop+$DneviDnevnic);
//                $DneviDela=$MesecneUre[$VMesec][1]-($DneviBolniske+$DneviPlDop+$DneviNePlDop+$DneviDnevnic+$DneviDodPrevoz);
                $DneviDela=$MesecneUre[$VMesec][1]-($DneviBolniske+$DneviBolniskeNega+$DneviPlDop+$DneviNePlDop+$DneviDnevnic+$DneviDodPrevoz+$DneviSprDodPrevoz+$DneviKorUr);
			    $DneviDelaStroski=$MesecneUre[$VMesec][4]-($DneviBolniske+$DneviBolniskeNega+$DneviPlDop+$DneviNePlDop+$DneviDnevnic+$DneviKorUr);
                $ProcentZapM=$oUcitelj->getProcentZaposlitveM($VLeto,$VMesec);
			    if ($DneviDelaStroski < 0 ) { 
                    $DneviDelaStroski=0;
                }
			    if ($DneviDela < 0 ) { 
                    $DneviDela=0;
                }
			    
			    echo "<tr>";
			    echo "<td>".$IndxObdelava."</td>";
			    //echo "<td>".$oUcitelj->getSifra()."</td>";
			    echo "<td>".$oUcitelj->getPriimek() ." ".$oUcitelj->getIme()."</td>";
			    
			    //'prevoz
			    if (is_numeric($oUcitelj->getPrevoz()) ) {
				    if ($MesecneUre[$VMesec][4] > 0 ) {
					    $VPrevoz=$oUcitelj->getPrevoz()*($DneviDelaStroski)/$MesecneUre[$VMesec][4];
					    if ($oUcitelj->getPrevoz()*($DneviDelaStroski)/$MesecneUre[$VMesec][4] != 0 ) {
						    echo "<td bgcolor='orange' align='right'>".number_format($oUcitelj->getPrevoz()*($DneviDelaStroski)/$MesecneUre[$VMesec][4],2,",","")."</td>";
					    }else{
						    echo "<td align=right>".($oUcitelj->getPrevoz()*($DneviDelaStroski)/$MesecneUre[$VMesec][4])."</td>";
					    }
				    }else{
					    $VPrevoz=0;
					    echo "<td align=right>0,00</td>";
				    }
			    }else{	
				    $VPrevoz=0;
				    echo "<td align=right>0,00</td>";
			    }
			    
			    //'prehrana
			    //'nadomestilo prehrane ne pripada, ?e delavec ni bil prisoten vsaj 4 ure (?templano)
                /* prej izračun z DneviDelaStroski
			    if ($EvidencaPrisotnosti==1 ) {
				    //'pogleda v bazo prisotnosti, če je dnevna prisotnost večja od 4 ur
				    $DneviDelaStroskiM=PrisotnostZaMalico($VLeto,$VMesec,$oUcitelj->getIdUcitelj());
				    if ($Prehrana*$DneviDelaStroski != 0 ) {
					    echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDelaStroski,2,",","")."</td><td bgcolor='orange' align='right'> ".number_format($Prehrana*$DneviDelaStroskiM,2,",","")."</td>";
				    }else{
					    echo "<td align='right'>".($Prehrana*$DneviDelaStroski)."</td><td align=right>".($Prehrana*$DneviDelaStroski)."</td>";
				    }
			    
				    //'prevoz+prehrana
				    if ($Prehrana*$DneviDelaStroski+$VPrevoz != 0 ) {
					    echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDelaStroski+$VPrevoz,2,",","")."</td><td bgcolor='orange' align='right'> ".number_format($Prehrana*$DneviDelaStroskiM+$VPrevoz,2,",","")."</td>";
				    }else{
					    echo "<td align=right>".($Prehrana*$DneviDelaStroski+$VPrevoz)."</td><td align=right>".($Prehrana*$DneviDelaStroski+$VPrevoz)."</td>";
				    }
			    }else{
				    if ($Prehrana*$DneviDelaStroski != 0 ) {
					    echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDelaStroski,2,",","")."</td>";
				    }else{
					    echo "<td align='right'>".($Prehrana*$DneviDelaStroski)."</td>";
				    }
			    
				    //'prevoz+prehrana
				    if ($Prehrana*$DneviDelaStroski+$VPrevoz != 0 ) {
					    echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDelaStroski+$VPrevoz,2,",","")."</td>";
				    }else{
					    echo "<td align='right'>".($Prehrana*$DneviDelaStroski+$VPrevoz)."</td>";
				    }
			    }
                */
                /*  po novem izračun z DneviDela (za prehrano) */
                if ($EvidencaPrisotnosti==1 ) {
                    //'pogleda v bazo prisotnosti, če je dnevna prisotnost večja od 4 ur
                    $DneviDelaStroskiM=PrisotnostZaMalico($VLeto,$VMesec,$oUcitelj->getIdUcitelj());
                    if ($Prehrana*$DneviDela != 0 ) {
                        echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDela,2,",","")."</td><td bgcolor='orange' align='right'> ".number_format($Prehrana*$DneviDelaStroskiM,2,",","")."</td>";
                    }else{
                        echo "<td align='right'>".($Prehrana*$DneviDela)."</td><td align=right>".($Prehrana*$DneviDela)."</td>";
                    }
                
                    //'prevoz+prehrana
                    if ($Prehrana*$DneviDela+$VPrevoz != 0 ) {
                        echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDela+$VPrevoz,2,",","")."</td><td bgcolor='orange' align='right'> ".number_format($Prehrana*$DneviDelaStroskiM+$VPrevoz,2,",","")."</td>";
                    }else{
                        echo "<td align=right>".($Prehrana*$DneviDela+$VPrevoz)."</td><td align=right>".($Prehrana*$DneviDela+$VPrevoz)."</td>";
                    }
                }else{
                    if ($Prehrana*$DneviDela != 0 ) {
                        echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDela,2,",","")."</td>";
                    }else{
                        echo "<td align='right'>".($Prehrana*$DneviDela)."</td>";
                    }
                
                    //'prevoz+prehrana
                    if ($Prehrana*$DneviDela+$VPrevoz != 0 ) {
                        echo "<td bgcolor='orange' align='right'>".number_format($Prehrana*$DneviDela+$VPrevoz,2,",","")."</td>";
                    }else{
                        echo "<td align='right'>".($Prehrana*$DneviDela+$VPrevoz)."</td>";
                    }
                }
			    
			    //'placan dopust
			    //'ProcZaposl=.ProcentZaposlitveM(VLeto,VMesec)
                if ($DneviPlDop != 0 ) {
                    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviPlDop."</td>";
                    echo "<td bgcolor='orange' align='center'>".number_format($DneviPlDop*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviPlDop."</td>";
                    echo "<td align='center'>".number_format($DneviPlDop*8*$ProcentZapM/100,2,",","")."</td>";
                }
                //koriščene ure
                if ($DneviKorUr != 0 ) {
                    echo "<td bgcolor='orange' align='center'>".number_format($DneviKorUr*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    echo "<td align='center'>".number_format($DneviKorUr*8*$ProcentZapM/100,2,",","")."</td>";
                }
			    
			    //'neplacan dopust
			    if ($DneviNePlDop != 0 ) {
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviNePlDop."</td>";
				    echo "<td bgcolor='orange' align='center'>".number_format($DneviNePlDop*8*$ProcentZapM/100,2,",","")."</td>";
			    }else{
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviNePlDop."</td>";
				    echo "<td align='center'>".number_format($DneviNePlDop*8*$ProcentZapM/100,2,",","")."</td>";
			    }
			    
			    //'bolniška
			    if ($DneviBolniske != 0 ) {
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviBolniske."</td>";
				    echo "<td bgcolor='orange' align='center'>".number_format($DneviBolniske*8*$ProcentZapM/100,2,",","")."</td>";
			    }else{
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviBolniske."</td>";
				    echo "<td align='center'>".number_format($DneviBolniske*8*$ProcentZapM/100,2,",","")."</td>";
			    }
			    
                //'bolniška - nega
                if ($DneviBolniskeNega != 0 ) {
                    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviBolniskeNega."</td>";
                    echo "<td bgcolor='orange' align='center'>".number_format($DneviBolniskeNega*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviBolniskeNega."</td>";
                    echo "<td align='center'>".number_format($DneviBolniskeNega*8*$ProcentZapM/100,2,",","")."</td>";
                }
                
			    //'bolniška 50%
			    if ($DneviBolniske50 != 0 ) {
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviBolniske50."</td>";
				    echo "<td bgcolor='orange' align='center'>".number_format($DneviBolniske50*8*$ProcentZapM/100,2,",","")."</td>";
			    }else{
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviBolniske50."</td>";
				    echo "<td align='center'>".number_format($DneviBolniske50*8*$ProcentZapM/100,2,",","")."</td>";
			    }
			    
			    //'bolniška ?%
                $UreBolProc=0;
                if ($DneviBolniskeProc != 0 ) {
			        $SQL = "SELECT leto,mesec,ucitelj,rubrika,sum(enot) AS senot FROM tabpregleddelan GROUP BY leto,mesec,ucitelj,rubrika,enot HAVING Ucitelj=".$oUcitelj->getIdUcitelj()." AND rubrika=48 AND leto=".$VLeto." AND mesec=".$VMesec;
			        $result = mysqli_query($link,$SQL);
			        $ProcZaposl=$ProcentZapM;
			        if ($R = mysqli_fetch_array($result)){
				        $UreBolProc=$UreBolProc+$R["senot"]/100*$ProcZaposl/100*8;
			        }
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviBolniskeProc."</td>";
				    echo "<td bgcolor='orange' align='center'>".number_format($UreBolProc,2,",","")."</td>";
			    }else{
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviBolniskeProc."</td>";
				    echo "<td align='center'>".number_format($UreBolProc,2,",","")."</td>";
			    }
			    
                //izobr dnevnice
                if ($IzobrDnevnice != 0 ) {
                    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$IzobrDnevnice."</td>";
                    echo "<td bgcolor='orange' align='center'>".number_format($IzobrDnevnice*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$IzobrDnevnice."</td>";
                    echo "<td align='center'>".number_format($IzobrDnevnice*8*$ProcentZapM/100,2,",","")."</td>";
                }
				//sprem dnevnice
                if ($SpremDnevnice != 0 ) {
                    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$SpremDnevnice."</td>";
                    echo "<td bgcolor='orange' align='center'>".number_format($SpremDnevnice*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$SpremDnevnice."</td>";
                    echo "<td align='center'>".number_format($SpremDnevnice*8*$ProcentZapM/100,2,",","")."</td>";
                }
			    
                //'dnevi z dodatnim prevozom - izobraževanje
                if ($DneviDodPrevoz != 0 ) {
                    echo "<td bgcolor='orange' align='center'>".number_format($DneviDodPrevoz*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    echo "<td align='center'>".number_format($DneviDodPrevoz*8*$ProcentZapM/100,2,",","")."</td>";
                }
                
                //'dnevi z dodatnim prevozom - spremstvo
                if ($DneviSprDodPrevoz != 0 ) {
                    echo "<td bgcolor='orange' align='center'>".number_format($DneviSprDodPrevoz*8*$ProcentZapM/100,2,",","")."</td>";
                }else{
                    echo "<td align='center'>".number_format($DneviSprDodPrevoz*8*$ProcentZapM/100,2,",","")."</td>";
                }
                
                //Dnevi dela
                for ($Indx=$VMesec;$Indx <= $VMesec;$Indx++){
                    if ($MesecneUre[$Indx][1] != 0 ) {
                        echo "<td bgcolor='orange' align='center'>".number_format($DneviDela*8*$ProcentZapM/100,2,",","")."</td>";
                        echo "<td bgcolor='orange' align='center'>".$DneviDela."</td>";
                    }else{
                        echo "<td align='center'>".number_format($MesecneUre[$Indx][1]*8*$ProcentZapM/100,2,",","")."</td>";
                        echo "<td align='center'>".$MesecneUre[$Indx][1]."</td>";
                    }
    /*                    
    '                    'realizirane ure
    '                    if MesecneUre(Indx,0) <> 0 ) {
    '                        echo "<td bgcolor=orange align=right>"&FormatNumber(MesecneUre(Indx,0),2)&"</td>"
    '                    }else{
    '                        echo "<td align=right>"&FormatNumber(MesecneUre(Indx,0),2)&"</td>"
    '                    }
    '                    'vi?ek ur
    '                    if MesecneUre(Indx,2) <> 0 ) {
    '                        echo "<td bgcolor=orange align=right>"&FormatNumber(MesecneUre(Indx,2),2)&"</td>"
    '                    }else{
    '                        echo "<td align=right>"&FormatNumber(MesecneUre(Indx,2),2)&"</td>"
    '                    }
    */                    
                }
			    //'prazniki
			    if ($StPraznikovM != 0 ) {
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$StPraznikovM."</td>";
				    echo "<td bgcolor='orange' align='center'>".number_format($StPraznikovM*8*$ProcentZapM/100,2,",","")."</td>";
			    }else{
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$StPraznikovM."</td>";
				    echo "<td align='center'>".number_format($StPraznikovM*8*$ProcentZapM/100,2,",","")."</td>";
			    }
			    
			    //'skupaj dni za obračun
			    $DneviObracuna=$DneviDela+$DneviBolniske+$DneviBolniskeNega+$DneviPlDop+$DneviNePlDop+$DneviDnevnic+$StPraznikovM+$DneviDodPrevoz+$DneviSprDodPrevoz+$DneviKorUr;
			    if ($DneviObracuna != 0 ) {
				    echo "<td bgcolor='orange' align='center'>".number_format($DneviObracuna*8*$ProcentZapM/100,2,",","")."</td>";
				    if (isset($_POST["vkljucidneve"])) echo "<td bgcolor='orange' align='center'>".$DneviObracuna."</td>";
			    }else{
				    echo "<td align='center'>".number_format($DneviObracuna*8*$ProcentZapM/100,2,",","")."</td>";
				    if (isset($_POST["vkljucidneve"])) echo "<td align='center'>".$DneviObracuna."</td>";
			    }
			    
			    echo "</tr>";
			    $oUcitelj=null;
		    }
		    echo "</table><br />";

		    echo "<h3>Legenda:</h3>";
		    $SQL = "SELECT * FROM TabDoprinos WHERE aktivno > 2 ORDER BY aktivno";
		    $result = mysqli_query($link,$SQL);

		    echo "<table border='0'>";
		    echo "<tr><th>Oznaka</th><th>Pomen</th></tr>";
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td>".$R["OblikaDelaOznaka"]."</td>";
			    echo "<td> - ".$R["OblikaDela"]."</td>";
			    echo "</tr>";
		    }
		    echo "</table><br />";
            
            $EndTime=new DateTime("now");
            $interval=$StartTime->diff($EndTime);
            echo "Porabljen čas ".$interval->format('%i:%S')." <br />";
    }
}
?>
<br />
<!-- <a href="PregledDelaRacunovodstvo.php?id=1">Vnos šifer, količnikov in razredov</a><br> -->
<a href="PrevozniStroski.php">Vnos prevoznih stroškov</a><br />

</body>
</html>
