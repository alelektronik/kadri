<?php
  
class RUcitelj {
	private $mIme;
	private $mPriimek;
	private $mDekliski;
	private $mIdUcitelj;
	private $mSpol;
	private $mDatRoj;
	private $mEmso;
	private $mNaslov;
	private $mPosta;
	private $mKraj;
	private $mIzobrazba;
    private $mStopnjaIzobrazbe;
	private $mIzobOpis;
	private $mIzobUstr;
	private $mIdDelo; //array
	private $mDelovniCas; //array
	private $mIdVzgojnoDelo; //array
	private $mDelDobaLet;
    private $mDelDobaSol;
	private $mDopustnaDD;
	private $mDopustnaIz;
	private $mDopustNaOt;
	private $mDopustNaSta;
	private $mDopustNaInv;
	private $mDopustNaVod;
	private $mDopustStari;
	private $mDopustVzgoja;
	private $mDopustDelInv;
	private $mDopustPP;
	private $mDrugo;
	private $mDelez;
	private $mKoef; //array
	private $mStPogodbe; //array
	private $mObremen1; //array
	private $mObremen2; //array
	private $mObremen3; //(100)
	private $mObremen4; //(100)
	private $mObremen5; //(100)
	private $mUporabnik;
	private $mGeslo;
	private $mNivoDostopa;
	private $mKomentar;
	private $mStatus;
	private $mStatusDelavca;
	private $mDatumStart; //(100)
	private $mDatumEnd; //(100)
	private $mVpisM1; //(100)
	private $mIzpisM1; //(100)
	private $mPedIzobr;
	private $mStrokIzpit;
	private $mMentor;
	private $mSvetovalec;
	private $mSvetnik;
	private $mZdrPregled;
	private $mPeriodaLet;
	private $mPrevoz;
	private $mPozVarnost;
	private $mPeriodaPV;
	private $mVarstvoDelo;
	private $mPeriodaVD;
	private $mDavcna;
	private $mObcina;
	private $mDrzava;
	private $mDrzavljanstvo;
	private $mKrajRoj;
	private $mDrzavaRoj;
	private $mNaslovZac;
	private $mPostaZac;
	private $mKrajZac;
	private $mObcinaZac;
	private $mDrzavaZac;
	private $mInvalid;
	private $mKatInvalid;
	private $mDelnoUpokojen;
	private $mDopDelo; //(100)
	private $mDelodaj1; //(100)
	private $mDelodaj1mat; //(100)
	private $mDelodajNaslov1; //(100)
	private $mDelodaj2; //(100)
	private $mDelodaj2mat; //(100)
	private $mDelodajNaslov2; //(100)
	private $mDelodaj3; //(100)
	private $mDelodaj3mat; //(100)
	private $mDelodajNaslov3; //(100)
	private $mDatumPogodbe; //(100)
	private $mPolniDelCas; //(100)
	private $mRazlogDolCas; //(100)
	private $mPotrStrokUsp; //(100)
	private $mNazivDelMesta; //(100)
	private $mUrTeden; //(100)
	private $mIzmensko; //(100)
	private $mKrajDela; //(100)
	private $mKonkKlavz; //(100)
	private $mNacinPrenehanja; //(100)
	private $mStarejsi;
	private $mDojecaMati;
	private $mDopust;
    private $mDopustVse;
	private $mDolocenCas;
	private $mDoprinos;
	private $mObveza;
	private $mTedenskaObremenitev; //(100)
	private $mOpisDela; //(100)
	private $mSkupinaDela; //(100)
	private $mVzgojnoDelo; //(100)
	private $mDelPogodba; //(100)
	private $mDoprinosi; //(400,7)
	private $mStDoprinosov;
	private $mDogodkovNaDan;
	private $mDogodek; //(20,6)
	private $mKoriscenDopust;
	private $mPreostaliDopust;
	private $mMesecneUre; //(12,4) //0-delovne ure, 1-delovni dnevi, 2-doprinos, 3-potr. doprinos, 4-dan s stroški
	private $mCountDay; //(12,30)
	private $mRealiziranDoprinos;
	private $mPotrjenRealiziranDoprinos;
	private $mDnevneUre; //(12,31,4)
	private $mAktiv;
	private $mRazrednik;
	private $mTelefon;
	private $mEmail;
	private $mDrugiKontakti;
	private $mSifra;
	private $mPlacniRazred;
	private $mDoprinasanje;
	private $mZmanjsanaObveza; //porodni?ka, nega, bolni?ke
	private $mDeloMedPocitnicami;
	private $mStPog; //?tevilo aktualnih pogodb
	private $mStVsehPogodb;
	private $mMesecnaObremenitev; //(31)
	private $mUcenje;
	private $mZacetekDela;
	private $mVLetoPregled;
	private $mDelCas;	//nedolo?en, dolo?en, dopolnjevanje
	private $mPrekinjena;	//?e je med dvema pogodbama ve? kot en dan razlike
	private $mAktStPogodbe;	//aktualna ?tevilka pogodba za obra?un v primeru prekinjene zaposlitve
	private $mDatumCStart;
	private $mDatumCEnd;
    private $TotalDoprinos;
    private $PotrjenTotalDoprinos;
    private $mSistemizacija;
    private $mKolDop; //Koledar doprinosov [mesec][dan][kumulativa doprinosov,del. oznaka dneva,status dneva]
    private $mOpombe;
	
//	function __construct() {
//	}
	
//	function __destruct() {
//	}
	
	public function setIme($s) {
		$this->mIme = $s;
	}
	public function getIme() {
		return $this->mIme;
	}

	public function setPriimek($s) {
		$this->mPriimek = $s;
	}
	public function getPriimek() {
		return $this->mPriimek;
	}
	
	public function setDekliski($s) {
		$this->mDekliski = $s;
	}
	public function getDekliski() {
		return $this->mDekliski;
	}
	
	public function setIdUcitelj($s) {
		$this->mIdUcitelj = $s;
	}
	public function getIdUcitelj() {
		return $this->mIdUcitelj;
	}

	public function setSpol($s) {
		$this->mSpol = $s;
	}
	public function getSpol() {
		return $this->mSpol;
	}

	public function setDatRoj($s) {
		$this->mDatRoj = $s;
	}
	public function getDatRoj() {
		return $this->mDatRoj;
	}

	public function setEmso($s) {
		$this->mEmso = $s;
	}
	public function getEmso() {
		return $this->mEmso;
	}

	public function setNaslov($s) {
		$this->mNaslov = $s;
	}
	public function getNaslov() {
		return $this->mNaslov;
	}

	public function setPosta($s) {
		$this->mPosta = $s;
	}
	public function getPosta() {
		return $this->mPosta;
	}

	public function setKraj($s) {
		$this->mKraj = $s;
	}
	public function getKraj() {
		return $this->mKraj;
	}

	public function setIzobrazba($s) {
		$this->mIzobrazba = $s;
	}
	public function getIzobrazba() {
		return $this->mIzobrazba;
	}

    public function setStopnjaIzobrazbe($s) {
        $this->mStopnjaIzobrazbe = $s;
    }
    public function getStopnjaIzobrazbe() {
        return $this->mStopnjaIzobrazbe;
    }

	public function setIzobOpis($s) {
		$this->mIzobOpis = $s;
	}
	public function getIzobOpis() {
		return $this->mIzobOpis;
	}

	public function setDelDobaLet($s) {
		$this->mDelDobaLet = $s;
	}
	public function getDelDobaSol() {
		return $this->mDelDobaSol;
	}

    public function setDelDobaSol($s) {
        $this->mDelDobaSol = $s;
    }
    public function getDelDobaLet() {
        return $this->mDelDobaLet;
    }

	public function setDopustNaDD($s) {
		$this->mDopustNaDD = $s;
	}
	public function getDopustNaDD() {
		return $this->mDopustNaDD;
	}

	public function setDopustNaIz($s) {
		$this->mDopustNaIz = $s;
	}
	public function getDopustNaIz() {
		return $this->mDopustNaIz;
	}

	public function setDopustNaOt($s){
		$this->mDopustNaOt = $s;
	}
	public function getDopustNaOt() {
		return $this->mDopustNaOt;
	}

	public function setDopustNaSta($s) {
		$this->mDopustNaSta = $s;
	}
	public function getDopustNaSta() {
		return $this->mDopustNaSta;
	}

	public function setDopustNaInv($s) {
		$this->mDopustNaInv = $s;
	}
	public function getDopustNaInv() {
		return $this->mDopustNaInv;
	}

	public function setDopustNaVod($s) {
		$this->mDopustNaVod = $s;
	}
	public function getDopustNaVod() {
		return $this->mDopustNaVod;
	}

	public function setDopustStari($s) {
		$this->mDopustStari = $s;
	}
	public function getDopustStari() {
		return $this->mDopustStari;
	}

	public function setDopustVzgoja($s) {
		$this->mDopustVzgoja = $s;
	}
	public function getDopustVzgoja() {
		return $this->mDopustVzgoja;
	}

	public function setDopustDelInv($s) {
		$this->mDopustDelInv = $s;
	}
	public function getDopustDelInv() {
		return $this->mDopustDelInv;
	}

	public function setDopustPP($s) {
		$this->mDopustPP = $s;
	}
	public function getDopustPP() {
		return $this->mDopustPP;
	}

	public function setDopustDrugo($s) {
		$this->mDrugo = $s;
	}
	public function getDopustDrugo() {
		return $this->mDrugo;
	}

	public function setDelez($s) {
		$this->mDelez = $s;
	}
	public function getDelez() {
		return $this->mDelez;
	}

	public function setKoef($s) {
		$this->mKoef = $s;
	}
	public function getKoef() {
		return $this->mKoef;
	}

	public function setUporabnik($s) {
		$this->mUporabnik = $s;
	}
	public function getUporabnik() {
		return $this->mUporabnik;
	}

	public function setGeslo($s) {
		$this->mGeslo = $s;
	}
	public function getGeslo() {
		return $this->mGeslo;
	}

	public function setNivoDostopa($s) {
		$this->mNivoDostopa = $s;
	}
	public function getNivoDostopa() {
		return $this->mNivoDostopa;
	}

	public function setKomentar($s) {
		$this->mKomentar = $s;
	}
	public function getKomentar() {
		return $this->mKomentar;
	}

	public function setStatus($s) {
		$this->mStatus = $s;
	}
	public function getStatus() {
		return $this->mStatus;
	}

	public function setStatusDelavca($s) {
		$this->mStatusDelavca = $s;
	}
	public function getStatusDelavca() {
		return $this->mStatusDelavca;
	}

    public function setSistemizacijaU($s) {
        $this->mSistemizacija = $s;
    }
    public function getSistemizacijaU() {
        $sist="";
        if ($this->mStPog > 0) {
            for ($i=1;$i <= $this->mStPog;$i++) {
                if (strlen($sist)==0){
                    if (isset($this->mSistemizacija[$i])){
                        $sist = $this->mSistemizacija[$i];
                    }
                }else{
                    $enak=0;
                    for ($j=1;$j <= $i-1;$j++){
                        if (isset($this->mSistemizacija[$i]) && (isset($this->mSistemizacija[$j]))){
                            if ($this->mSistemizacija[$i] == $this->mSistemizacija[$j]){
                                $enak=$enak+1;
                            }
                        }
                    }
                    if ($enak == 0){
                        $sist = $sist.", ".$this->mSistemizacija[$i];
                    }
                }
            }
        }
        
        return $sist;
    }

	public function setDatumStart($s) {
		if (strstr($s,".")) { 
			$astr=explode(".",$s);
			$this->mDatumCStart = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
		}
		else {
			if (strstr($s,"-")) {
				$this->mDatumCStart = new DateTime($s);
			}
			else {
				$this->mDatumCStart=new DateTime("now");
			}
		}
	}
	public function getDatumStart() {
		return $this->mDatumCStart;
	}

	public function setVpisM1($s) {
		if (strstr($s,".")) { 
			$astr=explode(".",$s);
			$this->mVpisM1 = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
		}
		else {
			if (strstr($s,"-")) {
				$this->mVpisM1 = new DateTime($s);
			}
			else {
				$this->mVpisM1=new DateTime("now");
			}
		}
	}
    public function getVpisM1() {
        return $this->mVpisM1;
    }

	public function setDatumEnd($s) {
		if (strstr($s,".")) { 
			$astr=explode(".",$s);
			$this->mDatumCEnd = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
		}
		else {
			if (strstr($s,"-")) {
				$this->mDatumCEnd = new DateTime($s);
			}
			else {
				$this->mDatumCEnd=new DateTime("now");
			}
		}
	}
	public function getDatumEnd() {
		return $this->mDatumCEnd;
	}

	public function setIzpisM1($s) {
		if (strstr($s,".")) { 
			$astr=explode(".",$s);
			$this->mIzpisM1 = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
		}
		else {
			if (strstr($s,"-")) {
				$this->mIzpisM1 = new DateTime($s);
			}
			else {
				$this->mIzpisM1=new DateTime("now");
			}
		}
	}
	public function getIzpisM1() {
		return $this->mIzpisM1;
	}

	public function setPedIzobr($s) {
		$this->mPedIzobr = $s;
	}
	public function getPedIzobr() {
		return $this->mPedIzobr;
	}

	public function setStrokIzpit($s) {
		$this->mStrokIzpit = $s;
	}
	public function getStrokIzpit() {
		return $this->mStrokIzpit;
	}

	public function getUcenje() {
		return $this->mUcenje;
	}

	public function setMentor($s) {
		$this->mMentor = $s;
	}
	public function getMentor() {
		return $this->mMentor;
	}

	public function setSvetovalec($s) {
		$this->mSvetovalec = $s;
	}
	public function getSvetovalec() {
		return $this->mSvetovalec;
	}

	public function setSvetnik($s) {
		$this->mSvetnik = $s;
	}
	public function getSvetnik() {
		return $this->mSvetnik;
	}

	public function setZdrPregled($s) {
		$this->mZdrPregled = $s;
	}
	public function getZdrPregled() {
		return $this->mZdrPregled;
	}

	public function setPeriodaLet($s) {
		$this->mPeriodaLet = $s;
	}
	public function getPeriodaLet() {
		return $this->mPeriodaLet;
	}

	public function setPrevoz($s) {
		$this->mPrevoz = $s; 
	}
	public function getPrevoz() {
		return $this->mPrevoz;
	}

	public function setPozVarnost($s) {
		$this->mPozVarnost = $s;
	}
	public function getPozVarnost() {
		return $this->mPozVarnost;
	}

	public function setPeriodaPV($s) {
		$this->mPeriodaPV = $s;
	}
	public function getPeriodaPV() {
		return $this->mPeriodaPV;
	}

	public function setVarstvoDelo($s) {
		$this->mVarstvoDelo = $s;
	}
	public function getVarstvoDelo() {
		return $this->mVarstvoDelo;
	}

	public function setPeriodaVD($s) {
		$this->mPeriodaVD = $s;
	}
	public function getPeriodaVD() {
		return $this->mPeriodaVD;
	}

	public function setDavcna($s) {
		$this->mDavcna = $s;
	}
	public function getDavcna() {
		return $this->mDavcna;
	}

	public function setObcina($s) {
		$this->mObcina = $s;
	}
	public function getObcina() {
		return $this->mObcina;
	}

	public function setDrzava($s) {
		$this->mDrzava = $s;
	}
	public function getDrzava() {
		return $this->mDrzava;
	}

	public function setDrzavljanstvo($s) {
		$this->mDrzavljanstvo = $s;
	}
	public function getDrzavljanstvo() {
		return $this->mDrzavljanstvo;
	}

	public function setKrajRoj($s) {
		$this->mKrajRoj = $s;
	}
	public function getKrajRoj() {
		return $this->mKrajRoj;
	}

	public function setDrzavaRoj($s) {
		$this->mDrzavaRoj = $s;
	}
	public function getDrzavaRoj() {
		return $this->mDrzavaRoj;
	}

	public function setNaslovZac($s) {
		$this->mNaslovZac = $s;
	}
	public function getNaslovZac() {
		return $this->mNaslovZac;
	}

	public function setPostaZac($s) {
		$this->mPostaZac = $s;
	}
	public function getPostaZac() {
		return $this->mPostaZac;
	}

	public function setKrajZac($s) {
		$this->mKrajZac = $s;
	}
	public function getKrajZac() {
		return $this->mKrajZac;
	}

	public function setObcinaZac($s) {
		$this->mObcinaZac = $s;
	}
	public function getObcinaZac() {
		return $this->mObcinaZac;
	}

	public function setDrzavaZac($s) {
		$this->mDrzavaZac = $s;
	}
	public function getDrzavaZac() {
		return $this->mDrzavaZac;
	}

	public function setInvalid($s) {
		$this->mInvalid = $s;
	}
	public function getInvalid() {
		return $this->mInvalid;
	}

	public function setKatInvalid($s) {
		$this->mKatInvalid = $s;
	}
	public function getKatInvalid(){
		return $this->mKatInvalid;
	}

	public function setDelnoUpokojen($s) {
		$this->mDelnoUpokojen = $s;
	}
	public function getDelnoUpokojen(){
		return $this->mDelnoUpokojen;
	}

	public function setStarejsi($s) {
		$this->mStarejsi = $s;
	}
	public function getStarejsi(){
		return $this->mStarejsi;
	}

	public function setDojecaMati($s) {
		$this->mDojecaMati = $s;
	}
	public function getDojecaMati(){
		return $this->mDojecaMati;
	}
	
	public function setDopust($s) {
		$this->mDopust = $s;
	}
	public function getDopust(){
		return $this->mDopust;
	}

    public function setDopustVse($s) {
        $this->mDopustVse = $s;
    }
    public function getDopustVse(){
        return $this->mDopustVse;
    }

	public function setDolocenCas($s) {
		$this->mDolocenCas = $s;
	}
	public function getDolocenCas(){
		return $this->mDolocenCas;
	}

	public function setDoprinos($s) {
		$this->mDoprinos = $s;
	}
	public function getDoprinos(){
		return $this->mDoprinos;
	}

	public function setObveza($s) {
		$this->mObveza = $s;
	}
	public function getObveza(){
		return $this->mObveza;
	}

	public function setDoprinasanje($s) {
		$this->mDoprinasanje = $s;
	}
	public function getDoprinasanje(){
		return $this->mDoprinasanje;
	}

	public function setZmanjsanaObveza($n){
		$this->mZmanjsanaObveza = $n;
	}
	public function getZmanjsanaObveza() {
		return $this->mZmanjsanaObveza;
	}

	public function setDeloMedPocitnicami($n){
		$this->mDeloMedPocitnicami = $n;
	}
	public function getDeloMedPocitnicami(){
		return $this->mDeloMedPocitnicami;
	}

	public function setAktiv($s) {
		$this->mAktiv = $s;
	}
	public function getAktiv(){
		return $this->mAktiv;
	}

	public function setRazrednik($s) {
		$this->mRazrednik = $s;
	}
	public function getRazrednik(){
		return $this->mRazrednik;
	}
	public function getRazrednikRazred(){
		if (strlen($this->mRazrednik) > 2) {
			$s=explode(".",$this->mRazrednik);
			return $s[0];
		} else {
			return 0;
		}
	}
	public function getRazrednikParalelka(){
		if (strlen($this->mRazrednik) > 2) {
			$s=explode(".",$this->mRazrednik);
			return $s[1];
		} else {
			return "";
		}
	}

	public function setTelefon($s) {
		$this->mTelefon = $s;
	}
	public function getTelefon(){
		return $this->mTelefon;
	}

	public function setEmail($s) {
		$this->mEmail = $s;
	}
	public function getEmail(){
		return $this->mEmail;
	}

	public function setSifra($s) {
		$this->mSifra = $s;
	}
	public function getSifra(){
		return $this->mSifra;
	}

	public function setPlacniRazred($s) {
		$this->mPlacniRazred = $s;
	}
	public function getPlacniRazred(){
		return $this->mPlacniRazred;
	}

	public function setDrugiKontakti($s) {
		$this->mDrugiKontakti = $s;
	}
	public function getDrugiKontakti(){
		return $this->mDrugiKontakti;
	}

	public function setPreostaliDopust($s) {
		$this->mPreostaliDopust = $s;
	}
	public function getPreostaliDopust(){
		return $this->mPreostaliDopust;
	}

	public function getLetoPregled(){
		return $this->mVLetoPregled;
	}

	public function setRealiziranDoprinos($s) {
		$this->mRealiziranDoprinos = $s;
	}
	public function getRealiziranDoprinos(){
		return $this->mRealiziranDoprinos;
	}

	public function setPotrjenRealiziranDoprinos($s) {
		$this->mPotrjenRealiziranDoprinos = $s;
	}
	public function getPotrjenRealiziranDoprinos(){
		return $this->mPotrjenRealiziranDoprinos;
	}

	public function getCountDayPos($i,$j) {
		return $this->mCountDay[$i][$j];
	}

	public function getCountDay(){
		return $this->mCountDay;
	}

	public function getMesecneUre(){
		return $this->mMesecneUre;
	}

	public function getMesecneUrePos($i,$j){
		return $this->mMesecneUre[$i][$j];
	}

	public function getDnevneUre($i,$j,$k){
		return $this->mDnevneUre[$i][$j][$k];
	}

    public function getKolDop($i,$j,$k){
        return $this->mKolDop[$i][$j][$k];
    }
    
	public function setStPog($s) {
		$this->mStPog = $s;
	}
	public function getStPog(){
		return $this->mStPog;
	}

	public function setDoprinosiDelavca($s) {
		//Metoda priredi polje doprinosov
		$this->mDoprinosi = $s;
	}
	public function getDoprinosiDelavca(){
		//'Metoda vrne polje Doprinosov
		return $this->mDoprinosi;
	}
    public function getStDoprinosov(){
        //'Metoda vrne polje Doprinosov
        return $this->mStDoprinosov;
    }
	public function CheckPraznik($d){
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['praznik'])){
            switch ($this->mKolDop[$m][$dan]['praznik']){
                case 1:
                    return 2; //'prost dan
                case 0:
                    return 1; //'praznik
                case 2:
                    return 3; //'delovni dan - sobota
                case 3:
                case 4:
                    return 4; //'dela prost dan
                default:
                    return 0; //'ni v bazi/delovni dan
            }
        }else{
            return 0;
        }
    }    
        
	public function getCheckDelCas($d){
		//'vrne status delovnega časa na konkreten dan
		//'če gre za krajši delovni čas (vsota ur < 40), vrne 1, sicer pa 0
		
        /*
		//'novo
		$DelovnihUr=0;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			$datetime1 = $this->mDatumStart[$indx];
			$datetime2 = $this->mDatumEnd[$indx];
			$interval1 = $datetime1->diff($d);
			$interval2 = $d->diff($datetime2);
			
			if (($interval1->days >= 0) && ($interval2->days >= 0)){
				$DelovnihUr=$DelovnihUr + $this->mUrTeden[$indx];
			}
		}
		if ($DelovnihUr < 40){
			return 1;
		}
		else {
			return 0;
		}
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['urteden'])){
            if ($this->mKolDop[$m][$dan]['urteden'] < 40){
                return 1;
            }else{
                return 0;
            }
        }else{
            return 0;
        }
	}
	
	public function getCheckObremenitev($d){
		//podatek prejme v obliki objekta datetime
		//'vrne obremenitev na določen dan
		//'sešteje obremenitve po vseh aktualnih pogodbah
        
		/*
		//'nova obremenitev
		$obremenitev=0;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			$datetime1 = $this->mDatumStart[$indx];
			$datetime2 = $this->mDatumEnd[$indx];
			$interval1 = $datetime1->diff($d);
			$interval2 = $d->diff($datetime2);
			if (($interval1->days >= 0) && ($interval2->days >= 0)){
				switch ($d->format('w')+1){
					case 2:
						$obremenitev=$obremenitev+$this->mObremen1[$indx];
						break;
					case 3:
						$obremenitev=$obremenitev+$this->mObremen2[$indx];
						break;
					case 4:
						$obremenitev=$obremenitev+$this->mObremen3[$indx];
						break;
					case 5:
						$obremenitev=$obremenitev+$this->mObremen4[$indx];
						break;
					case 6:
						$obremenitev=$obremenitev+$this->mObremen5[$indx];
						break;
				}
			}
		}
		 return $obremenitev;
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['obremenitev'])){
            return $this->mKolDop[$m][$dan]['obremenitev'];
        }else{
            return 0;
        }
	}

	public function getCheckDogodek($d){
		//podatek prejme v obliki objekta datetime
		//na mDogodek prenese doprinose istega d dneva in vrne false, če ni dogodka, oz. true, če so dogodki
        /*
		$this->mDogodkovNaDan=0;
		$CheckDogodek=false;
		for ($Indx=0;$Indx <= 20;$Indx++){
			for ($i1=0;$i1 <= 6;$i1++){
				$this->mDogodek[$Indx][$i1]=0;
			}
		}
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if ($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')){
				$CheckDogodek=true;
				$this->mDogodkovNaDan = $this->mDogodkovNaDan + 1;
				for ($i1=0;$i1 <= 6;$i1++){
					$this->mDogodek[$this->mDogodkovNaDan][$i1]=$this->mDoprinosi[$Indx][$i1];
				}
			}
		}
		return $CheckDogodek;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')]['dogodek'])){
            return true;
        }else{
            return false;
        }
	}
	
	public function getDogodkovNaDan(){
		return $this->mDogodkovNaDan;
	}
	
	public function getDogodek($i,$j){
		return $this->mDogodek[$i][$j];
	}
	
	public function getNazivDelMesta($i){
		return $this->mNazivDelMesta[$i];
	}
	
	public function getCheckDoprinosi($d){
		//vrne vsoto doprinosov na določen dan d, ki ga prejme v obliki datetime
        /*
		$Suma=0;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
            $dan=$this->mDoprinosi[$Indx][0];
			if ($dan->format('Y-m-d') == $d->format('Y-m-d')){
				$Suma = $Suma + $this->mDoprinosi[$Indx][4];
			}
		}
		return $Suma;
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['SkCas'])){
            return $this->mKolDop[$m][$dan]['SkCas'];
        }else{
            return 0;
        }
	}

	public function getCheckPotrjeniDoprinosi($d){
		//vrne vsoto potrjenih doprinosov na določen dan d, ki ga prejme v obliki datetime
        /*
		$Suma=0;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
            $dan=$this->mDoprinosi[$Indx][0];
			if (($dan->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][6] > 0)){
				$Suma = $Suma + $this->mDoprinosi[$Indx][4];
			}
		}
		return $Suma;
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['SkCasP'])){
            return $this->mKolDop[$m][$dan]['SkCasP'];
        }else{
            return 0;
        }
	}

	public function getCheckBolniska($d){
		//vrne, da obstajajo bolniške na določen dan
        /*
		$CheckBolniska=false;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][5] == 3)){
				$CheckBolniska=true;
			}
		}
		return $CheckBolniska;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')][3])){
            return true;
        }else{
            return false;
        }
	}

    public function getCheckBolniskaNega($d){
        //vrne, da obstaja bolniška - nega na določen dan
        /*
        $CheckBolniska=false;
        for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
            if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][5] == 3)){
                $CheckBolniska=true;
            }
        }
        return $CheckBolniska;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')][22])){
            return true;
        }else{
            return false;
        }
    }

	public function getCheckBolniska50($d){
		//vrne, da obstajajo 50% bolniške na določen dan
        /*
		$CheckBolniska=false;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][5] == 4)){
				$CheckBolniska=true;
			}
		}
		return $CheckBolniska;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')][4])){
            return true;
        }else{
            return false;
        }
	}

	public function getCheckBolniskaProc($d){
		//vrne, da obstajajo ?% bolniške na določen dan
        /*
		$CheckBolniska=false;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][5] == 19)){
				$CheckBolniska=true;
			}
		}
		return $CheckBolniska;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')][19])){
            return true;
        }else{
            return false;
        }
	}

	public function getCheckBolniskaProcUre($d){
		//vrne število ur ?% bolniške
        /*
		$CheckBolniskaProcUre=0;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][5] == 19)){
				$CheckBolniskaProcUre=$CheckBolniskaProcUre+$this->mDoprinosi[$Indx][7];
			}
		}
		return $CheckBolniskaProcUre;
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan][19])){
            return $this->mKolDop[$m][$dan][19];
        }else{
            return 0;
        }
	}

	public function getProcentZaposlitve($d){
		//'vrne procent zaposlitve na dan v mesecu
		/*
		//'novo
		$DelovnihUr=0;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			$datetime1 = $this->mDatumStart[$indx];
			$datetime2 = $this->mDatumEnd[$indx];
			$interval1 = $datetime1->diff($d);
			$interval2 = $d->diff($datetime2);
			if (($interval1->days >= 0) && ($interval2->days >= 0)){
				if ($this->mUrTeden[$indx] > 0){
					$DelovnihUr=$DelovnihUr + $this->mUrTeden[$indx];
				} else {
					$DelovnihUr=$DelovnihUr+40;
				}
			}
		}
		return round($DelovnihUr/40*100);
        */
        $m=$d->format('n');
        $dan=$d->format('j');
        if (isset($this->mKolDop[$m][$dan]['urteden'])){
            return $this->mKolDop[$m][$dan]['urteden']/40*100;
        }else{
            return 0;
        }
	}

	public function getProcentZaposlitveM($leto,$mesec){
		//'vrne procent zaposlitve za aktualni mesec

        if (($leto) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }
		
		$DelovnihUr=0;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			$datetime1 = new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
			$datetime2 = new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
			$d1 = new datetime($leto."-".$mesec."-01");
			//$interval1 = $datetime1->diff($d1);
			$d2 = new datetime($leto."-".$mesec."-".$MesecDni[$mesec]);
			//$interval2 = $datetime2->diff($d2);
			
            $dd1=intval($datetime1->format('Ymd'));     //dejanski začetek dela
            $dz1=intval($d1->format('Ymd'));            //prvi dan meseca
            $dd2=intval($datetime2->format('Ymd'));     //dejanski konec pogodbe
            $dz2=intval($d2->format('Ymd'));            //zadnji dan meseca

			//if ($interval1->invert == 0) {
        //    if ($dd1 <= $dz1){
				$DatStart= new DateTime($d1->format('Y-m-d'));
		//	}else{         //če je datum začetka kasneje od 1. v aktualnem mesecu
		//		$DatStart= new dateTime($this->mDatumStart[$indx]->format('Y-m-d'));
		//	}
			
			//if ($interval2->invert > 0) {
            if ($dd2 > $dz2){   //je zaposlen cel mesec
				$DatEnd=new DateTime($d2->format('Y-m-d'));
                
			    //$interval1 = $DatStart->diff($d2);
			    //$interval2 = $DatEnd->diff($d1);
		    
                $ds1=intval($DatStart->format('Ymd'));
                $ds2=intval($DatEnd->format('Ymd'));
			    //if (($interval1->invert == 0) && ($interval2->invert == 1)) {
                if ($ds1 <= $dz2 && $ds2 > $dz1){
				    $interval3 = $DatStart->diff($DatEnd);
                    if ($interval3->invert == 0){
                    //if ($ds1 <= $ds2){
				        $DelovnihUr = $DelovnihUr + $this->mUrTeden[$indx]/40*($interval3->days+1);
                    }
			    }
            }else{
                if ($dd2 > $dz1){     //če pogodba poteče v aktualnem mesecu, še obračunava
                    $DatEnd=new DateTime($d2->format('Y-m-d'));
                    
                    $ds1=intval($DatStart->format('Ymd'));
                    $ds2=intval($DatEnd->format('Ymd'));
                    //if (($interval1->invert == 0) && ($interval2->invert == 1)) {
                    if ($ds1 <= $dz2 && $ds2 > $dz1){
                        $interval3 = $DatStart->diff($DatEnd);
                        if ($interval3->invert == 0){
                        //if ($ds1 <= $ds2){
                            $DelovnihUr = $DelovnihUr + $this->mUrTeden[$indx]/40*($interval3->days+1);
                        }
                    }
                }
                //$DatEnd=new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
            }
		}
//        if ($this->mStPog > 1){           //povprečje na število pogodb
//            $DelovnihUr=$DelovnihUr/$this->mStPog;
//        }
        if (isset($d2)){       //so pogodbe
		    $interval4 = $d1->diff($d2);
		    $ProcentZaposlitveM=$DelovnihUr/($interval4->days+1)*100;
		}else{                 //ni pogodb
            $ProcentZaposlitveM = 0;
        }
        if ($this->mStPog > 1){  //korekcija večih pogodb
            if ($ProcentZaposlitveM > 125){
                $ProcentZaposlitveM = 100;
            }
        }
//        }
		return $ProcentZaposlitveM;
	}
	
	public function getProcZapLetno($leto){
		//'vrne ute?eno povpre?je zaposlitve na letni ravni za izracun doprinosa
		
		$DatStartSkupno= new DateTime($leto."-12-31");
		$DatEndSkupno=new DateTime($leto."-01-01");
		$zaposlitev=0;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			$datetime1 = new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
			$datetime2 = new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
			$d1 = new DateTime($leto."-01-01");
			//$interval1 = $datetime1->diff($d1);
			$d2 = new DateTime($leto."-12-31");
			//$interval2 = $datetime2->diff($d2);

            $dd1=intval($datetime1->format('Ymd'));
            $dz1=intval($d1->format('Ymd'));
            $dd2=intval($datetime2->format('Ymd'));
            $dz2=intval($d2->format('Ymd'));

			//if ($interval1->invert == 0){
            if ($dd1 <= $dz1){
				$DatStart=new DateTime($d1->format('Y-m-d'));
			}else{
				$DatStart=new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
			}
			
			//if ($interval2->invert == 1){
            if ($dd2 > $dz2){
				$DatEnd=new DateTime($d2->format('Y-m-d'));
			}else{
				$DatEnd=new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
			}

            $ds1=intval($DatStart->format('Ymd'));
            $ds2=intval($DatEnd->format('Ymd'));
            $de=intval($DatEndSkupno->format('Ymd'));
            $ds=intval($DatStartSkupno->format('Ymd'));
			//'preveri čas zaposlitve - začetni in končni datum aktualnih pogodb za tekoče leto
			//$interval3 = $DatEnd->diff($DatEndSkupno);
			//if ($interval3->invert == 1){
            if ($ds2 > $de){
				$DatEndSkupno=new DateTime($DatEnd->format('Y-m-d'));
			}
			
			//$interval4 = $DatStart->diff($DatStartSkupno);
			//if ($interval4->invert == 0){
            if ($ds1 <= $ds){
				$DatStartSkupno=new DateTime($DatStart->format('Y-m-d'));
			}
			
			$interval5 = $DatStart->diff($DatEnd);
			if ($this->mUrTeden[$indx] > 0){
				$zaposlitev=$zaposlitev+$this->mUrTeden[$indx]/40*($interval5->days+1);
			}else{
				$zaposlitev=$zaposlitev+40/40*($interval->days+1);
			}
		}
		$interval6 = $DatStartSkupno->diff($DatEndSkupno);
		return round($zaposlitev/($interval6->days+1)*100,2);
	}
	
	public function getCheckDoprinosRubrika($d,$r){
        /*
		$Suma=0;
		for ($Indx=1;$Indx <= $this->mStDoprinosov;$Indx++){
			if (($this->mDoprinosi[$Indx][0]->format('Y-m-d') == $d->format('Y-m-d')) && ($this->mDoprinosi[$Indx][1] == $r)){
				$Suma=$Suma+$this->mDoprinosi[$Indx][7];
			}
		}
		return $Suma;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')][$r])){
            return $this->mKolDop[$d->format('n')][$d->format('j')][$r];
        }else{
            return 0;
        }
	}

	public function getDelMesto(){
        /*
		$DelMesto="";
		if ($this->mStPog > 0){
			for ($indx=1;$indx <= $this->mStPog;$indx++){
				if ($indx == 1){
					$DelMesto=$this->mNazivDelMesta[$indx]."</b>";
				}else{
					$enak=0;
					for ($indx1=1;$indx1 <= $indx-1;$indx1++){
						if ($this->mNazivDelMesta[$indx] == $this->mNazivDelMesta[$indx1]){
							$enak=$enak+1;
						}
					}
					if ($enak == 0){
						$DelMesto=$DelMesto.", ".$this->mNazivDelMesta[$indx];
					}
				}
			}
		}
        */
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['nazivdelmesta'])){
            return $this->mKolDop[$m][$d]['nazivdelmesta'];
        }else{
            return "Trenutno nima pogodb.";
        }
	}
    public function getSeDopusta(){
        return $this->mDopust+$this->mDopustStari-$this->mKoriscenDopust;
    }

    public function getOpisDela(){
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['opisdela'])){
            return $this->mKolDop[$m][$d]['opisdela'];
        }else{
            return "";
        }
    }

    public function getSkupinaDela(){
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['skupinadela'])){
            return $this->mKolDop[$m][$d]['skupinadela'];
        }else{
            return "";
        }
    }

    public function getIdDelo(){
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['iddelo'])){
            return $this->mKolDop[$m][$d]['iddelo'];
        }else{
            return "0";
        }
    }

    public function getIdVzgojnoDelo(){
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['idvzgdelo'])){
            return $this->mKolDop[$m][$d]['idvzgdelo'];
        }else{
            return "0";
        }
    }

    public function getVzgojnoDelo(){
        $dan=new DateTime("now");
        $m=$dan->format('n');
        $d=$dan->format('j');
        if (isset($this->mKolDop[$m][$d]['vzgojnodelo'])){
            return $this->mKolDop[$m][$d]['vzgojnodelo'];
        }else{
            return "0";
        }
    }

	public function PreberiSeGlavno($ucitelj,$VLetoPregled,$VLeto){
		//'Prebere podatke iz baze v objekt. 
		//'Poleg teh podatkov izra?una tudi:
		//'- dopust oz. dele? dopusta (TabDopust)
		//'- obvezo (glede na ?tevilo prostih dni)
		//'- tedensko obremenitev (TabKrajsiDelovnik)
		//'ter nastavi lastnosti, ki jih prebere v TabDelo, TabVzgDelo, TabStatus
		global $link;
        
		$this->mVLetoPregled=$VLetoPregled;
		
		$SQL = "SELECT tabucitelji.*, TabStatus.*,TabIzobrazba.opis,tabucitelji.status AS ustatus,TabStatus.status AS sstatus FROM ";
		$SQL = $SQL ."(tabucitelji ";
		$SQL = $SQL ."INNER JOIN TabStatus ON tabucitelji.status=TabStatus.IdStatus) " ;
		$SQL = $SQL ."INNER JOIN TabIzobrazba ON tabucitelji.izobrazba=TabIzobrazba.IdIzobrazba " ;
		$SQL = $SQL ."WHERE tabucitelji.IdUcitelj =" . $ucitelj; //'&" ORDER BY TabKrajsiDelovnik.datumDo DESC"

		$result = mysqli_query($link,$SQL);
		//$R = mysqli_fetch_array($result);
		if ($R = mysqli_fetch_array($result)) {
			$this->mIme=$R["Ime"];
			$this->mPriimek=$R["Priimek"];
			$this->mDekliski=$R["Dekliski"];
			$this->mIdUcitelj=$R["IdUcitelj"];
			$this->mSpol=$R["Spol"];
            if (strlen(isDate($R["DatRoj"])) > 0){
			    $this->mDatRoj=new DateTime($R["DatRoj"]);
            }else{
                $this->mDatRoj=new DateTime("now");
            }
			$this->mEmso=$R["EMSO"];
			$this->mNaslov=$R["Naslov"];
			$this->mPosta=$R["Posta"];
			$this->mKraj=$R["Kraj"];
			$this->mIzobrazba=$R["opis"];
            $this->mStopnjaIzobrazbe=$R["Izobrazba"];
			$this->mIzobOpis=$R["IzobOpis"];
			$this->mUporabnik=$R["Uporabnik"];
			$this->mGeslo=$R["Geslo"];
			$this->mNivoDostopa=$R["NivoDostopa"];
			$this->mKomentar=$R["Komentar"];
			$this->mStatus=$R["ustatus"];
			$this->mStatusDelavca=$R["sstatus"];
			$this->mPedIzobr=$R["PedIzobr"];
			$this->mStrokIzpit=$R["StrokIzpit"];
			$this->mMentor=$R["Mentor"];
			$this->mSvetovalec=$R["Svetovalec"];
			$this->mSvetnik=$R["Svetnik"];
			$this->mZdrPregled=$R["ZdrPregled"];
			$this->mPeriodaLet=$R["PeriodaLet"];
			$this->mPrevoz=$R["Prevoz"];
			$this->mPozVarnost=$R["PozVarnost"];
			$this->mPeriodaPV=$R["PeriodaPV"];
			$this->mVarstvoDelo=$R["VarstvoDelo"];
			$this->mPeriodaVD=$R["PeriodaVD"];
			$this->mDavcna=$R["Davcna"];
			$this->mObcina=$R["Obcina"];
			$this->mDrzava=$R["Drzava"];
			$this->mDrzavljanstvo=$R["drzavljanstvo"];
			$this->mKrajRoj=$R["KrajRoj"];
			$this->mDrzavaRoj=$R["DrzavaRoj"];
			$this->mNaslovZac=$R["NaslovZac"];
			$this->mPostaZac=$R["PostaZac"];
			$this->mKrajZac=$R["KrajZac"];
			$this->mObcinaZac=$R["ObcinaZac"];
			$this->mDrzavaZac=$R["DrzavaZac"];
			$this->mInvalid=$R["Invalid"];
			$this->mKatInvalid=$R["KatInvalid"];
			$this->mDelnoUpokojen=$R["DelnoUpokojen"];
			$this->mStarejsi=$R["Starejsi"];
			$this->mDojecaMati=$R["DojecaMati"];
			$this->mDoprinasanje=$R["Doprinasanje"];
            $this->mDelDobaSol=$R["DelDobaSol"];
            // $this->mSistemizacija=$R["Sistemizacija"];

			$this->mDolocenCas=false;
			if (($this->mStatus == 4) || ($this->mStatus == 5)){
				$this->mDolocenCas=true;
			}
			
			//'prebere iz TabDopust
            $this->mDelDobaLet=0;
            $this->mDopustNaDD=0;
            $this->mDopustNaInv=0;
            $this->mDopustNaIz=0;
            $this->mDopustNaOt=0;
            $this->mDopustNaSta=0;
            $this->mDopustNaVod=0;
            $this->mDopustVzgoja=0;
            $this->mDopustDelInv=0;
            $this->mDopustPP=0;
            $this->mDrugo=0;
            $this->mDopustStari=0;
            $this->mDelez=-1;

			$SQL = "SELECT * FROM TabDopust WHERE idUcitelj=".$ucitelj." AND leto=".$VLetoPregled;
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)) {
                if (isset($R["DelDobaLet"])){
				    $this->mDelDobaLet=$R["DelDobaLet"];
                }else{
                    $this->mDelDobaLet=0;
                }
                if (isset($R["DopustNaDD"])){
				    $this->mDopustNaDD=$R["DopustNaDD"];
                }else{
                    $this->mDopustNaDD=0;
                }
                if (isset($R["DopustNaInv"])){
				    $this->mDopustNaInv=$R["DopustNaInv"];
                }else{
                    $this->mDopustNaInv=0;
                }
                if (isset($R["DopustNaIz"])){
				    $this->mDopustNaIz=$R["DopustNaIz"];
                }else{
                    $this->mDopustNaIz=0;
                }
                if (isset($R["DopustNaOt"])){
				    $this->mDopustNaOt=$R["DopustNaOt"];
                }else{
                    $this->mDopustNaOt=0;
                }
                if (isset($R["DopustNaSta"])){
				    $this->mDopustNaSta=$R["DopustNaSta"];
                }else{
                    $this->mDopustNaSta=0;
                }
                if (isset($R["DopustNaVod"])){
				    $this->mDopustNaVod=$R["DopustNaVod"];
                }else{
                    $this->mDopustNaVod=0;
                }
                if (isset($R["DopustVzgoja"])){
				    $this->mDopustVzgoja=$R["DopustVzgoja"];
                }else{
                    $this->mDopustVzgoja=0;
                }
                if (isset($R["DopustDelInv"])){
				    $this->mDopustDelInv=$R["DopustDelInv"];
                }else{
                    $this->mDopustDelInv=0;
                }
                if (isset($R["DopustPP"])){
				    $this->mDopustPP=$R["DopustPP"];
                }else{
                    $this->mDopustPP=0;
                }
                if (isset($R["Drugo"])){
				    $this->mDrugo=$R["Drugo"];
                }else{
                    $this->mDrugo=0;
                }
                if (isset($R["DopustStari"])){
				    $this->mDopustStari=$R["DopustStari"];
                }else{
                    $this->mDopustStari=0;
                }
                if (isset($R["Delez"])){
				    $this->mDelez=$R["Delez"];
                }else{
                    $this->mDelez=-1;
                }
			}
			
			//'prebere iz pogodb
			$SQL = "SELECT tabpogodbe.*, TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo FROM ";
			$SQL = $SQL ."((tabpogodbe LEFT JOIN TabDelo ON tabpogodbe.IdDelo=TabDelo.IdDelo) ";
			$SQL = $SQL ."INNER JOIN TabVzgDelo ON tabpogodbe.IdVzgojnoDelo=TabVzgDelo.IdVzgojnoDelo) ";
			$SQL = $SQL . "WHERE idUcitelj=".$ucitelj;

			$indx=0;
			$indx1=0;
			$datIzkoriscen=false;
			
            $result = mysqli_query($link,$SQL);
            if (mysqli_num_rows($result) > 0){
			    while ($R = mysqli_fetch_array($result)){
				    if (!$datIzkoriscen){ 
					    $Datum=isDate($R["DatumStart"]);
					    
					    if (!$Datum) {
						    $Datum=$VLetoPregled."-01-01";
					    }
					    $this->mZacetekDela = new DateTime($Datum);
				    }
				    $datIzkoriscen=true;
				    $indx=$indx+1; //'upošteva le pogodbe za aktualno leto
				    $indx1=$indx1+1; //'šteje vse pogodbe
				    
				    $Datum=isDate($R["DatumEnd"]);
				    if (!$Datum) {
					    $Datum=($VLetoPregled+2)."-01-01";
				    }
				    $this->mDatumEnd[$indx]= new DateTime($Datum);

				    $Datum=isDate($R["DatumStart"]);
				    
				    if (!$Datum) {
					    $Datum=$VLetoPregled."-01-01";
				    }
				    $this->mDatumStart[$indx]=new DateTime($Datum);

				    $this->mIzpisM1[$indx]=$R["IzpisM1"];
				    $this->mVpisM1[$indx]=$R["VpisM1"];
				    
				    //'echo mZacetekDela&", "&mDatumStart(indx)&" "&DateDiff("d",mZacetekDela,mDatumStart(indx))&"<br />"
				    $datetime1 = new DateTime($this->mZacetekDela->format('Y-m-d'));
				    $datetime2 = new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
                    
                    $ds1=intval($datetime1->format('Ymd'));
                    $ds2=intval($datetime2->format('Ymd'));
				    //$interval = $datetime1->diff($datetime2);
				    //if ($interval->invert == 1){    // < 0
                    if ($ds1 > $ds2){
					    $this->mZacetekDela=new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
				    }
				    
				    //'pripravi le aktualne pogodbe (veljavne za to leto)
				    if (($VLetoPregled <= $this->mDatumEnd[$indx]->format('Y')) && ($VLetoPregled >= $this->mDatumStart[$indx]->format('Y'))){
					    $this->mIdDelo[$indx]=$R["IdDelo"];
					    $this->mDelovniCas[$indx]=$R["DelovniCas"];
					    $this->mIdVzgojnoDelo[$indx]=$R["IdVzgojnoDelo"];
					    $this->mKoef[$indx]=$R["Koef"];
					    if ($this->mKoef[$indx] == 0){
						    $this->mKoef[$indx]=1;
					    }
					    $this->mDopDelo[$indx]=$R["DopDelo"];
					    $this->mDelodaj1[$indx]=$R["Delodaj1"];
					    $this->mDelodaj1mat[$indx]=$R["Delodaj1mat"];
					    $this->mDelodajNaslov1[$indx]=$R["Delodaj1naslov"];
					    $this->mDelodaj2[$indx]=$R["Delodaj2"];
					    $this->mDelodaj2mat[$indx]=$R["Delodaj2mat"];
					    $this->mDelodajNaslov2[$indx]=$R["Delodaj2naslov"];
					    $this->mDelodaj3[$indx]=$R["Delodaj3"];
					    $this->mDelodaj3mat[$indx]=$R["Delodaj3mat"];
					    $this->mDelodajNaslov3[$indx]=$R["Delodaj3naslov"];
					    $this->mDatumPogodbe[$indx]=$R["DatumPogodbe"];
					    $this->mPolniDelCas[$indx]=$R["PolniDelCas"];
					    $this->mRazlogDolCas[$indx]=$R["RazlogDolCas"];
					    $this->mPotrStrokUsp[$indx]=$R["PotrStrokUsp"];
					    $this->mNazivDelMesta[$indx]=$R["NazivDelMesta"];
					    if (strlen($R["UrTeden"]) > 0){
						    $this->mUrTeden[$indx]=$R["UrTeden"];
					    } else {
						    $this->mUrTeden[$indx]=40;
					    }
					    $this->mIzmensko[$indx]=$R["Izmensko"];
					    $this->mKrajDela[$indx]=$R["KrajDela"];
					    $this->mKonkKlavz[$indx]=$R["KonkKlavz"];
					    $this->mNacinPrenehanja[$indx]=$R["NacinPrenehanja"];
					    $this->mOpisDela[$indx]=$R["OpisDela"];
					    $this->mSkupinaDela[$indx]=$R["SkupinaDela"];
					    $this->mVzgojnoDelo[$indx]=$R["VzgojnoDelo"];
					    $this->mStPogodbe[$indx]=$R["StPogodbe"];
					    $this->mObremen1[$indx]=$R["Obremen1"];
					    $this->mObremen2[$indx]=$R["Obremen2"];
					    $this->mObremen3[$indx]=$R["Obremen3"];
					    $this->mObremen4[$indx]=$R["Obremen4"];
					    $this->mObremen5[$indx]=$R["Obremen5"];
					    $this->mIzobUstr[$indx]=$R["IzobUstr"];
                        $this->mSistemizacija[$indx]=$R["Sistemizacija"];
                        $this->mOpombe[$indx]=$R["Opombe"];
                        
                        $dan=new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
                        $prviDan=new DateTime($VLetoPregled."-01-01");
                        
                        $ds1=intval($prviDan->format('Ymd'));
                        $dd=intval($dan->format('Ymd'));
                        
                        //$interval=$dan->diff($prviDan);
                        //if ($interval->invert == 0){
                        if ($dd <= $ds1){
                            $dan=new DateTime($prviDan->format('Y-m-d'));
                        }
                        $zadnjiDan=new DateTime(($VLetoPregled+1)."-01-01");
                        $dz1=intval($zadnjiDan->format('Ymd'));
                        $de=intval($this->mDatumEnd[$indx]->format('Ymd'));
                        
                        //$interval2=$zadnjiDan->diff($this->mDatumEnd[$indx]);
                        //if ($interval2->invert == 1){
                        if ($dz1 > $de){
                            $zadnjiDan=new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
                        }
                        /*
                        $interval1=$prviDan->diff($dan);
                        $interval2=$dan->diff($zadnjiDan);
                        while ($interval1->invert == 0 && $interval2->invert == 0){
                        */
                        if ($prviDan->format('Ymd') <= $dan->format('Ymd')){
                            $interval1 = 0;
                        }else{
                            $interval1 = 1;
                        }
                        if ($dan->format('Ymd') <= $zadnjiDan->format('Ymd')){
                            $interval2 = 0;
                        }else{
                            $interval2 = 1;
                        }
                        
                        //while ($interval1->invert == 0 && $interval2->invert == 0){
                        while ($interval1 == 0 && $interval2 == 0){
//                            if ($dan->format('Y-m-d') != $zadnjiDan->format('Y-m-d')){
                            $m=$dan->format('n'); //dan
                            $d=$dan->format('j'); //mesec
                            if ($dan->format('Ymd') <= $zadnjiDan->format('Ymd')){
                                $this->mKolDop[$m][$d]['zaposlen']=1;     //na ta dan je zaposlen
                                //izračuna obremenitev na ta dan
                                if (isset($this->mKolDop[$m][$d]['obremenitev'])){
                                    switch ($dan->format('w')){
                                        case 1: //PON
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mKolDop[$m][$d]['obremenitev']+$this->mObremen1[$indx];
                                            break;
                                        case 2: //TOR
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mKolDop[$m][$d]['obremenitev']+$this->mObremen2[$indx];
                                            break;
                                        case 3: //SRE
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mKolDop[$m][$d]['obremenitev']+$this->mObremen3[$indx];
                                            break;
                                        case 4: //ČET
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mKolDop[$m][$d]['obremenitev']+$this->mObremen4[$indx];
                                            break;
                                        case 5: //PET
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mKolDop[$m][$d]['obremenitev']+$this->mObremen5[$indx];
                                            break;
                                    }
                                }else{
                                    switch ($dan->format('w')){
                                        case 1: //PON
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mObremen1[$indx];
                                            break;
                                        case 2: //TOR
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mObremen2[$indx];
                                            break;
                                        case 3: //SRE
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mObremen3[$indx];
                                            break;
                                        case 4: //ČET
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mObremen4[$indx];
                                            break;
                                        case 5: //PET
                                            $this->mKolDop[$m][$d]['obremenitev']=$this->mObremen5[$indx];
                                            break;
                                    }
                                }
                                //ur na teden
                                if (isset($this->mKolDop[$m][$d]['urteden'])){
                                    $this->mKolDop[$m][$d]['urteden']=$this->mKolDop[$m][$d]['urteden']+$this->mUrTeden[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['urteden']=$this->mUrTeden[$indx];
                                }
                                //sestavi naziv delovnega mesta
                                if (isset($this->mKolDop[$m][$d]['nazivdelmesta'])){
                                    $this->mKolDop[$m][$d]['nazivdelmesta']=$this->mKolDop[$m][$d]['nazivdelmesta'].', '.$this->mNazivDelMesta[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['nazivdelmesta']=$this->mNazivDelMesta[$indx];
                                }
                                //sestavi opis dela
                                if (isset($this->mKolDop[$m][$d]['opisdela'])){
                                    $this->mKolDop[$m][$d]['opisdela']=$this->mKolDop[$m][$d]['opisdela'].', '.$this->mOpisDela[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['opisdela']=$this->mOpisDela[$indx];
                                }
                                //sestavi skupino dela
                                if (isset($this->mKolDop[$m][$d]['skupinadela'])){
                                    $this->mKolDop[$m][$d]['skupinadela']=$this->mKolDop[$m][$d]['skupinadela'].', '.$this->mSkupinaDela[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['skupinadela']=$this->mSkupinaDela[$indx];
                                }
                                //sestavi iddelo
                                if (isset($this->mKolDop[$m][$d]['iddelo'])){
                                    $this->mKolDop[$m][$d]['iddelo']=$this->mKolDop[$m][$d]['iddelo'].', '.$this->mIdDelo[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['iddelo']=$this->mIdDelo[$indx];
                                }
                                //sestavi idvzgdelo
                                if (isset($this->mKolDop[$m][$d]['idvzgdelo'])){
                                    $this->mKolDop[$m][$d]['idvzgdelo']=$this->mKolDop[$m][$d]['idvzgdelo'].', '.$this->mIdVzgojnoDelo[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['idvzgdelo']=$this->mIdVzgojnoDelo[$indx];
                                }
                                //sestavi vzgojnodelo
                                if (isset($this->mKolDop[$m][$d]['vzgojnodelo'])){
                                    $this->mKolDop[$m][$d]['vzgojnodelo']=$this->mKolDop[$m][$d]['vzgojnodelo'].', '.$this->mVzgojnoDelo[$indx];
                                }else{
                                    $this->mKolDop[$m][$d]['vzgojnodelo']=$this->mVzgojnoDelo[$indx];
                                }
                            }
                            $dan->add(new DateInterval('P1D'));
                            /*
                            $interval2=$dan->diff($zadnjiDan);
                            $interval1=$prviDan->diff($dan);
                            */
                            if ($prviDan->format('Ymd') <= $dan->format('Ymd')){
                                $interval1 = 0;
                            }else{
                                $interval1 = 1;
                            }
                            if ($dan->format('Ymd') <= $zadnjiDan->format('Ymd')){
                                $interval2 = 0;
                            }else{
                                $interval2 = 1;
                            }
                        }
				    } else {
					    $indx=$indx-1;
				    }
			    }
			    $this->mStPog=$indx;
			    $this->mStVsehPogodb=$indx1;
            }else{
                $Datum=$VLetoPregled."-01-01";
                $this->mZacetekDela = new DateTime($Datum);
                $this->mDatumEnd[1]= new DateTime($Datum);
                $this->mDatumStart[1]=new DateTime($Datum);
                $this->mIzpisM1[1]="";
                $this->mVpisM1[1]="";
                $this->mStPog=0;
                $this->mStVsehPogodb=0;
            }
			
			//'nastavi začetni datum na pogodbo, ki se je prva začela in končni na tisto, ki se zadnja neha
			//'pri pogodbah, ki veljajo za aktualno leto
            if (!isset($this->mDatumStart[1])){
                  $DatumCStart=new DateTime("now");
            }else{
			    $DatumCStart=new DateTime($this->mDatumStart[1]->format('Y-m-d'));
            }
            if (!isset($this->mDatumEnd[1])){
                $DatumCEnd=new DateTime("now");
            }else{
			    $DatumCEnd=new DateTime($this->mDatumEnd[1]->format('Y-m-d'));
            }
			for ($indx=1;$indx <= $this->mStPog;$indx++){
				$datetime1 = new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
				$datetime2 = new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
				//$interval1 = $DatumCStart->diff($datetime1);
				//$interval2 = $DatumCEnd->diff($datetime2);
				
                $dd1=intval($datetime1->format('Ymd'));
                $dd2=intval($datetime2->format('Ymd'));
                $ds=intval($DatumCStart->format('Ymd'));
                $de=intval($DatumCEnd->format('Ymd'));
                
				//if ($interval1->invert == 1){
                if ($ds > $dd1){
					$DatumCStart=new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
				}
				//if ($interval2->invert == 0){
                if ($de <= $dd2){
					$DatumCEnd=new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
				}
			}
			
			//'mZacetekDela=DatumCStart
            $this->mDopustVse = $this->mDopustNaDD+$this->mDopustNaIz+$this->mDopustNaOt+$this->mDopustNaSta+$this->mDopustNaInv+$this->mDopustNaVod+$this->mDopustVzgoja+$this->mDopustDelInv+$this->mDopustPP+$this->mDrugo;
			if ($this->mDelez >= 0){
				$this->mDopust = $this->mDelez;
			}else{
				$this->mDopust = $this->mDopustNaDD+$this->mDopustNaIz+$this->mDopustNaOt+$this->mDopustNaSta+$this->mDopustNaInv+$this->mDopustNaVod+$this->mDopustVzgoja+$this->mDopustDelInv+$this->mDopustPP+$this->mDrugo;
                if ($this->mDopust-$this->mDopustPP > 35){
                    $this->mDopust = 35+$this->mDopustPP;
                }
			}
			
			//'vodja aktiva
			$SQL = "SELECT TabVodjeAktivov.*,TabAktiv.* FROM ";
			$SQL = $SQL . "TabVodjeAktivov INNER JOIN TabAktiv ON TabVodjeAktivov.idAktiv=TabAktiv.id ";
			$SQL = $SQL . "WHERE leto=".$VLeto." AND idUcitelj=".$ucitelj;
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$this->mAktiv=$R["Aktiv"];
			}else{
				$this->mAktiv="";
			}

			//'razrednik
			$SQL = "SELECT tabrazdat.* FROM ";
			$SQL = $SQL . "tabucenje INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
			$SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND predmet=50 AND idUcitelj=".$ucitelj;

			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$this->setRazrednik($R["razred"].". ".$R["oznaka"]);
			}else{
				$this->setRazrednik("");
			}
			
			//'kontaktni podatki
			$SQL = "SELECT tabucitelji.*,tabkontakti.* FROM tabucitelji LEFT JOIN tabkontakti ON tabucitelji.idUcitelj=tabkontakti.idUcitelj ";
			$SQL = $SQL . " WHERE tabucitelji.idUcitelj=".$ucitelj;
			
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$this->setTelefon($R["Telefon"]);
				$this->setEmail($R["email"]);
				$this->setDrugiKontakti($R["drugo"]);
			}
			
			//'šifra in plačni razred
			$SQL = "SELECT * FROM TabRacunovodstvo WHERE leto=".$VLeto." AND idUcitelj=".$ucitelj;
			
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$this->setSifra($R["sifra"]);
				$this->setPlacniRazred($R["placRazred"]);
			}else{
				$this->setSifra("");
				$this->setPlacniRazred(0);
			}

			$this->mDatumCStart=$DatumCStart;
			$this->mDatumCEnd=$DatumCEnd;
            
            $this->mPrekinjena=$this->getPrekinjena();
		}else{
            echo $SQL."<br />";
            echo "Delavec ".$ucitelj." nima vnesenih vseh podatkov!<br />";
            die('Napaka pri branju baze: ' . mysqli_error());
        }
	}
	
    public function PreberiSe($ucitelj,$VLetoPregled,$VLeto){
        //'Prebere podatke iz baze v objekt. 
        //'Poleg teh podatkov izra?una tudi:
        //'- dopust oz. dele? dopusta (TabDopust)
        //'- obvezo (glede na ?tevilo prostih dni)
        //'- tedensko obremenitev (TabKrajsiDelovnik)
        //'ter nastavi lastnosti, ki jih prebere v TabDelo, TabVzgDelo, TabStatus

        global $DelovniDan;
        global $link;
    /*    for ($i=1;$i<=12;$i++){
            for ($j=1;$j<=31;$j++){
                for ($k=0;$k<=35;$k++){
                    $this->mKolDop[$i][$j][$k]=0;
                }
                $this->mKolDop[$i][$j][26]="";
                $this->mKolDop[$i][$j][32]="";
                $this->mKolDop[$i][$j][34]="";
            }
        }        
     */   
        $this->PreberiSeGlavno($ucitelj,$VLetoPregled,$VLeto);
        $DatumCStart=new DateTime($this->mDatumCStart->format('Y-m-d'));
        $DatumCEnd=new DateTime($this->mDatumCEnd->format('Y-m-d'));
            
        //'Prebere doprinose mDoprinosi, nastavi mKoriscenDopust in mStDoprinosov
/* staro        
        $SQL = "SELECT tabpregleddelan.datum,tabpregleddelan.rubrika,tabpregleddelan.enot,tabpregleddelan.komentar,tabpregleddelan.ucitelj,tabpregleddelan.enotpotrjeno ";
        $SQL = $SQL . ",tabdoprinos.addsub,tabdoprinos.aktivno,tabdoprinos.koeficient,tabdoprinos.uramin,tabdoprinos.oblikadelaoznaka ";
        $SQL = $SQL . " FROM tabpregleddelan INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos ";
        $SQL = $SQL . " WHERE tabpregleddelan.leto=".$VLetoPregled." AND tabpregleddelan.ucitelj=".$ucitelj." ORDER BY datum";
*/
//novo
        $SQL = "SELECT iddoprinos,addsub,aktivno,koeficient,uramin,oblikadelaoznaka FROM tabdoprinos";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Doprinos[$R["iddoprinos"]]["addsub"]=$R["addsub"];
            $Doprinos[$R["iddoprinos"]]["koeficient"]=$R["koeficient"];
            $Doprinos[$R["iddoprinos"]]["uramin"]=$R["uramin"];
            $Doprinos[$R["iddoprinos"]]["aktivno"]=$R["aktivno"];
            $Doprinos[$R["iddoprinos"]]["oblikadelaoznaka"]=$R["oblikadelaoznaka"];
        }
        $SQL = "SELECT tabpregleddelan.datum,tabpregleddelan.rubrika,tabpregleddelan.enot,tabpregleddelan.komentar,tabpregleddelan.ucitelj,tabpregleddelan.enotpotrjeno ";
        $SQL = $SQL . " FROM tabpregleddelan ";
        $SQL = $SQL . " WHERE tabpregleddelan.leto=".$VLetoPregled." AND tabpregleddelan.ucitelj=".$ucitelj." ORDER BY datum";
        
        $this->mKoriscenDopust=0;
        $Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Indx=$Indx+1;
            $dan=new DateTime($R["datum"]);
            $d=$dan->format('j');
            $m=$dan->format('n');
            
            $this->mDoprinosi[$Indx][0]=new DateTime($dan->format('Y-m-d'));
            $this->mDoprinosi[$Indx][1]=$R["rubrika"];
            $ProcZaposl=$this->getProcentZaposlitve($dan);
            switch ($this->mDoprinosi[$Indx][1]) {
                //'case 27,35,36,37,38,39,40,47 'odsotnosti: dopusti
                case 27: //'letni dopust, gabrov dan
                    //ne upošteva
                    break;
                case 35:
                    if ($this->mPrekinjena){
                        if ($this->getZaposlenZadnjaPog($dan)){
                            $this->mKoriscenDopust=$this->mKoriscenDopust+$R["enot"];
                        }
                    }else{
                        $this->mKoriscenDopust=$this->mKoriscenDopust+$R["enot"];
                    }
            }
            $this->mDoprinosi[$Indx][2]=$R["komentar"];
            $this->mDoprinosi[$Indx][3]=$R["ucitelj"];
            $koef=floatval($Doprinos[intval($R["rubrika"])]["koeficient"]);
            $enot=floatval($R["enot"]);
            $uramin=intval($Doprinos[intval($R["rubrika"])]["uramin"]);
            $aktivno=intval($Doprinos[intval($R["rubrika"])]["aktivno"]);
            switch ($Doprinos[intval($R["rubrika"])]["addsub"]){
                case "add":
                    if (($koef == 8) && ($ProcZaposl < 100)){
                        $this->mDoprinosi[$Indx][4]=0+$enot/$uramin*$koef*$ProcZaposl/100;
                    }else{
                        $this->mDoprinosi[$Indx][4]=0+$enot/$uramin*$koef;
                    }
                    break;
                case "sub":
                    if (($koef == 8) && ($ProcZaposl < 100)){
                        $this->mDoprinosi[$Indx][4]=0-$enot/$uramin*$koef*$ProcZaposl/100;
                    }else{
                        $this->mDoprinosi[$Indx][4]=0-$enot/$uramin*$koef;
                    }
                    break;
            }
            $this->mDoprinosi[$Indx][5]=$aktivno;
            $this->mDoprinosi[$Indx][6]=$R["enotpotrjeno"];
            $this->mDoprinosi[$Indx][7]=$R["enot"];
            
            //izračuna kumulativo doprinosa za določen dan
            if (isset($this->mKolDop[$m][$d]['SkCas'])){
                $this->mKolDop[$m][$d]['SkCas']= $this->mKolDop[$m][$d]['SkCas']+$this->mDoprinosi[$Indx][4];
                $this->mKolDop[$m][$d]['dogodek']=true;
            }else{
                $this->mKolDop[$m][$d]['SkCas']=$this->mDoprinosi[$Indx][4];
                $this->mKolDop[$m][$d]['dogodek']=true;
            }

            //tvori opis dneva - vse komentarje vpisanih rubrik
            if (isset($this->mKolDop[$m][$d]['komentarji'])){
                $this->mKolDop[$m][$d]['komentarji']= $this->mKolDop[$m][$d]['komentarji']."\n".$this->mDoprinosi[$Indx][2];
            }else{
                $this->mKolDop[$m][$d]['komentarji']=$this->mDoprinosi[$Indx][2];
            }

            //kumulativa potrjenih doprinosov
            if (isset($this->mKolDop[$m][$d]['SkCasP'])){
                if ($this->mDoprinosi[$Indx][6]){
                    $this->mKolDop[$m][$d]['SkCasP']= $this->mKolDop[$m][$d]['SkCasP']+$this->mDoprinosi[$Indx][4];
                }
            }else{
                if ($this->mDoprinosi[$Indx][6]){
                    $this->mKolDop[$m][$d]['SkCasP']=$this->mDoprinosi[$Indx][4];
                }
            }
            //zavede Koriščenje ur - če je v dnevu -8 ur
            if (isset($this->mKolDop[$m][$d]['SkCasP']) && !$this->mDoprinasanje){
                if ($this->mKolDop[$m][$d]['SkCasP']==-8){
                    $this->mKolDop[$m][$d]['5']=1;
                    $this->mKolDop[$m][$d]['dogodek']=true;
                }
            }
            
            //skombinira oznako dneva (če jih je več)
            if (isset($Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"])){
                if (isset($this->mKolDop[$m][$d]['OznDan'])){
                    $this->mKolDop[$m][$d]['OznDan']=$this->mKolDop[$m][$d]['OznDan']." ".$Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"];
                }else{
                    $this->mKolDop[$m][$d]['OznDan']=$Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"];
                }
            }
            //označi, katere rubrike obstajajo in v primeru koeficienta 0 zapiše kumulativo, sicer pa 1 (obstaja)
            if (isset($this->mKolDop[$m][$d][$aktivno])){
                if ($koef == 0){     //aktivne rubrike
                    $this->mKolDop[$m][$d][$aktivno]=$this->mDoprinosi[$Indx][4];
                    $this->mKolDop[$m][$d]['dogodek']=true;
                }else{
                    if ($aktivno==19){
                        $this->mKolDop[$m][$d][$aktivno]=$this->mDoprinosi[$Indx][7];
                        $this->mKolDop[$m][$d]['dogodek']=true;
                    }else{
                        $this->mKolDop[$m][$d][$aktivno]=1;
                        $this->mKolDop[$m][$d]['dogodek']=true;
                    }
                }
            }else{
                $this->mKolDop[$m][$d][$aktivno]=1;
                $this->mKolDop[$m][$d]['dogodek']=true;
            }
                
            /*
            if (isset($this->mKolDop[$dan->format('n')][$dan->format('j')]['DanStat'])){
                $this->mKolDop[$dan->format('n')][$dan->format('j')]['DanStat']=$this->mKolDop[$dan->format('n')][$dan->format('j')]['DanStat'];
            }else{
                $this->mKolDop[$dan->format('n')][$dan->format('j')]['DanStat']=;
            }
            */
        }
        $this->mStDoprinosov=$Indx;
        
        //označi praznike in tip (kat)
        $SQL = "SELECT datum,kat FROM TabPraznik WHERE year(datum)=".$VLetoPregled." ORDER BY datum";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);
            $this->mKolDop[$dan->format('n')][$dan->format('j')]['praznik']=$R["kat"];
        }
        /*
        //'med posebnimi dnevi za aktualno leto
        $SQL = "SELECT datum FROM TabPraznik WHERE year(datum)=".$VLetoPregled." AND kat =1";
        //'izračuna obvezo
        $indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);
            
            //označi praznike in tip (kat)
            $this->mKolDop[$dan->format('n')][$dan->format('j')]['praznik']=$R["kat"];
            
            //'izračuna obvezo
            if ($this->getZaposlen($dan)){
                if (($DatumCStart->format('Ymd') <= $dan->format('Ymd')) && ($dan->format('Ymd') <= $DatumCEnd->format('Ymd'))){
                    $indx=$indx+1;
                }
            }
        }
        $this->mObveza=$indx;
        */
        
        //'preveri, če je porodniška ali bolniška med počitnicami (zaradi zmanjšanja obveze)
        $SQL = "SELECT datum,kat FROM TabPraznik WHERE year(datum)=".$VLetoPregled." AND kat =1";
        //'izračuna korekcijo obveze
        $indx=0;
        $indxObveza=0;
        $indxDopust=0;
        $indxDelovniDopust=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);

            //označi praznike in tip (kat)
            $this->mKolDop[$dan->format('n')][$dan->format('j')]['praznik']=$R["kat"];
            
            
            $danes=new DateTime("now");
            $d=$dan->format('j');
            $m=$dan->format('n');
            if ($this->getZaposlen($dan)){
                //'izračuna obvezo
                /*
                $interval1 = $dan->diff($DatumCStart);
                $interval2 = $dan->diff($DatumCEnd);
                
                if (($interval1->invert == 1) && ($interval2->invert == 0)){
                */
                if (($DatumCStart->format('Ymd') <= $dan->format('Ymd')) && ($dan->format('Ymd') <= $DatumCEnd->format('Ymd'))){
                    $indxObveza += 1;
                }

                /*
                $interval1 = $dan->diff($DatumCStart);
                $interval2 = $dan->diff($DatumCEnd);
                if (($interval1->invert == 1) && ($interval2->invert == 0)){
                */
                if (($DatumCStart->format('Ymd') <= $dan->format('Ymd')) && ($dan->format('Ymd') <= $DatumCEnd->format('Ymd'))){
                    $ddn=intval($danes->format('Ymd'));
                    $dd=intval($dan->format('Ymd'));
                    //$interval3 = $danes->diff($dan);
                    //if ($interval3->invert == 1 or $interval3->days == 0){
                    if ($ddn >= $dd){
                        $indxDelovniDopust=$indxDelovniDopust+1;    //'število prostih dni v letu po koledarju do današnjega dne
                    }
                    if (isset($this->mKolDop[$m][$d]['10'])){    //porodniška
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['11'])){    //nega
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['3'])){ //bolniška
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['4'])){   //bolniška 50%
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['22'])){   //bolniška - nega
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['2'])){   //Gaber
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['5'])){    //dopust ure
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['6'])){    //dopust
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                        
                }
            }
        }
        $this->mObveza=$indxObveza;
        
        //'od obveze odšteje število dni porodniške in bolniške med počitnicami
        $this->mZmanjsanaObveza = $indx;
        $this->mDeloMedPocitnicami = $indxDelovniDopust-$indxDopust;
        $this->mObveza = $this->mObveza - $this->mZmanjsanaObveza - $this->mDeloMedPocitnicami;

        $this->mUcenje=0;
        for ($indx=1;$indx <= $this->mStPog;$indx++){
            //'učitelj,vzgojitelj, pripravnik
//            if (($this->mIdVzgojnoDelo[$indx]==1) || ($this->mIdVzgojnoDelo[$indx]==2) || ($this->mIdVzgojnoDelo[$indx]==19) || ($this->mDoprinasanje)){
            if (($this->mDoprinasanje)){
                $this->mUcenje=1;
            }
        }
        
        $ProcZaposl=$this->getProcZapLetno($VLetoPregled);
        if ($this->mUcenje==1){
            if  ($ProcZaposl < 100){ //'krajši
                $this->mDoprinos=($this->mObveza-$this->mDopust-$this->mDopustStari)*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000];
                if ($this->mDopust+$this->mDopustStari >= $this->mObveza){
                    $this->mDoprinos=0;
                }
            }else{    
                $this->mDoprinos=($this->mObveza-$this->mDopust-$this->mDopustStari)*$DelovniDan[$VLetoPregled-2000];
                if ($this->mDopust+$this->mDopustStari >= $this->mObveza){
                    $this->mDoprinos=0;
                }
            }    
        }else{
            $this->mDoprinos=0;
            $this->mObveza=0;
        }
    }
    
	public function PreberiSeMinusi($ucitelj,$VLetoPregled,$VLeto,$VMesec){
		//'Prebere podatke iz baze v objekt. 
		//'Poleg teh podatkov izra?una tudi:
		//'- dopust oz. dele? dopusta (TabDopust)
		//'- obvezo (glede na ?tevilo prostih dni)
		//'- tedensko obremenitev (TabKrajsiDelovnik)
		//'ter nastavi lastnosti, ki jih prebere v TabDelo, TabVzgDelo, TabStatus
		
        global $DelovniDan;
        global $link;
    /*     for ($i=1;$i<=12;$i++){
            for ($j=1;$j<=31;$j++){
                for ($k=0;$k<=35;$k++){
                    $this->mKolDop[$i][$j][$k]=0;
                }
                $this->mKolDop[$i][$j][26]="";
                $this->mKolDop[$i][$j][32]="";
                $this->mKolDop[$i][$j][34]="";
            }
        }        
    */    
        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }
        $this->PreberiSeGlavno($ucitelj,$VLetoPregled,$VLeto);
        $DatumCStart=new DateTime($this->mDatumCStart->format('Y-m-d'));
        $DatumCEnd=new DateTime($this->mDatumCEnd->format('Y-m-d'));
            
            //'Prebere doprinose mDoprinosi, nastavi mKoriscenDopust in mStDoprinosov
        $SQL = "SELECT iddoprinos,addsub,aktivno,koeficient,uramin,oblikadelaoznaka,spremenljivka FROM tabdoprinos";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Doprinos[$R["iddoprinos"]]["addsub"]=$R["addsub"];
            $Doprinos[$R["iddoprinos"]]["koeficient"]=$R["koeficient"];
            $Doprinos[$R["iddoprinos"]]["uramin"]=$R["uramin"];
            $Doprinos[$R["iddoprinos"]]["aktivno"]=$R["aktivno"];
            $Doprinos[$R["iddoprinos"]]["oblikadelaoznaka"]=$R["oblikadelaoznaka"];
            $Doprinos[$R["iddoprinos"]]["spremenljivka"]=$R["spremenljivka"];
        }
        $SQL = "SELECT tabpregleddelan.datum,tabpregleddelan.rubrika,tabpregleddelan.enot,tabpregleddelan.komentar,tabpregleddelan.ucitelj,tabpregleddelan.enotpotrjeno ";
        $SQL = $SQL . " FROM tabpregleddelan ";
        $SQL = $SQL . " WHERE tabpregleddelan.leto=".$VLetoPregled." AND tabpregleddelan.ucitelj=".$ucitelj." ORDER BY datum";
        $this->mKoriscenDopust=0;
        $Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if (($Doprinos[$R["rubrika"]]["addsub"]=="add") && ($Doprinos[$R["rubrika"]]["aktivno"] < 2) or ($Doprinos[$R["rubrika"]]["spremenljivka"]=="Predure")){
                continue;
            }else{
                $Indx=$Indx+1;
                $dan=new DateTime($R["datum"]);
                $m=$dan->format('n');
                $d=$dan->format('j');
                
                $this->mDoprinosi[$Indx][0]=new DateTime($dan->format('Y-m-d'));
                $this->mDoprinosi[$Indx][1]=$R["rubrika"];
                $ProcZaposl=$this->getProcentZaposlitve($dan);
                switch ($this->mDoprinosi[$Indx][1]) {
                    //'case 27,35,36,37,38,39,40,47 'odsotnosti: dopusti
                    case 27: //'letni dopust, gabrov dan
                        break;
                    case 35:
                        if ($this->mPrekinjena){
                            if ($this->getZaposlenZadnjaPog($dan)){
                                $this->mKoriscenDopust=$this->mKoriscenDopust+$R["enot"];
                            }
                        }else{
                            $this->mKoriscenDopust=$this->mKoriscenDopust+$R["enot"];
                        }
                }
                $this->mDoprinosi[$Indx][2]=$R["komentar"];
                $this->mDoprinosi[$Indx][3]=$R["ucitelj"];
                $koef=floatval($Doprinos[intval($R["rubrika"])]["koeficient"]);
                $enot=floatval($R["enot"]);
                $uramin=intval($Doprinos[intval($R["rubrika"])]["uramin"]);
                $aktivno=intval($Doprinos[intval($R["rubrika"])]["aktivno"]);
                switch ($Doprinos[intval($R["rubrika"])]["addsub"]){
                    case "add":
                        if (($koef == 8) && ($ProcZaposl < 100)){
                            $this->mDoprinosi[$Indx][4]=0+$enot/$uramin*$koef*$ProcZaposl/100;
                        }else{
                            $this->mDoprinosi[$Indx][4]=0+$enot/$uramin*$koef;
                        }
                        break;
                    case "sub":
                        if (($koef == 8) && ($ProcZaposl < 100)){
                            $this->mDoprinosi[$Indx][4]=0-$enot/$uramin*$koef*$ProcZaposl/100;
                        }else{
                            $this->mDoprinosi[$Indx][4]=0-$enot/$uramin*$koef;
                        }
                        break;
                }
                $this->mDoprinosi[$Indx][5]=$aktivno;
                $this->mDoprinosi[$Indx][6]=$R["enotpotrjeno"];
                $this->mDoprinosi[$Indx][7]=$R["enot"];
                
                //izračuna kumulativo doprinosa za določen dan
                if (isset($this->mKolDop[$m][$d]['SkCas'])){
                    $this->mKolDop[$m][$d]['SkCas']= $this->mKolDop[$m][$d]['SkCas']+$this->mDoprinosi[$Indx][4];
                    $this->mKolDop[$m][$d]['dogodek']=true;
                }else{
                    $this->mKolDop[$m][$d]['SkCas']=$this->mDoprinosi[$Indx][4];
                    $this->mKolDop[$m][$d]['dogodek']=true;
                }
                //kumulativa potrjenih doprinosov
                if (isset($this->mKolDop[$m][$d]['SkCasP'])){
                    if ($this->mDoprinosi[$Indx][6]){
                        $this->mKolDop[$m][$d]['SkCasP']= $this->mKolDop[$m][$d]['SkCasP']+$this->mDoprinosi[$Indx][4];
                    }
                }else{
                    if ($this->mDoprinosi[$Indx][6]){
                        $this->mKolDop[$m][$d]['SkCasP']=$this->mDoprinosi[$Indx][4];
                    }
                }
                
                //skombinira oznako dneva (če jih je več)
                if (isset($Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"])){
                    if (isset($this->mKolDop[$m][$d]['OznDan'])){
                        $this->mKolDop[$m][$d]['OznDan']=$this->mKolDop[$m][$d]['OznDan']." ".$Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"];
                    }else{
                        $this->mKolDop[$m][$d]['OznDan']=$Doprinos[intval($R["rubrika"])]["oblikadelaoznaka"];
                    }
                }
                //označi, katere rubrike obstajajo in v primeru koeficienta 0 zapiše kumulativo, sicer pa 1 (obstaja)
                if (isset($this->mKolDop[$m][$d][$aktivno])){
                    if ($koef == 0){     //aktivne rubrike
                        $this->mKolDop[$m][$d][$aktivno]=$this->mDoprinosi[$Indx][4];
                        $this->mKolDop[$m][$d]['dogodek']=true;
                    }else{
                        if ($aktivno==19){
                            $this->mKolDop[$m][$d][$aktivno]=$this->mDoprinosi[$Indx][7];
                            $this->mKolDop[$m][$d]['dogodek']=true;
                        }else{
                            $this->mKolDop[$m][$d][$aktivno]=1;
                            $this->mKolDop[$m][$d]['dogodek']=true;
                        }
                    }
                }else{
                    $this->mKolDop[$m][$d][$aktivno]=1;
                    $this->mKolDop[$m][$d]['dogodek']=true;
                }
                    
                /*
                if (isset($this->mKolDop[$m][$d]['DanStat'])){
                    $this->mKolDop[$m][$d]['DanStat']=$this->mKolDop[$m][$d]['DanStat'];
                }else{
                    $this->mKolDop[$m][$d]['DanStat']=;
                }
                */
            }
        }
        $this->mStDoprinosov=$Indx;
        
        //označi praznike in tip (kat)
        $SQL = "SELECT datum,kat FROM TabPraznik WHERE year(datum)=".$VLetoPregled." ORDER BY datum";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);
            $this->mKolDop[$dan->format('n')][$dan->format('j')]['praznik']=$R["kat"];
        }
        
        //'med posebnimi dnevi za aktualno leto
        $SQL = "SELECT datum FROM TabPraznik WHERE year(datum)=".$VLetoPregled." AND kat =1";
        //'izračuna obvezo
        $indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);
            if ($this->getZaposlen($dan)){
                /*
                $interval1 = $dan->diff($DatumCStart);
                $interval2 = $dan->diff($DatumCEnd);
                
                if (($interval1->invert == 1) && ($interval2->invert == 0)){
                */
                if (($DatumCStart->format('Ymd') <= $dan->format('Ymd')) && ($dan->format('Ymd') <= $DatumCEnd->format('Ymd'))){
                    $indx=$indx+1;
                }
            }
        }
        $this->mObveza=$indx;

        //'preveri, če je porodniška ali bolniška med počitnicami (zaradi zmanjšanja obveze)
        $SQL = "SELECT datum FROM TabPraznik WHERE year(datum)=".$VLetoPregled." AND kat =1";
        //'izračuna korekcijo obveze
        $indx=0;
        $indxDopust=0;
        $indxDelovniDopust=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $dan=new DateTime($R["datum"]);
            $m=$dan->format('n');
            $d=$dan->format('j');
            $danes=new DateTime("now");
            if ($this->getZaposlen($dan)){
                /*
                $interval1 = $dan->diff($DatumCStart);
                $interval2 = $dan->diff($DatumCEnd);
                if (($interval1->invert == 1) && ($interval2->invert == 0)){
                */
                if (($DatumCStart->format('Ymd') <= $dan) && ($dan <= $DatumCEnd->format('Ymd'))){
                    $ddn=intval($danes->format('Ymd'));
                    $dd=intval($dan->format('Ymd'));
                    //$interval3 = $danes->diff($dan);
                    //if ($interval3->invert == 1 or $interval3->days == 0){
                    if ($ddn >= $dd){
                        $indxDelovniDopust=$indxDelovniDopust+1;    //'število prostih dni v letu po koledarju do današnjega dne
                    }
                    if (isset($this->mKolDop[$m][$d]['10'])){    //porodniška
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['11'])){    //nega
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['3'])){ //bolniška
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['4'])){   //bolniška 50%
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['22'])){   //bolniška - nega
                        $indx=$indx+1;
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['2'])){   //Gaber
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['5'])){    //dopust ure
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                    if (isset($this->mKolDop[$m][$d]['6'])){    //dopust
                        //if ($interval3->invert == 1 or $interval3->days == 0){
                        if ($ddn >= $dd){
                            $indxDopust=$indxDopust+1;
                        }
                    }
                        
                }
            }
        }
        //'od obveze odšteje število dni porodniške in bolniške med počitnicami
        $this->mZmanjsanaObveza = $indx;
        $this->mDeloMedPocitnicami = $indxDelovniDopust-$indxDopust;
        $this->mObveza = $this->mObveza - $this->mZmanjsanaObveza - $this->mDeloMedPocitnicami;

        $this->mUcenje=0;
        for ($indx=1;$indx <= $this->mStPog;$indx++){
            //'učitelj,vzgojitelj, pripravnik
//            if (($this->mIdVzgojnoDelo[$indx]==1) || ($this->mIdVzgojnoDelo[$indx]==2) || ($this->mIdVzgojnoDelo[$indx]==19) || ($this->mDoprinasanje)){
            if (($this->mDoprinasanje)){
                $this->mUcenje=1;
            }
        }
        
        $ProcZaposl=$this->getProcZapLetno($VLetoPregled);
        if ($this->mUcenje==1){
            if  ($ProcZaposl < 100){ //'krajši
                $this->mDoprinos=($this->mObveza-$this->mDopust-$this->mDopustStari)*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000];
                if ($this->mDopust+$this->mDopustStari >= $this->mObveza){
                    $this->mDoprinos=0;
                }
            }else{    
                $this->mDoprinos=($this->mObveza-$this->mDopust-$this->mDopustStari)*$DelovniDan[$VLetoPregled-2000];
                if ($this->mDopust+$this->mDopustStari >= $this->mObveza){
                    $this->mDoprinos=0;
                }
            }    
        }else{
            $this->mDoprinos=0;
            $this->mObveza=0;
        }
    }
	
	public function getZaposlen($d){
		//'Ugotovi, če je delavec zaposlen na določen datum.
		//'če ni zaposlen po trenutni pogodbi, pregleda pretekle pogodbe
		/*
		$Zaposlen=false;
		for ($indx=1;$indx <= $this->mStPog;$indx++){
            $danS=$this->mDatumStart[$indx];
            $danE=$this->mDatumEnd[$indx];
            $interval1=$danS->diff($d);
            $interval2=$d->diff($danE);
			if (($interval1->invert == 0) && ($interval2->invert == 0)){
				$Zaposlen=true;
                $this->mAktStPogodbe=$indx;
			}
		}
        return $Zaposlen;
        */
        if (isset($this->mKolDop[$d->format('n')][$d->format('j')]['zaposlen'])){
            if ($this->mKolDop[$d->format('n')][$d->format('j')]['zaposlen']){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
	}
	
	public function getZaposlenZadnjaPog($d){
		//'Ugotovi, če je delavec zaposlen na določen datum.
		//'Če ni zaposlen po trenutni pogodbi, pregleda pretekle pogodbe
		
        $Danes=new DateTime("now");
        /*
        if ($this->getZaposlen($Danes)){
            return true;
        }else{
		    $ZaposlenZadnjaPog=false;
        
			for ($indx=1;$indx <= $this->mStPog;$indx++){
                $danS=$this->mDatumStart[$indx];
                $danE=$this->mDatumEnd[$indx];
                $interval1=$danS->diff($d);
                $interval2=$d->diff($danE);
                
				if (($interval1->invert == 0) && ($interval2->invert == 0)){
					$ZaposlenZadnjaPog=true;
				}
			}
            return $ZaposlenZadnjaPog;
        }
        */
        return $this->getZaposlen($Danes);
	}
	
	public function getKoeficient($d){
		//'Ugotovi, kakšen koeficient ur ima delavec na določen datum.
		//'izračuna uteženo povprečje trenutno veljavnih pogodb
		
		$koef=0;
		$ure=0;
        /*
		for ($indx=1;$indx <= $this->mStPog;$indx++){
            $danS=new DateTime($this->mDatumStart[$indx]->format('Y-m-d'));
            $danE=new DateTime($this->mDatumEnd[$indx]->format('Y-m-d'));
            $interval1=$danS->diff($d);
            $interval2=$d->diff($danE);
            if (($interval1->invert == 0) && ($interval2->invert == 0)){
				$ure=$ure+$this->mUrTeden[$indx];
				$koef=$koef+$this->mKoef[$indx]*$this->mUrTeden[$indx];
			}
		}
        */
        $dan=$d->format('Ymd');
        for ($indx=1;$indx <= $this->mStPog;$indx++){
            $danS=$this->mDatumStart[$indx]->format('Ymd');
            $danE=$this->mDatumEnd[$indx]->format('Ymd');
            if (($danS <= $d) && ($danE >= $d)){
                $ure=$ure+$this->mUrTeden[$indx];
                $koef=$koef+$this->mKoef[$indx]*$this->mUrTeden[$indx];
            }
        }
		if ($ure > 0){
			return $koef/$ure;
		}else{
			return 1;
		}
	}
	
    public function getPrekinjena(){
        //metoda vrne true, če je med aktualnimi pogodbami kakšen dan vrzeli in false, če med začetnim in končnim datumom ni vrzeli
        //gleda med DatumCStart in DatumCEnd
        $prekinjena=false;
        if ($this->mStPog == 0){
            return false;
        }
        if ($this->mStPog == 1){
            return true;
        }else{
            $danSV=new DateTime($this->mDatumStart[1]->format('Y-m-d'));
            $danEV=new DateTime($this->mDatumEnd[1]->format('Y-m-d'));
            
            $dsv=intval($danSV->format('Ymd'));
            $dev=intval($danEV->format('Ymd'));
            //prvi prehod
            for ($i=1;$i <= $this->mStPog;$i++){
                $danS=new DateTime($this->mDatumStart[$i]->format('Y-m-d'));
                $danE=new DateTime($this->mDatumEnd[$i]->format('Y-m-d'));
                //$interval1=$danSV->diff($danS);
                //$interval2=$danS->diff($danEV);
                
                $ds=intval($danS->format('Ymd'));
                $de=intval($danE->format('Ymd'));
                
                //if (($interval1->invert == 0) && ($interval2->invert == 0)){
                if ($dsv <= $ds && $ds <= $dev){
                    //$interval3=$danEV->diff($danE);
                    //if ($interval3->invert == 0){
                    if ($dev <= $de){
                        $danEV=new DateTime($danE->format('Y-m-d'));
                    }                    
                }
                /*
                if (($interval1->invert == 0) && ($interval2->invert == 1 && $interval2->days > 1)){
                    $prekinjena=true;
                }
                */
                $interval4=$danSV->diff($danE);
                //if ($interval1->invert == 1 && ($interval4->invert == 0 or $interval4->days == 1)){
                if ($dsv <= $ds && ($interval4->invert == 0 or $interval4->days == 1)){
                    $danSV=new DateTime($danS->format('Y-m-d'));
                }
                /*
                $interval5=$danE->diff($danSV);
                if ($interval5.invert == 0 && $interval5->days > 1){
                    $prekinjena=true;
                }
                */
            }
            //2. prehod
            for ($i=1;$i <= $this->mStPog;$i++){
                $danS=new DateTime($this->mDatumStart[$i]->format('Y-m-d'));
                $danE=new DateTime($this->mDatumEnd[$i]->format('Y-m-d'));
                $interval1=$danSV->diff($danS);
                $interval2=$danS->diff($danEV);
                if (($interval1->invert == 0) && ($interval2->invert == 0)){
                    $interval3=$danEV->diff($danE);
                    if ($interval3->invert == 0){
                        $danEV=new DateTime($danE->format('Y-m-d'));
                    }                    
                }
                if (($interval1->invert == 0) && ($interval2->invert == 1 && $interval2->days > 1)){
                    $prekinjena=true;
                }
                $interval4=$danSV->diff($danE);
                if ($interval1->invert == 1 && ($interval4->invert == 0 or $interval4->days == 1)){
                    $danSV=new DateTime($danS->format('Y-m-d'));
                }
                $interval5=$danE->diff($danSV);
                if ($interval5->invert == 0 && $interval5->days > 1){
                    $prekinjena=true;
                }
            }
        }
        return $prekinjena;    
    }
    
	public function PodatkiZaposlenega(){
		//'Metoda izpiše podatke o zaposlenem s potrebnim letnim doprinosom

        global $VLevel;		
		if ($this->getSpol() == "M"){
			echo "Ime: <a href='PopraviUcitelja.php?idUcitelj=".$this->getIdUcitelj()."'><b>".$this->getIme()." ".$this->getPriimek()."</b></a><br />";
		} else {
			if ($this->getDekliski() != ""){
				echo "Ime: <a href='PopraviUcitelja.php?idUcitelj=".$this->getIdUcitelj()."'><b>".$this->getIme()." ".$this->getPriimek()."</b></a> (dekliški priimek: ".$this->getDekliski().")<br />";
			}else{
				echo "Ime: <a href='PopraviUcitelja.php?idUcitelj=".$this->getIdUcitelj()."'><b>".$this->getIme()." ".$this->getPriimek()."</b></a><br />";
			}
		}
		echo "Izobrazba: <b>".$this->getIzobrazba()." - ".$this->getIzobOpis()."</b><br />";
		echo "Opravljanje dela: ";
		if ($this->mStPog > 0){
			for ($indx=1;$indx <= $this->mStPog;$indx++){
				if ($indx == 1){
					echo "<b>".$this->mOpisDela[$indx]."</b>";
				}else{
					$enak=0;
					for ($indx1=1;$indx1 <= $indx-1;$indx1++){
						if ($this->mOpisDela[$indx] == $this->mOpisDela[$indx1]){
							$enak=$enak+1;
						}
					}
					if ($enak == 0){
						echo ", <b>".$this->mOpisDela[$indx]."</b>";
					}
				}
			}
		}
		echo "<br />";
		echo "Skupina dela: ";
		if ($this->mStPog > 0) {
			for ($indx=1;$indx <= $this->mStPog;$indx++){
				if ($indx == 1){
					echo "<b>".$this->mSkupinaDela[$indx]."</b>";
				}else{
					$enak=0;
					for ($indx1=1;$indx1 <= $indx-1;$indx1++){
						if ($this->mSkupinaDela[$indx] == $this->mSkupinaDela[$indx1]){
							$enak=$enak+1;
						}
					}
					if ($enak == 0){
						echo ", <b>".$this->mSkupinaDela[$indx]."</b>";
					}
				}
			}
		}
		echo "<br />";
		echo "Delovno mesto: ";
		if ($this->mStPog > 0){
			for ($indx=1;$indx <= $this->mStPog;$indx++){
				if ($indx == 1){
					echo "<b>".$this->mVzgojnoDelo[$indx]."</b>";
				}else{
					$enak=0;
					for ($indx1=1;$indx1 <= $indx-1;$indx1++){
						if ($this->mVzgojnoDelo[$indx] == $this->mVzgojnoDelo[$indx1]){
							$enak=$enak+1;
						}
					}
					if ($enak == 0){
						echo ", <b>".$this->mVzgojnoDelo[$indx]."</b>";
					}
				}
			}
		}
		echo "<br />";
		
		echo "Delovni čas: <br />";
		echo "<table border='1' cellspacing='0'>";
		echo "<tr><th>Del.čas</th><th>Ur/teden</th><th>PON</th><th>TOR</th><th>SRE</th><th>ČET</th><th>PET</th><th>Od</th><th>Do</th><th>Prijava</th><th>Odjava</th><th>Delo</th><th>Opombe</th></tr>";
		for ($indx=1;$indx <= $this->mStPog;$indx++){
			switch ($this->mDelovniCas[$indx]){
				case 0:
					echo "<tr>";
					echo "<td>Polni</td>";
                    break;
				case 1:
					echo "<tr>";
					echo "<td>Krajši</td>";
                    break;
				case 3:
					echo "<tr>";
					echo "<td>Dopolnjevanje</td>";
                    break;
			}
			echo "<td>".$this->mUrTeden[$indx]."</td>";
			echo "<td>".$this->mObremen1[$indx]."</td>";
			echo "<td>".$this->mObremen2[$indx]."</td>";
			echo "<td>".$this->mObremen3[$indx]."</td>";
			echo "<td>".$this->mObremen4[$indx]."</td>";
			echo "<td>".$this->mObremen5[$indx]."</td>";
			echo "<td>".$this->mDatumStart[$indx]->format('d.m.Y')."</td>";
			if ($this->mRazlogDolCas[$indx] != ""){
				echo "<td>".$this->mDatumEnd[$indx]->format('d.m.Y')."</td>";
			}else{
				echo "<td>&nbsp;</td>";
			}
			echo "<td>".$this->mVpisM1[$indx]."</td>";
			echo "<td>".$this->mIzpisM1[$indx]."</td>";
			echo "<td>".$this->mNazivDelMesta[$indx]."</td>";
            echo "<td><textarea cols='20' rows='2'>".$this->mOpombe[$indx]."</textarea></td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "Povprečni % zaposlitve vseh pogodb: <b>".round($this->getProcZapLetno($this->mVLetoPregled),2)."</b><br />";
		if ($VLevel > 1 ) {
			echo "<a href='DodajPogodbo.php?id=5&idUcitelj=".$this->getIdUcitelj()."'>Poglej pogodbe</a><br />";
		}
		echo "<br />";
        $zacDela=new DateTime($this->mZacetekDela->format('Y-m-d'));
		echo "Datum začetka dela na šoli: <b>".$zacDela->format('d.m.Y')."</b><br />";
		if ($this->getPedIzobr() != "" ) {
			echo "Datum pridobitve pedagoško-andragoške izobrazbe: ".$this->getPedIzobr()."<br />";
		}
		if ($this->getStrokIzpit() != "" ) {
			echo "Datum strokovnega izpita: ".$this->getStrokIzpit()."<br />";
		}
		if ($this->getMentor() != "" ) {
			echo "Datum pridobitve naziva Mentor: ".$this->getMentor()."<br />";
		}
		if ($this->getSvetovalec() != "" ) {
			echo "Datum pridobitve naziva Svetovalec: ".$this->getSvetovalec()."<br />";
		}
		if ($this->getSvetnik() != "" ) {
			echo "Datum pridobitve naziva Svetnik: ".$this->getSvetnik()."<br />";
		}
		echo "Delovna doba: <b>".$this->getDelDobaLet()."</b>";
		switch ($this->getDelDobaLet() % 100){
			case 1:
				echo " leto<br />";
                break;
			case 2:
				echo " leti<br />";
                break;
			case 3:
				echo " leta<br />";
                break;
            case 4:
                echo " leta<br />";
                break;
			default:
				echo " let<br />";
		}
		$SkupniDopust = $this->getDopustNaDD()+$this->getDopustNaIz()+$this->getDopustNaOt()+$this->getDopustNaSta()+$this->getDopustNaInv()+$this->getDopustNaVod()+$this->getDopustVzgoja()+$this->getDopustDelInv()+$this->getDopustPP()+$this->getDopustDrugo();
        if ($SkupniDopust != $this->getDopust()){
            echo "<a href='PopraviDopust.php?idUcitelj=".$this->getIdUcitelj()."&leto=".$this->getLetoPregled()."&id=1&kam=0'><b>Dopust</b></a>: <br />Na delovno dobo:<b> " . $this->getDopustNaDD() . "</b>, na vzgojno delo:<b> " . $this->getDopustVzgoja() . "</b>, na izobrazbo:<b> " . $this->getDopustNaIz() . "</b>, na otroke: <b>" . $this->getDopustNaOt() . "</b>, na starost: <b>" . $this->getDopustNaSta() . "</b>, na invalidnost: <b>" . $this->getDopustNaInv() . "</b>, na vodenje: <b>" . $this->getDopustNaVod() . "</b>, na delovno invalidnost: <b>" . $this->getDopustDelInv() . "</b>, na prilagojen program: <b>" . $this->getDopustPP() . "</b>, drugo: <b>" . $this->getDopustDrugo() . "</b>, skupaj:<b> " . $this->getDopust() . "</b> ($SkupniDopust) dni<br />";
        }else{
		    echo "<a href='PopraviDopust.php?idUcitelj=".$this->getIdUcitelj()."&leto=".$this->getLetoPregled()."&id=1&kam=0'><b>Dopust</b></a>: <br />Na delovno dobo:<b> " . $this->getDopustNaDD() . "</b>, na vzgojno delo:<b> " . $this->getDopustVzgoja() . "</b>, na izobrazbo:<b> " . $this->getDopustNaIz() . "</b>, na otroke: <b>" . $this->getDopustNaOt() . "</b>, na starost: <b>" . $this->getDopustNaSta() . "</b>, na invalidnost: <b>" . $this->getDopustNaInv() . "</b>, na vodenje: <b>" . $this->getDopustNaVod() . "</b>, na delovno invalidnost: <b>" . $this->getDopustDelInv() . "</b>, na prilagojen program: <b>" . $this->getDopustPP() . "</b>, drugo: <b>" . $this->getDopustDrugo() . "</b>, skupaj:<b> " . $SkupniDopust . "</b> dni<br />";
        }
		
		echo "Stari dopust: <b>" . $this->getDopustStari() . "</b><br />";
		if ($this->getDelez() >= 0 ) {
			echo "<font color='red'>Zaposlen/-a za določen čas. Ustrezen delež dopusta: <b>".$this->getDopust()."</b> dni</font><br>";
		}
		
		if ($this->mUcenje == 1) {
			echo "Število prostih dni: <b>" . $this->getObveza() . "</b> dni <br />";
			if ($this->getZmanjsanaObveza() > 0 ) {
				echo "Zmanjšana obveza (porodniška, nega otroka, bolniška med počitnicami): <b>" . $this->getZmanjsanaObveza() . "</b> dni <br />";
			}
			if ($this->getDeloMedPocitnicami() > 0 ) {
				echo "Zmanjšana obveza (delo med počitnicami): <b>" . $this->getDeloMedPocitnicami() . "</b> dni <br />";
			}
			echo "Potrebne dodatne ure:<b> " . round($this->getDoprinos(),1) . "</b> (DU)<br /><br />";
		}
	}
	
	public function Sistemizacija($VLeto){
		//'Metoda izpi?e sistemizacijo delavca za dolo?eno ?olsko leto
		global $VLevel,$EvidencaPrisotnosti,$link,$VecSol;
        
        $ucitelj=$this->getIdUcitelj();
        /*
		$SQL = "SELECT tabucenje.*, tabpredmeti.Opis,tabrazdat.*,tabpredmeti.Oznaka AS poznaka,tabucenje.Id AS uid FROM ";
		$SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) ";
		$SQL = $SQL . "LEFT JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
		$SQL = $SQL . "WHERE iducitelj=" . $this->getIdUcitelj() ." AND tabucenje.leto=".$VLeto;
		$SQL = $SQL ." ORDER BY  tabpredmeti.Oznaka,tabucenje.Razred,tabucenje.paralelka";

		echo "<table border=1 cellspacing=0>";
		if ($VLevel < 2 ) {
			echo "<tr bgcolor=lightcyan><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th></tr>";
		}else{
			echo "<tr bgcolor=lightcyan><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th><th>Briši</th><th>Popravi</th></tr>";
		}

        $SkupajUre=0;
        $BZdruzevanje=false;
        $BZdruzevanje1=false;

        for ($Indx=0;$Indx <= 12;$Indx++){
            $izbirni[$Indx]=0;
            $Nivoji[1][$Indx]=0;
            $Nivoji[2][$Indx]=0;
            $Nivoji[3][$Indx]=0;
            $Nivoji[4][$Indx]=0;
            $Nivoji[5][$Indx]=0;
            $Nivoji[6][$Indx]=0;
        }

        $StIzbirni=0;

		$ColorChange1=true;
		$Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Indx=$Indx+1;
			if ($ColorChange1 ) {
				echo "<tr bgcolor=lightyellow><td>" . $R["poznaka"] ." - " . $R["Opis"] ."</td><td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td><td align='right'>" . $R["Planirano"] ."</td>";
			}else{
				echo "<tr bgcolor=#FFFFCC><td>" . $R["poznaka"] ." - " . $R["Opis"] ."</td><td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td><td align='right'>" . $R["Planirano"] ."</td>";
			}
			$ColorChange1 = !$ColorChange1;
			switch ($R["Zdruzeno"]){
			    case 1:
				    echo "<td>Združevanje/nivoji</td>";
				    $BZdruzevanje= !$BZdruzevanje;
				    if ($BZdruzevanje) {
					    $SkupajUre=$SkupajUre-$R["Planirano"];
				    }
                    break;
			    case 2:
				    echo "<td>Izbirne vsebine</td>";
                    for ($StIzbirni=0;$StIzbirni <= 12;$StIzbirni++){
					    if ($izbirni[$StIzbirni] == $R["Predmet"]) {
                            $SkupajUre=$SkupajUre-$R["Planirano"];
						    break;
                        }
				    }
				    if ($StIzbirni == 12 ) {
                        for ($StIzbirni=0;$StIzbirni <= 12;$StIzbirni++){
                            if ($izbirni[$StIzbirni] == 0) {
                                $izbirni[$StIzbirni]=$R["Predmet"];
                                break;
                            }
                        }
				    }
                    break;
			    case 0:
				    echo "<td>&nbsp;</td>";
                    break;
			    case 3:
				    echo "<td>&nbsp;</td>";
                    break;
			    case 7:
				    echo "<td>Drugi učitelj</td>";
                    break;
                default: //4,5,6
                    if ($R["Realizirano"] > 0 ) {
                        echo "<td>".($R["Zdruzeno"]-3).". nivo, skupina ".$R["Realizirano"]."</td>";
                    }else{
                        echo "<td>".($R["Zdruzeno"]-3).". nivo</td>";
                    }            
                    $StNivoji[$R["Zdruzeno"]]=0;
                    while ($StNivoji[$R["Zdruzeno"]] < 12 ) {
                        if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]] == $R["Predmet"].$R["Realizirano"] ) {
                            $SkupajUre=$SkupajUre-$R["Planirano"];
                            break;
                        }
                        $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                    }
                    if ($StNivoji[$R["Zdruzeno"]]==12 ) {
                        $StNivoji[$R["Zdruzeno"]]=0;
                        while ($StNivoji[$R["Zdruzeno"]] < 12){
                            if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]] == 0 ) {
                                $Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]=$R["Predmet"].$R["Realizirano"];
                                break;
                            }
                            $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                        }
                    }
			}
			echo "<td>".$R["Realizirano"]."</td>";

			if ($VLevel > 1 ) {
				echo "<td align=center><a href='BrisiUcenje.php?id=".$R["uid"]."'>B</a></td>";
				echo "<td align=center><a href='PopraviUcenje.php?id=".$R["uid"]."'>P</a></td>";
			}
			
			echo "</tr>";
			$SkupajUre=$SkupajUre+$R["Planirano"];
        }
		echo "<tr bgcolor=lightgrey><td>Skupaj ur</td><td></td><td align='right'><b>" . $SkupajUre . "</b></td><td>&nbsp;</td></tr>";
		echo "</table><br>";
        */
        
        /* nov izpis sistemizacije - začetek */
        $SkupajUre=0;
        $BZdruzevanje=false;
        $BZdruzevanje1=false;
        $StEnakih=30;

        for ($Indx=0;$Indx <= $StEnakih;$Indx++){
            $izbirni[$Indx]=0;
            $Nivoji[1][$Indx]=0;
            $Nivoji[2][$Indx]=0;
            $Nivoji[3][$Indx]=0;
            $Nivoji[4][$Indx]=0;
            $Nivoji[5][$Indx]=0;
            $Nivoji[6][$Indx]=0;
        }

        $StIzbirni=0;
        echo "<table border='1' cellspacing='0'>";
        if ($VLevel < 2) {
            echo "<tr bgcolor='lightcyan'><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th></tr>";
        }else{
            echo "<tr bgcolor='lightcyan'><th>Predmet</th><th>Razred</th><th>Plan ur</th><th>Posebnosti</th><th>Skupina</th><th>Briši</th><th>Popravi</th></tr>";
        }

        $ColorChange1=true;
        $Indx=1;
        $SQL = "SELECT tabucenje.*, tabpredmeti.Oznaka, tabpredmeti.Opis FROM tabpredmeti ";
        $SQL .= "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet ";
        $SQL .= "WHERE iducitelj=" . $this->getIdUcitelj() ." AND leto=".$VLeto;
        $SQL .= " ORDER BY  tabpredmeti.Oznaka,tabucenje.Razred,tabucenje.Paralelka,tabucenje.osemdevet";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($ColorChange1 ){
                echo "<tr bgcolor='lightyellow'><td>" . $R["Oznaka"] ." - " . $R["Opis"] ."</td>";
                if ($VecSol > 0){
                    if (strlen($R["Paralelka"]) > 0){
                        echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"];
                        //če je vezano na razred
                        $SQL = "SELECT solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.id=".$R["idRazred"];
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo " - ".$R1["solakratko"];
                        }
                    }else{
                        //če je vezano na skupino razredov ali šolo
                        $VIdSola=intval($R["Razred"]/10+1);
                        $razred=$R["Razred"] % 10;
                        $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo "<td align='right'>" . $razred . ". ";
                            echo " - ".$R1["solakratko"];
                        }
                    }
                    echo "</td>";
                }else{
                    echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td>";
                }
                echo "<td align='right'>" . $R["Planirano"] ."</td>";
            }else{
                echo "<tr bgcolor=#FFFFCC><td>" . $R["Oznaka"] ." - " . $R["Opis"] ."</td>";
                if ($VecSol > 0){
                    if (strlen($R["Paralelka"]) > 0){
                        echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"];
                        //če je vezano na razred
                        $SQL = "SELECT solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.id=".$R["idRazred"];
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo " - ".$R1["solakratko"];
                        }
                    }else{
                        //če je vezano na skupino razredov ali šolo
                        $VIdSola=intval($R["Razred"]/10+1);
                        $razred=$R["Razred"] % 10;
                        $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo "<td align='right'>" . $razred . ". ";
                            echo " - ".$R1["solakratko"];
                        }
                    }
                    echo "</td>";
                }else{
                    echo "<td align='right'>" . $R["Razred"] . ". " . $R["Paralelka"] . "</td>";
                }
                echo "<td align='right'>" . $R["Planirano"] ."</td>";
            }
            $ColorChange1=!$ColorChange1;
            switch ($R["Zdruzeno"]){
                case 1:
                    echo "<td>Združevanje/nivoji</td>";
                    $BZdruzevanje= !$BZdruzevanje;
                    if ($BZdruzevanje){
                        $SkupajUre=$SkupajUre-$R["Planirano"];
                     }
                     break;
                case 2;
                    echo "<td>Izbirne vsebine</td>";
                    $StIzbirni=0;
                    while ($StIzbirni < $StEnakih){
                        if ($izbirni[$StIzbirni]==$R["Predmet"]."_".$R["Realizirano"] ){
                            $SkupajUre=$SkupajUre-$R["Planirano"];
                            break;
                        }
                        $StIzbirni=$StIzbirni+1;
                    }
                    if ($StIzbirni==$StEnakih){
                        $StIzbirni=0;
                        while ($StIzbirni < $StEnakih){
                            if ($izbirni[$StIzbirni]==0 ){
                                $izbirni[$StIzbirni]=$R["Predmet"]."_".$R["Realizirano"];
                                break;
                            }
                            $StIzbirni=$StIzbirni+1;
                        }
                    }
                    break;
                case 4:
                case 5:
                case 6:
                    if ($R["Realizirano"] > 0 ){
                        echo "<td>".($R["Zdruzeno"]-3).". nivo, skupina ".$R["Realizirano"]."</td>";
                    }else{
                        echo "<td>".($R["Zdruzeno"]-3).". nivo</td>";
                    }            
                    $StNivoji[$R["Zdruzeno"]]=0;
                    while ($StNivoji[$R["Zdruzeno"]] < $StEnakih ){
                        if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==$R["Predmet"].$R["Realizirano"] ){
                            $SkupajUre=$SkupajUre-$R["Planirano"];
                            break;
                        }
                        $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                    }
                    if ($StNivoji[$R["Zdruzeno"]]==$StEnakih ){
                        $StNivoji[$R["Zdruzeno"]]=0;
                        while ($StNivoji[$R["Zdruzeno"]] < $StEnakih ){
                            if ($Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]==0 ){
                                $Nivoji[$R["Zdruzeno"]][$StNivoji[$R["Zdruzeno"]]]=$R["Predmet"].$R["Realizirano"];
                                break;
                            }
                            $StNivoji[$R["Zdruzeno"]]=$StNivoji[$R["Zdruzeno"]]+1;
                        }
                    }
                    break;
                case 0:
                    echo "<td>&nbsp;</td>";
                    break;
                case 3;
                    echo "<td>&nbsp;</td>";
                    break;
                case 7:
                    echo "<td>Drugi učitelj</td>";
            }
                
            echo "<td>".$R["Realizirano"]."</td>";   //skupina

            if ($VLevel > 1 ){
                echo "<td align='center'><a href='Predmeti.php?id=2&id1=".$R["Id"]."'>B</a></td>";
                echo "<td align='center'><a href='Predmeti.php?id=3&id1=".$R["Id"]."'>P</a></td>";
            }
                
            echo "</tr>";
            $SkupajUre=$SkupajUre+$R["Planirano"];
            $Indx=$Indx+1;
        }
        echo "<tr bgcolor='lightgrey'><td>Skupaj ur</td><td></td><td align='right'><b>" . $SkupajUre . "</b></td><td>&nbsp;</td></tr>";
        echo "</table><br />";
        
        /* nov izpis sistemizacije - konec */
        
//		if ($EvidencaPrisotnosti == 1 ) {
			echo "<br>";
			echo "Sistemizacija del in nalog:<br>";
			//$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$ucitelj;
			
            //$result = mysqli_query($link,$SQL);
            //if ($R = mysqli_fetch_array($result)){
            for ($i=1;$i <= $this->mStPog;$i++){
				//if ($R["Sistemizacija"] != "" ) {
                if (isset($this->mSistemizacija[$i])){
                    if ($this->mSistemizacija[$i]!=""){
					    //$SQL = "SELECT * FROM TabSistemizacija WHERE idSistemizacija IN (".$R["Sistemizacija"].") ORDER BY idSistemizacija";
                        $SQL = "SELECT * FROM TabSistemizacija WHERE idSistemizacija IN (".$this->mSistemizacija[$i].") ORDER BY idSistemizacija";
					    
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
						    echo "<a href='".$R["Povezava"]."' target='_blank'>".$R["Opis"]."</a><br>";
					    }
                    }
				}
            }
			//} 
			echo "<br>";
//		}
	}
	
	public function IzpisIzobrazevanj($VLeto){
	//'izpis izobra?evanj u?itelja za dolo?eno leto
        global $link;
        
		echo "<h2>Spisek izobraževanj</h2>";
		echo "<table border=1 cellspacing=0>";
		echo "<tr bgcolor='lightcyan'><th>Leto</th><th>Ime</th><th>Izobraževanje</th><th>Izvajalec</th><th>Naslov izv.</th><th>Kraj</th><th>Datum od</th><th>Datum do</th><th>Trajanje</th><th>Točke</th><th>Kotizacija EUR</th><th>Ostali<br>stroški EUR</th><th>Popravi/<br>vpiši poročilo</th><th>Briši</th><th>Poglej</th><th>Odobreno</th></tr>";
		$SQL = "SELECT tabizobrazevanje.*,tabucitelji.*,tabizobrazevanje.Naslov AS inaslov,tabizobrazevanje.Kraj AS ikraj,tabizobrazevanje.Id AS iid FROM ";
		$SQL = $SQL."tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.IdUcitelj=tabucitelji.IdUcitelj ";
		$SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto." AND tabucitelji.idUcitelj=".$this->getIdUcitelj();
		$SQL = $SQL." ORDER BY priimek,ime";

		$Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $Indx = $Indx+1;
			switch ($R["porocilo"]){
				case "":
					echo "<tr bgcolor='lightyellow'>";
                    break;
				case "ODPADLO":
					echo "<tr bgcolor='lightsalmon'>";
                    break;
				default:
					echo "<tr bgcolor='lightgreen'>";
			}
			echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
			echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			echo "<td>".$R["Izobrazevanje"]."</td>";
			echo "<td>".$R["Izvajalec"]."</td>";
			echo "<td>".$R["inaslov"]."</td>";
			echo "<td>".$R["ikraj"]."</td>";
			echo "<td>".$R["DatumOd"]."</td>";
			echo "<td>".$R["DatumDo"]."</td>";
			echo "<td>".$R["Trajanje"]."</td>";
			echo "<td>".$R["Tocke"]."</td>";
			echo "<td>".$R["Kotizacija"]."</td>";
			echo "<td>".$R["OstStroski"]."</td>";
//'				echo "<td>"&R("Porocilo")&"</td>"
			echo "<td><a href='VnosIzobrazevanje.php?id=2&popravi=".$R["iid"]."&SolskoLeto=".$VLeto."'>Popravi</a></td>";
			echo "<td><a href='VnosIzobrazevanje.php?id=3&brisi=".$R["iid"]."&SolskoLeto=".$VLeto."'>Briši</a></td>";
			echo "<td><a href='VnosIzobrazevanje.php?id=5&poglej=".$R["iid"]."&SolskoLeto=".$VLeto."'>Poglej</a></td>";
			if ($R["priporocam"] ) {
				echo "<td><input name='iz_".$Indx."' type='hidden' value='".$R["iid"]."'><input name='odobr_".$Indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='iz_".$Indx."' type='hidden' value='".$R["iid"]."'><input name='odobr_".$Indx."' type='checkbox'></td>";
			}
			echo "</tr>";
    }
		echo "</table>";
	}
	
	public function IzpisUrnikaUcitelja($VLeto){
		//'izpis urnika po uciteljih - 2
        global $link;
        global $Danes;
		
		$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		//'echo "<br>" & SQL & "<br>"
		$Indx1=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			$VUcitelji[$Indx1][0] = $R["iducitelj"];
			$VUcitelji[$Indx1][1] = $R["priimek"];
			$VUcitelji[$Indx1][2] = $R["ime"];
            $Indx1=$Indx1+1;
		}
		$StUciteljev=$Indx1-1;

		$SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
		
		$Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			$VPredmeti[$Indx][0] = $R["id"];
			$VPredmeti[$Indx][1] = $R["oznaka"];
			$VPredmeti[$Indx][2] = $R["opis"];
			$VPredmeti[$Indx][3] = $R["prioriteta"];
			$Indx=$Indx+1;
		}
		$StPredmetov=$Indx-1;
		
		$SQL = "SELECT idprostor,stevilka,oznaka,opis FROM tabprostor  ORDER BY IdProstor";
		
		$Indx=0;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			$VProstor[$Indx][0] = $R["idprostor"];
			$VProstor[$Indx][1] = $R["stevilka"];
			$VProstor[$Indx][2] = $R["oznaka"];
			$VProstor[$Indx][3] = $R["opis"];
			$Indx=$Indx+1;
		}
		$StProstorov=$Indx-1;
        
        $danurnik=intval($Danes->format('Ymd'));
        
        $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM ((taburnik "; 
		$SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) ";
		$SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
		$SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor ";
		$SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od <= ".$danurnik." AND do >= ".$danurnik." AND tabucitelji.IdUcitelj=".$this->getIdUcitelj()." ORDER BY taburnik.DanVTednu,taburnik.Ura";

		for ($Indx2=0;$Indx2 <= 150;$Indx2++){
			$Obremenitev[$Indx2]=0;
			for ($Indx=0;$Indx <= 5;$Indx++){
				for ($Indx0=0;$Indx0 <= 12;$Indx0++){
					$UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
				}
			}
		}

		$Indx=0;
		//$IzbraniUcitelj=$ucitelj;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			$IzbraniUcitelj=$StUciteljev+1;
			for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
				if ($this->getIdUcitelj()==$VUcitelji[$Indx2][0] ) {
					$IzbraniUcitelj=$Indx2;
				}
			}
			switch ($R["nivo"]){
				case 1: //,2,3
					$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                    break;
                case 2: 
                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                    break;
                case 3: 
                    $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                    break;
				default:
					$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
			}
			$Indx=$Indx+1;
        }

        //izrečuna obremenitev - sešteje ure
		for ($Indx2=0;$Indx2 <= 150;$Indx2++){
			for ($Indx=0;$Indx <= 5;$Indx++){
				for ($Indx0=0;$Indx0 <= 12;$Indx0++){
					if ($UrnikUcitelj[$Indx2][$Indx][$Indx0] != "" ) {
						$Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
					}
				}
			}
		}

		echo "<br>Urnik učitelja:<br>";
		echo "<table border=1 cellspacing=0 bgcolor='lightyellow'>";
        
		for ($Indx=0;$Indx <= 150;$Indx++){
			if ($Obremenitev[$Indx] > 0 ) {
				echo "<tr bgcolor='cyan'>";
				echo "<td>".$Obremenitev[$Indx]."</td>";
				for ($Indx2=1;$Indx2 <= 5;$Indx2++){
					echo "<td><b>".Int2Dan($Indx2)."</b></td>";
				}
				echo "</tr>";
				for ($Indx2=0;$Indx2 <= 12;$Indx2++){
					echo "<tr bgcolor='lightyellow'>";
					echo "<td>".$Indx2."</td>";


					for ($Indx1=1;$Indx1 <= 5;$Indx1++){
						if ($UrnikUcitelj[$Indx][$Indx1][$Indx2] != "" ) {
							echo "<td>";
							echo "<table class='hide'>";
							echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
							echo "</table>";
							echo "</td>";
						}else{
							echo "<td>&nbsp;</td>";
						}
					}
					echo "</tr>";
				}
			}
		}

		echo "</table><br>";
	}
	
	public function KomentarRavnatelja(){
		//'Metoda izpi?e komentar ravnatelja v izpisu podatkov delavca
        global $VLevel,$VDelo;
		echo "Komentar ravnatelja<br>";
		echo "<form accept-charset='utf-8' name='Koment' method=post action='VpisKomentarja.php'>";
		echo "<textarea name=komentar cols='60' rows='10'>" . $this->getKomentar() . "</textarea><br>";
		if ((($VLevel > 1) && ($VDelo == 4)) || ($VLevel == 3) ) {
			echo "<input name='submit' type='submit' value='Pošlji'>";
		}
		echo "</form>";
	}
	
	public function ResetPrisotnost(){
		for ($i1=0;$i1 <= 12;$i1++){
			for ($Indx=1;$Indx <= 30;$Indx++){
				$this->mCountDay[$i1][$Indx]=0;
			}
		}
		$this->mRealiziranDoprinos=0;
		$this->mPotrjenRealiziranDoprinos=0;
	}
	
	public function IzracunPrisotnosti($VLetoPregled){
		//'Metoda izračuna dnevne ure, doprinose in odsotnosti za delavca
		//'Metoda se kliče pred klicem izpisa letnega koledarja

		//'ProcZaposl=$this->getUrTeden/40*100
        
        $DanasnjiDan= new DateTime("now");
		$ActualYear=$DanasnjiDan->format('Y');
		$Delavec=$this->getIdUcitelj();

		$this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mKoriscenDopust;

		if (($VLetoPregled) % 4 == 0 ) {
			$MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
		}else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        for ($i1=0;$i1 <= 12;$i1++){
            for ($Indx=1;$Indx <= 30;$Indx++){
                $this->mCountDay[$i1][$Indx]=0;
            }
        }

		$this->TotalDoprinos=0;
		$this->PotrjenTotalDoprinos=0;
		$this->mRealiziranDoprinos=$this->TotalDoprinos;
		$this->mPotrjenRealiziranDoprinos=$this->PotrjenTotalDoprinos;
		$this->mMesecneUre[0][0]=0; // 	'0-delovne ure
		$this->mMesecneUre[0][1]=0;	//'1-delovni dnevi
		$this->mMesecneUre[0][2]=0;	//'2-dnevni doprinos
		$this->mMesecneUre[0][3]=0;	//'3-potrjen dnevni doprinos
		$this->mMesecneUre[0][4]=0;	//'4-delovni dnevi s stroški
		for ($Indx=1;$Indx <= 12;$Indx++){
			$this->IzracunPrisotnostiMesec($VLetoPregled,$Indx,1);
		}
		//'mRealiziranDoprinos=TotalDoprinos
		//'mPotrjenRealiziranDoprinos=PotrjenTotalDoprinos
	}

    public function IzracunPrisotnostiMesec($VLetoPregled,$Indx,$nacin){
    //'izračuna mesečno prisotnost za delavca
    //'nacin: 1 za trenutni datum, 2 za zadnji dan v mesecu
        global $DodatnihRubrik;
        $TotalDoprinos=$this->TotalDoprinos;
        $PotrjenTotalDoprinos=$this->PotrjenTotalDoprinos;
        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        //'ProcZaposl=$this->getUrTeden/40*100
        $DanasnjiDan=new DateTime("now");
        $ActualYear=$DanasnjiDan->format('Y');
        if ($nacin == 2){
            $DanasnjiDan=new DateTime($VLetoPregled."-".$Indx."-".$MesecDni[$Indx]);
            $this->mMesecneUre[0][0]=0;
            $this->mMesecneUre[0][1]=0;
            $this->mMesecneUre[0][2]=0;
            $this->mMesecneUre[0][3]=0;
            $this->mMesecneUre[0][4]=0;
            for ($i1=1;$i1 <= 30;$i1++){
                $this->mCountDay[0][$i1]=0;
                $this->mCountDay[$Indx][$i1]=0;
            }
        }
        $Delavec=$this->getIdUcitelj();

        $this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mKoriscenDopust;
         
        $this->mMesecneUre[$Indx][0]=0;
        $this->mMesecneUre[$Indx][1]=0;
        $this->mMesecneUre[$Indx][2]=0;
        $this->mMesecneUre[$Indx][3]=0;
        $this->mMesecneUre[$Indx][4]=0;
        
        for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
            $Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
            $DnevneUre=0;
            $DnevniDoprinos=0;
            $PotrjenDnevniDoprinos=0;
            $PotrjeneDnevneUre=0;
            $PreveriDoprinose=$this->getCheckDoprinosi($Datum);
            $PreveriPotrjeneDoprinose=$this->getCheckPotrjeniDoprinosi($Datum);
            $PreveriBolnisko=$this->getCheckBolniska($Datum);
            $PreveriBolnisko50=$this->getCheckBolniska50($Datum);
            $PreveriBolniskoNega=$this->getCheckBolniskaNega($Datum);
            $PreveriBolniskoProc=$this->getCheckBolniskaProc($Datum);
            $PreveriBolniskoProcUre=$this->getCheckBolniskaProcUre($Datum);
            $PreveriDogodek=$this->getCheckDogodek($Datum);
            $PreveriDelCas=$this->getCheckDelCas($Datum);
            $PreveriObremenitev=floatval($this->getCheckObremenitev($Datum));
            $PreveriKoeficient=$this->getKoeficient($Datum);
            $ProcZaposl=$this->getProcentZaposlitve($Datum);
            switch ($Datum->format('w')+1){
                case 1: //,7    '1-nedelja, 7-sobota
                case 7: // 7-sobota
                    $PreveriPraznik=$this->CheckPraznik($Datum);
                    switch ($PreveriPraznik){
                        case 3: // 'delovna sobota
                            if ($this->getZaposlen($Datum) ) {
                                $this->mMesecneUre[0][1]=$this->mMesecneUre[0][1]+1;
                                $this->mMesecneUre[$Indx][1]=$this->mMesecneUre[$Indx][1]+1;
                                $this->mMesecneUre[$Indx][4]=$this->mMesecneUre[$Indx][4]+1;
                                $this->mMesecneUre[0][4]=$this->mMesecneUre[0][4]+1;
                            }
                            if ($PreveriDogodek ) {
                                for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
                                    if ($i1 != 17){
                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                            $this->mCountDay[$Indx][$i1]=$this->mCountDay[$Indx][$i1]+ 1;   //zazna dnevno rubriko
                                            $this->mCountDay[0][$i1]=$this->mCountDay[0][$i1]+1;   //kumulativa dnevnih rubrik
                                        }
                                    }
                                }
                            }else{
                                $IzpisUr=true;
                            }

                            if ($PreveriBolnisko or $PreveriBolniskoNega ) {
                                $DnevniDoprinos=$PreveriDoprinose;
                                
                                $DnevneUre=$PreveriDoprinose;
                                $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                $PotrjeneDnevneUre=$PreveriPotrjeneDoprinose;
                                
                                $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                
                                $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                            }else{
                                if ($PreveriBolnisko50 ) {
                                    $DnevniDoprinos=$PreveriKoeficient*4-4+$PreveriDoprinose;
                                    $DnevneUre=$PreveriKoeficient*4+$PreveriDoprinose;
                                    $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                    $PotrjenDnevniDoprinos=$PreveriKoeficient*4-4+$PreveriPotrjeneDoprinose;
                                    $PotrjeneDnevneUre=$PreveriKoeficient*4+$PreveriPotrjeneDoprinose;
                                    
                                    $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                    $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                    $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                    
                                    $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                    $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                    $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                }else{
                                    if ($PreveriBolniskoProc ) {
                                        if ($PreveriBolniskoProcUre > 0 ) {
                                            $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))-$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriDoprinose;
                                            $DnevneUre=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriDoprinose;
                                            $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                            $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))-$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriPotrjeneDoprinose;
                                            $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriPotrjeneDoprinose;

                                            $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                            $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                            $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                            
                                            $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                            $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                            $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                        }
                                    }else{
                                        $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriDoprinose;
                                        /*
                                        $interval = $Datum->diff($DanasnjiDan);
                                        if ($interval->days >= 0) {
                                        */
                                        if ($Datum->format('Ymd') <= $DanasnjiDan->format('Ymd')) {
                                            $DnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriDoprinose;
                                        }else{
                                            $DnevneUre=$PreveriDoprinose;
                                        }
                                        
                                        $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                        $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                        $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                        
                                        $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                        $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                        $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                        
                                        $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                        $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                        $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                    }
                                }
                            }
                            break;
                        default:    //'običajen prost vikend
                            if ($PreveriDogodek ) {
                                for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
                                    if ($i1 == 7 or $i1 == 13){
                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                            $this->mCountDay[$Indx][$i1]=$this->mCountDay[$Indx][$i1]+ 1;   //zazna dnevno rubriko
                                            $this->mCountDay[0][$i1]=$this->mCountDay[0][$i1]+1;   //kumulativa dnevnih rubrik
                                        }
                                    }
                                }
                            }else{
                                $IzpisUr=true;
                            }

                            $DnevniDoprinos=$PreveriDoprinose;
                            $DnevneUre=$DnevniDoprinos;
                            $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                            $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                            $PotrjeneDnevneUre=$PotrjenDnevniDoprinos;
                            
                            $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                            $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                            $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                            $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                            $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                            $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                            $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                            
                            $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                            $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                            $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                    }
                    break;
                default: //'delovnik
                    $PreveriPraznik=$this->CheckPraznik($Datum);
                    switch ($PreveriPraznik){
                        case 4:    //'nadomeščan dan - poseben prost dan
                            $DnevniDoprinos=$PreveriDoprinose;
                            $DnevneUre=$DnevniDoprinos;
                            $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                            $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                            $PotrjeneDnevneUre=$PotrjenDnevniDoprinos;
                            
                            $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                            $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                            $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                            $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;

                            $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                            $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                            $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                            
                            $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                            $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                            $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                            break;
                        case 1:    //'praznik
                            if ($PreveriDogodek ) {
                                //'če je na ta dan kakšen vpis (bolniške)
                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][3])){
                                    $this->mCountDay[$Indx][3]=$this->mCountDay[$Indx][3]+1;   //zazna dnevno rubriko
                                    $this->mCountDay[0][3]=$this->mCountDay[0][3]+1;   //kumulativa dnevnih rubrik
                                }
                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][4])){
                                    $this->mCountDay[$Indx][4]=$this->mCountDay[$Indx][4]+1;   //zazna dnevno rubriko
                                    $this->mCountDay[0][4]=$this->mCountDay[0][4]+1;   //kumulativa dnevnih rubrik
                                }
                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][19])){
                                    $this->mCountDay[$Indx][19]=$this->mCountDay[$Indx][19]+1;   //zazna dnevno rubriko
                                    $this->mCountDay[0][19]=$this->mCountDay[0][19]+1;   //kumulativa dnevnih rubrik
                                }

                                if ($PreveriBolnisko or $PreveriBolniskoNega) {
                                    $DnevniDoprinos=$PreveriDoprinose;
                                    
                                    $DnevneUre=$PreveriDoprinose;
                                    $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                    $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                    $PotrjeneDnevneUre=$PreveriPotrjeneDoprinose;
                                    
                                    $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                    $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                    $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                    
                                    $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                    $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                    $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                }else{
                                    if ($PreveriBolnisko50 ) {
                                        if ($PreveriDelCas == 1 ) {
                                            $DnevniDoprinos=$PreveriDoprinose;
                                            $DnevneUre=$PreveriDoprinose;
                                            $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                            $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                            $PotrjeneDnevneUre=$PreveriPotrjeneDoprinose;
                                        }
                                        
                                        $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                        $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                        $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                        
                                        $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                        $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                        $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                    }else{
                                        if ($PreveriBolniskoProc ) {
                                            if ($PreveriBolniskoProcUre > 0 ) {
                                                if ($PreveriDelCas == 1 ) {
                                                    $DnevniDoprinos=$PreveriDoprinose;
                                                    $DnevneUre=$PreveriDoprinose;
                                                    $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                                    $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                                    $PotrjeneDnevneUre=$PreveriPotrjeneDoprinose;
                                                }
                                                
                                                $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                                $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                                $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                                $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                                $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                                $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                                $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                                
                                                $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                                $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                                $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                            }
                                        }else{
                                            if ($PreveriDelCas ==1 ) {
                                                $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriDoprinose;
                                                
                                                //$interval=$Datum->diff($DanasnjiDan);
                                                //if ($interval->invert == 0 ) { 
                                                //    $DnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriDoprinose;
                                                //}else{
                                                    $DnevneUre=$PreveriDoprinose;
                                                //}
                                                
                                                $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                                $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                                $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                            }else{
                                                $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriDoprinose;
                                                
                                                //$interval=$Datum->diff($DanasnjiDan);
                                                //if ($interval->invert == 0 ) { 
                                                //    $DnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriDoprinose;
                                                //}else{
                                                    $DnevneUre=$PreveriDoprinose;
                                                //}
                                                
                                                $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                                $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                                $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                            }
                                            $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                            $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                            $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                            
                                            $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                            $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                            $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                        }    
                                    }
                                }
                            }else{
                                $DnevniDoprinos=$PreveriDoprinose;
                                $DnevneUre=$DnevniDoprinos;
                                $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                $PotrjeneDnevneUre=$PotrjenDnevniDoprinos;
                                
                                $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                
                                $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                /*
                                $interval=$Datum->diff($DanasnjiDan);
                                if ($interval->days >= 0 ) { 
                                */
                                $dd=intval($Datum->format('Ymd'));
                                $dz=intval($DanasnjiDan->format('Ymd'));
                                if ($dd <= $dz){
                                    $this->mCountDay[$Indx][17]=$this->mCountDay[$Indx][17]+1;
                                    $this->mCountDay[0][17]=$this->mCountDay[0][17]+1;
                                }
                            }
                            break;
                        default:  //,2 'običajen dan - delovnik
                            //'če je delavec na določen dan zaposlen, potem izračunava ure, sicer gre mimo
                            if ($this->getZaposlen($Datum) ) {
                                $this->mMesecneUre[0][1]=$this->mMesecneUre[0][1]+1;
                                $this->mMesecneUre[$Indx][1]=$this->mMesecneUre[$Indx][1]+1;
                                if ($PreveriDelCas == 1 ) {
                                    if ($PreveriObremenitev > 0 ) {
                                        //'dnevi s potnimi stro?ki in malico
                                        $this->mMesecneUre[$Indx][4]=$this->mMesecneUre[$Indx][4]+1;
                                        $this->mMesecneUre[0][4]=$this->mMesecneUre[0][4]+1;
                                    }
                                }else{
                                    //'dnevi s potnimi stro?ki in malico
                                    $this->mMesecneUre[$Indx][4]=$this->mMesecneUre[$Indx][4]+1;
                                    $this->mMesecneUre[0][4]=$this->mMesecneUre[0][4]+1;
                                }
                                //'če je današnji dan večji od datuma
                                if ($PreveriDogodek ) {
                                    //'če je na ta dan kakšen vpis
                                    for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
                                        if ($i1 != 17){
                                            if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                $this->mCountDay[$Indx][$i1]=$this->mCountDay[$Indx][$i1]+1;   //zazna dnevno rubriko
                                                $this->mCountDay[0][$i1]=$this->mCountDay[0][$i1]+1;   //kumulativa dnevnih rubrik
                                            }
                                        }
                                    }
                                }else{
                                    $IzpisUr=true;
                                }

                                if ($PreveriBolnisko or $PreveriBolniskoNega) {
                                    $DnevniDoprinos=$PreveriDoprinose;
                                    
                                    $DnevneUre=$PreveriDoprinose;
                                    $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                    $PotrjenDnevniDoprinos=$PreveriPotrjeneDoprinose;
                                    $PotrjeneDnevneUre=$PreveriPotrjeneDoprinose;
                                    
                                    $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                    $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                    $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                    $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                    $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                    
                                    $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                    $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                    $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                }else{
                                    if ($PreveriBolnisko50 ) {
                                        $DnevniDoprinos=$PreveriKoeficient*4-4+$PreveriDoprinose;
                                        $DnevneUre=$PreveriKoeficient*4+$PreveriDoprinose;
                                        $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                        $PotrjenDnevniDoprinos=$PreveriKoeficient*4-4+$PreveriPotrjeneDoprinose;
                                        $PotrjeneDnevneUre=$PreveriKoeficient*4+$PreveriPotrjeneDoprinose;
                                        
                                        $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                        $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                        $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                        $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                        $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                        
                                        $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                        $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                        $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                    }else{
                                        if ($PreveriBolniskoProc ) {
                                            if ($PreveriBolniskoProcUre > 0 ) {
                                                $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))-$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriDoprinose;
                                                $DnevneUre=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriDoprinose;
                                                $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                                $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))-$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriPotrjeneDoprinose;
                                                $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev/(100/(100-$PreveriBolniskoProcUre))+$PreveriPotrjeneDoprinose;

                                                $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                                $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                                $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                                $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                                $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                                $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                                $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                                
                                                $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                                $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                                $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                            }
                                        }else{
                                            $DnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriDoprinose;
                                            //$interval = $Datum->diff($DanasnjiDan);
                                            if ($Datum->format('Ymd') <= $DanasnjiDan->format('Ymd')) {
                                                $DnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriDoprinose;
                                            }else{
                                                $DnevneUre=$PreveriDoprinose;
                                            }
                                            
                                            $TotalDoprinos=$TotalDoprinos+$DnevniDoprinos;
                                            $PotrjenDnevniDoprinos=$PreveriKoeficient*$PreveriObremenitev-$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                            $PotrjeneDnevneUre=$PreveriKoeficient*$PreveriObremenitev+$PreveriPotrjeneDoprinose;
                                            
                                            $PotrjenTotalDoprinos=$PotrjenTotalDoprinos+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[$Indx][0]=$this->mMesecneUre[$Indx][0]+$DnevneUre;
                                            $this->mMesecneUre[$Indx][2]=$this->mMesecneUre[$Indx][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[$Indx][3]=$this->mMesecneUre[$Indx][3]+$PotrjenDnevniDoprinos;
                                            $this->mMesecneUre[0][0]=$this->mMesecneUre[0][0]+$DnevneUre;
                                            $this->mMesecneUre[0][2]=$this->mMesecneUre[0][2]+$DnevniDoprinos;
                                            $this->mMesecneUre[0][3]=$this->mMesecneUre[0][3]+$PotrjenDnevniDoprinos;
                                            
                                            $this->mDnevneUre[$Indx][$Indx1][0]=$DnevneUre;
                                            $this->mDnevneUre[$Indx][$Indx1][2]=$DnevniDoprinos;
                                            $this->mDnevneUre[$Indx][$Indx1][3]=$PotrjenDnevniDoprinos;
                                        }
                                    }
                                }
                            }
                    }
            }
        }
        $this->mRealiziranDoprinos=$this->mRealiziranDoprinos+$TotalDoprinos;
        $this->mPotrjenRealiziranDoprinos=$this->mPotrjenRealiziranDoprinos+$PotrjenTotalDoprinos;
    }
    
	public function IzpisKoledarjaPrisotnosti($VLetoPregled){
		//'Metoda pripravi izpis letnega koledarja dela delavca na zaslon
        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        //'ProcZaposl=$this->getUrTeden/40*100
        $DanasnjiDan=new DateTime("now");
        $ActualYear=$DanasnjiDan->format('Y');
        /*
        if ($nacin == 2){
            $DanasnjiDan=new DateTime($VLetoPregled."-".$Indx."-".$MesecDni[$Indx]);
        }
        */
        $Delavec=$this->getIdUcitelj();

		$this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mKoriscenDopust;

		echo "<a name='#letnipregled'> </a>";
		echo "<h2>Prisotnost na delovnem mestu za leto ".$VLetoPregled."</h2>";
		echo "<table border='1'>";
		echo "<tr><th></th>";
		for ($Indx=1;$Indx <= 31;$Indx++){
			echo "<th>".$Indx."</th>";
		}
		echo "</tr>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			$this->IzpisMesecaPrisotnosti($VLetoPregled,$Indx,0); 
		}
		echo "</table><br>";
	}

	public function IzpisMesecaPrisotnosti($VLetoPregled,$Indx,$nacin){
	//'izpiše delavčevo prisotnost za določen mesec
	//'nacin: 0 - izpiše številko meseca
	//'       1 - izpiše ime in priimek delavca
        global $DodatnihRubrik;
        if (($VLetoPregled) % 4 == 0 ) {
            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
        }else{
            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
        }

        //'ProcZaposl=$this->getUrTeden/40*100
        $DanasnjiDan=new DateTime("now");
        $ActualYear=$DanasnjiDan->format('Y');
        $DanZacPocitnic=new DateTime($VLetoPregled."-06-24");
        $DanKonPocitnic=new DateTime($VLetoPregled."-09-01");
        if ($nacin == 2){
            $DanasnjiDan=new DateTime($VLetoPregled."-".$Indx."-".$MesecDni[$Indx]);
        }
        $Delavec=$this->getIdUcitelj();
        $IzpisUr=true;
        $this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mKoriscenDopust;
			
			switch ($nacin){
				case 0:
					echo "<tr><td align='right'>".$Indx."</td>";
                    break;
				case 1:
                case 3:
					echo "<tr><td align='left'>".$this->getPriimek() .", ". $this->getIme()."</td>";
                    break;
				case 2:
					echo "<tr><td align='left'><b>".$MonthName[$Indx]."</b></td>";
                    break;
			}
			for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
				$Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
				$PreveriDoprinose=$this->getCheckDoprinosi($Datum);
				$PreveriPotrjeneDoprinose=$this->getCheckPotrjeniDoprinosi($Datum);
				$PreveriBolnisko=$this->getCheckBolniska($Datum);
                $PreveriBolniskoNega=$this->getCheckBolniskaNega($Datum);
				$PreveriBolnisko50=$this->getCheckBolniska50($Datum);
				$PreveriDogodek=$this->getCheckDogodek($Datum);
				$PreveriDelCas=$this->getCheckDelCas($Datum);
				$PreveriObremenitev=$this->getCheckObremenitev($Datum);
				$PreveriKoeficient=$this->getKoeficient($Datum);
				switch ($Datum->format('w')+1){
					case 1: //,7 'vikend
                    case 7: //,7 'vikend
                        $PreveriPraznik=$this->CheckPraznik($Datum);
                        switch ($PreveriPraznik){
                            case 3: // 'delovna sobota
                                if ($this->getZaposlen($Datum) ) {
                                    if ($PreveriDogodek ) {
                                        $i1=1;
                                        while ($i1 <= $DodatnihRubrik){
                                            switch ($i1){
                                                case 2:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='pink' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 5:
                                                case 6:
                                                case 7:
                                                case 8:
                                                case 9:
                                                case 10:
                                                case 11:
                                                case 18:
                                                case 23:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightcyan' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 3:
                                                case 4:
                                                case 19:
                                                case 22:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightyellow' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 12:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='blue' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                   }
                                                    $i1=$i1+1;
                                                    break;
                                                case 13:
                                                case 14:
                                                case 20:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightpink' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 15:
                                                case 16:
                                                case 21:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lime' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 1: 
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['SkCas'])){
                                                        if (!isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            /*
                                                            $interval1=$DanZacPocitnic->diff($Datum);
                                                            $interval2=$DanKonPocitnic->diff($Datum);
                                                            if (($interval1->invert == 0) && ($interval2->invert == 1) ) {
                                                            */
                                                            $dd=intval($Datum->format('Ymd'));
                                                            $dz=intval($DanZacPocitnic->format('Ymd'));
                                                            $dk=intval($DanKonPocitnic->format('Ymd'));
                                                            if ($dd > $dz && $dd < $dk){
                                                                //'če je to med glavnimi počitnicami, polja obarva s počitniškimi barvami
                                                                echo "<td align='right' bgcolor='lightgrey' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                            }else{
                                                                //'običajen dan
                                                                echo "<td align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                            }
                                                            if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                                echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                            }else{
                                                                echo "<span>";
                                                            }
                                                            $i1=$DodatnihRubrik;
                                                        }
                                                    }
                                                    $IzpisUr=true;
                                                    $i1=$i1+1;
                                            }
                                        }
                                    }else{
                                        /*
                                        $interval1=$DanZacPocitnic->diff($Datum);
                                        $interval2=$DanKonPocitnic->diff($Datum);
                                        if (($interval1->invert == 0) && ($interval2->invert == 1) ) {
                                        */
                                        $dd=intval($Datum->format('Ymd'));
                                        $dz=intval($DanZacPocitnic->format('Ymd'));
                                        $dk=intval($DanKonPocitnic->format('Ymd'));
                                        if ($dd > $dz && $dd < $dk){
                                            //'če je to med glavnimi počitnicami, polja obarva s počitniškimi barvami
                                            echo "<td align='right' bgcolor='lightgrey' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                        }else{
                                            //'običajen dan
                                            echo "<td align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                        }
                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                        }else{
                                            echo "<span>";
                                        }
                                        $IzpisUr=true;
                                    }
                                    if ($this->mDnevneUre[$Indx][$Indx1][0] != 0 ) {
                                        echo number_format($this->mDnevneUre[$Indx][$Indx1][0],1,",","");
                                    }else{
                                        if ($this->mDnevneUre[$Indx][$Indx1][2] != 0 ) {
                                            echo "Du";
                                        }
                                    }
                                    echo "</span>";
                                    echo "</td>";
                                }else{
                                    //'če ni zaposlen na določen datum, se izpiše prazno
                                    echo "<td align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                    //echo "&nbsp;</td>";
                                    echo "</td>";
                                }
                                break;
                            default: // ' med vikendom preveri, če gre za izobraževanje ali spremstvo z dnevnico
                                if ($this->getZaposlen($Datum) ) {
                                    if ($PreveriDogodek ) {
                                        $i1=1;
                                        while ($i1 <= $DodatnihRubrik){
                                            switch ($i1){
                                                case 4:
                                                case 7:
                                                case 13:
                                                case 14:
                                                case 15:
                                                case 16:
                                                case 21:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightpink' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 1: 
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['SkCas'])){
                                                        if (!isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            //'običajen dan
                                                            echo "<td bgcolor='lightsalmon' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                            if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                                echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                            }else{
                                                                echo "<span>";
                                                            }
                                                            $i1=$DodatnihRubrik;
                                                        }
                                                    }
                                                    $IzpisUr=true;
                                                    $i1=$i1+1;
                                                    break;
                                                default:
                                                    $i1=$i1+1;
                                            }
                                        }
                                    }else{
                                        echo "<td bgcolor='lightsalmon' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                        }else{
                                            echo "<span>";
                                        }
                                        $IzpisUr=true;
                                    }

                                    if ($IzpisUr ) {
                                        if ($this->mDnevneUre[$Indx][$Indx1][0] != 0 ) {
                                            echo number_format($this->mDnevneUre[$Indx][$Indx1][0],1,",","");
                                        }
                                    }
                                    echo "</span>";
                                    echo "</td>";
                                }else{
                                    //'če ni zaposlen na določen datum, se izpiše prazno
                                    echo "<td bgcolor='lightsalmon' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                    //echo "&nbsp;</td>";
                                    echo "</td>";
                                }
                        }
                        break;
					default: // 'delovnik
						$PreveriPraznik=$this->CheckPraznik($Datum);
						switch ($PreveriPraznik){
							case 4: //'dela prost dan
								echo "<td bgcolor='khaki' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                    echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                }else{
                                    echo "<span>";
                                }
                                $IzpisUr=false;
								if ($this->mDnevneUre[$Indx][$Indx1][0] != 0 ) {
									echo number_format($this->mDnevneUre[$Indx][$Indx1][0],1,",","");
                                    $IzpisUr=true;
								}
                                echo "</span>";
                                echo "</td>";
                                break;
                            case 1: //'praznik
                                if ($PreveriDogodek ) {
                                    $i1=1;
                                    while ($i1 <= $DodatnihRubrik){
                                        switch ($i1){
                                            case 3:
                                            case 4:
                                            case 19:
                                            case 22:
                                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                    echo "<td bgcolor='lightyellow' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                        echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                    }else{
                                                        echo "<span>";
                                                    }
                                                    
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                        echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                    }
                                                    $IzpisUr=false;
                                                    $i1=$DodatnihRubrik;
                                                }
                                                $i1=$i1+1;
                                                break;
                                            default:
                                                if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                    echo "<td bgcolor='lightgreen' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                        echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                    }else{
                                                        echo "<span>";
                                                    }
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                        echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                    }
                                                    $IzpisUr=true;
                                                    $i1=$DodatnihRubrik;
                                                }
                                                $i1=$i1+1;
                                        }
                                    }
                                    if ($IzpisUr ) {
                                        if (($this->mDnevneUre[$Indx][$Indx1][0] != 0) || ($this->mDnevneUre[$Indx][$Indx1][2] != 0) ) {
                                            echo number_format($this->mDnevneUre[$Indx][$Indx1][2],1,",","");
                                        }
                                    }
                                    echo "</span>";
                                    echo "</td>";
                                }else{
                                    echo "<td bgcolor='lightgreen' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                        echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                    }else{
                                        echo "<span>";
                                    }
                                    /*
                                    $interval=$Datum->diff($DanasnjiDan);
                                    if ($interval->invert == 0 ) {
                                    */
                                    $dd=intval($Datum->format('Ymd'));
                                    $dz=intval($DanasnjiDan->format('Ymd'));
                                    if ($dd <= $dz){
                                        echo "Dp ";
                                    }
                                    if (($this->mDnevneUre[$Indx][$Indx1][0] != 0) || ($this->mDnevneUre[$Indx][$Indx1][2] != 0) ) {
                                        echo number_format($this->mDnevneUre[$Indx][$Indx1][1],1,",","");
                                    }
                                    echo "</span>";
                                    echo "</td>";
                                }
                                break;
							default: // 0,2 'delovni dan
								if ($this->getZaposlen($Datum) ) {
									if ($PreveriDogodek ) {
                                        $i1=1;
                                        while ($i1 <= $DodatnihRubrik){
                                            switch ($i1){
                                                case 2:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='pink' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 5:
                                                case 6:
                                                case 7:
                                                case 8:
                                                case 9:
                                                case 10:
                                                case 11:
                                                case 18:
                                                case 23:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightcyan' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 3:
                                                case 4:
                                                case 19:
                                                case 22:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightyellow' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 12:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='blue' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 13:
                                                case 14:
                                                case 20:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lightpink' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 15:
                                                case 16:
                                                case 21:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lime' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 17:
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')][$i1])){
                                                        echo "<td bgcolor='lime' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                        }else{
                                                            echo "<span>";
                                                        }
                                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            echo $this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'];
                                                        }
                                                        $IzpisUr=false;
                                                        $i1=$DodatnihRubrik;
                                                    }
                                                    $i1=$i1+1;
                                                    break;
                                                case 1: 
                                                    if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['SkCas'])){
                                                        if (!isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['OznDan'])){
                                                            /*
                                                            $interval1=$DanZacPocitnic->diff($Datum);
                                                            $interval2=$DanKonPocitnic->diff($Datum);
                                                            if (($interval1->invert == 0) && ($interval2->invert == 1) ) {
                                                            */
                                                            $dd=intval($Datum->format('Ymd'));
                                                            $dz=intval($DanZacPocitnic->format('Ymd'));
                                                            $dk=intval($DanKonPocitnic->format('Ymd'));
                                                            if ($dd > $dz && $dd < $dk){
                                                                //'če je to med glavnimi počitnicami, polja obarva s počitniškimi barvami
                                                                echo "<td align='right' bgcolor='lightgrey' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                                            }else{
                                                                //'običajen dan
                                                                echo "<td align='right'>";
                                                            }
                                                            $i1=$DodatnihRubrik;
                                                            if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                                                echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                                            }else{
                                                                echo "<span>";
                                                            }
                                                        }
                                                    }
                                                    $IzpisUr=true;
                                                    $i1=$i1+1;
                                            }
                                        }
									}else{
										if ($PreveriPraznik == 2 ) {
											echo "<td bgcolor='lightblue' align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
										}else{
                                            /*
                                            $interval1=$DanZacPocitnic->diff($Datum);
                                            $interval2=$DanKonPocitnic->diff($Datum);
                                            if (($interval1->invert == 0) && ($interval2->invert == 1) ) {
                                            */
                                            $dd=intval($Datum->format('Ymd'));
                                            $dz=intval($DanZacPocitnic->format('Ymd'));
                                            $dk=intval($DanKonPocitnic->format('Ymd'));
                                            if ($dd > $dz && $dd < $dk){
												//'?e je to med glavnimi po?itnicami, polja obarva s po?itni?kimi barvami
												echo "<td align='right' bgcolor='lightgrey' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
											}else{
												echo "<td align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
											}
										}
                                        if (isset($this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji'])){
                                            echo "<span title='".$this->mKolDop[$Datum->format('n')][$Datum->format('j')]['komentarji']."'>";
                                        }else{
                                            echo "<span>";
                                        }
										$IzpisUr=true;
									}

									if ($IzpisUr ) {
										if ($this->mDnevneUre[$Indx][$Indx1][0] != 0 ) {
											echo number_format($this->mDnevneUre[$Indx][$Indx1][0],1,",","");
										}else{
											if ($this->mDnevneUre[$Indx][$Indx1][2] != 0 ) {
												echo "Du";
											}
										}
									}
                                            
                                    echo "</span>";
                                            
                                    //echo "&nbsp;</td>";
                                    echo "</td>";
								}else{
									//'če ni zaposlen na določen datum, se izpiše prazno
									echo "<td align='right' onclick=\"location.href='IzpisUcitelja.php?id1=1&idUcitelj=".$this->getIdUcitelj()."&letopregled=$VLetoPregled&mesec=".$Datum->format('n')."&dan=".$Datum->format('j')."'\">";
                                    //echo "&nbsp;</td>";
                                    echo "</td>";
								}
						}
				}
			}
			if ($nacin == 2){
				echo "<td>&nbsp;</td>";
			}
			echo "</tr>";
	}
	
	public function LetniPregledUr($VLetoPregled){
		//'Metoda izpiše pregled ur za doprinos.
		//'Izpiše koliko je prostih dni, tabelo delovnih dni in realizacijo po mesecih, koriščen dopust ter seštevek doprinesenih 
		//'in potrebnih ur
        global $ProstiDnevi,$DodatnihRubrik,$izpisDU,$IzpisSezon,$JesenskiDel,$DelovniDan,$OznakaDneva,$ObracunajDu;
		$ProcZaposl=$this->getProcZapLetno($VLetoPregled);
		$Danes=new DateTime("now");
		$Delavec=$this->getIdUcitelj();
        $MonthName=array('','januar','februar','marec','april','maj','junij','julij','avgust','september','oktober','november','december');
		
		echo "Počitnice: ".$ProstiDnevi." dni<br>";
		if ($Danes->format('Y') > $VLetoPregled ) {
            $Datum=new DateTime($VLetoPregled."-12-31");
			echo "Koeficient dela: ".round($this->getKoeficient($Datum),2)."<br>";
		}else{
			echo "Koeficient dela: ".round($this->getKoeficient($Danes),2)."<br>";
		}

		echo "<table border='1'>";
		echo "<tr><th>Mesec</th><th>Del. dni</th><th>Real. Ure</th><th>Višek ur</th>";
		for ($Indx=2;$Indx <= $DodatnihRubrik;$Indx++){
			echo "<th>".$OznakaDneva[$Indx]."</th>";
		}
		
		echo "<th>Kumulativa</th>";
		$TekocaVsota=0;
		$VsotaJesen=0;
		echo "</tr>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			echo "<tr>";
			echo "<td><a href='PregledDelaMesec.php?idUcitelj=".$Delavec."&leto=".$VLetoPregled."&mesec=".$Indx."'>".$MonthName[$Indx]."</a></td><td align='center'>".round($this->mMesecneUre[$Indx][1])."</td><td align='right'>".round($this->mMesecneUre[$Indx][0],1)."</td><td align='right'>".round($this->mMesecneUre[$Indx][2],1)."</td>";
			$TekocaVsota=$TekocaVsota+$this->mMesecneUre[$Indx][2];
			if ($Indx > 8 ) {
				$VsotaJesen=$VsotaJesen+$this->mMesecneUre[$Indx][2];
			}
			for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
				echo "<td align=right>".$this->mCountDay[$Indx][$i1]."</td>";
			}
			if ($Indx < 9 ) {
				echo "<td>".round($TekocaVsota,2)."</td>";
			}else{
				echo "<td>".round($TekocaVsota,2)."/".round($VsotaJesen,2)."</td>";
			}
			echo "</tr>";
		}
		echo "<tr>";
		echo "<td>Skupaj</td><td align='center'>".$this->mMesecneUre[0][1]."</td><td align='right'>".round($this->mMesecneUre[0][0],1)."</td><td align='right'>".round($this->mMesecneUre[0][2],1)."</td>";
		for ($i1=2;$i1 <= $DodatnihRubrik;$i1++){
			echo "<td align='right'>".$this->mCountDay[0][$i1]."</td>";
		}
		echo "</tr>";
		echo "</table><br>";

		//$this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mCountDay[0][6]-$this->mCountDay[0][2];
        $this->mPreostaliDopust=$this->getDopust()+$this->getDopustStari()-$this->mCountDay[0][6];// gabra ne šteje -$this->mCountDay[0][2];

		echo "<b>Koriščen dopust:</b><br>";
		echo "<table border='1'>";
		echo "<tr><th>Leto</th><th>Skupaj<br>dopusta</th>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			echo "<th>".$Indx."</th>";
		}
		echo "<th>Skupaj<br>koriščeno</th><th>Preostali<br>dopust</th></tr>";
		echo "<tr><td>".$VLetoPregled."</td><td align='center'>".($this->getDopust()+$this->getDopustStari())."</td>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			//echo "<td align='center'>".($this->mCountDay[$Indx][6]+$this->mCountDay[$Indx][2])."</td>";
            echo "<td align='center'>".($this->mCountDay[$Indx][6])."</td>"; //gabra ne šteje
		}
		//echo "<td align='center'>".($this->mCountDay[0][2]+$this->mCountDay[0][6])."</td><td align='center'>".$this->mPreostaliDopust."</td></tr></table><br />";
        echo "<td align='center'>".($this->mCountDay[0][6])."</td><td align='center'>".$this->mPreostaliDopust."</td></tr></table><br />";

        //izpis povzetka ur
        echo "<table border='1'>";
        
        if ($this->mUcenje == 1) {
            echo "<tr><td>Število prostih dni: </td><td><b>" . $this->getObveza() . "</b> dni </td></tr>";
            if ($this->getZmanjsanaObveza() > 0 ) {
                echo "<tr><td>Zmanjšana obveza (porodniška, nega otroka, bolniška med počitnicami): </td><td><b>" . $this->getZmanjsanaObveza() . "</b> dni </td></tr>";
            }
            if ($this->getDeloMedPocitnicami() > 0 ) {
                echo "<tr><td>Zmanjšana obveza (delo med počitnicami): </td><td><b>" . $this->getDeloMedPocitnicami() . "</b> dni </td></tr>";
            }
            echo "<tr><td>Potrebne dodatne ure:</td><td><b> " . round($this->getDoprinos(),1) . "</b> (DU)<br /></td></tr>";
        }
        
		if ($this->getDoprinos() != "" ) {
			echo "<tr><td>Potrebne dodatne ure:</td><td><b> " . round($this->getDoprinos(),2) . "</b> DU";
			if ($izpisDU == 0 ) {
				echo "/".round($this->getDoprinos()/1.5,2) ." PU";
			}
			echo "</td></tr>";
		}else{
			echo "<tr><td>Potrebne dodatne ure:</td><td><b> " . $this->getDoprinos() . "</b> DU</td></tr>";
		}
        //pogleda procent zaposljenosti za tekoče leto (po pogodbah)
        $ProcZaposl=$this->getProcZapLetno($VLetoPregled);

		//razlika med Koriščenimi dnevi in obvezo
        if ($this->mCountDay[0][5] > 0){
            if ($this->getDoprinos() > 0){
		        $VKorUre=$this->getDopust()+$this->getDopustStari()+$this->mCountDay[0][5] - $this->getObveza();
            }else{
                $VKorUre=$this->mCountDay[0][5];
            }
        }else{
            $VKorUre=0;
        }
        if ($ObracunajDu == 1){
            if ($ProcZaposl < 100){
                $PreseganjeObveze = $this->getDoprinos()-$this->mRealiziranDoprinos + $VKorUre*8*$ProcZaposl/100;
                $PotrjenoPreseganjeObveze = $this->getDoprinos()-$this->mPotrjenRealiziranDoprinos + $VKorUre*8*$ProcZaposl/100;
            }else{
                $PreseganjeObveze = $this->getDoprinos()-$this->mRealiziranDoprinos + $VKorUre*8;
                $PotrjenoPreseganjeObveze = $this->getDoprinos()-$this->mPotrjenRealiziranDoprinos + $VKorUre*8;
            }
        }else{
            $PreseganjeObveze = $this->getDoprinos()-$this->mRealiziranDoprinos;
            $PotrjenoPreseganjeObveze = $this->getDoprinos()-$this->mPotrjenRealiziranDoprinos;
        }
        
		if ($this->mUcenje == 1 ) {
			echo "<tr><td>Opravili ste že: </td><td><b>" .  round($this->mRealiziranDoprinos,2) . " </b>DU";
			if ($izpisDU == 0 ) {
				echo "/".round($this->mRealiziranDoprinos/1.5,2) ." PU";
			}
			echo "</td></tr>";
			echo "<tr><td>Potrjeno ste opravili že: </td><td><b>" .  round($this->mPotrjenRealiziranDoprinos,2) . " </b>DU";
			if ($izpisDU == 0 ) {
				echo "/".round($this->mPotrjenRealiziranDoprinos/1.5,2) ." PU";
			}
			echo "</td></tr>";
            /*
			if ($this->getDoprinos()-$this->mRealiziranDoprinos < 0 ) {
				echo "<tr><td>Obvezo presegate za: </td><td><font color='green'><b>" . round(abs($this->getDoprinos()-$this->mRealiziranDoprinos),2) . "</b> DU</font>";
				if ($izpisDU == 0 ) {
					echo "<font color='green'>/".round((abs($this->getDoprinos()-$this->mRealiziranDoprinos)/1.5),2) ." PU</font>";
				}
				echo "</td></tr>";
			}else{
				echo "<tr><td>Opraviti je potrebno še: </td><td><font color='red'><b>" . round($this->getDoprinos()-$this->mRealiziranDoprinos,2) . "</b> DU</font>";
				if ($izpisDU == 0 ) {
					echo "<font color='red'>/".round(($this->getDoprinos()-$this->mRealiziranDoprinos)/1.5,2) ." PU</font>";
				}
				echo "</td></tr>";
			}	
			if ($this->getDoprinos()-$this->mPotrjenRealiziranDoprinos < 0 ) {
				echo "<tr><td>Obvezo potrjeno presegate za: </td><td><font color='green'><b>" . round(abs($this->getDoprinos()-$this->mPotrjenRealiziranDoprinos),2) . "</b> DU</font>";
				if ($izpisDU == 0 ) {
					echo "<font color='green'>/".round(abs(($this->getDoprinos()-$this->mPotrjenRealiziranDoprinos)/1.5),2) ." PU</font>";
				}
				echo "</td></tr>";
			}else{
				echo "<tr><td>Opraviti je potrebno še potrjenih: </td><td><font color='red'><b>" . round($this->getDoprinos()-$this->mPotrjenRealiziranDoprinos,2) . "</b> DU</font>";
				if ($izpisDU == 0 ) {
					echo "<font color='red'>/".round(($this->getDoprinos()-$this->mPotrjenRealiziranDoprinos)/1.5,2) ." PU</font>";
				}
				echo "</td></tr>";
			}
            */
            if ($PreseganjeObveze < 0 ) {
                echo "<tr><td>Obvezo presegate za: </td><td><font color='green'><b>" . round(abs($PreseganjeObveze),2) . "</b> DU</font>";
                if ($izpisDU == 0 ) {
                    echo "<font color='green'>/".round((abs($PreseganjeObveze)/1.5),2) ." PU</font>";
                }
                echo "</td></tr>";
            }else{
                echo "<tr><td>Opraviti je potrebno še: </td><td><font color='red'><b>" . round($PreseganjeObveze,2) . "</b> DU</font>";
                if ($izpisDU == 0 ) {
                    echo "<font color='red'>/".round(($PreseganjeObveze)/1.5,2) ." PU</font>";
                }
                echo "</td></tr>";
            }    
            if ($PotrjenoPreseganjeObveze < 0 ) {
                echo "<tr><td>Obvezo potrjeno presegate za: </td><td><font color='green'><b>" . round(abs($PotrjenoPreseganjeObveze),2) . "</b> DU</font>";
                if ($izpisDU == 0 ) {
                    echo "<font color='green'>/".round(abs(($PotrjenoPreseganjeObveze)/1.5),2) ." PU</font>";
                }
                echo "</td></tr>";
            }else{
                echo "<tr><td>Opraviti je potrebno še potrjenih: </td><td><font color='red'><b>" . round($PotrjenoPreseganjeObveze,2) . "</b> DU </font>";
                if ($izpisDU == 0 ) {
                    echo "<font color='red'>/".round(($PotrjenoPreseganjeObveze)/1.5,2) ." PU</font>";
                }
                echo "</td></tr>";
            }
            	
			if ($ProcZaposl < 100 ) {
				if ($IzpisSezon ==0 ) {
					echo "<tr><td>V pomladnem delu je treba nadomestiti </td><td>".round($this->getDoprinos()-$JesenskiDel*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000],1)." DU.</td></tr>";
					echo "<tr><td>V jesenskem delu je treba nadomestiti </td><td>".round($JesenskiDel*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000],1). " DU. </td></tr>";
				}
				if ($VKorUre >= 0 ) {
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000].") <font color='red'>+".$VKorUre."</font>.</td></tr>";
				}else{
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000].") <font color='green'>".$VKorUre."</font>.</td></tr>";
				}
			}else{
				if ($IzpisSezon ==0 ) {
					echo "<tr><td>V pomladnem delu je treba nadomestiti </td><td>".round($this->getDoprinos()-$JesenskiDel*$DelovniDan[$VLetoPregled-2000],1)." DU.</td></tr>";
					echo "<tr><td>V jesenskem delu je treba nadomestiti </td><td>".round($JesenskiDel*$DelovniDan[$VLetoPregled-2000],1). " DU. </td></tr>";
				}
				if ($VKorUre >= 0 ) {
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$DelovniDan[$VLetoPregled-2000]." ur) <font color='red'>+".$VKorUre."</font>.</td></tr>";
				}else{
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$DelovniDan[$VLetoPregled-2000]." ur) <font color='green'>".$VKorUre."</font>.</td></tr>";
				}
			}
			echo "<tr><td>Dopusta je še: </td><td><b>" . $this->mPreostaliDopust . " </b> dni.</td></tr>";
		}else{
			if  ($ProcZaposl < 100 ) {
				echo "<tr><td>Opravili ste že: </td><td><b>" .  round($this->mRealiziranDoprinos,2) . " </b>DU.</td></tr>";
				echo "<tr><td>Potrjeno ste opravili že: </td><td><b>" .  round($this->mPotrjenRealiziranDoprinos,2) . " </b>DU.</td></tr>";
				echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$ProcZaposl/100*$DelovniDan[$VLetoPregled-2000]." ur).</td></tr>";
				echo "<tr><td>Dopusta je še: </td><td><b>" . $this->mPreostaliDopust . " </b>dni.</td></tr>";
			}else{
				if ($this->mRealiziranDoprinos > 0 ) {
					echo "<tr><td>Imate: </td><td><b>" . round($this->mRealiziranDoprinos,2) . " </b>DU viška.</td></tr>";
				}else{
					echo "<tr><td>Imate: </td><td><font color='red'><b>" . round($this->mRealiziranDoprinos,2) . " </b></font>DU minusa.</td></tr>";
				}
				if ($this->mPotrjenRealiziranDoprinos > 0 ) {
					echo "<tr><td>Potrjenih imate: </td><td><b>" . round($this->mPotrjenRealiziranDoprinos,2) . " </b>DU viška.</td></tr>";
				}else{
					echo "<tr><td>Potrjenih imate: </td><td><font color='red'><b>" . round($this->mPotrjenRealiziranDoprinos,2) . " </b></font>DU minusa.</td></tr>";
				}
				if ($VKorUre >= 0 ) {
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$DelovniDan[$VLetoPregled-2000]." ur).</td></tr>";
				}else{
					echo "<tr><td>Koristili ste ur za: </td><td><b>".$this->mCountDay[0][5]." </b> dni (".$this->mCountDay[0][5]*$DelovniDan[$VLetoPregled-2000]." ur).</td></tr>";
				}
				echo "<tr><td>Dopusta je še: </td><td><b>" . $this->mPreostaliDopust . " </b> dni.</td></tr>";
			}
		}
        echo "</table><br />";
	}
	
	public function Rubrike($VLetoPregled,$VLeto,$vse){
		//'Metoda izpiše vse vnesene rubrike delavca.
		//'Nepotrjene rubrike izpiše rumeno, potrjene zeleno in izplačane rdeče.
		//'Rubrike je možno izbrisati (označi se jih s kljukico in klikne gumb Izbriši) ali potrjevati s klikom na da ali ne.
		global $izpisDU;
        global $link;
		$Delavec=$this->getIdUcitelj();
		$Danes=new DateTime("now");
		$mesecComp[1]=$Danes->format('n');
		if ($mesecComp[1] ==1 ) { 
			$mesecComp[2]=12;
		}else{
			$mesecComp[2]=$mesecComp[1]-1;
		}
		
		if ($vse =="1" ) {
			$SQL = "SELECT tabpregleddelan.*,tabdoprinos.*,tabpregleddelan.id AS pid FROM tabpregleddelan INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos ";
			$SQL = $SQL . "WHERE tabpregleddelan.leto=".$VLetoPregled." AND ucitelj=".$Delavec;
			$SQL = $SQL ." ORDER BY datum DESC";
		}else{
			$SQL = "SELECT tabpregleddelan.*,tabdoprinos.*,tabpregleddelan.id AS pid FROM tabpregleddelan INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos ";
			$SQL = $SQL . "WHERE tabpregleddelan.leto=".$VLetoPregled." AND ucitelj=".$Delavec." AND mesec IN (".$mesecComp[1].",".$mesecComp[2].")";
			$SQL = $SQL ." ORDER BY datum DESC";
		}

		echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.php'>";
		echo "<input name='submit' type='submit' value='Briši'>";
        echo "<input name='submit' type='submit' value='Potrdi'><br />";
		echo "<a name='spisek'><br></a><table border='1' cellspacing='0'>";
		echo "<tr bgcolor='cyan'><th>št.</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th>";
		if ($izpisDU == 0 ) {
			echo "<th>DU</th>";
		}
		echo "<th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
		$Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
			switch ($R["aktivno"]){
				case 1:
					if ($R["EnotPotrjeno"] ) {
						if ($R["Rubrika"]==28 ) {
							echo "<tr bgcolor='red'>";
						}else{
							echo "<tr bgcolor='lightgreen'>";
						}
					}else{
						if ($R["Rubrika"]==28 ) {
							echo "<tr bgcolor='red'>";
						}else{
							echo "<tr bgcolor='lightyellow'>";
						}
					}
                    break;
				default:
					if ($R["Rubrika"]==28 ) {
						echo "<tr bgcolor='red'>";
					}else{
						echo "<tr bgcolor='lightcyan'>";
					}
			}
			echo "<td>".$Indx."</td>";
            $Datum=new DateTime($R["Datum"]);
			echo "<td>".$Datum->format('d.m.Y')."</td>";
			echo "<td>".$R["OblikaDela"]."</td>";
			switch ($R["aktivno"]){
				case 19:
					echo "<td>".$R["Enot"]." %</td>";
					if ($izpisDU == 0 ) {
						echo "<td>".round($R["Enot"]/100*$this->getCheckObremenitev($Datum),2)." ur</td>";
					}
                    break;
				default:
					if ($R["uramin"] > 1 ) {
						echo "<td>".$R["Enot"]." min</td>";
						if ($izpisDU == 0 ) {
							echo "<td>".round($R["Enot"]/$R["uramin"]*$R["koeficient"],2)." ur</td>";
						}
					}else{
						if ($R["koeficient"]==8 || $R["koeficient"]==0 ) {
							echo "<td>".$R["Enot"]." dni</td>";
							if ($izpisDU == 0 ) {
								echo "<td>".$R["Enot"]." dni</td>";
							}
						}else{
							
							echo "<td>".$R["Enot"]." ur</td>";
							if ($izpisDU == 0 ) {
								echo "<td>".round($R["Enot"]/$R["uramin"]*$R["koeficient"],2)." ur</td>";
							}
						}
					}
			}
			echo "<td>".$R["Komentar"]."</td>";
			if ($R["EnotPotrjeno"] ) {
                echo "<td><input name='potrdi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='potrjeno_".$Indx."' type='checkbox' checked='checked'></td>";
//				echo "<td align='center'><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["Ucitelj"]."'>da</a></td>";
			}else{
                echo "<td><input name='potrdi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='potrjeno_".$Indx."' type='checkbox'></td>";
//				echo "<td align='center'><a href='PotrdiPDNRubriko.php?id="&R("pid")&"&potrdi=1&Ucitelj="&R("Ucitelj")&"'>ne</a></td>"
			}
			echo "<td><a href='IzpisUcitelja.php?id1=1&idUcitelj=".$Delavec."&id=".$R["pid"]."'>Popravi</a></td>";
			echo "<td><input name='brisi_".$Indx."' type='hidden' value='".$R["pid"]."'><input name='br_".$Indx."' type='checkbox'></td>";
			echo "</tr>";
			$Indx=$Indx+1;
		}
		if ($vse=="1" ) {
			echo "<tr><td></td><td></td><td><a href='IzpisUcitelja.php?idUcitelj=".$Delavec."&letopregled=".$VLetoPregled."&leto=".$VLeto."&vse=0'>Izpis zadnjih vnosov za leto ".$VLetoPregled."</a></td></tr>";
		}else{
			echo "<tr><td></td><td></td><td><a href='IzpisUcitelja.php?idUcitelj=".$Delavec."&letopregled=".$VLetoPregled."&leto=".$VLeto."&vse=1'>Izpis vseh vnosov za leto ".$VLetoPregled."</a></td></tr>";
		}
		echo "</table><br>";
		echo "<input name='idUcitelj' type='hidden' value='".$Delavec."'>";
        echo "<input name='StRubrik' type='hidden' value='".($Indx-1)."'>";
        echo "<input name='vse' type='hidden' value='".$vse."'>";
		echo "<input name='submit' type='submit' value='Briši'>";
        echo "<input name='submit' type='submit' value='Potrdi'>";
		echo "</form><br>";
	}
    
}
?>