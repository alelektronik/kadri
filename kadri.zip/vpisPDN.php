<?php
require ('const.php');
include ('iskanje.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pregled dela
</title>
</head>
<body>

<?php
if (isset($_POST["datod"])){
    $DatumOd=new DateTime($_POST["datod"]);
    $VLeto=intval($DatumOd->format('Y'));
    $VLetoPregled=$VLeto;
    $VPregledLeto = $VLetoPregled;
    $VMesec=intval($DatumOd->format('n'));
    $VDan=intval($DatumOd->format('j'));
}else{
    $VLeto=PreberiLeto("leto");
    $VLetoPregled=$VLeto;
    $VPregledLeto = $VLetoPregled;
    if (isset($_POST["mesec"])){
        $VMesec = intval($_POST["mesec"]);
    }else{
        $VMesec = 1;
    }
    if (isset($_POST["dan"])){
        $VDan = $_POST["dan"];
    }else{
        $VDan = 1;
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$Prepovedano=false;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
    $Prepovedano=true;
}

if (isset($_POST["idUcitelj"])){
    $ucitelj = $_POST["idUcitelj"];
}else{
    if (isset($_GET["idUcitelj"])){
        $ucitelj = $_GET["idUcitelj"];
    }else{
        if (isset($_SESSION["idUcitelj"])){ 
            $ucitelj = $_SESSION["idUcitelj"];
        }else{
            $ucitelj = 0;
        }
    }
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id = $_GET["id"];
    }else{
        $id = "";
    }
}
if (isset($_POST["MKomentar"])){
    $VMKomentar = $_POST["MKomentar"];
}else{
    $VMKomentar = "";
}
if (isset($_POST["cas"])){
    $Vcas = str_replace(",",".",$_POST["cas"]);
    if (!is_numeric($Vcas)){
        $Vcas=0;
    }
}else{
    $Vcas = 0;
}
if (isset($_POST["rubrika"])){
    $VRubrika = $_POST["rubrika"];
}else{
    $VRubrika = 0;
}
$TimeStamp = $Danes;
if (isset($_POST["EnotPotrjeno"])){
    $VEnotPotrjeno=$_POST["EnotPotrjeno"];
    if ($VEnotPotrjeno=="on" ) {
        $VEnotPotrjeno="true";
    }else{
        $VEnotPotrjeno="false";
    }
}else{
    $VEnotPotrjeno="false";
}

//echo "Leto: ".$VLeto."/".($VLeto+1)."<br />";

if (($VLeto) % 4 == 0 ) {
    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
}else{
    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
}

if (isDate($VPregledLeto.'-'.$VMesec.'-'.$VDan)){
    $DanVpis=new DateTime($VPregledLeto.'-'.$VMesec.'-'.$VDan);
    $DanMejni=new DateTime($VPregledLeto.'-'.$VMesec.'-'.$MesecDni[$VMesec]);
}else{
    $DanVpis=new DateTime($Danes->format('Y-m-d'));
    $DanMejni=new DateTime($Danes->format('Y-m-').$MesecDni[intval($Danes->format('n'))]);
}
//--------------- vpis - začetek -----------------------------------------------------------------------------------------------        
        if ($id==""){  //dodajanje novega zapisa
            if ($VLevel < 2 ) {
//                $interval=$DanVpis->diff($Danes);
                $interval=$Danes->diff($DanMejni);
                if ($interval->invert==1 && ($interval->days > $RazlikaDniVpis)) {
                    header("Location: staripodatki.htm");
                    $Prepovedano=true;
                }
            }
            if (!$Prepovedano){
                $SQL = "SELECT * FROM TabPraznik WHERE leto IN (".$VLeto.",".($VLeto+1).") ORDER BY datum";
                $Indx=1;
                $ProstiDnevi=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    $Praznik[$Indx][1]=$R["kat"];
                    if ($Praznik[$Indx][1]==1 ) {
                        $ProstiDnevi=$ProstiDnevi+1;
                    }
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;
                
                switch ($VRubrika){
                    case 21:          //dnevne rubrike
                    case 27:
                    case 32:
                    case 33:
                    case 34:
                    case 35:
                    case 36:
                    case 37:
                    case 38:
                    case 39:
                    case 40:
                    case 41:
                    case 42:
                    case 43:
                    case 44:
                    case 45:
                    case 47:
                    case 17:
                        $SteviloDni=$Vcas;
                        if ($Vcas > 0 ) {      //vneseno je število dni
                            echo "Število dni: ".$SteviloDni."<br>";
                            if ($SteviloDni > 1 ) {
                                $Indx=1;
                                $Datum=new DateTime($DanVpis->format('Y-m-d'));
                                while (($Indx <= $SteviloDni )){
                                    $preveriPraznik=CheckPraznik($Datum);
                                    //echo "Datum: ".$Datum->format('d.m.y')." ".$preveriPraznik."<br />";
                                    switch ($preveriPraznik){
                                        case 0:
                                        case 2:
                                            if (!(($Datum->format('w')+1 == 1) or ($Datum->format('w')+1 == 7)) ) {
                                                //'echo "Datum: ".datum."<br>"
                                                $VDan=$Datum->format('d');
                                                $VMesec=$Datum->format('m');
                                                $VPregledLeto=$Datum->format('Y');
                                                if ($VEnotPotrjeno == "false") {
                                                    $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                                    $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                                }else{
                                                    $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                                    $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                                }
                                                $result = mysqli_query($link,$SQL);
                                                if (!$result){
                                                    die("Napaka pri vpisu podatkov: ".mysqli_error());
                                                }
                                                //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                                $Indx=$Indx+1;
                                            }
                                            break;
                                        case 3:
                                            $VDan=$Datum->format('d');
                                            $VMesec=$Datum->format('m');
                                            $VPregledLeto=$Datum->format('Y');
                                            if ($VEnotPotrjeno == "false" ) {
                                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                            }else{
                                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                            }
                                            $result = mysqli_query($link,$SQL);
                                            if (!$result){
                                                die("Napaka pri vpisu podatkov: ".mysqli_error());
                                            }
                                            
                                            //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                            $Indx=$Indx+1;
                                    }
                                    $Datum->add(new DateInterval('P1D'));
                                    //Datum=day(datum).".".month(datum).".".year(datum)
                                }
                            }else{
                                if ($VEnotPotrjeno == "false" ) {
                                    $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                    $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                }else{
                                    $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                    $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                }
                                $result = mysqli_query($link,$SQL);
                                if (!$result){
                                    die("Napaka pri vpisu podatkov: ".mysqli_error());
                                }

                                //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                            }
                        }else{ //vneseno je po datumu od-do
                            if (isset($_POST["datdo"])){
                                $DatumDo=new DateTime($_POST["datdo"]);
                                $VletoK=$DatumDo->format('Y');
                                $VmesecK=$DatumDo->format('n');
                                $VdanK=$DatumDo->format('j');
                            }else{
                                $VletoK = $_POST["letoK"];
                                $VmesecK = $_POST["mesecK"];
                                $VdanK = $_POST["danK"];
                            }
                            
                            $Indx=1;
                            $Datum=new DateTime($DanVpis->format('Y-m-d'));
                            if (isDate($VletoK.'-'.$VmesecK.'-'.$VdanK)){
                                $DatumK=new DateTime($VletoK.'-'.$VmesecK.'-'.$VdanK);
                            }else{
                                $DatumK=new DateTime($DanVpis->format('Y-m-d'));
                            }
                            $interval=$Datum->diff($DatumK);
                            while (($interval->invert == 0) && ($interval->days >= 0)){
                                $preveriPraznik=CheckPraznik($Datum);
                                //echo "Datum: ".$Datum->format('Y-m-d')." ".$preveriPraznik."<br>";
                                switch ($preveriPraznik){
                                    case 0:
                                    case 2:
                                        if (!((($Datum->format('w')+1)==1) or ($Datum->format('w')+1)==7)) {
                                            $VDan=$Datum->format('d');
                                            $VMesec=$Datum->format('m');
                                            $VPregledLeto=$Datum->format('Y');
                                            if ($VEnotPotrjeno == "false" ) {
                                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                            }else{
                                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",1,'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                            }
                                            $result = mysqli_query($link,$SQL);
                                            if (!$result){
                                                die("Napaka pri vpisu podatkov: ".mysqli_error());
                                            }

                                            //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                            $Indx=$Indx+1;
                                        }
                                        break;
                                    case 3:
                                        $VDan=$Datum->format('d');
                                        $VMesec=$Datum->format('m');
                                        $VPregledLeto=$Datum->format('Y');
                                        if ($VEnotPotrjeno == "false" ) {
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                        }else{
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".C."','".$VUporabnik."')";
                                        }
                                        $result = mysqli_query($link,$SQL);
                                        if (!$result){
                                            die("Napaka pri vpisu podatkov: ".mysqli_error());
                                        }
                                        
                                        //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                        $Indx=$Indx+1;
                                }
                                $Datum->add(new DateInterval('P1D'));
                                $interval=$Datum->diff($DatumK);
                            }
                        }
                        break;
                    default:      //ostale rubrike, ki jih vpisujejo delavci (urne, minutne)
                        $Datum=new DateTime($DanVpis->format('Y-m-d'));
                        if (isset($_POST["datdo"])){
                            $DatumDo=new DateTime($_POST["datdo"]);
                            $VletoK=$DatumDo->format('Y');
                            $VmesecK=$DatumDo->format('n');
                            $VdanK=$DatumDo->format('j');
                        }else{
                            $VletoK = $_POST["letoK"];
                            $VmesecK = $_POST["mesecK"];
                            $VdanK = $_POST["danK"];
                        }
                        if (isDate($VletoK.'-'.$VmesecK.'-'.$VdanK)){
                            $DatumK=new DateTime($VletoK.'-'.$VmesecK.'-'.$VdanK);
                        }else{
                            $DatumK=new DateTime($DanVpis->format('Y-m-d'));
                        }
                        $interval=$Datum->diff($DatumK);
                            
                        if (($interval->invert == 0) && ($interval->days >= 0)) {
                            $Indx=1;
                            while (($interval->invert == 0) && ($interval->days >= 0)){
                                //echo "Datum: ".$Datum->format('Y-m-d')." ".CheckPraznik($Datum)."<br />";
                                if ($VRubrika==48 ) {
                                    if (!((($Datum->format('w')+1)==1) or ($Datum->format('w')+1)==7)) {
                                        $VDan=$Datum->format('d');
                                        $VMesec=$Datum->format('m');
                                        $VPregledLeto=$Datum->format('Y');
                                        if ($VEnotPotrjeno == "false" ) {
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                        }else{
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                        }
                                        $result = mysqli_query($link,$SQL);
                                        if (!$result){
                                            die("Napaka pri vpisu podatkov: ".mysqli_error());
                                        }

                                        //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                        $Indx=$Indx+1;
                                    }
                                }else{
                                    //if ((CheckPraznik($Datum) != 1) && !((($Datum->format('w')+1)==1) or ($Datum->format('w')+1)==7) ) {
                                        $VDan=$Datum->format('d');
                                        $VMesec=$Datum->format('m');
                                        $VPregledLeto=$Datum->format('Y');
                                        if ($VEnotPotrjeno == "false" ) {
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                                        }else{
                                            $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                            $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                                        }
                                        $result = mysqli_query($link,$SQL);
                                        if (!$result){
                                            die("Napaka pri vpisu podatkov: ".mysqli_error());
                                        }

                                        //'?e je bolni?ka na prost dan, vpi?e plus ure zaradi zmanj?anja obveze
                                        $Indx=$Indx+1;
                                    //}
                                }
                                $Datum->add(new DateInterval('P1D'));
                                $interval=$Datum->diff($DatumK);
                            }
                        }else{
                            if ($VEnotPotrjeno == "false" ) {
                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas) VALUES ";
                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."')";
                            }else{
                                $SQL = "INSERT INTO tabpregleddelan (datum,leto,mesec,dan,rubrika,enot,DatVnosa,komentar,vpisal,Ucitelj,EnotPotrjeno,cas,potrdil) VALUES ";
                                $SQL = $SQL."('".$VPregledLeto."-".$VMesec."-".$VDan."',".$VPregledLeto.",".$VMesec.",".$VDan.",".$VRubrika.",".$Vcas.",'".$TimeStamp->format('Y-m-d')."','".$VMKomentar."','".$VUporabnik."',".$ucitelj.",".$VEnotPotrjeno.",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."')";
                            }
                            $result = mysqli_query($link,$SQL);
                            if (!$result){
                                die("Napaka pri vpisu podatkov: ".mysqli_error());
                            }
                        }
                }
                //echo $SQL."<br />";
                echo "<br><h2>Podatki SO vpisani!</h2><br>";
            }
        }else{    //popravljanje zapisa
            $SQL = "SELECT * FROM tabpregleddelan WHERE Id=" . $id;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                if ($VLevel < 2 ) {
                    $interval=$DanVpis->diff($Danes);
                    if (($interval->invert==0) && ($interval->days > ($MesecDni[$VMesec]+$RazlikaDniVpis) )) {
                        header("Location: staripodatki.htm");
                        $Prepovedano=true;
                    }
                }
                if (!$Prepovedano){
                    if ($VLevel < 2 ) {
                        $SQL = "UPDATE tabpregleddelan SET datum='".$VPregledLeto."-".$VMesec."-".$VDan."',leto=".$VPregledLeto.",mesec=".$VMesec.",dan=".$VDan.",rubrika=".$VRubrika.", enot=".$Vcas.",DatVnosa='".$TimeStamp->format('Y-m-d')."',komentar='".$VMKomentar."',vpisal='".$VUporabnik."',EnotPotrjeno=".$VEnotPotrjeno.",cas='".$Danes->format('Y-m-d H:i:s')."'  WHERE id=".$R["id"];
                    }else{
                        $SQL = "UPDATE tabpregleddelan SET datum='".$VPregledLeto."-".$VMesec."-".$VDan."',leto=".$VPregledLeto.",mesec=".$VMesec.",dan=".$VDan.",rubrika=".$VRubrika.", enot=".$Vcas.",DatVnosa='".$TimeStamp->format('Y-m-d')."',komentar='".$VMKomentar."',vpisal='".$VUporabnik."',EnotPotrjeno=".$VEnotPotrjeno.",cas='".$Danes->format('Y-m-d H:i:s')."',potrdil='".$VUporabnik."' WHERE id=".$R["id"];
                    }
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die("Napaka pri vpisu podatkov: ".mysqli_error());
                    }
                    echo "<br><h2>Podatki SO popravljeni/prepisani!</h2><br />";
                }
            }
        }

        if (!$Prepovedano){
            if ($EvidencaPrisotnosti > 0 ) {
                if ($id=="" ) {
                    $VDan=$DanVpis->format('d');
                    $VMesec=$DanVpis->format('m');
                    $VPregledLeto=$DanVpis->format('Y');
                    /*
                    VPregledleto = int($_POST["leto"))
                    Vmesec = int($_POST["mesec"))
                    Vdan = int($_POST["dan"))
                    */
                    if ($VLevel < 2 ) {
                        if (($VPregledLeto != $ActualYear) or ($VMesec != $ActualMonth) ) {
                            header("Location: staripodatki.htm");
                        }
                    }

                    switch ($VRubrika){
                        case 4:
                        case 14:
                        case 17:
                        case 27:
                        case 32:
                        case 33:
                        case 34:
                        case 35:
                        case 36:
                        case 37:
                        case 38:
                        case 39:
                        case 40:
                        case 41:
                        case 42:
                        case 43:
                        case 44:
                        case 45:
                            $SteviloDni=$Vcas;
                            echo "Število dni: ".$SteviloDni."<br />";
                            
                            $SQL = "SELECT * FROM Kadrovi WHERE emso='".$ucitelj."'";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $VDelavec=$R["STDELAVCA"];
                            }
                            $Datum=new DateTime($DanVpis->format('Y-m-d'));
                            
                            if (($SteviloDni > 1) && (isset($VDelavec)) ) {
                                $Indx=1;
                                while ($Indx <= $SteviloDni) {
                                        //echo "Datum: ".$Datum->format('Y-m-d')." ".CheckPraznik($Datum)."<br />";
                                        if ((CheckPraznik($Datum) != 1) && !(($Datum->format('w')+1==1) or ($Datum->format('w')+1==7)) ) {
                                            $VDan=$Datum->format('d');
                                            $VMesec=$Datum->format('m');
                                            $VPregledLeto=$Datum->format('Y');
                                            
                                            switch ($VRubrika){
                                                case 27:
                                                case 35:
                                                    $Odsotnost=5;
                                                    break;
                                                case 36:
                                                    $Odsotnost=6;
                                                    break;
                                                case 37:
                                                case 38:
                                                    $Odsotnost=7;
                                                    break;
                                                case 39:
                                                    $Odsotnost=14;
                                                    break;
                                                case 40:
                                                case 47:
                                                    $Odsotnost=15;
                                                    break;
                                                case 41:
                                                    $Odsotnost=10;
                                                    break;
                                                case 4:
                                                case 42:
                                                case 43:
                                                    $Odsotnost=1;
                                                    break;
                                                case 14:
                                                case 44:
                                                case 45:
                                                    $Odsotnost=9;
                                                    break;
                                                case 32:
                                                case 17:
                                                    $Odsotnost=2;
                                                    break;
                                                case 33:
                                                    $Odsotnost=13;
                                                    break;
                                                case 34:
                                                    $Odsotnost=16;
                                                    break;
                                            }
                                            
                                            $SQL = "INSERT INTO TabOdsotnost (stdelavca,odsotnoststart,odsotnostend,sifraodsotnosti) VALUES ";
                                            $SQL = $SQL . "('".$VDelavec."','".$Datum->format('Y-m-d')."','".$Datum->format('Y-m-d')."',".$Odsotnost.")";

                                            $result = mysqli_query($link,$SQL);
                                            if (!$result){
                                                die("Napaka pri vpisu podatkov: ".mysqli_error());
                                            }
                                            $Indx=$Indx+1;
                                        }
                                        $Datum->add(new DateInterval('P1D'));
                                }
                            }else{
                                switch ($VRubrika){
                                    case 27:
                                    case 35:
                                        $Odsotnost=5;
                                        break;
                                    case 36:
                                        $Odsotnost=6;
                                        break;
                                    case 37:
                                    case 38:
                                        $Odsotnost=7;
                                        break;
                                    case 39:
                                        $Odsotnost=14;
                                        break;
                                    case 40:
                                    case 47:
                                        $Odsotnost=15;
                                        break;
                                    case 41:
                                        $Odsotnost=10;
                                        break;
                                    case 4:
                                    case 42:
                                    case 43:
                                        $Odsotnost=1;
                                        break;
                                    case 14:
                                    case 44:
                                    case 45:
                                        $Odsotnost=9;
                                        break;
                                    case 32:
                                    case 17:
                                        $Odsotnost=2;
                                        break;
                                    case 33:
                                        $Odsotnost=13;
                                        break;
                                    case 34:
                                        $Odsotnost=16;
                                        break;
                                }
                                if (isset($VDelavec)){
                                    $SQL = "INSERT INTO TabOdsotnost (stdelavca,odsotnoststart,odsotnostend,sifraodsotnosti) VALUES ";
                                    $SQL = $SQL . "('".$VDelavec."','".$Datum->format('Y-m-d')."','".$Datum->format('Y-m-d')."',".$Odsotnost.")";

                                    $Indx=$Indx+1;
                                    $result = mysqli_query($link,$SQL);
                                    if (!$result){
                                        die("Napaka pri vpisu podatkov: ".mysqli_error());
                                    }
                                }
                            }
                       }
                    //echo $SQL."<br>";
                    echo "<br><h2>Podatki SO vpisani tudi v evidenco prihodov na delo!</h2><br />";
                }
            }
        }
//-------------------vpis - konec -----------------------------------------------------------------------------        
if (!$Prepovedano){
    if (isset($_POST["odkod"])){
        header("Location: PotrjevanjeRubrikPDN.php?mesec=$VMesec&leto=$VLeto");
    }else{
        header("Location: IzpisUcitelja.php?idUcitelj=".$ucitelj);
    }
}
?>

<br />
<a href="prijava.php">Nazaj na glavni meni</a><br />
<a href="pravilnik.htm">Pravilnik</a><br />
</body>
</html>
