<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis bolniških in porodniških odsotnosti
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("DelKontr",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }
        echo "<br />";
        echo "<a href='IzpisBolniskih.php?letopregled=".($VLetoPregled-1)."'>".($VLetoPregled-1)."</a> | <a href='IzpisBolniskih.php?letopregled=".($VLetoPregled+1)."'>".($VLetoPregled+1)."</a>";
        echo "<h2>Spisek bolniških in porodniških odsotnosti</h2>";
        $SQL = "SELECT tabpregleddelan.*,TabDoprinos.*,tabucitelji.*,tabpregleddelan.Komentar AS pkomentar,tabpregleddelan.id AS pid FROM (tabpregleddelan ";
        $SQL = $SQL . "INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos) ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON tabpregleddelan.Ucitelj=tabucitelji.idUcitelj ";
        //$SQL = $SQL . "WHERE tabpregleddelan.leto IN (".($VLetoPregled-1).",".$VLetoPregled.") AND (oblikadela LIKE '%boln%' OR (rubrika=25 AND tabpregleddelan.komentar LIKE '%bolni%'))";
        $SQL = $SQL . "WHERE tabpregleddelan.leto =$VLetoPregled AND (oblikadela LIKE '%boln%' OR (rubrika=25 AND tabpregleddelan.komentar LIKE '%bolni%'))";
        $SQL = $SQL ." ORDER BY priimek,ime,datum";
        $result = mysqli_query($link,$SQL);

        echo "<form accept-charset='utf-8' name='BrisanjeDela' method=post action='brisiPDN.php'>";
        echo "<input name='submit' type='submit' value='Briši'><br />";
        echo "<a name='spisek'><br><table border=1 cellspacing=0>";
        echo "<tr bgcolor='cyan'><th>Št.</th><th>Ime</th><th>Datum</th><th width='250'>Rubrika</th><th>Čas</th><th>DU</th><th width='250'>Komentar</th><th>Potrjeno</th><th>Popravi</th><th>Briši</th></tr>";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
	        switch ($R["aktivno"]){
		        case 1:
			        if ($R["EnotPotrjeno"] ){
				        if ($R["Rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightgreen'>";
				        }
			        }else{
				        if ($R["Rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightyellow'>";
				        }
			        }
                    break;
		        default:
				        if ($R["Rubrika"]==28 ){
					        echo "<tr bgcolor='red'>";
				        }else{
					        echo "<tr bgcolor='lightcyan'>";
				        }
	        }
	        echo "<td>".$Indx."</td>";
	        echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
            $Datum=new DateTime(isDate($R["Datum"]));
	        echo "<td>".$Datum->format('d.m.Y')."</td>";
	        echo "<td>".$R["OblikaDela"]."</td>";
	        if ($R["uramin"] > 1 ){
		        echo "<td>".$R["Enot"]." min</td>";
		        echo "<td>".$R["Enot"]/$R["uramin"]*$R["koeficient"]." ur</td>";
	        }else{
		        if ($R["koeficient"]==8 or $R["koeficient"]==0 ){
			        echo "<td>".$R["Enot"]." dni</td>";
			        echo "<td>".$R["Enot"]." dni</td>";
		        }else{
			        echo "<td>".$R["Enot"]." ur</td>";
			        echo "<td>".$R["Enot"]/$R["uramin"]*$R["koeficient"]." ur</td>";
		        }
	        }
	        echo "<td>".$R["pkomentar"]."</td>";
	        if ($R["EnotPotrjeno"] ){
		        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=0&Ucitelj=".$R["Ucitelj"]."'>da</a></td>";
	        }else{
		        echo "<td align=center><a href='PotrdiPDNRubriko.php?id=".$R["pid"]."&potrdi=1&Ucitelj=".$R["Ucitelj"]."'>ne</a></td>";
	        }
	        echo "<td><a href='IzpisUcitelja.php?id1=1&id=".$R["pid"]."&idUcitelj=".$R["Ucitelj"]."'>Popravi</a></td>";
	        echo "<td><input name='id' value='".$R["pid"]."' type='checkbox'></td>";
	        echo "</tr>";
	        $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<input name='submit' type='submit' value='Briši'>";
        echo "</form><br />";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>
</body>
</html>
