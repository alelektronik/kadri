<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prostori
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
 //   echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Prostori",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
    case "2":
    case "4":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

switch ($Vid){
	case "1": // 'vnos prostorov
		$SQL = "SELECT * FROM tabprostor ORDER BY Stevilka,Opis";
		$result = mysqli_query($link,$SQL);
		
		echo "<h2>Vnos prostorov</h2>";
		echo "<form name='Predmeti' method='post' action='Prostori.php'>";
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Prostor - opis</th><th>Številka</th><th>Oznaka</th><th>št. miz</th><th>Popravi</th></tr>";
		
		echo "<tr>";
		echo "<td>&nbsp;</td>";
		echo "<td><input name='opis' type='text' size='50'></td>";
		echo "<td><input name='stevilka' type='text' size='5'></td>";
		echo "<td><input name='oznaka' type='text' size='5'></td>";
		echo "<td><input name='StMiz' type='text' size='4'></td>";
		echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
		echo "</tr>";

		$indx=1;
        while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td>".$R["Opis"]."</td>";
			echo "<td>".$R["Stevilka"]."</td>";
			echo "<td>".$R["Oznaka"]."</td>";
			echo "<td>".$R["StMiz"]."</td>";
			echo "<td><a href='Prostori.php?id=3&zapis=".$R["Id"]."'>Popravi</a></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='2'>";
		echo "</form>";
        break;
	case "2": // 'vpis zapisa
		$SQL = "SELECT * FROM tabprostor WHERE Opis='".$_POST["opis"]."' AND stevilka='".$_POST["stevilka"]."' AND oznaka='".$_POST["oznaka"]."'";
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			echo "Ta prostor že obstaja!<br />";
		}else{
			$SQL = "SELECT * FROM tabprostor ORDER BY IdProstor DESC";
			$result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
				$VidProstor=$R["IdProstor"]+1;
			}else{
				$VidProstor=0;
				$SQL = "INSERT INTO tabprostor (idProstor,Stevilka,oznaka,opis,Stmiz) VALUES (0,'000','Nedol','Nedoločen',0)";
				$result = mysqli_query($link,$SQL);
				$VidProstor=1;
			}
			$SQL = "INSERT INTO tabprostor (idProstor,Stevilka,oznaka,opis,Stmiz) VALUES (".$VidProstor.",'".$_POST["stevilka"]."','".$_POST["oznaka"]."','".$_POST["opis"]."',".$_POST["StMiz"].")";
			$result = mysqli_query($link,$SQL);
		}
		
		header ("Location: Prostori.php?id=1");
        break;
	case "3":   //popravljanje zapisa
		$SQL = "SELECT * FROM tabprostor WHERE id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			echo "<h2>Vnos prostorov</h2>";
			echo "<form name='Predmeti' method='post' action='Prostori.php'>";
			echo "<table border='1'>";
			echo "<tr><th>Št.</th><th>Prostor - opis</th><th>številka</th><th>Oznaka</th><th>št. miz</th><th>Popravi</th></tr>";
			
			echo "<tr>";
			echo "<td>&nbsp;</td>";
			echo "<td><input name='opis' type='text' size='50' value='".$R["Opis"]."'></td>";
			echo "<td><input name='stevilka' type='text' size='5' value='".$R["Stevilka"]."'></td>";
			echo "<td><input name='oznaka' type='text' size='5' value='".$R["Oznaka"]."'></td>";
			echo "<td><input name='StMiz' type='text' size='4' value='".$R["StMiz"]."'></td>";
			echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
			echo "</tr>";
			echo "</table>";
			echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
			echo "<input name='id' type='hidden' value='4'>";
			echo "</form>";
		}
		break;
	case "4":  //vpis popravka
		$SQL = "SELECT * FROM tabprostor WHERE id=".$_POST["zapis"];
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			$SQL = "UPDATE tabprostor SET opis='".$_POST["opis"]."',oznaka='".$_POST["oznaka"]."',stevilka='".$_POST["stevilka"]."',Stmiz=".$_POST["StMiz"]." WHERE id=".$R["Id"];
			$result = mysqli_query($link,$SQL);
		}
		
		header ("Location: Prostori.php?id=1");
}
?>

</body>
</html>
