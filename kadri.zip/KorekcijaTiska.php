<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat_1",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
    };
</script>
<script>
 function showKorekcija()
 {
/* if (str=="")
   {
   document.getElementById("txtHint").innerHTML="";
   return;
   } 
*/
 var klasif=document.getElementById("klasif").value;
/*
 var pozx=document.getElementByName("koordinatax").value;
 var pozy=document.getElementByName("koordinatay").value;
 var datum=document.getElementByName("datum").value;
 var opomba=document.getElementByName("KorOpombe").value;
 */

 if (window.XMLHttpRequest)
   {// code for IE7+, Firefox, Chrome, Opera, Safari
   xmlhttp=new XMLHttpRequest();
   }
 else
   {// code for IE6, IE5
   xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
   }
 xmlhttp.onreadystatechange=function()
   {
   if (xmlhttp.readyState==4 && xmlhttp.status==200)
     {
     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
     }
   }
 xmlhttp.open("GET","getkorekcija.php?klasif="+klasif,true);
 xmlhttp.send();
 }
 </script>
<title>Korekcija tiska
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}
/*
if (isset($_SESSION["klasifikacija"])){
    $Klasifikacija = $_SESSION["klasifikacija"];
}else{
    $Klasifikacija = "";
}
*/

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}
switch ($id){
	case "1":
		$KorX=$_POST["koordinatax"];
		$KorY=$_POST["koordinatay"];
		$RefStFix=$_POST["RefStFix"];
		$RefStVar=$_POST["RefStVar"];
		$PrintDay=$_POST["datum"];
		$KorOpombe=$_POST["KorOpombe"];
        /*
        $Klasifikacija=$_POST["klasif"];
        if (strlen($RefStFix) == 0){
            $RefStFix=$Klasifikacija;
        }
        */
		$_SESSION["posx"]=$KorX;
		$_SESSION["posy"]=$KorY;
		$_SESSION["RefStFix"]=$RefStFix;
		$_SESSION["RefStVar"]=$RefStVar;
		$_SESSION["DayToPrint"]=$PrintDay;
		$_SESSION["KorOpombe"]=$KorOpombe;
        //$_SESSION["klasifikacija"]=$Klasifikacija;
		echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
        break;
	default:	
		if ($KorX==""){
            $KorX=0;
        }
		if ($KorY==""){
            $KorY=0;
        }
		if ($PrintDay=="") {
            $PrintDay=$Danes->format('j.n.Y');
        }
		$_SESSION["posx"]=$KorX;
		$_SESSION["posy"]=$KorY;
		$_SESSION["RefStFix"]=$RefStFix;
		$_SESSION["RefStVar"]=$RefStVar;
		$_SESSION["DayToPrint"]=$PrintDay;
		$_SESSION["KorOpombe"]=$KorOpombe;
        if (isset($Klasifikacija)){
            $_SESSION["klasifikacija"]=$Klasifikacija;
        }
}
echo "<form name='rezultati' method=post action='KorekcijaTiska.php'>";
echo "<h2>Izberite korekcijo</h2><br />";
echo "<table border='0'>";
echo "<tr>";
echo "	<td>";
echo "		izpis višje(+)/nižje(-) mm:";
echo "		<input name='koordinatay' type='text' size='6' value='".$KorY."'>";
echo "	</td>";
echo "</tr>";
echo "<tr>";
echo "	<td>";
echo "		izpis bolj desno(+)/levo(-) mm:";
echo "		<input name='koordinatax' type='text' size='6' value='".$KorX."'>";
echo "	</td>";
echo "</tr>";
echo "<tr>";
if (strstr($PrintDay,".")) { 
    $astr=explode(".",$PrintDay);
    $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
}else{
    $Datum  = new DateTime($Danes->format('Y-m-d'));
}
echo "		<td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
echo "</tr>";
echo "<tr>";
echo "		<td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'>";
//klasifikacija
/*
echo "<select id='klasif' name='klasif' onchange='showKorekcija()'>";
echo "<option value=''>Če bo fiksni del prazen, se bo upošteval ta spustni seznam</option>";
$SQL = "SELECT znak,znakopis3,opis,obrazlozitev FROM klasifikacija WHERE aktivno=1 ORDER BY id";
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    echo "<option value='".$R["znak"]."'>";
    echo $R["znak"]." - ";
    if (isset($R["znakopis3"])){
        echo $R["znakopis3"]." / ";
    }
    echo $R["opis"];
    if (isset($R["obrazlozitev"])){
        if (mb_strlen($R["obrazlozitev"]) > 40){
            echo " (".mb_strcut($R["obrazlozitev"],0,40,$encoding)."...)";
        }else{
            echo " (".$R["obrazlozitev"].")";
        }
    }
    echo "</option>";
}
echo "</select>";
*/
echo "</td>";
echo "</tr>";
echo "<tr>";
echo "		<td><div id='txtHint'>Ref. št. (spremenljivi del): <input id='RefStVar' name='RefStVar' type='text' size='5'value='". $RefStVar ."'></div></td>";
echo "</tr>";
echo "<tr>";
echo "		<td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
echo "</tr>";
echo "<tr>";
echo "	<td>";
echo "		<input name='id' type='hidden' value='1'>";
echo "		<input name='submit' type='submit' value='Pošlji'>";
echo "	</td>";
echo "</tr>";
echo "</table>";
echo "</form>";
?>
</body>
</html>
