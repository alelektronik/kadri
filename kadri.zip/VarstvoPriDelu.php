<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Varstvo pri delu
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    $VLetoPregled=$VLeto;

    switch ($Vid){
        case "1":   //popravljanje in dodajanje zapisa
            for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
                if (isset($_POST["VarstvoDelo".$Indx]) ){
                    if (isset($_POST["PeriodaVD".$Indx])){
                        $PeriodaVD=$_POST["PeriodaVD".$Indx];
                    }else{
                        $PeriodaVD=4;
                    }
                    $SQL = "UPDATE tabucitelji SET PeriodaVD=".$PeriodaVD.", VarstvoDelo='".$_POST["VarstvoDelo".$Indx]."' WHERE idUcitelj=".$_POST["ucitelj".$Indx];
                    $result = mysqli_query($link,$SQL);
                    
                    $SQL = "SELECT * FROM TabVarstvoDelo WHERE idUcitelj=".$_POST["ucitelj".$Indx]." AND datum='".$_POST["VarstvoDelo".$Indx]."'";
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $PeriodaVD=$PeriodaVD;
                    }else{
                        $SQL = "INSERT INTO TabVarstvoDelo (idUcitelj,datum) VALUES (".$_POST["ucitelj".$Indx].",'".$_POST["VarstvoDelo".$Indx]."')";
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }
            break;
        case "2":
            $SQL = "SELECT tabucitelji.*,TabVarstvoDelo.* FROM tabucitelji INNER JOIN TabVarstvoDelo ON tabucitelji.idUcitelj=TabVarstvoDelo.idUcitelj ";
            $SQL = $SQL . "WHERE tabucitelji.idUcitelj=".$_GET["delavec"];
            $result = mysqli_query($link,$SQL);
            
            echo "<br><table border='1'>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Izpiti varstva pri delu</th></tr>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
                echo "<td align='right'>".$R["datum"]."</td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            break;
        case "3":
            $SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
            $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
            $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.Status < 10 ";
            $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
            //Response.Write "<br>" & SQL & "<br>"
            $result = mysqli_query($link,$SQL);

            $Indx=1;

            echo "<h2>Pregled delavcev z opravljenimi izpiti iz varstva pri delu</h2>";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
            echo "<th>Star</th>";
            echo "<th>Opis dela</th><th>Ponavljanje<br>pregledov (let)</th><th>Zadnji izpit<br>varstva pri delu</th>";
            echo "</tr>";
            $ColorChange=true;

            while ($R = mysqli_fetch_array($result)){
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
                if ($ColorChange ){
                    if (!isDate($oUcitelj->getVarstvoDelo()) ){
                        echo "<tr bgcolor='lightsalmon'>";
                    }else{
                        if (! is_numeric($oUcitelj->getPeriodaVD()) ){
                            $PeriodaVD=4;
                        }else{
                            $PeriodaVD=$oUcitelj->getPeriodaVD();
                        }
                        $Datum=new DateTime(isDate($oUcitelj->getVarstvoDelo()));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaVD*365)){
                            echo "<tr bgcolor='lightsalmon'>";
                        }else{
                            echo "<tr bgcolor='lightyellow'>";
                        }
                    }
                }else{
                    if (!isDate($oUcitelj->getVarstvoDelo()) ){
                        echo "<tr bgcolor='lightsalmon'>";
                    }else{
                        if (! is_numeric($oUcitelj->getPeriodaVD()) ){
                            $PeriodaVD=4;
                        }else{
                            $PeriodaVD=$oUcitelj->getPeriodaVD();
                        }
                        $Datum=new DateTime(isDate($oUcitelj->getVarstvoDelo()));
                        $Interval=$Datum->diff($Danes);
                        if (($Interval->invert == 0) && ($Interval->days > $PeriodaVD*365)){
                            echo "<tr bgcolor='lightsalmon'>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC>";
                        }
                    }
                }
                $ColorChange=!$ColorChange;
                echo "<td>".$Indx."</td>";
                echo "<td>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</td>";
                echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
                echo "<td>";
                echo "<b>".$oUcitelj->getDelMesto()."</b>";
                echo "&nbsp;</td>";
                echo "<td align='center'>".$oUcitelj->getPeriodaVD()."</td>";
                echo "<td align='right'>".$oUcitelj->getVarstvoDelo()."</td>";
                echo "</tr>";
                $oUcitelj=null;
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            break;
    }
    $SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
    $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
    $SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.Status < 10 ";
    $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
    //Response.Write "<br>" & SQL & "<br>"
    $result = mysqli_query($link,$SQL);

    $Indx=1;

    echo "<h2>Pregled delavcev z opravljenimi izpiti iz varstva pri delu</h2>";
    echo "<form name='form_VarstvoDelo' method='post' action='VarstvoPriDelu.php'>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "<table border=1 cellspacing=0>";
    echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
    echo "<th>Star</th>";
    echo "<th>Opis dela</th><th>Ponavljanje<br>pregledov (let)</th><th>Zadnji izpit<br>varstva pri delu</th>";
    echo "</tr>";
    $ColorChange=true;

    while ($R = mysqli_fetch_array($result)){
        $oUcitelj=new RUcitelj();
        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
        if ($ColorChange ){
            if (!isDate($oUcitelj->getVarstvoDelo()) ){
                echo "<tr bgcolor='lightsalmon'>";
            }else{
                if (! is_numeric($oUcitelj->getPeriodaVD()) ){
                    $PeriodaVD=4;
                }else{
                    $PeriodaVD=$oUcitelj->getPeriodaVD();
                }
                $Datum=new DateTime(isDate($oUcitelj->getVarstvoDelo()));
                $Interval=$Datum->diff($Danes);
                if (($Interval->invert == 0) && ($Interval->days > $PeriodaVD*365)){
                    echo "<tr bgcolor='lightsalmon'>";
                }else{
                    echo "<tr bgcolor='lightyellow'>";
                }
            }
        }else{
            if (!isDate($oUcitelj->getVarstvoDelo()) ){
                echo "<tr bgcolor='lightsalmon'>";
            }else{
                if (! is_numeric($oUcitelj->getPeriodaVD()) ){
                    $PeriodaVD=4;
                }else{
                    $PeriodaVD=$oUcitelj->getPeriodaVD();
                }
                $Datum=new DateTime(isDate($oUcitelj->getVarstvoDelo()));
                $Interval=$Datum->diff($Danes);
                if (($Interval->invert == 0) && ($Interval->days > $PeriodaVD*365)){
                    echo "<tr bgcolor='lightsalmon'>";
                }else{
                    echo "<tr bgcolor=#FFFFCC>";
                }
            }
        }
        $ColorChange=!$ColorChange;
        echo "<td>".$Indx."</td>";
        echo "<td><input name='ucitelj".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'><a href='VarstvoPriDelu.php?id=2&delavec=".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
        echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
        echo "<td>";
        echo "<b>".$oUcitelj->getDelMesto()."</b>";
        echo "&nbsp;</td>";
        echo "<td><input name='PeriodaVD".$Indx."' type='text' value='".$oUcitelj->getPeriodaVD()."' size='3'></td>";
        echo "<td><input name='VarstvoDelo".$Indx."' type='text' value='".$oUcitelj->getVarstvoDelo()."' size='8'></td>";
        echo "</tr>";
        $oUcitelj=null;
	    $Indx=$Indx+1;
    }
    echo "</table>";
    echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
    echo "<input name='id' type='hidden' value='1'>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form><br />";
    echo "<a href='VarstvoPriDelu.php?id=3'>Izpis primeren za Excel</a>";
}
?>

</body>
</html>
