<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}
if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izjave
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>
<?php

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Obdelava=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Obdelava=$_GET["id"];
    }else{
        $Obdelava="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

select case Obdelava
    case "1": //'izbor prostora
        response.write "<h2>Vnos učnih pripomočkov - izbor prostora</h2>"
        Response.Write "<form accept-charset='utf-8' name='Inventura' method=post action='VnosUcniPripomocki.asp'>"
        response.write "<table border=1>"
        response.write "<tr><td>Prostor</td><td><select name='prostor'>"
        
        SQL = "SELECT * FROM tabprostor ORDER BY Opis"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                response.write "<option value='"&R("idProstor")&"'>"&R("opis")&" - "&R("Stevilka")&"</option>"
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select></td></tr>"
        response.write "</table>"
        Response.Write "<input name='id' type='hidden' value='2'>"
        Response.Write "<input name='submit' type='submit' value='Pošlji'>"
        response.write "</form>"
        break;
    case "2": //'vnos osnovnih sredstev
        VidProstor=request("prostor")
        response.write "<h2>Vnos učnih pripomočkov - dodajanje inventarja v prostor</h2>"
        Response.Write "<form accept-charset='utf-8' name='Inventura' method=post action='VnosUcniPripomocki.asp'>"
        response.write "<table border=1>"
        SQL = "SELECT * FROM tabprostor WHERE idProstor="&VidProstor
        set R = conn.execute(SQL,,adcmdtext)
        
        if NOT R.EOF then
            VProstor=R("Opis")&" - "&R("Stevilka")
        end if
        
        response.write "<tr><th>Prostor</th><th>Inventar</th></tr>"
        response.write "<tr><td>"&VProstor&"</td>"
        response.write "<td><select name='OsnSredstvo'>"
        
        SQL = "SELECT DISTINCT OsnSredstvo,DatumVpisa FROM TabUcniPripomocki WHERE idProstor = 0 ORDER BY OsnSredstvo"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                response.write "<option>"&R("OsnSredstvo")&" datum: "&R("DatumVpisa")&"</option>"
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        
        response.write "</select></td>"
        response.write "</tr>"
        response.write "</table><br>"
        Response.Write "<input name='id' type='hidden' value='3'>"
        Response.Write "<input name='prostor' type='hidden' value='"&VidProstor&"'>"
        Response.Write "<input name='submit' type='submit' value='Pošlji'>"
        response.write "</form>"
        break;
    case "3": // 'vpis zapisa
        VidProstor=request("prostor")
        VOsnSredstvo=request("OsnSredstvo")
        if InStr(VOsnSredstvo," datum: ")-1 > 0 then 
            s1=left(VosnSredstvo,InStr(VOsnSredstvo," datum: ")-1)
            s2=right(VosnSredstvo,len(VOsnSredstvo)-InStr(VOsnSredstvo," datum: ")-7)
        else
            s1=" "
            s2=" "
        end if
        
        
        SQL = "SELECT * FROM tabprostor WHERE idProstor="&VidProstor
        set R = conn.execute(SQL,,adcmdtext)
        
        if NOT R.EOF then
            VProstor=R("Opis")&" - "&R("Stevilka")
        end if

        SQL = "SELECT * FROM TabUcniPripomocki WHERE OsnSredstvo='"&s1&"' AND datumVpisa='"&s2&"' AND idProstor=0"
        set R = conn.execute(SQL,,adcmdtext)
        
        if NOT R.EOF then
            SQL = "UPDATE TabUcniPripomocki SET idProstor="&VidProstor&",status=1 WHERE id="&R("id")
            set R = conn.execute(SQL,,adcmdtext)
            response.write SQL&"<br>"
        else
            response.write "<h2>Zapisa ne morem prirediti!</h2>"
        end if
        conn.close
        Set Conn=nothing
        response.redirect "VnosUcniPripomocki.asp?id=2&prostor="&VidProstor
        break;
    case "4":
        SQL = "SELECT TabUcniPripomocki.*,tabprostor.*,TabInvStat.*,tabucitelji.*,TabUcniPripomocki.Status AS ustatus,TabUcniPripomocki.idProstor AS uidProstor FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "WHERE TabUcniPripomocki.id="&request("Zapis")
        set R = conn.execute(SQL,,adcmdtext)
        
        if NOT R.EOF then
            VOsnSredstvo=R("OsnSredstvo")
            VInvSt=R("InvSt")
            VDodatniOpis=R("DodatniOpis")
            VStatus=R("uStatus")
            VDatumInv=R("DatumInv")
            VidProstor=R("uidProstor")
            Vopomba=R("Opomba")
            VdatumVpisa=R("DatumVpisa")
            VPrevzel=R("prevzel")
            VDatumPrevzem=R("DatumPrevzem")
            
            Response.Write "<form accept-charset='utf-8' name='Inventura' method=post action='VnosUcniPripomocki.asp'>"
            response.write "<table border=0>"
            response.write "<tr><td>Prostor</td><td>"
            response.write "<select name='prostor'>"
            SQL = "SELECT * FROM tabprostor ORDER BY Opis"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("idProstor")=VidProstor then
                        response.write "<option value='"&R("idProstor")&"' selected>"&R("opis")&" - "&R("Stevilka")&"</option>"
                    else
                        response.write "<option value='"&R("idProstor")&"'>"&R("opis")&" - "&R("Stevilka")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td>Učni pripomoček</td><td><input name='OsnSredstvo' type='text' value='"&VOsnSredstvo&"' size='60'></td></tr>"
            response.write "<tr><td>Dodatni opis</td><td><input name='DodatniOpis' type='text' value='"&VDodatniOpis&"' size='40'></td></tr>"
            response.write "<tr><td>Datum vpisa</td><td>"&VDatumVpisa&"</td></tr>"
            response.write "<tr><td>Datum inventure</td><td><input name='DatumInv' type='text' value='"&VDatumInv&"' size='10'></td></tr>"
            response.write "<tr><td>Status</td><td>"
            response.write "<select name='Status'>"
            SQL = "SELECT * FROM TabInvStat"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("StatusInv")=VStatus then
                        response.write "<option value='"&R("StatusInv")&"' selected>"&R("opis")&"</option>"
                    else
                        response.write "<option value='"&R("StatusInv")&"'>"&R("opis")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td>Opomba</td><td><input name='Opomba' type='text' value='"&VOpomba&"' size='40'></td></tr>"
            response.write "<tr><td>Prevzel</td><td>"
            response.write "<select name='prevzel'>"
            SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY Priimek,Ime"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("idUcitelj")=VPrevzel then
                        response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                    else
                        response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td>Datum prevzema</td><td><input name='DatumPrevzem' type='text' value='"&VDatumPrevzem&"' size='10'></td></tr>"
            response.write "</table>"
            Response.Write "<input name='id' type='hidden' value='7'>"
            Response.Write "<input name='zapis' type='hidden' value='"&request("Zapis")&"'>"
            Response.Write "<input name='submit' type='submit' value='Pošlji'>"
            response.write "</form>"
        end if
        break;
    case "5":
        SQL = "SELECT TabUcniPripomocki.* FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "WHERE TabUcniPripomocki.id="&request("Zapis")
        set R = conn.execute(SQL,,adcmdtext)

        if NOT R.EOF then
            VidProstor=R("idProstor")
        end if
        
        SQL = "UPDATE TabUcniPripomocki SET idProstor=0,status=0,prevzel=0,datumPrevzem='',"
        SQL = SQL & "vpisal='"&VUporabnik&"',"
        SQL = SQL & "cas='"&year(now)&"-"&month(now)&"-"&day(now)&" "&hour(now)&":"&minute(now)&":"&second(now)&"' "
        SQL = SQL & "WHERE id="&request("Zapis")
        set R = conn.execute(SQL,,adcmdtext)
        
        response.write "<h2>Učni pripomoček je bil umaknjen iz prostora!</h2>"
        conn.close
        Set Conn=nothing
        response.redirect "VnosUcniPripomocki.asp?id=2&prostor="&VidProstor
        break;
    case "6":
        SQL = "SELECT TabUcniPripomocki.*,tabprostor.*,TabInvStat.*,tabucitelji.*,tabprostor.opis AS popis,TabinvStat.Opis AS iopis,TabUcniPripomocki.id AS uid FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "WHERE "
        SQL = SQL & "tabprostor.opis LIKE '%"&request("iskanje")&"%' OR "
        SQL = SQL & "TabInvStat.opis LIKE '%"&request("iskanje")&"%' OR "
        SQL = SQL & "TabUcniPripomocki.OsnSredstvo LIKE '%"&request("iskanje")&"%' OR "
        SQL = SQL & "TabUcniPripomocki.DodatniOpis LIKE '%"&request("iskanje")&"%' OR "
        SQL = SQL & "TabUcniPripomocki.InvSt LIKE '%"&request("iskanje")&"%' OR "
        SQL = SQL & "TabUcniPripomocki.Opomba LIKE '%"&request("iskanje")&"%' "
        SQL = SQL & " ORDER BY OsnSredstvo"
        set R = conn.execute(SQL,,adcmdtext)

        response.write "<h3>Učni pripomočki - "&request("iskanje")&"</h3>"
        Response.Write "<form accept-charset='utf-8' name='prevzemnica' method=post action='PrevzemnicaUPPDF.asp'>"
        response.write "<table border=1>"
        response.write "<tr><th>št.</th><th>Prostor</th><th>Inv. št.</th><th>Inventar</th><th>Dodatni opis</th><th>Datum vpisa</th><th>Status</th><th>Opomba</th><th>Prevzel</th><th>Datum prevzema</th><th>Podpisana<br>prevzemnica</th><th>Vključi na<br>prevzemnico</th><th>Popravi</th><th>Briši</th></tr>"
        Indx=1
        Do
            if NOT R.EOF then
                response.write "<tr>"
                response.write "<td>"&indx&"</td>"
                response.write "<td>"&R("popis")&" - "&R("Stevilka")&"</td>"
                response.write "<td>"&R("InvSt")&"</td>"
                response.write "<td>"&R("OsnSredstvo")&"</td>"
                response.write "<td>"&R("DodatniOpis")&"</td>"
                response.write "<td>"&R("DatumVpisa")&"</td>"
                response.write "<td>"&R("iOpis")&"</td>"
                response.write "<td>"&R("opomba")&"</td>"
                response.write "<td>"&R("priimek")&" "&R("ime")&"</td>"
                response.write "<td>"&R("DatumPrevzem")&"</td>"
                response.write "<td><a href='"&R("Prevzemnica")&"' target='_blank'>"&R("Prevzemnica")&"</a></td>"
                response.write "<td><input name='zap"&indx&"' type='hidden' value='"&R("uid")&"'><input name='TvoriPrevzemnico"&Indx&"' type='checkbox'></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=4&zapis="&R("uid")&"'>Popravi</a></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=5&zapis="&R("uid")&"'>Briši</a></td>"
                response.write "</tr>"
            else
                Exit Do
            end if
            R.MoveNext
            Indx=Indx+1
        Loop
        response.write "</table><br>"
        Response.Write "<input name='StPrevz' type='hidden' value='"&Indx-1&"'>"
        Response.Write "<input name='submit' type='submit' value='Tvori prevzemnico'>"
        response.write "</form><br>"
        response.write "<a href='VnosUcniPripomocki.asp?id=1'>Izbira prostora</a><br>"

        Response.Write "<form accept-charset='utf-8' name='Iskanje' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Iskalni niz: <input name='iskanje' type='text' size='30'>"
        Response.Write "<input name='id' type='hidden' value='6'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form><br>"
        Response.Write "<form accept-charset='utf-8' name='IskanjePrevzemnik' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Išči po prevzemnikih: "
        response.write "<select name='prevzel'>"
        SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                if R("idUcitelj")=VPrevzel then
                    response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                else
                    response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                end if
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select>"
        Response.Write "<input name='id' type='hidden' value='61'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form>"
        break;
    case "61":
        SQL = "SELECT TabUcniPripomocki.*,tabprostor.*,TabInvStat.*,tabucitelji.*,tabprostor.opis AS popis,TabinvStat.Opis AS iopis,TabUcniPripomocki.id AS uid FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "WHERE "
        SQL = SQL & "idUcitelj="&request("prevzel")
        SQL = SQL & " ORDER BY OsnSredstvo"
        set R = conn.execute(SQL,,adcmdtext)

        response.write "<h3>Učni pripomočki - po prevzemnikih</h3>"
        Response.Write "<form accept-charset='utf-8' name='prevzemnica' method=post action='PrevzemnicaUPPDF.asp'>"
        response.write "<table border=1>"
        response.write "<tr><th>št.</th><th>Prostor</th><th>Inv. št.</th><th>Inventar</th><th>Dodatni opis</th><th>Datum vpisa</th><th>Status</th><th>Opomba</th><th>Prevzel</th><th>Datum prevzema</th><th>Podpisana<br>prevzemnica</th><th>Vključi na<br>prevzemnico</th><th>Popravi</th><th>Briši</th></tr>"
        Indx=1
        Do
            if NOT R.EOF then
                response.write "<tr>"
                response.write "<td>"&indx&"</td>"
                response.write "<td>"&R("popis")&" - "&R("Stevilka")&"</td>"
                response.write "<td>"&R("InvSt")&"</td>"
                response.write "<td>"&R("OsnSredstvo")&"</td>"
                response.write "<td>"&R("DodatniOpis")&"</td>"
                response.write "<td>"&R("DatumVpisa")&"</td>"
                response.write "<td>"&R("iOpis")&"</td>"
                response.write "<td>"&R("opomba")&"</td>"
                response.write "<td>"&R("priimek")&" "&R("ime")&"</td>"
                response.write "<td>"&R("DatumPrevzem")&"</td>"
                response.write "<td><a href='"&R("Prevzemnica")&"' target='_blank'>"&R("Prevzemnica")&"</a></td>"
                response.write "<td><input name='zap"&indx&"' type='hidden' value='"&R("uid")&"'><input name='TvoriPrevzemnico"&Indx&"' type='checkbox'></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=4&zapis="&R("uid")&"'>Popravi</a></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=5&zapis="&R("uid")&"'>Briši</a></td>"
                response.write "</tr>"
            else
                Exit Do
            end if
            R.MoveNext
            Indx=Indx+1
        Loop
        response.write "</table><br>"
        Response.Write "<input name='StPrevz' type='hidden' value='"&Indx-1&"'>"
        Response.Write "<input name='submit' type='submit' value='Tvori prevzemnico'>"
        response.write "</form><br>"
        response.write "<a href='VnosUcniPripomocki.asp?id=1'>Izbira prostora</a><br>"

        Response.Write "<form accept-charset='utf-8' name='Iskanje' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Iskalni niz: <input name='iskanje' type='text' size='30'>"
        Response.Write "<input name='id' type='hidden' value='6'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form><br>"
        Response.Write "<form accept-charset='utf-8' name='IskanjePrevzemnik' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Išči po prevzemnikih: "
        response.write "<select name='prevzel'>"
        SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                if R("idUcitelj")=VPrevzel then
                    response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                else
                    response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                end if
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select>"
        Response.Write "<input name='id' type='hidden' value='61'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form>"
        break;
    case "7":
        VidProstor=request("prostor")
        SQL = "UPDATE TabUcniPripomocki SET "
        SQL = SQL & "idProstor="&request("prostor")&","
        SQL = SQL & "OsnSredstvo='"&request("OsnSredstvo")&"',"
        SQL = SQL & "DodatniOpis='"&request("DodatniOpis")&"',"
        SQL = SQL & "DatumInv='"&request("DatumInv")&"',"
        SQL = SQL & "Status="&request("Status")&","
        SQL = SQL & "Opomba='"&request("Opomba")&"',"
        SQL = SQL & "Prevzel="&request("Prevzel")&","
        SQL = SQL & "DatumPrevzem='"&request("DatumPrevzem")&"',"
        SQL = SQL & "vpisal='"&VUporabnik&"',"
        SQL = SQL & "cas='"&year(now)&"-"&month(now)&"-"&day(now)&" "&hour(now)&":"&minute(now)&":"&second(now)&"' "
        SQL = SQL & "WHERE id="&request("Zapis")
        set R = conn.execute(SQL,,adcmdtext)
        
        response.write "<h2>Učni pripomoček je bil popravljen!</h2>"
        conn.close
        Set Conn=nothing
        response.redirect "VnosUcniPripomocki.asp?id=2&prostor="&VidProstor
        break;
    case "8":
            response.write "<p>"
            response.write "Navodilo:<br>"
            response.write "Za vpis večih enakih artiklov vpišite v rubriko <b>Količina</b> število komadov.<br>"
            response.write "</p>"
            VOsnSredstvo=""
            VInvSt=""
            VDodatniOpis=""
            VStatus=1
            VDatumInv=day(now)&"."&month(now)&"."&year(now)
            VidProstor=0
            Vopomba=""
            VPrevzel=0
            VDatumPrevzem=day(now)&"."&month(now)&"."&year(now)
            VKolicina=1
            VdatumVpisa=day(now)&"."&month(now)&"."&year(now)
            
            SQL = "SELECT * FROM TabUcniPripomocki ORDER BY InvSt DESC LIMIT 0,1 "
            set R = conn.execute(SQL,,adcmdtext)
            if NOT R.EOF then
                VInvSt=int(R("InvSt"))+1
            end if
            
            if NOT isNumeric(VInvST) then
                VInvSt=3000000
            end if
            
            Response.Write "<form accept-charset='utf-8' name='Inventura' method=post action='VnosUcniPripomocki.asp'>"
            response.write "<table border=0>"
            response.write "<tr><td>Prostor</td><td>"
            response.write "<select name='prostor'>"
            SQL = "SELECT * FROM tabprostor ORDER BY Opis"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("idProstor")=VidProstor then
                        response.write "<option value='"&R("idProstor")&"' selected>"&R("opis")&" - "&R("Stevilka")&"</option>"
                    else
                        response.write "<option value='"&R("idProstor")&"'>"&R("opis")&" - "&R("Stevilka")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td><input name='InvSt' type='hidden' size='6' value='"&VInvSt&"'>Učni pripomoček</td><td><input name='OsnSredstvo' type='text' value='"&VOsnSredstvo&"' size='60'></td></tr>"
            response.write "<tr><td>Dodatni opis</td><td><input name='DodatniOpis' type='text' value='"&VDodatniOpis&"' size='40'></td></tr>"
            response.write "<tr><td>Datum vpisa</td><td>"&VDatumVpisa&"</td></tr>"
            response.write "<tr><td>Datum inventure</td><td><input name='DatumInv' type='text' value='"&VDatumInv&"' size='10'></td></tr>"
            response.write "<tr><td>Status</td><td>"
            response.write "<select name='Status'>"
            SQL = "SELECT * FROM TabInvStat"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("StatusInv")=VStatus then
                        response.write "<option value='"&R("StatusInv")&"' selected>"&R("opis")&"</option>"
                    else
                        response.write "<option value='"&R("StatusInv")&"'>"&R("opis")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td>Opomba</td><td><input name='Opomba' type='text' value='"&VOpomba&"' size='40'></td></tr>"
            
            response.write "<tr><td>Prevzel</td><td>"
            response.write "<select name='prevzel'>"
            SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
            set R = conn.execute(SQL,,adcmdtext)
            
            Do
                if NOT R.EOF then
                    if R("idUcitelj")=VPrevzel then
                        response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                    else
                        response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                    end if
                else
                    Exit Do
                end if
                R.MoveNext
            Loop
            response.write "</select>"
            response.write "</td></tr>"
            response.write "<tr><td>Datum prevzema</td><td><input name='DatumPrevzem' type='text' value='"&VDatumPrevzem&"' size='10'></td></tr>"
            response.write "<tr><td>Količina</td><td><input name='kolicina' type='text' value='"&VKolicina&"' size='10'></td></tr>"
            response.write "</table>"
            Response.Write "<input name='id' type='hidden' value='9'>"
            Response.Write "<input name='submit' type='submit' value='Vpiši'>"
            response.write "</form>"
            break;
    case "9":
        VidProstor=request("prostor")
        Vkolicina=int(request("kolicina"))
        if isNumeric(request("invSt")) then
            VInvSt=int(request("invSt"))
        else
            VInvSt=request("invSt")
        end if
        for Indx=1 to Vkolicina
            SQL = "INSERT INTO TabUcniPripomocki (InvSt,idProstor,OsnSredstvo,DodatniOpis,DatumVpisa,DatumInv,Status,Opomba,prevzel,datumPrevzem,vpisal,cas) VALUES ("
            SQL = SQL & "'"&VInvSt&"',"
            SQL = SQL & request("prostor")&","
            SQL = SQL & "'"&request("OsnSredstvo")&"',"
            SQL = SQL & "'"&request("DodatniOpis")&"',"
            SQL = SQL & "'"&day(now)&"."&month(now)&"."&year(now)&"',"
            SQL = SQL & "'"&request("DatumInv")&"',"
            SQL = SQL & request("Status")&","
            SQL = SQL & "'"&request("Opomba")&"',"
            SQL = SQL & request("prevzel")&","
            SQL = SQL & "'"&request("DatumPrevzem")&"',"
            SQL = SQL & "'"&VUporabnik&"',"
            SQL = SQL & "'"&year(now)&"-"&month(now)&"-"&day(now)&" "&hour(now)&":"&minute(now)&":"&second(now)&"') "
            set R = conn.execute(SQL,,adcmdtext)
            if isNumeric(VInvSt) then
                VInvSt=VInvSt+1
            end if
        next
        
        response.write "<h2>Učni pripomoček je bil vpisan!</h2>"
        conn.close
        Set Conn=nothing
        response.redirect "VnosUcniPripomocki.asp?id=2&prostor="&VidProstor
        break;
    case "10":

        SQL = "SELECT TabUcniPripomocki.OsnSredstvo,TabUcniPripomocki.DodatniOpis,TabUcniPripomocki.DatumVpisa,TabUcniPripomocki.opomba,TabUcniPripomocki.datumPrevzem,"
        SQL = SQL & "tabprostor.opis AS popis,tabprostor.stevilka,TabInvStat.Opis AS iopis,tabucitelji.priimek,tabucitelji.ime,Count(TabUcniPripomocki.OsnSredstvo) AS CountOfOsnSr FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "GROUP BY TabUcniPripomocki.OsnSredstvo,TabUcniPripomocki.DodatniOpis,TabUcniPripomocki.DatumVpisa,TabUcniPripomocki.opomba,TabUcniPripomocki.datumPrevzem,"
        SQL = SQL & "tabprostor.opis,tabprostor.stevilka,TabInvStat.Opis,tabucitelji.priimek,tabucitelji.ime "
        SQL = SQL & " ORDER BY tabprostor.opis,tabprostor.stevilka"

        set R = conn.execute(SQL,,adcmdtext)

        response.write "<h3>Učni pripomočki - cel spisek</h3>"
        response.write "<table border=1>"
        response.write "<tr><th>št.</th><th>Prostor</th><th>Inventar</th><th>Dodatni opis</th><th>Datum vpisa</th><th>Status</th><th>Opomba</th><th>Prevzel</th><th>Datum prevzema</th><th>Količina</th></tr>"
            Indx=1
        Do
            if NOT R.EOF then
                response.write "<tr>"
                response.write "<td>"&indx&"</td>"
                response.write "<td>"&R("popis")&" - "&R("Stevilka")&"</td>"
                response.write "<td>"&R("OsnSredstvo")&"</td>"
                response.write "<td>"&R("DodatniOpis")&"</td>"
                response.write "<td>"&R("DatumVpisa")&"</td>"
                response.write "<td>"&R("iOpis")&"</td>"
                response.write "<td>"&R("opomba")&"</td>"
                response.write "<td>"&R("priimek")&" "&R("ime")&"</td>"
                response.write "<td>"&R("DatumPrevzem")&"</td>"
                response.write "<td align='right'>"&R("CountOfOsnSr")&"</td>"
                response.write "</tr>"
            else
                Exit Do
            end if
            R.MoveNext
            Indx=Indx+1
        Loop
        response.write "</table><br>"
        response.write "<a href='VnosUcniPripomocki.asp?id=1'>Izbira prostora</a><br>"

        Response.Write "<form accept-charset='utf-8' name='Iskanje' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Iskalni niz: <input name='iskanje' type='text' size='30'>"
        Response.Write "<input name='id' type='hidden' value='6'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form><br>"
        Response.Write "<form accept-charset='utf-8' name='IskanjePrevzemnik' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Išči po prevzemnikih: "
        response.write "<select name='prevzel'>"
        SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                if R("idUcitelj")=VPrevzel then
                    response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                else
                    response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                end if
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select>"
        Response.Write "<input name='id' type='hidden' value='61'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form>"
        break;
    case "10a":
        SQL = "SELECT TabUcniPripomocki.*,tabprostor.*,TabInvStat.*,tabucitelji.*,tabprostor.opis AS popis,TabinvStat.Opis AS iopis,TabUcniPripomocki.id AS uid FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & " ORDER BY OsnSredstvo"

        set R = conn.execute(SQL,,adcmdtext)

        response.write "<h3>Učni pripomočki - cel spisek</h3>"
        Response.Write "<form accept-charset='utf-8' name='prevzemnica' method=post action='PrevzemnicaUPPDF.asp'>"
        response.write "<table border=1>"
        response.write "<tr><th>št.</th><th>Prostor</th><th>Inventar</th><th>Dodatni opis</th><th>Datum vpisa</th><th>Status</th><th>Opomba</th><th>Prevzel</th><th>Datum prevzema</th><th>Podpisana<br>prevzemnica</th><th>Vključi na<br>prevzemnico</th><th>Popravi</th><th>Briši</th></tr>"
        Indx=0
        Do
            if NOT R.EOF then
                indx=indx+1
                response.write "<tr>"
                response.write "<td>"&indx&"</td>"
                response.write "<td>"&R("popis")&" - "&R("Stevilka")&"</td>"
                response.write "<td>"&R("OsnSredstvo")&"</td>"
                response.write "<td>"&R("DodatniOpis")&"</td>"
                response.write "<td>"&R("DatumVpisa")&"</td>"
                response.write "<td>"&R("iOpis")&"</td>"
                response.write "<td>"&R("opomba")&"</td>"
                response.write "<td>"&R("priimek")&" "&R("ime")&"</td>"
                response.write "<td>"&R("DatumPrevzem")&"</td>"
                response.write "<td><a href='"&R("Prevzemnica")&"' target='_blank'>"&R("Prevzemnica")&"</a></td>"
                response.write "<td><input name='zap_"&CStr(indx)&"' type='hidden' value='"&R("uid")&"'><input name='TvoriPrevzemnico_"&CStr(Indx)&"' type='checkbox'></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=4&zapis="&R("uid")&"'>Popravi</a></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=5&zapis="&R("uid")&"'>Briši</a></td>"
                response.write "</tr>"
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</table><br>"
        Response.Write "<input name='StPrevz' type='hidden' value='"&Indx&"'>"
        Response.Write "<input name='submit' type='submit' value='Tvori prevzemnico'>"
        response.write "</form><br>"
        response.write "<a href='VnosUcniPripomocki.asp?id=1'>Izbira prostora</a><br>"

        Response.Write "<form accept-charset='utf-8' name='Iskanje' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Iskalni niz: <input name='iskanje' type='text' size='30'>"
        Response.Write "<input name='id' type='hidden' value='6'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form><br>"
        Response.Write "<form accept-charset='utf-8' name='IskanjePrevzemnik' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Išči po prevzemnikih: "
        response.write "<select name='prevzel'>"
        SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                if R("idUcitelj")=VPrevzel then
                    response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                else
                    response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                end if
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select>"
        Response.Write "<input name='id' type='hidden' value='61'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form>"
end select

select case Obdelava
    case "2":
    case "3":
    case "5":
        SQL = "SELECT TabUcniPripomocki.*,tabprostor.*,TabInvStat.*,tabucitelji.*,tabprostor.opis AS popis,TabinvStat.Opis AS iopis,TabUcniPripomocki.id AS uid FROM ((TabUcniPripomocki "
        SQL = SQL & "INNER JOIN tabprostor ON TabUcniPripomocki.idProstor=tabprostor.idProstor) "
        SQL = SQL & "INNER JOIN TabInvStat ON TabUcniPripomocki.Status=TabInvStat.statusInv) "
        SQL = SQL & "INNER JOIN tabucitelji ON TabUcniPripomocki.prevzel=tabucitelji.idUcitelj "
        SQL = SQL & "WHERE TabUcniPripomocki.idProstor="&VidProstor&" ORDER BY OsnSredstvo"
        set R = conn.execute(SQL,,adcmdtext)

        response.write "<h3>Učni pripomočki - "&VProstor&"</h3>"
        Response.Write "<form accept-charset='utf-8' name='prevzemnica' method=post action='PrevzemnicaUPPDF.asp'>"
        response.write "<table border=1>"
        response.write "<tr><th>št.</th><th>Prostor</th><th>Inv. št.</th><th>Inventar</th><th>Dodatni opis</th><th>Datum vpisa</th><th>Status</th><th>Opomba</th><th>Prevzel</th><th>Datum prevzema</th><th>Podpisana<br>prevzemnica</th><th>Vključi na<br>prevzemnico</th><th>Popravi</th><th>Briši</th></tr>"
        Indx=0
        Do
            if NOT R.EOF then
                indx=indx+1
                response.write "<tr>"
                response.write "<td>"&indx&"</td>"
                response.write "<td>"&R("popis")&" - "&R("Stevilka")&"</td>"
                response.write "<td>"&R("InvSt")&"</td>"
                response.write "<td>"&R("OsnSredstvo")&"</td>"
                response.write "<td>"&R("DodatniOpis")&"</td>"
                response.write "<td>"&R("DatumVpisa")&"</td>"
                response.write "<td>"&R("iOpis")&"</td>"
                response.write "<td>"&R("opomba")&"</td>"
                response.write "<td>"&R("priimek")&" "&R("ime")&"</td>"
                response.write "<td>"&R("DatumPrevzem")&"</td>"
                response.write "<td><a href='"&R("Prevzemnica")&"' target='_blank'>"&R("Prevzemnica")&"</a></td>"
                response.write "<td><input name='zap_"&CStr(indx)&"' type='hidden' value='"&R("uid")&"'><input name='TvoriPrevzemnico_"&CStr(Indx)&"' type='checkbox'></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=4&zapis="&R("uid")&"'>Popravi</a></td>"
                response.write "<td><a href='VnosUcniPripomocki.asp?id=5&zapis="&R("uid")&"'>Briši</a></td>"
                response.write "</tr>"
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</table><br>"
        Response.Write "<input name='StPrevz' type='hidden' value='"&Indx&"'>"
        Response.Write "<input name='submit' type='submit' value='Tvori prevzemnico'>"
        response.write "</form><br>"
        response.write "<a href='VnosUcniPripomocki.asp?id=1'>Izbira prostora</a><br>"

        Response.Write "<form accept-charset='utf-8' name='Iskanje' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Iskalni niz: <input name='iskanje' type='text' size='30'>"
        Response.Write "<input name='id' type='hidden' value='6'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form><br>"
        Response.Write "<form accept-charset='utf-8' name='IskanjePrevzemnik' method=post action='VnosUcniPripomocki.asp'>"
        response.write "Išči po prevzemnikih: "
        response.write "<select name='prevzel'>"
        SQL = "SELECT * FROM tabucitelji ORDER BY Priimek,Ime"
        set R = conn.execute(SQL,,adcmdtext)
        
        Do
            if NOT R.EOF then
                if R("idUcitelj")=VPrevzel then
                    response.write "<option value='"&R("idUcitelj")&"' selected>"&R("priimek")&" "&R("ime")&"</option>"
                else
                    response.write "<option value='"&R("idUcitelj")&"'>"&R("priimek")&" "&R("ime")&"</option>"
                end if
            else
                Exit Do
            end if
            R.MoveNext
        Loop
        response.write "</select>"
        Response.Write "<input name='id' type='hidden' value='61'>"
        Response.Write "<input name='submit' type='submit' value='Išči'>"
        response.write "</form>"
end select

conn.close
Set Conn=nothing
?>
<a href="VnosUcniPripomocki.asp?id=8">Dodaj učne pripomočke</a><br>
<a href="VnosUcniPripomocki.asp?id=10">Izpis vseh učnih pripomočkov</a><br>
<a href="VnosUcniPripomocki.asp?id=10a">Popravljanje zapisov in prevzemnice</a><br>
<a href="VnosUcniPripomocki.asp?id=1">Na izbor prostora</a><br>
<a href="prijava.asp">Nazaj na glavni meni</a><br>

</body>
</html>
