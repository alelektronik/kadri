<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function ToStopnja($x){
    switch ($x){
        case 0:
            return "Šolsko";
        case 1:
            return "Občinsko";
        case 2:
            return "Medobčinsko";
        case 3:
            return "Področno";
        case 4:
            return "Regijsko";
        case 5:
            return "Mestno";
        case 7:
            return "Državno četrfinale";
        case 8:
            return "Državno polfinale";
        case 9:
            return "Državno finale";
        case 10:
            return "Državno";
    }
}
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function ToPoravnava($x){
    switch ($x){
        case "0":
            return "L";
        case "1":
            return "C";
        case "2":
            return "R";
    }
}
function Arr2Str($a){
    $s="";
    for ($i=0;$i < count($a);$i++){
        if (strlen($s) == 0){
            $s=$a[$i];
        }else{
            $s=$s.",".$a[$i];
        }
    }
    return $s;
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
switch ($Vid){
	case "107":
	case "108":
	case "111":
	case "204":
	case "206":
	case "207":
    case "209":
	case "210":
	case "211":
	case "307":
	case "308":
	case "310":
	//case "312":
	case "403":
	case "404":
	case "406":
	case "502":
		break;
    case "106":
    case "208":
    case "306":
    case "405":
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        break;
	default:
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
/*
		$n=$VLevel;
		include('menu_func.inc');
		include ('menu.inc');
*/
}
if (isset($_POST["ucenec"])){
    $ucenec = $_POST["ucenec"];
}else{
    if (isset($_GET["ucenec"])){
        $ucenec=$_GET["ucenec"];
    }else{
        $ucenec = 0;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        if (isset($_SESSION["razred"])){
            $VRazred=$_SESSION["razred"];
        }else{
            $VRazred = 0;
        }
    }
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay = $_SESSION["DayToPrint"];
}else{
    $PrintDay = $Danes->format('j. n. Y');
}
$_SESSION["DayToPrint"]=$PrintDay;

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
    $VSolaKraj=$R["Kraj"];
    $VRavnatelj=$R["Ravnatelj"];
    $TipSole=$R["TipSole"];
    $RavnateljID=$R["ravnatelj_ID"];
}else{
    $VSola=" ";
    $VRavnatelj=" ";
    $RavnateljID=0;
    $VSolaNaslov="";
    $VSolaKraj="";
    $TipSole=0;
}

$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $SpolRavnatelj=$R["Spol"];
}else{
    $SpolRavnatelj="M";
}

if (isset($_POST["idtekm"])){
    $VIdTekm = $_POST["idtekm"];
}else{
    if (isset($_GET["idtekm"])){
        $VIdTekm=$_GET["idtekm"];
    }else{
        $VIdTekm = "";
    }
}

switch ($Vid){
    case "101": //izbor tekmovanj v znanju
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";

        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        $SQL = "SELECT * FROM tabsifranttekm";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $VTip[$Indx][1]=$R["idTekmovanja"];
            $VTip[$Indx][2]=$R["opis"];
            $Indx=$Indx+1;
        }

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["stopnja"])){
            $VStopnja = $_POST["stopnja"];
        }else{
            if (isset($_GET["stopnja"])){
                $VStopnja=$_GET["stopnja"];
            }else{
                $VStopnja = 0;
            }
        }
        if (isset($_POST["tip"])){
            $VTipT = $_POST["tip"];
        }else{
            if (isset($_GET["tip"])){
                $VTipT=$_GET["tip"];
            }else{
                $VTipT = 0;
            }
        }
        if (isset($_POST["zapis"])){
            $VZapis = $_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                $VZapis = 0;
            }
        }
        switch ($VIdTekm){
            case "1":
                if (($VKrozek=="") or ($VMentor=="") ){
                    echo "<h2>Tekmovanje ni bilo dodano!</h2>";
                }else{
                    $SQL = "SELECT * FROM tabdrtekm WHERE leto=".$VLeto." AND krozek='".$VKrozek."' AND mentor='".$VMentor."' AND stopnja=".$VStopnja;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<h2>To tekmovanje je že vpisano!</h2>";
                    }else{
                        $SQL = "INSERT INTO tabdrtekm (leto,krozek,mentor,stopnja,tip) VALUES (".$VLeto.",'".$VKrozek."','".$VMentor."',".$VStopnja.",".$VTipT.")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu!<br />");
                        }
                        
                        echo "<h2>Dodano je bilo tekmovanje: ".$VKrozek." - ".$VMentor."</h2>";
                    }
                }
                break;
            case "2":
                if ($VLevel > 1 ){
                    $SQL = "DELETE FROM tabdrtekm WHERE id=".$VZapis;
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri brisanju!<br />");
                    }
                    
                    $SQL = "DELETE FROM tabdrtekmClan WHERE idTekmovanje=".$VZapis;
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri brisanju!<br />");
                    }
                }
        }

        $SQL = "SELECT tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabdrtekm.leto, tabdrtekmclan.idtekmovanje, tabdrtekmclan.kraj, tabdrtekmclan.datum, tabdrtekm.tip,tabdrtekm.porocilo, Count(tabdrtekmclan.idtekmovanje) AS countofkrozek " ;
        $SQL = $SQL."FROM tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.idTekmovanje = tabdrtekm.id " ;
        $SQL = $SQL."GROUP BY tabdrtekm.leto, tabdrtekmclan.idTekmovanje, tabdrtekm.tip, tabdrtekmclan.Kraj, tabdrtekmclan.Datum, tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor ";
        $SQL = $SQL."HAVING (((tabdrtekm.leto)=".$VLeto.")) ORDER BY tabdrtekm.tip,tabdrtekm.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izbor in vpis tekmovanja - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p>Če vaše tekmovanje še ni v spodnjem spisku, ga vpišite, pri tem pa pazite na to, da se bodo na nivoju šole uporabljale <b>enotne oznake imen tekmovanj</b>.<br />";
        echo "<b>Postopek vpisa:</b><br />";
        echo "1. Vpis imena tekmovanja, izbor stopnje tekmovanja in vpis mentorja (pri več mentorjih lahko vpišete isto ime tekmovanja za vsakega mentorja posebej)<br />";
        echo "2. Klik na ime tekmovanja, vpis datuma in kraja tekmovanja ter izbor učencev s spiska učencev<br />";
        echo "3. Učencem vpišete osvojena mesta oz. osvojitev priznanj<br />";
        echo "<font color='green'>Osnovne podatke o tekmovanju lahko popravite s klikom na <b>Poglej/popravi</b> v stolpcu Poročilo</font><br />";
        echo "<br />";
        echo "Standardna priznanja lahko izpišete s klikom na <b>Priznanja</b> v stolpcu Priznanja<br />";
        echo "<br />";
        echo "Za pregleden izpis spiska tekmovanj s statistiko ter možnostjo tiskanja poročila o tekmovanju kliknite <a href='tekmovanjakrozki.php?id=109'>tukaj</a>.<br />";
        echo "Za izpis dobitnikov priznanj z vseh tekmovanj po tekmovanjih ali po razredih kliknite <a href='tekmovanjakrozki.php?id=112'>tukaj</a>.<br />";

        echo "</p>";
        echo "<form name='DrTekm' method=post action='tekmovanjakrozki.php'>";

        echo "<table border=1 cellspacing=0>";
        if ($VecSol > 0){
            if ($VLevel < 2 ){
                echo "<tr><th>Št.</th><th>Tip</th><th>Tekmovanje</th><th>Šola</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th></tr>";
            }else{
                echo "<tr><th>Št.</th><th>Tip</th><th>Tekmovanje</th><th>Šola</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th><th>Briši</th></tr>";
            }
        }else{
            if ($VLevel < 2 ){
                echo "<tr><th>Št.</th><th>Tip</th><th>Tekmovanje</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th></tr>";
            }else{
                echo "<tr><th>Št.</th><th>Tip</th><th>Tekmovanje</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th><th>Briši</th></tr>";
            }
        }
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$VTip[$R["tip"]][2]."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=102&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
            if ($VecSol > 0){
                echo "<td>";
                $sola="";
                if ($R["countofkrozek"] > 0){
                    $SQL = "SELECT DISTINCT tabsola.solakratko FROM ((tabdrtekmclan ";
                    $SQL .= "INNER JOIN tabrazred ON tabdrtekmclan.iducenec=tabrazred.iducenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL .= "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdrtekmclan.idtekmovanje=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $sola = $sola . $R1["solakratko"]."<br />";
                    }
                }
                echo $sola."</td>";
            }
            echo "<td>".ToStopnja($R["stopnja"])."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td>".$R["mentor"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            if ($R["countofkrozek"] > 0 ){
                echo "<td><a href='tekmovanjakrozki.php?id=108&solskoleto=".$VLeto."&idtekm=".$R["id"]."'>Priznanja</a></td>";
            }else{
                echo "<td></td>";
            }
            if (isset($R["porocilo"]) && strlen($R["porocilo"]) > 0){
                echo "<td bgcolor='lightgreen'>";
            }else{
                echo "<td bgcolor='red'>";
            }
            echo "<a href='tekmovanjakrozki.php?id=106&idtekm=".$R["id"]."'><img src='img/m_poglej.gif' border='0' alt='Poglej'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            if ($VLevel > 1 ){
                echo "<td><a href='tekmovanjakrozki.php?id=101&idtekm=2&zapis=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "<tr><td></td>";
        echo "<td><select name='tip'>";
        $Indx=0;
        while (strlen($VTip[$Indx][2]) > 0){
            echo "<option value='".$VTip[$Indx][1]."'>".$VTip[$Indx][2]."</option>";
            $Indx=$Indx+1;
        }
        echo "</select></td>";
        echo "<td><input name='krozek' type='text' size='30'></td>";
        if ($VecSol > 0){
            echo "<td></td>";
        }
        echo "<td><select name='stopnja'>";
        echo "<option value='0'>Šolsko</option>";
        echo "<option value='1'>Občinsko</option>";
        echo "<option value='2'>Medobčinsko</option>";
        echo "<option value='3'>Področno</option>";
        echo "<option value='4'>Regijsko</option>";
        echo "<option value='5'>Mestno</option>";
        echo "<option value='7'>Državno četrtfinale</option>";
        echo "<option value='8'>Državno polfinale</option>";
        echo "<option value='9'>Državno finale</option>";
        echo "<option value='10'>Državno</option>";
        echo "</select></td>";
        echo "<td>&nbsp;</td>";
        echo "<td>&nbsp;</td>";
        echo "<td><input name='mentor' type='text' size='30'></td><td></td><td></td><td><input name='id' type='hidden' value='101'><input name='idtekm' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
        echo "</table><br />";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "102": //dodeli učence tekmovanj
            echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
            echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
            echo "<script type=\"text/javascript\">";
            echo "    window.onload = function(){";
            echo "        var Danes = new Date();";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat01\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat02\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "    };";
            echo "</script>";
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        
        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VTekmovanje=$R["krozek"];
            $VMentor=$R["mentor"];
            $VStopnja=$R["stopnja"];
            $VLeto=$R["leto"];
            
            echo "<form name='tekmovanja' method='post' action='tekmovanjakrozki.php'>";
            echo "<h2>Vpis tekmovanja v znanju - ".$VTekmovanje."</h2>";
            echo "<table border=0>";
            echo "<tr><td>Šolsko leto:</td><td><input name='idtekm' type='hidden' value='".$VIdTekm."'>".$VLeto."/".($VLeto+1)."</td></tr>";
            echo "<tr><td>Mentor:</td><td>".$VMentor."</td></tr>";
            echo "<tr><td>Tekmovanje:</td><td>".$VTekmovanje."</td></tr>";
            echo "<tr><td>Stopnja:</td><td>".ToStopnja($VStopnja)."</td></tr>";
            $SQL = "SELECT * FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VDatum=$R["datum"];
                $VKraj=$R["kraj"];
            }else{
                $VDatum="";
                $VKraj="";
            }
            echo "<tr><td>Datum tekmovanja:</td><td><input name='datum' type='text' size='10' value='".$VDatum."' id='dat01'></td></tr>";
            echo "<tr><td>Kraj tekmovanja:</td><td><input name='kraj' type='text' size='40' value='".$VKraj."'></td></tr>";
            echo "<tr><td>Tekmovalci:<br />(Več naenkrat jih lahko označite s <br />skupnim pritiskom tipke Ctrl in levim klikom)</td>";
            echo "<td><select name='tekmovalci[]' multiple size='30'>";
            $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime,tabrazdat.* FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
            }
            echo "</select></td></tr>";
            echo "</table>";
            echo "<p>Pri dodajanju učencev na tekmovanje kliknite na gumb <b>Dodaj nove</b>.<br />Če ste se namenili le popraviti podatke o osvojenih priznanjih, kliknite na <b>Popravi<b> </p>";
            echo "<input name='id' type='hidden' value='103'>";
            echo "<input name='submit' type='submit' value='Popravi'><input name='submit' type='submit' value='Dodaj nove'>";
            echo "</form><br />";
            
            $SQL = "SELECT tabdrtekmclan.*,tabdrtekm.*,tabucenci.*,tabrazdat.* FROM ";
            $SQL = $SQL . "(((tabdrtekmclan INNER JOIN tabdrtekm ON tabdrtekmclan.idtekmovanje=tabdrtekm.id) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.iducenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.iducenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto." AND tabdrtekmclan.idtekmovanje=".$VIdTekm;
            $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Spisek udeležencev: ".$R["krozek"]." - ".$R["mentor"]."</h2>";
            }

            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Št.</th><th>Ime</th><th>Priimek</th><th>Razred</th><th>Dat. roj.</th><th>Kontakt</th><th>Mentor</th>";
            echo "</tr>";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["Ime"]."</td><td>".$R["Priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                $Datum=new DateTime(isDate($R["DatRoj"]));
                echo "<td align='right'>".$Datum->format('d.m.Y')."</td>";
                echo "<td>".$R["oceGSM"].", ".$R["matiGSM"].", ".$R["SkrbnikiKontakt"]."</td>";
                echo "<td>".$R["mentor"]."</td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<a href='tekmovanjakrozki.php?id=104&solskoleto=".$VLeto."&idtekm=".$VIdTekm."'>Spisek udeležencev tekmovanja</a><br /><br />";
            
        }
        echo "</body>";
        echo "</html>";
        break;
    case "103": //vpis tekmovanja - udeležencev
            echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
            echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
            echo "<script type=\"text/javascript\">";
            echo "    window.onload = function(){";
            echo "        var Danes = new Date();";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat01\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat02\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "    };";
            echo "</script>";
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        
        echo "<form name='tekmovanja' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='105'>";
        echo "<h2>Vpis rezultatov tekmovanja</h2>";
        echo "<table border=0>";

        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VLeto=$R["leto"];
            $VMentor=$R["mentor"];
            $VTekmovanje=$R["krozek"];
            $VStopnja=$R["stopnja"];
            
            echo "<tr><td>Šolsko leto: <b>".$VLeto."/".($VLeto+1)."</b>";
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "</td></tr>";
            echo "<tr><td>Mentor: <b>".$VMentor."</b>";
            echo "<input type='hidden' name='mentor' value='".$VMentor."'>";
            echo "</td></tr>";
            echo "<tr><td>Tekmovanje: <b>".$VTekmovanje."</b>";
            echo "<input type='hidden' name='tekmovanje' value='".$VTekmovanje."'>";
            echo "</td></tr>";
            echo "<tr><td>Stopnja tekmovanja: <b>".ToStopnja($VStopnja)."</b>";
            echo "<input type='hidden' name='stopnja' value='".$VStopnja."'>";
            echo "</td></tr>";
            echo "<tr><td>Datum tekmovanja:";
            $VDatum=$_POST["datum"];
            echo " <b>".$VDatum."</b>";
            echo "<input type='hidden' name='datum' value='".$VDatum."' id='dat01'>";
            echo "</td></tr>";
            echo "<tr><td>Kraj tekmovanja:";
            $VKraj=$_POST["kraj"];
            echo " <b>".$VKraj."</b>";
            echo "<input type='hidden' name='kraj' value='".$VKraj."'>";
            echo "</td></tr>";
            echo "</table><br />";
            echo "<table borde=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Mesto/Priznanje</th><th>Nadaljnje<br />tekmovanje</th>";

            if (isset($_POST["tekmovalci"])){
                $VTekmovalci=Arr2Str($_POST["tekmovalci"]);
            }else{
                $VTekmovalci="";
            }
            
            if ($_POST["submit"]=="Popravi" ){
                $SQL = "SELECT * FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                
                if (mysqli_num_rows($result) > 0){
                    while ($R = mysqli_fetch_array($result)){
                        if (strlen($VTekmovalci)==0 ){
                            $VTekmovalci=$R["idUcenec"];
                        }else{
                            $VTekmovalci=$VTekmovalci.",".$R["idUcenec"];
                        }
                    }
                
                    $SQL = "SELECT tabucenci.*,tabrazred.Razred,tabrazred.Paralelka,tabdrtekmclan.* FROM (tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
                    $SQL = $SQL . "LEFT JOIN tabdrtekmclan ON tabucenci.idUcenec=tabdrtekmclan.idUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto." AND tabdrtekmclan.idTekmovanje=".$VIdTekm." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"]." ".$R["Razred"].". ".strtolower($R["Paralelka"]);
                        echo "</td><td>";
                        echo "<select name='priznanje_".$Indx."'>";
                        echo "<option value=0 selected>Upoštevaj moj opis</option>";
                        echo "<option value=1>Sodelovanje</option>";
                        echo "<option value=2>Bronasto priznanje</option>";
                        echo "<option value=3>Srebrno priznanje</option>";
                        echo "<option value=4>Zlato priznanje</option>";
                        echo "</select>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20' value='".$R["priznanje"]."'>";
                        echo "</td><td>";
                        if ($R["napredovanje"] ){
                            echo "<input name='uvrstitev".$Indx."' type='checkbox' checked='checked'>";
                        }else{
                            echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        }
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                }else{
                    $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime,tabrazred.Razred,tabrazred.Paralelka FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"]." ".$R["Razred"].".".strtolower($R["Paralelka"]);
                        echo "</td><td>";
                        echo "<select name='priznanje_".$Indx."'>";
                        echo "<option value=0 selected>Upoštevaj moj opis</option>";
                        echo "<option value=1>Sodelovanje</option>";
                        echo "<option value=2>Bronasto priznanje</option>";
                        echo "<option value=3>Srebrno priznanje</option>";
                        echo "<option value=4>Zlato priznanje</option>";
                        echo "</select>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20'>";
                        echo "</td><td>";
                        echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                }
            }else{
                    $SQL = "SELECT tabucenci.IdUcenec,tabucenci.Priimek,tabucenci.Ime,tabrazred.Razred,tabrazred.Paralelka FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"]." ".$R["Razred"].".".strtolower($R["Paralelka"]);
                        echo "</td><td>";
                        echo "<select name='priznanje_".$Indx."'>";
                        echo "<option value=0 selected>Upoštevaj moj opis</option>";
                        echo "<option value=1>Sodelovanje</option>";
                        echo "<option value=2>Bronasto priznanje</option>";
                        echo "<option value=3>Srebrno priznanje</option>";
                        echo "<option value=4>Zlato priznanje</option>";
                        echo "</select>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20'>";
                        echo "</td><td>";
                        echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
            }
            echo "Skupno število udeležencev tekmovanja naše šole: <b>".($Indx-1)."</b>";
            echo "<input name='skupaj' type='hidden' value='".($Indx-1)."'><br />";
            echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'><br />";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "104": //udeleženci tekmovanj v znanju
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        
        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VLeto=$R["leto"];
            
            $SQL = "SELECT tabdrtekmclan.*,tabdrtekm.*,tabucenci.*,tabrazdat.* FROM ";
            $SQL = $SQL . "(((tabdrtekmclan INNER JOIN tabdrtekm ON tabdrtekmclan.idtekmovanje=tabdrtekm.id) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.iducenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.iducenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto." AND tabdrtekmclan.idtekmovanje=".$VIdTekm;
            $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Spisek udeležencev: ".$R["krozek"]." - ".$R["mentor"]."</h2>";
            }

            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Št.</th><th>Slika</th><th>Ime</th><th>Priimek</th><th>Razred</th>";
            echo "</tr>";

            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td><img src='slike/".$VLeto."_".$R["idUcenec"].".jpg' width='50' onmouseover='width+=100' onmouseout='width-=100'></td>";
                echo "<td>".$R["Ime"]."</td><td>".$R["Priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            
        }
        echo "</body>";
        echo "</html>";
    
        break;
    case "105": //shrani rezultate tekmovalcev
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["stopnja"])){
            $VStopnja = $_POST["stopnja"];
        }else{
            if (isset($_GET["stopnja"])){
                $VStopnja=$_GET["stopnja"];
            }else{
                $VStopnja = 0;
            }
        }
        if (isset($_POST["tip"])){
            $VTipT = $_POST["tip"];
        }else{
            if (isset($_GET["tip"])){
                $VTipT=$_GET["tip"];
            }else{
                $VTipT = 0;
            }
        }
        if (isset($_POST["brisanje"])){
            $VBrisanje = $_POST["brisanje"];
        }else{
            if (isset($_GET["brisanje"])){
                $VBrisanje=$_GET["brisanje"];
            }else{
                $VBrisanje = 0;
            }
        }
        if (isset($_POST["zapis"])){
            $VZapis = $_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $VZapis=$_GET["zapis"];
            }else{
                $VZapis = 0;
            }
        }
        if (isset($_POST["tekmovanje"])){
            $VTekmovanje=$_POST["tekmovanje"];
        }else{
            $VTekmovanje="";
        }
        if (isset($_POST["datum"])){
            $VDatum=$_POST["datum"];
        }else{
            $VDatum=$Danes->format('j.n.Y');
        }
        if (isset($_POST["kraj"])){
            $VKraj=$_POST["kraj"];
        }else{
            $VKraj="";
        }
        if (isset($_POST["skupaj"])){
            $VSkupaj=$_POST["skupaj"];
        }else{
            $VSkupaj=0;
        }
        
        for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
            $VTekmovalci[$Indx][1]=$_POST["tekmovalec".$Indx];
            switch ( $_POST["priznanje_".$Indx]){
                case 0:
                    $VTekmovalci[$Indx][2]=$_POST["priznanje".$Indx];
                    break;
                case 1:
                    $VTekmovalci[$Indx][2]="Sodelovanje";
                    break;
                case 2:
                    $VTekmovalci[$Indx][2]="Bronasto priznanje";
                    break;
                case 3:
                    $VTekmovalci[$Indx][2]="Srebrno priznanje";
                    break;
                case 4:
                    $VTekmovalci[$Indx][2]="Zlato priznanje";
            }
            
            if (isset($_POST["uvrstitev".$Indx])){
                $VTekmovalci[$Indx][3]="true";
            }else{
                $VTekmovalci[$Indx][3]="false";
            }
        }
        $VStamp=$Danes->format('Y-m-d H:i:s');

        if ($VBrisanje=="1" ){
            $SQL = "SELECT * FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $VLeto=$R["leto"];
            }
            
            for ($Indx=1;$Indx <=$_POST["stbris"];$Indx++){
                if (isset($_POST["br_".$Indx])){
                    $SQL = "DELETE FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm." AND idUcenec=".$_POST["tekm_".$Indx];
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri brisanju!<br />");
                    }
                }
            }
        }else{
            for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
                $SQL = "SELECT * FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm." AND idUcenec=".$VTekmovalci[$Indx][1];
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabdrtekmclan SET leto=".$VLeto.",mentor1='".$VMentor."',datum='".$VDatum."',priznanje='".$VTekmovalci[$Indx][2]."',napredovanje=".$VTekmovalci[$Indx][3].",stopnja='".ToStopnja($VStopnja)."',kraj='".$VKraj."',vpisal='".$VUporabnik."',idDogodek='".$VStamp."' WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabdrtekmclan (leto,idUcenec,mentor1,datum,tekmovanje,idtekmovanje,priznanje,napredovanje,stopnja,kraj,vpisal,idDogodek) VALUES (";
                    $SQL = $SQL .$VLeto.",".$VTekmovalci[$Indx][1].",'".$VMentor."','".$VDatum."','".$VTekmovanje."',".$VIdTekm.",'".$VTekmovalci[$Indx][2]."',".$VTekmovalci[$Indx][3].",'".ToStopnja($VStopnja)."','".$VKraj."','".$VUporabnik."','".$VStamp."')";
                }
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu!<br />");
                }
            }
            if ($Opravila==1 ){
                $SQL = "SELECT tabdeldogodek.* FROM ";
                $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos rezultatov tekmovanj iz znanja' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VDogodki[$Indx]=$R["id"];
                    $Indx=$Indx+1;
                }
                $StDogodkov=$Indx-1;

                for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu!<br />");
                    }
                }
            }
        }

        echo "Vpisano je bilo:<br />";
        $SQL = "SELECT tabdrtekmclan.*,tabucenci.Priimek,tabucenci.Ime,tabrazdat.* FROM ";
        $SQL = $SQL . "((tabdrtekmclan INNER JOIN tabucenci ON tabdrtekmclan.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto." AND tabdrtekmclan.idTekmovanje=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        echo "<form name='bris_tekm' method=post action='tekmovanjakrozki.php'>";
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th><th>Tekmovanje</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Tekmovalec</th><th>Mesto/Priznanje</th><th>Napredovanje</th><th>Briši</th>";
        echo "</tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["tekmovanje"]."</td>";
            echo "<td>".$R["stopnja"]."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td>".$R["mentor1"]."</td>";
            echo "<td>".$R["Priimek"]." ".$R["Ime"]." ".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "<td>".$R["priznanje"]."</td>";
            if ($R["napredovanje"] ){
                echo "<td><input type='checkbox' checked='checked'></td>";
            }else{
                echo "<td><input type='checkbox'></td>";
            }
            echo "<td><input name='tekm_".$Indx."' type='hidden' value='".$R["idUcenec"]."'><input name='br_".$Indx."' type='checkbox'></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<input name='id' type='hidden' value='105'>";
        echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
        echo "<input name='brisanje' type='hidden' value='1'>";
        echo "<input name='stbris' type='hidden' value='".($Indx-1)."'>";
        echo "<input name='submit' type='submit' value='Briši'>";
        echo "</form><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na spisek tekmovanj</a>";
        echo "</body>";
        echo "</html>";

        break;
    case "106": //poročilo za tekmovanja
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        if (isset($_POST["brisi"])){
            $Brisi=$_POST["brisi"];
        }else{
            $Brisi="";
        }
        switch ($Brisi){
            case "1":
                if ($VLevel < 2){
                    $n=$VLevel;
                    include('menu_func.inc');
                    include ('menu.inc');
                }
                break;
            case "2":
                break;
            default:
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
        }
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["stopnja"])){
            $VStopnja = $_POST["stopnja"];
        }else{
            if (isset($_GET["stopnja"])){
                $VStopnja=$_GET["stopnja"];
            }else{
                $VStopnja = 0;
            }
        }
        if (isset($_POST["tip"])){
            $VTipT = $_POST["tip"];
        }else{
            if (isset($_GET["tip"])){
                $VTipT=$_GET["tip"];
            }else{
                $VTipT = 0;
            }
        }
        $SQL = "SELECT * FROM tabsifranttekm";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $VTip[$Indx][1]=$R["idTekmovanja"];
            $VTip[$Indx][2]=$R["opis"];
            $Indx=$Indx+1;
        }
        switch ($Brisi){
            case "1":
                if ($VLevel > 1 ){
                    $SQL = "DELETE FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri brisanju!<br />");
                    }
                    $SQL = "DELETE FROM tabdrtekm WHERE id=".$VIdTekm;
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri brisanju!<br />");
                    }
                    
                    header ("Location: tekmovanjakrozki.php?id=101");
                }
                break;
            case "2":
                $SQL = "UPDATE tabdrtekm SET tip=".$VTipT.",krozek='".$VKrozek."',mentor='".$VMentor."',stopnja=".$VStopnja." WHERE id=".$VIdTekm;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu!<br />");
                }
                $SQL = "UPDATE tabdrtekmclan SET stopnja='".ToStopnja($VStopnja)."',tekmovanje='".$VKrozek."',mentor1='".$VMentor."' WHERE idTekmovanje=".$VIdTekm;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu!<br />");
                }
                header ("Location: tekmovanjakrozki.php?id=101");
                break;
            default:
                $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Poročilo o tekmovanju v znanju: ".$R["krozek"]." - ".$R["mentor"].":</h2>";
                    $VPorocilo=$R["porocilo"];
                    echo "<form name='form_tekmovanje' method=post action='tekmovanjakrozki.php'>";
                    
                    echo "Tip: <select name='tip'>";
                    $Indx=0;
                    while (strlen($VTip[$Indx][2]) > 0){
                        if ($VTip[$Indx][1] == $R["tip"] ){
                            echo "<option value='".$VTip[$Indx][1]."' selected='selected'>".$VTip[$Indx][2]."</option>";
                        }else{
                            echo "<option value='".$VTip[$Indx][1]."'>".$VTip[$Indx][2]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                    echo "</select><br />";
                    echo "Krožek: <input name='krozek' type='text' size='40' value='".$R["krozek"]."'><br />";
                    echo "Mentor: <input name='mentor' type='text' size='40' value='".$R["mentor"]."'><br />";
                    echo "Stopnja: <select name='stopnja'>";
                    for ($Indx=0;$Indx <= 10;$Indx++){
                        if ($Indx != 6){
                            if ($R["stopnja"]==$Indx ){
                                echo "<option value='".$Indx."' selected='selected'>".ToStopnja($Indx)."</option>";
                            }else{
                                echo "<option value='".$Indx."'>".ToStopnja($Indx)."</option>";
                            }
                        }
                    }
                    echo "</select><br />";
                    echo "<input name='brisi' type='hidden' value='2'>";
                    echo "<input name='id' type='hidden' value='106'>";
                    echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
                    echo "<input name='submit' type='submit' value='Spremeni podatke'>";
                    echo "</form>";
                    
                    echo "<form name='form_realizacija' method=post action='tekmovanjakrozki.php'>";
                    echo "<input type='hidden' name='id' value='107'>";
                    echo "<input type='hidden' name='idtekm' value='".$VIdTekm."'>";

                    echo "Poročilo o tekmovanju v znanju<br />";
                    echo "<textarea name='komentar' cols='80' rows='10'>".$VPorocilo."</textarea><br />";

                    echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
                    echo "</form>";
                }
        }
        echo "</body>";
        echo "</html>";
    
        break;
    case "107": //vpis poročila za tekmovanja
        $areplace=array("'",chr(34));
        $VPorocilo = str_replace($areplace,"",$_POST["komentar"]);

        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $SQL = "UPDATE  tabdrtekm SET porocilo='" . $VPorocilo ."' WHERE Id=".$R["id"];
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu!<br />");
            }
        }

        if ($Opravila==1 ){
            $SQL = "SELECT tabdeldogodek.id FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos rezultatov šolskih športnih tekmovanj' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["id"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu!<br />");
                }
            }
        }
        header ("Location: tekmovanjakrozki.php?id=101");
        break;
    case "108": //priznanja za tekmovanja v PDF
        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VImeKrozka=$R["krozek"];
            $VMentor=$R["mentor"];
        }else{
            $VImeKrozka="";
            $VMentor="";
        }

        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddFont('castelar','','castelar.php');
        $pdf->AddFont('timesbd_CE','','timesbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabdrtekmclan.*,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.datroj,tabrazdat.* FROM ";
        $SQL = $SQL . "(((tabdrtekmclan INNER JOIN tabdrtekm ON tabdrtekmclan.idTekmovanje=tabdrtekm.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto." AND tabdrtekmclan.idTekmovanje=".$VIdTekm;
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx][1]=$R["ime"]." ".$R["priimek"];
            $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
            $ucenci[$Indx][3]=$R["datroj"];
            $ucenci[$Indx][4]=$R["spol"];
            switch ( $R["stopnja"]){
                case "Šolsko":
                case "Občinsko":
                case "Medobčinsko":
                case "Regijsko":
                case "Področno":
                case "Mestno":
                    $ucenci[$Indx][5]=$R["stopnja"]." tekmovanje";
                    break;
                default:
                    $ucenci[$Indx][5]=$R["stopnja"];
            }
            if (strlen($R["priznanje"])==1 ){
                $ucenci[$Indx][6]=$R["priznanje"].". mesto";
            }else{
                $ucenci[$Indx][6]=$R["priznanje"];
            }
            $Indx=$Indx+1;;
        }
        $StUcencev=$Indx-1;

        for ($IndxUcenec=1;$IndxUcenec <= $StUcencev;$IndxUcenec++){
            if ($IndxUcenec > 1 ){
                $pdf->AddPage("P","A4");
            }

            $Indx1=0;
            
            //logotip in črte
            $pdf->Image("logo1.gif",95, 40,30);
            $pdf->SetTextColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            $pdf->Line(30.0, 180, 167, 180);
            $pdf->Line(30.0, 200, 167, 200);
            $pdf->Line(30.0, 220, 167, 220);
            $pdf->Line(30.0, 240, 167, 240);
            
            //'naslov dokumenta
            $pdf->SetFont('arialbd_CE','',22);
            $txt=ToWin($VSola);
            $pdf->SetXY(10,20);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10,30);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('castelar','',64);
            $pdf->SetTextColor(0,0,255); //modra
            $txt=ToWin("PRIZNANJE");
            $pdf->SetXY(10,95);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arialbd_CE','',24);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin("za sodelovanje");
            $pdf->SetXY(10,120);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin("na tekmovanju v znanju");
            $pdf->SetXY(10,132);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetTextColor(255,0,0); //rdeča
            $txt=ToWin($VImeKrozka);
            $pdf->SetXY(10,144);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($ucenci[$IndxUcenec][5]);
            $pdf->SetXY(10,156);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('timesbd_CE','',30);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin($ucenci[$IndxUcenec][1].", ".$ucenci[$IndxUcenec][2]);
            $pdf->SetXY(10,190);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',24);
            $Datum=new DateTime(isDate($ucenci[$IndxUcenec][3]));
            if ($ucenci[$IndxUcenec][4]=="M" ){
                $txt=ToWin("rojen ".$Datum->format('j. n. Y'));
            }else{
                $txt=ToWin("rojena ".$Datum->format('j. n. Y'));
            }
            $pdf->SetXY(10,210);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',16);
            $txt=ToWin($ucenci[$IndxUcenec][6]);
            $pdf->SetXY(10,230);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Mentor");
            $pdf->SetXY(120,255);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VMentor);
            $pdf->SetXY(120,261);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $txt=ToWin("Kraj in datum:");
            $pdf->SetXY(15,255);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(15,261);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }    
        $pdf->Output("priznanja.pdf","D");
            
        break;
    case "109": //spisek tekmovanj
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        
        $SQL = "SELECT tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabdrtekm.leto, tabdrtekmclan.idTekmovanje,tabdrtekmclan.datum,tabdrtekmclan.kraj, Count(tabdrtekmclan.idTekmovanje) AS countofkrozek ";
        $SQL = $SQL."FROM tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.idTekmovanje = tabdrtekm.id " ;
        $SQL = $SQL."WHERE (((tabdrtekm.leto)=".$VLeto.")) ";
        $SQL = $SQL."GROUP BY tabdrtekm.leto, tabdrtekmclan.idTekmovanje, tabdrtekmclan.datum,tabdrtekmclan.kraj,tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor ";
        $SQL = $SQL." ORDER BY tabdrtekm.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<p>Za <font color='green'><b>izpis poročila o tekmovanju</b></font> kliknite na ime tekmovanja v stolpcu Tekmovanje.<br />";
        echo "Podatke o udeležencih in osvojenih priznanjih lahko popravite s klikom na <b>Popravi</b> v stolpcu Popravi";
        echo "</p>";

        echo "<h2>Tekmovanja v znanju v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Tekmovanje</th>";
        if ($VecSol > 0){
            echo "<th>Šola</th>";
        }
        echo "<th>Mentor</th>";
        echo "<th>Stopnja</th>";
        echo "<th>Kraj</th>";
        echo "<th>Datum</th>";
        echo "<th>Udeležencev</th>";
        echo "<th>Briši</th>";
        echo "<th>Popravi</th>";
        echo "</tr>";

        $Indx=1;
        $VCount[0][0]=0;
        while ($R = mysqli_fetch_array($result)){
            $VTekmovanje[$Indx]=$R["id"];
            $VCount[0][0]=$VCount[0][0]+$R["countofkrozek"];
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=110&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
            if ($VecSol > 0){
                echo "<td>";
                $sola="";
                if ($R["countofkrozek"] > 0){
                    $SQL = "SELECT DISTINCT tabsola.solakratko FROM ((tabdrtekmclan ";
                    $SQL .= "INNER JOIN tabrazred ON tabdrtekmclan.iducenec=tabrazred.iducenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL .= "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabdrtekmclan.idtekmovanje=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $sola = $sola . $R1["solakratko"]."<br />";
                    }
                }
                echo $sola."</td>";
            }
            echo "<td>".$R["mentor"]."</td>";
            echo "<td>".ToStopnja($R["stopnja"])."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=111&idtekm=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            echo "<td><a href='tekmovanjakrozki.php?id=102&idtekm=".$R["id"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        $StTekmovanj=$Indx-1;
        for ($i=0;$i <= $StTekmovanj;$i++){
            for ($j=0;$j <= 7;$j++){
                $VCount[$i][$j]=0;
            }
        }
        if ($VecSol > 0){
            echo "<tr><td></td><td>Skupaj</td><td></td><td></td><td></td><td></td><td></td><td align=center>".$VCount[0][0]."</td></tr>";
        }else{
            echo "<tr><td></td><td>Skupaj</td><td></td><td></td><td></td><td></td><td align=center>".$VCount[0][0]."</td></tr>";
        }
        echo "</table><br />";

        $SQL = "SELECT DISTINCT tabdrtekm.leto,tabdrtekmclan.leto,tabdrtekm.krozek,Count(tabdrtekmclan.tekmovanje) AS countofkrozek FROM ";
        $SQL = $SQL . "tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.Tekmovanje = tabdrtekm.krozek GROUP BY tabdrtekm.leto,tabdrtekm.krozek,tabdrtekmclan.leto HAVING tabdrtekm.leto=".$VLeto." AND tabdrtekmclan.leto=".$VLeto;
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        $VCount[0][0]=0;
        while ($R = mysqli_fetch_array($result)){
            $VTekmovanje[$Indx]=$R["krozek"];
            $VCount[0][0]=$VCount[0][0]+$R["countofkrozek"];
            $Indx=$Indx+1;
        }
        $StTekmovanj=$Indx-1;

        $SQL = "SELECT tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor,tabdrtekm.leto, tabdrtekmclan.idTekmovanje,tabdrtekmclan.datum,tabdrtekmclan.kraj, Count(tabdrtekmclan.idTekmovanje) AS countofkrozek " ;
        $SQL = $SQL."FROM tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekmclan.idTekmovanje = tabdrtekm.id " ;
        $SQL = $SQL."WHERE (((tabdrtekm.leto)=".$VLeto.")) ";
        $SQL = $SQL."GROUP BY tabdrtekm.leto, tabdrtekmclan.idTekmovanje, tabdrtekmclan.datum,tabdrtekmclan.kraj,tabdrtekm.id, tabdrtekm.krozek, tabdrtekm.stopnja,tabdrtekm.mentor ";
        $SQL = $SQL." ORDER BY tabdrtekm.krozek";
        $result = mysqli_query($link,$SQL);

        for ($Indx=1;$Indx <= $StTekmovanj;$Indx++){
            $SQL = "SELECT * FROM tabdrtekmclan WHERE Tekmovanje='".$VTekmovanje[$Indx]."' AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            
            while ($R = mysqli_fetch_array($result)){
                $VCount[$Indx][0]=$R["tekmovanje"];
                if ((is_numeric(strpos($R["priznanje"],"Bronast"))) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                    $VCount[$Indx][1]=$VCount[$Indx][1]+1;
                }
                if ((is_numeric(strpos($R["priznanje"],"Srebrn"))) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                    $VCount[$Indx][2]=$VCount[$Indx][2]+1;
                }
                if ((is_numeric(strpos($R["priznanje"],"Zlat"))) or (is_numeric(strpos($R["priznanje"],"zlat")))){
                    $VCount[$Indx][3]=$VCount[$Indx][3]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Šolsko"))){
                    $VCount[$Indx][4]=$VCount[$Indx][4]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Regijsko"))){
                    $VCount[$Indx][5]=$VCount[$Indx][5]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Področno"))){
                    $VCount[$Indx][6]=$VCount[$Indx][6]+1;
                }
                if (is_numeric(strpos($R["stopnja"],"Državno"))){
                    $VCount[$Indx][7]=$VCount[$Indx][7]+1;
                }
            }
        }

        echo "<h2>Preglednica osvojenih priznanj in udeležbe na tekmovanjih</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Tekmovanje</th>";
        echo "<th>Bronasto</th>";
        echo "<th>Srebrno</th>";
        echo "<th>Zlato</th>";
        echo "<th>Šolsko</th>";
        echo "<th>Regijsko</th>";
        echo "<th>Področno</th>";
        echo "<th>Državno</th>";
        echo "<th>Sodelovalo</th>";
        echo "</tr>";

        $VCount[0][0]=0;
        for ($Indx=1;$Indx <= $StTekmovanj;$Indx++){
            $VCount[0][0]=$VCount[0][0]+Max($VCount[$Indx]);
            $VCount[0][1]=$VCount[0][1]+$VCount[$Indx][1];
            $VCount[0][2]=$VCount[0][2]+$VCount[$Indx][2];
            $VCount[0][3]=$VCount[0][3]+$VCount[$Indx][3];
            $VCount[0][4]=$VCount[0][4]+$VCount[$Indx][4];
            $VCount[0][5]=$VCount[0][5]+$VCount[$Indx][5];
            $VCount[0][6]=$VCount[0][6]+$VCount[$Indx][6];
            $VCount[0][7]=$VCount[0][7]+$VCount[$Indx][7];
            echo "<tr>";
            echo "<td>".$VCount[$Indx][0]."</td>";
            echo "<td align=right>".$VCount[$Indx][1]."</td>";
            echo "<td align=right>".$VCount[$Indx][2]."</td>";
            echo "<td align=right>".$VCount[$Indx][3]."</td>";
            echo "<td align=right>".$VCount[$Indx][4]."</td>";
            echo "<td align=right>".$VCount[$Indx][5]."</td>";
            echo "<td align=right>".$VCount[$Indx][6]."</td>";
            echo "<td align=right>".$VCount[$Indx][7]."</td>";
            echo "<td align=right>".Max($VCount[$Indx])."</td>";
            echo "</tr>";
        }
        echo "<tr>";
        echo "<td>Skupaj</td>";
        echo "<td align=right>".$VCount[0][1]."</td>";
        echo "<td align=right>".$VCount[0][2]."</td>";
        echo "<td align=right>".$VCount[0][3]."</td>";
        echo "<td align=right>".$VCount[0][4]."</td>";
        echo "<td align=right>".$VCount[0][5]."</td>";
        echo "<td align=right>".$VCount[0][6]."</td>";
        echo "<td align=right>".$VCount[0][7]."</td>";
        echo "<td align=right>".$VCount[0][0]."</td>";
        echo "</tr>";

        echo "</table><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "110": //izpis podatkov o tekmovanju
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        
        echo "<br /><h2>Poročilo o tekmovanju</h2>";
        $SQL = "SELECT tabdrtekmclan.*,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
        $SQL = $SQL . "((tabdrtekmclan INNER JOIN tabucenci ON tabdrtekmclan.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.idTekmovanje=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "Tekmovanje: <b>".$R["tekmovanje"]."</b><br />";
            echo "Stopnja tekmovanja: <b>".$R["stopnja"]."</b><br />";
            echo "Kraj tekmovanja: <b>".$R["kraj"]."</b><br />";
            echo "Datum tekmovanja: <b>".$R["datum"]."</b><br />";
            echo "Mentor: <b>".$R["mentor1"]."</b><br /><br />";
        }
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Tekmovalec</th>";
        echo "<th>Mesto/Priznanje</th>";
        echo "<th>Napredovanje</th>";
        echo "</tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "<td>".$R["priznanje"]." &nbsp;</td>";
            if ($R["napredovanje"] ){
                echo "<td>Napredoval</td>";
            }else{
                echo "<td>&nbsp;</td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br /><br />";

        $SQL = "SELECT * FROM tabdrtekm WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<b>Poročilo</b>:<br />";
            echo str_replace(chr(13).chr(10),"<br />",$R["porocilo"])."<br />";
        }

        echo "</body>";
        echo "</html>";
        break;
    case "111": //briši tekmovanje
        $SQL = "SELECT tabdrtekm.*,tabdrtekmclan.* FROM tabdrtekm LEFT JOIN tabdrtekmclan ON tabdrtekm.id=tabdrtekmclan.idTekmovanje WHERE tabdrtekm.id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VUcitelj=$R["vpisal"];
            if ($VLevel > 1 ){
                $SQL = "DELETE FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
                $result = mysqli_query($link,$SQL);

                $SQL = "DELETE FROM tabdrtekm WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                echo "Izbrisano!<br />";
            }
            if (($VLevel < 2) && ($VUporabnik==$VUcitelj) ){
                $SQL = "DELETE FROM tabdrtekmclan WHERE idTekmovanje=".$VIdTekm;
                $result = mysqli_query($link,$SQL);

                $SQL = "DELETE FROM tabdrtekm WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                echo "Izbrisano!<br />";
            }
        }
        header ("Location: tekmovanjakrozki.php?id=109");
        break;
    case "112": //dobitniki srebrnih in zlatih priznanj
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";
        echo "<h2>Dobitniki srebrnih in zlatih priznanj</h2>";
        if ($VLeto <= 2008 ){
            $SQL = "SELECT DISTINCT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabrazred.osemdevet,tabopomini.Opis FROM ";
            $SQL = $SQL."((tabopomini INNER JOIN TabVzgUkrepi ON tabopomini.IdUkrep = TabVzgUkrepi.IdUkrep) ";
            $SQL = $SQL."INNER JOIN tabucenci ON TabVzgUkrepi.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL."INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec ";
            $SQL = $SQL."WHERE TabVzgUkrepi.IdUkrep IN (8,9,11,12,14,15,17,18,20,21,23,24,26,27,29,30,32,33,35,36,38,39,41,42,44,45) AND TabVzgUkrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
            $SQL = $SQL." ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabopomini.Opis";
            $result = mysqli_query($link,$SQL);

            echo "<table border=1>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$Indx."</td><td>".$R["priimek"].", ".$R["ime"]." ".$R["razred"].". ".strtolower($R["paralelka"])."</td><td>".$R["Opis"]."</td></tr>";
                $Indx = $Indx+1;
            } 
            echo "</table><br />";
            
            $SQL = "SELECT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.* FROM (tabdrtekmclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec ";
            $SQL = $SQL . "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND ((tabdrtekmclan.priznanje LIKE 'Zlato%') OR (tabdrtekmclan.priznanje LIKE 'Srebrno%')) ";
            $SQL = $SQL . "ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabdrtekmclan.priznanje";
            $result = mysqli_query($link,$SQL);

            echo "<table border=1>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Indx2=$Indx2+1;
                echo "<tr><td>".$Indx."</td><td>".$R["priimek"].", ".$R["ime"]." ".$R["razred"].". ".strtolower($R["paralelka"])."</td><td>".$R["tekmovanje"]."</td><td>".$R["priznanje"]."</td></tr>";
                $Indx = $Indx+1;
            } 
            echo "</table>";
        }else{
            $SQL = "SELECT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.*,tabdrtekm.*,tabsifranttekm.*,tabsola.solakratko FROM (((((tabdrtekmclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabdrtekm ON tabdrtekmclan.idTekmovanje=tabdrtekm.id) ";
            $SQL = $SQL . "INNER JOIN tabsifranttekm ON tabdrtekm.tip=tabsifranttekm.idTekmovanja) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL = $SQL . "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND ((tabdrtekmclan.priznanje LIKE 'Zlat%') OR (tabdrtekmclan.priznanje LIKE 'Srebrn%')) ";
            $SQL = $SQL . "ORDER BY tabrazdat.idsola,tabdrtekm.tip,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabdrtekmclan.priznanje";
            $result = mysqli_query($link,$SQL);

            echo "<table border=1>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$Indx."</td><td>".$R["priimek"].", ".$R["ime"]." ".$R["razred"].". ".$R["paralelka"]."</td>";
                if ($VecSol > 0){
                    echo "<td>".$R["solakratko"]."</td>";
                }
                echo "<td>".$R["tekmovanje"]."</td><td>".$R["opis"]."</td><td>".$R["priznanje"]."</td></tr>";
                $Indx = $Indx+1;
            } 
            echo "</table>";
            
            $SQL = "SELECT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.tekmovanje,tabdrtekmclan.stopnja,tabdrtekmclan.priznanje,tabsifranttekm.*,tabsola.solakratko FROM (((((tabdrtekmclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabdrtekm ON tabdrtekmclan.idTekmovanje=tabdrtekm.id) ";
            $SQL = $SQL . "INNER JOIN tabsifranttekm ON tabdrtekm.tip=tabsifranttekm.idTekmovanja) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL = $SQL . "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND ((tabdrtekmclan.priznanje LIKE '1. mesto%') OR (tabdrtekmclan.priznanje LIKE '2. mesto%') OR (tabdrtekmclan.priznanje LIKE '3. mesto%')) ";
            $SQL = $SQL . "ORDER BY tabrazdat.idsola,tabdrtekm.tip,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabdrtekmclan.priznanje";
            $result = mysqli_query($link,$SQL);

            echo "<h2>Uvrstitve med prve tri</h2>";
            echo "<table border=1>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr><td>".$Indx."</td><td>".$R["priimek"].", ".$R["ime"]." ".$R["razred"].". ".$R["paralelka"]."</td>";
                if ($VecSol > 0){
                    echo "<td>".$R["solakratko"]."</td>";
                }
                echo "<td>".$R["stopnja"]."</td><td>".$R["tekmovanje"]."</td><td>".$R["opis"]."</td><td>".$R["priznanje"]."</td></tr>";
                $Indx = $Indx+1;
            } 
            echo "</table>";
        }

        //'--------------------------------------------------------- Pohvale in priznanja - zacetek ---------------------------
        echo "<h2>Pohvale in priznanja v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
        if ($VLeto <= 2008 ){
            $SQL = "SELECT tabvzgukrepi.*,tabopomini.*,tabopomini.idukrep AS oidukrep,,tabucenci.*,tabrazred.* FROM ";
            $SQL .= "((tabvzgukrepi INNER JOIN tabopomini ON tabvzgukrepi.IdUkrep=tabopomini.IdUkrep) ";
            $SQL .= "INNER JOIN tabucenci ON tabvzgukrepi.IdUcenec=tabucenci.IdUcenec) ";
            $SQL .= "INNER JOIN tabrazred ON tabvzgukrepi.IdUcenec=tabrazred.IdUcenec ";
            $SQL .= "WHERE tabvzgukrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabopomini.Opis LIKE 'Pohvala%' ";
            $SQL .= "ORDER BY tabopomini.id";
            $result = mysqli_query($link,$SQL);

            For ($Indx=0;$Indx <= 200;$Indx++){
                $CountPohvala[$Indx]=0;
            }

            while ($R = mysqli_fetch_array($result)){
                $CountPohvala[$R["oidukrep"]]=$CountPohvala[$R["oidukrep"]]+1;
            }

            $CompPohvala="";
            echo "<table border=0>";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($CompPohvala != $R["Opis"] ){
                    echo "<tr><th>".$R["Opis"]."</th></tr>";
                    $CompPohvala=$R["Opis"];
                    if (is_numeric(strpos($R["Opis"],"Bronasto"))){
                        switch ( $CountPohvala[$R["oidukrep"]]){
                            case 1;
                                echo "<tr><td align=center>1 učenec</td></tr>";
                                break;
                            case 2:
                                echo "<tr><td align=center>2 učenca</td></tr>";
                                break;
                            case 3:
                            case 4:
                                echo "<tr><td align=center>".$CountPohvala[$R["oidukrep"]]." učenci</td></tr>";
                                break;
                            default:
                                echo "<tr><td align=center>".$CountPohvala[$R["oidukrep"]]." učencev</td></tr>";
                        }
                    }
                }
                if (is_numeric(strpos($R["Opis"],"Zlato"))){
                    echo "<tr><td align=center>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                }else{
                    if (is_numeric(strpos($R["Opis"],"Srebrno"))){
                        echo "<tr><td align=center>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]."</td></tr>";
                    }
                }
            }
            echo "</table><br />";
        }
            
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $sole=array();
        while ($R = mysqli_fetch_array($result)){
            $sole[$i][0]=$R["id"];
            $sole[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
        for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
            echo "<h2>".$sole[$IndxSola][1]."</h2>";
            $SQL = "SELECT DISTINCT tip,krozek FROM tabdrtekm WHERE leto=".$VLeto." ORDER BY tip,krozek";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $CountTekmovanja[$Indx]=$R["krozek"];
                $Indx=$Indx+1;
            }
            $StDrTekm=$Indx-1;
            
            For ($Indx=0;$Indx <= 200;$Indx++){
                $CountPohvalaDrT[$Indx][1]=0;
                $CountPohvalaDrT[$Indx][2]=0;
                $CountPohvalaDrT[$Indx][3]=0;
            }

            $SQL = "SELECT tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.*,tabdrtekm.*,tabsifranttekm.* FROM ((((tabdrtekmclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabdrtekm ON tabdrtekmclan.idTekmovanje=tabdrtekm.id) ";
            $SQL = $SQL . "INNER JOIN tabsifranttekm ON tabdrtekm.tip=tabsifranttekm.idTekmovanja) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabdrtekm.tip,tabdrtekmclan.Tekmovanje,tabdrtekmclan.priznanje,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";

            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= $StDrTekm;$Indx++){
                    if ($CountTekmovanja[$Indx]==$R["tekmovanje"] ){
                        if (is_numeric(strpos($R["priznanje"],"Zlat")) or (is_numeric(strpos($R["priznanje"],"zlat")))){
                            $CountPohvalaDrT[$Indx][1]=$CountPohvalaDrT[$Indx][1]+1;
                        }
                        if (is_numeric(strpos($R["priznanje"],"Srebrn")) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                            $CountPohvalaDrT[$Indx][2]=$CountPohvalaDrT[$Indx][2]+1;
                        }
                        if (is_numeric(strpos($R["priznanje"],"Bronast")) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                            $CountPohvalaDrT[$Indx][3]=$CountPohvalaDrT[$Indx][3]+1;
                        }
                    }
                }
            }

            $result = mysqli_query($link,$SQL);
            $CompPohvala="";
            $CompDrTekm=0;
            $CompTip=0;
            echo "<table border=0>";
            while ($R = mysqli_fetch_array($result)){
                if ($CompTip != $R["tip"] ){
                    echo "</table><br />";
                    echo "<h2>".$R["opis"]."</h2>";
                    echo "<table border=0>";
                    $CompTip=$R["tip"];
                }
                if ($CompPohvala != $R["tekmovanje"]){
                    echo "<tr><th>".$R["tekmovanje"]."</th></tr>";
                    $CompPohvala=$R["tekmovanje"];
                    for ($Indx=1;$Indx <= $StDrTekm;$Indx++){
                        if ($CompPohvala == $CountTekmovanja[$Indx]){
                            $CompDrTekm=$Indx;
                        }
                    }
                    if (is_numeric(strpos($R["priznanje"],"Bronast")) or (is_numeric(strpos($R["priznanje"],"bronast")))){
                        switch ( $CountPohvalaDrT[$CompDrTekm][3]){
                            case 1:
                                echo "<tr><td align=center>1 učenec - bronasto priznanje</td></tr>";
                                break;
                            case 2:
                                echo "<tr><td align=center>2 učenca - bronasto priznanje</td></tr>";
                                break;
                            case 3:
                            case 4:
                                echo "<tr><td align=center>".$CountPohvalaDrT[$CompDrTekm][3]." učenci - bronasto priznanje</td></tr>";
                                break;
                            default:
                                echo "<tr><td align=center>".$CountPohvalaDrT[$CompDrTekm][3]." učencev - bronasto priznanje</td></tr>";
                        }
                    }
                }
                if (is_numeric(strpos($R["priznanje"],"Zlat")) or (is_numeric(strpos($R["priznanje"],"zlat")))){
                    echo "<tr><td align=center><font color='blue'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]." - zlato priznanje</font></td></tr>";
                }else{
                    if (is_numeric(strpos($R["priznanje"],"Srebrn")) or (is_numeric(strpos($R["priznanje"],"srebrn")))){
                        echo "<tr><td align=center><font color='green'>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["paralelka"]." - srebrno priznanje</font></td></tr>";
                    }
                }
            }
            echo "</table><br />";
        }    
        //'--------------------------------------------------------- Pohvale in priznanja - konec ---------------------------

        if ($VLeto <= 2008 ){
            echo "<h3>Tekmovanja v znanju po razredih</h3>";
            $SQL = "SELECT tabvzgukrepi.leto,tabopomini.id,tabopomini.opis,tabrazred.razred,tabrazred.paralelka,tabrazred.leto,Count(tabvzgukrepi.leto) AS StPriznanj FROM ";
            $SQL = $SQL . "(tabvzgukrepi INNER JOIN tabopomini ON tabvzgukrepi.IdUkrep=tabopomini.IdUkrep) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabvzgukrepi.IdUcenec=tabrazred.IdUcenec ";
            $SQL = $SQL . "GROUP BY tabvzgukrepi.leto,tabopomini.id,tabopomini.Opis,tabrazred.razred,tabrazred.paralelka,tabrazred.leto ";
            $SQL = $SQL . "HAVING tabvzgukrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabopomini.Opis LIKE 'Pohvala%' ";
            $SQL = $SQL . "ORDER BY tabrazred.razred,tabrazred.paralelka,tabopomini.id";
            $result = mysqli_query($link,$SQL);

            $CompRazred="";
            while ($R = mysqli_fetch_array($result)){
                if ($CompRazred != $R["razred"].". ".strtolower($R["paralelka"]) ){
                    echo "<br /><b>Priznanja v ".$R["razred"].". ".strtolower($R["paralelka"])."</b><br />";
                    echo mb_substr($R["opis"],strlen($R["opis"])-10-1,strlen($R["opis"])-10,$encoding)." (".$R["StPriznanj"].")" ;
                    $CompRazred = $R["razred"].". ".strtolower($R["paralelka"]);
                }else{
                    echo ", ".mb_substr($R["opis"],strlen($R["opis"])-10-1,strlen($R["opis"])-10,$encoding)." (".$R["StPriznanj"].")" ;
                }
            }
            echo "<br />";
        }    
        if ($VLeto <= 2008 ){
            echo "<h3>Druga tekmovanja v znanju po razredih</h3>";
        }else{
            echo "<h3>Tekmovanja v znanju po razredih</h3>";
        }
        $SQL = "SELECT tabdrtekmclan.leto,tabdrtekmclan.idTekmovanje,tabdrtekmclan.tekmovanje,tabdrtekmclan.priznanje,tabrazred.razred,tabrazred.paralelka,tabrazred.leto,Count(tabdrtekmclan.idTekmovanje) AS StPriznanj,tabrazdat.idsola FROM ";
        $SQL = $SQL . "(tabdrtekmclan INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL = $SQL . "GROUP BY tabrazdat.idsola,tabdrtekmclan.leto,tabdrtekmclan.idTekmovanje,tabdrtekmclan.tekmovanje,tabdrtekmclan.priznanje,tabrazred.razred,tabrazred.paralelka,tabrazred.leto ";
        $SQL = $SQL . "HAVING tabdrtekmclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." ";
        $SQL = $SQL . "ORDER BY tabrazdat.idsola,tabrazred.razred,tabrazred.paralelka,tabdrtekmclan.tekmovanje";
        $result = mysqli_query($link,$SQL);

        $CompRazred="";
        if ($VecSol > 0){
            while ($R = mysqli_fetch_array($result)){
                if ($CompRazred != $R["razred"].". ".$R["paralelka"].$R["idsola"]){
                    echo "<br /><b>Priznanja v ".$R["razred"].". ".$R["paralelka"];
                    $SQL = "SELECT solakratko FROM tabsola WHERE id=".$R["idsola"];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        echo " - ".$R1["solakratko"];
                    }
                    echo "</b><br />";
                    echo $R["tekmovanje"]." - ".$R["priznanje"]." (".$R["StPriznanj"].")" ;
                    $CompRazred = $R["razred"].". ".$R["paralelka"].$R["idsola"];
                }else{
                    echo ", ".$R["tekmovanje"]." - ".$R["priznanje"]." (".$R["StPriznanj"].")" ;
                }
            }
        }else{
            while ($R = mysqli_fetch_array($result)){
                if ($CompRazred != $R["razred"].". ".$R["paralelka"]){
                    echo "<br /><b>Priznanja v ".$R["razred"].". ".$R["paralelka"]."</b><br />";
                    echo $R["tekmovanje"]." - ".$R["priznanje"]." (".$R["StPriznanj"].")" ;
                    $CompRazred = $R["razred"].". ".$R["paralelka"];
                }else{
                    echo ", ".$R["tekmovanje"]." - ".$R["priznanje"]." (".$R["StPriznanj"].")" ;
                }
            }
        }
        echo "</body>";
        echo "</html>";
        break;
    case "113": //izpis dr tekm poročila
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=101'>Na seznam</a><br />";

        echo "<br><h2>Poročila o tekmovanjih</h2>";

        $SQL = "SELECT id FROM tabdrtekm WHERE leto=".$VLeto." ORDER BY tip,krozek,stopnja,mentor";
        $result1 = mysqli_query($link,$SQL);

        while ($R1 = mysqli_fetch_array($result1)){
            $VStamp=$R1["id"];
            $SQL = "SELECT tabdrtekmclan.mentor1,tabdrtekmclan.napredovanje,tabdrtekmclan.tekmovanje,tabdrtekmclan.stopnja,tabdrtekmclan.kraj,tabdrtekmclan.datum,tabdrtekmclan.priznanje,tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka FROM ";
            $SQL = $SQL . "((tabdrtekmclan INNER JOIN tabucenci ON tabdrtekmclan.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdrtekmclan.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabdrtekmclan.idTekmovanje=".$VStamp;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "Tekmovanje: <b>".$R["tekmovanje"]."</b><br />";
                echo "Stopnja tekmovanja: <b>".$R["stopnja"]."</b><br />";
                echo "Kraj tekmovanja: <b>".$R["kraj"]."</b><br />";
                echo "Datum tekmovanja: <b>".$R["datum"]."</b><br />";
                echo "Mentor: <b>".$R["mentor1"]."</b><br /><br />";
            }
            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Št.</th>";
            echo "<th>Tekmovalec</th>";
            echo "<th>Mesto/Priznanje</th>";
            echo "<th>Napredovanje</th>";
            echo "</tr>";

            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                echo "<td>".$R["priznanje"]." &nbsp;</td>";
                if ($R["napredovanje"]){
                    echo "<td>Napredoval</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br /><br />";

            $SQL = "SELECT * FROM TabDrTekm WHERE id=".$VStamp;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<b>Poročilo</b>:<br />";
                echo str_replace("\n","<br />",$R["porocilo"]." ")."<br /><hr><br />";
            }
        }
        echo "</body>";
        echo "</html>";
        break;
    case "201": // izbor krožka
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        
        switch ( $VIdTekm){
            case "1":
                if ((strlen($VKrozek)==0) or (strlen($VMentor)==0) ){
                    echo "<h2>Interesna dejavnost ni bila dodana!</h2>";
                }else{
                    $SQL = "INSERT INTO tabkrozki (leto,krozek,mentor) VALUES (".$VLeto.",'".$VKrozek."','".$VMentor."')";
                    $result = mysqli_query($link,$SQL);
                    
                    echo "<h2>Dodana je bila interesna dejavnost: ".$VKrozek." - ".$VMentor."</h2>";
                }
        }

        $SQL = "SELECT tabkrozki.id, tabkrozki.krozek, tabkrozki.mentor,tabkrozki.leto, tabkrozki.planirano,tabkrozki.realizirano,tabkrozki.obisk,tabkrozekclan.krozek AS ckrozek,tabkrozki.porocilo,  Count(tabkrozekclan.krozek) AS countofkrozek " ;
        $SQL = $SQL."FROM tabkrozki LEFT JOIN tabkrozekclan ON tabkrozekclan.krozek = tabkrozki.id " ;
        $SQL = $SQL."WHERE (((tabkrozki.leto)=".$VLeto.")) ";
        $SQL = $SQL."GROUP BY tabkrozki.leto, tabkrozekclan.krozek, tabkrozki.id, tabkrozki.krozek, tabkrozki.mentor, tabkrozki.planirano,tabkrozki.realizirano,tabkrozki.obisk ";
        //$SQL = $SQL."HAVING (((tabkrozki.leto)=".$VLeto.")) ORDER BY tabkrozki.krozek";
        $SQL = $SQL." ORDER BY tabkrozki.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izbor interesne dejavnosti - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p>Če vaše interesne dejavnosti še ni v spodnjem spisku, jo vpišite, pri tem pa pazite na to, da se bodo na nivoju šole uporabljale <b>enotne oznake imen interesnih dejavnosti</b>.<br />";
        echo "<b>Postopek vpisa:</b><br />";
        echo "1. Vpis imena interesne dejavnosti in mentorja<br />";
        echo "2. Klik na ime interesne dejavnosti za izbor udeležencev ID s spiska učencev<br />";
        echo "3. Klik na Poglej/popravi za vpis poročila in realizacije<br />";
        echo "<font color='green'>Osnovne podatke o tekmovanju lahko popravite s klikom na <b>Poglej/popravi</b> v stolpcu Poročilo</font><br />";
        echo "<br />";
        echo "Standardna priznanja lahko izpišete s klikom na <b>Priznanja</b> v stolpcu Priznanja<br />";
        echo "<br />";
        echo "Za spisek udeležencev po interesnih dejavnostih in izpise ID po učencih kliknite <a href='tekmovanjakrozki.php?id=203'>tukaj</a> ali <a href='tekmovanjakrozki.php?id=211'>tukaj (PDF)</a>.<br />";
        echo "Za izpis obvestil (priloga spričevalu) o sodelovanju na interesnih dejavnostih in tekmovanjih kliknite <a href='izborrazreda.php?id=interesne1'>tukaj (Word)</a>.<br />";

        echo "</p>";

        echo "<form name='Krozki' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='201'>";
        echo "<table border=1 cellspacing=0>";
        if ($VecSol > 0){
            if ($VLevel > 1 ){
                echo "<tr><th>Št.</th><th>Krožek</th><th>Šola</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Priznanja</th><th>Poročilo</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Št.</th><th>Krožek</th><th>Šola</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Priznanja</th><th>Poročilo</th></tr>";
            }
        }else{
            if ($VLevel > 1 ){
                echo "<tr><th>Št.</th><th>Krožek</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Priznanja</th><th>Poročilo</th><th>Briši</th></tr>";
            }else{
                echo "<tr><th>Št.</th><th>Krožek</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Priznanja</th><th>Poročilo</th></tr>";
            }
        }
        $Indx=1;
        $Sodelujocih=0;
        $Plan=0;
        $Realizacija=0;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=202&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
            if ($VecSol > 0){
                echo "<td>";
                $sola="";
                if ($R["countofkrozek"] > 0){
                    $SQL = "SELECT DISTINCT tabsola.solakratko FROM ((tabkrozekclan ";
                    $SQL .= "INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.iducenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL .= "WHERE tabkrozekclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabkrozekclan.krozek=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $sola = $sola . $R1["solakratko"]."<br />";
                    }
                }
                echo $sola."</td>";
            }
            echo "<td>".$R["mentor"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            $Sodelujocih += $R["countofkrozek"];
            echo "<td align=center>".$R["planirano"]."</td>";
            $Plan += $R["planirano"];
            echo "<td align=center>".$R["realizirano"]."</td>";
            $Realizacija += $R["realizirano"];
            if (is_numeric($R["planirano"]) ){
                if ($R["planirano"] > 0 ){
                    echo "<td align=center>".number_format($R["realizirano"]/$R["planirano"]*100,2)."</td>";
                }else{
                    echo "<td align=center>&nbsp;</td>";
                }
            }else{
                echo "<td align=center>&nbsp;</td>";
            }
            echo "<td align=center>".$R["obisk"]."</td>";
            
            if ($R["countofkrozek"] > 0 ){
                echo "<td><a href='tekmovanjakrozki.php?id=207&leto=".$VLeto."&krozek=".$R["id"]."'>Priznanja</a></td>";
            }else{
                echo "<td></td>";
            }
            if (isset($R["porocilo"]) && strlen($R["porocilo"]) > 0){
                echo "<td bgcolor='lightgreen'>";
            }else{
                echo "<td bgcolor='red'>";
            }
            echo "<a href='tekmovanjakrozki.php?id=209&idtekm=".$R["id"]."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            if ($VLevel > 1 ){
                echo "<td><a href='tekmovanjakrozki.php?id=209&idtekm=".$R["id"]."&brisi=1'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        //skupaj
        echo "<tr><td colspan='3'>Skupaj</td><td align='center'>$Sodelujocih</td><td align='center'>$Plan</td><td align='center'>$Realizacija</td><td colspan='3'>&nbsp;</td></tr>";
        
        if ($VecSol > 0){
            echo "<tr><td></td><td><input name='krozek' type='text' size='30'></td><td></td><td><input name='mentor' type='text' size='30'></td><td></td><td></td><td></td><td></td><td></td><td><input name='idtekm' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
        }else{
            echo "<tr><td></td><td><input name='krozek' type='text' size='30'></td><td><input name='mentor' type='text' size='30'></td><td></td><td></td><td></td><td></td><td></td><td><input name='idtekm' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
        }
        echo "</table><br />";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "202": //dodeli učence krožku
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=201'>Na seznam</a><br />";
        
        $SQL = "SELECT tabkrozekclan.id AS cid,tabkrozki.krozek,tabkrozki.mentor,tabucenci.*,tabrazdat.* FROM ";
        $SQL = $SQL . "(((tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabkrozekclan.ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozekclan.krozek=".$VIdTekm;
        $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["krozek"]." - ".$R["mentor"]."</h2>";
        }

        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th><th>Ime</th><th>Priimek</th><th>Razred</th><th>Dat. roj.</th><th>Kontakt</th><th>Mentor</th><th>Briši</th>";
        echo "</tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["Ime"]."</td><td>".$R["Priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
            $Datum=new DateTime(isDate($R["DatRoj"]));
            echo "<td align='right'>".$Datum->format('d.m.Y')."</td>";
            echo "<td>".$R["ocekontakt"].", ".$R["oceGSM"].", ".$R["matikontakt"].", ".$R["matiGSM"].", ".$R["SkrbnikiKontakt"]."</td>";
            echo "<td>".$R["mentor"]."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=204&idtekm=".$R["cid"]."&krozek=".$VIdTekm."&solskoleto=".$VLeto."'>Briši</a></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<a href='izpisrazreda.php?id=7&krozek=".$VIdTekm."'>Pošiljanje e-pošte staršem</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=207&solskoleto=".$VLeto."&krozek=".$VIdTekm."'>Izpis priznanj - standardno</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=205&solskoleto=".$VLeto."&krozek=".$VIdTekm."'>Spisek udeležencev ID</a><br /><br />";

        echo "<form name='izpisi' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='208'>";

        $VFile="Predloga";

        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
        echo "<input name='krozek' type='hidden' value='".$VIdTekm."'>";

        $SQL = "SELECT priznanje FROM TabDiploma ORDER BY priznanje";
        $result = mysqli_query($link,$SQL);

        echo "Izpis po predlogi: <select name='fileizbrani'>";

        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<option>".$R["priznanje"]."</option>";
            }
        }else{
            echo "<option>".$VFile."</option>";
        }
        echo "</select>";
        echo "<input type='submit' name='submit' value='Izberi'>";
        echo "</form><br />";

        $SQL = "SELECT * FROM tabkrozki WHERE id=". $VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo"<h2>Vpis učencev na interesni dejavnosti<br />";
              echo $R["krozek"]."</h2><br />";
        }else{
            header ("Location: tekmovanjakrozki.php?id=201");
        }

        echo "<form name='tekmovanja' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='206'>";
        echo "<input type='hidden' name='krozek' value='".$VIdTekm."'>";
        echo "<table border=0>";
        echo "<tr>";
        echo "    <td>";
        echo "Šolsko leto: <select name='solskoleto'>";
        echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
        echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . $VLeto . "</option>";
        echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
        echo "        </select>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        Vpisani na interesno dejavnost:<br />";
        echo "        (Več naenkrat jih lahko označite s <br />skupnim pritiskom tipke Ctrl in levim klikom)";
        echo "    </td>";
        echo "    <td>";
        echo "        <select name='vpisani[]' multiple='multiple' size='30'>";
        
        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0";
        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
        }
        echo "        </select>";
        echo "    </td>";
        echo "</tr>";
        echo "<tr>";
        echo "    <td>";
        echo "        <input name='submit' type='submit' value='Pošlji'>";
        echo "    </td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "203": // spisek krožkov z udeleženci
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=201'>Na seznam</a><br />";
        
        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabkrozekclan.*,tabkrozki.mentor,tabkrozki.krozek AS kkrozek FROM ";
        $SQL = $SQL ."((tabrazred INNER JOIN tabkrozekclan ON tabrazred.idUcenec=tabkrozekclan.Ucenec) ";
        $SQL = $SQL ."INNER JOIN tabucenci ON tabkrozekclan.Ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL ."INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
        $SQL = $SQL ."WHERE tabrazred.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozki.leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tabkrozki.krozek,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        $CompPomoc="";
        $Indx=1;
        echo "<table>";
        while ($R = mysqli_fetch_array($result)){
            $VPomoc=$R["kkrozek"];
            if ($VPomoc <> $CompPomoc ){
                echo "</table><br />";
                $Indx=1;
                echo "<h2>".$VPomoc." - ".$R["mentor"]."</h2>";
                echo "<table border=1>";
                echo "<tr>";
                //echo "<th>Št.</th><th>Učenec</th>";
                echo "<th width='20'>Št.</th><th width='120'>Ime</th><th width='150'>Priimek</th><th width='40'>Razred</th><th width='150'>Mentor</th>";
                echo "</tr>";
                $CompPomoc=$VPomoc;
            }    
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["ime"]."</td><td>".$R["priimek"]."</td><td>".$R["razred"].". ".$R["paralelka"]."</td><td>".$R["mentor"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<hr>";

        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabkrozekclan.*,tabkrozki.mentor,tabkrozki.krozek AS kkrozek FROM ";
        $SQL = $SQL ."((tabrazred INNER JOIN tabkrozekclan ON tabrazred.idUcenec=tabkrozekclan.Ucenec) ";
        $SQL = $SQL ."INNER JOIN tabucenci ON tabkrozekclan.Ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL ."INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
        $SQL = $SQL ."WHERE tabrazred.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozki.leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        $CompPomoc="";
        $Indx=1;
        echo "<table border=1>";
        //echo "<tr><th>Ime</th><th>št.</th><th>Interesna dejavnost</th><th>Mentor</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            $VPomoc=$R["priimek"]." ".$R["ime"];
            if ($VPomoc != $CompPomoc ){
                echo "<tr>";
                $Indx=1;
                echo "<td colspan='3' bgcolor='lightgreen'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                echo "</tr>";
                $CompPomoc=$VPomoc;
            }    
            echo "<tr>";
            //echo "<td></td>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["kkrozek"]."</td><td>".$R["mentor"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "204": //briši krožek - učenec
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        $SQL = "DELETE FROM tabkrozekclan WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);
        header ("Location: tekmovanjakrozki.php?id=202&idtekm=".$VKrozek."&solskoleto=".$VLeto);
        break;
    case "205": //krožek udeleženci - s slikami
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=201'>Na seznam</a><br />";
        
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        $SQL = "SELECT tabkrozekclan.*,tabkrozki.krozek AS kkrozek,tabkrozki.mentor,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
        $SQL = $SQL . "(((tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabkrozekclan.ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozekclan.krozek=".$VKrozek;
        $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["kkrozek"]." - ".$R["mentor"]."</h2>";
        }

        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th><th>Slika</th><th>Ime</th><th>Priimek</th><th>Razred</th>";
        echo "</tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><img src='slike/".$VLeto."_".$R["iducenec"].".jpg' width='50' onmouseover='width+=100' onmouseout='width-=100'></td>";
            echo "<td>".$R["ime"]."</td><td>".$R["priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";

        echo "</body>";
        echo "</html>";
        break;
    case "206": //vpis krožkov - udeležencev
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        
        $VSkupaj=200;
        if (isset($_POST["vpisani"])){
            $VTekmovalci=Arr2Str($_POST["vpisani"]);
        }else{
            $VTekmovalci="";
        }
        if (strlen($VTekmovalci) > 0){
            $SQL = "SELECT tabucenci.iducenec FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Vvpisani[$Indx]=$R["iducenec"];
                $Indx=$Indx+1;
            }
            $VSkupaj=$Indx-1;

            $VStamp=$Danes->format('Y-m-d H:i:s');

            for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
                if ($Vvpisani[$Indx] > 0 ){
                    $SQL = "SELECT * FROM tabkrozekclan WHERE ucenec=".$Vvpisani[$Indx]." AND krozek=".$VKrozek;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "Učenec ".$R["ucenec"]." je že vpisan.<br />";
                    }else{
                        $SQL = "INSERT INTO tabkrozekclan (leto,krozek,ucenec,avtor,datum) VALUES (".$VLeto.",".$VKrozek.",".$Vvpisani[$Indx].",'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }
        }
        echo "Vpisano je bilo:<br />";
        $SQL = "SELECT tabkrozki.krozek,tabkrozki.mentor FROM ((tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.Id) INNER JOIN tabucenci ON tabkrozekclan.ucenec=tabucenci.idUcenec) INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.idUcenec WHERE tabrazred.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozekclan.krozek=".$VKrozek;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["krozek"]." - ".$R["mentor"]."</h2>";
        }

        if ($Opravila==1 ){
            $SQL = "SELECT tabdogodek.*,tabdeldogodek.id AS did FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Poročilo o interesni dejavnosti' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["did"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        header ("Location: tekmovanjakrozki.php?id=202&idtekm=".$VKrozek);
        break;
    case "207": //krožki priznanja PDF
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }

        $SQL = "SELECT * FROM tabkrozki WHERE id=".$VKrozek;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VImeKrozka=$R["krozek"];
            $VMentor=$R["mentor"];
        }else{
            $VImeKrozka="";
            $VMentor="";
        }

        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddFont('castelar','','castelar.php');
        $pdf->AddFont('timesbd_CE','','timesbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabkrozekclan.*,tabkrozki.*,tabucenci.ime,tabucenci.priimek,tabucenci.datroj,tabucenci.spol,tabrazdat.* FROM ";
        $SQL = $SQL . "(((tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabkrozekclan.ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozekclan.krozek=".$VKrozek;
        $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime";
        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx][1]=$R["ime"]." ".$R["priimek"];
            $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
            $ucenci[$Indx][3]=$R["datroj"];
            $ucenci[$Indx][4]=$R["spol"];
            $Indx=$Indx+1;;
        }
        $StUcencev=$Indx-1;

        for ($IndxUcenec=1;$IndxUcenec <= $StUcencev;$IndxUcenec++){
            if ($IndxUcenec > 1 ){
                $pdf->AddPage("P","A4");
            }

            $Indx1=0;
            
            //logotip in črte
            $pdf->Image("logo1.gif",90, 40,30);
            $pdf->SetTextColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            $pdf->Line(30.0, 180, 167, 180);
            $pdf->Line(30.0, 200, 167, 200);
            $pdf->Line(30.0, 220, 167, 220);
            
            //'naslov dokumenta
            $pdf->SetFont('arialbd_CE','',22);
            $txt=ToWin($VSola);
            $pdf->SetXY(10,20);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10,30);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('castelar','',64);
            $pdf->SetTextColor(0,0,255); //modra
            $txt=ToWin("PRIZNANJE");
            $pdf->SetXY(10,100);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arialbd_CE','',24);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin("za obiskovanje");
            $pdf->SetXY(10,120);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin("interesne dejavnosti");
            $pdf->SetXY(10,132);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetTextColor(255,0,0); //rdeča
            $txt=ToWin($VImeKrozka);
            $pdf->SetXY(10,150);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('timesbd_CE','',30);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin($ucenci[$IndxUcenec][1].", ".$ucenci[$IndxUcenec][2]);
            $pdf->SetXY(10,190);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',24);
            $Datum=new DateTime(isDate($ucenci[$IndxUcenec][3]));
            if ($ucenci[$IndxUcenec][4]=="M" ){
                $txt=ToWin("rojen ".$Datum->format('j. n. Y'));
            }else{
                $txt=ToWin("rojena ".$Datum->format('j. n. Y'));
            }
            $pdf->SetXY(10,210);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Izvajalec");
            $pdf->SetXY(120,261);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VMentor);
            $pdf->SetXY(120,267);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $txt=ToWin("Kraj in datum:");
            $pdf->SetXY(15,261);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(15,267);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }    
        $pdf->Output("priznanja.pdf","D");
        break;
    case "208": //ID priznanja učenci
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }

        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=201'>Na seznam</a><br />";
        
        $WSola = 0;
        $WNaslov = 0;
        $WPriznanje = 0;
        $WVrstica1 = 0;
        $WVrstica2 = 0;
        $WDejavnost = 0;
        $WKrajDat = 0;
        $WNazivIzv = 0;
        $WIzvajalec = 0;
        $WIme = 0;
        $WRazred = 0;
        $WDatRoj = 0;

        echo "<form name='tekmovanja' method='post' action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='502'>";
        $VFile=$_POST["fileizbrani"];
        $SQL = "SELECT * FROM tabdiploma WHERE priznanje='".$VFile."'";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["sola"];
            $VNaslov=$R["naslov"];
            $VRavnatelj=$R["ravnatelj"];
            $VKraj=$R["kraj"];

            $VIzvajalec = $R["izvajalec"];
            $VPriznanje = $R["diploma"];
            $VLine1 = $R["line1"];
            $VLine2 = $R["line2"];
            $VVsebina = $R["vsebina"];
            $VDatum = "";

            $PozXSola=$R["PozXSola"];
            $PozYSola=$R["PozYSola"];
            $PozXNaslov=$R["PozXNaslov"];
            $PozYNaslov=$R["PozYNaslov"];
            $PozXRavnatelj=$R["PozXRavnatelj"];
            $PozYRavnatelj=$R["PozYRavnatelj"];
            $PozXKraj=$R["PozXKraj"];
            $PozYKraj=$R["PozYkraj"];
            $PozXIzvajalec=$R["PozXIzvajalec"];
            $PozYIzvajalec=$R["PozYIzvajalec"];
            $PozXPriznanje=$R["PozXPriznanje"];
            $PozYPriznanje=$R["PozYpriznanje"];
            $PozXLine1=$R["PozXLine1"];
            $PozYLine1=$R["PozYLine1"];
            $PozXLine2=$R["PozXLine2"];
            $PozYLine2=$R["PozYLine2"];
            $PozXVsebina=$R["PozXVsebina"];
            $PozYVsebina=$R["PozYVsebina"];
            $PozXDatum=$R["PozXDatum"];
            $PozYDatum=$R["PozYDatum"];
            $PozXLogo=$R["PozXLogo"];
            $PozYLogo=$R["PozYLogo"];
            $PozXIme=$R["PozXIme"];
            $PozYIme=$R["PozYIme"];
            $PozX1Crta1=$R["PozX1Crta1"];
            $PozY1Crta1=$R["PozY1Crta1"];
            $PozX2Crta1=$R["PozX2Crta1"];
            $PozY2Crta1=$R["PozY2Crta1"];
            $PozX1Crta2=$R["PozX1Crta2"];
            $PozY1Crta2=$R["PozY1Crta2"];
            $PozX2Crta2=$R["PozX2Crta2"];
            $PozY2Crta2=$R["PozY2Crta2"];
            $PozX1Crta3=$R["PozX1Crta3"];
            $PozY1Crta3=$R["PozY1Crta3"];
            $PozX2Crta3=$R["PozX2Crta3"];
            $PozY2Crta3=$R["PozY2Crta3"];
            $VFile=$R["priznanje"];
            $LogoSize=$R["LogoSize"];
            $PorSola=$R["PorSola"];
            $PorRavnatelj=$R["PorRavnatelj"];
            $PorKraj=$R["PorKraj"];
            $PorIzvajalec=$R["PorRavnatelj"];
            $PorPriznanje=$R["PorPriznanje"];
            $PorLine1=$R["PorLine1"];
            $PorLine2=$R["PorLine2"];
            $PorVsebina=$R["PorVsebina"];
            $PorDatum=$R["PorDatum"];
            $PorIme=$R["PorIme"];
            $PorNaslov=$R["PorNaslov"];
            $FSSola=$R["FSSola"];
            $FSRavnatelj=$R["FSRavnatelj"];
            $FSKraj=$R["FSKraj"];
            $FSIzvajalec=$R["FSIzvajalec"];
            $FSPriznanje=$R["FSPriznanje"];
            $FSLine1=$R["FSLine1"];
            $FSLine2=$R["FSLine2"];
            $FSVsebina=$R["FSVsebina"];
            $FSDatum=$R["FSDatum"];
            $FSIme=$R["FSIme"];
            $FSNaslov=$R["FSNaslov"];
            $VFont=$R["Font"];
            if (isset($R["ozadje"])){
                $VOzadje = $R["ozadje"];
            }else{
                $VOzadje = "";
            }
            if (isset($R["PozXRazred"])){
                $PozXRazred = $R["PozXRazred"];
            }else{
                $PozXRazred = 0;
            }
            if (isset($R["PozYRazred"])){
                $PozYRazred = $R["PozYRazred"];
            }else{
                $PozYRazred = 0;
            }
            if (isset($R["PorRazred"])){
                $PorRazred = $R["PorRazred"];
            }else{
                $PorRazred = 0;
            }
            if (isset($R["FSRazred"])){
                $FSRazred = $R["FSRazred"];
            }else{
                $FSRazred = 24;
            }
            if (isset($R["wsola"])) $WSola = $R["wsola"];
            if (isset($R["wnaslov"])) $WNaslov = $R["wnaslov"];
            if (isset($R["wpriznanje"])) $WPriznanje = $R["wpriznanje"];
            if (isset($R["wvrstica1"])) $WVrstica1 = $R["wvrstica1"];
            if (isset($R["wvrstica2"])) $WVrstica2 = $R["wvrstica2"];
            if (isset($R["wdejavnost"])) $WDejavnost = $R["wdejavnost"];
            if (isset($R["wkrajdat"])) $WKrajDat = $R["wkrajdat"];
            if (isset($R["wnazivizv"])) $WNazivIzv = $R["wnazivizv"];
            if (isset($R["wizvajalec"])) $WIzvajalec = $R["wizvajalec"];
            if (isset($R["wime"])) $WIme = $R["wime"];
            if (isset($R["wrazred"])) $WRazred = $R["wrazred"];
            if (isset($R["wdatroj"])) $WDatRoj = $R["wdatroj"];
        }

        echo "Meri se X od levega roba in Y od zgornjega roba na listu A4.<br />";
        echo "Koordinate se nanašajo na zgornji levi/desni kot ali sredino napisa. 0-leva poravnava, 1-centrirano, 2-desna poravnava.<br />";
        echo "V primeru sredinske (1) in desne (2) poravnave vpišite začetno točko (x,y) in širino polja.<br />";
        echo "Črte imajo začetno in končno točko. <br />";
        echo "Če rubrike ne želite, jo pustite prazno ali pa ji dajte X koordinato na 0. <br />";
        echo "<br />";

        echo "<table border=0>";

        echo "<tr><th>Rubrika</th><th>Vsebina</th><th>Koordinata X</th><th>Koordinata Y</th><th>Širina<br /><small>(0=do desnega roba)</small></th><th>Poravnava</th><th>Velikost<br />pisave</th></tr>";
        echo "<tr><td>Šola:</td><td><input name='sola' type='text' value='".$VSola."' size='40'>";
        echo "</td><td><input type='text' name='PozXSola' value='".$PozXSola."' size='5'></td>";
        echo "<td><input type='text' name='PozYSola' value='".$PozYSola."' size='5'></td>";
        echo "<td><input type='text' name='wsola' value='".$WSola."' size='5'></td>";
        echo "<td><input type='text' name='PorSola' value='".$PorSola."' size='2'></td>";
        echo "<td><input type='text' name='FSSola' value='".$FSSola."' size='3'></td></tr>";

        echo "<tr><td>Naslov:</td><td><input name='naslov' type='text' value='".$VSolaNaslov."' size='40'></td>";
        echo "<td><input type='text' name='PozXNaslov' value='".$PozXNaslov."' size='5'></td>";
        echo "<td><input type='text' name='PozYNaslov' value='".$PozYNaslov."' size='5'></td>";
        echo "<td><input type='text' name='wnaslov' value='".$WNaslov."' size='5'></td>";
        echo "<td><input type='text' name='PorNaslov' value='".$PorNaslov."' size='2'></td>";
        echo "<td><input type='text' name='FSNaslov' value='".$FSNaslov."' size='3'></td></tr>";
        
        echo "<tr><td>Priznanje: (modro)</td><td><input name='priznanje' type='text' value='".$VPriznanje."' size='40'></td>";
        echo "<td><input type='text' name='PozXPriznanje' value='".$PozXPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='PozYPriznanje' value='".$PozYPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='wpriznanje' value='".$WPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='PorPriznanje' value='".$PorPriznanje."' size='2'></td>";
        echo "<td><input type='text' name='FSPriznanje' value='".$FSPriznanje."' size='3'></td></tr>";
        
        echo "<tr><td>Vrstica 1:</td><td><input name='vrstica1' type='text' value='".$VLine1."' size='40'></td>";
        echo "<td><input type='text' name='PozXLine1' value='".$PozXLine1."' size='5'></td>";
        echo "<td><input type='text' name='PozYLine1' value='".$PozYLine1."' size='5'></td>";
        echo "<td><input type='text' name='wvrstica1' value='".$WVrstica1."' size='5'></td>";
        echo "<td><input type='text' name='PorLine1' value='".$PorLine1."' size='2'></td>";
        echo "<td><input type='text' name='FSLine1' value='".$FSLine1."' size='3'></td></tr>";
        
        echo "<tr><td>Vrstica 2:</td><td><input name='vrstica2' type='text' value='".$VLine2."' size='40'></td>";
        echo "<td><input type='text' name='PozXLine2' value='".$PozXLine2."' size='5'></td>";
        echo "<td><input type='text' name='PozYLine2' value='".$PozYLine2."' size='5'></td>";
        echo "<td><input type='text' name='wvrstica2' value='".$WVrstica2."' size='5'></td>";
        echo "<td><input type='text' name='PorLine2' value='".$PorLine2."' size='2'></td>";
        echo "<td><input type='text' name='FSLine2' value='".$FSLine2."' size='3'></td></tr>";
        
        echo "<tr><td>Dejavnost: (rdeče)</td><td><input name='vsebina' type='text' value='".$VVsebina."' size='40'></td>";
        echo "<td><input type='text' name='PozXVsebina' value='".$PozXVsebina."' size='5'></td>";
        echo "<td><input type='text' name='PozYVsebina' value='".$PozYVsebina."' size='5'></td>";
        echo "<td><input type='text' name='wdejavnost' value='".$WDejavnost."' size='5'></td>";
        echo "<td><input type='text' name='PorVsebina' value='".$PorVsebina."' size='2'></td>";
        echo "<td><input type='text' name='FSVsebina' value='".$FSVsebina."' size='3'></td></tr>";
        
        echo "<tr><td>Kraj in datum:</td><td><input name='kraj' type='text' value='".$VKraj."' size='40'></td>";
        echo "<td><input type='text' name='PozXKraj' value='".$PozXKraj."' size='5'></td>";
        echo "<td><input type='text' name='PozYKraj' value='".$PozYKraj."' size='5'></td>";
        echo "<td><input type='text' name='wkrajdat' value='".$WKrajDat."' size='5'></td>";
        echo "<td><input type='text' name='PorKraj' value='".$PorKraj."' size='2'></td>";
        echo "<td><input type='text' name='FSKraj' value='".$FSKraj."' size='3'></td></tr>";
        
        echo "<tr><td>Naziv izvajalca:</td><td><input name='naziv' type='text' value='".$VIzvajalec."' size='40'></td>";
        echo "<td><input type='text' name='PozXIzvajalec' value='".$PozXIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='PozYIzvajalec' value='".$PozYIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='wnazivizv' value='".$WNazivIzv."' size='5'></td>";
        echo "<td><input type='text' name='PorIzvajalec' value='".$PorIzvajalec."' size='2'></td>";
        echo "<td><input type='text' name='FSIzvajalec' value='".$FSIzvajalec."' size='3'></td></tr>";
        
        echo "<tr><td>Izvajalec:</td><td><input name='izvajalec' type='text' value='".$VRavnatelj."' size='40'></td>";
        echo "<td><input type='text' name='PozXRavnatelj' value='".$PozXRavnatelj."' size='5'></td>";
        echo "<td><input type='text' name='PozYRavnatelj' value='".$PozYRavnatelj."' size='5'></td>";
        echo "<td><input type='text' name='wizvajalec' value='".$WIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='PorRavnatelj' value='".$PorRavnatelj."' size='2'></td>";
        echo "<td><input type='text' name='FSRavnatelj' value='".$FSRavnatelj."' size='3'></td></tr>";
        
        echo "<tr><td>Ime</td><td></td><td><input type='text' name='PozXIme' value='".$PozXIme."' size='5'></td>";
        echo "<td><input type='text' name='PozYIme' value='".$PozYIme."' size='5'></td>";
        echo "<td><input type='text' name='wime' value='".$WIme."' size='5'></td>";
        echo "<td><input type='text' name='PorIme' value='".$PorIme."' size='2'></td>";
        echo "<td><input type='text' name='FSIme' value='".$FSIme."' size='3'></td></tr>";
        
        echo "<tr><td>Razred</td><td></td><td><input type='text' name='PozXRazred' value='".$PozXRazred."' size='5'></td>";
        echo "<td><input type='text' name='PozYRazred' value='".$PozYRazred."' size='5'></td>";
        echo "<td><input type='text' name='wrazred' value='".$WRazred."' size='5'></td>";
        echo "<td><input type='text' name='PorRazred' value='".$PorRazred."' size='2'></td>";
        echo "<td><input type='text' name='FSRazred' value='".$FSRazred."' size='3'></td></tr>";
        
        echo "<tr><td>Datum rojstva</td><td></td><td><input type='text' name='PozXDatum' value='".$PozXDatum."' size='5'></td>";
        echo "<td><input type='text' name='PozYDatum' value='".$PozYDatum."' size='5'></td>";
        echo "<td><input type='text' name='wdatroj' value='".$WDatRoj."' size='5'></td>";
        echo "<td><input type='text' name='PorDatum' value='".$PorDatum."' size='2'></td>";
        echo "<td><input type='text' name='FSDatum' value='".$FSDatum."' size='3'></td></tr>";
        
        echo "<tr><td>Logotip</td><td></td><td><input type='text' name='PozXLogo' value='".$PozXLogo."' size='5'></td>";
        echo "<td><input type='text' name='PozYLogo' value='".$PozYLogo."' size='5'></td></tr>";
        
        echo "<tr><td>Širina logotipa (mm)</td><td></td><td><input type='text' name='LogoSize' value='".$LogoSize."' size='5'></td></tr>";
        
        echo "<tr><th></th><th></th><th>X1</th><th>Y1</th><th>X2</th><th>Y2</th></tr>";
        echo "<tr><td>Črta 1</td><td></td><td><input type='text' name='PozX1Crta1' value='".$PozX1Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta1' value='".$PozY1Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta1' value='".$PozX2Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta1' value='".$PozY2Crta1."' size='5'></td></tr>";
        
        echo "<tr><td>Črta 2</td><td></td><td><input type='text' name='PozX1Crta2' value='".$PozX1Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta2' value='".$PozY1Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta2' value='".$PozX2Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta2' value='".$PozY2Crta2."' size='5'></td></tr>";
        
        echo "<tr><td>Črta 3</td><td></td><td><input type='text' name='PozX1Crta3' value='".$PozX1Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta3' value='".$PozY1Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta3' value='".$PozX2Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta3' value='".$PozY2Crta3."' size='5'></td></tr>";
        
        echo "<tr><td>Pisava: </td><td><select name='Font'>";
        echo "<option value='".$VFont."' selected>".$VFont."</option>";
        echo "<option value='Arial'>Arial</option>";
        echo "<option value='Times'>Times</option>";
        echo "</select></td></tr>";

        echo "<tr><td>Shrani kot: </td><td><input name='dato' size='40' value='".$VFile."'><input name='leto' type='hidden' value='".$VLeto."'></td></tr>";
        echo "<tr><td>Ozadje: </td><td><input name='ozadje' type='hidden' value='".$VOzadje."'>".$VOzadje."</td></tr>";

        $SQL = "SELECT tabkrozki.*,tabucenci.iducenec FROM ((tabkrozekclan INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.Id) INNER JOIN tabucenci ON tabkrozekclan.ucenec=tabucenci.idUcenec) INNER JOIN tabrazred ON tabkrozekclan.ucenec=tabrazred.idUcenec WHERE tabrazred.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozki.leto=".$VLeto." AND tabkrozekclan.krozek=".$VKrozek;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<tr><td>".$R["krozek"]." - ".$R["mentor"]."</td><td>";
        }

        echo "<input name='vpisani[]' type='hidden' value='";

        $result = mysqli_query($link,$SQL);
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            if ($Indx > 1){
                echo ",".$R["iducenec"];
            }else{
                echo $R["iducenec"];
            }
            $Indx=$Indx+1;
        }
        echo "'></td></tr>";
        echo "<tr>";
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "209": //ID poročilo
        
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        
        if (isset($_POST["brisi"])){
            $Brisi=$_POST["brisi"];
        }else{
            if (isset($_GET["brisi"])){
                $Brisi=$_GET["brisi"];
            }else{
                $Brisi="";
            }
        }
        switch ($Brisi){
            case "1":
                if ($VLevel > 1 ){
                    $SQL = "DELETE FROM tabkrozki WHERE id=".$VIdTekm;
                    $result = mysqli_query($link,$SQL);
                    header ("Location: tekmovanjakrozki.php?id=201");
                }
                break;
            case "2":
                $SQL = "UPDATE tabkrozki SET krozek='".$VKrozek."',mentor='".$VMentor."' WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                header ("Location: tekmovanjakrozki.php?id=201");
                break;
            default:
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Tekmovanja in interesne dejavnosti";
                echo "</title>";
                echo "</head>";
                echo "<body>";
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='tekmovanjakrozki.php?id=201'>Na seznam</a><br />";
                $SQL = "SELECT * FROM tabkrozki WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Poročilo interesne dejavnosti: ".$R["krozek"]." - ".$R["mentor"].":</h2>";
                    echo "<form name='form_krozek' method=post action='tekmovanjakrozki.php'>";
                    echo "Krožek: <input name='krozek' type='text' size='40' value='".$R["krozek"]."'><br />";
                    echo "Mentor: <input name='mentor' type='text' size='40' value='".$R["mentor"]."'><br />";
                    echo "<input name='brisi' type='hidden' value='2'>";
                    echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
                    echo "<input name='id' type='hidden' value='209'>";
                    echo "<input name='submit' type='submit' value='Spremeni podatke'>";
                    echo "</form>";
                    
                    echo "<form name='form_realizacija' method=post action='tekmovanjakrozki.php'>";
                    echo "<input type='hidden' name='id' value='210'>";
                    echo "<input type='hidden' name='idtekm' value='".$VIdTekm."'>";

                    echo "Poročilo o delu interesne dejavnosti<br />";
                    echo "<font color='red'>Poročilo ne sme vsebovati enojnih ali dvojnih narekovajev!</font><br />";
                    echo "<textarea name='komentar' cols='80' rows='10'>".$R["porocilo"]."</textarea><br />";
                    echo "Planirano: <input name='planirano' type='text' size='5' value='".$R["planirano"]."'> ";
                    echo "Realizirano: <input name='realizirano' type='text' size='5' value='".$R["realizirano"]."'>";
                    if ($R["planirano"] > 0 ){
                        echo " Procent: ".number_format($R["realizirano"]/$R["planirano"]*100,2).", ";
                    }else{
                        echo " Procent: , ";
                    }
                    echo "Obisk (%): <input name='obisk' type='text' size='5' value='".$R["obisk"]."'>"."<br />";
                    echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
                    echo "</form>";
                    echo "</body>";
                    echo "</html>";
                }
        }
        break;
    case "210": //vpis ID report
        $VPorocilo = $_POST["komentar"];
        if (strlen($VPorocilo) > 0 ){
            $VPorocilo=str_replace("'","",$VPorocilo);
            $VPorocilo=str_replace(chr(34),"",$VPorocilo);
        }

        $SQL = "SELECT * FROM tabkrozki WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VPlanirano=$_POST["planirano"];
            if (strlen($VPlanirano) > 0 ){
                $VPlanirano=str_replace(",",".",$VPlanirano);
            }else{
                $VPlanirano=0.0;
            }
            $VRealizirano=$_POST["realizirano"];
            if (strlen($VRealizirano) > 0){
                $VRealizirano=str_replace(",",".",$VRealizirano);
            }else{
                $VRealizirano=0.0;
            }
            $VObisk=$_POST["obisk"];
            if (strlen($VObisk) > 0){
                $VObisk=str_replace(",",".",$VObisk);
            }else{
                $VObisk=0.0;
            }
            $SQL = "UPDATE  tabkrozki SET ";
            $SQL = $SQL . "porocilo='" . $VPorocilo ."',";
            $SQL = $SQL . "planirano=".$VPlanirano.",";
            $SQL = $SQL . "realizirano=".$VRealizirano.",";
            $SQL = $SQL . "obisk=".$VObisk;
            $SQL = $SQL ." WHERE Id=".$R["id"];
            $result = mysqli_query($link,$SQL);
        }

        if ($Opravila==1 ){
            $SQL = "SELECT tabdogodek.*,tabdeldogodek.id=did FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Poročilo o interesni dejavnosti' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["did"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        header ("Location: tekmovanjakrozki.php?id=201");
        break;
    case "211": //interesne dejavnosti PDF
        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddFont('castelar','','castelar.php');
        $pdf->AddFont('timesbd_CE','','timesbd_CE.php');
        //$pdf->AddPage("P","A4");

        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabkrozekclan.*,tabkrozki.*,tabkrozki.id AS kid,tabkrozki.krozek AS kkrozek,tabrazdat.* FROM ";
        $SQL = $SQL ."(((tabrazred INNER JOIN tabkrozekclan ON tabrazred.idUcenec=tabkrozekclan.Ucenec) ";
        $SQL = $SQL ."INNER JOIN tabucenci ON tabkrozekclan.Ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL ."INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabkrozekclan.leto=".$VLeto." AND tabkrozki.leto=".$VLeto;
        $SQL = $SQL ." ORDER BY tabkrozki.krozek,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        $CompPredmet=0;
        $VStran=0;
        $Indx1=0;
        $Indx=1;
        $XPoz[1]=15;
        $XPoz[2]=85;
        $YPoz=90;
        while ($R = mysqli_fetch_array($result)){
            if ($CompPredmet != $R["kid"]){
                $CompPredmet=$R["kid"];
                $Indx1=0;
                $Indx=1;
                $CountUc=1;
                
                if ($VStran > 0 ){
                    $pdf->SetFont('arial_CE','',12);
                    if ($SpolRavnatelj=="M"){
                        $txt=ToWin("Ravnatelj:");
                    }else{
                        $txt=ToWin("Ravnateljica:");
                    }
                    $pdf->SetXY(120,261);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VRavnatelj);
                    $pdf->SetXY(120,267);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Kraj in datum:");
                    $pdf->SetXY(15,261);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin($VSolaKraj.", ".$PrintDay);
                    $pdf->SetXY(15,267);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                }
                
                $VStran=$VStran+1;
                $pdf->AddPage("P","A4");

                $pdf->Image("logo1.gif",15,10,30);
                
                $pdf->SetFont('arialbd_CE','',16);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Interesne dejavnosti");
                $pdf->SetXY(10,50);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                $pdf->SetXY(10,58);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($R["kkrozek"]);
                $pdf->SetXY(15,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Mentor/ica: ".$R["mentor"]);
                $pdf->SetXY(15,77);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Razred");
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            if ($CountUc % 61 == 0){    //nova stran v primeru več kot 60 učencev na stran
                $pdf->SetFont('arial_CE','',12);
                if ($SpolRavnatelj=="M"){
                    $txt=ToWin("Ravnatelj:");
                }else{
                    $txt=ToWin("Ravnateljica:");
                }
                $pdf->SetXY(120,261);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin($VRavnatelj);
                $pdf->SetXY(120,267);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $txt=ToWin("Kraj in datum:");
                $pdf->SetXY(15,261);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                $pdf->SetXY(15,267);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $pdf->AddPage("P","A4");

                $pdf->Image("logo1.gif",15,10,30);
                
                $pdf->SetFont('arialbd_CE','',16);
                $txt=ToWin($VSola);
                $pdf->SetXY(55,18);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($VSolaNaslov);
                $pdf->SetXY(55,26);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Interesne dejavnosti");
                $pdf->SetXY(10,50);
                $pdf->Cell(0,0,$txt,0,2,"C");
                $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                $pdf->SetXY(10,58);
                $pdf->Cell(0,0,$txt,0,2,"C");

                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin($R["kkrozek"]);
                $pdf->SetXY(15,70);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Mentor/ica: ".$R["mentor"]);
                $pdf->SetXY(15,77);
                $pdf->Cell(0,0,$txt,0,2,"L");
                
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Razred");
                $pdf->SetXY($XPoz[2],$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            if ($CountUc % 61 == 31 ){
                $pdf->SetFont('arialbd_CE','',14);
                $txt=ToWin("Učenec/učenka");
                $pdf->SetXY($XPoz[1]+100,$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin("Razred");
                $pdf->SetXY($XPoz[2]+100,$YPoz);
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            if ($CountUc % 61 < 31 ){
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($CountUc.". ".$R["priimek"]." ".$R["ime"]);
                if ($Indx < 61){
                    $pdf->SetXY($XPoz[1],$YPoz+($Indx % 61)*5);
                }else{
                    $pdf->SetXY($XPoz[1],$YPoz+($Indx % 60)*5);
                }
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($R["razred"].". ".$R["oznaka"]);
                if ($Indx < 61){
                    $pdf->SetXY($XPoz[2],$YPoz+($Indx % 61)*5);
                }else{
                    $pdf->SetXY($XPoz[2],$YPoz+($Indx % 60)*5);
                }
                $pdf->Cell(0,0,$txt,0,2,"L");
            }else{
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin($CountUc.". ".$R["priimek"]." ".$R["ime"]);
                if ($Indx < 61){
                    $pdf->SetXY($XPoz[1]+100,$YPoz+(($Indx % 61) -30)*5);
                }else{
                    $pdf->SetXY($XPoz[1]+100,$YPoz+(($Indx % 60) -30)*5);
                }
                $pdf->Cell(0,0,$txt,0,2,"L");
                $txt=ToWin($R["razred"].". ".$R["oznaka"]);
                if ($Indx < 61){
                    $pdf->SetXY($XPoz[2]+100,$YPoz+(($Indx % 61)-30)*5);
                }else{
                    $pdf->SetXY($XPoz[2]+100,$YPoz+(($Indx % 60)-30)*5);
                }
                $pdf->Cell(0,0,$txt,0,2,"L");
            }
            $CountUc=$CountUc+1;
            $Indx=$Indx+1;
        }

        $pdf->SetFont('arial_CE','',12);
        if ($SpolRavnatelj=="M"){
            $txt=ToWin("Ravnatelj:");
        }else{
            $txt=ToWin("Ravnateljica:");
        }
        $pdf->SetXY(120,261);
        $pdf->Cell(0,0,$txt,0,2,"C");
        $txt=ToWin($VRavnatelj);
        $pdf->SetXY(120,267);
        $pdf->Cell(0,0,$txt,0,2,"C");

        $txt=ToWin("Kraj in datum:");
        $pdf->SetXY(15,261);
        $pdf->Cell(0,0,$txt,0,2,"L");
        $txt=ToWin($VSolaKraj.", ".$PrintDay);
        $pdf->SetXY(15,267);
        $pdf->Cell(0,0,$txt,0,2,"L");
        
        $pdf->Output("interesne.pdf","D");
        break;
    case "301": //izbor šolskih športnih tekmovanj
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["stopnja"])){
            $VStopnja = $_POST["stopnja"];
        }else{
            if (isset($_GET["stopnja"])){
                $VStopnja=$_GET["stopnja"];
            }else{
                $VStopnja = 0;
            }
        }
        
        switch ( $VIdTekm){
            case "1":
                if (($VKrozek=="") or ($VMentor=="") ){
                    echo "<h2>Interesna dejavnost ni bila dodana!</h2>";
                }else{
                    $SQL = "SELECT * FROM tabsst WHERE leto=".$VLeto." AND krozek='".$VKrozek."' AND mentor='".$VMentor."' AND stopnja=".$VStopnja;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<h2>To tekmovanje je že vpisano!</h2>";
                    }else{
                        $SQL = "INSERT INTO tabsst (leto,krozek,mentor,stopnja) VALUES (".$VLeto.",'".$VKrozek."','".$VMentor."',".$VStopnja.")";
                        $result = mysqli_query($link,$SQL);
                        
                        echo "<h2>Dodano je bilo šolsko športno tekmovanje: ".$VKrozek." - ".$VMentor."</h2>";
                    }
                }
        }

        $SQL = "SELECT tabsst.id, tabsst.krozek, tabsst.stopnja,tabsst.mentor,tabsst.leto, tabsstclan.idTekmovanje,tabsst.porocilo,  Count(tabsstclan.idTekmovanje) AS countofkrozek " ;
        $SQL = $SQL."FROM tabsst LEFT JOIN tabsstclan ON tabsstclan.idTekmovanje = tabsst.id " ;
        $SQL = $SQL."GROUP BY tabsst.leto, tabsstclan.idTekmovanje, tabsst.id, tabsst.krozek, tabsst.stopnja,tabsst.mentor ";
        $SQL = $SQL."HAVING (((tabsst.leto)=".$VLeto.")) ORDER BY tabsst.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izbor in vpis tekmovanja - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p>Če vaše tekmovanje še ni v spodnjem spisku, ga vpišite, pri tem pa pazite na to, da se bodo na nivoju šole uporabljale <b>enotne oznake imen tekmovanj</b>.<br />";
        echo "<b>Postopek vpisa:</b><br />";
        echo "1. Vpis imena tekmovanja, izbor stopnje tekmovanja in vpis mentorja<br />";
        echo "2. Klik na ime tekmovanja, vpis datuma in kraja tekmovanja ter izbor učencev s spiska učencev<br />";
        echo "3. Učencem vpišete osvojena mesta oz. osvojitev priznanj<br />";
        echo "<font color='green'>Osnovne podatke o tekmovanju lahko popravite s klikom na <b>Poglej/popravi</b> v stolpcu Poročilo</font><br />";
        echo "<br />";
        echo "Standardna priznanja lahko izpišete s klikom na <b>Priznanja</b> v stolpcu Priznanja<br />";
        echo "<br />";
        echo "Za pregleden izpis spiska tekmovanj s statistiko ter možnostjo tiskanja poročila o tekmovanju kliknite <a href='tekmovanjakrozki.php?id=309'>tukaj</a>.<br />";
        echo "Za izpis <font color='green'><b>dobitnikov priznanj</b></font> z vseh tekmovanj po tekmovanjih ali po razredih kliknite <a href='tekmovanjakrozki.php?id=112'>tukaj</a>.<br />";
        echo "Za izpis <font color='green'><b>največjih uspehov</b></font> kliknite <a href='tekmovanjakrozki.php?id=311'>tukaj</a>.<br />";
        echo "Za izpis <font color='green'><b>udeležbe na največ tekmovanjih</b></font> kliknite <a href='tekmovanjakrozki.php?id=312'>tukaj</a>.<br />";
        //echo "Za izpis obvestil (PDF) o udeležbah na šolskih športnih tekmovanjih kliknite <a href='izborrazreda.php?id=sst'>tukaj</a>.<br />";

        echo "</p>";

        echo "<form name='SST' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='301'>";
        echo "<table border=1 cellspacing=0>";
        if ($VecSol > 0){
            echo "<tr><th>Št.</th><th>Tekmovanje</th><th>Šola</th><th>Stopnja</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th>";
        }else{
            echo "<tr><th>Št.</th><th>Tekmovanje</th><th>Stopnja</th><th>Mentor</th><th>Udeležencev</th><th>Priznanja</th><th>Poročilo</th>";;
        }
        if ($VLevel > 1){
            echo "<th>Briši</th>";
        }
        echo "</tr>";
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=302&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
            if ($VecSol > 0){
                echo "<td>";
                $sola="";
                if ($R["countofkrozek"] > 0){
                    $SQL = "SELECT DISTINCT tabsola.solakratko FROM ((tabsstclan ";
                    $SQL .= "INNER JOIN tabrazred ON tabsstclan.iducenec=tabrazred.iducenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL .= "WHERE tabsstclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabsstclan.idtekmovanje=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $sola = $sola . $R1["solakratko"]."<br />";
                    }
                }
                echo $sola."</td>";
            }
            echo "<td>".ToStopnja($R["stopnja"])."</td>";
            echo "<td>".$R["mentor"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            if ($R["countofkrozek"] > 0 ){
                echo "<td><a href='tekmovanjakrozki.php?id=308&solskoleto=".$VLeto."&krozek=".$R["id"]."'>Priznanja</a></td>";
            }else{
                echo "<td></td>";
            }
            if (isset($R["porocilo"]) && strlen($R["porocilo"]) > 0){
                echo "<td bgcolor='lightgreen'>";
            }else{
                echo "<td bgcolor='red'>";
            }
            echo "<a href='tekmovanjakrozki.php?id=306&idtekm=".$R["id"]."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            if ($VLevel > 1){
                echo "<td align='center'><a href='tekmovanjakrozki.php?id=310&zapis=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "<tr><td></td><td><input name='krozek' type='text' size='30'></td>";
        if ($VecSol > 0){
            echo "<td></td>";
        }
        echo "<td><select name='stopnja'>";
        echo "<option value='0'>Šolsko</option>";
        echo "<option value='1'>Občinsko</option>";
        echo "<option value='2'>Medobčinsko</option>";
        echo "<option value='3'>Področno</option>";
        echo "<option value='4'>Regijsko</option>";
        echo "<option value='5'>Mestno</option>";
        echo "<option value='7'>Državno četrtfinale</option>";
        echo "<option value='8'>Državno polfinale</option>";
        echo "<option value='9'>Državno finale</option>";
        echo "<option value='10'>Državno</option>";
        echo "</select></td>";
        echo "<td><input name='mentor' type='text' size='30'></td><td></td><td></td><td><input name='idtekm' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
        echo "</table><br />";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "302": // dodeli učence SST
            echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
            echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
            echo "<script type=\"text/javascript\">";
            echo "    window.onload = function(){";
            echo "        var Danes = new Date();";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat01\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "        new JsDatePick({";
            echo "            useMode:2,";
            echo "            target:\"dat02\",";
            echo "            dateFormat:\"%d.%m.%Y\",";
            echo "            yearsRange:[1940,2080],";
            echo "            limitToToday:false";
            echo "        });";
            echo "    };";
            echo "</script>";
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VTekmovanje=$R["krozek"];
            $VMentor=$R["mentor"];
            $VStopnja=$R["stopnja"];
            $VLeto=$R["leto"];
            
            echo "<form name='tekmovanja' method='post' action='tekmovanjakrozki.php'>";
            echo "<input name='id' type='hidden' value='303'>";
            echo "<h2>Vpis šolskega športnega tekmovanja</h2>";
            echo "<table border=0>";
            echo "<tr><td>Šolsko leto:</td><td><input name='idtekm' type='hidden' value='".$VIdTekm."'>".$VLeto."/".($VLeto+1)."</td></tr>";
            echo "<tr><td>Mentor:</td><td>".$VMentor."</td></tr>";
            echo "<tr><td>Tekmovanje:</td><td>".$VTekmovanje."</td></tr>";
            echo "<tr><td>Stopnja:</td><td>".ToStopnja($VStopnja)."</td></tr>";
            $SQL = "SELECT * FROM tabsstclan WHERE idTekmovanje=".$VIdTekm;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VDatum=$R["datum"];
                $VKraj=$R["kraj"];
            }else{
                $VDatum="";
                $VKraj="";
            }
            echo "<tr><td>Datum tekmovanja:</td><td><input name='datum' type='text' size='10' value='".$VDatum."' id='dat01'></td></tr>";
            echo "<tr><td>Kraj tekmovanja:</td><td><input name='kraj' type='text' size='40' value='".$VKraj."'></td></tr>";
            echo "<tr><td>Tekmovalci:<br />(Več naenkrat jih lahko označite s <br />skupnim pritiskom tipke Ctrl in levim klikom)</td>";
            echo "<td><select name='tekmovalci[]' multiple size='30'>";
            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0";
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
            }
            echo "</select></td></tr>";
            echo "</table>";
            echo "<p>Pri dodajanju učencev na tekmovanje kliknite na gumb <b>Dodaj nove</b>.<br />Če ste se namenili le popraviti podatke o osvojenih priznanjih, kliknite na <b>Popravi<b> </p>";
            echo "<input name='submit' type='submit' value='Popravi'><input name='submit' type='submit' value='Dodaj nove'>";
            echo "</form><br />";
            
            $SQL = "SELECT tabsstclan.*,tabsst.*,tabucenci.*,tabrazdat.* FROM ";
            $SQL = $SQL . "(((tabsstclan INNER JOIN tabsst ON tabsstclan.idtekmovanje=tabsst.id) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabsstclan.iducenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabsstclan.iducenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.idtekmovanje=".$VIdTekm;
            $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Spisek udeležencev: ".$R["krozek"]." - ".$R["mentor"]."</h2>";
            }

            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Št.</th><th>Ime</th><th>Priimek</th><th>Razred</th><th>Dat. roj.</th><th>Kontakt</th><th>Mentor</th>";
            echo "</tr>";

            $Indx=1;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["Ime"]."</td><td>".$R["Priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                $Datum=new DateTime(isDate($R["DatRoj"]));
                echo "<td align='right'>".$Datum->format('d.m.Y')."</td>";
                echo "<td>".$R["oceGSM"].", ".$R["matiGSM"].", ".$R["SkrbnikiKontakt"]."</td>";
                echo "<td>".$R["mentor"]."</td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<a href='izpisrazreda.php?id=8&idtekm=".$VIdTekm."'>Pošiljanje e-pošte staršem</a><br />";
            echo "<a href='tekmovanjakrozki.php?id=305&solskoleto=".$VLeto."&idtekm=".$VIdTekm."'>Spisek udeležencev tekmovanja</a><br /><br />";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "303": //vpis SST
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        echo "<form name='tekmovanja' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='304'>";
        echo "<h2>Vpis rezultatov šolskega športnega tekmovanja</h2>";
        echo "<table border=0>";

        $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VLeto=$R["leto"];
            $VMentor=$R["mentor"];
            $VTekmovanje=$R["krozek"];
            $VStopnja=$R["stopnja"];
            
            echo "<tr><td>Šolsko leto: <b>".$VLeto."/".($VLeto+1)."</b>";
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "</td></tr>";
            echo "<tr><td>Mentor: <b>".$VMentor."</b>";
            echo "<input type='hidden' name='mentor' value='".$VMentor."'>";
            echo "</td></tr>";
            echo "<tr><td>Tekmovanje: <b>".$VTekmovanje."</b>";
            echo "<input type='hidden' name='tekmovanje' value='".$VTekmovanje."'>";
            echo "</td></tr>";
            echo "<tr><td>Stopnja tekmovanja: <b>".ToStopnja($VStopnja)."</b>";
            echo "<input type='hidden' name='stopnja' value='".$VStopnja."'>";
            echo "</td></tr>";
            echo "<tr><td>Datum tekmovanja:";
            $VDatum=$_POST["datum"];
            echo " <b>".$VDatum."</b>";
            echo "<input type='hidden' name='datum' value='".$VDatum."'>";
            echo "</td></tr>";
            echo "<tr><td>Kraj tekmovanja:";
            $VKraj=$_POST["kraj"];
            echo " <b>".$VKraj."</b>";
            echo "<input type='hidden' name='kraj' value='".$VKraj."'>";
            echo "</td></tr>";
            echo "</table><br />";
            echo "<table borde=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Mesto/Priznanje</th><th>Nadaljnje<br />tekmovanje</th>";

            if (isset($_POST["tekmovalci"])){
                $VTekmovalci=Arr2Str($_POST["tekmovalci"]);
            }else{
                $VTekmovalci="";
            }
            
            if ($_POST["submit"]=="Popravi" ){
                $SQL = "SELECT * FROM tabsstclan WHERE idTekmovanje=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                
                if (mysqli_num_rows($result)){
                     while ($R = mysqli_fetch_array($result)){
                        if (strlen($VTekmovalci)==0 ){
                            $VTekmovalci=$R["idUcenec"];
                        }else{
                            $VTekmovalci=$VTekmovalci.",".$R["idUcenec"];
                        }
                    }
                
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka,tabsstclan.* FROM (tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
                    $SQL = $SQL . "LEFT JOIN tabsstclan ON tabucenci.idUcenec=tabsstclan.idUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.idTekmovanje=".$VIdTekm." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"]." ".$R["razred"].". ".$R["paralelka"];


                        echo "</td><td>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20' value='".$R["priznanje"]."'>";
                        echo "</td><td>";
                        if ($R["napredovanje"]){
                            echo "<input name='uvrstitev".$Indx."' type='checkbox' checked='checked'>";
                        }else{
                            echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        }
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                }else{
                    $SQL = "SELECT tabucenci.*,tabrazred.* FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"]." ".$R["Razred"].". ".$R["Paralelka"];
                        echo "</td><td>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20'>";
                        echo "</td><td>";
                        echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
                }
            }else{
                    $SQL = "SELECT tabucenci.*,tabrazred.* FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td><td>";
                        echo "<input type='hidden' name='tekmovalec".$Indx."' value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"]." ".$R["Razred"].". ".$R["Paralelka"];
                        echo "</td><td>";
                        echo "<input name='priznanje".$Indx."' type='text' size='20'>";
                        echo "</td><td>";
                        echo "<input name='uvrstitev".$Indx."' type='checkbox'>";
                        echo "</td></tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";
            }
            echo "Skupno število udeležencev tekmovanja naše šole: <b>".($Indx-1)."</b>";
            echo "<input name='skupaj' type='hidden' value='".($Indx-1)."'><br />";
            echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'><br />";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "304": //shrani SST
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["tekmovanje"])){
            $VTekmovanje=$_POST["tekmovanje"];
        }else{
            $VTekmovanje="";
        }
        if (isset($_POST["datum"])){
            $VDatum=$_POST["datum"];
        }else{
            $VDatum=$Danes->format('j.n.Y');
        }
        if (isset($_POST["kraj"])){
            $VKraj=$_POST["kraj"];
        }else{
            $VKraj="";
        }
        if (isset($_POST["stopnja"])){
            $VStopnja=$_POST["stopnja"];
        }else{
            $VStopnja=0;
        }
        if (isset($_POST["skupaj"])){
            $VSkupaj=$_POST["skupaj"];
        }else{
            $VSkupaj=0;
        }

        for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
            $VTekmovalci[$Indx][1]=$_POST["tekmovalec".$Indx];
            $VTekmovalci[$Indx][2]=$_POST["priznanje".$Indx];
            if (isset($_POST["uvrstitev".$Indx])){
                $VTekmovalci[$Indx][3]="true";
            }else{
                $VTekmovalci[$Indx][3]="false";
            }
        }
        $VStamp=$Danes->format('Y-m-d H:i:s');
        if (isset($_POST["brisanje"])){
            $VBrisanje = $_POST["brisanje"];
        }else{
            if (isset($_GET["brisanje"])){
                $VBrisanje=$_GET["brisanje"];
            }else{
                $VBrisanje = 0;
            }
        }

        if ($VBrisanje=="1" ){
            $SQL = "SELECT * FROM tabsstclan WHERE idTekmovanje=".$VIdTekm;
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $VLeto=$R["leto"];
            }
            
            for ($Indx=1;$Indx <=$_POST["stbris"];$Indx++){
                if (isset($_POST["br_".$Indx])){
                    $SQL = "DELETE FROM tabsstclan WHERE idTekmovanje=".$VIdTekm." AND idUcenec=".$_POST["tekm_".$Indx];
                    $result = mysqli_query($link,$SQL);
                }
            }
        }else{
            for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
                $SQL = "SELECT * FROM tabsstclan WHERE idTekmovanje=".$VIdTekm." AND idUcenec=".$VTekmovalci[$Indx][1];
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "UPDATE tabsstclan SET leto=".$VLeto.",mentor1='".$VMentor."',datum='".$VDatum."',priznanje='".$VTekmovalci[$Indx][2]."',napredovanje=".$VTekmovalci[$Indx][3].",stopnja='".ToStopnja($VStopnja)."',kraj='".$VKraj."',vpisal='".$VUporabnik."',idDogodek='".$VStamp."' WHERE id=".$R["id"];
                }else{
                    $SQL = "INSERT INTO tabsstclan (leto,idUcenec,mentor1,datum,tekmovanje,idtekmovanje,priznanje,napredovanje,stopnja,kraj,vpisal,idDogodek) VALUES (";
                    $SQL = $SQL .$VLeto.",".$VTekmovalci[$Indx][1].",'".$VMentor."','".$VDatum."','".$VTekmovanje."',".$VIdTekm.",'".$VTekmovalci[$Indx][2]."',".$VTekmovalci[$Indx][3].",'".ToStopnja($VStopnja)."','".$VKraj."','".$VUporabnik."','".$VStamp."')";
                }
                $result = mysqli_query($link,$SQL);
            }
            if ($Opravila==1 ){
                $SQL = "SELECT tabdogodek.*,tabdeldogodek.id AS did FROM ";
                $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos rezultatov šolskih športnih tekmovanj' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VDogodki[$Indx]=$R["did"];
                    $Indx=$Indx+1;
                }
                $StDogodkov=$Indx-1;

                for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                    $result = mysqli_query($link,$SQL);
                }
            }
        }

        echo "Vpisano je bilo:<br />";
        $SQL = "SELECT tabsstclan.*,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
        $SQL = $SQL . "((tabsstclan INNER JOIN tabucenci ON tabsstclan.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabsstclan.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.idTekmovanje=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        echo "<form name='tekmovanja' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='304'>";
        echo "<table>";
        echo "<tr>";
        echo "<th>Št.</th><th>Tekmovanje</th><th>Stopnja</th><th>Kraj</th><th>Datum</th><th>Mentor</th><th>Tekmovalec</th><th>Mesto/Priznanje</th><th>Napredovanje</th><th>Briši</th>";
        echo "</tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["tekmovanje"]."</td>";
            echo "<td>".$R["stopnja"]."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td>".$R["mentor1"]."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "<td>".$R["priznanje"]."</td>";
            if ($R["napredovanje"] ){
                echo "<td><input type='checkbox' checked></td>";
            }else{
                echo "<td><input type='checkbox'></td>";
            }
            echo "<td><input name='tekm_".$Indx."' type='hidden' value='".$R["idUcenec"]."'><input name='br_".$Indx."' type='checkbox'></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
        echo "<input name='brisanje' type='hidden' value='1'>";
        echo "<input name='stbris' type='hidden' value='".($Indx-1)."'>";
        echo "<input name='submit' type='submit' value='Briši'>";
        echo "</form><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na spisek tekmovanj</a>";
        echo "</body>";
        echo "</html>";
        break;
    case "305": //SST udeleženci
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $SQL = "SELECT tabsstclan.*,tabsst.*,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
            $SQL = $SQL . "(((tabsstclan INNER JOIN tabsst ON tabsstclan.idtekmovanje=tabsst.id) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabsstclan.iducenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabsstclan.iducenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.idtekmovanje=".$VIdTekm;
            $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Spisek udeležencev: ".$R["krozek"]." - ".$R["mentor"]."</h2>";
            }

            echo "<table border='1'>";
            echo "<tr>";
            echo "<th>Št.</th><th>Slika</th><th>Ime</th><th>Priimek</th><th>Razred</th>";
            echo "</tr>";

            $Indx=1;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td><img src='slike/".$VLeto."_".$R["iducenec"].".jpg' width='50' onmouseover='width+=100' onmouseout='width-=100'></td>";
                echo "<td>".$R["ime"]."</td><td>".$R["priimek"]."</td><td>".$R["razred"].". ".$R["oznaka"]."</td>";
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
        }
        echo "</body>";
        echo "</html>";
        break;
    case "306": // SST poročilo
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
		if (!isset($_POST["brisi"])){
			include('menu_func.inc');
			include ('menu.inc');
		}
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";

        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["stopnja"])){
            $VStopnja = $_POST["stopnja"];
        }else{
            if (isset($_GET["stopnja"])){
                $VStopnja=$_GET["stopnja"];
            }else{
                $VStopnja = 0;
            }
        }
        
        if (isset($_POST["brisi"])){
            $Brisi=$_POST["brisi"];
        }else{
            $Brisi="";
        }
        switch ($Brisi){
            case "1":
                if ($VLevel > 1 ){
                    $SQL = "DELETE FROM tabsstclan WHERE idTekmovanje=".$VIdTekm;
                    $result = mysqli_query($link,$SQL);
                    $SQL = "DELETE FROM tabsst WHERE id=".$VIdTekm;
                    $result = mysqli_query($link,$SQL);
                    
                    header ("Location: tekmovanjakrozki.php?id=301");
                }
                break;
            case "2":
                $SQL = "UPDATE tabsst SET krozek='".$VKrozek."',mentor='".$VMentor."',stopnja=".$VStopnja." WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                $SQL = "UPDATE tabsstclan SET stopnja='".ToStopnja($VStopnja)."',tekmovanje='".$VKrozek."',mentor1='".$VMentor."' WHERE idTekmovanje=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                header ("Location: tekmovanjakrozki.php?id=301");
                break;
            default:
                $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Poročilo o šolskem športnem tekmovanju: ".$R["krozek"]." - ".$R["mentor"].":</h2>";
                    
                    echo "<form name='form_tekmovanje' method=post action='tekmovanjakrozki.php'>";
                    echo "Krožek: <input name='krozek' type='text' size='40' value='".$R["krozek"]."'><br />";
                    echo "Mentor: <input name='mentor' type='text' size='40' value='".$R["mentor"]."'><br />";
                    echo "Stopnja: <select name='stopnja'>";
                    for ($Indx=0;$Indx <= 10;$Indx++){
                        if ($Indx != 6){
                            if ($R["stopnja"]==$Indx ){
                                echo "<option value='".$Indx."' selected='selected'>".ToStopnja($Indx)."</option>";
                            }else{
                                echo "<option value='".$Indx."'>".ToStopnja($Indx)."</option>";
                            }
                        }
                    }
                    echo "</select><br />";
                    echo "<input name='brisi' type='hidden' value='2'>";
                    echo "<input name='id' type='hidden' value='306'>";
                    echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
                    echo "<input name='submit' type='submit' value='Spremeni podatke'>";
                    echo "</form>";
                    
                    echo "<form name='form_realizacija' method=post action='tekmovanjakrozki.php'>";
                    echo "<input name='id' type='hidden' value='307'>";
                    echo "<input type='hidden' name='idtekm' value='".$VIdTekm."'>";

                    echo "Poročilo o šolskem športnem tekmovanju<br />";
                    echo "<textarea name='komentar' cols='80' rows='10'>".$R["porocilo"]."</textarea><br />";

                    echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
                    echo "</form>";
                }
        }
        echo "</body>";
        echo "</html>";
        break;
    case "307": //vpis SST report
        $VPorocilo = str_replace("'","",$_POST["komentar"]);
        $VPorocilo = str_replace("'","",$VPorocilo);

        $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $SQL = "UPDATE  tabsst SET porocilo='" . $VPorocilo ."' WHERE Id=".$R["id"];
            $result = mysqli_query($link,$SQL);
        }

        if ($Opravila==1 ){
            $SQL = "SELECT tabdogodek.*,tabdeldogodek.id AS did FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos rezultatov šolskih športnih tekmovanj' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["did"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        header ("Location: tekmovanjakrozki.php?id=301");
        break;
    case "308": //SST priznanja PDF
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }

        $SQL = "SELECT * FROM tabsst WHERE id=".$VKrozek;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VImeKrozka=$R["krozek"];
            $VMentor=$R["mentor"];
        }else{
            $VImeKrozka="";
            $VMentor="";
        }

        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
        $pdf->AddFont('castelar','','castelar.php');
        $pdf->AddFont('timesbd_CE','','timesbd_CE.php');
        $pdf->AddPage("P","A4");

        $SQL = "SELECT tabsstclan.*,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.datroj,tabrazred.* FROM ((tabsstclan INNER JOIN tabsst ON tabsstclan.idTekmovanje=tabsst.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabsstclan.idUcenec=tabucenci.idUcenec) INNER JOIN tabrazred ON tabsstclan.idUcenec=tabrazred.idUcenec ";
        $SQL = $SQL ."WHERE tabrazred.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.idTekmovanje=".$VKrozek;

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $ucenci[$Indx][1]=$R["ime"]." ".$R["priimek"];
            $ucenci[$Indx][2]=$R["Razred"].". ".$R["Paralelka"];
            $ucenci[$Indx][3]=$R["datroj"];
            $ucenci[$Indx][4]=$R["spol"];
            switch ( $R["stopnja"]){
                case "Šolsko":
                case "Občinsko":
                case "Medobčinsko":
                case "Regijsko":
                case "Področno":
                case "Mestno":
                    $ucenci[$Indx][5]=$R["stopnja"]." prvenstvo";
                    break;
                default:
                    $ucenci[$Indx][5]=$R["stopnja"];
            }
            if (strlen($R["priznanje"])==1 ){
                $ucenci[$Indx][6]=$R["priznanje"].". mesto";
            }else{
                $ucenci[$Indx][6]=$R["priznanje"];
            }
            $Indx=$Indx+1;;
        }
        $StUcencev=$Indx-1;

        for ($IndxUcenec=1;$IndxUcenec <= $StUcencev;$IndxUcenec++){
            if ($IndxUcenec > 1 ){
                $pdf->AddPage("P","A4");
            }

            $Indx1=0;
            
            //logotip in črte
            $pdf->Image("logo1.gif",85, 40,30);
            $pdf->SetTextColor(0,0,0); //črna
            $pdf->SetLineWidth(0.2);
            $pdf->Line(30.0, 180, 167, 180);
            $pdf->Line(30.0, 200, 167, 200);
            $pdf->Line(30.0, 220, 167, 220);
            $pdf->Line(30.0, 240, 167, 240);
            
            //'naslov dokumenta
            $pdf->SetFont('arialbd_CE','',22);
            $txt=ToWin($VSola);
            $pdf->SetXY(10,20);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VSolaNaslov);
            $pdf->SetXY(10,30);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('castelar','',64);
            $pdf->SetTextColor(0,0,255); //modra
            $txt=ToWin("PRIZNANJE");
            $pdf->SetXY(10,100);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arialbd_CE','',24);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin("za sodelovanje");
            $pdf->SetXY(10,120);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin("na šolskem športnem tekmovanju");
            $pdf->SetXY(10,132);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetTextColor(255,0,0); //rdeča
            $txt=ToWin($VImeKrozka);
            $pdf->SetXY(10,150);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($ucenci[$IndxUcenec][5]);
            $pdf->SetXY(10,162);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('timesbd_CE','',30);
            $pdf->SetTextColor(0,0,0); //črna
            $txt=ToWin($ucenci[$IndxUcenec][1].", ".$ucenci[$IndxUcenec][2]);
            $pdf->SetXY(10,190);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',24);
            $Datum=new DateTime(isDate($ucenci[$IndxUcenec][3]));
            if ($ucenci[$IndxUcenec][4]=="M" ){
                $txt=ToWin("rojen ".$Datum->format('j. n. Y'));
            }else{
                $txt=ToWin("rojena ".$Datum->format('j. n. Y'));
            }
            $pdf->SetXY(10,210);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',16);
            $txt=ToWin($ucenci[$IndxUcenec][6]);
            $pdf->SetXY(10,230);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Mentor");
            $pdf->SetXY(120,261);
            $pdf->Cell(0,0,$txt,0,2,"C");
            $txt=ToWin($VMentor);
            $pdf->SetXY(120,267);
            $pdf->Cell(0,0,$txt,0,2,"C");

            $txt=ToWin("Kraj in datum:");
            $pdf->SetXY(15,261);
            $pdf->Cell(0,0,$txt,0,2,"L");
            $txt=ToWin($VSolaKraj.", ".$PrintDay);
            $pdf->SetXY(15,267);
            $pdf->Cell(0,0,$txt,0,2,"L");
        }    
        $pdf->Output("priznanja.pdf","D");
        break;
    case "309": //list SST
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        $SQL = "SELECT tabsst.id, tabsst.krozek, tabsst.stopnja,tabsst.mentor,tabsst.leto, tabsstclan.idTekmovanje,tabsstclan.datum,tabsstclan.kraj,tabsst.porocilo, Count(tabsstclan.idTekmovanje) AS countofkrozek " ;
        $SQL = $SQL."FROM tabsst LEFT JOIN tabsstclan ON tabsstclan.idTekmovanje = tabsst.id " ;
        $SQL = $SQL."GROUP BY tabsst.leto, tabsstclan.idTekmovanje, tabsstclan.datum,tabsstclan.kraj,tabsst.id, tabsst.krozek, tabsst.stopnja,tabsst.mentor ";
        $SQL = $SQL."HAVING (((tabsst.leto)=".$VLeto.")) ORDER BY tabsst.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<p>Za <font color='green'><b>izpis poročila o tekmovanju</b></font> kliknite na ime tekmovanja v stolpcu Tekmovanje.<br />";
        echo "Podatke o udeležencih in osvojenih priznanjih lahko popravite s klikom na <b>Popravi</b> v stolpcu Popravi";
        echo "</p>";

        echo "<h2>Šolska športna tekmovanja v šolskem letu ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<table border=1 cellspacing=0>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Tekmovanje</th>";
        echo "<th>Mentor</th>";
        echo "<th>Stopnja</th>";
        echo "<th>Kraj</th>";
        echo "<th>Datum</th>";
        echo "<th>Udeležencev</th>";
        echo "<th>Briši</th>";
        echo "<th>Popravi</th>";
        echo "</tr>";

        $Indx=1;
        $VCount[0][0]=0;
        while ($R = mysqli_fetch_array($result)){
            $VTekmovanje[$Indx]=$R["id"];
            $VCount[0][0]=$VCount[0][0]+$R["countofkrozek"];
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=313&idtekm=".$R["id"]."'>".$R["krozek"]."</a></td>";
            echo "<td>".$R["mentor"]."</td>";
            echo "<td>".ToStopnja($R["stopnja"])."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=310&zapis=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            if (isset($R["porocilo"]) && strlen($R["porocilo"]) > 0){
                echo "<td bgcolor='lightgreen'>";
            }else{
                echo "<td bgcolor='red'>";
            }
            echo "<a href='tekmovanjakrozki.php?id=302&idtekm=".$R["id"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        $StTekmovanj=$Indx-1;
        echo "<tr><td></td><td>Skupaj</td><td></td><td></td><td></td><td></td><td align=center>".$VCount[0][0]."</td></tr>";
        echo "</table><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "310": // briši SST
        $Zapis=$_GET["zapis"];
        $SQL = "SELECT tabsst.*,tabsstclan.* FROM tabsst LEFT JOIN tabsstclan ON tabsst.id=tabsstclan.idTekmovanje WHERE tabsst.id=".$Zapis;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VUcitelj=$R["vpisal"];
            if ($VLevel > 1 ){
                $SQL = "DELETE FROM tabsstclan WHERE idTekmovanje=".$Zapis;
                $result = mysqli_query($link,$SQL);

                $SQL = "DELETE FROM tabsst WHERE id=".$Zapis;
                $result = mysqli_query($link,$SQL);
                echo "Izbrisano!<br />";
            }
            if (($VLevel < 2) && ($VUporabnik==$VUcitelj) ){
                $SQL = "DELETE FROM tabsstclan WHERE idTekmovanje=".$Zapis;
                $result = mysqli_query($link,$SQL);

                $SQL = "DELETE FROM tabsst WHERE id=".$Zapis;
                $result = mysqli_query($link,$SQL);
                echo "Izbrisano!<br />";
            }
        }
        header ("Location: tekmovanjakrozki.php?id=309");
        break;
    case "311": //uspehi SST
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        echo "<br /><h2>Rezultati šolskih športnih tekmovanj - ".$VLeto."/".($VLeto+1)."</h2>";
        $SQL = "SELECT tabsstclan.*,tabucenci.priimek,tabucenci.ime,tabrazred.*,tabsola.solakratko FROM ";
        $SQL .= "(((tabsstclan INNER JOIN tabucenci ON tabsstclan.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabsstclan.idUcenec=tabrazred.idUcenec) ";
        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabsstclan.leto=".$VLeto." AND tabsstclan.priznanje <> '' AND stopnja <> 'Šolsko' ";
        $SQL = $SQL . "ORDER BY tekmovanje,stopnja,priznanje,priimek,ime";
        $result = mysqli_query($link,$SQL);

        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Tekmovalec</th>";
        if ($VecSol > 0){
            echo "<th>Šola</th>";
        }
        echo "<th>Mesto/Priznanje</th>";
        echo "<th>Tekmovanje</th>";
        echo "<th>Stopnja</th>";
        echo "<th>Kraj</th>";
        echo "<th>Datum</th>";
        echo "<th>Mentor</th>";
        echo "</tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["ime"]." ".$R["priimek"].", ".$R["Razred"].". ".$R["Paralelka"]."</td>";
            if ($VecSol > 0){
                echo "<td>".$R["solakratko"]." &nbsp;</td>";
            }
            echo "<td>".$R["priznanje"]." &nbsp;</td>";
            echo "<td>".$R["tekmovanje"]."</td>";
            echo "<td>".$R["stopnja"]."</td>";
            echo "<td>".$R["kraj"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td>".$R["mentor1"]."</td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br /><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "312": //SST spisek največje udeležbe
        echo "<title>Šolska športna tekmovanja";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        echo "<br /><h2>Šolska športna tekmovanja - učenci na največ prireditvah - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Št.</th><th>Učenec</th><th>razred</th><th>nastopov</th><th>nastopi</th></tr>";
        $SQL = "SELECT leto,iducenec,count(iducenec) AS nastopov FROM tabsstclan GROUP BY leto,iducenec HAVING leto=$VLeto ORDER BY nastopov DESC";
        $result = mysqli_query($link,$SQL);
        $indx=0;
        while ($R = mysqli_fetch_array($result)){
            $indx += 1;
            echo "<tr>";
            echo "<td>$indx</td>";
            $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabsstclan.tekmovanje,tabsstclan.stopnja,tabsstclan.priznanje,tabsstclan.datum,tabsstclan.mentor1 FROM ((tabrazred ";
            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsstclan ON tabrazred.iducenec=tabsstclan.iducenec ";
            $SQL .= "WHERE tabrazred.leto=$VLeto AND tabrazdat.leto=$VLeto AND tabsstclan.leto=$VLeto AND tabsstclan.iducenec=".$R["iducenec"];

            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                echo "<td>".$R1["priimek"]." ".$R1["ime"]."</td>";
                echo "<td>".$R1["razred"]." ".$R1["oznaka"]."</td>";
                echo "<td>".$R["nastopov"]."</td>";
            }
            echo "<td>";
            $result1 = mysqli_query($link,$SQL);
            while ($R1 = mysqli_fetch_array($result1)){
                echo "<b>".$R1["tekmovanje"]."</b> (".$R1["stopnja"]."), ".$R1["priznanje"].", ".$R1["datum"].", ".$R1["mentor1"]."<br />";
            }
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br />";
        echo "</body>";
        echo "</html>";
        break;
    case "313": //izpis podatkov o SST
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=301'>Na seznam</a><br />";
        
        echo "<br /><h2>Poročilo o tekmovanju</h2>";
        $SQL = "SELECT tabsstclan.*,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
        $SQL = $SQL . "((tabsstclan INNER JOIN tabucenci ON tabsstclan.iducenec=tabucenci.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabsstclan.iducenec=tabrazred.iducenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabsstclan.idTekmovanje=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "Tekmovanje: <b>".$R["tekmovanje"]."</b><br />";
            echo "Stopnja tekmovanja: <b>".$R["stopnja"]."</b><br />";
            echo "Kraj tekmovanja: <b>".$R["kraj"]."</b><br />";
            echo "Datum tekmovanja: <b>".$R["datum"]."</b><br />";
            echo "Mentor: <b>".$R["mentor1"]."</b><br /><br />";
        }
        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th>";
        echo "<th>Tekmovalec</th>";
        echo "<th>Mesto/Priznanje</th>";
        echo "<th>Napredovanje</th>";
        echo "</tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
            echo "<td>".$R["priznanje"]." &nbsp;</td>";
            if ($R["napredovanje"] ){
                echo "<td>Napredoval</td>";
            }else{
                echo "<td>&nbsp;</td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br /><br />";

        $SQL = "SELECT * FROM tabsst WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<b>Poročilo</b>:<br />";
            echo str_replace(chr(13).chr(10),"<br />",$R["porocilo"])."<br />";
        }

        echo "</body>";
        echo "</html>";
        break;
    case "401": //izbor natečaja
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        
        switch ( $VIdTekm){
            case "1":
                if ((strlen($VKrozek) == 0) or (strlen($VMentor)==0) ){
                    echo "<h2>Natečaj ni bil dodan!</h2>";
                }else{
                    $SQL = "INSERT INTO tabnatecaj (leto,krozek,mentor) VALUES (".$VLeto.",'".$VKrozek."','".$VMentor."')";
                    $result = mysqli_query($link,$SQL);
                    
                    echo "<h2>Dodana je bila interesna dejavnost: ".$VKrozek." - ".$VMentor."</h2>";
                }
        }

        $SQL = "SELECT tabnatecaj.id, tabnatecaj.krozek AS kkrozek, tabnatecaj.mentor,tabnatecaj.leto, tabnatecaj.planirano,tabnatecaj.realizirano,tabnatecaj.obisk,tabnatecajclan.krozek,  Count(tabnatecajclan.krozek) AS countofkrozek " ;
        $SQL = $SQL."FROM tabnatecaj LEFT JOIN tabnatecajclan ON tabnatecajclan.krozek = tabnatecaj.id " ;
        $SQL = $SQL."GROUP BY tabnatecaj.leto, tabnatecajclan.krozek, tabnatecaj.id, tabnatecaj.krozek, tabnatecaj.mentor, tabnatecaj.planirano,tabnatecaj.realizirano,tabnatecaj.obisk ";
        $SQL = $SQL."HAVING (((tabnatecaj.leto)=".$VLeto.")) ORDER BY tabnatecaj.krozek";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izbor natečaja - ".$VLeto."/".($VLeto+1)."</h2>";
        echo "<p>Če vašega natečaja še ni v spodnjem spisku, ga vpišite, pri tem pa pazite na to, da se bodo na nivoju šole uporabljale <b>enotne oznake imen natečajev</b>.<br />";
        echo "<b>Postopek vpisa:</b><br />";
        echo "1. Vpis imena natečaja in mentorja<br />";
        echo "2. Klik na ime natečaja za izbor udeležencev natečaja s spiska učencev<br />";
        echo "3. Klik na Poglej/popravi za vpis poročila in realizacije<br />";
        echo "<font color='green'>Osnovne podatke o natečaju lahko popravite s klikom na <b>Poglej/popravi</b> v stolpcu Poročilo</font><br />";
        echo "<br />";

        echo "</p>";

        echo "<form name='Krozki' method=post action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='401'>";
        echo "<table border=1 cellspacing=0>";
        if ($VLevel > 1 ){
            echo "<tr><th>Št.</th><th>Natečaj</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Poročilo</th><th>Briši</th></tr>";
        }else{
            echo "<tr><th>Št.</th><th>Natečaj</th><th>Mentor</th><th>Vpisanih</th><th>Plan.</th><th>Real.</th><th>%</th><th>Obisk(%)</th><th>Poročilo</th></tr>";
        }
        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=402&idtekm=".$R["id"]."'>".$R["kkrozek"]."</a></td>";
            echo "<td>".$R["mentor"]."</td>";
            echo "<td align=center>".$R["countofkrozek"]."</td>";
            echo "<td align=center>".$R["planirano"]."</td>";
            echo "<td align=center>".$R["realizirano"]."</td>";
            if (is_numeric($R["planirano"])){
                if ($R["planirano"] > 0 ){
                    echo "<td align=center>".number_format($R["realizirano"]/$R["planirano"]*100,2)."</td>";
                }else{
                    echo "<td align=center>&nbsp;</td>";
                }
            }else{
                echo "<td align=center>&nbsp;</td>";
            }
            echo "<td align=center>".$R["obisk"]."</td>";
            
            echo "<td><a href='tekmovanjakrozki.php?id=405&idtekm=".$R["id"]."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
            if ($VLevel > 1 ){
                echo "<td><a href='tekmovanjakrozki.php?id=405&idtekm=".$R["id"]."&brisi=1'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "<tr><td></td><td><input name='krozek' type='text' size='30'></td><td><input name='mentor' type='text' size='30'></td><td></td><td></td><td></td><td></td><td></td><td><input name='idtekm' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
        echo "</table><br />";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "402": //dodeli učence natečaju
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=401'>Na seznam</a><br />";
        
        $SQL = "SELECT tabnatecajclan.id AS nid,tabnatecaj.*,tabucenci.*,tabrazdat.* FROM ";
        $SQL = $SQL . "(((tabnatecajclan INNER JOIN tabnatecaj ON tabnatecajclan.krozek=tabnatecaj.Id) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabnatecajclan.ucenec=tabucenci.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabnatecajclan.ucenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabnatecajclan.leto=".$VLeto." AND tabnatecajclan.krozek=".$VIdTekm;
        $SQL = $SQL . " ORDER BY tabrazdat.razred, tabrazdat.oznaka, tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["krozek"]." - ".$R["mentor"]."</h2>";
        }

        echo "<table border=1>";
        echo "<tr>";
        echo "<th>Št.</th><th>Učenec</th><th>Dat. roj.</th><th>Kontakt</th><th>Briši</th>";
        echo "</tr>";

        $Indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
            $Datum=new DateTime(isDate($R["DatRoj"]));
            echo "<td align='right'>".$Datum->format('d.m.Y')."</td>";
            echo "<td>".$R["ocekontakt"].", ".$R["matikontakt"].", ".$R["SkrbnikiKontakt"]."</td>";
            echo "<td><a href='tekmovanjakrozki.php?id=404&idtekm=".$R["nid"]."&krozek=".$VIdTekm."'>Briši</a></td>";
            echo "</tr>";
            $Indx=$Indx+1;
        }
        echo "</table><br />";

        $SQL = "SELECT * FROM tabnatecaj WHERE id=". $VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo"<h2>Vpis učencev na natečaj<br />";
              echo $R["krozek"]."</h2><br />";
        }else{
            header ("Location: tekmovanjakrozki.php?id=401");
        }

        echo "<form name='tekmovanja' method=post action='tekmovanjakrozki.php'>";
        echo "<input type='hidden' name='id' value='403'>";
        echo "<input type='hidden' name='krozek' value='".$VIdTekm."'>";
        
        echo "<table border=0>";
        echo "<tr>";
        echo "<td>";
        echo "Šolsko leto: <select name='solskoleto'>";
        echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
        echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . $VLeto . "</option>";
        echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "Vpisani na natečaj:<br />";
        echo "(Več naenkrat jih lahko označite s <br />skupnim pritiskom tipke Ctrl in levim klikom)";
        echo "</td>";
        echo "<td>";
        echo "<select name='vpisani[]' multiple size='30'>";
        
        $SQL = "SELECT tabucenci.*,tabrazred.*,tabrazdat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0";
        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</form>";
        echo "</body>";
        echo "</html>";
        break;
    case "403": //vpis natečaja
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        $VTekmovanje=$VKrozek;
        if (isset($_POST["vpisani"])){
            $VTekmovalci=Arr2Str($_POST["vpisani"]);
        }else{
            $VTekmovalci="";
        }
        if (strlen($VTekmovalci) > 0){
            $SQL = "SELECT tabucenci.*,tabrazred.* FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec WHERE tabrazred.leto=".$VLeto." AND tabucenci.IdUcenec IN (".$VTekmovalci.") ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Vvpisani[$Indx]=$R["IdUcenec"];
                $Indx=$Indx+1;
            }
            $VSkupaj=$Indx-1;

            $VStamp=$Danes->format('Y-m-d H:i:s');

            for ($Indx=1;$Indx <= $VSkupaj;$Indx++){
                if ($Vvpisani[$Indx] > 0 ){
                    $SQL = "SELECT * FROM tabnatecajclan WHERE ucenec=".$Vvpisani[$Indx]." AND krozek=".$VTekmovanje;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "Učenec ".$R["ucenec"]." je že vpisan.<br />";
                    }else{
                        $SQL = "INSERT INTO tabnatecajclan (leto,krozek,ucenec,avtor,datum) VALUES (".$VLeto.",".$VTekmovanje.",".$Vvpisani[$Indx].",'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }
        }
        /*
        echo "Vpisano je bilo:<br />";
        $SQL = "SELECT tabnatecaj.*,tabucenci.*,tabrazred.* FROM ((tabnatecajclan INNER JOIN tabnatecaj ON tabnatecajclan.krozek=tabnatecaj.Id) INNER JOIN tabucenci ON tabnatecajclan.ucenec=tabucenci.idUcenec) INNER JOIN tabrazred ON tabnatecajclan.ucenec=tabrazred.idUcenec WHERE tabrazred.leto=".$VLeto." AND tabnatecajclan.leto=".$VLeto." AND tabnatecajclan.krozek=".$VTekmovanje;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            echo "<h2>".$R["krozek"]." - ".$R["mentor"]."</h2>";
        }
        */

        header ("Location: tekmovanjakrozki.php?id=402&idtekm=".$VTekmovanje);
        break;
    case "404": //briši natečaj učenec
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        $SQL = "DELETE FROM tabnatecajclan WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);
        header ("Location: tekmovanjakrozki.php?id=402&idtekm=".$VKrozek);
        break;
    case "405": //natečaj poročilo
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "<a href='tekmovanjakrozki.php?id=401'>Na seznam</a><br />";
        
        if (isset($_POST["krozek"])){
            $VKrozek = $_POST["krozek"];
        }else{
            if (isset($_GET["krozek"])){
                $VKrozek=$_GET["krozek"];
            }else{
                $VKrozek = "";
            }
        }
        if (isset($_POST["mentor"])){
            $VMentor = $_POST["mentor"];
        }else{
            if (isset($_GET["mentor"])){
                $VMentor=$_GET["mentor"];
            }else{
                $VMentor = "";
            }
        }
        if (isset($_POST["brisi"])){
            $Brisi = $_POST["brisi"];
        }else{
            if (isset($_GET["brisi"])){
                $Brisi=$_GET["brisi"];
            }else{
                $Brisi = "";
            }
        }

        switch ($Brisi){
            case "1":
                if ($VLevel > 1 ){
                    $SQL = "DELETE FROM tabnatecaj WHERE id=".$VIdTekm;
                    $result = mysqli_query($link,$SQL);
                    header ("Location: tekmovanjakrozki.php?id=401");
                }
                break;
            case "2":
                $SQL = "UPDATE tabnatecaj SET krozek='".$VKrozek."',mentor='".$VMentor."' WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                header ("Location: tekmovanjakrozki.php?id=401");
                break;
            default:
                $SQL = "SELECT * FROM tabnatecaj WHERE id=".$VIdTekm;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Poročilo o natečaju: ".$R["krozek"]." - ".$R["mentor"].":</h2>";
                    echo "<form name='form_krozek' method=post action='tekmovanjakrozki.php'>";
                    echo "Natečaj: <input name='krozek' type='text' size='40' value='".$R["krozek"]."'><br />";
                    echo "Mentor: <input name='mentor' type='text' size='40' value='".$R["mentor"]."'><br />";
                    echo "<input name='brisi' type='hidden' value='2'>";
                    echo "<input name='id' type='hidden' value='405'>";
                    echo "<input name='idtekm' type='hidden' value='".$VIdTekm."'>";
                    echo "<input name='submit' type='submit' value='Spremeni podatke'>";
                    echo "</form>";
                    
                    echo "<form name='form_realizacija' method=post action='tekmovanjakrozki.php'>";
                    echo "<input type='hidden' name='id' value='406'>";
                    echo "<input type='hidden' name='idtekm' value='".$VIdTekm."'>";

                    echo "Poročilo o natečaju<br />";
                    echo "<font color='red'>Poročilo ne sme vsebovati enojnih ali dvojnih narekovajev!</font><br />";
                    echo "<textarea name='komentar' cols='80' rows='10'>".$R["porocilo"]."</textarea><br />";
                    echo "Planirano: <input name='planirano' type='text' size='5' value='".$R["planirano"]."'> ";
                    echo "Realizirano: <input name='realizirano' type='text' size='5' value='".$R["realizirano"]."'>";
                    if ($R["planirano"] > 0 ){
                        echo " Procent: ".number_format($R["realizirano"]/$R["planirano"]*100,2).", ";
                    }else{
                        echo " Procent: , ";
                    }
                    echo "Obisk (%): <input name='obisk' type='text' size='5' value='".$R["obisk"]."'>"."<br />";
                    echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
                    echo "</form>";
                }
        }
        echo "</body>";
        echo "</html>";
        break;
    case "406": //vpis natečaj report
        $areplace=array("'",chr(34));
        $VPorocilo = str_replace($areplace,"",$_POST["komentar"]);

        $SQL = "SELECT * FROM tabnatecaj WHERE id=".$VIdTekm;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $VPlanirano=$_POST["planirano"];
            if (strlen($VPlanirano) > 0 ){
                $VPlanirano=str_replace(",",".",$VPlanirano);
            }else{
                $VPlanirano=0.0;
            }
            $VRealizirano=$_POST["realizirano"];
            if (strlen($VRealizirano) > 0){
                $VRealizirano=str_replace(",",".",$VRealizirano);
            }else{
                $VRealizirano=0.0;
            }
            $VObisk=$_POST["obisk"];
            if (strlen($VObisk) > 0){
                $VObisk=str_replace(",",".",$VObisk);
            }else{
                $VObisk=0.0;
            }
            $SQL = "UPDATE  tabnatecaj SET ";
            $SQL = $SQL . "porocilo='" . $VPorocilo ."',";
            $SQL = $SQL . "planirano=".$VPlanirano.",";
            $SQL = $SQL . "realizirano=".$VRealizirano.",";
            $SQL = $SQL . "obisk=".$VObisk;
            $SQL = $SQL ." WHERE Id=".$R["id"];
            $result = mysqli_query($link,$SQL);
        }
        header ("Location: tekmovanjakrozki.php?id=401");
        break;
    case "501": //form ID priznanja
        echo "<title>Tekmovanja in interesne dejavnosti";
        echo "</title>";
        echo "</head>";
        echo "<body>";
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $PozXSola=10;
        $PozYSola=20;
        $PozXNaslov=10;
        $PozYNaslov=30;
        $PozXRavnatelj=160;
        $PozYRavnatelj=267;
        $PozXKraj=15;
        $PozYKraj=261;
        $PozXIzvajalec=160;
        $PozYIzvajalec=261;
        $PozXPriznanje=10;
        $PozYPriznanje=90;
        $PozXLine1=10;
        $PozYLine1=120;
        $PozXLine2=10;
        $PozYLine2=130;
        $PozXVsebina=10;
        $PozYVsebina=150;
        $PozXDatum=10;
        $PozYDatum=210;
        $PozXLogo=95;
        $PozYLogo=50;
        $PozXIme=10;
        $PozYIme=190;
        $PozX1Crta1=30;
        $PozY1Crta1=180;
        $PozX2Crta1=167;
        $PozY2Crta1=180;
        $PozX1Crta2=30;
        $PozY1Crta2=200;
        $PozX2Crta2=167;
        $PozY2Crta2=200;
        $PozX1Crta3=30;
        $PozY1Crta3=220;
        $PozX2Crta3=167;
        $PozY2Crta3=220;
        $VFile="predloga";
        $LogoSize=30;
        $PorSola=1;
        $PorRavnatelj=1;
        $PorKraj=0;
        $PorIzvajalec=1;
        $PorPriznanje=1;
        $PorLine1=1;
        $PorLine2=1;
        $PorVsebina=1;
        $PorDatum=1;
        $PorIme=1;
        $PorNaslov=1;
        $FSSola=22;
        $FSRavnatelj=12;
        $FSKraj=12;
        $FSIzvajalec=12;
        $FSPriznanje=64;
        $FSLine1=24;
        $FSLine2=24;
        $FSVsebina=24;
        $FSDatum=24;
        $FSIme=30;
        $FSNaslov=22;
        $VFont="Arial";
        $VIzvajalec = "Ravnatelj:";
        $VMentor = $VRavnatelj;
        $VPriznanje = "PRIZNANJE";
        $VLine1 = "za obiskovanje";
        $VLine2 = "interesne dejavnosti";
        $VVsebina = "Dejavnost";
        $VKraj = $VSolaKraj.", ".$Danes->format('j.n.Y');
        $VOzadje = "";
        $PozXRazred = 0;
        $PozYRazred = 0;
        $PorRazred = 0;
        $FSRazred = 24;
        $WSola = 0;
        $WNaslov = 0;
        $WPriznanje = 0;
        $WVrstica1 = 0;
        $WVrstica2 = 0;
        $WDejavnost = 0;
        $WKrajDat = 0;
        $WNazivIzv = 0;
        $WIzvajalec = 0;
        $WIme = 0;
        $WRazred = 0;
        $WDatRoj = 0;
        
        if (isset($_GET["fileizbrani"])){
            $VFile=$_GET["fileizbrani"];
            $SQL = "SELECT * FROM tabdiploma WHERE priznanje='".$VFile."'";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $PozXSola=$R["PozXSola"];
                $PozYSola=$R["PozYSola"];
                $PozXNaslov=$R["PozXNaslov"];
                $PozYNaslov=$R["PozYNaslov"];
                $PozXRavnatelj=$R["PozXRavnatelj"];
                $PozYRavnatelj=$R["PozYRavnatelj"];
                $PozXKraj=$R["PozXKraj"];
                $PozYKraj=$R["PozYkraj"];
                $PozXIzvajalec=$R["PozXIzvajalec"];
                $PozYIzvajalec=$R["PozYIzvajalec"];
                $PozXPriznanje=$R["PozXPriznanje"];
                $PozYPriznanje=$R["PozYpriznanje"];
                $PozXLine1=$R["PozXLine1"];
                $PozYLine1=$R["PozYLine1"];
                $PozXLine2=$R["PozXLine2"];
                $PozYLine2=$R["PozYLine2"];
                $PozXVsebina=$R["PozXVsebina"];
                $PozYVsebina=$R["PozYVsebina"];
                $PozXDatum=$R["PozXDatum"];
                $PozYDatum=$R["PozYDatum"];
                $PozXLogo=$R["PozXLogo"];
                $PozYLogo=$R["PozYLogo"];
                $PozXIme=$R["PozXIme"];
                $PozYIme=$R["PozYIme"];
                $PozX1Crta1=$R["PozX1Crta1"];
                $PozY1Crta1=$R["PozY1Crta1"];
                $PozX2Crta1=$R["PozX2Crta1"];
                $PozY2Crta1=$R["PozY2Crta1"];
                $PozX1Crta2=$R["PozX1Crta2"];
                $PozY1Crta2=$R["PozY1Crta2"];
                $PozX2Crta2=$R["PozX2Crta2"];
                $PozY2Crta2=$R["PozY2Crta2"];
                $PozX1Crta3=$R["PozX1Crta3"];
                $PozY1Crta3=$R["PozY1Crta3"];
                $PozX2Crta3=$R["PozX2Crta3"];
                $PozY2Crta3=$R["PozY2Crta3"];
                $VFile=$R["priznanje"];
                $LogoSize=$R["LogoSize"];
                $PorSola=$R["PorSola"];
                $PorRavnatelj=$R["PorRavnatelj"];
                $PorKraj=$R["PorKraj"];
                $PorIzvajalec=$R["PorIzvajalec"];
                $PorPriznanje=$R["PorPriznanje"];
                $PorLine1=$R["PorLine1"];
                $PorLine2=$R["PorLine2"];
                $PorVsebina=$R["PorVsebina"];
                $PorDatum=$R["PorDatum"];
                $PorIme=$R["PorIme"];
                $PorNaslov=$R["PorNaslov"];
                $FSSola=$R["FSSola"];
                $FSRavnatelj=$R["FSRavnatelj"];
                $FSKraj=$R["FSKraj"];
                $FSIzvajalec=$R["FSIzvajalec"];
                $FSPriznanje=$R["FSPriznanje"];
                $FSLine1=$R["FSLine1"];
                $FSLine2=$R["FSLine2"];
                $FSVsebina=$R["FSVsebina"];
                $FSDatum=$R["FSDatum"];
                $FSIme=$R["FSIme"];
                $FSNaslov=$R["FSNaslov"];
                $VFont=$R["Font"];
                                  
                $VSola = $R["sola"];
                $VNaslov = $R["naslov"];
                $VMentor = $R["ravnatelj"];
                $VKraj = $R["kraj"];
                $VIzvajalec = $R["izvajalec"];
                $VPriznanje = $R["diploma"];
                $VLine1 = $R["line1"];
                $VLine2 = $R["line2"];
                $VImeKrozka = $R["vsebina"];
                if (isset($R["ozadje"])){
                    $VOzadje = $R["ozadje"];
                }else{
                    $VOzadje = "";
                }
                if (isset($R["PozXRazred"])){
                    $PozXRazred = $R["PozXRazred"];
                }else{
                    $PozXRazred = 0;
                }
                if (isset($R["PozYRazred"])){
                    $PozYRazred = $R["PozYRazred"];
                }else{
                    $PozYRazred = 0;
                }
                if (isset($R["PorRazred"])){
                    $PorRazred = $R["PorRazred"];
                }else{
                    $PorRazred = 0;
                }
                if (isset($R["FSRazred"])){
                    $FSRazred = $R["FSRazred"];
                }else{
                    $FSRazred = 24;
                }
                if (isset($R["wsola"])) $WSola = $R["wsola"];
                if (isset($R["wnaslov"])) $WNaslov = $R["wnaslov"];
                if (isset($R["wpriznanje"])) $WPriznanje = $R["wpriznanje"];
                if (isset($R["wvrstica1"])) $WVrstica1 = $R["wvrstica1"];
                if (isset($R["wvrstica2"])) $WVrstica2 = $R["wvrstica2"];
                if (isset($R["wdejavnost"])) $WDejavnost = $R["wdejavnost"];
                if (isset($R["wkrajdat"])) $WKrajDat = $R["wkrajdat"];
                if (isset($R["wnazivizv"])) $WNazivIzv = $R["wnazivizv"];
                if (isset($R["wizvajalec"])) $WIzvajalec = $R["wizvajalec"];
                if (isset($R["wime"])) $WIme = $R["wime"];
                if (isset($R["wrazred"])) $WRazred = $R["wrazred"];
                if (isset($R["wdatroj"])) $WDatRoj = $R["wdatroj"];
            }
        }
        echo "<form name='tekmovanja' method='post' ENCTYPE='multipart/form-data' action='tekmovanjakrozki.php'>";
        echo "<input name='id' type='hidden' value='502'>";
        echo "<br />";
        echo "<h2>Priznanja in diplome po meri</h2>";
        echo "Meri se X od levega roba in Y od zgornjega roba na listu A4.<br />";
        echo "Koordinate se nanašajo na zgornji levi/desni kot ali sredino napisa. 0-leva poravnava, 1-centrirano, 2-desna poravnava.<br />";
        echo "V primeru sredinske (1) in desne (2) poravnave vpišite začetno točko (x,y) in širino polja.<br />";
        echo "Črte imajo začetno in končno točko. <br />";
        echo "Če rubrike ne želite, jo pustite prazno ali pa ji dajte X koordinato na 0. <br />";
        echo "<br />";
        echo "Eventuelna slika (jpg) za ozadje naj bo ločljivosti vsaj 1191x1684 pixlov pri 144 DPI. Velikost je omejena na 1.5 MByte.<br />Program doda 5 mm roba na levo, zgoraj, desno. Spodnji rob je odvisen od višine slike.<br />";
        echo "<br />";

        echo "<table border=0>";

        echo "<tr><th>Rubrika</th><th>Vsebina</th><th>Koordinata X</th><th>Koordinata Y</th><th>Širina<br /><small>(0=do desnega roba)</small></th><th>Poravnava</th><th>Velikost<br />pisave</th></tr>";
        echo "<tr><td>Šola:</td><td><input name='sola' type='text' value='".$VSola."' size='40'>";
        echo "</td><td><input type='text' name='PozXSola' value='".$PozXSola."' size='5'></td>";
        echo "<td><input type='text' name='PozYSola' value='".$PozYSola."' size='5'></td>";
        echo "<td><input type='text' name='wsola' value='".$WSola."' size='5'></td>";
        echo "<td><input type='text' name='PorSola' value='".$PorSola."' size='2'></td>";
        echo "<td><input type='text' name='FSSola' value='".$FSSola."' size='3'></td></tr>";

        echo "<tr><td>Naslov:</td><td><input name='naslov' type='text' value='".$VSolaNaslov."' size='40'></td>";
        echo "<td><input type='text' name='PozXNaslov' value='".$PozXNaslov."' size='5'></td>";
        echo "<td><input type='text' name='PozYNaslov' value='".$PozYNaslov."' size='5'></td>";
        echo "<td><input type='text' name='wnaslov' value='".$WNaslov."' size='5'></td>";
        echo "<td><input type='text' name='PorNaslov' value='".$PorNaslov."' size='2'></td>";
        echo "<td><input type='text' name='FSNaslov' value='".$FSNaslov."' size='3'></td></tr>";
        
        echo "<tr><td>Priznanje: (modro)</td><td><input name='priznanje' type='text' value='".$VPriznanje."' size='40'></td>";
        echo "<td><input type='text' name='PozXPriznanje' value='".$PozXPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='PozYPriznanje' value='".$PozYPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='wpriznanje' value='".$WPriznanje."' size='5'></td>";
        echo "<td><input type='text' name='PorPriznanje' value='".$PorPriznanje."' size='2'></td>";
        echo "<td><input type='text' name='FSPriznanje' value='".$FSPriznanje."' size='3'></td></tr>";
        
        echo "<tr><td>Vrstica 1:</td><td><input name='vrstica1' type='text' value='".$VLine1."' size='40'></td>";
        echo "<td><input type='text' name='PozXLine1' value='".$PozXLine1."' size='5'></td>";
        echo "<td><input type='text' name='PozYLine1' value='".$PozYLine1."' size='5'></td>";
        echo "<td><input type='text' name='wvrstica1' value='".$WVrstica1."' size='5'></td>";
        echo "<td><input type='text' name='PorLine1' value='".$PorLine1."' size='2'></td>";
        echo "<td><input type='text' name='FSLine1' value='".$FSLine1."' size='3'></td></tr>";
        
        echo "<tr><td>Vrstica 2:</td><td><input name='vrstica2' type='text' value='".$VLine2."' size='40'></td>";
        echo "<td><input type='text' name='PozXLine2' value='".$PozXLine2."' size='5'></td>";
        echo "<td><input type='text' name='PozYLine2' value='".$PozYLine2."' size='5'></td>";
        echo "<td><input type='text' name='wvrstica2' value='".$WVrstica2."' size='5'></td>";
        echo "<td><input type='text' name='PorLine2' value='".$PorLine2."' size='2'></td>";
        echo "<td><input type='text' name='FSLine2' value='".$FSLine2."' size='3'></td></tr>";
        
        echo "<tr><td>Dejavnost: (rdeče)</td><td><input name='vsebina' type='text' value='".$VVsebina."' size='40'></td>";
        echo "<td><input type='text' name='PozXVsebina' value='".$PozXVsebina."' size='5'></td>";
        echo "<td><input type='text' name='PozYVsebina' value='".$PozYVsebina."' size='5'></td>";
        echo "<td><input type='text' name='wdejavnost' value='".$WDejavnost."' size='5'></td>";
        echo "<td><input type='text' name='PorVsebina' value='".$PorVsebina."' size='2'></td>";
        echo "<td><input type='text' name='FSVsebina' value='".$FSVsebina."' size='3'></td></tr>";
        
        echo "<tr><td>Kraj in datum:</td><td><input name='kraj' type='text' value='".$VKraj."' size='40'></td>";
        echo "<td><input type='text' name='PozXKraj' value='".$PozXKraj."' size='5'></td>";
        echo "<td><input type='text' name='PozYKraj' value='".$PozYKraj."' size='5'></td>";
        echo "<td><input type='text' name='wkrajdat' value='".$WKrajDat."' size='5'></td>";
        echo "<td><input type='text' name='PorKraj' value='".$PorKraj."' size='2'></td>";
        echo "<td><input type='text' name='FSKraj' value='".$FSKraj."' size='3'></td></tr>";
        
        echo "<tr><td>Naziv izvajalca:</td><td><input name='naziv' type='text' value='".$VIzvajalec."' size='40'></td>";
        echo "<td><input type='text' name='PozXIzvajalec' value='".$PozXIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='PozYIzvajalec' value='".$PozYIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='wnazivizv' value='".$WNazivIzv."' size='5'></td>";
        echo "<td><input type='text' name='PorIzvajalec' value='".$PorIzvajalec."' size='2'></td>";
        echo "<td><input type='text' name='FSIzvajalec' value='".$FSIzvajalec."' size='3'></td></tr>";
        
        echo "<tr><td>Izvajalec:</td><td><input name='izvajalec' type='text' value='".$VMentor."' size='40'></td>";
        echo "<td><input type='text' name='PozXRavnatelj' value='".$PozXRavnatelj."' size='5'></td>";
        echo "<td><input type='text' name='PozYRavnatelj' value='".$PozYRavnatelj."' size='5'></td>";
        echo "<td><input type='text' name='wizvajalec' value='".$WIzvajalec."' size='5'></td>";
        echo "<td><input type='text' name='PorRavnatelj' value='".$PorRavnatelj."' size='2'></td>";
        echo "<td><input type='text' name='FSRavnatelj' value='".$FSRavnatelj."' size='3'></td></tr>";
        
        echo "<tr><td>Ime</td><td></td><td><input type='text' name='PozXIme' value='".$PozXIme."' size='5'></td>";
        echo "<td><input type='text' name='PozYIme' value='".$PozYIme."' size='5'></td>";
        echo "<td><input type='text' name='wime' value='".$WIme."' size='5'></td>";
        echo "<td><input type='text' name='PorIme' value='".$PorIme."' size='2'></td>";
        echo "<td><input type='text' name='FSIme' value='".$FSIme."' size='3'></td></tr>";
        
        echo "<tr><td>Razred</td><td></td><td><input type='text' name='PozXRazred' value='".$PozXRazred."' size='5'></td>";
        echo "<td><input type='text' name='PozYRazred' value='".$PozYRazred."' size='5'></td>";
        echo "<td><input type='text' name='wrazred' value='".$WRazred."' size='5'></td>";
        echo "<td><input type='text' name='PorRazred' value='".$PorRazred."' size='2'></td>";
        echo "<td><input type='text' name='FSRazred' value='".$FSRazred."' size='3'></td></tr>";
        
        echo "<tr><td>Datum rojstva</td><td></td><td><input type='text' name='PozXDatum' value='".$PozXDatum."' size='5'></td>";
        echo "<td><input type='text' name='PozYDatum' value='".$PozYDatum."' size='5'></td>";
        echo "<td><input type='text' name='wdatroj' value='".$WDatRoj."' size='5'></td>";
        echo "<td><input type='text' name='PorDatum' value='".$PorDatum."' size='2'></td>";
        echo "<td><input type='text' name='FSDatum' value='".$FSDatum."' size='3'></td></tr>";
        
        echo "<tr><td>Logotip</td><td></td><td><input type='text' name='PozXLogo' value='".$PozXLogo."' size='5'></td>";
        echo "<td><input type='text' name='PozYLogo' value='".$PozYLogo."' size='5'></td></tr>";
        
        echo "<tr><td>Širina logotipa (mm)</td><td></td><td><input type='text' name='LogoSize' value='".$LogoSize."' size='5'></td></tr>";
        
        echo "<tr><th></th><th></th><th>X1</th><th>Y1</th><th>X2</th><th>Y2</th></tr>";
        echo "<tr><td>Črta 1</td><td></td><td><input type='text' name='PozX1Crta1' value='".$PozX1Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta1' value='".$PozY1Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta1' value='".$PozX2Crta1."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta1' value='".$PozY2Crta1."' size='5'></td></tr>";
        
        echo "<tr><td>Črta 2</td><td></td><td><input type='text' name='PozX1Crta2' value='".$PozX1Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta2' value='".$PozY1Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta2' value='".$PozX2Crta2."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta2' value='".$PozY2Crta2."' size='5'></td></tr>";
        
        echo "<tr><td>Črta 3</td><td></td><td><input type='text' name='PozX1Crta3' value='".$PozX1Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozY1Crta3' value='".$PozY1Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozX2Crta3' value='".$PozX2Crta3."' size='5'></td>";
        echo "<td><input type='text' name='PozY2Crta3' value='".$PozY2Crta3."' size='5'></td></tr>";
        
        echo "<tr><td>Pisava: </td><td><select name='Font'>";
        echo "<option value='".$VFont."' selected>".$VFont."</option>";
        echo "<option value='Arial'>Arial</option>";
        echo "<option value='Times'>Times</option>";
        echo "</select></td></tr>";
        
        echo "<tr><td>Shrani kot: </td><td><input name='dato' size='40' value='".$VFile."'></td></tr>";
        
        echo "<tr><td>Izberi obstoječo predlogo: </td><td><select name='fileizbrani'>";
        $SQL = "SELECT priznanje FROM tabdiploma ORDER BY priznanje";
        $result = mysqli_query($link,$SQL);

        if (mysqli_num_rows($result)){
             while ($R = mysqli_fetch_array($result)){
                 echo "<option>".$R["priznanje"]."</option>";
            }
        }else{
            echo "<option>".$VFile."</option>";
        }
        echo "</select>";
        echo "</td><td colspan='5'><input type='submit' name='submit' value='Izberi'></td></tr>";

        echo "<tr><td>Slika za ozadje:</td>";
        echo "<td><input name='ozadje' type='hidden' value='".$VOzadje."'>".$VOzadje."</td>";
        echo "<td colspan='5'><input  name='file' type='file'></td></tr>";
        echo "<tr>";
        echo "<td>";
        echo "Učenci šole:<br />";
        echo "(Več naenkrat jih lahko označite s <br />skupnim pritiskom tipke Ctrl in levim klikom)";
        echo "</td>";
        echo "<td>";
        echo "<select name='vpisani[]' multiple size='30'>";
        
        $SQL = "SELECT tabucenci.*,tabrazdat.* FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0";
        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["IdUcenec"]."'>".$R["Priimek"]." ".$R["Ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        
        echo "</body>";
        echo "</html>";
        break;
    case "502": //ID priznanja PDF
        $VSubmit=$_POST["submit"];
        if ($VSubmit=="Izberi"){
            $VFile=$_POST["fileizbrani"];
            $_SESSION["fileizbrani"]=$VFile;
            header ("Location: tekmovanjakrozki.php?id=501&fileizbrani=".$VFile);
        }else{
            $allowedExts = array("jpg", "JPG");
            $VOzadje="";
            $uploaded=false;
            if (isset($_FILES["file"])){
                $Preneseno=$_FILES["file"];
                $extension = explode(".", $Preneseno["name"]);
                $extension = end($extension);
                $extension = strtolower($extension);
                if (strlen($_FILES["file"]["name"]) > 0){
                    if (($_FILES["file"]["size"] < 1512000) && in_array($extension, $allowedExts)){
                            if ($_FILES["file"]["error"] > 0){
                                echo "Vrnjena koda: " . $_FILES["file"]["error"] . "<br />";
                            }else{
                                //echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                                //echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                                //echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                                //echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
                                $VOzadje="ozadje_".$Danes->format('YmdHis').".jpg";
                                if (file_exists("img/" . $_FILES["file"]["name"])){
                                    //echo $_FILES["file"]["name"] . " že obstaja. ";
                                    move_uploaded_file($_FILES["file"]["tmp_name"],"img/".$VOzadje);
                                    //echo "Shranjeno v: " . "dato/" . $VOzadje;
                                    $uploaded=true;
                                }else{
                                    move_uploaded_file($_FILES["file"]["tmp_name"],"img/" . $VOzadje);
                                    //echo "Shranjeno v: " . "dato/" . $VOzadje;
                                    $uploaded=true;
                                }
                           }
                    }else{
                        echo "Napačen tip ali velikost (1.5M) datoteke.";
                    }
                }
            }
            if (!$uploaded){
                $VOzadje=$_POST["ozadje"];
            }
            $PozXSola=$_POST["PozXSola"];
            $PozYSola=$_POST["PozYSola"];
            $PozXNaslov=$_POST["PozXNaslov"];
            $PozYNaslov=$_POST["PozYNaslov"];
            $PozXRavnatelj=$_POST["PozXRavnatelj"];
            $PozYRavnatelj=$_POST["PozYRavnatelj"];
            $PozXKraj=$_POST["PozXKraj"];
            $PozYKraj=$_POST["PozYKraj"];
            $PozXIzvajalec=$_POST["PozXIzvajalec"];
            $PozYIzvajalec=$_POST["PozYIzvajalec"];
            $PozXPriznanje=$_POST["PozXPriznanje"];
            $PozYPriznanje=$_POST["PozYPriznanje"];
            $PozXLine1=$_POST["PozXLine1"];
            $PozYLine1=$_POST["PozYLine1"];
            $PozXLine2=$_POST["PozXLine2"];
            $PozYLine2=$_POST["PozYLine2"];
            $PozXVsebina=$_POST["PozXVsebina"];
            $PozYVsebina=$_POST["PozYVsebina"];
            $PozXDatum=$_POST["PozXDatum"];
            $PozYDatum=$_POST["PozYDatum"];
            $PozXLogo=$_POST["PozXLogo"];
            $PozYLogo=$_POST["PozYLogo"];
            $PozXIme=$_POST["PozXIme"];
            $PozYIme=$_POST["PozYIme"];
            $PozX1Crta1=$_POST["PozX1Crta1"];
            $PozY1Crta1=$_POST["PozY1Crta1"];
            $PozX2Crta1=$_POST["PozX2Crta1"];
            $PozY2Crta1=$_POST["PozY2Crta1"];
            $PozX1Crta2=$_POST["PozX1Crta2"];
            $PozY1Crta2=$_POST["PozY1Crta2"];
            $PozX2Crta2=$_POST["PozX2Crta2"];
            $PozY2Crta2=$_POST["PozY2Crta2"];
            $PozX1Crta3=$_POST["PozX1Crta3"];
            $PozY1Crta3=$_POST["PozY1Crta3"];
            $PozX2Crta3=$_POST["PozX2Crta3"];
            $PozY2Crta3=$_POST["PozY2Crta3"];
            $VFile=$_POST["dato"];
            $LogoSize=$_POST["LogoSize"];
            $PorSola=$_POST["PorSola"];
            $PorRavnatelj=$_POST["PorRavnatelj"];
            $PorKraj=$_POST["PorKraj"];
            $PorIzvajalec=$_POST["PorIzvajalec"];
            $PorPriznanje=$_POST["PorPriznanje"];
            $PorLine1=$_POST["PorLine1"];
            $PorLine2=$_POST["PorLine2"];
            $PorVsebina=$_POST["PorVsebina"];
            $PorDatum=$_POST["PorDatum"];
            $PorIme=$_POST["PorIme"];
            $PorNaslov=$_POST["PorNaslov"];
            $FSSola=$_POST["FSSola"];
            $FSRavnatelj=$_POST["FSRavnatelj"];
            $FSKraj=$_POST["FSKraj"];
            $FSIzvajalec=$_POST["FSIzvajalec"];
            $FSPriznanje=$_POST["FSPriznanje"];
            $FSLine1=$_POST["FSLine1"];
            $FSLine2=$_POST["FSLine2"];
            $FSVsebina=$_POST["FSVsebina"];
            $FSDatum=$_POST["FSDatum"];
            $FSIme=$_POST["FSIme"];
            $FSNaslov=$_POST["FSNaslov"];
            $VFont=$_POST["Font"];
                              
            $VSola = $_POST["sola"];
            $VNaslov = $_POST["naslov"];
            $VMentor = $_POST["izvajalec"];
            $VKraj = $_POST["kraj"];
            $VIzvajalec = $_POST["naziv"];
            $VPriznanje = $_POST["priznanje"];
            $VLine1 = $_POST["vrstica1"];
            $VLine2 = $_POST["vrstica2"];
            $VImeKrozka = $_POST["vsebina"];
            $PozXRazred = $_POST["PozXRazred"];
            $PozYRazred = $_POST["PozYRazred"];
            $PorRazred = $_POST["PorRazred"];
            $FSRazred = $_POST["FSRazred"];
            $VTekmovalci=Arr2Str($_POST["vpisani"]);

            $WSola = $_POST["wsola"];
            $WNaslov = $_POST["wnaslov"];
            $WPriznanje = $_POST["wpriznanje"];
            $WVrstica1 = $_POST["wvrstica1"];
            $WVrstica2 = $_POST["wvrstica2"];
            $WDejavnost = $_POST["wdejavnost"];
            $WKrajDat = $_POST["wkrajdat"];
            $WNazivIzv = $_POST["wnazivizv"];
            $WIzvajalec = $_POST["wizvajalec"];
            $WIme = $_POST["wime"];
            $WRazred = $_POST["wrazred"];
            $WDatRoj = $_POST["wdatroj"];
            
            $SQL = "SELECT * FROM tabdiploma WHERE priznanje='".$VFile."'";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $SQL="UPDATE tabdiploma SET ";
                $SQL=$SQL."PozXSola=".$PozXSola.",PozYSola=".$PozYSola.",";
                $SQL=$SQL."PozXNaslov=".$PozXNaslov.",PozYNaslov=".$PozYNaslov.",";
                $SQL=$SQL."PozXRavnatelj=".$PozXRavnatelj.",PozYRavnatelj=".$PozYRavnatelj.",";
                $SQL=$SQL."PozXKraj=".$PozXKraj.",PozYKraj=".$PozYKraj.",";
                $SQL=$SQL."PozXIzvajalec=".$PozXIzvajalec.",PozYIzvajalec=".$PozYIzvajalec.",";
                $SQL=$SQL."PozXPriznanje=".$PozXPriznanje.",PozYPriznanje=".$PozYPriznanje.",";
                $SQL=$SQL."PozXLine1=".$PozXLine1.",PozYLine1=".$PozYLine1.",";
                $SQL=$SQL."PozXLine2=".$PozXLine2.",PozYLine2=".$PozYLine2.",";
                $SQL=$SQL."PozXVsebina=".$PozXVsebina.",PozYVsebina=".$PozYVsebina.",";
                $SQL=$SQL."PozXDatum=".$PozXDatum.",PozYDatum=".$PozYDatum.",";
                $SQL=$SQL."PozXLogo=".$PozXLogo.",PozYLogo=".$PozYLogo.",";
                $SQL=$SQL."PozXIme=".$PozXIme.",PozYIme=".$PozYIme.",";
                $SQL=$SQL."PozXRazred=".$PozXRazred.",PozYRazred=".$PozYRazred.",";
                $SQL=$SQL."PozX1Crta1=".$PozX1Crta1.",PozY1Crta1=".$PozY1Crta1.",";
                $SQL=$SQL."PozX2Crta1=".$PozX2Crta1.",PozY2Crta1=".$PozY2Crta1.",";
                $SQL=$SQL."PozX1Crta2=".$PozX1Crta2.",PozY1Crta2=".$PozY1Crta2.",";
                $SQL=$SQL."PozX2Crta2=".$PozX2Crta2.",PozY2Crta2=".$PozY2Crta2.",";
                $SQL=$SQL."PozX1Crta3=".$PozX1Crta3.",PozY1Crta3=".$PozY1Crta3.",";
                $SQL=$SQL."PozX2Crta3=".$PozX2Crta3.",PozY2Crta3=".$PozY2Crta3.",";
                $SQL=$SQL."LogoSize=".$LogoSize.",PorSola=".$PorSola.",";
                $SQL=$SQL."PorRavnatelj=".$PorRavnatelj.",PorPriznanje=".$PorPriznanje.",";
                $SQL=$SQL."PorLine1=".$PorLine1.",PorLine2=".$PorLine2.",";
                $SQL=$SQL."PorVsebina=".$PorVsebina.",PorDatum=".$PorDatum.",PorIzvajalec=".$PorIzvajalec.",";
                $SQL=$SQL."PorIme=".$PorIme.",PorNaslov=".$PorNaslov.",PorKraj=".$PorKraj.",PorRazred=".$PorRazred.",";
                $SQL=$SQL."FSSola=".$FSSola.",";
                $SQL=$SQL."FSRavnatelj=".$FSRavnatelj.",FSPriznanje=".$FSPriznanje.",";
                $SQL=$SQL."FSLine1=".$FSLine1.",FSLine2=".$FSLine2.",";
                $SQL=$SQL."FSVsebina=".$FSVsebina.",FSDatum=".$FSDatum.",FSKraj=".$FSKraj.",FSRazred=".$FSRazred.",";
                $SQL=$SQL."FSIme=".$FSIme.",FSNaslov=".$FSNaslov.",FSIzvajalec=".$FSIzvajalec.",font='".$VFont."',";
                $SQL=$SQL."sola='".$VSola."',Naslov='".$VNaslov."',";
                $SQL=$SQL."diploma='".$VPriznanje."',Line1='".$VLine1."',";
                $SQL=$SQL."Line2='".$VLine2."',vsebina='".$VImeKrozka."',";
                $SQL=$SQL."kraj='".$VKraj."',izvajalec='".$VIzvajalec."',";
                $SQL=$SQL."ravnatelj='".$VMentor."',";
                $SQL=$SQL."ozadje='".$VOzadje."',";
                $SQL=$SQL."wsola=".$WSola.",";
                $SQL=$SQL."wnaslov=".$WNaslov.",";
                $SQL=$SQL."wpriznanje=".$WPriznanje.",";
                $SQL=$SQL."wvrstica1=".$WVrstica1.",";
                $SQL=$SQL."wvrstica2=".$WVrstica2.",";
                $SQL=$SQL."wdejavnost=".$WDejavnost.",";
                $SQL=$SQL."wkrajdat=".$WKrajDat.",";
                $SQL=$SQL."wnazivizv=".$WNazivIzv.",";
                $SQL=$SQL."wizvajalec=".$WIzvajalec.",";
                $SQL=$SQL."wime=".$WIme.",";
                $SQL=$SQL."wrazred=".$WRazred.",";
                $SQL=$SQL."wdatroj=".$WDatRoj;
                
                $SQL=$SQL." WHERE priznanje='".$VFile."'";
            }else{
                $SQL="INSERT INTO tabdiploma (priznanje,PozXSola,PozYSola,PozXNaslov,PozYNaslov,PozXRavnatelj,PozYRavnatelj, PozXKraj,PozYKraj,";
                $SQL=$SQL."PozXIzvajalec,PozYIzvajalec,PozXPriznanje,PozYPriznanje,PozXLine1,PozYLine1,PozXLine2,PozYLine2,PozXVsebina,PozYVsebina,";
                $SQL=$SQL."PozXDatum,PozYDatum,PozXLogo,PozYLogo,PozX1Crta1,PozY1Crta1,PozX2Crta1,PozY2Crta1,";
                $SQL=$SQL."PozX1Crta2,PozY1Crta2,PozX2Crta2,PozY2Crta2,";
                $SQL=$SQL."PozX1Crta3,PozY1Crta3,PozX2Crta3,PozY2Crta3,";
                $SQL=$SQL."PozXIme,PozYIme,";
                $SQL=$SQL."LogoSize,PorSola,PorRavnatelj,PorPriznanje,PorLine1,PorLine2,PorVsebina,PorDatum,PorIme,PorNaslov,PorKraj,PorIzvajalec,";
                $SQL=$SQL."FSSola,FSRavnatelj,FSPriznanje,FSLine1,FSLine2,FSVsebina,FSDatum,FSIme,FSNaslov,FSKraj,FSIzvajalec,Font,";
                $SQL=$SQL."sola,naslov,diploma,line1,line2,vsebina,kraj,izvajalec,ravnatelj,ozadje,PozXRazred,PozYRazred,PorRazred,FSRazred,";
                $SQL .= "wsola,wnaslov,wpriznanje,wvrstica1,wvrstica2,wdejavnost,wkrajdat,wnazivizv,wizvajalec,wime,wrazred,wdatroj";
                $SQL=$SQL.") VALUES ('".$VFile."',".$PozXSola.",".$PozYSola.",".$PozXNaslov.",".$PozYNaslov.",".$PozXRavnatelj.",".$PozYRavnatelj.",".$PozXKraj.",".$PozYKraj.",";
                $SQL=$SQL.$PozXIzvajalec.",".$PozYIzvajalec.",".$PozXPriznanje.",".$PozYPriznanje.",".$PozXLine1.",".$PozYLine1.",".$PozXLine2.",".$PozYLine2.",".$PozXVsebina.",".$PozYVsebina.",";
                $SQL=$SQL.$PozXDatum.",".$PozYDatum.",".$PozXLogo.",".$PozYLogo.",".$PozX1Crta1.",".$PozY1Crta1.",".$PozX2Crta1.",".$PozY2Crta1.",";
                $SQL=$SQL.$PozX1Crta2.",".$PozY1Crta2.",".$PozX2Crta2.",".$PozY2Crta2.",";
                $SQL=$SQL.$PozX1Crta3.",".$PozY1Crta3.",".$PozX2Crta3.",".$PozY2Crta3.",";
                $SQL=$SQL.$PozXIme.",".$PozYIme.",";
                $SQL=$SQL.$LogoSize.",".$PorSola.",".$PorRavnatelj.",".$PorPriznanje.",".$PorLine1.",".$PorLine2.",".$PorVsebina.",".$PorDatum.",".$PorIme.",".$PorNaslov.",".$PorKraj.",".$PorIzvajalec.",";
                $SQL=$SQL.$FSSola.",".$FSRavnatelj.",".$FSPriznanje.",".$FSLine1.",".$FSLine2.",".$FSVsebina.",".$FSDatum.",".$FSIme.",".$FSNaslov.",".$FSKraj.",".$FSIzvajalec.",'".$VFont."',";
                $SQL=$SQL."'".$VSola."','".$VNaslov."','".$VPriznanje."','".$VLine1."','".$VLine2."','".$VImeKrozka."','".$VKraj."','".$VIzvajalec."','".$VMentor."','".$VOzadje."',".$PozXRazred.",".$PozYRazred.",".$PorRazred.",".$FSRazred.",";
                $SQL .= $WSola.",".$WNaslov.",".$WPriznanje.",".$WVrstica1.",".$WVrstica2.",".$WDejavnost.",".$WKrajDat.",".$WNazivIzv.",".$WIzvajalec.",".$WIme.",".$WRazred.",".$WDatRoj;
                $SQL .= ")";
            }
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu v bazo!<br />$SQL <br />");
            }
            
            $pdf = new FPDF();

            //$pdf->AddFont('EAN_b','','EAN_b.php');
            $pdf->AddPage("P","A4");
            $pdf->AddFont('castelar','','castelar.php');

            if ($VFont=="Arial"){
                $pdf->AddFont('arial_CE','','arial_CE.php');
                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                $VFontSet="arial";
            }else{
                $pdf->AddFont('timesbd_CE','','timesbd_CE.php');
                $pdf->AddFont('times_CE','','times_CE.php');
                $VFontSet="times";
            }
            if (strlen($VTekmovalci) == 0 ){
                $VTekmovalci="0";
            }
            
            $SQL = "SELECT tabucenci.*,tabrazdat.* FROM ";
            $SQL = $SQL . "(tabucenci INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabucenci.iducenec IN (".$VTekmovalci.") AND tabrazdat.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $ucenci[$Indx][1]=$R["Ime"]." ".$R["Priimek"];
                $ucenci[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                $ucenci[$Indx][3]=$R["DatRoj"];
                $ucenci[$Indx][4]=$R["Spol"];
                $Indx=$Indx+1;
            }
            $StUcencev=$Indx-1;

            for ($IndxUcenec=1;$IndxUcenec <= $StUcencev;$IndxUcenec++){
                if ($IndxUcenec > 1){
                    $pdf->AddPage("P","A4");
                }
                //slika ozadja
                if (strpos($VOzadje,".jpg") > 0){
                    $ozadje="img/".$VOzadje;
                    $pdf->Image($ozadje,5,5,200);
                }
                //logotip
                $Indx1=0;
                if ($PozXLogo > 0 ){
                    $pdf->Image("img/logo1.gif",$PozXLogo, $PozYLogo,$LogoSize);
                }

                $pdf->SetTextColor(0,0,0); //črna
                $pdf->SetLineWidth(0.2);
                                
                if ($PozX1Crta1 > 0 ){
                    $pdf->Line($PozX1Crta1, $PozY1Crta1, $PozX2Crta1, $PozY2Crta1);
                }
                if ($PozX1Crta2 > 0 ){
                    $pdf->Line($PozX1Crta2, $PozY1Crta2, $PozX2Crta2, $PozY2Crta2);
                }
                if ($PozX1Crta3 > 0 ){
                    $pdf->Line($PozX1Crta3, $PozY1Crta3, $PozX2Crta3, $PozY2Crta3);
                }
                                
                if ($PozXSola > 0 ){ 
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSSola);
                    $txt=ToWin($VSola);
                    $pdf->SetXY($PozXSola, $PozYSola);
                    $pdf->Cell(0,0,$txt,$WSola,2,ToPoravnava($PorSola));
                }
                if ($PozXNaslov > 0 ){
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSNaslov);
                    $txt=ToWin($VNaslov);
                    $pdf->SetXY($PozXNaslov, $PozYNaslov);
                    $pdf->Cell(0,0,$txt,$WNaslov,2,ToPoravnava($PorNaslov));
                }
                if ($PozXPriznanje > 0 ){
                    $pdf->SetTextColor(0,0,255); //modra
                    $pdf->SetFont('castelar','',$FSPriznanje);
                    $txt=ToWin($VPriznanje);
                    $pdf->SetXY($PozXPriznanje, $PozYPriznanje);
                    $pdf->Cell(0,0,$txt,$WPriznanje,2,ToPoravnava($PorPriznanje));
                }
                $pdf->SetTextColor(0,0,0); //črna
                if ($PozXLine1 > 0 ){
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSLine1);
                    $txt=ToWin($VLine1);
                    $pdf->SetXY($PozXLine1, $PozYLine1);
                    $pdf->Cell(0,0,$txt,$WVrstica1,2,ToPoravnava($PorLine1));
                }
                if ($PozXLine2 > 0 ){
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSLine2);
                    $txt=ToWin($VLine2);
                    $pdf->SetXY($PozXLine2, $PozYLine2);
                    $pdf->Cell(0,0,$txt,0,2,ToPoravnava($PorLine2));
                }
                if ($PozXVsebina > 0 ){
                    $pdf->SetTextColor(255,0,0); //rdeča
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSVsebina);
                    $txt=ToWin($VImeKrozka);
                    $pdf->SetXY($PozXVsebina, $PozYVsebina);
                    $pdf->Cell(0,0,$txt,$WVrstica2,2,ToPoravnava($PorVsebina));
                }
                $pdf->SetTextColor(0,0,0); //črna
                if ($PozXIme > 0 ){
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSIme);
                    $txt=ToWin($ucenci[$IndxUcenec][1]);
                    $pdf->SetXY($PozXIme, $PozYIme);
                    $pdf->Cell(0,0,$txt,$WIme,2,ToPoravnava($PorIme));
                }
                $pdf->SetTextColor(0,0,0); //črna
                if ($PozXRazred > 0 ){
                    $pdf->SetFont($VFontSet.'bd_CE','',$FSRazred);
                    $txt=ToWin($ucenci[$IndxUcenec][2]);
                    $pdf->SetXY($PozXRazred, $PozYRazred);
                    $pdf->Cell(0,0,$txt,$WRazred,2,ToPoravnava($PorRazred));
                }
                    
                    
                if ($VTekmovalci != "0" ){
                    if ($PozXDatum > 0 ){
                        $pdf->SetFont($VFontSet.'_CE','',$FSDatum);
                        $Datum=new DateTime(isDate($ucenci[$IndxUcenec][3]));
                        if ($ucenci[$IndxUcenec][4]=="M" ){
                            $txt=ToWin("rojen ".$Datum->format('j. n. Y'));
                        }else{
                            $txt=ToWin("rojena ".$Datum->format('j. n. Y'));
                        }
                        $pdf->SetXY($PozXDatum, $PozYDatum);
                        $pdf->Cell(0,0,$txt,$WDatRoj,2,ToPoravnava($PorDatum));
                    }
                }
                if ($PozXIzvajalec > 0 ){
                    $pdf->SetFont($VFontSet.'_CE','',$FSIzvajalec);
                    $txt=ToWin($VIzvajalec);
                    $pdf->SetXY($PozXIzvajalec, $PozYIzvajalec);
                    $pdf->Cell(0,0,$txt,$WNazivIzv,2,ToPoravnava($PorIzvajalec));
                }
                if ($PozXRavnatelj > 0 ){
                    $pdf->SetFont($VFontSet.'_CE','',$FSRavnatelj);
                    $txt=ToWin($VMentor);
                    $pdf->SetXY($PozXRavnatelj, $PozYRavnatelj);
                    $pdf->Cell(0,0,$txt,$WIzvajalec,2,ToPoravnava($PorRavnatelj));
                }
                if ($PozXKraj > 0 ){
                    $pdf->SetFont($VFontSet.'_CE','',$FSKraj);
                    $txt=ToWin($VKraj);
                    $pdf->SetXY($PozXKraj, $PozYKraj);
                    $pdf->Cell(0,0,$txt,$WKrajDat,2,ToPoravnava($PorKraj));
                }
            }    
            $pdf->Output("priznanja.pdf","D");
        }
        break;
}
?>
