<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Učenec
</title>
<?php
echo "<style type='text/css'>";
echo ".break { page-break-before: always; }";
echo "input.groovybutton";
echo "{";
echo "   font-size:8px;";
echo "   font-weight:bold;";
echo "   width:18px;";
echo "}";
echo "</style>";
?>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function Arr2Str($a){
    $s="";
    for ($i=0;$i < count($a);$i++){
        if (strlen($s) == 0){
            $s=$a[$i];
        }else{
            $s=$s.",".$a[$i];
        }
    }
    return $s;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

	if (isset($_POST["id"])){
		$Vid = $_POST["id"];
	}else{
		if (isset($_GET["id"])){
			$Vid=$_GET["id"];
		}else{
			$Vid = 0;
		}
	}

	switch ($Vid){
		case "3":
			break;
		default:
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
	}
	switch ($Vid){
		case "1": //dodajanje učencev in podatkov o razrednikih in drugih učiteljih
			if (isset($_POST["razred"])){
				$VRazred = $_POST["razred"];
			}else{
				if (isset($_GET["razred"])){
					$VRazred=$_GET["razred"];
				}else{
					$VRazred = 0;
				}
			}
			if ($VRazred==0){
				$VDevetletka = $_SESSION["devetletka"];
				$VRazred = $_SESSION["razred"];
				$VParalelka = $_SESSION["paralelka"];
				$IdUcitelj = $_SESSION["ucitelj"];
				$IdVzgojitelj = $_SESSION["vzgojitelj"];
			}

			$SQL = "SELECT * FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id WHERE tabrazdat.id=".$VRazred;
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$VRazred1=$R["razred"];
				$VParalelka=$R["oznaka"];
				$VDevetletka=$R["osemdevet"];
                $VIdSola=$R["idsola"];
				if (isset($R["IdUcitelj"])){
					$IdUcitelj=$R["IdUcitelj"];
				}else{
					$IdUcitelj=0;
				}
				if (isset($R["IdVzgojitelj"])){
					$IdVzgojitelj=$R["IdVzgojitelj"];
				}else{
					$IdVzgojitelj=0;
				}
			}else{
				$SQL= "SELECT * FROM tabrazdat WHERE tabrazdat.id=".$VRazred;
				$result = mysqli_query($link,$SQL);
				if ($R = mysqli_fetch_array($result)){
					$VRazred1=$R["razred"];
					$VParalelka=$R["oznaka"];
					$VDevetletka=9;
					$IdUcitelj=0;
					$IdVzgojitelj=0;
                    $VIdSola=$R["idsola"];
				}else{
					$VRazred1=0;
					$VParalelka='a';
					$VDevetletka=9;
					$IdUcitelj=0;
					$IdVzgojitelj=0;
                    $VIdSola=1;
				}
			}

            echo "<br />";
            if ($VecSol > 0){
                $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . " - ".$R["solakratko"]."<br />";
                }else{
                    echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
                }
            }else{
                echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
            }

			echo "<table border='0'>";
			echo "<tr><td width='400'>";
			echo "<form  name='ucencirazred' method='post' action='izpisrazreda.php'>";
			//Dim  Ucitelji(200,2)
			echo "Učitelj: <select  name='ucitelji'>";
			echo "<option value=0>Ni izbire</option>";
			$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY Priimek, Ime";
			$result = mysqli_query($link,$SQL);

			while ($R = mysqli_fetch_array($result)){
				if ($R["iducitelj"]==$IdUcitelj ){
					echo "<option value=". $R["iducitelj"]." selected='selected'>". $R["priimek"]." ".$R["ime"] ."</option>";
				}else{
					echo "<option value=". $R["iducitelj"].">". $R["priimek"]." ".$R["ime"] ."</option>";
				}
			}
			echo "</select><br /><br />";

			if ($VRazred1 < 6 ){
                if ($VRazred1 > 1){
                    echo "Učitelj PB: ";
                }else{
                    echo "Drugi učitelj: ";
                }
				echo "<select  name='vzgojitelji'>";
				$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji ORDER BY Priimek, Ime";
				$result = mysqli_query($link,$SQL);
				echo "<option value=0>Ni izbire</option>";
				while ($R = mysqli_fetch_array($result)){
					if ($R["iducitelj"]==$IdVzgojitelj ){
						echo "<option value=". $R["iducitelj"]." selected='selected'>". $R["priimek"]." ".$R["ime"] ."</option>";
					}else{
						echo "<option value=". $R["iducitelj"].">". $R["priimek"]." ".$R["ime"] ."</option>";
					}
				}
				echo "</select><br /><br />";
			}else{
				echo "<input name='vzgojitelji' type='hidden' value=''>";
			}

			$SQL = "SELECT tabrazred.iducenec FROM ";
			$SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . "WHERE idRazred=".$VRazred;
			$result = mysqli_query($link,$SQL);
			$Indx=0;
			while ($R = mysqli_fetch_array($result)){
				$StariUcenci[$Indx]=$R["iducenec"];
				$Indx=$Indx+1;
			}
			$StStarih= $Indx-1;

			echo "<select  name='ucenec[]' multiple size='30'>";

			//$SQL = "SELECT iducenec,priimek,ime,datroj FROM tabucenci  WHERE year(datroj) > ". ($VLeto-20) ." AND Aktivnost < 4 ORDER BY priimek, ime";
            $SQL = "SELECT iducenec,priimek,ime,datroj FROM tabucenci  WHERE Aktivnost < 4 ORDER BY priimek, ime";
			$result = mysqli_query($link,$SQL);
			$Indx =1;
			while ($R = mysqli_fetch_array($result)){
				$Ucenci[$Indx][1]=$R["iducenec"];
				$Ucenci[$Indx][2]=$R["priimek"].", ".$R["ime"];
				$Ucenci[$Indx][3]=new DateTime(isDate($R["datroj"]));
				$UcenecObstaja=false;
				for ($Indx2=1;$Indx2 <= $StStarih;$Indx2++){
					if ($Ucenci[$Indx][1]==$StariUcenci[$Indx2] ){
						$UcenecObstaja=true;
					}
				}
				if ($UcenecObstaja ){
					echo "<option value=". $Ucenci[$Indx][1]." selected='selected'>".$Ucenci[$Indx][2].", ".$Ucenci[$Indx][3]->format('d.m.Y')."</option>";
				}else{
					echo "<option value=". $Ucenci[$Indx][1].">".$Ucenci[$Indx][2].", ".$Ucenci[$Indx][3]->format('d.m.Y')."</option>";
				}
				$Indx=$Indx+1;
			}
			echo "</select><br /><br />";
			echo "<input name='razred' type='hidden' value='".$VRazred."'>";
			echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
			echo "<input name='id' type='hidden' value='2'>";
			echo "<input name='submit' type='submit' value='Pošlji'>";

			echo "</form>";
			echo "</td><td width='400' valign='top'><h2>Spisek učencev</h2>";
				echo "<table border='1'>";
				echo "<tr><th>N</th><th>Mat. list</th><th>Priimek in ime</th><th>Datum rojstva</th></tr>";

				$SQL = "SELECT tabrazred.*,tabrazred.id AS rid, tabucitelji.priimek as upriimek, tabucitelji.ime as uime, tabucitelji.spol as uspol,tabvzgojitelji.priimek as vpriimek, tabvzgojitelji.ime as vime, tabvzgojitelji.spol AS vspol,tabucenci.iducenec AS uid,tabrazdat.*,tabrazdat.leto AS rleto FROM ";
				$SQL = $SQL . "(((tabvzgojitelji ";
				$SQL = $SQL . "INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
				$SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
				$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
				$SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred;
				$SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
				$Indx=1;
				$result = mysqli_query($link,$SQL);
				while ($R = mysqli_fetch_array($result)){
					$oUcenec=new RUcenec();
					$oUcenec->getUcenec($R["uid"]);
					echo "<tr><td>" . $Indx ."</td>";
					echo "<td>" . $oUcenec->getMaticniList() . "</td>";
					echo "<td><a href='ucenec_pregled.php?ucenec=".$oUcenec->getIdUcenec() ."'>" . $oUcenec->getPriimek() . ", " . $oUcenec->getIme() . "</a></td>";
					echo "<td align='right'>" . $oUcenec->getDatRoj() . "</td>";
					$Indx=$Indx+1;
				}
			   
				echo "</table>";
			echo "</td></tr>";
			echo "</table><br />";
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
		
			break;
		case "2": //vpis učencev v razred
			/*
			$VDevetletka = $_SESSION["devetletka"];
			$VParalelka = $_SESSION["paralelka"];
			*/
			$VRazred = $_POST["razred"];
			$IdUcitelj = $_POST["ucitelji"];
			$IdVzgojitelj = $_POST["vzgojitelji"];
			$NoviUcenci=Arr2Str($_POST["ucenec"]);

			echo "<h2>Popravljeni podatki za razred</h2>";

			$SQL = "SELECT * FROM tabucitelji WHERE IdUcitelj=". $IdUcitelj;
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$VUcitelj=$R["Priimek"].", ".$R["Ime"];
			}else{
				$VUcitelj="";
			}

			$SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$VRazred1=$R["razred"];
				$VParalelka=$R["oznaka"];
				$VDevetletka=$R["osemdevet"];
			}

			if ($VRazred1 < 6) {
				$SQL = "SELECT * FROM tabvzgojitelji WHERE IdUcitelj=".$IdVzgojitelj;
				$result = mysqli_query($link,$SQL);
				if ($R = mysqli_fetch_array($result)){
					$VVzgojitelj=$R["Priimek"].", ".$R["Ime"];
				}else{
					$VVzgojitelj="";
				}
			}else{
				$IdVzgojitelj=0;
				$VVzgojitelj="";
			}

			$SQL = "SELECT tabrazred.iducenec,tabrazred.iducitelj,tabrazred.idvzgojitelj,tabrazdat.idsola FROM ";
			$SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . "WHERE idRazred=".$VRazred;
			$result = mysqli_query($link,$SQL);
			$Indx=0;
			while ($R = mysqli_fetch_array($result)){
				$StariUcenci[$Indx]=$R["iducenec"];
				$IdUcStari=$R["iducitelj"];
				$IdVzgStari=$R["idvzgojitelj"];
                $VIdSola=$R["idsola"];
				$Indx=$Indx+1;
			}
			$StStarih= $Indx-1;

            if ($VecSol > 0){
                $SQL = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . " - ".$R["solakratko"]."<br />";
                }else{
                    echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
                }
            }else{
                echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $VRazred1 . ". " . $VParalelka . "<br />";
            }

			echo "Učitelj: " . $VUcitelj . "<br />";
            if ($VRazred1 > 1){
			    echo "Učitelj PB: " . $VVzgojitelj . "<br /><br />";
            }else{
                echo "Drugi učitelj: " . $VVzgojitelj . "<br /><br />";
            }

			if (strlen($NoviUcenci) > 0){
				$SQL = "SELECT * FROM tabucenci  WHERE IdUcenec IN (" . $NoviUcenci . ") ORDER BY Priimek, Ime";
				$result = mysqli_query($link,$SQL);
				$Indx =1;
				$Indx3=0;
				while ($R = mysqli_fetch_array($result)){
					$Ucenci[$Indx][1]=$R["IdUcenec"];
					$Ucenci[$Indx][2]=$R["Priimek"].", ".$R["Ime"];
					$Ucenci[$Indx][3]=$R["DatRoj"];
					$UcenecObstaja=false;
					for ($Indx2=1;$Indx2 <= $StStarih;$Indx2++){
						if ($Ucenci[$Indx][1]==$StariUcenci[$Indx2]){
							$UcenecObstaja=true;
						}
					}
					
					if (!$UcenecObstaja ){
					  $Novinci[$Indx3]=$Ucenci[$Indx][1];
					  $Indx3=$Indx3+1;
					}
					$Indx=$Indx+1;
				}
				//dejansko stevilo novih
				$Indx3=$Indx3-1;
			}else{
				$Indx3=-1;
			}

			//Zamenja ucitelja in vzgojitelja, če sta spremenjena - začetek
			$SQL="UPDATE  tabrazred SET IdUcitelj=". $IdUcitelj ." WHERE idRazred=".$VRazred;
			if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri popravljanju razrednika!<br />$SQL <br />");
            }
			
			$SQL="UPDATE  tabrazred SET IdVzgojitelj=". $IdVzgojitelj ." WHERE idRazred=".$VRazred;
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri popravljanju vzgojitelja!<br />$SQL <br />");
            }
			//Zamenja ucitelja in vzgojitelja, če sta spremenjena - konec

			//Preveri, ce so slucajno ze v kaksnem razredu
			for ($Indx=0;$Indx <= $Indx3;$Indx++){
				$SQL = "SELECT tabrazred.*,tabrazdat.* FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id WHERE tabrazdat.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND IdUcenec=".$Novinci[$Indx];
				$result = mysqli_query($link,$SQL);
				$Indx2=0;
				if ($R = mysqli_fetch_array($result)){
					$SQL="UPDATE  tabrazred SET Razred=". $VRazred1 .", paralelka='". $VParalelka ."', osemdevet=9, IdUcitelj=". $IdUcitelj .", IdVzgojitelj=". $IdVzgojitelj .", idRazred=".$VRazred.", slika='slike/".$VLeto."_".$Novinci[$Indx].".jpg' WHERE tabrazred.id=".$R["Id"]." AND IdUcenec=". $Novinci[$Indx];
					echo "Popravljen je bil zapis za učenca z ID številko " . $Novinci[$Indx] . "<br />";
				}else{
					$SQL = "INSERT  INTO tabrazred (leto,razred,paralelka,osemdevet,IdUcenec,IdUcitelj,IdVzgojitelj,LetoSolanja,Ponavljalec,Uspeh,idRazred,slika,";
                    $SQL .= "uspehpol,napredovanje,razredniizpit,nadarjen,statussport,statuskult,vpisal,datumvpisa,evidst,datumizdaje,opomba) VALUES (";
                    $SQL .= $VLeto .",". $VRazred1 .",'". $VParalelka ."',9,". $Novinci[$Indx] .",". $IdUcitelj .",". $IdVzgojitelj .",". $VRazred1 .",0,0,".$VRazred.",'slike/".$VLeto."_".$Novinci[$Indx].".jpg',";
                    $SQL .= "0,0,0,";
                    
                    $SQL1 = "SELECT nadarjen FROM tabrazred WHERE leto=".($VLeto-1)." AND iducenec=".$Novinci[$Indx];
                    $result1 = mysqli_query($link,$SQL1);
                    if ($R1 = mysqli_fetch_array($result1)){
                        if (isset($R["nadarjen"])){
                            $SQL .= $R["nadarjen"].",";
                        }else{
                            $SQL .= "0,";
                        }
                    }else{
                        $SQL .= "0,";
                    }
                    $SQL .= "0,0,'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."','','',''";
                    $SQL .= ")";
					echo "Dodan je bil zapis za učenca z ID številko " . $Novinci[$Indx] . "<br />";
					echo "Preverite število let šolanja!<br /><br />";
				}
				if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri dodajanju učencev v razred!<br />$SQL<br />");
                }
			}

			echo "<br />Popravljen spisek učencev je naslednji:<br />";

			$SQL = "SELECT tabrazred.*, tabucitelji.priimek AS upriimek, tabucitelji.ime AS uime, tabvzgojitelji.priimek AS vpriimek, tabvzgojitelji.ime AS vime, tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.DatRoj,tabrazdat.* FROM ";
			$SQL = $SQL . "((TabVzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON TabVzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
			$SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
			$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred ;
			$SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
			$result = mysqli_query($link,$SQL);
			echo "<table border=1><th>Št</th><th>ID učenec</th><th>Priimek in ime</th><th>Datum rojstva</th>";

			$Indx=1;
			while ($R = mysqli_fetch_array($result)){
				$Datum=new DateTime(isDate($R["DatRoj"]));
				echo "<tr><td>" . $Indx ."</td><td>" . $R["IdUcenec"] . "</td><td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"] ."'>" . $R["ucpriimek"] . ", " . $R["ucime"] . "</a></td><td>" . $Datum->format('d.m.Y') . "</td></tr>";
				$Indx=$Indx+1;
			}

			echo "</table>";
			echo "<a href='izborrazreda.php'>Izbor razreda</a><br />";
			echo "<a href='izpisrazreda.php?razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis razreda</a><br />";
		
			break;

		case "3": //odstranjevanje učenca iz razreda
			$SQL = "DELETE FROM TabRazred WHERE id=".$_GET["brisi"];
			$result = mysqli_query($link,$SQL);
			header("Location: izpisrazreda.php?razred=".$_GET["razred"]."&solskoleto=".$VLeto);
			break;
		case "4": //Kontakti s starši
			if (isset($_POST["razred"])){
				$VRazred = $_POST["razred"];
			}else{
				if (isset($_GET["razred"])){
					$VRazred=$_GET["razred"];
				}else{
					$VRazred = 0;
				}
			}

			$SQL = "SELECT tabrazred.*,tabrazdat.*,tabucenci.* FROM ";
			$SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
			$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . " WHERE idRazred=".$VRazred;
			$SQL = $SQL ." ORDER BY priimek,ime";
			$result = mysqli_query($link,$SQL);

			if ($R = mysqli_fetch_array($result)){
				$VRazred1=$R["razred"];
				$VParalelka=$R["oznaka"];
			}

			echo "<h2>Pošiljanje elektronskih sporočil staršem in skrbnikom - ".$VRazred1.". ".$VParalelka."</h2>";
			echo "<form name='sporocila' method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
			echo "<table border=1>";
			echo "<tr><th>Št.</th><th>Ime</th><th>Oče</th><th>Mati</th><th>Skrbnik</th></tr>";
            echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></td><td><input class='groovybutton' name='b2' type='button' value='' onClick='OznaciStolpec(this.form,2)'></td><td><input class='groovybutton' name='b3' type='button' value='' onClick='OznaciStolpec(this.form,3)'></td></tr>";

			$Indx=1;
			$i1=1;
			$result = mysqli_query($link,$SQL);
			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				echo "<td>".$Indx."</td>";
				echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
				echo "<td>";
				if (is_numeric(strpos($R["oceemail"],"@")) ){
					echo "<input name='uc_".$i1."' type='hidden' value='".$R["oceemail"]."'><input id='dan_1' name='em_".$i1."' type='checkbox'>";
					echo "<a href='mailto:".$R["oceemail"]."'>".$R["oceemail"]."</a>";
					$i1=$i1+1;
				}
				echo "</td>";
				echo "<td>";
				if (is_numeric(strpos($R["matiemail"],"@"))){
					echo "<input name='uc_".$i1."' type='hidden' value='".$R["matiemail"]."'><input id='dan_2' name='em_".$i1."' type='checkbox'>";
					echo "<a href='mailto:".$R["matiemail"]."'>".$R["matiemail"]."</a>";
					$i1=$i1+1;
				}
				echo "</td>";
				echo "<td>";
				if (is_numeric(strpos($R["SkrbnikiEmail"],"@"))){
					echo "<input name='uc_".$i1."' type='hidden' value='".$R["SkrbnikiEmail"]."'><input id='dan_3' name='em_".$i1."' type='checkbox'>";
					echo "<a href='mailto:".$R["SkrbnikiEmail"]."'>".$R["SkrbnikiEmail"]."</a>";
					$i1=$i1+1;
				}
				echo "</td>";
				echo "</tr>";
				$Indx=$Indx+1;
			}
			echo "</table><br />";
			echo "<input name='Stevilo' type='hidden' value='".($i1-1)."'>";
			echo "<input name='id' type='hidden' value='3'>";
			echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
			echo "<b>Sporočilo:</b><br /><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
			echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
			echo "<input name='Povezava' type='hidden' value='/'>";
			echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
			echo "<input name='submit' type='submit' value='Pošlji e-mail'>";
			echo "</form>";
            if ($VLevel > 2){
                echo "<a href='izpisrazreda.php?id=4a&solskoleto=".$VLeto."'>Pošiljanje e-mailov vsem staršem</a><br />";
            }
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
			break;
        case "4a": //Kontakti s starši
            echo "<form method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
            $i1=1;
            $Indx=1;
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th>Oče e-mail</th><th>Učenci</th></tr>";
            
            $SQL = "SELECT DISTINCT tabucenci.oceemail FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0";
            $SQL = $SQL ." ORDER BY razred,paralelka,priimek,ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["oceemail"]) && (strpos($R["oceemail"],"@") > 0)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["oceemail"],"@")) ){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["oceemail"]."'><input name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["oceemail"]."'>".$R["oceemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    $ucenci="";
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE oceemail='".$R["oceemail"]."' AND tabrazred.leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($ucenci) > 0){
                            $ucenci=$ucenci.", ".$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }else{
                            $ucenci=$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }
                    }
                    echo $ucenci."</td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
            }
            
            echo "<tr><th>Št.</th><th>Mati e-mail</th><th>Učenci</th></tr>";
            
            $SQL = "SELECT DISTINCT tabucenci.matiemail FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0";
            $SQL = $SQL ." ORDER BY razred,paralelka,priimek,ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["matiemail"]) && (strpos($R["matiemail"],"@") > 0)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["matiemail"],"@")) ){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["matiemail"]."'><input name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["matiemail"]."'>".$R["matiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    $ucenci="";
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE matiemail='".$R["matiemail"]."' AND tabrazred.leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($ucenci) > 0){
                            $ucenci=$ucenci.", ".$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }else{
                            $ucenci=$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }
                    }
                    echo $ucenci."</td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
            }

            echo "<tr><th>Št.</th><th>Skrbniki e-mail</th><th>Učenci</th></tr>";
            
            $SQL = "SELECT DISTINCT tabucenci.skrbnikiemail FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0";
            $SQL = $SQL ." ORDER BY razred,paralelka,priimek,ime";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["skrbnikiemail"]) && (strpos($R["skrbnikiemail"],"@") > 0)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["skrbnikiemail"],"@")) ){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["skrbnikiemail"]."'><input name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["skrbnikiemail"]."'>".$R["skrbnikiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    $ucenci="";
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE skrbnikiemail='".$R["skrbnikiemail"]."' AND tabrazred.leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($ucenci) > 0){
                            $ucenci=$ucenci.", ".$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }else{
                            $ucenci=$R1["priimek"]." ".$R1["ime"]." ".$R1["razred"].$R1["paralelka"];
                        }
                    }
                    echo $ucenci."</td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
            }
            echo "</table><br />";
            echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
            echo "<input name='Stevilo' type='hidden' value='".($i1-1)."'>";
            echo "<input name='id' type='hidden' value='3'>";
            echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
            echo "<b>Sporočilo:</b><br /><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
            echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
            echo "<input name='Povezava' type='hidden' value='/'>";
            echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
            echo "<input name='submit' type='submit' value='Pošlji e-mail'>";
            echo "</form>";
            break;
		case "5": //Svet staršev
			if (isset($_POST["razred"])){
				$VRazred = $_POST["razred"];
			}else{
				if (isset($_GET["razred"])){
					$VRazred=$_GET["razred"];
				}else{
					$VRazred = 0;
				}
			}

            $VDevetletka=9;
            if ($VRazred=="" ){
                $VDevetletka = $_SESSION["devetletka"];
                $VRazred = $_SESSION["razred"];
                $VParalelka = $_SESSION["paralelka"];
                $IdUcitelj = $_SESSION["ucitelj"];
                $IdVzgojitelj = $_SESSION["vzgojitelj"];
            }
            $_SESSION["razred"]=$VRazred;

            echo "<form name='rezultati1' method='post' action='izpisrazreda.php'>";
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "<input name='vrstaos' type='hidden' value='9'>";
            if ($VLevel < 2){
                $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
                $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
            }else{
                $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
                $SQL .= " ORDER BY idsola,razred,oznaka";
            }
            $result = mysqli_query($link,$SQL);

            echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
            echo "<option value='0'>Ni izbran</option>";
            $Indx=1;
            if ($VecSol > 0){
                while ($R = mysqli_fetch_array($result)){
                    if ($VRazred==$R["id"] ){
                        echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
            }else{
                while ($R = mysqli_fetch_array($result)){
                    if ($VRazred==$R["id"] ){
                        echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='5'>";
            //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
            //echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            
			$SQL = "SELECT tabrazred.*,tabrazdat.*,tabucenci.* FROM ";
			$SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
			$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . " WHERE idRazred=".$VRazred;
			$SQL = $SQL ." ORDER BY priimek,ime";
			$result = mysqli_query($link,$SQL);

			if ($R = mysqli_fetch_array($result)){
				$VRazred1=$R["razred"];
				$VParalelka=$R["oznaka"];
			}

			echo "<h2>Predstavnik v svetu staršev - ".$VRazred1.". ".$VParalelka."</h2>";

			if (isset($_POST["id1"])){
				$Vid1=$_POST["id1"];
			}else{
				$Vid1="0";
			}
			switch ($Vid1){
				case "1":
					for ($Indx=1;$Indx <= $_POST["stevilo"];$Indx++){
						//'izbriše star zapis
						$SQL = "DELETE FROM TabSvetStarsev WHERE leto=".$VLeto." AND idUcenec=".$_POST["uc_".$Indx];
						$result = mysqli_query($link,$SQL);
						
						if (strlen($_POST["svst_1_".$Indx]) > 0){
							//'v svetu staršev je oče
							$SQL = "INSERT INTO TabSvetStarsev (leto,idUcenec,svet,status) VALUES (".$VLeto.",".$_POST["uc_".$Indx].",1,".$_POST["svst_1_".$Indx].")";
							$result = mysqli_query($link,$SQL);
						}else{
							if (strlen($_POST["svst_2_".$Indx]) > 0){
								//'v svetu staršev je mati
								$SQL = "INSERT INTO TabSvetStarsev (leto,idUcenec,svet,status) VALUES (".$VLeto.",".$_POST["uc_".$Indx].",2,".$_POST["svst_2_".$Indx].")";
								$result = mysqli_query($link,$SQL);
                            /*    
							}else{
								if (strlen($_POST["svst_3_".$Indx]) > 0){
									//'v svetu staršev je skrbnik
									$SQL = "INSERT INTO TabSvetStarsev (leto,idUcenec,svet,status) VALUES (".$VLeto.",".$_POST["uc_".$Indx].",3,".$_POST["svst_3_".$Indx].")";
									$result = mysqli_query($link,$SQL);
								}
                            */
							}
						}
					}
					echo "<h2>Predstavniki v svet staršev so vpisani!</h2>";
			}

			echo "<form name='svet' method='post' action='izpisrazreda.php'>";
			echo "Navodilo: v okence pred staršem, ki je predstavnik v Svetu staršev, vpišite 1, pri namestniku pa 2.<br />";
			echo "<table border=1>";
			echo "<tr><th>Št.</th><th>Ime</th><th>Oče</th><th>Mati</th></tr>";

			$SQL = "SELECT tabrazred.*,tabrazdat.*,tabucenci.*,tabucenci.iducenec AS uid FROM ";
			$SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
			$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
			$SQL = $SQL . " WHERE idRazred=".$VRazred;
			$SQL = $SQL ." ORDER BY priimek,ime";
			$result = mysqli_query($link,$SQL);

			$Indx=1;
			$i1=0;
			while ($R = mysqli_fetch_array($result)){
				$i1=$i1+1;
				echo "<tr>";
				echo "<td>".$Indx."</td>";
				echo "<td><input name='uc_".$i1."' type='hidden' value='".$R["uid"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
				echo "<td>";
				$SQL = "SELECT * FROM TabSvetStarsev WHERE leto=".$VLeto." AND idUcenec=".$R["uid"]." AND svet=1";;
				$result1 = mysqli_query($link,$SQL);
				if ($R1 = mysqli_fetch_array($result1)){
					if ($R1["status"]==1 ){
						echo "<input name='svst_1_".$i1."' type='text' value='1' size='1'>";
					}else{
						echo "<input name='svst_1_".$i1."' type='text' value='2' size='1'>";
					}
				}else{
					echo "<input name='svst_1_".$i1."' type='text' size='1'>";
				}
				echo $R["oce"];
				echo "</td>";
				echo "<td>";
				
				$SQL = "SELECT * FROM TabSvetStarsev WHERE leto=".$VLeto." AND idUcenec=".$R["uid"]." AND svet=2";
				$result1 = mysqli_query($link,$SQL);
				if ($R1 = mysqli_fetch_array($result1)){
					if ($R1["status"]==1 ){
						echo "<input name='svst_2_".$i1."' type='text' value='1' size='1'>";
					}else{
						echo "<input name='svst_2_".$i1."' type='text' value='2' size='1'>";
					}
				}else{
					echo "<input name='svst_2_".$i1."' type='text' size='1'>";
				}
				echo $R["mati"];
				echo "</td>";
                /*
				echo "<td>";
				$SQL = "SELECT * FROM TabSvetStarsev WHERE leto=".$VLeto." AND idUcenec=".$R["uid"]." AND svet=3";
				$result1 = mysqli_query($link,$SQL);
				if ($R1 = mysqli_fetch_array($result1)){
					if ($R1["status"]==1 ){
						echo "<input name='svst_3_".$i1."' type='text' value='1' size='1'>";
					}else{
						echo "<input name='svst_3_".$i1."' type='text' value='2' size='1'>";
					}
				}else{
					echo "<input name='svst_3_".$i1."' type='text' size='1'>";
				}
				echo $R["Skrbniki"];
				echo "</td>";
                */
				echo "</tr>";
				$Indx=$Indx+1;
			}
			echo "</table><br />";
			echo "<input name='stevilo' type='hidden' value='".$i1."'>";
			echo "<input name='id1' type='hidden' value='1'>";
			echo "<input name='id' type='hidden' value='5'>";
			echo "<input name='razred' type='hidden' value='".$VRazred."'>";
			echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
			echo "<input name='submit' type='submit' value='Pošlji'>";
			echo "</form><br />";
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
			break;
        case "6": //Dopisovanje s starši
            if (isset($_POST["razred"])){
                $VRazred = $_POST["razred"];
            }else{
                if (isset($_GET["razred"])){
                    $VRazred=$_GET["razred"];
                }else{
                    $VRazred = 0;
                }
            }

            $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka,";
            $SQL .= "tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.oceemail,tabucenci.matiemail,tabucenci.skrbnikiemail FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . " WHERE idRazred=".$VRazred;
            $SQL = $SQL ." ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
            }

            echo "<h2>Dopisovanje s starši - ".$VRazred1.". ".$VParalelka."</h2>";
            echo "<form name='sporocila' method='post' action='izpisrazreda.php'>";
            echo "<table border=1>";
            echo "<tr><th>Št.</th><th>Ime</th><th>Oče</th><th>Mati</th><th>Skrbnik</th><th>Pošlji<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></th><th>Ogled</th><th>Zadnji<br />kontakt</th></tr>";

            $Indx=1;
            $i1=1;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td>";
                if (is_numeric(strpos($R["oceemail"],"@")) ){
                    //echo "<input name='uc_".$i1."' type='hidden' value='".$R["oceemail"]."'><input name='em_".$i1."' type='checkbox'>";
                    echo "<a href='mailto:".$R["oceemail"]."'>".$R["oceemail"]."</a>";
                    $i1=$i1+1;
                }
                echo "</td>";
                echo "<td>";
                if (is_numeric(strpos($R["matiemail"],"@"))){
                    //echo "<input name='uc_".$i1."' type='hidden' value='".$R["matiemail"]."'><input name='em_".$i1."' type='checkbox'>";
                    echo "<a href='mailto:".$R["matiemail"]."'>".$R["matiemail"]."</a>";
                    $i1=$i1+1;
                }
                echo "</td>";
                echo "<td>";
                if (is_numeric(strpos($R["skrbnikiemail"],"@"))){
                    //echo "<input name='uc_".$i1."' type='hidden' value='".$R["skrbnikiemail"]."'><input name='em_".$i1."' type='checkbox'>";
                    echo "<a href='mailto:".$R["skrbnikiemail"]."'>".$R["skrbnikiemail"]."</a>";
                    $i1=$i1+1;
                }
                echo "</td>";
                echo "<td align='center'>";
                echo "<input id='dan_1' name='em_".$R["iducenec"]."' type='checkbox'>";
                echo "</td>";

                echo "<td align='center'>";
                echo "<a href='izpisrazreda.php?id=6b&razred=".$VRazred."&ucenec=".$R["iducenec"]."'><img src='img/m_poglej1.gif' border='0'></a>";
                echo "</td>";
                
                echo "<td>";
                $SQL = "SELECT datum FROM tabsporocila WHERE leto=".$VLeto." AND iducenec=".$R["iducenec"]." ORDER BY datum DESC LIMIT 0,1";
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    $Datum=new DateTime($R1["datum"]);
                    echo $Datum->format('j.n.Y H:i:s');
                }else{
                    echo "Ni vpisov";
                }
                echo "</td>";
                
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            //echo "<input name='Stevilo' type='hidden' value='".($i1-1)."'>";
            //echo "<input name='stucencev' type='hidden' value='".($Indx-1)."'>";
            echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='id' type='hidden' value='6a'>";
            //echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
            echo "<b>Sporočilo staršem:</b><br />";
            echo "<small>(Sporočila se pošljejo na e-mail očeta in matere, če sta vnesena)</small><br />";
            echo "<textarea name='vsebina' rows='8' cols='80'></textarea><br />";
            //echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
            //echo "<input name='Povezava' type='hidden' value='/'>";
            echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            if ($VLevel > 2){
                echo "<a href='izpisrazreda.php?id=4a&solskoleto=".$VLeto."'>Pošiljanje e-mailov vsem staršem</a><br />";
            }
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
            break;
        case "6a": //vpis sporočila in pošiljanje preko e-pošte
            if (isset($_POST["razred"])){
                $VRazred = $_POST["razred"];
            }else{
                if (isset($_GET["razred"])){
                    $VRazred=$_GET["razred"];
                }else{
                    $VRazred = 0;
                }
            }
            if ($VRazred > 0){
                //error_reporting(E_ALL);
                error_reporting(E_STRICT);
                date_default_timezone_set('Europe/Ljubljana');
                require_once('class.phpmailer.php');

                $txt=$_POST["vsebina"];
                $order   = array("\"", "'", ">","<",'$');
                $txt = str_replace($order,"",$txt);
                
                echo "<br />";
                
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.oceemail,tabucenci.matiemail FROM tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                $SQL .= "WHERE idrazred=".$VRazred." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if (isset($_POST["em_".$R["iducenec"]])){
                        //pobriše krmilne HTML znake
                        $SQL = "INSERT INTO tabsporocila (leto,datum,iducenec,posiljatelj,vsebina) VALUES (";
                        $SQL .= $VLeto;
                        $SQL .= ",'".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL .= ",".$R["iducenec"];
                        $SQL .= ",1";
                        $SQL .= ",'".$txt."'";
                        $SQL .= ")";
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Težave s podatkovno bazo, sporočilo ni shranjeno!<br />$SQL <br />");
                        }else{
                            echo "Sporočilo je bilo poslano: ".$R["ime"]." ".$R["priimek"]."<br />";
                        }
                        
                        //$address = $R["email"];
                        
                        $mail             = new PHPMailer();
                        $mail->CharSet='UTF-8';

                        //$body             = file_get_contents('contents.html');
                        //$body             = eregi_replace("[\]",'',$body);


                        $emailsender = "mail.kadri.send@gmail.com";
                        $mail->IsSMTP(); // telling the class to use SMTP
                        
                        $mail->Host       = $mail_host1; // SMTP server
                        $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                        $mail->SMTPAuth   = true;                  // enable SMTP authentication
                        $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                        $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                        $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                        $mail->Username   = $mail_user1;  // GMAIL username
                        $mail->Password   = $mail_pass1;            // GMAIL password

                        $mail->SetFrom("$emailsender");

                        $mail->AddReplyTo("$emailsender");

                        if ($R["spol"]=="M"){
                            $mail->Subject    = "Sporočilo razrednika staršem učenca: ".$R["ime"]." ".$R["priimek"];
                        }else{
                            $mail->Subject    = "Sporočilo razrednika staršem učenke: ".$R["ime"]." ".$R["priimek"];
                        }

                        $body="Spoštovani,\n\nV aplikaciji Kadri je objavljeno sporočilo razrednika staršem za ";
                        if ($R["spol"]=="M"){
                            $body .= "učenca: ";
                        }else{
                            $body .= "učenko: ";
                        }
                        $body .= $R["ime"]." ".$R["priimek"]."\n\nVsebina:\n";
                        $body .= $txt;
                        $body .= "\n\nLep pozdrav,\n\n".$_POST["posiljatelj"]."\n\nP.S. \nTo sporočilo je generirano avtomatsko. Na to sporočilo ne odgovarjajte!";
                        $mail->AltBody    = $body;
                        
                        $body = str_replace("\n","<br />",$body);
                        $mail->MsgHTML($body);

                        //$address = "whoto@otherdomain.com";
                        //$mail->AddAddress($address, "John Doe");

                        //$mail->AddAttachment("images/phpmailer.gif");      // attachment
                        //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
                        
                        $mailout=false;
                        $address1=$R["oceemail"];
                        if (strpos($address1,"@") > 0 ) {
                            $mail->AddAddress($address1);
                            $mailout=true;
                        }
                        $address2=$R["matiemail"];
                        if (strpos($address2,"@") > 0 ) {
                            $mail->AddAddress($address2);
                            $mailout=true;
                        }
                        
                        if ($mailout){
                            if(!$mail->Send()) {
                                echo "Napaka pri pošiljanju pošte: " . $mail->ErrorInfo;
                            }
                        }
                        echo "<br />";
                        $mail=null;
                    }
                }
            }
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
            echo "<a href='izpisrazreda.php?id=6&razred=".$VRazred."'>Nazaj na sporočila</a><br />";
            break;
        case "6b": //izpis zgodovine sporočil med starši in razrednikom
            if (isset($_POST["razred"])){
                $VRazred = $_POST["razred"];
            }else{
                if (isset($_GET["razred"])){
                    $VRazred=$_GET["razred"];
                }else{
                    $VRazred = 0;
                }
            }
            if (isset($_POST["ucenec"])){
                $ucenec = $_POST["ucenec"];
            }else{
                if (isset($_GET["ucenec"])){
                    $ucenec=$_GET["ucenec"];
                }else{
                    $ucenec = 0;
                }
            }
            $SQL = "SELECT priimek,ime,spol FROM tabucenci WHERE iducenec=".$ucenec;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VUcenec=$R["ime"]." ".$R["priimek"];
                $VSpol=$R["spol"];
            }
            
            //zgodovina sporočil
            $SQL = "SELECT datum,posiljatelj,vsebina FROM tabsporocila WHERE leto=".$VLeto." AND iducenec=".$ucenec." ORDER BY datum DESC";
            $result = mysqli_query($link,$SQL);
            $txt = "";
            while ($R = mysqli_fetch_array($result)){
                $datum=new DateTime($R["datum"]);
                if ($R["posiljatelj"] == 1){
                    $txt .= $datum->format('d.m.Y H:m:s').", razrednik -> starši:\n";
                }else{
                    $txt .= $datum->format('d.m.Y H:m:s').", starši -> razrednik:\n";
                }
                $txt .= $R["vsebina"]."\n\n";
            }
            echo "<br />";
            echo "<b>Zgodovina sporočil za: $VUcenec</b><br />";
            echo "<textarea cols='80' rows='12'>$txt</textarea><br />";
            echo "<br />";
            echo "<a href='izpisrazreda.php?razred=".$VRazred."'>Nazaj na izpis razreda</a><br />";
            echo "<a href='izpisrazreda.php?id=6&razred=".$VRazred."'>Nazaj na sporočila</a><br />";
            break;
        case "7": //Kontakti s starši učencev na interesni dejavnosti
            if (isset($_POST["krozek"])){
                $VKrozek = $_POST["krozek"];
            }else{
                if (isset($_GET["krozek"])){
                    $VKrozek=$_GET["krozek"];
                }else{
                    $VKrozek = 0;
                }
            }

            $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime,tabucenci.oceemail,tabucenci.matiemail,tabucenci.skrbnikiemail,tabkrozki.krozek,tabkrozki.mentor FROM ";
            $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabkrozekclan ON tabrazred.iducenec=tabkrozekclan.ucenec) ";
            $SQL .= "INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
            $SQL = $SQL . " WHERE tabkrozekclan.krozek=".$VKrozek." AND tabkrozekclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabucenci.priimek,tabucenci.ime";

            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Pošiljanje elektronskih sporočil staršem učencev na interesni dejavnosti - ".$R["krozek"].", ".$R["mentor"]."</h2>";
                echo "<form method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Ime</th><th>Oče</th><th>Mati</th><th>Skrbnik</th></tr>";
                echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></td><td><input class='groovybutton' name='b2' type='button' value='' onClick='OznaciStolpec(this.form,2)'></td><td><input class='groovybutton' name='b3' type='button' value='' onClick='OznaciStolpec(this.form,3)'></td></tr>";

                $Indx=1;
                $i1=1;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["oceemail"],"@")) ){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["oceemail"]."'><input id='dan_1' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["oceemail"]."'>".$R["oceemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["matiemail"],"@"))){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["matiemail"]."'><input id='dan_2' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["matiemail"]."'>".$R["matiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["skrbnikiemail"],"@"))){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["skrbnikiemail"]."'><input id='dan_3' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["skrbnikiemail"]."'>".$R["skrbnikiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='Stevilo' type='hidden' value='".($i1-1)."'>";
                echo "<input name='id' type='hidden' value='3'>";
                echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
                echo "<b>Sporočilo:</b><br /><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
                echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
                echo "<input name='Povezava' type='hidden' value='/'>";
                echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
                echo "<input name='submit' type='submit' value='Pošlji e-mail'>";
                echo "</form>";
            }
            echo "<a href='tekmovanjakrozki.php?id=202&idtekm=".$VKrozek."'>Nazaj na izpis krožka</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
            break;
        case "8": //Kontakti s starši učencev na šolskih športnih tekmovanjih
            if (isset($_POST["idtekm"])){
                $VKrozek = $_POST["idtekm"];
            }else{
                if (isset($_GET["idtekm"])){
                    $VKrozek=$_GET["idtekm"];
                }else{
                    $VKrozek = 0;
                }
            }

            $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime,tabucenci.oceemail,tabucenci.matiemail,tabucenci.skrbnikiemail,tabsstclan.tekmovanje,tabsstclan.mentor1 FROM ";
            $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
            $SQL .= "INNER JOIN tabsstclan ON tabrazred.iducenec=tabsstclan.iducenec ";
            $SQL = $SQL . " WHERE tabsstclan.idtekmovanje=".$VKrozek." AND tabsstclan.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
            $SQL = $SQL ." ORDER BY tabucenci.priimek,tabucenci.ime";

            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Pošiljanje elektronskih sporočil staršem učencev na interesni dejavnosti - ".$R["tekmovanje"].", ".$R["mentor1"]."</h2>";
                echo "<form method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Ime</th><th>Oče</th><th>Mati</th><th>Skrbnik</th></tr>";
                echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></td><td><input class='groovybutton' name='b2' type='button' value='' onClick='OznaciStolpec(this.form,2)'></td><td><input class='groovybutton' name='b3' type='button' value='' onClick='OznaciStolpec(this.form,3)'></td></tr>";

                $Indx=1;
                $i1=1;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["oceemail"],"@")) ){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["oceemail"]."'><input id='dan_1' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["oceemail"]."'>".$R["oceemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["matiemail"],"@"))){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["matiemail"]."'><input id='dan_2' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["matiemail"]."'>".$R["matiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "<td>";
                    if (is_numeric(strpos($R["skrbnikiemail"],"@"))){
                        echo "<input name='uc_".$i1."' type='hidden' value='".$R["skrbnikiemail"]."'><input id='dan_3' name='em_".$i1."' type='checkbox'>";
                        echo "<a href='mailto:".$R["skrbnikiemail"]."'>".$R["skrbnikiemail"]."</a>";
                        $i1=$i1+1;
                    }
                    echo "</td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='Stevilo' type='hidden' value='".($i1-1)."'>";
                echo "<input name='id' type='hidden' value='3'>";
                echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
                echo "<b>Sporočilo:</b><br /><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
                echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
                echo "<input name='Povezava' type='hidden' value='/'>";
                echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
                echo "<input name='submit' type='submit' value='Pošlji e-mail'>";
                echo "</form>";
            }
            echo "<a href='tekmovanjakrozki.php?id=302&idtekm=".$VKrozek."'>Nazaj na izpis tekmovanja</a><br />";
                        ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
            break;
        case "9": //vnos socigrama
            if (isset($_POST["razred"])){
                $VRazred = $_POST["razred"];
            }else{
                if (isset($_GET["razred"])){
                    $VRazred=$_GET["razred"];
                }else{
                    $VRazred = 0;
                }
            }
            if ($VRazred > 0){
                $SQL = "SELECT tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime,tabucenci.iducenec,tabucenci.spol FROM ";
                $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=$VLeto AND tabrazdat.id=$VRazred";
                $SQL = $SQL ." ORDER BY tabucenci.priimek,tabucenci.ime";

                $result = mysqli_query($link,$SQL);
                $indx=0;
                //prebere učence
                while ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $indx += 1;
                    $ucenec[$indx][0] = $R["iducenec"];
                    $ucenec[$indx][1] = $R["ime"]." ".$R["priimek"];
                    $ucenec[$indx][2] = $R["spol"];
                }
                $StUcencev=$indx;
                
                //izpiše učence in obrazec za vnos izbir
                echo "<h2>Vnos sociograma za $VRazred1. $VParalelka</h2>";
                echo "<small>Učencem vnesite njihove izbire. Če imate manj kot 3, ostale pustite prazne.</small>";
                echo "<form name='sociogram' method='post' action='izpisrazreda.php'>";
                echo "<table border='1'>";
                echo "<tr><th>Št.</th><th>Ime</th><th>1.</th><th>2.</th><th>3.</th></tr>";
                
                for ($i=1;$i <= $StUcencev;$i++){
                    echo "<td>$i</td>";
                    echo "<td>".$ucenec[$i][1]."<input type='hidden' name='uc_$i' value='".$ucenec[$i][0]."'></td>";
                    $SQL = "SELECT md1,md2,md3 FROM tabsociogram WHERE leto=$VLeto AND iducenec=".$ucenec[$i][0];
                    $result1 = mysqli_query($link,$SQL);
                    $R1 = mysqli_fetch_array($result1);
                    echo "<td><select name='md1_$i'>";
                    echo "<option value='0'>-</option>";
                    for ($j=1;$j <= $StUcencev; $j++){
                        if ($i != $j){
                            if ($R1){
                                if (($ucenec[$j][0] == $R1["md1"])){
                                    echo "<option value='".$ucenec[$j][0]."' selected='selected'>".$ucenec[$j][1]."</option>";
                                }else{
                                    echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                                }
                            }else{
                                echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                            }
                        }
                    }
                    echo "</select></td>";
                    echo "<td><select name='md2_$i'>";
                    echo "<option value='0'>-</option>";
                    for ($j=1;$j <= $StUcencev; $j++){
                        if ($i != $j){
                            if ($R1){
                                if (($ucenec[$j][0] == $R1["md2"])){
                                    echo "<option value='".$ucenec[$j][0]."' selected='selected'>".$ucenec[$j][1]."</option>";
                                }else{
                                    echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                                }
                            }else{
                                echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                            }
                        }
                    }
                    echo "</select></td>";
                    echo "<td><select name='md3_$i'>";
                    echo "<option value='0'>-</option>";
                    for ($j=1;$j <= $StUcencev; $j++){
                        if ($i != $j){
                            if ($R1){
                                if (($ucenec[$j][0] == $R1["md3"])){
                                    echo "<option value='".$ucenec[$j][0]."' selected='selected'>".$ucenec[$j][1]."</option>";
                                }else{
                                    echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                                }
                            }else{
                                echo "<option value='".$ucenec[$j][0]."'>".$ucenec[$j][1]."</option>";
                            }
                        }
                    }
                    echo "</select></td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "<input name='stucencev' type='hidden' value='$StUcencev'>";
                echo "<input name='razred' type='hidden' value='$VRazred'>";
                echo "<input name='leto' type='hidden' value='$VLeto'>";
                echo "<input name='id' type='hidden' value='9a'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
            break;
        case "9a": //vpis podatkov za sociogram
            if (isset($_POST["stucencev"])){
                $StUcencev=$_POST["stucencev"];
            }else{
                $StUcencev=0;
            }
            if ($StUcencev > 0){
                for ($i=1;$i <= $StUcencev;$i++){
                    $Ucenec=$_POST["uc_$i"];
                    $SQL = "SELECT id FROM tabsociogram WHERE iducenec=$Ucenec AND leto=$VLeto";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        //update
                        $SQL = "UPDATE tabsociogram SET md1=".$_POST["md1_$i"].",md2=".$_POST["md2_$i"].",md3=".$_POST["md3_$i"]." WHERE id=".$R["id"];
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Napaka pri prepisovanju podatkov!<br />$SQL");
                        }
                    }else{
                        //insert
                        $SQL = "INSERT INTO tabsociogram (leto,iducenec,md1,md2,md3,ld1,ld2,ld3) VALUES (".$VLeto.",".$Ucenec.",".$_POST["md1_$i"].",".$_POST["md2_$i"].",".$_POST["md3_$i"].",0,0,0)";
                        if (!($result1 = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu podatkov!<br />$SQL");
                        }
                    }
                }
                echo "<h2>Podatki so vpisani</h2>";
                
                //izpis tabele priljubljenosti
                if (isset($_POST["razred"])){
                    $VRazred = $_POST["razred"];
                }else{
                    if (isset($_GET["razred"])){
                        $VRazred=$_GET["razred"];
                    }else{
                        $VRazred = 0;
                    }
                }
                $SQL = "SELECT razred,oznaka FROM tabrazdat WHERE id=$VRazred";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }else{
                    $VRazred1=0;
                    $VParalelka="";
                }
                
                //prebere podatke o učencih in izbirah
                $SQL = "SELECT tabucenci.ime,tabucenci.priimek,tabucenci.spol,tabucenci.iducenec,tabsociogram.md1,tabsociogram.md2,tabsociogram.md3 FROM (tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec) ";
                $SQL .= "INNER JOIN tabsociogram ON tabucenci.iducenec=tabsociogram.iducenec ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabsociogram.leto=$VLeto AND tabrazred.idrazred=$VRazred ";
                $SQL .= "ORDER BY tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                $indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $indx += 1;
                    $ucenec[$indx][0] = $R["iducenec"];
                    $ucenec[$indx][1] = $R["ime"]." ".$R["priimek"];
                    $ucenec[$indx][2] = $R["spol"];
                    $ucenec[$indx][3] = $R["md1"];
                    $ucenec[$indx][4] = $R["md2"];
                    $ucenec[$indx][5] = $R["md3"];
                    $ucenec[$indx][6] = 0;
                    $ucenec[$indx][7] = $R["ime"]." \\n".$R["priimek"];
                }
                $StUcencev=$indx;
                
                //prešteje kolikokrat je bil kdo izbran
                for ($i=1;$i <= $StUcencev;$i++){
                    for ($j=1;$j <= $StUcencev;$j++){
                        if ($i != $j){
                            if (($ucenec[$i][0] == $ucenec[$j][3]) or ($ucenec[$i][0] == $ucenec[$j][4]) or ($ucenec[$i][0] == $ucenec[$j][5])){
                                $ucenec[$i][6] += 1;
                            }
                        }
                    }
                }
                
                //izpiše tabelo priljubljenosti
                echo "<table border='1'>";
                echo "<tr><th>št</th><th>ime</th><th>število izbir</th><th>graf</th></tr>";
                for ($i=1;$i <= $StUcencev;$i++){
                    if ($ucenec[$i][2] == "M"){
                        echo "<tr bgcolor='lightgrey'>";
                    }else{
                        echo "<tr>";
                    }
                    echo "<td>$i</td>";
                    echo "<td>".$ucenec[$i][1]."</td>";
                    echo "<td align='center'>".$ucenec[$i][6]."</td>";
                    echo "<td>";
                    for ($j=0;$j < $ucenec[$i][6];$j++){
                        echo "<img src='mo5.gif'>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                
                //pripravi .DOT datoteko povezav
                $myFile = "dato/sociogram-$VRazred1$VParalelka-".$Danes->format('Ymd').".dot";
                $fh = fopen($myFile,'w') or die("Ne morem odpreti .dot datoteke!");

                fwrite ($fh,"digraph G {\n");
                
                for ($i=1;$i <= $StUcencev;$i++){
                    if ($ucenec[$i][2] == "M"){
                        fwrite ($fh,"u".$ucenec[$i][0]." [label=\"".$ucenec[$i][7]."\",style=filled,color=skyblue];\n");
                    }else{
                        fwrite ($fh,"u".$ucenec[$i][0]." [label=\"".$ucenec[$i][7]."\",style=filled,color=lightpink];\n");
                    }
                    if ($ucenec[$i][3] > 0){
                        fwrite ($fh,"u".$ucenec[$i][0]." -> u".$ucenec[$i][3].";\n");
                    }
                    if ($ucenec[$i][4] > 0){
                        fwrite ($fh,"u".$ucenec[$i][0]." -> u".$ucenec[$i][4].";\n");
                    }
                    if ($ucenec[$i][5] > 0){
                        fwrite ($fh,"u".$ucenec[$i][0]." -> u".$ucenec[$i][5].";\n");
                    }
                }
                fwrite ($fh,"}\n");
                fclose($fh);
                echo "<a href='$myFile'>Prenesi datoteko za grafično obdelavo v programu GraphViz</a><br />";
                
                $doclocation=$_SERVER["DOCUMENT_ROOT"];
                //naredi sliko digrama tipa DOT
                $command="dot -Tpng $doclocation/$myFile -o $doclocation/dato/sociogram-$VRazred1$VParalelka-".$Danes->format('Ymd').".png";
                //echo $command."<br />";
                $out = exec($command);
                sleep(2); //počaka 2 sekundi
                //echo $out."<br />";
                echo "<br />";
                echo "<img src='dato/sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd').".png' alt='"."Tu bi morala biti slika: sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd').".png"."'>";

                //naredi sliko digrama tipa CIRCO
                echo "<hr>";
                $command="circo -Tpng $doclocation/$myFile -o $doclocation/dato/sociogram-$VRazred1$VParalelka-".$Danes->format('Ymd')."_2.png";
                //echo $command."<br />";
                $out = exec($command);
                sleep(2); //počaka 2 sekundi
                echo "<br />";
                echo "<img src='dato/sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd')."_2.png' alt='"."Tu bi morala biti slika: sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd')."_2.png"."'>";

                //naredi sliko digrama tipa FDP
                echo "<hr>";
                $command="fdp -Tpng $doclocation/$myFile -o $doclocation/dato/sociogram-$VRazred1$VParalelka-".$Danes->format('Ymd')."_3.png";
                //echo $command."<br />";
                $out = exec($command);
                sleep(2); //počaka 2 sekundi
                echo "<br />";
                echo "<img src='dato/sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd')."_3.png' alt='"."Tu bi morala biti slika: sociogram-".$VRazred1.$VParalelka."-".$Danes->format('Ymd')."_3.png"."'>";
            }
            break;
		default:
			if (isset($_POST["razred"])){
				$VRazred = $_POST["razred"];
			}else{
				if (isset($_GET["razred"])){
					$VRazred=$_GET["razred"];
				}else{
					$VRazred = 0;
				}
			}
			$VDevetletka=9;
			if ($VRazred=="" ){
				$VDevetletka = $_SESSION["devetletka"];
				$VRazred = $_SESSION["razred"];
				$VParalelka = $_SESSION["paralelka"];
				$IdUcitelj = $_SESSION["ucitelj"];
				$IdVzgojitelj = $_SESSION["vzgojitelj"];
			}
            $_SESSION["razred"]=$VRazred;

            echo "<form name='rezultati1' method='post' action='izpisrazreda.php'>";
            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
            echo "<input name='vrstaos' type='hidden' value='9'>";
            if ($VLevel < 2){
                $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
                $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
            }else{
                $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
                $SQL .= " ORDER BY idsola,razred,oznaka";
            }
            $result = mysqli_query($link,$SQL);

            echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
            echo "<option value='0'>Ni izbran</option>";
            $Indx=1;
            if ($VecSol > 0){
                while ($R = mysqli_fetch_array($result)){
                    if ($VRazred==$R["id"] ){
                        echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
            }else{
                while ($R = mysqli_fetch_array($result)){
                    if ($VRazred==$R["id"] ){
                        echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }else{
                        echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                    }
                    $Indx=$Indx+1;
                }
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='0'>";
            //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
            //echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
                                
			$SQL = "SELECT tabrazred.*,tabrazred.id AS rid, tabucitelji.priimek as upriimek, tabucitelji.ime as uime, tabucitelji.spol as uspol,tabvzgojitelji.priimek as vpriimek, tabvzgojitelji.ime as vime, tabvzgojitelji.spol AS vspol,tabucenci.iducenec AS uid,tabrazdat.*,tabrazdat.leto AS rleto,tabrazdat.idsola FROM ";
			$SQL = $SQL . "(((tabvzgojitelji ";
			$SQL = $SQL . "INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
			$SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
			$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
			$SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred;
			$SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
			$result = mysqli_query($link,$SQL);
			if ($R = mysqli_fetch_array($result)){
				$VParalelka=$R["oznaka"];
				$VLeto=$R["rleto"];
				$_SESSION["solskoleto"] = $VLeto;
                $VIdSola=$R["idsola"];
                if ($VecSol > 0){
                    $SQL1 = "SELECT solakratko FROM tabsola WHERE id=".$VIdSola;
                    $result1 = mysqli_query($link,$SQL1);
                    if ($R1 = mysqli_fetch_array($result1)){
                        echo "<h2>Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $R["razred"] . ". " . $R["oznaka"] . " - ".$R1["solakratko"]."</h2>";
                    }else{
                        echo "<h2>Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $R["razred"] . ". " . $R["oznaka"] . "</h2>";
                    }
                }else{
                    echo "<h2>Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . ", Razred: " . $R["razred"] . ". " . $R["oznaka"] . "</h2>";
                }
				$Ucitelj = $R["upriimek"]  . ", " . $R["uime"];
				$IdUcitelj=$R["IdUcitelj"];
				$Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
				$IdVzgojitelj=$R["IdVzgojitelj"];

				if ($R["uspol"]=="M" ){
					echo "<h3>Razrednik: " . $Ucitelj . "<br />";
				}else{
					echo "<h3>Razredničarka: " . $Ucitelj . "<br />";
				}
				switch ( $R["razred"]){
					case 1:
						if ($R["vspol"]=="M" ){
							echo "Drugi učitelj: " . $Vzgojitelj . "</h3>";
						}else{
							echo "Druga učiteljica: " . $Vzgojitelj . "</h3>";
						}
						break;
					case 2:
					case 3:
					case 4:
					case 5:
						if ($R["vspol"]=="M" ){
							echo "Učitelj PB: " . $Vzgojitelj . "</h3>";
						}else{
							echo "Učiteljica PB: " . $Vzgojitelj . "</h3>";
						}
						break;
					default:
						echo "</h3>";
				}
			}

			if ($VLevel < 1 ){
				echo "<table border=1><th>N</th><th>Mat. list</th><th>Priimek in ime</th><th>Datum rojstva</th><th>Naslov</th><th>Posta</th><th>Kraj</th><th>Oče</th><th>Telefon</th><th>Mati</th><th>Telefon</th><th>Bivanje</th>";
			}else{
				echo "<table border=1><th>N</th><th>Mat. list</th><th>Priimek in ime</th><th>Datum rojstva</th><th>Naslov</th><th>Posta</th><th>Kraj</th><th>Oče</th><th>Telefon</th><th>Mati</th><th>Telefon</th><th>Bivanje</th><th width='20'><img src='img/m_delete.gif' border='0' alt='Briši'></th><th width='20'><img src='img/m_edit1.gif' border='0' alt='Popravi'></th>";
			}

			$Indx=1;
			$result = mysqli_query($link,$SQL);
			while ($R = mysqli_fetch_array($result)){
				$oUcenec=new RUcenec();
				$oUcenec->getUcenec($R["uid"]);
				echo "<tr><td>" . $Indx ."</td>";
				echo "<td>" . $oUcenec->getMaticniList() . "</td>";
				echo "<td><a href='ucenec_pregled.php?ucenec=".$oUcenec->getIdUcenec() ."'>" . $oUcenec->getPriimek() . ", " . $oUcenec->getIme() . "</a></td>";
				echo "<td align='right'>" . $oUcenec->getDatRoj() . "</td>";
				echo "<td>". $oUcenec->getNaslov() ."</td>";
				echo "<td>". $oUcenec->getPosta() ."</td>";
				echo "<td>". $oUcenec->getKraj() ."</td>";
				echo "<td>". $oUcenec->getoce() ."</td>";
				if (strlen($oUcenec->getoce()) > 0){
                    echo "<td>";
                    if (strlen($oUcenec->getocekontakt()) > 0){
                        echo "<b>".$oUcenec->getocekontakt()."</b>&nbsp;";
                    }
                    if (strlen($oUcenec->getoceGSM()) > 0){
                        echo "GSM: <b>".$oUcenec->getoceGSM()."</b>&nbsp;";
                    }
                    if (strlen($oUcenec->getoceSluzba()) > 0){
                        echo "služba: <b>".$oUcenec->getoceSluzba(). "</b>";
                    }
                    echo "</td>";
				}else{
					echo "<td>&nbsp;</td>";
				}
				echo "<td>". $oUcenec->getmati() ."</td>";
				if (strlen($oUcenec->getmati()) > 0){
                    echo "<td>";
                    if (strlen($oUcenec->getmatikontakt()) > 0){
                        echo "<b>".$oUcenec->getmatikontakt()."</b>&nbsp;";
                    }            
                    if (strlen($oUcenec->getmatiGSM()) > 0){
                        echo "GSM: <b>".$oUcenec->getmatiGSM()."</b>&nbsp;";
                    }
                    if (strlen($oUcenec->getmatiSluzba()) > 0){
                        echo "služba: <b>".$oUcenec->getmatiSluzba(). "</b>";
                    }
                    echo "</td>";
				}else{
					echo "<td>&nbsp;</td>";
				}
				echo "<td>". $oUcenec->getBivanjePri() ."</td>";
				if ($VLevel < 1 ){
					echo "</tr>";
				}else{
					echo "<td align=center><a href='izpisrazreda.php?id=3&brisi=".$R["rid"] ."&razred=".$VRazred."&solskoleto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
					echo "<td align=center><a href='ucenec.php?id=3&ucenec=".$R["uid"] ."&leto=".$VLeto."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
					echo "</tr>";
				}    
				$Indx=$Indx+1;
			}

			echo "</table>";
			/*
			$_SESSION["leto"]=$VLeto;
			$_SESSION["razred"]=$VRazred;
			$_SESSION["paralelka"]=$VParalelka;
			$_SESSION["devetletka"]=$VDevetletka;
			$_SESSION["ucitelj"]=$IdUcitelj;
			$_SESSION["vzgojitelj"]=$IdVzgojitelj;
			*/
			switch ( $VLevel){
				Case 0:
					echo "<a href='izborrazreda.php'>Izbor razreda</a><br />";
					break;
				case 1:
				case 2:
				case 3:
					echo "<h2><a href='izpisrazreda.php?id=1&razred=".$VRazred."&solskoleto=".$VLeto."'>Dodajanje učencev, razrednikov in vzgojiteljev v razrede</a></h2>";
					echo "<h2><a href='izpisrazreda.php?id=4&solskoleto=".$VLeto."&razred=".$VRazred."'>Pošiljanje elektronskih sporočil</a></h2>";
                    echo "<h2><a href='izpisrazreda.php?id=6&solskoleto=".$VLeto."&razred=".$VRazred."'>Sporočila staršem</a></h2>";
					echo "<h2><a href='izpisrazreda.php?id=5&solskoleto=".$VLeto."&razred=".$VRazred."'>Vnos predstavnikov za svet staršev</a></h2>";
					echo "<a href='izborrazreda.php'>Izbor razreda</a><br />";
					echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."&solskoleto=".$VLeto."'>Izpis redovalnice razreda</a><br />";
					break;
				default:
					echo "<br />";
			}
	}
}
?>
    <script language="JavaScript">
    function OznaciVse(form){
        for (i=1; i < form.elements.length; i++) {
            form.elements[i].checked=true;
        }
    }
    function BrisiVse(form){
        for (i=1; i < form.elements.length; i++) {
            form.elements[i].checked=false;
        }
    }
    </script>

</body>
</html>
