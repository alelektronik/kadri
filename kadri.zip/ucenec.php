<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Učenec
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat04",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat05",
            dateFormat:"%d.%m.%Y",
            
            yearsRange:[1940,2080],
            limitToToday:true
        });
    };
</script>
</head>
<body>

<?php
$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    if (!CheckDostop("UpdUc",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = 0;
            }
        }

        switch ($Vid){
            case "1": //vnosni obrazec za novega učenca
                echo "<form name='dodajucenca' method=post action='ucenec.php'>";
                echo "<h2>Vpis podatkov o učencu:</h2>";
                
                echo "<table>";
                echo "<tr><td>Priimek: </td><td><input name='priimek' type='text' size='25'></td></tr>";
                echo "<tr><td>Ime: </td><td><input name='ime' type='text' size='25' ></td></tr>";
                echo "<tr><td>Spol:</td><td><select name='spol'><option selected>M</option><option>F</option></select></td></tr>";
                echo "<tr><td>Datum rojstva: </td><td><input name='datroj' type='text' size='10' id='dat01'></td></tr>";
                echo "<tr><td>Kraj rojstva: </td><td><input name='krajroj' type='text' size='40' ></td></tr>";
                echo "<tr><td>Država rojstva: </td><td><input name='drzavaroj' type='text' size='40'></td></tr>";
                echo "<tr><td>Državljanstvo: </td><td><input name='drzavljanstvo' type='text' size='25'></td></tr>";
                echo "<tr><td>EMŠO: </td><td><input name='emso' type='text' size='15'></td></tr>";
                echo "<tr><td>Matični list: </td><td><input name='maticnilist' type='text' size='10'></td></tr>";
                echo "<tr><td>Matična knjiga: </td><td><input name='maticnaknjiga' type='text' size='10'></td></tr>";
                //'Stalni naslov
                echo "<tr><td>Naslov: </td><td><input name='naslov' type='text' size='40' ></td></tr>";
                echo "<tr><td>Pošta: </td><td><input name='posta' type='text' size='5' ></td></tr>";
                echo "<tr><td>Kraj: </td><td><input name='kraj' type='text' size='25' ></td></tr>";
                //'začasno bivališče
                echo "<tr><td>Naslov začasnega bivališča: </td><td><input name='naslovzac' type='text' size='40' ></td></tr>";
                echo "<tr><td>Pošta začasnega bivališča: </td><td><input name='postazac' type='text' size='5' ></td></tr>";
                echo "<tr><td>Kraj začasnega bivališča: </td><td><input name='krajzac' type='text' size='25' ></td></tr>";

                echo "<tr><td>Telefon doma</td><td><input name='telefondoma' type='text' size='30' ></td></tr>";
                echo "<tr><td>Oče</td><td><input name='oce' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov naslov</td><td><input name='ocenaslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov začasni naslov</td><td><input name='ocezacnasl' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov telefon doma</td><td><input name='ocekontakt' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov GSM</td><td><input name='ocegsm' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov službeni telefon</td><td><input name='ocesluzba' type='text' size='30' ></td></tr>";
                echo "<tr><td>Očetov e-mail</td><td><input name='oceemail' type='text' size='30' ></td></tr>";

                echo "<tr><td>Mati</td><td><input name='mati' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin naslov</td><td><input name='matinaslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin začasni naslov</td><td><input name='matizacnasl' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin telefon doma</td><td><input name='matikontakt' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin GSM</td><td><input name='matigsm' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin službeni telefon</td><td><input name='matisluzba' type='text' size='30' ></td></tr>";
                echo "<tr><td>Materin e-mail</td><td><input name='matiemail' type='text' size='30' ></td></tr>";

                echo "<tr><td>Skrbnik</td><td><input name='skrbniki' type='text' size='30' ></td></tr>";
                echo "<tr><td>Naslov skrbnika</td><td><input name='skrbnikinaslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Telefon skrbnika</td><td><input name='skrbnikikontakt' type='text' size='30' ></td></tr>";
                echo "<tr><td>Kontaktni e-mail skrbnika</td><td><input name='skrbnikiemail' type='text' size='30' ></td></tr>";

                echo "<tr><td>Plačnik</td><td><input name='placnik' type='text' size='30' ></td></tr>";
                echo "<tr><td>Naslov plačnika</td><td><input name='placniknaslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Telefon plačnika</td><td><input name='placnikkontakt' type='text' size='30' ></td></tr>";

                echo "<tr><td>Datum začetka šolanja</td><td><input name='zacsolanja' type='text' size='10' id='dat02'></td></tr>";
                echo "<tr><td>Datum zaključka šolanja</td><td><input name='konsolanja' type='text' size='10' id='dat03'></td></tr>";
                echo "<tr><td>Datum začetka šolanja na šoli</td><td><input name='zacsolanjasola' type='text' size='10' id='dat04'></td></tr>";
                echo "<tr><td>Datum zaključka šolanja na šoli</td><td><input name='konsolanjasola' type='text' size='10' id='dat05'></td></tr>";

                echo "<tr><td>Opombe</td><td><textarea name='opombe' cols='40' rows='3'></textarea></td></tr>";
                
                echo "<tr><td>Prihajanje v šolo</td><td>";
                echo "<select name='krajbivanja'>";
                
                $SQL = "SELECT * FROM tabkrajbivanja";
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["Id"]."'>".$R["KrajBivanja"]."</option>";
                }

                echo "</select></td></tr>";

                echo "<tr><td>Posebne potrebe</td><td>";
                echo "<select name='posebnepotrebe'>";
                
                $SQL = "SELECT * FROM tabposebnepotrebe";
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["IdPosebnePotrebe"]."'>".$R["OpisPosebnePotrebe"]."</option>";
                }
                echo "</select></td></tr>";

                echo "<tr><td>Bivanje</td><td>";
                echo "<select name='bivanje'>";
                
                $SQL = "SELECT * FROM tabbivanje";
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["idBivanje"]."'>".$R["Bivanje"]."</option>";
                }
                echo "</select></td></tr>";

                echo "<tr><td>Učenec je rom</td><td><input name='rom' type='checkbox'></td></tr>";
                
                echo "<tr><td>Šolski okoliš</td><td><input name='solskiokolis' type='text' size='30' >";
                echo "<select name='solskiokolis1'>";
                echo "<option value='0'>Domač</option>";
                $SQL = "SELECT naziv,obcina FROM tabzavodi ORDER BY obcina,naziv";
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($VSolskiOkolis == $R1["naziv"]){
                        echo "<option value='".$R1["naziv"]."' selected='selected'>".$R1["obcina"]." - ".$R1["naziv"]."</option>";
                    }else{
                        echo "<option value='".$R1["naziv"]."'>".$R1["obcina"]." - ".$R1["naziv"]."</option>";
                    }
                }
                echo "</select>";
                echo "</td></tr>";

                echo "<tr><td>Status</td><td>";
                echo "<select name='aktivnost'>";
                
                $SQL = "SELECT * FROM tabaktivnostucenca";
                $result = mysqli_query($link,$SQL);
                $Indx = 0;

                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["Id"]."'>".$R["AktivnostUcenca"]."</option>";
                }
                echo "</select></td></tr>";
                echo "</table>";
                echo "<input name='id' type='hidden' value='2'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
                break;
            case "2": //vpis učenca
                $VPriimek=$_POST["priimek"];
                $VIme=$_POST["ime"];
                $VNaslov=$_POST["naslov"];
                $VPosta=$_POST["posta"];
                $VKraj=$_POST["kraj"];
                $VNaslovZac=$_POST["naslovzac"];
                $VPostaZac=$_POST["postazac"];
                $VKrajZac=$_POST["krajzac"];
                $VSpol=$_POST["spol"];
                $Vemso=$_POST["emso"];
                if (isDate($_POST["datroj"])){
                    $VDatRoj=new DateTime(isDate($_POST["datroj"]));
                }else{
                    if (strlen($Vemso) > 0){
                        //datum rojstva prebere iz emšo številke
                        $VDatRoj="-".substr($$_POST["emso"],2,2) . "-".substr($_POST["emso"],0,2);
                        if (intval(substr($_POST["emso"],4,3)) < 900 ){
                            $VDatRoj="2".substr($_POST["emso"],4,3).$VDatRoj;
                        }else{
                            $VDatRoj="1".substr($_POST["emso"],4,3).$VDatRoj;
                        }
                        $VDatRoj= new DateTime($VDatRoj);
                    }else{
                        //če ni vpisan, uporabi aktualni datum
                        $VDatRoj=new DateTime("now");
                    }
                }
                $VOce=$_POST["oce"];
                $VMati=$_POST["mati"];
                $VLetoRoj=$VDatRoj->format('Y');
                $VPosebnePotrebe= $_POST["posebnepotrebe"];
                $VAktivnost= $_POST["aktivnost"];
                $VKrajBivanja= $_POST["krajbivanja"];
                $VKrajRoj=$_POST["krajroj"];
                $VDrzavaRoj=$_POST["drzavaroj"];
                $VDrzavljanstvo=$_POST["drzavljanstvo"];
                $VMaticniList=$_POST["maticnilist"];
                $VMaticnaKnjiga=$_POST["maticnaknjiga"];
                $VTelefonDoma=$_POST["telefondoma"];
                $VOceNaslov=$_POST["ocenaslov"];
                $VOceZacNasl=$_POST["ocezacnasl"];
                $VOceKontakt=$_POST["ocekontakt"];
                $VOceGSM=$_POST["ocegsm"];
                $VOceSluzba=$_POST["ocesluzba"];
                $VOceEmail=$_POST["oceemail"];
                $VMatiNaslov=$_POST["matinaslov"];
                $VMatiZacNasl=$_POST["matizacnasl"];
                $VMatiKontakt=$_POST["matikontakt"];
                $VMatiGSM=$_POST["matigsm"];
                $VMatiSluzba=$_POST["matisluzba"];
                $VMatiEmail=$_POST["matiemail"];
                if (isset($_POST["rom"])){
                    $VRom=1;
                }else{
                    $VRom=0;
                }
                $VBivanje=$_POST["bivanje"];
                $VZacSolanja=$_POST["zacsolanja"];
                $VKonSolanja=$_POST["konsolanja"];
                $VZacSolanjaSola=$_POST["zacsolanjasola"];
                $VKonSolanjaSola=$_POST["konsolanjasola"];
                $VSkrbniki=$_POST["skrbniki"];
                $VSkrbnikiNaslov=$_POST["skrbnikinaslov"];
                $VSkrbnikiKontakt=$_POST["skrbnikikontakt"];
                $VSkrbnikiEmail=$_POST["skrbnikiemail"];
                $VPlacnik=$_POST["placnik"];
                $VPlacnikNaslov=$_POST["placniknaslov"];
                $VPlacnikKontakt=$_POST["placnikkontakt"];
                $VOpombe=$_POST["opombe"];
                //$VSolskiOkolis=$_POST["solskiokolis"];
                if ($_POST["solskiokolis1"] != '0'){
                    $VSolskiOkolis=$_POST["solskiokolis1"];
                }else{
                    $VSolskiOkolis=$_POST["solskiokolis"];
                }

                If (strlen($VPosta)==0 ){ 
                    $VPosta=0;
                }
                If (strlen($VPostaZac)==0 ){ 
                    $VPostaZac=0;
                }

                $SQL = "SELECT * FROM tabucenci WHERE priimek='".$VPriimek."' AND ime='".$VIme."' AND DatRoj='".$VDatRoj->format('Y-m-d H:i:s')."'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    if ($R["Spol"]=="M"){
                        echo "<h1>Učenec s temi podatki je že vpisan</h1>";
                    }else{
                        echo "<h1>Učenka s temi podatki je že vpisana</h1>";
                    }
                    echo $R["Priimek"]." ".$R["Ime"].", ".$VDatRoj->format('d.m.Y')."<br />";
                    echo "<br /><a href='ucenec.php?id=3&ucenec=".$R["IdUcenec"]."'>Popravi podatke učenca</a><br />";
                    echo "<a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"]."'>Na pregled učenca</a><br />";
                    if ($VLevel > 2){
                        echo "<a href='ucenec.php?id=5&ucenec=".$R["IdUcenec"]."'>Dokončno briši učenca iz baze</a><br />";
                    }
                }else{
                    $SQL = "SELECT * FROM tabucenci ORDER BY IdUcenec DESC";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $ucenec=$R["IdUcenec"]+1;
                    }else{
                        $ucenec=1;
                    }

                    $SQL = "INSERT INTO tabucenci (";
                    $SQL = $SQL . "IdUcenec,";
                    $SQL = $SQL . "Priimek,";
                    $SQL = $SQL . "Ime,";
                    $SQL = $SQL . "DatRoj,";
                    $SQL = $SQL . "Naslov,";
                    $SQL = $SQL . "Posta,";
                    $SQL = $SQL . "Kraj,";
                    $SQL = $SQL . "NaslovZac,";
                    $SQL = $SQL . "PostaZac,";
                    $SQL = $SQL . "KrajZac,";
                    $SQL = $SQL . "TelefonDoma,";
                    $SQL = $SQL . "oce,";
                    $SQL = $SQL . "mati,";
                    $SQL = $SQL . "LetoRoj,";
                    $SQL = $SQL . "Spol,";
                    $SQL = $SQL . "IdKrajBivanja,";
                    $SQL = $SQL . "IdPosebnePotrebe,";
                    $SQL = $SQL . "Aktivnost,";
                    $SQL = $SQL . "KrajRoj,";
                    $SQL = $SQL . "DrzavaRoj,";
                    $SQL = $SQL . "emso,";
                    $SQL = $SQL . "MaticniList,";
                    $SQL = $SQL . "MaticnaKnjiga,";
                    $SQL = $SQL . "Drzavljanstvo,";
                    $SQL = $SQL . "bivanje,";
                    $SQL = $SQL . "rom,";
                    $SQL = $SQL . "ocenaslov,";
                    $SQL = $SQL . "ocezacnasl,";
                    $SQL = $SQL . "ocekontakt,";
                    $SQL = $SQL . "oceGSM,";
                    $SQL = $SQL . "oceSluzba,";
                    $SQL = $SQL . "oceemail,";
                    $SQL = $SQL . "matinaslov,";
                    $SQL = $SQL . "matizacnasl,";
                    $SQL = $SQL . "matikontakt,";
                    $SQL = $SQL . "matiGSM,";
                    $SQL = $SQL . "matiSluzba,";
                    $SQL = $SQL . "matiemail,";
                    $SQL = $SQL . "ZacSolanja,";
                    $SQL = $SQL . "KonSolanja,";
                    $SQL = $SQL . "ZacSolanjaSola,";
                    $SQL = $SQL . "KonSolanjaSola,";
                    $SQL = $SQL . "Skrbniki,";
                    $SQL = $SQL . "SkrbnikiNaslov,";
                    $SQL = $SQL . "SkrbnikiKontakt,";
                    $SQL = $SQL . "Skrbnikiemail,";
                    $SQL = $SQL . "Placnik,";
                    $SQL = $SQL . "PlacnikNaslov,";
                    $SQL = $SQL . "PlacnikKontakt,";
                    $SQL = $SQL . "SolskiOkolis,";
                    $SQL = $SQL . "Opombe";
                    $SQL = $SQL . ") VALUES (";
                    $SQL = $SQL . $ucenec.","; 
                    $SQL = $SQL . "'".$VPriimek . "',"; 
                    $SQL = $SQL . "'".$VIme . "',"; 
                    $SQL = $SQL . "'".$VDatRoj->format('Y-m-d') . "',"; 
                    $SQL = $SQL . "'".$VNaslov . "',"; 
                    $SQL = $SQL . $VPosta . ",";
                    $SQL = $SQL . "'" . $VKraj . "',";
                    $SQL = $SQL . "'".$VNaslovZac . "',"; 
                    $SQL = $SQL . $VPostaZac . ",";
                    $SQL = $SQL . "'" . $VKrajZac . "',";
                    $SQL = $SQL . "'" . $VTelefonDoma . "',";
                    $SQL = $SQL . "'" . $VOce . "',";
                    $SQL = $SQL . "'" . $VMati . "',"; 
                    $SQL = $SQL . $VLetoRoj . ",";
                    $SQL = $SQL . "'".$VSpol."',";
                    $SQL = $SQL . $VKrajBivanja.",";
                    $SQL = $SQL . $VPosebnePotrebe.",";
                    $SQL = $SQL . $VAktivnost.",";
                    $SQL = $SQL . "'".$VKrajRoj."',";
                    $SQL = $SQL . "'" .$VDrzavaRoj."',";
                    $SQL = $SQL . "'".$Vemso."',";
                    $SQL = $SQL . "'".$VMaticniList."',";
                    $SQL = $SQL . "'".$VMaticnaKnjiga."',";
                    $SQL = $SQL . "'".$VDrzavljanstvo."',";
                    $SQL = $SQL . $VBivanje. ",";
                    $SQL = $SQL . $VRom.",";
                    $SQL = $SQL . "'".$VOceNaslov."',";
                    $SQL = $SQL . "'".$VOceZacNasl."',";
                    $SQL = $SQL . "'".$VOceKontakt."',";
                    $SQL = $SQL . "'".$VOceGSM."',";
                    $SQL = $SQL . "'".$VOceSluzba."',";
                    $SQL = $SQL . "'".$VOceEmail."',";
                    $SQL = $SQL . "'".$VMatiNaslov."',";
                    $SQL = $SQL . "'".$VMatiZacNasl."',";
                    $SQL = $SQL . "'".$VMatiKontakt."',";
                    $SQL = $SQL . "'".$VMatiGSM."',";
                    $SQL = $SQL . "'".$VMatiSluzba."',";
                    $SQL = $SQL . "'".$VMatiEmail."',";
                    $SQL = $SQL . "'".$VZacSolanja."',";
                    $SQL = $SQL . "'".$VKonSolanja."',";
                    $SQL = $SQL . "'".$VZacSolanjaSola."',";
                    $SQL = $SQL . "'".$VKonSolanjaSola."',";
                    $SQL = $SQL . "'".$VSkrbniki."',";
                    $SQL = $SQL . "'".$VSkrbnikiNaslov."',";
                    $SQL = $SQL . "'".$VSkrbnikiKontakt."',";
                    $SQL = $SQL . "'".$VSkrbnikiEmail."',";
                    $SQL = $SQL . "'".$VPlacnik."',";
                    $SQL = $SQL . "'".$VPlacnikNaslov."',";
                    $SQL = $SQL . "'".$VPlacnikKontakt."',";
                    $SQL = $SQL . "'".$VSolskiOkolis."',";
                    $SQL = $SQL . "'".$VOpombe."'";
                    $SQL = $SQL . ")";
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu podatkov učenca!<br />$SQL<br />");
                    }

                    //Izpis osebnih podatkov
                    $SQL = "SELECT * FROM tabucenci WHERE IdUcenec=".$ucenec;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        if ($R["Spol"]=="M"){
                            echo "<h2>Vpisali ste podatke za učenca:</h2>";
                        }else{
                            echo "<h2>Vpisali ste podatke za učenko:</h2>";
                        }
                        $DatRoj=new DateTime($R["DatRoj"]);
                        echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $DatRoj->format('d.m.Y') . "</b><br />";
                        echo "<br /><a href='ucenec.php?id=3&ucenec=".$R["IdUcenec"]."'>Popravi podatke učenca</a><br />";
                        echo "<a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"]."'>Na pregled učenca</a><br />";
                        if ($VLevel > 2){
                            echo "<a href='ucenec.php?id=5&ucenec=".$R["IdUcenec"]."'>Dokončno briši učenca iz baze</a><br />";
                        }
                    }
                }
                break;
            case "3": //obrazec za popravljanje podatkov učenca
                if (isset($_POST["ucenec"])){
                    $ucenec = $_POST["ucenec"];
                }else{
                    if (isset($_GET["ucenec"])){
                        $ucenec=$_GET["ucenec"];
                    }else{
                        $ucenec = 0;
                    }
                }
                
                if ($VLevel > 1){
                    echo "<form name='ucenci1' method='post' action='ucenec.php'>";
                    echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                    $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                    $SQL .= "WHERE tabrazred.leto=$VLeto ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);

                    echo "<br />Učenec: <select name='ucenec' onchange='this.form.submit()'>";
                    echo "<option value='0'>Ni izbran</option>";
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        if ($ucenec==$R["iducenec"] ){
                            echo "<option value='".$R["iducenec"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]." - ".$R["razred"].". ".$R["paralelka"]."</option>";
                        }else{
                            echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"]." - ".$R["razred"].". ".$R["paralelka"]."</option>";
                        }
                        $Indx=$Indx+1;
                    }
                    echo "</select>";
                    echo "<input name='id' type='hidden' value='3'>";
                    //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                    //echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form>";
                }
                
                //'Izpis osebnih podatkov
                $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    if ($VLevel > 1 ){
                        echo "<br /><a href='ucenec.php?id=5&ucenec=".$R["IdUcenec"]."'>Dokončno briši učenca iz baze</a><br />";
                    }
                    echo "<h2>Popravi podatke o učencu:</h2>";
                    
                    echo "<form accept-charset='utf-8' name='popraviucenca' method='post' action='ucenec.php'>";
                    echo "<table>";
                    echo "<tr><td><input type='hidden' name='ucenec' value='".$R["IdUcenec"]."'>Priimek: </td><td><input name='priimek' type='text' size='25' value='" . $R["Priimek"]  . "'></td></tr>";
                    echo "<tr><td>Ime: </td><td><input name='ime' type='text' size='25' value='" . $R["Ime"]  . "'></td></tr>";
                    echo "<tr><td>Spol:</td><td><select name='spol'><option selected>".$R["Spol"]."</option><option>M</option><option>F</option></select></td></tr>";
                    $VDatRoj=new DateTime($R["DatRoj"]);
                    echo "<tr><td>Datum rojstva: </td><td><input name='datroj' type='text' size='10' value='" . $VDatRoj->format('d.m.Y')  . "' id='dat01'></td></tr>";
                    echo "<tr><td>Kraj rojstva: </td><td><input name='krajroj' type='text' size='40' value='" . $R["KrajRoj"]  . "'></td></tr>";
                    echo "<tr><td>Država rojstva: </td><td><input name='drzavaroj' type='text' size='40' value='" . $R["DrzavaRoj"]  . "'></td></tr>";
                    echo "<tr><td>Državljanstvo: </td><td><input name='drzavljanstvo' type='text' size='25' value='" . $R["Drzavljanstvo"]  . "'></td></tr>";
                    echo "<tr><td>EMŠO: </td><td><input name='emso' type='text' size='15' value='" . $R["emso"]  . "'></td></tr>";
                    echo "<tr><td>Matični list: </td><td><input name='maticnilist' type='text' size='10' value='" . $R["MaticniList"]  . "'></td></tr>";
                    echo "<tr><td>Matična knjiga: </td><td><input name='maticnaknjiga' type='text' size='10' value='" . $R["MaticnaKnjiga"]  . "'></td></tr>";
                    
                    echo "<tr><td>Naslov: </td><td><input name='naslov' type='text' size='40' value='" . $R["Naslov"]  . "'></td></tr>";
                    echo "<tr><td>Pošta: </td><td><input name='posta' type='text' size='5' value='" . $R["Posta"]  . "'></td></tr>";
                    echo "<tr><td>Kraj: </td><td><input name='kraj' type='text' size='25' value='" . $R["Kraj"]  . "'></td></tr>";
                    //'začasno bivališče
                    echo "<tr><td>Naslov začasnega bivališča: </td><td><input name='naslovzac' type='text' size='40' value='" . $R["NaslovZac"]  . "'></td></tr>";
                    echo "<tr><td>Pošta začasnega bivališča: </td><td><input name='postazac' type='text' size='5' value='" . $R["PostaZac"]  . "'></td></tr>";
                    echo "<tr><td>Kraj začasnega bivališča: </td><td><input name='krajzac' type='text' size='25' value='" . $R["KrajZac"]  . "'></td></tr>";

                    echo "<tr><td>Telefon doma</td><td><input name='telefondoma' type='text' size='30' value='" . $R["TelefonDoma"]  . "'></td></tr>";

                    echo "<tr><td>Oče</td><td><input name='oce' type='text' size='30' value='" . $R["oce"]  . "'></td></tr>";
                    echo "<tr><td>Očetov naslov</td><td><input name='ocenaslov' type='text' size='30' value='" . $R["ocenaslov"]  . "'></td></tr>";
                    if (isset($R["ocezacnasl"])){
                        echo "<tr><td>Očetov začasni naslov</td><td><input name='ocezacnasl' type='text' size='30' value='" . $R["ocezacnasl"]  . "'></td></tr>";
                    }else{
                        echo "<tr><td>Očetov začasni naslov</td><td><input name='ocezacnasl' type='text' size='30' value=''></td></tr>";
                    }
                    echo "<tr><td>Očetov telefon doma</td><td><input name='ocekontakt' type='text' size='30' value='" . $R["ocekontakt"]  . "'></td></tr>";
                    echo "<tr><td>Očetov GSM</td><td><input name='ocegsm' type='text' size='30' value='" . $R["oceGSM"]  . "'></td></tr>";
                    echo "<tr><td>Očetov službeni telefon</td><td><input name='ocesluzba' type='text' size='30' value='" . $R["oceSluzba"]  . "'></td></tr>";
                    echo "<tr><td>Očetov e-mail</td><td><input name='oceemail' type='text' size='30' value='" . $R["oceemail"]  . "'></td></tr>";

                    echo "<tr><td>Mati</td><td><input name='mati' type='text' size='30' value='" . $R["mati"]  . "'></td></tr>";
                    echo "<tr><td>Materin naslov</td><td><input name='matinaslov' type='text' size='30' value='" . $R["matinaslov"]  . "'></td></tr>";
                    if (isset($R["matizacnasl"])){
                        echo "<tr><td>Materin začasni naslov</td><td><input name='matizacnasl' type='text' size='30' value='" . $R["matizacnasl"]  . "'></td></tr>";
                    }else{
                        echo "<tr><td>Materin začasni naslov</td><td><input name='matizacnasl' type='text' size='30' value=''></td></tr>";
                    }
                    echo "<tr><td>Materin telefon doma</td><td><input name='matikontakt' type='text' size='30' value='" . $R["matikontakt"]  . "'></td></tr>";
                    echo "<tr><td>Materin GSM</td><td><input name='matigsm' type='text' size='30' value='" . $R["matiGSM"]  . "'></td></tr>";
                    echo "<tr><td>Materin službeni telefon</td><td><input name='matisluzba' type='text' size='30' value='" . $R["matiSluzba"]  . "'></td></tr>";
                    echo "<tr><td>Materin e-mail</td><td><input name='matiemail' type='text' size='30' value='" . $R["matiemail"]  . "'></td></tr>";

                    echo "<tr><td>Skrbnik</td><td><input name='skrbniki' type='text' size='30' value='" . $R["Skrbniki"]  . "'></td></tr>";
                    echo "<tr><td>Naslov skrbnika</td><td><input name='skrbnikinaslov' type='text' size='30'  value='" . $R["SkrbnikiNaslov"]  . "'></td></tr>";
                    echo "<tr><td>Telefon skrbnika</td><td><input name='skrbnikikontakt' type='text' size='30'  value='" . $R["SkrbnikiKontakt"]  . "'></td></tr>";
                    echo "<tr><td>Kontaktni e-mail skrbnika</td><td><input name='skrbnikiemail' type='text' size='30'  value='" . $R["SkrbnikiEmail"]  . "'></td></tr>";

                    echo "<tr><td>Plačnik</td><td><input name='placnik' type='text' size='30' value='" . $R["Placnik"]  . "'></td></tr>";
                    echo "<tr><td>Naslov plačnika</td><td><input name='placniknaslov' type='text' size='30' value='" . $R["PlacnikNaslov"]  . "'></td></tr>";
                    echo "<tr><td>Telefon plačnika</td><td><input name='placnikkontakt' type='text' size='30' value='" . $R["PlacnikKontakt"]  . "'></td></tr>";
                    
                    echo "<tr><td>Datum začetka šolanja</td><td><input name='zacsolanja' type='text' size='10' value='".$R["ZacSolanja"]."' id='dat02'></td></tr>";
                    echo "<tr><td>Datum zaključka šolanja</td><td><input name='konsolanja' type='text' size='10' value='".$R["KonSolanja"]."' id='dat03'></td></tr>";
                    echo "<tr><td>Datum začetka šolanja na šoli</td><td><input name='zacsolanjasola' type='text' size='10' value='".$R["ZacSolanjaSola"]."' id='dat04'></td></tr>";
                    echo "<tr><td>Datum zaključka šolanja na šoli</td><td><input name='konsolanjasola' type='text' size='10' value='".$R["KonSolanjaSola"]."' id='dat05'></td></tr>";

                    echo "<tr><td>Opombe</td><td><textarea name='opombe' cols='40' rows='3'>".$R["Opombe"]."</textarea></td></tr>";
                    
                    $VAktivnost=$R["Aktivnost"];
                    $VPosebnePotrebe=$R["IdPosebnePotrebe"];
                    $VKrajBivanja=$R["IdKrajBivanja"];
                    $VBivanje=$R["Bivanje"];
                    $VRom=$R["Rom"];
                    $VSolskiOkolis=$R["SolskiOkolis"];
                    
                    echo "<tr><td>Prihajanje v šolo</td><td>";
                    echo "<select name='krajbivanja'>";
                    
                    $SQL = "SELECT * FROM tabkrajbivanja";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["Id"]==$VKrajBivanja ){
                            echo "<option selected='selected' value='".$R["Id"]."'>".$R["KrajBivanja"]."</option>";
                        }else{
                            echo "<option value='".$R["Id"]."'>".$R["KrajBivanja"]."</option>";
                        }
                    }

                    echo "</select></td></tr>";

                    echo "<tr><td>Posebne potrebe</td><td>";
                    echo "<select name='posebnepotrebe'>";
                    
                    $SQL = "SELECT * FROM tabposebnepotrebe";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["IdPosebnePotrebe"]==$VPosebnePotrebe ){
                            echo "<option selected value='".$R["IdPosebnePotrebe"]."'>".$R["OpisPosebnePotrebe"]."</option>";
                        }else{
                            echo "<option value='".$R["IdPosebnePotrebe"]."'>".$R["OpisPosebnePotrebe"]."</option>";
                        }
                    }
                    
                    echo "</select></td></tr>";

                    echo "<tr><td>Bivanje</td><td>";
                    echo "<select name='bivanje'>";
                    
                    $SQL = "SELECT * FROM tabbivanje";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["idBivanje"]==$VBivanje ){
                            echo "<option selected='selected' value='".$R["idBivanje"]."'>".$R["Bivanje"]."</option>";
                        }else{
                            echo "<option value='".$R["idBivanje"]."'>".$R["Bivanje"]."</option>";
                        }
                    }

                    echo "</select></td></tr>";
                    
                    if ($VRom==0 ){
                        echo "<tr><td>Učenec je rom</td><td><input name='rom' type='checkbox'></td></tr>";
                    }else{
                        echo "<tr><td>Učenec je rom</td><td><input name='rom' type='checkbox' checked></td></tr>";
                    }
                    
                    echo "<tr><td>Šolski okoliš</td><td><input name='solskiokolis' type='text' size='30' value='" . $VSolskiOkolis  . "'><br />";
                    echo "<select name='solskiokolis1'>";
                    echo "<option value='0'>Domač</option>";
                    $SQL = "SELECT naziv,obcina FROM tabzavodi ORDER BY obcina,naziv";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($VSolskiOkolis == $R1["naziv"]){
                        echo "<option value='".$R1["naziv"]."' selected='selected'>".$R1["obcina"]." - ".$R1["naziv"]."</option>";
                    }else{
                        echo "<option value='".$R1["naziv"]."'>".$R1["obcina"]." - ".$R1["naziv"]."</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td></tr>";
                    
                    echo "<tr><td>Status</td><td>";
                    echo "<select name='aktivnost'>";
                    
                    $SQL = "SELECT * FROM tabaktivnostucenca";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["Id"]==$VAktivnost ){
                            echo "<option selected='selected' value='".$R["Id"]."'>".$R["AktivnostUcenca"]."</option>";
                        }else{
                            echo "<option value='".$R["Id"]."'>".$R["AktivnostUcenca"]."</option>";
                        }
                    }
                    echo "</select></td></tr>";

                    echo "</table>";
                    echo "<input name='id' type='hidden' value='4'>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form>";
                }
                break;
              case "4": //vpis popravkov
                $ucenec =  $_POST["ucenec"];

                $VPriimek=$_POST["priimek"];
                $VIme=$_POST["ime"];
                $VNaslov=$_POST["naslov"];
                $VPosta=$_POST["posta"];
                $VKraj=$_POST["kraj"];
                $VNaslovZac=$_POST["naslovzac"];
                $VPostaZac=$_POST["postazac"];
                $VKrajZac=$_POST["krajzac"];
                $VSpol=$_POST["spol"];
                $Vemso=$_POST["emso"];
                if (isDate($_POST["datroj"])){
                    $VDatRoj=new DateTime(isDate($_POST["datroj"]));
                }else{
                    if (strlen($Vemso) > 0){
                        //datum rojstva prebere iz emšo številke
                        $VDatRoj="-".substr($$_POST["emso"],2,2) . "-".substr($_POST["emso"],0,2);
                        if (intval(substr($_POST["emso"],4,3)) < 900 ){
                            $VDatRoj="2".substr($_POST["emso"],4,3).$VDatRoj;
                        }else{
                            $VDatRoj="1".substr($_POST["emso"],4,3).$VDatRoj;
                        }
                        $VDatRoj= new DateTime($VDatRoj);
                    }else{
                        //če ni vpisan, uporabi aktualni datum
                        $VDatRoj=new DateTime("now");
                    }
                }
                $VOce=$_POST["oce"];
                $VMati=$_POST["mati"];
                $VLetoRoj=$VDatRoj->format('Y');
                $VPosebnePotrebe= $_POST["posebnepotrebe"];
                $VAktivnost= $_POST["aktivnost"];
                $VKrajBivanja= $_POST["krajbivanja"];
                $VKrajRoj=$_POST["krajroj"];
                $VDrzavaRoj=$_POST["drzavaroj"];
                $VDrzavljanstvo=$_POST["drzavljanstvo"];
                $VMaticniList=$_POST["maticnilist"];
                $VMaticnaKnjiga=$_POST["maticnaknjiga"];
                $VTelefonDoma=$_POST["telefondoma"];
                $VOceNaslov=$_POST["ocenaslov"];
                $VOceZacNasl=$_POST["ocezacnasl"];
                $VOceKontakt=$_POST["ocekontakt"];
                $VOceGSM=$_POST["ocegsm"];
                $VOceSluzba=$_POST["ocesluzba"];
                $VOceEmail=$_POST["oceemail"];
                $VMatiNaslov=$_POST["matinaslov"];
                $VMatiZacNasl=$_POST["matizacnasl"];
                $VMatiKontakt=$_POST["matikontakt"];
                $VMatiGSM=$_POST["matigsm"];
                $VMatiSluzba=$_POST["matisluzba"];
                $VMatiEmail=$_POST["matiemail"];
                if (isset($_POST["rom"])){
                    $VRom=1;
                }else{
                    $VRom=0;
                }
                $VBivanje=$_POST["bivanje"];
                $VZacSolanja=$_POST["zacsolanja"];
                $VKonSolanja=$_POST["konsolanja"];
                $VZacSolanjaSola=$_POST["zacsolanjasola"];
                $VKonSolanjaSola=$_POST["konsolanjasola"];
                $VSkrbniki=$_POST["skrbniki"];
                $VSkrbnikiNaslov=$_POST["skrbnikinaslov"];
                $VSkrbnikiKontakt=$_POST["skrbnikikontakt"];
                $VSkrbnikiEmail=$_POST["skrbnikiemail"];
                $VPlacnik=$_POST["placnik"];
                $VPlacnikNaslov=$_POST["placniknaslov"];
                $VPlacnikKontakt=$_POST["placnikkontakt"];
                $VOpombe=$_POST["opombe"];
                if ($_POST["solskiokolis1"] != '0'){
                    $VSolskiOkolis=$_POST["solskiokolis1"];
                }else{
                    $VSolskiOkolis=$_POST["solskiokolis"];
                }

                If (strlen($VPosta)==0 ){ 
                    $VPosta=0;
                }
                If (strlen($VPostaZac)==0 ){ 
                    $VPostaZac=0;
                }

                $SQL = "UPDATE tabucenci SET  ";
                $SQL = $SQL . "Drzavljanstvo='".$VDrzavljanstvo."',";
                $SQL = $SQL . "Priimek='".$VPriimek."',";
                $SQL = $SQL . "Ime='".$VIme."',";
                $SQL = $SQL . "DatRoj='".$VDatRoj->format('Y-m-d')."',";
                $SQL = $SQL . "Naslov='".$VNaslov."',";
                $SQL = $SQL . "Posta=".$VPosta . ",";
                $SQL = $SQL . "Kraj='".$VKraj."',";
                $SQL = $SQL . "NaslovZac='".$VNaslovZac."',";
                $SQL = $SQL . "PostaZac=".$VPostaZac . ",";
                $SQL = $SQL . "KrajZac='".$VKrajZac."',";
                $SQL = $SQL . "TelefonDoma='".$VTelefonDoma."',";
                $SQL = $SQL . "Oce='".$VOce."',";
                $SQL = $SQL . "Mati='".$VMati."',";
                $SQL = $SQL . "LetoRoj=".$VLetoRoj.",";
                $SQL = $SQL . "IdKrajBivanja=".$VKrajBivanja.",";
                $SQL = $SQL . "IdPosebnePotrebe=".$VPosebnePotrebe .",";
                $SQL = $SQL . "Aktivnost=".$VAktivnost.",";
                $SQL = $SQL . "Spol='".$VSpol."',";
                $SQL = $SQL . "KrajRoj='".$VKrajRoj."' ,";
                $SQL = $SQL . "DrzavaRoj='".$VDrzavaRoj."',";
                $SQL = $SQL . "emso='".$Vemso."',";
                $SQL = $SQL . "MaticniList='".$VMaticniList."',";
                $SQL = $SQL . "MaticnaKnjiga='".$VMaticnaKnjiga."',";
                $SQL = $SQL . "bivanje=".$VBivanje.",";
                $SQL = $SQL . "rom=".$VRom.",";
                $SQL = $SQL . "OceNaslov='".$VOceNaslov."',";
                $SQL = $SQL . "ocezacnasl='".$VOceZacNasl."',";
                $SQL = $SQL . "ocekontakt='".$VOceKontakt."',";
                $SQL = $SQL . "oceGSM='".$VOceGSM."',";
                $SQL = $SQL . "oceSluzba='".$VOceSluzba."',";
                $SQL = $SQL . "matinaslov='".$VMatiNaslov."',";
                $SQL = $SQL . "matizacnasl='".$VMatiZacNasl."',";
                $SQL = $SQL . "matikontakt='".$VMatiKontakt."',";
                $SQL = $SQL . "matiGSM='".$VMatiGSM."',";
                $SQL = $SQL . "matiSluzba='".$VMatiSluzba."',";
                $SQL = $SQL . "ZacSolanja='".$VZacSolanja."',";
                $SQL = $SQL . "KonSolanja='".$VKonSolanja."',";
                $SQL = $SQL . "ZacSolanjaSola='".$VZacSolanjaSola."',";
                $SQL = $SQL . "KonSolanjaSola='".$VKonSolanjaSola."',";
                $SQL = $SQL . "skrbniki='".$VSkrbniki."',";
                $SQL = $SQL . "skrbnikinaslov='".$VSkrbnikiNaslov."',";
                $SQL = $SQL . "skrbnikikontakt='".$VSkrbnikiKontakt."',";
                $SQL = $SQL . "oceemail='".$VOceEmail."',";
                $SQL = $SQL . "matiemail='".$VMatiEmail."',";
                $SQL = $SQL . "skrbnikiemail='".$VSkrbnikiEmail."',";
                $SQL = $SQL . "placnik='".$VPlacnik."',";
                $SQL = $SQL . "placniknaslov='".$VPlacnikNaslov."',";
                $SQL = $SQL . "placnikkontakt='".$VPlacnikKontakt."',";
                $SQL = $SQL . "SolskiOkolis='".$VSolskiOkolis."',";
                $SQL = $SQL . "opombe='".$VOpombe."'";
                $SQL = $SQL . " WHERE IdUcenec=".$ucenec;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu podatkov učenca!<br />$SQL<br />");
                }
                
                //'Izpis osebnih podatkov
                $SQL = "SELECT * FROM tabucenci WHERE iducenec=" . $ucenec;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    if ($R["Spol"]=="M"){
                        echo "<h2>Popravili ste podatke za učenca:</h2>";
                    }else{
                        echo "<h2>Popravili ste podatke za učenko:</h2>";
                    }
                    $DatRoj=new DateTime($R["DatRoj"]);
                    echo "Ime: <b>" . $R["Priimek"]  . ", " . $R["Ime"] . "</b>, Datum rojstva: <b>" . $DatRoj->format('d.m.Y') . "</b><br />";
                    echo "<br /><a href='ucenec.php?id=3&ucenec=".$R["IdUcenec"]."'>Popravi podatke učenca</a><br />";
                    echo "<a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"]."'>Na pregled učenca</a><br />";
                    if ($VLevel > 2){
                        echo "<a href='ucenec.php?id=5&ucenec=".$R["IdUcenec"]."'>Dokončno briši učenca iz baze</a><br />";
                    }
                    if (isset($_SESSION["razred"])){
                        echo "<a href='izpisrazreda.php?razred=".$_SESSION["razred"]."&solskoleto=".$VLeto."'>Na izpis razreda</a><br />";
                    }
                    
                    if (isset($_SESSION["razred"])){
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                        $SQL = $SQL . " WHERE idrazred=".$_SESSION["razred"]." ORDER BY priimek,ime";
                    }else{
                        $SQL = "SELECT tabrazred.idrazred,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred ";
                            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL = $SQL . " WHERE idrazred=".$R["idrazred"]." ORDER BY priimek,ime";
                        }else{
                            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazdat ";
                            $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL = $SQL . " WHERE idrazred=0 ORDER BY priimek,ime";
                        }
                    }
                    $result = mysqli_query($link,$SQL);
                    $Indx=1;
                    $izbrani=0;
                    if ($result){
                        while ($R = mysqli_fetch_array($result)){
                            $idUcenec[$Indx][0]=$R["iducenec"];
                            $idUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                            if ($R["iducenec"]==$ucenec){
                                $izbrani=$Indx;
                            }
                            $Indx=$Indx+1;
                        }
                        $vseh=$Indx-1;
			            if (isset($idUcenec)){
				            switch ($izbrani){
					            case 1:
						            echo "<a href='izborrazreda.php'>Izberi razred</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani+1][0]."'> Naslednji (".$idUcenec[$izbrani+1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$vseh][0]."'> Zadnji (".$idUcenec[$vseh][1].")</a><br />";
						            break;
					            case $vseh:
                                    if ($vseh > 1){
						                echo "<a href='ucenec_pregled.php?ucenec=".$idUcenec[1][0]."'> Prvi (".$idUcenec[1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani-1][0]."'>Prejšnji (".$idUcenec[$izbrani-1][1].")</a> | <a href='izborrazreda.php'>Izberi razred</a><br />";
                                    }
						            break;
					            default:
                                    if ($vseh > 1){
						                echo "<a href='ucenec_pregled.php?ucenec=".$idUcenec[1][0]."'> Prvi (".$idUcenec[1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani-1][0]."'>Prejšnji (".$idUcenec[$izbrani-1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$izbrani+1][0]."'>Naslednji (".$idUcenec[$izbrani+1][1].")</a> | <a href='ucenec_pregled.php?ucenec=".$idUcenec[$vseh][0]."'> Zadnji (".$idUcenec[$vseh][1].")</a><br />";
                                    }
				            }
			            }
                    }
                }
                break;
             case "5": //brisanje učenca
                if (isset($_POST["potrditev"])){
                    $ucenec = $_POST["ucenec"];
                    if (!CheckDostop("ImpExUc",$VUporabnik) ) {
                        header("Location: nepooblascen.htm");
                    }else{

                        $SQL = "DELETE FROM tabucenci WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele učencev!<br />";
                        }

                        $SQL = "DELETE FROM tabrazred WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz razrednih tabel!<br />";
                        }
                        $SQL = "DELETE FROM tabkrozekclan WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabel interesnih dejavnosti!<br />";
                        }

                        $SQL = "DELETE FROM tabnatecajclan WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabel natečajev!<br />";
                        }

                        $SQL = "DELETE FROM tabocene WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele ocen!<br />";
                        }

                        $SQL = "DELETE FROM tabopocene WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele opisnih ocen!<br />";
                        }

                        $SQL = "DELETE FROM tabplavanje WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele plavanja!<br />";
                        }

                        $SQL = "DELETE FROM tabprehrana WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele prehrane!<br />";
                        }

                        $SQL = "DELETE FROM tabmalica WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele malice!<br />";
                        }

                        $SQL = "DELETE FROM tabprisotnost WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele prisotnosti!<br />";
                        }

                        $SQL = "DELETE FROM tabsstclan WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabel šolskih športnih tekmovanj!<br />";
                        }

                        $SQL = "DELETE FROM tabopb WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele OPB!<br />";
                        }

                        $SQL = "DELETE FROM tabtabori WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele taborov!<br />";
                        }

                        $SQL = "DELETE FROM tabtekmovanja WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele tekmovanj!<br />";
                        }

                        $SQL = "DELETE FROM tabvzgukrepi WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele vzgojnih ukrepov!<br />";
                        }

                        $SQL = "DELETE FROM tabdodpouk WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele dodatnega pouka!<br />";
                        }

                        $SQL = "DELETE FROM tabdrtekmclan WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele drugih tekmovanj!<br />";
                        }

                        $SQL = "DELETE FROM tabgovorilne WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele govorilnih ur!<br />";
                        }

                        $SQL = "DELETE FROM tabip WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele individualnih programov!<br />";
                        }

                        $SQL = "DELETE FROM tabizbirni WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele izbirnih predmetov!<br />";
                        }

                        $SQL = "DELETE FROM tabnivoji WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele nivojskih predmetov!<br />";
                        }

                        $SQL = "DELETE FROM tabkontrolkaucenec WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele kontrolnih nalog!<br />";
                        }

                        $SQL = "DELETE FROM tabnadarjeni WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele nadarjenih!<br />";
                        }

                        $SQL = "DELETE FROM tabnpz WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele NPZ!<br />";
                        }

                        $SQL = "DELETE FROM tabnpz6 WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele NPZ6!<br />";
                        }

                        $SQL = "DELETE FROM tabnpzocene WHERE idUcenec=".$ucenec;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "<br />Učenec je bil izbrisan iz tabele NPZ ocene!<br />";
                        }
                    }
                }else{
                    echo "<br />";
                    if (isset($_POST["ucenec"])){
                        echo "<h2>Učenec ni bil izbrisan!</h2>";
                    }else{
                        $ucenec = $_GET["ucenec"];
                        $SQL = "SELECT priimek,ime,spol FROM tabucenci WHERE iducenec=$ucenec";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<form accept-charset='utf-8' name='brisi' method='post' action='ucenec.php'>";
                            echo "<input name='potrditev' type='checkbox'>";
                            if ($R["spol"] == "M"){
                                echo " Učenec: ".$R["ime"]." ".$R["priimek"]." bo dokončno odstranjen iz baze (nepovratno)! ";
                            }else{
                                echo " Učenka: ".$R["ime"]." ".$R["priimek"]." bo dokončno odstranjena iz baze (nepovratno)! ";
                            }
                            echo "<input name='ucenec' type='hidden' value='$ucenec'>";
                            echo "<input name='id' type='hidden' value='5'>";
                            echo "<input name='submit' type='submit' value='Pošlji'>";
                            echo "</form>";
                        }
                    }
                }
        }     
        echo "<br /><a href='izborucenca.php'>Na izbor učencev</a><br />";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>

</body>
</html>
