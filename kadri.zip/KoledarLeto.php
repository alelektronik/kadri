<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Realizacija
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

function ToMesec($n){
    switch ($n){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("DelPregl",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = "0";
        }
    }
    switch ($Vid){
        case "0":
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
            for ($VLeto=$ActualYear-1;$VLeto <= $ActualYear+2;$VLeto++){
                $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto." ORDER BY leto,mesec,dan";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                $ProstiDnevi=0;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    $Praznik[$Indx][1]=$R["kat"];
                    if ($Praznik[$Indx][1]==1){
                        $ProstiDnevi=$ProstiDnevi+1;
                    }
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;

                if (($VLeto) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                echo "<h2>Koledar za leto ".$VLeto."</h2>";
                echo "<table border=1>";
                echo "<tr><th></th>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    echo "<th>".$Indx."</th>";
                }
                echo "</tr>";
                for ($Indx=1;$Indx<= 12;$Indx++){
                    echo "<tr><td>".$Indx."</td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7:
                                switch (CheckPraznik($Datum)){
                                    case 1: //praznik
                                        echo "<td align='center' width='20' bgcolor=lightgreen><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                        break;
                                    case 3:  //delovna sobota
                                        echo "<td align='center' width='20'><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                        break;
                                    default: //delovni dan
                                        echo "<td align='center' width='20' bgcolor=lightsalmon><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                }
                                break;
                            default:
                                switch (CheckPraznik($Datum)){
                                    case 1: //praznik
                                        echo "<td align='center' width='20' bgcolor=lightgreen><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                        break;
                                    case 2:  //počitnice
                                        echo "<td align='center' width='20' bgcolor=lightblue><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                        break;
                                    case 4:  //dela prost dan
                                        echo "<td align='center' width='20' bgcolor=khaki><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                        break;
                                    default: //delovni dan
                                        echo "<td align='center' width='20'><a href='KoledarLeto.php?id=1&kleto=".$VLeto."&kmesec=".$Indx."&kdan=".$Indx1."'>&nbsp;</a></td>";
                                }
                        }
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
            }

            for ($VLeto=$ActualYear;$VLeto <= $ActualYear+1;$VLeto++){
	            echo "<h2>Koledar za leto ".$VLeto."</h2>";
                if (($VLeto) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }
	            for ($Indx=1;$Indx <= 12;$Indx++){
		            echo ToMesec($Indx)."<br />";
		            echo "<table border=1>";
		            echo "<tr>";
		            for ($i1=0;$i1 <= 6;$i1++){
			            echo "<th>".Int2Dan($i1)."</th>";
		            }
		            echo "</tr>";
		            echo "<tr>";
                    $Datum=new DateTime($VLeto."-".$Indx."-1");
		            for ($i1=1;$i1 < $Datum->format('w')+1;$i1++){ 
			            echo "<td>&nbsp;</td>";
		            }
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
			            switch ($Datum->format('w')+1){
				            case 1:
					            echo "<tr><td bgcolor=lightsalmon>".$Indx1."</td>";
                                break;
				            case 7;
					            echo "<td bgcolor=lightsalmon>".$Indx1."</td></tr>";
                                break;
				            default:
					            echo "<td>".$Indx1."</td>";
			            }
                    }
		            if ($Datum->format('w') != 6){
			            echo "</tr>";
		            }
		            echo "</table><br />";
	            }
            }
            break;
    case "1": //vnos lastnosti dneva
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        
        echo "<br />";
        echo "<form name='form_OpisneOcene' method=post action='KoledarLeto.php'>";
        echo "<input name='id' type='hidden' value='2'>";
        echo "<input name='kleto' type='hidden' value='".$_GET["kleto"]."'>";
        echo "<input name='kmesec' type='hidden' value='".$_GET["kmesec"]."'>";
        echo "<input name='kdan' type='hidden' value='".$_GET["kdan"]."'>";
        $SQL = "SELECT opis,kat FROM tabpraznik WHERE leto=".$_GET["kleto"]." AND mesec=".$_GET["kmesec"]." AND dan=".$_GET["kdan"];
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VOpis=$R["opis"];
            $VKat=$R["kat"];
        }else{
            $VOpis="";
            $VKat=0;
        }
        
        echo $_GET["kdan"].".".$_GET["kmesec"].".".$_GET["kleto"].": <input name='opis' type='text' value='".$VOpis."'>";
        echo "<select name='kat'>";
        echo "<option value='0'>praznik</option>";
        echo "<option value='1'>počitnice</option>";
        echo "<option value='2'>delovni dan</option>";
        echo "<option value='3'>dela prost dan</option>";
        echo "<option value='4'>počitnice-ni obveza</option>";
        echo "</select><br />";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        break;
    case "2": //vpis lastnosti dneva
        if ($VLevel > 1){
            $SQL = "SELECT id FROM tabpraznik WHERE leto=".$_POST["kleto"]." AND mesec=".$_POST["kmesec"]." AND dan=".$_POST["kdan"];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $SQL = "UPDATE tabpraznik SET opis='".$_POST["opis"]."', kat=".$_POST["kat"]." WHERE id=".$R["id"];
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri popravljanju zapisa v koledarju!<br />$SQL<br />");
                }
            }else{
                $Datum=new DateTime($_POST["kleto"]."-".$_POST["kmesec"]."-".$_POST["kdan"]);
                $SQL = "INSERT INTO tabpraznik (datum,leto,mesec,dan,opis,kat,trajanje) VALUES (";
                $SQL .= "'".$Datum->format('Y-m-d')."',";
                $SQL .= $Datum->format('Y').",";
                $SQL .= $Datum->format('n').",";
                $SQL .= $Datum->format('j').",";
                $SQL .= "'".$_POST["opis"]."',";
                $SQL .= $_POST["kat"].",0";
                $SQL .= ")";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu v koledar!<br />$SQL<br />");
                }
            }
        }
        header("Location: KoledarLeto.php");
        break;
    }
}
?>
</body>
</html>