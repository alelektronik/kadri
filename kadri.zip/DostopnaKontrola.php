<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Dostopna kontrola
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if ($VLevel < 2) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
	case "1":
		for ($indx=1;$indx <= $_POST["StZapisov"];$indx++){
            if (strlen($_POST["ime_".$indx]) > 0){
			    $SQL = "SELECT * FROM TabDostop WHERE idUcitelj=".$_POST["ime_".$indx];
			    $result = mysqli_query($link,$SQL);
			    
			    if ($R = mysqli_fetch_array($result)){
				    $SQL = "UPDATE TabDostop SET ";
				    if (isset($_POST["VnosUcDat_".$indx])){
                        if ($_POST["VnosUcDat_".$indx]=="on"){
					        $SQL = $SQL . "VnosUcDat=true,";
                        }else{
                            $SQL = $SQL . "VnosUcDat=false,";
                        }
				    }else{
					    $SQL = $SQL . "VnosUcDat=false,";
				    }
				    if (isset($_POST["UpdUc_".$indx]) ) {
					    $SQL = $SQL . "UpdUc=true,";
				    }else{
					    $SQL = $SQL . "UpdUc=false,";
				    }
				    if (isset($_POST["Redov_".$indx]) ) {
					    $SQL = $SQL . "Redov=true,";
				    }else{
					    $SQL = $SQL . "Redov=false,";
				    }
				    if (isset($_POST["VnosNPZ_".$indx]) ) {
					    $SQL = $SQL . "VnosNPZ=true,";
				    }else{
					    $SQL = $SQL . "VnosNPZ=false,";
				    }
				    if (isset($_POST["ImpExNPZ_".$indx]) ) {
					    $SQL = $SQL . "ImpExNPZ=true,";
				    }else{
					    $SQL = $SQL . "ImpExNPZ=false,";
				    }
				    if (isset($_POST["DelPregl_".$indx]) ) {
					    $SQL = $SQL . "DelPregl=true,";
				    }else{
					    $SQL = $SQL . "DelPregl=false,";
				    }
				    if (isset($_POST["DelKontr_".$indx]) ) {
					    $SQL = $SQL . "DelKontr=true,";
				    }else{
					    $SQL = $SQL . "DelKontr=false,";
				    }
				    if (isset($_POST["UpdDel_".$indx]) ) {
					    $SQL = $SQL . "UpdDel=true,";
				    }else{
					    $SQL = $SQL . "UpdDel=false,";
				    }
				    if (isset($_POST["Tajn_".$indx]) ) {
					    $SQL = $SQL . "Tajn=true,";
				    }else{
					    $SQL = $SQL . "Tajn=false,";
				    }
				    if (isset($_POST["VnosSist_".$indx]) ) {
					    $SQL = $SQL . "VnosSist=true,";
				    }else{
					    $SQL = $SQL . "VnosSist=false,";
				    }
				    if (isset($_POST["VnosAktivi_".$indx]) ) {
					    $SQL = $SQL . "VnosAktivi=true,";
				    }else{
					    $SQL = $SQL . "VnosAktivi=false,";
				    }
				    if (isset($_POST["VnosUrnik_".$indx]) ) {
					    $SQL = $SQL . "VnosUrnik=true,";
				    }else{
					    $SQL = $SQL . "VnosUrnik=false,";
				    }
				    if (isset($_POST["VnosNadom_".$indx]) ) {
					    $SQL = $SQL . "VnosNadom=true,";
				    }else{
					    $SQL = $SQL . "VnosNadom=false,";
				    }
				    if (isset($_POST["inventura_".$indx]) ) {
					    $SQL = $SQL . "inventura=true,";
				    }else{
					    $SQL = $SQL . "inventura=false,";
				    }
				    if (isset($_POST["StatUc_".$indx]) ) {
					    $SQL = $SQL . "StatUc=true,";
				    }else{
					    $SQL = $SQL . "StatUc=false,";
				    }
				    if (isset($_POST["StatDel_".$indx]) ) {
					    $SQL = $SQL . "StatDel=true,";
				    }else{
					    $SQL = $SQL . "StatDel=false,";
				    }
				    if (isset($_POST["LetnPor_".$indx]) ) {
					    $SQL = $SQL . "LetnPor=true,";
				    }else{
					    $SQL = $SQL . "LetnPor=false,";
				    }
				    if (isset($_POST["Prehrana_".$indx]) ) {
					    $SQL = $SQL . "Prehrana=true,";
				    }else{
					    $SQL = $SQL . "Prehrana=false,";
				    }
				    if (isset($_POST["Prisotnost_".$indx]) ) {
					    $SQL = $SQL . "Prisotnost=true,";
				    }else{
					    $SQL = $SQL . "Prisotnost=false,";
				    }
				    if (isset($_POST["NovoSL_".$indx]) ) {
					    $SQL = $SQL . "NovoSL=true,";
				    }else{
					    $SQL = $SQL . "NovoSL=false,";
				    }
				    if (isset($_POST["ImpExUc_".$indx]) ) {
					    $SQL = $SQL . "ImpExUc=true,";
				    }else{
					    $SQL = $SQL . "ImpExUc=false,";
				    }
				    if (isset($_POST["DatSola_".$indx]) ) {
					    $SQL = $SQL . "DatSola=true,";
				    }else{
					    $SQL = $SQL . "DatSola=false,";
				    }
				    if (isset($_POST["Prazniki_".$indx]) ) {
					    $SQL = $SQL . "Prazniki=true,";
				    }else{
					    $SQL = $SQL . "Prazniki=false,";
				    }
				    if (isset($_POST["Prostori_".$indx]) ) {
					    $SQL = $SQL . "Prostori=true,";
				    }else{
					    $SQL = $SQL . "Prostori=false,";
				    }
				    if (isset($_POST["Predmeti_".$indx]) ) {
					    $SQL = $SQL . "Predmeti=true,";
				    }else{
					    $SQL = $SQL . "Predmeti=false,";
				    }
				    if (isset($_POST["TabEd_".$indx]) ) {
					    $SQL = $SQL . "TabEd=true,";
				    }else{
					    $SQL = $SQL . "TabEd=false,";
				    }
				    if (isset($_POST["RDU_".$indx]) ) {
					    $SQL = $SQL . "RDU=true,";
				    }else{
					    $SQL = $SQL . "RDU=false,";
				    }
				    if (isset($_POST["PreglZbirn_".$indx]) ) {
					    $SQL = $SQL . "PreglZbirn=true,";
				    }else{
					    $SQL = $SQL . "PreglZbirn=false,";
				    }
				    if (isset($_POST["PreglPoroc_".$indx]) ) {
					    $SQL = $SQL . "PreglPoroc=true,";
				    }else{
					    $SQL = $SQL . "PreglPoroc=false,";
				    }
				    if (isset($_POST["PreglReal_".$indx]) ) {
					    $SQL = $SQL . "PreglReal=true,";
				    }else{
					    $SQL = $SQL . "PreglReal=false,";
				    }
				    if (isset($_POST["drugo1_".$indx]) ) {
					    $SQL = $SQL . "drugo1=true,";
				    }else{
					    $SQL = $SQL . "drugo1=false,";
				    }
				    if (isset($_POST["drugo2_".$indx]) ) {
					    $SQL = $SQL . "drugo2=true,";
				    }else{
					    $SQL = $SQL . "drugo2=false,";
				    }
				    if (isset($_POST["drugo3_".$indx]) ) {
					    $SQL = $SQL . "drugo3=true,";
				    }else{
					    $SQL = $SQL . "drugo3=false,";
				    }
				    if (isset($_POST["drugo4_".$indx]) ) {
					    $SQL = $SQL . "drugo4=true,";
				    }else{
					    $SQL = $SQL . "drugo4=false,";
				    }
				    if (isset($_POST["drugo5_".$indx]) ) {
					    $SQL = $SQL . "drugo5=true,";
				    }else{
					    $SQL = $SQL . "drugo5=false,";
				    }
				    if (isset($_POST["drugo6_".$indx]) ) {
					    $SQL = $SQL . "drugo6=true,";
				    }else{
					    $SQL = $SQL . "drugo6=false,";
				    }
				    if (isset($_POST["drugo7_".$indx]) ) {
					    $SQL = $SQL . "drugo7=true,";
				    }else{
					    $SQL = $SQL . "drugo7=false,";
				    }
				    if (isset($_POST["drugo8_".$indx]) ) {
					    $SQL = $SQL . "drugo8=true,";
				    }else{
					    $SQL = $SQL . "drugo8=false,";
				    }
				    if (isset($_POST["drugo9_".$indx]) ) {
					    $SQL = $SQL . "drugo9=true ";
				    }else{
					    $SQL = $SQL . "drugo9=false ";
				    }
				    $SQL = $SQL . "WHERE id=".$R["id"];
				    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri popravku vpisa dostopnih pravic!<br />$SQL<br />");
                    }
			    }else{
				    $SQL = "INSERT INTO TabDostop (idUcitelj,";
				    $SQL = $SQL . "VnosUcDat,";
				    $SQL = $SQL . "UpdUc,";
				    $SQL = $SQL . "Redov,";
				    $SQL = $SQL . "VnosNPZ,";
				    $SQL = $SQL . "ImpExNPZ,";
				    $SQL = $SQL . "DelPregl,";
				    $SQL = $SQL . "DelKontr,";
				    $SQL = $SQL . "UpdDel,";
				    $SQL = $SQL . "Tajn,";
				    $SQL = $SQL . "VnosSist,";
				    $SQL = $SQL . "VnosAktivi,";
				    $SQL = $SQL . "VnosUrnik,";
				    $SQL = $SQL . "VnosNadom,";
				    $SQL = $SQL . "inventura,";
				    $SQL = $SQL . "StatUc,";
				    $SQL = $SQL . "StatDel,";
				    $SQL = $SQL . "LetnPor,";
				    $SQL = $SQL . "Prehrana,";
				    $SQL = $SQL . "Prisotnost,";
				    $SQL = $SQL . "NovoSL,";
				    $SQL = $SQL . "ImpExUc,";
				    $SQL = $SQL . "DatSola,";
				    $SQL = $SQL . "Prazniki,";
				    $SQL = $SQL . "Prostori,";
				    $SQL = $SQL . "Predmeti,";
				    $SQL = $SQL . "TabEd,";
				    $SQL = $SQL . "RDU,";
				    $SQL = $SQL . "PreglZbirn,";
				    $SQL = $SQL . "PreglPoroc,";
				    $SQL = $SQL . "PreglReal,";
				    $SQL = $SQL . "drugo1,";
				    $SQL = $SQL . "drugo2,";
				    $SQL = $SQL . "drugo3,";
				    $SQL = $SQL . "drugo4,";
				    $SQL = $SQL . "drugo5,";
				    $SQL = $SQL . "drugo6,";
				    $SQL = $SQL . "drugo7,";
				    $SQL = $SQL . "drugo8,";
				    $SQL = $SQL . "drugo9";
				    $SQL = $SQL . ") VALUES (".$_POST["ime_".$indx].",";
				    if (isset($_POST["VnosUcDat_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["UpdUc_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Redov_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["VnosNPZ_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["ImpExNPZ_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["DelPregl_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["DelKontr_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["UpdDel_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Tajn_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["VnosSist_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["VnosAktivi_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["VnosUrnik_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["VnosNadom_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["inventura_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["StatUc_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["StatDel_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["LetnPor_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Prehrana_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Prisotnost_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["NovoSL_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["ImpExUc_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["DatSola_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Prazniki_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Prostori_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["Predmeti_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["TabEd_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["RDU_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["PreglZbirn_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["PreglPoroc_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["PreglReal_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo1_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo2_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo3_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo4_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo5_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo6_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo7_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo8_".$indx]) ) {
					    $SQL = $SQL . "true,";
				    }else{
					    $SQL = $SQL . "false,";
				    }
				    if (isset($_POST["drugo9_".$indx]) ) {
					    $SQL = $SQL . "true ";
				    }else{
					    $SQL = $SQL . "false ";
				    }
				    $SQL = $SQL . ")";
				    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu dostopnih pravic!<br />$SQL<br />");
                    }
			    }
            }
		}
}

$SQL = "SELECT tabucitelji.IdUcitelj,tabucitelji.Priimek,tabucitelji.Ime,TabDostop.* FROM tabucitelji ";
$SQL = $SQL . "LEFT JOIN TabDostop ON tabucitelji.idUcitelj=TabDostop.idUcitelj ";
$SQL = $SQL . "WHERE tabucitelji.status >= 0 ";
$SQL = $SQL . "ORDER BY priimek,ime";
//Response.Write "<br>" & $SQL & "<br>"
$result = mysqli_query($link,$SQL);

$indx=1;

echo "<br />Spisek zaposlenih:<br />";
echo "<form name='Dostop' method='post' action='DostopnaKontrola.php'>";
echo "<table border='1' cellspacing='0'>";
echo "<tr bgcolor=lightcyan><th>Št.</th><th>Priimek, Ime</th><th>Delo</th><th>Nivo<br>dostopa</th>";
echo "<th>VnosUcDat</th>";
echo "<th>UpdUc</th>";
echo "<th>Redov</th>";
echo "<th>VnosNPZ</th>";
echo "<th>ImpExNPZ</th>";
echo "<th>DelPregl</th>";
echo "<th>DelKontr</th>";
echo "<th>UpdDel</th>";
echo "<th>Tajn</th>";
echo "<th>VnosSist</th>";
echo "<th>VnosAktivi</th>";
echo "<th>VnosUrnik</th>";
echo "<th>VnosNadom</th>";
echo "<th>inventura</th>";
echo "<th>StatUc</th>";
echo "<th>StatDel</th>";
echo "<th>LetnPor</th>";
echo "<th>Prehrana</th>";
echo "<th>Prisotnost</th>";
echo "<th>NovoSL</th>";
echo "<th>ImpExUc</th>";
echo "<th>DatSola</th>";
echo "<th>Prazniki</th>";
echo "<th>Prostori</th>";
echo "<th>Predmeti</th>";
echo "<th>TabEd</th>";
echo "<th>RDU</th>";
echo "<th>PreglZbirn</th>";
echo "<th>PreglPoroc</th>";
echo "<th>PreglReal</th>";
echo "<th>drugo1</th>";
echo "<th>drugo2</th>";
echo "<th>drugo3</th>";
echo "<th>drugo4</th>";
echo "<th>drugo5</th>";
echo "<th>drugo6</th>";
echo "<th>drugo7</th>";
echo "<th>drugo8</th>";
echo "<th>drugo9</th>";
echo "</tr>";
$ColorChange=true;

while ($R = mysqli_fetch_array($result)){
	if ($R["IdUcitelj"] > 0){
		$oUcitelj = new RUcitelj;
		$oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
		if ($indx % 20 == 0 ) {
			echo "<tr bgcolor='lightcyan'><th>Št.</th><th>Priimek, Ime</th><th>Delo</th><th>Nivo<br>dostopa</th>";
			echo "<th>VnosUcDat</th>";
			echo "<th>UpdUc</th>";
			echo "<th>Redov</th>";
			echo "<th>VnosNPZ</th>";
			echo "<th>ImpExNPZ</th>";
			echo "<th>DelPregl</th>";
			echo "<th>DelKontr</th>";
			echo "<th>UpdDel</th>";
			echo "<th>Tajn</th>";
			echo "<th>VnosSist</th>";
			echo "<th>VnosAktivi</th>";
			echo "<th>VnosUrnik</th>";
			echo "<th>VnosNadom</th>";
			echo "<th>inventura</th>";
			echo "<th>StatUc</th>";
			echo "<th>StatDel</th>";
			echo "<th>LetnPor</th>";
			echo "<th>Prehrana</th>";
			echo "<th>Prisotnost</th>";
			echo "<th>NovoSL</th>";
			echo "<th>ImpExUc</th>";
			echo "<th>DatSola</th>";
			echo "<th>Prazniki</th>";
			echo "<th>Prostori</th>";
			echo "<th>Predmeti</th>";
			echo "<th>TabEd</th>";
			echo "<th>RDU</th>";
			echo "<th>PreglZbirn</th>";
			echo "<th>PreglPoroc</th>";
			echo "<th>PreglReal</th>";
			echo "<th>drugo1</th>";
			echo "<th>drugo2</th>";
			echo "<th>drugo3</th>";
			echo "<th>drugo4</th>";
			echo "<th>drugo5</th>";
			echo "<th>drugo6</th>";
			echo "<th>drugo7</th>";
			echo "<th>drugo8</th>";
			echo "<th>drugo9</th>";
			echo "</tr>";
		}
		if ($ColorChange ) {
			echo "<tr bgcolor='lightyellow'>";
		}else{
			echo "<tr bgcolor=#FFFFCC>";
		}
		$ColorChange=!$ColorChange;
		
		echo "<td>".$indx."</td>";
		echo "<td><input name='ime_".$indx."' type='hidden' value='".$R["idUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]." (".$R["idUcitelj"].")"."</td>";
		echo "<td>".$oUcitelj->getDelMesto()."</td>";
		echo "<td>".$oUcitelj->getNivoDostopa()."</td>";
		if ($R["idUcitelj"] > 0 ) {
			if ($R["VnosUcDat"] ) {
				echo "<td><input name='VnosUcDat_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosUcDat_".$indx."' type='checkbox'></td>";
			}
			if ($R["UpdUc"]) {
				echo "<td><input name='UpdUc_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='UpdUc_".$indx."' type='checkbox'></td>";
			}
			if ($R["Redov"]) {
				echo "<td><input name='Redov_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Redov_".$indx."' type='checkbox'></td>";
			}
			if ($R["VnosNPZ"]) {
				echo "<td><input name='VnosNPZ_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosNPZ_".$indx."' type='checkbox'></td>";
			}
			if ($R["ImpExNPZ"]) {
				echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox'></td>";
			}
			if ($R["DelPregl"]) {
				echo "<td><input name='DelPregl_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='DelPregl_".$indx."' type='checkbox'></td>";
			}
			if ($R["DelKontr"]) {
				echo "<td><input name='DelKontr_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='DelKontr_".$indx."' type='checkbox'></td>";
			}
			if ($R["UpdDel"]) {
				echo "<td><input name='UpdDel_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='UpdDel_".$indx."' type='checkbox'></td>";
			}
			if ($R["Tajn"]) {
				echo "<td><input name='Tajn_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Tajn_".$indx."' type='checkbox'></td>";
			}
			if ($R["VnosSist"]) {
				echo "<td><input name='VnosSist_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosSist_".$indx."' type='checkbox'></td>";
			}
			if ($R["VnosAktivi"]) {
				echo "<td><input name='VnosAktivi_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosAktivi_".$indx."' type='checkbox'></td>";
			}
			if ($R["VnosUrnik"]) {
				echo "<td><input name='VnosUrnik_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosUrnik_".$indx."' type='checkbox'></td>";
			}
			if ($R["VnosNadom"]) {
				echo "<td><input name='VnosNadom_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='VnosNadom_".$indx."' type='checkbox'></td>";
			}
			if ($R["Inventura"]) {
				echo "<td><input name='inventura_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='inventura_".$indx."' type='checkbox'></td>";
			}
			if ($R["StatUc"]) {
				echo "<td><input name='StatUc_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='StatUc_".$indx."' type='checkbox'></td>";
			}
			if ($R["StatDel"]) {
				echo "<td><input name='StatDel_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='StatDel_".$indx."' type='checkbox'></td>";
			}
			if ($R["LetnPor"]) {
				echo "<td><input name='LetnPor_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='LetnPor_".$indx."' type='checkbox'></td>";
			}
			if ($R["Prehrana"]) {
				echo "<td><input name='Prehrana_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Prehrana_".$indx."' type='checkbox'></td>";
			}
			if ($R["Prisotnost"]) {
				echo "<td><input name='Prisotnost_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Prisotnost_".$indx."' type='checkbox'></td>";
			}
			if ($R["NovoSL"]) {
				echo "<td><input name='NovoSL_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='NovoSL_".$indx."' type='checkbox'></td>";
			}
			if ($R["ImpExUc"]) {
				echo "<td><input name='ImpExUc_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='ImpExUc_".$indx."' type='checkbox'></td>";
			}
			if ($R["DatSola"]) {
				echo "<td><input name='DatSola_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='DatSola_".$indx."' type='checkbox'></td>";
			}
			if ($R["Prazniki"]) {
				echo "<td><input name='Prazniki_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Prazniki_".$indx."' type='checkbox'></td>";
			}
			if ($R["Prostori"]) {
				echo "<td><input name='Prostori_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Prostori_".$indx."' type='checkbox'></td>";
			}
			if ($R["Predmeti"]) {
				echo "<td><input name='Predmeti_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='Predmeti_".$indx."' type='checkbox'></td>";
			}
			if ($R["TabEd"]) {
				echo "<td><input name='TabEd_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='TabEd_".$indx."' type='checkbox'></td>";
			}
			if ($R["RDU"]) {
				echo "<td><input name='RDU_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='RDU_".$indx."' type='checkbox'></td>";
			}
			if ($R["PreglZbirn"]) {
				echo "<td><input name='PreglZbirn_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='PreglZbirn_".$indx."' type='checkbox'></td>";
			}
			if ($R["PreglPoroc"]) {
				echo "<td><input name='PreglPoroc_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='PreglPoroc_".$indx."' type='checkbox'></td>";
			}
			if ($R["PreglReal"]) {
				echo "<td><input name='PreglReal_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='PreglReal_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo1"]) {
				echo "<td><input name='drugo1_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo1_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo2"]) {
				echo "<td><input name='drugo2_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo2_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo3"]) {
				echo "<td><input name='drugo3_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo3_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo4"]) {
				echo "<td><input name='drugo4_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo4_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo5"]) {
				echo "<td><input name='drugo5_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo5_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo6"]) {
				echo "<td><input name='drugo6_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo6_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo7"]) {
				echo "<td><input name='drugo7_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo7_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo8"]) {
				echo "<td><input name='drugo8_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo8_".$indx."' type='checkbox'></td>";
			}
			if ($R["drugo9"]) {
				echo "<td><input name='drugo9_".$indx."' type='checkbox' checked></td>";
			}else{
				echo "<td><input name='drugo9_".$indx."' type='checkbox'></td>";
			}
		}else{
			switch ($oUcitelj->getNivoDostopa()){
				case 0:
					echo "<td><input name='VnosUcDat_".$indx."' type='checkbox'></td>";
					echo "<td><input name='UpdUc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Redov_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosNPZ_".$indx."' type='checkbox'></td>";
					echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DelPregl_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DelKontr_".$indx."' type='checkbox'></td>";
					echo "<td><input name='UpdDel_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Tajn_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosSist_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosAktivi_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosUrnik_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosNadom_".$indx."' type='checkbox'></td>";
					echo "<td><input name='inventura_".$indx."' type='checkbox'></td>";
					echo "<td><input name='StatUc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='StatDel_".$indx."' type='checkbox'></td>";
					echo "<td><input name='LetnPor_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prehrana_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prisotnost_".$indx."' type='checkbox'></td>";
					echo "<td><input name='NovoSL_".$indx."' type='checkbox'></td>";
					echo "<td><input name='ImpExUc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DatSola_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prazniki_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prostori_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Predmeti_".$indx."' type='checkbox'></td>";
					echo "<td><input name='TabEd_".$indx."' type='checkbox'></td>";
					echo "<td><input name='RDU_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglZbirn_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglPoroc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglReal_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo1_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo2_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo3_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo4_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo5_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo6_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo7_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo8_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo9_".$indx."' type='checkbox'></td>";
					break;
				case 1:
					echo "<td><input name='VnosUcDat_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='UpdUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Redov_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosNPZ_".$indx."' type='checkbox'></td>";
					echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DelPregl_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DelKontr_".$indx."' type='checkbox'></td>";
					echo "<td><input name='UpdDel_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Tajn_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosSist_".$indx."' type='checkbox'></td>";
					
					echo "<td><input name='VnosAktivi_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosUrnik_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosNadom_".$indx."' type='checkbox'></td>";
					echo "<td><input name='inventura_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatDel_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='LetnPor_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prehrana_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prisotnost_".$indx."' type='checkbox'></td>";
					echo "<td><input name='NovoSL_".$indx."' type='checkbox'></td>";
					
					echo "<td><input name='ImpExUc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DatSola_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prazniki_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Prostori_".$indx."' type='checkbox'></td>";
					echo "<td><input name='Predmeti_".$indx."' type='checkbox'></td>";
					echo "<td><input name='TabEd_".$indx."' type='checkbox'></td>";
					echo "<td><input name='RDU_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglZbirn_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglPoroc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='PreglReal_".$indx."' type='checkbox'></td>";
					
					echo "<td><input name='drugo1_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo2_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo3_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo4_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo5_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo6_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo7_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo8_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo9_".$indx."' type='checkbox'></td>";
					break;
				case 2:
					echo "<td><input name='VnosUcDat_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='UpdUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Redov_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosNPZ_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DelPregl_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='DelKontr_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='UpdDel_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Tajn_".$indx."' type='checkbox'></td>";
					echo "<td><input name='VnosSist_".$indx."' type='checkbox' checked></td>";
					
					echo "<td><input name='VnosAktivi_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosUrnik_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosNadom_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='inventura_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatDel_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='LetnPor_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prehrana_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prisotnost_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='NovoSL_".$indx."' type='checkbox' checked></td>";
					
					echo "<td><input name='ImpExUc_".$indx."' type='checkbox'></td>";
					echo "<td><input name='DatSola_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prazniki_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prostori_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Predmeti_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='TabEd_".$indx."' type='checkbox'></td>";
					echo "<td><input name='RDU_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglZbirn_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglPoroc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglReal_".$indx."' type='checkbox' checked></td>";
					
					echo "<td><input name='drugo1_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo2_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo3_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo4_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo5_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo6_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo7_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo8_".$indx."' type='checkbox'></td>";
					echo "<td><input name='drugo9_".$indx."' type='checkbox'></td>";
					break;
				case 3:
					echo "<td><input name='VnosUcDat_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='UpdUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Redov_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosNPZ_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='ImpExNPZ_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='DelPregl_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='DelKontr_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='UpdDel_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Tajn_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosSist_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosAktivi_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosUrnik_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='VnosNadom_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='inventura_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='StatDel_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='LetnPor_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prehrana_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prisotnost_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='NovoSL_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='ImpExUc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='DatSola_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prazniki_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Prostori_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='Predmeti_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='TabEd_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='RDU_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglZbirn_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglPoroc_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='PreglReal_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo1_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo2_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo3_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo4_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo5_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo6_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo7_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo8_".$indx."' type='checkbox' checked></td>";
					echo "<td><input name='drugo9_".$indx."' type='checkbox' checked></td>";
			}
		}
		echo "</tr>";
		$indx=$indx+1;
	}
}
echo "</table>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='StZapisov' type='hidden' value='".($indx-1)."'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>";

?>
<a href="prijava.php">Nazaj na glavni meni</a><br />

</body>
</html>
