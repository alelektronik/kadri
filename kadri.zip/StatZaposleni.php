<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Statistike
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $VUporabnikId=$UciteljComp;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');
    if (!CheckDostop("StatDel",$VUporabnik) ) {
        echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
    }

    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    echo "<form accept-charset='utf-8' name='casVsi' method=post action='StatZaposleni.php'>";
    echo "Šolsko leto: ";
    echo "<select name='solskoleto'>";
    echo "<option value='" .  $VLeto  . "' selected>" . $VLeto."/".($VLeto+1) ."</option>";
    echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1)."/".($VLeto) ."</option>";
    echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1)."/".($VLeto+2) ."</option>";
    echo "</select>";
    echo "<input name='id' type='hidden' value='1'>";
    echo "<input name='submit' type='submit' value='Izberi'>";
    echo "</form><br />";

    //inicializacija polj
    for ($i=0;$i <= 300;$i++){
        $SkupinaDela[$i]=0;
        $VzgDelo[$i]=0;
        $Delo[$i]=0;
        for($j=0;$j <= 30;$j++){
            $IzobrazbaSkupina[$i][$j]=0;
            $IzobrazbaDelo[$i][$j]=0;
            $IzobrazbaVzgDelo[$i][$j]=0;
            $Starost[$i][$j]=0;
        }
    }
    for ($i=0;$i <= 400;$i++){
        for($j=0;$j <= 25;$j++){
            $DelPog[$i][$j]="";
            $Delavec[$i][$j]="";
        }
    }

    $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabucitelji.letoroj,tabucitelji.izobrazba,tabucitelji.spol";
    $SQL = $SQL . ",tabucitelji.status,tabucitelji.mentor,tabucitelji.svetovalec,tabucitelji.svetnik,tabucitelji.nivodostopa, tabstatus.status AS sstatus FROM ";
    $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
    $SQL = $SQL . "WHERE tabucitelji.Status < 10 ";
    $SQL = $SQL . " ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $Delavec[$Indx][0]=$R["iducitelj"];
        $Delavec[$Indx][1]=$R["priimek"]." ".$R["ime"];
        $Delavec[$Indx][2]=$R["letoroj"];
        $Delavec[$Indx][3]=$R["izobrazba"];
    //'        $Delavec[$Indx][4]=$R["SkupinaDela"];
    //'        $Delavec[$Indx][5]=$R["OpisDela"];
    //'        $Delavec[$Indx][6]=$R["VzgojnoDelo"];
        $Delavec[$Indx][7]=$R["sstatus"];
    //'        $Delavec[$Indx][8]=$R["DelovniCas"];
    //'        $Delavec[$Indx][9]=$R["DatumStart"];
    //'        $Delavec[$Indx][10]=$R["DatumEnd"];
        $Delavec[$Indx][11]=$R["spol"];
    //'        $Delavec[$Indx][12]=$R["IdDelo"];
    //'        $Delavec[$Indx][13]=$R["IzobUstr"];
        $Delavec[$Indx][21]=$R["mentor"];
        $Delavec[$Indx][22]=$R["svetovalec"];
        $Delavec[$Indx][23]=$R["svetnik"];
        $Delavec[$Indx][24]=$R["nivodostopa"];
        $Delavec[$Indx][25]=$R["status"];
        $Indx=$Indx+1;
    }
    $StDelavcev=$Indx-1;

    //echo "Število delavcev ".$StDelavcev."<br />";

    $DatumPreveri=new DateTime(($VLeto+1)."-06-30");
    echo "<h2>Statistika zaposlenih na ".$DatumPreveri->format('d.m.Y')."</h2>";

    $SQL = "SELECT DISTINCT SkupinaDela FROM TabDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $NSkupinaDela[$Indx]=$R["SkupinaDela"];
        $Indx=$Indx+1;
    }
    $StSkupinDela=$Indx-1;

    $SQL = "SELECT VzgojnoDelo FROM TabVzgDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $TipVzgojnoDelo[$Indx]=$R["VzgojnoDelo"];
        $Indx=$Indx+1;
    }
    $StTipovVzgDelo=$Indx-1;

    $SQL = "SELECT OpisDela FROM TabDelo";
    $result = mysqli_query($link,$SQL);
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $TipDelo[$Indx]=$R["OpisDela"];
        $Indx=$Indx+1;
    }
    $StOpisovDela=$Indx-1;

    for ($Indx=0;$Indx <= 20;$Indx++){
        $count[$Indx]=0;
    }

    for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
        $SQL = "SELECT tabpogodbe.*,TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo FROM ";
        $SQL = $SQL . "(tabpogodbe INNER JOIN TabDelo ON tabpogodbe.idDelo=TabDelo.idDelo) ";
        $SQL = $SQL . "INNER JOIN TabVzgDelo ON tabpogodbe.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo ";
        $SQL = $SQL . "WHERE idUcitelj=".$Delavec[$Indx][0]." ORDER BY UrTeden DESC";
        $result = mysqli_query($link,$SQL);
        $i2=1;
        while ($R = mysqli_fetch_array($result)){
            if (isDate($R["DatumStart"]) ){
                $Datum=new DateTime(isDate($R["DatumStart"]));
                $DelPog[$i2][2]=$Datum->format('d.m.Y');
            }else{
                $DelPog[$i2][2]=$Danes->format('d.m.Y');
            }
            if (isDate($R["DatumEnd"])) {
                $Datum=new DateTime(isDate($R["DatumEnd"]));
                $DelPog[$i2][3]=$Datum->format('d.m.Y');
            }else{
                $DelPog[$i2][3]=$DatumPreveri->format('d.m.Y');
            }
            $DatumStart=new DateTime(isDate($DelPog[$i2][2]));
            $DatumEnd=new DateTime(isDate($DelPog[$i2][3]));
            $Interval1=$DatumStart->diff($DatumPreveri);
            $Interval2=$DatumEnd->diff($DatumPreveri);
            if (($Interval1->invert == 0) && (($Interval2->invert > 0) or (($Interval2->invert ==0) && ($Interval2->days==0)))){
                $DelPog[$i2][1]=1;
                $DelPog[$i2][0]=$R["UrTeden"];
                
                $DelPog[$i2][4]=$R["SkupinaDela"];
                $DelPog[$i2][5]=$R["OpisDela"];
                $DelPog[$i2][6]=$R["VzgojnoDelo"];
                
                $DelPog[$i2][8]=$R["DelovniCas"];
                $DelPog[$i2][9]=$DelPog[$i2][2];
                $DelPog[$i2][10]=$DelPog[$i2][3];
                $DelPog[$i2][12]=$R["IdDelo"];
                $DelPog[$i2][13]=$R["IzobUstr"];
                $DelPog[$i2][14]=$R["IdVzgojnoDelo"];
                $DelPog[$i2][15]=$R["PolniDelCas"];
                $DelPog[$i2][18]=$R["DopDelo"];
                $DelPog[$i2][20]=$R["Izmensko"];
            }else{
                $i2=$i2-1;
            }
            $i2=$i2+1;
        }
        $StDelPogodba=$i2-1;
        
        if ($StDelPogodba > 0 ){
            $Delavec[$Indx][4]=$DelPog[1][4];    //'SkupinaDela
            $Delavec[$Indx][5]=$DelPog[1][5];    //'OpisDela
            $Delavec[$Indx][6]=$DelPog[1][6];    //'VzgojnoDelo
            $Delavec[$Indx][8]=$DelPog[1][8];    //'DelovniCas
            $Delavec[$Indx][9]=$DelPog[1][9];    //'DatumStart
            $Delavec[$Indx][10]=$DelPog[1][10];    //'DatumEnd
            $Delavec[$Indx][12]=$DelPog[1][12];    //'IdDelo
            $Delavec[$Indx][13]=$DelPog[1][13];    //'IzobUstr
            $Delavec[$Indx][14]=$DelPog[1][14];    //'idVzgojnoDelo
            $Delavec[$Indx][15]=$DelPog[1][15];    //'PolniDelCas
            $Delavec[$Indx][18]=$DelPog[1][18];    //'DopDelo
            $Delavec[$Indx][20]=$DelPog[1][20];    //'Izmensko
        }
        
        if ($StDelPogodba > 0 ){
            switch ( $Delavec[$Indx][4]){
                case $NSkupinaDela[1];
                    $SkupinaDela[1]=$SkupinaDela[1]+1;
                    $IzobrazbaSkupina[1][$Delavec[$Indx][3]]=$IzobrazbaSkupina[1][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[2];
                    $SkupinaDela[2]=$SkupinaDela[2]+1;
                    $IzobrazbaSkupina[2][$Delavec[$Indx][3]]=$IzobrazbaSkupina[2][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[3]:
                    $SkupinaDela[3]=$SkupinaDela[3]+1;
                    $IzobrazbaSkupina[3][$Delavec[$Indx][3]]=$IzobrazbaSkupina[3][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[4]:
                    $SkupinaDela[4]=$SkupinaDela[4]+1;
                    $IzobrazbaSkupina[4][$Delavec[$Indx][3]]=$IzobrazbaSkupina[4][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[5]:
                    $SkupinaDela[5]=$SkupinaDela[5]+1;
                    $IzobrazbaSkupina[5][$Delavec[$Indx][3]]=$IzobrazbaSkupina[5][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[6]:
                    $SkupinaDela[6]=$SkupinaDela[6]+1;
                    $IzobrazbaSkupina[6][$Delavec[$Indx][3]]=$IzobrazbaSkupina[6][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[7]:
                    $SkupinaDela[7]=$SkupinaDela[7]+1;
                    $IzobrazbaSkupina[7][$Delavec[$Indx][3]]=$IzobrazbaSkupina[7][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[8]:
                    $SkupinaDela[8]=$SkupinaDela[8]+1;
                    $IzobrazbaSkupina[8][$Delavec[$Indx][3]]=$IzobrazbaSkupina[8][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
                    break;
                case $NSkupinaDela[9]:
                    $SkupinaDela[9]=$SkupinaDela[9]+1;
                    $IzobrazbaSkupina[9][$Delavec[$Indx][3]]=$IzobrazbaSkupina[9][$Delavec[$Indx][3]]+1;
                    $IzobrazbaSkupina[0][$Delavec[$Indx][3]]=$IzobrazbaSkupina[0][$Delavec[$Indx][3]]+1;
                    $SkupinaDela[0]=$SkupinaDela[0]+1;
            }
            if ($Delavec[$Indx][14] > 0 ){
                $VzgDelo[$Delavec[$Indx][14]]=$VzgDelo[$Delavec[$Indx][14]]+1;
            }
            $VzgDelo[0]=$VzgDelo[0]+1;
            if ($Delavec[$Indx][12] > 0 ){
                $Delo[$Delavec[$Indx][12]]=$Delo[$Delavec[$Indx][12]]+1;
            }
            $Delo[0]=$Delo[0]+1;
            if ($Delavec[$Indx][12] > 0 ){
                $IzobrazbaDelo[$Delavec[$Indx][12]][$Delavec[$Indx][3]]=$IzobrazbaDelo[$Delavec[$Indx][12]][$Delavec[$Indx][3]]+1;
            }
            $IzobrazbaDelo[0][$Delavec[$Indx][3]]=$IzobrazbaDelo[0][$Delavec[$Indx][3]]+1;
            if ($Delavec[$Indx][14] > 0 ){
                $IzobrazbaVzgDelo[$Delavec[$Indx][14]][$Delavec[$Indx][3]]=$IzobrazbaVzgDelo[$Delavec[$Indx][14]][$Delavec[$Indx][3]]+1;
            }
            $IzobrazbaVzgDelo[0][$Delavec[$Indx][3]]=$IzobrazbaVzgDelo[0][$Delavec[$Indx][3]]+1;
            switch ( $VLeto-$Delavec[$Indx][2]){
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                    $Starost[1][$Delavec[$Indx][25]]=$Starost[1][$Delavec[$Indx][25]]+1;
                    break;
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                    $Starost[2][$Delavec[$Indx][25]]=$Starost[2][$Delavec[$Indx][25]]+1;
                    break;
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                    $Starost[3][$Delavec[$Indx][25]]=$Starost[3][$Delavec[$Indx][25]]+1;
                    break;
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                    $Starost[4][$Delavec[$Indx][25]]=$Starost[4][$Delavec[$Indx][25]]+1;
                    break;
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    $Starost[5][$Delavec[$Indx][25]]=$Starost[5][$Delavec[$Indx][25]]+1;
                    break;
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                    $Starost[6][$Delavec[$Indx][25]]=$Starost[6][$Delavec[$Indx][25]]+1;
                    break;
                default:
                    $Starost[7][$Delavec[$Indx][25]]=$Starost[7][$Delavec[$Indx][25]]+1;
            }
        
            $count[16]=$count[16]+1;
            if ($Delavec[$Indx][15]=="Da" ){ 
                $count[0]=$count[0]+1;
            }
            if ($Delavec[$Indx][15]=="Ne" ){ 
                $count[1]=$count[1]+1;
            }
            if ($Delavec[$Indx][16] ){ 
                $count[2]=$count[2]+1;
            }
            if (is_numeric(strpos($Delavec[$Indx][17],"Da"))){ 
                $count[3]=$count[3]+1;
            }
            if ($Delavec[$Indx][18] ){ 
                $count[4]=$count[4]+1;
            }
            if (strlen($Delavec[$Indx][19]) > 0){ 
                $count[5]=$count[5]+1;
            }
            if ($Delavec[$Indx][20]){ 
                $count[18]=$count[18]+1;
            }
            if (strlen($Delavec[$Indx][21]) > 0){
                if (strlen($Delavec[$Indx][22]) > 0){
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[7]=$count[7]+1;
                    }
                }else{
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[6]=$count[6]+1;
                    }
                }
            }else{
                if (strlen($Delavec[$Indx][22]) > 0){
                    if (strlen($Delavec[$Indx][23]) > 0){
                        $count[8]=$count[8]+1;
                    }else{
                        $count[7]=$count[7]+1;
                    }
                }else{
                    if (strlen($Delavec[$Indx][23]) > 0 ){
                        $count[8]=$count[8]+1;
                    }
                }
            }
            switch ( $Delavec[$Indx][24]){
                case 0:
                    $count[9]=$count[9]+1;
                    break;
                case 1:
                    $count[10]=$count[10]+1;
                    break;
                case 2:
                    $count[11]=$count[11]+1;
                    break;
                case 3:
                    $count[12]=$count[12]+1;
            }
            switch ( $Delavec[$Indx][25]){
                case 3:
                    $count[13]=$count[13]+1;
                    break;
                case 6:
                    $count[14]=$count[14]+1;
                    break;
                case 10:
                    $count[15]=$count[15]+1;
            }
            
            $count[17]=$count[17]+1;
        }
    }

    echo "<table border=1>";
    echo "<tr><th>Delovno mesto</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StOpisovDela;$Indx++){
        if (strlen($TipDelo[$Indx]) > 0){
            echo "<tr>";
            echo "<td>&nbsp;".$TipDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$Delo[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$Delo[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaDelo[0][10]."</td>";
            echo "</tr>";
    echo "</table>";

    echo "<br />";

    echo "<table border=1>";
    echo "<tr><th>Delo</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StTipovVzgDelo;$Indx++){
        if (strlen($TipVzgojnoDelo[$Indx]) > 0 ){
            echo "<tr>";
            echo "<td>&nbsp;".$TipVzgojnoDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$VzgDelo[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$VzgDelo[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaVzgDelo[0][10]."</td>";
            echo "</tr>";
            echo "<tr>";
    echo "</table>";

    echo "<br />";

    echo "<table border=1>";
    echo "<tr><th>Delovne skupine</th><th>N</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6/1</th><th>6/2</th><th>7</th><th>8/1</th><th>8/2</th></tr>";
    for ($Indx=1;$Indx <= $StSkupinDela;$Indx++){
        if (strlen($NSkupinaDela[$Indx]) > 0){
            echo "<tr>";
            echo "<td>&nbsp;".$NSkupinaDela[$Indx]."</td>";
            echo "<td>&nbsp;".$SkupinaDela[$Indx]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[$Indx][10]."</td>";
            echo "</tr>";
        }
    }
            echo "<tr>";
            echo "<td>Skupaj</td>";
            echo "<td>&nbsp;".$SkupinaDela[0]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][1]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][2]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][3]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][4]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][5]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][6]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][7]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][8]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][9]."</td>";
            echo "<td>&nbsp;".$IzobrazbaSkupina[0][10]."</td>";
            echo "</tr>";
    echo "</table>";

    echo "<br>";

    $StrStarost[1]="do 29 let";
    $StrStarost[2]="30-34 let";
    $StrStarost[3]="35-39 let";
    $StrStarost[4]="40-44 let";
    $StrStarost[5]="45-49 let";
    $StrStarost[6]="50-55 let";
    $StrStarost[7]=" nad 55 let";

    echo "<table border=1>";
    echo "<th>Starostna skupina</th><th>Redno</th><th>Na več šolah</th><th>Pripravnik</th>";
    for ($Indx=1;$Indx <= 7;$Indx++){
            echo "<tr>";
            echo "<td>&nbsp;".$StrStarost[$Indx]."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][1]+$Starost[$Indx][4])."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][2]+$Starost[$Indx][5])."</td>";
            echo "<td>&nbsp;".($Starost[$Indx][3]+$Starost[$Indx][6])."</td>";
            echo "</tr>";
    }
    echo "</table>";

        echo "<br><table border=1>";
        echo "<tr><th>zaposleni</th><th>število</th></tr>";
        echo "<tr><td>Skupaj zaposlenih</td><td align=center>".$count[16]."</td></tr>";
        echo "<tr><td>Polni delovni čas</td><td align=center>".$count[0]."</td></tr>";
        echo "<tr><td>Skrajšan delovni čas</td><td align=center>".$count[1]."</td></tr>";
        echo "<tr><td>Invalid</td><td align=center>".$count[2]."</td></tr>";
        echo "<tr><td>Delno upokojen</td><td align=center>".$count[3]."</td></tr>";
        echo "<tr><td>Dopolnjuje delo</td><td align=center>".$count[4]."</td></tr>";
        echo "<tr><td>Izmensko delo</td><td align=center>".$count[18]."</td></tr>";
        echo "<tr><td>Začasno bivališče</td><td align=center>".$count[5]."</td></tr>";
        echo "<tr><td>Mentor</td><td align=center>".$count[6]."</td></tr>";
        echo "<tr><td>Svetovalec</td><td align=center>".$count[7]."</td></tr>";
        echo "<tr><td>Svetnik</td><td align=center>".$count[8]."</td></tr>";
        echo "<tr><td>Običajen dostop</td><td align=center>".$count[9]."</td></tr>";
        echo "<tr><td>Razredniški dostop</td><td align=center>".$count[10]."</td></tr>";
        echo "<tr><td>Ravnateljski dostop</td><td align=center>".$count[11]."</td></tr>";
        echo "<tr><td>Administratorski dostop</td><td align=center>".$count[12]."</td></tr>";
        echo "<tr><td>Pripravnik</td><td align=center>".$count[13]."</td></tr>";
        echo "<tr><td>Volunterski pripravnik</td><td align=center>".$count[14]."</td></tr>";
        echo "<tr><td>Gostujoči učitelji</td><td align=center>".$count[15]."</td></tr>";
        echo "</table>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
<br>
<a href="prijava.php">Nazaj na glavni meni</a><br />

</body>
</html>
