<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

echo "<html>";
echo "<head>";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
echo "<meta http-equiv='pragma' content='no-cache' > ";
echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
echo "<title>Geslo";
echo "</title>";
echo "</head>";
echo "<body>";
$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE uporabnik='". $VUporabnik . "' AND geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["priimek"]." ".$R["ime"];
    $IdUcitelj=$R["iducitelj"];
    $VUporabnikId=$IdUcitelj;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
//echo "Za geslo uporabite velike in male črke ter številke (NE posebnih znakov!)<br />";

$SQL = "SELECT ime,priimek FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    echo "<h2>Pozdravljeni : <b>" . $R["ime"]  . " " . $R["priimek"] . "</b></h2>";
    echo "Sprememba gesla:<br />";
    echo "<small>Za geslo uporabite velike in male črke ter številke (NE posebnih znakov!)</small><br />";
    echo "<form name='sprgeslo' method='post' action='DoSpremeniGeslo.php'>";
    echo "<table border='0'>";
    echo "<tr><td>Vnesite  staro geslo:</td><td><input name='StGeslo' type='password' size='16'></td></tr>";
    echo "<tr><td>Vnesite  novo geslo:</td><td><input name='NGeslo' type='password' size='16'></td></tr>";
    echo "<tr><td>Ponovite  novo geslo:</td><td><input name='RGeslo' type='password' size='16'></td></tr>";
    echo "</table>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";
}else{
    echo "Vaše uporabniško ime ali geslo je nepravilno!<br><br />";
    echo "<a href='index.php'>Nazaj na vnos uporabniškega imena in gesla</a><br />";
}

?>

</body>
</html>
