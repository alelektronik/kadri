<?php
include ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Popravljanje dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    if (isset($_POST["id"])){
        $id = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $id=$_GET["id"];
        }else{
            $id = 0;
        }
    }

	switch ($id){
		case 2:
			break;
		default:
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
	}
    switch ($id){
	    case 1:
		    $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Davcna,TabDopust.* FROM tabucitelji INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj WHERE tabucitelji.idUcitelj=". $ucitelj." AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                    $VPriimek=$R["Priimek"];
                    $VIme=$R["Ime"];
                    $VDelovnaDoba=$R["DelDobaLet"];
                    $VDopDelDoba=$R["DopustNaDD"];
                    $VDopIzobrazba=$R["DopustNaIz"];
                    $VDopOtroci=$R["DopustNaOt"];
                    $VDopStarost=$R["DopustNaSta"];
                    $VDopInvalidnost=$R["DopustNaInv"];
                    $VDopVodenje=$R["DopustNaVod"];
                    $VDopStari=$R["DopustStari"];
                    $VDopVzgoja=$R["DopustVzgoja"];
                    $VDopustDelInv=$R["DopustDelInv"];
                    $VDopustPP=$R["DopustPP"];
                    $VDrugo=$R["Drugo"];
                    $VDelez=$R["Delez"];
		    }else{
			    $SQL = "INSERT INTO TabDopust (leto,idUcitelj,DelDobaLet,DopustNaDD,DopustNaIz,DopustNaOt,DopustNaSta,DopustNaInv,DopustNaVod,DopustVzgoja,DopustStari,DopustDelInv,DopustPP,Drugo,Delez) ";
			    $SQL = $SQL . "VALUES (".$VLeto.",".$ucitelj.",0,0,0,0,0,0,0,0,0,0,0,0,-1)";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    echo $SQL."<br />";
                    die("Napaka pri vpisovanju dopustov: ".mysqli_error());
                }
			    
			    $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Davcna,TabDopust.* FROM tabucitelji INNER JOIN TabDopust ON tabucitelji.IdUcitelj=TabDopust.idUcitelj WHERE tabucitelji.IdUcitelj=". $ucitelj." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VPriimek=$R["Priimek"];
                    $VIme=$R["Ime"];
                    $VDelovnaDoba=$R["DelDobaLet"];
                    $VDopDelDoba=$R["DopustNaDD"];
                    $VDopIzobrazba=$R["DopustNaIz"];
                    $VDopOtroci=$R["DopustNaOt"];
                    $VDopStarost=$R["DopustNaSta"];
                    $VDopInvalidnost=$R["DopustNaInv"];
                    $VDopVodenje=$R["DopustNaVod"];
                    $VDopStari=$R["DopustStari"];
                    $VDopVzgoja=$R["DopustVzgoja"];
                    $VDopustDelInv=$R["DopustDelInv"];
                    $VDopustPP=$R["DopustPP"];
                    $VDrugo=$R["Drugo"];
                    $VDelez=$R["Delez"];
			    }else{
                    if (isset($_POST["kam"])){
                        header("Location: IzpisUcitelja.php?leto=".$VLeto."idUcitelj=".$ucitelj);
                    }else{
                        header("Location: IzpisDopustov.php?leto=".$VLeto);
                    }
			    }
		    }

		    if ($VLevel > 1) {
			    echo "<form accept-charset='utf-8' name='dopusti' method=post action='PopraviDopust.php'>";
			    echo "<h2>Popravi podatke o dopustih za leto ".$VLeto."</h2>";
			    
			    echo "<table>";
			    echo "<tr><td><b>".$VPriimek." " .$VIme. "</b></td></tr>";
			    echo "<tr><td>Delovna doba: </td><td><input name='delovnadoba' type='text' size='5' value='".$VDelovnaDoba."'></td></tr>";
			    echo "<tr><td>Dopust na del. dobo: </td><td><input name='dopdeldoba' type='text' size='5' value='".$VDopDelDoba."'></td></tr>";
			    echo "<tr><td>Dopust na vzgojno delo: </td><td><input name='dopvzgoja' type='text' size='5' value='".$VDopVzgoja."'></td></tr>";
			    echo "<tr><td>Dopust na izobrazbo: </td><td><input name='dopizobrazba' type='text' size='5' value='".$VDopIzobrazba."'></td></tr>";
			    echo "<tr><td>Dopust na otroke: </td><td><input name='dopotroci' type='text' size='5' value='".$VDopOtroci."'></td></tr>";
			    echo "<tr><td>Dopust na starost: </td><td><input name='dopstarost' type='text' size='5' value='".$VDopStarost."'></td></tr>";
			    echo "<tr><td>Dopust na invalidnost: </td><td><input name='dopinvalidnost' type='text' size='5' value='".$VDopInvalidnost."'></td></tr>";
			    echo "<tr><td>Dopust na vodenje: </td><td><input name='dopvodenje' type='text' size='5' value='".$VDopVodenje."'></td></tr>";
			    echo "<tr><td>Dopust za delovne invalide: </td><td><input name='dopustDelInv' type='text' size='5' value='".$VDopustDelInv."'></td></tr>";
			    echo "<tr><td>Dopust za prilagojene programe: </td><td><input name='dopustPP' type='text' size='5' value='".$VDopustPP."'></td></tr>";
			    echo "<tr><td>Drugo: </td><td><input name='drugo' type='text' size='5' value='".$VDrugo."'></td></tr>";
			    echo "<tr><td>Stari dopust: </td><td><input name='dopstari' type='text' size='5' value='".$VDopStari."'></td></tr>";
			    echo "<tr><td>Delež dopusta: </td><td><input name='delez' type='text' size='5' value='".$VDelez."'></td></tr>";
			    
			    echo "</table><br />";
			    echo "Če je vrednost za delež dopusta različna od -1 (npr.: 0,1,2,...), se ta vrednost upošteva kot število dni dopusta (delež).<br />";

			    echo "<input name='idZapis' type='hidden' value='".$R["Id"]."'>";
			    echo "<input name='leto' type='hidden' value='".$VLeto."'>";
			    echo "<input name='id' type='hidden' value='2'>";
                echo "<input name='idUcitelj' type='hidden' value='".$ucitelj."'>";
                if (isset($_GET["kam"])){
                    echo "<input name='kam' type='hidden' value='".$_GET["kam"]."'>";
                }
			    echo "<input name='submit' type='submit' value='Pošlji'>";
			    echo "</form>";
		    }else{
		 	    echo "Nimate potrebnih pooblastil za vpis podatkov!";
			    header("Location: nepooblascen.htm");
		    }
            break;
	    case 2:
		    $VDelez=$_POST["delez"];
		    if (!is_numeric($VDelez) ){ 
                $VDelez=-1;
            }
		    $SQL = "UPDATE TabDopust SET ";
			if (is_numeric($_POST["delovnadoba"])){
				$SQL = $SQL . "DelDobaLet=".$_POST["delovnadoba"].", ";
			}else{
				$SQL = $SQL . "DelDobaLet=0, ";
			}
			if (is_numeric($_POST["dopdeldoba"])){
				$SQL = $SQL . "DopustNaDD=".$_POST["dopdeldoba"].", ";
			}else{
				$SQL = $SQL . "DopustNaDD=0, ";
			}
			if (is_numeric($_POST["dopvzgoja"])){
				$SQL = $SQL . "DopustVzgoja=".$_POST["dopvzgoja"].", ";
			}else{
				$SQL = $SQL . "DopustVzgoja=".$_POST["dopvzgoja"].", ";
			}
			if (is_numeric($_POST["dopizobrazba"])){
				$SQL = $SQL . "DopustNaIz=".$_POST["dopizobrazba"].", ";
			}else{
				$SQL = $SQL . "DopustNaIz=0, ";
			}
			if (is_numeric($_POST["dopotroci"])){
				$SQL = $SQL . "DopustNaOt=".$_POST["dopotroci"].", ";
			}else{
				$SQL = $SQL . "DopustNaOt=0, ";
			}
			if (is_numeric($_POST["dopstarost"])){
				$SQL = $SQL . "DopustNaSta=".$_POST["dopstarost"].", ";
			}else{	
				$SQL = $SQL . "DopustNaSta=0, ";
			}
			if (is_numeric($_POST["dopinvalidnost"])){
				$SQL = $SQL . "DopustNaInv=".$_POST["dopinvalidnost"].", ";
			}else{
				$SQL = $SQL . "DopustNaInv=0, ";
			}
			if (is_numeric($_POST["dopvodenje"])){
				$SQL = $SQL . "DopustNaVod=".$_POST["dopvodenje"].", ";
			}else{
				$SQL = $SQL . "DopustNaVod=0, ";
			}
			if (is_numeric($_POST["dopustDelInv"])){
				$SQL = $SQL . "DopustDelInv=".$_POST["dopustDelInv"].", ";
			}else{
				$SQL = $SQL . "DopustDelInv=0, ";
			}
			if (is_numeric($_POST["dopustPP"])){
				$SQL = $SQL . "DopustPP=".$_POST["dopustPP"].", ";
			}else{
				$SQL = $SQL . "DopustPP=0, ";
			}
			if (is_numeric($_POST["drugo"])){
				$SQL = $SQL . "Drugo=".$_POST["drugo"].", ";
			}else{
				$SQL = $SQL . "Drugo=0, ";
			}
			$SQL = $SQL . "Delez=".$VDelez.", ";
			if (is_numeric($_POST["dopstari"])){
				$SQL = $SQL . "DopustStari=".$_POST["dopstari"]." ";
			}else{
				$SQL = $SQL . "DopustStari=0 ";
			}
		    $SQL = $SQL . "WHERE id=".$_POST["idZapis"];
            $result = mysqli_query($link,$SQL);
            if (!$result){
                echo $SQL."<br />";
                die("Napaka pri popravljanju dopustov: ".mysqli_error());
            }
		    
            if (isset($_POST["kam"])){
                header("Location: IzpisUcitelja.php?leto=".$VLeto."&idUcitelj=".$ucitelj);
            }else{
                header("Location: IzpisDopustov.php?leto=".$VLeto);
            }
    }
}
?>

</body>
</html>
