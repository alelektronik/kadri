<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Semafor
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo2",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    function Vsebuje($a,$s){
        $x=split(",",$s);
        return (in_array($a,$x));
    }

    echo "Leto: <a href='IzpisOpravil.php?leto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | ".$VLeto."/".($VLeto+1)." | <a href='IzpisOpravil.php?leto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
    echo "<h2>Opravila</h2>";

    $SQL = "SELECT iducitelj,ime,priimek FROM tabucitelji WHERE izobrazba > 5 AND status > 0 ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);
    $i=1;
    while ($R = mysqli_fetch_array($result)){
        $Ucitelji[$i][0]=$R["iducitelj"];
        $Ucitelji[$i][1]=$R["ime"]." ".$R["priimek"];
        $i += 1;
    }
    $StUciteljev=$i-1;
    
    for($i=1;$i <= $StUciteljev;$i++){
        $VUporabnikId=$Ucitelji[$i][0];
        $ImeUp=$Ucitelji[$i][1];
        echo "<h3>".$Ucitelji[$i][1]."</h3>";
        $VRazrednik="";
        $StUcencev=0;
        $SQL = "SELECT DISTINCT tabucitelji.spol,tabrazred.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
        $SQL .= "INNER JOIN tabrazred ON tabucitelji.iducitelj=tabrazred.iducitelj) ";
        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazred.iducitelj=".$VUporabnikId;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            //razrednik
            if ($R = mysqli_fetch_array($result)){
                $VRazrednik=$R["iducitelj"];
                $VRazred=$R["id"];
                $VSola=$R["idsola"];
                $VRazredOznaka=$R["razred"].". ".$R["oznaka"];
                $VRazred1=$R["razred"];
                $SpolR=$R["spol"];
                
                //pogleda, če je kot razrednik vpisan tudi v sistemizaciji
                $SQL = "SELECT DISTINCT tabucitelji.spol,tabucenje.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
                $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.predmet=50";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //razrednik po sistemizaciji
                    if ($VRazrednik == $R["iducitelj"]){
                        //preveri še razred
                        if ($VRazred == $R["id"]){
                            if ($SpolR == "M"){
                                echo "Razrednik ".$VRazredOznaka."<br />";
                            }else{
                                echo "Razredničarka ".$VRazredOznaka."<br />";
                            }
                        }else{
                            echo "V razrednih podatkih ste vpisani kot razrednik $VRazredOznaka razreda, v podatkih za sistemizacijo pa kot razrednik ".$R["razred"].". ".$R["oznaka"]." razreda!<br />Prosim, če obvestite administratorja.<br />";
                        }
                    }else{
                        //različno vpisano v razrednih podatkoh in sistemizaciji
                        echo "Za $VRazredOznaka so vpisani različni podatki o razredništvu!<br />Prosim, če obvestite administratorja.<br />";
                    }
                }
            }
        }else{
            //ni razrednik vpisan pri podatkih o razredih
            $SQL = "SELECT DISTINCT tabucitelji.spol,tabucenje.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
            $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.predmet=50";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                //razrednik po sistemizaciji
                $VRazrednik=$R["iducitelj"];
                $VRazred=$R["id"];
                $VSola=$R["idsola"];
                $VRazredOznaka=$R["razred"].". ".$R["oznaka"];
                $VRazred1=$R["razred"];
                if ($R["spol"] == "M"){
                    echo "Razrednik ".$VRazredOznaka."<br />";
                }else{
                    echo "Razredničarka ".$VRazredOznaka."<br />";
                }
            }
        }
        //preveri vodenje aktiva
        $VAktiv="";
        $VIdAktiv=0;
        $SQL = "SELECT DISTINCT tabvodjeaktivov.iducitelj,tabaktiv.aktiv,tabaktiv.id FROM (tabucitelji ";
        $SQL .= "INNER JOIN tabvodjeaktivov ON tabucitelji.iducitelj=tabvodjeaktivov.iducitelj) ";
        $SQL .= "INNER JOIN tabaktiv ON tabvodjeaktivov.idaktiv=tabaktiv.id ";
        $SQL .= "WHERE tabvodjeaktivov.leto=".$VLeto." AND tabvodjeaktivov.iducitelj=".$VUporabnikId;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $VAktiv=$R["aktiv"];
            $VIdAktiv=$R["id"];
            echo "Je vodja aktiva: ".$VAktiv."<br />";
        }
        //preveri vodenje aktiva v naslednjem letu
        $VAktivN="";
        $VIdAktivN=0;
        $SQL = "SELECT DISTINCT tabvodjeaktivov.iducitelj,tabaktiv.aktiv,tabaktiv.id FROM (tabucitelji ";
        $SQL .= "INNER JOIN tabvodjeaktivov ON tabucitelji.iducitelj=tabvodjeaktivov.iducitelj) ";
        $SQL .= "INNER JOIN tabaktiv ON tabvodjeaktivov.idaktiv=tabaktiv.id ";
        $SQL .= "WHERE tabvodjeaktivov.leto=".($VLeto+1)." AND tabvodjeaktivov.iducitelj=".$VUporabnikId;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $VAktivN=$R["aktiv"];
            $VIdAktivN=$R["id"];
            echo "V naslednjem ŠL je vodja aktiva: ".$VAktivN."<br />";
        }
        
        echo "<table class='condensed' >";
        echo "<tr><th>Rubrika</th><th>Status</th><th>Opombe</th></tr>";
        if ($VRazrednik > 0){
            //razrednik
            //pripravljeni podatki za spričevalo za določen razred
            $NUspeh=0;
            $NPonavljalec=0;
            $NNapreduje=0;
            $NRazredniIzpit=0;
            $NNadarjen=0;
            $NSportnik=0;
            $NKulturnik=0;
            $NEvid=0;
            $NDatum=0;
            $SQL = "SELECT uspeh,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,evidst,datumizdaje FROM tabrazred ";
            $SQL .= "WHERE idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["uspeh"])){
                    if ($R["uspeh"] > 0){
                        $NUspeh += 1;
                    }
                }
                if (isset($R["ponavljalec"])){
                    if ($R["ponavljalec"] > 0){
                        $NPonavljalec += 1;
                    }
                }
                if (isset($R["napredovanje"])){
                    if ($R["napredovanje"] > 0){
                        $NNapreduje += 1;
                    }
                }
                if (isset($R["razredniizpit"])){
                    if ($R["razredniizpit"] > 0){
                        $NRazredniIzpit += 1;
                    }
                }
                if (isset($R["nadarjen"])){
                    if ($R["nadarjen"] > 0){
                        $NNadarjen += 1;
                    }
                }
                if (isset($R["statussport"])){
                    if ($R["statussport"] > 0){
                        $NSportnik += 1;
                    }
                }
                if (isset($R["statuskult"])){
                    if ($R["statuskult"] > 0){
                        $NKulturnik += 1;
                    }
                }
                if (isset($R["evidst"])){
                    if (strlen($R["evidst"]) == 0){
                        $NEvid += 1;
                    }
                }else{
                    $NEvid += 1;
                }
                if (isset($R["datumizdaje"])){
                    if (strlen($R["datumizdaje"]) == 0){
                        $NDatum += 1;
                    }
                }else{
                    $NDatum += 1;
                }
            }
            echo "<tr>";
            echo "<td><a href='vnesiocene.php?id=7&razred=".$VRazred."&solskoleto=".$VLeto."'>Podatki za spričevalo, nadarjeni, statusi</a></td>";
            if ($NEvid > 0 or $NDatum > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            echo "Uspeh ima vpisano $NUspeh učencev, razred ponavlja $NPonavljalec učencev, ne napreduje oz. z nezadostno napreduje $NNapreduje učencev, razredni izpit ima $NRazredniIzpit učencev, ";
            echo "nadarjenih je $NNadarjen učencev, status športnika ima $NSportnik učencev, status kulturnika ima $NKulturnik učencev, evidenčno številko nima vpisanih $NEvid učencev, datuma izdaje spričevala nima vpisanih $NDatum učencev.";
            echo "</td>";
            echo "</tr>";
            
            //vpisane zaključne ocene
            if ($VRazred1 < 3){
                //opisne ocene - preveri, če je kdo, ki nima vpisane nobene v nobeni od tabel
                $SQL = "SELECT iducenec FROM tabrazred WHERE iducitelj=".$VUporabnikId." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                $iu=1;
                while ($R = mysqli_fetch_array($result)){
                     $ucenci[$iu]=$R["iducenec"];
                     $iu += 1;
                }
                $StUcencev=$iu-1;
                $NNeocenjeno=0;
                for ($iu=1;$iu <= $StUcencev;$iu++){
                    //izbiranje s kljukicami
                    $NOcen1[$iu]=0;
                    $NOcen2[$iu]=0;
                    $NOcen3[$iu]=0;
                    $SQL = "SELECT iducenec FROM tabopocene WHERE leto=".$VLeto." AND iducenec=".$ucenci[$iu]." AND tip=0";
                    $result = mysqli_query($link,$SQL);
                    if (mysqli_num_rows($result) == 0){
                        $NOcen1[$iu] += 1;
                    }
                    //ocenjevanje z ocenami ciljev
                    $SQL = "SELECT iducenec FROM tabopocenen WHERE leto=".$VLeto." AND iducenec=".$ucenci[$iu]." AND tip=0";
                    $result = mysqli_query($link,$SQL);
                    if (mysqli_num_rows($result) == 0){
                        $NOcen2[$iu] += 1;
                    }
                    //ročni vpisi
                    $SQL = "SELECT ucenec,slo,mat,spo,lvz,gvz,svz FROM tabopocucenec WHERE leto=".$VLeto." AND ucenec=".$ucenci[$iu];
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        if (isset($R["slo"])){
                            if (strlen($R["slo"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                        
                        if (isset($R["mat"])){
                            if (strlen($R["mat"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                        if (isset($R["spo"])){
                            if (strlen($R["spo"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                        if (isset($R["lvz"])){
                            if (strlen($R["lvz"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                        if (isset($R["gvz"])){
                            if (strlen($R["gvz"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                        if (isset($R["svz"])){
                            if (strlen($R["svz"]) == 0){
                                $NOcen3[$iu] += 1;
                            }
                        }else{
                            $NOcen3[$iu] += 1;
                        }
                    }else{
                        $NOcen3[$iu] += 1;
                    }
                    if ($NOcen1[$iu] > 0 && $NOcen2[$iu] > 0 && $NOcen3[$iu] > 0){
                        $NNeocenjeno += 1;
                    }
                }
                echo "<tr>";
                echo "<td>";
                echo "<a href='opisneocene.php?idd=200'>Vnos opisnih ocen (kljukice ali ročno)</a><br />";
                echo "<a href='opisneocenen.php?idd=200'>Vnos opisnih ocen (ocenjevanje ciljev)</a>";
                echo "</td>";
                if ($NNeocenjeno > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($NNeocenjeno > 0){
                    echo "V vašem razredu je $NNeocenjeno učencev brez zaključnih ocen.";
                }else{
                    echo "V vašem razredu ni učencev brez zaključnih ocen.";
                }                        
                echo "</td>";
                echo "</tr>";
            }else{
                //številčne ocene
                $NNeocenjeno=0;
                $NOpraviceno=0;
                $NNezakljuceno=0;
                $SQL = "SELECT tabocene.neocenjen,tabocene.ocenakoncna FROM tabrazred ";
                $SQL .= "LEFT JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec ";
                $SQL .= "WHERE idrazred=".$VRazred." AND tabocene.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                     if (isset($R["neocenjen"])){
                         switch ($R["neocenjen"]){
                             case 1:
                                $NNeocenjeno += 1;
                                break;
                             case 2:
                                $NOpraviceno += 1;                                
                                break;
                             default:
                                if (isset($R["ocenakoncna"])){
                                    if (intval($R["ocenakoncna"]) == 0){
                                        $NNezakljuceno += 1;
                                    }
                                }
                         }
                     }
                }
                echo "<tr>";
                echo "<td><a href='izpisredovalnice.php?id=4&razred=$VRazred&solskoleto=$VLeto'>Vnos ocen v redovalnico</a></td>";
                if ($NNezakljuceno > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($NNezakljuceno > 0){
                    echo "Neocenjenih je $NNeocenjeno učencev, ocenjevanja opravičenih je $NOpraviceno učencev, nezaključenih je $NNezakljuceno ocen v vašem razredu.";
                }else{
                    echo "Vsi učenci v vašem razredu imajo zaključne ocene (neocenjenih je $NNeocenjeno učencev, ocenjevanja opravičenih je $NOpraviceno učencev).";
                }
                echo "</td>";
                echo "</tr>";
            }
            
            //pedagoško poročilo - polletno
            $Komentar="";
            $UcnoVzgDelo="";
            $Pohvale="";
            $VzgUkrepi="";
            $Uspehi="";
            $Priporocila="";
            $SQL = "SELECT id,komentar,ucnovzgdelo,pohvale,vzgukrepi,uspehi,priporocila FROM tabrazrednikpor WHERE leto=".$VLeto." AND razrednik=".$VUporabnikId." AND idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $Porocilo=true;
                $Komentar=mb_substr($R["komentar"],0,25,$encoding);
                $UcnoVzgDelo=mb_substr($R["ucnovzgdelo"],0,25,$encoding);
                $Pohvale=mb_substr($R["pohvale"],0,25,$encoding);
                $VzgUkrepi=mb_substr($R["vzgukrepi"],0,25,$encoding);
                $Uspehi=mb_substr($R["uspehi"],0,25,$encoding);
                $Priporocila=mb_substr($R["priporocila"],0,25,$encoding);
            }else{
                $Porocilo=false;
            }
            echo "<tr>";
            echo "<td><a href='PedPorocilo.php?id=0a'>Vnos polletnega pedagoškega poročila</a></td>";
            if (!$Porocilo){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Komentar){
                echo $Komentar." ...<br />";
            }
            if ($UcnoVzgDelo){
                echo $UcnoVzgDelo." ...<br />";
            }
            if ($Pohvale){
                echo $Pohvale." ...<br />";
            }
            if ($VzgUkrepi){
                echo $VzgUkrepi." ...<br />";
            }
            if ($Uspehi){
                echo $Uspehi." ...<br />";
            }
            if ($Priporocila){
                echo $Priporocila." ...";
            }
            echo "</td>";
            echo "</tr>";
            
            //pedagoško poročilo - končno
            $Komentar="";
            $UcnoVzgDelo="";
            $Pohvale="";
            $VzgUkrepi="";
            $Uspehi="";
            $Priporocila="";
            $SQL = "SELECT id,komentar,ucnovzgdelo,pohvale,vzgukrepi,uspehi,priporocila FROM tabrazrednikpork WHERE leto=".$VLeto." AND razrednik=".$VUporabnikId." AND idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $Porocilo=true;
                $Komentar=mb_substr($R["komentar"],0,25,$encoding);
                $UcnoVzgDelo=mb_substr($R["ucnovzgdelo"],0,25,$encoding);
                $Pohvale=mb_substr($R["pohvale"],0,25,$encoding);
                $VzgUkrepi=mb_substr($R["vzgukrepi"],0,25,$encoding);
                $Uspehi=mb_substr($R["uspehi"],0,25,$encoding);
                $Priporocila=mb_substr($R["priporocila"],0,25,$encoding);
            }else{
                $Porocilo=false;
            }
            echo "<tr>";
            echo "<td><a href='PedPorocilo.php?id=0b'>Vnos končnega pedagoškega poročila</a></td>";
            if (!$Porocilo){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Komentar){
                echo $Komentar." ...<br />";
            }
            if ($UcnoVzgDelo){
                echo $UcnoVzgDelo." ...<br />";
            }
            if ($Pohvale){
                echo $Pohvale." ...<br />";
            }
            if ($VzgUkrepi){
                echo $VzgUkrepi." ...<br />";
            }
            if ($Uspehi){
                echo $Uspehi." ...<br />";
            }
            if ($Priporocila){
                echo $Priporocila." ...";
            }
            echo "</td>";
            echo "</tr>";
            
            //razredna realizacija
            if ($SemaforRealizacija){
                $SQL = "SELECT planpol,realizacijapol,plan,realizacija FROM tabrealizacija WHERE idrazred=".$VRazred;
                $result = mysqli_query($link,$SQL);
                $NiVpisa1=0;
                $NiVpisa2=0;
                while ($R = mysqli_fetch_array($result)){
                    if (isset($R["realizacija"])){
                        if ($R["realizacija"] == 0 && $R["plan"] > 0){
                            $NiVpisa2 += 1;
                        }
                    }else{
                        $NiVpisa2 += 1;
                    }
                    if (isset($R["realizacijapol"])){
                        if ($R["realizacijapol"] == 0 && $R["planpol"] > 0){
                            $NiVpisa1 += 1;
                        }
                    }else{
                        $NiVpisa1 += 1;
                    }
                }
                echo "<tr>";
                echo "<td>";
                echo "<a href='VnosRealizacije.php?razred=$VRazred'>Realizacija ur za razred</a><br />";
                echo "</td>";
                if ($NiVpisa1 > 0 or $NiVpisa2 > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($NiVpisa1+$NiVpisa2 > 0){
                    echo "Manjka realizacija za $NiVpisa1 dejavnosti ob polletju in za $NiVpisa2 ob koncu leta.";
                }else{
                    echo "Vpisana je vsa realizacija.";
                }
                echo "</td>";
                echo "</tr>";
            }
            //opb in juv
            if ($VRazred1 < 6){
                $SQL = "SELECT iducenec FROM tabrazred WHERE iducitelj=".$VUporabnikId." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                $iu=1;
                while ($R = mysqli_fetch_array($result)){
                     $ucenci[$iu]=$R["iducenec"];
                     $iu += 1;
                }
                $StUcencev=$iu-1;
                $Nvpisano=$StUcencev;
                for ($iu=1;$iu <= $StUcencev;$iu++){
                    $SQL = "SELECT id FROM tabopb ";
                    $SQL .= "WHERE iducenec=".$ucenci[$iu]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Nvpisano -= 1;
                    }
                }
                echo "<tr>";
                echo "<td>";
                echo "<a href='izborrazreda.php?id=opb'>Vnos učancev za OPB in JUV</a><br />";
                echo "</td>";
                if ($Nvpisano > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($Nvpisano > 0){
                    echo "Manjkajo podatki o OPB in JUV za $Nvpisano učencev.";
                }else{
                    echo "Vsi podatki o OPB in JUV so vpisani.";
                }
                echo "</td>";
                echo "</tr>";
            }
            
            //predstavniki v svet staršev
            $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            $Vpis=0;
            while ($R = mysqli_fetch_array($result)){
                $SQL = "SELECT svet FROM tabsvetstarsev WHERE iducenec=".$R["iducenec"];
                $result1 = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result1)){
                    $Vpis += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='izpisrazreda.php?id=5&razred=$VRazred'>Predstavniki v svetu staršev</a><br />";
            echo "</td>";
            if ($Vpis == 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Vpis == 0){
                echo "Manjkajo predstavniki v svetu staršev.";
            }else{
                echo "Predstavniki v svetu staršev so vpisani.";
            }
            echo "</td>";
            echo "</tr>";

            //soglasja staršev
            $SQL = "SELECT tabdovoljenja.id FROM tabrazred ";
            $SQL .= "LEFT JOIN tabdovoljenja ON tabrazred.iducenec=tabdovoljenja.iducenec ";
            $SQL .= "WHERE idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            $NiVpisa=0;
            while ($R = mysqli_fetch_array($result)){
                if (!isset($R["id"])){
                    $NiVpisa += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='vnosispiski.php?idd=108&razred=$VRazred'>Soglasja za objave in zdrav življenski slog</a><br />";
            echo "</td>";
            if ($NiVpisa > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($NiVpisa){
                echo "Manjka vpis soglasij za $NiVpisa učencev.";
            }else{
                echo "Vsi učenci imajo vpisana soglasja.";
            }
            echo "</td>";
            echo "</tr>";
            
            //podatki o naročilu prehrane
            if ($SemaforPrehrana){
                $SQL = "SELECT tabprehrana.id FROM tabrazred ";
                $SQL .= "LEFT JOIN tabprehrana ON tabrazred.iducenec=tabprehrana.iducenec ";
                $SQL .= "WHERE tabrazred.idrazred=".$VRazred;
                $result = mysqli_query($link,$SQL);
                $NiVpisa=0;
                while ($R = mysqli_fetch_array($result)){
                    if (!isset($R["id"])){
                        $NiVpisa += 1;
                    }
                }
                echo "<tr>";
                echo "<td>";
                echo "<a href='vnosispiski.php?idd=105&razred=$VRazred'>Naročilo prehrane</a><br />";
                echo "</td>";
                if ($NiVpisa > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($NiVpisa > 0){
                    echo "Manjkajo podatki za $NiVpisa učencev.";
                }else{
                    echo "Vsi učenci imajo vpisane podatki o prehrani.";
                }
                echo "</td>";
                echo "</tr>";
                
                //mesečni podatki o malici
                $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
                $result = mysqli_query($link,$SQL);
                $iu=1;
                while ($R = mysqli_fetch_array($result)){
                     $ucenci[$iu]=$R["iducenec"];
                     $iu += 1;
                }
                $StUcencev= $iu-1;
                $malic[1]=$StUcencev;
                $malic[2]=$StUcencev;
                $malic[3]=$StUcencev;
                $malic[4]=$StUcencev;
                $malic[5]=$StUcencev;
                $malic[6]=$StUcencev;
                $malic[9]=$StUcencev;
                $malic[10]=$StUcencev;
                $malic[11]=$StUcencev;
                $malic[12]=$StUcencev;
                for ($iu=1;$iu <= $StUcencev;$iu++){
                    $SQL = "SELECT DISTINCT tabmalica.iducenec,tabmalica.mesec,tabmalica.leto FROM tabmalica ";
                    $SQL .= "WHERE tabmalica.iducenec=".$ucenci[$iu]." AND ((leto=".$VLeto." AND mesec > 8) OR (leto=".($VLeto+1)." AND mesec < 7))";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $malic[intval($R["mesec"])] -= 1;
                    }
                }
                echo "<tr>";
                echo "<td>";
                echo "<a href='izborrazreda.php?id=malice'>Vnos podatkov o malicah</a><br />";
                echo "</td>";
                if ($malic[1]+$malic[2]+$malic[3]+$malic[4]+$malic[5]+$malic[6]+$malic[9]+$malic[10]+$malic[11]+$malic[12] > 0){
                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                }else{
                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                }
                echo "<td>";
                if ($malic[1]+$malic[2]+$malic[3]+$malic[4]+$malic[5]+$malic[6]+$malic[9]+$malic[10]+$malic[11]+$malic[12] > 0){
                    echo "Po mesecih manjkajo vpisi za št. učencev: ";
                    if ($malic[9] > 0){
                        echo "sep ".$malic[9].", ";
                    }
                    if ($malic[10] > 0){
                        echo "okt ".$malic[10].", ";
                    }
                    if ($malic[11] > 0){
                        echo "nov ".$malic[11].", ";
                    }
                    if ($malic[12] > 0){
                        echo "dec ".$malic[12].", ";
                    }
                    if ($malic[1] > 0){
                        echo "jan ".$malic[1].", ";
                    }
                    if ($malic[2] > 0){
                        echo "feb ".$malic[2].", ";
                    }
                    if ($malic[3] > 0){
                        echo "mar ".$malic[3].", ";
                    }
                    if ($malic[4] > 0){
                        echo "apr ".$malic[4].", ";
                    }
                    if ($malic[5] > 0){
                        echo "maj ".$malic[5].", ";
                    }
                    if ($malic[6] > 0){
                        echo "jun ".$malic[6];
                    }
                }else{
                    echo "Vpisani so podatki za vse učence.";
                }
                echo "</td>";
                echo "</tr>";
            }
            //mesečni izostanki
            /*
            $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
            $result = mysqli_query($link,$SQL);
            $iu=1;
            while ($R = mysqli_fetch_array($result)){
                 $ucenci[$iu]=$R["iducenec"];
                 $iu += 1;
            }
            $StUcencev= $iu-1;
            */
            $ods[1]=$StUcencev;
            $ods[2]=$StUcencev;
            $ods[3]=$StUcencev;
            $ods[4]=$StUcencev;
            $ods[5]=$StUcencev;
            $ods[6]=$StUcencev;
            $ods[9]=$StUcencev;
            $ods[10]=$StUcencev;
            $ods[11]=$StUcencev;
            $ods[12]=$StUcencev;
            for ($iu=1;$iu <= $StUcencev;$iu++){
                $SQL = "SELECT iducenec,mesec,leto FROM tabprisotnost ";
                $SQL .= "WHERE tabprisotnost.iducenec=".$ucenci[$iu]." AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $ods[intval($R["mesec"])] -= 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='izborrazreda.php?id=odsotnost'>Vnos podatkov o izostankih učencev</a><br />";
            echo "</td>";
            if ($ods[1]+$ods[2]+$ods[3]+$ods[4]+$ods[5]+$ods[6]+$ods[9]+$ods[10]+$ods[11]+$ods[12] > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($ods[1]+$ods[2]+$ods[3]+$ods[4]+$ods[5]+$ods[6]+$ods[9]+$ods[10]+$ods[11]+$ods[12] > 0){
                echo "Po mesecih manjkajo vpisi za št. učencev: ";
                if ($ods[9] > 0){
                    echo "sep ".$ods[9].", ";
                }
                if ($ods[10] > 0){
                    echo "okt ".$ods[10].", ";
                }
                if ($ods[11] > 0){
                    echo "nov ".$ods[11].", ";
                }
                if ($ods[12] > 0){
                    echo "dec ".$ods[12].", ";
                }
                if ($ods[1] > 0){
                    echo "jan ".$ods[1].", ";
                }
                if ($ods[2] > 0){
                    echo "feb ".$ods[2].", ";
                }
                if ($ods[3] > 0){
                    echo "mar ".$ods[3].", ";
                }
                if ($ods[4] > 0){
                    echo "apr ".$ods[4].", ";
                }
                if ($ods[5] > 0){
                    echo "maj ".$ods[5].", ";
                }
                if ($ods[6] > 0){
                    echo "jun ".$ods[6];
                }
            }else{
                echo "Vpisani so vsi podatki o odsotnostih.";
            }
            echo "</td>";
            echo "</tr>";
        }
        
        //podatki vodij aktivov
        if (strlen($VAktiv) > 0){
            //poročilo aktiva
            $SQL = "SELECT id,programdela FROM tabaktivporocilo WHERE leto=".$VLeto." AND aktiv=".$VIdAktiv;
            $result = mysqli_query($link,$SQL);
            $NiVpisa=0;
            $Vsebina="";
            if ($R = mysqli_fetch_array($result)){
                $NiVpisa += 1;
                $Vsebina=mb_substr($R["programdela"],0,25,$encoding);
            }

            echo "<tr>";
            echo "<td>";
            echo "<a href='IzborAktiviPorocilo.php?id=1a'>Vnos poročila aktiva</a><br />";
            echo "</td>";
            if ($NiVpisa == 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if (strlen($Vsebina) > 0){
                echo $Vsebina." ...";
            }else{
                echo "Ni vsebine!";
            }
            echo "</td>";
            echo "</tr>";
        }
        if (strlen($VAktiv) > 0){
            //načrt aktiva
            $SQL = "SELECT id,programdela FROM tabaktivplan WHERE leto=".($VLeto+1)." AND aktiv=".$VIdAktiv;
            $result = mysqli_query($link,$SQL);
            $NiVpisa=0;
            $Vsebina="";
            if ($R = mysqli_fetch_array($result)){
                $NiVpisa += 1;
                $Vsebina=mb_substr($R["programdela"],0,25,$encoding);
            }

            echo "<tr>";
            echo "<td>";
            echo "<a href='IzborAktiviPorocilo.php?id=1b'>Vnos načrta dela aktiva za naslednje ŠL</a><br />";
            echo "</td>";
            if ($NiVpisa == 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if (strlen($Vsebina) > 0){
                echo $Vsebina." ...";
            }else{
                echo "Ni vsebine!";
            }
            echo "</td>";
            echo "</tr>";
        }
        
        //podatki nerazrednikov
        
        //nezaključene ocene
        $StNeocenjenih=0;
        $SQL = "SELECT tabucenje.predmet,tabucenje.idrazred,tabpredmeti.prioriteta,tabpredmeti.oznaka AS poznaka,tabrazdat.razred,tabrazdat.oznaka FROM (tabucenje ";
        $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id) ";
        $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
        $SQL .= "WHERE tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.leto=".$VLeto." AND tabucenje.idrazred > 0 AND tabpredmeti.prioriteta IN (0,1)";
        $result = mysqli_query($link,$SQL);
        $NeocRazredi="";
        while ($R = mysqli_fetch_array($result)){
            $StN=$StNeocenjenih;
            $SQL = "SELECT tabocene.neocenjen,tabocene.ocenakoncna,tabocene.iducenec FROM tabrazred ";
            $SQL .="INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec ";
            $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazred.idrazred=".$R["idrazred"]." AND tabocene.idpredmet=".$R["predmet"];
            $result1 = mysqli_query($link,$SQL);
            while ($R1 = mysqli_fetch_array($result1)){
                if ($R["prioriteta"] == 1){
                    //izbirni predmet
                    $SQL = "SELECT id FROM tabizbirni WHERE leto=".$VLeto." AND ucenec=".$R1["iducenec"]." AND izbirni=".$R["predmet"];
                    $result2 = mysqli_query($link,$SQL);
                    if ($R2 = mysqli_fetch_array($result2)){
                        if (intval($R1["ocenakoncna"]) == 0 && $R1["neocenjen"] == 0){
                            $StNeocenjenih += 1;
                        }
                    }
                }else{
                    if (intval($R1["ocenakoncna"]) == 0 &&  $R1["neocenjen"] == 0){
                        $StNeocenjenih += 1;
                    }
                }
            }
            if ($StN < $StNeocenjenih){
                $NeocRazredi .= "<a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>".$R["razred"].$R["oznaka"]."-".$R["poznaka"]."</a>"." ";
            }
        }
        echo "<tr>";
        echo "<td>";
        echo "<a href='izpisredovalnice.php'>Ocene učencev</a><br />";
        echo "</td>";
        if ($StNeocenjenih > 0){
            echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
        }else{
            echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
        }
        echo "<td>";
        if ($StNeocenjenih > 0){
            echo "Manjka $StNeocenjenih zaključnih ocen pri vaših predmetih. ".$NeocRazredi;
        }else{
            echo "Vsi vaši učenci imajo zaključne ocene.";
        }
        echo "</td>";
        echo "</tr>";
        
        //poročila o tekmovanjih v znanju
        $Nepopoln=0;
        $SQL = "SELECT porocilo FROM tabdrtekm WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["porocilo"])){
                    if (strlen($R["porocilo"]) == 0){
                        $Nepopoln += 1;
                    }
                }else{
                    $Nepopoln += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju</a><br />";
            echo "</td>";
            if ($Nepopoln > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Nepopoln > 0){
                echo "Vpisanih imate $Nepopoln tekmovanj brez poročil.";
            }else{
                echo "Vsa vaša tekmovanja vsebujejo poročila.";
            }
            echo "</td>";
            echo "</tr>";
        }else{
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju</a><br />";
            echo "</td>";
            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
            echo "<td>";
            echo "Na vaše ime ni vpisanih tekmovanj v znanju.";
            echo "</td>";
            echo "</tr>";
        }
     
        //poročila o interesnih dejavnostih
        $Nepopoln=0;
        $SQL = "SELECT porocilo FROM tabkrozki WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["porocilo"])){
                    if (strlen($R["porocilo"]) == 0){
                        $Nepopoln += 1;
                    }
                }else{
                    $Nepopoln += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a><br />";
            echo "</td>";
            if ($Nepopoln > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Nepopoln > 0){
                echo "Vpisanih imate $Nepopoln interesnih dejavnosti brez poročil.";
            }else{
                echo "Vse vaše interesne dejavnosti imajo vpisana poročila.";
            }
            echo "</td>";
            echo "</tr>";
        }else{
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a><br />";
            echo "</td>";
            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
            echo "<td>";
            echo "Na vaše ime ni vpisanih interesnih dejavnosti.";
            echo "</td>";
            echo "</tr>";
        }

        //poročila o šolskih športnih tekmovanjih
        $Nepopoln=0;
        $SQL = "SELECT porocilo FROM tabsst WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["porocilo"])){
                    if (strlen($R["porocilo"]) == 0){
                        $Nepopoln += 1;
                    }
                }else{
                    $Nepopoln += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=301'>Šolska športna tekmovanja</a><br />";
            echo "</td>";
            if ($Nepopoln > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($Nepopoln > 0){
                echo "Vpisanih imate $Nepopoln šolskih športnih tekmovanj brez poročil.";
            }else{
                echo "Vsa vaša šolska športna tekmovanja imajo vpisana poročila.";
            }
            echo "</td>";
            echo "</tr>";
        }else{
            echo "<tr>";
            echo "<td>";
            echo "<a href='tekmovanjakrozki.php?id=201'>Šolska športna tekmovanja</a><br />";
            echo "</td>";
            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
            echo "<td>";
            echo "Na vaše ime ni vpisanih šolskih športnih tekmovanj.";
            echo "</td>";
            echo "</tr>";
        }

        //realizacija po učiteljih
        if ($SemaforRealizacija){
            $SQL = "SELECT tabrealizacija.planpol,tabrealizacija.realizacijapol,tabrealizacija.plan,tabrealizacija.realizacija FROM tabrealizacija ";
            $SQL .= "INNER JOIN tabucenje ON tabrealizacija.ucenje=tabucenje.id ";
            $SQL .= "WHERE tabucenje.iducitelj=".$VUporabnikId." AND tabrealizacija.leto=".$VLeto." AND tabucenje.leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            $NiVpisa1=0;
            $NiVpisa2=0;
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["realizacija"])){
                    if ($R["realizacija"] == 0 && $R["plan"] > 0){
                        $NiVpisa2 += 1;
                    }
                }else{
                    $NiVpisa2 += 1;
                }
                if (isset($R["realizacijapol"])){
                    if ($R["realizacijapol"] == 0 && $R["planpol"] > 0){
                        $NiVpisa1 += 1;
                    }
                }else{
                    $NiVpisa1 += 1;
                }
            }
            echo "<tr>";
            echo "<td>";
            echo "<a href='VnosRealizacijeInd.php?ucitelj=$VUporabnikId'>Realizacija ur po učiteljih</a><br />";
            echo "</td>";
            if ($NiVpisa1 > 0 or $NiVpisa2 > 0){
                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
            }else{
                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
            }
            echo "<td>";
            if ($NiVpisa1+$NiVpisa2 > 0){
                echo "Manjka realizacija za $NiVpisa1 dejavnosti ob polletju in za $NiVpisa2 ob koncu leta.";
            }else{
                echo "Vse vaše dejavnosti imajo vpisano realizacijo.";
            }
            echo "</td>";
            echo "</tr>";
        }
        echo "</table><br />";
        echo "<hr>";
    }
}

?>
<br />

</body>
</html>
