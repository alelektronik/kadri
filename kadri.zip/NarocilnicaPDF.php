<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }

    $pdf = new FPDF();

    //$pdf->AddFont('EAN_b','','EAN_b.php');
    $pdf->AddFont('arial_CE','','arial_CE.php');
    $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
    $pdf->SetAutoPageBreak(0);

    $XPoz[1]=12;
    $XPoz[2]=42;
    $XPoz[3]=63;
    $XPoz[4]=103;
    $XPoz[5]=123;
    $XPoz[6]=190;
    
    $trr="";
    $SQL = "SELECT solakratko,naslov,posta,kraj,email,internet,telefon,ddv_id,zavezanecddv,trr,UstanovaIDmin FROM tabsola";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        if ($R["zavezanecddv"]=="DA"){
            $podatkisole=$R["solakratko"].", ".$R["naslov"].", ".$R["posta"]." ".$R["kraj"].", mat. št.: ".$R["UstanovaIDmin"].", telefon: ".$R["telefon"].", www: ".$R["internet"].", e-pošta: ".$R["email"].", davčna številka: ".$R["ddv_id"].", zavezanec za DDV: DA, TRR: ".$R["trr"];
        }else{
            $podatkisole=$R["solakratko"].", ".$R["naslov"].", ".$R["posta"]." ".$R["kraj"].", mat. št.: ".$R["UstanovaIDmin"].", telefon: ".$R["telefon"].", www: ".$R["internet"].", e-pošta: ".$R["email"].", davčna številka: ".$R["ddv_id"].", zavezanec za DDV: NE, TRR: ".$R["trr"];
        }
        $trr=$R["trr"];
    }
    
    $SQL = "SELECT * FROM TabNarocilnica ";
    $SQL = $SQL ."WHERE id=".$Vid;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        $pdf->AddPage("P","A4");
        $pdf->Image("logo1.gif",$XPoz[1],10,30);

        $pdf->SetFont('arialbd_CE','',16);
        $txt=ToWin("Naročilnica\nŠt.: ".($R["ZapSt"]."/".$R["leto"]));
        $pdf->SetXY($XPoz[2]+20,10);
        $pdf->MultiCell($XPoz[5]-$XPoz[2],8,$txt,0,"C");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Izdajatelj:");
        $pdf->SetXY($XPoz[1],66);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $pdf->SetFont('arialbd_CE','',12);
        $txt=ToWin($R["Izdajatelj"]);
        $pdf->SetXY($XPoz[3],66);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("ID št. za DDV:");
        $pdf->SetXY($XPoz[1],75);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $pdf->SetFont('arialbd_CE','',12);
        if ($R["Zavezanec"]){
            $txt=ToWin("SI".$R["Davcna"]);
        }else{
            $txt=ToWin($R["Davcna"]);
        }
        $pdf->SetXY($XPoz[3],75);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Zavezanec za DDV:");
        $pdf->SetXY($XPoz[1],80);
        $pdf->MultiCell(0,5,$txt,0,"L");

        if ($R["Zavezanec"]){
            $txt="DA";
        }else{
            $txt="NE";
        }
        $pdf->SetFont('arialbd_CE','',12);
        $pdf->SetXY($XPoz[3],80);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("TRR:");
        $pdf->SetXY($XPoz[1],85);
        $pdf->MultiCell(0,5,$txt,0,"L");
        $txt=ToWin($trr);
        $pdf->SetFont('arialbd_CE','',12);
        $pdf->SetXY($XPoz[3],85);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Kraj izdaje:");
        $pdf->SetXY($XPoz[1],90);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $pdf->SetFont('arialbd_CE','',12);
        $txt=ToWin($R["Kraj"]);
        $pdf->SetXY($XPoz[3],90);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Datum izdaje:");
        $pdf->SetXY($XPoz[1],95);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $pdf->SetFont('arialbd_CE','',12);
        $txt=ToWin($R["DatumIzd"]);
        $pdf->SetXY($XPoz[3],95);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Dobavitelj:");
        $pdf->SetXY($XPoz[1],110);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $pdf->SetFont('arialbd_CE','',12);
        $txt=ToWin($R["Dobavitelj"]);
        $pdf->SetXY($XPoz[3],110);
        $pdf->MultiCell($XPoz[6]-$XPoz[2],5,$txt,0,"L");

        $pdf->SetFont('arial_CE','',12);
        $txt=ToWin("Naročamo:");
        $pdf->SetXY($XPoz[1],130);
        $pdf->MultiCell(0,5,$txt,0,"L");

        $Narocilo=explode("\n",$R["VrstaBlaga"]);
        $txt="";
        for ($i=0;$i < count($Narocilo);$i++){
            $txt=$txt.$Narocilo[$i]."\n";
        }
		if (intval($R["znesek"]) > 0){
			$txt=$txt."do višine zneska (EUR): ".number_format($R["znesek"],2,",",".")."\n";
		}
        if (count($Narocilo) < 12){
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin($txt);
            $pdf->SetXY($XPoz[1],135);
            $pdf->MultiCell($XPoz[6]-$XPoz[1],5,$txt,1,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Na računu navedite številko naročilnice!");
            $pdf->SetXY($XPoz[1],145+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Plačilo v roku 30 dni od izdaje e-računa.");
            $pdf->SetXY($XPoz[1],150+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            if (isset($R["InterniNarocnik"])){
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Naročil:");
                $pdf->SetXY($XPoz[4],165+(count($Narocilo)+1)*7);
                $pdf->MultiCell(0,5,$txt,0,"L");
                
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin($R["InterniNarocnik"]);
                $pdf->SetXY($XPoz[5],165+(count($Narocilo)+1)*7);
                $pdf->MultiCell(0,5,$txt,0,"L");
            }
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Odobril:");
            $pdf->SetXY($XPoz[4],175+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arialbd_CE','',12);
            $txt=ToWin($R["Narocil"]);
            $pdf->SetXY($XPoz[5],175+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Datum:");
            $pdf->SetXY($XPoz[4],185+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arialbd_CE','',12);
            $txt=ToWin($R["DatumIzd"]);
            $pdf->SetXY($XPoz[5],185+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Žig");
            $pdf->SetXY($XPoz[3]+20,195+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Podpis:___________________");
            $pdf->SetXY($XPoz[4],195+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Odpremil:");
            $pdf->SetXY($XPoz[1],175+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Datum:");
            $pdf->SetXY($XPoz[1],185+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Podpis:___________________");
            $pdf->SetXY($XPoz[1],195+(count($Narocilo)+1)*7);
            $pdf->MultiCell(0,5,$txt,0,"L");
        }else{
            $pdf->SetFont('arial_CE','',7);
            $txt=ToWin($txt);
            $pdf->SetXY($XPoz[1],135);
            $pdf->MultiCell($XPoz[6]-$XPoz[1],3,$txt,1,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Na računu navedite številko naročilnice!");
            $pdf->SetXY($XPoz[1],145+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Plačilo v roku 30 dni od izdaje e-računa.");
            $pdf->SetXY($XPoz[1],150+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            if (isset($R["InterniNarocnik"])){
                $pdf->SetFont('arial_CE','',12);
                $txt=ToWin("Naročil:");
                $pdf->SetXY($XPoz[4],165+(count($Narocilo)+1)*3);
                $pdf->MultiCell(0,5,$txt,0,"L");
                
                $pdf->SetFont('arialbd_CE','',12);
                $txt=ToWin($R["InterniNarocnik"]);
                $pdf->SetXY($XPoz[5],165+(count($Narocilo)+1)*3);
                $pdf->MultiCell(0,5,$txt,0,"L");
            }
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Odobril:");
            $pdf->SetXY($XPoz[4],175+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arialbd_CE','',12);
            $txt=ToWin($R["Narocil"]);
            $pdf->SetXY($XPoz[5],175+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Datum:");
            $pdf->SetXY($XPoz[4],185+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arialbd_CE','',12);
            $txt=ToWin($R["DatumIzd"]);
            $pdf->SetXY($XPoz[5],185+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Žig");
            $pdf->SetXY($XPoz[3]+20,195+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Podpis:___________________");
            $pdf->SetXY($XPoz[4],195+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");

            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Odpremil:");
            $pdf->SetXY($XPoz[1],175+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Datum:");
            $pdf->SetXY($XPoz[1],185+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
            
            $pdf->SetFont('arial_CE','',12);
            $txt=ToWin("Podpis:___________________");
            $pdf->SetXY($XPoz[1],195+(count($Narocilo)+1)*3);
            $pdf->MultiCell(0,5,$txt,0,"L");
        }
        
        $txt=ToWin($podatkisole);
        $pdf->SetFont('arial_CE','',8);
        $pdf->SetXY(20,270);
        $pdf->MultiCell(170,3,$txt,0,"C");
    }
    $pdf->Output("Narocilnica.pdf","D");
}
?>
