<?php
include ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Dodajanje pogodb
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat04",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat05",
            dateFormat:"%d.%m.%Y",
            
            yearsRange:[1940,2080],
            limitToToday:true
        });
    };
</script>
</head>
<body>

<?php
function vsebuje($s,$a){
    //ali niz števil ločenih z vejico $s vsebuje število $a
    $sarr=explode(",",$s);
    for ($i=0;$i < count($sarr);$i++){
        if (intval($a)==intval($sarr[$i])){
            return true;
        }
    }
    return false;
}
function Arr2Str($a){
    $s="";
    if (is_array($a)){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }else{
        return $a;
    }
    return $s;
}
$VLeto=PreberiLeto("leto");

if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
//    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');

    if (!CheckDostop("UpdDel",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["idUcitelj"])){
            $ucitelj = $_POST["idUcitelj"];
        }else{
            if (isset($_GET["idUcitelj"])){
                $ucitelj = $_GET["idUcitelj"];
            }else{
                if (isset($_SESSION["idUcitelj"])){ 
                    $ucitelj = $_SESSION["idUcitelj"];
                }else{
                    $ucitelj = 0;
                }
            }
        }

        if (isset($_POST["id"])){
            $id = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $id=$_GET["id"];
            }else{
                $id = 0;
            }
        }

        $VPogodbenik=$ucitelj;

        switch ($id){
	        case 1:	//'vpiši novo pogodbo
                if (isset($_POST["ustreznost"])){
		            $Vustreznost= $_POST["ustreznost"];
		            if (!is_numeric($Vustreznost)){
			            $Vustreznost=0;
		            }
                }else{
                    $Vustreznost=0;
                }
                if (isset($_POST["delovnomesto"])){
		            $Vdelovnomesto= $_POST["delovnomesto"];
		            if (!is_numeric($Vdelovnomesto)){
			            $Vdelovnomesto=0;
		            }
                }else{
                    $Vdelovnomesto=0;
                }
                if (isset($_POST["delovnicas"])){
		            $Vdelovnicas=$_POST["delovnicas"];
		            if (!is_numeric($Vdelovnicas)){
			            $Vdelovnicas=0;
		            }
                }else{
                    $Vdelovnicas=0;
                }
                if (isset($_POST["vrstadela"])){
		            $Vvrstadela=$_POST["vrstadela"];
		            if (!is_numeric($Vvrstadela)){
			            $Vvrstadela=0;
		            }
                }else{
                    $Vvrstadela=0;
                }
                if (isset($_POST["koeficient"])){
		            $Vkoeficient=$_POST["koeficient"];
		            if (!is_numeric($Vkoeficient)){
			            $Vkoeficient=0;
		            }
                }else{
                    $Vkoeficient=0;
                }
                if (isset($_POST["datumstart"])){
		            $VDatumStart=$_POST["datumstart"];
                }else{
                    $VDatumStart="";
                }
                if (isset($_POST["datumend"])){
		            $VDatumEnd=$_POST["datumend"];
                }else{
                    $VDatumEnd="";
                }
                if (isset($_POST["dopdelo"])){    
			        $VDopDelo="true";
		        }else{
			        $VDopDelo="false";
		        }
                if (isset($_POST["delodaj1"])){
		            $VDelodaj1=$_POST["delodaj1"];
                }else{
                    $VDelodaj1="";
                }
                if (isset($_POST["delodaj1mat"])){
		            $VDelodaj1mat=$_POST["delodaj1mat"];
                }else{
                    $VDelodaj1mat="";
                }
                if (isset($_POST["delodaj1naslov"])){
		            $VDelodaj1naslov=$_POST["delodaj1naslov"];
                }else{
                    $VDelodaj1naslov="";
                }
                if (isset($_POST["delodaj2"])){
		            $VDelodaj2=$_POST["delodaj2"];
                }else{
                    $VDelodaj2="";
                }
                if (isset($_POST["delodaj2mat"])){
		            $VDelodaj2mat=$_POST["delodaj2mat"];
                }else{
                    $VDelodaj2mat="";
                }
                if (isset($_POST["delodaj2naslov"])){
		            $VDelodaj2naslov=$_POST["delodaj2naslov"];
                }else{
                    $VDelodaj2naslov="";
                }
                if (isset($_POST["delodaj3"])){
		            $VDelodaj3=$_POST["delodaj3"];
                }else{
                    $VDelodaj3="";
                }
                if (isset($_POST["delodaj3mat"])){
		            $VDelodaj3mat=$_POST["delodaj3mat"];
                }else{
                    $VDelodaj3mat="";
                }
                if (isset($_POST["delodaj3naslov"])){
		            $VDelodaj3naslov=$_POST["delodaj3naslov"];
                }else{
                    $VDelodaj3naslov="";
                }
                if (isset($_POST["datumpogodbe"])){
		            $VDatumPogodbe=$_POST["datumpogodbe"];
                }else{
                    $VDatumPogodbe="";
                }
                if (isset($_POST["polnidelcas"])){
			        $VPolniDelCas="da";
		        }else{
			        $VPolniDelCas="ne";
		        }
                if (isset($_POST["razlogdolcas"])){    
		            $VRazlogDolCas=$_POST["razlogdolcas"];
                }else{
                    $VRazlogDolCas="";
                }
                if (isset($_POST["potrstrokusp"])){
		            $VPotrStrokUsp=$_POST["potrstrokusp"];
                }else{
                    $VPotrStrokUsp="";
                }
                if (isset($_POST["nazivdelmesta1"])){
		            if (strlen($_POST["nazivdelmesta1"]) > 0){
			            $VNazivDelMesta=$_POST["nazivdelmesta1"];
		            }else{
                        if (isset($_POST["nazivdelmesta"])){
			                $VNazivDelMesta=$_POST["nazivdelmesta"];
                        }else{
                            $VNazivDelMesta="";
                        }
		            }
                }else{
                    if (isset($_POST["nazivdelmesta"])){
                        $VNazivDelMesta=$_POST["nazivdelmesta"];
                    }else{
                        $VNazivDelMesta="";
                    }
                } 
                
                if (isset($_POST["urteden"])){
                    $VUrTeden=$_POST["urteden"];
                }else{
                    $VUrTeden=40;
                }
                if (isset($_POST["izmensko"])){
                    $VIzmensko="true";
                }else{
                    $VIzmensko="false";
                }
                if (isset($_POST["krajdela"])){    
                    $VKrajDela=$_POST["krajdela"];
                }else{
                    $VKrajDela="";
                }
                if (isset($_POST["konkklavz"])){
                    $VKonkKlavz="true";
                }else{
                    $VKonkKlavz="false";
                }
                if (isset($_POST["nacinprenehanja"])){
                    $VNacinPrenehanja=$_POST["nacinprenehanja"];
                }else{
                    $VNacinPrenehanja="";
                }
			    if (isset($_POST["delanaloge"])){
				    $VDelaNaloge=Arr2Str($_POST["delanaloge"]);
			    }else{
				    $VDelaNaloge=0;
			    }
                /*
                if ($EvidencaPrisotnosti ) {
                    if (isset($_POST["DelaNaloge"])){
                        $DelaNaloge=$_POST["DelaNaloge"];
                    }else{
                        $DelaNaloge=0;
                    }
                }
                
                if (isset($_POST["DelaNaloge"])){
                    $VDelaNaloge=$_POST["DelaNaloge"];
                }else{
                    $VDelaNaloge=0;
                }
                */
                if (isset($_POST["stpogodbe"])){
                    $VStPogodbe=$_POST["stpogodbe"];
                }else{
                    $VStPogodbe="";
                }
                if (isset($_POST["ob1"])){
                    $VObremen1=str_replace(",",".",$_POST["ob1"]);
                    if (strlen($_POST["ob1"])==0){
                        $VObremen1=0;
                    }
                }else{
                    $VObremen1=8;
                }
                if (isset($_POST["ob2"])){
                    $VObremen2=str_replace(",",".",$_POST["ob2"]);
                    if (strlen($_POST["ob2"])==0){
                        $VObremen2=0;
                    }
                }else{
                    $VObremen2=8;
                }
                if (isset($_POST["ob3"])){
                    $VObremen3=str_replace(",",".",$_POST["ob3"]);
                    if (strlen($_POST["ob3"])==0){
                        $VObremen3=0;
                    }
                }else{
                    $VObremen3=8;
                }
                if (isset($_POST["ob4"])){
                    $VObremen4=str_replace(",",".",$_POST["ob4"]);
                    if (strlen($_POST["ob4"])==0){
                        $VObremen4=0;
                    }
                }else{
                    $VObremen4=8;
                }
                if (isset($_POST["ob5"])){
                    $VObremen5=str_replace(",",".",$_POST["ob5"]);
                    if (strlen($_POST["ob5"])==0){
                        $VObremen5=0;
                    }
                }else{
                    $VObremen5=8;
                }
                if (isset($_POST["vpism1"])){   
		            $VVpisM1=$_POST["vpism1"];
                }else{
                    $VVpisM1="";
                }
                if (isset($_POST["izpism1"])){
		            $VIzpisM1=$_POST["izpism1"];
                }else{
                    $VIzpisM1="";
                }
                if (isset($_POST["opombe"])){
                    $VOpombe=$_POST["opombe"];
                }else{
                    $VOpombe="";
                }
		        
		        $SQL = "INSERT INTO tabpogodbe (IdUcitelj,IzobUstr,IdDelo,DelovniCas,IdVzgojnoDelo,DatumStart,DatumEnd";
		        $SQL = $SQL . ",DopDelo";
		        $SQL = $SQL . ",Delodaj1,Delodaj1mat,Delodaj1naslov,Delodaj2,Delodaj2mat,Delodaj2naslov,Delodaj3,Delodaj3mat,Delodaj3naslov,DatumPogodbe,PolniDelCas,RazlogDolCas";
		        $SQL = $SQL . ",PotrStrokUsp,NazivDelMesta,UrTeden,Izmensko,KrajDela,KonkKlavz,NacinPrenehanja,Sistemizacija";
		        $SQL = $SQL . ",StPogodbe,obremen1,obremen2,obremen3,obremen4,obremen5,vpisM1,izpisM1,Opombe";
		        $SQL = $SQL . ",cas,vpisal";
		        $SQL = $SQL .")";
		        $SQL = $SQL . " values (".$VPogodbenik."," . $Vustreznost . ",".$Vdelovnomesto.",".$Vdelovnicas.",".$Vvrstadela;
		        $SQL = $SQL .",'".$VDatumStart."','".$VDatumEnd."'";
		        $SQL = $SQL . ",".$VDopDelo;
		        $SQL = $SQL . ",'".$VDelodaj1."','".$VDelodaj1mat."','".$VDelodaj1naslov."','".$VDelodaj2."','".$VDelodaj2mat."','".$VDelodaj2naslov."','".$VDelodaj3."','".$VDelodaj3mat."','".$VDelodaj3naslov."','".$VDatumPogodbe."','".$VPolniDelCas."','".$VRazlogDolCas."'";
		        $SQL = $SQL . ",'".$VPotrStrokUsp."','".$VNazivDelMesta."','".$VUrTeden."',".$VIzmensko.",'".$VKrajDela."',".$VKonkKlavz.",'".$VNacinPrenehanja."','".$VDelaNaloge."'";
		        $SQL = $SQL . ",'".$VStPogodbe."',".$VObremen1.",".$VObremen2.",".$VObremen3.",".$VObremen4.",".$VObremen5;
		        $SQL = $SQL . ",'".$VVpisM1."','".$VIzpisM1."','".$VOpombe."'";
		        $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."'";
		        $SQL = $SQL .")";
		        //'response.write $SQL."<br>"
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    echo $SQL."<br />";
                    die("Napaka pri zapisu pogodbe: ".mysqli_error());
                }
		        
		        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "<h2>Pogodbe delavca: ".$R["Priimek"]." ".$R["Ime"]."</h2>";
		        }
		        
		        echo "<h2>Pogodba je bila dodana!</h2>";
		        echo "<table border='1'>";
		        echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
		        $indx=0;
                $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result)){
			        $indx=$indx+1;
			        echo "<tr>";
			        echo "<td>".$indx."</td>";
			        echo "<td>".$R1["DatumPogodbe"]."</td>";
			        echo "<td>".$R1["StPogodbe"]."</td>";
			        echo "<td>".$R1["DatumStart"]."</td>";
			        echo "<td>".$R1["DatumEnd"]."</td>";
			        echo "<td>".$R1["VpisM1"]."</td>";
			        echo "<td>".$R1["IzpisM1"]."</td>";
			        echo "<td>".$R1["NazivDelMesta"]."</td>";
			        echo "<td>".$R1["UrTeden"]."</td>";
                    echo "<td><textarea cols='20' rows='2'>".$R1["Opombe"]."</textarea></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
			        echo "</tr>";
		        }
		        echo "</table><br />";
		        echo "<a href='DodajPogodbo.php?idUcitelj=".$VPogodbenik."'>Dodaj pogodbo</a>";
                echo "<a href='IzpisUcitelja.php?idUcitelj=".$VPogodbenik."'>Na delavca</a><br />";
                echo "<a href='DodajPogodbo.php?id=6'>Vse pogodbe</a>";
		        break;
	        case 2:	//'briši pogodbo
		        $SQL = "DELETE FROM tabpogodbe WHERE id=".$_GET["brisi"];
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    echo $SQL."<br />";
                    die("Napaka pri brisanju: ".mysqli_error());
                }
		        
		        echo "<h2>Pogodba je zbrisana!</h2>";
                $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Pogodbe delavca: ".$R["Priimek"]." ".$R["Ime"]."</h2>";
                }
                
                echo "<table border='1'>";
                echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
                $indx=0;
                $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result)){
                    $indx=$indx+1;
                    echo "<tr>";
                    echo "<td>".$indx."</td>";
                    echo "<td>".$R1["DatumPogodbe"]."</td>";
                    echo "<td>".$R1["StPogodbe"]."</td>";
                    echo "<td>".$R1["DatumStart"]."</td>";
                    echo "<td>".$R1["DatumEnd"]."</td>";
                    echo "<td>".$R1["VpisM1"]."</td>";
                    echo "<td>".$R1["IzpisM1"]."</td>";
                    echo "<td>".$R1["NazivDelMesta"]."</td>";
                    echo "<td>".$R1["UrTeden"]."</td>";
                    echo "<td><textarea cols='20' rows='2'>".$R1["Opombe"]."</textarea></td>";
                    echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
                    echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                echo "<a href='DodajPogodbo.php?idUcitelj=".$VPogodbenik."'>Dodaj pogodbo</a>";
                echo "<a href='IzpisUcitelja.php?idUcitelj=".$VPogodbenik."'>Na delavca</a><br />";
                echo "<a href='DodajPogodbo.php?id=6'>Vse pogodbe</a>";
                break;
	        case 3:	//'popravi pogodbo
		        $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabpogodbe.* FROM tabpogodbe INNER JOIN tabucitelji ON tabpogodbe.idUcitelj=tabucitelji.idUcitelj WHERE tabpogodbe.id=". $_GET["popravi"];
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        $VPriimek=$R["Priimek"];
			        $VIme=$R["Ime"];
			        $Vustreznost=$R["IzobUstr"];
			        $Vdelovnomesto=$R["IdDelo"];
			        $Vdelovnicas=$R["DelovniCas"];
			        $Vvrstadela=$R["IdVzgojnoDelo"];
			        $Vkoeficient=$R["Koef"];
			        $VDatumStart=$R["DatumStart"];
			        $VDatumEnd=$R["DatumEnd"];
			        
			        $VDopDelo=$R["DopDelo"];
			        $VDelodaj1=$R["Delodaj1"];
			        $VDelodaj1mat=$R["Delodaj1mat"];
			        $VDelodaj1naslov=$R["Delodaj1naslov"];
			        $VDelodaj2=$R["Delodaj2"];
			        $VDelodaj2mat=$R["Delodaj2mat"];
			        $VDelodaj2naslov=$R["Delodaj2naslov"];
			        $VDelodaj3=$R["Delodaj3"];
			        $VDelodaj3mat=$R["Delodaj3mat"];
			        $VDelodaj3naslov=$R["Delodaj3naslov"];
			        $VDatumPogodbe=$R["DatumPogodbe"];
			        $VPolniDelCas=$R["PolniDelCas"];
			        if (strtoupper($VPolniDelCas)=="DA" ){
				        $VPolniDelCas=true;
			        }else{
				        $VPolniDelCas=false;
			        }
			        $VRazlogDolCas=$R["RazlogDolCas"];
			        $VPotrStrokUsp=$R["PotrStrokUsp"];
			        $VNazivDelMesta=$R["NazivDelMesta"];
			        $VUrTeden=$R["UrTeden"];
			        $VIzmensko=$R["Izmensko"];
			        $VKrajDela=$R["KrajDela"];
			        $VKonkKlavz=$R["KonkKlavz"];
			        $VNacinPrenehanja=$R["NacinPrenehanja"];
			        if (isset($R["Sistemizacija"])){
				        $DelaNaloge=$R["Sistemizacija"];
			        }else{
                        $DelaNaloge="";
                    }
			        $VStPogodbe=$R["StPogodbe"];
			        $VObremen1=$R["Obremen1"];
			        if (!is_numeric($VObremen1) ){ 
                        $VObremen1=8;
                    }
			        $VObremen2=$R["Obremen2"];
			        if (!is_numeric($VObremen2) ){ 
                        $VObremen2=8;
                    }
			        $VObremen3=$R["Obremen3"];
			        if (!is_numeric($VObremen3) ){ 
                        $VObremen3=8;
                    }
			        $VObremen4=$R["Obremen4"];
			        if (!is_numeric($VObremen4) ){ 
                        $VObremen4=8;
                    }
			        $VObremen5=$R["Obremen5"];
			        if (!is_numeric($VObremen5) ){ 
                        $VObremen5=8;
                    }
				        
			        $VVpisM1=$R["VpisM1"];
			        $VIzpisM1=$R["IzpisM1"];
                    $VOpombe=$R["Opombe"];
                }else{
			        echo "<h2>Pogodba ne obstaja!</h2>";
		        }

		        if ($VLevel > 1) {
			        echo "<form accept-charset='utf-8' name='popraviPogodbo' method=post action='DodajPogodbo.php'>";
			        echo "<input name='idUcitelj' type='hidden' value='".$VPogodbenik."'>";
			        echo "<input name='popravi' type='hidden' value='".$_GET["popravi"]."'>";
			        echo "<input name='id' type='hidden' value='4'>";
			        echo "<h2>Popravi podatke o pogodbi</h2>";
			        
			        echo "<table>";
			        echo "<tr><td>Priimek in ime: </td><td>".$VPriimek." ".$VIme."</td></tr>";
			        echo "<tr><td>Št. pogodbe: </td><td><input name='stpogodbe' type='text' value='".$VStPogodbe."' size='10'></td></tr>";

			        echo "<tr><td>Ustreznost izobrazbe</td><td>";
			        echo "<select name='ustreznost'>";
			        switch ($Vustreznost){
				        case 0:
					        echo "<option value='0' selected='selected'>Ustrezna</option>";
                            break;
				        case 1:
					        echo "<option value='1' selected='selected'>Neustrezna</option>";
			        }
			        echo "<option value='0'>Ustrezna</option>";
			        echo "<option value='1'>Neustrezna</option>";
			        echo "</select></td></tr>";

			        echo "<tr><td>Delovno mesto (statistika)</td><td>";
			        echo "<select name='delovnomesto'>";
			        $SQL = "SELECT * FROM TabDelo";
                    $Indx = 0;
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
				        if ($R1["IdDelo"]==$Vdelovnomesto ){
					        echo "<option value='".$R1["IdDelo"]."' selected='selected'>".$R1["SkupinaDela"]." - ".$R1["OpisDela"]."</option>";
				        }else{
					        echo "<option value='".$R1["IdDelo"]."'>".$R1["SkupinaDela"]." - ".$R1["OpisDela"]."</option>";
				        }
			        }
			        echo "</select></td></tr>";

			        echo "<tr><td>Delovni čas</td><td>";
			        echo "<select name='delovnicas'>";
			        switch ($Vdelovnicas){
				        case 0:
					        echo "<option value='0' Selected='selected'>Polni delovni čas</option>";
                            break;
				        case 1:
					        echo "<option value='1' Selected='selected'>Krajši delovni čas</option>";
                            break;
				        case 2:
					        echo "<option value='2' Selected='selected'>Ekvivalent polnega delovnega časa</option>";
                            break;
				        case 3:
					        echo "<option value='3' Selected>Na več šolah</option>";
			        }
			        echo "<option value='0'>Polni delovni čas</option>";
			        echo "<option value='1'>Krajši delovni čas</option>";
			        echo "<option value='3'>Na več šolah</option>";
			        echo "</select></td></tr>";

			        echo "<tr><td>Datum pogodbe: </td><td><input name='datumpogodbe' type='text' size='10' value='".$VDatumPogodbe."' id='dat01'></td></tr>";
			        if ($VPolniDelCas ){
				        echo "<tr><td>Polni delovni čas: </td><td><input name='polnidelcas' type='checkbox' checked='checked'></td></tr>";
			        }else{
				        echo "<tr><td>Polni delovni čas: </td><td><input name='polnidelcas' type='checkbox'></td></tr>";
			        }
			        echo "<tr><td>Ur na teden: </td><td><input name='urteden' type='text' size='5' value='".$VUrTeden."'></td></tr>";

			        echo "<tr><td>Tedenska obremenitev</td><td><table><tr><th>PON</th><th>TOR</th><th>SRE</th><th>ČET</th><th>PET</th></tr>";
			        echo "<tr><td><input type='text' name='ob1' value='".$VObremen1."' size='4'></td>";
			        echo "<td><input type='text' name='ob2' value='".$VObremen2."' size='4'></td>";
			        echo "<td><input type='text' name='ob3' value='".$VObremen3."' size='4'></td>";
			        echo "<td><input type='text' name='ob4' value='".$VObremen4."' size='4'></td>";
			        echo "<td><input type='text' name='ob5' value='".$VObremen5."' size='4'></td></tr>";
			        echo "</table></td></tr>";
			        
			        if ($VIzmensko ){
				        echo "<tr><td>Izmensko delo: </td><td><input name='izmensko' type='checkbox' checked='checked'></td></tr>";
			        }else{
				        echo "<tr><td>Izmensko delo: </td><td><input name='izmensko' type='checkbox'></td></tr>";
			        }
			        if ($VKonkKlavz ){
				        echo "<tr><td>Konkurenčna klavzula: </td><td><input name='konkklavz' type='checkbox' checked='checked'></td></tr>";
			        }else{
				        echo "<tr><td>Konkurenčna klavzula: </td><td><input name='konkklavz' type='checkbox'></td></tr>";
			        }

			        echo "<tr><td>Razlog sklenitve pog. za dol. čas: </td><td><input name='razlogdolcas' type='text' size='40' value='".$VRazlogDolCas."'></td></tr>";
			        echo "<tr><td>Potrebna strokovna usposobljenost: </td><td><input name='potrstrokusp' type='text' size='30' value='".$VPotrStrokUsp."'></td></tr>";
			        
			        echo "<tr><td>Naziv del. mesta: </td><td><input name='nazivdelmesta1' type='text' size='30' value='".$VNazivDelMesta."'>Če vpišete tu ročno, bo to vpisano, sicer izberite spodaj<br />";
			        echo "<select name='nazivdelmesta'>";
			        echo "<option>Ni izbran</option>";
			        
			        $SQL = "SELECT * FROM TabDelMesta";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
				        echo "<option>".$R1["DelMesto"]." (".$R1["Sifra"]."]</option>";
			        }
			        echo "</select></td></tr>";
			        
			        echo "<tr><td>Kraj dela: </td><td><input name='krajdela' type='text' size='40' value='".$VKrajDela."'></td></tr>";
			        if ($VDopDelo ){
				        echo "<tr><td>Dopolnjevanje dela: </td><td><input name='dopdelo' type='checkbox' checked='checked'></td></tr>";
			        }else{
				        echo "<tr><td>Dopolnjevanje dela: </td><td><input name='dopdelo' type='checkbox'></td></tr>";
			        }
			        echo "<tr><td>Dopolnilni delodajalec 1: </td><td><input name='delodaj1' type='text' size='30' value='".$VDelodaj1."'></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 1: </td><td><input name='delodaj1mat' type='text' size='10'  value='".$VDelodaj1mat."'></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 1: </td><td><input name='delodaj1naslov' type='text' size='30'  value='".$VDelodaj1naslov."'></td></tr>";
			        echo "<tr><td>Dopolnilni delodajalec 2: </td><td><input name='delodaj2' type='text' size='30' value='".$VDelodaj2."'></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 2: </td><td><input name='delodaj2mat' type='text' size='10'  value='".$VDelodaj2mat."'></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 2: </td><td><input name='delodaj2naslov' type='text' size='30'  value='".$VDelodaj2naslov."'></td></tr>";
			        echo "<tr><td>Dopolnilni delodajalec 3: </td><td><input name='delodaj3' type='text' size='30' value='".$VDelodaj3."'></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 3: </td><td><input name='delodaj3mat' type='text' size='10'  value='".$VDelodaj3mat."'></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 3: </td><td><input name='delodaj3naslov' type='text' size='30'  value='".$VDelodaj3naslov."'></td></tr>";

			        echo "<tr><td>Vrsta dela</td><td>";
			        echo "<select name='vrstadela'>";
			        $SQL = "SELECT * FROM TabVzgDelo";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
				        if ($R1["IdVzgojnoDelo"]==$Vvrstadela ){
					        echo "<option value='".$R1["IdVzgojnoDelo"]."' selected='selected'>".$R1["VzgojnoDelo"]."</option>";
				        }else{
					        echo "<option value='".$R1["IdVzgojnoDelo"]."'>".$R1["VzgojnoDelo"]."</option>";
				        }
			        }
			        echo "</select></td></tr>";
			        
        //			if ($EvidencaPrisotnosti==1 ){
				        if (strlen($DelaNaloge) > 0 ){
					        $SQL = "SELECT * FROM TabSistemizacija WHERE idSistemizacija IN (".$DelaNaloge.")";
                            $indx=0;
                            $result1 = mysqli_query($link,$SQL);
                            while ($R1 = mysqli_fetch_array($result1)){
						        $Dela[$indx]=$R1["idSistemizacija"];
						        $indx=$indx+1;
					        }
					        $StDela=$indx-1;
				        }else{
					        $StDela=0;
				        }
				        
				        echo "<tr><td>Opis del in nalog (za več opisov drži Ctrl+klik)</td><td><select  name='delanaloge[]' multiple size=5>";
				        
				        $SQL = "SELECT * FROM TabSistemizacija ORDER BY idSistemizacija";
                        $result1 = mysqli_query($link,$SQL);
                        while ($R1 = mysqli_fetch_array($result1)){
					        $DelaSel=false;
					        for ($indx=0;$indx <= $StDela;$indx++){
						        if ($R1["idSistemizacija"]==$Dela[$indx] ){
							        $DelaSel=true;
						        }
					        }
					        if ($DelaSel ){
						        echo "<option value='".$R1["idSistemizacija"]."' selected>".$R1["idSistemizacija"].". ".$R1["Opis"]."</option>";
					        }else{
						        echo "<option value='".$R1["idSistemizacija"]."'>".$R1["idSistemizacija"].". ".$R1["Opis"]."</option>";
					        }
				        }
				        echo "</select></td></tr>";
        //			}
			        
			        echo "<tr><td>Datum začetka dela</td><td><input name='datumstart' type='text' size='15' value='".$VDatumStart."' id='dat02'></td></tr>";
			        echo "<tr><td>Datum zaključka dela</td><td><input name='datumend' type='text' size='15' value='".$VDatumEnd."' id='dat03'></td></tr>";
			        echo "<tr><td>Način prenehanja dela</td><td><input name='nacinprenehanja' type='text' size='30' value='".$VNacinPrenehanja."'></td></tr>";
			        echo "<tr><td>Datum vpisa M1</td><td><input name='vpism1' type='text' size='15' value='".$VVpisM1."' id='dat04'></td></tr>";
			        echo "<tr><td>Datum izpisa M1</td><td><input name='izpism1' type='text' size='15' value='".$VIzpisM1."' id='dat05'></td></tr>";
                    echo "<tr><td>Opombe</td><td><textarea name='opombe' cols='40' rows='2'>".$VOpombe."</textarea></td></tr>";
			        
			        echo "</table>";

			        echo "<input name='submit' type='submit' value='Pošlji'>";
			        echo "</form>";
		        }
                break;
	        case 4:	//'vpis popravkov
                if (isset($_POST["ustreznost"])){
                    $Vustreznost= $_POST["ustreznost"];
                    if (!is_numeric($Vustreznost)){
                        $Vustreznost=0;
                    }
                }else{
                    $Vustreznost=0;
                }
                if (isset($_POST["delovnomesto"])){
                    $Vdelovnomesto= $_POST["delovnomesto"];
                    if (!is_numeric($Vdelovnomesto)){
                        $Vdelovnomesto=0;
                    }
                }else{
                    $Vdelovnomesto=0;
                }
                if (isset($_POST["delovnicas"])){
                    $Vdelovnicas=$_POST["delovnicas"];
                    if (!is_numeric($Vdelovnicas)){
                        $Vdelovnicas=0;
                    }
                }else{
                    $Vdelovnicas=0;
                }
                if (isset($_POST["vrstadela"])){
                    $Vvrstadela=$_POST["vrstadela"];
                    if (!is_numeric($Vvrstadela)){
                        $Vvrstadela=0;
                    }
                }else{
                    $Vvrstadela=0;
                }
                if (isset($_POST["koeficient"])){
                    $Vkoeficient=$_POST["koeficient"];
                    if (!is_numeric($Vkoeficient)){
                        $Vkoeficient=0;
                    }
                }else{
                    $Vkoeficient=0;
                }
                if (isset($_POST["datumstart"])){
                    $VDatumStart=$_POST["datumstart"];
                }else{
                    $VDatumStart="";
                }
                if (isset($_POST["datumend"])){
                    $VDatumEnd=$_POST["datumend"];
                }else{
                    $VDatumEnd="";
                }
                if (isset($_POST["dopdelo"])){    
                    $VDopDelo=$_POST["dopdelo"];
                    if (isset($VDopDelo)){ 
                        $VDopDelo="true";
                    }else{
                        $VDopDelo="false";
                    }
                }else{
                    $VDopDelo="false";
                }
                if (isset($_POST["delodaj1"])){
                    $VDelodaj1=$_POST["delodaj1"];
                }else{
                    $VDelodaj1="";
                }
                if (isset($_POST["delodaj1mat"])){
                    $VDelodaj1mat=$_POST["delodaj1mat"];
                }else{
                    $VDelodaj1mat="";
                }
                if (isset($_POST["delodaj1naslov"])){
                    $VDelodaj1naslov=$_POST["delodaj1naslov"];
                }else{
                    $VDelodaj1naslov="";
                }
                if (isset($_POST["delodaj2"])){
                    $VDelodaj2=$_POST["delodaj2"];
                }else{
                    $VDelodaj2="";
                }
                if (isset($_POST["delodaj2mat"])){
                    $VDelodaj2mat=$_POST["delodaj2mat"];
                }else{
                    $VDelodaj2mat="";
                }
                if (isset($_POST["delodaj2naslov"])){
                    $VDelodaj2naslov=$_POST["delodaj2naslov"];
                }else{
                    $VDelodaj2naslov="";
                }
                if (isset($_POST["delodaj3"])){
                    $VDelodaj3=$_POST["delodaj3"];
                }else{
                    $VDelodaj3="";
                }
                if (isset($_POST["delodaj3mat"])){
                    $VDelodaj3mat=$_POST["delodaj3mat"];
                }else{
                    $VDelodaj3mat="";
                }
                if (isset($_POST["delodaj3naslov"])){
                    $VDelodaj3naslov=$_POST["delodaj3naslov"];
                }else{
                    $VDelodaj3naslov="";
                }
                if (isset($_POST["datumpogodbe"])){
                    $VDatumPogodbe=$_POST["datumpogodbe"];
                }else{
                    $VDatumPogodbe="";
                }
                if (isset($_POST["polnidelcas"])){
                    $VPolniDelCas="da";
                }else{
                    $VPolniDelCas="ne";
                }
                if (isset($_POST["razlogdolcas"])){    
                    $VRazlogDolCas=$_POST["razlogdolcas"];
                }else{
                    $VRazlogDolCas="";
                }
                if (isset($_POST["potrstrokusp"])){
                    $VPotrStrokUsp=$_POST["potrstrokusp"];
                }else{
                    $VPotrStrokUsp="";
                }
                if (isset($_POST["nazivdelmesta1"])){
                    if (strlen($_POST["nazivdelmesta1"]) > 0){
                        $VNazivDelMesta=$_POST["nazivdelmesta1"];
                    }else{
                        if (isset($_POST["nazivdelmesta"])){
                            $VNazivDelMesta=$_POST["nazivdelmesta"];
                        }else{
                            $VNazivDelMesta="";
                        }
                    }
                }else{
                    if (isset($_POST["nazivdelmesta"])){
                        $VNazivDelMesta=$_POST["nazivdelmesta"];
                    }else{
                        $VNazivDelMesta="";
                    }
                } 
                
                if (isset($_POST["urteden"])){
                    $VUrTeden=$_POST["urteden"];
                }else{
                    $VUrTeden=40;
                }
                if (isset($_POST["izmensko"])){
                    $VIzmensko="true";
                }else{
                    $VIzmensko="false";
                }
                if (isset($_POST["krajdela"])){    
                    $VKrajDela=$_POST["krajdela"];
                }else{
                    $VKrajDela="";
                }
                if (isset($_POST["konkklavz"])){
                    $VKonkKlavz="true";
                }else{
                    $VKonkKlavz="false";
                }
                if (isset($_POST["nacinprenehanja"])){
                    $VNacinPrenehanja=$_POST["nacinprenehanja"];
                }else{
                    $VNacinPrenehanja="";
                }
                if (isset($_POST["delanaloge"])){
                    $VDelaNaloge=Arr2Str($_POST["delanaloge"]);
                }else{
                    $VDelaNaloge=0;
                }
                /*
                if ($EvidencaPrisotnosti ) {
                    if (isset($_POST["DelaNaloge"])){
                        $DelaNaloge=$_POST["DelaNaloge"];
                    }else{
                        $DelaNaloge=0;
                    }
                }
                if (isset($_POST["DelaNaloge"])){
                    $VDelaNaloge=$_POST["DelaNaloge"];
                }else{
                    $VDelaNaloge=0;
                }
                */
                if (isset($_POST["stpogodbe"])){
                    $VStPogodbe=$_POST["stpogodbe"];
                }else{
                    $VStPogodbe="";
                }
                if (isset($_POST["ob1"])){
                    $VObremen1=str_replace(",",".",$_POST["ob1"]);
                    if (strlen($_POST["ob1"])==0){
                        $VObremen1=0;
                    }
                }else{
                    $VObremen1=8;
                }
                if (isset($_POST["ob2"])){
                    $VObremen2=str_replace(",",".",$_POST["ob2"]);
                    if (strlen($_POST["ob2"])==0){
                        $VObremen2=0;
                    }
                }else{
                    $VObremen2=8;
                }
                if (isset($_POST["ob3"])){
                    $VObremen3=str_replace(",",".",$_POST["ob3"]);
                    if (strlen($_POST["ob3"])==0){
                        $VObremen3=0;
                    }
                }else{
                    $VObremen3=8;
                }
                if (isset($_POST["ob4"])){
                    $VObremen4=str_replace(",",".",$_POST["ob4"]);
                    if (strlen($_POST["ob4"])==0){
                        $VObremen4=0;
                    }
                }else{
                    $VObremen4=8;
                }
                if (isset($_POST["ob5"])){
                    $VObremen5=str_replace(",",".",$_POST["ob5"]);
                    if (strlen($_POST["ob5"])==0){
                        $VObremen5=0;
                    }
                }else{
                    $VObremen5=8;
                }
                if (isset($_POST["vpism1"])){   
                    $VVpisM1=$_POST["vpism1"];
                }else{
                    $VVpisM1="";
                }
                if (isset($_POST["izpism1"])){
                    $VIzpisM1=$_POST["izpism1"];
                }else{
                    $VIzpisM1="";
                }
                if (isset($_POST["opombe"])){
                    $VOpombe=$_POST["opombe"];
                }else{
                    $VOpombe="";
                }

		        
		        $SQL = "UPDATE tabpogodbe SET IzobUstr=".$Vustreznost.",IdDelo=".$Vdelovnomesto.",DelovniCas=".$Vdelovnicas.",IdVzgojnoDelo=".$Vvrstadela;
		        $SQL = $SQL . ",DatumStart='".$VDatumStart."', DatumEnd='".$VDatumEnd."'";
		        $SQL = $SQL . ",DopDelo=".$VDopDelo;
		        $SQL = $SQL . ", Delodaj1='".$VDelodaj1."', Delodaj1mat='".$VDelodaj1mat."',Delodaj1naslov='".$VDelodaj1naslov."'";
		        $SQL = $SQL . ", Delodaj2='".$VDelodaj2."', Delodaj2mat='".$VDelodaj2mat."',Delodaj2naslov='".$VDelodaj2naslov."'";
		        $SQL = $SQL .", Delodaj3='".$VDelodaj3."', Delodaj3mat='".$VDelodaj3mat."',Delodaj3naslov='".$VDelodaj3naslov."'";
		        $SQL = $SQL .", Koef=".$Vkoeficient;
		        $SQL = $SQL . ", DatumPogodbe='".$VDatumPogodbe."',PolniDelCas='".$VPolniDelCas."', RazlogDolCas='".$VRazlogDolCas."',PotrStrokUsp='".$VPotrStrokUsp."'";
		        $SQL = $SQL . ", NazivDelMesta='".$VNazivDelMesta."',UrTeden='".$VUrTeden."', Izmensko=".$VIzmensko.", KrajDela='".$VKrajDela."', KonkKlavz=".$VKonkKlavz.",NacinPrenehanja='".$VNacinPrenehanja."'";
                $SQL = $SQL . ", Sistemizacija='".$VDelaNaloge."'";
		        $SQL = $SQL . ", StPogodbe='".$VStPogodbe."'";
		        $SQL = $SQL . ", obremen1=".$VObremen1.", obremen2=".$VObremen2.", obremen3=".$VObremen3.", obremen4=".$VObremen4.", obremen5=".$VObremen5;
		        $SQL = $SQL . ", VpisM1='".$VVpisM1."', IzpisM1='".$VIzpisM1."', Opombe='".$VOpombe."'";
		        $SQL = $SQL . ", cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."'";
		        $SQL = $SQL . " WHERE id=".$_POST["popravi"]; 
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    echo $SQL."<br />";
                    die("Napaka pri popravljanju pogodbe: ".mysqli_error());
                }
		        
		        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "<h2>Pogodbe delavca: ".$R["Priimek"]." ".$R["Ime"]."</h2>";
		        }
		        
                echo "<table border='1'>";
                echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
		        $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$VPogodbenik;
                $indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result)){
			        $indx=$indx+1;
			        echo "<tr>";
			        echo "<td>".$indx."</td>";
			        echo "<td>".$R1["DatumPogodbe"]."</td>";
			        echo "<td>".$R1["StPogodbe"]."</td>";
			        echo "<td>".$R1["DatumStart"]."</td>";
			        echo "<td>".$R1["DatumEnd"]."</td>";
			        echo "<td>".$R1["VpisM1"]."</td>";
			        echo "<td>".$R1["IzpisM1"]."</td>";
			        echo "<td>".$R1["NazivDelMesta"]."</td>";
			        echo "<td>".$R1["UrTeden"]."</td>";
                    echo "<td><textarea cols='20' rows='2'>".$R1["Opombe"]."</textarea></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
			        echo "</tr>";
		        }
		        echo "</table><br />";
		        echo "<a href='DodajPogodbo.php?idUcitelj=".$VPogodbenik."'>Dodaj pogodbo</a><br />";
		        echo "<a href='IzpisUcitelja.php?idUcitelj=".$VPogodbenik."'>Na delavca</a><br />";
		        echo "<a href='DodajPogodbo.php?id=6'>Vse pogodbe</a>";
                break;
	        case 5:
		        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "<h2>Pogodbe delavca: ".$R["Priimek"]." ".$R["Ime"]."</h2>";
		        }
		        
		        $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$VPogodbenik;
		        echo "<table border='1'>";
		        if ($VLevel > 1 ){
			        echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>PDF</th><th>Dodaj PDF</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
		        }else{
			        echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
		        }	
		        $indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R1 = mysqli_fetch_array($result)){
			        $indx=$indx+1;
			        echo "<tr>";
			        echo "<td>".$indx."</td>";
			        echo "<td>".$R1["DatumPogodbe"]."</td>";
			        echo "<td>".$R1["StPogodbe"]."</td>";
			        echo "<td>".$R1["DatumStart"]."</td>";
			        echo "<td>".$R1["DatumEnd"]."</td>";
			        echo "<td>".$R1["VpisM1"]."</td>";
			        echo "<td>".$R1["IzpisM1"]."</td>";
			        echo "<td>".$R1["NazivDelMesta"]."</td>";
			        echo "<td>".$R1["UrTeden"]."</td>";
			        if ($VLevel > 1 ){
				        echo "<td><a href='pogodbe/".$R1["pdf"]."'>".$R1["pdf"]."</a></td>";
				        echo "<td><a href='VnosPDFPogodbe.php?idUcitelj=".$R1["IdUcitelj"]."&pogodba=".$R1["Id"]."'>Dodaj PDF pogodbe</a></td>";
			        }
                    echo "<td><textarea cols='20' rows='2'>".$R1["Opombe"]."</textarea></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
			        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
			        echo "</tr>";
		        }
		        echo "</table><br />";
		        echo "<a href='DodajPogodbo.php?idUcitelj=".$VPogodbenik."'>Dodaj pogodbo</a><br />";
		        echo "<a href='IzpisUcitelja.php?idUcitelj=".$VPogodbenik."'>Na delavca</a><br />";
		        echo "<a href='DodajPogodbo.php?id=6'>Vse pogodbe</a>";
                break;
	        case 6:	//'izpis vseh delavcev s pogodbami
		        $SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
			        echo "<h3>Pogodbe delavca: ".$R["Priimek"]." ".$R["Ime"]."</h3>";
		        
                    echo "<table border='1'>";
                    if ($VLevel > 1 ){
                        echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>PDF</th><th>Dodaj PDF</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
                    }else{
                        echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Prijava</th><th>Odjava</th><th>Delovno mesto</th><th>ur</th><th>Opombe</th><th>Briši</th><th>Popravi</th></tr>";
                    }    
                    $indx=0;
			        $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$R["IdUcitelj"];
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $indx++;
                        echo "<tr>";
                        echo "<td>".$indx."</td>";
                        echo "<td>".$R1["DatumPogodbe"]."</td>";
                        echo "<td>".$R1["StPogodbe"]."</td>";
                        echo "<td>".$R1["DatumStart"]."</td>";
                        echo "<td>".$R1["DatumEnd"]."</td>";
                        echo "<td>".$R1["VpisM1"]."</td>";
                        echo "<td>".$R1["IzpisM1"]."</td>";
                        echo "<td>".$R1["NazivDelMesta"]."</td>";
                        echo "<td>".$R1["UrTeden"]."</td>";
                        if ($VLevel > 1 ){
                            echo "<td><a href='pogodbe/".$R1["pdf"]."'>".$R1["pdf"]."</a></td>";
                            echo "<td><a href='VnosPDFPogodbe.php?idUcitelj=".$R1["IdUcitelj"]."&pogodba=".$R1["Id"]."'>Dodaj PDF pogodbe</a></td>";
                        }
                        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
                        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
                        echo "</tr>";
			        }
			        echo "</table><br />";
			        echo "<a href='DodajPogodbo.php?idUcitelj=".$R["IdUcitelj"]."'>Dodaj pogodbo</a><br />";
			        echo "<a href='IzpisUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>Na delavca</a>";
		        }
	            break;
            case "7": //kateri predmet kdo uči po pogodbah
                echo "<h2>Zaposleni po sistemiziranih delovnih mestih</h2>";
                $SQL = "SELECT idsistemizacija,opis,povezava FROM tabsistemizacija ORDER BY idsistemizacija";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<h3><a href='".$R["povezava"]."' target='_blank'>".$R["opis"]."</a></h3>";
                    echo "<ul>";
                    $SQL = "SELECT tabpogodbe.sistemizacija,tabpogodbe.datumstart,tabpogodbe.datumend,tabucitelji.ime,tabucitelji.priimek FROM tabpogodbe ";
                    $SQL .= "INNER JOIN tabucitelji ON tabpogodbe.iducitelj=tabucitelji.iducitelj ";
                    $SQL .= "WHERE tabucitelji.status ";
                    $SQL .= "ORDER BY tabucitelji.priimek,tabucitelji.ime";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        $datSt=isDate($R1["datumstart"]);
                        if ($datSt){
                            $ds=new DateTime($datSt);
                            if ($Danes->format('Ymd') >= $ds->format('Ymd')){
                                $datEnd=isDate($R1["datumend"]);
                                if ($datEnd){
                                    $de=new DateTime($datEnd);
                                    if ($Danes->format('Ymd') <= $de->format('Ymd')){
                                        if (isset($R1["sistemizacija"])){
                                            if (vsebuje($R1["sistemizacija"],$R["idsistemizacija"])){
                                                echo "<li>".$R1["ime"]." ".$R1["priimek"]."</li>";
                                            }
                                        }
                                    }
                                }else{
                                    if (isset($R1["sistemizacija"])){
                                        if (vsebuje($R1["sistemizacija"],$R["idsistemizacija"])){
                                            echo "<li>".$R1["ime"]." ".$R1["priimek"]."</li>";
                                        }
                                    }
                                }
                            }
                        }
                    }
                    echo "</ul>";
                }
                break;
	        default:	//'dodaj novo pogodbo
		        $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$VPogodbenik;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "<form accept-charset='utf-8' name='dodajucenca' method=post action='DodajPogodbo.php'>";
			        echo "<input name='idUcitelj' type='hidden' value='".$VPogodbenik."'>";
			        echo "<input name='id' type='hidden' value='1'>";
			        echo "<h2>Vpiši pogodbo</h2>";
			        
			        echo "<table>";
			        echo "<tr><td>Priimek in ime: </td><td>".$R["Priimek"]." ".$R["Ime"]."</td></tr>";

			        echo "<tr><td>Številka pogodbe: </td><td><input name='stpogodbe' type='text' size='10' ></td></tr>";

			        echo "<tr><td>Ustreznost izobrazbe</td><td>";
			        echo "<select name='ustreznost'>";
			        echo "<option value='0'>Ustrezna</option>";
			        echo "<option value='1'>Neustrezna</option>";
			        echo "</select></td></tr>";

			        echo "<tr><td>Delovno mesto (statistika)</td><td>";
			        echo "<select name='delovnomesto'>";
			        
			        $SQL = "SELECT * FROM TabDelo";
			        $Indx = 0;
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
				        echo "<option value='".$R["IdDelo"]."'>".$R["SkupinaDela"]." - ".$R["OpisDela"]."</option>";
			        }
			        echo "</select></td></tr>";

			        echo "<tr><td>Delovni čas</td><td>";
			        echo "<select name='delovnicas'>";
			        echo "<option value='0'>Polni delovni čas</option>";
			        echo "<option value='1'>Krajši delovni čas</option>";
			        echo "<option value='3'>Na več šolah</option>";
			        echo "</select></td></tr>";

			        echo "<tr><td>Invalidnost: </td><td><input name='invalid' type='checkbox'></td></tr>";
			        echo "<tr><td>Kategorija invalidnosti: </td><td><input name='katinvalid' type='text' size='10' ></td></tr>";
			        echo "<tr><td>Delna upokojitev: </td><td><input name='delnoupokojen' type='text' size='20'></td></tr>";

			        echo "<tr><td>Datum pogodbe: </td><td><input name='datumpogodbe' type='text' size='10' value='".$Danes->format('d.m.Y')."' id='dat01'></td></tr>";
			        echo "<tr><td>Polni delovni čas: </td><td><input name='polnidelcas' type='checkbox' checked='checked'></td></tr>";
			        echo "<tr><td>Ur na teden: </td><td><input name='urteden' type='text' size='5' value='40'></td></tr>";
			        
			        echo "<tr><td>Tedenska obremenitev</td><td><table><tr><th>PON</th><th>TOR</th><th>SRE</th><th>ČET</th><th>PET</th></tr>";
			        echo "<tr><td><input type='text' name='ob1' value='8' size='4'></td>";
			        echo "<td><input type='text' name='ob2' value='8' size='4'></td>";
			        echo "<td><input type='text' name='ob3' value='8' size='4'></td>";
			        echo "<td><input type='text' name='ob4' value='8' size='4'></td>";
			        echo "<td><input type='text' name='ob5' value='8' size='4'></td></tr>";
			        echo "</table></td></tr>";
			        
			        echo "<tr><td>Izmensko delo: </td><td><input name='izmensko' type='checkbox'></td></tr>";
			        echo "<tr><td>Konkurenčna klavzula: </td><td><input name='konkklavz' type='checkbox'></td></tr>";

			        echo "<tr><td>Razlog sklenitve pog. za dol. čas: </td><td><input name='razlogdolcas' type='text' size='40' ></td></tr>";
			        echo "<tr><td>Potrebna strokovna usposobljenost: </td><td><input name='potrstrokusp' type='text' size='30' ></td></tr>";
			        
			        echo "<tr><td>Naziv del. mesta: </td><td><input name='nazivdelmesta1' type='text' size='30' >Če vpišete tu ročno, bo to vpisano, sicer izberite spodaj<br />";
			        echo "<select name='nazivdelmesta'>";
			        echo "<option>Ni izbran</option>";
			        
			        $SQL = "SELECT * FROM TabDelMesta";
	                $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
			            echo "<option>".$R["DelMesto"]." (".$R["Sifra"]."]</option>";
			        }
			        echo "</select></td></tr>";
			        
			        echo "<tr><td>Kraj dela: </td><td><input name='krajdela' type='text' size='40' ></td></tr>";
			        echo "<tr><td>Dopolnjevanje dela: </td><td><input name='dopdela' type='checkbox'></td></tr>";
			        echo "<tr><td>Dopolnilni delodajalec 1: </td><td><input name='delodaj1' type='text' size='30' ></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 1: </td><td><input name='delodaj1mat' type='text' size='10' ></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 1: </td><td><input name='delodaj1naslov' type='text' size='30' ></td></tr>";
			        echo "<tr><td>Dopolnilni delodajalec 2: </td><td><input name='delodaj2' type='text' size='30' ></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 2: </td><td><input name='delodaj2mat' type='text' size='10' ></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 2: </td><td><input name='delodaj2naslov' type='text' size='30' ></td></tr>";
			        echo "<tr><td>Dopolnilni delodajalec 3: </td><td><input name='delodaj3' type='text' size='30' ></td></tr>";
			        echo "<tr><td>Mat. št. dop. delodajalca 3: </td><td><input name='delodaj3mat' type='text' size='10' ></td></tr>";
			        echo "<tr><td>Naslov dop. delodajalca 3: </td><td><input name='delodaj3naslov' type='text' size='30' ></td></tr>";
			        
			        echo "<tr><td>Vrsta dela</td><td>";
			        echo "<select name='vrstadela'>";
			        
			        $SQL = "SELECT * FROM TabVzgDelo";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
				        echo "<option value='".$R["IdVzgojnoDelo"]."'>".$R["VzgojnoDelo"]."</option>";
			        }
			        echo "</select></td></tr>";
			        
			        //if ($EvidencaPrisotnosti==1 ){
				        echo "<tr><td>Opis del in nalog (za več opisov drži Ctrl+klik)</td><td><select  name='delanaloge[]' multiple size='5'>";
				        $SQL = "SELECT * FROM TabSistemizacija ORDER BY idSistemizacija";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
					        echo "<option value='".$R["idSistemizacija"]."'>".$R["idSistemizacija"].". ".$R["Opis"]."</option>";
				        }
				        echo "</select></td></tr>";
			        //}
			        
			        echo "<tr><td>Datum začetka dela</td><td><input name='datumstart' type='text' size='15' value='".$Danes->format('d.m.Y')."' id='dat02'></td></tr>";
			        echo "<tr><td>Datum zaključka dela</td><td><input name='datumend' type='text' size='15' id='dat03'></td></tr>";
			        echo "<tr><td>Način prenehanja dela</td><td><input name='nacinprenehanja' type='text' size='30'></td></tr>";
			        echo "<tr><td>Datum vpisa M1</td><td><input name='vpism1' type='text' size='15' value='".$Danes->format('d.m.Y')."' id='dat04'></td></tr>";
			        echo "<tr><td>Datum izpisa M1</td><td><input name='izpism1' type='text' size='15' id='dat05'></td></tr>";
                    echo "<tr><td>Opombe</td><td><textarea name='opombe' cols='40' rows='2'></textarea></td></tr>";
			        echo "</table>";

			        echo "<input name='submit' type='submit' value='Pošlji'>";
			        echo "</form>";
		        }else{
			        echo "<h2>Delavec še ni vpisan!</h2>";
			        echo "<p>";
			        echo "<a href='DodajUcitelja.php'>Vpis delavca</a>";
			        echo "</p>";
		        }
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>

</body>
</html>
