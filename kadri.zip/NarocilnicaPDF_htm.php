<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Naročilnica
</title>
<style type="text/css">
TABLE
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 0px;
    BACKGROUND-COLOR: white;
    border-spacing: 2;
}
TABLE.obracun
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 1px;
    BACKGROUND-COLOR: white;
    border-spacing: 0;
    border-collapse: collapse
}
TABLE.sivina
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 1px;
    BACKGROUND-COLOR: lightgrey;
    border-spacing: 0;
    border-collapse: collapse
}
TD
{
    BORDER: black solid 0px;
    border-spacing: 0;
}
TD.obracun
{
    BORDER: black solid 1px;
    border-spacing: 0;
    border-collapse: collapse
}
TD.sivina
{
    BORDER: black solid 0px;
    border-spacing: 0;
    border-collapse: collapse
}
</style>
</head>
<body>

<?php
$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
    if ($VLeto == "" ) {
        if (isset($_SESSION["leto"])){
            $VLeto=$_SESSION["leto"];
            if ($VLeto == "" ) {
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }else{
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }    
        }
    }
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        if ($ActualMonth > 8 ) {
            $VLeto = $ActualYear;
        }else{
            if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                $VLeto = $ActualYear;
            }else{
                $VLeto=$ActualYear-1;
            }
        }
    }
}
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_GET["id"])){
    $Vid=$_GET["id"];
}else{
    $Vid="";
}

$SQL = "SELECT * FROM TabNarocilnica ";
$SQL = $SQL ."WHERE id=".$Vid;
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    echo "<table border='0' width='750'>";
    echo "    <tr>";
    echo "        <td><img src='logo.gif' width='200'></td>";
    echo "        <td width='550' align='center'><span style='font-size:xx-large;font-weight:bold'>Naročilnica<br />Št. ".($R["ZapSt"]."/".$R["leto"])."</span></td>";
    echo "    </tr>";
    echo "</table>";
    echo "<table border='0'>";
    echo "    <tr>";
    echo "        <td width='250' height='60'>&nbsp;</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>&nbsp;</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Izdajatelj:</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>".$R["Izdajatelj"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>ID št. za DDV:</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>".$R["Davcna"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Zavezanec za DDV:</td>";
    if ($R["Zavezanec"]){
        echo "        <td width='500' style='font-size:medium;font-weight:bold'>DA</td>";
    }else{
        echo "        <td width='500' style='font-size:medium;font-weight:bold'>NE</td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Kraj izdaje:</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>".$R["Kraj"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Datum izdaje:</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>".$R["DatumIzd"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250' height='60'>&nbsp;</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>&nbsp;</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Dobavitelj:</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>".$R["Dobavitelj"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250' height='60'>&nbsp;</td>";
    echo "        <td width='500' style='font-size:medium;font-weight:bold'>&nbsp;</td>";
    echo "    </tr>";
    echo "</table>";

    echo "<table class='obracun'>";
    echo "    <tr>";
    echo "        <td width='750'>Naročamo:</td>";
    echo "    </tr>";
    $Narocilo=explode("\n",$R["VrstaBlaga"]);
    for ($i=0;$i < count($Narocilo);$i++){
        echo "    <tr>";
        echo "        <td class='obracun' width='750'>".$Narocilo[$i]."</td>";
        echo "    </tr>";
    }
    echo "    <tr>";
    echo "        <td width='750' style='font-size:small'>Kopijo naročilnice priložite k računu, sicer vam ga bomo zavrnili!</td>";
    echo "    </tr>";
        
    echo "    <tr>";
    echo "        <td width='750' style='font-size:small'>Plačilo v roku 30 dni od izdaje računa.</td>";
    echo "    </tr>";
    echo "</table>";
    echo "<table>";
    echo "    <tr>";
    echo "        <td width='400' height='40'>&nbsp;</td>";
    echo "        <td width='350'>Naročil:&nbsp;<span style='font-size:medium;font-weight:bold'>".$R["Narocil"]."</span></td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='400' height='40'>&nbsp;</td>";
    echo "        <td width='350'>Datum:&nbsp;<span style='font-size:medium;font-weight:bold'>".$R["DatumIzd"]."</span></td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='400' align='center' height='40'>Žig</td>";
    echo "        <td width='350'><span style='font-size:medium;font-weight:bold'>Podpis:___________________ </span></td>";
    echo "    </tr>";
    echo "</table>";
}		
?>

</body>
</html>
