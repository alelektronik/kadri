<?php
include('const.php');
ini_set('max_execution_time', 600); 
include('razredi.php');
include('iskanje.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis vnesenih pregledov dela
</title>
</head>
<body>
<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    if ($Prijavljeni <> $ucitelj) {
        if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
    }

    echo "<h2>Pregled odsotnosti in nadomeščanj - ".$VLetoPregled."</h2>";
    $SQL = "SELECT tabpregleddelan.leto,tabpregleddelan.rubrika, TabDoprinos.OblikaDela, TabDoprinos.uramin, TabDoprinos.koeficient,SUM(tabpregleddelan.enot) AS stevilo FROM ";
    $SQL = $SQL . "tabpregleddelan INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos ";
    $SQL = $SQL . "WHERE tabpregleddelan.leto=".$VLetoPregled;
    $SQL = $SQL . " GROUP BY tabpregleddelan.rubrika,tabpregleddelan.leto,TabDoprinos.OblikaDela, TabDoprinos.uramin, TabDoprinos.koeficient ";
    //$SQL = $SQL . "HAVING tabpregleddelan.leto=".$VLetoPregled;
    $result = mysqli_query($link,$SQL);

    echo "<table border='1' cellspacing='0'>";
    echo "<tr><th>Rubrika</th><th>Število</th></tr>";
    while ($R = mysqli_fetch_array($result)){
	    echo "<tr>";
	    echo "<td width='400'>".$R["OblikaDela"]."</td>";
	    switch ($R["uramin"]){
		    case 1:
			    if ($R["koeficient"]==0 or $R["koeficient"]==8){
				    echo "<td align='right'>".number_format($R["stevilo"],0)."</td><td>dni</td>";
			    }else{
				    if ($R["koeficient"]==1.5) {
					    echo "<td align='right'>".number_format($R["stevilo"],2)."</td><td>PU</td>";
				    }else{
					    echo "<td align='right'>".number_format($R["stevilo"],2)."</td><td>DU</td>";
				    }
			    }
                break;
		    case 50:
			    echo "<td align='right'>".number_format($R["stevilo"]/$R["uramin"],2)."</td><td>ur OPB</td>";
                break;
		    case 60:
			    echo "<td align='right'>".number_format($R["stevilo"]/$R["uramin"],2)."</td><td>DU</td>";
	    }
	    echo "</tr>";
    }
    echo "</table><br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
</body>
</html>
