<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Potni nalogi
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat04",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat05",
            dateFormat:"%d.%m.%Y",
            
            yearsRange:[1940,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
  //  echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
/*
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }   
    if (isset($_POST["zapis"])){
        $zapis=$_POST["zapis"];
    }else{
        if (isset($_GET["zapis"])){
            $zapis=$_GET["zapis"];
        }else{
            $zapis="";
        }
    }   

    switch ($Vid){
        case "8":
        case "8a":
            break;
        default:
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
    }
        
    switch ($Vid){
	    case "1": // 'vnos potnega naloga
		    if (!CheckDostop("drugo5",$VUporabnik)) {
                header ("Location: nepooblascen.htm");
            }else{
                if (is_numeric($_POST["StUciteljev"])){
		            $StUciteljev=$_POST["StUciteljev"];
		        }else{
			        $StUciteljev=0;
		        }

		        if ($StUciteljev == 0 ){
			        header ("Location: IzborPotniNalog.php");
		        }
		        
		        $StUciteljevPN=0;
		        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
			        $Ucitelj[$Indx][0]=$_POST["uc".$Indx];
			        if (isset($_POST["pn".$Indx])){
				        $Ucitelj[$Indx][1]=true;
				        $StUciteljevPN=$StUciteljevPN+1;
				        $VUcitelj=$Ucitelj[$Indx][0];
			        }else{
				        $Ucitelj[$Indx][1]=false;
			        }
		        }
		        
		        $SQL = "SELECT * FROM tabsola";
		        $result = mysqli_query($link,$SQL);
		        if ($R = mysqli_fetch_array($result)){
			        $VSola=$R["MaticnaSola"];
			        $VRavnatelj=$R["Ravnatelj"];
		        }else{
			        $VSola=" ";
			        $VRavnatelj=" ";
		        }
		        
		        if ($StUciteljevPN == 1 ){
			        $SQL = "SELECT tabucitelji.* FROM tabucitelji  WHERE idUcitelj=".$VUcitelj;
			        $result = mysqli_query($link,$SQL);
			        
			        if ($R = mysqli_fetch_array($result)){
                        $oUcitelj=new RUcitelj();
                        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
				        $VPotnik=$oUcitelj->getIme()." ".$oUcitelj->getPriimek();
				        $VDelovnoMesto=$oUcitelj->getDelMesto();
				        $VNaslov=$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj();
			        }else{
				        $VPotnik="";
				        $VDelovnoMesto="";
				        $VNaslov="";
			        }
		        }else{
			        $VPotnik="več imen";
			        $VDelovnoMesto="več delovnih mest";
			        $VNaslov="več naslovov";
		        }

		        //'prebere podatke iz pogodb

		        $SQL = "SELECT * FROM TabPotniNalog WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt DESC LIMIT 0,1 ";
		        $result = mysqli_query($link,$SQL);
		        
		        if ($R = mysqli_fetch_array($result)){
			        $i1=$R["ZapSt"]+1;
		        }else{
			        $i1=1;
		        }
		        
        //'		response.write VUcitelj&"<br>"
		        echo "<h2>Nalog za službeno potovanje</h2>";
		        echo "<form name='ucitelji' method=post action='VnosPotniNalogi.php'>";
		        echo "<table border='0'>";
		        echo "<tr><td>Zaporedna št. </td><td><input name='ZapSt' type='text' size='5' value='".$i1."'></td></tr>";
		        echo "<tr><td>Datum </td><td><input name='Datum' type='text' size='10' value='".$Danes->format('d.m.Y')."' id='dat01'></td></tr>";
		        echo "<tr><td>Odrejam, da odpotuje </td><td>".$VPotnik."</td></tr>";
		        echo "<tr><td>Na delovnem mestu </td><td>".$VDelovnoMesto."</td></tr>";
		        echo "<tr><td>stanujoč </td><td>".$VNaslov."</td></tr>";
		        echo "<tr><td>dne </td><td><input name='DanOdhoda' type='text' size='10' value='".$Danes->format('d.m.Y')."' id='dat02'></td></tr>";
		        echo "<tr><td>ob </td><td>";
			        echo "ura <select name='UraOdhoda'>";
			        for ($Indx=0;$Indx <= 23;$Indx++){
				        if ($Indx==8 ){
					        echo "<option selected>".$Indx."</option>";
				        }else{
					        echo "<option>".$Indx."</option>";
				        }
			        }
			        echo "</select>";
			        echo "min <select name='MinOdhoda'>";
			        for ($Indx=0;$Indx <= 59;$Indx++){
				        if ($Indx < 10 ){
					        echo "<option>0".$Indx."</option>";
				        }else{
					        echo "<option>".$Indx."</option>";
				        }
			        }
			        echo "</select>";
			        echo "</td></tr>";
		        echo "<tr><td>po nalogu (odločba - spis) </td><td><input name='Odlocba' type='text' size='30' value='ravnateljice'></td></tr>";
		        echo "<tr><td>v/na </td><td><input name='Kam' type='text' size='30'></td></tr>";
		        echo "<tr><td>z nalogo </td><td><input name='Naloga' type='text' size='30'></td></tr>";
		        echo "<tr><td>Potovanje bo trajalo do </td><td><input name='DanPrihoda' type='text' size='10' value='".$Danes->format('d.m.Y')."' id='dat03'></td></tr>";
		        echo "<tr><td>to je </td><td><input name='Dni' type='text' size='5' value='1'> dni</td></tr>";
		        
		        echo "<tr><td>odobravam uporabo (avtomobila, letala, itd.) </td><td><input name='PrevSredstvo' type='text' size='30'><br /><small>Za nov vpis tule mora biti v spodnjem polju prazen izbor.</small></td></tr>";
		        echo "<tr><td>&nbsp; </td><td><select name='PrevSredstvo1'>";
		        echo "<option value='0'>&nbsp;</option>";
		        $SQL = "SELECT TabRegistracije.*,tabucitelji.Priimek,tabucitelji.Ime FROM TabRegistracije ";
		        $SQL = $SQL . "INNER JOIN tabucitelji ON TabRegistracije.idUcitelj=tabucitelji.idUcitelj ORDER BY tabucitelji.priimek,tabucitelji.ime,tabregistracije.registracija";
		        $result = mysqli_query($link,$SQL);
		        $indx=0;
		        while ($R = mysqli_fetch_array($result)){
        //'				if ($R["TabRegistracije.idUcitelj")=0) and (StUciteljevPN > 1) ){
			        if ($R["idUcitelj"]==0 ){
				        echo "<option value='".$R["id"]."'>";
				        echo $R["Priimek"]." ".$R["Ime"]." - ".$R["registracija"];
				        echo "</option>";
			        }else{
				        if ($StUciteljevPN == 1 ){
					        if ($R["idUcitelj"]==$VUcitelj ){
						        echo "<option value='".$R["id"]."' selected>";
						        echo $R["Priimek"]." ".$R["Ime"]." - ".$R["registracija"];
						        echo "</option>";
					        }else{
						        echo "<option value='".$R["id"]."'>";
						        echo $R["Priimek"]." ".$R["Ime"]." - ".$R["registracija"];
						        echo "</option>";
					        }
				        }else{
					        echo "<option value='".$R["id"]."'>";
					        echo $R["Priimek"]." ".$R["Ime"]." - ".$R["registracija"];
					        echo "</option>";
				        }
			        }
			        $indx=$indx+1;
		        }
		        
		        echo "</select></td></tr>";
		        
		        echo "<tr><td>potne stroške plača </td><td><input name='Placnik' type='text' size='30' value='".$VSola."'></td></tr>";
		        echo "<tr><td>višina dnevnice </td><td><input name='Dnevnica' type='text' size='5'> EUR</td></tr>";
		        echo "<tr><td>posebni dodatki </td><td><input name='Dodatki' type='text' size='5'> EUR</td></tr>";
		        echo "<tr><td>odobravam izplačilo predujma v znesku </td><td><input name='Predujem' type='text' size='5'> EUR</td></tr>";
		        echo "<tr><td></td></tr>";
		        echo "<tr><td>Podpis odredbodajalca </td><td><input name='Odredbodajalec' type='text' size='20' value='".$VRavnatelj."'></td></tr>";
		        echo "</table>";
		        echo "<input name='id' type='hidden' value='2'>";
		        
		        $i1=0;
		        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
			        if ($Ucitelj[$Indx][1] ){
				        $i1=$i1+1;
				        echo "<input name='uc".$i1."' type='hidden' value='".$Ucitelj[$Indx][0]."'>";
			        }
		        }

		        echo "<input name='StUciteljev' type='hidden' value='".$i1."'>";
		        echo "<input name='submit' type='submit' value='Pošlji'>";
		        echo "</form>";
		        echo "<hr>";
            }
            break;
	    case "2": // 'shranitev potnih nalogov in preusmeritev na PotniNalogiPDF.php
		    if (!CheckDostop("drugo5",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }else{
		        $StUciteljev=$_POST["StUciteljev"];
                if (isset($_POST["ZapSt"])){
		            if (is_numeric($_POST["ZapSt"]) ){
			            $i1=$_POST["ZapSt"];
		            }else{
			            $i1=1;
                    }
                }else{
                    $i1=1;
                }
                if (isset($_POST["Dnevnica"])){
		            if (is_numeric($_POST["Dnevnica"]) ){
			            $VDnevnica=str_replace(",",".",$_POST["Dnevnica"]);
		            }else{
			            $VDnevnica=0;
		            }
                }else{
                    $VDnevnica=0;
                }
                if (isset($_POST["Dodatki"])){
		            if (is_numeric($_POST["Dodatki"]) ){
			            $VDodatki=str_replace(",",".",$_POST["Dodatki"]);
		            }else{
			            $VDodatki=0;
		            }
                }else{
                    $VDodatki=0;
                }
                if (isset($_POST["Predujem"])){
		            if (is_numeric($_POST["Predujem"]) ){
			            $VPredujem=str_replace(",",".",$_POST["Predujem"]);
		            }else{
			            $VPredujem=0;
		            }
                }else{
                    $VPredujem=0;
                }
                if (isset($_POST["Dni"])){
		            if (is_numeric($_POST["Dni"]) ){
			            $VDni=$_POST["Dni"];
		            }else{
			            $VDni=0;
		            }
                }else{
                    $VDni=0;
                }
                if (isset($_POST["PrevSredstvo1"])){
		            $VPrevSredstvo=$_POST["PrevSredstvo1"];
                }else{
                    $VPrevSredstvo="";
                }
		        if (($VPrevSredstvo=="1") or ($VPrevSredstvo=="") or ($VPrevSredstvo=="0") ){
			        $VPrevSredstvo=$_POST["PrevSredstvo"];
			        if ($StUciteljev == 1 ){
				        $Ucitelj[1][0]=$_POST["uc1"];
				        //$SQL = "SELECT * FROM TabRegistracije WHERE idUcitelj=".$Ucitelj[1][0];
                        $SQL = "SELECT * FROM TabRegistracije WHERE registracija='".$VPrevSredstvo."'";
				        $result = mysqli_query($link,$SQL);
				        //'že obstaja prepiše, sicer doda novega
				        if (!($R = mysqli_fetch_array($result))){
                            /*
					        $SQL = "UPDATE TabRegistracije SET registracija='".$VPrevSredstvo."' WHERE id=".$R["id"];
					        $result = mysqli_query($link,$SQL);
				        }else{
                            */
					        $SQL = "INSERT INTO TabRegistracije (idUcitelj,registracija) VALUES (".$Ucitelj[1][0].",'".$VPrevSredstvo."')";
					        $result = mysqli_query($link,$SQL);
				        }
			        }
		        }else{
			        $SQL = "SELECT * FROM TabRegistracije WHERE id=".$VPrevSredstvo;
			        $result = mysqli_query($link,$SQL);
			        if ($R = mysqli_fetch_array($result)){
				        $VPrevSredstvo=$R["registracija"];
			        }else{
				        $VPrevSredstvo="-";
			        }
		        }
		        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
			        $Ucitelj[$Indx][0]=$_POST["uc".$Indx];
                    if (isset($_POST["Datum"])){
                        $astr=explode(".",$_POST["Datum"]);
                        $Datum = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                    }else{
                        $Datum=new DateTime($Danes->format('Y-m-d'));
                    }
			        $SQL = "SELECT * FROM TabPotniNalog WHERE leto=".$Datum->format('Y')." AND ZapSt=".$i1;
			        $result = mysqli_query($link,$SQL);
			        
			        if ($R = mysqli_fetch_array($result)){
				        echo "Potni nalog z zaporedno številko ".$i1." je že vnesen. NI vpisa!<br />";
        //'				Exit for
			        }else{
                        if (isset($_POST["DanOdhoda"])){
                            $astr=explode(".",$_POST["DanOdhoda"]);
                            $DanOdhoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                        }else{
                            $DanOdhoda=new DateTime($Danes->format('Y-m-d'));
                        }
                        if (isset($_POST["DanPrihoda"])){
                            $astr=explode(".",$_POST["DanPrihoda"]);
                            $DanPrihoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                        }else{
                            $DanPrihoda=new DateTime($Danes->format('Y-m-d'));
                        }
                        if (isset($_POST["UraOdhoda"])){
                            $UraOdhoda=$_POST["UraOdhoda"];
                        }else{
                            $UraOdhoda="";
                        }
                        if (isset($_POST["MinOdhoda"])){
                            $MinOdhoda=$_POST["MinOdhoda"];
                        }else{
                            $MinOdhoda="";
                        }
                        if (isset($_POST["Odlocba"])){
                            $odlocba=$_POST["Odlocba"];
                        }else{
                            $odlocba="";
                        }
                        if (isset($_POST["Kam"])){
                            $kam=$_POST["Kam"];
                        }else{
                            $kam="";
                        }
                        if (isset($_POST["Naloga"])){
                            $Naloga=$_POST["Naloga"];
                        }else{
                            $Naloga="";
                        }
                        if (isset($_POST["Placnik"])){
                            $Placnik=$_POST["Placnik"];
                        }else{
                            $Placnik="";
                        }
                        if (isset($_POST["Odredbodajalec"])){
                            $Odredbodajalec=$_POST["Odredbodajalec"];
                        }else{
                            $Odredbodajalec="";
                        }
				        $SQL = "INSERT INTO TabPotniNalog (";
				        $SQL = $SQL . "leto,ZapSt,Datum,idUcitelj,DanOdhoda,UraOdhoda,Odlocba,Kam,Naloga,DanPrihoda,Dni,PrevSredstvo,Placnik,Dnevnica,Dodatki,Predujem,Odredbodajalec,vpisal,cas) VALUES (";
				        $SQL = $SQL . $Datum->format('Y').",".$i1.",'".$Datum->format('Y-m-d')."',".$Ucitelj[$Indx][0].",'".$DanOdhoda->format('Y-m-d')."','".$UraOdhoda.":".$MinOdhoda.":00',";
				        $SQL = $SQL ."'".$odlocba."','".$kam."','".$Naloga."','".$DanPrihoda->format('Y-m-d')."',".$VDni.",'".$VPrevSredstvo."',";
				        $SQL = $SQL ."'".$Placnik."',".$VDnevnica.",".$VDodatki.",".$VPredujem.",'".$Odredbodajalec."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
				        $result = mysqli_query($link,$SQL);
			        }
			        $i1=$i1+1;
		        }
		        
                echo "<a href='IzborPotniNalog.php'>Nov potni nalog</a><br />";
                
                $SQL = "SELECT * FROM TabPotniNalog  ORDER BY id DESC LIMIT 0,".$StUciteljev;
                $result = mysqli_query($link,$SQL);
                echo "<a href='PotniNalogiPDF.php?spisek=";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($Indx==1 ){
                        echo $R["id"];
                    }else{
                        echo ",".$R["id"];
                    }
                    $Indx=$Indx+1;
                }
                echo "'>Izpis potnih nalogov (PDF)</a><br />";

                $SQL = "SELECT TabPotniNalog.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
                $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
                //'$SQL = $SQL & "INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo "
                $SQL = $SQL . "WHERE leto=".$Danes->format('Y');
                $SQL = $SQL . " ORDER BY ZapSt DESC";
                $result = mysqli_query($link,$SQL);
		        echo "<br /><table border='1'>";
		        echo "<tr><th>Št.</th><th>Datum</th><th>Zap.št</th><th>Ime</th><th>Kam</th><th>Naloga</th><th>Znesek</th><th>Obračun</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        echo "<tr>";
			        echo "<td align='center'>".$Indx."</td>";
                    $Datum=new DateTime($R["Datum"]);
			        echo "<td>".$Datum->format('d.m.Y')."</td>";
			        echo "<td align=center>".$R["ZapSt"]."</td>";
			        echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			        echo "<td>".$R["Kam"]."</td>";
			        echo "<td>".$R["Naloga"]."</td>";
			        echo "<td align='right'>".number_format($R["OdobrenoIzpl"],2,",","")." EUR</td>";
			        if ($R["OdobrenoIzpl"] > 0 ){
				        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Popravi</a></td>";
			        }else{
				        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Vnesi</a></td>";
			        }
			        echo "</tr>";
			        $Indx=$Indx+1;
		        }
		        echo "</table><br />";
		        
		        $SQL = "SELECT * FROM TabPotniNalog  ORDER BY id DESC LIMIT 0,".$StUciteljev;
		        $result = mysqli_query($link,$SQL);
		        echo "<a href='PotniNalogiPDF.php?spisek=";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        if ($Indx==1 ){
				        echo $R["id"];
			        }else{
				        echo ",".$R["id"];
			        }
			        $Indx=$Indx+1;
		        }
		        echo "'>Izpis potnih nalogov (PDF)</a><br />";
            }
            break;
	    case "3":   //dopolnjevanje/vnašanje potnega naloga - obračuna
		    
		    $SQL = "SELECT * FROM ";
		    $SQL = $SQL ."tabucitelji "; //'INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo ";
		    $SQL = $SQL ."WHERE status > 0 ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    
		    $Indx=0;
		    while ($R = mysqli_fetch_array($result)){
                $Indx=$Indx+1;
			    $ucitelj[$Indx][0]=$R["IdUcitelj"];
			    $ucitelj[$Indx][1]=$R["Priimek"]." ".$R["Ime"];
			    //ucitelj(Indx,2)=$R["VzgojnoDelo")
			    $ucitelj[$Indx][3]=$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
		    }
		    $StUciteljev=$Indx;

		    $SQL = "SELECT TabPotniNalog.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
		    $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		    //'$SQL = $SQL & "INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo "
		    $SQL = $SQL . "WHERE TabPotniNalog.id=".$zapis;
		    $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
		        echo "<h2>Nalog za službeno potovanje</h2>";
		        echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
		        echo "<table border='0'>";
		        echo "<tr><td>Zaporedna št. </td><td>".$R["ZapSt"]."</td></tr>";
                $Datum=new DateTime($R["Datum"]);
		        echo "<tr><td>Datum </td><td>".$Datum->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>Odrejam, da odpotuje </td><td>".$R["Priimek"]." ".$R["Ime"]."</td></tr>";
		        
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["idUcitelj"],$Datum->format('Y'),$VLeto);		
		        
		        echo "<tr><td>Na delovnem mestu </td><td>".$oUcitelj->getDelMesto() ."</td></tr>";
		        echo "<tr><td>stanujoč </td><td>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td></tr>";
                $DanOdhoda=new DateTime($R["DanOdhoda"]);
		        echo "<tr><td>dne </td><td>".$DanOdhoda->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>ob </td><td>".$R["UraOdhoda"]."</td></tr>";
		        echo "<tr><td>po nalogu (odločba - spis) </td><td>".$R["Odlocba"]."</td></tr>";
		        echo "<tr><td>v/na </td><td>".$R["Kam"]."</td></tr>";
		        echo "<tr><td>z nalogo </td><td>".$R["Naloga"]."</td></tr>";
                $DanPrihoda=new DateTime($R["DanPrihoda"]);
		        echo "<tr><td>Potovanje bo trajalo do </td><td>".$DanPrihoda->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>to je </td><td>".$R["Dni"]." dni</td></tr>";
		        echo "<tr><td>odobravam uporabo (avtomobila, letala, itd.) </td><td>".$R["PrevSredstvo"]."</td></tr>";
		        echo "<tr><td>potne stroške plača </td><td>".$R["Placnik"]."</td></tr>";
		        echo "<tr><td>višina dnevnice </td><td>".number_format($R["Dnevnica"],2,",","")." EUR</td></tr>";
		        echo "<tr><td>posebni dodatki </td><td>".number_format($R["Dodatki"],2,",","")." EUR</td></tr>";
		        echo "<tr><td>odobravam izplačilo predujma v znesku </td><td>".number_format($R["Predujem"],2,",","")." EUR</td></tr>";
		        echo "<tr><td></td></tr>";
		        echo "<tr><td>Podpis odredbodajalca </td><td>".$R["Odredbodajalec"]."</td></tr>";
		        echo "</table>";
		        echo "<hr>";

		        echo "<h2>Obračun potnih stroškov</h2>";
		        echo "<font color='red'>Ne puščajte praznih polj - vpišite 0<br />Vpišete lahko le datum in čas odhoda in prihoda, program pa bo po pošiljanju v izračun avtomatsko vnesel razliko in izračunal dnevnice. Pa tudi kilometrino, če boste v četrto vrstico prevoznih stroškov vpisali <b>km:</b> in število kilometrov</font><br />";
		        echo "<table border='0'>";
		        echo "<tr><td>Ime in priimek predlagatelja </td><td>".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."</td></tr>";
		        echo "<tr><td>Prebivališče </td><td>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td></tr>";
		        if (isset($R["DanOdhodaObr"])){
                    $DanOdhoda= new DateTime($R["DanOdhodaObr"]);
			        echo "<tr><td>Datum odhoda </td><td><input name='DanOdhodaObr' type='text' size='10' value='".$DanOdhoda->format('d.m.Y')."'></td></tr>";
		        }else{
                    $DanOdhoda= new DateTime($R["DanOdhoda"]);
                    echo "<tr><td>Datum odhoda </td><td><input name='DanOdhodaObr' type='text' size='10' value='".$DanOdhoda->format('d.m.Y')."'></td></tr>";
		        }
		        
		        echo "<tr><td>Čas odhoda </td><td>";
			        echo "ura <select name='UraOdhodaObr'>";
			        if (isset($R["UraOdhodaObr"])){
				        $VCas=new DateTime($R["UraOdhodaObr"]);
			        }else{
				        $VCas=new DateTime("8:00:00");
			        }
			        for ($Indx=0;$Indx <= 23;$Indx++){
				        if ($Indx==$VCas->format('H') ){
					        echo "<option selected>".$Indx."</option>";
				        }else{
					        echo "<option>".$Indx."</option>";
				        }
			        }
			        echo "</select>";
			        echo "min <select name='MinOdhodaObr'>";
			        for ($Indx=0;$Indx<= 59;$Indx++){
				        if ($Indx < 10 ){
					        if ($Indx==$VCas->format('i') ){
						        echo "<option selected>0".$Indx."</option>";
					        }else{
						        echo "<option>0".$Indx."</option>";
					        }
				        }else{
					        if ($Indx==$VCas->format('i') ){
						        echo "<option selected>".$Indx."</option>";
					        }else{
						        echo "<option>".$Indx."</option>";
					        }
				        }
			        }
			        echo "</select>";
			        echo "</td></tr>";
		        
		        if (isset($R["DanPrihodaObr"])){
                    $DanPrihoda=new DateTime($R["DanPrihodaObr"]);
			        echo "<tr><td>Datum vrnitve </td><td><input name='DanPrihodaObr' type='text' size='10' value='".$DanPrihoda->format('d.m.Y')."' id='dat01'></td></tr>";
		        }else{
                    $DanPrihoda=new DateTime($R["DanPrihoda"]);
                    echo "<tr><td>Datum vrnitve </td><td><input name='DanPrihodaObr' type='text' size='10' value='".$DanPrihoda->format('d.m.Y')."' id='dat01'></td></tr>";
		        }
		        echo "<tr><td>Čas vrnitve </td><td>";
			        echo "ura <select name='UraPrihodaObr'>";
			        if (isset($R["UraPrihodaObr"])){
				        $VCas=new DateTime($R["UraPrihodaObr"]);
			        }else{
				        $VCas=new DateTime("16:00:00");
			        }
			        for ($Indx=0;$Indx<= 23;$Indx++){
				        if ($Indx==$VCas->format('H')){
					        echo "<option selected>".$Indx."</option>";
				        }else{
					        echo "<option>".$Indx."</option>";
				        }
			        }
			        echo "</select>";
			        echo "min <select name='MinPrihodaObr'>";
			        for ($Indx=0;$Indx<= 59;$Indx++){
				        if ($Indx < 10 ){
					        if ($Indx==$VCas->format('i') ){
						        echo "<option selected>0".$Indx."</option>";
					        }else{
						        echo "<option>0".$Indx."</option>";
					        }
				        }else{
					        if ($Indx==$VCas->format('i') ){
						        echo "<option selected>".$Indx."</option>";
					        }else{
						        echo "<option>".$Indx."</option>";
					        }
				        }
			        }
			        echo "</select>";
			        echo "</td></tr>";

		        echo "<tr><td>Odsotnost dni </td><td><input name='DniObr' type='text' size='5' value='".$R["DniObr"]."'></td></tr>";
		        echo "<tr><td>Odsotnost ur </td><td><input name='UrObr' type='text' size='5' value='".$R["UrObr"]."'></td></tr>";
		        echo "<tr><td>Odsotnost min </td><td><input name='MinObr' type='text' size='5' value='".$R["MinObr"]."'></td></tr>";
		        echo "<tr><td>Število dnevnic </td><td><input name='Dnevnic' type='text' size='5' value='".$R["Dnevnic"]."'></td></tr>";
		        echo "<tr><td>po EUR </td><td><input name='Dnevnica' type='text' size='5' value='".$R["Dnevnica"]."'></td></tr>";
		        if (isset($R["ZnizanjeOd"])){
			        echo "<tr><td><input name='procentZnizanja' type='text' size='5' value='".$R["ProcentZnizanja"]."'> procentov zvišanja/znižanja dnevnic od </td><td><input name='ZnizanjeOd' type='text' size='5' value='".number_format($R["ZnizanjeOd"],2,",","")."'> EUR </td></tr>";
		        }else{
                    echo "<tr><td><input name='procentZnizanja' type='text' size='5' value='0'> procentov zvišanja/znižanja dnevnic od </td><td><input name='ZnizanjeOd' type='text' size='5' value='".number_format($R["Dnevnica"],2,",","")."'> EUR </td></tr>";
		        }
		        echo "<tr><td>Prevozni stroški </td><td></td></tr>";
                if (isset($R["PrevStroskiTxt1"])) {
                    $PrevStroskiTxt1=$R["PrevStroskiTxt1"];
                }else{
                    $PrevStroskiTxt1="";
                }                
                if (isset($R["PrevStroski1"])) {
                    $PrevStroski1=$R["PrevStroski1"];
                    if (!is_numeric($PrevStroski1)){
                        $PrevStroski1=0;
                    }
                }else{
                    $PrevStroski1=0;
                }                
                if (isset($R["PrevStroskiTxt2"])) {
                    $PrevStroskiTxt2=$R["PrevStroskiTxt2"];
                }else{
                    $PrevStroskiTxt2="";
                }                
                if (isset($R["PrevStroski2"])) {
                    $PrevStroski2=$R["PrevStroski2"];
                    if (!is_numeric($PrevStroski2)){
                        $PrevStroski2=0;
                    }
                }else{
                    $PrevStroski2=0;
                }                
                if (isset($R["PrevStroskiTxt3"])) {
                    $PrevStroskiTxt3=$R["PrevStroskiTxt3"];
                }else{
                    $PrevStroskiTxt3="";
                }                
                if (isset($R["PrevStroski3"])) {
                    $PrevStroski3=$R["PrevStroski3"];
                    if (!is_numeric($PrevStroski3)){
                        $PrevStroski3=0;
                    }
                }else{
                    $PrevStroski3=0;
                }                
                if (isset($R["PrevStroskiTxt4"])) {
                    $PrevStroskiTxt4=$R["PrevStroskiTxt4"];
                }else{
                    $PrevStroskiTxt4="";
                }                
                if (isset($R["PrevStroski4"])) {
                    $PrevStroski4=$R["PrevStroski4"];
                    if (!is_numeric($PrevStroski4)){
                        $PrevStroski4=0;
                    }
                }else{
                    $PrevStroski4=0;
                }                
                if (isset($R["DrugiStroskiTxt1"])) {
                    $DrugiStroskiTxt1=$R["DrugiStroskiTxt1"];
                }else{
                    $DrugiStroskiTxt1="";
                }                
                if (isset($R["DrugiStroski1"])) {
                    $DrugiStroski1=$R["DrugiStroski1"];
                    if (!is_numeric($DrugiStroski1)){
                        $DrugiStroski1=0;
                    }
                }else{
                    $DrugiStroski1=0;
                }                
                if (isset($R["DrugiStroskiTxt2"])) {
                    $DrugiStroskiTxt2=$R["DrugiStroskiTxt2"];
                }else{
                    $DrugiStroskiTxt2="";
                }                
                if (isset($R["DrugiStroski2"])) {
                    $DrugiStroski2=$R["DrugiStroski2"];
                    if (!is_numeric($DrugiStroski2)){
                        $DrugiStroski2=0;
                    }
                }else{
                    $DrugiStroski2=0;
                }                
		        echo "<tr><td><input name='PrevStroskiTxt1' type='text' size='40' value='".$PrevStroskiTxt1."'></td><td><input name='PrevStroski1' type='text' size='5' value='".number_format($PrevStroski1,2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt2' type='text' size='40' value='".$PrevStroskiTxt2."'></td><td><input name='PrevStroski2' type='text' size='5' value='".number_format($PrevStroski2,2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt3' type='text' size='40' value='".$PrevStroskiTxt3."'></td><td><input name='PrevStroski3' type='text' size='5' value='".number_format($PrevStroski3,2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt4' type='text' size='40' value='".$PrevStroskiTxt4."'><br><font color='red'>Če želite izračun kilometrine v gornjo vrstico vnesite <b>km:</b> in število kilometrov</font></td><td><input name='PrevStroski4' type='text' size='5' value='".number_format($PrevStroski4,2)."'></td></tr>";
		        echo "<tr><td>Drugi stroški </td><td></td></tr>";
		        echo "<tr><td><input name='DrugiStroskiTxt1' type='text' size='40' value='".$DrugiStroskiTxt1."'></td><td><input name='DrugiStroski1' type='text' size='5' value='".number_format($DrugiStroski1,2)."'></td></tr>";
		        echo "<tr><td><input name='DrugiStroskiTxt2' type='text' size='40' value='".$DrugiStroskiTxt2."'></td><td><input name='DrugiStroski2' type='text' size='5' value='".number_format($DrugiStroski2,2)."'></td></tr>";
		        if (strlen($R["Predujem"]) > 0 ){
                    $Datum= new DateTime($R["Datum"]);
			        echo "<tr><td>Predujem prejet dne ".$Datum->format('d.m.Y')."</td><td>v znesku ".number_format($R["Predujem"],2)."</td></tr>";
		        }else{
			        echo "<tr><td>Predujem prejet dne </td><td>v znesku </td></tr>";
		        }
		        echo "<input type='hidden' name='predujem' value='".$R["Predujem"]."'>";
                if (isset($R["Priloge"])){
                    $Priloge=$R["Priloge"];
                }else{
                    $Priloge="";
                }
		        echo "<tr><td>Priloge </td><td><input name='Priloge' type='text' size='40' value='".$Priloge."'></td></tr>";
                if (isset($R["OdobrenoIzpl"])){
                    $OdobrenoIzpl=$R["OdobrenoIzpl"];
                }else{
                    $OdobrenoIzpl=0;
                }
		        echo "<tr><td>Račun pregledal in odobril izplačilo EUR </td><td><input name='OdobrenoIzpl' type='text' size='10' value='".number_format($R["OdobrenoIzpl"],2)."'> Če želite ponoven obračun odobrenega izplačila, vnesite 0!</td></tr>";
		        echo "</table>";
		        
		        echo "<input name='zapis' type='hidden' value='".$zapis."'>";
		        echo "<input name='id' type='hidden' value='4'>";
		        echo "<input name='submit' type='submit' value='Pošlji za izračun zneskov'>";
		        echo "</form>";
            }
            break;
	    case "4":  //izračun zneskov
            if (isset($_POST["Dnevnica"])){
                $VDnevnica=str_replace(",",".",$_POST["Dnevnica"]);
                $VDnevnica=floatval($VDnevnica);
            }else{
                $VDnevnica=0;
            }
		    
		    $SQL = "SELECT * FROM TabDnevnice ORDER BY id DESC  LIMIT 0,1";
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    $Stroski[0]=$R["km"];
			    $Stroski[1]=$R["dnevnica_do8"];
			    $Stroski[2]=$R["dnevnica_8do12"];
			    $Stroski[3]=$R["dnevnica_nad12"];
		    }
            
            if (isset($_POST["DanOdhodaObr"])){
                $astr=explode(".",$_POST["DanOdhodaObr"]);
                $VDanOdhodaObr = $astr[2]."-".$astr[1]."-".$astr[0];
            }else{
                $VDanOdhodaObr=$Danes->format('Y-m-d');
            }
            if (isset($_POST["DanPrihodaObr"])){
                $astr=explode(".",$_POST["DanPrihodaObr"]);
                $VDanPrihodaObr = $astr[2]."-".$astr[1]."-".$astr[0];
            }else{
                $VDanPrihodaObr=$Danes->format('Y-m-d');
            }
		    $VUraOdhodaObr=$_POST["UraOdhodaObr"].":".$_POST["MinOdhodaObr"].":00";
		    $VUraPrihodaObr=$_POST["UraPrihodaObr"].":".$_POST["MinPrihodaObr"].":00";
            
            $VDanOdhodaObr=new DateTime($VDanOdhodaObr." ".$VUraOdhodaObr);
            $VDanPrihodaObr=new DateTime($VDanPrihodaObr." ".$VUraPrihodaObr);
            
            if (isset($_POST["DniObr"])){
		        $VDniObr=$_POST["DniObr"];
            }else{
                $VDniObr=0;
            }
            if (isset($_POST["UrObr"])){
                $VUrObr=$_POST["UrObr"];
            }else{
                $VUrObr=0;
            }
            if (isset($_POST["MinObr"])){
                $VMinObr=$_POST["MinObr"];
            }else{
                $VMinObr=0;
            }
            
            if (isset($_POST["procentZnizanja"])){
		        $VProcentZnizanja=str_replace(",",".",$_POST["procentZnizanja"]);
                $VProcentZnizanja=floatval($VProcentZnizanja);
            }else{
                $VProcentZnizanja=0;
            }
		    $VZnizanjeOd=str_replace(",",".",$_POST["ZnizanjeOd"]);
            if (isset($_POST["Dnevnic"])){
                $VDnevnic=intval($_POST["Dnevnic"]);
            }else{
                $VDnevnic=0;
            }
            $Interval1=$VDanOdhodaObr->diff($VDanPrihodaObr);
		    $VDniObr=$Interval1->days;
		    $VUrObr=$Interval1->h;
		    $VMinObr=$Interval1->i;
		    if ($VDnevnic == 0){
			    if ($VUrObr >= 12) {
				    $VDnevnic=$VDniObr+1;
			    }else{
				    $VDnevnic=$VDniObr;
			    }
			    
			    if ($VDnevnic == 0 ){
				    switch ($VUrObr){
					    case 6:
                        case 7:
						    $VDnevnic=1;
						    $VDnevnica=$Stroski[1];
                            break;
					    case 8:
                        case 9:
                        case 10:
                        case 11;
						    $VDnevnic=1;
						    $VDnevnica=$Stroski[2];
				    }
			    }else{
				    switch ($VUrObr){
					    case 6;
                        case 7:
						    $VZnizanjeOd=$Stroski[1];
						    $VProcentZnizanja=100;
                            break;
					    case 8:
                        case 9:
                        case 10:
                        case 11:
						    $VZnizanjeOd=$Stroski[2];
						    $VProcentZnizanja=100;
				    }
			    }
		    }
		    
                if (isset($_POST["PrevStroskiTxt1"])) {
                    $PrevStroskiTxt1=$_POST["PrevStroskiTxt1"];
                }else{
                    $PrevStroskiTxt1="";
                }                
                if (isset($_POST["PrevStroski1"])) {
                    $PrevStroski1=floatval(str_replace(",",".",$_POST["PrevStroski1"]));
                    if (!is_numeric($PrevStroski1)){
                        $PrevStroski1=0;
                    }
                }else{
                    $PrevStroski1=0;
                }                
                if (isset($_POST["PrevStroskiTxt2"])) {
                    $PrevStroskiTxt2=$_POST["PrevStroskiTxt2"];
                }else{
                    $PrevStroskiTxt2="";
                }                
                if (isset($_POST["PrevStroski2"])) {
                    $PrevStroski2=floatval(str_replace(",",".",$_POST["PrevStroski2"]));
                    if (!is_numeric($PrevStroski2)){
                        $PrevStroski2=0;
                    }
                }else{
                    $PrevStroski2=0;
                }                
                if (isset($_POST["PrevStroskiTxt3"])) {
                    $PrevStroskiTxt3=$_POST["PrevStroskiTxt3"];
                }else{
                    $PrevStroskiTxt3="";
                }                
                if (isset($_POST["PrevStroski3"])) {
                    $PrevStroski3=floatval(str_replace(",",".",$_POST["PrevStroski3"]));
                    if (!is_numeric($PrevStroski3)){
                        $PrevStroski3=0;
                    }
                }else{
                    $PrevStroski3=0;
                }                
                if (isset($_POST["PrevStroskiTxt4"])) {
                    $PrevStroskiTxt4=$_POST["PrevStroskiTxt4"];
                }else{
                    $PrevStroskiTxt4="";
                }                
                if (isset($_POST["PrevStroski4"])) {
                    $PrevStroski4=floatval(str_replace(",",".",$_POST["PrevStroski4"]));
                    if (!is_numeric($PrevStroski4)){
                        $PrevStroski4=0;
                    }
                }else{
                    $PrevStroski4=0;
                }                
                if (isset($_POST["DrugiStroskiTxt1"])) {
                    $DrugiStroskiTxt1=$_POST["DrugiStroskiTxt1"];
                }else{
                    $DrugiStroskiTxt1="";
                }                
                if (isset($_POST["DrugiStroski1"])) {
                    $DrugiStroski1=floatval(str_replace(",",".",$_POST["DrugiStroski1"]));
                    if (!is_numeric($DrugiStroski1)){
                        $DrugiStroski1=0;
                    }
                }else{
                    $DrugiStroski1=0;
                }                
                if (isset($_POST["DrugiStroskiTxt2"])) {
                    $DrugiStroskiTxt2=$_POST["DrugiStroskiTxt2"];
                }else{
                    $DrugiStroskiTxt2="";
                }                
                if (isset($_POST["DrugiStroski2"])) {
                    $DrugiStroski2=floatval(str_replace(",",".",$_POST["DrugiStroski2"]));
                    if (!is_numeric($DrugiStroski2)){
                        $DrugiStroski2=0;
                    }
                }else{
                    $DrugiStroski2=0;
                }                
                if (isset($_POST["Priloge"])){
                    $Priloge=$_POST["Priloge"];
                }else{
                    $Priloge="";
                }
                if (isset($_POST["OdobrenoIzpl"])){
                    $OdobrenoIzpl=floatval(str_replace(",",".",$_POST["OdobrenoIzpl"]));
                }else{
                    $OdobrenoIzpl=0;
                }
		    if (strpos($PrevStroskiTxt4,"km:") >= 0 ){
                $astr=explode("km:",$PrevStroskiTxt4);
                if (isset($astr[1])){
                    $astr[1]=intval(str_replace(",",".",$astr[1]));
			        if (is_numeric($astr[1]) ){
				        $VPrevStroski4=$astr[1]*$Stroski[0];
			        }else{
				        $VPrevStroski4=$PrevStroski4;
			        }
                }else{
                    $VPrevStroski4=$PrevStroski4;
                }
		    }else{
			    $VPrevStroski4=$PrevStroski4;
		    }
		    
		    $SQL = "UPDATE TabPotniNalog SET ";
		    $SQL = $SQL ." DanOdhodaObr='".$VDanOdhodaObr->format('Y-m-d')."',";
		    $SQL = $SQL . "UraOdhodaObr='".$VDanOdhodaObr->format('H:i:s')."',";
		    $SQL = $SQL ." DanPrihodaObr='".$VDanPrihodaObr->format('Y-m-d')."',";
		    $SQL = $SQL . "UraPrihodaObr='".$VDanPrihodaObr->format('H:i:s')."',";
		    $SQL = $SQL . "DniObr=".$VDniObr.",";
		    $SQL = $SQL . "UrObr=".$VUrObr.",";
		    $SQL = $SQL . "MinObr=".$VMinObr.",";
		    $SQL = $SQL . "Dnevnic=".$VDnevnic.",";
		    $SQL = $SQL . "Dnevnica=".$VDnevnica.",";
		    $SQL = $SQL . "ProcentZnizanja=".$VProcentZnizanja.",";
		    $SQL = $SQL . "ZnizanjeOd=".str_replace(",",".",$VZnizanjeOd).",";
		    $SQL = $SQL . "PrevStroskiTxt1='".$PrevStroskiTxt1."',";
		    $SQL = $SQL . "PrevStroskiTxt2='".$PrevStroskiTxt2."',";
		    $SQL = $SQL . "PrevStroskiTxt3='".$PrevStroskiTxt3."',";
		    $SQL = $SQL . "PrevStroskiTxt4='".$PrevStroskiTxt4."',";
		    $SQL = $SQL . "DrugiStroskiTxt1='".$DrugiStroskiTxt1."',";
		    $SQL = $SQL . "DrugiStroskiTxt2='".$DrugiStroskiTxt2."',";
		    $SQL = $SQL . "PrevStroski1=".str_replace(",",".",$PrevStroski1).",";
		    $SQL = $SQL . "PrevStroski2=".str_replace(",",".",$PrevStroski2).",";
		    $SQL = $SQL . "PrevStroski3=".str_replace(",",".",$PrevStroski3).",";
		    $SQL = $SQL . "PrevStroski4=".str_replace(",",".",$VPrevStroski4).",";
		    $SQL = $SQL . "DrugiStroski1=".str_replace(",",".",$DrugiStroski1).",";
		    $SQL = $SQL . "DrugiStroski2=".str_replace(",",".",$DrugiStroski2).",";
		    $SQL = $SQL . "Priloge='".$Priloge."',";
		    $SQL = $SQL . "OdobrenoIzpl=".str_replace(",",".",$OdobrenoIzpl).",";
		    $SQL = $SQL . "vpisal='".$VUporabnik."',";
		    $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
		    $SQL = $SQL . " WHERE id=".$zapis;
    //'		echo $SQL & "<br>"
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu popravkov potnega naloga: ".$SQL."<br />");
            }
		    
		    $SQL = "SELECT TabPotniNalog.*,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Naslov,tabucitelji.Posta,tabucitelji.Kraj FROM ";
		    $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		    $SQL = $SQL . "WHERE TabPotniNalog.id=".$zapis;
		    $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["idUcitelj"],$VDanOdhodaObr->format('Y'),$VLeto);
		        echo "<h2>Nalog za službeno potovanje</h2>";
		        echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
		        echo "<table border='0'>";
		        echo "<tr><td>Zaporedna št. </td><td>".$R["ZapSt"]."</td></tr>";
                $Datum=new DateTime($R["Datum"]);
		        echo "<tr><td>Datum </td><td>".$Datum->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>Odreja, da odpotuje </td><td>".$R["Priimek"]." ".$R["Ime"]."</td></tr>";
		        echo "<tr><td>Na delovnem mestu </td><td>".$oUcitelj->getDelMesto()."</td></tr>";
		        echo "<tr><td>stanujoč </td><td>".$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"]."</td></tr>";
                $Datum=new DateTime($R["DanOdhoda"]);
		        echo "<tr><td>dne </td><td>".$Datum->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>ob </td><td>".$R["UraOdhoda"]."</td></tr>";
		        echo "<tr><td>po nalogu (odločba - spis) </td><td>".$R["Odlocba"]."</td></tr>";
		        echo "<tr><td>v/na </td><td>".$R["Kam"]."</td></tr>";
		        echo "<tr><td>z nalogo </td><td>".$R["Naloga"]."</td></tr>";
                $Datum=new DateTime($R["DanPrihoda"]);
		        echo "<tr><td>Potovanje bo trajalo do </td><td>".$Datum->format('d.m.Y')."</td></tr>";
		        echo "<tr><td>to je </td><td>".$R["Dni"]." dni</td></tr>";
		        echo "<tr><td>odobravam uporabo (avtomobila, letala, itd.) </td><td>".$R["PrevSredstvo"]."</td></tr>";
		        echo "<tr><td>potne stroške plača </td><td>".$R["Placnik"]."</td></tr>";
		        echo "<tr><td>višina dnevnice </td><td>".number_format($R["Dnevnica"],2)." EUR</td></tr>";
		        echo "<tr><td>posebni dodatki </td><td>".number_format($R["Dodatki"],2)." EUR</td></tr>";
		        echo "<tr><td>odobravam izplačilo predujma v znesku </td><td>".number_format($R["Predujem"],2)." EUR</td></tr>";
		        echo "<tr><td>&nbsp;</td></tr>";
		        echo "<tr><td>Podpis odredbodajalca </td><td>".$R["Odredbodajalec"]."</td></tr>";
		        echo "</table>";
		        echo "<hr>";
		        

		        echo "<h2>Obračun potnih stroškov</h2>";
		        echo "<table border='0'>";
		        echo "<tr><td>Ime in priimek predlagatelja </td><td>".$R["Priimek"]." ".$R["Ime"]."</td></tr>";
		        echo "<tr><td>Prebivališče </td><td>".$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"]."</td></tr>";
                $Datum=new DateTime($R["DanOdhodaObr"]);
		        echo "<tr><td>Datum odhoda </td><td><input name='DanOdhodaObr' type='text' size='10' value='".$Datum->format('d.m.Y')."'></td></tr>";
		        
		        echo "<tr><td>Čas odhoda </td><td>";
                
			    echo "ura <select name='UraOdhodaObr'>";
			    $VCas=new DateTime($R["UraOdhodaObr"]);
			    for ($Indx=0;$Indx <= 23;$Indx++){
				    if ($Indx==$VCas->format('H') ){
					    echo "<option selected>".$Indx."</option>";
				    }else{
					    echo "<option>".$Indx."</option>";
				    }
			    }
			    echo "</select>";
			    echo "min <select name='MinOdhodaObr'>";
			    for ($Indx=0;$Indx<= 59;$Indx++){
				    if ($Indx < 10 ){
					    if ($Indx==$VCas->format('i')) {
						    echo "<option selected>0".$Indx."</option>";
					    }else{
						    echo "<option>0".$Indx."</option>";
					    }
				    }else{
					    if ($Indx==$VCas->format('i')) {
						    echo "<option selected>".$Indx."</option>";
					    }else{
						    echo "<option>".$Indx."</option>";
					    }
				    }
			    }
			    echo "</select>";
			    echo "</td></tr>";
		        $Datum=new DateTime($R["DanPrihodaObr"]);
		        echo "<tr><td>Datum vrnitve </td><td><input name='DanPrihodaObr' type='text' size='10' value='".$Datum->format('d.m.Y')."'></td></tr>";
		        echo "<tr><td>Čas vrnitve </td><td>";
			    echo "ura <select name='UraPrihodaObr'>";
			    $VCas=new DateTime($R["UraPrihodaObr"]);
			    for ($Indx=0;$Indx <= 23;$Indx++){
				    if ($Indx==$VCas->format('H')) {
					    echo "<option selected>".$Indx."</option>";
				    }else{
					    echo "<option>".$Indx."</option>";
				    }
			    }
			    echo "</select>";
			    echo "min <select name='MinPrihodaObr'>";
			    for ($Indx=0;$Indx <= 59;$Indx++){
                    if ($Indx < 10 ){
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>0".$Indx."</option>";
                        }else{
                            echo "<option>0".$Indx."</option>";
                        }
                    }else{
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>".$Indx."</option>";
                        }else{
                            echo "<option>".$Indx."</option>";
                        }
                    }
			    }
			    echo "</select>";
			    echo "</td></tr>";

		        $Znesek[1]=$R["Dnevnic"]*$R["Dnevnica"];
		        $Znesek[2]=$R["ProcentZnizanja"]/100*$R["ZnizanjeOd"];
		        $Znesek[3]=$Znesek[1]+$Znesek[2];
		        $Znesek[4]=$Znesek[3]+$R["PrevStroski1"]+$R["PrevStroski2"]+$R["PrevStroski3"]+$R["PrevStroski4"]+$R["DrugiStroski1"]+$R["DrugiStroski2"];
		        $Znesek[5]=$Znesek[4]-$R["Predujem"];
	        
		        echo "<tr><td>Odsotnost dni </td><td><input name='DniObr' type='text' size='5' value='".$R["DniObr"]."'></td></tr>";
		        echo "<tr><td>Odsotnost ur </td><td><input name='UrObr' type='text' size='5' value='".$R["UrObr"]."'></td></tr>";
		        echo "<tr><td>Odsotnost min </td><td><input name='MinObr' type='text' size='5' value='".$R["MinObr"]."'></td></tr>";
		        echo "<tr><td>Število dnevnic </td><td><input name='Dnevnic' type='text' size='5' value='".$R["Dnevnic"]."'></td></tr>";
		        echo "<tr><td>po EUR </td><td><input name='Dnevnica' type='text' size='5' value='".$R["Dnevnica"]."'></td><td>Skupaj EUR ".number_format($Znesek[1],2)."</td></tr>";
		        if ($R["ZnizanjeOd"] != "" ){
			        echo "<tr><td><input name='procentZnizanja' type='text' size='5' value='".$R["ProcentZnizanja"]."'> procentov zvišanja/znižanja dnevnic od </td><td><input name='ZnizanjeOd' type='text' size='5' value='".number_format($R["ZnizanjeOd"],2)."'> EUR </td><td>Skupaj EUR ".number_format($Znesek[2],2)."</td></tr>";
		        }else{
			        echo "<tr><td><input name='procentZnizanja' type='text' size='5' value='".$R["ProcentZnizanja"]."'> procentov zvišanja/znižanja dnevnic od </td><td><input name='ZnizanjeOd' type='text' size='5' value='".number_format($R["Dnevnica"],2)."'> EUR </td><td>Skupaj EUR </td></tr>";
		        }
		        echo "<tr><td></td><td></td><td>Skupaj EUR ".number_format($Znesek[3],2)."</td></tr>";
		        echo "<tr><td>Prevozni stroški </td><td></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt1' type='text' size='40' value='".$R["PrevStroskiTxt1"]."'></td><td><input name='PrevStroski1' type='text' size='5' value='".number_format($R["PrevStroski1"],2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt2' type='text' size='40' value='".$R["PrevStroskiTxt2"]."'></td><td><input name='PrevStroski2' type='text' size='5' value='".number_format($R["PrevStroski2"],2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt3' type='text' size='40' value='".$R["PrevStroskiTxt3"]."'></td><td><input name='PrevStroski3' type='text' size='5' value='".number_format($R["PrevStroski3"],2)."'></td></tr>";
		        echo "<tr><td><input name='PrevStroskiTxt4' type='text' size='40' value='".$R["PrevStroskiTxt4"]."'></td><td><input name='PrevStroski4' type='text' size='5' value='".number_format($R["PrevStroski4"],2)."'></td></tr>";
		        echo "<tr><td>Drugi stroški </td><td></td></tr>";
		        echo "<tr><td><input name='DrugiStroskiTxt1' type='text' size='40' value='".$R["DrugiStroskiTxt1"]."'></td><td><input name='DrugiStroski1' type='text' size='5' value='".number_format($R["DrugiStroski1"],2)."'></td></tr>";
		        echo "<tr><td><input name='DrugiStroskiTxt2' type='text' size='40' value='".$R["DrugiStroskiTxt2"]."'></td><td><input name='DrugiStroski2' type='text' size='5' value='".number_format($R["DrugiStroski2"],2)."'></td></tr>";
		        echo "<tr><td></td><td></td><td>Skupaj EUR ".number_format($Znesek[4],2)."</td></tr>";
		        if ($R["Predujem"] > 0 ){
                    $Datum = new DateTime($R["Datum"]);
			        echo "<tr><td>Predujem prejet dne ".$Datum->format('d.m.Y')."</td><td>v znesku ".number_format($R["Predujem"],2)."</td></tr>";
		        }else{
			        echo "<tr><td>Predujem prejet dne </td><td>v znesku </td></tr>";
		        }
		        echo "<input type='hidden' name='predujem' value='".number_format($R["Predujem"],2)."'>";
		        echo "<tr><td></td><td></td><td>Skupaj EUR ".number_format($Znesek[5],2)."</td></tr>";
		        echo "<tr><td>Priloge </td><td><input name='Priloge' type='text' size='40' value='".$R["Priloge"]."'></td></tr>";
		        if ($R["OdobrenoIzpl"] > 0 ){
			        echo "<tr><td>Račun pregledal in odobril izplačilo EUR </td><td><input name='OdobrenoIzpl' type='text' size='40' value='".number_format($R["OdobrenoIzpl"],2)."'></td></tr>";
		        }else{
			        echo "<tr><td>Račun pregledal in odobril izplačilo EUR </td><td><input name='OdobrenoIzpl' type='text' size='40' value='".number_format($Znesek[5],2)."'></td></tr>";
		        }
		        echo "</table>";
		        
		        echo "<input name='zapis' type='hidden' value='".$zapis."'>";
		        echo "<input name='id' type='hidden' value='5'>";
		        echo "<input name='submit' type='submit' value='Potrdi'><br />";
		        echo "</form>";
		        if ($R["OdobrenoIzpl"] > 0 ){
			        echo "<a href='PotniNalogiPDF.php?spisek=".$zapis."'>Izpis potnih nalogov (PDF)</a><br />";
		        }
            }
            break;
	    case "5":  //Spisek potnih nalogov
		    if (!CheckDostop("Tajn",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }else{
		        
                if (isset($_POST["Dnevnica"])){
                    $VDnevnica=str_replace(",",".",$_POST["Dnevnica"]);
                }else{
                    $VDnevnica="0";
                }
                if (is_numeric($VDnevnica) ){
                    $VDnevnica=str_replace(",",".",$VDnevnica);
                }else{
                    $VDnevnica=0;
                }
                
                $SQL = "SELECT * FROM TabDnevnice ORDER BY id DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                
                if ($R = mysqli_fetch_array($result)){
                    $Stroski[0]=$R["km"];
                    $Stroski[1]=$R["dnevnica_do8"];
                    $Stroski[2]=$R["dnevnica_8do12"];
                    $Stroski[3]=$R["dnevnica_nad12"];
                }
		        
		        if ($zapis <> ""){
                    if (isset($_POST["DanOdhodaObr"])){
                        $astr=explode(".",$_POST["DanOdhodaObr"]);
                        $VDanOdhodaObr = $astr[2]."-".$astr[1]."-".$astr[0];
                    }else{
                        $VDanOdhodaObr=$Danes->format('Y-m-d');
                    }
                    if (isset($_POST["DanPrihodaObr"])){
                        $astr=explode(".",$_POST["DanPrihodaObr"]);
                        $VDanPrihodaObr = $astr[2]."-".$astr[1]."-".$astr[0];
                    }else{
                        $VDanPrihodaObr=$Danes->format('Y-m-d');
                    }
                    $VUraOdhodaObr=$_POST["UraOdhodaObr"].":".$_POST["MinOdhodaObr"].":00";
                    $VUraPrihodaObr=$_POST["UraPrihodaObr"].":".$_POST["MinPrihodaObr"].":00";
                    
                    $VDanOdhodaObr=new DateTime($VDanOdhodaObr." ".$VUraOdhodaObr);
                    $VDanPrihodaObr=new DateTime($VDanPrihodaObr." ".$VUraPrihodaObr);
                    
                    if (isset($_POST["DniObr"])){
                        $VDniObr=$_POST["DniObr"];
                    }else{
                        $VDniObr=0;
                    }
                    if (isset($_POST["UrObr"])){
                        $VUrObr=$_POST["UrObr"];
                    }else{
                        $VUrObr=0;
                    }
                    if (isset($_POST["MinObr"])){
                        $VMinObr=$_POST["MinObr"];
                    }else{
                        $VMinObr=0;
                    }
                    
                    $VProcentZnizanja=$_POST["procentZnizanja"];
                    $VZnizanjeOd=floatval(str_replace(",",".",$_POST["ZnizanjeOd"]));
                    if (isset($_POST["Dnevnic"])){
                        $VDnevnic=intval($_POST["Dnevnic"]);
                    }else{
                        $VDnevnic=0;
                    }
                    $Interval1=$VDanOdhodaObr->diff($VDanPrihodaObr);
                    $VDniObr=$Interval1->days;
                    $VUrObr=$Interval1->h;
                    $VMinObr=$Interval1->i;
                    if ($VDnevnic == 0){
                        if ($VUrObr >= 12) {
                            $VDnevnic=$VDniObr+1;
                        }else{
                            $VDnevnic=$VDniObr;
                        }
                        
                        if ($VDnevnic == 0 ){
                            switch ($VUrObr){
                                case 6:
                                case 7:
                                    $VDnevnic=1;
                                    $VDnevnica=$Stroski[1];
                                    break;
                                case 8:
                                case 9:
                                case 10:
                                case 11;
                                    $VDnevnic=1;
                                    $VDnevnica=$Stroski[2];
                            }
                        }else{
                            switch ($VUrObr){
                                case 6;
                                case 7:
                                    $VZnizanjeOd=$Stroski[1];
                                    $VProcentZnizanja=100;
                                    break;
                                case 8:
                                case 9:
                                case 10:
                                case 11:
                                    $VZnizanjeOd=$Stroski[2];
                                    $VProcentZnizanja=100;
                            }
                        }
                    }
                    
                    if (isset($_POST["PrevStroskiTxt1"])) {
                        $PrevStroskiTxt1=$_POST["PrevStroskiTxt1"];
                    }else{
                        $PrevStroskiTxt1="";
                    }                
                    if (isset($_POST["PrevStroski1"])) {
                        $PrevStroski1=floatval(str_replace(",",".",$_POST["PrevStroski1"]));
                        if (!is_numeric($PrevStroski1)){
                            $PrevStroski1=0;
                        }
                    }else{
                        $PrevStroski1=0;
                    }                
                    if (isset($_POST["PrevStroskiTxt2"])) {
                        $PrevStroskiTxt2=$_POST["PrevStroskiTxt2"];
                    }else{
                        $PrevStroskiTxt2="";
                    }                
                    if (isset($_POST["PrevStroski2"])) {
                        $PrevStroski2=floatval(str_replace(",",".",$_POST["PrevStroski2"]));
                        if (!is_numeric($PrevStroski2)){
                            $PrevStroski2=0;
                        }
                    }else{
                        $PrevStroski2=0;
                    }                
                    if (isset($_POST["PrevStroskiTxt3"])) {
                        $PrevStroskiTxt3=$_POST["PrevStroskiTxt3"];
                    }else{
                        $PrevStroskiTxt3="";
                    }                
                    if (isset($_POST["PrevStroski3"])) {
                        $PrevStroski3=floatval(str_replace(",",".",$_POST["PrevStroski3"]));
                        if (!is_numeric($PrevStroski3)){
                            $PrevStroski3=0;
                        }
                    }else{
                        $PrevStroski3=0;
                    }                
                    if (isset($_POST["PrevStroskiTxt4"])) {
                        $PrevStroskiTxt4=$_POST["PrevStroskiTxt4"];
                    }else{
                        $PrevStroskiTxt4="";
                    }                
                    if (isset($_POST["PrevStroski4"])) {
                        $PrevStroski4=floatval(str_replace(",",".",$_POST["PrevStroski4"]));
                        if (!is_numeric($PrevStroski4)){
                            $PrevStroski4=0;
                        }
                    }else{
                        $PrevStroski4=0;
                    }                
                    if (isset($_POST["DrugiStroskiTxt1"])) {
                        $DrugiStroskiTxt1=$_POST["DrugiStroskiTxt1"];
                    }else{
                        $DrugiStroskiTxt1="";
                    }                
                    if (isset($_POST["DrugiStroski1"])) {
                        $DrugiStroski1=floatval(str_replace(",",".",$_POST["DrugiStroski1"]));
                        if (!is_numeric($DrugiStroski1)){
                            $DrugiStroski1=0;
                        }
                    }else{
                        $DrugiStroski1=0;
                    }                
                    if (isset($_POST["DrugiStroskiTxt2"])) {
                        $DrugiStroskiTxt2=$_POST["DrugiStroskiTxt2"];
                    }else{
                        $DrugiStroskiTxt2="";
                    }                
                    if (isset($_POST["DrugiStroski2"])) {
                        $DrugiStroski2=floatval(str_replace(",",".",$_POST["DrugiStroski2"]));
                        if (!is_numeric($DrugiStroski2)){
                            $DrugiStroski2=0;
                        }
                    }else{
                        $DrugiStroski2=0;
                    }                
                    if (isset($_POST["Priloge"])){
                        $Priloge=$_POST["Priloge"];
                    }else{
                        $Priloge="";
                    }
                    if (isset($_POST["OdobrenoIzpl"])){
                        $OdobrenoIzpl=floatval(str_replace(",",".",$_POST["OdobrenoIzpl"]));
                    }else{
                        $OdobrenoIzpl=0;
                    }
                    if (strpos($PrevStroskiTxt4,"km:") >= 0 ){
                        $astr=explode("km:",$PrevStroskiTxt4);
                        if (isset($astr[1])){
                            $astr[1]=str_replace(",",".",$astr[1]);
                            if (is_numeric($astr[1]) ){
                                $VPrevStroski4=$astr[1]*$Stroski[0];
                            }else{
                                $VPrevStroski4=$PrevStroski4;
                            }
                        }else{
                            $VPrevStroski4=$PrevStroski4;
                        }
                    }else{
                        $VPrevStroski4=$PrevStroski4;
                    }
                    if (isset($_POST["Priloge"])){
                        $Priloge=$_POST["Priloge"];
                    }else{
                        $Priloge="";
                    }
                    if (isset($_POST["OdobrenoIzpl"])){
                        $OdobrenoIzpl=$_POST["OdobrenoIzpl"];
                    }else{
                        $OdobrenoIzpl=0;
                    }
                    
                    $SQL = "UPDATE TabPotniNalog SET ";
                    $SQL = $SQL ." DanOdhodaObr='".$VDanOdhodaObr->format('Y-m-d')."',";
                    $SQL = $SQL . "UraOdhodaObr='".$VDanOdhodaObr->format('H:i:s')."',";
                    $SQL = $SQL ." DanPrihodaObr='".$VDanPrihodaObr->format('Y-m-d')."',";
                    $SQL = $SQL . "UraPrihodaObr='".$VDanPrihodaObr->format('H:i:s')."',";
                    $SQL = $SQL . "DniObr=".$VDniObr.",";
                    $SQL = $SQL . "UrObr=".$VUrObr.",";
                    $SQL = $SQL . "MinObr=".$VMinObr.",";
                    $SQL = $SQL . "Dnevnic=".$VDnevnic.",";
                    $SQL = $SQL . "Dnevnica=".$VDnevnica.",";
                    $SQL = $SQL . "ProcentZnizanja=".str_replace(",",".",$VProcentZnizanja).",";
                    $SQL = $SQL . "ZnizanjeOd=".str_replace(",",".",$VZnizanjeOd).",";
                    $SQL = $SQL . "PrevStroskiTxt1='".$PrevStroskiTxt1."',";
                    $SQL = $SQL . "PrevStroskiTxt2='".$PrevStroskiTxt2."',";
                    $SQL = $SQL . "PrevStroskiTxt3='".$PrevStroskiTxt3."',";
                    $SQL = $SQL . "PrevStroskiTxt4='".$PrevStroskiTxt4."',";
                    $SQL = $SQL . "DrugiStroskiTxt1='".$DrugiStroskiTxt1."',";
                    $SQL = $SQL . "DrugiStroskiTxt2='".$DrugiStroskiTxt2."',";
                    $SQL = $SQL . "PrevStroski1=".str_replace(",",".",$PrevStroski1).",";
                    $SQL = $SQL . "PrevStroski2=".str_replace(",",".",$PrevStroski2).",";
                    $SQL = $SQL . "PrevStroski3=".str_replace(",",".",$PrevStroski3).",";
                    $SQL = $SQL . "PrevStroski4=".str_replace(",",".",$VPrevStroski4).",";
                    $SQL = $SQL . "DrugiStroski1=".str_replace(",",".",$DrugiStroski1).",";
                    $SQL = $SQL . "DrugiStroski2=".str_replace(",",".",$DrugiStroski2).",";
                    $SQL = $SQL . "Priloge='".$Priloge."',";
                    $SQL = $SQL . "OdobrenoIzpl=".str_replace(",",".",$OdobrenoIzpl).",";
                    $SQL = $SQL . "vpisal='".$VUporabnik."',";
                    $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
                    $SQL = $SQL . " WHERE id=".$zapis;
            //'        echo $SQL & "<br>"
                    
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu obračuna: ".$SQL."<br />");
                    }
		        }
		        echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
                if (isset($_POST["letoPN"])){
			        $letoPN=$_POST["letoPN"];
		        }else{
                    $letoPN=$Danes->format('Y');
		        }
		        echo "Izberi leto: <select name='letoPN'>";
		        if ($letoPN == $Danes->format('Y')){
			        echo "<option selected>".$Danes->format('Y')."</option>";
			        echo "<option>".($Danes->format('Y')-1)."</option>";
		        }else{
			        echo "<option>".$Danes->format('Y')."</option>";
			        echo "<option selected>".($Danes->format('Y')-1)."</option>";
		        }
		        echo "</select>";
		        echo "<input name='id' type='hidden' value='5'>";
		        echo "<input name='submit' type='submit' value='Izberi'><br />";
		        echo "</form>";

		        echo "<form name='dnevnice' method='post' action='VnosPotniNalogi.php'>";
		        if (!isset($_POST["dnevnica_do8"])){
			        $SQL = "SELECT * FROM TabDnevnice ORDER BY id DESC LIMIT 0,1";
			        $result = mysqli_query($link,$SQL);
			        if ($R = mysqli_fetch_array($result)){
                        $Stroski[0]=$R["km"];
                        $Stroski[1]=$R["dnevnica_do8"];
                        $Stroski[2]=$R["dnevnica_8do12"];
                        $Stroski[3]=$R["dnevnica_nad12"];
			        }
		        }else{
                    if (isset($_POST["km"])){
                        $Stroski[0]=$_POST["km"];
                    }else{
                        $Stroski[0]=0;
                    }    
                    if (isset($_POST["dnevnica_do8"])){
                        $Stroski[1]=$_POST["dnevnica_do8"];
                    }else{
                        $Stroski[1]=0;
                    }
                    if (isset($_POST["dnevnica_8do12"])){
                        $Stroski[2]=$_POST["dnevnica_8do12"];
                    }else{
                        $Stroski[2]=0;
                    }
                    if (isset($_POST["dnevnica_nad12"])){
                        $Stroski[3]=$_POST["dnevnica_nad12"];
                    }else{
                        $Stroski[3]=0;
                    }    
			        $SQL = "INSERT INTO TabDnevnice (datum,km,dnevnica_do8,dnevnica_8do12,dnevnica_nad12) VALUES (";
			        $SQL = $SQL . "'".$Danes->format('Y-m-d')."',";
			        $SQL = $SQL . str_replace(",",".",$Stroski[0]).",";
			        $SQL = $SQL . str_replace(",",".",$Stroski[1]).",";
			        $SQL = $SQL .str_replace(",",".",$Stroski[2]).",";
			        $SQL = $SQL . str_replace(",",".",$Stroski[3]).")";
			        $result = mysqli_query($link,$SQL);
			        
			        $SQL = "SELECT * FROM TabDnevnice ORDER BY id DESC LIMIT 0,1";
			        $result = mysqli_query($link,$SQL);
			        if ($R = mysqli_fetch_array($result)){
                        $Stroski[0]=$R["km"];
                        $Stroski[1]=$R["dnevnica_do8"];
                        $Stroski[2]=$R["dnevnica_8do12"];
                        $Stroski[3]=$R["dnevnica_nad12"];
			        }
		        }
		        
		        echo "<h2>Kilometrina in dnevnice:</h2>";
		        echo "<table border='1'>";
		        echo "<tr><td>Kilometrina</td><td><input name='km' type='text' size='6' value='".$Stroski[0]."'></td></tr>";
		        echo "<tr><td>Dnevnica 6 do 8 ur</td><td><input name='dnevnica_do8' type='text' size='6' value='".$Stroski[1]."'></td></tr>";
		        echo "<tr><td>Dnevnica 8 do 12 ur</td><td><input name='dnevnica_8do12' type='text' size='6' value='".$Stroski[2]."'></td></tr>";
		        echo "<tr><td>Dnevnica nad 12 ur</td><td><input name='dnevnica_nad12' type='text' size='6' value='".$Stroski[3]."'></td></tr>";
		        echo "</table>";
		        echo "<input name='id' type='hidden' value='5'>";
		        echo "<input name='submit' type='submit' value='Spremeni'><br>";
		        echo "</form>";
		        
		        echo "<h2>Spisek potnih nalogov za leto ".$letoPN."</h2>";
		        echo "<a href='IzborPotniNalog.php'>Nov potni nalog</a><br />";
		        $SQL = "SELECT TabPotniNalog.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
		        $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		        $SQL = $SQL . "WHERE leto=".$letoPN;
		        $SQL = $SQL . " ORDER BY ZapSt DESC";
		        $result = mysqli_query($link,$SQL);
		        
		        echo "<form name='obracunPDF' method='post' action='PotniNalogiPDF.php'>";
                echo "<br />";
                echo "<input name='submit' type='submit' value='Tvori PDF'><br />";
		        echo "<table border='1'>";
		        echo "<tr><th>Št.</th><th>Datum</th><th>Zap.št</th><th>Ime</th><th>Kam</th><th>Naloga</th><th>Znesek</th><th>Nalog</th><th>Obračun</th><th>Izpis</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        if (isDate($R["DanOdhodaObr"]) && isDate($R["DanPrihodaObr"]) ){
				        echo "<tr bgcolor='lightgreen'>";
			        }else{
				        echo "<tr bgcolor='lightsalmon'>";
			        }
			        echo "<td align=center>".$Indx."</td>";
                    $Datum=new DateTime($R["Datum"]);
			        echo "<td>".$Datum->format('d.m.Y')."</td>";
			        echo "<td align=center>".$R["ZapSt"]."</td>";
			        echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			        echo "<td>".$R["Kam"]."</td>";
			        echo "<td>".$R["Naloga"]."</td>";
			        echo "<td align=right>".number_format($R["OdobrenoIzpl"],2)." EUR</td>";
			        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=7'>Popravi</a></td>";
			        if ($R["OdobrenoIzpl"] > 0 ){
				        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Popravi</a></td>";
			        }else{
				        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Vnesi</a></td>";
			        }
			        echo "<td><input name='pn".$Indx."' type='checkbox'><input name='idpn".$Indx."' type='hidden' value='".$R["id"]."'></td>";
			        echo "</tr>";
			        $Indx=$Indx+1;
		        }
		        echo "</table><br>";
		        echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
		        echo "<input name='submit' type='submit' value='Tvori PDF'><br />";
		        echo "</form>";
            }
            break;
	    case "6": //kopiranje potnih nalogov
		    if (!CheckDostop("Tajn",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }else{
		        $StZapisov=$_POST["StZapisov"];
		        $i1=$_POST["pniz"];
		        $KopirajIz=$_POST["idpniz".$i1];
		        for ($Indx=1;$Indx <= $StZapisov;$Indx++){
			        if (isset($_POST["pn".$Indx])){
				        if (strlen($zapis) == 0 ){
					        $zapis=$_POST["idpn".$Indx];
				        }else{
					        $zapis=$zapis.",".$_POST["idpn".$Indx];
				        }
			        }
		        }
		        
		        $SQL = "SELECT * FROM TabPotniNalog WHERE id=".$KopirajIz;
		        $result = mysqli_query($link,$SQL);

		        if ($R = mysqli_fetch_array($result)){
			        $SQL = "UPDATE TabPotniNalog SET ";
			        $SQL = $SQL ." DanOdhodaObr='".$R["DanOdhodaObr"]."',";
			        $SQL = $SQL . "UraOdhodaObr='".$R["UraOdhodaObr"]."',";
			        $SQL = $SQL ." DanPrihodaObr='".$R["DanPrihodaObr"]."',";
			        $SQL = $SQL . "UraPrihodaObr='".$R["UraPrihodaObr"]."',";
			        $SQL = $SQL . "DniObr=".$R["DniObr"].",";
			        $SQL = $SQL . "UrObr=".$R["UrObr"].",";
			        $SQL = $SQL . "MinObr=".$R["MinObr"].",";
			        $SQL = $SQL . "Dnevnic=".$R["Dnevnic"].",";
			        $SQL = $SQL . "ProcentZnizanja=".$R["ProcentZnizanja"].",";
			        $SQL = $SQL . "ZnizanjeOd=".$R["ZnizanjeOd"].",";
			        $SQL = $SQL . "PrevStroskiTxt1='".$R["PrevStroskiTxt1"]."',";
			        $SQL = $SQL . "PrevStroskiTxt2='".$R["PrevStroskiTxt2"]."',";
			        $SQL = $SQL . "PrevStroskiTxt3='".$R["PrevStroskiTxt3"]."',";
			        $SQL = $SQL . "PrevStroskiTxt4='".$R["PrevStroskiTxt4"]."',";
			        $SQL = $SQL . "DrugiStroskiTxt1='".$R["DrugiStroskiTxt1"]."',";
			        $SQL = $SQL . "DrugiStroskiTxt2='".$R["DrugiStroskiTxt2"]."',";
			        $SQL = $SQL . "PrevStroski1=".$R["PrevStroski1"].",";
			        $SQL = $SQL . "PrevStroski2=".$R["PrevStroski2"].",";
			        $SQL = $SQL . "PrevStroski3=".$R["PrevStroski3"].",";
			        $SQL = $SQL . "PrevStroski4=".$R["PrevStroski4"].",";
			        $SQL = $SQL . "DrugiStroski1=".$R["DrugiStroski1"].",";
			        $SQL = $SQL . "DrugiStroski2=".$R["DrugiStroski2"].",";
			        $SQL = $SQL . "Priloge='".$R["Priloge"]."',";
			        $SQL = $SQL . "OdobrenoIzpl=".$R["OdobrenoIzpl"].",";
			        $SQL = $SQL . "vpisal='".$VUporabnik."',";
			        $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
			        $SQL = $SQL." WHERE id IN (".$zapis.")";
			        $result = mysqli_query($link,$SQL);
		        }else{
			        echo "Vir ne obstaja!<br>Potni nalogi niso bili skopirani!<br />";
		        }
		        echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
		        if (isset($_POST["letoPN"])){
                    $letoPN=$_POST["letoPN"];
		        }else{
                    $letoPN=$Danes->format('Y');
		        }
		        echo "Izberi leto: <select name='letoPN'>";
		        if ($letoPN == $Danes->format('Y')){
			        echo "<option selected>".$Danes->format('Y')."</option>";
			        echo "<option>".($Danes->format('Y')-1)."</option>";
		        }else{
                    echo "<option>".$Danes->format('Y')."</option>";
                    echo "<option selected>".($Danes->format('Y')-1)."</option>";
		        }
		        echo "</select>";
		        echo "<input name='id' type='hidden' value='5'>";
		        echo "<input name='submit' type='submit' value='Izberi'><br />";
		        echo "</form>";
		        
		        echo "<h2>Spisek potnih nalogov za leto ".$letoPN."</h2>";
		        
		        $SQL = "SELECT TabPotniNalog.*,tabucitelji.* FROM ";
		        $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		        $SQL = $SQL . "WHERE leto=".$letoPN;
		        $SQL = $SQL . " ORDER BY ZapSt DESC";
		        $result = mysqli_query($link,$SQL);
		        
		        echo "<form name='obracunPDF' method='post' action='PotniNalogiPDF.php'>";
		        echo "<br><table border='1'>";
		        echo "<tr><th>Št.</th><th>Datum</th><th>Zap.št</th><th>Ime</th><th>Kam</th><th>Naloga</th><th>Znesek</th><th>Obračun</th><th>Izpis</th></tr>";
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
			        echo "<tr>";
                    echo "<td align=center>".$Indx."</td>";
                    $Datum=new DateTime($R["Datum"]);
                    echo "<td>".$Datum->format('d.m.Y')."</td>";
                    echo "<td align=center>".$R["ZapSt"]."</td>";
                    echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
                    echo "<td>".$R["Kam"]."</td>";
                    echo "<td>".$R["Naloga"]."</td>";
                    echo "<td align=right>".number_format($R["OdobrenoIzpl"],2)." EUR</td>";
                    echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["TabPotniNalog.id"]."&id=7'>Popravi</a></td>";
                    if ($R["OdobrenoIzpl"] > 0 ){
                        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Popravi</a></td>";
                    }else{
                        echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Vnesi</a></td>";
                    }
                    echo "<td><input name='pn".$Indx."' type='checkbox'><input name='idpn".$Indx."' type='hidden' value='".$R["TabPotniNalog.id"]."'></td>";
                    echo "</tr>";
			        $Indx=$Indx+1;
		        }
		        echo "</table><br />";
		        echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
		        echo "<input name='submit' type='submit' value='Tvori PDF'><br />";
		        echo "</form>";
            }
            break;
	    case "7":  //popravi potni nalog
		    if (!CheckDostop("Tajn",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }
		    $SQL = "SELECT TabPotniNalog.* FROM TabPotniNalog ";
		    $SQL = $SQL . "WHERE TabPotniNalog.id=".$zapis;
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    $VUcitelj=$R["idUcitelj"];
		    }
		    
		    $SQL = "SELECT tabucitelji.IdUcitelj,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Naslov,tabucitelji.Posta,tabucitelji.Kraj FROM ";
		    $SQL = $SQL ."tabucitelji "; //'INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo "
		    $SQL = $SQL ."WHERE status > 0 ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    
		    $Indx=0;
		    while ($R = mysqli_fetch_array($result)){
                $Indx=$Indx+1;
			    $ucitelj[$Indx][0]=$R["IdUcitelj"];
			    $ucitelj[$Indx][1]=$R["Priimek"]." ".$R["Ime"];
			    //'ucitelj(Indx,2)=$R["VzgojnoDelo")
			    $ucitelj[$Indx][3]=$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
		    }
		    $StUciteljev=$Indx;
		    
		    $SQL = "SELECT TabPotniNalog.* FROM TabPotniNalog ";
		    $SQL = $SQL . "WHERE TabPotniNalog.id=".$zapis;
		    $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
		        echo "<h2>Nalog za službeno potovanje</h2>";
		        echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
		        echo "<table border='0'>";
		        echo "<tr><td>Zaporedna št. </td><td><input name='ZapSt' type='text' size='5' value='".$R["ZapSt"]."'></td></tr>";
                $Datum=new DateTime($R["Datum"]);
		        echo "<tr><td>Datum </td><td><input name='Datum' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat01'></td></tr>";
		        echo "<tr><td>Odrejam, da odpotuje </td><td><select name='delavec'>";
		        for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
			        if ($R["idUcitelj"]==$ucitelj[$Indx][0] ){
				        echo "<option value='".$ucitelj[$Indx][0]."' selected>".$ucitelj[$Indx][1].", ".$ucitelj[$Indx][2].", ".$ucitelj[$Indx][3]."</option>";
			        }else{
				        echo "<option value='".$ucitelj[$Indx][0]."'>".$ucitelj[$Indx][1].", ".$ucitelj[$Indx][2].", ".$ucitelj[$Indx][3]."</option>";
			        }
		        }
		        echo"</select></td></tr>";
                
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["idUcitelj"],$Datum->format('Y'),$VLeto);
		        echo "<tr><td>Odrejam, da odpotuje </td><td>".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."</td></tr>";
		        echo "<tr><td>Na delovnem mestu </td><td>".$oUcitelj->getDelMesto()."</td></tr>";
		        echo "<tr><td>stanujoč </td><td>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td></tr>";
                $Datum=new DateTime($R["DanOdhoda"]);
		        echo "<tr><td>dne </td><td><input name='DanOdhoda' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat02'></td></tr>";
		        echo "<tr><td>ob </td><td>".$R["UraOdhoda"]."</td></tr>";
		        echo "<tr><td>ob </td><td>";
			    echo "ura <select name='UraOdhoda'>";
                $VCas=new DateTime($R["UraOdhoda"]);
                for ($Indx=0;$Indx <= 23;$Indx++){
                    if ($Indx==$VCas->format('H')) {
                        echo "<option selected>".$Indx."</option>";
                    }else{
                        echo "<option>".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "min <select name='MinOdhoda'>";
                for ($Indx=0;$Indx <= 59;$Indx++){
                    if ($Indx < 10 ){
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>0".$Indx."</option>";
                        }else{
                            echo "<option>0".$Indx."</option>";
                        }
                    }else{
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>".$Indx."</option>";
                        }else{
                            echo "<option>".$Indx."</option>";
                        }
                    }
                }
			    echo "</select>";
			    echo "</td></tr>";
		        echo "<tr><td>po nalogu (odločba - spis) </td><td><input name='Odlocba' type='text' size='30' value='".$R["Odlocba"]."'></td></tr>";
		        echo "<tr><td>v/na </td><td><input name='Kam' type='text' size='30' value='".$R["Kam"]."'></td></tr>";
		        echo "<tr><td>z nalogo </td><td><input name='Naloga' type='text' size='30' value='".$R["Naloga"]."'></td></tr>";
                $Datum=new DateTime($R["DanPrihoda"]);
		        echo "<tr><td>Potovanje bo trajalo do </td><td><input name='DanPrihoda' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat03'></td></tr>";
		        echo "<tr><td>to je </td><td><input name='Dni' type='text' size='5' value='".$R["Dni"]."'> dni</td></tr>";
		        echo "<tr><td>odobravam uporabo (avtomobila, letala, itd.) </td><td><input name='PrevSredstvo' type='text' size='30' value='".$R["PrevSredstvo"]."'></td></tr>";
		        echo "<tr><td>potne stroške plača </td><td><input name='Placnik' type='text' size='30' value='".$R["Placnik"]."'></td></tr>";
		        echo "<tr><td>višina dnevnice </td><td><input name='Dnevnica' type='text' size='5' value='".$R["Dnevnica"]."'> EUR</td></tr>";
		        echo "<tr><td>posebni dodatki </td><td><input name='Dodatki' type='text' size='5' value='".$R["Dodatki"]."'> EUR</td></tr>";
		        echo "<tr><td>odobravam izplačilo predujma v znesku </td><td><input name='Predujem' type='text' size='5' value='".$R["Predujem"]."'> EUR</td></tr>";
		        echo "<tr><td></td></tr>";
		        echo "<tr><td>Podpis odredbodajalca </td><td><input name='Odredbodajalec' type='text' size='20' value='".$R["Odredbodajalec"]."'></td></tr>";
		        echo "</table>";
		        
		        echo "<input name='zapis' type='hidden' value='".$zapis."'>";
		        echo "<input name='id' type='hidden' value='8'>";
		        echo "<input name='submit' type='submit' value='Pošlji'>";
		        echo "</form>";
            }
            break;
	    case "7a": //popravljanje za netajnike (učitelje)
		    if (!CheckDostop("drugo5",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }
		    
            $SQL = "SELECT iducitelj FROM tabpotninalog ";
            $SQL = $SQL . "WHERE tabpotninalog.id=".$zapis;
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $VUcitelj=$R["iducitelj"];
            }
            
            $SQL = "SELECT tabucitelji.IdUcitelj,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Naslov,tabucitelji.Posta,tabucitelji.Kraj FROM ";
            $SQL = $SQL ."tabucitelji "; //'INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo "
            $SQL = $SQL ."WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Indx=$Indx+1;
                $ucitelj[$Indx][0]=$R["IdUcitelj"];
                $ucitelj[$Indx][1]=$R["Priimek"]." ".$R["Ime"];
                //'ucitelj(Indx,2)=$R["VzgojnoDelo")
                $ucitelj[$Indx][3]=$R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"];
            }
            $StUciteljev=$Indx;
            
            $SQL = "SELECT iducitelj,datum,zapst,danodhoda,uraodhoda,odlocba,kam,naloga,danprihoda,dni,prevsredstvo,placnik,dnevnica,dodatki,predujem,odredbodajalec FROM tabpotninalog ";
            $SQL = $SQL . "WHERE tabpotninalog.id=".$zapis;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Nalog za službeno potovanje</h2>";
                echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
                echo "<table border='0'>";
                echo "<tr><td>Zaporedna št. </td><td><input name='ZapSt' type='text' size='5' value='".$R["zapst"]."'></td></tr>";
                $Datum=new DateTime($R["datum"]);
                echo "<tr><td>Datum </td><td><input name='Datum' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat01'></td></tr>";
                echo "<tr><td>Odrejam, da odpotuje </td><td><select name='delavec'>";
                for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
                    if ($R["iducitelj"]==$ucitelj[$Indx][0] ){
                        echo "<option value='".$ucitelj[$Indx][0]."' selected>".$ucitelj[$Indx][1].", ".$ucitelj[$Indx][2].", ".$ucitelj[$Indx][3]."</option>";
                    }else{
                        echo "<option value='".$ucitelj[$Indx][0]."'>".$ucitelj[$Indx][1].", ".$ucitelj[$Indx][2].", ".$ucitelj[$Indx][3]."</option>";
                    }
                }
                echo"</select></td></tr>";
                
                $oUcitelj=new RUcitelj();
                $oUcitelj->PreberiSeGlavno($R["iducitelj"],$Datum->format('Y'),$VLeto);
                echo "<tr><td>Odrejam, da odpotuje </td><td>".$oUcitelj->getPriimek()." ".$oUcitelj->getIme()."</td></tr>";
                echo "<tr><td>Na delovnem mestu </td><td>".$oUcitelj->getDelMesto()."</td></tr>";
                echo "<tr><td>stanujoč </td><td>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td></tr>";
                $Datum=new DateTime($R["danodhoda"]);
                echo "<tr><td>dne </td><td><input name='DanOdhoda' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat02'></td></tr>";
                echo "<tr><td>ob </td><td>".$R["uraodhoda"]."</td></tr>";
                echo "<tr><td>ob </td><td>";
                echo "ura <select name='UraOdhoda'>";
                $VCas=new DateTime($R["uraodhoda"]);
                for ($Indx=0;$Indx <= 23;$Indx++){
                    if ($Indx==$VCas->format('H')) {
                        echo "<option selected>".$Indx."</option>";
                    }else{
                        echo "<option>".$Indx."</option>";
                    }
                }
                echo "</select>";
                echo "min <select name='MinOdhoda'>";
                for ($Indx=0;$Indx <= 59;$Indx++){
                    if ($Indx < 10 ){
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>0".$Indx."</option>";
                        }else{
                            echo "<option>0".$Indx."</option>";
                        }
                    }else{
                        if ($Indx==$VCas->format('i')) {
                            echo "<option selected>".$Indx."</option>";
                        }else{
                            echo "<option>".$Indx."</option>";
                        }
                    }
                }
                echo "</select>";
                echo "</td></tr>";
                echo "<tr><td>po nalogu (odločba - spis) </td><td><input name='Odlocba' type='text' size='30' value='".$R["odlocba"]."'></td></tr>";
                echo "<tr><td>v/na </td><td><input name='Kam' type='text' size='30' value='".$R["kam"]."'></td></tr>";
                echo "<tr><td>z nalogo </td><td><input name='Naloga' type='text' size='30' value='".$R["naloga"]."'></td></tr>";
                $Datum=new DateTime($R["danprihoda"]);
                echo "<tr><td>Potovanje bo trajalo do </td><td><input name='DanPrihoda' type='text' size='10' value='".$Datum->format('d.m.Y')."' id='dat03'></td></tr>";
                echo "<tr><td>to je </td><td><input name='Dni' type='text' size='5' value='".$R["dni"]."'> dni</td></tr>";
                echo "<tr><td>odobravam uporabo (avtomobila, letala, itd.) </td><td><input name='PrevSredstvo' type='text' size='30' value='".$R["prevsredstvo"]."'></td></tr>";
                echo "<tr><td>potne stroške plača </td><td><input name='Placnik' type='text' size='30' value='".$R["placnik"]."'></td></tr>";
                echo "<tr><td>višina dnevnice </td><td><input name='Dnevnica' type='text' size='5' value='".$R["dnevnica"]."'> EUR</td></tr>";
                echo "<tr><td>posebni dodatki </td><td><input name='Dodatki' type='text' size='5' value='".$R["dodatki"]."'> EUR</td></tr>";
                echo "<tr><td>odobravam izplačilo predujma v znesku </td><td><input name='Predujem' type='text' size='5' value='".$R["predujem"]."'> EUR</td></tr>";
                echo "<tr><td></td></tr>";
                echo "<tr><td>Podpis odredbodajalca </td><td><input name='Odredbodajalec' type='text' size='20' value='".$R["odredbodajalec"]."'></td></tr>";
                echo "</table>";
                
                echo "<input name='zapis' type='hidden' value='".$zapis."'>";
                echo "<input name='id' type='hidden' value='8a'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
            break;
	    case "8":  //vpis popravka
		    if (!CheckDostop("Tajn",$VUporabnik) ){
                header ("Location: nepooblascen.htm");
            }else{
		        
		        $SQL = "UPDATE TabPotniNalog SET ";
                if (isset($_POST["DanOdhoda"])){
                    $astr=explode(".",$_POST["DanOdhoda"]);
                    $DanOdhoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $DanOdhoda=new DateTime($Danes->format('Y-m-d'));
                }
                if (isset($_POST["DanPrihoda"])){
                    $astr=explode(".",$_POST["DanPrihoda"]);
                    $DanPrihoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $DanPrihoda=new DateTime($Danes->format('Y-m-d'));
                }
                if (isset($_POST["UraOdhoda"])){
                    $UraOdhoda=$_POST["UraOdhoda"];
                }else{
                    $UraOdhoda="";
                }
                if (isset($_POST["MinOdhoda"])){
                    $MinOdhoda=$_POST["MinOdhoda"];
                }else{
                    $MinOdhoda="";
                }
                if (isset($_POST["Datum"])){
                    $astr=explode(".",$_POST["Datum"]);
                    $Datum = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $Datum=new DateTime($Danes->format('Y-m-d'));
                }
		        $SQL = $SQL ." DanOdhoda='".$DanOdhoda->format('Y-m-d')."',";
		        $SQL = $SQL ." DanPrihoda='".$DanPrihoda->format('Y-m-d')."',";
		        $SQL = $SQL ." Datum='".$Datum->format('Y-m-d')."',";
		        $SQL = $SQL ." UraOdhoda='".$UraOdhoda.":".$MinOdhoda.":00',";
		        $SQL = $SQL ." ZapSt=".$_POST["ZapSt"].",";
		        $SQL = $SQL ." idUcitelj=".$_POST["delavec"].",";
		        $SQL = $SQL ." odlocba='".$_POST["Odlocba"]."',";
		        $SQL = $SQL ." kam='".$_POST["Kam"]."',";
		        $SQL = $SQL ." naloga='".$_POST["Naloga"]."',";
		        $SQL = $SQL ." dni='".$_POST["Dni"]."',";
		        $SQL = $SQL ." prevSredstvo='".$_POST["PrevSredstvo"]."',";
		        $SQL = $SQL ." placnik='".$_POST["Placnik"]."',";
		        $SQL = $SQL ." dnevnica=".str_replace(",",".",$_POST["Dnevnica"]).",";
		        $SQL = $SQL ." dodatki=".str_replace(",",".",$_POST["Dodatki"]).",";
		        $SQL = $SQL ." predujem=".str_replace(",",".",$_POST["Predujem"]).",";
		        $SQL = $SQL ." odredbodajalec='".$_POST["Odredbodajalec"]."',";
		        $SQL = $SQL . "vpisal='".$VUporabnik."',";
		        $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
		        $SQL = $SQL . " WHERE id=".$zapis;
		        if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu popravka!<br />$SQL <br />");
                }
		        header ("Location:VnosPotniNalogi.php?id=5");
            }
            break;
	    case "8a":  //vpis popravka za netajnike (učitelje)
		    if (!CheckDostop("drugo5",$VUporabnik) ){ 
                header ("Location: nepooblascen.htm");
            }else{
		        
                $SQL = "UPDATE TabPotniNalog SET ";
                if (isset($_POST["DanOdhoda"])){
                    $astr=explode(".",$_POST["DanOdhoda"]);
                    $DanOdhoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $DanOdhoda=new DateTime($Danes->format('Y-m-d'));
                }
                if (isset($_POST["DanPrihoda"])){
                    $astr=explode(".",$_POST["DanPrihoda"]);
                    $DanPrihoda = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $DanPrihoda=new DateTime($Danes->format('Y-m-d'));
                }
                if (isset($_POST["UraOdhoda"])){
                    $UraOdhoda=$_POST["UraOdhoda"];
                }else{
                    $UraOdhoda="";
                }
                if (isset($_POST["MinOdhoda"])){
                    $MinOdhoda=$_POST["MinOdhoda"];
                }else{
                    $MinOdhoda="";
                }
                if (isset($_POST["Datum"])){
                    $astr=explode(".",$_POST["Datum"]);
                    $Datum = new DateTime($astr[2]."-".$astr[1]."-".$astr[0]);
                }else{
                    $Datum=new DateTime($Danes->format('Y-m-d'));
                }
                $SQL = $SQL ." DanOdhoda='".$DanOdhoda->format('Y-m-d')."',";
                $SQL = $SQL ." DanPrihoda='".$DanPrihoda->format('Y-m-d')."',";
                $SQL = $SQL ." Datum='".$Datum->format('Y-m-d')."',";
                $SQL = $SQL ." UraOdhoda='".$UraOdhoda.":".$MinOdhoda.":00',";
                $SQL = $SQL ." ZapSt=".$_POST["ZapSt"].",";
                $SQL = $SQL ." idUcitelj=".$_POST["delavec"].",";
                $SQL = $SQL ." odlocba='".$_POST["Odlocba"]."',";
                $SQL = $SQL ." kam='".$_POST["Kam"]."',";
                $SQL = $SQL ." naloga='".$_POST["Naloga"]."',";
                $SQL = $SQL ." dni='".$_POST["Dni"]."',";
                $SQL = $SQL ." prevSredstvo='".$_POST["PrevSredstvo"]."',";
                $SQL = $SQL ." placnik='".$_POST["Placnik"]."',";
                $SQL = $SQL ." dnevnica=".str_replace(",",".",$_POST["Dnevnica"]).",";
                $SQL = $SQL ." dodatki=".str_replace(",",".",$_POST["Dodatki"]).",";
                $SQL = $SQL ." predujem=".str_replace(",",".",$_POST["Predujem"]).",";
                $SQL = $SQL ." odredbodajalec='".$_POST["Odredbodajalec"]."',";
                $SQL = $SQL . "vpisal='".$VUporabnik."',";
                $SQL = $SQL . "cas='".$Danes->format('Y-m-d H:i:s')."'";
                $SQL = $SQL . " WHERE id=".$zapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu popravka!<br />$SQL <br />");
                }
		        header ("Location: VnosPotniNalogi.php?id=9");
            }
            break;
	    case "9":  //spisek mojih potnih nalogov
		    echo "<form name='obracun' method='post' action='VnosPotniNalogi.php'>";
		    if (isset($_POST["letoPN"])){
			    $letoPN=$_POST["letoPN"];
		    }else{
			    $letoPN=$Danes->format('Y');
		    }
            echo "Izberi leto: <select name='letoPN'>";
            if ($letoPN == $Danes->format('Y')){
                echo "<option selected>".$Danes->format('Y')."</option>";
                echo "<option>".($Danes->format('Y')-1)."</option>";
            }else{
                echo "<option>".$Danes->format('Y')."</option>";
                echo "<option selected>".($Danes->format('Y')-1)."</option>";
            }
		    echo "</select>";
		    echo "<input name='id' type='hidden' value='9'>";
		    echo "<input name='submit' type='submit' value='Izberi'><br />";
		    echo "</form>";
		    
		    echo "<h2>Spisek potnih nalogov za leto ".$letoPN."</h2>";
		    
		    $SQL = "SELECT TabPotniNalog.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
		    $SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		    //'$SQL = $SQL & "INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo "
		    $SQL = $SQL ."WHERE leto=".$letoPN." AND uporabnik='".$VUporabnik."'";
		    $SQL = $SQL . " ORDER BY ZapSt DESC";
		    $result = mysqli_query($link,$SQL);
		    
		    echo "<form name='obracunPDF' method='post' action='PotniNalogiPDF.php'>";
		    echo "<br><table border='1'>";
		    echo "<tr><th>Št.</th><th>Datum</th><th>Zap.št</th><th>Ime</th><th>Kam</th><th>Naloga</th><th>Znesek</th><th>Popravi</th><th>Obračun</th><th>Izpis</th></tr>";
		    $Indx=1;
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td align=center>".$Indx."</td>";
                $Datum=new DateTime($R["Datum"]);
			    echo "<td>".$Datum->format('d.m.Y')."</td>";
			    echo "<td align=center>".$R["ZapSt"]."</td>";
			    echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			    echo "<td>".$R["Kam"]."</td>";
			    echo "<td>".$R["Naloga"]."</td>";
			    echo "<td align=right>".number_format($R["OdobrenoIzpl"],2)." EUR</td>";
			    echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=7a'>Popravi</a></td>";
			    if (isset($R["OdobrenoIzpl"]) ){
                    echo "<td><a href='VnosPotniNalogi.php?zapis=".$R["id"]."&id=3'>Vnesi</a></td>";
			    }else{
                    echo "<td>&nbsp;</td>";
			    }
			    echo "<td><input name='pn".$Indx."' type='checkbox'><input name='idpn".$Indx."' type='hidden' value='".$R["id"]."'></td>";
			    echo "</tr>";
			    $Indx=$Indx+1;
		    }
		    echo "</table><br />";
		    echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
		    echo "<input name='submit' type='submit' value='Tvori PDF'><br />";
		    echo "</form>";
    }

    if (CheckDostop("Tajn",$VUporabnik) ){
    //'if VLevel > 1 ){
	    echo "<a href='VnosPotniNalogi.php?id=5'>Na spisek potnih nalogov</a><br />";
	    echo "<a href='VnosPotniNalogi.php?id=9'>Spisek mojih potnih nalogov</a>";
    }else{
	    echo "<a href='VnosPotniNalogi.php?id=9'>Spisek mojih potnih nalogov</a>";
    }
    //echo "<br /><a href='prijava.php'>Nazaj na glavni meni</a><br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>


</body>
</html>
