<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

function ToNivo($x){
	switch ($x){
		case 0:
			return "Samostojen predmet";
		case 1:
			return "1. skupina";
		case 2:
			return "2. skupina";
		case 3:
			return "3. skupina";
		case 4:
			return "Izbirni";
		case 5:
			return "Podaljšano bivanje";
		case 6:
			return "Druge dejavnosti";
		case 7:
			return "4. skupina";
		case 8:
			return "5. skupina";
		case 9:
			return "6. skupina";
		default:
			return "Samostojen predmet";
	}
}

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Izpis učitelja
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br />";

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
	            $ucitelj = $_SESSION["idUcitelj"];
            }else{
	            $ucitelj = 0;
            }
        }
    }

    if (($UciteljComp != $ucitelj ) && ($VLevel < 2)) {
	    if (!CheckDostop("DelKontr",$VUporabnik)) { 
            header("Location: nepooblascen.htm");
	    }else{
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
            echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br />";
        }
    }else{
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
        if (CheckDostop("DelKontr",$VUporabnik)) { 
            //echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br />";
            
            echo "<br /><form accept-charset='utf-8' name='ucitelji' method=post action='IzpisUcitelja.php'>";
            echo "<select name='idUcitelj' onchange='this.form.submit()'>";
            $SQL = "SELECT iducitelj,priimek,ime,status FROM tabucitelji WHERE status > 0 ORDER BY priimek, ime ";
            echo "<option value='0'>Ni izbran</option>";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["status"]==0 ) {
                    if ($ucitelj==$R["iducitelj"]) {
                        echo "<option value='" . $R["iducitelj"] . "' selected='selected'>(".$R["iducitelj"].") " . $R["priimek"] . ", " . $R["ime"] . " (*) </option>";
                    }else{
                        echo "<option value='" . $R["iducitelj"] . "'>(".$R["iducitelj"].") " . $R["priimek"] . ", " . $R["ime"] . " (*) </option>";
                    }
                }else{
                    if ($ucitelj==$R["iducitelj"]) {
                        echo "<option value='" . $R["iducitelj"] . "' selected='selected'>(".$R["iducitelj"].") " . $R["priimek"] . ", " . $R["ime"] . "</option>";
                    }else{
                        echo "<option value='" . $R["iducitelj"] . "'>(".$R["iducitelj"].") " . $R["priimek"] . ", " . $R["ime"] . "</option>";
                    }
                }
            }
            echo "</select>";
            //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
            echo "</form>";
            
        }

        $SQL = "SELECT DISTINCT TabDoprinos.aktivno FROM TabDoprinos WHERE aktivno > 0";
        $result = mysqli_query($link,$SQL);
        $DodatnihRubrik=mysqli_num_rows($result);

        if ($ucitelj > 0){
            $oUcitelj = new RUcitelj;
            $oUcitelj->PreberiSe($ucitelj,$VLetoPregled,$VLeto);

            $SQL = "SELECT * FROM TabDoprinos";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
	            $OznakaDneva[$R["aktivno"]]=$R["OblikaDelaOznaka"];
            }

            echo "Leto: ".$VLeto."/".($VLeto+1)."<br />";
            echo "<a href='#letnipregled'>Skok na letni pregled dela</a><br />";
            $_SESSION["leto"]=$VLeto;
            $_SESSION["solskoleto"]=$VLeto;
            $_SESSION["letopregled"]=$VLetoPregled;

            $PomladniDel=0;
            $JesenskiDel=0;

            $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLetoPregled." ORDER BY datum";
            $Indx=1;
            $ProstiDnevi=0;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
	            $Praznik[$Indx][0]=new DateTime($R["datum"]);
	            $Praznik[$Indx][1]=$R["kat"];
            //'		echo "Praznik "&Praznik(Indx,0)&" "&Praznik(Indx,1)&"<br />"
	            if ($Praznik[$Indx][1]==1 ) {
		            $ProstiDnevi=$ProstiDnevi+1;
		            if ($Praznik[$Indx][0]->format('m') < 9){
			            $PomladniDel=$PomladniDel+1;
                    }else{
			            $JesenskiDel=$JesenskiDel+1;
		            }
	            }
	            $Indx=$Indx+1;
            }
            $StPraznikov=$Indx-1;

            if (isset($_POST["id1"])){
                $id1=$_POST["id1"];
            }else{
                if (isset($_GET["id1"])){
                    $id1=$_GET["id1"];
                }else{
                    $id1="";
                }
            }
            switch ($id1){
	            case "1":	//'vnos podatkov
		            echo "<h2>Vnos podatkov o doprinosu: ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()."</h2>";
		            //$oUcitelj->PodatkiZaposlenega();

                    if (isset($_POST["id"])){
		                $id=$_POST["id"];
                    }else{
                        if (isset($_GET["id"])){
                            $id=$_GET["id"];
                        }else{
                            $id="";
                        }
                    }
		            if ($id != "" ) {
			            $SQL = "SELECT * FROM tabpregleddelan WHERE id=".$id;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
				            $VLetoPregled=$R["Leto"];
				            $VMesec=$R["Mesec"];
				            $VDan=$R["Dan"];
				            $VRubrika=$R["Rubrika"];
				            $VMKomentar=$R["Komentar"];
				            $Vcas=$R["Enot"];
				            $VEnotPotrjeno=$R["EnotPotrjeno"];
			            }else{
                            if (isset($_POST["mesec"])){
				                $VMesec=$_POST["mesec"];
                            }else{
				                $VMesec=$ActualMonth;
                            }
                            if (isset($_POST["dan"])){
				                $VDan=$_POST["dan"];
                            }else{
				                $VDan=$Danes->format('d');
                            }
                            if (isset($_POST["rubrika"])){
				                $VRubrika=$_POST["rubrika"];
                            }else{
				                $VRubrika=9;
                            }
                            if (isset($_POST["MKomentar"])){
				                $VMKomentar=$_POST["MKomentar"];
                            }else{
                                $VMKomentar="";
                            }
                            $Vcas="";
				            $VEnotPotrjeno=false;
			            }
		            }else{
                        if (isset($_POST["mesec"])){
                            $VMesec=$_POST["mesec"];
                        }else{
                            if (isset($_GET["mesec"])){
                                $VMesec=$_GET["mesec"];
                            }else{
                                $VMesec=$ActualMonth;
                            }
                        }
                        if (isset($_POST["dan"])){
                            $VDan=$_POST["dan"];
                        }else{
                            if (isset($_GET["dan"])){
                                $VDan=$_GET["dan"];
                            }else{
                                $VDan=$Danes->format('d');
                            }
                        }
                        if (isset($_POST["rubrika"])){
                            $VRubrika=$_POST["rubrika"];
                        }else{
                            $VRubrika=9;
                        }
                        if (isset($_POST["MKomentar"])){
                            $VMKomentar=$_POST["MKomentar"];
                        }else{
                            $VMKomentar="";
                        }
                        $Vcas="";
                        $VEnotPotrjeno=false;
		            }
                    $elementov=0;
                    $SQL = "SELECT * FROM TabDoprinos ORDER BY sortiranje DESC";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $elementov=$R["sortiranje"];
                    }

		            switch ( $VLevel){
			            case 2:
				            $SQL = "SELECT * FROM TabDoprinos ORDER BY sortiranje ";
                            break;
                        case 3:
                            $SQL = "SELECT * FROM TabDoprinos ORDER BY sortiranje ";
                            break;
			            default:
				            $SQL = "SELECT * FROM TabDoprinos WHERE aktivno < 2 ORDER BY sortiranje ";
		            }
                    $StAktRubrik=0;
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
			            $AktivnaRubrika[$R["sortiranje"]][0]=$R["idDoprinos"];
			            $AktivnaRubrika[$R["sortiranje"]][1]=$R["OblikaDelaKratko"];
			            $AktivnaRubrika[$R["sortiranje"]][2]=$R["OblikaDela"];
			            $AktivnaRubrika[$R["sortiranje"]][3]=$R["aktivno"];
			            $AktivnaRubrika[$R["sortiranje"]][4]=$R["uramin"];
			            $AktivnaRubrika[$R["sortiranje"]][5]=$R["koeficient"];
			            $AktivnaRubrika[$R["sortiranje"]][6]=$R["addsub"];
			            $AktivnaRubrika[$R["sortiranje"]][7]=$R["spremenljivka"];
			            if ($AktivnaRubrika[$R["sortiranje"]][0]==$VRubrika ) {
				            $VSRubrika=$AktivnaRubrika[$R["sortiranje"]][2];
			            }
                        $StAktRubrik=$StAktRubrik+1;
		            }

		            if (($VLevel < 2) && $VEnotPotrjeno) {
			            echo "<h2>Potrjenih podatkov ne morete popravljati!</h2>";
		            }else{
			            echo "<br /><form accept-charset='utf-8' name='PregledDela' onsubmit='return preveri(this)' method='post' action='vpisPDN.php'>";

			            echo "<table border='1'>";
			            echo "<tr><td>Datum</td><td>";
			            /*
                        echo " Dan: <select name='dan'>";
			            echo "<option selected='selected'>".$VDan."</option>";
			            for ($Indx=1;$Indx <= 31;$Indx++){
				            echo "<option>".$Indx."</option>";
			            }
			            echo "</select>";
			            echo " Mesec: <select name='mesec'><option selected='selected'>". $VMesec ."</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option></select>";
			            echo "Leto: <select name='leto'><option selected='selected'>". $VLetoPregled ."</option><option>". ($VLetoPregled-1) ."</option><option>". ($VLetoPregled+1) ."</option></select>";
                        */
                        $DatumOd=new DateTime($VLetoPregled."-".$VMesec."-".$VDan);
                        echo "<input name='datod' type='text' size='10' value='".$DatumOd->format('d.m.Y')."' id='dat01'>";
			            echo "</td></tr>";
			            echo "<tr><td>Rubrika</td><td>";
			            echo "<select name='rubrika'>";
			            echo "<option value='".$VRubrika."' selected='selected'>".$VSRubrika."</option>";
			            //for ($Indx=1;$Indx <= $StAktRubrik;$Indx++){
                        for ($Indx=1;$Indx <= $elementov;$Indx++){
                            if (isset($AktivnaRubrika[$Indx][3])){
				                if ($AktivnaRubrika[$Indx][3] > 0 ) {
					                if ($AktivnaRubrika[$Indx][4] > 1 ) {
						                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (min)</option>";
					                }else{
						                switch ( $AktivnaRubrika[$Indx][5]){
							                case 0:
								                if ($AktivnaRubrika[$Indx][3]==19 ) {
									                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (%)</option>";
								                }else{
									                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (dni)</option>";
								                }
                                                break;
                                            case 4:
                                                if ($AktivnaRubrika[$Indx][3]==19 ) {
                                                    echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (%)</option>";
                                                }else{
                                                    echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (dni)</option>";
                                                }
                                                break;
                                            case 8:
                                                if ($AktivnaRubrika[$Indx][3]==19 ) {
                                                    echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (%)</option>";
                                                }else{
                                                    echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (dni)</option>";
                                                }
                                                break;
							                default:
								                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (ur)</option>";
						                }
					                }
				                }
                            }
			            }
                        echo "</select></td>";
			            echo "</tr>";
			            if ($VLevel < 2 ) {
				            echo "<tr><td>Enot (ur/min/dni/%):</td><td><input name='cas' type='text' size='5' value='". $Vcas ."'> Enot ne pišite (so privzete iz rubrike). Lahko pišete z decimalkami (npr. 2,33).</td></tr>";
			            }else{
				            echo "<tr><td>Enot (ur/min/dni/%):</td><td><input name='cas' type='text' size='5' value='". $Vcas ."'>";
				            /*
                            echo " do Dan: <select name='danK'>";
				            echo "<option selected='selected'>1</option>";
				            for ($Indx=1; $Indx <= 31;$Indx++){
					            echo "<option>".$Indx."</option>";
				            }
				            echo "</select>";
				            echo " Mesec: <select name='mesecK'><option selected='selected'>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option></select>";
				            echo "Leto: <select name='letoK'><option selected='selected'>". ($VLetoPregled-1) ."</option><option>". $VLetoPregled ."</option><option>". ($VLetoPregled+1) ."</option></select><br />";
                            */
                            $DatumDo=new DateTime(($VLetoPregled-1)."-1-1");
                            echo " do datuma: <input name='datdo' type='text' size='10' value='".$DatumDo->format('d.m.Y')."' id='dat02'>";
                            echo "<br />";
				            echo "Za vnos <b>dnevnih</b> rubrik <b>do datuma</b> vpišite za število enot - in izberite ustrezen datum.<br />";
				            echo "Za vnos <b>urnih in minutnih</b> rubrik <b>do datuma</b> mora biti končni datum večji od začetnega.";
				            echo "</td></tr>";
			            }
			            echo "<tr>";
			            echo "<td>Moj komentar <br />(čim krajši - do 50 znakov)</td>";
			            echo "<td><textarea name='MKomentar' cols='65' rows='3'>". $VMKomentar ."</textarea><input type='hidden' name='id' value='". $id ."'></td>";
			            echo "</tr>";
			            if ($VLevel > 1 ) {
				            if ($VEnotPotrjeno ) {
					            echo "<tr><td><input name='EnotPotrjeno' type='checkbox' checked='checked'> Potrjen vnos</td></tr>";
				            }else{
					            echo "<tr><td><input name='EnotPotrjeno' type='checkbox'> Potrjen vnos</td></tr>";
				            }
			            }
			            echo "</table>";

                        echo "<input name='idUcitelj' type='hidden' value='".$ucitelj."'>";
                        if (isset($_GET["odkod"])){
                            echo "<input name='odkod' type='hidden' value='1'>";
                        }
			            echo "<input name='submit' type='submit' value='Pošlji'>";
			            echo "</form><br />";
		            }

		            for ($VLeto=$ActualYear;$VLeto <= ($ActualYear-1);$VLeto--){
			            $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto;
			            $Indx=1;
			            $ProstiDnevi=0;
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
				            $Praznik[$Indx][0]=new DateTime($R["Datum"]);
				            $Praznik[$Indx][1]=$R["kat"];
		            //'		echo "Praznik "&Praznik(Indx,0)&" "&Praznik(Indx,1)&"<br />"
				            if ($Praznik[$Indx][1]==1 ) {
					            $ProstiDnevi=$ProstiDnevi+1;
				            }
				            $Indx=$Indx+1;
			            }
			            $StPraznikov=$Indx-1;

                        if (($VLeto) % 4 == 0 ) {
                            $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                        }else{
                            $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                        }

			            echo "<h2>Koledar za leto ".$VLeto."</h2>";
			            echo "<table border=1>";
			            echo "<tr><th></th>";
			            for ($Indx=1;$Indx <= 31;$Indx++){
				            echo "<th>".$Indx."</th>";
			            }
			            echo "</tr>";
			            for ($Indx=1;$Indx <= 12;$Indx++){
				            echo "<tr><td>".$Indx."</td>";
				            for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
					            $Datum=new DateTime($VLeto."-".$Indx."-".Indx1);
                                
					            switch ($Datum->format('w')+1){
						            case 1: //,7
							            echo "<td bgcolor='lightsalmon'>&nbsp;</td>";
                                        break;
                                    case 7:
                                        echo "<td bgcolor='lightsalmon'>&nbsp;</td>";
                                        break;
						            default:
			            //'				echo datum&" "&CheckPraznik(datum)&"<br />"
							            switch (CheckPraznik($Datum)){
								            case 0:
									            echo "<td>&nbsp;</td>";
                                                break;
								            case 1:
									            echo "<td bgcolor='lightgreen'>&nbsp;</td>";
                                                break;
								            case 2:
									            echo "<td bgcolor='lightblue'>&nbsp;</td>";
							            }
					            }
				            }
				            echo "</tr>";
			            }
			            echo "</table><br />";
		            }
                    break;
	            default:	//'izpis podatkov
		            if ($RazsirjenVnos && ($VLevel > 1) ) {
			            echo "<h2><a href='PodatkiODelavcu.php?id=".$ucitelj."'>Pregled za zaposlenega:</a></h2>";
		            }else{
			            echo "<h2>Pregled za zaposlenega:</h2>";
		            }

		            //'Prikaz z objekti - namesto PodatkiUcitelja.inc in DeloUcitelj.inc
		            $oUcitelj->PodatkiZaposlenega();
		            $oUcitelj->Sistemizacija($VLeto);
			            
		            $_SESSION["Ucitelj"] = $ucitelj;
		            $_SESSION["UciteljPredmet"]=$ucitelj;

		            echo "<a href='Predmeti.php'>Dodaj predmete</a><br />";

		            $oUcitelj->IzpisIzobrazevanj($VLeto);
		            $oUcitelj->IzpisUrnikaUcitelja($VLeto);
		            $oUcitelj->KomentarRavnatelja();

		            echo "<h2><a href='IzpisUcitelja.php?id1=1&idUcitelj=".$ucitelj."&letopregled=".$VLetoPregled."&leto=".$VLeto."'>Vnos pregleda dela</a></h2><br />";
		            if ($VLeto < 2008 ) { 
			            $NacinObracunaDoprinosa=0;
		            }else{
			            $NacinObracunaDoprinosa=1;
		            }


		            echo "<a name='letnipregled'> </a>";
		            $oUcitelj->IzracunPrisotnosti($VLetoPregled);
		            $oUcitelj->IzpisKoledarjaPrisotnosti($VLetoPregled);
		            echo "<a href='IzpisUcitelja.php?idUcitelj=".$ucitelj."&letopregled=".($VLetoPregled-1)."&leto=".$VLeto."'>Prejšnje leto</a> <a href='IzpisUcitelja.php?idUcitelj=".$ucitelj."&letopregled=".($VLetoPregled+1)."&leto=".$VLeto."'>Naslednje leto</a><br /><br />";
		            //echo "<a href='PregledDelaNPDF1.php?iducitelj=".$ucitelj."&leto=".$VLetoPregled."' target='_blank'>Pregled dela v PDF</a><br />";
		            //echo "<a href='PregledDelaNPDF1.php?iducitelj=".$ucitelj."&leto=".($VLetoPregled-1)."' target='_blank'>Pregled dela v PDF (preteklo leto)</a><br />";

		            echo "<a name='vnos'> </a><h2><a href='IzpisUcitelja.php?id1=1&idUcitelj=".$ucitelj."&letopregled=".$VLetoPregled."&leto=".$VLeto."'>Vnos pregleda dela</a></h2><br />";

		            $oUcitelj->LetniPregledUr($VLetoPregled);
                    if (isset($_POST["vse"])){
                        $_SESSION["vse"]=$_POST["vse"];
		                $oUcitelj->Rubrike($VLetoPregled,$VLeto,$_SESSION["vse"]);
                    }else{
                        if (isset($_GET["vse"])){
                            $_SESSION["vse"]=$_GET["vse"];
                            $oUcitelj->Rubrike($VLetoPregled,$VLeto,$_SESSION["vse"]);
                        }else{
                            if (!isset($_SESSION["vse"])){
                                $_SESSION["vse"]="0";
                            }
                            $oUcitelj->Rubrike($VLetoPregled,$VLeto,$_SESSION["vse"]);
                        }
                    }
                        
		            //'Konec novega prikaza
            } 

            $_SESSION["Ucitelj"]=$ucitelj;
        }else{
            echo "Ta delavec ne obstaja!<br />";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>
<br />
<a href="prijava.php">Nazaj na glavni meni</a><br />
<a href="pravilnik.htm">Pravilnik</a><br />
<script type="text/JavaScript">
	function jeStevilo(niz){
		if (niz.length == 0) {
			return false 
		}
		var i=0
		while (i < niz.length){
			if ('0123456789.,-'.indexOf(niz.charAt(i)) == -1) {
				return false
			}
			i++
		}
		return true
	}
	
	function preveri(element) {
		if (!jeStevilo(element['cas'].value)){
			alert('Vnesite čas brez enot')
			return false
		}
		if (element['MKomentar'].value == '') {
			alert('Niste vnesli komentarja')
			return false
		}
		return true
	}
</script>

</body>
</html>
