<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="Author" content=" AL ELEKTRONIK Aleš Drinovec s.p., Naklo">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj2.css"> 
<title>Video pomoč</title>
</head>
<body>
<ul>
<li><a href='http://www.youtube.com/watch?v=9b75pCp-krg'>Prijava v Kadre</a></li>
<li><a href='http://www.youtube.com/watch?v=qlX1rcq1RZk'>Menjava gesla</a></li>
<li><a href='http://www.youtube.com/watch?v=bookaCCMVsE'>Vnos doprinosa</a></li>
<li><a href='http://www.youtube.com/watch?v=o6IUDdbo7Lg'>Vnos zapisnika</a></li>
<li><a href='http://www.youtube.com/watch?v=9KqcQpkTs2s'>Redovalnica</a></li>
<li><a href='http://www.youtube.com/watch?v=-Z0ZVfxe77Y'>Nastavitev tiskanja</a></li>
<li><a href='http://www.youtube.com/watch?v=nL_--fj9VNs'>Vnos opisnih ocen</a></li>
<li><a href='http://www.youtube.com/watch?v=d7mV7g-_wzE'>Popravljanje podatkov o učencih</a></li>
<li><a href='http://www.youtube.com/watch?v=AQwffFNJRsQ'>Seznami učencev</a></li>
<li><a href='http://www.youtube.com/watch?v=pRCJY6FwTMc'>Vnos tekmovanja v znanju</a></li>
<li><a href='http://www.youtube.com/watch?v=HV90SmM_45o'>Vnos interesne dejavnosti</a></li>
<li><a href='http://www.youtube.com/watch?v=tRRpqeBiGd8'>Vnos dnevov dejavnosti</a></li>
<li><a href='http://www.youtube.com/watch?v=PNCxEOX653Q'>Vnos tabora/šole v naravi</a></li>
<li><a href='http://www.youtube.com/watch?v=1gUYsVjNiVI'>Naknadna registracija časa prihoda/odhoda delavca</a></li>
<li><a href=''></a></li>
</ul>
Tajništvo/Administracija:<br />
<ul>
<li><a href='http://www.youtube.com/watch?v=3RYiblKcI1c'>Ponovna zaposlitev delavca</a></li>
<li><a href='http://www.youtube.com/watch?v=7PKyBWiNVX0'>Sprememba tedenske obremenitve delavca</a></li>
<li><a href='http://www.youtube.com/watch?v=UQ5VCpxU5XI'>Registracija delovnega časa</a></li>
</ul>
</body>
</html>