<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prisotnost
</title>
<style type='text/css'>
.break { page-break-before: always; }
input.groovybutton
{
   font-size:8px;
   font-weight:bold;
   width:18px;
}
</style>
</head>
<body>

<?php
$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

/*
if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

function Koda2Str($x){
    switch ($x){
        case "1001":
            return "Prihod";
        case "3001":
            return "Odhod z dela";
        case "3002":
            return "Službeni izhod";
        case "3010":
            return "Malica";
        case "5002":
            return "Najava bolniške";
        case "5004":
            return "Najava plačanega dopusta";
    }
}

function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

function Menjava($Indx,$Indx1){
    global $DelavecCasi;
    
    $DelavecCasi[0][1]= $DelavecCasi[$Indx][1];
    $DelavecCasi[0][2]= $DelavecCasi[$Indx][2];
    $DelavecCasi[0][3]= $DelavecCasi[$Indx][3];
    $DelavecCasi[0][4]= $DelavecCasi[$Indx][4];
    $DelavecCasi[0][5]= $DelavecCasi[$Indx][5];
    $DelavecCasi[0][6]= $DelavecCasi[$Indx][6];
    $DelavecCasi[0][7]= $DelavecCasi[$Indx][7];
    $DelavecCasi[0][8]= $DelavecCasi[$Indx][8];
    $DelavecCasi[0][9]= $DelavecCasi[$Indx][9];
    $DelavecCasi[0][10]=$DelavecCasi[$Indx][10];
    $DelavecCasi[0][11]=$DelavecCasi[$Indx][11];
    $DelavecCasi[0][12]=$DelavecCasi[$Indx][12];
        
    $DelavecCasi[$Indx][1]=$DelavecCasi[$Indx1][1];
    $DelavecCasi[$Indx][2]=$DelavecCasi[$Indx1][2];
    $DelavecCasi[$Indx][3]=$DelavecCasi[$Indx1][3];
    $DelavecCasi[$Indx][4]=$DelavecCasi[$Indx1][4];
    $DelavecCasi[$Indx][5]=$DelavecCasi[$Indx1][5];
    $DelavecCasi[$Indx][6]=$DelavecCasi[$Indx1][6];
    $DelavecCasi[$Indx][7]=$DelavecCasi[$Indx1][7];
    $DelavecCasi[$Indx][8]=$DelavecCasi[$Indx1][8];
    $DelavecCasi[$Indx][9]=$DelavecCasi[$Indx1][9];
    $DelavecCasi[$Indx][10]=$DelavecCasi[$Indx1][10];
    $DelavecCasi[$Indx][11]=$DelavecCasi[$Indx1][11];
    $DelavecCasi[$Indx][12]=$DelavecCasi[$Indx1][12];
    
    $DelavecCasi[$Indx1][1]=$DelavecCasi[0][1];
    $DelavecCasi[$Indx1][2]=$DelavecCasi[0][2];
    $DelavecCasi[$Indx1][3]=$DelavecCasi[0][3];
    $DelavecCasi[$Indx1][4]=$DelavecCasi[0][4];
    $DelavecCasi[$Indx1][5]=$DelavecCasi[0][5];
    $DelavecCasi[$Indx1][6]=$DelavecCasi[0][6];
    $DelavecCasi[$Indx1][7]=$DelavecCasi[0][7];
    $DelavecCasi[$Indx1][8]=$DelavecCasi[0][8];
    $DelavecCasi[$Indx1][9]=$DelavecCasi[0][9];
    $DelavecCasi[$Indx1][10]=$DelavecCasi[0][10];
    $DelavecCasi[$Indx1][11]=$DelavecCasi[0][11];
    $DelavecCasi[$Indx1][12]=$DelavecCasi[0][12];
}


if (isset($_POST["leto"])){
    $VLeto=$_POST["leto"];
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        $VLeto=$Danes->format('Y');
    }
}
if (isset($_POST["mesec"])){
    $VMesec=$_POST["mesec"];
}else{
    if (isset($_GET["mesec"])){
        $VMesec=$_GET["mesec"];
    }else{
        $VMesec=$Danes->format('n');
    }
}
if ($VLevel > 1){
    if (!CheckDostop("Prisotnost",$VUporabnik)){
        $VDelavec=$Ucitelj;
    }else{
        if (isset($_POST["delavec"])){
            $VDelavec=$_POST["delavec"];
        }else{
            if (isset($_GET["delavec"])){
                $VDelavec=$_GET["delavec"];
            }else{
                $VDelavec=0;
            }
        }
    }
}else{
    $VDelavec=$Ucitelj;
}

for ($Indx=1;$Indx <= 1000;$Indx++){
    $DelavecDat[$Indx][1]="";
    $DelavecDat[$Indx][2]="";
    $DelavecDat[$Indx][3]="";
}

switch ($VMesec){
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        $MesecDni=31;
        break;
    case 4:
    case 6:
    case 9:
    case 11:
        $MesecDni=30;
        break;
    case 2:
        if ($VLeto % 4 == 0){
            $MesecDni=29;
        }else{
            $MesecDni=28;
        }
}

if ($VDelavec > 0){
    //ispis posameznega delavca
    $SQL = "SELECT priimime,stdelavca,emso FROM kadrovi WHERE stdelavca=".$VDelavec;
}else{
    //izpis vseh delavcev
    $SQL = "SELECT priimime,stdelavca,emso FROM kadrovi ORDER BY priimime";
}
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $DelavecDat[$Indx][1]=$R["priimime"];
    $DelavecDat[$Indx][2]=$R["stdelavca"];
    $DelavecDat[$Indx][3]=$R["emso"];
    $Indx=$Indx+1;
}
$StDelavcev=$Indx-1;
echo "<h2>Prisotnost delavcev - ".$VMesec."/".$VLeto."</h2>";
if (isset($_POST["izpisur"])){
    echo "<table border=1><tr><th>Ime</th><th>Prisotnost</th><th>Odsotnost</th></tr>";
}

for ($Indx=0;$Indx <= 16;$Indx++){
    $CountOdsotnost[$Indx]=0;
}
    
for ($Indx0=1;$Indx0 <= $StDelavcev;$Indx0++){
    for ($Indx=0;$Indx <= 186;$Indx++){
        $DelavecCasi[$Indx][1]=""; //    'ime
        $DelavecCasi[$Indx][2]=""; //    'stdelavca
        $DelavecCasi[$Indx][3]=""; //    'letopr
        $DelavecCasi[$Indx][4]=""; //    'danpr
        $DelavecCasi[$Indx][5]=0; //    'uraprih
        $DelavecCasi[$Indx][6]=0; //    'minprih
        $DelavecCasi[$Indx][7]=""; //    'danodh
        $DelavecCasi[$Indx][8]=0; //    'uraodh
        $DelavecCasi[$Indx][9]=0; //    'minodh
        $DelavecCasi[$Indx][10]=""; //    'vrstaprih
        $DelavecCasi[$Indx][11]=0; //    'minut
        $DelavecCasi[$Indx][12]=""; //    'sistemdat
    }
    $OdsotnostJe=false;
    for ($IndxDan=0;$IndxDan <= 32;$IndxDan++){
        $Odsotnost[$IndxDan]=0;
    }
    For ($Indx=0;$Indx <= 16;$Indx++){
        $CountOdsotnostPos[$Indx]=0;
    }

    $SQL = "SELECT odsotnoststart,odsotnostend,sifraodsotnosti FROM tabodsotnost WHERE stdelavca='".$DelavecDat[$Indx0][2]."'";
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        for ($Indx=1;$Indx <= 31;$Indx++){
            if (checkdate($VMesec,$Indx,$VLeto)){
                $DatumComp=$VLeto.LeadZero($VMesec).LeadZero($Indx);
                $DatumS=new DateTime($R["odsotnoststart"]);
                $DCompS=$DatumS->format('Ymd');
                $DatumE=new DateTime($R["odsotnostend"]);
                $DCompE=$DatumE->format('Ymd');
                if (($DatumComp >= $DCompS) && ($DatumComp <= $DCompE)){
                    $Odsotnost[$Indx]=$R["sifraodsotnosti"]+10;
                    $OdsotnostJe=true;
                }
            }
        }
    }

    for ($IndxDan=0;$IndxDan <= 32;$IndxDan++){
        if ($Odsotnost[$IndxDan] > 0 ){
            for ($IndxMin=0;$IndxMin <= 192;$IndxMin++){
                $Delavec[$IndxDan][$IndxMin]=$Odsotnost[$IndxDan];
            }
        }else{
            for ($IndxMin=0;$IndxMin <= 192;$IndxMin++){
                $Delavec[$IndxDan][$IndxMin]=0;
            }
        }
    }
    for ($IndxDan=0;$IndxDan <= 32;$IndxDan++){
        $Prisotnost[$IndxDan]=0;
        $DelaNaDan[$IndxDan][1]=0;
        $DelaNaDan[$IndxDan][2]=0;
        $DelaNaDan[$IndxDan][3]=0;
        $DelaNaDan[$IndxDan][4]=0;
    }
    
//'preberem vrednosti prihodov in odhodov iz obeh tabel    
    $SQL = "SELECT tabprihodi.letopr,tabprihodi.danpr,tabprihodi.uraprih,tabprihodi.minprih,tabprihodi.vrstaprih,tabprihodi.danodh,tabprihodi.uraodh,tabprihodi.minodh,tabprihodi.minut,tabprihodi.sistemdat";
    $SQL = $SQL . ",kadrovi.priimime,kadrovi.stdelavca FROM tabprihodi INNER JOIN kadrovi ON tabprihodi.sifra=kadrovi.stdelavca WHERE tabprihodi.sifra='".$DelavecDat[$Indx0][2]."' AND ((tabprihodi.letopr='".$VLeto."' AND tabprihodi.mesecpr='".$VMesec."') OR (tabprihodi.letodh='".$VLeto."' AND tabprihodi.mesecodh='".$VMesec."')) ORDER BY tabprihodi.sistemdat ASC,tabprihodi.minut";
    $result = mysqli_query($link,$SQL);
    $Indx=0;
    if (mysqli_num_rows($result) > 0){
         while ($R = mysqli_fetch_array($result)){
            $Indx=$Indx+1;
            $DelavecCasi[$Indx][1]=$R["priimime"]; //    'ime
            $DelavecCasi[$Indx][2]=$R["stdelavca"]; //    'stdelavca
            $DelavecCasi[$Indx][3]=$R["letopr"]; //    'letopr
            $DelavecCasi[$Indx][4]=$R["danpr"]; //    'danpr
            $DelavecCasi[$Indx][5]=$R["uraprih"]; //    'uraprih
            $DelavecCasi[$Indx][6]=$R["minprih"]; //    'minprih
            $DelavecCasi[$Indx][7]=$R["danodh"]; //    'danodh
            $DelavecCasi[$Indx][8]=$R["uraodh"]; //    'uraodh
            $DelavecCasi[$Indx][9]=$R["minodh"]; //    'minodh
            $DelavecCasi[$Indx][10]=$R["vrstaprih"]; //    'vrstaprih
            $DelavecCasi[$Indx][11]=$R["minut"]; //    'minut
            $Datum=new DateTime(isDate($R["sistemdat"]));
            $DelavecCasi[$Indx][12]=$Datum->format('Ymd'); //   'sistemdat
            //echo $DelavecCasi[$Indx][12]."<br />";
        }
    }

    $SQL = "SELECT promet1.letopr,promet1.danpr,promet1.uraprih,promet1.minprih,promet1.vrstaprih,promet1.danodh,promet1.uraodh,promet1.minodh,promet1.minut,promet1.sistemdat";
    $SQL= $SQL . ",kadrovi.priimime,kadrovi.stdelavca FROM promet1 INNER JOIN kadrovi ON promet1.sifra=kadrovi.stdelavca WHERE promet1.sifra='".$DelavecDat[$Indx0][2]."' AND ((promet1.letopr='".$VLeto."' AND promet1.mesecpr='".$VMesec."') OR (promet1.letodh='".$VLeto."' AND promet1.mesecodh='".$VMesec."')) ORDER BY promet1.sistemdat ASC,promet1.minut";
    $result = mysqli_query($link,$SQL);

    if (mysqli_num_rows($result) > 0){
        while ($R = mysqli_fetch_array($result)){
            $Indx=$Indx+1;
            //'do 186 zapisov na delavca na mesec: 1-priimime, 2-stdelavca, 3-letopr, 4-danpr, 5-uraprih, 6-minprih, 7-danodh, 8-uraodh, 9-minodh, 10-vrstaprih, 11-min,12-sistemdat
            $DelavecCasi[$Indx][1]=$R["priimime"]; //    'ime
            $DelavecCasi[$Indx][2]=$R["stdelavca"]; //    'stdelavca
            $DelavecCasi[$Indx][3]=$R["letopr"]; //    'letopr
            $DelavecCasi[$Indx][4]=$R["danpr"]; //    'danpr
            $DelavecCasi[$Indx][5]=$R["uraprih"]; //    'uraprih
            $DelavecCasi[$Indx][6]=$R["minprih"]; //    'minprih
            $DelavecCasi[$Indx][7]=$R["danodh"]; //    'danodh
            $DelavecCasi[$Indx][8]=$R["uraodh"]; //    'uraodh
            $DelavecCasi[$Indx][9]=$R["minodh"]; //    'minodh
            $DelavecCasi[$Indx][10]=$R["vrstaprih"]; //    'vrstaprih
            $DelavecCasi[$Indx][11]=$R["minut"]; //    'minut
            $Datum=new DateTime(isDate($R["sistemdat"]));
            $DelavecCasi[$Indx][12]=$Datum->format('Ymd'); //   'sistemdat
            //echo $DelavecCasi[$Indx][12]."<br />";
        }
    }
    $StDogodkov=$Indx;
//'posortiram prihode in odhode glede na minuto dogodka
    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
        for ($Indx1=($Indx+1);$Indx1 <= $StDogodkov;$Indx1++){
            if ($Indx != $Indx1 ){
                if ($DelavecCasi[$Indx][12] > $DelavecCasi[$Indx1][12] ){
                    Menjava($Indx1,$Indx);
                }else{
                    if ($DelavecCasi[$Indx][12] == $DelavecCasi[$Indx1][12] ){
                        if ($DelavecCasi[$Indx][11] > $DelavecCasi[$Indx1][11] ){
                            Menjava($Indx1,$Indx);
                        }
                    }
                }
            }
        }
    }
    
    $DanPrihoda="";
    if ($DelavecCasi[1][11] > 0 ){
        if (isset($_POST["izpisur"])){
            echo "<tr><td>".$DelavecCasi[1][1]."</td>";
        }else{
            echo "<br /><h3>".$DelavecCasi[1][1]." (".$DelavecCasi[1][2].")</h3>";
            echo "<table border=1>";
            echo "<tr bgcolor=lightcyan><th>Dan</th><th>Prihod</th><th>Odhod</th><th>Koda prih/odh</th><th>Opis kode</th><th>Prisotnost</th></tr>";
        }
        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                if (strlen($DelavecCasi[$Indx][3]) > 0){
                    $Dan=$DelavecCasi[$Indx][4];
                    $Delavec[$Dan][round(($DelavecCasi[$Indx][5]*60+$DelavecCasi[$Indx][6])/5) -60]=1;
                }else{
                    $Dan=$DelavecCasi[$Indx][7];
                    switch ( $DelavecCasi[$Indx][10]){
                        case "3001":
                            $Delavec[$Dan][round(($DelavecCasi[$Indx][8]*60+$DelavecCasi[$Indx][9])/5)-60]=10;
                            break;
                        case "3002":
                            $Delavec[$Dan][round(($DelavecCasi[$Indx][8]*60+$DelavecCasi[$Indx][9])/5)-60]=9;
                            break;
                        case "3010":
                            $Delavec[$Dan][round(($DelavecCasi[$Indx][8]*60+$DelavecCasi[$Indx][9])/5)-60]=8;
                    }
                }
                
                //'Preveri kako so bili stemplani prihodi in odhodi in jih zamenja, če so napačni - privzame, da je bil odhod za prihodom
                
                if ($DelaNaDan[$Dan][1] > 0 ){
                    if ($DelaNaDan[$Dan][2] > 0 ){
                        if ($DelaNaDan[$Dan][3] > 0 ){
                            if ($DelaNaDan[$Dan][4] > 0 ){
                                $DelaNaDan[$Dan][4]=$DelavecCasi[$Indx][11];
                            }
                        }else{
                            $DelaNaDan[$Dan][3]=$DelavecCasi[$Indx][11];
                        }
                    }else{
                        $DelaNaDan[$Dan][2]=$DelavecCasi[$Indx][11];
                    }
                }else{
                    $DelaNaDan[$Dan][1]=$DelavecCasi[$Indx][11];
                }
                
                if ($DelaNaDan[$Dan][1] > $DelaNaDan[$Dan][2] ){
                    $DelaNaDan[$Dan][0]=$DelaNaDan[$Dan][2];
                    $DelaNaDan[$Dan][2]=$DelaNaDan[$Dan][1];
                    $DelaNaDan[$Dan][1]=$DelaNaDan[$Dan][0];
                    $DelaNaDan[$Dan][0]=0;
                }
                if ($DelaNaDan[$Dan][3] > $DelaNaDan[$Dan][4] ){
                    $DelaNaDan[$Dan][0]=$DelaNaDan[$Dan][4];
                    $DelaNaDan[$Dan][4]=$DelaNaDan[$Dan][3];
                    $DelaNaDan[$Dan][3]=$DelaNaDan[$Dan][0];
                    $DelaNaDan[$Dan][0]=0;
                }
        }
        
//        'Če je le en čas, ga vzame kot prihod in šteje tisti dan 8 ur
        
        for ($Indx=1;$Indx <= 31;$Indx++){
            if (($DelaNaDan[$Indx][2] > 0) && ($DelaNaDan[$Indx][1] == 0) ){
                if ($DelaNaDan[$Indx][2] > 480 ){
                    $DelaNaDan[$Indx][1]=$DelaNaDan[$Indx][2]-480;
                }else{
                    $DelaNaDan[$Indx][1]=$DelaNaDan[$Indx][2];
                    $DelaNaDan[$Indx][2]=$DelaNaDan[$Indx][1]+480;
                }
            }
            if (($DelaNaDan[$Indx][2] == 0) && ($DelaNaDan[$Indx][1] > 0) ){
                $DelaNaDan[$Indx][2]=$DelaNaDan[$Indx][1]+480;
            }
           // 'če ni četrtega časa, privzame, da je za 8 ur večji od prvega.
            if (($DelaNaDan[$Indx][4] == 0) && ($DelaNaDan[$Indx][3] > 0) ){
                $DelaNaDan[$Indx][4]=$DelaNaDan[$Indx][1]+480;
                
                //'če je četrti čas manjši od tretjega, ga nastavi za 15 minut večjega
                if ($DelaNaDan[$Indx][3] > $DelaNaDan[$Indx][4] ){
                    $DelaNaDan[$Indx][4]=$DelaNaDan[$Indx][3]+15;
                }
            }
           // 'če je tretji čas 0, mu nastavi vrednost drugega časa.
            if (($DelaNaDan[$Indx][3] == 0) && ($DelaNaDan[$Indx][4] > 0) ){
                $DelaNaDan[$Indx][3]=$DelaNaDan[$Indx][2];
            }
        }
        if (!isset($_POST["izpisur"])){
            $ColorChange=true;
            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                if (strlen($DelavecCasi[$Indx][4]) > 0){
                    $StrMin=$DelavecCasi[$Indx][6];
                    if (strlen($StrMin) < 2 ){
                        $StrMin="0".$StrMin;
                    }
                    if ($DanPrihoda != $DelavecCasi[$Indx][4] ){ 
                        $ColorChange=!$ColorChange;
                    }
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td align=right>".$DelavecCasi[$Indx][4]."</td><td align=right>".$DelavecCasi[$Indx][5].":".$StrMin."</td><td>&nbsp</td><td align=center>".$DelavecCasi[$Indx][10]."</td><td>".Koda2Str($DelavecCasi[$Indx][10])."</td>";
                        if ($DanPrihoda != $DelavecCasi[$Indx][4] ){ 
                            echo "<td align=right>".($DelaNaDan[$DelavecCasi[$Indx][4]][2]-$DelaNaDan[$DelavecCasi[$Indx][4]][1]+$DelaNaDan[$DelavecCasi[$Indx][4]][4]-$DelaNaDan[$DelavecCasi[$Indx][4]][3])." min</td>";
                        }
                        echo "</tr>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td align=right>".$DelavecCasi[$Indx][4]."</td><td align=right>".$DelavecCasi[$Indx][5].":".$StrMin."</td><td>&nbsp</td><td align=center>".$DelavecCasi[$Indx][10]."</td><td>".Koda2Str($DelavecCasi[$Indx][10])."</td>";
                        if ($DanPrihoda != $DelavecCasi[$Indx][4] ){ 
                            echo "<td align=right>".($DelaNaDan[$DelavecCasi[$Indx][4]][2]-$DelaNaDan[$DelavecCasi[$Indx][4]][1]+$DelaNaDan[$DelavecCasi[$Indx][4]][4]-$DelaNaDan[$DelavecCasi[$Indx][4]][3])." min</td>";
                        }
                        echo "</tr>";
                    }
                    $DanPrihoda=$DelavecCasi[$Indx][4];
                }else{
                    $StrMin=$DelavecCasi[$Indx][9];
                    if (strlen($StrMin) < 2 ){
                        $StrMin="0".$StrMin;
                    }
                    if ($DanPrihoda != $DelavecCasi[$Indx][7] ){ 
                        $ColorChange=!$ColorChange;
                    }
                    if ($ColorChange ){
                        echo "<tr bgcolor=lightyellow><td align=right>".$DelavecCasi[$Indx][7]."</td><td>&nbsp;</td><td align=right>".$DelavecCasi[$Indx][8].":".$StrMin."</td><td align=center>".$DelavecCasi[$Indx][10]."</td><td>".Koda2Str($DelavecCasi[$Indx][10])."</td>";
                        if ($DanPrihoda != $DelavecCasi[$Indx][7] ){ 
                            echo "<td align=right>".($DelaNaDan[$DelavecCasi[$Indx][7]][2]-$DelaNaDan[$DelavecCasi[$Indx][7]][1]+$DelaNaDan[$DelavecCasi[$Indx][7]][4]-$DelaNaDan[$DelavecCasi[$Indx][7]][3])." min</td>";
                        }
                        echo "</tr>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC><td align=right>".$DelavecCasi[$Indx][7]."</td><td>&nbsp;</td><td align=right>".$DelavecCasi[$Indx][8].":".$StrMin."</td><td align=center>".$DelavecCasi[$Indx][10]."</td><td>".Koda2Str($DelavecCasi[$Indx][10])."</td>";
                        if ($DanPrihoda != $DelavecCasi[$Indx][7] ){ 
                            echo "<td align=right>".($DelaNaDan[$DelavecCasi[$Indx][7]][2]-$DelaNaDan[$DelavecCasi[$Indx][7]][1]+$DelaNaDan[$DelavecCasi[$Indx][7]][4]-$DelaNaDan[$DelavecCasi[$Indx][7]][3])." min</td>";
                        }
                        echo "</tr>";
                    }
                    $DanPrihoda=$DelavecCasi[$Indx][7];
                }
            }
        }
        
        $DeloSum=0;
        for ($Indx=1;$Indx <= 31;$Indx++){
            $DeloSum=$DeloSum+$DelaNaDan[$Indx][2]-$DelaNaDan[$Indx][1]+$DelaNaDan[$Indx][4]-$DelaNaDan[$Indx][3];
        }
        if (!isset($_POST["izpisur"])){
            echo "<tr bgcolor=lightgrey><td></td><td></td><td></td><td></td><td></td><td align=right>".$DeloSum." min</td></tr>";
            echo "<tr bgcolor=lightgrey><td></td><td></td><td></td><td></td><td></td><td align=right>".intval($DeloSum/60)." ur ".($DeloSum % 60)." min</td></tr>";
            echo "</table><br /><br />";
            for ($IndxDan=1;$IndxDan <= $MesecDni;$IndxDan++){
                for ($IndxMin=1;$IndxMin <= 192;$IndxMin++){
                    if ($Delavec[$IndxDan][$IndxMin]==1 ){
                        $Prisotnost[$IndxDan]=1;
                        $Delavec[$IndxDan][0]=1;
                    }    
                    if ($Delavec[$IndxDan][$IndxMin]==10 ){
                        $Prisotnost[$IndxDan]=0;
                        $Delavec[$IndxDan][0]=1;
                    }    
                    if ($Delavec[$IndxDan][$IndxMin]== 0 ){
                        if ($Prisotnost[$IndxDan] > 0 ){
                            $Delavec[$IndxDan][$IndxMin]=2;
                        }else{
                            $Delavec[$IndxDan][$IndxMin]=0;
                        }
                    }
                }
            }
            
            $SQL = "SELECT kadrovi.priimime,kadrovi.stdelavca,tabodsotnost.odsotnoststart,tabodsotnost.odsotnostend,tabsifraodsotnosti.odsotnost FROM (tabodsotnost INNER JOIN kadrovi ON tabodsotnost.stdelavca=kadrovi.stdelavca) INNER JOIN tabsifraodsotnosti ON tabodsotnost.sifraodsotnosti=tabsifraodsotnosti.sifra WHERE tabodsotnost.stdelavca='".$DelavecDat[$Indx0][2]."' ORDER BY tabodsotnost.odsotnoststart";
            $result = mysqli_query($link,$SQL);

            echo "Planirana odsotnost delavca:<br />";
            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Ime</th>";
            echo "<th>Začetek</th>";
            echo "<th>Konec</th>";
            echo "<th>Tip</th>";
            echo "</tr>";

            while ($R = mysqli_fetch_array($result)){
                $DatumS=new DateTime(isDate($R["odsotnoststart"]));
                $DatumE=new DateTime(isDate($R["odsotnostend"]));
                if ((($DatumS->format('n')==$VMesec) && ($DatumS->format('Y')==$VLeto)) or (($DatumE->format('n')==$VMesec) && ($DatumE->format('Y')==$VLeto))){
                    echo "<tr>";
                    echo "<td>".$R["priimime"]."</td>";
                    if (!$OdsotnostJe ){
                        $DelavecDat[1]=$R["priimime"];
                        $DelavecDat[2]=$R["stdelavca"];
                    }
                    echo "<td>".$DatumS->format('d.m.Y')."</td>";
                    echo "<td>".$DatumE->format('d.m.Y')."</td>";
                    echo "<td>".$R["odsotnost"]."</td>";
                    echo "</tr>";
                }
            }
            echo "</table><br />";
        }
        if ((strlen($DelavecDat[$Indx0][1]) > 0) or $OdsotnostJe ){
            if (!isset($_POST["izpisur"])){
                echo $DelavecDat[$Indx0][1]." (".$DelavecDat[$Indx0][2].")"."<br /><table border=0>";
                echo "<tr><td></td><td>";
                echo "<img src='5.gif'>";
                echo "<img src='6.gif'>";
                echo "<img src='7.gif'>";
                echo "<img src='8.gif'>";
                echo "<img src='9.gif'>";
                echo "<img src='10.gif'>";
                echo "<img src='11.gif'>";
                echo "<img src='12.gif'>";
                echo "<img src='13.gif'>";
                echo "<img src='14.gif'>";
                echo "<img src='15.gif'>";
                echo "<img src='16.gif'>";
                echo "<img src='17.gif'>";
                echo "<img src='18.gif'>";
                echo "<img src='19.gif'>";
                echo "<img src='20.gif'>";
                echo "</td></tr>";
                echo "<tr><td>Dan</td>";
                echo "<td>";
                for ($Indx=1;$Indx <= 192;$Indx++){
                    if ($Indx % 12 == 0 ){
                        echo "<img src='r5.gif'>";
                    }else{
                        if (($Indx > 24) && ($Indx < 120) ){
                            echo "<img src='g5.gif'>";
                        }else{
                            echo "<img src='m5.gif'>";
                        }
                    }
                }
                echo "</td></tr>";
                for ($IndxDan=1;$IndxDan <= $MesecDni;$IndxDan++){
                    echo "<tr><td align=right>".$IndxDan."</td><td>";
                    for ($IndxMin=1;$IndxMin <= 192;$IndxMin++){
                        switch ( $Delavec[$IndxDan][$IndxMin]){
                            case 1:
                                echo "<img src='g5.gif'>";
                                break;
                            case 2:
                                echo "<img src='m5.gif'>";
                                break;
                            case 8: // 'sluzbeni
                                echo "<img src='mo5.gif'>";
                                break;
                            case 9: // 'malica
                                echo "<img src='p5.gif'>";
                                break;
                            case 10:
                                echo "<img src='r5.gif'>";
                                break;
                            case 11: // ' sluzbena odsotnost - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[1]=$CountOdsotnost[1]+1;
                                    $CountOdsotnostPos[1]=$CountOdsotnostPos[1]+1;
                                }
                                break;
                            case 12: // ' bolniska odsotnost - 
                                echo "<img src='ze5_3.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[2]=$CountOdsotnost[2]+1;
                                    $CountOdsotnostPos[2]=$CountOdsotnostPos[2]+1;
                                }
                                break;
                            case 13: // ' sluzbeno potovanje - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[3]=$CountOdsotnost[3]+1;
                                    $CountOdsotnostPos[3]=$CountOdsotnostPos[3]+1;
                                }
                                break;
                            case 14: // ' izobrazevanje - 
                                echo "<img src='ze5_2.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[4]=$CountOdsotnost[4]+1;
                                    $CountOdsotnostPos[4]=$CountOdsotnostPos[4]+1;
                                }
                                break;
                            case 15: // ' redni dopust - 
                                echo "<img src='ze5_4.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[5]=$CountOdsotnost[5]+1;
                                    $CountOdsotnostPos[5]=$CountOdsotnostPos[5]+1;
                                }
                                break;
                            case 16: // ' izredni dopust - 
                                echo "<img src='ze5_4.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[6]=$CountOdsotnost[6]+1;
                                    $CountOdsotnostPos[6]=$CountOdsotnostPos[6]+1;
                                }
                                break;
                            case 17: //' neplacan dopust - 
                                echo "<img src='ze5_4.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[7]=$CountOdsotnost[7]+1;
                                    $CountOdsotnostPos[7]=$CountOdsotnostPos[7]+1;
                                }
                                break;
                            case 18: // ' Tabor - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[8]=$CountOdsotnost[8]+1;
                                    $CountOdsotnostPos[8]=$CountOdsotnostPos[8]+1;
                                }
                                break;
                            case 19: // ' spremljanje ucencev - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[9]=$CountOdsotnost[9]+1;
                                    $CountOdsotnostPos[9]=$CountOdsotnostPos[9]+1;
                                }
                                break;
                            case 20: // ' neopravicena odsotnost - 
                                echo "<img src='ze5_5.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[10]=$CountOdsotnost[10]+1;
                                    $CountOdsotnostPos[10]=$CountOdsotnostPos[10]+1;
                                }
                            case 21: // 'pozabljena kartica - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[11]=$CountOdsotnost[11]+1;
                                    $CountOdsotnostPos[11]=$CountOdsotnostPos[11]+1;
                                }
                                break;
                            case 22: // ' drugo - 
                                echo "<img src='ze5_1.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[12]=$CountOdsotnost[12]+1;
                                    $CountOdsotnostPos[12]=$CountOdsotnostPos[12]+1;
                                }
                                break;
                            case 23: // ' bolniška 4 ure - 
                                echo "<img src='ze5_3.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[13]=$CountOdsotnost[13]+1;
                                    $CountOdsotnostPos[13]=$CountOdsotnostPos[13]+1;
                                }
                                break;
                            case 24: // ' porodniški - 
                                echo "<img src='ze5_3.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[14]=$CountOdsotnost[14]+1;
                                    $CountOdsotnostPos[14]=$CountOdsotnostPos[14]+1;
                                }
                                break;
                            case 25: // ' varstvo, nega otroka - 
                                echo "<img src='ze5_3.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[15]=$CountOdsotnost[15]+1;
                                    $CountOdsotnostPos[15]=$CountOdsotnostPos[15]+1;
                                }
                                break;
                            case 26: // ' Koriščenje ur - 
                                echo "<img src='ze5_4.gif'>";
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[16]=$CountOdsotnost[16]+1;
                                    $CountOdsotnostPos[16]=$CountOdsotnostPos[16]+1;
                                }
                                break;
                            default:
                                echo "<img src='ru5.gif'>";
                        }
                    }
                    echo "</td></tr>";
                }
                echo "</table><br />";
            }else{
               for ($IndxDan=1;$IndxDan <= $MesecDni;$IndxDan++){
                    //echo "<tr><td align=right>".$IndxDan."</td><td>";
                    for ($IndxMin=1;$IndxMin <= 192;$IndxMin++){
                        switch ( $Delavec[$IndxDan][$IndxMin]){
                            case 11: // ' sluzbena odsotnost - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[1]=$CountOdsotnost[1]+1;
                                    $CountOdsotnostPos[1]=$CountOdsotnostPos[1]+1;
                                }
                                break;
                            case 12: // ' bolniska odsotnost - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[2]=$CountOdsotnost[2]+1;
                                    $CountOdsotnostPos[2]=$CountOdsotnostPos[2]+1;
                                }
                                break;
                            case 13: // ' sluzbeno potovanje - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[3]=$CountOdsotnost[3]+1;
                                    $CountOdsotnostPos[3]=$CountOdsotnostPos[3]+1;
                                }
                                break;
                            case 14: // ' izobrazevanje - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[4]=$CountOdsotnost[4]+1;
                                    $CountOdsotnostPos[4]=$CountOdsotnostPos[4]+1;
                                }
                                break;
                            case 15: // ' redni dopust - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[5]=$CountOdsotnost[5]+1;
                                    $CountOdsotnostPos[5]=$CountOdsotnostPos[5]+1;
                                }
                                break;
                            case 16: // ' izredni dopust - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[6]=$CountOdsotnost[6]+1;
                                    $CountOdsotnostPos[6]=$CountOdsotnostPos[6]+1;
                                }
                                break;
                            case 17: //' neplacan dopust - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[7]=$CountOdsotnost[7]+1;
                                    $CountOdsotnostPos[7]=$CountOdsotnostPos[7]+1;
                                }
                                break;
                            case 18: // ' Tabor - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[8]=$CountOdsotnost[8]+1;
                                    $CountOdsotnostPos[8]=$CountOdsotnostPos[8]+1;
                                }
                                break;
                            case 19: // ' spremljanje ucencev - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[9]=$CountOdsotnost[9]+1;
                                    $CountOdsotnostPos[9]=$CountOdsotnostPos[9]+1;
                                }
                                break;
                            case 20: // ' neopravicena odsotnost - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[10]=$CountOdsotnost[10]+1;
                                    $CountOdsotnostPos[10]=$CountOdsotnostPos[10]+1;
                                }
                            case 21: // 'pozabljena kartica - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[11]=$CountOdsotnost[11]+1;
                                    $CountOdsotnostPos[11]=$CountOdsotnostPos[11]+1;
                                }
                                break;
                            case 22: // ' drugo - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[12]=$CountOdsotnost[12]+1;
                                    $CountOdsotnostPos[12]=$CountOdsotnostPos[12]+1;
                                }
                                break;
                            case 23: // ' bolniška 4 ure - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[13]=$CountOdsotnost[13]+1;
                                    $CountOdsotnostPos[13]=$CountOdsotnostPos[13]+1;
                                }
                                break;
                            case 24: // ' porodniški - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[14]=$CountOdsotnost[14]+1;
                                    $CountOdsotnostPos[14]=$CountOdsotnostPos[14]+1;
                                }
                                break;
                            case 25: // ' varstvo, nega otroka - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[15]=$CountOdsotnost[15]+1;
                                    $CountOdsotnostPos[15]=$CountOdsotnostPos[15]+1;
                                }
                                break;
                            case 26: // ' Koriščenje ur - 
                                if ($IndxMin==1 ){
                                    $CountOdsotnost[16]=$CountOdsotnost[16]+1;
                                    $CountOdsotnostPos[16]=$CountOdsotnostPos[16]+1;
                                }
                                break;
                        }
                    }
                }
                $OdsotnostSum=0;
                for ($Indx=1;$Indx <= 16;$Indx++){
                    $OdsotnostSum=$OdsotnostSum+$CountOdsotnostPos[$Indx];
                }
                echo "<td align=right>".round($DeloSum/60)." ur ".($DeloSum % 60)." min</td><td align=right>".$OdsotnostSum." dni</td></tr>";
            }
        }
    }
    echo "<div class='break'></div>";
}

if (isset($_POST["izpisur"])){
    echo "</table>";
}else{
    $SQL = "SELECT odsotnost FROM tabsifraodsotnosti";
    $result = mysqli_query($link,$SQL);

    echo "<h2>Odsotnost v mesecu ".$VMesec."/".$VLeto."</h2>";
    echo "<table border=1>";
    echo "<tr><th>Tip odsotnosti</th><th>Dni</th></tr>";
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $Indx=$Indx+1;
        if ($CountOdsotnost[$Indx] > 0 ){
            echo "<tr><td>".$R["odsotnost"]."</td><td>".$CountOdsotnost[$Indx]."</td></tr>";
        }
    }
    echo "</table>";

    echo "Legenda:<br />";
    echo "<img src='g5.gif'> - Prihod<br />";
    echo "<img src='m5.gif'> - Prisotnost<br />";
    echo "<img src='mo5.gif'> - Službeni izhod<br />";
    echo "<img src='p5.gif'> - Izhod - malica<br />";
    echo "<img src='r5.gif'> - Odhod<br /><br />";
    echo "<img src='ze5_1.gif'> - službena odsotnost, službeno potovanje, tabor, spremljanje učencev, pozabljena kartica, drugo<br />";
    echo "<img src='ze5_3.gif'> - bolniška odsotnost<br />";
    echo "<img src='ze5_2.gif'> - izobraževanje<br />";
    echo "<img src='ze5_4.gif'> - redni, izredni in neplačani dopust<br />";
    echo "<img src='ze5_5.gif'> - neopravičena odsotnost<br />";
}
?>
<br />
<a href="prijava.php">Nazaj na glavni meni</a><br />

</body>
</html>
