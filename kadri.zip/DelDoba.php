<?php
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Delovna doba
</title>
</head>
<body>

<?php
if (isset($_POST["id"])){
    $id=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id=0;
    }
}        

if (isset($_POST["datumod"])){
    if (isDate($_POST["datumod"])){
        $VdatumOd=new DateTime(isDate($_POST["datumod"]));
    }else{
        $VdatumOd=new DateTime($Danes->format('Y-m-d'));
    }
}else{
   $VdatumOd=new DateTime($Danes->format('Y-m-d'));
}
if (isset($_POST["datumdo"])){
    if (isDate($_POST["datumdo"])){
        $VdatumDo=new DateTime(isDate($_POST["datumdo"]));
    }else{
        $VdatumDo=new DateTime($Danes->format('Y-m-d'));
    }
}else{
   $VdatumDo=new DateTime($Danes->format('Y-m-d'));
}
if (isset($_POST["ur"])){
    $Vur=intval($_POST["ur"]);
}else{
    $Vur=40;
}
if (isset($_POST["urpolno"])){
    $VurPolno=intval($_POST["urpolno"]);
}else{
    $VurPolno=40;
}
echo "<h2>Izračun delovne dobe</h2><br>";
echo "<form name='DelDoba' method=post action='DelDoba.php'>";
echo "<table border=0>";
echo "<tr>";
echo "<td>";
echo "Od: <input name='datumod' type='text' size='10' value='".$VdatumOd->format('j.n.Y')."'>";
echo "</td>";
echo "<td>";
echo "Do: <input name='datumdo' type='text' size='10' value='".$VdatumDo->format('j.n.Y')."'>";
echo "</td>";
echo "</tr>";
echo "<tr>";
echo "<td>";
echo "Ur na teden: <input name='ur' type='text' size='4' value='".$Vur."'>";
echo "</td>";
echo "<td>";
echo "Ur/polno: <input name='urpolno' type='text' size='4' value='".$VurPolno."'>";
echo "</td>";
echo "</tr>";
echo "</table>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form><br><br>";

switch ($id){
    case "1":
        if ($VdatumOd->format('j') > $VdatumDo->format('j')){
            if ($VdatumOd->format('n') > $VdatumDo->format('n')){
                if ($VdatumOd->format('Y') < $VdatumDo->format('Y')){
                    $Vlet=$VdatumDo->format('Y')-$VdatumOd->format('Y')-1;
                    $Vmesecev=$VdatumDo->format('n')+12-$VdatumOd->format('n')-1;
                    $Vdni=30-($VdatumOd->format('j')-1)+$VdatumDo->format('j');
                }else{
                    echo "Napačni datumi!<br />";
                }
            }else{
                $Vlet=$VdatumDo->format('Y')-$VdatumOd->format('Y');
                $Vmesecev=$VdatumDo->format('n')-$VdatumOd->format('n')-1;
                if ($VdatumOd->format('j') > 30){
                    $Vdni=30-30+1+$VdatumDo->format('j');
                }else{
                    $Vdni=30-$VdatumOd->format('j')+1+$VdatumDo->format('j');
                }
                if ($Vdni == 30){
                    $Vdni=0;
                    if ($Vmesecev < 12){
                        $Vmesecev=$Vmesecev+1;
                    }else{
                        $Vlet=$Vlet+1;
                        $Vmesecev=0;
                    }
                }
            }
        }else{
            if ($VdatumOd->format('n') > $VdatumDo->format('n')){
                if ($VdatumOd->format('Y') < $VdatumDo->format('Y')){
                    $Vlet=$VdatumDo->format('Y')-$VdatumOd->format('Y')-1;
                    $Vmesecev=$VdatumDo->format('n')+12-$VdatumOd->format('n');
                    switch ($VdatumDo->format('n')){
                        case 2:
                            switch ($VdatumDo->format('j')){
                                case 28:
                                case 29:
                                    if ($VdatumOd->format('j') > 1){
                                        $Vdni=30-($VdatumOd->format('j')-1);
                                        echo "3<br />";
                                    }else{
                                        $Vdni=0;
                                        if ($Vmesecev==12){
                                            $Vlet=$Vlet+1;
                                            $Vmesecev=0;
                                        }else{
                                            $Vmesecev=$Vmesecev+1;
                                        }
                                    }
                                break;
                                default:
                                    if ($VdatumOd->format('j') > $VdatumDo->format('j')){
                                        $Vdni=30-$VdatumOd->format('j')+1+$VdatumDo->format('j');
                                    }else{
                                        $Vdni=$VdatumDo->format('j')-$VdatumOd->format('j')+1;
                                    }
                            }
                            break;
                        default:
                            switch ($VdatumDo->format('j')){
                                case 30:
                                case 31:
                                    if ($VdatumOd->format('j') > 1){
                                        $Vdni=30-($VdatumOd->format('j')-1);
                                    }else{
                                        $Vdni=0;
                                        if ($Vmesecev=12){
                                            $Vlet=$Vlet+1;
                                            $Vmesecev=0;
                                        }else{
                                            $Vmesecev=$Vmesecev+1;
                                        }
                                    }
                                    break;
                                default:
                                    if ($VdatumOd->format('j') > $VdatumDo->format('j')){
                                        $Vdni=30-$VdatumOd->format('j')+1+$VdatumDo->format('j');
                                    }else{
                                        $Vdni=$VdatumDo->format('j')-$VdatumOd->format('j')+1;
                                    }
                            }
                    }
                }else{
                    echo "Napačni datumi!<br />";
                }
            }else{
                if ($VdatumOd->format('Y') <= $VdatumDo->format('Y')){
                    $Vlet=$VdatumDo->format('Y')-$VdatumOd->format('Y');
                    $Vmesecev=$VdatumDo->format('n')-$VdatumOd->format('n');
                    switch ($VdatumDo->format('n')){
                        case 2:
                            switch ($VdatumDo->format('j')){
                                case 28:
                                case 29:
                                    if ($VdatumOd->format('j') > 1){
                                        $Vdni=30-($VdatumOd->format('j')-1);
                                    }else{
                                        $Vdni=0;
                                        if ($Vmesecev==12){
                                            $Vlet=$Vlet+1;
                                            $Vmesecev=0;
                                        }else{
                                            $Vmesecev=$Vmesecev+1;
                                        }
                                    }
                                    break;
                                default:
                                    if ($VdatumOd->format('j') > $VdatumDo->format('j')){
                                        $Vdni=30-$VdatumOd->format('j')+1+$VdatumDo->format('j');
                                    }else{
                                        $Vdni=$VdatumDo->format('j')-$VdatumOd->format('j')+1;
                                    }
                            }
                            break;
                        default:
                            switch ($VdatumDo->format('j')){
                                case 30:
                                case 31:
                                    if ($VdatumOd->format('j') > 1){
                                        $Vdni=30-($VdatumOd->format('j')-1);
                                    }else{
                                        $Vdni=0;
                                        if ($Vmesecev==12){
                                            $Vlet=$Vlet+1;
                                            $Vmesecev=0;
                                        }else{
                                            $Vmesecev=$Vmesecev+1;
                                        }
                                    }
                                    break;
                                default:
                                    if ($VdatumOd->format('j') > $VdatumDo->format('j')){
                                        $Vdni=30-$VdatumOd->format('j')+1+$VdatumDo->format('j');
                                    }else{
                                        $Vdni=$VdatumDo->format('j')-$VdatumOd->format('j')+1;
                                    }
                            }
                    }
                }else{
                    echo "Napačni datumi!<br />";
                }
            }
        }
        if (isset($Vlet)){
            $Indx=($Vlet*12*30+$Vmesecev*30+$Vdni)*$Vur/$VurPolno;

            $VletKor=intval($Indx/30/12);
            $VmesecevKor=intval(($Indx-$VletKor*30*12)/30);
            $zac=($Indx/30-intval($Indx/30))*30;
            if (($Indx % 30-$zac > 0) && ($Indx % 30-$zac < 0.6)){
                if ($Vur != $VurPolno){    
                    $VdniKor=($Indx % 30)-1;
                }else{
                    $VdniKor=$Vdni;
                }
            }else{
                $VdniKor=$Indx % 30;
            }

            echo "<table border=1>";
            echo "<tr><th>Del. čas</th><th>Let</th><th>Mesecev</th><th>Dni</th></tr>";
            echo "<tr><td>Polni</td><td align=center>".$Vlet."</td><td align=center>".$Vmesecev."</td><td align=center>".$Vdni."</td></tr>";
            echo "<tr><td>Krajši</td><td align=center>".$VletKor."</td><td align=center>".$VmesecevKor."</td><td align=center>".$VdniKor."</td></tr>";
        }
}

?>
</body>
</html>
