<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function Faktor($x){
    switch ($x){
        case 1:
            return 4;
        case 2:
            return 4.2;
        case 3:
            return 4.4;
        case 4:
            return 4.8;
        case 5:
            return 5.2;
        case 6:
            return 5.2;
        case 7:
            return 5.8;
        case 8:
            return 6;
        case 9:
            return 6;
    }
}
function Arr2Str($a){
    $s="";
    if (count($a) > 0){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }
    return $s;
}
function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $Ucitelj=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
    if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["idd"])){
            $VSelect = $_POST["idd"];
        }else{
            if (isset($_GET["idd"])){
                $VSelect=$_GET["idd"];
            }else{
                $VSelect = 0;
            }
        }
        
        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = 0;
            }
        }

        if (isset($_POST["razred"])){
            $VRazred = $_POST["razred"];
        }else{
            if (isset($_GET["razred"])){
                $VRazred=$_GET["razred"];
            }else{
                $VRazred = 0;
            }
        }
	    switch ($VSelect){	
		    case "125":
			    switch ($Vid){
				    case "2":
				    case "3":
				    case "5":
					    break;
				    default:
					    echo "<html>";
					    echo "<head>";
					    echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
					    echo "<meta http-equiv='pragma' content='no-cache' > ";
					    echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
					    echo "<title>Vnosi in spiski";
					    echo "</title>";
					    echo "<style type='text/css'>";
					    echo ".break { page-break-before: always; }";
					    echo "input.groovybutton";
					    echo "{";
					    echo "   font-size:8px;";
					    echo "   font-weight:bold;";
					    echo "   width:18px;";
					    echo "}";
					    echo "</style>";
					    echo "</head>";
					    echo "<body>";
					    $n=$VLevel;
					    include('menu_func.inc');
					    include ('menu.inc');
			    }
            case "104":
		    case "127":
			    break;
		    case "112":
		    case "122":
			    break;
		    default:
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    $n=$VLevel;
			    include('menu_func.inc');
			    include ('menu.inc');
                
                if ($VSelect != "107"){
                    echo "<form name='rezultati1' method='post' action='vnosispiski.php'>";
                    echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    echo "<input name='vrstaos' type='hidden' value='9'>";
                    if ($VLevel < 2){
                        $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                        $SQL .= "INNER JOIN tabucenje ON tabrazdat.id=tabucenje.idrazred ";
                        $SQL .= "WHERE tabucenje.iducitelj=".$Prijavljeni." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto." AND tabrazdat.razred > 0 ";
                        $SQL .= " ORDER BY idsola,tabrazdat.razred,oznaka";
                    }else{
                        $SQL = "SELECT DISTINCT tabrazdat.*,tabsola.solakratko FROM (tabrazdat ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                        $SQL .= "WHERE leto=".$VLeto." AND razred > 0 ";
                        $SQL .= " ORDER BY idsola,razred,oznaka";
                    }
                    $result = mysqli_query($link,$SQL);

                    echo "<br />Razred: <select name='razred' onchange='this.form.submit()'>";
                    echo "<option value='0'>Ni izbran</option>";
                    $Indx=1;
                    if ($VecSol > 0){
                        while ($R = mysqli_fetch_array($result)){
                            if ($VRazred==$R["id"] ){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." ".$R["solakratko"]."</option>";
                            }
                            $Indx=$Indx+1;
                        }
                    }else{
                        while ($R = mysqli_fetch_array($result)){
                            if ($VRazred==$R["id"] ){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                            $Indx=$Indx+1;
                        }
                    }
                    echo "</select>";
                    echo "<input name='id' type='hidden' value='$Vid'>";
                    if ($VSelect == "113"){
                        echo "<input name='idd' type='hidden' value='112'>";
                    }else{
                        echo "<input name='idd' type='hidden' value='$VSelect'>";
                    }
                    
                    //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                    //echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form>";
                }
	    }
	    $_SESSION["razred"]=$VRazred;
        if (isset($_POST["stucencev"])){
            $SteviloUcencev = $_POST["stucencev"];
        }else{
            if (isset($_GET["stucencev"])){
                $SteviloUcencev=$_GET["stucencev"];
            }else{
                $SteviloUcencev = 0;
            }
        }

        switch ($VSelect){
            case "101": //vnos dod pouk
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                if ($VRazred==0){
                    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto;
                }else{
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                }
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM tabdodoblikep WHERE oznaka IN ('DOD','DOP')";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $DodPouk[$Indx][0]=$R["id"];
                    $DodPouk[$Indx][1]=$R["oznaka"];
                    $DodPouk[$Indx][2]=$R["opis"];
                    $Indx=$Indx+1;
                }
                $StDodPouk=$Indx-1;

                switch ($Vid){ 
                    case "1":
                        $Ucitelj=$_POST["ucitelj"];
                        $VPredmet=$_POST["predmet"];
                        $VPomoc=$_POST["pomoc"];
                        $VUcenec=$_POST["ucenec"];
                        $VUdelezba=$_POST["udelezba"];
                        $VUstreznost=$_POST["ustreznost"];
                        $VPredlogi=$_POST["predlogi"];
                        
                        $_SESSION["dod_ucitelj"]=$Ucitelj;
                        $_SESSION["dod_ucenec"]=$VUcenec;
                        $_SESSION["dod_predmet"]=$VPredmet;
                        $_SESSION["dod_pomoc"]=$VPomoc;
                        
                        foreach($_POST["ucenec"] as $VUcenec){ 
                            $SQL = "SELECT * FROM tabdodpouk WHERE leto=".$VLeto." AND idUcenec=".$VUcenec." AND pomoc=".$VPomoc." AND predmet=".$VPredmet." AND idUcitelj=".$Ucitelj;
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL="UPDATE tabdodpouk SET idUcenec=".$VUcenec.",pomoc=".$VPomoc.",predmet=".$VPredmet.",idUcitelj=".$Ucitelj.",udelezba='".$VUdelezba."',ustreznost='".$VUstreznost."',predlogi='".$VPredlogi."' WHERE id=".$R["id"];
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<p>Napaka pri vpisu - podatki niso popravljeni!<br />$SQL</p>";
                                }
                            }else{
                                $SQL="INSERT INTO tabdodpouk (leto,idUcenec,pomoc,predmet,idUcitelj,udelezba,ustreznost,predlogi) VALUES (".$VLeto.",".$VUcenec.",".$VPomoc.",".$VPredmet.",".$Ucitelj.",'".$VUdelezba."','".$VUstreznost."','".$VPredlogi."')";
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<p>Napaka pri vpisu - podatki niso vpisani!<br />$SQL</p>";
                                }
                                
                                if ($Opravila==1){
                                    $SQL = "SELECT tabdogodek.*,tabdeldogodek.id AS did FROM ";
                                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos učencev za ISP, DSP, DOD, DOP' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                                    $result = mysqli_query($link,$SQL);

                                    $Indx=1;
                                    while ($R = mysqli_fetch_array($result)){
                                        $VDogodki[$Indx]=$R["did"];
                                        $Indx=$Indx+1;
                                    }
                                    $StDogodkov=$Indx-1;

                                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                                
                            }
                        }
                        break;
                    case "2":
                        $SQL = "SELECT * FROM tabdodpouk WHERE id=".$_GET["popravi"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VUcenec=$R["idUcenec"];
                            $Ucitelj=$R["idUcitelj"];
                            $VPomoc=$R["pomoc"];
                            $VPredmet=$R["predmet"];
                            $VidPouk=$R["id"];
                            $VUdelezba=$R["udelezba"];
                            $VUstreznost=$R["ustreznost"];
                            $VPredlogi=$R["predlogi"];
                        }
                        
                        echo "<form name='form_PopravidodatniPouk' method=post action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='101'>";
                        echo "<table border=1 cellspacing=0>";
                        echo "<tr><th>Leto</th><th>Ime</th><th>Oblika pouka</th><th>Predmet</th><th>Učitelj</th><th>Udeležba</th><th>Ustreznost programa/izvedbe</th><th>Predlogi za sprememebe</th></tr>";
                        echo "<tr>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        
                        if ($VRazred==0){
                            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto;
                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                        }else{
                            $SQL = "SELECT  tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE tabrazdat.id=".$VRazred;
                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                        }
                        $result = mysqli_query($link,$SQL);
                        echo "<td><select name='ucenec'>";
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["iducenec"]==$VUcenec){
                                echo "<option value=".$R["iducenec"]." selected>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='pomoc'>";
                        for ($Indx=1;$Indx <= $StDodPouk;$Indx++){
                            if ($Indx==$VPomoc){
                                echo "<option value='".$DodPouk[$Indx][0]."' selected>".$DodPouk[$Indx][1]."</option>";
                            }else{
                                echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='predmet'>";
                        $SQL = "SELECT * FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["Id"]==$VPredmet){
                                echo "<option value='".$R["Id"]."' selected='selected'>".$R["Oznaka"]."</option>";
                            }else{
                                echo "<option value='".$R["Id"]."'>".$R["Oznaka"]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='ucitelj'>";
                        //$SQL = "SELECT tabucitelji.iducitelj,tabucitelji.ime,tabucitelji.priimek FROM tabucitelji WHERE status > 0 AND idVzgojnoDelo IN (1,2,5,6,7,8,13,14,17,18,19,20) ORDER BY priimek,ime";
                        $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.ime,tabucitelji.priimek FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["iducitelj"]==$Ucitelj){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }
                        echo "</select></td>";
                        /*
                        echo "<td><select name='udelezba'>";
                        echo "<option>redno obiskuje</option>";
                        echo "<option>občasno obiskuje</option>";
                        echo "<option>ne obiskuje</option>";
                        echo "</select></td>";
                        */
                        echo "<td><textarea name='udelezba' cols='30' rows='4'>".$VUdelezba."</textarea></td>";
                        echo "<td><textarea name='ustreznost' cols='30' rows='4'>".$VUstreznost."</textarea></td>";
                        echo "<td><textarea name='predlogi' cols='30' rows='4'>".$VPredlogi."</textarea></td>";

                        echo "</tr>";
                        echo "</table>";
                        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                        echo "<input name='paralelka' type='hidden' value='".$VParalelka."'>";
                        echo "<input name='id' type='hidden' value='4'>";
                        echo "<input name='idpouk' type='hidden' value='".$VidPouk."'>";
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form>";
                        break;
                    case "3":
                        $SQL = "DELETE FROM tabdodpouk WHERE id=".$_GET["brisi"];
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>";
                        }
                        break;
                    case "4":
                        $Ucitelj=$_POST["ucitelj"];
                        $VPredmet=$_POST["predmet"];
                        $VPomoc=$_POST["pomoc"];
                        $VUcenec=$_POST["ucenec"];
                        $VidPouk=$_POST["idpouk"];
                        $VUdelezba=$_POST["udelezba"];
                        $VUstreznost=$_POST["ustreznost"];
                        $VPredlogi=$_POST["predlogi"];
                        
                        $SQL="UPDATE tabdodpouk SET idUcenec=".$VUcenec.",pomoc=".$VPomoc.",predmet=".$VPredmet.",idUcitelj=".$Ucitelj.",udelezba='".$VUdelezba."',ustreznost='".$VUstreznost."',predlogi='".$VPredlogi."' WHERE id=".$VidPouk;
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<p>Napaka pri vpisu - podatki niso popravljeni!<br />$SQL</p>";
                        }
                }

                if ($Vid != 2){
                    if ($VRazred==0){
                        $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,tabpredmeti.oznaka AS poznaka,tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime,tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                        $SQL = $SQL."(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL."INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                        $SQL = $SQL."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                        $SQL = $SQL."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                        $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL."WHERE tabrazred.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (3,4) ";
                        $SQL = $SQL." ORDER BY tabrazdat.idsola,tabucenci.priimek,tabucenci.ime";
                    }else{
                        $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,tabpredmeti.oznaka AS poznaka,tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime,tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                        $SQL = $SQL."(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL."INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                        $SQL = $SQL."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                        $SQL = $SQL."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                        $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL."WHERE tabrazred.idRazred=".$VRazred." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (3,4) ";
                        $SQL = $SQL." ORDER BY tabrazdat.idsola,tabucenci.priimek,tabucenci.ime";
                    }
                    $result = mysqli_query($link,$SQL);

                    echo "<h2>Vnos DOD in DOP pouka</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<th>Leto</th><th>Ime</th><th>Oblika pouka</th><th>Predmet</th><th>Učitelj</th><th>Udeležba</th><th>Ustreznost programa/<br />izvedbe</th><th>Predlogi za<br />spremembe</th><th>Popravi</th><th>Briši</th>";

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                        if ($VecSol > 0){
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]." - ".$R["solakratko"]."</td>";
                        }else{
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]."</td>";
                        }
                        for ($i=1;$i <= $StDodPouk;$i++){
                            if ($DodPouk[$i][0] == $R["pomoc"]){
                                echo "<td>".$DodPouk[$i][1]."</td>";
                            }
                        }
                        echo "<td>".$R["poznaka"]."</td>";
                        echo "<td>".$R["upriimek"]." ".$R["uime"]."</td>";
                        if (isset($R["udelezba"])){
                            echo "<td>".$R["udelezba"]."</td>";
                        }else{
                            echo "<td>&nbsp;</td>";
                        }
                        echo "<td>".$R["ustreznost"]."</td>";
                        echo "<td>".$R["predlogi"]."</td>";
                        echo "<td><a href='vnosispiski.php?idd=101&id=2&popravi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                        echo "<td><a href='vnosispiski.php?idd=101&id=3&brisi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                        echo "</tr>";
                        $Indx = $Indx+1;
                    }
                        
                    echo "<tr><td> </td></tr>";

                    echo "<form name='form_DodatniPouk' method=post action='vnosispiski.php'>";
                    echo "<input name='idd' type='hidden' value='101'>";

                    echo "<tr>";
                    echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                    echo "<td><select name='ucenec[]' multiple size='3'>";
                    echo "<option value='0'>&nbsp;</option>";
                    
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.iducenec,tabrazdat.*,tabsola.solakratko FROM ";
                    $SQL = $SQL."((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    if ($VRazred==0){
                        $SQL = $SQL."WHERE tabrazred.leto=".$VLeto;
                    }else{
                        $SQL = $SQL."WHERE tabrazred.idrazred=".$VRazred;
                    }
                    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($VecSol > 0){
                            if (isset($_SESSION["dod_ucenec"])){
                                if ($R["iducenec"] == $_SESSION["dod_ucenec"]){
                                    echo "<option value=".$R["iducenec"]." selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }else{
                                    echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }
                        }else{
                            if (isset($_SESSION["dod_ucenec"])){
                                if ($R["iducenec"] == $_SESSION["dod_ucenec"]){
                                    echo "<option value=".$R["iducenec"]." selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }else{
                                    echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                    }
                    echo "</select><br /><small>Več učencev označite s Ctrl+klik</small></td>";

                    echo "<td><select name='pomoc'>";
                    echo "<option value='0'>&nbsp;</option>";
                    for ($Indx=1;$Indx <= $StDodPouk;$Indx++){
                        if (isset($_SESSION["dod_pomoc"])){
                            if ($DodPouk[$Indx][0] == $_SESSION["dod_pomoc"]){
                                echo "<option value='".$DodPouk[$Indx][0]."' selected='selected'>".$DodPouk[$Indx][1]."</option>";
                            }else{
                                echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                            }
                        }else{
                            echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                        }
                    }
                    echo "</select></td>";

                    echo "<td><select name='predmet'>";
                    echo "<option value='0'>&nbsp;</option>";
                    $SQL = "SELECT id,oznaka FROM tabpredmeti WHERE prioriteta IN (0) ORDER BY oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if (isset($_SESSION["dod_predmet"])){
                            if ($R["id"] == $_SESSION["dod_predmet"]){
                                echo "<option value=".$R["id"]." selected='selected'>".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value=".$R["id"].">".$R["oznaka"]."</option>";
                            }
                        }else{
                            echo "<option value=".$R["id"].">".$R["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";

                    echo "<td><select name='ucitelj'>";
                    echo "<option value='0'>&nbsp;</option>";
                    
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if (isset($_SESSION["dod_ucitelj"])){
                            if ($R["iducitelj"] == $_SESSION["dod_ucitelj"]){
                                echo "<option value=".$R["iducitelj"]." selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }else{
                            echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
                        }
                    }
                    echo "</select></td>";
                    echo "<td><textarea name='udelezba' cols='30' rows='4'></textarea></td>";
                    echo "<td><textarea name='ustreznost' cols='30' rows='4'></textarea></td>";
                    echo "<td><textarea name='predlogi' cols='30' rows='4'></textarea></td>";
                    echo "</tr>";
                    echo "</table>";
                    echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                    echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                    echo "<input name='id' type='hidden' value='1'>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form>";
                }
                echo "</body>";
                echo "</html>";
                break;
            case "101a": //vnos sp pouk
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                if ($VRazred==0){
                    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto;
                }else{
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                }
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM tabdodoblikep WHERE NOT (oznaka IN ('DOD','DOP'))";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $DodPouk[$Indx][0]=$R["id"];
                    $DodPouk[$Indx][1]=$R["oznaka"];
                    $DodPouk[$Indx][2]=$R["opis"];
                    $Indx=$Indx+1;
                }
                $StDodPouk=$Indx-1;

                switch ($Vid){ 
                    case "1":
                        $Ucitelj=$_POST["ucitelj"];
                        $VPredmet=$_POST["predmet"];
                        $VPomoc=$_POST["pomoc"];
                        $VUcenec=$_POST["ucenec"];
                        $VUdelezba=$_POST["udelezba"];
                        $VUstreznost=$_POST["ustreznost"];
                        $VPredlogi=$_POST["predlogi"];
                        
                        $_SESSION["dod_ucitelj"]=$Ucitelj;
                        $_SESSION["dod_ucenec"]=$VUcenec;
                        $_SESSION["dod_predmet"]=$VPredmet;
                        $_SESSION["dod_pomoc"]=$VPomoc;
                        
                        foreach($_POST["ucenec"] as $VUcenec){
                            $SQL = "SELECT * FROM tabdodpouk WHERE leto=".$VLeto." AND idUcenec=".$VUcenec." AND pomoc=".$VPomoc." AND predmet=".$VPredmet." AND idUcitelj=".$Ucitelj;
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL="UPDATE tabdodpouk SET idUcenec=".$VUcenec.",pomoc=".$VPomoc.",predmet=".$VPredmet.",idUcitelj=".$Ucitelj.",udelezba='".$VUdelezba."',ustreznost='".$VUstreznost."',predlogi='".$VPredlogi."' WHERE id=".$R["id"];
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<p>Napaka pri vpisu - podatki niso popravljeni!<br />$SQL</p>";
                                }
                            }else{
                                $SQL="INSERT INTO tabdodpouk (leto,idUcenec,pomoc,predmet,idUcitelj,udelezba,ustreznost,predlogi) VALUES (".$VLeto.",".$VUcenec.",".$VPomoc.",".$VPredmet.",".$Ucitelj.",'".$VUdelezba."','".$VUstreznost."','".$VPredlogi."')";
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<p>Napaka pri vpisu - podatki niso vpisani!<br />$SQL</p>";
                                }
                                
                                if ($Opravila==1){
                                    $SQL = "SELECT tabdogodek.*,tabdeldogodek.id AS did FROM ";
                                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos učencev za ISP, DSP, DOD, DOP' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                                    $result = mysqli_query($link,$SQL);

                                    $Indx=1;
                                    while ($R = mysqli_fetch_array($result)){
                                        $VDogodki[$Indx]=$R["did"];
                                        $Indx=$Indx+1;
                                    }
                                    $StDogodkov=$Indx-1;

                                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                                        $result = mysqli_query($link,$SQL);
                                    }
                                }
                                
                            }
                        }
                        break;
                    case "2":
                        $SQL = "SELECT * FROM tabdodpouk WHERE id=".$_GET["popravi"];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VUcenec=$R["idUcenec"];
                            $Ucitelj=$R["idUcitelj"];
                            $VPomoc=$R["pomoc"];
                            $VPredmet=$R["predmet"];
                            $VidPouk=$R["id"];
                            if (isset($R["udelezba"])){
                                $VUdelezba=$R["udelezba"];
                            }else{
                                $VUdelezba="";
                            }
                            $VUstreznost=$R["ustreznost"];
                            $VPredlogi=$R["predlogi"];
                        }
                        
                        echo "<form name='form_PopravidodatniPouk' method=post action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='101a'>";
                        echo "<table border=1 cellspacing=0>";
                        echo "<tr><th>Leto</th><th>Ime</th><th>Oblika pouka</th><th>Predmet</th><th>Učitelj</th><th>Udeležba</th><th>Ustreznost programa/izvedbe</th><th>Predlogi za sprememebe</th></tr>";
                        echo "<tr>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        
                        if ($VRazred==0){
                            $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto;
                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                        }else{
                            $SQL = "SELECT  tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE tabrazdat.id=".$VRazred;
                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                        }
                        $result = mysqli_query($link,$SQL);
                        echo "<td><select name='ucenec'>";
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["iducenec"]==$VUcenec){
                                echo "<option value=".$R["iducenec"]." selected>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='pomoc'>";
                        for ($Indx=1;$Indx <= $StDodPouk;$Indx++){
                            if ($Indx==$VPomoc){
                                echo "<option value='".$DodPouk[$Indx][0]."' selected>".$DodPouk[$Indx][1]."</option>";
                            }else{
                                echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='predmet'>";
                        $SQL = "SELECT * FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["Id"]==$VPredmet){
                                echo "<option value='".$R["Id"]."' selected='selected'>".$R["Oznaka"]."</option>";
                            }else{
                                echo "<option value='".$R["Id"]."'>".$R["Oznaka"]."</option>";
                            }
                        }
                        echo "</select></td>";

                        echo "<td><select name='ucitelj'>";
                        //$SQL = "SELECT tabucitelji.iducitelj,tabucitelji.ime,tabucitelji.priimek FROM tabucitelji WHERE status > 0 AND idVzgojnoDelo IN (1,2,5,6,7,8,13,14,17,18,19,20) ORDER BY priimek,ime";
                        $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.ime,tabucitelji.priimek FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["iducitelj"]==$Ucitelj){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }
                        echo "</select></td>";
                        echo "<td><textarea name='udelezba' cols='30' rows='4'>".$VUdelezba."</textarea></td>";
                        echo "<td><textarea name='ustreznost' cols='30' rows='4'>".$VUstreznost."</textarea></td>";
                        echo "<td><textarea name='predlogi' cols='30' rows='4'>".$VPredlogi."</textarea></td>";

                        echo "</tr>";
                        echo "</table>";
                        echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                        echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                        echo "<input name='paralelka' type='hidden' value='".$VParalelka."'>";
                        echo "<input name='id' type='hidden' value='4'>";
                        echo "<input name='idpouk' type='hidden' value='".$VidPouk."'>";
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form>";
                        break;
                    case "3":
                        $SQL = "DELETE FROM tabdodpouk WHERE id=".$_GET["brisi"];
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>";
                        }
                        break;
                    case "4":
                        $Ucitelj=$_POST["ucitelj"];
                        $VPredmet=$_POST["predmet"];
                        $VPomoc=$_POST["pomoc"];
                        $VUcenec=$_POST["ucenec"];
                        $VidPouk=$_POST["idpouk"];
                        $VUstreznost=$_POST["ustreznost"];
                        $VPredlogi=$_POST["predlogi"];
                        if (isset($_POST["udelezba"])){
                            $VUdelezba=$_POST["udelezba"];
                        }else{
                            $VUdelezba="";
                        }
                        
                        $SQL="UPDATE tabdodpouk SET idUcenec=".$VUcenec.",pomoc=".$VPomoc.",predmet=".$VPredmet.",idUcitelj=".$Ucitelj.",udelezba='".$VUdelezba."',ustreznost='".$VUstreznost."',predlogi='".$VPredlogi."' WHERE id=".$VidPouk;
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<p>Napaka pri vpisu - podatki niso popravljeni!<br />$SQL</p>";
                        }
                }

                if ($Vid != 2){
                    if ($VRazred==0){
                        $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,tabpredmeti.oznaka AS poznaka,tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime,tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                        $SQL = $SQL."(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL."INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                        $SQL = $SQL."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                        $SQL = $SQL."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                        $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL."WHERE tabrazred.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (1,2,5,6,7) ";
                        $SQL = $SQL." ORDER BY tabrazdat.idsola,tabucenci.priimek,tabucenci.ime";
                    }else{
                        $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,tabpredmeti.oznaka AS poznaka,tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime,tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                        $SQL = $SQL."(((((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL."INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                        $SQL = $SQL."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                        $SQL = $SQL."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                        $SQL = $SQL."INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL."WHERE tabrazred.idRazred=".$VRazred." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (1,2,5,6,7) ";
                        $SQL = $SQL." ORDER BY tabrazdat.idsola,tabucenci.priimek,tabucenci.ime";
                    }
                    $result = mysqli_query($link,$SQL);

                    echo "<h2>Vnos ISP, DSP, SP, SS, PP pouka</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<th>Leto</th><th>Ime</th><th>Oblika pouka</th><th>Predmet</th><th>Učitelj</th><th>Udeležba</th><th>Ustreznost programa/<br />izvedbe</th><th>Predlogi za<br />spremembe</th><th>Popravi</th><th>Briši</th>";

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                        if ($VecSol > 0){
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]." - ".$R["solakratko"]."</td>";
                        }else{
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]."</td>";
                        }
                        for ($i=1;$i <= $StDodPouk;$i++){
                            if ($DodPouk[$i][0] == $R["pomoc"]){
                                echo "<td>".$DodPouk[$i][1]."</td>";
                            }
                        }
                        echo "<td>".$R["poznaka"]."</td>";
                        echo "<td>".$R["upriimek"]." ".$R["uime"]."</td>";
                        if (isset($R["udelezba"])){
                            echo "<td>".$R["udelezba"]."</td>";
                        }else{
                            echo "<td>&nbsp;</td>";
                        }
                        echo "<td>".$R["ustreznost"]."</td>";
                        echo "<td>".$R["predlogi"]."</td>";
                        echo "<td><a href='vnosispiski.php?idd=101a&id=2&popravi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                        echo "<td><a href='vnosispiski.php?idd=101a&id=3&brisi=".$R["id"]."&solskoleto=".$VLeto."&razred=".$VRazred."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                        echo "</tr>";
                        $Indx = $Indx+1;
                    }
                        
                    echo "<tr><td> </td></tr>";

                    echo "<form name='form_DodatniPouk' method=post action='vnosispiski.php'>";
                    echo "<input name='idd' type='hidden' value='101a'>";

                    echo "<tr>";
                    echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                    echo "<td><select name='ucenec[]' multiple size='3'>";
                    echo "<option value='0'>&nbsp;</option>";
                    
                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.iducenec,tabrazdat.*,tabsola.solakratko FROM ";
                    $SQL = $SQL."((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    if ($VRazred==0){
                        $SQL = $SQL."WHERE tabrazred.leto=".$VLeto;
                    }else{
                        $SQL = $SQL."WHERE tabrazred.idrazred=".$VRazred;
                    }
                    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($VecSol > 0){
                            if (isset($_SESSION["dod_ucenec"])){
                                if ($R["iducenec"] == $_SESSION["dod_ucenec"]){
                                    echo "<option value=".$R["iducenec"]." selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }else{
                                    echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }
                        }else{
                            if (isset($_SESSION["dod_ucenec"])){
                                if ($R["iducenec"] == $_SESSION["dod_ucenec"]){
                                    echo "<option value=".$R["iducenec"]." selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }else{
                                    echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }
                            }else{
                                echo "<option value=".$R["iducenec"].">".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                    }
                    echo "</select><br /><small>Več učencev označite s Ctrl+klik</small></td>";

                    echo "<td><select name='pomoc'>";
                    echo "<option value='0'>&nbsp;</option>";
                    for ($Indx=1;$Indx <= $StDodPouk;$Indx++){
                        if (isset($_SESSION["dod_pomoc"])){
                            if ($DodPouk[$Indx][0] == $_SESSION["dod_pomoc"]){
                                echo "<option value='".$DodPouk[$Indx][0]."' selected='selected'>".$DodPouk[$Indx][1]."</option>";
                            }else{
                                echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                            }
                        }else{
                            echo "<option value='".$DodPouk[$Indx][0]."'>".$DodPouk[$Indx][1]."</option>";
                        }
                    }
                    echo "</select></td>";

                    echo "<td><select name='predmet'>";
                    echo "<option value='0'>&nbsp;</option>";
                    $SQL = "SELECT id,oznaka FROM tabpredmeti WHERE prioriteta IN (0) ORDER BY oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if (isset($_SESSION["dod_predmet"])){
                            if ($R["id"] == $_SESSION["dod_predmet"]){
                                echo "<option value=".$R["id"]." selected='selected'>".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value=".$R["id"].">".$R["oznaka"]."</option>";
                            }
                        }else{
                            echo "<option value=".$R["id"].">".$R["oznaka"]."</option>";
                        }
                    }
                    echo "</select></td>";

                    echo "<td><select name='ucitelj'>";
                    echo "<option value='0'>&nbsp;</option>";
                    
                    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if (isset($_SESSION["dod_ucitelj"])){
                            if ($R["iducitelj"] == $_SESSION["dod_ucitelj"]){
                                echo "<option value=".$R["iducitelj"]." selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                        }else{
                            echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
                        }
                    }
                    echo "</select></td>";
                    echo "<td><textarea name='udelezba' cols='30' rows='4'></textarea></td>";
                    echo "<td><textarea name='ustreznost' cols='30' rows='4'></textarea></td>";
                    echo "<td><textarea name='predlogi' cols='30' rows='4'></textarea></td>";
                    echo "</tr>";
                    echo "</table>";
                    echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                    echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                    echo "<input name='id' type='hidden' value='1'>";
                    echo "<input name='submit' type='submit' value='Pošlji'>";
                    echo "</form>";
                }
                echo "<br /><br />";
                echo "Legenda dodatnih pomoči:<br />";
                $SQL = "SELECT * FROM tabdodoblikep";
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    echo " - ".$R["oznaka"]." - ".$R["opis"]."<br />";
                }
                echo "</body>";
                echo "</html>";
                break;
            case "102": //spisek dod
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    echo "<h2>".$sole[$IndxSola][1]."</h2>";
                
                    $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,";
                    $SQL = $SQL . "tabdodoblikep.oznaka AS doznaka,tabdodoblikep.opis AS dopis,";
                    $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,";
                    $SQL = $SQL . "tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime";
                    $SQL = $SQL . ",tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                    $SQL = $SQL ."((((((tabrazred INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabucenci ON tabdodpouk.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabdodoblikep ON tabdodpouk.pomoc=tabdodoblikep.id) ";
                    $SQL = $SQL ."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                    $SQL = $SQL ."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    switch ($Vid){   //različno razvrščanje
                        case "1":
                           echo "<br /><a href='vnosispiski.php?idd=102'>Na spisek po učencih</a><br />";
                           $SQL = $SQL ." ORDER BY tabsola.id,tabdodoblikep.oznaka,tabpredmeti.VrstniRed,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                           break;
                        default:
                           echo "<br /><a href='vnosispiski.php?idd=102&id=1'>Na spisek po predmetih/učiteljih</a><br />";
                           $SQL = $SQL ." ORDER BY tabsola.id,tabdodoblikep.oznaka,tabucenci.priimek,tabucenci.ime,tabpredmeti.VrstniRed,tabrazdat.razred,tabrazdat.oznaka";
                    }
                    $result = mysqli_query($link,$SQL);

                    $CompPomoc="";
                    $Indx=1;
                    echo "<table>";
                    while ($R = mysqli_fetch_array($result)){
                        $VPomoc=$R["doznaka"];
                        if ($VPomoc != $CompPomoc){
                            echo "</table><br />";
                            $Indx=1;
                            echo "<h2>".$VPomoc." - ".$R["dopis"]."</h2>";
                            echo "<table border=1>";
                            echo "<tr>";
                            echo "<th>Št.</th><th>Učenec</th><th>Predmet</th><th>Učitelj</th><th>Ustreznost</th><th>Predlogi</th>";
                            echo "</tr>";
                            $CompPomoc=$VPomoc;
                        }    
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        //if ($VecSol > 0){
                        //   echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]." - ".$R["solakratko"]."</td>";
                        //}else{
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]."</td>";
                        //}
                        echo "<td>".$R["poznaka"]."</td>";
                        echo "<td>".$R["upriimek"]." ".$R["uime"]."</td>";
                        echo "<td>".$R["ustreznost"]."</td>";
                        echo "<td>".$R["predlogi"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";

                    //'jutranje varstvo
                    echo "<h2>Jutranje varstvo</h2>";
                    $SQL = "SELECT tabopbucitelji.*,tabucitelji.priimek,tabucitelji.ime FROM tabopbucitelji INNER JOIN tabucitelji ON tabopbucitelji.idUcitelj=tabucitelji.idUcitelj WHERE leto=".$VLeto." AND idPredmet=0 ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    echo "Učitelji:<br />";
                    while ($R = mysqli_fetch_array($result)){
                        echo $R["priimek"]." ".$R["ime"]."<br />";
                    }

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.*,tabsola.solakratko FROM ";
                    $SQL = $SQL ."(((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                    $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                    $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.juv=true"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL ." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    echo "<table>";
                    echo "<tr><th>Št.</th><th>Učenec</th><th>Prihod</th></tr>";
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        //if ($VecSol > 0){
                        //    echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</td>";
                        //}else{
                            echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                        //}
                        echo "<td align=right>".$R["juvcas"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }
                    echo "</table><br />";

                    for ($i1=1;$i1 <= 15;$i1++){
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.*,tabsola.solakratko FROM ";
                        $SQL = $SQL ."(((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                        $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.pb".$i1."=true AND tabrazdat.idsola=".$sole[$IndxSola][0];
                        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);
                        
                        if (mysqli_num_rows($result) > 0){
                            echo "<h2>PB".$i1."</h2>";
                            $SQL = "SELECT tabopbucitelji.*,tabucitelji.priimek,tabucitelji.ime FROM tabopbucitelji INNER JOIN tabucitelji ON tabopbucitelji.idUcitelj=tabucitelji.idUcitelj WHERE leto=".$VLeto." AND idPredmet=".$i1." ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);
                            echo "Učitelji:<br />";
                            while ($R = mysqli_fetch_array($result)){
                                echo $R["priimek"]." ".$R["ime"]."<br />";
                            }
                        }
                        
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.* FROM ";
                        $SQL = $SQL ."((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                        $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.pb".$i1."=true"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        if (mysqli_num_rows($result) > 0){
                            echo "<table>";
                            echo "<tr><th>Št.</th><th>Učenec</th><th>Odhod</th></tr>";
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].".".$R["oznaka"]."</td>";
                                echo "<td align=right>".$R["pbcas"]."</td>";
                                echo "</tr>";
                                $Indx=$Indx+1;
                            }
                            echo "</table><br />";
                        }
                    }
                }
                echo "<hr>";
                //Dopolnilni pouk
                echo "<h2>Kandidati za dopolnilni pouk na osnovi preteklih zaključnih ocen</h2>";
                $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabocene.ocenakoncna,tabpredmeti.oznaka AS poznaka FROM (((tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec) ";
                $SQL .= "INNER JOIN tabpredmeti ON tabocene.idpredmet=tabpredmeti.id ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabrazdat.leto=$VLeto AND tabocene.leto=".($VLeto-1)." AND tabpredmeti.id IN (16,11,26) AND tabocene.ocenakoncna IN ('1','2','3') AND tabrazdat.razred > 3 ";
                $SQL .= "ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                $i=1;
                echo "<table border='1'>";
                echo "<tr><th>št.</th><th>Ime</th><th>razred</th><th>predmet</th><th>ocena</th></tr>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>$i</td>";
                    $i++;
                    echo "<td>".$R["priimek"].", ".$R["ime"]."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>".$R["poznaka"]."</td>";
                    echo "<td>".$R["ocenakoncna"]."</td>";
                    echo "</tr>";
                }
                echo "</table><br />";
                
                //Dodatni pouk
                echo "<h2>Kandidati za dodatni pouk na osnovi preteklih zaključnih ocen</h2>";
                $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabocene.ocenakoncna,tabpredmeti.oznaka AS poznaka FROM (((tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec) ";
                $SQL .= "INNER JOIN tabpredmeti ON tabocene.idpredmet=tabpredmeti.id ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabrazdat.leto=$VLeto AND tabocene.leto=".($VLeto-1)." AND tabpredmeti.id IN (16,11,26,1,8,6,28,13) AND tabocene.ocenakoncna ='5' AND tabrazdat.razred > 3 ";
                $SQL .= "ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabpredmeti.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                $i=1;
                echo "<table border='1'>";
                echo "<tr><th>št.</th><th>Ime</th><th>razred</th><th>predmet</th><th>ocena</th></tr>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>$i</td>";
                    $i++;
                    echo "<td>".$R["priimek"].", ".$R["ime"]."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    echo "<td>".$R["poznaka"]."</td>";
                    echo "<td>".$R["ocenakoncna"]."</td>";
                    echo "</tr>";
                }
                echo "</table><br />";

                echo "</body>";
                echo "</html>";
                break;

            case "102a": //spisek pb in juv po skupinah
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    echo "<h2>".$sole[$IndxSola][1]."</h2>";
                    
                    //gleda rubrike juv,pb1,pb2,pb3,pb4,pb5,pb6,pb7,pb8,pb9,pb10,pb11,pb12,pb13,pb14,pb15 po razredih
                    $SQL = "SELECT tabrazdat.id,tabopb.juv,tabopb.pb1,tabopb.pb2,tabopb.pb3,tabopb.pb4,tabopb.pb4,tabopb.pb5,tabopb.pb6,tabopb.pb7";
                    $SQL .= ",tabopb.pb8,tabopb.pb9,tabopb.pb10,tabopb.pb11,tabopb.pb12,tabopb.pb13,tabopb.pb14,tabopb.pb15,tabopb.pb16,tabopb.pb17,tabopb.pb18,tabopb.pb19,tabopb.pb20 FROM (tabopb ";
                    $SQL .= "INNER JOIN tabrazred ON tabopb.iducenec=tabrazred.iducenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL .= "WHERE tabopb.leto=$VLeto AND tabrazred.leto=$VLeto AND tabrazdat.leto=$VLeto AND tabrazdat.razred < 6 AND tabrazdat.razred > 0 AND tabrazdat.idsola=$IndxSola ";
                    $SQL .= "ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["juv"]){
                            if (isset($stevec[$R["id"]][0])){
                                $stevec[$R["id"]][0] += 1;
                            }else{
                                $stevec[$R["id"]][0] = 1;
                            }
                        }
                        if ($R["pb1"]){
                            if (isset($stevec[$R["id"]][1])){
                                $stevec[$R["id"]][1] += 1;
                            }else{
                                $stevec[$R["id"]][1] = 1;
                            }
                        }
                        if ($R["pb2"]){
                            if (isset($stevec[$R["id"]][2])){
                                $stevec[$R["id"]][2] += 1;
                            }else{
                                $stevec[$R["id"]][2] = 1;
                            }
                        }
                        if ($R["pb3"]){
                            if (isset($stevec[$R["id"]][3])){
                                $stevec[$R["id"]][3] += 1;
                            }else{
                                $stevec[$R["id"]][3] = 1;
                            }
                        }
                        if ($R["pb4"]){
                            if (isset($stevec[$R["id"]][4])){
                                $stevec[$R["id"]][4] += 1;
                            }else{
                                $stevec[$R["id"]][4] = 1;
                            }
                        }
                        if ($R["pb5"]){
                            if (isset($stevec[$R["id"]][5])){
                                $stevec[$R["id"]][5] += 1;
                            }else{
                                $stevec[$R["id"]][5] = 1;
                            }
                        }
                        if ($R["pb6"]){
                            if (isset($stevec[$R["id"]][6])){
                                $stevec[$R["id"]][6] += 1;
                            }else{
                                $stevec[$R["id"]][6] = 1;
                            }
                        }
                        if ($R["pb7"]){
                            if (isset($stevec[$R["id"]][7])){
                                $stevec[$R["id"]][7] += 1;
                            }else{
                                $stevec[$R["id"]][7] = 1;
                            }
                        }
                        if ($R["pb8"]){
                            if (isset($stevec[$R["id"]][8])){
                                $stevec[$R["id"]][8] += 1;
                            }else{
                                $stevec[$R["id"]][8] = 1;
                            }
                        }
                        if ($R["pb9"]){
                            if (isset($stevec[$R["id"]][9])){
                                $stevec[$R["id"]][9] += 1;
                            }else{
                                $stevec[$R["id"]][9] = 1;
                            }
                        }
                        if ($R["pb10"]){
                            if (isset($stevec[$R["id"]][10])){
                                $stevec[$R["id"]][10] += 1;
                            }else{
                                $stevec[$R["id"]][10] = 1;
                            }
                        }
                        if ($R["pb11"]){
                            if (isset($stevec[$R["id"]][11])){
                                $stevec[$R["id"]][11] += 1;
                            }else{
                                $stevec[$R["id"]][11] = 1;
                            }
                        }
                        if ($R["pb12"]){
                            if (isset($stevec[$R["id"]][12])){
                                $stevec[$R["id"]][12] += 1;
                            }else{
                                $stevec[$R["id"]][12] = 1;
                            }
                        }
                        if ($R["pb13"]){
                            if (isset($stevec[$R["id"]][13])){
                                $stevec[$R["id"]][13] += 1;
                            }else{
                                $stevec[$R["id"]][13] = 1;
                            }
                        }
                        if ($R["pb14"]){
                            if (isset($stevec[$R["id"]][14])){
                                $stevec[$R["id"]][14] += 1;
                            }else{
                                $stevec[$R["id"]][14] = 1;
                            }
                        }
                        if ($R["pb15"]){
                            if (isset($stevec[$R["id"]][15])){
                                $stevec[$R["id"]][15] += 1;
                            }else{
                                $stevec[$R["id"]][15] = 1;
                            }
                        }
                        if ($R["pb16"]){
                            if (isset($stevec[$R["id"]][16])){
                                $stevec[$R["id"]][16] += 1;
                            }else{
                                $stevec[$R["id"]][16] = 1;
                            }
                        }
                        if ($R["pb17"]){
                            if (isset($stevec[$R["id"]][17])){
                                $stevec[$R["id"]][17] += 1;
                            }else{
                                $stevec[$R["id"]][17] = 1;
                            }
                        }
                        if ($R["pb18"]){
                            if (isset($stevec[$R["id"]][18])){
                                $stevec[$R["id"]][18] += 1;
                            }else{
                                $stevec[$R["id"]][18] = 1;
                            }
                        }
                        if ($R["pb19"]){
                            if (isset($stevec[$R["id"]][19])){
                                $stevec[$R["id"]][19] += 1;
                            }else{
                                $stevec[$R["id"]][19] = 1;
                            }
                        }
                        if ($R["pb20"]){
                            if (isset($stevec[$R["id"]][20])){
                                $stevec[$R["id"]][20] += 1;
                            }else{
                                $stevec[$R["id"]][20] = 1;
                            }
                        }
                    }
                    $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=$VLeto AND razred > 0 AND razred < 6 AND idsola=$IndxSola ORDER BY razred,oznaka";
                    $result = mysqli_query($link,$SQL);
                    echo "<table border='1'>";
                    echo "<tr><th>razred</th><th>JUV</th><th>PB1</th><th>PB2</th><th>PB3</th><th>PB4</th><th>PB5</th><th>PB6</th><th>PB7</th><th>PB8</th><th>PB9</th><th>PB10</th><th>PB11</th><th>PB12</th><th>PB13</th><th>PB14</th><th>PB15</th><th>PB16</th><th>PB17</th><th>PB18</th><th>PB19</th><th>PB20</th></tr>";
                    $vsota[0]=0;
                    $vsota[1]=0;
                    $vsota[2]=0;
                    $vsota[3]=0;
                    $vsota[4]=0;
                    $vsota[5]=0;
                    $vsota[6]=0;
                    $vsota[7]=0;
                    $vsota[8]=0;
                    $vsota[9]=0;
                    $vsota[10]=0;
                    $vsota[11]=0;
                    $vsota[12]=0;
                    $vsota[13]=0;
                    $vsota[14]=0;
                    $vsota[15]=0;
                    $vsota[16]=0;
                    $vsota[17]=0;
                    $vsota[18]=0;
                    $vsota[19]=0;
                    $vsota[20]=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                        if (isset($stevec[$R["id"]][0])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][0]."</td>";
                            $vsota[0] += $stevec[$R["id"]][0];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][1])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][1]."</td>";
                            $vsota[1] += $stevec[$R["id"]][1];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][2])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][2]."</td>";
                            $vsota[2] += $stevec[$R["id"]][2];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][3])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][3]."</td>";
                            $vsota[3] += $stevec[$R["id"]][3];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][4])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][4]."</td>";
                            $vsota[4] += $stevec[$R["id"]][4];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][5])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][5]."</td>";
                            $vsota[5] += $stevec[$R["id"]][5];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][6])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][6]."</td>";
                            $vsota[6] += $stevec[$R["id"]][6];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][7])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][7]."</td>";
                            $vsota[7] += $stevec[$R["id"]][7];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][8])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][8]."</td>";
                            $vsota[8] += $stevec[$R["id"]][8];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][9])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][9]."</td>";
                            $vsota[9] += $stevec[$R["id"]][9];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][10])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][10]."</td>";
                            $vsota[10] += $stevec[$R["id"]][10];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][11])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][11]."</td>";
                            $vsota[11] += $stevec[$R["id"]][11];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][12])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][12]."</td>";
                            $vsota[12] += $stevec[$R["id"]][12];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][13])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][13]."</td>";
                            $vsota[13] += $stevec[$R["id"]][13];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][14])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][14]."</td>";
                            $vsota[14] += $stevec[$R["id"]][14];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][15])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][15]."</td>";
                            $vsota[15] += $stevec[$R["id"]][15];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][16])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][16]."</td>";
                            $vsota[16] += $stevec[$R["id"]][16];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][17])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][17]."</td>";
                            $vsota[17] += $stevec[$R["id"]][17];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][18])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][18]."</td>";
                            $vsota[18] += $stevec[$R["id"]][18];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][19])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][19]."</td>";
                            $vsota[19] += $stevec[$R["id"]][19];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        if (isset($stevec[$R["id"]][20])){
                            echo "<td align='center' bgcolor='lightgreen'>".$stevec[$R["id"]][20]."</td>";
                            $vsota[20] += $stevec[$R["id"]][20];
                        }else{
                            echo "<td align='center'>0</td>";
                        }
                        echo "</tr>";
                    }
                    echo "<tr>";
                    echo "<td>Skupaj</td>";
                    $skupaj=0;
                    for ($i=0;$i <= 20;$i++){
                        echo "<td align='center'>".$vsota[$i]."</td>";
                        if ($i > 0){
                            $skupaj += $vsota[$i];
                        }
                    }
                    echo "</tr>";
                    echo "</table><br />Skupaj učencev: $skupaj<br />";
                }

                echo "</body>";
                echo "</html>";
                break;
            case "103": //vnos opb
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='izborrazreda.php?id=opb'>Nazaj na izbor razreda</a><br />";
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VIdSola=$R["idsola"];
                }
                if (isset($_POST["stpb"])){
                    $SteviloPB=intval($_POST["stpb"]);
                }else{
                    $SteviloPB=15;
                }
                if ($SteviloUcencev > 0){
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $ucenec=$_POST["ucenec".$Indx];
                        if ($ucenec > 0){
                            $SQL="SELECT * FROM tabopb WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabopb SET ";
                                if (isset($_POST["juv".$Indx])){
                                    $SQL=$SQL."juv=true,";
                                }else{
                                    $SQL=$SQL."juv=false,";
                                }
                                $SQL = $SQL ."juvcas='".$_POST["juvcas".$Indx]."',";
                                for ($i1=1;$i1 <= $SteviloPB;$i1++){
                                    if (isset($_POST["pb".$Indx."i".$i1])){
                                        $SQL=$SQL."pb".$i1."=true,";
                                    }else{
                                        $SQL=$SQL."pb".$i1."=false,";
                                    }
                                }
                                $SQL = $SQL ."pbcas='".$_POST["pbcas".$Indx]."',";
                                $SQL = $SQL ."idsola=".$VIdSola.",";
                                $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                            }else{
                                $SQL = "INSERT INTO tabopb (";
                                $SQL=$SQL."juv,juvcas,";
                                for ($i1=1;$i1 <= $SteviloPB;$i1++){
                                    $SQL =$SQL . "pb".$i1.",";
                                }
                                $SQL = $SQL . "pbcas,vpisal,cas,leto,idsola,idUcenec) VALUES (";
                                if (isset($_POST["juv".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                $SQL=$SQL."'".$_POST["juvcas".$Indx]."',";
                                for ($i1=1;$i1 <= $SteviloPB;$i1++){
                                    if (isset($_POST["pb".$Indx."i".$i1])){
                                        $SQL=$SQL."true,";
                                    }else{
                                        $SQL=$SQL."false,";
                                    }
                                }
                                $SQL=$SQL."'".$_POST["pbcas".$Indx]."',";
                                $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$VIdSola.",".$ucenec.")";
                            }
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<p>Napaka pri vpisu - podatki niso vpisani!<br />$SQL</p>";
                            }
                        }
                    }
                    // echo "<h2>Podatki SO vpisani!</h2>";
                    
                    if ($Opravila==1){
                        $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["iducitelj"];
                        }else{
                            $Ucitelj=0;
                        }
                        
                        $SQL = "SELECT tabdeldogodek.* FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos učencev za OPB' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                        if ($Ucitelj != $Prijavljeni){
                            $SQL = "SELECT tabdeldogodek.* FROM ";
                            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos učencev za OPB' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                            $result = mysqli_query($link,$SQL);

                            $Indx=1;
                            while ($R = mysqli_fetch_array($result)){
                                $VDogodki[$Indx]=$R["id"];
                                $Indx=$Indx+1;
                            }
                            $StDogodkov=$Indx-1;

                            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                                $result = mysqli_query($link,$SQL);
                            }
                        }

                    }
                }

                if ($Vid > 0){
                    $SQL = "DELETE FROM tabopbucitelji WHERE id=".$Vid;
                    if (!($result = mysqli_query($link,$SQL))){
                        echo "<h2>Napaka pri brisanju - podatki niso zbrisani!<br />$SQL</h2>";
                    }
                }

                if (isset($_POST["ucopb"])){
                    $SQL = "INSERT INTO tabopbucitelji (";
                    $SQL=$SQL."leto,idUcitelj,idPredmet,idsola)";
                    $SQL = $SQL . " VALUES (";
                    $SQL=$SQL.$VLeto.",";
                    $SQL=$SQL.$_POST["ucopb"].",";
                    $SQL=$SQL.$_POST["opb"].",";
                    $SQL=$SQL.$VIdSola.")";
                    if (!($result = mysqli_query($link,$SQL))){
                        echo "<p>Napaka pri vpisu - podatki niso vpisani!<br />$SQL</p>";
                    }
                }

                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.idsola,tabsola.solakratko FROM ";
                $SQL = $SQL."((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL = $SQL."WHERE tabrazred.idRazred=" . $VRazred ." AND tabrazred.leto=".$VLeto;
                $SQL = $SQL." ORDER BY tabucenci.Priimek,tabucenci.Ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VSola=$R["solakratko"];
                    $VIdSola=$R["idsola"];
                    $VUcenec[$Indx][0]=$R["iducenec"];
                    $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $VUcenec[$Indx][2]=$R["razred"].". ".$R["paralelka"];
                    $VUcenec[$Indx][3]=$R["idrazred"];
                    $VUcenec[$Indx][4]=$R["idsola"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;

                //'Izpis razrednih podatkov

                /* ugotovi število predmetov PB */
                $SQL = "SELECT * FROM tabpredmeti WHERE opis LIKE 'podaljšano bivanje%'";
                $result = mysqli_query($link,$SQL);
                $SteviloPB = mysqli_num_rows($result);
                
                echo "<h2>Jutranje varstvo in OPB ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<p>Odkljukajte učence in učenke v ustrezni skupini JUV in OPB";
                if ($VecSol > 0){
                    echo " - <b>".$VSola."</b>";
                }
                echo "<br />Čas prihoda in odhoda pišite v obliki HH:MM (npr. 6:10, 15:30, 16:00)</p>";
                echo "<form  name='UcenciOPB' method='post' action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='103'>";
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                echo "<th>JUV<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,0)'></th>";
                echo "<th>Prihod<br />na JUV</th>";
                for ($i1=1;$i1 <= $SteviloPB;$i1++){
                    echo "<th>PB".$i1."<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,".$i1.")'></th>";
                }
                echo "<th>Odhod</th>";
                echo "</tr>";

                
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $SQL = "SELECT * FROM tabopb WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$R["idUcenec"]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        if ($R["juv"]){
                            echo "<td align='center'><input id='dan_0' name='juv".$Indx."' type='checkbox' checked></td>";
                        }else{
                            echo "<td align='center'><input id='dan_0' name='juv".$Indx."' type='checkbox'></td>";
                        }
                        echo "<td><input name='juvcas".$Indx."' type='text' size='5' value='".$R["juvcas"]."'></td>";
                        for ($i1=1;$i1 <= $SteviloPB;$i1++){
                            if ($R["pb".$i1]){
                                echo "<td align='center'><input id='dan_".$i1."' name='pb".$Indx."i".$i1."' type='checkbox' checked='checked'></td>";
                            }else{
                                echo "<td align='center'><input id='dan_".$i1."' name='pb".$Indx."i".$i1."' type='checkbox'></td>";
                            }
                        }
                        echo "<td><input name='pbcas".$Indx."' type='text' size='5' value='".$R["pbcas"]."'></td>";
                        echo "</tr>";
                    }else{  //za to leto še nima zapisa
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        echo "<td align='center'><input id='dan_0' name='juv".$Indx."' type='checkbox'></td>";
                        echo "<td><input name='juvcas".$Indx."' type='text' size='5' value=''></td>";
                        for ($i1=1;$i1 <= $SteviloPB;$i1++){
                            echo "<td align='center'><input id='dan_".$i1."' name='pb".$Indx."i".$i1."' type='checkbox'></td>";
                        }
                        echo "<td><input name='pbcas".$Indx."' type='text' size='5' value=''></td>";
                        echo "</tr>"    ;
                    }
                }
                
                echo "</table>";
                echo "<input type='hidden' name='stpb' value='".$SteviloPB."'>";
                echo "<input type='hidden' name='stucencev' value='".$StUcencev."'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                echo "</form>";

                $_SESSION["razred"]=$VRazred;

                echo "<h2>Učitelji OPB</h2>";

                echo "<form  name='UciteljiOPB' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='103'>";
                echo "<table border=1>";
                echo "<tr><th>Št.</th><th>Ime</th><th>Skupina</th><th><img src='img/m_delete.gif' border='0' alt='Briši'></th><tr>";
                echo "<tr><td></td>";
                echo "<td><select name='ucopb'>";
                echo "<option value='0' selected='selected'>Ni izbran</option>";
                $SQL ="SELECT priimek,ime,iducitelj FROM tabucitelji WHERE izobrazba > 5 AND status > 0 ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                }
                echo "</select></td>";
                echo "<td><select name='opb'>";
                for ($Indx=0;$Indx <= $SteviloPB;$Indx++){
                    if ($Indx==0){
                        echo "<option value='".$Indx."'>JUV</option>";
                    }else{
                        echo "<option value='".$Indx."'>PB".$Indx."</option>";
                    }
                }
                echo "</td></select>";
                echo "<td><input name='submit' type='submit' value='Dodaj'></td></tr>";
                
                $SQL = "SELECT tabopbucitelji.*, tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj FROM ";
                $SQL = $SQL . "tabopbucitelji INNER JOIN tabucitelji ON tabopbucitelji.idUcitelj=tabucitelji.idUcitelj ";
                $SQL = $SQL . "WHERE leto=".$VLeto." AND idsola=".$VIdSola." ORDER BY idPredmet,priimek,ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                    if ($R["idPredmet"]==0){
                        echo "<td>JUV</td>";
                    }else{
                        echo "<td>PB".$R["idPredmet"]."</td>";
                    }
                    echo "<td><a href='vnosispiski.php?idd=103&id=".$R["id"]."&razred=".$VRazred."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "</form>";

                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='izborrazreda.php?id=opb'>Nazaj na izbor razreda</a><br />";

                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
                echo "</body>";
                echo "</html>";
                break;
            case "104": // opb juv pdf
                if (isset($_SESSION["DayToPrint"])){
                    $PrintDay = $_SESSION["DayToPrint"];
                }else{
                    $PrintDay = $Danes->format('j. n. Y');
                }
                $_SESSION["DayToPrint"]=$PrintDay;

                /* ugotovi število predmetov PB */
                $SQL = "SELECT * FROM tabpredmeti WHERE opis LIKE 'podaljšano bivanje%'";
                $result = mysqli_query($link,$SQL);
                $SteviloPB = mysqli_num_rows($result);

                $pdf = new FPDF();

                //$pdf->AddFont('EAN_b','','EAN_b.php');
                $pdf->AddFont('arial_CE','','arial_CE.php');
                $pdf->AddFont('arialbd_CE','','arialbd_CE.php');
                
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    $SQL = "SELECT * FROM tabsola WHERE id=".$sole[$IndxSola][0];
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $VSola=$R["Sola"];
                        $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
                        $VSolaKraj=$R["Kraj"];
                        $VRavnatelj=$R["Ravnatelj"];
                        $TipSole=$R["TipSole"];
                        $RavnateljID=$R["ravnatelj_ID"];
                    }else{
                        $VSola=" ";
                        $VRavnatelj=" ";
                        $RavnateljID=0;
                        $VSolaNaslov="";
                        $VSolaKraj="";
                        $TipSole=0;
                    }

                    $SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $SpolRavnatelj=$R["Spol"];
                    }else{
                        $SpolRavnatelj="M";
                    }
                    
                    $pdf->AddPage("P","A4");

                    //'Oblike dodatne pomoči
                    $SQL = "SELECT tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabdodpouk.*,";
                    $SQL = $SQL . "tabdodoblikep.oznaka AS doznaka,tabdodoblikep.opis AS dopis,";
                    $SQL = $SQL . "tabpredmeti.oznaka AS poznaka,";
                    $SQL = $SQL . "tabucitelji.priimek AS upriimek,tabucitelji.ime AS uime,";
                    $SQL = $SQL . "tabrazdat.razred,tabrazdat.oznaka AS roznaka FROM ";
                    $SQL = $SQL ."(((((tabrazred INNER JOIN tabdodpouk ON tabrazred.idUcenec=tabdodpouk.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabucenci ON tabdodpouk.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabdodoblikep ON tabdodpouk.pomoc=tabdodoblikep.id) ";
                    $SQL = $SQL ."INNER JOIN tabpredmeti ON tabdodpouk.predmet=tabpredmeti.id) ";
                    $SQL = $SQL ."INNER JOIN tabucitelji ON tabdodpouk.idUcitelj=tabucitelji.idUcitelj) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL ." ORDER BY tabdodoblikep.oznaka,tabpredmeti.VrstniRed,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompPomoc="";
                    $Indx=1;
                    $VStran=0;
                    $XPoz[1]=10;
                    $XPoz[2]=32;
                    $XPoz[3]=95;
                    $XPoz[4]=120;
                    $YPoz=65;
                    $YPozDiff=4.5;
                    while ($R = mysqli_fetch_array($result)){
                        $VPomoc=$R["doznaka"];
                        if (($VPomoc != $CompPomoc) or ($Indx % 36==0)){
                            if ($VStran > 0){
                                $pdf->SetFont('arial_CE','',12);
                                if ($SpolRavnatelj=="M"){
                                    $txt=ToWin("Ravnatelj:");
                                }else{
                                    $txt=ToWin("Ravnateljica:");
                                }
                                $pdf->SetXY(120,261);
                                $pdf->Cell(0,0,$txt,0,2,"C");
                                $txt=ToWin($VRavnatelj);
                                $pdf->SetXY(120,267);
                                $pdf->Cell(0,0,$txt,0,2,"C");

                                $txt=ToWin("Kraj in datum:");
                                $pdf->SetXY(15,261);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                                $txt=ToWin($VSolaKraj.", ".$PrintDay);
                                $pdf->SetXY(15,267);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                                
                                if ($VPomoc != $CompPomoc){
                                    $Indx=1;
                                }
                            }

                            if ($VStran > 0){
                                $pdf->AddPage("P","A4");
                            }
                            $VStran=$VStran+1;

                            $pdf->Image("logo1.gif",15,10,30);
                            
                            $pdf->SetFont('arialbd_CE','',16);
                            $txt=ToWin($VSola);
                            $pdf->SetXY(55,18);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin($VSolaNaslov);
                            $pdf->SetXY(55,26);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin($VPomoc." - ".$R["dopis"]);
                            $pdf->SetXY(10,45);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                            $pdf->SetXY(10,53);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            
                            $pdf->SetFont('arialbd_CE','',12);
                            $txt=ToWin("Št.");
                            $pdf->SetXY($XPoz[1],$YPoz);
                            $pdf->Cell(20,0,$txt,0,2,"R");
                            $txt=ToWin("Učenec");
                            $pdf->SetXY($XPoz[2],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin("Predmet");
                            $pdf->SetXY($XPoz[3],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin("Učitelj");
                            $pdf->SetXY($XPoz[4],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $CompPomoc=$VPomoc;
                        }    

                        $pdf->SetFont('arial_CE','',12);
                        $txt=ToWin(($Indx).". ");
                        $pdf->SetXY($XPoz[1],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(20,0,$txt,0,2,"R");
                        $txt=ToWin($R["ucpriimek"]." ".$R["ucime"].", ".$R["razred"].". ".$R["roznaka"]);
                        $pdf->SetXY($XPoz[2],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($R["poznaka"]);
                        $pdf->SetXY($XPoz[3],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($R["upriimek"]." ".$R["uime"]);
                        $pdf->SetXY($XPoz[4],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        $Indx=$Indx+1;
                    }

                    $pdf->SetFont('arial_CE','',12);
                    if ($SpolRavnatelj=="M"){
                        $txt=ToWin("Ravnatelj:");
                    }else{
                        $txt=ToWin("Ravnateljica:");
                    }
                    $pdf->SetXY(120,261);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VRavnatelj);
                    $pdf->SetXY(120,267);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Kraj in datum:");
                    $pdf->SetXY(15,261);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin($VSolaKraj.", ".$PrintDay);
                    $pdf->SetXY(15,267);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    //'Jutranje varstvo
                    $VStran=$VStran+1;
                    $pdf->AddPage("P","A4");
                    $YPoz=60;
                    
                    $SQL = "SELECT tabopbucitelji.*,tabucitelji.priimek,tabucitelji.ime FROM tabopbucitelji INNER JOIN tabucitelji ON tabopbucitelji.idUcitelj=tabucitelji.idUcitelj WHERE idPredmet=0 AND tabopbucitelji.leto=".$VLeto." AND tabopbucitelji.idsola=".$sole[$IndxSola][0]." ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    $pdf->SetFont('arial_CE','',11);
                    $txt=ToWin("Učitelji: ");
                    $pdf->SetXY($XPoz[1],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $txt=ToWin($R["priimek"]." ".$R["ime"]);
                        $pdf->SetXY($XPoz[1],$YPoz+($Indx % 36)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $Indx=$Indx+1;
                    }

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.* FROM ";
                    $SQL = $SQL ."((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                    $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.juv=true"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompPomoc="";
                    $XPoz[1]=10;
                    $XPoz[2]=32;
                    $XPoz[3]=110;
                    $XPoz[4]=120;
                    $YPoz=90;
                    $YPozDiff=4.5;

                    $pdf->Image("logo1.gif",15,15,30);

                    $pdf->SetFont('arialbd_CE','',16);
                    $txt=ToWin($VSola);
                    $pdf->SetXY(55,18);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin($VSolaNaslov);
                    $pdf->SetXY(55,26);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    $txt=ToWin("Jutranje varstvo");
                    $pdf->SetXY(10,45);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                    $pdf->SetXY(10,53);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    
                    $pdf->SetFont('arial_CE','',12);
                    $txt=ToWin("Št.");
                    $pdf->SetXY($XPoz[1],$YPoz);
                    $pdf->Cell(20,0,$txt,0,2,"R");
                    $txt=ToWin("Učenec");
                    $pdf->SetXY($XPoz[2],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin("Prihod");
                    $pdf->SetXY($XPoz[3],$YPoz);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $Indx=1;

                    while ($R = mysqli_fetch_array($result)){
                        if ($Indx % 36 == 0){
                            $VStran=$VStran+1;
                            $pdf->AddPage("P","A4");
                            $pdf->Image("logo1.gif",15,15,30);

                            $pdf->SetFont('arialbd_CE','',16);
                            $txt=ToWin($VSola);
                            $pdf->SetXY(55,18);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin($VSolaNaslov);
                            $pdf->SetXY(55,26);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin("Jutranje varstvo");
                            $pdf->SetXY(10,45);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                            $pdf->SetXY(10,53);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            
                            $pdf->SetFont('arialbd_CE','',12);
                            $txt=ToWin("Št.");
                            $pdf->SetXY($XPoz[1],$YPoz);
                            $pdf->Cell(20,0,$txt,0,2,"R");
                            $txt=ToWin("Učenec");
                            $pdf->SetXY($XPoz[2],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin("Prihod");
                            $pdf->SetXY($XPoz[3],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");

                            $pdf->SetFont('arial_CE','',12);
                            if ($SpolRavnatelj=="M"){
                                $txt=ToWin("Ravnatelj:");
                            }else{
                                $txt=ToWin("Ravnateljica:");
                            }
                            $pdf->SetXY(120,261);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            $txt=ToWin($VRavnatelj);
                            $pdf->SetXY(120,267);
                            $pdf->Cell(0,0,$txt,0,2,"C");

                            $txt=ToWin("Kraj in datum:");
                            $pdf->SetXY(15,261);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin($VSolaKraj.", ".$PrintDay);
                            $pdf->SetXY(15,267);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                        
                        $pdf->SetFont('arial_CE','',12);
                        $txt=ToWin($Indx.". ");
                        $pdf->SetXY($XPoz[1],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(20,0,$txt,0,2,"R");
                        $txt=ToWin($R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]);
                        $pdf->SetXY($XPoz[2],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        $txt=ToWin($R["juvcas"]);
                        $pdf->SetXY($XPoz[3],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                        $pdf->Cell(0,0,$txt,0,2,"L");
                        
                        $Indx=$Indx+1;
                    }

                    $pdf->SetFont('arial_CE','',12);
                    if ($SpolRavnatelj=="M"){
                        $txt=ToWin("Ravnatelj:");
                    }else{
                        $txt=ToWin("Ravnateljica:");
                    }
                    $pdf->SetXY(120,261);
                    $pdf->Cell(0,0,$txt,0,2,"C");
                    $txt=ToWin($VRavnatelj);
                    $pdf->SetXY(120,267);
                    $pdf->Cell(0,0,$txt,0,2,"C");

                    $txt=ToWin("Kraj in datum:");
                    $pdf->SetXY(15,261);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    $txt=ToWin($VSolaKraj.", ".$PrintDay);
                    $pdf->SetXY(15,267);
                    $pdf->Cell(0,0,$txt,0,2,"L");

                    $XPoz[1]=10;
                    $XPoz[2]=32;
                    $XPoz[3]=120;
                    $XPoz[4]=130;
                    $YPozDiff=4.5;

                    //'Oddelki PB
                    for ($i1=1;$i1 <= $SteviloPB;$i1++){
                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.* FROM ";
                        $SQL = $SQL ."((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                        $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.pb".$i1."=true"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $VStran=$VStran+1;
                            $pdf->AddPage("P","A4");
                            
                            $SQL = "SELECT tabopbucitelji.*,tabucitelji.priimek,tabucitelji.ime FROM tabopbucitelji ";
                            $SQL = $SQL . "INNER JOIN tabucitelji ON tabopbucitelji.idUcitelj=tabucitelji.idUcitelj ";
                            $SQL = $SQL . "WHERE idPredmet=".$i1." AND tabopbucitelji.leto=".$VLeto." AND tabopbucitelji.idsola=".$sole[$IndxSola][0]." ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);
                            $YPoz=60;
                            
                            $pdf->SetFont('arial_CE','',11);
                            $txt=ToWin("Učitelji: ");
                            $pdf->SetXY($XPoz[1],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $Indx=1;
                            while ($R = mysqli_fetch_array($result)){
                                $txt=ToWin($R["priimek"]." ".$R["ime"]);
                                $pdf->SetXY($XPoz[1],$YPoz+($Indx % 36)*$YPozDiff);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                                $Indx=$Indx+1;
                            }
                        }
                        $YPoz=90;

                        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabopb.*,tabrazdat.* FROM ";
                        $SQL = $SQL ."((tabrazred INNER JOIN tabopb ON tabrazred.idUcenec=tabopb.idUcenec) ";
                        $SQL = $SQL ."INNER JOIN tabucenci ON tabopb.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL ."WHERE tabrazdat.leto=".$VLeto." AND tabopb.leto=".$VLeto." AND tabopb.pb".$i1."=true"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                        $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            
                            $pdf->Image("logo1.gif",15,15,30);

                            $pdf->SetFont('arialbd_CE','',16);
                            $txt=ToWin($VSola);
                            $pdf->SetXY(55,18);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin($VSolaNaslov);
                            $pdf->SetXY(55,26);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            
                            $txt=ToWin("Podaljšano bivanje - PB".$i1);
                            $pdf->SetXY(10,45);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                            $pdf->SetXY(10,53);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            
                            $pdf->SetFont('arialbd_CE','',12);
                            $txt=ToWin("Št.");
                            $pdf->SetXY($XPoz[1],$YPoz);
                            $pdf->Cell(20,0,$txt,0,2,"R");
                            $txt=ToWin("Učenec");
                            $pdf->SetXY($XPoz[2],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin("Odhod");
                            $pdf->SetXY($XPoz[3],$YPoz);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $Indx=1;

                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                if ($Indx % 36 == 0){
                                    $VStran=$VStran+1;
                                    $pdf->AddPage("P","A4");
                                    $pdf->Image("logo1.gif",15,15,30);

                                    $pdf->SetFont('arialbd_CE','',16);
                                    $txt=ToWin($VSola);
                                    $pdf->SetXY(55,18);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                    $txt=ToWin($VSolaNaslov);
                                    $pdf->SetXY(55,26);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                    
                                    $txt=ToWin("Podaljšano bivanje - PB".$i1);
                                    $pdf->SetXY(10,45);
                                    $pdf->Cell(0,0,$txt,0,2,"C");
                                    $txt=ToWin("za šolsko leto ".$VLeto."/".($VLeto+1));
                                    $pdf->SetXY(10,53);
                                    $pdf->Cell(0,0,$txt,0,2,"C");
                                    
                                    $pdf->SetFont('arialbd_CE','',12);
                                    $txt=ToWin("Št.");
                                    $pdf->SetXY($XPoz[1],$YPoz);
                                    $pdf->Cell(20,0,$txt,0,2,"R");
                                    $txt=ToWin("Učenec");
                                    $pdf->SetXY($XPoz[2],$YPoz);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                    $txt=ToWin("Odhod");
                                    $pdf->SetXY($XPoz[3],$YPoz);
                                    $pdf->Cell(0,0,$txt,0,2,"L");

                                    $pdf->SetFont('arial_CE','',12);
                                    if ($SpolRavnatelj=="M"){
                                        $txt=ToWin("Ravnatelj:");
                                    }else{
                                        $txt=ToWin("Ravnateljica:");
                                    }
                                    $pdf->SetXY(120,261);
                                    $pdf->Cell(0,0,$txt,0,2,"C");
                                    $txt=ToWin($VRavnatelj);
                                    $pdf->SetXY(120,267);
                                    $pdf->Cell(0,0,$txt,0,2,"C");

                                    $txt=ToWin("Kraj in datum:");
                                    $pdf->SetXY(15,261);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                    $txt=ToWin($VSolaKraj.", ".$PrintDay);
                                    $pdf->SetXY(15,267);
                                    $pdf->Cell(0,0,$txt,0,2,"L");
                                }
                                
                                $pdf->SetFont('arial_CE','',12);
                                $txt=ToWin($Indx.". ");
                                $pdf->SetXY($XPoz[1],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                                $pdf->Cell(20,0,$txt,0,2,"R");
                                $txt=ToWin($R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]);
                                $pdf->SetXY($XPoz[2],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                                $txt=ToWin($R["pbcas"]);
                                $pdf->SetXY($XPoz[3],$YPoz+(($Indx % 36)+1)*$YPozDiff);
                                $pdf->Cell(0,0,$txt,0,2,"L");
                                
                                $Indx=$Indx+1;
                            }

                            $pdf->SetFont('arial_CE','',12);
                            if ($SpolRavnatelj=="M"){
                                $txt=ToWin("Ravnatelj:");
                            }else{
                                $txt=ToWin("Ravnateljica:");
                            }
                            $pdf->SetXY(120,261);
                            $pdf->Cell(0,0,$txt,0,2,"C");
                            $txt=ToWin($VRavnatelj);
                            $pdf->SetXY(120,267);
                            $pdf->Cell(0,0,$txt,0,2,"C");

                            $txt=ToWin("Kraj in datum:");
                            $pdf->SetXY(15,261);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                            $txt=ToWin($VSolaKraj.", ".$PrintDay);
                            $pdf->SetXY(15,267);
                            $pdf->Cell(0,0,$txt,0,2,"L");
                        }
                    }
                }    
                $pdf->Output("OddelkiPBinJUV.pdf","D");
                break;
            case "105": //vnos prehrana
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                if ($SteviloUcencev > 0){
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $ucenec=$_POST["ucenec".$Indx];
                        $VOpombe=$_POST["opombe".$Indx];
                        if ($ucenec > 0){
                            $SQL="SELECT * FROM tabprehrana WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabprehrana SET ";
                                if (isset($_POST["zajtrk".$Indx])){
                                    $SQL=$SQL."zajtrk=true,";
                                }else{
                                    $SQL=$SQL."zajtrk=false,";
                                }
                                if (isset($_POST["malica".$Indx])){
                                    $SQL=$SQL."malica=true,";
                                }else{
                                    $SQL=$SQL."malica=false,";
                                }
                                if (isset($_POST["kosilo".$Indx])){
                                    $SQL=$SQL."kosilo=true,";
                                }else{
                                    $SQL=$SQL."kosilo=false,";
                                }
                                if (isset($_POST["popmalica".$Indx])){
                                    $SQL=$SQL."popmalica=true,";
                                }else{
                                    $SQL=$SQL."popmalica=false,";
                                }
                                if (isset($_POST["regresmalica".$Indx])){
                                    $SQL=$SQL."regresmalica=true,";
                                }else{
                                    $SQL=$SQL."regresmalica=false,";
                                }
                                if (isset($_POST["regreskosilo".$Indx])){
                                    $SQL=$SQL."regreskosilo=true,";
                                }else{
                                    $SQL=$SQL."regreskosilo=false,";
                                }
                                $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."', opombe='".$VOpombe."' WHERE id=".$R["id"];
                            }else{
                                $SQL = "INSERT INTO tabprehrana (";
                                $SQL=$SQL."zajtrk,malica,kosilo,popmalica,regresmalica,regreskosilo,vpisal,cas,leto,idUcenec,opombe) VALUES (";
                                if (isset($_POST["zajtrk".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["malica".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["kosilo".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["popmalica".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["regresmalica".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["regreskosilo".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$ucenec.",'".$VOpombe."')";
                            }
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                            }
                        }
                    }
                    //echo "<h2>Podatki SO vpisani!</h2>";
                    
                    if ($Opravila==1){
                        $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["iducitelj"];
                        }else{
                            $Ucitelj=0;
                        }
                        
                        $SQL = "SELECT tabdeldogodek.* FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos prehrane učencev' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }

                if ($VRazred=="0"){
                    $SQL = "SELECT tabrazred.idrazred,tabrazred.razred,tabrazred.paralelka, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=" . $VLeto ." AND (tabrazred.razred > 0) ";
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = "SELECT tabrazred.idrazred,tabrazred.razred,tabrazred.paralelka, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.idrazred=" . $VRazred;
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                }
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcenec[$Indx][0]=$R["iducenec"];
                    $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $VUcenec[$Indx][2]=$R["razred"].". ".$R["paralelka"];
                    $VUcenec[$Indx][3]=$R["idrazred"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;

                //'Izpis razrednih podatkov
                echo "<h2>Prehrana ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<form  name='UcenciPrehrana' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='105'>";
                
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                echo "<th>Zajtrk<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></th>";
                echo "<th>Malica<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,2)'></th>";
                echo "<th>Kosilo<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,3)'></th>";
                echo "<th>Pop. malica<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,4)'></th>";
                echo "<th>Subv. malica<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,5)'></th>";
                echo "<th>Subv. kosilo<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,6)'></th>";
                echo "<th>Opombe</th>";
                echo "</tr>";

                $VZajtrkov=0;
                $VMalic=0;
                $VKosil=0;
                $VPMalic=0;
                $VSubMalic=0;
                $VSubKosil=0;

                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $SQL = "SELECT * FROM tabprehrana WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$R["idUcenec"]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        if ($R["zajtrk"]){
                            echo "<td align='center'><input id='dan_1' name='zajtrk".$Indx."' type='checkbox' checked='checked'></td>";
                            $VZajtrkov=$VZajtrkov+1;
                        }else{
                            echo "<td align='center'><input id='dan_1' name='zajtrk".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["malica"]){
                            echo "<td align='center'><input id='dan_2' name='malica".$Indx."' type='checkbox' checked></td>";
                            $VMalic=$VMalic+1;
                        }else{
                            echo "<td align='center'><input id='dan_2' name='malica".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["kosilo"]){
                            echo "<td align='center'><input id='dan_3' name='kosilo".$Indx."' type='checkbox' checked></td>";
                            $VKosil=$VKosil+1;
                        }else{
                            echo "<td align='center'><input id='dan_3' name='kosilo".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["popmalica"]){
                            echo "<td align='center'><input id='dan_4' name='popmalica".$Indx."' type='checkbox' checked></td>";
                            $VPMalic=$VPMalic+1;
                        }else{
                            echo "<td align='center'><input id='dan_4' name='popmalica".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["regresmalica"]){
                            echo "<td align='center'><input id='dan_5' name='regresmalica".$Indx."' type='checkbox' checked></td>";
                            $VSubMalic=$VSubMalic+1;
                        }else{
                            echo "<td align='center'><input id='dan_5' name='regresmalica".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["regreskosilo"]){
                            echo "<td align='center'><input id='dan_6' name='regreskosilo".$Indx."' type='checkbox' checked></td>";
                            $VSubKosil=$VSubKosil+1;
                        }else{
                            echo "<td align='center'><input id='dan_6' name='regreskosilo".$Indx."' type='checkbox'></td>";
                        }
                        echo "<td><textarea name='opombe".$Indx."' cols='20' rows='2'>".$R["opombe"]."</textarea></td>";
                        echo "</tr>";
                    }else{
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        echo "<td align='center'><input id='dan_1' name='zajtrk".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_2' name='malica".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_3' name='kosilo".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_4' name='popmalica".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_5' name='regresmalica".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_6' name='regreskosilo".$Indx."' type='checkbox'></td>";
                        echo "<td><textarea name='opombe".$Indx."' cols='20' rows='2'></textarea></td>";
                        echo "</tr>";
                    }
                }

                $SteviloUcencev=$Indx-1;
                echo "<tr>";
                echo "<th>&nbsp;</th>";
                echo "<th>Skupaj</th>";
                echo "<th>".$VZajtrkov."</th>";
                echo "<th>".$VMalic."</th>";
                echo "<th>".$VKosil."</th>";
                echo "<th>".$VPMalic."</th>";
                echo "<th>".$VSubMalic."</th>";
                echo "<th>".$VSubKosil."</th>";
                echo "<th>&nbsp;</th>";
                echo "</tr>";

                echo "</table>";
                echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                echo "</form>";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
                echo "</body>";
                echo "</html>";
                break;
            case "106": //spisek prehrana
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    echo "<h2>".$sole[$IndxSola][1]."</h2>";
                    for ($i=0;$i < 50;$i++){
                        for ($j=0;$j < 10;$j++){
                            $countT[$i][$j]=0;
                        }
                    }
                        
                    $SQL = "SELECT tabprehrana.*,tabrazdat.*,tabrazdat.id AS rid FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabprehrana ON tabrazred.idUcenec=tabprehrana.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabprehrana.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    $CompRazred="";
                    while ($R = mysqli_fetch_array($result)){
                        $VRazred=$R["razred"].". ".$R["oznaka"];
                        if ($VRazred != $CompRazred){
                            $Indx=$Indx+1;
                            $countT[$Indx][0]=$VRazred;
                            $countT[$Indx][7]=$R["razred"];
                            $countT[$Indx][8]=$R["oznaka"];
                            $countT[$Indx][9]=$R["rid"];
                            if ($R["zajtrk"]){    $countT[$Indx][1]=1;}
                            if ($R["malica"]){    $countT[$Indx][2]=1;}
                            if ($R["kosilo"]){    $countT[$Indx][3]=1;}
                            if ($R["popmalica"]){    $countT[$Indx][4]=1;}
                            if ($R["regresmalica"]){    $countT[$Indx][5]=1;}
                            if ($R["regreskosilo"]){    $countT[$Indx][6]=1;}
                            $CompRazred=$VRazred;
                        }else{
                            if ($R["zajtrk"]){    $countT[$Indx][1]=$countT[$Indx][1]+1;}
                            if ($R["malica"]){    $countT[$Indx][2]=$countT[$Indx][2]+1;}
                            if ($R["kosilo"]){    $countT[$Indx][3]=$countT[$Indx][3]+1;}
                            if ($R["popmalica"]){    $countT[$Indx][4]=$countT[$Indx][4]+1;}
                            if ($R["regresmalica"]){    $countT[$Indx][5]=$countT[$Indx][5]+1;}
                            if ($R["regreskosilo"]){    $countT[$Indx][6]=$countT[$Indx][6]+1;}
                        }
                    }
                    $StRazredov=$Indx;

                    for ($Indx=1;$Indx <= 6;$Indx++){
                        $CountSum[$Indx]=0;
                    }

                    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                        $CountSum[1]=$CountSum[1]+$countT[$Indx][1];
                        $CountSum[2]=$CountSum[2]+$countT[$Indx][2];
                        $CountSum[3]=$CountSum[3]+$countT[$Indx][3];
                        $CountSum[4]=$CountSum[4]+$countT[$Indx][4];
                        $CountSum[5]=$CountSum[5]+$countT[$Indx][5];
                        $CountSum[6]=$CountSum[6]+$countT[$Indx][6];
                    }

                    echo "<h2>Prehrana - ".$VLeto."/".($VLeto+1)."</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<tr bgcolor=lightcyan><th>Razred</th><th>zajtrk</th><th>malica</th><th>kosilo</th><th>pop. malica</th><th>št. subv. malic</th><th>št. subv. kosil</th></tr>";
                    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                        echo "<tr bgcolor=lightyellow>";
                        for ($i1=0;$i1 <= 6;$i1++){
                            if ($i1==0){
                                echo "<td align=center bgcolor=khaki><a href='vnosispiski.php?idd=105&solskoleto=".$VLeto."&razred=".$countT[$Indx][9]."'>".$countT[$Indx][$i1]."</a></td>";
                            }else{
                                echo "<td align=center>".$countT[$Indx][$i1]."</td>";
                            }
                        }
                        echo "</tr>";
                    }
                    echo "<tr bgcolor=lightgreen><td>Skupaj</td>";
                    for ($Indx=1;$Indx <= 6;$Indx++){
                        echo "<td align=center>".$CountSum[$Indx]."</td>";
                    }
                    echo "</tr>";
                    echo "</table><br />";
                }
                echo "</body>";
                echo "</html>";
                break;
            case "106a": //izvoz podatkov o prehrani učencev (katere obroke je naročil)
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

                if (isset($_GET["letoobr"])){
                    $VLetoObr=$_GET["letoobr"];
                }else{
                    $VLetoObr=$Danes->format('Y');
                }
                if (isset($_GET["mesecobr"])){
                    $VMesecObr=intval($_GET["mesecobr"]);
                }else{
                    $VMesecObr=intval($Danes->format('n'));
                }
                if (($VLetoPregled) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                //nastavi Prehrana, da je jedel vsak dan in Praznik, da ni dela prost dan
                for ($Indx=1;$Indx <=$MesecDni[$VMesecObr];$Indx++){
                    $Praznik[$Indx]=0;
                }
                //nastavi praznike in v primeru praznika tudi, da tisti dan ni jedel
                $SQL = "SELECT datum,kat,leto,mesec,dan FROM tabpraznik WHERE leto=".$VLetoObr." AND mesec=".$VMesecObr." ORDER BY datum";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    //$Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    //$Praznik[$Indx][1]=$R["kat"];
                    //$Indx=$Indx+1;
                    switch ($R["kat"]){
                        case 1:
                            $Praznik[intval($R["dan"])]= 2; //'prost dan
                            $Indx=$Indx+1;
                            break;
                        case 0:
                            $Praznik[intval($R["dan"])]= 1; //'praznik
                            $Indx=$Indx+1;
                            break;
                        case 2:
                            $Praznik[intval($R["dan"])]= 5; //'delovni dan - sobota
                            $Indx=$Indx+1;
                            break;
                        case 3:
                            $Praznik[intval($R["dan"])]= 4; //'dela prost dan
                            $Indx=$Indx+1;
                            break;
                        case 4:
                            $Praznik[intval($R["dan"])]= 4; //'dela prost dan
                            $Indx=$Indx+1;
                            break;
                        default:
                            $Praznik[intval($R["dan"])]= 0; //'ni v bazi/delovni dan
                            $Indx=$Indx+1;
                    }
                }
                $StPraznikov=$Indx-1;

                $VFile="prehrana.xml";
                $MyFile = "dato".$FileSep.$VFile;
                $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

                echo "<h2>Izvoz podatkov o učencih za malico (Vasco)</h2>";

                //z BOM     fwrite($fh, chr(239).chr(187).chr(191)."<"."?xml version=".chr(34)."1.0".chr(34)." encoding=".chr(34)."UTF-8".chr(34)."?".">"."\n");
                //brez BOM
                fwrite($fh, "<"."?xml version=".chr(34)."1.0".chr(34)." encoding=".chr(34)."UTF-8".chr(34)."?".">"."\n");
                //            fwrite($fh, "<!--XML file generated by Kadri-->"."\n");
                fwrite($fh,"<VRoot iType=".chr(34)."2".chr(34)." Leto=".chr(34).$VLetoObr.chr(34)." Mesec=".chr(34).$VMesecObr.chr(34)." iErrorCode=".chr(34)."0".chr(34)." sErrorMessage=".chr(34).chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34)." xsi:noNamespaceSchemaLocation=".chr(34)."http://www.vasco.si/datoteke/VascoPrehranaResp.xsd".chr(34).">\n");

                $SQL = "SELECT tabrazred.idrazred,tabrazred.razred,tabrazred.paralelka, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabvasco.sifra FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                $SQL = $SQL . "LEFT JOIN tabvasco ON tabrazred.iducenec=tabvasco.iducenec ";
                $SQL = $SQL . "WHERE tabrazred.leto=" . $VLeto ." AND (tabrazred.razred > 0) ";
                $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcenec[$Indx][0]=$R["iducenec"];
                    $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $VUcenec[$Indx][2]=$R["razred"].". ".$R["paralelka"];
                    $VUcenec[$Indx][3]=$R["emso"];
                    if (isset($R["sifra"])){
                        $VUcenec[$Indx][10]=$R["sifra"];
                    }else{
                        $VUcenec[$Indx][10]=0;
                    }
                    $SQL = "SELECT * FROM tabprehrana WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["zajtrk"]){
                            $VUcenec[$Indx][4]=true;
                        }else{
                            $VUcenec[$Indx][4]=false;
                        }
                        if ($R1["malica"]){
                            $VUcenec[$Indx][5]=true;
                        }else{
                            $VUcenec[$Indx][5]=false;
                        }
                        if ($R1["kosilo"]){
                            $VUcenec[$Indx][6]=true;
                        }else{
                            $VUcenec[$Indx][6]=false;
                        }
                        if ($R1["popmalica"]){
                            $VUcenec[$Indx][7]=true;
                        }else{
                            $VUcenec[$Indx][7]=false;
                        }
                        if ($R1["regresmalica"]){
                            $VUcenec[$Indx][8]=true;
                        }else{
                            $VUcenec[$Indx][8]=false;
                        }
                        if ($R1["regreskosilo"]){
                            $VUcenec[$Indx][9]=true;
                        }else{
                            $VUcenec[$Indx][9]=false;
                        }
                    }else{
                        $VUcenec[$Indx][4]=false;
                        $VUcenec[$Indx][5]=false;
                        $VUcenec[$Indx][6]=false;
                        $VUcenec[$Indx][7]=false;
                        $VUcenec[$Indx][8]=false;
                        $VUcenec[$Indx][9]=false;
                    }
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;
                
                //poraba učencev
                fwrite($fh,"<PorabaUcenci TudiNeprijavljeni=".chr(34)."false".chr(34).">\n");

                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $SQL="SELECT dan,malica FROM tabmalica WHERE idUcenec=".$VUcenec[$Indx][0]." AND leto=".$VLetoObr." AND mesec=".$VMesecObr;
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $Datum=new DateTime($VLetoObr."-".$VMesecObr."-".$R["dan"]);
                        //malica
                        if (!$R["malica"]){  //če ima false, potem je jedel
                            if ($VUcenec[$Indx][5]){
                                fwrite($fh,"    <UcenecR>\n");
                                fwrite($fh,"        <MaticnaStevilka>".$VUcenec[$Indx][3]."</MaticnaStevilka>\n");
                                fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                                fwrite($fh,"        <SifraArtikla>1</SifraArtikla>\n");
                                fwrite($fh,"        <TipObroka>2</TipObroka>\n");
                                fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+2)."</PrijavaID>\n");
                                fwrite($fh,"        <Datum>".$Datum->format("Y-m-d")."</Datum>\n");
                                fwrite($fh,"    </UcenecR>\n");
                            }
                            //kosilo
                            if ($VUcenec[$Indx][6]){
                                fwrite($fh,"    <UcenecR>\n");
                                fwrite($fh,"        <MaticnaStevilka>".$VUcenec[$Indx][3]."</MaticnaStevilka>\n");
                                fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                                fwrite($fh,"        <SifraArtikla>2</SifraArtikla>\n");
                                fwrite($fh,"        <TipObroka>3</TipObroka>\n");
                                fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+3)."</PrijavaID>\n");
                                fwrite($fh,"        <Datum>".$Datum->format("Y-m-d")."</Datum>\n");
                                fwrite($fh,"    </UcenecR>\n");
                            }
                            //popoldnska malica
                            if ($VUcenec[$Indx][7]){
                                fwrite($fh,"    <UcenecR>\n");
                                fwrite($fh,"        <MaticnaStevilka>".$VUcenec[$Indx][3]."</MaticnaStevilka>\n");
                                fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                                fwrite($fh,"        <SifraArtikla>3</SifraArtikla>\n");
                                fwrite($fh,"        <TipObroka>4</TipObroka>\n");
                                fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+4)."</PrijavaID>\n");
                                fwrite($fh,"        <Datum>".$Datum->format("Y-m-d")."</Datum>\n");
                                fwrite($fh,"    </UcenecR>\n");
                            }
                        }
                    }
                }
                fwrite($fh,"</PorabaUcenci>\n");

                //odjave učencev (teh podatkov ni v kadrih)
                /*
                fwrite($fh,"<OdjaveUcenci>\n");
                fwrite($fh,"    <UcenecO>\n");
                fwrite($fh,"        <MaticnaStevilka>1234567890123</MaticnaStevilka>\n");
                fwrite($fh,"        <SifraUcenca>12345</SifraUcenca>\n");
                fwrite($fh,"        <SifraArtikla>1</SifraArtikla>\n");
                fwrite($fh,"        <TipObroka>2</TipObroka>\n");
                fwrite($fh,"        <PrijavaID>12345</PrijavaID>\n");
                fwrite($fh,"        <TipOdjave>2</TipOdjave>\n");
                fwrite($fh,"        <Datum>2010-09-17</Datum>\n");
                fwrite($fh,"    </UcenecO>\n");
                fwrite($fh,"</OdjaveUcenci>\n");
                */

                //storitve
                /*
                fwrite($fh,"<Storitve>\n");
                fwrite($fh,"    <Storitev>\n");
                fwrite($fh,"        <SifraStoritve>1</SifraStoritve>\n");
                fwrite($fh,"        <NazivStoritve>Malica</NazivStoritve>\n");
                fwrite($fh,"        <TipObroka>2</TipObroka>\n");
                fwrite($fh,"        <CenaZDDV>0.8</CenaZDDV>\n");
                fwrite($fh,"        <ProcentDDV>0</ProcentDDV>\n");
                fwrite($fh,"    </Storitev>\n");
                fwrite($fh,"    <Storitev>\n");
                fwrite($fh,"        <SifraStoritve>2</SifraStoritve>\n");
                fwrite($fh,"        <NazivStoritve>Kosilo</NazivStoritve>\n");
                fwrite($fh,"        <TipObroka>3</TipObroka>\n");
                fwrite($fh,"        <CenaZDDV>1.5</CenaZDDV>\n");
                fwrite($fh,"        <ProcentDDV>0</ProcentDDV>\n");
                fwrite($fh,"    </Storitev>\n");
                fwrite($fh,"    <Storitev>\n");
                fwrite($fh,"        <SifraStoritve>3</SifraStoritve>\n");
                fwrite($fh,"        <NazivStoritve>Pop. malica</NazivStoritve>\n");
                fwrite($fh,"        <TipObroka>4</TipObroka>\n");
                fwrite($fh,"        <CenaZDDV>0.8</CenaZDDV>\n");
                fwrite($fh,"        <ProcentDDV>0</ProcentDDV>\n");
                fwrite($fh,"    </Storitev>\n");
                fwrite($fh,"</Storitve>\n");
                */
                
                //Regresorji
                /*
                fwrite($fh,"<Regresorji>\n");
                fwrite($fh,"    <Regresor>\n");
                fwrite($fh,"        <SifraRegresorja>1</SifraRegresorja>\n");
                fwrite($fh,"        <NazivRegresorja>MŠŠ</NazivRegresorja>\n");
                fwrite($fh,"        <NaslovRegresorja>Ulica 1</NaslovRegresorja>\n");
                fwrite($fh,"        <PostaRegresorja>1000 Ljubljana</PostaRegresorja>\n");
                fwrite($fh,"        <NeSubNeNe>true</NeSubNeNe>\n");
                fwrite($fh,"        <SubPrvi>true</SubPrvi>\n");
                fwrite($fh,"    </Regresor>\n");
                fwrite($fh,"    <Regresor>\n");
                fwrite($fh,"        <SifraRegresorja>2</SifraRegresorja>\n");
                fwrite($fh,"        <NazivRegresorja>Sklad nekoga</NazivRegresorja>\n");
                fwrite($fh,"        <NaslovRegresorja>Ulica 2</NaslovRegresorja>\n");
                fwrite($fh,"        <PostaRegresorja>2000 Maribor</PostaRegresorja>\n");
                fwrite($fh,"        <NeSubNeNe>false</NeSubNeNe>\n");
                fwrite($fh,"        <SubPrvi>false</SubPrvi>\n");
                fwrite($fh,"    </Regresor>\n");
                fwrite($fh,"</Regresorji>\n");
                */
                
                //Izjeme dni (prazniki, pouka prosti dnevi)
                
                if ($StPraznikov > 0){
                    fwrite($fh,"<IzjemeDni>\n");
                    for ($Indx=1;$Indx <= $MesecDni[$VMesecObr];$Indx++){
                        if ($Praznik[$Indx]==5){
                            fwrite($fh,"    <Dan>\n");
                            $Datum=new DateTime($VLetoObr."-".$VMesecObr."-".$Indx);
                            fwrite($fh,"        <Datum>".$Datum->format('Y-m-d')."</Datum>\n");
                            fwrite($fh,"        <PoukaProst>false</PoukaProst>\n");
                            fwrite($fh,"    </Dan>\n");
                        }else{
                            if ($Praznik[$Indx] > 0){
                                fwrite($fh,"    <Dan>\n");
                                $Datum=new DateTime($VLetoObr."-".$VMesecObr."-".$Indx);
                                fwrite($fh,"        <Datum>".$Datum->format('Y-m-d')."</Datum>\n");
                                fwrite($fh,"        <PoukaProst>true</PoukaProst>\n");
                                fwrite($fh,"    </Dan>\n");
                            }
                        }
                    }
                    fwrite($fh,"</IzjemeDni>\n");
                }
                
                //prijave
                $DatumOd=new DateTime($VLeto."-09-01");
                $DatumDo=new DateTime(($VLeto+1)."-06-24");

                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    //zajtrk
                    if ($VUcenec[$Indx][4]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+1)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>0</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                //malica
                    if ($VUcenec[$Indx][5]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+2)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>1</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                //kosilo
                    if ($VUcenec[$Indx][6]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+3)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>2</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                //pop. malica    
                    if ($VUcenec[$Indx][7]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+4)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>3</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                //regres. malica
                    if ($VUcenec[$Indx][8]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+5)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>4</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                //regres. kosilo
                    if ($VUcenec[$Indx][9]){
                        fwrite($fh,"<Prijave>\n");
                        fwrite($fh,"    <Prijava>\n");
                        fwrite($fh,"        <PrijavaID>".(100000+intval($VUcenec[$Indx][0])*10+6)."</PrijavaID>\n");
                        fwrite($fh,"        <SifraUcenca>".$VUcenec[$Indx][10]."</SifraUcenca>\n");
                        fwrite($fh,"        <DatumOd>".$DatumOd->format('Y-m-d')."</DatumOd>\n");
                        fwrite($fh,"        <DatumDo>".$DatumDo->format('Y-m-d')."</DatumDo>\n");
                        fwrite($fh,"        <SifraArtikla>5</SifraArtikla>\n");
                        fwrite($fh,"        <Dnevi>YYYYYYY</Dnevi>\n");
                        fwrite($fh,"        <SifraRegresor>1</SifraRegresor>\n");
                        fwrite($fh,"        <ProcentRegresa>0</ProcentRegresa>\n");
                        fwrite($fh,"        <ZnesekRegresa>0.5</ZnesekRegresa>\n");
                        fwrite($fh,"    </Prijava>\n");
                        fwrite($fh,"</Prijave>\n");
                    }
                }
                
                //poraba neprijavljenih (ne uporabljamo)
                /*
                fwrite($fh,"<PorabaNeprijavljeni>\n");
                fwrite($fh,"    <UcenecR>\n");
                fwrite($fh,"        <MaticnaStevilka/>\n");


                fwrite($fh,"        <SifraUcenca>3312</SifraUcenca>\n");
                fwrite($fh,"        <SifraArtikla>1</SifraArtikla>\n");
                fwrite($fh,"        <TipObroka>2</TipObroka>\n");
                fwrite($fh,"        <PrijavaID>0</PrijavaID>\n");
                fwrite($fh,"        <Datum>2010-09-16</Datum>\n");
                fwrite($fh,"    </UcenecR>\n");
                fwrite($fh,"</PorabaNeprijavljeni>\n");
                */
                
                fwrite($fh,"</VRoot>\n");
                
                fclose($fh);

                $VFile1="prehrana_ucenci.xml";
                $MyFile1 = "dato".$FileSep.$VFile1;
                $fh = fopen($MyFile1,'w') or die("Ne morem odpreti datoteke!");
                
                fwrite($fh, "<"."?xml version=".chr(34)."1.0".chr(34)." encoding=".chr(34)."UTF-8".chr(34)."?".">"."\n");
                fwrite ($fh,"<VRoot iType=".chr(34)."1".chr(34)." iErrorCode=".chr(34)."0".chr(34)." sErrorMessage=".chr(34).chr(34)." xmlns:xsi=".chr(34)."http://www.w3.org/2001/XMLSchema-instance".chr(34)." xsi:noNamespaceSchemaLocation=".chr(34)."http://www.vasco.si/datoteke/XMLSchemas/VascoUcenciResp.xsd".chr(34).">\n");
                fwrite ($fh,"<Ucenci>\n");
                $SQL = "SELECT tabucenci.emso,tabucenci.priimek,tabucenci.ime,tabucenci.naslov,tabucenci.posta,tabrazdat.razred,tabrazdat.oznaka,tabvasco.sifra FROM ((tabrazred ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "LEFT JOIN tabvasco ON tabrazred.iducenec=tabvasco.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto;
                $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    fwrite ($fh,"<Ucenec>\n");
                    fwrite ($fh," <MaticnaStevilka>".$R["emso"]."</MaticnaStevilka>\n");
                    if (isset($R["sifra"])){
                        fwrite ($fh," <Sifra>".$R["sifra"]."</Sifra>\n");
                    }else{
                        fwrite ($fh," <Sifra>0</Sifra>\n");
                    }
                    fwrite ($fh," <Priimek>".$R["priimek"]."</Priimek>\n");
                    fwrite ($fh," <Ime>".$R["ime"]."</Ime>\n");
                    fwrite ($fh," <Naslov>".$R["naslov"]."</Naslov>\n");
                    fwrite ($fh," <PostnaStevilka>".$R["posta"]."</PostnaStevilka>\n");
                    fwrite ($fh," <Razred>".$R["razred"].mb_strtoupper($R["oznaka"],$encoding)."</Razred>\n");
                    fwrite ($fh," <Aktiven>true</Aktiven>\n");
                    fwrite ($fh,"</Ucenec>\n");
                }
                fwrite ($fh,"</Ucenci>\n");
                fwrite ($fh,"</VRoot>\n");
                fclose($fh);
                
                echo "Za prenos XML datoteke z <b>desnim gumbom kliknite</b> na spodnjo povezavo in izberite <b>Shrani cilj kot</b>.<br />";
                echo "<h3>Shrani datoteko o učencih <a href='".$MyFile1."'>".$VFile1."</a></h3>";
                echo "<h3>Shrani datoteko o koriščenju hrane <a href='".$MyFile."'>".$VFile."</a></h3>";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

                
                echo "</body>";
                echo "</html>";
                break;
            case "107": //vnos malice
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                $VMesec=$_POST["mesec"];
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                //echo "<a href='izborrazreda.php?id=malice'>Na izbor razreda</a><br />";
                
                //izbor razreda, meseca
                echo "<form name='malice' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='107'>";
                echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                echo "<br /><table border=0>";
                echo "<tr><th>razred</th><th>mesec</th></tr>";
                
                echo "<tr>";
                $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." ORDER BY idsola,razred,oznaka";
                $result = mysqli_query($link,$SQL);

                echo "<td><select name='razred'  onchange='this.form.submit()'>";
            //    echo "<tr><td>Izberi razred</td><td><select name='razred'>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    if ($VecSol > 0){
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                        }
                    }else{
                        if ($VRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }
                    }
                    $Indx=$Indx+1;
                }
                echo "<option value='0'>Vsi</option>";
                echo "</select>";

                echo "</td>";

                echo "<td>";
                echo "<select name='mesec' onchange='this.form.submit()'>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    if (($Indx != 7) && ($Indx != 8) ){
                        if ($Indx==$VMesec){
                            echo "<option value=".$Indx." selected='selected'>".$Indx."</option>";
                        }else{
                            echo "<option value=".$Indx.">".$Indx."</option>";
                        }
                    }
                }
                echo "</select>";
                echo "</td>";
                echo "</tr>";
                echo "</table>";
                //    echo "<input name='submit' type='submit' value='Pošlji'>";
                //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                echo "</form>";

                if (CheckDostop("Prehrana",$VUporabnik)){ 
                    $DovoljenVpis=true;
                }else{
                    $DovoljenVpis=false;
                }

                $SQL = "SELECT * FROM tabpraznik WHERE leto=$VLetoPregled AND mesec=$VMesec ORDER BY leto,mesec,dan";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$R["leto"]][$R["mesec"]][$R["dan"]]=$R["kat"];
                }
                
                
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                if ($VMesec < 9){
                    $VLetoPregled=$VLeto+1;
                }else{
                    $VLetoPregled=$VLeto;
                }
                if (($VLetoPregled) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }
                if (CheckDostop("Prehrana",$VUporabnik) ) {
                    echo "<a href='vnosispiski.php?idd=106a&letoobr=".$VLetoPregled."&mesecobr=".$VMesec."'>Izvozi podatke</a>";
                }
                echo "<div class='break'></div>";
                if ($Vid=="1"){
                    if (!$DovoljenVpis){
                        $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$MesecDni[$VMesec]);
                        $Interval=$Danes->diff($Dan);
                        if (($Interval->invert==0) or (($Interval->invert==1) && ($Interval->d <= 4))){
                            $DovoljenVpis=true;
                        }
                    }
                        
                    if ($DovoljenVpis){
                        $SQL = "SELECT tabucenci.iducenec, tabrazdat.* FROM ";
                        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        if ($VRazred != 0){
                            $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred ;
                            $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                        }else{
                            $SQL = $SQL . "WHERE tabrazdat.leto=" . $VLeto ;
                            $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
                        }
                        $result = mysqli_query($link,$SQL);

                        //'Izpis razrednih podatkov
                        $PrvaStran=true;
                        $CompRazred=0;
                        while ($R = mysqli_fetch_array($result)){
                            for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                                $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                                if (isset($Praznik[$VLetoPregled][$VMesec][$Indx])){
                                    $VCheckPraznik=$Praznik[$VLetoPregled][$VMesec][$Indx];
                                }else{
                                    $VCheckPraznik=10;  //delovni dan
                                }
                                if ((($Dan->format('w')+1)==1) or (($Dan->format('w')+1)==7)){
                                    //if ($VCheckPraznik == 3){
                                    if ($VCheckPraznik == 2){ //delovna sobota ali nedelja
                                        $SQL1="SELECT * FROM tabmalica WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                        $result1 = mysqli_query($link,$SQL1);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                $SQL1="UPDATE tabmalica SET malica=true WHERE id=".$R1["id"];
                                            }else{
                                                $SQL1="UPDATE tabmalica SET malica=false WHERE id=".$R1["id"];
                                            }
                                            //$result1 = mysqli_query($link,$SQL1);
                                            if (!($result1 = mysqli_query($link,$SQL1))){
                                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                            }
                                        }else{
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                $SQL1="INSERT INTO tabmalica (idUcenec,leto,mesec,dan,malica) VALUES (".$R["iducenec"].",".$VLetoPregled.",".$VMesec.",".$Indx.",true)";
                                            }else{
                                                $SQL1="INSERT INTO tabmalica (idUcenec,leto,mesec,dan,malica) VALUES (".$R["iducenec"].",".$VLetoPregled.",".$VMesec.",".$Indx.",false)";
                                            }
                                            //$result1 = mysqli_query($link,$SQL1);
                                            if (!($result1 = mysqli_query($link,$SQL1))){
                                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                            }
                                        }
                                    }else{
                                        echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                                    }
                                }else{
                                    if (($VCheckPraznik==0) or ($VCheckPraznik==1) or ($VCheckPraznik==3) or ($VCheckPraznik==4)){
                                        echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                                    }else{
                                        $SQL1="SELECT * FROM tabmalica WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                        $result1 = mysqli_query($link,$SQL1);
                                        if ($R1 = mysqli_fetch_array($result1)){
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                if (!$R1["malica"]){
                                                    $SQL1="UPDATE tabmalica SET malica=true WHERE id=".$R1["id"];
                                                    if (!($result1 = mysqli_query($link,$SQL1))){
                                                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                                    }
                                                }
                                            }else{
                                                if ($R1["malica"]){
                                                    $SQL1="UPDATE tabmalica SET malica=false WHERE id=".$R1["id"];
                                                    if (!($result1 = mysqli_query($link,$SQL1))){
                                                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                                    }
                                                }
                                            }
                                        }else{
                                            if (isset($_POST["mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled])){
                                                $SQL1="INSERT INTO tabmalica (idUcenec,leto,mesec,dan,malica) VALUES (".$R["iducenec"].",".$VLetoPregled.",".$VMesec.",".$Indx.",true)";
                                            }else{
                                                $SQL1="INSERT INTO tabmalica (idUcenec,leto,mesec,dan,malica) VALUES (".$R["iducenec"].",".$VLetoPregled.",".$VMesec.",".$Indx.",false)";
                                            }
                                            //$result1 = mysqli_query($link,$SQL1);
                                            if (!($result1 = mysqli_query($link,$SQL1))){
                                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }else{
                        echo "<h2>Potekel je rok za vnos podatkov. Obrnite se na vodjo prehrane!</h2>";
                    }
                }

                echo "<form  name='malica' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='107'>";
                echo "<br /><table border=1>";

                $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.iducenec, tabrazdat.* FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                if ($VRazred != 0){
                    $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred ;
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                }else{
                    $SQL = $SQL . "WHERE tabrazdat.leto=" . $VLeto ;
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek,tabucenci.Ime";
                }
                $result = mysqli_query($link,$SQL);

                //'Izpis razrednih podatkov
                $i1=1;
                $i2=0;
                $PrvaStran=true;
                $CompRazred=0;
                for ($Indx=0;$Indx <= 31;$Indx++){
                    $StMalicDan[$Indx]=0;
                }
                while ($R = mysqli_fetch_array($result)){
                    if ($CompRazred != $R["id"]){
                        if (!$PrvaStran){
                            //'vsote po dnevih
                            echo "<tr bgcolor='lightgreen'>";
                            echo "<td>&nbsp;</td>";
                            echo "<td>Skupaj</td>";
                            echo "<td>&nbsp;</td>";
                            $StMalic=0;
                            for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                                $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                                if (isset($Praznik[$VLetoPregled][$VMesec][$Indx])){
                                    $VCheckPraznik=$Praznik[$VLetoPregled][$VMesec][$Indx];
                                }else{
                                    $VCheckPraznik=10;
                                }
                                if ((($Dan->format('w')+1)==1) or ($Dan->format('w')+1)==7){
                                    echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                                }else{
                                    if (($VCheckPraznik==0) or ($VCheckPraznik==1) or ($VCheckPraznik==3) or ($VCheckPraznik==4)){
                                        echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                                    }else{
                                        echo "<td align='right' width='20'>".$StMalicDan[$Indx]."</td>";
                                        $StMalic=$StMalic+$StMalicDan[$Indx];
                                    }
                                }
                            }
                            echo "<td align='center'>".$StMalic."</td>";
                            echo "</tr>";
                        }
                        echo "</table><br />";
                        if ($PrvaStran){
                            echo "<h2>Malice: ".$R["razred"].". ".$R["oznaka"].", ".$VMesec." - ".$VLeto."/".($VLeto+1)."</h2>";
                        }else{
                            echo "<h2 class='break'>Malice: ".$R["razred"].". ".$R["oznaka"].", ".$VMesec." - ".$VLeto."/".($VLeto+1)."</h2>";
                        }
                        $PrvaStran=false;
                        echo "<br /><table border=1>";
                        echo "<tr>";
                        echo "<th>Št.</th>";
                        echo "<th width='180'>Ime</th>";
                        echo "<th>Razred</th>";
                        for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                            $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                            if (isset($Praznik[$VLetoPregled][$VMesec][$Indx])){
                                $VCheckPraznik=$Praznik[$VLetoPregled][$VMesec][$Indx];
                            }else{
                                $VCheckPraznik=10;
                            }
                            if ((($Dan->format('w')+1)==1) or ($Dan->format('w')+1)==7){
                                if ($VCheckPraznik==2){
                                    echo "<th width='20'><input class='groovybutton' name='b".$Indx."' type='button' value='".$Indx."' onClick='OznaciStolpec(this.form,".$Indx.")'></th>";
                                }else{
                                    echo "<th width='20' bgcolor='lightsalmon'>".$Indx."</th>";
                                }
                            }else{
                                if (($VCheckPraznik==0) or ($VCheckPraznik==1) or ($VCheckPraznik==3) or ($VCheckPraznik==4)){
                                    echo "<td width='20' bgcolor='lightskyblue'>$Indx</td>";
                                }else{
                                    echo "<th width='20'><input class='groovybutton' name='b".$Indx."' type='button' value='".$Indx."' onClick='OznaciStolpec(this.form,".$Indx.")'></th>";
                                }
                            }
                        }
                        echo "<th>Skupaj</th>";
                        echo "</tr>";
                        $CompRazred=$R["id"];
                        for ($Indx=0;$Indx <= 31;$Indx++){
                            $StMalicDan[$Indx]=0;
                        }
                        $i1=1;
                    }
                    if ($i1 % 2 == 0){
                        echo "<tr>";
                    }else{
                        echo "<tr bgcolor=#e5e5e5>";
                    }
                    echo "<td>".$i1."</td>";
                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                    echo "<td>".$R["razred"].". ".$R["oznaka"]."</td>";
                    $StMalic=0;
                    for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                        $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                        if (isset($Praznik[$VLetoPregled][$VMesec][$Indx])){
                            $VCheckPraznik=$Praznik[$VLetoPregled][$VMesec][$Indx];
                        }else{
                            $VCheckPraznik=10;
                        }
                        if ((($Dan->format('w')+1)==1) or ($Dan->format('w')+1)==7){
                            if ($VCheckPraznik==2){
                                $SQL1="SELECT malica,iducenec FROM tabmalica WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                $result1 = mysqli_query($link,$SQL1);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    if ($R1["malica"]){
                                        echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox' checked='checked'></td>";
                                        $StMalic=$StMalic+1;
                                        $StMalicDan[$Indx]=$StMalicDan[$Indx]+1;
                                    }else{
                                        echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox'></td>";
                                    }
                                }else{
                                    echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox'></td>";
                                }
                            }else{
                                echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                            }
                        }else{
                            if (($VCheckPraznik==0) or ($VCheckPraznik==1) or ($VCheckPraznik==3) or ($VCheckPraznik==4)){
                                echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                            }else{
                                $SQL1="SELECT malica,iducenec FROM tabmalica WHERE idUcenec=".$R["iducenec"]." AND leto=".$VLetoPregled." AND mesec=".$VMesec." AND dan=".$Indx;
                                $result1 = mysqli_query($link,$SQL1);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    if ($R1["malica"]){
                                        echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox' checked='checked'></td>";
                                        $StMalic=$StMalic+1;
                                        $StMalicDan[$Indx]=$StMalicDan[$Indx]+1;
                                    }else{
                                        echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox'></td>";
                                    }
                                }else{
                                    echo "<td width='20'><input id='dan_".$Indx."' name='mal_".$R["iducenec"]."_".$Indx."_".$VMesec."_".$VLetoPregled."' type='checkbox'></td>";
                                }
                            }
                        }
                    }
                    echo "<td align='center'>".$StMalic."</td>";
                    echo "</tr>";
                    
                    $i1=$i1+1;
                    $i2=$i2+1;
                }

                //'vsote po dnevih
                echo "<tr bgcolor='lightgreen'>";
                echo "<td>&nbsp;</td>";
                echo "<td>Skupaj</td>";
                echo "<td>&nbsp;</td>";
                $StMalic=0;
                for ($Indx=1;$Indx <= $MesecDni[$VMesec];$Indx++){
                    $Dan=new DateTime($VLetoPregled."-".$VMesec."-".$Indx);
                    if (isset($Praznik[$VLetoPregled][$VMesec][$Indx])){
                        $VCheckPraznik=$Praznik[$VLetoPregled][$VMesec][$Indx];
                    }else{
                        $VCheckPraznik=10; //delovni dan
                    }
                    if ((($Dan->format('w')+1)==1) or ($Dan->format('w')+1)==7){
                        if ($VCheckPraznik == 2){
                            echo "<td align='right' width='20'>".$StMalicDan[$Indx]."</td>";
                            $StMalic=$StMalic+$StMalicDan[$Indx];
                        }else{
                            echo "<td width='20' bgcolor='lightsalmon'>&nbsp;</td>";
                        }
                    }else{
                        if (($VCheckPraznik==0) or ($VCheckPraznik==1) or ($VCheckPraznik==3) or ($VCheckPraznik==4)){
                            echo "<td width='20' bgcolor='lightskyblue'>&nbsp;</td>";
                        }else{
                            echo "<td align='right' width='20'>".$StMalicDan[$Indx]."</td>";
                            $StMalic=$StMalic+$StMalicDan[$Indx];
                        }
                    }
                }
                echo "<td align='center'>".$StMalic."</td>";
                echo "</tr>";

                echo "</table>";

                echo "<input id='StOtrok' type='hidden' name='stotrok' value='".($i2-1)."'>";
                echo "<input type='hidden' name='id' value='1'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input type='hidden' name='mesec' value='".$VMesec."'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form><br /><br />";

                ?>
                        <a href="prijava.php">Nazaj na glavni meni</a><br />
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
                echo "</body>";
                echo "</html>";
                break;
            case "108": // vnos izjave - soglasja
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='izborrazreda.php?id=izjave'>Na izbor razreda</a><br />";
                if ($SteviloUcencev > 0){
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $ucenec=$_POST["ucenec".$Indx];
                        $SQL="SELECT * FROM tabdovoljenja WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabdovoljenja SET ";
                            if (isset($_POST["izjava".$Indx])){
                                $SQL=$SQL."izjava=true,";
                            }else{
                                $SQL=$SQL."izjava=false,";
                            }
                            $SQL=$SQL."komentar='".$_POST["komentar".$Indx]."',";
                            if (isset($_POST["zdrziv".$Indx])){
                                $SQL=$SQL."zdravozivljenje=true,";
                            }else{
                                $SQL=$SQL."zdravozivljenje=false,";
                            }
                            $SQL=$SQL."komentzdrziv='".$_POST["komentzdrziv".$Indx]."',";
                            $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabdovoljenja (";
                            $SQL=$SQL."izjava,komentar,ZdravoZivljenje,KomentZdrZiv,vpisal,cas,leto,idUcenec) VALUES (";
                            if (isset($_POST["izjava".$Indx])){
                                $SQL=$SQL."true,";
                            }else{
                                $SQL=$SQL."false,";
                            }
                            $SQL=$SQL."'".$_POST["komentar".$Indx]."',";
                            if (isset($_POST["zdrziv".$Indx])){
                                $SQL=$SQL."true,";
                            }else{
                                $SQL=$SQL."false,";
                            }
                            $SQL=$SQL."'".$_POST["komentzdrziv".$Indx]."',";
                            $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$ucenec.")";
                        }
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                        }
                    }
                    //echo "<h2>Podatki SO vpisani!</h2>";
                    if ($Opravila==1){
                        $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["iducitelj"];
                        }else{
                            $Ucitelj=0;
                        }
                        
                        $SQL = "SELECT tabdeldogodek.* FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos soglasij staršev' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                            }
                        }
                    }
                }

                if ($VRazred==0){
                    $SQL = "SELECT id FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY razred,oznaka";
                    $result = mysqli_query($link,$SQL);
                    $IndxR=1;
                    while ($R = mysqli_fetch_array($result)){
                        $Razredi[$IndxR]=$R["id"];
                        $IndxR=$IndxR+1;
                    }
                    $StRazredov=$IndxR-1;
                }else{
                    $Razredi[1]=$VRazred;
                    $StRazredov=1;
                }
                for ($IndxR=1;$IndxR <= $StRazredov;$IndxR++){    
                    $Indx=1;

                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL."(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec )";
                    $SQL = $SQL." INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL."WHERE tabrazdat.id=" . $Razredi[$IndxR] ;
                    $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $VUcenec[$Indx][0]=$R["iducenec"];
                        $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                        $VUcenec[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                        $VUcenec[$Indx][3]=$R["id"];
                        $Indx=$Indx+1;
                    }
                    $StUcencev=$Indx-1;
                    //'Izpis razrednih podatkov
                    echo "<h2>Soglasja staršev - ".$VLeto."/".($VLeto+1)."</h2>";
                    echo "<a href='vnosispiski.php?idd=109&razred=".$Razredi[$IndxR]."&solskoleto=".$VLeto."'>Priprava za tisk</a><br />";
                    if ($StRazredov == 1){
                        echo "<form  name='UcenciIzjave' method=post action='vnosispiski.php'>";
                    }
                    echo "<input name='idd' type='hidden' value='108'>";
                    echo "<br /><table border=1>";
                    echo "<tr>";
                    echo "<th>Št.</th>";
                    echo "<th>Leto</th>";
                    echo "<th>Ime</th>";
                    echo "<th>Soglasje<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></th>";
                    echo "<th>Opomba 1</th>";
                    echo "<th>Soglasje<br />Zdravo življ. slog<br /><input class='groovybutton' name='b2' type='button' value='' onClick='OznaciStolpec(this.form,2)'></th>";
                    echo "<th>Opomba 2</th>";
                    echo "</tr>";

                    for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                        $SQL = "SELECT * FROM tabdovoljenja WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                            echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                            if ($R["Izjava"]){
                                echo "<td align='center'><input id='dan_1' name='izjava".$Indx."' type='checkbox' checked='checked'></td>";
                            }else{
                                echo "<td align='center'><input id='dan_1' name='izjava".$Indx."' type='checkbox'></td>";
                            }
                            echo "<td><textarea name='komentar".$Indx."' cols='40' rows='2'>".$R["Komentar"]."</textarea></td>";
                            if ($R["ZdravoZivljenje"]){
                                echo "<td align='center'><input id='dan_2' name='zdrziv".$Indx."' type='checkbox' checked='checked'></td>";
                            }else{
                                echo "<td align='center'><input id='dan_2' name='zdrziv".$Indx."' type='checkbox'></td>";
                            }
                            echo "<td><input name='komentzdrziv".$Indx."' type='text' size='30' value='".$R["KomentZdrZiv"]."'></td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                            echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                            echo "<td align='center'><input id='dan_1' name='izjava".$Indx."' type='checkbox'></td>";
                            echo "<td><textarea name='komentar".$Indx."' cols='40' rows='2'></textarea></td>";
                            echo "<td align='center'><input id='dan_2' name='zdrziv".$Indx."' type='checkbox'></td>";
                            echo "<td><input name='komentzdrziv".$Indx."' type='text' size='30' value=''></td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                }
                if ($StRazredov == 1){
                    echo "<input type='hidden' name='stucencev' value='".$StUcencev."'>";
                    echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                    echo "<input name='submit' type='submit' value='Pošlji'><br />";
                    echo "</form>";
                }
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
                echo "</body>";
                echo "</html>";
                break;
            case "109": //izpis soglasij
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                $Indx=0;
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                $SQL = $SQL."(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec )";
                $SQL = $SQL." INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL = $SQL."WHERE tabrazdat.id=" . $VRazred ;
                $SQL = $SQL." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $VUcenec[$Indx][0]=$R["iducenec"];
                    $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $VUcenec[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                    $VUcenec[$Indx][3]=$R["id"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;
                //'Izpis razrednih podatkov
                echo "<h2>Soglasja staršev - ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<a href='vnosispiski.php?idd=108&razred=".$VRazred."&solskoleto=".$VLeto."'>Na vnos soglasij</a><br />";
                echo "<form  name='UcenciIzjave' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='108'>";
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Leto</th>";
                echo "<th>Ime</th>";
                echo "<th>Soglasje</th>";
                echo "<th>Opomba 1</th>";
                echo "<th>Soglasje<br />Zdravo življ. slog</th>";
                echo "<th>Opomba 2</th>";
                echo "</tr>";

                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $SQL = "SELECT * FROM tabdovoljenja WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        if ($R["Izjava"]){
                            echo "<td><input name='izjava".$Indx."' type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<td><input name='izjava".$Indx."' type='checkbox'></td>";
                        }
                        echo "<td>".$R["Komentar"]."</td>";
                        if ($R["ZdravoZivljenje"]){
                            echo "<td><input name='zdrziv".$Indx."' type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<td><input name='zdrziv".$Indx."' type='checkbox'></td>";
                        }
                        echo "<td>".$R["KomentZdrZiv"]."</td>";
                        echo "</tr>";
                    }else{
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                        echo "<td><input name='izjava".$Indx."' type='checkbox'></td>";
                        echo "<td>&nbsp;</td>";
                        echo "<td><input name='zdrziv".$Indx."' type='checkbox'></td>";
                        echo "<td>&nbsp;</td>";
                        echo "</tr>";
                    }
                }
                echo "</table>";
                echo "</form><br /><br />";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "110": //vnos telefonov
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                switch ($Vid){
                    case "1":
                        for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                            $SQL = "UPDATE tabucenci SET ";
                            $SQL = $SQL . "TelefonDoma='".$_POST["telefondoma_".$Indx]."',";
                            $SQL = $SQL . "oceKontakt='".$_POST["ocekontakt_".$Indx]."',";
                            $SQL = $SQL . "oceGSM='".$_POST["ocegsm_".$Indx]."',";
                            $SQL = $SQL . "oceSluzba='".$_POST["ocesluzba_".$Indx]."',";
                            $SQL = $SQL . "matiKontakt='".$_POST["matikontakt_".$Indx]."',";
                            $SQL = $SQL . "matiGSM='".$_POST["matigsm_".$Indx]."',";
                            $SQL = $SQL . "matiSluzba='".$_POST["matisluzba_".$Indx]."',";
                            $SQL = $SQL . "SkrbnikiKontakt='".$_POST["skrbnikikontakt_".$Indx]."'";
                            $SQL = $SQL . " WHERE idUcenec=".$_POST["uc_".$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                        echo "<h2>Podatki so bili vpisani!</h2>";
                }

                $SQL = "SELECT tabucenci.*,tabrazdat.*,tabbivanje.bivanje AS bbivanje FROM ";
                $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                $SQL = $SQL . "INNER JOIN tabbivanje ON tabucenci.Bivanje=tabbivanje.idBivanje ";
                $SQL = $SQL . "WHERE tabrazdat.id=" . $VRazred;
                $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                echo "<form name='telefoni' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='110'>";

                if ($R = mysqli_fetch_array($result)){
                    $VLeto=$R["leto"];
                    echo "<h2>Šolsko leto: " . $VLeto . "/" . ($VLeto+1) . "<br /> Razred: ".$R["razred"].". " . $R["oznaka"]. "</h2>";
                }

                echo "<table border=1>";
                echo "<tr><th>N</th><th>Priimek in ime</th><th>Bivanje</th><th>Telefon doma</th><th>Oče</th><th>Oče-telefon</th><th>Oče-GSM</th><th>Oče-služba</th><th>Mati</th><th>Mati-telefon</th><th>Mati-GSM</th><th>Mati-služba</th><th>Skrbniki-telefon</th></tr>";

                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr><td>" . $Indx ."<input name='uc_".$Indx."' type='hidden' value='".$R["IdUcenec"]."'></td>";
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"] ."'>" . $R["Priimek"] . ", " . $R["Ime"] . "</a></td>";
                    echo "<td>". $R["bbivanje"] ."</td>";
                    echo "<td><input name='telefondoma_".$Indx."' type='text' size='12' value='". $R["TelefonDoma"] ."'></td>";
                    echo "<td>". $R["oce"] ."</td>";
                    if (strlen($R["oce"]) > 0){
                        echo "<td><input name='ocekontakt_".$Indx."' type='text' size='12' value='". $R["ocekontakt"] ."'></td>";
                        echo "<td><input name='ocegsm_".$Indx."' type='text' size='12' value='". $R["oceGSM"] ."'></td>";
                        echo "<td><input name='ocesluzba_".$Indx."' type='text' size='12' value='". $R["oceSluzba"] ."'></td>";
                    }else{
                        echo "<td><input name='ocekontakt_".$Indx."' type='text' size='12' value=''></td>";
                        echo "<td><input name='ocegsm_".$Indx."' type='text' size='12' value=''></td>";
                        echo "<td><input name='ocesluzba_".$Indx."' type='text' size='12' value=''></td>";
                    }
                    echo "<td>". $R["mati"] ."</td>";
                    if (strlen($R["mati"]) > 0){
                        echo "<td><input name='matikontakt_".$Indx."' type='text' size='12' value='". $R["matikontakt"] ."'></td>";
                        echo "<td><input name='matigsm_".$Indx."' type='text' size='12' value='". $R["matiGSM"] ."'></td>";
                        echo "<td><input name='matisluzba_".$Indx."' type='text' size='12' value='". $R["matiSluzba"] ."'></td>";
                    }else{
                        echo "<td><input name='matikontakt_".$Indx."' type='text' size='12' value=''></td>";
                        echo "<td><input name='matigsm_".$Indx."' type='text' size='12' value=''></td>";
                        echo "<td><input name='matisluzba_".$Indx."' type='text' size='12' value=''></td>";
                    }
                    if (strlen($R["Skrbniki"]) > 0){
                        echo "<td><input name='skrbnikikontakt_".$Indx."' type='text' size='12' value='". $R["SkrbnikiKontakt"] ."'></td>";
                    }else{
                        echo "<td><input name='skrbnikikontakt_".$Indx."' type='text' size='12' value=''></td>";
                    }
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "</table><br />";
                echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                echo "<input name='razred' type='hidden' value='".$VRazred."'>";
                echo "<input name='stucencev' type='hidden' value='".($Indx-1)."'>";
                echo "<input name='id' type='hidden' value='1'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";

                echo "<h2><a href='izpisrazreda.php?id=4&solskoleto=".$VLeto."&razred=".$VRazred."'>Pošiljanje elektronskih sporočil</a></h2>";
                echo "<a href='izborrazreda.php?id=telefoni'>Izbor razreda</a><br />";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "111": //vnos plavanja
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                switch ($Vid){
                    case "1":
                        $SQL = "SELECT tabplavanje.leto,tabplavanje.stopnja,tabucenci.iducenec,tabucenci.ime,tabucenci.priimek,tabrazdat.razred,tabrazdat.oznaka FROM ((tabplavanje ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabplavanje.idUcenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL . " WHERE tabplavanje.leto > ".($VLeto-8);
                        $SQL = $SQL . " ORDER BY priimek,ime,tabplavanje.leto";
                        $result = mysqli_query($link,$SQL);
                        
                        $Indx=0;
                        $VPlavalecComp=0;
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["iducenec"] != $VPlavalecComp){
                                $VPlavalecComp=$R["iducenec"];
                                $Indx=$Indx+1;
                                $VPlavanje[$Indx][0]=$R["iducenec"];
                                $VPlavanje[$Indx][1]=$R["priimek"]." ".$R["ime"];
                                $VPlavanje[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                                $VPlavanje[$Indx][$R["leto"]-($VLeto-8)+3]=$R["stopnja"];
                            }else{
                                $VPlavanje[$Indx][2]=$R["razred"].". ".$R["oznaka"];
                                $VPlavanje[$Indx][$R["leto"]-($VLeto-8)+3]=$R["stopnja"];
                            }
                        }
                        $StPlavalcev=$Indx;
                        
                        echo "<table border='1' cellspacing='0'>";
                        echo "<tr><th>Št.</th><th>ime</th>";
                        for ($Indx=$VLeto-8;$Indx <= $VLeto;$Indx++){
                            echo "<th>".$Indx."</th>";
                        }
                        echo "</tr>";
                        
                        for ($Indx=1;$Indx <= $StPlavalcev;$Indx++){
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$VPlavanje[$Indx][1].", ".$VPlavanje[$Indx][2]."</td>";
                            for ($i1=3;$i1 <= 11;$i1++){
                                if (isset($VPlavanje[$Indx][$i1])){
                                    echo "<td align='center'>".$VPlavanje[$Indx][$i1]."</td>";
                                }else{
                                    echo "<td align='center'>&nbsp;</td>";
                                }
                            }
                            echo "</tr>";
                        }
                        echo "</table><br />";
                    default:
                        if ($SteviloUcencev > 0){
                            for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                                $ucenec=$_POST["ucenec".$Indx];
                                if ($ucenec > 0){
                                    $SQL="SELECT * FROM tabplavanje WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                                    $result = mysqli_query($link,$SQL);
                                    
                                    if ($R = mysqli_fetch_array($result)){
                                        $SQL = "UPDATE tabplavanje SET ";
                                        $SQL=$SQL."stopnja=".$_POST["stopnja".$Indx];
                                        $SQL=$SQL.",komentar='".$_POST["komentar".$Indx]."' ";
                                        $SQL=$SQL." WHERE id=".$R["id"];
                                    }else{
                                        $SQL = "INSERT INTO tabplavanje (";
                                        $SQL=$SQL."leto,idUcenec,stopnja,komentar) VALUES (";
                                        $SQL=$SQL.$VLeto.",";
                                        $SQL=$SQL.$_POST["ucenec".$Indx].",";
                                        $SQL=$SQL.$_POST["stopnja".$Indx].",'".$_POST["komentar".$Indx]."')";
                                    }
                                    if (!($result = mysqli_query($link,$SQL))){
                                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                    }
                                }
                            }
                            //echo "<h2>Podatki SO vpisani!</h2>";
                        }

                        $SQL = "SELECT tabrazred.idrazred,tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                        $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                        $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred ." AND tabrazred.leto=".$VLeto;
                        $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                        $result = mysqli_query($link,$SQL);
                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VUcenec[$Indx][0]=$R["iducenec"];
                            $VUcenec[$Indx][1]=$R["priimek"]." ".$R["ime"];
                            $VUcenec[$Indx][2]=$R["razred"].". ".$R["paralelka"];
                            $VUcenec[$Indx][3]=$R["idrazred"];
                            $Indx=$Indx+1;
                        }
                        $StUcencev=$Indx-1;
                        
                        //'Izpis razrednih podatkov
                        echo "<h2>Plavanje ".$VLeto."/".($VLeto+1)."</h2>";
                        echo "<form  name='Plavanje' method='post' action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='111'>";
                        echo "<br /><table border=1>";
                        echo "<tr>";
                        echo "<th>Št.</th>";
                        echo "<th>Ime</th>";
                        echo "<th>Stopnja plavalca</th>";
                        echo "<th>Komentar</th>";
                        echo "</tr>";

                        for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                            $SQL = "SELECT * FROM tabplavanje WHERE iducenec=".$VUcenec[$Indx][0]." AND leto=".$VLeto;
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                                echo "<td><input name='stopnja".$Indx."' type='text' value='".$R["stopnja"]."'></td>";
                                echo "<td><input name='komentar".$Indx."' type='text' value='".$R["komentar"]."'></td>";
                                echo "</tr>";    
                            }else{
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$VUcenec[$Indx][0]."'>".$VUcenec[$Indx][1].", ".$VUcenec[$Indx][2]."</td>";
                                echo "<td><input name='stopnja".$Indx."' type='text' value='0'></td>";
                                echo "<td><input name='komentar".$Indx."' type='text' value=''></td>";
                                echo "</tr>";
                            }
                        }
                        echo "</table>";
                        echo "<input type='hidden' name='stucencev' value='".$StUcencev."'>";
                        echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                        echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                        echo "</form>";
                }
                echo "<a href='vnosispiski.php?idd=111&id=1&razred=".$VRazred."'>Izpis zgodovine</a><br />";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "112": //vnos tabori
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
                echo "<script type=\"text/javascript\">";
                echo "    window.onload = function(){";
                echo "        var Danes = new Date();";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat01\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat02\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "    };";
                echo "</script>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    $n=$VLevel;
			    include('menu_func.inc');
			    include ('menu.inc');
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

                $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE tabrazdat.id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                    $VSola=$R["solakratko"];
                }

                if ($SteviloUcencev > 0){
                    $VDatumZac=$_POST["datumzac"];
                    $VDatumKon=$_POST["datumkon"];
                    $VVrsta=$_POST["vrsta"];
                    $VKraj=$_POST["kraj"];
                    $VZnesek=str_replace(",",".",$_POST["znesek"]);
                    if (!is_numeric($VZnesek)){
                        $VZnesek=0;
                    }
                    for ($i=0;$i < 7;$i++){
                        $Spremljevalec[$i]=$_POST["spremljevalec".$i];
                    }
                    $VSpremljevalci=Arr2Str($Spremljevalec);
                    $SQL = "SELECT * FROM tabtabordata WHERE idRazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabtabordata SET ";
                        $SQL = $SQL."DatumZac='".$VDatumZac."',DatumKon='".$VDatumKon."',Kraj='".$VKraj."',Vrsta='".$VVrsta."',Znesek=".$VZnesek.", Spremljevalci='".$VSpremljevalci."'";
                        $SQL = $SQL . " WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabtabordata (leto,razred,paralelka,DatumZac,DatumKon,Kraj,Vrsta,Znesek,spremljevalci,idRazred)";
                        $SQL = $SQL . " VALUES (".$VLeto.",".$VRazred1.",'".$VParalelka."','".$VDatumZac."','".$VDatumKon."','".$VKraj."','".$VVrsta."',".$VZnesek.",'".$VSpremljevalci."',".$VRazred.")";
                    }
                    if (!($result = mysqli_query($link,$SQL))){
                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                    }
                    
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $ucenec=$_POST["ucenec".$Indx];
                        if ($ucenec > 0){
                            $SQL="SELECT * FROM tabtabori WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabtabori SET ";
                                if (isset($_POST["udelezba".$Indx])){
                                    $SQL=$SQL."udelezba=true,";
                                }else{
                                    $SQL=$SQL."udelezba=false,";
                                }
                                if (isset($_POST["brezplacno".$Indx])){
                                    $SQL=$SQL."brezplacno=true,";
                                }else{
                                    $SQL=$SQL."brezplacno=false,";
                                }
                                if (isset($_POST["subvencija".$Indx])){
                                    $SQL=$SQL."subvencija=true,";
                                }else{
                                    $SQL=$SQL."subvencija=false,";
                                }
                                $SQL = $SQL . "opomba='".$_POST["opomba".$Indx]."',";
                                $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                            }else{
                                $SQL = "INSERT INTO tabtabori (udelezba,brezplacno,subvencija,opomba,";
                                $SQL=$SQL."vpisal,cas,leto,idUcenec) VALUES (";
                                if (isset($_POST["udelezba".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["brezplacno".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                if (isset($_POST["subvencija".$Indx])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                                $SQL = $SQL . "'".$_POST["opomba".$Indx]."',";
                                $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$ucenec.")";
                            }
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                            }
                        }
                    }
                    //echo "<h2>Podatki SO vpisani!</h2>";
                    
                    if ($Opravila==1){
                        $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["iducitelj"];
                        }else{
                            $Ucitelj=0;
                        }
                        
                        $SQL = "SELECT tabdeldogodek.id FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='Šola v naravi/Tabori' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                    }
                }

                $SQL = "SELECT * FROM tabtabordata WHERE idRazred=".$VRazred;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VDatumZac=$R["DatumZac"];
                    $VDatumKon=$R["DatumKon"];
                    $VKraj=$R["Kraj"];
                    $VVrsta=$R["Vrsta"];
                    $VZnesek=$R["Znesek"];
                    $VSpremljevalci=$R["Spremljevalci"];
                }else{
                    $VDatumZac="";
                    $VDatumKon="";
                    $VKraj="";
                    $VVrsta="";
                    $VZnesek=0;
                    $VSpremljevalci="";
                }
                for ($Indx=0;$Indx < 7;$Indx++){
                    $Spremljevalec[$Indx]=0;
                }
                if (strlen($VSpremljevalci) > 0){
                    $SQL = "SELECT iducitelj FROM tabucitelji WHERE idUcitelj IN (".$VSpremljevalci.") AND iducitelj > 0";
                    $result = mysqli_query($link,$SQL);
                    
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Spremljevalec[$Indx]=$R["iducitelj"];
                        $Indx=$Indx+1;
                    }
                }

                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status IN (1,2,3,4,5,6) ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VUcitelji[$Indx][0]=$R["iducitelj"];
                    $VUcitelji[$Indx][1]=$R["priimek"]." ".$R["ime"];
                    $Indx=$Indx+1;
                }
                $VUcitelji[$Indx][0]=0;
                $VUcitelji[$Indx][1]="Ni izbran";
                $StUciteljev=$Indx;

                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND idrazred=".$VRazred;
                $SQL .= " ORDER BY tabucenci.priimek,tabucenci.ime";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Indx=$Indx+1;
                    $ucenci[$Indx][0]=$R["iducenec"];
                    $ucenci[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                }
                $SteviloUcencev=$Indx;

                //Izpis razrednih podatkov

                echo "<p>";
                echo "Navodilo:<br />";
                echo "Razredniki razredov, ki ste bili skupaj na taboru ali v šoli v naravi vnesite enake podatke (datum od, datum do, kraj, vrsta), ker se bodo potem pri pregledu podatki združevali, možno pa je kreirati tudi spisek učencev s podatki za prijavo policiji.<br />";
                echo "<a href='vnosispiski.php?idd=113'>Spisek taborov</a><br />";
                echo "</p>";

                if ($VecSol > 0){
                    echo "<h2>Šola v naravi/Tabor ".$VLeto."/".($VLeto+1)." - ".$VRazred1.". ".$VParalelka." - ".$VSola."</h2>";
                }else{
                    echo "<h2>Šola v naravi/Tabor ".$VLeto."/".($VLeto+1)." - ".$VRazred1.". ".$VParalelka."</h2>";
                }
                echo "<form  name='Tabor' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='112'>";
                echo "<table border=0>";
                echo "<tr><td>Datum začetka</td><td><input name='datumzac' type='text' value='".$VDatumZac."' size='10' id='dat01'></td></tr>";
                echo "<tr><td>Datum konca</td><td><input name='datumkon' type='text' value='".$VDatumKon."' size='10' id='dat02'></td></tr>";
                echo "<tr><td>Kraj</td><td><input name='kraj' type='text' value='".$VKraj."' size=30></td></tr>";
                echo "<tr><td>Vrsta</td><td><input name='vrsta' type='text' value='".$VVrsta."' size=30></td></tr>";
                echo "<tr><td>Znesek plačila na udeleženca</td><td><input name='znesek' type='text' value='".$VZnesek."' size=10>&nbsp;EUR</td></tr>";
                for ($Indx=1;$Indx <= 7;$Indx++){
                    echo "<tr></tr>";
                }
                echo "</table><br />";

                echo "<br />Pod Opomba vpišite število dni prisotnosti - krajše bivanje (prejšnji odhod domov)<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                echo "<th>Udeležba<br /><input class='groovybutton' name='b1' type='button' value='' onClick='OznaciStolpec(this.form,1)'></th>";
                echo "<th>Brezplačno<br /><input class='groovybutton' name='b2' type='button' value='' onClick='OznaciStolpec(this.form,2)'></th>";
                echo "<th>Subvencija<br /><input class='groovybutton' name='b3' type='button' value='' onClick='OznaciStolpec(this.form,3)'></th>";
                echo "<th>Opomba</th>";
                echo "</tr>";

                for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                    $SQL = "SELECT udelezba,brezplacno,subvencija,opomba FROM tabtabori WHERE leto=".$VLeto." AND idUcenec=".$ucenci[$Indx][0];
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$ucenci[$Indx][0]."'>".$ucenci[$Indx][1]."</td>";
                        if ($R["udelezba"]){
                            echo "<td align='center'><input id='dan_1' name='udelezba".$Indx."' type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<td align='center'><input id='dan_1' name='udelezba".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["brezplacno"]){
                            echo "<td align='center'><input id='dan_2' name='brezplacno".$Indx."' type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<td align='center'><input id='dan_2' name='brezplacno".$Indx."' type='checkbox'></td>";
                        }
                        if ($R["subvencija"]){
                            echo "<td align='center'><input id='dan_3' name='subvencija".$Indx."' type='checkbox' checked='checked'></td>";
                        }else{
                            echo "<td align='center'><input id='dan_3' name='subvencija".$Indx."' type='checkbox'></td>";
                        }
                        echo "<td><input name='opomba".$Indx."' type='text' size='10' value='".$R["opomba"]."'></td>";
                        echo "</tr>";    
                    }else{
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$ucenci[$Indx][0]."'>".$ucenci[$Indx][1]."</td>";
                        echo "<td align='center'><input id='dan_1' name='udelezba".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_2' name='brezplacno".$Indx."' type='checkbox'></td>";
                        echo "<td align='center'><input id='dan_3' name='subvencija".$Indx."' type='checkbox'></td>";
                        echo "<td><input name='opomba".$Indx."' type='text' size='10' value=''></td>";
                        echo "</tr>";
                    }
                }

                echo "</table><br />";

                echo "Spremljevalci:<br />";
                for ($Indx=0;$Indx < 7;$Indx++){
                    echo "<select name='spremljevalec".$Indx."'>";
                    for ($i1=1;$i1 <= $StUciteljev;$i1++){
                        if ($VUcitelji[$i1][0]==$Spremljevalec[$Indx]){
                            echo "<option value='".$VUcitelji[$i1][0]."' selected='selected'>".$VUcitelji[$i1][1]."</option>";
                        }else{
                            echo "<option value='".$VUcitelji[$i1][0]."'>".$VUcitelji[$i1][1]."</option>";
                        }
                    }
                    echo "</select><br />";
                }
                echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                echo "</form>";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=true;
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                form.elements[i].checked=false;
                            }
                        }
                        </script>
                <?php
                echo "</body>";
                echo "</html>";
                break;
            case "113": //spisek tabori
                /* echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT tabtabordata.*,tabsola.solakratko FROM (tabtabordata ";
                $SQL .= "INNER JOIN tabrazdat ON tabtabordata.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL .= "WHERE tabtabordata.leto=".$VLeto;
                $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,oznaka";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                $TaborDat[$Indx][1]="";
                $TaborDat[$Indx][2]="";
                $TaborDat[$Indx][3]="";
                $TaborDat[$Indx][4]="";
                $TaborDat[$Indx][5]="";
                $TaborDat[$Indx][6]="";
                $TaborDat[$Indx][7]="";
                $TaborDat[$Indx][8]="";
                $TaborDat[$Indx][9]="";
                $TaborDat[$Indx][10]=$VLeto;
                $TaborDat[$Indx][11]=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($VecSol > 0){
                        $TaborDat[$Indx][1]=$R["razred"].". ".$R["paralelka"]." - ".$R["solakratko"];
                    }else{
                        $TaborDat[$Indx][1]=$R["razred"].". ".$R["paralelka"];
                    }
                    $TaborDat[$Indx][2]=$R["DatumZac"]." - ".$R["DatumKon"];
                    $TaborDat[$Indx][3]=$R["Kraj"];
                    $TaborDat[$Indx][4]=$R["Vrsta"];
                    $TaborDat[$Indx][5]=$R["Znesek"];
                    $TaborDat[$Indx][6]=$R["razred"];
                    $TaborDat[$Indx][7]=$R["paralelka"];
                    $TaborDat[$Indx][8]=$R["DatumZac"];
                    $TaborDat[$Indx][9]=$R["DatumKon"];
                    $TaborDat[$Indx][10]=$R["leto"];
                    $TaborDat[$Indx][11]=$R["idRazred"];
                    $Indx=$Indx+1;
                }
                $StRazredov=$Indx-1;

                for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                    $countT[$Indx][0]=0;
                    $countT[$Indx][1]=0;
                    $countT[$Indx][2]=0;
                    $countT[$Indx][3]=0;
                    $countT[$Indx][4]=0;
                    $countT[$Indx][5]=0;
                }
                
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabrazred.idrazred,tabtabori.* FROM ";
                $SQL = $SQL."tabrazred INNER JOIN tabtabori ON tabrazred.idUcenec=tabtabori.idUcenec ";
                $SQL = $SQL ."WHERE tabrazred.leto=".$VLeto." AND tabtabori.leto=".$VLeto;
                $SQL = $SQL ." ORDER BY tabrazred.razred,tabrazred.paralelka";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                $CompRazred=$TaborDat[$Indx][11];
                while ($R = mysqli_fetch_array($result)){
                    $VRazred=$R["idrazred"];
                    if ($VRazred != $CompRazred){
                        $Indx=$StRazredov+1;
                        for ($i1=1;$i1 <= $StRazredov;$i1++){
                            if ($VRazred==$TaborDat[$i1][11]){
                                $Indx=$i1;
                            }
                        }
                        $countT[$Indx][0]=$VRazred;
                        if ($R["Udelezba"]){    $countT[$Indx][1]=1;}
                        if ($R["Brezplacno"]){    $countT[$Indx][3]=1;}
                        if ($R["Subvencija"]){    $countT[$Indx][4]=1;}
                        $countT[$Indx][5]=1;
                        $CompRazred=$VRazred;
                    }else{
                        if ($R["Udelezba"]){    $countT[$Indx][1]=$countT[$Indx][1]+1;}
                        if ($R["Brezplacno"]){    $countT[$Indx][3]=$countT[$Indx][3]+1;}
                        if ($R["Subvencija"]){    $countT[$Indx][4]=$countT[$Indx][4]+1;}
                        $countT[$Indx][5]=$countT[$Indx][5]+1;
                    }
                }

                for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                    $countT[$Indx][2]=$countT[$Indx][5]-$countT[$Indx][1];
                }

                for ($Indx=1;$Indx <= 5;$Indx++){
                    $CountSum[$Indx]=0;
                }

                for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                    $CountSum[1]=$CountSum[1]+$countT[$Indx][1];
                    $CountSum[2]=$CountSum[2]+$countT[$Indx][2];
                    $CountSum[3]=$CountSum[3]+$countT[$Indx][3];
                    $CountSum[4]=$CountSum[4]+$countT[$Indx][4];
                    $CountSum[5]=$CountSum[5]+$countT[$Indx][5];
                }

                echo "<h2>Šola v naravi/Tabori - ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<table border=1 cellspacing=0>";
                echo "<tr bgcolor=lightcyan><th>Razred</th><th>Datum</th><th>Kraj</th><th>Vrsta</th><th>udeležencev</th><th>niso se udeležili</th><th>znesek plačila</th><th>Brezplačnih</th><th>Subvencij</th><th>Prijava<br />na CŠOD</th></tr>";
                for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td align=center bgcolor=khaki><a href='vnosispiski.php?idd=112&solskoleto=".$VLeto."&razred=".$TaborDat[$Indx][11]."'>".$TaborDat[$Indx][1]."</a></td>";
                    echo "<td align=center>".$TaborDat[$Indx][2]."</td>";
                    echo "<td align=center>".$TaborDat[$Indx][3]."</td>";
                    echo "<td align=center>".$TaborDat[$Indx][4]."</td>";
                    echo "<td align=center>".$countT[$Indx][1]."</td>";
                    echo "<td align=center>".$countT[$Indx][2]."</td>";
                    echo "<td align=center>".number_format($TaborDat[$Indx][5],2)."</td>";
                    echo "<td align=center>".$countT[$Indx][3]."</td>";
                    echo "<td align=center>".$countT[$Indx][4]."</td>";
                    echo "<td><a href='vnosispiski.php?idd=113&id=2&kraj=".$TaborDat[$Indx][3]."&zacetek=".$TaborDat[$Indx][8]."&konec=".$TaborDat[$Indx][9]."&leto=".$TaborDat[$Indx][10]."'>Spisek</a></td>";
                    echo "</tr>";
                }
                echo "<tr bgcolor=lightgreen><td>Skupaj</td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td align=center>".$CountSum[1]."</td>";
                echo "<td align=center>".$CountSum[2]."</td>";
                echo "<td></td>";
                echo "<td align=center>".$CountSum[3]."</td>";
                echo "<td align=center>".$CountSum[4]."</td>";
                echo "</tr>";
                echo "</table><br />";

                if ($Vid=="2"){
                    $SQL = "SELECT * FROM TabSola";
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $VSola=$R["SolaKratko"];
                    }
                    
                    $SQL = "SELECT * FROM tabtabordata WHERE leto=".$_GET["leto"]." AND kraj='".$_GET["kraj"]."' AND datumZac='".$_GET["zacetek"]."' AND datumKon='".$_GET["konec"]."'";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $CsodDat[$Indx][0]=$R["leto"];
                        $CsodDat[$Indx][1]=$R["razred"];
                        $CsodDat[$Indx][2]=$R["paralelka"];
                        $CsodDat[$Indx][3]=$R["Kraj"];
                        $CsodDat[$Indx][4]=$R["DatumZac"];
                        $CsodDat[$Indx][5]=$R["DatumKon"];
                        $CsodDat[$Indx][6]=$R["idRazred"];
                        $Indx=$Indx+1;
                    }
                    $StRazredov=$Indx-1;
                    
                    echo "<h2>Prijava učencev za ".$_GET["kraj"]."</h2>";
                    echo "<h3>Šola: ".$VSola."<br />";
                    echo "Prihod: ".$_GET["zacetek"]."<br />";
                    echo "Odhod: ".$_GET["konec"]."<br />";
                    echo "</h3><table border=1 cellspacing=0>";
                    echo "<tr><th>Št.</th><th>Priimek</th><th>Ime</th><th>Dat.roj.</th><th>kraj. roj.</th><th>država roj.</th></tr>";
                    $i1=1;
                    for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                        $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabtabori.*,tabucenci.priimek,tabucenci.ime,tabucenci.datroj,tabucenci.krajroj,tabucenci.drzavaroj FROM ";
                        $SQL = $SQL."(tabrazred INNER JOIN tabtabori ON tabrazred.idUcenec=tabtabori.idUcenec) ";
                        $SQL = $SQL."INNER JOIN tabucenci ON tabrazred.idUcenec =tabucenci.idUcenec " ;
                        $SQL = $SQL ."WHERE tabtabori.leto=".$CsodDat[$Indx][0]." AND idRazred=".$CsodDat[$Indx][6]." AND udelezba=true ";
                        $SQL = $SQL ." ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        
                        while ($R = mysqli_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$i1."</td>";
                            echo "<td>".mb_strtoupper($R["priimek"],$encoding)."</td>";
                            echo "<td>".mb_strtoupper($R["ime"],$encoding)."</td>";
                            $Datum=new DateTime(isDate($R["datroj"]));
                            echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
                            echo "<td>".$R["krajroj"]."</td>";
                            echo "<td>".$R["drzavaroj"]."</td>";
                            echo "</tr>";
                            $i1=$i1+1;
                        }
                    }
                    echo "</table><br />";
                }
                echo "</body>";
                echo "</html>";
                break;
            case "114": //spisek nadarjeni
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    echo "<h2>".$sole[$IndxSola][1]."</h2>";

                    echo "<h2>Spisek nadarjenih učencev in učenk</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazred.nadarjen=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk s statusom športnika</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazred.StatusSport=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk s statusom kulturnika</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazred.StatusKult=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].".".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk tujcev</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='150'>Državljanstvo</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.drzavljanstvo,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabucenci.drzavljanstvo <> 'slovensko'"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["drzavljanstvo"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk Romov</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabucenci.rom=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk vozačev</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='150'>način prihoda</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabkrajbivanja.krajbivanja,tabrazdat.* FROM ";
                    $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabkrajbivanja ON tabucenci.idKrajBivanja=tabkrajbivanja.id) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabucenci.idKrajBivanja IN (3,4,5,7,8,9,10,11)"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["krajbivanja"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk, ki ne bivajo pri starših</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='150'>Bivanje</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabbivanje.bivanje AS bbivanje,tabrazdat.* FROM ";
                    $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabbivanje ON tabucenci.Bivanje=tabbivanje.idBivanje) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabucenci.Bivanje > 0"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["bbivanje"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk ponavljalcev</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazred.ponavljalec=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center'>".$Indx."</td>";
                        echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";

                    echo "<h2>Spisek učencev in učenk iz drugih šolskih okolišev</h2>";
                    echo "<table border='1'>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='200'>Šolski okoliš</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.solskiokolis,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabucenci.SolskiOkolis,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (strlen($R["solskiokolis"]) > 0){
                            $Indx=$Indx+1;
                            echo "<tr>";
                            echo "<td align='center'>".$Indx."</td>";
                            echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                            echo "<td>".$R["solskiokolis"]."</td>";
                            echo "</tr>";
                        }
                    }

                    echo "</table>";
                    
                    //učenci, ki so se prešolali med letom
                    echo "<h2>Spisek učencev in učenk, ki so se prešolali med letom</h2>";
                    echo "<table border='1'>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='200'>Šolski okoliš</th><th>Datum začetka<br />šolanja na šoli</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.solskiokolis,tabucenci.zacsolanjasola,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]. " AND tabrazdat.razred > 0 ";
                    $SQL = $SQL . " ORDER BY tabucenci.SolskiOkolis,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (isDate($R["zacsolanjasola"])){
                            $datum=new DateTime(isDate($R["zacsolanjasola"]));
                            $d1=$datum->format('Ymd');
                            $d2=$VLeto."0901";
                            $d3=($VLeto+1)."0831";
                            if ($d1 > $d2){
                                if ($d1 <= $d3){
                                    $Indx=$Indx+1;
                                    echo "<tr>";
                                    echo "<td align='center'>".$Indx."</td>";
                                    echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                                    echo "<td>".$R["solskiokolis"]."</td>";
                                    echo "<td align='right'>".$R["zacsolanjasola"]."</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                    }
                    echo "</table>";
                    
                    //učenci, ki so odšli na drugo šolo
                    echo "<h2>Spisek učencev in učenk, ki so med letom odšli na drugo šolo</h2>";
                    echo "<table border='1'>";
                    echo "<tr><th width='20'>Št.</th><th width='250'>Ime</th><th>Datum konca<br />šolanja na šoli</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.solskiokolis,tabucenci.konsolanjasola,tabucenci.konsolanja FROM tabucenci ";
                    //$SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    //$SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    //$SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]. " AND tabrazdat.razred > 0 ";
                    $SQL = $SQL . " ORDER BY tabucenci.SolskiOkolis,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (isDate($R["konsolanjasola"])){
                            $datum=new DateTime(isDate($R["konsolanjasola"]));
                            $d1=$datum->format('Ymd');
                            $d2=$VLeto."0901";
                            $d3=($VLeto+1)."0831";
                            if ($d1 > $d2){
                                if ($d1 <= $d3){
                                    $Indx=$Indx+1;
                                    echo "<tr>";
                                    echo "<td align='center'>".$Indx."</td>";
                                    //echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                                    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                                    //echo "<td>".$R["solskiokolis"]."</td>";
                                    echo "<td align='right'>".$R["konsolanjasola"]."</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                    }

                    echo "</table>";
                    
                    //učenci, ki nimajo vpisanega datuma začetka šolanja na šoli
                    echo "<h2>Spisek učencev in učenk, ki nimajo vpisanega datuma začetka šolanja na šoli</h2>";
                    echo "<table border='1'>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabucenci.solskiokolis,tabucenci.zacsolanjasola,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$IndxSola][0]. " AND tabrazdat.razred > 0 ";
                    $SQL = $SQL . " ORDER BY tabucenci.SolskiOkolis,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (!isDate($R["zacsolanjasola"])){
                            $Indx=$Indx+1;
                            echo "<tr>";
                            echo "<td align='center'>".$Indx."</td>";
                            echo "<td align='center'>".$R["razred"].". ".$R["oznaka"]."</td>";
                            echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                            //echo "<td>".$R["solskiokolis"]."</td>";
                            //echo "<td align='right'>".$R["zacsolanjasola"]."</td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                }
                break;
            case "115": //nadarjeni
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                switch ($Vid){
                    case "1";
                        if ((strlen($_POST["ucenec"]) ==0) or (!isDate($_POST["datum"]))){
                            echo $_POST["ucenec"]."<br />".$_POST["datum"]."<br />";
                            echo "<h2>Učenec ni bil dodan!</h2>";
                        }else{
                            $SQL = "SELECT tabnadarjeni.* FROM tabnadarjeni INNER JOIN tabrazred ON tabnadarjeni.idUcenec=tabrazred.idUcenec WHERE tabrazred.leto=".$VLeto." AND tabnadarjeni.idUcenec=".$_POST["ucenec"]." ";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabnadarjeni SET idUcenec=".$_POST["ucenec"].", datum='".$_POST["datum"]."', komentar='".$_POST["komentar"]."', cas='".$Danes->format('Y-m-d H:i:s')."',vpisal='".$VUporabnik."',evidst='".$_POST["evidst"]."' WHERE id=".$R["id"];
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                }else{
                                    echo "<h2>Nadarjen učenec bil popravljen.</h2>";
                                }
                            }else{
                                $SQL = "INSERT INTO tabnadarjeni (idUcenec,datum,komentar,cas,vpisal,evidst) VALUES (".$_POST["ucenec"].",'".$_POST["datum"]."','".$_POST["komentar"]."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."','".$_POST["evidst"]."')";
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                }else{                            
                                    echo "<h2>Nadarjen učenec je bil dodan.</h2>";
                                }
                            }
                            $SQL = "UPDATE tabrazred SET nadarjen=1 WHERE idUcenec=".$_POST["ucenec"]." AND leto=".$VLeto;
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                            }
                        }
                        break;
                    case "2": //brisanje
                        $SQL = "DELETE FROM tabnadarjeni WHERE idUcenec=".$_GET["ucenec"];
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>";
                        }
                        $SQL = "UPDATE tabrazred SET nadarjen=0 WHERE idUcenec=".$_GET["ucenec"]." AND leto=".$VLeto;
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                        }
                }

                if ($Vid=="3"){
                    $SQL = "SELECT tabnadarjeni.evidst,tabnadarjeni.komentar,tabnadarjeni.datum,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "tabnadarjeni LEFT JOIN tabucenci ON tabnadarjeni.idUcenec=tabucenci.idUcenec ";
                    $SQL = $SQL . "ORDER BY priimek,ime";
                }else{
                    $SQL = "SELECT tabnadarjeni.evidst,tabnadarjeni.komentar,tabnadarjeni.datum,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                    $SQL = $SQL . "((tabnadarjeni INNER JOIN tabucenci ON tabnadarjeni.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabnadarjeni.idUcenec=tabrazred.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ";
                    $SQL = $SQL . "ORDER BY priimek,ime";
                }
                $result = mysqli_query($link,$SQL);

                echo "<h2>Spisek nadarjenih - ".$VLeto."/".($VLeto+1)."</h2>";

                echo "<form name='Nadarjeni' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='115'>";

                echo "<table border=1 cellspacing=0>";
                echo "<tr><th>Št.</th><th>Evid.št.</th><th>Učenec</th><th>Razred</th><th>Datum<br />potrditve OUZ</th><th>Komentar</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["evidst"]."</td>";
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"]."</a></td>";
                    if ($Vid=="3"){
                        echo "<td></td>";
                    }else{
                        echo "<td>".$R["razred"].". ".$R["oznaka"]." </td>";
                    }
                    echo "<td align=right>".$R["datum"]."</td>";
                    echo "<td>".$R["komentar"]."</td>";
                    echo "<td><a href='vnosispiski.php?idd=115&id=2&ucenec=".$R["iducenec"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "<tr><td></td>";
                echo "<td><input name='evidst' type='text' size='6'></td>";
                echo "<td><select name='ucenec'>";
                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.* FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                }
                echo "</select></td><td></td>";
                echo "<td><input name='datum' type='text' size='10'></td>";
                echo "<td><textarea name='komentar' cols='30' rows='1'></textarea></td>";
                echo "<td><input name='id' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
                echo "</table><br />";
                echo "</form>";
                echo "<a href='vnosispiski.php?idd=115&id=3'>Izpis vseh nadarjenih</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "116": //tujci
                /*            echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                switch ($Vid){
                    case "1":
                        if ((strlen($_POST["ucenec"])==0) or (!isDate($_POST["datum"]))){
                            echo $_POST["ucenec"]."<br />".$_POST["datum"]."<br />";
                            echo "<h2>Učenec ni bil dodan!</h2>";
                        }else{
                            $SQL = "SELECT tabtujci.* FROM tabtujci INNER JOIN tabrazred ON tabtujci.idUcenec=tabrazred.idUcenec WHERE tabrazred.leto=".$VLeto." AND tabtujci.idUcenec=".$_POST["ucenec"]." ";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabtujci SET idUcenec=".$_POST["ucenec"].", datum='".$_POST["datum"]."',komentar='".$_POST["komentar"]."', cas='".$Danes->format('Y-m-d H:i:s')."',vpisal='".$VUporabnik;
                                $SQL = $SQL . ",listina='".$_POST["listina"]."',drzavaListine='".$_POST["drzavalistine"]."',ustanovaListine='".$_POST["ustanovalistine"]."',izobProgram='".$_POST["izobprogram"]."',evidst='".$_POST["evidst"]."'";
                                $SQL = $SQL ."' WHERE id=".$R["id"];
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                }else{
                                    echo "<h2>Tuj učenec je bil popravljen.</h2>";
                                }
                            }else{
                                $SQL = "INSERT INTO tabtujci (idUcenec,datum,komentar,cas,vpisal,listina,drzavaListine,ustanovaListine,izobProgram,evidst) VALUES ";
                                $SQL = $SQL . "(".$_POST["ucenec"].",'".$_POST["datum"]."','".$_POST["komentar"]."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."'";
                                $SQL = $SQL . ",'".$_POST["listina"]."','".$_POST["drzavalistine"]."','".$_POST["ustanovalistine"]."','".$_POST["izobprogram"]."','".$_POST["evidst"]."')";
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                }else{                            
                                    echo "<h2>Tuj učenec je bil dodan.</h2>";
                                }
                            }
                        }
                        break;
                    case "2";
                        $SQL = "DELETE FROM tabtujci WHERE idUcenec=".$_GET["ucenec"];
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>";
                        }
                }

                if ($Vid=="3"){
                    $SQL = "SELECT tabtujci.*,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.drzavljanstvo FROM ";
                    $SQL = $SQL . "(tabtujci LEFT JOIN tabucenci ON tabtujci.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "ORDER BY priimek,ime";
                }else{
                    $SQL = "SELECT tabtujci.*,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.drzavljanstvo,tabrazred.* FROM ";
                    $SQL = $SQL . "(tabtujci INNER JOIN tabucenci ON tabtujci.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazred ON tabtujci.idUcenec=tabrazred.idUcenec ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." ";
                    $SQL = $SQL . "ORDER BY priimek,ime";
                }
                $result = mysqli_query($link,$SQL);

                echo "<h2>Spisek učencev-tujcev - ".$VLeto."/".($VLeto+1)."</h2>";

                echo "<form name='tujci' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='116'>";

                echo "<table border=1 cellspacing=0>";
                echo "<tr><th>Št.</th><th>Evid.št.</th><th>Učenec</th><th>Razred</th><th>Spol</th><th>Državljanstvo</th><th>Datum<br />odločbe</th><th>Listina</th><th>Država</th><th>Ustanova</th><th>Izobraževalni<br />program</th><th>Komentar</th><th>Briši</th></tr>";
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    echo "<td>".$R["evidst"]."</td>";
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"]."</a></td>";
                    if ($Vid=="3"){
                        echo "<td></td>";
                    }else{
                        echo "<td>".$R["Razred"].". ".strtolower($R["Paralelka"])." </td>";
                    }
                    if ($R["spol"]=="M"){
                        echo "<td>moški</td>";
                    }else{
                        echo "<td>ženski</td>";
                    }
                    echo "<td>".$R["drzavljanstvo"]."</td>";
                    echo "<td align=right>".$R["datum"]."</td>";
                    echo "<td>".$R["listina"]."</td>";
                    echo "<td>".$R["drzavaListine"]."</td>";
                    echo "<td>".$R["UstanovaListine"]."</td>";
                    echo "<td>".$R["izobProgram"]."</td>";
                    echo "<td>".$R["komentar"]."</td>";
                    echo "<td><a href='vnosispiski.php?idd=116&id=2&ucenec=".$R["iducenec"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                    echo "</tr>";
                    $Indx=$Indx+1;
                }
                echo "<tr><td></td>";
                echo "<td><input name='evidst' type='text' size='6'></td>";
                echo "<td><select name='ucenec'>";
                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".strtolower($R["paralelka"])."</option>";
                }
                echo "</select></td><td></td><td></td><td></td>";
                echo "<td><input name='datum' type='text' size='10'></td>";
                echo "<td><input name='listina' type='text' size='10'></td>";
                echo "<td><input name='drzavalistine' type='text' size='10'></td>";
                echo "<td><input name='ustanovalistine' type='text' size='10'></td>";
                echo "<td><input name='izobprogram' type='text' size='10'></td>";
                echo "<td><textarea name='komentar' cols='30' rows='1'></textarea></td>";
                echo "<td><input name='id' type='hidden' value='1'><input name='submit' type='submit' value='Dodaj'></td></tr>";
                echo "</table><br />";
                echo "</form>";
                echo "<a href='vnosispiski.php?idd=116&id=3'>Izpis vseh tujcev</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "117": //spisek popravci
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

                $SQL = "SELECT id,solakratko FROM tabsola";
                $result = mysqli_query($link,$SQL);
                $i=1;
                $sole=array();
                while ($R = mysqli_fetch_array($result)){
                    $sole[$i][0]=$R["id"];
                    $sole[$i][1]=$R["solakratko"];
                    $i += 1;
                }
                $StSol=$i-1;
                for ($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){
                    echo "<h2>".$sole[$IndxSola][1]."</h2>";
                    echo "<h2>Spisek učencev in učenk s polletnimi negativnimi ocenami</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Predmet</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE (tabrazred.leto=".$VLeto." AND TabOcene.leto=".$VLeto.") AND (TabOcene.OcenaPolletna='1' OR TabOcene.OcenaPolletna='Ni opravil')"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek neocenjenih učencev in učenk</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Predmet</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE (tabrazred.leto=".$VLeto." AND TabOcene.leto=".$VLeto.") AND TabOcene.Neocenjen=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk z zaključnimi negativnimi ocenami</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Predmet</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE (tabrazred.leto=".$VLeto." AND TabOcene.leto=".$VLeto.") AND (TabOcene.OcenaKoncna='1' OR TabOcene.OcenaKoncna='Ni opravil')"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk s popravnimi izpiti</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Popravni</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND TabOcene.leto=".$VLeto." AND TabOcene.Popravni=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                       echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk s predmetnimi izpiti</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Predmetni izpit</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE tabrazred.leto=".$VLeto." AND TabOcene.leto=".$VLeto." AND TabOcene.Popravni=2"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                       echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk z razrednimi izpiti</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazred.RazredniIzpit=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                     while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk, ki napredujejo z nezadostno</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazred.Napredovanje=1"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk, ki ne napredujejo</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabrazred.Napredovanje=2"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table><br />";

                    echo "<h2>Spisek učencev in učenk brez vpisanih zaključnih ocen</h2>";
                    echo "<table border=1>";
                    echo "<tr><th width='20'>Št.</th><th width='20'>Razred</th><th width='250'>Ime</th><th width='50'>Predmet</th></tr>";

                    $SQL = "SELECT tabrazred.iducenec,tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime,tabpredmeti.oznaka FROM ";
                    $SQL = $SQL . "(((tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN TabOcene ON tabrazred.idUcenec=TabOcene.idUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabpredmeti ON TabOcene.idPredmet=tabpredmeti.id) ";
                    $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL . " WHERE (tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto.") AND (tabocene.ocenakoncna='') AND tabocene.neocenjen=0 AND tabocene.popravni=0"." AND tabrazdat.idsola=".$sole[$IndxSola][0];
                    $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka,tabucenci.priimek,tabucenci.ime";
                    $result = mysqli_query($link,$SQL);

                    $CompUcenec=0;
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        if ($CompUcenec != $R["iducenec"]){
                            $Indx=$Indx+1;
                            $CompUcenec=$R["iducenec"];
                            echo "<td>".$Indx."</td>";
                        }else{
                            echo "<td></td>";
                        }
                        echo "<td>".$R["razred"].". ".$R["paralelka"]."</td>";
                        echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                        echo "<td>".$R["oznaka"]."</td>";
                        echo "</tr>";
                    }

                    echo "</table><br />";

                }
                echo "</body>";
                echo "</html>";
                break;
            case "118": //vpis programa
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                if ($SteviloUcencev > 0){
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $SQL="SELECT * FROM tabprogrammss WHERE idUcenec=".$_POST["ucenec_".$Indx];
                        $result = mysqli_query($link,$SQL);
                            
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabprogrammss SET ";
                            $SQL=$SQL."odDatum='".$_POST["od_".$Indx]."',";
                            $SQL=$SQL."doDatum='".$_POST["do_".$Indx]."',";
                            $SQL=$SQL."program='".$_POST["program_".$Indx]."',";
                            
                            $SQL1 = "SELECT razred,uspeh FROM tabrazred WHERE idUcenec=".$_POST["ucenec_".$Indx]." AND leto=".$VLeto;
                            $result1 = mysqli_query($link,$SQL1);
                            if ($R1 = mysqli_fetch_array($result1)){
                                if ($R1["razred"]==9){
                                    $SQL=$SQL."uspeh='".number_format($R1["uspeh"],2)."',";
                                }else{
                                    $SQL=$SQL."uspeh='".$_POST["uspeh_".$Indx]."',";
                                }
                            }else{
                                $SQL=$SQL."uspeh='".$_POST["uspeh_".$Indx]."',";
                            }
                            
                            $SQL=$SQL."opomba='".$_POST["opomba_".$Indx]."'";
                            $SQL=$SQL." WHERE idUcenec=".$_POST["ucenec_".$Indx];
                            if (!($result = mysqli_query($link,$SQL))){
                                echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                            }
                        }else{
                            $SQL = "SELECT ZacSolanja,KonSolanja FROM tabucenci WHERE idUcenec=".$_POST["ucenec_".$Indx];
                            $result = mysqli_query($link,$SQL);
                            
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "INSERT INTO tabprogrammss (idUcenec,odDatum,doDatum,program,uspeh,opomba) VALUES (";
                                $SQL=$SQL.$_POST["ucenec_".$Indx].",";
                                if (strlen($_POST["od_".$Indx])==0){
                                    $SQL=$SQL."'".$R["ZacSolanja"]."',";
                                }else{
                                    $SQL=$SQL."'".$_POST["od_".$Indx]."',";
                                }
                                if (strlen($_POST["do_".$Indx])==0){
                                    $SQL=$SQL."'".$R["KonSolanja"]."',";
                                }else{
                                    $SQL=$SQL."'".$_POST["do_".$Indx]."',";
                                }
                                $SQL=$SQL."'".$_POST["program_".$Indx]."',";
                                
                                $SQL1 = "SELECT razred,uspeh FROM tabrazred WHERE idUcenec=".$_POST["ucenec_".$Indx]." AND leto=".$VLeto;
                                $result1 = mysqli_query($link,$SQL1);
                                if ($R1 = mysqli_fetch_array($result1)){
                                    if ($R1["razred"]==9){
                                        $SQL=$SQL."'".number_format($R1["uspeh"],2)."',";
                                    }else{
                                        $SQL=$SQL."'".$_POST["uspeh_".$Indx]."',";
                                    }
                                }else{
                                    $SQL=$SQL."'".$_POST["uspeh_".$Indx]."',";
                                }
                                $SQL=$SQL."'".$_POST["opomba_".$Indx]."'";
                                $SQL=$SQL.")";
                                if (!($result = mysqli_query($link,$SQL))){
                                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                }
                            }
                        }
                    }
                    //echo "<h2>Podatki SO vpisani!</h2>";
                }

                $SQL = "SELECT * FROM tabsifrantprogram";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VProgram[$Indx][1]=$R["program"];
                    $VProgram[$Indx][2]=$R["opis"];
                    $Indx=$Indx+1;
                }
                $StProgramov=$Indx-1;

                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime, tabrazred.razred,tabrazred.paralelka, tabprogrammss.*,tabsola.solakratko FROM ";
                $SQL = $SQL . "(((tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec = tabrazred.IdUcenec)  ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id) ";
                $SQL = $SQL . "LEFT JOIN tabprogrammss ON tabucenci.IdUcenec=tabprogrammss.IdUcenec ";
                $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto;
                $SQL = $SQL . " ORDER BY tabrazdat.idsola,tabrazred.razred,tabrazred.paralelka,tabucenci.Priimek,tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                //'Izpis podatkov
                echo "<h2>Izobraževalni program</h2>";
                echo "<form  name='UcenciProgram' method=post action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='118'>";
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                echo "<th>Program</th>";
                echo "<th>od</th>";
                echo "<th>do</th>";
                echo "<th>uspeh</th>";
                echo "<th>opomba</th>";
                echo "</tr>";

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$Indx."</td>";
                    if ($VecSol > 0){
                        echo "<td><input name='ucenec_".$Indx."' type='hidden' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]." - ".$R["solakratko"]."</td>";
                    }else{
                        echo "<td><input name='ucenec_".$Indx."' type='hidden' value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</td>";
                    }
                    
                    echo "<td>";
                    if (strlen($R["program"]) > 0){
                        echo "<select name='program_".$Indx."'>";
                        for ($i1=1;$i1 <= $StProgramov;$i1++){
                            if ($R["program"]==$VProgram[$i1][1]){
                                echo "<option value='".$VProgram[$i1][1]."' selected='selected'>".$VProgram[$i1][1]." - ".$VProgram[$i1][2]."</option>";
                            }else{
                                echo "<option value='".$VProgram[$i1][1]."'>".$VProgram[$i1][1]." - ".$VProgram[$i1][2]."</option>";
                            }
                        }
                        echo "</select>";
                    }else{
                        echo "<select name='program_".$Indx."'>";
                        for ($i1=1;$i1 <= $StProgramov;$i1++){
                            if ($i1==1){
                                echo "<option value='".$VProgram[$i1][1]."' selected='selected'>".$VProgram[$i1][1]." - ".$VProgram[$i1][2]."</option>";
                            }else{
                                echo "<option value='".$VProgram[$i1][1]."'>".$VProgram[$i1][1]." - ".$VProgram[$i1][2]."</option>";
                            }
                        }
                        echo "</select>";
                    }
                    echo "</td>";
                    
                    echo "<td><input name='od_".$Indx."' type='text' value='".$R["odDatum"]."' size='10'></td>";
                    echo "<td><input name='do_".$Indx."' type='text' value='".$R["doDatum"]."' size='10'></td>";
                    echo "<td><input name='uspeh_".$Indx."' type='text' value='".$R["uspeh"]."' size='10'></td>";
                    echo "<td><input name='opomba_".$Indx."' type='text' value='".$R["opomba"]."' size='10'></td>";
                    echo "</tr>";
                    $Indx = $Indx+1;
                } 

                $SteviloUcencev=$Indx-1;
                echo "</table>";
                echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                echo "</form>";
                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "119": //izpis razreda Untis
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                if ($VRazred== 0){
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.datroj,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    if (isset($_POST["zaleto"])){
                        $SQL = $SQL . "WHERE tabrazdat.leto=". $VLeto." AND tabrazdat.razred < 9";
                    }else{
                        $SQL = $SQL . "WHERE tabrazdat.leto=". $VLeto." AND tabrazdat.razred >= 1";
                    }
                    $SQL = $SQL ." ORDER BY tabrazdat.idsola,tabucenci.Priimek, tabucenci.Ime, tabrazdat.razred,tabrazdat.oznaka";
                }else{
                    $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.spol,tabucenci.datroj,tabrazdat.* FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE idRazred=" . $VRazred;
                    $SQL = $SQL ." ORDER BY tabucenci.Priimek, tabucenci.Ime, tabrazdat.razred,tabrazdat.oznaka";
                }

                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT * FROM tabuntisucenci WHERE iducenec=".$R["iducenec"];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        echo "&quot;".$R1["UcenecUntis"]."&quot;;"; // '1 ime
                    }else{
                        echo "&quot;".mb_substr($R["priimek"],0,3,$encoding).mb_substr($R["ime"],0,1,$encoding)."&quot;;"; // '1 ime
                    }
                    echo "&quot;".$R["priimek"]."&quot;;"; // '2 polno ime
                    echo ";"; // '3 tekst
                    echo ";"; // '4 opis
                    echo ";"; // '5 statistika 1
                    echo ";"; // '6 statistika 2
                    //'7 oznaka (spol M/W)
                    if ($R["spol"]=="M"){
                        echo "&quot;M&quot;;";
                    }else{
                        echo "&quot;W&quot;;";
                    }
                    
                    echo "&quot;".$R["ime"]."&quot;;"; // '8 rojstno ime
                    echo ";"; // '9 številka učenca
                    if (isset($_POST["zaleto"])){
                        echo "&quot;".($R["razred"]+1).$R["oznaka"]."&quot;;"; // '10 razred
                    }else{
                        echo "&quot;".$R["razred"].$R["oznaka"]."&quot;;"; // '10 razred
                    }
                    if ($R["spol"]=="M"){
                        echo "&quot;2&quot;;"; // '11 spol (1=ženski, 2=moški)
                    }else{
                        echo "&quot;1&quot;;"; // '11 spol (1=ženski, 2=moški)
                    }
                    echo ";"; // '12 oznaka optimizacije (izb. predmeti)
                    //'13 rojstni datum LLLLMMDD
                    $Datum=new DateTime(isDate($R["datroj"]));
                    echo "&quot;".$Datum->format('Ymd');
                    echo "&quot;;<br />";
                    $Indx=$Indx+1;
                }
                echo "</body>";
                echo "</html>";
                break;
            case "120": //popravi izostanki razred
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                if (isset($_POST["mesec"])){
                    $VMesec=$_POST["mesec"];
                    $VRazred=$_POST["razred"];
                    if (!is_numeric($VMesec)){
                        $VMesec=$Danes->format('n');
                    }
                }else{
                    $VLeto = $_SESSION["leto"];
                    $VRazred = $_SESSION["razred"];
                    $VMesec = $_SESSION["mesec"];
                }
                if (!CheckDostop("Redov",$VUporabnik)){ 
                    header ("Location: nepooblascen.htm");
                }else{
                    //izbor razreda, meseca
                    echo "<form name='malice' method=post action='vnosispiski.php'>";
                    echo "<input name='idd' type='hidden' value='120'>";
                    echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    echo "<table border=0>";
                    echo "<tr><th>razred</th><th>mesec</th></tr>";
                    
                    echo "<tr>";
                    $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." ORDER BY idsola,razred,oznaka";
                    $result = mysqli_query($link,$SQL);

                    echo "<td><select name='razred'  onchange='this.form.submit()'>";
                //    echo "<tr><td>Izberi razred</td><td><select name='razred'>";
                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        if ($VecSol > 0){
                            if ($VRazred==$R["id"] ){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }
                        }else{
                            if ($VRazred==$R["id"] ){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                        $Indx=$Indx+1;
                    }
                    echo "<option value='0'>Vsi</option>";
                    echo "</select>";

                    echo "</td>";

                    echo "<td>";
                    echo "<select name='mesec' onchange='this.form.submit()'>";
                    for ($Indx=1;$Indx <= 12;$Indx++){
                        if (($Indx != 7) && ($Indx != 8) ){
                            if ($Indx==$VMesec){
                                echo "<option value=".$Indx." selected='selected'>".$Indx."</option>";
                            }else{
                                echo "<option value=".$Indx.">".$Indx."</option>";
                            }
                        }
                    }
                    echo "</select>";
                    echo "</td>";
                    echo "</tr>";
                    echo "</table>";
                    //    echo "<input name='submit' type='submit' value='Pošlji'>";
                    //echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
                    echo "</form>";
                    
                    switch ($Vid){
                        case "1";
                            $StUcencev=$_POST["stucencev"];
                            //echo $VLeto.", ".$VRazred.", ".$VMesec.", ".$StUcencev."<br >";

                            for ($Indx=0;$Indx <= $StUcencev;$Indx++){
                                $ucenec[$Indx] = $_POST["ucenec".$Indx];
                                $VOpraviceno[$Indx]=$_POST["opraviceno".$Indx];
                                if (!is_numeric($VOpraviceno[$Indx])){
                                    $VOpraviceno[$Indx]=0;
                                }
                                $VNeopraviceno[$Indx]=$_POST["neopravicene".$Indx];
                                if (!is_numeric($VNeopraviceno[$Indx])){ 
                                    $VNeopraviceno[$Indx]=0;
                                }
                            }

                            for ($Indx=0;$Indx <= $StUcencev;$Indx++){
                                if ($ucenec[$Indx] > 0){
                                    $SQL="SELECT * FROM tabprisotnost WHERE IdUcenec=".$ucenec[$Indx]." AND leto=".$VLeto." AND mesec=".$VMesec;
                                    $result = mysqli_query($link,$SQL);

                                    if ($R = mysqli_fetch_array($result)){
                                        $SQL="UPDATE  tabprisotnost SET Opraviceno=". $VOpraviceno[$Indx] .",neopraviceno=". $VNeopraviceno[$Indx] .", vpisal='".$VUporabnik."', datum='".$Danes->format('Y-m-d H:i:s')."' WHERE IdUcenec=". $ucenec[$Indx] ." AND leto=".$VLeto." AND mesec=".$VMesec;
                                    }else{
                                        if ($VMesec > 0){
                                            $SQL="INSERT INTO tabprisotnost (IdUcenec,leto,mesec,Opraviceno,Neopraviceno,vpisal,datum) VALUES (".$ucenec[$Indx].",".$VLeto.",".$VMesec.",".$VOpraviceno[$Indx].",".$VNeopraviceno[$Indx].",'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                                        }
                                    }
                                    if (!($result = mysqli_query($link,$SQL))){
                                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                                    }
                                }
                            }

                            if ($Opravila==1){
                                $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    $Ucitelj=$R["iducitelj"];
                                }else{
                                    $Ucitelj=0;
                                }
                                
                                $SQL = "SELECT tabdeldogodek.id FROM ";
                                $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                                $SQL = $SQL . "WHERE tabdogodek.Dogodek='Vnos odsotnosti' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                                $result = mysqli_query($link,$SQL);

                                $Indx=1;
                                while ($R = mysqli_fetch_array($result)){
                                    $VDogodki[$Indx]=$R["id"];
                                    $Indx=$Indx+1;
                                }
                                $StDogodkov=$Indx-1;

                                for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                                    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                                    $result = mysqli_query($link,$SQL);
                                }
                            }
                    }
                    $SQL = "SELECT tabrazdat.*, tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                    $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    $SQL = $SQL . "WHERE tabrazred.idRazred=" . $VRazred ;
                    $SQL = $SQL . " ORDER BY tabucenci.Priimek,tabucenci.Ime";
                    $result = mysqli_query($link,$SQL);

                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Ucenci[$Indx][0]=$R["iducenec"];
                        $Ucenci[$Indx][1]=$R["priimek"].", ".$R["ime"];
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                        $Ucenci[$Indx][2]=0;
                        $Ucenci[$Indx][3]=0;
                        $Indx=$Indx+1;
                    }
                    $SteviloUcencev=$Indx-1;

                    for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                        $SQL = "SELECT * FROM tabprisotnost WHERE leto=".$VLeto." AND mesec=".$VMesec." AND iducenec=".$Ucenci[$Indx][0];
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $Ucenci[$Indx][2]=$R["Opraviceno"];
                            $Ucenci[$Indx][3]=$R["Neopraviceno"];
                        }    
                    }

                    //Izpis razrednih podatkov
                    echo "<h2>Vpis izostankov</h2>";
                    echo "<form  name='UcenciUspehRazred' method=post action='vnosispiski.php'>";
                    echo "<input name='idd' type='hidden' value='120'>";
                    echo "<input name='id' type='hidden' value='1'>";
                    echo "<br /><table border=1>";
                    echo "<tr><th>Št.</th><th>Leto</th><th>Mesec</th><th>Razred</th><th>Učenec</th>";
                    echo "<th>Opravičene</th><th>Neopravičene</th>";
                    if ($eDnevnik){
                        echo "<th>Dr</th><th>Op</th><th>NO</th>";
                    }
                    echo "</tr>";
                    echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                    echo "<input type='hidden' name='mesec' value='".$VMesec."'>";
                    echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                    echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                    for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                        echo "<tr><td>".($Indx+1)."</td>";
                        echo "<td>".$VLeto."/".($VLeto+1)."</td>";
                        echo "<td>".$VMesec."</td>";
                        echo "<td>".$VRazred1.". ". $VParalelka."</td>";
                        echo "<td><input name=ucenec".$Indx." type=hidden value=".$Ucenci[$Indx][0].">".$Ucenci[$Indx][1]."</td>";
                        echo "<td><input name='opraviceno".$Indx."' value='".$Ucenci[$Indx][2]."' size=5></td>";
                        echo "<td><input name='neopravicene".$Indx."' value='".$Ucenci[$Indx][3]."' size=5></td>";
                        if ($eDnevnik){
                            echo "<td align='center'>";
                            $SQL = "SELECT count(status) AS cstat FROM tabodsotnostuc WHERE leto=".$VLeto." AND iducenec=".$Ucenci[$Indx][0]." AND month(datum)=".$VMesec." AND status=0";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["cstat"];
                            }
                            echo "</td>";
                            echo "<td align='center'>";
                            $SQL = "SELECT count(status) AS cstat FROM tabodsotnostuc WHERE leto=".$VLeto." AND iducenec=".$Ucenci[$Indx][0]." AND month(datum)=".$VMesec." AND status=1";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["cstat"];
                            }
                            echo "</td>";
                            echo "<td align='center'>";
                            $SQL = "SELECT count(status) AS cstat FROM tabodsotnostuc WHERE leto=".$VLeto." AND iducenec=".$Ucenci[$Indx][0]." AND month(datum)=".$VMesec." AND status=2";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
                                echo $R1["cstat"];
                            }
                            echo "</td>";
                        }
                        echo "</tr>";
                    } 
                    echo "</table>";

                    echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                    echo "</form>";
                    echo "<a href='vnosispiski.php?idd=121&razred=".$VRazred."'>Letni pregled izostankov</a><br />";
                    echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."'>Redovalnica</a><br />";
                    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                    echo "</body>";
                    echo "</html>";
                }
                break;
            case "121": //izpis izostanki - razred
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                $SQL = "SELECT * FROM tabdnipouka WHERE leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VDniPouka[1]=$R["m1"];
                    $VDniPouka[2]=$R["m2"];
                    $VDniPouka[3]=$R["m3"];
                    $VDniPouka[4]=$R["m4"];
                    $VDniPouka[5]=$R["m5"];
                    $VDniPouka[6]=$R["m6"];
                    $VDniPouka[7]=$R["m7"];
                    $VDniPouka[8]=$R["m8"];
                    $VDniPouka[9]=$R["m9"];
                    if ($VRazred1 < 9){
                        $VDniPouka[10]=$R["m10"];
                    }else{
                        $VDniPouka[10]=$R["m109"];
                    }
                }

                $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . " WHERE tabrazdat.id=" . $VRazred ;
                $SQL = $SQL ." ORDER BY tabucenci.Priimek,tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci[$Indx][0]=$R["iducenec"];
                    $Ucenci[$Indx][1]=$R["priimek"].", ".$R["ime"];
                    for ($Indx0=2;$Indx0 <= 26;$Indx0++){
                        $Ucenci[$Indx][$Indx0]=0;
                    }
                    $Indx=$Indx+1;
                }
                $SteviloUcencev=$Indx-1;
                
                $SQL = "SELECT tabprisotnost.iducenec,tabprisotnost.mesec,opraviceno,neopraviceno FROM ";
                $SQL = $SQL . "((tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "LEFT JOIN tabprisotnost ON tabrazred.IdUcenec=tabprisotnost.IdUcenec) ";
                $SQL = $SQL . "WHERE tabrazred.idrazred=" . $VRazred ." AND tabprisotnost.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                while ($R = mysqli_fetch_array($result)){
                    for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                        if ($R["iducenec"]==$Ucenci[$Indx][0]){
                            $Indx0=2+2*($R["mesec"]-1);
                            $Ucenci[$Indx][$Indx0]=$R["opraviceno"];
                            $Ucenci[$Indx][$Indx0+1]=$R["neopraviceno"];
                        }
                   }
                }
                
                //Izpis razrednih podatkov
                echo "<h2>Izpis izostankov - ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<h2>".$VRazred1.". ".$VParalelka."</h2>";
                echo "<br /><table border=1>";
                echo "<tr><th>Št.</th><th>Učenec</th><th>9</th><th></th><th>10</th><th></th><th>11</th><th></th><th>12</th><th></th><th>1</th><th></th><th>2</th><th></th><th>3</th><th></th><th>4</th><th></th><th>5</th><th></th><th>6</th><th></th><th>1. pol.</th><th></th><th>2. pol.</th><th></th><th>Skupaj</th><th></th></tr>";
                echo "<tr><th></th><th></th>";
                for ($Indx=1;$Indx <= 13;$Indx++){
                    echo "<th>Opr.</th><th>Neopr.</th>";
                }
                echo "</tr>";

                for ($Indx=0;$Indx <= 2;$Indx++){
                    for ($Indx0=0;$Indx0 <= 31;$Indx0++){
                        $Izostanki[$Indx][$Indx0]=0;
                    }
                }

                for ($Indx=0;$Indx <= $SteviloUcencev;$Indx++){
                        $Izostanki[0][26]=$Ucenci[$Indx][18]+$Ucenci[$Indx][20]+$Ucenci[$Indx][22]+$Ucenci[$Indx][24]+$Ucenci[$Indx][2]+$Ucenci[$Indx][4]+$Ucenci[$Indx][6]+$Ucenci[$Indx][8]+$Ucenci[$Indx][10]+$Ucenci[$Indx][12];
                        $Izostanki[0][27]=$Ucenci[$Indx][19]+$Ucenci[$Indx][21]+$Ucenci[$Indx][23]+$Ucenci[$Indx][25]+$Ucenci[$Indx][3]+$Ucenci[$Indx][5]+$Ucenci[$Indx][7]+$Ucenci[$Indx][9]+$Ucenci[$Indx][11]+$Ucenci[$Indx][13];
                        $Izostanki[0][28]=$Ucenci[$Indx][18]+$Ucenci[$Indx][20]+$Ucenci[$Indx][22]+$Ucenci[$Indx][24]+$Ucenci[$Indx][2];
                        $Izostanki[0][29]=$Ucenci[$Indx][19]+$Ucenci[$Indx][21]+$Ucenci[$Indx][23]+$Ucenci[$Indx][25]+$Ucenci[$Indx][3];
                        $Izostanki[0][30]=$Ucenci[$Indx][4]+$Ucenci[$Indx][6]+$Ucenci[$Indx][8]+$Ucenci[$Indx][10]+$Ucenci[$Indx][12];
                        $Izostanki[0][31]=$Ucenci[$Indx][5]+$Ucenci[$Indx][7]+$Ucenci[$Indx][9]+$Ucenci[$Indx][11]+$Ucenci[$Indx][13];
                        echo "<tr>";
                        echo "<td>".($Indx+1)."</td><td>".$Ucenci[$Indx][1]."</td>";
                        echo "<td align=center>".$Ucenci[$Indx][18]."</td><td align=center>".$Ucenci[$Indx][19]."</td>"; //  'mesec=9
                        echo "<td align=center>".$Ucenci[$Indx][20]."</td><td align=center>".$Ucenci[$Indx][21]."</td>"; //  'mesec=10
                        echo "<td align=center>".$Ucenci[$Indx][22]."</td><td align=center>".$Ucenci[$Indx][23]."</td>"; //  'mesec=11
                        echo "<td align=center>".$Ucenci[$Indx][24]."</td><td align=center>".$Ucenci[$Indx][25]."</td>"; //  'mesec=12
                        echo "<td align=center>".$Ucenci[$Indx][2]."</td><td align=center>".$Ucenci[$Indx][3]."</td>"; //  'mesec=1
                        echo "<td align=center>".$Ucenci[$Indx][4]."</td><td align=center>".$Ucenci[$Indx][5]."</td>"; //  'mesec=2
                        echo "<td align=center>".$Ucenci[$Indx][6]."</td><td align=center>".$Ucenci[$Indx][7]."</td>"; //  'mesec=3
                        echo "<td align=center>".$Ucenci[$Indx][8]."</td><td align=center>".$Ucenci[$Indx][9]."</td>"; //  'mesec=4
                        echo "<td align=center>".$Ucenci[$Indx][10]."</td><td align=center>".$Ucenci[$Indx][11]."</td>"; //  'mesec=5
                        echo "<td align=center>".$Ucenci[$Indx][12]."</td><td align=center>".$Ucenci[$Indx][13]."</td>"; //  'mesec=6
                        echo "<td align=center>".$Izostanki[0][28]."</td><td align=center>".$Izostanki[0][29]."</td>"; //  'skupaj
                        echo "<td align=center>".$Izostanki[0][30]."</td><td align=center>".$Izostanki[0][31]."</td>"; //  'skupaj
                        echo "<td align=center>".$Izostanki[0][26]."</td><td align=center>".$Izostanki[0][27]."</td>"; //  'skupaj
                        echo "</tr>";
                        for ($Indx0=2;$Indx0 <= 26;$Indx0++){
                            $Izostanki[0][$Indx0]=$Izostanki[0][$Indx0]+$Ucenci[$Indx][$Indx0];
                        }
                } 
                echo "<tr>";
                echo "<td></td><td><b>Skupaj</b></td>";
                echo "<td align=center>".$Izostanki[0][18]."</td><td align=center>".$Izostanki[0][19]."</td>"; //  'mesec=9
                echo "<td align=center>".$Izostanki[0][20]."</td><td align=center>".$Izostanki[0][21]."</td>"; //  'mesec=10
                echo "<td align=center>".$Izostanki[0][22]."</td><td align=center>".$Izostanki[0][23]."</td>"; //  'mesec=11
                echo "<td align=center>".$Izostanki[0][24]."</td><td align=center>".$Izostanki[0][25]."</td>"; //  'mesec=12
                echo "<td align=center>".$Izostanki[0][2]."</td><td align=center>".$Izostanki[0][3]."</td>"; //  'mesec=1
                echo "<td align=center>".$Izostanki[0][4]."</td><td align=center>".$Izostanki[0][5]."</td>"; //  'mesec=2
                echo "<td align=center>".$Izostanki[0][6]."</td><td align=center>".$Izostanki[0][7]."</td>"; //  'mesec=3
                echo "<td align=center>".$Izostanki[0][8]."</td><td align=center>".$Izostanki[0][9]."</td>"; //  'mesec=4
                echo "<td align=center>".$Izostanki[0][10]."</td><td align=center>".$Izostanki[0][11]."</td>"; //  'mesec=5
                echo "<td align=center>".$Izostanki[0][12]."</td><td align=center>".$Izostanki[0][13]."</td>"; //  'mesec=6
                echo "<td align=center></td><td align=center></td>" ;
                echo "<td align=center></td><td align=center></td>" ;
                $Izostanki[1][26]=$Izostanki[0][18]+$Izostanki[0][20]+$Izostanki[0][22]+$Izostanki[0][24]+$Izostanki[0][2]+$Izostanki[0][4]+$Izostanki[0][6]+$Izostanki[0][8]+$Izostanki[0][10]+$Izostanki[0][12];
                $Izostanki[1][27]=$Izostanki[0][19]+$Izostanki[0][21]+$Izostanki[0][23]+$Izostanki[0][25]+$Izostanki[0][3]+$Izostanki[0][5]+$Izostanki[0][7]+$Izostanki[0][9]+$Izostanki[0][11]+$Izostanki[0][13];
                echo "<td align=center>".$Izostanki[1][26]."</td><td align=center>".$Izostanki[1][27]."</td>"; //  'skupaj
                echo "</tr>";
                echo "<tr>";
                echo "<td></td><td><b>Skupaj izostankov</b></td>";
                echo "<td align=center>".($Izostanki[0][18]+$Izostanki[0][19])."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".($Izostanki[0][20]+$Izostanki[0][21])."</td><td align=center></td>"; //  'mesec=10
                echo "<td align=center>".($Izostanki[0][22]+$Izostanki[0][23])."</td><td align=center></td>"; //  'mesec=11
                echo "<td align=center>".($Izostanki[0][24]+$Izostanki[0][25])."</td><td align=center></td>"; //  'mesec=12
                echo "<td align=center>".($Izostanki[0][2]+$Izostanki[0][3])."</td><td align=center></td>"; //  'mesec=1
                echo "<td align=center>".($Izostanki[0][4]+$Izostanki[0][5])."</td><td align=center></td>"; //  'mesec=2
                echo "<td align=center>".($Izostanki[0][6]+$Izostanki[0][7])."</td><td align=center></td>"; //  'mesec=3
                echo "<td align=center>".($Izostanki[0][8]+$Izostanki[0][9])."</td><td align=center></td>"; //  'mesec=4
                echo "<td align=center>".($Izostanki[0][10]+$Izostanki[0][11])."</td><td align=center></td>"; //  'mesec=5
                echo "<td align=center>".($Izostanki[0][12]+$Izostanki[0][13])."</td><td align=center></td>"; //  'mesec=6
                echo "<td align=center></td><td align=center></td>"; 
                echo "<td align=center></td><td align=center></td>";
                echo "<td align=center>".($Izostanki[1][26]+$Izostanki[1][27])."</td><td align=center></td>"; //  'skupaj
                echo "</tr>";

                echo "<tr>";
                echo "<td></td><td><b>Šolskih dni ob koncu pouka</b></td>";
                echo "<td align=center>".$VDniPouka[1]."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".$VDniPouka[2]."</td><td align=center></td>"; //  'mesec=10
                echo "<td align=center>".$VDniPouka[3]."</td><td align=center></td>"; //  'mesec=11
                echo "<td align=center>".$VDniPouka[4]."</td><td align=center></td>"; //  'mesec=12
                echo "<td align=center>".$VDniPouka[5]."</td><td align=center></td>"; //  'mesec=1
                echo "<td align=center>".$VDniPouka[6]."</td><td align=center></td>"; //  'mesec=2
                echo "<td align=center>".$VDniPouka[7]."</td><td align=center></td>"; //  'mesec=3
                echo "<td align=center>".$VDniPouka[8]."</td><td align=center></td>"; //  'mesec=4
                echo "<td align=center>".$VDniPouka[9]."</td><td align=center></td>"; //  'mesec=5
                echo "<td align=center>".$VDniPouka[10]."</td><td align=center></td>"; //  'mesec=6
                $VDniPoukaSum=0;
                for ($Indx=1;$Indx <= 10;$Indx++){
                    $VDniPoukaSum=$VDniPoukaSum+$VDniPouka[$Indx];
                }
                echo "<td align=center></td><td align=center></td>";
                echo "<td align=center></td><td align=center></td>";
                echo "<td align=center>".$VDniPoukaSum."</td><td align=center></td>"; //  'skupaj
                echo "</tr>";    

                echo "<tr>";
                echo "<td></td><td><b>Procent prisotnosti</b></td>";
                echo "<td align=center>".number_format(100-(($Izostanki[0][18]+$Izostanki[0][19])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[1]),2)."</td><td align=center></td>";  
                echo "<td align=center>".number_format(100-(($Izostanki[0][20]+$Izostanki[0][21])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[2]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][22]+$Izostanki[0][23])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[3]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][24]+$Izostanki[0][25])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[4]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][2]+$Izostanki[0][3])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[5]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][4]+$Izostanki[0][5])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[6]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][6]+$Izostanki[0][7])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[7]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][8]+$Izostanki[0][9])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[8]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][10]+$Izostanki[0][11])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[9]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center>".number_format(100-(($Izostanki[0][12]+$Izostanki[0][13])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPouka[10]),2)."</td><td align=center></td>"; //  'mesec=9
                echo "<td align=center></td><td align=center></td>";
                echo "<td align=center></td><td align=center></td>";
                echo "<td align=center>".number_format(100-(($Izostanki[1][26]+$Izostanki[1][27])*100/($SteviloUcencev+1)/Faktor($VRazred1)/$VDniPoukaSum),2)."</td><td align=center></td>"; //  'mesec=9
                echo "</tr>";
                        
                echo "</table>";

                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<a href='izpisredovalnice.php?id=4&razred=".$VRazred."'>Redovalnica</a><br />";
                echo "<a href='izborrazreda.php?id=odsotnost'>Na vnos izostankov</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "122": //pogovorne ure - vnos
                echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<link rel='stylesheet' type='text/css' media='all' href='jsDatePick_ltr.min.css' >";
                echo "<script type='text/javascript' src='jsDatePick.min.1.3.js'></script>";
                echo "<script type=\"text/javascript\">";
                echo "    window.onload = function(){";
                echo "        var Danes = new Date();";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_1\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_2\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_3\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_4\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_5\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_6\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_7\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_8\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_9\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_10\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_11\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_12\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_13\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_14\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "        new JsDatePick({";
                echo "            useMode:2,";
                echo "            target:\"dat_15\",";
                echo "            dateFormat:\"%d.%m.%Y\",";
                echo "            yearsRange:[1940,2080],";
                echo "            limitToToday:false";
                echo "        });";
                echo "    };";
                echo "</script>";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    $n=$VLevel;
			    include('menu_func.inc');
			    include ('menu.inc');
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VRazred1=$R["razred"];
                    $VParalelka=$R["oznaka"];
                }

                if ($SteviloUcencev > 0){
                    $SQL = "SELECT * FROM tabgudatum WHERE idRazred=".$VRazred;
                    $result = mysqli_query($link,$SQL);
                    
                    for ($i1=1;$i1 <= 5;$i1++){
                        $VDatumRS[$i1]=$_POST["rs".$i1."d"];
                        if (!isDate($VDatumRS[$i1])){
                            $VDatumRS[$i1]="";
                        }
                    }
                    for ($i1=1;$i1 <= 10;$i1++){
                        $VDatumGU[$i1]=$_POST["gu".$i1."d"];
                        if (!isDate($VDatumGU[$i1])){
                            $VDatumGU[$i1]="";
                        }
                    }
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabgudatum SET ";
                        for ($i1=1;$i1 <= 5;$i1++){
                            $SQL = $SQL . "rs".$i1."d='".$VDatumRS[$i1]."',";
                        }
                        for ($i1=1;$i1 <= 10;$i1++){
                            $SQL = $SQL . "gu".$i1."d='".$VDatumGU[$i1]."',";
                        }
                        $SQL = $SQL . "vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                    }else{
                        $SQL = "INSERT INTO tabgudatum (";
                        for ($i1=1;$i1 <= 5;$i1++){
                            $SQL = $SQL . "rs".$i1."d,";
                        }
                        for ($i1=1;$i1 <= 10;$i1++){
                            $SQL = $SQL . "gu".$i1."d,";
                        }
                        $SQL = $SQL . "vpisal,cas,leto,razred,paralelka,idRazred) VALUES (";
                        for ($i1=1;$i1 <= 5;$i1++){
                            $SQL = $SQL . "'".$VDatumRS[$i1]."',";
                        }
                        for ($i1=1;$i1 <= 10;$i1++){
                            $SQL = $SQL . "'".$VDatumGU[$i1]."',";
                        }
                        $SQL = $SQL . "'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$VRazred1.",'".$VParalelka."',".$VRazred.")";
                    }
                    if (!($result = mysqli_query($link,$SQL))){
                        echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                    }
                    
                    for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                        $ucenec=$_POST["ucenec".$Indx];
                        $SQL="SELECT * FROM tabgovorilne WHERE leto=".$VLeto." AND idUcenec=".$ucenec;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabgovorilne SET ";
                            for ($i1=1;$i1 <= 5;$i1++){
                                if (isset($_POST["rs".$Indx."u".$i1])){
                                    $SQL=$SQL." rs".$i1."=true,";
                                }else{
                                    $SQL=$SQL." rs".$i1."=false,";
                                }
                            }
                            for ($i1=1;$i1 <= 10;$i1++){
                                if (isset($_POST["gu".$Indx."u".$i1])){
                                    $SQL=$SQL." gu".$i1."=true,";
                                }else{
                                    $SQL=$SQL." gu".$i1."=false,";
                                }
                            }
                            $SQL=$SQL."vpisal='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$R["id"];
                        }else{
                            $SQL = "INSERT INTO tabgovorilne (";
                            for ($i1=1;$i1 <= 5;$i1++){
                                $SQL=$SQL." rs".$i1.",";
                            }
                            for ($i1=1;$i1 <= 10;$i1++){
                                $SQL=$SQL." gu".$i1.",";
                            }
                            $SQL=$SQL."vpisal,cas,leto,idUcenec) VALUES (";
                            for ($i1=1;$i1 <= 5;$i1++){
                                if (isset($_POST["rs".$Indx."u".$i1])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                            }
                            for ($i1=1;$i1 <= 10;$i1++){
                                if (isset($_POST["gu".$Indx."u".$i1])){
                                    $SQL=$SQL."true,";
                                }else{
                                    $SQL=$SQL."false,";
                                }
                            }
                            $SQL=$SQL."'".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."',".$VLeto.",".$ucenec.")";
                        }
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                        }
                    }

                    if ($Opravila==1){
                        $SQL = "SELECT iducitelj FROM tabrazred WHERE idRazred=".$VRazred;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["iducitelj"];
                        }else{
                            $Ucitelj=0;
                        }
                        
                        $SQL = "SELECT tabdeldogodek.id FROM ";
                        $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                        $SQL = $SQL . "WHERE tabdogodek.Dogodek='Sodelovanje s starši' AND leto=".$VLeto." AND idUcitelj=".$Prijavljeni." AND opravljeno=false";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            $VDogodki[$Indx]=$R["id"];
                            $Indx=$Indx+1;
                        }
                        $StDogodkov=$Indx-1;

                        for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                            $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                            $result = mysqli_query($link,$SQL);
                        }
                    }

                }

                $SQL = "SELECT * FROM tabgudatum WHERE idRazred=".$VRazred;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    for ($i1=1;$i1 <= 5;$i1++){
                        $VDatumRS[$i1]=$R["rs".$i1."d"];
                    }
                    for ($i1=1;$i1 <= 10;$i1++){
                        $VDatumGU[$i1]=$R["gu".$i1."d"];
                    }
                }else{
                    for ($i1=1;$i1 <= 5;$i1++){
                        $VDatumRS[$i1]="";
                    }
                    for ($i1=1;$i1 <= 10;$i1++){
                        $VDatumGU[$i1]="";
                    }
                }

                $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.iducenec,tabucenci.priimek,tabucenci.ime FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabucenci ON tabrazred.idUcenec=tabucenci.idUcenec ";
                $SQL = $SQL . "WHERE tabrazred.idrazred=".$VRazred." ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Indx=$Indx+1;
                    $ucenci[$Indx][0]=$R["iducenec"];
                    $ucenci[$Indx][1]=$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"];
                }
                $SteviloUcencev=$Indx;

                //Izpis razrednih podatkov
                echo "<h2>Sodelovanje s starši ".$VLeto."/".($VLeto+1)."</h2>";
                echo "<form  name='UcenciUspehRazred' method='post' action='vnosispiski.php'>";
                echo "<input name='idd' type='hidden' value='122'>";
                echo "<br /><table border=1>";
                echo "<tr>";
                echo "<th></th>";
                echo "<th></th>";
                echo "<th>Roditeljski<br />sestanki</th>";
                for ($Indx=1;$Indx <= 4;$Indx++){
                    echo "<th></th>";
                }
                echo "<th>Pogovorne<br />ure</th>";
                for ($Indx=1;$Indx <= 9;$Indx++){
                    echo "<th></th>";
                }
                echo "</tr>";

                echo "<tr>";
                echo "<th>Št.</th>";
                echo "<th>Ime</th>";
                for ($Indx=1;$Indx <= 5;$Indx++){
                    if ($VDatumRS[$Indx] != ""){
                        echo "<th><input name='rs".$Indx."d' type='text' value='".$VDatumRS[$Indx]."' size='7' id='dat_$Indx'></th>";
                    }else{
                        echo "<th><input name='rs".$Indx."d' type='text' value='' size='7' id='dat_$Indx'></th>";
                    }
                }
                for ($Indx=1;$Indx <= 10;$Indx++){
                    if ($VDatumGU[$Indx] != ""){
                        echo "<th><input name='gu".$Indx."d' type='text' value='".$VDatumGU[$Indx]."' size='7' id='dat_".($Indx+5)."'></th>";
                    }else{
                        echo "<th><input name='gu".$Indx."d' type='text' value='' size='7' id='dat_".($Indx+5)."'></th>";
                    }
                }
                echo "<th>Ime</th>";
                echo "</tr>";

                for ($Indx=1;$Indx <= $SteviloUcencev;$Indx++){
                    $SQL = "SELECT * FROM tabgovorilne WHERE leto=".$VLeto." AND idUcenec=".$ucenci[$Indx][0];
                    $result = mysqli_query($link,$SQL);

                    if ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$ucenci[$Indx][0]."'>".$ucenci[$Indx][1]."</td>";
                        for ($i1=1;$i1 <= 5;$i1++){
                            if ($R["rs".$i1]){
                                echo "<td><input name='rs".$Indx."u".$i1."' type='checkbox' checked='checked'></td>";
                            }else{
                                echo "<td><input name='rs".$Indx."u".$i1."' type='checkbox'></td>";
                            }
                        }
                        for ($i1=1;$i1 <= 10;$i1++){
                            if ($R["gu".$i1]){
                                echo "<td><input name='gu".$Indx."u".$i1."' type='checkbox' checked='checked'></td>";
                            }else{
                                echo "<td><input name='gu".$Indx."u".$i1."' type='checkbox'></td>";
                            }
                        }
                        echo "<td>".$ucenci[$Indx][1]."</td>";
                        echo "</tr>";
                    }else{
                        echo "<tr>";
                        echo "<td>".$Indx."</td>";
                        echo "<td><input name='ucenec".$Indx."' type='hidden' value='".$ucenci[$Indx][0]."'>".$ucenci[$Indx][1]."</td>";
                        for ($i1=1;$i1 <= 5;$i1++){
                            echo "<td><input name='rs".$Indx."u".$i1."' type='checkbox'></td>";
                        }
                        for ($i1=1;$i1 <= 10;$i1++){
                            echo "<td><input name='gu".$Indx."u".$i1."' type='checkbox'></td>";
                        }
                        echo "<td>".$ucenci[$Indx][1]."</td>";
                        echo "</tr>";
                    }
                }
                echo "</table>";
                echo "<input type='hidden' name='stucencev' value='".$SteviloUcencev."'>";
                echo "<input type='hidden' name='razred' value='".$VRazred."'>";
                echo "<input name='submit' type='submit' value='Pošlji'></form><br /><br />";

                echo "</form>";

                echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "</body>";
                echo "</html>";
                break;
            case "123": //izpis uspeh dolžniki
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                echo "<h2>Neocenjeni in učenci z zaključnimi nezadostnimi ocenami</h2>";
                $SQL = "SELECT tabocene.*,tabucenci.priimek,tabucenci.ime,tabucenci.iducenec,tabpredmeti.oznaka AS poznaka,tabpredmeti.opis,tabrazdat.razred,tabrazdat.oznaka AS roznaka,tabsola.solakratko FROM ";
                $SQL = $SQL . "((((tabocene INNER JOIN tabucenci ON tabocene.IdUcenec=tabucenci.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON tabocene.IdPredmet=tabpredmeti.Id) ";
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                $SQL = $SQL . "WHERE tabocene.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND ((tabocene.OcenaKoncna IN ('','0','1','Ni opravil')) OR (tabocene.neocenjen = 1))";
                $SQL = $SQL . "ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                echo "<table border=1 cellspacing=0>";
                echo "<tr><th>Razred</th><th>Ime</th><th>Predmet</th><th>Ocenjen</th><th>Zaključena ocena</th></tr>";
                while ($R = mysqli_fetch_array($result)){
                    echo "<tr>";
                    if ($VecSol > 0){
                        echo "<td>".$R["razred"].". ".$R["roznaka"]." - ".$R["solakratko"]."</td>";
                    }else{
                        echo "<td>".$R["razred"].". ".$R["roznaka"]."</td>";
                    }
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["iducenec"]."'>".$R["priimek"].", ".$R["ime"]."</a></td>";
                    echo "<td>".$R["poznaka"]." - ".$R["opis"]."</td>";
                    if ($R["Neocenjen"]==1){
                        echo "<td>Neocenjen</td>";
                    }else{
                        echo "<td>Ocenjen</td>";
                    }
                    echo "<td align='center'>".$R["OcenaKoncna"]."</td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "</body>";
                echo "</html>";
                break;
            case "124": //briši neocenjen
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                $SQL = "UPDATE tabocene SET Neocenjen=0 WHERE leto=".$VLeto." AND OcenaKoncna <> ''";
                if (!($result = mysqli_query($link,$SQL))){
                    echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                }

                echo "Neocenjeni pri zaključenih ocenah so brisani!<br />";
                echo "</body>";
                echo "</html>";
                break;
            case "125": //prakse
                /*            echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
                */
                if ($Vid != "1"){
                    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                    /*
                    echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
                    */
                    echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";
                }
                if (isset($_POST["praksa"])){
                    $VPraksa = $_POST["praksa"];
                }else{
                    if (isset($_GET["praksa"])){
                        $VPraksa=$_GET["praksa"];
                    }else{
                        $VPraksa = 0;
                    }
                }

                switch ($Vid){
                    case "1": //'izpis prakse
                        $SQL = "SELECT * FROM tabsola";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VSola=$R["Sola"];
                            $VNaslovSole=$R["Naslov"];
                            $VKraj=$R["Kraj"];
                        }else{
                            $VSola="";
                            $VNaslovSole="";
                            $VKraj="";
                        }
                        $SQL = "SELECT tabpraksa.* FROM tabpraksa INNER JOIN tabucitelji ON tabpraksa.mentor=tabucitelji.idUcitelj WHERE tabpraksa.id=".$VPraksa;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VLeto=$R["Leto"];
                            $VMentor=$R["Mentor"];
                            $VPraksa=$R["Praksa"];
                            $VPredmeti=$R["Predmeti"];
                            $VStudentov=$R["studentov"];
                            $VUstanova=$R["ustanova"];
                            $VHospitacije=$R["hospitacije"];
                            $VNastopi=$R["nastopi"];
                            $VDrugo=$R["drugo"];
                        }
                        
                        echo "<table border='0' width='700'>";
                        echo "<tr><td>";
                        echo "<table border='0'>";
                        echo "<tr><td width='250'><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
                        echo "</table>";

                        echo "<h1>".$VPraksa."</h1>";
                        
                        echo "<h3>Mentor: ";
                        $SQL="SELECT ime,priimek FROM tabucitelji WHERE idUcitelj=".$VMentor;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo $R["ime"]." ".$R["priimek"];
                        }
                        echo "&nbsp;</h3>";
                        echo "<p>V sodelovanju z ".$VUstanova."</p>";
                        echo "<p><b>Predmeti:</b><br />";
                        if ($VPredmeti != ""){
                            $SQL="SELECT oznaka,opis FROM tabpredmeti WHERE id IN (".$VPredmeti.") ORDER BY opis";
                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                 echo $R["oznaka"]." - ".$R["opis"]."<br />";
                            }
                        }
                        echo "</p>";
                        
                        echo "<p><b>Vključenih študentov:</b> ".$VStudentov."<br />";
                        echo "<p><b>Opazovalna praksa - hospitacije:</b><br />";
                        echo $VHospitacije."</p>";
                        echo "<p><b>Nastopi študentov:</b><br />";
                        echo $VNastopi."</p>";
                        echo "<p><b>Druge oblike dela s študenti:</b><br />";
                        echo $VDrugo."</p>";
                        
                        echo "</td></tr></table><br />";
                        break;
                    case "2": //'briši
                        $SQL = "SELECT * FROM tabpraksa WHERE id=".$VPraksa;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            if (($VLevel > 1) or ($R["Mentor"]==$Prijavljeni)){
                                $SQL = "DELETE FROM tabpraksa WHERE id=".$VPraksa;
                                if (!($result = mysqli_query($link,$SQL))){
                                    die ("<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>");
                                }
                            }
                        }
                        header ("Location: vnosispiski.php?idd=125");
                        break;
                    case "3": //'vpis nove prakse
                        $VMentor=$_POST["mentor"];
                        $VPredmeti=Arr2Str($_POST["predmeti"]);
                        $VStudentov=$_POST["studentov"];
                        $VUstanova=$_POST["ustanova"];
                        $VHospitacije=$_POST["hospitacije"];
                        if (strlen($VHospitacije) > 0){
                            $VHospitacije=str_replace("'","",$VHospitacije);
                        }
                        $VNastopi=$_POST["nastopi"];
                        if (strlen($VNastopi) > 0){
                            $VNastopi=str_replace("'","",$VNastopi);
                        }
                        $VDrugo=$_POST["drugo"];
                        if (strlen($VDrugo) > 0){
                            $VDrugo=str_replace("'","",$VDrugo);
                        }
                        
                        $SQL = "INSERT INTO tabpraksa (leto,mentor,praksa,predmeti,studentov,ustanova,hospitacije,nastopi,drugo,cas,vpisal) VALUES (";
                        $SQL = $SQL . $VLeto;
                        $SQL = $SQL . ",".$VMentor;
                        $SQL = $SQL . ",'".$VPraksa."'";
                        $SQL = $SQL . ",'".$VPredmeti."'";
                        $SQL = $SQL . ",".$VStudentov;
                        $SQL = $SQL . ",'".$VUstanova."'";
                        $SQL = $SQL . ",'".$VHospitacije."'";
                        $SQL = $SQL . ",'".$VNastopi."'";
                        $SQL = $SQL . ",'".$VDrugo."'";
                        $SQL = $SQL . ",'".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . ",'".$VUporabnik."'";
                        $SQL = $SQL .")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die ("<h2>Napaka pri vpisu - podatki niso vpisani!</h2>");
                        }
                        
                        header ("Location: vnosispiski.php?idd=125");
                        break;
                    case "4": //'popravi praksa
                        $SQL="SELECT * FROM tabpraksa WHERE id=".$VPraksa;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $VLeto=$R["Leto"];
                            $VMentor=$R["Mentor"];
                            $VPraksaIme=$R["Praksa"];
                            $VPredmeti=$R["Predmeti"];
                            $VStudentov=$R["studentov"];
                            $VUstanova=$R["ustanova"];
                            $VHospitacije=$R["hospitacije"];
                            $VNastopi=$R["nastopi"];
                            $VDrugo=$R["drugo"];
                        }
                        
                        $SQL="SELECT priimek,ime FROM tabucitelji WHERE idUcitelj=".$VMentor;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Ucitelj=$R["priimek"]." ".$R["ime"];
                        }else{
                            $Ucitelj="Napaka!!!";
                        }
                        
                        echo "<h2>Popravi prakso - ".$Ucitelj.":</h2>";
                        echo "<form name='form_novapraksa' method=post action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='125'>";
                        echo "<input type='hidden' name='praksaid' value='".$VPraksa."'>";
                        echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                        echo "<input type='hidden' name='id' value='5'>";

                        echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60' value='".$VPraksaIme."'><br /><br />";
                        
                        echo "<b>Mentor:</b> ";
                        if ($VLevel > 1){
                            $SQL="SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                            $result = mysqli_query($link,$SQL);
                            echo "<select name='mentor'>";
                            while ($R = mysqli_fetch_array($result)){
                                if ($R["iducitelj"]==$VMentor){
                                    echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                                }else{
                                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                                }
                            }
                            echo "</select><br /><br />";
                        }else{
                            echo "<select name='mentor'>";
                            echo "<option value='".$VMentor."' selected='selected'>".$Ucitelj."</option>";
                            echo "</select><br /><br />";
                        }
                        
                        echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' value='".$VUstanova."'><br /><br />";
                        
                        $SQL="SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
                        $result = mysqli_query($link,$SQL);
                        echo "Predmeti:<br /><select name='predmeti[]' size='15' multiple='multiple'>";
                        while ($R = mysqli_fetch_array($result)){
                            if (vsebuje($R["id"],$VPredmeti)){
                                echo "<option value='".$R["id"]."' selected='selected'>".$R["opis"]." (".$R["oznaka"].")</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["opis"]."(".$R["oznaka"].")</option>";
                            }
                        }
                        echo "</select><br /><br/ >";
                        
                        echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' value='".$VStudentov."'><br /><br />";
                        
                        echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'>".$VHospitacije."</textarea><br />";
                        echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'>".$VNastopi."</textarea><br />";
                        echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'>".$VDrugo."</textarea><br />";

                        echo "<input name='submit' type='submit' value='Pošlji popravek'>";
                        echo "</form>";
                        break;
                    case "5": //'vpis popravljenih podatkov
                        $VMentor=$_POST["mentor"];
                        $VPredmeti=Arr2Str($_POST["predmeti"]);
                        $VStudentov=$_POST["studentov"];
                        $VUstanova=$_POST["ustanova"];
                        $VHospitacije=$_POST["hospitacije"];
                        if (strlen($VHospitacije) > 0){
                            $VHospitacije=str_replace("'","",$VHospitacije);
                        }
                        $VNastopi=$_POST["nastopi"];
                        if (strlen($VNastopi) > 0){
                            $VNastopi=str_replace("'","",$VNastopi);
                        }
                        $VDrugo=$_POST["drugo"];
                        if (strlen($VDrugo) > 0){
                            $VDrugo=str_replace("'","",$VDrugo);
                        }
                    
                        $SQL = "SELECT * FROM tabpraksa WHERE id=".$_POST["praksaid"];
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabpraksa SET ";
                            $SQL = $SQL . "mentor=".$VMentor;
                            $SQL = $SQL . ",praksa='".$VPraksa."'";
                            $SQL = $SQL . ",predmeti='".$VPredmeti."'";
                            $SQL = $SQL . ",studentov=".$VStudentov;
                            $SQL = $SQL . ",ustanova='".$VUstanova."'";
                            $SQL = $SQL . ",hospitacije='".$VHospitacije."'";
                            $SQL = $SQL . ",nastopi='".$VNastopi."'";
                            $SQL = $SQL . ",drugo='".$VDrugo."'";
                            $SQL = $SQL . ",cas='".$Danes->format('Y-m-d H:i:s')."'";
                            $SQL = $SQL . ",vpisal='".$VUporabnik."'";
                            $SQL = $SQL . " WHERE id=".$R["id"];
                            if (!($result = mysqli_query($link,$SQL))){
                                die ("<h2>Napaka pri vpisu - podatki niso vpisani!</h2>");
                            }
                        }
                        header ("Location: vnosispiski.php?idd=125");
                        break;
                    default:
                        $SQL = "SELECT tabpraksa.*,tabpraksa.id AS pid,tabucitelji.priimek,tabucitelji.ime FROM tabpraksa INNER JOIN tabucitelji ON tabpraksa.Mentor=tabucitelji.idUcitelj WHERE tabpraksa.leto=".$VLeto." ORDER BY tabpraksa.praksa";
                        $result = mysqli_query($link,$SQL);

                        if (mysqli_num_rows($result) > 0){
                            $Indx=0;
                            echo "<form name='form_praksa' method=post action='vnosispiski.php'>";
                            echo "<input name='idd' type='hidden' value='125'>";
                            echo "<h2>Izbor prakse za popravljanje</h2>";
                            echo "<select name='praksa'>";
                            while ($R = mysqli_fetch_array($result)){
                                if (($R["Mentor"]==$Prijavljeni) or ($VLevel > 1)){
                                    echo "<option value='".$R["pid"]."'>".$R["Praksa"]." - ".$R["priimek"]." ".$R["ime"]."</option>";
                                }
                            }
                            echo "</select>";
                            echo "<input type='hidden' name='id' value='4'>";
                            echo "<input name='submit' type='submit' value='Izberi prakso'>";
                            echo "</form>";
                            
                            $result = mysqli_query($link,$SQL);
                            echo "<h2>Pregled praks</h2>";
                            echo "<table border=1>";
                            echo "<tr><th>Praksa</th><th>Mentor</th><th>Predmet</th><th>Študentov</th><th>Briši</th></tr>";
                            $VSumStudentov=0;
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td><a href='vnosispiski.php?idd=125&praksa=".$R["Id"]."&id=1'>".$R["Praksa"]."</a></td>";
                                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                                
                                echo "<td>";
                                if (strlen($R["Predmeti"]) > 0){
                                    $SQL="SELECT oznaka,opis FROM tabpredmeti WHERE id IN (".$R["Predmeti"].") ORDER BY opis";
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        echo $R1["oznaka"]." - ".$R1["opis"]."<br />";
                                    }
                                }
                                echo "</td>";
                                echo "<td align='center'>".$R["studentov"]."</td>";
                                $VSumStudentov=$VSumStudentov+$R["studentov"];
                                echo "<td><a href='vnosispiski.php?idd=125&praksa=".$R["Id"]."&id=2'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                                echo "</tr>";
                            }
                            echo "</table><br />";
                            echo "Skupaj je bilo udeleženih ".$VSumStudentov." študentov.";
                            echo "<hr>";
                            
                            echo "<h2>Nova praksa - ".$VUporabnikIme.":</h2>";
                            echo "<form name='form_novapraksa' method=post action='vnosispiski.php'>";
                            echo "<input name='idd' type='hidden' value='125'>";
                            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                            echo "<input type='hidden' name='id' value='3'>";

                            echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60'><br /><br />";
                            
                            echo "<b>Mentor:</b> ";
                            if ($VLevel > 1){
                                $SQL="SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                                $result = mysqli_query($link,$SQL);
                                echo "<select name='mentor'>";
                                echo "<option value='0'>Ni izbran</option>";
                                while ($R = mysqli_fetch_array($result)){
                                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                                }
                                echo "</select><br /><br />";
                            }else{
                                echo "<select name='mentor'>";
                                echo "<option value='".$Prijavljeni."' selected='selected'>".$VUporabnikIme."</option>";
                                echo "</select><br /><br />";
                            }
                            
                            echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' ><br /><br />";
                            
                            $SQL="SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
                            $result = mysqli_query($link,$SQL);
                            echo "Predmeti:<br /><select name='predmeti[]' size='15' multiple='multiple'>";
                            while ($R = mysqli_fetch_array($result)){
                                echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                            }
                            echo "</select><br /><br/ >";
                            
                            echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' ><br /><br />";
                            
                            echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'></textarea><br />";
                            echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'></textarea><br />";
                            echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'></textarea><br />";

                            echo "<input name='submit' type='submit' value='Pošlji novo prakso'>";
                            echo "</form>";
                        }else{
                            echo "<h2>Nova praksa - ".$VUporabnikIme.":</h2>";
                            echo "<form name='form_novapraksa' method=post action='vnosispiski.php'>";
                            echo "<input name='idd' type='hidden' value='125'>";
                            echo "<input type='hidden' name='solskoleto' value='".$VLeto."'>";
                            echo "<input type='hidden' name='id' value='3'>";

                            echo "<b>Naziv prakse:</b> <input name='praksa' type='text' size='60'><br /><br />";
                            
                            echo "<b>Mentor:</b> ";
                            if ($VLevel > 1){
                                $SQL="SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                                $result = mysqli_query($link,$SQL);
                                echo "<select name='mentor'>";
                                echo "<option value='0'>Ni izbran</option>";
                                while ($R = mysqli_fetch_array($result)){
                                    echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                                }
                                echo "</select><br /><br />";
                            }else{
                                echo "<select name='mentor'>";
                                echo "<option value='".$Prijavljeni."' selected='selected'>".$VUporabnikIme."</option>";
                                echo "</select><br /><br />";
                            }
                            
                            echo "<b>Sodelovanje z ustanovo:</b> <input name='ustanova' type='text' size='40' ><br /><br />";
                            
                            $SQL="SELECT id,opis,oznaka FROM tabpredmeti WHERE prioriteta IN (0,1) ORDER BY prioriteta,opis,oznaka";
                            $result = mysqli_query($link,$SQL);
                            echo "Predmeti:<br /><select name='predmeti[]' size='15' multiple='multiple'>";
                            while ($R = mysqli_fetch_array($result)){
                                echo "<option value='".$R["id"]."'>".$R["opis"]." (".$R["oznaka"].")</option>";
                            }
                            echo "</select><br /><br/ >";
                            
                            echo "<b>Število študentov:</b> <input name='studentov' type='text' size='4' ><br /><br />";
                            
                            echo "<b>Opazovalna praksa - hospitacije:</b><br /><textarea name='hospitacije' cols='80' rows='10'></textarea><br />";
                            echo "<b>Nastopi študentov:</b><br /><textarea name='nastopi' cols='80' rows='10'></textarea><br />";
                            echo "<b>Druge oblike dela s študenti:</b><br /><textarea name='drugo' cols='80' rows='10'></textarea><br />";

                            echo "<input name='submit' type='submit' value='Pošlji novo prakso'>";
                            echo "</form>";
                        }

                }
                echo "</body>";
                echo "</html>";
                break;
            case "126": //individualni programi
                /*           echo "<html>";
                echo "<head>";
                echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
                echo "<meta http-equiv='pragma' content='no-cache' > ";
                echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
                echo "<title>Vnosi in spiski";
                echo "</title>";
                echo "<style type='text/css'>";
                echo ".break { page-break-before: always; }";
                echo "input.groovybutton";
                echo "{";
                echo "   font-size:8px;";
                echo "   font-weight:bold;";
                echo "   width:18px;";
                echo "}";
                echo "</style>";
                echo "</head>";
                echo "<body>";
			    */
                if (isset($_POST["vpis"])){
                    $VVpis = $_POST["vpis"];
                }else{
                    if (isset($_GET["vpis"])){
                        $VVpis=$_GET["vpis"];
                    }else{
                        $VVpis = 0;
                    }
                }

                if ($VVpis != "5"){
                    echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
                }

                switch ($VVpis){
                    case "2":
                        $SQL = "SELECT tabip.*,tabucitelji.priimek,tabucitelji.ime FROM tabip INNER JOIN tabucitelji ON tabip.avtor=tabucitelji.idUcitelj WHERE tabip.id=".$Vid;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VLeto = $R["leto"];
                            $VVsebina = $R["komentar"];
                            $VNaslov = $R["Naslov"];
                            $VDatum = $R["Datum"];
                            $VAvtor = $R["avtor"];
                            $VAvtorIme=$R["ime"]." ".$R["priimek"];
                            $VFile = $R["datoteka"];
                            $VUcenec = $R["ucenec"];
                            $VDovoljenja = $R["Dovoljenja"];
                        }
                        break;
                    case "1":
                        $Vid="";
                        $VVsebina = "";
                        $VNaslov = "";
                        $VDatum = "";
                        $VAvtor = $Prijavljeni;
                        $VFile = "";
                        $VUcenec = 0;
                        $VDovoljenja = "";
                        break;
                    case "3":
                        $VVsebina = $_POST["vsebina"];
                        $VNaslov = $_POST["naslov"];
                        $VVsebina = str_replace("'","",$VVsebina);
                        $VVsebina = str_replace(chr(34),"",$VVsebina);
                        $VDatum = $_POST["datum"];
                        $VAvtor = $_POST["avtor"];
                        if (isset($_POST["file1"])){
                            $VFile = $_POST["file1"];
                        }else{
                            $VFile="";
                        }
                        $VUcenec = $_POST["ucenec"];
                        $VDovoljenja=Arr2Str($_POST["dovoljenja"]);
                        
                        $SQL = "SELECT * FROM tabip WHERE id=".$Vid;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            if ($VLevel < 2){
                                if ($R["vpisal"] != $VUporabnik){
                                    if (vsebuje($Prijavljeni,$R["Dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                                        $SQL = "UPDATE tabip SET komentar='".$VVsebina."' WHERE id=".$Vid;
                                    }else{
                                        echo "<h2>Nimate pravic za popravljanje!</h2>";
                                    }
                                }else{
                                    $SQL = "UPDATE tabip SET avtor=".$VAvtor.",datum='".$VDatum."',ucenec=".$VUcenec.",naslov='".$VNaslov."', komentar='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."',dovoljenja='".$VDovoljenja."' WHERE id=".$Vid;
                                }
                            }else{
                                $SQL = "UPDATE tabip SET avtor=".$VAvtor.",datum='".$VDatum."',ucenec=".$VUcenec.",naslov='".$VNaslov."', komentar='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."',dovoljenja='".$VDovoljenja."' WHERE id=".$Vid;
                            }
                        }
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri vpisu - podatki niso vpisani!</h2>";
                        }
                        
                        $Vid="";
                        $VVsebina = "";
                        $VNaslov = "";
                        $VDatum = "";
                        $VAvtor = $Prijavljeni;
                        $VAvtorIme=$VUporabnikIme;
                        $VFile = "";
                        $VUcenec = 0;
                        $VDovoljenja = "";
                        break;
                    case "4":
                        $SQL = "SELECT * FROM tabip WHERE id=".$Vid;
                        $result = mysqli_query($link,$SQL);
                        
                        if ($R = mysqli_fetch_array($result)){
                            if ($VLevel < 2){
                                if ($R["vpisal"] != $VUporabnik){
                                    echo "<h2>Nimate pravic za brisanje!</h2>";
                                }else{
                                    $SQL = "DELETE FROM tabip WHERE id=".$Vid;
                                }
                            }else{
                                $SQL = "DELETE FROM tabip WHERE id=".$Vid;
                            }
                        }
                        if (!($result = mysqli_query($link,$SQL))){
                            echo "<h2>Napaka pri brisanju - podatki niso zbrisani!</h2>";
                        }
                        $Vid="";
                        $VVsebina = "";
                        $VNaslov = "";
                        $VDatum = "";
                        $VAvtor = $VUporabnikIme;
                        $VFile = "";
                        $VUcenec=0;
                        $VDovoljenja="";
                        break;
                    case "5":
                        $SQL = "SELECT * FROM tabsola";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VSola=$R["Sola"];
                            $VNaslovSole=$R["Naslov"];
                            $VKraj=$R["Kraj"];
                        }else{
                            $VSola="";
                            $VNaslov="";
                            $VKraj="";
                        }
                        
                        $SQL = "SELECT tabip.*,tabucitelji.priimek AS ucpriimek,tabucitelji.ime AS ucime,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabrazdat.* FROM ";
                        $SQL = $SQL . "(((tabip INNER JOIN tabucenci ON tabip.ucenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabucitelji ON tabip.avtor=tabucitelji.idUcitelj) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabip.id=".$Vid." AND tabrazdat.leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);

                        if ($R = mysqli_fetch_array($result)){
                            $VLeto = $R["leto"];
                            $VVsebina = $R["komentar"];
                            $VNaslov = $R["Naslov"];
                            $VDatum = $R["Datum"];
                            $VAvtorIme = $R["ucime"]." ".$R["ucpriimek"];
                            $VAvtor=$R["avtor"];
                            $VFile = $R["datoteka"];
                            $VDovoljenja=$R["Dovoljenja"];
                            $VUcenec=$R["ucenec"];
                            $VUcenecIme=$R["uime"]." ".$R["upriimek"].", ".$R["razred"].". ".$R["oznaka"];
                        }
                        if (vsebuje($Prijavljeni,$R["Dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                            echo "<table border='0' width='700'>";
                            echo "<tr><td width=250><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
                            echo "</table>";
                            echo "<table border='0' width='700'>";
                            echo "<tr><td><h3>Učenec: ".$VUcenecIme."</h3></td></tr>";
                            echo "<tr><td><h3>Naslov IP: ".$VNaslov."</h3></td></tr>";
                            echo "<tr><td><h3>Datum: ".$VDatum."</h3></td></tr>";
                            if ($VFile != ""){
                                echo "<tr><td><font size=3>Za ogled IP kliknite na spodnjo povezavo:<br />";
                                echo "<a href='ip/".$VFile."'>".$VFile."</a><br /><br /></font></td></tr>";
                            }
                            //'kljub temu izpiše tudi poročilo iz vsebine, če obstaja    
                            echo "<tr><td><font size='3'>".str_replace(chr(13).chr(10),"<br />",$VVsebina)."</font></td></tr>";
                            echo "<tr><td><h3>Avtor: ".$VAvtorIme."</h3></td></tr>";
                            echo "</table><br />";
                        }else{
                            echo "Nimate pooblastil za ogled teh vsebin.<br />";
                        }
                        break;
                    case "7":
                        echo "<form name='Iskanje' method=post action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='126'>";
                        echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
                        echo "<input name='vpis' type='hidden' value='7'>";
                        echo "<input name='submit' type='submit' value='Išči'>";
                        echo "</form>";
                        
                        if (isset($_POST["iskanje"])){
                            echo "<h2>Spisek IP - ".$_POST["iskanje"]."</h2>";
                            echo "<table border=1>";
                            echo "<tr><th>Št.</th><th>Učenec</th><th>Naslov</th><th>Datum</th><th>Avtor</th><th>Objavljeno</th><th>Popravi</th><th>Briši</th></tr>";

                            $SQL = "SELECT tabip.*,tabip.id AS iid,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabrazred.*,tabucitelji.*,tabrazdat.* FROM (((tabip ";
                            $SQL = $SQL . "INNER JOIN tabucenci ON tabip.ucenec=tabucenci.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                            $SQL = $SQL . "INNER JOIN tabucitelji ON tabip.avtor=tabucitelji.idUcitelj) ";
                            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                            $SQL = $SQL . "WHERE ";
                            $SQL = $SQL . "tabip.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND (";
                            $SQL = $SQL . "tabip.komentar LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabucitelji.priimek LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabucitelji.ime LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabucenci.priimek LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabucenci.ime LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabrazdat.razred LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabrazdat.oznaka LIKE '%".$_POST["iskanje"]."%'";
                            $SQL = $SQL . " OR tabip.naslov LIKE '%".$_POST["iskanje"]."%']";
                            $SQL = $SQL . " ORDER BY tabucenci.priimek,tabucenci.ime";
                            
                            $result = mysqli_query($link,$SQL);

                            $Indx=1;
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$Indx."</td>";
                                echo "<td>".$R["upriimek"]." ".$R["uime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                                if (vsebuje($Prijavljeni,$R["dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                                    echo "<td><a href='vnosispiski.php?idd=126&vpis=5&id=".$R["iid"]."'>".$R["Naslov"]."</a></td>";
                                }else{
                                    echo "<td>".$R["Naslov"]."</td>";
                                }
                                echo "<td align=right>".$R["Datum"]."</td>";
                                echo "<td>".$R["avtor"]."</td>";
                                $Datum=new DateTime(isDate($R["cas"]));
                                echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
                                if (vsebuje($Prijavljeni,$R["dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                                    echo "<td><a href='vnosispiski.php?idd=126&vpis=2.id=".$R["iid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                                    echo "<td><a href='vnosispiski.php?idd=126&vpis=4.id=".$R["iid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                    echo "<td>&nbsp;</td>";
                                }
                                echo "</tr>";
                                $Indx=$Indx+1;
                            }
                            echo "</table><br />";
                            echo "<input name='stzapisov' type='hidden' value='".($Indx-1)."'>";
                        }   
                        break;
                    default:
                        $VVsebina = "";
                        $VNaslov = "";
                        $VDatum = "";
                        $VAvtor = $Prijavljeni;
                        $VAvtorIme=$VUporabnikIme;
                        $VFile = "";
                        $VUcenec=0;
                        $VDovoljenja="";
                }

                switch ($VVpis){
                    case "5":
                    case "7":
                        echo "<br />";
                        break;
                    case "2":
                        echo "<h2>Vnos IP</h2>";
                        echo "<form name='form_vnos' method='post' action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='126'>";

                        echo "<table border=0><tr>";

                        echo "<tr><td>Šolsko leto:</td><td><a href='vnosispiski.php?idd=126&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> ".$VLeto."/".($VLeto+1)." <a href='IndProgrami.php?leto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a>";
                        echo "<input type=hidden name='leto' value='".$VLeto."'></td></tr>";
                        echo "<tr><td>Učenec:</td><td><select name='ucenec'>";
                        
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
                        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ORDER BY priimek,ime,tabrazdat.razred";
                        $result = mysqli_query($link,$SQL);
                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            if ($VecSol > 0){
                                if ($VUcenec=$R["iducenec"]){
                                    echo "<option value='".$R["iducenec"]."' selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }else{
                                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }
                            }else{
                                if ($VUcenec=$R["iducenec"]){
                                    echo "<option value='".$R["iducenec"]."' selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }else{
                                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }
                            }
                            $Indx=$Indx+1;
                        }
                        echo "</select></td></tr>";
                        echo "<tr><td>Naslov:</td><td><input name='naslov' type='text' size='40' value='".$VNaslov."'></td></tr>";
                        echo "<tr><td>Datum:</td><td><input name='datum' type='text' size='10' value='".$VDatum."'></td></tr>";
                        echo "<tr><td>Avtor:</td><td><select name='avtor'>";
                        echo "<option value='".$VAvtor."'>".$VAvtorIme."</option>";
                        echo "</td></tr>";
                        echo "<tr><td>Dovoljen dostop:<br />S Ctrl in klikom <br />označite več učiteljev</td><td><select name='dovoljenja[]' size='15' multiple>";
                        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE (status > 0) AND (idVzgojnoDelo IN (1,2)) ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            if (vsebuje($R["iducitelj"],$VDovoljenja)){
                                echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }else{
                                echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
                            }
                            $Indx=$Indx+1;
                        }
                        echo "</select></td></tr>";
                        echo "<input name='povezava' type='hidden' value='/'></td></tr>";
                        echo "</table>";

                        echo "<br /><b>Komentarji</b> (zgolj besedilo, brez urejanja (krepko,ležeče, ...) in tabel)<br />";
                        
                        echo "<textarea id='txt1' name='vsebina' cols='80' rows='20'>".$VVsebina."</textarea><br />";
                        echo "<input type='hidden' name='vpis' value='3'>"; // 'popravi;
                        echo "<input type='hidden' name='id' value='".$Vid."'>"; // 'popravi
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form><br /><br />";
                        break;
                    default:
                        echo "<h2>Vnos IP</h2>";
                        echo "<form name='form_vnos' method='post' ENCTYPE='multipart/form-data' action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='127'>";
                        /*
                        echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                        echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                        echo "<input name='level' type='hidden' value='".$VLevel."'>";
                         */
                        echo "<table border=0><tr>";

                        echo "<tr><td>Šolsko leto:</td><td><a href='vnosispiski.php?idd=126&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> ".$VLeto."/".($VLeto+1)." <a href='vnosispiski.php?idd=126&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a>";
                        echo "<input type=hidden name='leto' value='".$VLeto."'></td></tr>";
                        echo "<tr><td>Učenec:</td><td><select name='ucenec'>";
                        echo "<option value='0'>&nbsp;</option>";
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazdat.*,tabsola.solakratko FROM ";
                        $SQL = $SQL . "((tabucenci INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." ORDER BY priimek,ime,tabrazdat.razred";
                        $result = mysqli_query($link,$SQL);
                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            if ($VecSol > 0){
                                if ($VUcenec=$R["iducenec"]){
                                    echo "<option value='".$R["iducenec"]."' selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }else{
                                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                                }
                            }else{
                                if ($VUcenec=$R["iducenec"]){
                                    echo "<option value='".$R["iducenec"]."' selected='selected'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }else{
                                    echo "<option value='".$R["iducenec"]."'>".$R["priimek"]." ".$R["ime"].", ".$R["razred"].". ".$R["oznaka"]."</option>";
                                }
                            }
                            $Indx=$Indx+1;
                        }
                        echo "</select></td></tr>";
                        echo "<tr><td>Naslov programa:</td><td><input name='naslov' type='text' size='40' value='".$VNaslov."'></td></tr>";
                        echo "<tr><td>Datum:</td><td><input name='datum' type='text' size='10' value='".$VDatum."'></td></tr>";
                        echo "<tr><td>Avtor:</td><td><select name='avtor'>";
                        echo "<option value='".$VAvtor."'>".$VAvtorIme."</option>";
                        echo "</td></tr>";
                        echo "<tr><td>Datoteka:</td><td><input name='File1' type='file' size='40' value='".$VFile."'>";
                        echo "<input name='Povezava' type='hidden' value='/'></td></tr>";
                        echo "</table>";

                        echo "<br /><b>Komentarji</b> (zgolj besedilo, brez urejanja (krepko,ležeče, ...) in tabel)<br />";
                        
                        echo "<textarea id='txt1' name='vsebina' cols='80' rows='20'>".$VVsebina."</textarea><br />";
                        if ($Vid != ""){
                            echo "<input type='hidden' name='vpis' value='3'>"; // 'popravi
                            echo "<input type='hidden' name='id' value='".$Vid."'>"; // 'popravi
                        }else{
                            echo "<input type='hidden' name='vpis' value='1'>"; // 'nov vpis
                        }
                        echo "<input name='submit' type='submit' value='Pošlji'>";
                        echo "</form><br /><br />";

                        echo "<form name='Iskanje' method=post action='vnosispiski.php'>";
                        echo "<input name='idd' type='hidden' value='126'>";
                        echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
                        echo "<input name='vpis' type='hidden' value='7'>";
                        echo "<input name='submit' type='submit' value='Išči'>";
                        echo "</form>";
                        
                        echo "<h2>Spisek IP</h2>";
                        echo "<table border=1>";
                        echo "<tr><th>Št.</th><th>Učenec</th><th>Naslov</th><th>Datum</th><th>Avtor</th><th>Objavljeno</th><th>Popravi/Dovoljenja</th><th>Briši</th></tr>";

                        $SQL = "SELECT tabip.*,tabip.id AS iid,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucitelji.priimek AS ucpriimek,tabucitelji.ime AS ucime,tabrazdat.* FROM (((tabip ";
                        $SQL = $SQL . "INNER JOIN tabucenci ON tabip.ucenec=tabucenci.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
                        $SQL = $SQL . "INNER JOIN tabucitelji ON tabip.avtor=tabucitelji.idUcitelj) ";
                        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                        $SQL = $SQL . "WHERE tabip.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." ORDER BY tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);

                        $Indx=1;
                        while ($R = mysqli_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$Indx."</td>";
                            echo "<td>".$R["upriimek"]." ".$R["uime"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
                            if (vsebuje($Prijavljeni,$R["Dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                                echo "<td><a href='vnosispiski.php?idd=126&vpis=5&id=".$R["iid"]."'>".$R["Naslov"]."</a></td>";
                            }else{
                                echo "<td>".$R["Naslov"]."</td>";
                            }
                            echo "<td align=right>".$R["Datum"]."</td>";
                            echo "<td>".$R["ucpriimek"]." ".$R["ucime"]."</td>";
                            $Datum=new DateTime(isDate($R["cas"]));
                            echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
                            if (vsebuje($Prijavljeni,$R["Dovoljenja"]) or ($R["avtor"]==$Prijavljeni) or ($VLevel > 1)){
                                echo "<td><a href='vnosispiski.php?idd=126&vpis=2&id=".$R["iid"]."'><img src='img/m_edit1.gif' border='0' alt='Popravi'></a></td>";
                                echo "<td><a href='vnosispiski.php?idd=126&vpis=4&id=".$R["iid"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                                echo "<td>&nbsp;</td>";
                            }
                            echo "</tr>";
                            $Indx=$Indx+1;
                        }
                        echo "</table><br />";
                }
                echo "</body>";
                echo "</html>";
                break;
            case "127": //vpis individualnega programa
                $uploaded=false;
                $allowedExts = array("doc", "docx","pdf","rtf");
                $Preneseno=$_FILES["file"];
                $extension = explode(".", $Preneseno["name"]);
                $extension = end($extension);
                $extension = strtolower($extension);
                if (//(($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain") || ($_FILES["file"]["type"] == "application/vnd.ms-excel")) &&
                    ($_FILES["file"]["size"] < 4000000)
                    && in_array($extension, $allowedExts)){
                        if ($_FILES["file"]["error"] > 0){
                            echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                        }else{
                            echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                            echo "Type: " . $_FILES["file"]["type"] . "<br />";
                            echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                            echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
                     
                            if (file_exists("dato/" . $_FILES["file"]["name"])){
                                echo $_FILES["file"]["name"] . " already exists. ";
                                move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                                echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                                $uploaded=true;
                            }else{
                                move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                                echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                                $uploaded=true;
                            }
                       }
                }else{
                    echo "Invalid file";
                }
                
                $VVsebina = $_POST["vsebina"];
                $VNaslov = $_POST["naslov"];
                $VVsebina = str_replace("'","",$VVsebina);
                $VVsebina = str_replace(chr(34),"",$VVsebina);
                $VDatum = $_POST["datum"];
                $VAvtor = $_POST["avtor"];
                $VFile = $_POST["file1"];
                $VUcenec = $_POST["ucenec"];
                $VDovoljenja=Arr2Str($_POST["dovoljenja"]);
                
                $SQL = "SELECT * FROM tabip WHERE ucenec=".$VUcenec." AND avtor=".$VAvtor." AND datum='".$VDatum."' AND leto=".$VLeto;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    if ($VLevel < 2){
                        if ($R["vpisal"] != $VUporabnik) {
                            echo "<h2>Nimate pravic za popravljanje!</h2>";
                        }else{
                            $SQL = "UPDATE tabip SET komentar='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$R["id"];
                        }
                    }else{
                        $SQL = "UPDATE tabip SET komentar='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."' WHERE id=".$R["id"];
                    }
                    if (!($result = mysqli_query($link,$SQL))){
                        die ("<h2>Napaka pri vpisu - podatki niso vpisani!</h2>");
                    }
                }else{
                    $SQL = "INSERT INTO tabip (leto,naslov,ucenec,datum,avtor,komentar,cas,vpisal,datoteka,dovoljenja) VALUES (".$VLeto.",'".$VNaslov."',".$VUcenec.",'".$VDatum."',".$VAvtor.",'".$VVsebina."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."','".$VDatoteka."','".$VDovoljenja."')";
                    if (!($result = mysqli_query($link,$SQL))){
                        die ("<h2>Napaka pri vpisu - podatki niso vpisani!</h2>");
                    }
                }
                header ("Location: vnosispiski.php?idd=126");
                break;
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>
