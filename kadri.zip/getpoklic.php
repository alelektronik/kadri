<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<?php

if (isset($_GET["iskanje"])){
    $Isci=explode(" ", $_GET["iskanje"]);
    $VIskanje=$Isci[0];
    $VIskanje=$_GET["iskanje"];
    //echo $VUcenec[0]."<br />";

    if (strlen($VIskanje) > 0){
        echo "Najdeno na iskalni niz - ".$VIskanje."<br />";
        //echo "<table class='condensed' border=1>";
        
        $SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev WHERE";
        $SQL = $SQL . "(sifrakat LIKE '%".$VIskanje."%'";
        $SQL = $SQL . " OR deskriptor LIKE '%".$VIskanje."%'";
        $SQL = $SQL . ")";
        $SQL = $SQL ." AND sifraravni=5 ORDER BY sifrakat";
        $result = mysqli_query($link,$SQL);

        echo "<select name='poklic'>";
        if (mysqli_num_rows($result) > 0){
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["sifrakat"]."'>".$R["sifrakat"]." - ".$R["deskriptor"]."</option>";
            }
            
        }else{
            $SQL = "SELECT sifrakat,deskriptor FROM tabsifrantpoklicev WHERE solstvo=1";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["sifrakat"]."'>".$R["sifrakat"]." - ".$R["deskriptor"]."</option>";
            }
        }
        echo "</select>";
    }else{
        echo "Vpišite več znakov!<br />";
    }
    //echo "</td></tr>";
}
mysqli_close($link);
?>
