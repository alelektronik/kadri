<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Urnik
</title>
    <script>
     function potrditevNadomescanja(str)
     {
     var person = prompt("Vnesite vašo kodo", "");
     //if (person != null) {
     //   document.getElementById("demo").innerHTML =
     //   "Hello " + person + "! How are you today?";
     //}
     if (str=="")
       {
       //document.getElementById("txtHint").innerHTML="";
       return;
       } 
     if (window.XMLHttpRequest)
       {// code for IE7+, Firefox, Chrome, Opera, Safari
       xmlhttp=new XMLHttpRequest();
       }
     else
       {// code for IE6, IE5
       xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
       }
     xmlhttp.onreadystatechange=function()
       {
       if (xmlhttp.readyState==4 && xmlhttp.status==200)
         {
         document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
         }
       }
     xmlhttp.open("GET","potrdinadom.php?nadom="+str+"&uporabnik="+person,true);
     xmlhttp.send();
     }
     </script>
</head>
<body>

<?php
if (isset($_POST["leto"])) {
    $VLeto=$_POST["leto"];
}else{
    if (isset($_GET["leto"])){
        $VLeto=$_GET["leto"];
    }else{
        $VLeto=$Danes->format('Y');
    }
}

if (isset($_POST["mesec"])) {
    $VMesec=$_POST["mesec"];
}else{
    if (isset($_GET["mesec"])){
        $VMesec=$_GET["mesec"];
    }else{
        $VMesec=$Danes->format('n');
    }
}
if (isset($_POST["dan"])) {
    $VDan=$_POST["dan"];
}else{
    if (isset($_GET["dan"])){
        $VDan=$_GET["dan"];
    }else{
        $VDan=$Danes->format('j');
    }
}

$DanObracuna=$VLeto."-".$VMesec."-".$VDan;
if (!isDate($DanObracuna)){
    $DanObracuna=new DateTime(now);
    $VLeto=$DanObracuna->format('Y');
    $VMesec=$DanObracuna->format('n');
    $VDan=$DanObracuna->format('j');
}else{
    $DanObracuna=new DateTime($DanObracuna);
}

$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $ucitelj[$Indx][0]=$R["iducitelj"];
    $ucitelj[$Indx][1]=$R["priimek"]." ".$R["ime"];
    $ucitelj[$Indx][2]=true;
    $Indx=$Indx+1;
}
$ucitelj[$Indx][0]=-1;
$ucitelj[$Indx][1]="Anglisti";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=-2;
$ucitelj[$Indx][1]="Slavisti";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=-3;
$ucitelj[$Indx][1]="Matematiki";
$ucitelj[$Indx][2]=true;
$Indx=$Indx+1;
$ucitelj[$Indx][0]=0;
$ucitelj[$Indx][1]="Ni izbran";
$ucitelj[$Indx][2]=false;
$StUciteljev=$Indx;

if ($VMesec > 8){
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
}else{
    $SQL = "SELECT * FROM tabrazdat WHERE leto=".($VLeto-1)." ORDER BY razred,oznaka";
}    
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $razred[$Indx][0]=$R["razred"].". ".$R["oznaka"];
    $razred[$Indx][1]=$R["id"];
    $Indx=$Indx+1;
}
$StRazredov=$Indx-1;

$SQL = "SELECT * FROM tabprostor";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Prostor[$Indx][0]=$R["IdProstor"];
    $Prostor[$Indx][1]=$R["Opis"];
    $Prostor[$Indx][2]=true;
    $VProstor[$R["IdProstor"]][0] = $R["IdProstor"];
    $VProstor[$R["IdProstor"]][1] = $R["Stevilka"];
    $VProstor[$R["IdProstor"]][2] = $R["Oznaka"];
    $VProstor[$R["IdProstor"]][3] = $R["Opis"];
    $Indx=$Indx+1;
}
$Prostor[$Indx][0]=-1;
$Prostor[$Indx][1]="Isti prostor";
$Prostor[$Indx][2]=false;
$StProstorov=$Indx;
$VStProstorov=$Indx-1;

$SQL = "SELECT * FROM tabpredmeti ORDER BY oznaka";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Predmet[$Indx][0]=$R["Id"];
    $Predmet[$Indx][1]=$R["Oznaka"];
    $Indx=$Indx+1;
}
$StPredmetov=$Indx-1;

$SQL = "SELECT * FROM TabNadomOblika";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
    $Nadomescanje[$Indx][0]=$R["id"];
    $Nadomescanje[$Indx][1]=$R["nadomescanje"];
    $Indx=$Indx+1;
}
$StNadomescanj=$Indx-1;

//izpis za potrjevanje nadomeščanj
echo "<br /><form accept-charset='utf-8' name='datum' method='post' action='potrjevanjenadomescanj.php'>" ;
echo "Dan <select name='dan'>";
for ($Indx=1;$Indx <= 31;$Indx++){
    if ($Indx==$VDan ){
        echo "<option value='".$Indx."' selected>".$Indx."</option>";
    }else{
        echo "<option value='".$Indx."'>".$Indx."</option>";
    }
}
echo "</select>";
echo " Mesec <select name='mesec'>";
for ($Indx=1;$Indx <= 12;$Indx++){
    if ($Indx==$VMesec ){
        echo "<option value='".$Indx."' selected>".$Indx."</option>";
    }else{
        echo "<option value='".$Indx."'>".$Indx."</option>";
    }
}
echo "</select>";
echo " Leto <select name='leto'>";
for ($Indx=$Danes->format('Y')-1;$Indx <= $Danes->format('Y')+1;$Indx++){
    if ($Indx==$VLeto ){
        echo "<option value='".$Indx."' selected>".$Indx."</option>";
    }else{
        echo "<option value='".$Indx."'>".$Indx."</option>";
    }
}
echo "</select>";
echo "<input name='id' type='hidden' value='7a'>";
echo "<input name='submit' type='submit' value='Upoštevaj ta datum'>";
echo "</form>";

/*
$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["SolaKratko"];
    $VNaslov=$R["Naslov"].", ".$R["Kraj"];
    $VKraj=$R["Kraj"];
    $VRavnatelj=$R["Ravnatelj"];
}else{
    $VSola=" ";
    $VNaslov=" ";
    $VRavnatelj=" ";
}
echo "<table border=0>";
echo "<tr><td><img src='logo1.gif' height='160'></td><td><h2>".$VSola."<br />".$VNaslov."</h2></td></tr>";
echo "</table>";
*/
echo "<h1>Nadomeščanja za dan: ".$DanObracuna->format('d.m.Y')."</h1>";
$SQL = "SELECT TabNadomescanja.*,TabNadomOblika.nadomescanje,tabpredmeti.oznaka FROM ";
$SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
$SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
$SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
$SQL = $SQL . " ORDER BY razred,paralelka,ura";
$result = mysqli_query($link,$SQL);

echo "<form accept-charset='utf-8' name='potrditve' method='post' action='VnosNadomescanje.php'>";

echo "<div id='txtHint'>";

echo "<table border=1 cellspacing=0>";
echo "<tr>";
echo "<th>Št.</th>";
echo "<th>Datum</th>";
echo "<th>Razred</th>";
echo "<th>Ura</th>";
echo "<th>Predmet</th>";
echo "<th>Prostor</th>";
echo "<th>Odsotni učitelj</th>";
echo "<th>Nadomestni učitelj</th>";
echo "<th>Nadomestni prostor</th>";
echo "<th>Dejavnost</th>";
echo "<th>Učitelj<br />potrdil</th>";
echo "</tr>";

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    if ($R["potrjeno"]){
        echo "<tr bgcolor='lightgreen'>";
    }else{
        echo "<tr>";
    }
    echo "<td align=center><br />".$Indx."<br /><br /></td>";
    echo "<td>".$R["datumNad"]."</td>";
    echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
    echo "<td align=center>".$R["ura"]."</td>";
    echo "<td>".$R["oznaka"]."</td>";
    $p=false;
    for ($i1=1;$i1 <= $StProstorov;$i1++){
        if ($Prostor[$i1][0]==$R["prostor1"] ){
            echo "<td>".$Prostor[$i1][1]."</td>";
            $p=true;
            break;
        }
    }
    if (!$p){
        echo "<td>&nbsp;</td>";
    }
    $p=false;
    for ($i1=1;$i1 <= $StUciteljev;$i1++){
        if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
            echo "<td>".$ucitelj[$i1][1]."</td>";
            $p=true;
            break;
        }
    }
    if (!$p){
        echo "<td>&nbsp;</td>";
    }
    $p=false;
    for ($i1=1;$i1 <= $StUciteljev;$i1++){
        if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
            echo "<td>".$ucitelj[$i1][1]."</td>";
            $p=true;
            break;
        }
    }
    if (!$p){
        echo "<td>&nbsp;</td>";
    }
    $p=false;
    for ($i1=1;$i1 <= $StProstorov;$i1++){
        if ($Prostor[$i1][0]==$R["prostor2"] ){
            echo "<td>".$Prostor[$i1][1]."</td>";
            $p=true;
            break;
        }
    }
    if (!$p){
        echo "<td>&nbsp;</td>";
    }
    echo "<td>".$R["nadomescanje"]."</td>";
    
    echo "<td align='center'>";
    //echo "<input name='pid_".$Indx."' type='hidden' value='".$R["id"]."'>";
    if (intval($R["ucitelj2"]) > 0){
        if ($R["potrjeno"]){
            echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' checked='checked' onchange='potrditevNadomescanja(".$R["id"].")'>";
        }else{
            echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' onchange='potrditevNadomescanja(".$R["id"].")'>";
        }
    }
    echo "</td>";
    
    echo "</tr>";
    $Indx=$Indx+1;
}
echo "</table><br />";
echo "</div>";
echo "</form>";

?>

</body>
</html>
