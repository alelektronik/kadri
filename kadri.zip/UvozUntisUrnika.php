<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
ini_set('max_execution_time', 600); 
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prenos
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("LetoUrnik");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }

        $uploaded=false;
        $allowedExts = array("txt", "csv");
        $Preneseno=$_FILES["file"];
        $extension = explode(".", $Preneseno["name"]);
        $extension = end($extension);
        $extension = strtolower($extension);
        if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain"))
            && ($_FILES["file"]["size"] < 500000)
            && in_array($extension, $allowedExts)){
                if ($_FILES["file"]["error"] > 0){
                    echo "Napaka: " . $_FILES["file"]["error"] . "<br />";
                }else{
                    echo "Naloženo: " . $_FILES["file"]["name"] . "<br />";
                    echo "Tip: " . $_FILES["file"]["type"] . "<br />";
                    echo "Velikost: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                    echo "Začasna datoteka: " . $_FILES["file"]["tmp_name"] . "<br />";
             
                    if (file_exists("dato/" . $_FILES["file"]["name"])){
                        echo $_FILES["file"]["name"] . " že obstaja. ";
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"]. "<br />";
                        $uploaded=true;
                    }else{
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Shranjeno v: " . "dato/" . $_FILES["file"]["name"]. "<br />";
                        $uploaded=true;
                    }
               }
        }else{
            echo "Napačna datoteka.". "<br />";
        }
        echo "<br />";
        if ($uploaded){
            if (isset($_POST["od"])){
                $od=$_POST["od"];
            }else{
                $Datum=new DateTime($VLeto."-09-01");
                $od=$Datum->format('Ymd');
            }
            if (isset($_POST["do"])){
                $do=$_POST["do"];
            }else{
                $Datum=new DateTime(($VLeto+1)."-06-25");
                $do=$Datum->format('Ymd');
            }
            $myFile = "dato/".$_FILES["file"]["name"];
            $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
            $indx=0;
            while(!feof($fh)){
               //echo fgets($file). "<br />";
               $Vrstica[$indx]=fgets($fh);
               $indx=$indx+1;
            }
            $StVrstic=$indx-1;
            fclose($fh);
            
            //'V DatoVsebina prebere vsebino datoteke
            //DatoVsebina=ToWin(DatoVsebina)
            $brisi = array("\"","\r\n");
            $i1=0;
            $indx0=0;
            while ($indx0 <= $StVrstic){
                if (strlen($Vrstica[$indx0] > 0)){  //izpusti prazne vrstice
                    $VUrnik[$i1]=explode(";",$Vrstica[$indx0]);
                    for ($i=0;$i < count($VUrnik[$indx0]);$i++){
                        $VUrnik[$i1][$i]=str_replace($brisi,"",$VUrnik[$i1][$i]);
                    }
                    $i1++;
                }
                $indx0++;
            }
            $StVrstic=$i1-1;

            $SQL = "SELECT idpredmet,predmetuntis FROM tabuntispredm";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                 $PredmetUntis[$i][1]=$R["idpredmet"];
                 $PredmetUntis[$i][2]=$R["predmetuntis"];
                 $i=$i+1;
            }
            $StUntisPredmetov=$i-1;
                 
            //'pobriše stari urnik
            $SQL = "DELETE FROM taburnik WHERE leto=".$VLeto." AND od=".$od." AND do=".$do;
            $result = mysqli_query($link,$SQL);

            for ($indx=0;$indx <= $StVrstic;$indx++){
	            //'izpiše urnik
	            for ($indx0=1;$indx0 <= 8;$indx0++){
	                echo $VUrnik[$indx][$indx0].", ";
	            }
	            echo "<br />";
	            
	            //'prilagoditev podatkov
	            //'razred
	            if (mb_strlen($VUrnik[$indx][1],$encoding) > 0 ){
		            $VUrnik[$indx][9]=mb_substr($VUrnik[$indx][1],0,1,$encoding);
	            }else{
		            $VUrnik[$indx][9]=0;
	            }
	            //'paralelka
	            if (mb_strlen($VUrnik[$indx][1],$encoding) > 0 ){
                    if (mb_strpos($VUrnik[$indx][1],".",0,$encoding) > 0){
                        $VUrnik[$indx][10]=mb_substr($VUrnik[$indx][1],mb_strpos($VUrnik[$indx][1],".",0,$encoding)+1,(mb_strlen($VUrnik[$indx][1],$encoding)-2),$encoding);
                    }else{
		                $VUrnik[$indx][10]=mb_substr($VUrnik[$indx][1],1,(mb_strlen($VUrnik[$indx][1],$encoding)-1),$encoding);
                    }
	            }else{
		            $VUrnik[$indx][10]="";
	            }
	            
	            //'učitelj
	            $SQL = "SELECT iducitelj FROM TabUntisUcitelj WHERE UciteljUntis='".$VUrnik[$indx][2]."'";
	            $result = mysqli_query($link,$SQL);
	            if ($R = mysqli_fetch_array($result)){
		            $VUrnik[$indx][11]=$R["iducitelj"];
	            }else{
		            $VUrnik[$indx][11]=0;
		            echo "Ne najdem učitelja: (".$VUrnik[$indx][2].") privzeto 0<br />";
	            }

	            //'predmet
	            switch ($VUrnik[$indx][3]){    //preveri ime predmeta
		            case "1SLJ":
                    case "2SLJ":
                    case "3SLJ":
                    case "4SLJ":
                    case "5SLJ":
                    case "6SLJ":
                    case "1SLO":
                    case "2SLO":
                    case "3SLO":
                    case "4SLO":
                    case "5SLO":
                    case "6SLO":
			            $VSkupina=mb_substr($VUrnik[$indx][3],0,1,$encoding);
			            if ($VSkupina > 3 ){
				            $VSkupina=$VSkupina+3;
			            }
			            $VUrnik[$indx][12]="16";
			            $VUrnik[$indx][14]=$VSkupina;
                        break;
		            case "SLJn":
                    case "SLOn":
			            $VUrnik[$indx][12]="16";
			            $VUrnik[$indx][14]=0;
                        break;
		            case "1MAT":
                    case "2MAT":
                    case "3MAT":
                    case "4MAT":
                    case "5MAT":
                    case "6MAT":
			            $VSkupina=mb_substr($VUrnik[$indx][3],0,1,$encoding);
			            if ($VSkupina > 3 ){
				            $VSkupina=$VSkupina+3;
			            }
			            $VUrnik[$indx][12]="11";
			            $VUrnik[$indx][14]=$VSkupina;
                        break;
		            case "MATn":
			            $VUrnik[$indx][12]="11";
			            $VUrnik[$indx][14]=0;
                        break;
		            case "1TJA":
                    case "2TJA":
                    case "3TJA":
                    case "4TJA":
                    case "5TJA":
                    case "6TJA":
			            $VSkupina=mb_substr($VUrnik[$indx][3],0,1,$encoding);
			            if ($VSkupina > 3 ){
				            $VSkupina=$VSkupina+3;
			            }
			            $VUrnik[$indx][12]="26";
			            $VUrnik[$indx][14]=$VSkupina;
                        break;
		            case "TJAn":
			            $VUrnik[$indx][12]="26";
			            $VUrnik[$indx][14]=0;
                        break;
		            case "ŠVZm":
			            $VUrnik[$indx][12]="20";
			            $VUrnik[$indx][14]=1;
                        break;
                    case "ŠPOm";
                        for ($i=1;$i <= $StUntisPredmetov;$i++){
                            if ($PredmetUntis[$i][2]==mb_substr($VUrnik[$indx][3],0,3,$encoding)){
                                $VUrnik[$indx][12]=$PredmetUntis[$i][1];
                                $VUrnik[$indx][14]=1;
                                break;
                            }
                        }
                        if (!isset($VUrnik[$indx][12])){
                            echo "Ne najdem predmeta: (".$VUrnik[$indx][3].") privzeto 0<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        /*        
                        $SQL = "SELECT idpredmet FROM TabUntisPredm WHERE PredmetUntis='".mb_substr($VUrnik[$indx][3],0,3,$encoding)."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VUrnik[$indx][12]=$R["idpredmet"];
                            $VUrnik[$indx][14]=1;
                        }else{
                            echo "Ne najdem predmeta: ".$VUrnik[$indx][3]."<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        */
                        break;
		            case "ŠVZf":
			            $VUrnik[$indx][12]="20";
			            $VUrnik[$indx][14]=1;
                        break;
                    case "ŠPOf":
                    case "ŠPOm":
                        for ($i=1;$i <= $StUntisPredmetov;$i++){
                            if ($PredmetUntis[$i][2]==mb_substr($VUrnik[$indx][3],0,3,$encoding)){
                                $VUrnik[$indx][12]=$PredmetUntis[$i][1];
                                $VUrnik[$indx][14]=1;
                                break;
                            }
                        }
                        if (!isset($VUrnik[$indx][12])){
                            echo "Ne najdem predmeta: (".$VUrnik[$indx][3].") privzeto 0<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        /*
                        $SQL = "SELECT idpredmet FROM TabUntisPredm WHERE PredmetUntis='".mb_substr($VUrnik[$indx][3],0,3,$encoding)."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VUrnik[$indx][12]=$R["idpredmet"];
                            $VUrnik[$indx][14]=1;
                        }else{
                            echo "Ne najdem predmeta: ".$VUrnik[$indx][3]."<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        */
                        break;
		            case "ŠVZd":
			            $VUrnik[$indx][12]="20";
			            $VUrnik[$indx][14]=2;
                        break;
                    case "ŠPOd":
                    case "ŠPOž":
                        for ($i=1;$i <= $StUntisPredmetov;$i++){
                            if ($PredmetUntis[$i][2]==mb_substr($VUrnik[$indx][3],0,3,$encoding)){
                                $VUrnik[$indx][12]=$PredmetUntis[$i][1];
                                $VUrnik[$indx][14]=2;
                                break;
                            }
                        }
                        if (!isset($VUrnik[$indx][12])){
                            echo "Ne najdem predmeta: (".$VUrnik[$indx][3].") privzeto 0<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        /*
                        $SQL = "SELECT idpredmet FROM tabuntispredm WHERE PredmetUntis='".mb_substr($VUrnik[$indx][3],0,3,$encoding)."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $VUrnik[$indx][12]=$R["idpredmet"];
                            $VUrnik[$indx][14]=2;
                        }else{
                            echo "Ne najdem predmeta: ".$VUrnik[$indx][3]."<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        */
                        break;
		            case "TIT1":
			            $VUrnik[$indx][12]="25";
			            $VUrnik[$indx][14]=1;
                        break;
		            case "TIT2":
			            $VUrnik[$indx][12]="25";
			            $VUrnik[$indx][14]=2;
                        break;
		            default:  //drugi predmeti
                        for ($i=1;$i <= $StUntisPredmetov;$i++){
                            if ($PredmetUntis[$i][2]==$VUrnik[$indx][3]){
                                $VUrnik[$indx][12]=$PredmetUntis[$i][1];
                                break;
                            }
                        }
                        if (!isset($VUrnik[$indx][12])){
                            echo "Ne najdem predmeta: (".$VUrnik[$indx][3].") privzeto 0<br />";
                            $VUrnik[$indx][12]=0;
                        }
                        /*
			            $SQL = "SELECT idpredmet FROM TabUntisPredm WHERE PredmetUntis='".$VUrnik[$indx][3]."'";
			            $result = mysqli_query($link,$SQL);
			            if ($R = mysqli_fetch_array($result)){
				            $VUrnik[$indx][12]=$R["idpredmet"];
			            }else{
				            echo "Ne najdem predmeta: ".$VUrnik[$indx][3]."<br />";
				            $VUrnik[$indx][12]=0;
			            }
                        */
			            $VUrnik[$indx][14]=0;
	            }
	            if (!is_numeric($VUrnik[$indx][12]) ){
		            $VUrnik[$indx][12]="0";
	            }

	            //'prostor
	            $SQL = "SELECT idprostor FROM TabUntisProstor WHERE ProstorUntis='".$VUrnik[$indx][4]."'";
	            $result = mysqli_query($link,$SQL);
	            if ($R = mysqli_fetch_array($result)){
		            $VUrnik[$indx][13]=$R["idprostor"];
	            }else{
		            echo "Ne najdem prostora: (".$VUrnik[$indx][4].") privzeto 0<br />";
		            $VUrnik[$indx][13]=0;
	            }

	            //'idRazred
	            $SQL = "SELECT id FROM tabrazdat WHERE razred=".$VUrnik[$indx][9]." AND oznaka='".$VUrnik[$indx][10]."' AND leto=".$VLeto;
	            $result = mysqli_query($link,$SQL);
	            if ($R = mysqli_fetch_array($result)){
		            $VUrnik[$indx][8]=$R["id"];
	            }else{
		            echo "Ne najdem razreda: (".$VUrnik[$indx][1].") privzeto 0<br />";
		            $VUrnik[$indx][8]=0;
	            }

	            //'vpis v taburnik
	            $SQL = "INSERT INTO taburnik (leto,ucitelj,predmet,Nivo,Razred,Paralelka,VrstaOS,DanVtednu,Ura,Prostor,idRazred,od,do) VALUES (";
	            $SQL = $SQL . $VLeto . ",";
	            $SQL = $SQL . $VUrnik[$indx][11] . ","; // 'učitelj
	            $SQL = $SQL . $VUrnik[$indx][12] . ","; // 'predmet
	            $SQL = $SQL . $VUrnik[$indx][14] . ","; // 'skupina
	            $SQL = $SQL . $VUrnik[$indx][9] . ","; // 'razred
	            $SQL = $SQL . "'".$VUrnik[$indx][10] . "',"; // 'paralelka
	            $SQL = $SQL . "9,"; // 'vrsta OŠ
	            $SQL = $SQL . $VUrnik[$indx][5] . ","; // 'dan
	            $SQL = $SQL . $VUrnik[$indx][6] . ","; // 'ura
	            $SQL = $SQL . $VUrnik[$indx][13] . ","; // 'prostor
	            $SQL = $SQL . $VUrnik[$indx][8] . ",".$od.",".$do.")"; // 'idRazred
	            if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri uvozu urnika.<br />$SQL<br />");
                }
	            
	            //echo $SQL . "<br />";
                echo "<br />";
            }

            echo "<h2>Urnik je uvožen!</h2>";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>

</body>
</html>
