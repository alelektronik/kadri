<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<?php

if (isset($_GET["iskanje"])){
    $Isci=explode(" ", $_GET["iskanje"]);
    $VIskanje=$Isci[0];
    $VIskanje=$_GET["iskanje"];
    //echo $VUcenec[0]."<br />";
    $Vid="";
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }
    switch ($Vid){
        case "1": //glede na vnos, poišče kodo ekn
            if (strlen($VIskanje) > 0){
                echo "Najdeno na iskalni niz - ".$VIskanje."<br />";
                //echo "<table class='condensed' border=1>";
                
                $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE";
                $SQL = $SQL . "(znak LIKE '%".$VIskanje."%'";
                $SQL = $SQL . " OR opis LIKE '%".$VIskanje."%'";
                $SQL = $SQL . " OR obrazlozitev LIKE '%".$VIskanje."%'";
                $SQL = $SQL . ")";
                $SQL = $SQL ." AND nivo > 2 AND opis <> '-' ORDER BY znak";
                $result = mysqli_query($link,$SQL);
                echo "<select id='klasif' name='klasif' onchange='showIskanje2()' onmouseout='pokazi()'>";
                if (mysqli_num_rows($result) > 0){
                    while ($R = mysqli_fetch_array($result)){
                        $rokhrambe='';
                        if(isset($R["rokhrambe"])) {
                            $rokhrambe=$R["rokhrambe"];
                        }
                        $trajno='';
                        if(isset($R["trajno"])) {
                            $trajno=$R["trajno"];
                        }
                        $arhivsko='';
                        if(isset($R["arhivsko"])) {
                            $arhivsko=$R["arhivsko"];
                        }
                        $obrazlozitev='';
                        if(isset($R["obrazlozitev"])) {
                            $obrazlozitev=$R["obrazlozitev"];
                        }
                        $t=$R["opis"].", rok: ".$rokhrambe.", trajno: ".$trajno.", arhivsko: ".$arhivsko."\nobrazložitev: ".$obrazlozitev;
                        echo "<option value='".$R["znak"]."' title='".$t."'>".$R["znak"]."</option>";
                    }
                    
                }else{
                    $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE aktualno=1";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        $rokhrambe='';
                        if(isset($R["rokhrambe"])) {
                            $rokhrambe=$R["rokhrambe"];
                        }
                        $trajno='';
                        if(isset($R["trajno"])) {
                            $trajno=$R["trajno"];
                        }
                        $arhivsko='';
                        if(isset($R["arhivsko"])) {
                            $arhivsko=$R["arhivsko"];
                        }
                        $obrazlozitev='';
                        if(isset($R["obrazlozitev"])) {
                            $obrazlozitev=$R["obrazlozitev"];
                        }
                        $t=$R["opis"].", rok: ".$rokhrambe.", trajno: ".$trajno.", arhivsko: ".$arhivsko."\nobrazložitev: ".$obrazlozitev;
                        echo "<option value='".$R["znak"]."' title='".$t."'>".$R["znak"]."</option>";
                    }
                }
                echo "</select>";
            }else{
                echo "<select id='klasif' name='klasif' onchange='showIskanje2()' onmouseout='pokazi()'>";
                $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE aktualno=1";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $rokhrambe='';
                    if(isset($R["rokhrambe"])) {
                        $rokhrambe=$R["rokhrambe"];
                    }
                    $trajno='';
                    if(isset($R["trajno"])) {
                        $trajno=$R["trajno"];
                    }
                    $arhivsko='';
                    if(isset($R["arhivsko"])) {
                        $arhivsko=$R["arhivsko"];
                    }
                    $obrazlozitev='';
                    if(isset($R["obrazlozitev"])) {
                        $obrazlozitev=$R["obrazlozitev"];
                    }
                    $t=$R["opis"].", rok: ".$rokhrambe.", trajno: ".$trajno.", arhivsko: ".$arhivsko."\nobrazložitev: ".$obrazlozitev;
                    echo "<option value='".$R["znak"]."' title='".$t."'>".$R["znak"]."</option>";
                }
                echo "</select>";
            }
            break;
        case "2": // glede na izbrano ekn oznako določi zap. številke
            if (strlen($VIskanje) > 0){
                //echo "Najdeno na iskalni niz - ".$VIskanje."<br />";
                //echo "<table class='condensed' border=1>";
                
                $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE";
                $SQL = $SQL . " znak ='".$VIskanje."'";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        echo "<input id='hid_hramba' name='rokhrambe' type='hidden' value='".$R["rokhrambe"]."'>";
                        echo "<input id='hid_trajno' name='trajno' type='hidden' value='".$R["trajno"]."'>";
                        echo "<input id='hid_arhivsko' name='arhivsko' type='hidden' value='".$R["arhivsko"]."'>";
                        $SQL = "SELECT DISTINCT oznaka,zapst,leto FROM tabdelovodnik WHERE oznaka='$VIskanje' AND leto=".$Danes->format('Y')." ORDER BY zapst DESC LIMIT 0,1";
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            echo "<input id='hid_zapst' name='hzapst' type='hidden' value='".$R1["zapst"]."'>";
                        }else{
                            echo "<input id='hid_zapst' name='hzapst' type='hidden' value='1'>";
                        }
                    }else{
                        echo "<input id='hid_hramba' name='rokhrambe' type='hidden' value=''>";
                        echo "<input id='hid_trajno' name='trajno' type='hidden' value=''>";
                        echo "<input id='hid_arhivsko' name='arhivsko' type='hidden' value=''>";
                        echo "<input id='hid_zapst' name='hzapst' type='hidden' value='1'>";
                    }
                }else{
                    echo "<input id='hid_hramba' name='rokhrambe' type='hidden' value=''>";
                    echo "<input id='hid_trajno' name='trajno' type='hidden' value=''>";
                    echo "<input id='hid_arhivsko' name='arhivsko' type='hidden' value=''>";
                    echo "<input id='hid_zapst' name='hzapst' type='hidden' value='1'>";
                }
            }else{
                echo "<input id='hid_hramba' name='rokhrambe' type='hidden' value=''>";
                echo "<input id='hid_trajno' name='trajno' type='hidden' value=''>";
                echo "<input id='hid_arhivsko' name='arhivsko' type='hidden' value=''>";
                echo "<input id='hid_zapst' name='hzapst' type='hidden' value='1'>";
            }
            break;
        case "3":
            if (strlen($VIskanje) > 0){
                //echo "Najdeno na iskalni niz - ".$VIskanje."<br />";
                //echo "<table class='condensed' border=1>";
                
                $i=1;
                $SQL = "SELECT DISTINCT oznaka,zapst,leto FROM tabdelovodnik WHERE oznaka='$VIskanje' AND leto=".$Danes->format('Y')." ORDER BY zapst";
                $result1 = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result1) > 0){
                    echo "<select id='zap_st' name='zapst' onchange='poglejDoc()'>";
                    while($R1 = mysqli_fetch_array($result1)){
                        $SQL="SELECT ref,doc,zadeva FROM tabdelovodnik WHERE oznaka='".$R1["oznaka"]."' AND zapst=".$R1["zapst"]." AND leto=".$Danes->format('Y');
                        $result2 = mysqli_query($link,$SQL);
                        echo "<option value='".$R1["zapst"]."' title='";
                        while($R2 = mysqli_fetch_array($result2)){
                            echo "Ref: ".$R2["ref"].", dok.: ".$R2["doc"].", zadeva: ".$R2["zadeva"]."\n";
                        }
                        echo "'>".$R1["zapst"]."</option>";
                        $i=$R1["zapst"];
                    }
                    echo "<option value='".($i+1)."' selected='selected'>".($i+1)."</option>";
                    echo "</select>";
                }else{
                    echo "<input id='zap_st' name='zapst' type='text' size='6' value='1'>";
                }
            }else{
                echo "<input id='zap_st' name='zapst' type='text' size='6' value='1'>";
            }
            break;
        case "4":
            if (strlen($VIskanje) > 0){
                //echo "Najdeno na iskalni niz - ".$VIskanje."<br />";
                //echo "<table class='condensed' border=1>";
                $zapst=$_GET["zapst"];
                $i=1;
                $SQL = "SELECT oznaka,ref,doc,zapst,zadeva FROM tabdelovodnik WHERE oznaka='$VIskanje' AND zapst=$zapst AND leto=".$Danes->format('Y')." ORDER BY doc";
                $result1 = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result1) > 0){
                    echo "<select id='doc' name='doc' onchange='poglejDoc()'>";
                    while($R1 = mysqli_fetch_array($result1)){
                        echo "<option value='".$R1["doc"]."' title='Ref: ".$R1["ref"].", dok.: ".$R1["doc"].", zadeva: ".$R1["zadeva"]."'>".$R1["doc"]."</option>";
                        $i=$R1["doc"];
                    }
                    echo "<option value='".($i+1)."' selected='selected'>".($i+1)."</option>";
                    echo "</select>";
                }else{
                    echo "<input id='doc' name='doc' type='text' size='6' value='1'>";
                }
            }else{
                echo "<input id='doc' name='doc' type='text' size='6' value='1'>";
            }
            break;
    }
    //echo "</td></tr>";
}
mysqli_close($link);
?>
