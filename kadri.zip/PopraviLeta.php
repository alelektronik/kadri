<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>

<?php
$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
if (isset($_GET["leto"])){
    $VLeto=$_GET["leto"];
    if ($VLeto == "" ) {
        if (isset($_SESSION["leto"])){
            $VLeto=$_SESSION["leto"];
            if ($VLeto == "" ) {
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }else{
                if ($ActualMonth > 8 ) {
                    $VLeto = $ActualYear;
                }else{
                    if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
                        $VLeto = $ActualYear;
                    }else{
                        $VLeto=$ActualYear-1;
                    }
                }
            }    
        }
    }
}else{
    if ($ActualMonth > 8 ) {
        $VLeto = $ActualYear;
    }else{
        if (($ActualMonth == 8) && ($Danes->format('d') > 15) ) {
            $VLeto = $ActualYear;
        }else{
            $VLeto=$ActualYear-1;
        }
    }
}
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.DelDobaSol,TabDopust.* FROM tabucitelji INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj WHERE status > 0 AND TabDopust.leto=".$VLeto;
$result = mysqli_query($link,$SQL);

$StUciteljev=0;
while ($R = mysqli_fetch_array($result)){
	$StUciteljev=$StUciteljev+1;
	$ucitelj[$StUciteljev][0]=$R["IdUcitelj"];
	$ucitelj[$StUciteljev][3]=$R["Priimek"]." ".$R["Ime"];
	$ucitelj[$StUciteljev][1]=$R["DelDobaLet"];
	if (!is_numeric($ucitelj[$StUciteljev][1])){
		$ucitelj[$StUciteljev][1]=0;
	}
	$ucitelj[$StUciteljev][2]=$R["DelDobaSol"];
	if (!is_numeric($ucitelj[$StUciteljev][2])){
		$ucitelj[$StUciteljev][2]=0;
	}
	$ucitelj[$StUciteljev][4]=$R["Priimek"];
	$ucitelj[$StUciteljev][5]=$R["Ime"];
}

switch ($Vid){
	case "1": // 'prišteva
		for ($indx=1;$indx <= $StUciteljev;$indx++){
			$SQL = "UPDATE tabucitelji SET DelDobaLet=".($ucitelj[$indx][1]+1).",DelDobaSol=".($ucitelj[$indx][2]+1)." WHERE IdUcitelj=".$ucitelj[$indx][0]; 
            $result = mysqli_query($link,$SQL);
			$SQL = "UPDATE TabDopust SET DelDobaLet=".($ucitelj[$indx][1]+1)." WHERE IdUcitelj=".$ucitelj[$indx][0]." AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
			//echo "Delavec: ".$ucitelj[$indx][3]." Del.doba: ".$ucitelj[$indx][1]."/".($ucitelj[$indx][1]+1)." Del doba šol.: ".$ucitelj[$indx][2]."/".($ucitelj[$indx][2]+1)."<br />";
		}
        break;
	case "2":// 'odšteva
        for ($indx=1;$indx <= $StUciteljev;$indx++){
			$VDelDoba=$ucitelj[$indx][1];
			if ($VDelDoba > 0){
				$VDelDoba=$VDelDoba-1;
			}else{
				$VDelDoba=0;
			}
			$VDelDobaSol=$ucitelj[$indx][2];
			if ($VDelDobaSol > 0){
				$VDelDobaSol=$VDelDobaSol-1;
			}else{
				$VDelDobaSol=0;
			}
			$SQL = "UPDATE tabucitelji SET DelDobaLet=".$VDelDoba.",DelDobaSol=".$VDelDobaSol." WHERE IdUcitelj=".$ucitelj[$indx][0]; 
            $result = mysqli_query($link,$SQL);
			$SQL = "UPDATE TabDopust SET DelDobaLet=".$VDelDoba." WHERE IdUcitelj=".$ucitelj[$indx][0]." AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
			//echo "Delavec: ".$ucitelj[$indx][3]." Del.doba: ".$ucitelj[$indx][1]."/".$VDelDoba." Del doba šol.: ".$ucitelj[$indx][2]."/".$VDelDobaSol."<br />";
		}
}

//echo "<a href='IzpisDopustov.php?leto=".$VLeto."'></a>Nazaj na Podatke o dopustih<br />";
header("Location: IzpisDopustov.php?leto=".$VLeto);

?>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>
</body>
</html>
