<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Učenec
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

$Isci=explode(" ", $_POST["ucenec"]);
$VUcenec=$Isci[0];
//echo $VUcenec[0]."<br />";

echo "<h2>Najdeno na iskalni niz - ".$VUcenec."</h2>";
echo "<table border=1>";
echo "<table border=1><tr><th>N</th><th>Priimek in ime</th><th>Datum rojstva</th><th>Naslov</th><th>Posta</th><th>Kraj</th><th>Oče</th><th>Telefon</th><th>Mati</th><th>Telefon</th></tr>";

if (isDate($VUcenec) or (strlen($VUcenec) == 0)){
    if (strlen($VUcenec)==0){
        $SQL = "SELECT * FROM tabucenci WHERE ";
        $SQL = $SQL . "(day(DatRoj)=".$Danes->format('j')." AND month(DatRoj)=".$Danes->format('n').")";
        $SQL = $SQL ." ORDER BY priimek,ime";
    }else{
        $Datum=new DateTime(isDate($VUcenec));
        $SQL = "SELECT * FROM tabucenci WHERE ";
        $SQL = $SQL . "(day(DatRoj)=".$Datum->format('j')." AND month(DatRoj)=".$Datum->format('n').")";
        $SQL = $SQL ." ORDER BY priimek,ime";
    }
}else{
    $SQL = "SELECT * FROM tabucenci WHERE ";
    $SQL = $SQL . "(priimek LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR ime LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR naslov LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR posta LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR oce LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR mati LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR skrbniki LIKE '%".$VUcenec."%'";
    $SQL = $SQL . " OR placnik LIKE '%".$VUcenec."%'";
    $SQL = $SQL . ")";
    $SQL = $SQL ." ORDER BY priimek,ime";
}
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
    echo "<tr><td>" . $Indx ."</td>";
    echo "<td><a href='ucenec_pregled.php?ucenec=".$R["IdUcenec"] ."'>" . $R["Priimek"] . ", " . $R["Ime"] . "</a></td>";
    $Datum=new DateTime(isDate($R["DatRoj"]));
    echo "<td align='right'>" . $Datum->format('d.m.Y') . "</td>";
    echo "<td>". $R["Naslov"] ."</td>";
    echo "<td>". $R["Posta"] ."</td>";
    echo "<td>". $R["Kraj"] ."</td>";
    echo "<td>". $R["oce"] ."</td>";
    echo "<td>". $R["ocekontakt"] .", ".$R["oceGSM"]."</td>";
    echo "<td>". $R["mati"] ."</td>";
    echo "<td>". $R["matikontakt"] .", ".$R["matiGSM"]."</td>";
    echo "</tr>";
    $Indx=$Indx+1;
}
echo "</table><br>";

?>

</body>
</html>
