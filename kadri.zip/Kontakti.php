<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VUporabnikIme=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("DelPregl",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    ?>

    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="pragma" content="no-cache" > 
    <link rel="stylesheet" type="text/css" href="osmj.css"> 
    <title>Kontaktni podatki
    </title>
    </head>
    <body>

    <?php

    if (isset($_POST["iducitelj"])){
        $ucitelj=$_POST["iducitelj"];
    }else{
        if (isset($_GET["iducitelj"])){
            $ucitelj=$_GET["iducitelj"];
        }else{
            $ucitelj="";
        }
    }

    switch ($Vid){
        case "2":
            break;
        default:
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
    }
    if ($Vid != 4){
        if ($VLevel > 1){
            echo "<a href='Kontakti.php?id=1'>Vnos kontaktov</a><br />";
        }
    }
        
    switch ($Vid){
	    case "1": //vnos kontaktnih podatkov
		    echo "<form name='kontakti' method='post' action='Kontakti.php'>";
		    echo "<table border='1'>";
		    echo "<tr><th>Št.</th><th>Ime</th><th>Telefon</th><th>E-mail</th><th>drugo</th></tr>";
		    
		    $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabkontakti.* FROM tabucitelji LEFT JOIN tabkontakti ON tabucitelji.idUcitelj=tabkontakti.idUcitelj ";
		    $SQL = $SQL . " WHERE (tabucitelji.status > 0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    
		    $indx=1;
            while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td>".$indx."</td>";
			    echo "<td><input name='uc_".$indx."' type='hidden' value='".$R["idUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
			    echo "<td><input name='uct_".$indx."' type='text' value='".$R["Telefon"]."' size='10'></td>";
			    echo "<td><input name='uce_".$indx."' type='text' value='".$R["email"]."' size='20'></td>";
			    echo "<td><input name='ucd_".$indx."' type='text' value='".$R["drugo"]."' size='20'></td>";
			    echo "</tr>";
			    $indx=$indx+1;
		    }
		    echo "</table><br />";
		    echo "<input name='StDelavcev' type='hidden' value='".($indx-1)."'>";
		    echo "<input name='id' type='hidden' value='2'>";
		    echo "<input name='submit' type='submit' value='Pošlji'>";
		    echo "</form>";
            break;
	    case "2": //vpis kontaktnih podatkov
		    for ($indx=1;$indx <= $_POST["StDelavcev"];$indx++){
			    $SQL = "SELECT * FROM tabkontakti WHERE idUcitelj=".$_POST["uc_".$indx];
			    $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
				    $SQL = "UPDATE tabkontakti SET telefon='".$_POST["uct_".$indx]."',email='".$_POST["uce_".$indx]."',drugo='".$_POST["ucd_".$indx]."' WHERE id=".$R["id"];
			    }else{
				    $SQL = "INSERT INTO tabkontakti (idUcitelj,Telefon,email,drugo) VALUES (".$_POST["uc_".$indx].",'".$_POST["uct_".$indx]."','".$_POST["uce_".$indx]."','".$_POST["ucd_".$indx]."')";
			    }
			    $result = mysqli_query($link,$SQL);
		    }

		    header ("Location: Kontakti.php");
            break;
	    case "4":
		    echo "<pre>".chr(34)."Name".chr(34).",".chr(34)."E-mail address".chr(34)."<br />";
		    
		    $SQL = "SELECT tabucitelji.Priimek,tabucitelji.Ime,tabkontakti.* FROM ";
		    $SQL = $SQL . "(tabucitelji LEFT JOIN tabkontakti ON tabucitelji.idUcitelj=tabkontakti.idUcitelj) ";
		    $SQL = $SQL . " WHERE (tabucitelji.status > 0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    
            while ($R = mysqli_fetch_array($result)){
			    if (strlen($R["email"]) >0) {
				    echo chr(34).$R["Priimek"]." ".$R["Ime"].chr(34).",";
				    echo chr(34).$R["email"].chr(34)."<br />";
			    }
		    }
		    echo "</pre>";
            break;
	    default:
		    $SQL = "SELECT * FROM TabVodjeAktivov WHERE leto=".$VLeto;
		    $result = mysqli_query($link,$SQL);
		    
		    for ($indx=0;$indx <= 30;$indx++){
			    $VVodjaAktiva[$indx]=0;
		    }
		    
		    $indx=1;
            while ($R = mysqli_fetch_array($result)){
		        $VVodjaAktiva[$indx]=$R["idUcitelj"];
			    $indx=$indx+1;
		    }
            $StVodijAktiva=$indx-1;
            
		    $SQL = "SELECT * FROM tabucenje WHERE leto=".$VLeto." AND predmet=50";
		    $result = mysqli_query($link,$SQL);
		    
		    for ($indx=0;$indx <= 50;$indx++){
			    $VRazrednik[$indx]=0;
		    }
		    
		    $indx=1;
            while ($R = mysqli_fetch_array($result)){
			    $VRazrednik[$indx]=$R["IdUcitelj"];
			    $indx=$indx+1;
		    }
		    $StRazrednikov=$indx-1;
            
		    $SQL = "SELECT DISTINCT tabpogodbe.iducitelj,tabpogodbe.iddelo FROM tabpogodbe WHERE iddelo IN (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)";
		    $result = mysqli_query($link,$SQL);
	    
		    for ($indx=0;$indx <= 200;$indx++){
			    $VUcitelj[$indx]=0;
		    }
		    
		    $indx=1;
		    $VUcitelj[0]=0;
            while ($R = mysqli_fetch_array($result)){
			    if ($VUcitelj[$indx-1] != $R["iducitelj"]){
				    $VUcitelj[$indx]=$R["iducitelj"];
			    }else{
				    $indx=$indx-1;
			    }
			    $indx=$indx+1;
		    }
            $StUciteljev=$indx-1;
            
            //preveri porodniške - začetek
            $dan=new DateTime($Danes->format('Y-m-d'));
            if ($dan->format('w') == 0){ //nedelja
                $dan->add(new DateInterval('P1D'));
            }
            if ($dan->format('w') == 6){ //sobota
                $dan->add(new DateInterval('P2D'));
            }
            $SQL = "SELECT DISTINCT tabpregleddelan.ucitelj FROM tabpregleddelan ";
            $SQL .= "INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.iddoprinos ";
            $SQL .= "WHERE tabpregleddelan.leto=".$dan->format('Y')." AND tabpregleddelan.mesec=".$dan->format('n')." AND tabpregleddelan.dan=".$dan->format('j')." AND tabdoprinos.oblikadelaoznaka IN ('Md','Ds')";
            $result = mysqli_query($link,$SQL);
            $np=1;
            while ($R = mysqli_fetch_array($result)){
                $porodniska[$np] = $R["ucitelj"];
                $np++;
            }
            for ($i=0;$i < $StUciteljev;$i++){
                for ($j=1;$j < $np;$j++){
                    if($VUcitelj[$i] == $porodniska[$j]){
                        $VUcitelj[$i] = 0;
                    }
                }
            }
            //preveri porodniške - konec
		    
		    echo "<form name='obrazec' method='post' ENCTYPE='multipart/form-data' action='PosljiEmail.php'>";
		    echo "<table border='1'>";
		    if ($VLevel > 1){
			    echo "<tr><th>Št.</th><th>Ime</th><th>Status</th><th>Telefon</th><th>E-mail</th><th>drugo</th><th>Pošlji</th></tr>";
		    }else{
			    echo "<tr><th>Št.</th><th>Ime</th><th>Status</th><th>E-mail</th><th>Pošlji</th></tr>";
		    }
		    
		    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabkontakti.* FROM ";
		    $SQL = $SQL . "(tabucitelji LEFT JOIN tabkontakti ON tabucitelji.idUcitelj=tabkontakti.idUcitelj) ";
		    $SQL = $SQL . " WHERE (tabucitelji.status > 0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);
		    
		    $indx=0;
            while ($R = mysqli_fetch_array($result)){
			    $indx=$indx+1;
			    echo "<tr>";
			    echo "<td>".$indx."</td>";
			    echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
			    echo "<td>";
			    for ($i1=1;$i1 <= $StUciteljev;$i1++){
				    if ($VUcitelj[$i1]==$R["idUcitelj"]){
                        echo "<span id='ucitelj_".$indx."'><font color='blue'>U </font></span>";
                        break;
                    }
			    }
			    for ($i1=1;$i1 <= $StRazrednikov;$i1++){
				    if ($VRazrednik[$i1]==$R["idUcitelj"]){
                        echo "<span id='razrednik_".$indx."'><font color='green'>R </font></span>";
                    }
			    }
			    for ($i1=1;$i1 <= $StVodijAktiva;$i1++){
				    if ($VVodjaAktiva[$i1]==$R["idUcitelj"]){
                        echo "<span id='aktiv_".$indx."'><font color='red'>A </font></span>";
                    }
			    }
			    echo "</td>";
			    if ($VLevel > 1){
				    echo "<td><b>".$R["Telefon"]."</b>&nbsp;</td>";
				    echo "<td><a href='mailto:".$R["email"]."'>".$R["email"]."</a>&nbsp;</td>";
				    echo "<td>".$R["drugo"]."&nbsp;</td>";
			    }else{
				    echo "<td><a href='mailto:".$R["email"]."'>".$R["email"]."</a>&nbsp;</td>";
			    }
    //				echo "<td><input name='uc_"&indx&"' type='hidden' value='".$R["tabucitelji.idUcitelj"]."'><input name='em_"&indx&"' type='checkbox'></td>"
			    echo "<td><input name='uc_".$indx."' type='hidden' value='".$R["email"]."'><input name='em_".$indx."' type='checkbox'></td>";
			    echo "</tr>";
		    }
		    echo "</table>";
		    echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'><input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
		    echo "<input name='gumbrazredniki' type='button' value='Označi razrednike' onClick='OznaciRazrednike(this)'><input name='gumbaktiv' type='button' value='Označi vodje aktivov' onClick='OznaciAktiv(this)'><input name='gumbucitelj' type='button' value='Označi učitelje' onClick='OznaciUcitelje(this)'><br />";
		    echo "<br /><input name='Stevilo' type='hidden' value='".$indx."'>";
		    echo "<input name='id' type='hidden' value='3'>";
		    echo "<b>Zadeva:</b> <input name='subject' size='40' type='text'><br />";
		    echo "<b>Sporočilo:</b><br><textarea name='bodytext' rows='5' cols='60'></textarea><br />";
		    echo "<b>Priponka:</b> <input name='attachment' size='40' type='file'><br />";
		    echo "<input name='Povezava' type='hidden' value='/'>";
		    echo "<input name='posiljatelj' type='hidden' value='".$VUporabnikIme."'>";
		    echo "<input name='submit' type='submit' value='Pošlji e-mail'><br />";
		    echo "</form>";
    }	
}
if ($Vid != "4"){
	echo "<br />";
	if ($VLevel > 2){
		echo "<a href='Kontakti.php?id=1'>Vnos kontaktov</a><br />";
	}
	echo "<a href='Kontakti.php?id=4'>Podatki za uvoz v Outlookove stike<br />";
	echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

	?>
	<script language="JavaScript">
	function OznaciVse(form){
		for (i=1; i < form.elements.length; i++) {
			form.elements[i].checked=true;
		}
	}
	function BrisiVse(form){
		for (i=1; i < form.elements.length; i++) {
			form.elements[i].checked=false;
		}
	}
	function OznaciRazrednike(form){
		var stevilo = document.forms['obrazec']['Stevilo']
		var razrednik = document.getElementById('razrednik_1')
		
		for (i=1; i <= stevilo.value; i++) {
			razrednik = document.getElementById('razrednik_'+i); 
			if (!(razrednik==null || razrednik=="")) {
				document.forms['obrazec']['em_'+i].checked=true;
			}
		}
	}
	function OznaciAktiv(form){
		var stevilo = document.forms['obrazec']['Stevilo']
		var razrednik = document.getElementById('aktiv_1')
		
		for (i=1; i <= stevilo.value; i++) {
			razrednik = document.getElementById('aktiv_'+i); 
			if (!(razrednik==null || razrednik=="")) {
				document.forms['obrazec']['em_'+i].checked=true;
			}
		}
	}
	function OznaciUcitelje(form){
		var stevilo = document.forms['obrazec']['Stevilo']
		var razrednik = document.getElementById('ucitelj_1')
		
		for (i=1; i <= stevilo.value; i++) {
			razrednik = document.getElementById('ucitelj_'+i); 
			if (!(razrednik==null || razrednik=="")) {
				document.forms['obrazec']['em_'+i].checked=true;
			}
		}
	}
	</script>

	</body>
	</html>
<?php
}
?>