<?php
require('const.php');
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Popravljanje podatkov o delavcih
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat04",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat05",
            dateFormat:"%d.%m.%Y",
            
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat06",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat07",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat08",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat09",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
    };
</script>
</head>
<body>

<?php
function Arr2Str($a){
    $s="";
    if (is_array($a)){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }else{
        return $a;
    }
    return $s;
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("UpdDel",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');

        if (isset($_POST["idUcitelj"])){
            $ucitelj = $_POST["idUcitelj"];
        }else{
            if (isset($_GET["idUcitelj"])){
                $ucitelj = $_GET["idUcitelj"];
            }else{
                if (isset($_SESSION["idUcitelj"])){ 
                    $ucitelj = $_SESSION["idUcitelj"];
                }else{
                    $ucitelj = 0;
                }
            }
        }

        if (isset($_POST["id"])){
            $id = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $id = $_GET["id"];
            }else{
                $id=0;
            }
        }

        switch ($id){
            case 1:  //update učitelja
                $SQL = "SELECT uporabnik FROM tabucitelji WHERE idUcitelj=" . $ucitelj;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $spreminjani=$R["uporabnik"];
                }else{
                    $spreminjani="";
                }
                if ($spreminjani != "admin"){
                    if (isset($_POST["priimek"])){
                       $VPriimek=$_POST["priimek"];
                    }else{
                        $VPriimek="";
                    }
                    if (isset($_POST["dekliski"])){
                        $VDekliski=$_POST["dekliski"];
                    }else{
                        $VDekliski="";
                    }
                    if (isset($_POST["ime"])){
                        $VIme=$_POST["ime"];
                    }else{
                        $VIme="";
                    }    
                    if (isset($_POST["naslov"])){
                        $VNaslov=$_POST["naslov"];
                    }else{
                        $VNaslov="";
                    }
                    if (isset($_POST["posta"])){    
                        $VPosta=$_POST["posta"];
                    }else{
                        $VPosta=0;
                    }
                    if (isset($_POST["kraj"])){
                        $VKraj=$_POST["kraj"];
                    }else{
                        $VKraj="";
                    }
                    if (isset($_POST["spol"])){
                        $VSpol=$_POST["spol"];
                    }else{
                        $VSpol="M";
                    }
                    if (isset($_POST["datroj"])){
                        $datRoj=$_POST["datroj"];
                        if (isDate($datRoj)){
                            $VDatRoj=new DateTime(isDate($datRoj));
                        }else{
                            $VDatRoj=new DateTime("now");
                        }
                    }else{
                        $VDatRoj=new DateTime("now");
                    }
                    if (isset($_POST["emso"])){
                        $Vemso=$_POST["emso"];
                    }else{
                        $Vemso="";
                    }
                    if (isset($_POST["izobrazba"])){
                        $VIzobrazba=$_POST["izobrazba"];
                    }else{
                        $VIzobrazba=0;
                    }
                    if (isset($_POST["poklic"])){
                        $Vpoklic= $_POST["poklic"];
                    }else{
                        $Vpoklic="";
                    }
                    if (isset($_POST["ustreznost"])){
                        $Vustreznost= $_POST["ustreznost"];
                    }else{
                        $Vustreznost=0;
                    }
                    if (isset($_POST["delovnomesto"])){
                        $Vdelovnomesto= $_POST["delovnomesto"];
                    }else{
                        $Vdelovnomesto=0;
                    }
                    if (isset($_POST["delovnicas"])){
                        $Vdelovnicas=$_POST["delovnicas"];
                    }else{
                        $Vdelovnicas=0;
                    }
                    if (isset($_POST["vrstadela"])){
                        $Vvrstadela=$_POST["vrstadela"];
                    }else{
                        $Vvrstadela=0;
                    }
                    if (isset($_POST["deldobasol"])){
                        if (is_numeric($_POST["deldobasol"])){
                            $Vdeldobasol=$_POST["deldobasol"];
                        }else{
                            $Vdeldobasol=0;
                        }
                    }else{
                        $Vdeldobasol=0;
                    }
                    if (isset($_POST["status"])){
                        $Vstatus=$_POST["status"];
                    }else{
                        $Vstatus=0;
                    }
                    $napacenuporabnik=false;
                    $Vuporabniskoime="";
                    
                    if ($spreminjani != ""){
                        if (isset($_POST["uporabniskoime"])){
                            if (strlen($_POST["uporabniskoime"]) > 0){
                                $Vuporabniskoime=$_POST["uporabniskoime"];
                                $SQL = "SELECT iducitelj,uporabnik FROM tabucitelji WHERE uporabnik='".$Vuporabniskoime."'";
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    if ($R["iducitelj"] != $ucitelj){
                                        $napacenuporabnik=true;
                                    }
                                }
                            }else{
                                $Vuporabniskoime="";
                            }
                        }else{
                            $Vuporabniskoime="";
                        }
                    }else{
                        if (isset($_POST["uporabniskoime"])){
                            if (strlen($_POST["uporabniskoime"]) > 0){
                                $Vuporabniskoime=$_POST["uporabniskoime"];
                                $SQL = "SELECT iducitelj,uporabnik FROM tabucitelji WHERE uporabnik='".$Vuporabniskoime."'";
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    if ($R["iducitelj"] != $ucitelj){
                                        $napacenuporabnik=true;
                                    }
                                }
                            }else{
                                $Vuporabniskoime="";
                            }
                        }else{
                            $Vuporabniskoime="";
                        }
                    }
                    if (!$napacenuporabnik){
                        if (isset($_POST["upgeslo"])){
                            $dolzinaGesla=strlen($_POST["upgeslo"]);
                            if ($dolzinaGesla==32){
                                $Vupgeslo=$_POST["upgeslo"];
                            }else{
                                $Vupgeslo=md5($_POST["upgeslo"]);
                            }
                        }else{
                            $Vupgeslo="";
                        }
                        if (isset($_POST["pedizobr"])){
                            $VPedIzobr=$_POST["pedizobr"];
                        }else{
                            $VPedIzobr="";
                        }
                        if (isset($_POST["strokizpit"])){
                            $VStrokIzpit=$_POST["strokizpit"];
                        }else{
                            $VStrokIzpit="";
                        }
                        if (isset($_POST["mentor"])){
                            $VMentor=$_POST["mentor"];
                        }else{
                            $VMentor="";
                        }
                        if (isset($_POST["svetovalec"])){
                            $VSvetovalec=$_POST["svetovalec"];
                        }else{
                            $VSvetovalec="";
                        }
                        if (isset($_POST["svetnik"])){
                            $VSvetnik=$_POST["svetnik"];
                        }else{
                            $VSvetnik="";
                        }
                        if (isset($_POST["davcna"])){
                            $VDavcna=$_POST["davcna"];
                        }else{
                            $VDavcna="";
                        }
                        if (isset($_POST["obcina"])){
                            $VObcina=$_POST["obcina"];
                        }else{
                            $VObcina=999;
                        }
                        if (isset($_POST["drzava"])){
                            $VDrzava=$_POST["drzava"];
                        }else{
                            $VDrzava=999;
                        }
                        if (isset($_POST["drzavljanstvo"])){
                            $Vdrzavljanstvo=$_POST["drzavljanstvo"];
                        }else{
                            $Vdrzavljanstvo="";
                        }
                        if (isset($_POST["krajroj"])){
                            $VKrajRoj=$_POST["krajroj"];
                        }else{
                            $VKrajRoj="";
                        }
                        if (isset($_POST["drzavaroj"])){
                            $VDrzavaRoj=$_POST["drzavaroj"];
                        }else{
                            $VDrzavaRoj="";
                        }
                        if (isset($_POST["naslovzac"])){
                            $VNaslovZac=$_POST["naslovzac"];
                        }else{
                            $VNaslovZac="";
                        }
                        if (isset($_POST["postazac"])){
                            $VPostaZac=$_POST["postazac"];
                        }else{
                            $VPostaZac=0;
                        }
                        if (isset($_POST["krajzac"])){
                            $VKrajZac=$_POST["krajzac"];
                        }else{
                            $VKrajZac="";
                        }
                        if (isset($_POST["obcinazac"])){
                            $VObcinaZac=$_POST["obcinazac"];
                        }else{
                            $VObcinaZac=999;
                        }
                        if (isset($_POST["drzavazac"])){
                            $VDrzavaZac=$_POST["drzavazac"];
                        }else{
                            $VDrzavaZac=999;
                        }
                        if (isset($_POST["invalid"])){
                            if ($_POST["invalid"] == "on"){
                                $VInvalid="true";
                            }else{
                                $VInvalid="false";
                            }
                        }else{
                            $VInvalid="false";
                        }
                        if (isset($_POST["katinvalid"])){
                            $VKatInvalid=$_POST["katinvalid"];
                        }else{
                            $VKatInvalid="";
                        }
                        if (isset($_POST["delnoupokojen"])){
                            $VDelnoUpokojen=$_POST["delnoupokojen"];
                        }else{
                            $VDelnoUpokojen="";
                        }
                        if (isset($_POST["dopdelo"])){
                            if ($_POST["dopdelo"] == "on"){
                                $VDopDelo="true";
                            }else{
                                $VDopDelo="false";
                            }
                        }else{
                            $VDopDelo="false";
                        }
                        if (isset($_POST["delodaj1"])){
                            $VDelodaj1=$_POST["delodaj1"];
                        }else{
                            $VDelodaj1="";
                        }
                        if (isset($_POST["delodaj1mat"])){
                            $VDelodaj1mat=$_POST["delodaj1mat"];
                        }else{
                            $VDelodaj1mat="";
                        }
                        if (isset($_POST["delodaj1naslov"])){
                            $VDelodaj1naslov=$_POST["delodaj1naslov"];
                        }else{
                            $VDelodaj1naslov="";
                        }
                        if (isset($_POST["delodaj2"])){
                            $VDelodaj2=$_POST["delodaj2"];
                        }else{
                            $VDelodaj2="";
                        }
                        if (isset($_POST["delodaj2mat"])){
                            $VDelodaj2mat=$_POST["delodaj2mat"];
                        }else{
                            $VDelodaj2mat="";
                        }
                        if (isset($_POST["delodaj2naslov"])){
                            $VDelodaj2naslov=$_POST["delodaj2naslov"];
                        }else{
                            $VDelodaj2naslov="";
                        }
                        if (isset($_POST["delodaj3"])){
                            $VDelodaj3=$_POST["delodaj3"];
                        }else{
                            $VDelodaj3="";
                        }
                        if (isset($_POST["delodaj3mat"])){
                            $VDelodaj3mat=$_POST["delodaj3mat"];
                        }else{
                            $VDelodaj3mat="";
                        }
                        if (isset($_POST["delodaj3naslov"])){
                            $VDelodaj3naslov=$_POST["delodaj3naslov"];
                        }else{
                            $VDelodaj3naslov="";
                        }
                        if (isset($_POST["starejsi"])){
                            if ($_POST["starejsi"] == "on"){
                                $VStarejsi="true";
                            }else{
                                $VStarejsi="false";
                            }    
                        }else{
                            $VStarejsi="false";
                        }
                        if (isset($_POST["dojecamati"])){
                            if ($_POST["dojecamati"] == "on"){
                                $VDojecaMati="true";
                            }else{
                                $VDojecaMati="false";
                            }
                        }else{
                            $VDojecaMati="false";
                        }    
                        if (isset($_POST["telefon"])){
                            $VTelefon=$_POST["telefon"];
                        }else{
                            $VTelefon="";
                        }
                        if (isset($_POST["email"])){
                            $Vemail=$_POST["email"];
                        }else{
                            $Vemail="";
                        }
                        if (isset($_POST["pravice"])){
                            $Vpravice=$_POST["pravice"];
                        }else{
                            $Vpravice=0;
                        }
                        
                        if (isset($_POST["DelaNaloge"])){
                            $DelaNaloge=Arr2Str($_POST["DelaNaloge"]);
                        }else{
                            $DelaNaloge="0";
                        }
                        /*
                        if ($EvidencaPrisotnosti){
                            if (isset($_POST["DelaNaloge"])){
                                $DelaNaloge=$_POST["DelaNaloge"];
                            }else{
                                $DelaNaloge=0;
                            }
                        }
                        */
                        
                        $SQL = "SELECT nivodostopa FROM tabucitelji WHERE idUcitelj=" . $ucitelj;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            if ($R["nivodostopa"] >= $VLevel){
                                $Vpravice=$R["nivodostopa"];
                            }
                        }

                        if ($dolzinaGesla==32){
                            $SQL = "UPDATE tabucitelji SET Priimek='".$VPriimek."',dekliski='".$VDekliski."',Ime='".$VIme."',Spol='".$VSpol."',DatRoj='".$VDatRoj->format('Y-m-d')."',LetoRoj=".$VDatRoj->format('Y').",emso='".$Vemso."',naslov='".$VNaslov."',posta=".$VPosta.",kraj='".$VKraj."',Izobrazba=".$VIzobrazba.",IzobOpis='".$Vpoklic."',Uporabnik='".$Vuporabniskoime."',status=".$Vstatus.",NivoDostopa="; 
                        }else{
                            $SQL = "UPDATE tabucitelji SET Priimek='".$VPriimek."',dekliski='".$VDekliski."',Ime='".$VIme."',Spol='".$VSpol."',DatRoj='".$VDatRoj->format('Y-m-d')."',LetoRoj=".$VDatRoj->format('Y').",emso='".$Vemso."',naslov='".$VNaslov."',posta=".$VPosta.",kraj='".$VKraj."',Izobrazba=".$VIzobrazba.",IzobOpis='".$Vpoklic."',Uporabnik='".$Vuporabniskoime."',geslo='".$Vupgeslo."',status=".$Vstatus.",NivoDostopa="; 
                        }
                        $SQL = $SQL . $Vpravice. ", DelDobaSol=".$Vdeldobasol.", PedIzobr='".$VPedIzobr."',StrokIzpit='".$VStrokIzpit."',Mentor='".$VMentor."',Svetovalec='".$VSvetovalec."',Svetnik='".$VSvetnik."'";
                        $SQL = $SQL . ",davcna='".$VDavcna."',obcina='".$VObcina."',drzava='".$VDrzava."',drzavljanstvo='".$Vdrzavljanstvo."',KrajRoj='".$VKrajRoj."',DrzavaRoj='".$VDrzavaRoj."'";
                        $SQL = $SQL . ", NaslovZac='".$VNaslovZac."',PostaZac='".$VPostaZac."',KrajZac='".$VKrajZac."',ObcinaZac='".$VObcinaZac."',DrzavaZac='".$VDrzavaZac."'";
                        $SQL = $SQL . ", Invalid=".$VInvalid.", KatInvalid='".$VKatInvalid."', DelnoUpokojen='".$VDelnoUpokojen."',DopDelo=".$VDopDelo;
                        /*
                        $SQL = $SQL . ", Delodaj1='".VDelodaj1."', Delodaj1mat='".VDelodaj1mat."',Delodaj1naslov='".VDelodaj1naslov."'"
                        $SQL = $SQL . ", Delodaj2='".VDelodaj2."', Delodaj2mat='".VDelodaj2mat."',Delodaj2naslov='".VDelodaj2naslov."'"
                        $SQL = $SQL .", Delodaj3='".VDelodaj3."', Delodaj3mat='".VDelodaj3mat."',Delodaj3naslov='".VDelodaj3naslov."'"
                        $SQL = $SQL .", Koef=".VKoeficient
                        $SQL = $SQL . ", DatumPogodbe='".VDatumPogodbe."',PolniDelCas='".VPolniDelCas."', RazlogDolCas='".VRazlogDolCas."',PotrStrokUsp='".VPotrStrokUsp."'"
                        $SQL = $SQL . ", NazivDelMesta='".VNazivDelMesta."',UrTeden='".VUrTeden."', Izmensko=".Vizmensko.", KrajDela='".VKrajDela."', KonkKlavz=".VKonkKlavz.",NacinPrenehanja='".VNacinPrenehanja."'"
                        */
                        $SQL = $SQL . ", Starejsi=".$VStarejsi.", DojecaMati=".$VDojecaMati;
                        $SQL = $SQL . " WHERE IdUcitelj=".$ucitelj;
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu popravkov!<br />$SQL <br />");
                        }
                                 
                                 //        'response.write SQL&"<br>"
                        $SQL = "UPDATE TabVzgojitelji SET Priimek='".$VPriimek."',Ime='".$VIme."' WHERE IdUcitelj=".$ucitelj;
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu v tabelo vzgojiteljev!<br />$SQL <br />");
                        }

                        $SQL = "SELECT * FROM tabkontakti WHERE idUcitelj=".$ucitelj;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $SQL = "UPDATE tabkontakti SET telefon='".$VTelefon."',email='".$Vemail."' WHERE idUcitelj=".$ucitelj;
                        }else{
                            $SQL = "INSERT INTO tabkontakti (idUcitelj,telefon,email) VALUES (".$ucitelj.",'".$VTelefon."','".$Vemail."')";
                        }
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu kontaktov!<br />$SQL <br />");
                        }
                        /*
                        if ($EvidencaPrisotnosti){
                            $SQL = "UPDATE tabucitelji SET Sistemizacija='".$DelaNaloge."' WHERE idUcitelj=".$ucitelj;
                            $result = mysqli_query($link,$SQL);
                        }
                        */
                        $SQL = "UPDATE tabucitelji SET Sistemizacija='".$DelaNaloge."' WHERE idUcitelj=".$ucitelj; 
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu sistemizacije!<br />$SQL <br />");
                        }
                            
                        if ($EvidencaPrisotnosti){
                            $SQL = "UPDATE kadrovi SET PRIIMIME='".$VPriimek." ".$VIme."' WHERE EMSO=".$ucitelj; 
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu v evidenco prisotnosti!<br />$SQL <br />");
                            }
                        }
                        //če je status 0, pobriše uporabniško ime in geslo ter pravice
                        if ($VLevel > 1){
                            if ($Vstatus == 0){
                                $SQL = "UPDATE tabucitelji SET uporabnik='',geslo='',nivodostopa=0 WHERE iducitelj=".$ucitelj;
                                if (!($result = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu podatkov!<br />$SQL <br />");
                                }
                                $SQL = "UPDATE tabdostop SET ";
                                $SQL .= "VnosUcDat=false,";
                                $SQL .= "UpdUc=false,";             
                                $SQL .= "Redov=false,";
                                $SQL .= "VnosNPZ=false,";
                                $SQL .= "ImpExNPZ=false,";
                                $SQL .= "DelPregl=false,";
                                $SQL .= "DelKontr=false,";
                                $SQL .= "UpdDel=false,";
                                $SQL .= "Tajn=false,";
                                $SQL .= "VnosSist=false,";
                                $SQL .= "VnosAktivi=false,";
                                $SQL .= "VnosUrnik=false,";
                                $SQL .= "VnosNadom=false,";
                                $SQL .= "Inventura=false,";
                                $SQL .= "StatUc=false,";
                                $SQL .= "StatDel=false,";
                                $SQL .= "LetnPor=false,";
                                $SQL .= "Prehrana=false,";
                                $SQL .= "Prisotnost=false,";
                                $SQL .= "NovoSL=false,";
                                $SQL .= "ImpExUc=false,";
                                $SQL .= "DatSola=false,";
                                $SQL .= "Prazniki=false,";
                                $SQL .= "Prostori=false,";
                                $SQL .= "Predmeti=false,";
                                $SQL .= "TabEd=false,";
                                $SQL .= "RDU=false,";
                                $SQL .= "PreglZbirn=false,";
                                $SQL .= "PreglPoroc=false,";
                                $SQL .= "PreglReal=false,";
                                $SQL .= "drugo1=false,";
                                $SQL .= "drugo2=false,";
                                $SQL .= "drugo3=false,";
                                $SQL .= "drugo4=false,";
                                $SQL .= "drugo5=false,";
                                $SQL .= "drugo6=false,";
                                $SQL .= "drugo7=false,";
                                $SQL .= "drugo8=false,";
                                $SQL .= "drugo9=false";
                                $SQL .= " WHERE iducitelj=".$ucitelj;
                                if (!($result = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu podatkov!<br />$SQL <br />");
                                }
                                echo "Glede na status delavca (Ni več aktiven), so bili pobrisani uporabniško ime, geslo in pravice.<br />";
                            }                
                        }
                        
                        //        'Izpis osebnih podatkov
                        $SQL = "SELECT * FROM tabucitelji WHERE IdUcitelj=".$ucitelj;
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<h2>Vpisali ste podatke o delavcu:</h2>";
                            echo "<a href='IzpisUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</a><br>";
                            if ($VLevel > 1) {
                                echo "<h3><a href='DostopnaKontrola.php'>Nastavitev kontrole dostopanja do vsebin</a></h3>";
                            }
                            echo "<a href='PodatkiODelavcu.php?id=".$R["IdUcitelj"]."'>Pregled podatkov iz pogodbe</a><br>";
                            echo "<a href='IzborUcitelja.php?id=1'><h3>Na izbor delavcev</h3></a><br>";
                            echo "<a href='IzpisUciteljev.php'>Izpis učiteljev</a><br>";
                            echo "<a href='IzpisDopustov.php'>Dopusti</a><br>";
                        }
                    }else{
                        echo "Uporabniško ime je že v lasti nekoga drugega!<br />";
                    }
                }else{
                    if ($VUporabnik == "admin"){
                        if (isset($_POST["priimek"])){
                           $VPriimek=$_POST["priimek"];
                        }else{
                            $VPriimek="";
                        }
                        if (isset($_POST["dekliski"])){
                            $VDekliski=$_POST["dekliski"];
                        }else{
                            $VDekliski="";
                        }
                        if (isset($_POST["ime"])){
                            $VIme=$_POST["ime"];
                        }else{
                            $VIme="";
                        }    
                        if (isset($_POST["naslov"])){
                            $VNaslov=$_POST["naslov"];
                        }else{
                            $VNaslov="";
                        }
                        if (isset($_POST["posta"])){    
                            $VPosta=$_POST["posta"];
                        }else{
                            $VPosta=0;
                        }
                        if (isset($_POST["kraj"])){
                            $VKraj=$_POST["kraj"];
                        }else{
                            $VKraj="";
                        }
                        if (isset($_POST["spol"])){
                            $VSpol=$_POST["spol"];
                        }else{
                            $VSpol="M";
                        }
                        if (isset($_POST["datroj"])){
                            $datRoj=$_POST["datroj"];
                            if (isDate($datRoj)){
                                $VDatRoj=new DateTime(isDate($datRoj));
                            }else{
                                $VDatRoj=new DateTime("now");
                            }
                        }else{
                            $VDatRoj=new DateTime("now");
                        }
                        if (isset($_POST["emso"])){
                            $Vemso=$_POST["emso"];
                        }else{
                            $Vemso="";
                        }
                        if (isset($_POST["izobrazba"])){
                            $VIzobrazba=$_POST["izobrazba"];
                        }else{
                            $VIzobrazba=0;
                        }
                        if (isset($_POST["poklic"])){
                            $Vpoklic= $_POST["poklic"];
                        }else{
                            $Vpoklic="";
                        }
                        if (isset($_POST["ustreznost"])){
                            $Vustreznost= $_POST["ustreznost"];
                        }else{
                            $Vustreznost=0;
                        }
                        if (isset($_POST["delovnomesto"])){
                            $Vdelovnomesto= $_POST["delovnomesto"];
                        }else{
                            $Vdelovnomesto=0;
                        }
                        if (isset($_POST["delovnicas"])){
                            $Vdelovnicas=$_POST["delovnicas"];
                        }else{
                            $Vdelovnicas=0;
                        }
                        if (isset($_POST["vrstadela"])){
                            $Vvrstadela=$_POST["vrstadela"];
                        }else{
                            $Vvrstadela=0;
                        }
                        if (isset($_POST["deldobasol"])){
                            if (is_numeric($_POST["deldobasol"])){
                                $Vdeldobasol=$_POST["deldobasol"];
                            }else{
                                $Vdeldobasol=0;
                            }
                        }else{
                            $Vdeldobasol=0;
                        }
                        if (isset($_POST["status"])){
                            $Vstatus=$_POST["status"];
                        }else{
                            $Vstatus=0;
                        }
                        $napacenuporabnik=false;
                        if (!$napacenuporabnik){
                            if (isset($_POST["upgeslo"])){
                                $dolzinaGesla=strlen($_POST["upgeslo"]);
                                if ($dolzinaGesla==32){
                                    $Vupgeslo=$_POST["upgeslo"];
                                }else{
                                    $Vupgeslo=md5($_POST["upgeslo"]);
                                }
                            }else{
                                $Vupgeslo="";
                            }
                            if (isset($_POST["pedizobr"])){
                                $VPedIzobr=$_POST["pedizobr"];
                            }else{
                                $VPedIzobr="";
                            }
                            if (isset($_POST["strokizpit"])){
                                $VStrokIzpit=$_POST["strokizpit"];
                            }else{
                                $VStrokIzpit="";
                            }
                            if (isset($_POST["mentor"])){
                                $VMentor=$_POST["mentor"];
                            }else{
                                $VMentor="";
                            }
                            if (isset($_POST["svetovalec"])){
                                $VSvetovalec=$_POST["svetovalec"];
                            }else{
                                $VSvetovalec="";
                            }
                            if (isset($_POST["svetnik"])){
                                $VSvetnik=$_POST["svetnik"];
                            }else{
                                $VSvetnik="";
                            }
                            if (isset($_POST["davcna"])){
                                $VDavcna=$_POST["davcna"];
                            }else{
                                $VDavcna="";
                            }
                            if (isset($_POST["obcina"])){
                                $VObcina=$_POST["obcina"];
                            }else{
                                $VObcina=999;
                            }
                            if (isset($_POST["drzava"])){
                                $VDrzava=$_POST["drzava"];
                            }else{
                                $VDrzava=999;
                            }
                            if (isset($_POST["drzavljanstvo"])){
                                $Vdrzavljanstvo=$_POST["drzavljanstvo"];
                            }else{
                                $Vdrzavljanstvo="";
                            }
                            if (isset($_POST["krajroj"])){
                                $VKrajRoj=$_POST["krajroj"];
                            }else{
                                $VKrajRoj="";
                            }
                            if (isset($_POST["drzavaroj"])){
                                $VDrzavaRoj=$_POST["drzavaroj"];
                            }else{
                                $VDrzavaRoj="";
                            }
                            if (isset($_POST["naslovzac"])){
                                $VNaslovZac=$_POST["naslovzac"];
                            }else{
                                $VNaslovZac="";
                            }
                            if (isset($_POST["postazac"])){
                                $VPostaZac=$_POST["postazac"];
                            }else{
                                $VPostaZac=0;
                            }
                            if (isset($_POST["krajzac"])){
                                $VKrajZac=$_POST["krajzac"];
                            }else{
                                $VKrajZac="";
                            }
                            if (isset($_POST["obcinazac"])){
                                $VObcinaZac=$_POST["obcinazac"];
                            }else{
                                $VObcinaZac=999;
                            }
                            if (isset($_POST["drzavazac"])){
                                $VDrzavaZac=$_POST["drzavazac"];
                            }else{
                                $VDrzavaZac=999;
                            }
                            if (isset($_POST["invalid"])){
                                if ($_POST["invalid"] == "on"){
                                    $VInvalid="true";
                                }else{
                                    $VInvalid="false";
                                }
                            }else{
                                $VInvalid="false";
                            }
                            if (isset($_POST["katinvalid"])){
                                $VKatInvalid=$_POST["katinvalid"];
                            }else{
                                $VKatInvalid="";
                            }
                            if (isset($_POST["delnoupokojen"])){
                                $VDelnoUpokojen=$_POST["delnoupokojen"];
                            }else{
                                $VDelnoUpokojen="";
                            }
                            if (isset($_POST["dopdelo"])){
                                if ($_POST["dopdelo"] == "on"){
                                    $VDopDelo="true";
                                }else{
                                    $VDopDelo="false";
                                }
                            }else{
                                $VDopDelo="false";
                            }
                            if (isset($_POST["delodaj1"])){
                                $VDelodaj1=$_POST["delodaj1"];
                            }else{
                                $VDelodaj1="";
                            }
                            if (isset($_POST["delodaj1mat"])){
                                $VDelodaj1mat=$_POST["delodaj1mat"];
                            }else{
                                $VDelodaj1mat="";
                            }
                            if (isset($_POST["delodaj1naslov"])){
                                $VDelodaj1naslov=$_POST["delodaj1naslov"];
                            }else{
                                $VDelodaj1naslov="";
                            }
                            if (isset($_POST["delodaj2"])){
                                $VDelodaj2=$_POST["delodaj2"];
                            }else{
                                $VDelodaj2="";
                            }
                            if (isset($_POST["delodaj2mat"])){
                                $VDelodaj2mat=$_POST["delodaj2mat"];
                            }else{
                                $VDelodaj2mat="";
                            }
                            if (isset($_POST["delodaj2naslov"])){
                                $VDelodaj2naslov=$_POST["delodaj2naslov"];
                            }else{
                                $VDelodaj2naslov="";
                            }
                            if (isset($_POST["delodaj3"])){
                                $VDelodaj3=$_POST["delodaj3"];
                            }else{
                                $VDelodaj3="";
                            }
                            if (isset($_POST["delodaj3mat"])){
                                $VDelodaj3mat=$_POST["delodaj3mat"];
                            }else{
                                $VDelodaj3mat="";
                            }
                            if (isset($_POST["delodaj3naslov"])){
                                $VDelodaj3naslov=$_POST["delodaj3naslov"];
                            }else{
                                $VDelodaj3naslov="";
                            }
                            if (isset($_POST["starejsi"])){
                                if ($_POST["starejsi"] == "on"){
                                    $VStarejsi="true";
                                }else{
                                    $VStarejsi="false";
                                }    
                            }else{
                                $VStarejsi="false";
                            }
                            if (isset($_POST["dojecamati"])){
                                if ($_POST["dojecamati"] == "on"){
                                    $VDojecaMati="true";
                                }else{
                                    $VDojecaMati="false";
                                }
                            }else{
                                $VDojecaMati="false";
                            }    
                            if (isset($_POST["telefon"])){
                                $VTelefon=$_POST["telefon"];
                            }else{
                                $VTelefon="";
                            }
                            if (isset($_POST["email"])){
                                $Vemail=$_POST["email"];
                            }else{
                                $Vemail="";
                            }
                            
                            if (isset($_POST["DelaNaloge"])){
                                $DelaNaloge=Arr2Str($_POST["DelaNaloge"]);
                            }else{
                                $DelaNaloge="0";
                            }
                            /*
                            if ($EvidencaPrisotnosti){
                                if (isset($_POST["DelaNaloge"])){
                                    $DelaNaloge=$_POST["DelaNaloge"];
                                }else{
                                    $DelaNaloge=0;
                                }
                            }
                            */
                            
                            $SQL = "SELECT nivodostopa FROM tabucitelji WHERE idUcitelj=" . $ucitelj;
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                if ($R["nivodostopa"] >= $VLevel){
                                    $Vpravice=$R["nivodostopa"];
                                }
                            }

                            if ($dolzinaGesla==32){
                                $SQL = "UPDATE tabucitelji SET Priimek='".$VPriimek."',dekliski='".$VDekliski."',Ime='".$VIme."',Spol='".$VSpol."',DatRoj='".$VDatRoj->format('Y-m-d')."',LetoRoj=".$VDatRoj->format('Y').",emso='".$Vemso."',naslov='".$VNaslov."',posta=".$VPosta.",kraj='".$VKraj."',Izobrazba=".$VIzobrazba.",IzobOpis='".$Vpoklic."',status=".$Vstatus.",NivoDostopa="; 
                            }else{
                                $SQL = "UPDATE tabucitelji SET Priimek='".$VPriimek."',dekliski='".$VDekliski."',Ime='".$VIme."',Spol='".$VSpol."',DatRoj='".$VDatRoj->format('Y-m-d')."',LetoRoj=".$VDatRoj->format('Y').",emso='".$Vemso."',naslov='".$VNaslov."',posta=".$VPosta.",kraj='".$VKraj."',Izobrazba=".$VIzobrazba.",IzobOpis='".$Vpoklic."',geslo='".$Vupgeslo."',status=".$Vstatus.",NivoDostopa="; 
                            }
                            $SQL = $SQL . $Vpravice. ", DelDobaSol=".$Vdeldobasol.", PedIzobr='".$VPedIzobr."',StrokIzpit='".$VStrokIzpit."',Mentor='".$VMentor."',Svetovalec='".$VSvetovalec."',Svetnik='".$VSvetnik."'";
                            $SQL = $SQL . ",davcna='".$VDavcna."',obcina='".$VObcina."',drzava='".$VDrzava."',drzavljanstvo='".$Vdrzavljanstvo."',KrajRoj='".$VKrajRoj."',DrzavaRoj='".$VDrzavaRoj."'";
                            $SQL = $SQL . ", NaslovZac='".$VNaslovZac."',PostaZac='".$VPostaZac."',KrajZac='".$VKrajZac."',ObcinaZac='".$VObcinaZac."',DrzavaZac='".$VDrzavaZac."'";
                            $SQL = $SQL . ", Invalid=".$VInvalid.", KatInvalid='".$VKatInvalid."', DelnoUpokojen='".$VDelnoUpokojen."',DopDelo=".$VDopDelo;
                            /*
                            $SQL = $SQL . ", Delodaj1='".VDelodaj1."', Delodaj1mat='".VDelodaj1mat."',Delodaj1naslov='".VDelodaj1naslov."'"
                            $SQL = $SQL . ", Delodaj2='".VDelodaj2."', Delodaj2mat='".VDelodaj2mat."',Delodaj2naslov='".VDelodaj2naslov."'"
                            $SQL = $SQL .", Delodaj3='".VDelodaj3."', Delodaj3mat='".VDelodaj3mat."',Delodaj3naslov='".VDelodaj3naslov."'"
                            $SQL = $SQL .", Koef=".VKoeficient
                            $SQL = $SQL . ", DatumPogodbe='".VDatumPogodbe."',PolniDelCas='".VPolniDelCas."', RazlogDolCas='".VRazlogDolCas."',PotrStrokUsp='".VPotrStrokUsp."'"
                            $SQL = $SQL . ", NazivDelMesta='".VNazivDelMesta."',UrTeden='".VUrTeden."', Izmensko=".Vizmensko.", KrajDela='".VKrajDela."', KonkKlavz=".VKonkKlavz.",NacinPrenehanja='".VNacinPrenehanja."'"
                            */
                            $SQL = $SQL . ", Starejsi=".$VStarejsi.", DojecaMati=".$VDojecaMati;
                            $SQL = $SQL . " WHERE IdUcitelj=".$ucitelj;
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu popravkov!<br />$SQL <br />");
                            }
                                     
                                     //        'response.write SQL&"<br>"
                            $SQL = "UPDATE TabVzgojitelji SET Priimek='".$VPriimek."',Ime='".$VIme."' WHERE IdUcitelj=".$ucitelj;
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu v tabelo vzgojiteljev!<br />$SQL <br />");
                            }

                            $SQL = "SELECT * FROM tabkontakti WHERE idUcitelj=".$ucitelj;
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                $SQL = "UPDATE tabkontakti SET telefon='".$VTelefon."',email='".$Vemail."' WHERE idUcitelj=".$ucitelj;
                            }else{
                                $SQL = "INSERT INTO tabkontakti (idUcitelj,telefon,email) VALUES (".$ucitelj.",'".$VTelefon."','".$Vemail."')";
                            }
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu kontaktov!<br />$SQL <br />");
                            }
                            /*
                            if ($EvidencaPrisotnosti){
                                $SQL = "UPDATE tabucitelji SET Sistemizacija='".$DelaNaloge."' WHERE idUcitelj=".$ucitelj;
                                $result = mysqli_query($link,$SQL);
                            }
                            */
                            $SQL = "UPDATE tabucitelji SET Sistemizacija='".$DelaNaloge."' WHERE idUcitelj=".$ucitelj; 
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu sistemizacije!<br />$SQL <br />");
                            }
                                
                            if ($EvidencaPrisotnosti){
                                $SQL = "UPDATE kadrovi SET PRIIMIME='".$VPriimek." ".$VIme."' WHERE EMSO=".$ucitelj; 
                                if (!($result = mysqli_query($link,$SQL))){
                                    die("Napaka pri vpisu v evidenco prisotnosti!<br />$SQL <br />");
                                }
                            }
                            
                            //        'Izpis osebnih podatkov
                            $SQL = "SELECT * FROM tabucitelji WHERE IdUcitelj=".$ucitelj;
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                echo "<h2>Vpisali ste podatke o delavcu:</h2>";
                                echo "<a href='IzpisUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</a><br>";
                                if ($VLevel > 1) {
                                    echo "<h3><a href='DostopnaKontrola.php'>Nastavitev kontrole dostopanja do vsebin</a></h3>";
                                }
                                echo "<a href='PodatkiODelavcu.php?id=".$R["IdUcitelj"]."'>Pregled podatkov iz pogodbe</a><br>";
                                echo "<a href='IzborUcitelja.php?id=1'><h3>Na izbor delavcev</h3></a><br>";
                                echo "<a href='IzpisUciteljev.php'>Izpis učiteljev</a><br>";
                                echo "<a href='IzpisDopustov.php'>Dopusti</a><br>";
                            }
                        }else{
                            echo "Uporabniško ime je že v lasti nekoga drugega!<br />";
                        }
                    }else{
                        echo "Ne morete spremeniti administratorskega računa!<br />";
                    }
                }
                break;
            case 2: //obrazec za vpis novega delavca
                echo "<form accept-charset='utf-8' name='dodajucenca' method=post action='PopraviUcitelja.php'>";
                echo "<h2>Vpiši delavca</h2>";
                
                echo "<table>";
                echo "<tr><td>Številka pogodbe: </td><td><input name='stpogodbe' type='text' size='10' ></td></tr>";
                echo "<tr><td>Priimek: </td><td><input name='priimek' type='text' size='25'></td></tr>";
                echo "<tr><td>Ime: </td><td><input name='ime' type='text' size='25' ></td></tr>";
                echo "<tr><td>Dekliški priimek: </td><td><input name='dekliski' type='text' size='25'></td></tr>";
                echo "<tr><td>Spol:</td><td><select name='spol'><option selected>M</option><option>F</option></select></td></tr>";
                echo "<tr><td>Datum rojstva: </td><td><input name='datroj' type='text' size='10' id='dat01' /></td></tr>";
                echo "<tr><td>Kraj rojstva: </td><td><input name='krajroj' type='text' size='20'></td></tr>";
                echo "<tr><td>Država rojstva: </td><td><input name='drzavaroj' type='text' size='20'></td></tr>";
                echo "<tr><td>Državljanstvo: </td><td><input name='drzavljanstvo' type='text' size='20'></td></tr>";
                echo "<tr><td>EMŠO: </td><td><input name='emso' type='text' size='15'></td></tr>";
                echo "<tr><td>Davčna številka: </td><td><input name='davcna' type='text' size='10'></td></tr>";
                echo "<tr><td>Naslov: </td><td><input name='naslov' type='text' size='40' ></td></tr>";
                echo "<tr><td>Pošta: </td><td><input name='posta' type='text' size='5' ></td></tr>";
                echo "<tr><td>Kraj: </td><td><input name='kraj' type='text' size='25' ></td></tr>";
                echo "<tr><td>Občina: </td><td><select name='obcina'>";
                $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($R["sifra"]=="061")  {
                        echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
                    }else{
                        echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
                    }
                }
                echo "</select></td></tr>";

                echo "<tr><td>Država: </td><td><select name='drzava'>";
                $SQL = "SELECT * FROM TabSifrantDrzav ORDER BY drzava";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if( $R["sifra"]=="705" ) {
                        echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["drzava"]."</option>";
                    }else{
                        echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["drzava"]."</option>";
                    }
                }
                echo "</select></td></tr>";
                
                echo "<tr><td>Naslov zač. bivališča: </td><td><input name='naslovzac' type='text' size='40' ></td></tr>";
                echo "<tr><td>Pošta zač. bivališča: </td><td><input name='postazac' type='text' size='5' ></td></tr>";
                echo "<tr><td>Kraj zač. bivališča: </td><td><input name='krajzac' type='text' size='25' ></td></tr>";
                echo "<tr><td>Občina zač. bivališča: </td><td><select name='obcinazac'>";
                $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($R["sifra"]=="999")  {
                        echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
                    }else{
                        echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
                    }
                }
                echo "</select></td></tr>";
                
                echo "<tr><td>Država zač. bivališča: </td><td><select name='drzavazac'>";
                $SQL = "SELECT * FROM TabSifrantDrzav ORDER BY drzava";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if( $R["sifra"]=="999" ) {
                        echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["drzava"]."</option>";
                    }else{
                        echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["drzava"]."</option>";
                    }
                }
                echo "</select></td></tr>";

                echo "<tr><td>Telefon</td><td><input name='telefon' type='text' size='20'></td></tr>";
                echo "<tr><td>e-mail</td><td><input name='email' type='text' size='60'></td></tr>";
                
                echo "<tr><td>Stopnja izobrazbe</td><td>";
                echo "<select name='izobrazba'>";
                $SQL = "SELECT * FROM TabIzobrazba";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["idIzobrazba"]."'>".$R["Opis"]."</option>";
                }
                echo "</select></td></tr>";
                echo "<tr><td>Izobrazba: </td><td><input name='poklic' type='text' size='40' ></td></tr>";

                echo "<tr><td>Ustreznost izobrazbe</td><td>";
                echo "<select name='ustreznost'>";
                echo "<option value='0'>Ustrezna</option>";
                echo "<option value='1'>Neustrezna</option>";
                echo "</select></td></tr>";

                echo "<tr><td>Delovno mesto (statistika)</td><td>";
                echo "<select name='delovnomesto'>";
                
                $SQL = "SELECT * FROM TabDelo";
                $Indx = 0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='",$R["IdDelo"]."'>".$R["SkupinaDela"]." - ".$R["OpisDela"]."</option>";
                }
                echo "</select></td></tr>";

                echo "<tr><td>Delovni čas</td><td>";
                echo "<select name='delovnicas'>";
                echo "<option value='0' selected='selected'>Polni delovni čas</option>";
                echo "<option value='1'>Krajši delovni čas</option>";
                echo "<option value='3'>Na več šolah</option>";
                echo "</select></td></tr>";

                echo "<tr><td>Invalidnost: </td><td><input name='invalid' type='checkbox'></td></tr>";
                echo "<tr><td>Kategorija invalidnosti: </td><td><input name='katinvalid' type='text' size='10' ></td></tr>";
                echo "<tr><td>Delna upokojitev: </td><td><input name='delnoupokojen' type='text' size='20'></td></tr>";

                echo "<tr><td>Datum pogodbe: </td><td><input name='datumpogodbe' type='text' size='10' value='".$Danes->format('d.m.Y')."' id='dat02'></td></tr>";
                echo "<tr><td>Polni delovni čas: </td><td><input name='polnidelcas' type='checkbox' checked='checked'></td></tr>";
                echo "<tr><td>Ur na teden: </td><td><input name='urteden' type='text' size='5' value='40'></td></tr>";

                echo "<tr><td>Tedenska obremenitev</td><td>";
                echo "<table><tr><th>PON</th><th>TOR</th><th>SRE</th><th>ČET</th><th>PET</th></tr>";
                echo "<tr><td><input type='text' name='ob1' value='8' size='4'></td>";
                echo "<td><input type='text' name='ob2' value='8' size='4'></td>";
                echo "<td><input type='text' name='ob3' value='8' size='4'></td>";
                echo "<td><input type='text' name='ob4' value='8' size='4'></td>";
                echo "<td><input type='text' name='ob5' value='8' size='4'></td></tr>";
                echo "</table></td>";
                echo "</tr>";

                echo "<tr><td>Izmensko delo: </td><td><input name='izmensko' type='checkbox'></td></tr>";
                echo "<tr><td>Konkurenčna klavzula: </td><td><input name='konkklavz' type='checkbox'></td></tr>";
                echo "<tr><td>Starejši delavec: </td><td><input name='starejsi' type='checkbox'></td></tr>";
                echo "<tr><td>Doječa mater: </td><td><input name='dojecamater' type='checkbox'></td></tr>";

                echo "<tr><td>Status</td><td>";
                echo "<select name='status'>";

                $SQL = "SELECT * FROM TabStatus";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["IdStatus"]."'>".$R["Status"]."</option>";
                }
                echo "</select></td></tr>";

                echo "<tr><td>Razlog sklenitve pog. za dol. čas: </td><td><input name='razlogdolcas' type='text' size='40' ></td></tr>";
                echo "<tr><td>Potrebna strokovna usposobljenost: </td><td><input name='potrstrokusp' type='text' size='30' ></td></tr>";
                echo "<tr><td>Naziv del. mesta: </td><td><input name='nazivdelmesta1' type='text' size='30'>če vpišete tu ročno, bo to vpisano, sicer izberite spodaj<br />";
                echo "<select name='nazivdelmesta'>";
                echo "<option>Ni izbran</option>";
                
                $SQL = "SELECT * FROM TabDelMesta";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option>".$R["DelMesto"]." (".$R["Sifra"].")</option>";
                }
                echo "</select></td></tr>";
                echo "<tr><td>Kraj dela: </td><td><input name='krajdela' type='text' size='40' ></td></tr>";
                echo "<tr><td>Dopolnjevanje dela: </td><td><input name='dopdela' type='checkbox'></td></tr>";
                echo "<tr><td>Dopolnilni delodajalec 1: </td><td><input name='delodaj1' type='text' size='30' ></td></tr>";
                echo "<tr><td>Mat. št. dop. delodajalca 1: </td><td><input name='delodaj1mat' type='text' size='10' ></td></tr>";
                echo "<tr><td>Naslov dop. delodajalca 1: </td><td><input name='delodaj1naslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Dopolnilni delodajalec 2: </td><td><input name='delodaj2' type='text' size='30' ></td></tr>";
                echo "<tr><td>Mat. št. dop. delodajalca 2: </td><td><input name='delodaj2mat' type='text' size='10' ></td></tr>";
                echo "<tr><td>Naslov dop. delodajalca 2: </td><td><input name='delodaj2naslov' type='text' size='30' ></td></tr>";
                echo "<tr><td>Dopolnilni delodajalec 3: </td><td><input name='delodaj3' type='text' size='30' ></td></tr>";
                echo "<tr><td>Mat. št. dop. delodajalca 3: </td><td><input name='delodaj3mat' type='text' size='10' ></td></tr>";
                echo "<tr><td>Naslov dop. delodajalca 3: </td><td><input name='delodaj3naslov' type='text' size='30' ></td></tr>";
                
                echo "<tr><td>Vrsta dela</td><td>";
                echo "<select name='vrstadela'>";
                
                $SQL = "SELECT * FROM TabVzgDelo";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["IdVzgojnoDelo"]."'>".$R["VzgojnoDelo"]."</option>";
                }
                echo "</select></td></tr>";
                
                //if ($EvidencaPrisotnosti==1 ) {
                    echo "<tr><td>Opis del in nalog (za več opisov drži Ctrl+klik)</td><td><select  name='delanaloge[]' multiple size=5>";
                    $SQL = "SELECT * FROM TabSistemizacija ORDER BY idSistemizacija";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        echo "<option value='".$R["idSistemizacija"]."'>".$R["idSistemizacija"].". ".$R["Opis"]."</option>";
                    }
                    echo "</select></td></tr>";
                //}
                
                echo "<tr><td>Datum začetka dela</td><td><input name='datumstart' type='text' size='15' value='".$Danes->format('d.m.Y')."' id='dat03'></td></tr>";
                echo "<tr><td>Datum zaključka dela</td><td><input name='datumend' type='text' size='15' id='dat04'></td></tr>";
                echo "<tr><td>Način prenehanja dela</td><td><input name='nacinprenehanja' type='text' size='30'></td></tr>";
                echo "<tr><td>Delovna doba v šolstvu</td><td><input name='deldobasol' type='text' size='3'></td></tr>";
                echo "<tr><td>Datum pridobitve ped.-andrag. izobrazbe</td><td><input name='pedizobr' type='text' size='15' id='dat05'></td></tr>";
                echo "<tr><td>Datum strokovnega izpita</td><td><input name='strokizpit' type='text' size='15' id='dat06'></td></tr>";
                echo "<tr><td>Datum pridobitve naziva mentor</td><td><input name='mentor' type='text' size='15' id='dat07'></td></tr>";
                echo "<tr><td>Datum pridobitve naziva svetovalec</td><td><input name='svetovalec' type='text' size='15' id='dat08'></td></tr>";
                echo "<tr><td>Datum pridobitve naziva svetnik</td><td><input name='svetnik' type='text' size='15' id='dat09'></td></tr>";
                
                echo "<tr><td>Uporabniško ime: </td><td><input name='uporabniskoime' type='text' size='10' ></td></tr>";
                echo "<tr><td>Geslo: </td><td><input name='upgeslo' type='text' size='10' ></td></tr>";
                echo "<tr><td>Uporabniške pravice</td><td>";
                echo "<select name='pravice'>";
                $SQL = "SELECT * FROM TabLevel";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    echo "<option value='".$R["IdLevel"]."'>".$R["Level"]."</option>";
                }
                echo "</select></td></tr>";
                
                echo "</table>";

                echo "<input name='id' type='hidden' value='3'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            
                break;
            case 3: //vpis novega delavca
                if (isset($_POST["priimek"])){
                   $VPriimek=$_POST["priimek"];
                }else{
                    $VPriimek="";
                }
                if (isset($_POST["dekliski"])){
                    $VDekliski=$_POST["dekliski"];
                }else{
                    $VDekliski="";
                }
                if (isset($_POST["ime"])){
                    $VIme=$_POST["ime"];
                }else{
                    $VIme="";
                }    
                if (isset($_POST["naslov"])){
                    $VNaslov=$_POST["naslov"];
                }else{
                    $VNaslov="";
                }
                if (isset($_POST["posta"])){    
                    $VPosta=$_POST["posta"];
                    if (strlen($VPosta)==0){
                        $VPosta=0;
                    }
                }else{
                    $VPosta=0;
                }
                if (isset($_POST["kraj"])){
                    $VKraj=$_POST["kraj"];
                }else{
                    $VKraj="";
                }
                if (isset($_POST["spol"])){
                    $VSpol=$_POST["spol"];
                }else{
                    $VSpol="M";
                }
                if (isset($_POST["datroj"])){
                    $datRoj=$_POST["datroj"];
                    if (isDate($datRoj)){
                        $VDatRoj=new DateTime(isDate($datRoj));
                    }else{
                        $VDatRoj=new DateTime("now");
                    }
                }else{
                    $VDatRoj=new DateTime("now");
                }
                if (isset($_POST["emso"])){
                    $Vemso=$_POST["emso"];
                }else{
                    $Vemso="";
                }
                if (isset($_POST["izobrazba"])){
                    $VIzobrazba=$_POST["izobrazba"];
                }else{
                    $VIzobrazba=1;
                }
                if (isset($_POST["poklic"])){
                    $Vpoklic= $_POST["poklic"];
                }else{
                    $Vpoklic="";
                }
                if (isset($_POST["ustreznost"])){
                    $Vustreznost= $_POST["ustreznost"];
                }else{
                    $Vustreznost=0;
                }
                if (isset($_POST["delovnomesto"])){
                    $Vdelovnomesto= $_POST["delovnomesto"];
                }else{
                    $Vdelovnomesto=0;
                }
                if (isset($_POST["delovnicas"])){
                    $Vdelovnicas=$_POST["delovnicas"];
                }else{
                    $Vdelovnicas=0;
                }
                if (isset($_POST["vrstadela"])){
                    $Vvrstadela=$_POST["vrstadela"];
                }else{
                    $Vvrstadela=0;
                }
                if (isset($_POST["deldobasol"])){
                    if (is_numeric($_POST["deldobasol"])){
                        $Vdeldobasol=$_POST["deldobasol"];
                    }else{
                        $Vdeldobasol=0;
                    }
                }else{
                    $Vdeldobasol=0;
                }
                if (isset($_POST["status"])){
                    $Vstatus=$_POST["status"];
                }else{
                    $Vstatus=0;
                }
                if ($Vstatus == 0){
                    echo "Pozor, delavca ste vpisali s statusom neaktivnega delavca!<br />";
                }
                if (isset($_POST["uporabniskoime"])){
                    $Vuporabniskoime=$_POST["uporabniskoime"];
                }else{
                    $Vuporabniskoime="";
                }
                $novuporabnik=false;
                while (!$novuporabnik){
                    if (strlen($Vuporabniskoime) > 0){
                        $SQL = "SELECT iducitelj,uporabnik FROM tabucitelji WHERE uporabnik='".$Vuporabniskoime."'";
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            $Vuporabniskoime .= "1";
                            echo "Novo uporabniško ime je: ".$Vuporabniskoime."<br />";
                        }else{
                            $novuporabnik=true;
                        }
                    }else{
                        echo "Delavec je vpisan brez uporabniškega imena!<br />";
                        $novuporabnik=true;
                    }
                }
                if (isset($_POST["upgeslo"])){
                    $dolzinaGesla=strlen($_POST["upgeslo"]);
                    if ($dolzinaGesla==32){
                        $Vupgeslo=$_POST["upgeslo"];
                    }else{
                        $Vupgeslo=md5($_POST["upgeslo"]);
                    }
                }else{
                    $Vupgeslo="";
                }
                if (isset($_POST["pedizobr"])){
                    $VPedIzobr=$_POST["pedizobr"];
                }else{
                    $VPedIzobr="";
                }
                if (isset($_POST["strokizpit"])){
                    $VStrokIzpit=$_POST["strokizpit"];
                }else{
                    $VStrokIzpit="";
                }
                if (isset($_POST["mentor"])){
                    $VMentor=$_POST["mentor"];
                }else{
                    $VMentor="";
                }
                if (isset($_POST["svetovalec"])){
                    $VSvetovalec=$_POST["svetovalec"];
                }else{
                    $VSvetovalec="";
                }
                if (isset($_POST["svetnik"])){
                    $VSvetnik=$_POST["svetnik"];
                }else{
                    $VSvetnik="";
                }
                if (isset($_POST["davcna"])){
                    $VDavcna=$_POST["davcna"];
                }else{
                    $VDavcna="";
                }
                if (isset($_POST["obcina"])){
                    $VObcina=$_POST["obcina"];
                }else{
                    $VObcina=999;
                }
                if (isset($_POST["drzava"])){
                    $VDrzava=$_POST["drzava"];
                }else{
                    $VDrzava=999;
                }
                if (isset($_POST["drzavljanstvo"])){
                    $Vdrzavljanstvo=$_POST["drzavljanstvo"];
                }else{
                    $Vdrzavljanstvo="";
                }
                if (isset($_POST["krajroj"])){
                    $VKrajRoj=$_POST["krajroj"];
                }else{
                    $VKrajRoj="";
                }
                if (isset($_POST["drzavaroj"])){
                    $VDrzavaRoj=$_POST["drzavaroj"];
                }else{
                    $VDrzavaRoj="";
                }
                if (isset($_POST["naslovzac"])){
                    $VNaslovZac=$_POST["naslovzac"];
                }else{
                    $VNaslovZac="";
                }
                if (isset($_POST["postazac"])){
                    $VPostaZac=$_POST["postazac"];
                    if (strlen($VPostaZac) == 0){
                        $VPostaZac=0;
                    }
                }else{
                    $VPostaZac=0;
                }
                if (isset($_POST["krajzac"])){
                    $VKrajZac=$_POST["krajzac"];
                }else{
                    $VKrajZac="";
                }
                if (isset($_POST["obcinazac"])){
                    $VObcinaZac=$_POST["obcinazac"];
                }else{
                    $VObcinaZac=999;
                }
                if (isset($_POST["drzavazac"])){
                    $VDrzavaZac=$_POST["drzavazac"];
                }else{
                    $VDrzavaZac=999;
                }
                if (isset($_POST["invalid"])){
                    $VInvalid="true";
                }else{
                    $VInvalid="false";
                }
                if (isset($_POST["katinvalid"])){
                    $VKatInvalid=$_POST["katinvalid"];
                }else{
                    $VKatInvalid="";
                }
                if (isset($_POST["delnoupokojen"])){
                    $VDelnoUpokojen=$_POST["delnoupokojen"];
                }else{
                    $VDelnoUpokojen="";
                }
                if (isset($_POST["dopdelo"])){
                    $VDopDelo="true";
                }else{
                    $VDopDelo="false";
                }
                if (isset($_POST["delodaj1"])){
                    $VDelodaj1=$_POST["delodaj1"];
                }else{
                    $VDelodaj1="";
                }
                if (isset($_POST["delodaj1mat"])){
                    $VDelodaj1mat=$_POST["delodaj1mat"];
                }else{
                    $VDelodaj1mat="";
                }
                if (isset($_POST["delodaj1naslov"])){
                    $VDelodaj1naslov=$_POST["delodaj1naslov"];
                }else{
                    $VDelodaj1naslov="";
                }
                if (isset($_POST["delodaj2"])){
                    $VDelodaj2=$_POST["delodaj2"];
                }else{
                    $VDelodaj2="";
                }
                if (isset($_POST["delodaj2mat"])){
                    $VDelodaj2mat=$_POST["delodaj2mat"];
                }else{
                    $VDelodaj2mat="";
                }
                if (isset($_POST["delodaj2naslov"])){
                    $VDelodaj2naslov=$_POST["delodaj2naslov"];
                }else{
                    $VDelodaj2naslov="";
                }
                if (isset($_POST["delodaj3"])){
                    $VDelodaj3=$_POST["delodaj3"];
                }else{
                    $VDelodaj3="";
                }
                if (isset($_POST["delodaj3mat"])){
                    $VDelodaj3mat=$_POST["delodaj3mat"];
                }else{
                    $VDelodaj3mat="";
                }
                if (isset($_POST["delodaj3naslov"])){
                    $VDelodaj3naslov=$_POST["delodaj3naslov"];
                }else{
                    $VDelodaj3naslov="";
                }
                if (isset($_POST["starejsi"])){
                    $VStarejsi="true";
                }else{
                    $VStarejsi="false";
                }    
                if (isset($_POST["dojecamati"])){
                    $VDojecaMati="true";
                }else{
                    $VDojecaMati="false";
                }
                if (isset($_POST["telefon"])){
                    $VTelefon=$_POST["telefon"];
                }else{
                    $VTelefon="";
                }
                if (isset($_POST["email"])){
                    $Vemail=$_POST["email"];
                }else{
                    $Vemail="";
                }
                if (isset($_POST["pravice"])){
                    $Vpravice=$_POST["pravice"];
                }else{
                    $Vpravice=0;
                }
                if (isset($_POST["datumstart"])){
                    $VDatumStart=$_POST["datumstart"];
                }else{
                    $VDatumStart=$Danes->format('d.m.Y');
                }
                if (isset($_POST["datumend"])){
                    $VDatumEnd=$_POST["datumend"];
                }else{
                    $VDatumEnd="";
                }
                if (isset($_POST["datumpogodbe"])){
                    $VDatumPogodbe=$_POST["datumpogodbe"];
                }else{
                    $VDatumPogodbe="";
                }
                if (isset($_POST["polnidelcas"])){
                    $VPolniDelCas="da";
                }else{
                    $VPolniDelCas="ne";
                }
                if (isset($_POST["razlogdolcas"])){    
                    $VRazlogDolCas=$_POST["razlogdolcas"];
                }else{
                    $VRazlogDolCas="";
                }
                if (isset($_POST["potrstrokusp"])){
                    $VPotrStrokUsp=$_POST["potrstrokusp"];
                }else{
                    $VPotrStrokUsp="";
                }
                if (isset($_POST["nazivdelmesta1"])){
                    if (strlen($_POST["nazivdelmesta1"]) > 0){
                        $VNazivDelMesta=$_POST["nazivdelmesta1"];
                    }else{
                        if (isset($_POST["nazivdelmesta"])){
                            $VNazivDelMesta=$_POST["nazivdelmesta"];
                        }else{
                            $VNazivDelMesta="";
                        }
                    }
                }else{
                    $VNazivDelMesta="";
                }
                if (isset($_POST["urteden"])){
                    $VUrTeden=$_POST["urteden"];
                }else{
                    $VUrTeden=40;
                }
                if (isset($_POST["izmensko"])){
                    $VIzmensko="true";
                }else{
                    $VIzmensko="false";
                }
                if (isset($_POST["krajdela"])){    
                    $VKrajDela=$_POST["krajdela"];
                }else{
                    $VKrajDela="";
                }
                if (isset($_POST["konkklavz"])){
                    $VKonkKlavz="true";
                }else{
                    $VKonkKlavz="false";
                }
                if (isset($_POST["nacinprenehanja"])){
                    $VNacinPrenehanja=$_POST["nacinprenehanja"];
                }else{
                    $VNacinPrenehanja="";
                }
                if (isset($_POST["delanaloge"])){
                    $DelaNaloge=Arr2Str($_POST["delanaloge"]);
                }else{
                    $DelaNaloge="0";
                }
                /* if ($EvidencaPrisotnosti ) {
                    if (isset($_POST["delanaloge"])){
                        $DelaNaloge=$_POST["delanaloge"];
                    }else{
                        $DelaNaloge=0;
                    }
                }
                */
                if (isset($_POST["stpogodbe"])){
                    $VStPogodbe=$_POST["stpogodbe"];
                }else{
                    $VStPogodbe="";
                }
                if (isset($_POST["ob1"])){
                    $VObremen1=str_replace(",",".",$_POST["ob1"]);
                }else{
                    $VObremen1=8;
                }
                if (isset($_POST["ob2"])){
                    $VObremen2=str_replace(",",".",$_POST["ob2"]);
                }else{
                    $VObremen2=8;
                }
                if (isset($_POST["ob3"])){
                    $VObremen3=str_replace(",",".",$_POST["ob3"]);
                }else{
                    $VObremen3=8;
                }
                if (isset($_POST["ob4"])){
                    $VObremen4=str_replace(",",".",$_POST["ob4"]);
                }else{
                    $VObremen4=8;
                }
                if (isset($_POST["ob5"])){
                    $VObremen5=str_replace(",",".",$_POST["ob5"]);
                }else{
                    $VObremen5=8;
                }

                switch ($Vpravice){
                    case 2:
                        if ($VLevel < 2 ) { $Vpravice=1;}
                        break;
                    case 3:
                        if ($VLevel < 3 ) { $Vpravice=2;}
                        if ($VLevel < 2 ) { $Vpravice=1;}
                }

                $SQL = "SELECT * FROM tabucitelji ORDER BY IdUcitelj DESC";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $ucitelj=$R["IdUcitelj"]+1;
                }

                $SQL = "INSERT INTO tabucitelji (IdUcitelj,Priimek,Ime,dekliski,Spol,DatRoj,LetoRoj,EMSO,Naslov,Posta,Kraj,Izobrazba,IzobOpis,IzobUstr,IdDelo,DelovniCas,IdVzgojnoDelo,Uporabnik,Geslo,Status,NivoDostopa,DatumStart,DatumEnd,DelDobaSol,PedIzobr,StrokIzpit,Mentor,Svetovalec,Svetnik";
                $SQL = $SQL . ",davcna,obcina,drzava,drzavljanstvo,krajRoj,DrzavaRoj,NaslovZac,PostaZac,KrajZac,ObcinaZac,DrzavaZac,Invalid,KatInvalid,DelnoUpokojen,DopDelo";
                $SQL = $SQL . ",Delodaj1,Delodaj1mat,Delodaj1naslov,Delodaj2,Delodaj2mat,Delodaj2naslov,Delodaj3,Delodaj3mat,Delodaj3naslov,DatumPogodbe,PolniDelCas,RazlogDolCas";
                $SQL = $SQL . ",PotrStrokUsp,NazivDelMesta,UrTeden,Izmensko,KrajDela,KonkKlavz,NacinPrenehanja,Starejsi,DojecaMati";
                $SQL = $SQL .")";
                $SQL = $SQL . " values (".$ucitelj.",'" . $VPriimek . "','" . $VIme . "','" . $VDekliski ."','" . $VSpol . "','" . $VDatRoj->format('Y-m-d') . "'," . $VDatRoj->format('Y') . ",'" . $Vemso . "','" . $VNaslov . "'," . $VPosta . ",'" . $VKraj . "'," . $VIzobrazba.",'" . $Vpoklic ."'," . $Vustreznost . ",".$Vdelovnomesto.",".$Vdelovnicas.",".$Vvrstadela;
                $SQL = $SQL .",'".$Vuporabniskoime."','".$Vupgeslo."',".$Vstatus.",".$Vpravice.",'".$VDatumStart."','".$VDatumEnd."',".$Vdeldobasol.",'".$VPedIzobr."','".$VStrokIzpit."','".$VMentor."','".$VSvetovalec."','".$VSvetnik."'";
                $SQL = $SQL . ",'".$VDavcna."','".$VObcina."','".$VDrzava."','".$Vdrzavljanstvo."','".$VKrajRoj."','".$VDrzavaRoj."','".$VNaslovZac."','".$VPostaZac."','".$VKrajZac."','".$VObcinaZac."','".$VDrzavaZac."',".$VInvalid.",'".$VKatInvalid."','".$VDelnoUpokojen."',".$VDopDelo;
                $SQL = $SQL . ",'".$VDelodaj1."','".$VDelodaj1mat."','".$VDelodaj1naslov."','".$VDelodaj2."','".$VDelodaj2mat."','".$VDelodaj2naslov."','".$VDelodaj3."','".$VDelodaj3mat."','".$VDelodaj3naslov."','".$VDatumPogodbe."','".$VPolniDelCas."','".$VRazlogDolCas."'";
                $SQL = $SQL . ",'".$VPotrStrokUsp."','".$VNazivDelMesta."','".$VUrTeden."',".$VIzmensko.",'".$VKrajDela."',".$VKonkKlavz.",'".$VNacinPrenehanja."',".$VStarejsi.",".$VDojecaMati;
                $SQL = $SQL .")";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }
                
                $SQL = "INSERT INTO tabpogodbe (IdUcitelj,IzobUstr,IdDelo,DelovniCas,IdVzgojnoDelo,DatumStart,DatumEnd";
                $SQL = $SQL . ",DopDelo";
                $SQL = $SQL . ",Delodaj1,Delodaj1mat,Delodaj1naslov,Delodaj2,Delodaj2mat,Delodaj2naslov,Delodaj3,Delodaj3mat,Delodaj3naslov,DatumPogodbe,PolniDelCas,RazlogDolCas";
                $SQL = $SQL . ",PotrStrokUsp,NazivDelMesta,UrTeden,Izmensko,KrajDela,KonkKlavz,NacinPrenehanja";
                $SQL = $SQL . ",StPogodbe,obremen1,obremen2,obremen3,obremen4,obremen5";
                $SQL = $SQL .")";
                $SQL = $SQL . " values (".$ucitelj."," . $Vustreznost . ",".$Vdelovnomesto.",".$Vdelovnicas.",".$Vvrstadela;
                $SQL = $SQL .",'".$VDatumStart."','".$VDatumEnd."'";
                $SQL = $SQL . ",".$VDopDelo;
                $SQL = $SQL . ",'".$VDelodaj1."','".$VDelodaj1mat."','".$VDelodaj1naslov."','".$VDelodaj2."','".$VDelodaj2mat."','".$VDelodaj2naslov."','".$VDelodaj3."','".$VDelodaj3mat."','".$VDelodaj3naslov."','".$VDatumPogodbe."','".$VPolniDelCas."','".$VRazlogDolCas."'";
                $SQL = $SQL . ",'".$VPotrStrokUsp."','".$VNazivDelMesta."','".$VUrTeden."',".$VIzmensko.",'".$VKrajDela."',".$VKonkKlavz.",'".$VNacinPrenehanja."'";
                $SQL = $SQL . ",'".$VStPogodbe."',".$VObremen1.",".$VObremen2.",".$VObremen3.",".$VObremen4.",".$VObremen5;
                $SQL = $SQL .")";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }

                $SQL = "INSERT INTO TabVzgojitelji (IdUcitelj,Priimek,Ime) values (".$ucitelj.",'" . $VPriimek . "','" . $VIme ."')";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }

                $SQL = "INSERT INTO TabDopust (leto,idUcitelj) VALUES ";
                $SQL = $SQL . "(".$Danes->format('Y').",".$ucitelj.")";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }

                $SQL = "INSERT INTO tabkontakti (idUcitelj,Telefon,email) VALUES (".$ucitelj.",'".$VTelefon."','".$Vemail."')";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }

                $SQL = "INSERT INTO TabDostop (idUcitelj,";
                $SQL = $SQL . "VnosUcDat,";
                $SQL = $SQL . "UpdUc,";
                $SQL = $SQL . "Redov,";
                $SQL = $SQL . "VnosNPZ,";
                $SQL = $SQL . "ImpExNPZ,";
                $SQL = $SQL . "DelPregl,";
                $SQL = $SQL . "DelKontr,";
                $SQL = $SQL . "UpdDel,";
                $SQL = $SQL . "Tajn,";
                $SQL = $SQL . "VnosSist,";
                $SQL = $SQL . "VnosAktivi,";
                $SQL = $SQL . "VnosUrnik,";
                $SQL = $SQL . "VnosNadom,";
                $SQL = $SQL . "inventura,";
                $SQL = $SQL . "StatUc,";
                $SQL = $SQL . "StatDel,";
                $SQL = $SQL . "LetnPor,";
                $SQL = $SQL . "Prehrana,";
                $SQL = $SQL . "Prisotnost,";
                $SQL = $SQL . "NovoSL,";
                $SQL = $SQL . "ImpExUc,";
                $SQL = $SQL . "DatSola,";
                $SQL = $SQL . "Prazniki,";
                $SQL = $SQL . "Prostori,";
                $SQL = $SQL . "Predmeti,";
                $SQL = $SQL . "TabEd,";
                $SQL = $SQL . "RDU,";
                $SQL = $SQL . "PreglZbirn,";
                $SQL = $SQL . "PreglPoroc,";
                $SQL = $SQL . "PreglReal,";
                $SQL = $SQL . "drugo1,";
                $SQL = $SQL . "drugo2,";
                $SQL = $SQL . "drugo3,";
                $SQL = $SQL . "drugo4,";
                $SQL = $SQL . "drugo5,";
                $SQL = $SQL . "drugo6,";
                $SQL = $SQL . "drugo7,";
                $SQL = $SQL . "drugo8,";
                $SQL = $SQL . "drugo9";
                $SQL = $SQL . ") VALUES (".$ucitelj.",";
                switch ($Vpravice){
                    case 1:
                        $SQL = $SQL . "true,true,true,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "true,false,false,true,true,true,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                        break;
                    case 2:
                        $SQL = $SQL . "true,true,true,true,false,true,true,true,false,true,";
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true,true,";
                        $SQL = $SQL . "false,true,true,true,true,false,true,true,true,true,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                        break;
                    default:
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                }
                $SQL = $SQL . ")";
                $result = mysqli_query($link,$SQL);
                if (!$result){
                    die('Napaka pri vpisu v bazo: '. mysqli_error());
                }

                //if ($EvidencaPrisotnosti=1 ) {
                    $SQL = "UPDATE tabucitelji SET Sistemizacija='".$DelaNaloge."' WHERE idUcitelj=".$ucitelj;
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die('Napaka pri vpisu v bazo: '. mysqli_error());
                    }
                //}

                //Izpis osebnih podatkov
                $SQL = "SELECT * FROM tabucitelji WHERE IdUcitelj=".$ucitelj;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<h2>Vpisali ste podatke o delavcu:</h2>";
                    echo "<a href='IzpisUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</a><br>";
                    echo "<a href='DodajPogodbo.php?id=5&idUcitelj=".$R["IdUcitelj"]."'>Pregled podatkov iz pogodbe</a><br>";
                    echo "<h3><a href='DostopnaKontrola.php'>Vpis/sprememba dostopnih pravic</a></h3>";
                    echo "<a href='PopraviUcitelja.php?id=2'>Dodaj novega delavca</a><br>";
                    
                    $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$R["IdUcitelj"];
                    $result = mysqli_query($link,$SQL);

                    echo "<table border='1'>";
                    echo "<tr><th>Št.</th><th>Datum</th><th>Številka</th><th>Začetek</th><th>Konec</th><th>Delovno mesto</th><th>ur</th><th>Briši</th><th>Popravi</th></tr>";
                    $indx=0;
                    if ($R1 = mysqli_fetch_array($result)){
                        $indx=$indx+1;
                        echo "<tr>";
                        echo "<td>".$indx."</td>";
                        echo "<td>".$R1["DatumPogodbe"]."</td>";
                        echo "<td>".$R1["StPogodbe"]."</td>";
                        echo "<td>".$R1["DatumStart"]."</td>";
                        echo "<td>".$R1["DatumEnd"]."</td>";
                        echo "<td>".$R1["NazivDelMesta"]."</td>";
                        echo "<td>".$R1["UrTeden"]."</td>";
                        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=2&brisi=".$R1["Id"]."'>Briši</a></td>";
                        echo "<td><a href='DodajPogodbo.php?idUcitelj=".$R1["IdUcitelj"]."&id=3&popravi=".$R1["Id"]."'>Popravi</a></td>";
                        echo "</tr>";
                    }
                    echo "</table><br />";
                }

                if ($EvidencaPrisotnosti==1 ) {
                    $SQL = "INSERT INTO Kadrovi (stdelavca,sifra,priimime,emso) VALUES ('".$ucitelj."',".$ucitelj.",'".$VPriimek." ".$VIme."','".$ucitelj."')";
                    $result = mysqli_query($link,$SQL);
                    if (!$result){
                        die('Napaka pri vpisu v bazo: '. mysqli_error());
                    }
                }
                break;
            default:  //obrazec za popravljanje delavca  
                $oUcitelj = new RUcitelj($ucitelj);
                $oUcitelj->PreberiSeGlavno($ucitelj,$VLetoPregled,$VLeto);

                $RazsirjenVnos=true;

                if ($VLevel > 1)  {
	                echo "<form accept-charset='utf-8' name='dodajucenca' method='post' action='PopraviUcitelja.php'>";
	                echo "<h2>Popravi podatke delavca</h2>";
	                
	                echo "<table>";
	                echo "<tr><td><input name='idUcitelj' type='hidden' value='".$oUcitelj->getIdUcitelj()."'>Priimek: </td><td><input name='priimek' type='text' size='25' value='".$oUcitelj->getPriimek()."'></td></tr>";
	                echo "<tr><td>Ime: </td><td><input name='ime' type='text' size='25' value='".$oUcitelj->getIme()."'></td></tr>";
	                echo "<tr><td>Dekliški priimek: </td><td><input name='dekliski' type='text' size='25' value='".$oUcitelj->getDekliski()."'></td></tr>";
	                echo "<tr><td>Spol:</td><td><select name='spol'><option selected>".$oUcitelj->getSpol()."</option><option>M</option><option>F</option></select></td></tr>";
                    $datRoj=$oUcitelj->getDatRoj();
	                echo "<tr><td>Datum rojstva: </td><td><input name='datroj' type='text' size='10' value='".$datRoj->format('d.m.Y')."' id='dat01'></td></tr>";
	                echo "<tr><td>Kraj rojstva: </td><td><input name='krajroj' type='text' size='20' value='".$oUcitelj->getKrajRoj()."'></td></tr>";
	                echo "<tr><td>Država rojstva: </td><td><input name='drzavaroj' type='text' size='20' value='".$oUcitelj->getDrzavaRoj()."'></td></tr>";
	                echo "<tr><td>Državljanstvo: </td><td><input name='drzavljanstvo' type='text' size='20' value='".$oUcitelj->getDrzavljanstvo()."'></td></tr>";
	                echo "<tr><td>EMŠO: </td><td><input name='emso' type='text' size='15' value='".$oUcitelj->getEmso()."'></td></tr>";
	                echo "<tr><td>Davčna številka: </td><td><input name='davcna' type='text' size='10' value='".$oUcitelj->getDavcna()."'></td></tr>";
	                echo "<tr><td>Naslov: </td><td><input name='naslov' type='text' size='40' value='".$oUcitelj->getNaslov()."'></td></tr>";
	                echo "<tr><td>Pošta: </td><td><input name='posta' type='text' size='5' value='".$oUcitelj->getPosta()."'></td></tr>";
	                echo "<tr><td>Kraj: </td><td><input name='kraj' type='text' size='25' value='".$oUcitelj->getKraj()."'></td></tr>";

	                echo "<tr><td>Občina: </td><td><select name='obcina'>";
	                $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($R["sifra"]==$oUcitelj->getObcina()) {
			                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
		                }else{
			                echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
		                }
	                }
	                echo "</select></td></tr>";

	                echo "<tr><td>Država: </td><td><select name='drzava'>";
	                $SQL = "SELECT * FROM TabSifrantDrzav ORDER BY drzava";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($R["sifra"]==$oUcitelj->getDrzava()) {
			                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["drzava"]."</option>";
		                }else{
			                echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["drzava"]."</option>";
		                }
	                }
	                echo "</select></td></tr>";
	                
	                echo "<tr><td>Naslov zač. bivališča: </td><td><input name='naslovzac' type='text' size='40' value='".$oUcitelj->getNaslovZac()."'></td></tr>";
	                echo "<tr><td>Pošta zač. bivališča: </td><td><input name='postazac' type='text' size='5' value='".$oUcitelj->getPostaZac()."'></td></tr>";
	                echo "<tr><td>Kraj zač. bivališča: </td><td><input name='krajzac' type='text' size='25' value='".$oUcitelj->getKrajZac()."'></td></tr>";
	                echo "<tr><td>Občina zač. bivališča: </td><td><select name='obcinazac'>";
                    echo "<option value='999' selected='selected'>999 - Nedoločeno</option>";

	                $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($R["sifra"]==$oUcitelj->getObcinaZac() ) {
			                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
		                }else{
			                echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
		                }
	                }
	                echo "</select></td></tr>";
	                
	                echo "<tr><td>Država zač. bivališča: </td><td><select name='drzavazac'>";
                    echo "<option value='999' selected='selected'>999 - NERAZVRŠČENO</option>";

	                $SQL = "SELECT * FROM TabSifrantDrzav ORDER BY drzava";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($R["sifra"]==$oUcitelj->getDrzavaZac() ) {
			                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["drzava"]."</option>";
		                }else{
			                echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["drzava"]."</option>";
		                }
	                }
	                echo "</select></td></tr>";

	                echo "<tr><td>Telefon</td><td><input name='telefon' type='text' size='20' value='".$oUcitelj->getTelefon()."'></td></tr>";
	                echo "<tr><td>e-mail</td><td><input name='email' type='text' size='60' value='".$oUcitelj->getEmail()."'></td></tr>";
	                
	                echo "<tr><td>Stopnja izobrazbe</td><td>";
	                echo "<select name='izobrazba'>";

	                $SQL = "SELECT * FROM TabIzobrazba";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($R["Opis"]==$oUcitelj->getIzobrazba()) {
			                echo "<option value='".$R["idIzobrazba"]."' selected='selected'>".$R["Opis"]."</option>";
		                }else{
			                echo "<option value='".$R["idIzobrazba"]."'>".$R["Opis"]."</option>";
		                }
	                }
	                echo "</select></td></tr>";

	                echo "<tr><td>Izobrazba: </td><td><input name='poklic' type='text' size='40' value='".$oUcitelj->getIzobOpis()."'></td></tr>";

	                if ($oUcitelj->getInvalid()) {
		                echo "<tr><td>Invalidnost: </td><td><input name='invalid' type='checkbox' checked='checked'></td></tr>";
	                }else{
		                echo "<tr><td>Invalidnost: </td><td><input name='invalid' type='checkbox'></td></tr>";
	                }
	                echo "<tr><td>Kategorija invalidnosti: </td><td><input name='katinvalid' type='text' size='10' value='".$oUcitelj->getKatInvalid()."'></td></tr>";
	                echo "<tr><td>Delna upokojitev: </td><td><input name='delnoupokojen' type='text' value='".$oUcitelj->getDelnoUpokojen()."'></td></tr>";

	                if ($oUcitelj->getStarejsi()) {
		                echo "<tr><td>Starejši delavec: </td><td><input name='starejsi' type='checkbox' checked='checked'></td></tr>";
	                }else{
		                echo "<tr><td>Starejši delavec: </td><td><input name='starejsi' type='checkbox'></td></tr>";
	                }
	                if ($oUcitelj->getDojecaMati()) {
		                echo "<tr><td>Doječa mati: </td><td><input name='dojecamati' type='checkbox' checked='checked'></td></tr>";
	                }else{
		                echo "<tr><td>Doječa mati: </td><td><input name='dojecamati' type='checkbox'></td></tr>";
	                }

	                echo "<tr><td>Status</td><td>";
	                echo "<select name='status'>";
	                $SQL = "SELECT * FROM TabStatus";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($oUcitelj->getStatus()==$R["IdStatus"] ) {
			                echo "<option value='".$R["IdStatus"]."' selected='selected'>".$R["Status"]."</option>";
		                }else{
			                echo "<option value='".$R["IdStatus"]."'>".$R["Status"]."</option>";
		                }
                    }
	                echo "</select></td></tr>";
	                
	                echo "<tr><td>Delovna doba v šolstvu</td><td><input name='deldobasol' type='text' size='3' value='".$oUcitelj->getDelDobaSol()."'></td></tr>";
	                echo "<tr><td>Datum pridobitve ped.-andrag. izobrazbe</td><td><input name='pedizobr' type='text' size='15' value='".$oUcitelj->getPedIzobr()."' id='dat02'></td></tr>";
	                echo "<tr><td>Datum strokovnega izpita</td><td><input name='strokizpit' type='text' size='15' value='".$oUcitelj->getStrokIzpit()."' id='dat03'></td></tr>";
	                echo "<tr><td>Datum pridobitve naziva mentor</td><td><input name='mentor' type='text' size='15' value='".$oUcitelj->getMentor()."' id='dat04'></td></tr>";
	                echo "<tr><td>Datum pridobitve naziva svetovalec</td><td><input name='svetovalec' type='text' size='15' value='".$oUcitelj->getSvetovalec()."' id='dat05'></td></tr>";
	                echo "<tr><td>Datum pridobitve naziva svetnik</td><td><input name='svetnik' type='text' size='15' value='".$oUcitelj->getSvetnik()."' id='dat06'></td></tr>";
	                
	                echo "<tr><td>Uporabniško ime: </td><td><input name='uporabniskoime' type='text' size='10' value='".$oUcitelj->getUporabnik()."'></td></tr>";
	                echo "<tr><td>Geslo: </td><td><input name='upgeslo' type='password' size='10' value='".$oUcitelj->getGeslo()."'></td></tr>";
	                echo "<tr><td>Uporabniške pravice</td><td>";
	                echo "<select name='pravice'>";
	                $SQL = "SELECT * FROM TabLevel";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
		                if ($oUcitelj->getNivoDostopa()==$R["IdLevel"] ) {
			                echo "<option value='".$R["IdLevel"]."' selected='selected'>".$R["Level"]."</option>";
		                }else{
			                echo "<option value='".$R["IdLevel"]."'>".$R["Level"]."</option>";
		                }
                    }
	                echo "</select></td></tr>";
	                
	                echo "</table>";

                    echo "<input name='id' type='hidden' value='1'>";
	                echo "<input name='submit' type='submit' value='Pošlji'>";
	                echo "</form>";
                }else{
 	                //echo "Nimate potrebnih pooblastil za vpis podatkov!";
                    header("Location: nepooblascen.htm");
                }
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>

</body>
</html>
