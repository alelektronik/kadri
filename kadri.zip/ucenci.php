<?php
class RUcenec {
    private $IdUcenec;
    private $Priimek;  
    private $Ime;
    private $DatRoj;  
    private $KrajRoj;  
    private $DrzavaRoj;  
    private $Drzavljanstvo; 
    private $emso;  
    private $MaticniList; 
    private $MaticnaKnjiga; 
    private $Naslov;  
    private $Posta;  
    private $Kraj;  
    private $NaslovZac;  
    private $PostaZac;  
    private $KrajZac;  
    private $TelefonDoma; 
    private $oce;  
    private $ocenaslov;  
    private $ocezacnasl;  
    private $ocekontakt; 
    private $oceGSM;  
    private $oceSluzba;  
    private $oceemail;  
    private $mati;  
    private $matinaslov; 
    private $matizacnasl; 
    private $matikontakt; 
    private $matiGSM;  
    private $matiSluzba; 
    private $matiemail;  
    private $Aktivnost;  
    private $LetoRoj;  
    private $IdKrajBivanja; 
    private $IdKrajBivanjaZac; 
    private $Spol;  
    private $IdPosebnePotrebe; 
    private $Bivanje;  
    private $Rom;  
    private $ZacSolanja; 
    private $KonSolanja; 
    private $ZacSolanjaSola; 
    private $KonSolanjaSola; 
    private $Skrbniki;  
    private $SkrbnikiNaslov; 
    private $SkrbnikiKontakt; 
    private $SkrbnikiEmail; 
    private $Placnik;  
    private $PlacnikNaslov; 
    private $PlacnikKontakt; 
    private $Opombe;  
    private $OSObveza;  
    private $SolskiOkolis; 
    private $OtrokZiviPri;
    
    //dodatna polja - iz indeksnih tabel
    private $mAktivnoat;
    private $mKrajBivanja;
    private $mKrajBivanjaZac;
    private $mBivanje;
    private $mPosebnePotrebe;
    
//    function __construct() {
//    }
    
//    function __destruct() {
//    }
    
// get, set metode - začetek
    public function setIdUcenec($s) {
        $this->IdUcenec = $s;
    }
    public function getIdUcenec() {
        return $this->IdUcenec;
    }

    public function setIme($s) {
        $this->Ime = $s;
    }
    public function getIme() {
        return $this->Ime;
    }
     
    public function setPriimek($s) {
        $this->Priimek = $s;
    }
    public function getPriimek() {
        return $this->Priimek;
    }

    public function setDatRoj($s) {
        $this->DatRoj = $s;
    }
    public function getDatRoj() {
        return $this->DatRoj;
    }

    public function setKrajRoj($s) {
        $this->KrajRoj = $s;
    }
    public function getKrajRoj() {
        return $this->KrajRoj;
    }

    public function setDrzavaRoj($s) {
        $this->DrzavaRoj = $s;
    }
    public function getDrzavaRoj() {
        return $this->DrzavaRoj;
    }

    public function setDrzavljanstvo($s) {
        $this->Drzavljanstvo = $s;
    }
    public function getDrzavljanstvo() {
        return $this->Drzavljanstvo;
    }

    public function setemso($s) {
        $this->emso = $s;
    }
    public function getemso() {
        return $this->emso;
    }

    public function setMaticniList($s) {
        $this->MaticniList = $s;
    }
    public function getMaticniList() {
        return $this->MaticniList;
    }

    public function setMaticnaKnjiga($s) {
        $this->MaticnaKnjiga = $s;
    }
    public function getMaticnaKnjiga() {
        return $this->MaticnaKnjiga;
    }

    public function setNaslov($s) {
        $this->Naslov = $s;
    }
    public function getNaslov() {
        return $this->Naslov;
    }

    public function setPosta($s) {
        $this->Posta = $s;
    }
    public function getPosta() {
        return $this->Posta;
    }

    public function setKraj($s) {
        $this->Kraj = $s;
    }
    public function getKraj() {
        return $this->Kraj;
    }

    public function setNaslovZac($s) {
        $this->NaslovZac = $s;
    }
    public function getNaslovZac() {
        return $this->NaslovZac;
    }

    public function setPostaZac($s) {
        $this->PostaZac = $s;
    }
    public function getPostaZac() {
        return $this->PostaZac;
    }

    public function setKrajZac($s) {
        $this->KrajZac = $s;
    }
    public function getKrajZac() {
        return $this->KrajZac;
    }

    public function setTelefonDoma($s) {
        $this->TelefonDoma = $s;
    }
    public function getTelefonDoma() {
        return $this->TelefonDoma;
    }

    public function setoce($s) {
        $this->oce = $s;
    }
    public function getoce() {
        return $this->oce;
    }

    public function setocenaslov($s) {
        $this->ocenaslov = $s;
    }
    public function getocenaslov() {
        return $this->ocenaslov;
    }

    public function setocezacnasl($s) {
        $this->ocezacnasl = $s;
    }
    public function getocezacnasl() {
        return $this->ocezacnasl;
    }

    public function setocekontakt($s) {
        $this->ocekontakt = $s;
    }
    public function getocekontakt() {
        return $this->ocekontakt;
    }

    public function setoceGSM($s) {
        $this->oceGSM = $s;
    }
    public function getoceGSM() {
        return $this->oceGSM;
    }

    public function setoceSluzba($s) {
        $this->oceSluzba = $s;
    }
    public function getoceSluzba() {
        return $this->oceSluzba;
    }

    public function setoceemail($s) {
        $this->oceemail = $s;
    }
    public function getoceemail() {
        return $this->oceemail;
    }

    public function setmati($s) {
        $this->mati = $s;
    }
    public function getmati() {
        return $this->mati;
    }

    public function setmatinaslov($s) {
        $this->matinaslov = $s;
    }
    public function getmatinaslov() {
        return $this->matinaslov;
    }

    public function setmatizacnasl($s) {
        $this->matizacnasl = $s;
    }
    public function getmatizacnasl() {
        return $this->matizacnasl;
    }

    public function setmatikontakt($s) {
        $this->matikontakt = $s;
    }
    public function getmatikontakt() {
        return $this->matikontakt;
    }

    public function setmatiGSM($s) {
        $this->matiGSM = $s;
    }
    public function getmatiGSM() {
        return $this->matiGSM;
    }

    public function setmatiSluzba($s) {
        $this->matiSluzba = $s;
    }
    public function getmatiSluzba() {
        return $this->matiSluzba;
    }

    public function setmatiemail($s) {
        $this->matiemail = $s;
    }
    public function getmatiemail() {
        return $this->matiemail;
    }

    public function setAktivnost($s) {
        $this->Aktivnost = $s;
    }
    public function getAktivnost() {
        return $this->Aktivnost;
    }

    public function setLetoRoj($s) {
        $this->LetoRoj = $s;
    }
    public function getLetoRoj() {
        return $this->LetoRoj;
    }
    //nacin prihoda v šolo
    public function setIdKrajBivanja($s) {
        $this->IdKrajBivanja = $s;
    }
    public function getIdKrajBivanja() {
        return $this->IdKrajBivanja;
    }
    /*
    public function setIdKrajBivanjaZac($s) {
        $this->IdKrajBivanjaZac = $s;
    }
    public function getIdKrajBivanjaZac() {
        return $this->IdKrajBivanjaZac;
    }
    */
    public function setSpol($s) {
        $this->Spol = $s;
    }
    public function getSpol() {
        return $this->Spol;
    }
    public function getSpol2() {
        if ($this->Spol == "M"){
            return "moški";
        }else{
            return "ženski";
        }
    }

    public function setIdPosebnePotrebe($s) {
        $this->IdPosebnePotrebe = $s;
    }
    public function getIdPosebnePotrebe() {
        return $this->IdPosebnePotrebe;
    }

    public function setBivanje($s) {
        $this->Bivanje = $s;
    }
    public function getBivanje() {
        return $this->Bivanje;
    }

    public function setRom($s) {
        $this->Rom = $s;
    }
    public function getRom() {
        return $this->Rom;
    }

    public function setZacSolanja($s) {
        $this->ZacSolanja = $s;
    }
    public function getZacSolanja() {
        return $this->ZacSolanja;
    }

    public function setKonSolanja($s) {
        $this->KonSolanja = $s;
    }
    public function getKonSolanja() {
        return $this->KonSolanja;
    }

    public function setZacSolanjaSola($s) {
        $this->ZacSolanjaSola = $s;
    }
    public function getZacSolanjaSola() {
        return $this->ZacSolanjaSola;
    }

    public function setKonSolanjaSola($s) {
        $this->KonSolanjaSola = $s;
    }
    public function getKonSolanjaSola() {
        return $this->KonSolanjaSola;
    }

    public function setSkrbniki($s) {
        $this->Skrbniki = $s;
    }
    public function getSkrbniki() {
        return $this->Skrbniki;
    }

    public function setSkrbnikiNaslov($s) {
        $this->SkrbnikiNaslov = $s;
    }
    public function getSkrbnikiNaslov() {
        return $this->SkrbnikiNaslov;
    }

    public function setSkrbnikiKontakt($s) {
        $this->SkrbnikiKontakt = $s;
    }
    public function getSkrbnikiKontakt() {
        return $this->SkrbnikiKontakt;
    }

    public function setSkrbnikiEmail($s) {
        $this->SkrbnikiEmail = $s;
    }
    public function getSkrbnikiEmail() {
        return $this->SkrbnikiEmail;
    }

    public function setPlacnik($s) {
        $this->Placnik = $s;
    }
    public function getPlacnik() {
        return $this->Placnik;
    }

    public function setPlacnikNaslov($s) {
        $this->PlacnikNaslov = $s;
    }
    public function getPlacnikNaslov() {
        return $this->PlacnikNaslov;
    }

    public function setPlacnikKontakt($s) {
        $this->PlacnikKontakt = $s;
    }
    public function getPlacnikKontakt() {
        return $this->PlacnikKontakt;
    }

    public function setOpombe($s) {
        $this->Opombe = $s;
    }
    public function getOpombe() {
        return $this->Opombe;
    }

    public function setOSObveza($s) {
        $this->OSObveza = $s;
    }
    public function getOSObveza() {
        return $this->OSObveza;
    }

    public function setSolskiOkolis($s) {
        $this->SolskiOkolis = $s;
    }
    public function getSolskiOkolis() {
        return $this->SolskiOkolis;
    }
    //bivanje pri (id) 
    public function setOtrokZiviPri($s) {
        $this->OtrokZiviPri = $s;
    }
    public function getOtrokZiviPri() {
        return $this->OtrokZiviPri;
    }
/*            private $mAktivnoat;
            private $mKrajBivanja;
            private $mKrajBivanjaZac;
            private $mBivanje;
            private $mPosebnePotrebe;
            */
    public function getStatus() {
        return $this->mAktivnost;
    }
    public function getKrajBivanja() {
        return $this->mKrajBivanja;
    }
    public function getKrajBivanjaZac() {
        return $this->mKrajBivanjaZac;
    }
    public function getBivanjePri() {
        return $this->mBivanje;
    }
    public function getPosebnePotrebe() {
        return $this->mPosebnePotrebe;
    }
    
// get, set metode - konec
    
    public function getUcenec($id) {
        global $link;
        global $VLeto;
        
        $SQL = "SELECT * FROM tabucenci WHERE iducenec=".$id;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)) {
            $this->IdUcenec = $R["IdUcenec"];
            $this->Priimek = $R["Priimek"];
            $this->Ime = $R["Ime"];
            $Datum=new DateTime(isDate($R["DatRoj"]));
            $this->DatRoj = $Datum->format('d. m. Y');
            if (isset($R["KrajRoj"])){
                $this->KrajRoj = $R["KrajRoj"];
            }else{
                $this->KrajRoj = "";
            }
            if (isset($R["DrzavaRoj"])){
                $this->DrzavaRoj = $R["DrzavaRoj"];               //besedilo ali tabsifrantdrzav
            }else{
                $this->DrzavaRoj = "";
            }
            if (isset($R["Drzavljanstvo"])){
                $this->Drzavljanstvo = $R["Drzavljanstvo"];       //besedilo ali tabsifrantdrzav
            }else{
                $this->Drzavljanstvo = "";
            }
            $this->emso = $R["emso"];
            if (isset($R["MaticniList"])){
                $this->MaticniList = $R["MaticniList"];
            }else{
                $this->MaticniList = "";
            }
            if (isset($R["MaticnaKnjiga"])){
                $this->MaticnaKnjiga = $R["MaticnaKnjiga"];
            }else{
                $this->MaticnaKnjiga = "";
            }
            $this->Naslov = $R["Naslov"];
            $this->Posta = $R["Posta"];
            $this->Kraj = $R["Kraj"];
            if (isset($R["NaslovZac"])){
                $this->NaslovZac = $R["NaslovZac"];
            }else{
                $this->NaslovZac = "";
            }
            if (isset($R["PostaZac"])){
                $this->PostaZac = $R["PostaZac"];
            }else{
                $this->PostaZac = 0;
            }
            if (isset($R["KrajZac"])){
                $this->KrajZac = $R["KrajZac"];
            }else{
                $this->KrajZac = "";
            }
            if (isset($R["TelefonDoma"])){
                $this->TelefonDoma = $R["TelefonDoma"];
            }else{
                $this->TelefonDoma = "";
            }
            if (isset($R["oce"])){
                $this->oce = $R["oce"];
            }else{
                $this->NaslovZac = "";
            }
            if (isset($R["ocenaslov"])){
                $this->ocenaslov = $R["ocenaslov"];
            }else{
                $this->ocenaslov = "";
            }
            if (isset($R["ocezacnasl"])){
                $this->ocezacnasl = $R["ocezacnasl"];
            }else{
                $this->ocezacnasl = "";
            }
            if (isset($R["ocekontakt"])){
                $this->ocekontakt = $R["ocekontakt"];
            }else{
                $this->ocekontakt = "";
            }
            if (isset($R["oceGSM"])){
                $this->oceGSM = $R["oceGSM"];
            }else{
                $this->oceGSM = "";
            }
            if (isset($R["oceSluzba"])){
                $this->oceSluzba = $R["oceSluzba"];
            }else{
                $this->oceSluzba = "";
            }
            if (isset($R["oceemail"])){
                $this->oceemail = $R["oceemail"];
            }else{
                $this->oceemail = "";
            }
            if (isset($R["mati"])){
                $this->mati = $R["mati"];
            }else{
                $this->mati = "";
            }
            if (isset($R["matinaslov"])){
                $this->matinaslov = $R["matinaslov"];
            }else{
                $this->matinaslov = "";
            }
            if (isset($R["matizacnasl"])){
                $this->matizacnasl = $R["matizacnasl"];
            }else{
                $this->matizacnasl = "";
            }
            if (isset($R["matikontakt"])){
                $this->matikontakt = $R["matikontakt"];
            }else{
                $this->matikontakt = "";
            }
            if (isset($R["matiGSM"])){
                $this->matiGSM = $R["matiGSM"];
            }else{
                $this->matiGSM = "";
            }
            if (isset($R["matiSluzba"])){
                $this->matiSluzba = $R["matiSluzba"];
            }else{
                $this->matiSluzba = "";
            }
            if (isset($R["matiemail"])){
                $this->matiemail = $R["matiemail"];
            }else{
                $this->matiemail = "";
            }
            if (isset($R["Aktivnost"])){
                $this->Aktivnost = $R["Aktivnost"];                //tabaktivnostucenca - status
            }else{
                $this->Aktivnost = 0;
            }
            if (isset($R["LetoRoj"])){
                $this->LetoRoj = $R["LetoRoj"];
            }else{
                $this->LetoRoj = $VLeto-5;
            }
            if (isset($R["IdKrajBivanja"])){
                $this->IdKrajBivanja = $R["IdKrajBivanja"];        //tabkrajbivanja - način hoje v šolo
            }else{
                $this->IdKrajBivanja = 0;
            }
            /*
            $this->IdKrajBivanjaZac = $R["IdKrajBivanjaZac"];  //tabkrajbivanja
            */
            $this->Spol = $R["Spol"];
            if (isset($R["IdPosebnePotrebe"])){
                $this->IdPosebnePotrebe = $R["IdPosebnePotrebe"];  //tabposebnepotrebe
            }else{
                $this->IdPosebnePotrebe=0;
            }
            if (isset($R["Bivanje"])){
                $this->Bivanje = $R["Bivanje"];
            }else{
                $this->Bivanje = 0;
            }
            if (isset($R["Rom"])){
                $this->Rom = $R["Rom"];
            }else{
                $this->Rom = 0;
            }
            if (isset($R["ZacSolanja"])){
                $this->ZacSolanja = $R["ZacSolanja"];
            }else{
                $this->ZacSolanja = "";
            }
            if (isset($R["KonSolanja"])){
                $this->KonSolanja = $R["KonSolanja"];
            }else{
                $this->KonSolanja = "";
            }
            if (isset($R["ZacSolanjaSola"])){
                $this->ZacSolanjaSola = $R["ZacSolanjaSola"];
            }else{
                $this->ZacSolanjaSola = "";
            }
            if (isset($R["KonSolanjaSola"])){
                $this->KonSolanjaSola = $R["KonSolanjaSola"];
            }else{
                $this->KonSolanjaSola = "";
            }
            if (isset($R["Skrbniki"])){
                $this->Skrbniki = $R["Skrbniki"];
            }else{
                $this->Skrbniki = "";
            }
            if (isset($R["SkrbnikiNaslov"])){
                $this->SkrbnikiNaslov = $R["SkrbnikiNaslov"];
            }else{
                $this->SkrbnikiNaslov = "";
            }
            if (isset($R["SkrbnikiKontakt"])){
                $this->SkrbnikiKontakt = $R["SkrbnikiKontakt"];
            }else{
                $this->SkrbnikiKontakt = "";
            }
            if (isset($R["SkrbnikiEmail"])){
                $this->SkrbnikiEmail = $R["SkrbnikiEmail"];
            }else{
                $this->SkrbnikiEmail = "";
            }
            if (isset($R["Placnik"])){
                $this->Placnik = $R["Placnik"];
            }else{
                $this->Placnik = "";
            }
            if (isset($R["PlacnikNaslov"])){
                $this->PlacnikNaslov = $R["PlacnikNaslov"];
            }else{
                $this->PlacnikNaslov = "";
            }
            if (isset($R["PlacnikKontakt"])){
                $this->PlacnikKontakt = $R["PlacnikKontakt"];
            }else{
                $this->PlacnikKontakt = "";
            }
            if (isset($R["Opombe"])){
                $this->Opombe = $R["Opombe"];
            }else{
                $this->Opombe = "";
            }
            if (isset($R["OSObveza"])){
                $this->OSObveza = $R["OSObveza"];
            }else{
                $this->OSObveza = "";
            }
            if (isset($R["SolskiOkolis"])){
                $this->SolskiOkolis = $R["SolskiOkolis"];
            }else{
                $this->SolskiOkolis = "";
            }
            
            //podvojeno (Bivanje) - popravek ne vpisuje
            if (isset($R["OtrokZiviPri"])){
                $this->OtrokZiviPri = $R["OtrokZiviPri"];          //tabbivanje - 
            }else{
                $this->OtrokZiviPri = 0;
            }
        }
        
        //prebere podatke o statusu učenca
        $SQL = "SELECT * FROM tabaktivnostucenca WHERE id=".$this->Aktivnost;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)) {
            $this->mAktivnost=$R["AktivnostUcenca"];
        }else{
            $this->mAktivnost="ni vpisano";
        }
        if (isset($this->IdKrajBivanja)){
            $SQL = "SELECT * FROM tabkrajbivanja WHERE id=".$this->IdKrajBivanja;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)) {
                $this->mKrajBivanja=$R["KrajBivanja"];
            }else{
                $this->mKrajBivanja="ni vpisano";
            }
        }else{
            $this->mKrajBivanja="ni vpisano";
        }
        /*
        if (isset($this->IdKrajBivanjaZac)){
            $SQL = "SELECT * FROM tabkrajbivanja WHERE id=".$this->IdKrajBivanjaZac;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)) {
                $this->mKrajBivanjaZac=$R["KrajBivanja"];
            }else{
                $this->mKrajBivanjaZac="ni vpisano";
            }
        }else{
            $this->mKrajBivanjaZac="ni vpisano";
        }
        */ 
        if (isset($this->Bivanje)){
            $SQL = "SELECT * FROM tabbivanje WHERE idbivanje=".$this->Bivanje;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)) {
                $this->mBivanje=$R["Bivanje"];
            }else{
                $this->mBivanje="ni vpisano";
            }
        }else{
            $this->mBivanje="ni vpisano";
        }
            
        $SQL = "SELECT * FROM tabposebnepotrebe WHERE id=".$this->IdPosebnePotrebe;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)) {
            $this->mPosebnePotrebe=$R["OpisPosebnePotrebe"];
        }else{
            $this->mPosebnePotrebe="ni vpisano";
        }
    }

    public function getRazred($Leto) {
        global $link,$Danes;
        $razred = array();
        
        $SQL = "SELECT * FROM tabrazred INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id WHERE tabrazred.leto=".$Leto." AND tabrazdat.leto=".$Leto." AND tabrazred.iducenec=".$this->IdUcenec;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)) {
            $razred["leto"]=$R["Leto"];
            $razred["solskoleto"]=$R["Leto"]."/".($R["Leto"]+1);
            $razred["razred"]=$R["razred"];
            $razred["paralelka"]=$R["oznaka"];
            $razred["iducenec"]=$R["IdUcenec"];
            $razred["uspeh"]=$R["Uspeh"];
            $razred["uspehpol"]=$R["UspehPol"];
            $razred["ponavljalec"]=$R["Ponavljalec"];
            $razred["napredovanje"]=$R["Napredovanje"];
            $razred["razredniizpit"]=$R["RazredniIzpit"];
            $razred["nadarjen"]=$R["Nadarjen"];
            $razred["statussport"]=$R["StatusSport"];
            $razred["statuskult"]=$R["StatusKult"];
            $razred["letosolanja"]=$R["LetoSolanja"];
            $razred["iducitelj"]=$R["IdUcitelj"];
            $razred["idvzgojitelj"]=$R["IdVzgojitelj"];
            if (isset($R["EvidSt"])){
                $razred["evidst"]=$R["EvidSt"];
            }else{
                $razred["evidst"]="";
            }
            if (isset($R["DatumIzdaje"])){
                $razred["datumizdaje"]=$R["DatumIzdaje"];
            }else{
                $razred["datumizdaje"]="";
            }
            $razred["idrazred"]=$R["idRazred"];
            if (isset($R["Opomba"])){
                $razred["opomba"]=$R["Opomba"];
            }else{
                $razred["opomba"]="";
            }
            $razred["slika"]=$R["slika"];
            if (isset($R["Vpisal"])){
                $razred["vpisal"]=$R["Vpisal"];
            }else{
                $razred["vpisal"]="";
            }
            if (isset($R["DatumVpisa"])){
                $razred["datumvpisa"]=$R["DatumVpisa"];
            }else{
                $razred["datumvpisa"]=$Danes->format('Y-m-d');
            }    
            $razred["osemdevet"]=$R["osemdevet"];
            
            switch ($R["Napredovanje"]){
                case 0:
                    $razred["napredovanje2"]="Napreduje";
                    break;
                case 1:
                    $razred["napredovanje2"]="Napreduje z negativno";
                    break;
                case 2:
                    $razred["napredovanje2"]="Ne napreduje";
            }
                        
            $SQL = "SELECT priimek,ime,spol FROM tabucitelji WHERE iducitelj=".$R["IdUcitelj"]; 
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)) {
                $razred["razrednik"]=$R1["ime"]." ".$R1["priimek"];
                $razred["spolr"]=$R1["spol"];
            }else{
                $razred["razrednik"]="ni vpisano";
                $razred["spolr"]="M";
            }
            $SQL = "SELECT email FROM tabkontakti WHERE iducitelj=".$R["IdUcitelj"];
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)) {
                $razred["rmail"]=$R1["email"];
            }else{
                $razred["rmail"]="";
            }
            $SQL = "SELECT priimek,ime,spol FROM tabucitelji WHERE iducitelj=".$R["IdVzgojitelj"]; 
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)) {
                $razred["drugiucitelj"]=$R1["ime"]." ".$R1["priimek"];
                $razred["spoldu"]=$R1["spol"];
            }else{
                $razred["drugiucitelj"]="";
                $razred["spoldu"]="M";
            }
        }
        return $razred; 
    }
    public function getPredmeti($VLeto) {
        global $link,$Danes;
        $predmet = array();
        
        $SQL = "SELECT tabpredmeti.id AS pid FROM ";
        $SQL = $SQL . "(tabucenci INNER JOIN TabIzbirni ON TabIzbirni.Ucenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN TabPredmeti ON TabPredmeti.Id=TabIzbirni.Izbirni ";
        $SQL = $SQL . "WHERE TabIzbirni.Ucenec=" .$this->IdUcenec . " AND tabizbirni.leto=".$VLeto." ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);

        for ($IndxIzb=0;$IndxIzb <= 4;$IndxIzb++){
            $IzbraniPredmet[$IndxIzb]=0;
        }

        $IndxIzb=0;
        while ($R = mysqli_fetch_array($result)){
            $IzbraniPredmet[$IndxIzb]=$R["pid"];
            $IndxIzb=$IndxIzb+1;
        } 

        $Indx1=0;
        
        $SQL = "SELECT DISTINCT TabPredmeti.id,tabpredmeti.oznaka,tabpredmeti.opis,tabpredmeti.vrstnired,tabpredmeti.prioriteta FROM ";
        $SQL = $SQL . "(((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenje.idrazred=tabrazred.idrazred) ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
        //$SQL = $SQL . "INNER JOIN tabizbirni ON tabucenci.iducenec=tabizbirni.ucenec ";
        $SQL = $SQL . "WHERE tabpredmeti.prioriteta < 3 AND tabucenci.iducenec=" .$this->IdUcenec." AND tabrazred.leto=".$VLeto." AND tabucenje.leto=".$VLeto;
        $SQL = $SQL . " ORDER BY tabpredmeti.vrstnired";
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if (($R["prioriteta"]==0) or ($R["prioriteta"]==2)){
                $predmet[$Indx]["id"]=$R["id"];
                $predmet[$Indx]["oznaka"]=$R["oznaka"];
                $predmet[$Indx]["opis"]=$R["opis"];
                $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                $Indx=$Indx+1;
            }else{
                if ($R["id"]==$IzbraniPredmet[0]) {
                    $predmet[$Indx]["id"]=$R["id"];
                    $predmet[$Indx]["oznaka"]=$R["oznaka"];
                    $predmet[$Indx]["opis"]=$R["opis"];
                    $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                    $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                    $Indx=$Indx+1;
                }
                if ($R["id"]==$IzbraniPredmet[1]) {
                    $predmet[$Indx]["id"]=$R["id"];
                    $predmet[$Indx]["oznaka"]=$R["oznaka"];
                    $predmet[$Indx]["opis"]=$R["opis"];
                    $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                    $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                    $Indx=$Indx+1;
                }
                if ($R["id"]==$IzbraniPredmet[2]) {
                    $predmet[$Indx]["id"]=$R["id"];
                    $predmet[$Indx]["oznaka"]=$R["oznaka"];
                    $predmet[$Indx]["opis"]=$R["opis"];
                    $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                    $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                    $Indx=$Indx+1;
                }
                if ($R["id"]==$IzbraniPredmet[3]) {
                    $predmet[$Indx]["id"]=$R["id"];
                    $predmet[$Indx]["oznaka"]=$R["oznaka"];
                    $predmet[$Indx]["opis"]=$R["opis"];
                    $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                    $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                    $Indx=$Indx+1;
                }
                if ($R["id"]==$IzbraniPredmet[4]) {
                    $predmet[$Indx]["id"]=$R["id"];
                    $predmet[$Indx]["oznaka"]=$R["oznaka"];
                    $predmet[$Indx]["opis"]=$R["opis"];
                    $predmet[$Indx]["vrstnired"]=$R["vrstnired"];
                    $predmet[$Indx]["prioriteta"]=$R["prioriteta"];
                    $Indx=$Indx+1;
                }
            }
        }
        return $predmet;
    }
    private function PreveriOcene($txt){
        $prej="";
        if (strlen($txt) > 0){
            $txt=str_replace(","," ",$txt);
            $txt=str_replace("  "," ",$txt);
            $i=0;
            while ($i < strlen($txt)){
                if ((is_numeric(substr($txt,$i,1))) && ($prej != " ")) {
                    $txt=substr($txt,0,$i)." ".substr($txt,$i,strlen($txt)-$i);
                    $i=$i+1;
                }
                $prej=substr($txt,$i,1);
                $i=$i+1;
            }
        }
        return $txt;
    }
    public function getOcene($VLeto) {
        global $link,$Danes,$encoding;
        $OcenePredmeta = array();
        $SQL = "SELECT tabocene.*, tabpredmeti.id AS pid,tabpredmeti.oznaka, tabpredmeti.opis FROM tabpredmeti ";
        $SQL = $SQL . "INNER JOIN tabocene ON tabocene.IdPredmet = TabPredmeti.Id ";
        $SQL = $SQL . "WHERE IdUcenec=" .$this->IdUcenec . " AND leto=".$VLeto;
        $SQL = $SQL . " ORDER BY tabpredmeti.vrstnired";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $OcenePredmeta[$Indx]["leto"]=$R["Leto"];
            $OcenePredmeta[$Indx]["zapis"]=$R["Id"];
            $OcenePredmeta[$Indx]["iducenec"]=$R["IdUcenec"];
            $OcenePredmeta[$Indx]["id"]=$R["pid"];
            $OcenePredmeta[$Indx]["oznaka"]=mb_substr($R["oznaka"],0,3,$encoding);
            $OcenePredmeta[$Indx]["opis"]=$R["opis"];
            $OcenePredmeta[$Indx]["S1P"]=$this->PreveriOcene($R["OcenaS1P"]);
            $OcenePredmeta[$Indx]["S1U"]=$this->PreveriOcene($R["OcenaS1U"]);
            $OcenePredmeta[$Indx]["S2P"]=$this->PreveriOcene($R["OcenaS2P"]);
            $OcenePredmeta[$Indx]["S2U"]=$this->PreveriOcene($R["OcenaS2U"]);
            $OcenePredmeta[$Indx]["polletna"]=$R["OcenaPolletna"];
            $OcenePredmeta[$Indx]["koncna"]=$R["OcenaKoncna"];
            $OcenePredmeta[$Indx]["neocenjen"]=$R["Neocenjen"];
            $OcenePredmeta[$Indx]["popravni"]=$R["Popravni"];
            $OcenePredmeta[$Indx]["datum"]=$R["Datum"];
            $OcenePredmeta[$Indx]["vpisal"]=$R["Vpisovalec"];
            $Indx = $Indx+1;
        } 
        return $OcenePredmeta;
    }
    
    public function getOpisneOcene($VLeto,$tip) {
        global $link,$Danes,$encoding;
        $OpisneOcenePredmeta = array();

        $SQL = "SELECT oznaka,opis FROM tabpredmeti WHERE prioriteta=0 ORDER BY vrstnired";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]="";
            $OpisneOcenePredmeta[$R["oznaka"]]["predmet"]=$R["opis"];
        }
        
        $SQL = "SELECT tabopznanje.opisznanja, tabpredmeti.oznaka FROM ";
        $SQL = $SQL . "((tabopznanje INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
        $SQL = $SQL . "INNER JOIN tabopocene ON tabopznanje.IdZnanje=tabopocene.OpOcena) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopcilji.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabopocene.IdUcenec=".$this->IdUcenec." AND tabopocene.leto=".$VLeto." AND tabopocene.tip=".$tip;
        $SQL = $SQL . " ORDER BY tabopcilji.predmet,tabopznanje.IdCilji, tabopznanje.IdZnanje";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"];     
        } 
        return $OpisneOcenePredmeta;
    }
    
    public function getOpisneOceneN($VLeto,$tip) {
        global $link,$Danes,$encoding;
        $OpisneOcenePredmeta = array();

        $SQL = "SELECT oznaka,opis FROM tabpredmeti WHERE prioriteta=0 ORDER BY vrstnired";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]="";
            $OpisneOcenePredmeta[$R["oznaka"]]["predmet"]=$R["opis"];
        }
        
        $SQL = "SELECT tabopznanjen.opisznanja, tabpredmeti.oznaka, tabopocenen.ocena FROM ";
        $SQL = $SQL . "((tabopznanjen INNER JOIN tabopciljin ON tabopznanjen.IdCilji=tabopciljin.IdCilji) ";
        $SQL = $SQL . "INNER JOIN tabopocenen ON tabopznanjen.IdZnanje=tabopocenen.OpOcena) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopciljin.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabopocenen.IdUcenec=".$this->IdUcenec." AND tabopocenen.leto=".$VLeto." AND tabopocenen.tip=".$tip;
        $SQL = $SQL . " ORDER BY tabopciljin.predmet,tabopznanjen.IdCilji, tabopznanjen.IdZnanje";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]." (".$R["ocena"].") ";
        } 
        return $OpisneOcenePredmeta;
    }
    
    public function getOpisneOceneN1($VLeto,$tip) {
        global $link,$Danes,$encoding;
        $OpisneOcenePredmeta = array();

        $SQL = "SELECT oznaka,opis FROM tabpredmeti WHERE prioriteta=0 ORDER BY vrstnired";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]="";
            $OpisneOcenePredmeta[$R["oznaka"]]["predmet"]=$R["opis"];
        }
        
        $SQL = "SELECT tabopznanjen.opisznanja, tabpredmeti.oznaka, tabopocenen.ocena FROM ";
        $SQL = $SQL . "((tabopznanjen INNER JOIN tabopciljin ON tabopznanjen.IdCilji=tabopciljin.IdCilji) ";
        $SQL = $SQL . "INNER JOIN tabopocenen ON tabopznanjen.IdZnanje=tabopocenen.OpOcena) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopciljin.predmet=tabpredmeti.id ";
        $SQL = $SQL . "WHERE tabopocenen.IdUcenec=".$this->IdUcenec." AND tabopocenen.leto=".$VLeto." AND tabopocenen.tip=".$tip;
        $SQL = $SQL . " ORDER BY tabopciljin.predmet,tabopznanjen.IdCilji, tabopznanjen.IdZnanje";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            switch ($R["ocena"]){
                case 5:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."#X# # # # *";
                    break;
                case 4:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."# #X# # # *";
                    break;
                case 3:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."# # #X# # *";
                    break;
                case 2:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."# # # #X# *";
                    break;
                case 1:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."# # # # #X*";
                    break;
                case 0:
                    $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]=$OpisneOcenePredmeta[$R["oznaka"]]["ocena"].$R["opisznanja"]."#-#-#-#-#-*";
                    break;
            }
        } 
        return $OpisneOcenePredmeta;
    }
    
    public function getOpisneOceneRocne($VLeto) {
        global $link,$Danes,$encoding;
        $OpisneOcenePredmeta = array();

        $SQL = "SELECT oznaka,opis FROM tabpredmeti WHERE prioriteta=0 ORDER BY vrstnired";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta[$R["oznaka"]]["ocena"]="";
            $OpisneOcenePredmeta[$R["oznaka"]]["predmet"]=$R["opis"];
            //$txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $R["oznaka"]);
            //$OpisneOcenePredmeta[$txt]["ocena"]="";
            //$OpisneOcenePredmeta[$txt]["predmet"]=$R["opis"];
            
        }
        
        $SQL = "SELECT * FROM tabopocucenec WHERE ucenec=".$this->IdUcenec." AND leto=".$VLeto;    
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        if ($R = mysqli_fetch_array($result)){
            $OpisneOcenePredmeta["SLJ"]["ocena"]=$R["slo"];     
            $OpisneOcenePredmeta["MAT"]["ocena"]=$R["mat"];     
            $OpisneOcenePredmeta["SPO"]["ocena"]=$R["spo"];     
            if ($VLeto > 2012){
                $OpisneOcenePredmeta["LUM"]["ocena"]=$R["lvz"];     
            }else{
                $OpisneOcenePredmeta["LVZ"]["ocena"]=$R["lvz"];
            }
            if ($VLeto > 2012){
                $OpisneOcenePredmeta["GUM"]["ocena"]=$R["gvz"];     
            }else{
                $OpisneOcenePredmeta["GVZ"]["ocena"]=$R["gvz"];
            }
            if ($VLeto > 2012){
                $OpisneOcenePredmeta["ŠPO"]["ocena"]=$R["svz"];     
            }else{
                $OpisneOcenePredmeta["ŠVZ"]["ocena"]=$R["svz"];
            }
            $OpisneOcenePredmeta["TJA"]["ocena"]=$R["rez"];
            $OpisneOcenePredmeta["NAR"]["ocena"]=$R["nar"];     
            $OpisneOcenePredmeta["DRU"]["ocena"]=$R["dru"];     
            $OpisneOcenePredmeta["TIT"]["ocena"]=$R["tit"];     
            $OpisneOcenePredmeta["GOS"]["ocena"]=$R["gos"];     
        } 
        return $OpisneOcenePredmeta;
    }
    
    public function getIzbirni($VLeto){
        global $link,$encoding;
        $Izbirni = array();
        
        $SQL = "SELECT tabpredmeti.oznaka,tabpredmeti.opis,tabizbirni.izbirni FROM tabizbirni INNER JOIN tabpredmeti ON tabizbirni.izbirni=tabpredmeti.id WHERE leto=".$VLeto." AND tabizbirni.ucenec=".$this->IdUcenec;
        $result = mysqli_query($link,$SQL);
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            switch ($R["oznaka"]){
                case "GLŠ":  //ne upošteva glasbene šole in pevskih zborov
                case "MPZ":
                case "OPZ":
                    break;
                default:
                    $Izbirni[$Indx]["id"]=$R["izbirni"];
                    $Izbirni[$Indx]["oznaka"]=mb_substr($R["oznaka"],0,3,$encoding);
                    $Izbirni[$Indx]["opis"]=$R["opis"];
                    $Indx=$Indx+1;
            }
        }
        return $Izbirni;
    }
    public function getNPZ($VLeto){
        global $link,$encoding;
        $npz = array();
        
        $SQL = "SELECT tabnpzocene.*, tabpredmeti.oznaka, tabpredmeti.opis FROM tabnpzocene INNER JOIN tabpredmeti ON tabnpzocene.idPredmet=tabpredmeti.id WHERE idUcenec=".$this->IdUcenec." AND leto=".$VLeto." ORDER BY TabPredmeti.VrstniRed";
        $result = mysqli_query($link,$SQL);
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            switch ($R["oznaka"]){
                case "SLJ":
                    $npz[0]["id"]=$R["idPredmet"];
                    $npz[0]["oznaka"]=$R["oznaka"];
                    $npz[0]["opis"]=$R["opis"];
                    $npz[0]["tock"]=$R["tock"];
                    $npz[0]["procent"]=$R["odstotek"];
                    $npz[0]["mtock"]=$R["moznihTock"];
                    break;
                case "MAT":
                    $npz[1]["id"]=$R["idPredmet"];
                    $npz[1]["oznaka"]=$R["oznaka"];
                    $npz[1]["opis"]=$R["opis"];
                    $npz[1]["tock"]=$R["tock"];
                    $npz[1]["procent"]=$R["odstotek"];
                    $npz[1]["mtock"]=$R["moznihTock"];
                    break;
                default:  //tretji predmet
                    $npz[2]["id"]=$R["idPredmet"];
                    $npz[2]["oznaka"]=$R["oznaka"];
                    $npz[2]["opis"]=$R["opis"];
                    $npz[2]["tock"]=$R["tock"];
                    $npz[2]["procent"]=$R["odstotek"];
                    $npz[2]["mtock"]=$R["moznihTock"];
            }
        }
        return $npz;
    }
    
    public function getOdsotnost($VLeto){
        global $link,$encoding;
        $ods = array();
        
        $SQL = "SELECT mesec,opraviceno,neopraviceno FROM tabprisotnost WHERE IdUcenec=" .$this->IdUcenec . " AND leto=".$VLeto." ORDER BY leto DESC";
        $result = mysqli_query($link,$SQL);

        $ods["opraviceno"]=0;
        $ods["neopraviceno"]=0;

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $ods["opraviceno"]=$ods["opraviceno"]+$R["opraviceno"];
            $ods["neopraviceno"]=$ods["neopraviceno"]+$R["neopraviceno"];
        } 

        return $ods;
    }
}

?>
