<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odločbe za dopuste
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}

function ToRTF($txt){
	$txt=str_replace("Č","\\'c8",$txt);
	$txt=str_replace("č","\\'e8",$txt);
	$txt=str_replace("Š","\\'8a",$txt);
	$txt=str_replace("š","\\'9a",$txt);
	$txt=str_replace("Ž","\\'8e",$txt);
	$txt=str_replace("ž","\\'9e",$txt);
	$txt=str_replace("Ć","\\'c6",$txt);
	$txt=str_replace("ć","\\'e6",$txt);
	$txt=str_replace("Đ","\\'d0",$txt);
	$txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
	return $txt;
}

function To437($txt){
	$txt=str_replace("Č","^",$txt);
	$txt=str_replace("č","~",$txt);
	$txt=str_replace("Š","[",$txt);
	$txt=str_replace("š","{",$txt);
	$txt=str_replace("Ž","@",$txt);
	$txt=str_replace("ž","`",$txt);
	$txt=str_replace("Ć","]",$txt);
	$txt=str_replace("ć","}",$txt);
	$txt=str_replace("Đ","\\",$txt);
	$txt=str_replace("đ","|",$txt);
	return $txt;
}

$VFile="OdlocbeDopust.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VSola=$R["Sola"];
	$VSolaKratko=$R["SolaKratko"];
	$VRavnatelj=$R["Ravnatelj"];
	$VKraj=$R["Kraj"];
	$VNaslov=$R["Naslov"];
	$VPosta=$R["Posta"]." ".$VKraj;
}else{
	$VSola=" ";
	$VSolaKratko=$R["SolaKratko"];
	$VRavnatelj=" ";
	$VKraj=" ";
	$VNaslov=" ";
	$VPosta=" ";
}

fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1\\deff1\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\f1\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}{\\f35\\fswiss\\fcharset0\\fprq2{\\*\\panose 020b0a04020102020204}Arial Black;}{\\f453\\froman\\fcharset0\\fprq2 Times New Roman;}{\\f452\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
fwrite ($fh,"{\\f454\\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f455\\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f456\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f457\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
fwrite ($fh,"{\\f458\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f459\\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f463\\fswiss\\fcharset0\\fprq2 Arial;}{\\f462\\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f464\\fswiss\\fcharset161\\fprq2 Arial Greek;}"."\n");
fwrite ($fh,"{\\f465\\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f466\\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f467\\fswiss\\fcharset178\\fprq2 Arial (Arabic);}{\\f468\\fswiss\\fcharset186\\fprq2 Arial Baltic;}{\\f469\\fswiss\\fcharset163\\fprq2 Arial (Vietnamese);}}"."\n");
fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;"."\n");
fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red137\\green119\\blue186;}{\\stylesheet{\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{\\s1\\qj \\li0\\ri0\\sb240\\sa120\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\b\\shad\\f35\\fs36\\lang1033\\langfe1033\\kerning28\\cgrid\\langnp1033\\langfenp1033 \\sbasedon0 \\snext0 \\styrsid14375190 heading 1;}{\\s2\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar"."\n");
fwrite ($fh,"\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 \\sautoupd \\styrsid4161200 heading 2;}{\\s3\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel2\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\b\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 heading 3;}{\\*\\cs10 \\additive \\ssemihidden Default Paragraph Font;}{\\*"."\n");
fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\snext11 \\ssemihidden Normal Table;}{\\s15\\qc \\li0\\ri0\\sb60\\sa60\\sl-140\\slmult0"."\n");
fwrite ($fh,"\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\b\\f1\\fs14\\lang1024\\langfe1024\\cgrid\\noproof\\langnp1060\\langfenp1060 \\sbasedon0 \\snext15 Mesto;}{\\*\\cs16 \\additive \\b\\i\\f1\\fs24\\lang1060\\langfe1033\\langnp1060\\langfenp1033 \\sbasedon10 "."\n");
fwrite ($fh,"Naslov 2 Znak Znak Znak Znak Znak;}{\\s17\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\shad\\f35\\fs28\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext17 \\styrsid2692378 Slog Arial Black 24 pt Sen\\'e8eno Na sredini Polje: (Enojen Samo...;}{\\s18\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\f35\\fs48\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext18 \\styrsid14375190 "."\n");
fwrite ($fh,"Slog Arial Black 24 pt modra Sen\\'e8eno Na sredini Polje: (Enoje...;}{\\s19\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon2 \\snext19 \\styrsid14375190 Slog Naslov 2 + rde\\'e8a;}{"."\n");
fwrite ($fh,"\\s20\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\b\\shad\\f35\\fs28\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 \\sbasedon1 \\snext20 \\sautoupd \\styrsid2692378 Slog1;}{\\s21\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb"."\n");
fwrite ($fh,"\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\caps\\f1\\fs24\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 "."\n");
fwrite ($fh,"\\sbasedon1 \\snext21 \\sautoupd \\styrsid2692378 Slog Naslov 1,Naslov 1 Znak Znak Znak Znak + Arial 12 pt Ne Krep...;}{\\s22\\ql \\li0\\ri0\\sb100\\sa100\\sbauto1\\saauto1\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext22 \\styrsid5715400 Normal (Web);}");
fwrite ($fh,"{\\*\\ts23\\tsrowd\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
fwrite ($fh,"\\brdrs\\brdrw10 ");
fwrite ($fh,"\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\sbasedon11 \\snext23 \\styrsid5715400 Table Grid;}}{\\*\\latentstyles\\lsdstimax156\\lsdlockeddef0}{\\*\\listtable"."\n");
fwrite ($fh,"{\\list\\listtemplateid-1051832236{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow1\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 }{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2"."\n");
fwrite ($fh,"\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s2}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s3}{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0"."\n");
fwrite ($fh,"{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0"."\n");
fwrite ($fh,"\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}"."\n");
fwrite ($fh,"{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listname ;}\\listid327027276}}{\\*\\listoverridetable{\\listoverride\\listid327027276"."\n");
fwrite ($fh,"\\listoverridecount0\\ls1}}{\\*\\pgptbl {\\pgp\\ipgp0\\itap0\\li0\\ri0\\sb0\\sa0}}{\\*\\rsidtbl \\rsid882357\\rsid2692378\\rsid4161200\\rsid5715400\\rsid6759903\\rsid10756800\\rsid14375190\\rsid15216063\\rsid15866154}{\\*\\generator Microsoft Word 11.0.5604;}{\\info"."\n");
fwrite ($fh,"{\\title }{\\creatim\\yr2009\\mo2\\dy27\\hr7\\min33}{\\revtim\\yr2009\\mo2\\dy27\\hr7\\min52}{\\version2}{\\edmins16}{\\nofpages3}{\\nofwords874}{\\nofchars4985}"."\n");
fwrite ($fh,"{\\nofcharsws5848}{\\vern24689}}\\margl1134\\margr1134\\margt1134\\margb1134 ");
fwrite ($fh,"\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\hyphcaps0\\formshade\\horzdoc\\dgmargin\\dghspace187\\dgvspace127\\dghorigin1701\\dgvorigin1984"."\n");
fwrite ($fh,"\\dghshow0\\dgvshow2\\jexpand\\viewkind4\\viewscale150\\pgbrdrhead\\pgbrdrfoot\\bdrrlswsix\\nolnhtadjtbl\\nojkernpunct\\rsidroot5715400 \\fet0\\sectd \\linex0\\headery709\\footery709\\colsx708\\sectlinegrid254\\sectdefaultcl\\sftnbj {\\*\\pnseclvl1"."\n");
fwrite ($fh,"\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5"."\n");
fwrite ($fh,"\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang "."\n");
fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}\\pard\\plain "."\n");

	$SQL = "SELECT * FROM tabucitelji ";
	$SQL = $SQL . "WHERE tabucitelji.Status > 0 AND tabucitelji.Status < 10";
	$SQL = $SQL . " ORDER BY Priimek, Ime";
	//Response.Write "<br>" & SQL & "<br>"
    $result = mysqli_query($link,$SQL);

    $VLetoPregled=$VLeto;
    
    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        $oUcitelj = new RUcitelj;
        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
        /*
		$ucitelji[$Indx][0]=$R["tabucitelji.IdUcitelj"];
		$ucitelji[$Indx][1]=$R["Ime"]." ".$R["Priimek"];
		$ucitelji[$Indx][3]=day($R["DatRoj")).". ".Month($R["DatRoj")).". ".Year($R["DatRoj"))
		Dopust = $R["TabDopust.DopustNaDD")+$R["TabDopust.DopustNaIz")+$R["TabDopust.DopustNaOt")+$R["TabDopust.DopustNaSta")+$R["TabDopust.DopustNaInv")+$R["TabDopust.DopustNaVod")+$R["TabDopust.DopustVzgoja")+$R["DopustDelInv")+$R["DopustPP")+$R["Drugo")
		$ucitelji[$Indx][4)=Dopust
		$ucitelji[$Indx][5)=$R["TabDopust.DopustNaDD")
		$ucitelji[$Indx][6)=$R["TabDopust.DopustNaIz")
		$ucitelji[$Indx][7)=$R["TabDopust.DopustNaVod")
		$ucitelji[$Indx][8)=$R["TabDopust.DopustNaOt")
		$ucitelji[$Indx][9)=$R["TabDopust.DopustNaInv")
		$ucitelji[$Indx][10)=$R["TabDopust.DopustNaSta")
		$ucitelji[$Indx][11)=$R["TabDopust.DopustVzgoja")
		$ucitelji[$Indx][12)=$R["spol")
		$ucitelji[$Indx][13)=$R["TabDopust.DelDobaLet")
		select case $R["Status")
			case 1,2
				$ucitelji[$Indx][14)="nedoločen čas"
			case else 
				$ucitelji[$Indx][14)="določen čas"
		end select
		$ucitelji[$Indx][15)=$R["TabDopust.DopustStari")
		$ucitelji[$Indx][16)=$R["DopustDelInv")
		$ucitelji[$Indx][17)=$R["DopustPP")
		$ucitelji[$Indx][18)=$R["Drugo")
		$ucitelji[$Indx][19)=$R["Delez")
'			response.write ($ucitelji[$Indx][1)."<br>")
		'prebere podatke iz pogodb
		SQL = "SELECT tabpogodbe.*, TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo FROM "
		SQL = SQL ."((tabpogodbe LEFT JOIN TabDelo ON tabpogodbe.IdDelo=TabDelo.IdDelo) "
		SQL = SQL ."INNER JOIN TabVzgDelo ON tabpogodbe.IdVzgojnoDelo=TabVzgDelo.IdVzgojnoDelo) "
		SQL = SQL . "WHERE idUcitelj=".$R["tabucitelji.idUcitelj")
		set R1 = conn.execute(SQL,,adcmdtext)
		i=0
		Do
			if NOT R1.EOF then
				i=i+1 'upo?teva le pogodbe za aktualno leto
				
				DatumEnd(i)=R1("DatumEnd")
				if isNull(DatumEnd(i)) then
					DatumEnd(i)="1.1.".VLetoPregled+1
				end if
				if NOT isDate(DatumEnd(i)) then
					DatumEnd(i)="1.1.".VLetoPregled+1
				end if
				DatumStart(i)=R1("DatumStart")
				if isNull(DatumStart(i)) then
					DatumStart(i)="1.1.".VletoPregled
				end if
				if NOT isDate(DatumStart(i)) then
					DatumStart(i)="1.1.".VLetoPregled
				end if
				
				'pripravi le aktualne pogodbe (veljavne za to leto)
				if (VLetoPregled <= year(DatumEnd(i))) and (VLetoPregled >= year(DatumStart(i))) then
					NazivDelMesta(i)=R1("NazivDelMesta")
				else
					i=i-1
				end if
			else
				Exit Do
			end if
			R1.MoveNext
		Loop
		StPogodb=i

		$ucitelji[$Indx][2)=""
		if StPogodb > 0 then
			for i=1 to StPogodb
				if i=1 then
					$ucitelji[$Indx][2)=NazivDelMesta(i)
				else
					enak=0
					for i1=1 to i-1
						if NazivDelMesta(i) = NazivDelMesta(i1) then
							enak=enak+1
						end if
					next
					if enak = 0 then
						$ucitelji[$Indx][2)=$ucitelji[$Indx][2).", ".NazivDelMesta(i)
					end if
				end if
			next
		end if
        $Indx=$Indx+1;
	}
	StUciteljev=Indx

	Dim IndxUcitelj
	Dim Indx1
	
	for IndxUcitelj=0 to StUciteljev-1
    */
		$Indx1=0;

		fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
		fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
		
		//glava šole
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VSola)."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VNaslov.", ".$VPosta)."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

		//evid. št, kraj, datum
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
		fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
		if (strlen($RefStFix) > 0){
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Evid. št.: ").$RefStFix."-".$RefStVar."/".$VLeto."}{\\insrsid10756800 \\par }"."\n");
			$RefStVar=$RefStVar+1;
		}else{
            $SQL = "SELECT evstev,datum FROM tabevstevilked WHERE iducitelj=".$oUcitelj->getIdUcitelj()." AND leto=$VLeto AND dokument=1";
            $result1 = mysqli_query($link,$SQL);
            if ($result1){
                if ($R1 = mysqli_fetch_array($result1)){
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Evid. št.: ").$R1["evstev"]."}{\\insrsid10756800 \\par }"."\n");
                    $datum=new DateTime($R1["datum"]);
                    $PrintDay=$datum->format('j.n.Y');
                }else{
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Evid. št.: ")."}{\\insrsid10756800 \\par }"."\n");
                }
            }else{
                fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Evid. št.: ")."}{\\insrsid10756800 \\par }"."\n");
            }
		}
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF($VKraj.", ". $PrintDay)."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		
		//zakonska podlaga
		fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
		fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Na podlagi 49. /51. (za direktorje) člena Zakona o organizaciji in financiranju vzgoje in izobraževanja - ZOFVI (Ur. l. RS, št. 16/07 - UPB5, 36/08 58/09, 64/09 - popr., 65/09 - popr., 20711, 40/12 - ZUJF,  57/12 - ZPCP-2D, 2/15-odl US in 47/15), v skladu z Zakonom o delovnih razmerjih - ZDR-1 (Ur. l. RS, št. 21/13, 78/13 - popr. in 47/15 -ZZSDT) ter v skladu s Kolektivno pogodbo za dejavnost vzgoje in izobraževanja v RS - KP VIZ (Ur.l. RS, št. 52/94 s spremembami in dopolnitvami) in Zakonom o ukrepih na področju plač in drugih stroškov dela za leto $VLeto in drugih ukrepih v javnem sektorju (ZUPPJS16) (Ur. l. RS, št. 90/15)"));
        /*
        if ($oUcitelj->getDolocenCas()){
             if ($oUcitelj->getDelez() > -1){
                 fwrite ($fh," in 162. ");
             }
        }
        */
        fwrite ($fh,"}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		
		//naslov
		fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
		fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
		fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("OBVESTILO O DOLOČITVI LETNEGA DOPUSTA ZA LETO ".$VLeto)."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

		//Izpis osebnih podatkov

		fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
		fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        $Datum=$oUcitelj->getDatRoj();
        switch ($oUcitelj->getStatus()){
            case 0:
                $Status="ni več zaposlen";
                break;
            case 1:
            case 2:
                $Status="nedoločen čas";
                break;
            case 3:
            case 4:
            case 5:
                $Status="določen čas";
                break;
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                $Status="nedefinirano";
        }
        if ($oUcitelj->getDelez() < 0){
		    if ($oUcitelj->getSpol() =="M") {
			    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavec ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek().", rojen ".$Datum->format('d.m.Y').", je v zavodu ".$VSola." zaposlen za ".$Status." na delovnem mestu ".$oUcitelj->getDelMesto().". }{\\b\\insrsid5715400\\charrsid5715400 Delavcu za koledarsko leto ".$VLeto." pripada ".$oUcitelj->getDopust()." dni letnega dopusta.")."}{\\insrsid10756800 \\par }"."\n");
		    }else{
			    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavka ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek().", rojena ".$Datum->format('d.m.Y').", je v zavodu ".$VSola." zaposlena za ".$Status." na delovnem mestu ".$oUcitelj->getDelMesto().". }{\\b\\insrsid5715400\\charrsid5715400 Delavki za koledarsko leto ".$VLeto." pripada ".$oUcitelj->getDopust()." dni letnega dopusta.")."}{\\insrsid10756800 \\par }"."\n");
		    }
        }else{
            if ($oUcitelj->getSpol() =="M") {
                fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavec ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek().", rojen ".$Datum->format('d.m.Y').", je v zavodu ".$VSola." zaposlen za ".$Status." na delovnem mestu ".$oUcitelj->getDelMesto().". }{\\b\\insrsid5715400\\charrsid5715400 Delavcu za koledarsko leto ".$VLeto." pripada ".$oUcitelj->getDelez()." dni letnega dopusta.")."}{\\insrsid10756800 \\par }"."\n");
            }else{
                fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavka ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek().", rojena ".$Datum->format('d.m.Y').", je v zavodu ".$VSola." zaposlena za ".$Status." na delovnem mestu ".$oUcitelj->getDelMesto().". }{\\b\\insrsid5715400\\charrsid5715400 Delavki za koledarsko leto ".$VLeto." pripada ".$oUcitelj->getDelez()." dni letnega dopusta.")."}{\\insrsid10756800 \\par }"."\n");
            }
        }
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("OBRAZLOŽITEV:")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"\\pard \\qj \\li0\\ri0\\widctlpar\\tqr\\tx9356\\tx9498\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid3154335 "."\n");
        if ($oUcitelj->getSpol() == "M"){
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" Na podlagi 47. člena KPVIZ in 159. člena ZDR-1 ter po 12. členu ZUPPJS16 se delavcu letni dopust za leto $VLeto odmeri na podlagi naslednjih kriterijev:")."}{\\insrsid10756800 \\par }"."\n");
        }else{
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" Na podlagi 47. člena KPVIZ in 159. člena ZDR-1 ter po 12. členu ZUPPJS16 se delavki letni dopust za leto $VLeto odmeri na podlagi naslednjih kriterijev:")."}{\\insrsid10756800 \\par }"."\n");
        }
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- za }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDelDobaLet()." }{\\fs24\\insrsid5715400\\charrsid5715400 let delovne dobe \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaDD()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- stopnja izobrazbe, ki se zahteva za delovno mesto \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaIz()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- za zahtevnost/vodenje \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaVod()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
	//	if ($oUcitelj->getSpol() =="M"){
	//		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- na otroke (za otroka do dopolnjenega 15. leta starosti) \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaOt()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
	//	}else{
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- na otroke (za otroka do 7. leta starosti: 2 dni, za otroka do 15. leta starosti: 1 dan) \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaOt()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
	//	}
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- strokovnim delavcem v vzgoji in izobraževanju 1 dan \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustVzgoja()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- invalidu II. in III. kategorije 3 dni \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaInv()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- delovnemu invalidu in delavcu z najmanj 60% telesno okvaro 5 dni \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustDelInv()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- za dopolnjenih 50 let starosti \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustNaSta()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- za delo v VIZ s prilagojenimi programi (3/5/10 dni) \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustPP()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- drugo \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopustDrugo()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
/*
        if ($oUcitelj->getDelez() > -1){
            if ($oUcitelj->getDopustDrugo() < 0){
                if ($oUcitelj->getSpol() == "M"){
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Na podlagi omejitve iz 187. člena ZUJF delavcu v letu $VLeto pripada \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }else{
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Na podlagi omejitve iz 187. člena ZUJF delavki v letu $VLeto pripada \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }
            }
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Sorazmerno \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDelez()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");                
        }else{
            if ($oUcitelj->getDopustDrugo() < 0){
                if ($oUcitelj->getSpol() == "M"){
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Na podlagi omejitve iz 187. člena ZUJF delavcu v letu $VLeto pripada \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }else{
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Na podlagi omejitve iz 187. člena ZUJF delavki v letu $VLeto pripada \\tab }{\\b\\fs20\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs20\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }
            }
        }
		*/
//        if ($oUcitelj->getDelez() < 0){
		    fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("SKUPAJ DNI DOPUSTA \\tab ".$oUcitelj->getDopustVse()." \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
//        }else{
//            fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("SKUPAJ DNI DOPUSTA \\tab ".$oUcitelj->getDelez()." \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
//        }

        if ($oUcitelj->getDelez() > -1){
		
            if ($oUcitelj->getDopustVse() > 35){
                if ($oUcitelj->getSpol() == "M"){
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Določeno v 12. členu ZUPPJS16 delavcu }{\\insrsid10756800 \\par }{\\insrsid5715400\\charrsid5715400 ne glede na prej ugotovljeno skupno število dni v letu $VLeto pripada \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }else{
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Določeno v 12. členu ZUPPJS16 delavki }{\\insrsid10756800 \\par }{\\insrsid5715400\\charrsid5715400 ne glede na prej ugotovljeno skupno število dni v letu $VLeto pripada \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }
            }
		
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Sorazmerno \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDelez()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");                
        }else{
            if ($oUcitelj->getDopustVse() > $oUcitelj->getDopust()){
                if ($oUcitelj->getSpol() == "M"){
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Določeno v 12. členu ZUPPJS16 delavcu }{\\insrsid10756800 \\par }{\\insrsid5715400\\charrsid5715400 ne glede na prej ugotovljeno skupno število dni v letu $VLeto pripada \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }else{
                    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Določeno v 12. členu ZUPPJS16 delavki }{\\insrsid10756800 \\par }{\\insrsid5715400\\charrsid5715400 ne glede na prej ugotovljeno skupno število dni v letu $VLeto pripada \\tab }{\\b\\fs24\\insrsid5715400\\charrsid3154335 ".$oUcitelj->getDopust()."}{\\fs24\\insrsid5715400\\charrsid5715400  \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
                }
            }
        }

		fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("Prenos dopusta iz preteklega leta \\tab ".$oUcitelj->getDopustStari()." \\tab dni")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");

		if ($oUcitelj->getSpol() =="M"){
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("1. V skladu z določili 125. člena Zakona o organizaciji in financiranju vzgoje in izobraževanja  in 45. člena KP VIZ delavec praviloma izrabi večino letnega dopusta v času šolskih počitnic.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("2. Delavec ima pravico dva dneva letnega dopusta izrabiti na tista dneva, ki ju sam določi, pri čemer mora o tem obvestiti zavod tri delovne dni pred izrabo. Delavec teh dveh dni ne more koristiti v istem tednu.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("3. Delavec zaprosi za odobritev koriščenja rednega dopusta s posebnim obrazcem.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("4. V primeru, da delavcu preneha delovno razmerje med koledarskim letom, mu pripada del letnega dopusta sorazmerno z obdobjem zaposlitve v zavodu, ki ga izrabi do prenehanja delovnega razmerja.")."}{\\insrsid10756800 \\par }"."\n");
//			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Letni dopust je delavcu določen na podlagi 159. člena Zakona o delovnih razmerjih in v skladu z določili Kolektivne pogodbe za dejavnost vzgoje in izobraževanja v Republiki Sloveniji.")."}{\\insrsid10756800 \\par }"."\n");
//			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavcu pripada število dni letnega dopusta, ki je določeno s tem sklepom in po kriterijih navedenega zakona in kolektivne pogodbe.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" ")."}{\\insrsid10756800 \\par }"."\n");

            fwrite ($fh,"{\\insrsid16406371 \\page }    "."\n");

			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Pravni pouk: ")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Če delavec meni, da delodajalec ni izpolnil svoje obveznosti, ima pravico pisno zahtevati, da delodajalec kršitev odpravi, oziroma da svoje obveznosti izpolni. Zahteva se naslovi priporočeno po pošti na naslov ".$VSola.", ".$VNaslov.", ".$VPosta.".")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" ")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Če delodajalec v nadaljnjem roku 8 dni po vročeni pisni zahtevi delavca ne izpolni svoje obveznosti iz delovnega razmerja oziroma ne odpravi kršitve, lahko delavec v roku 8 dni od poteka roka za izpolnitev obveznosti oziroma odpravo kršitev vloži pritožbo na Svet zavoda ".$VSola.", ".$VNaslov.", ".$VPosta.".")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavec lahko neposredno zahteva sodno varstvo v roku trideset dni od poteka osemdnevnega roka, ki teče od dne vložitve delavčeve zahteve za odpravo kršitve delodajalca.")."}{\\insrsid10756800 \\par }"."\n");
		}else{
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("1. V skladu z določili 125. člena Zakona o organizaciji in financiranju vzgoje in izobraževanja  in 45. člena KP VIZ delavka praviloma izrabi večino letnega dopusta v času šolskih počitnic.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("2. Delavka ima pravico dva dneva letnega dopusta izrabiti na tista dneva, ki ju sama določi, pri čemer mora o tem obvestiti zavod tri delovne dni pred izrabo. Delavka teh dveh dni ne more koristiti v istem tednu.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("3. Delavka zaprosi za odobritev koriščenja rednega dopusta s posebnim obrazcem.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("4. V primeru, da delavki preneha delovno razmerje med koledarskim letom, ji pripada del letnega dopusta sorazmerno z obdobjem zaposlitve v zavodu, ki ga izrabi do prenehanja delovnega razmerja.")."}{\\insrsid10756800 \\par }"."\n");
//			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Letni dopust je delavki določen na podlagi 159. člena Zakona o delovnih razmerjih in v skladu z določili Kolektivne pogodbe za dejavnost vzgoje in izobraževanja v Republiki Sloveniji.")."}{\\insrsid10756800 \\par }"."\n");
//			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavki pripada število dni letnega dopusta, ki je določeno s tem sklepom in po kriterijih navedenega zakona in kolektivne pogodbe.")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" ")."}{\\insrsid10756800 \\par }"."\n");

            fwrite ($fh,"{\\insrsid16406371 \\page }    "."\n");

			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Pravni pouk: ")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Če delavka meni, da delodajalec ni izpolnil svoje obveznosti, ima pravico pisno zahtevati, da delodajalec kršitev odpravi, oziroma da svoje obveznosti izpolni. Zahteva se naslovi priporočeno po pošti na naslov ".$VSola.", ".$VNaslov.", ".$VPosta.".")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(" ")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Če delodajalec v nadaljnjem roku 8 dni po vročeni pisni zahtevi delavke ne izpolni svoje obveznosti iz delovnega razmerja oziroma ne odpravi kršitve, lahko delavka v roku 8 dni od poteka roka za izpolnitev obveznosti oziroma odpravo kršitev vloži pritožbo na Svet zavoda ".$VSolaKratko.", ".$VNaslov.", ".$VPosta.".")."}{\\insrsid10756800 \\par }"."\n");
			fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Delavka lahko neposredno zahteva sodno varstvo v roku trideset dni od poteka osemdnevnega roka, ki teče od dne vložitve delavkine zahteve za odpravo kršitve delodajalca.")."}{\\insrsid10756800 \\par }"."\n");
		}
		
//'		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n"
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"\\pard \\qj \\li0\\ri0\\widctlpar\\tx6804\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid3154335 ");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 \\tab ".ToRTF("Ravnatelj/-ica:")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 \\tab ".ToRTF($VRavnatelj)."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"\\pard \\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 ");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Vročiti:")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek(). ", z vročilnico na delovnem mestu")." }{\\insrsid10756800 \\par }"."\n");
		if ($oUcitelj->getSpol() =="M"){
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- osebna mapa delavca")."}{\\insrsid10756800 \\par }"."\n");
		}else{
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- osebna mapa delavke")."}{\\insrsid10756800 \\par }"."\n");
		}
//		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("- arhiv")."}{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
			
		if ($oUcitelj->getSpol() =="M"){
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Podpisani ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()." potrjujem prevzem Obvestila o določitvi letnega dopusta za leto ".$VLeto.".")."}{\\insrsid10756800 \\par }"."\n");
		}else{
			fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Podpisana ".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()." potrjujem prevzem Obvestila o določitvi letnega dopusta za leto ".$VLeto.".")."}{\\insrsid10756800 \\par }"."\n");
		}
//'		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n"
		fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Datum: _______________________, Podpis: __________________________________")."}{\\insrsid10756800 \\par }"."\n");
		fwrite ($fh,"{\\insrsid10756800 \\par } \\pard"."\n");
		fwrite ($fh,"{\\insrsid16406371 \\page }	"."\n");
	}	
		
	unset($oUcitelj);

fwrite ($fh," }"."\n");

fclose($fh);
echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri odločbe za dopuste</a></h2>"

?>
</body>
</html>
