<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VLetoSol=PreberiLeto("solskoleto");
function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}
function MonthName($x){
    switch ($x){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }       
}
function Arr2Str($a){
    $s="";
    for ($i=0;$i < count($a);$i++){
        if (strlen($s) == 0){
            $s=$a[$i];
        }else{
            $s=$s.",".$a[$i];
        }
    }
    return $s;
}

function CheckDelovodnik($d){
    global $StZapisov,$Zapisi;
    for ($Indx=1;$Indx <= $StZapisov;$Indx++){
        $Datum=new DateTime(isDate($d));
        $zapis=new DateTime(isDate($Zapisi[$Indx][0]));
        if ($Datum->format('Y-m-d')==$zapis->format('Y-m-d')){
            return true;
        }
        $zapis=new DateTime(isDate($Zapisi[$Indx][1]));
        if ($Datum->format('Y-m-d')==$zapis->format('Y-m-d')){
            return true;
        }
    }
    return false;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $Ucitelj=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("drugo4",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
switch ($Vid){
	case "2":
	case "4":
	case "8":
		break;
	default:
		$n=$VLevel;
        /*
		include('menu_func.inc');
		include ('menu.inc');
        */
}
if (isset($_POST["zapis"])){
    $VZapis = $_POST["zapis"];
}else{
    if (isset($_GET["zapis"])){
        $VZapis=$_GET["zapis"];
    }else{
        $VZapis = 0;
    }
}

$Obdelava=$Vid;

switch ($Obdelava){
    case "1": // 'vnos delovodnika
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        ?>
            <script>
             function showIskanje(str)
             {
             //if (str=="")
             //  {
             //  document.getElementById("txtHint").innerHTML="";
             //  return;
             //  } 
             if (window.XMLHttpRequest){
               // code for IE7+, Firefox, Chrome, Opera, Safari";
               xmlhttp=new XMLHttpRequest();
               }
             else{
               // code for IE6, IE5";
               xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
               }
             xmlhttp.onreadystatechange=function()
               {
               if (xmlhttp.readyState==4 && xmlhttp.status==200){
                 
                 document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                 }
               }
             xmlhttp.open("GET","getekn.php?id=1&iskanje="+str,true);
             xmlhttp.send();
             }

             function showIskanje2()
             {
             //if (str=="")
             //  {
             //  document.getElementById("klasif").innerHTML="";
             //  return;
             //  }
             var e=document.getElementById("klasif");
             var str=e.options[e.selectedIndex].value;
             
             if (window.XMLHttpRequest){
               // code for IE7+, Firefox, Chrome, Opera, Safari";
               xmlhttp=new XMLHttpRequest();
               }
             else{
               // code for IE6, IE5";
               xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
               }
             xmlhttp.onreadystatechange=function()
               {
               if (xmlhttp.readyState==4 && xmlhttp.status==200){
                 
                 document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
                 }
               }
             xmlhttp.open("GET","getekn.php?id=2&iskanje="+str,true);
             xmlhttp.send();
             
             //pokazi();
             }
             
             function pokazi()
             {
                 var oznaka=document.getElementById("klasif");
                 var zapst=document.getElementById("hid_zapst");
                 var trajno=document.getElementById("hid_trajno");
                 var hramba=document.getElementById("hid_hramba");
                 var arhiv=document.getElementById("hid_arhivsko");
                 
                 //document.getElementById("ekn").value=oznaka.value;
                 document.getElementById("roki").value=hramba.value+" "+trajno.value;
                 document.getElementById("arh").value=arhiv.value;
                 document.getElementById("zap_st").value=zapst.value;
                 
                 if (window.XMLHttpRequest){
                   // code for IE7+, Firefox, Chrome, Opera, Safari";
                   xmlhttp=new XMLHttpRequest();
                   }
                 else{
                   // code for IE6, IE5";
                   xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                   }
                 xmlhttp.onreadystatechange=function()
                   {
                   if (xmlhttp.readyState==4 && xmlhttp.status==200){
                     
                     document.getElementById("txtHint3").innerHTML=xmlhttp.responseText;
                     }
                   }
                 xmlhttp.open("GET","getekn.php?id=3&iskanje="+oznaka.value,true);
                 xmlhttp.send();
             }
             function poglejDoc()
             {
             var e=document.getElementById("zap_st");
             var str=e.options[e.selectedIndex].value;
             var isk=document.getElementById("klasif").value;
             
             if (window.XMLHttpRequest){
               // code for IE7+, Firefox, Chrome, Opera, Safari";
               xmlhttp=new XMLHttpRequest();
               }
             else{
               // code for IE6, IE5";
               xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
               }
             xmlhttp.onreadystatechange=function()
               {
               if (xmlhttp.readyState==4 && xmlhttp.status==200){
                 
                 document.getElementById("txtHint4").innerHTML=xmlhttp.responseText;
                 }
               }
             xmlhttp.open("GET","getekn.php?id=4&iskanje="+isk+"&zapst="+str,true);
             xmlhttp.send();
             }
             
             </script>
        <?php
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');

        $SQL = "SELECT solakratko,naslov,kraj,ravnatelj FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["solakratko"].", ".$R["naslov"].", ".$R["kraj"];
            $VRavnatelj=$R["ravnatelj"];
        }else{
            $VSola="";
            $VRavnatelj="";
        }

        $SQL = "SELECT zapst FROM tabdelovodnik WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt DESC LIMIT 0,1";
        //$SQL = "SELECT zapst FROM tabdelovodnik WHERE leto=".$VLeto." ORDER BY ZapSt DESC LIMIT 0,1";
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VZapSt=$R["zapst"];
            if (is_numeric($VZapSt)){
                $VZapSt=intval($VZapSt)+1;
            }else{
                $VZapSt=$VZapSt."/1";
            }
        }else{
            $VZapSt=1;
        }
        
        echo "<h2>Vnos delovodnika</h2>";
        //echo "<a href='delovodnik.php?id=1&leto=".($VLeto-1)."'>".($VLeto-1)."</a> | <a href='delovodnik.php?id=1&leto=".($VLeto+1)."'>".($VLeto+1)."</a><br /><br />";
        echo "<form name='Delovodnik' method=post action='delovodnik.php'>";
        
        //klasifikacija
        /*
        echo "<select name='klasif'>";
        $SQL = "SELECT znak,znakopis3,opis,obrazlozitev FROM klasifikacija WHERE aktivno=1 ORDER BY id";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            echo "<option value='".$R["znak"]."'>";
            echo $R["znak"]." - ";
            if (isset($R["znakopis3"])){
                echo $R["znakopis3"]." / ";
            }
            echo $R["opis"];
            if (isset($R["obrazlozitev"])){
                if (mb_strlen($R["obrazlozitev"]) > 40){
                    echo " (".mb_strcut($R["obrazlozitev"],0,40,$encoding)."...)";
                }else{
                    echo " (".$R["obrazlozitev"].")";
                }
            }
            echo "</option>";
        }
        echo "</select><br />";
        */
        echo "Išči EKN <input name='iskanje' type='text' onkeyup='showIskanje(this.value)'>";
        //echo "<input name='submit' type='submit' value='Najdi'>";
        
        /*
        echo "<div id='txtHint'>";
        echo "<select id='klasif' name='klasif' onchange='showIskanje2()' onmouseout='pokazi()'>";
        $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE aktualno=1";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $rokhrambe='';
            if(isset($R["rokhrambe"])) {
                $rokhrambe=$R["rokhrambe"];
            }
            $trajno='';
            if(isset($R["trajno"])) {
                $trajno=$R["trajno"];
            }
            $arhivsko='';
            if(isset($R["arhivsko"])) {
                $arhivsko=$R["arhivsko"];
            }
            $obrazlozitev='';
            if(isset($R["obrazlozitev"])) {
                $obrazlozitev=$R["obrazlozitev"];
            }
            $t=$R["opis"].", rok: ".$rokhrambe.", trajno: ".$trajno.", arhivsko: ".$arhivsko."\nobrazložitev: ".$obrazlozitev;
            echo "<option value='".$R["znak"]."' title='".$t."'>".$R["znak"]."</option>";
        }
        echo "</select>";
        echo "</div>";
        */
        echo "<div id='txtHint2'>";
        echo "<input id='hid_hramba' name='rokhrambe' type='hidden' value=''>";
        echo "<input id='hid_trajno' name='trajno' type='hidden' value=''>";
        echo "<input id='hid_arhivsko' name='arhivsko' type='hidden' value=''>";
        echo "<input id='hid_zapst' name='hzapst' type='hidden' value=''>";
        echo "</div>";
        
        echo "<table border=1>";
        echo "<tr><th>Zap. št.</th><th>Prišlo<br>datum</th><th>Vložil</th><th>Št. in<br>datum<br>vloge</th><th>Predmet<br>(zadeva)</th><tr>";
        echo "<tr>";
        echo "<td><div>";
        echo "<span id='txtHint'>";
        echo "<select id='klasif' name='klasif' onchange='showIskanje2()' onmouseout='pokazi()'>";
        $SQL = "SELECT id,znak,opis,rokhrambe,trajno,arhivsko,obrazlozitev,aktualno FROM ekn WHERE aktualno=1";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            $rokhrambe='';
            if(isset($R["rokhrambe"])) {
                $rokhrambe=$R["rokhrambe"];
            }
            $trajno='';
            if(isset($R["trajno"])) {
                $trajno=$R["trajno"];
            }
            $arhivsko='';
            if(isset($R["arhivsko"])) {
                $arhivsko=$R["arhivsko"];
            }
            $obrazlozitev='';
            if(isset($R["obrazlozitev"])) {
                $obrazlozitev=$R["obrazlozitev"];
            }
            $t=$R["opis"].", rok: ".$rokhrambe.", trajno: ".$trajno.", arhivsko: ".$arhivsko."\nobrazložitev: ".$obrazlozitev;
            echo "<option value='".$R["znak"]."' title='".$t."'>".$R["znak"]."</option>";
        }
        echo "</select>";
        echo "</span>";
        echo "-";
        
        echo "<span id='txtHint3'>";
        echo "<input id='zap_st' name='zapst' type='text' size='6' value=''>";
        echo "</span>";
        
        echo "/".$Danes->format('Y')."-";
        echo "<input id='ref' name='ref' type='text' size='10' value=''>-";
        echo "<span id='txtHint4'>";
        echo "<input id='doc' name='doc' type='text' size='4' value='1'>";
        echo "</span>";
        echo "</div></td>";
        echo "<td><input name='datumprejema' type='text' size='8' value='".$Danes->format('j.n.Y')."'></td>";
        echo "<td><input name='vlozil' type='text' size='40'><br /><select name='vlozil1'><option selected>".$VSola."</option><option>Ne upoštevaj te izbire</option></select></td>";
        echo "<td><input name='stvloge' type='text' size='8'><br />";
        echo "<input name='datumvloge' type='text' size='8' value='".$Danes->format('j.n.Y')."'></td>";
        echo "<td><textarea name='zadeva' cols='40' rows='3'></textarea></td>";
        echo "</tr>";
        echo "</table><br />";
        //2. vrstica za vnos
        echo "<table border=1>";
        echo "<tr><th>Priloge<br />vrednost</th><th>Ref.</th><th>Rešitev</th><th>Datum<br />rešitve</th><th>Datum<br />vložitve<br />v arhiv</th><th>Roki<br />in poslovne<br />pripombe</th><th>Arhivske<br />pripombe</th></tr>";
        echo "<tr>";
        echo "<td><input name='priloge' type='text' size='8'></td>";
        echo "<td><input name='referenca' type='text' size='8'></td>";
        echo "<td><textarea name='resitev' cols='40' rows='3'></textarea></td>";
        echo "<td><input name='datumresitve' type='text' size='8' value='".$Danes->format('j.n.Y')."'></td>";
        echo "<td><input name='datumvlozitvearhiv' type='text' size='8' value='".$Danes->format('j.n.Y')."'></td>";
        echo "<td><input id='roki' name='roki' type='text' size='8'></td>";
        echo "<td><input id='arh' name='arhpripombe' type='text' size='8'></td>";
        echo "</tr>";
        echo "</table>";
        echo "<input name='id' type='hidden' value='2'>";
        echo "<input name='submit' type='submit' value='Pošlji'><br />";
        //echo "Rezervacija številk: <input name='rezervacija' type='text' size='4'><br />";
        
        echo "</form>";
        $SQL = "SELECT * FROM tabdelovodnik ORDER BY id DESC LIMIT 0,10";
        $result = mysqli_query($link,$SQL);

        echo "<h3>Zadnjih 10 vnosov v delovodnik</h3>";
        echo "<table border=1>";
        echo "<tr><th>Zap. št.</th><th>Prišlo<br />datum</th><th>Vložil</th><th>Št. in<br />datum<br />vloge</th><th>Predmet<br />(zadeva)</th><th>Priloge<br />vrednost</th><th>Ref.</th><th>Rešitev</th><th>Dat. rešitve</th><th>Dat. vložitve v arhiv</th><th>Roki</th><th>Arh. pripombe</th><th>Popravi</th><tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            //echo "<td align=center>".$R["ZapSt"]."/".$R["Leto"]."</td>";
            echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
            if (strlen($R["ref"]) > 0){
                echo $R["ref"]."-";
            }
            echo $R["doc"]."</td>";
            echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
            echo "<td>".$R["Vlozil"]."&nbsp;</td>";
            echo "<td>".$R["StVloge"]."&nbsp;<br />";
            echo $R["DatumVloge"]."&nbsp;</td>";
            echo "<td><textarea cols='40' rows='3'>".$R["Zadeva"]."&nbsp;</textarea></td>";

            echo "<td>".$R["Priloge"]."</td>";
            echo "<td>".$R["Referenca"]."</td>";
            echo "<td>".$R["Resitev"]."</td>";
            echo "<td>".$R["DatumResitve"]."</td>";
            echo "<td>".$R["DatumVlozitveArhiv"]."</td>";
            echo "<td>".$R["Roki"]."</td>";
            echo "<td>".$R["ArhPripombe"]."</td>";
            
            echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
            echo "</tr>";
        }
        echo "</table><br />";
        echo "<a href='delovodnik.php?id=1'>Vnos delovodnika</a><br />";
        echo "<a href='delovodnik.php?id=8&leto=".$Danes->format('Y')."'>Tiskanje delovodnika (PDF)</a><br />";
        echo "<a href='delovodnik.php?id=8&leto=".($Danes->format('Y')-1)."'>Tiskanje delovodnika za preteklo leto (PDF)</a><br />";

        echo "<form name='Iskanje' method=post action='delovodnik.php'>";
        echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
        echo "<input name='id' type='hidden' value='6'>";
        echo "<input name='submit' type='submit' value='Išči'>";
        echo "</form>";
        
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y'))."'>Aktualni letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y')-1)."'>Pretekli letni koledar</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "1d": //spisek obvestil za delovodnik
        echo "<html>";
        echo "<head>";
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        echo "<h2>Spisek evidenčnih številk za polletna obvestila o ocenah ŠL ".($VLetoSol)."/".($VLetoSol+1)."</h2>";
        $SQL = "SELECT tabrazdat.*, tabucenci.priimek,tabucenci.ime FROM ";
        $SQL = $SQL . "(tabrazred ";
        $SQL = $SQL . "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE tabrazdat.leto=" . $VLetoSol ." ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek, tabucenci.ime";
        $result = mysqli_query($link,$SQL);
        $i=1;
        $r=0;
        while ($R = mysqli_fetch_array($result)){
            if ($r != $R["id"]){
                $i=1;
                $r=$R["id"];
            }
            echo "60302-2/".$Danes->format('Y')."-".$R["id"]."-".$i.";".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."<br />";
            $i += 1;
        }
        echo "</body>";
        echo "</html>";
        break;
        
    case "2": // 'vpis zapisa
        $VZapSt=$_POST["zapst"];
        $ekn=$_POST["klasif"];
        $ref=$_POST["ref"];
        $doc=$_POST["doc"];
        $VDatumPrejema=$_POST["datumprejema"];
		if (isDate($VDatumPrejema)){
			$VDatum=new DateTime(isDate($VDatumPrejema));
		}else{
			$VDatum=new DateTime($Danes->format('Y-m-d'));
		}
        if (!is_numeric($VZapSt)){
            $SQL = "SELECT zapst FROM tabdelovodnik WHERE leto=".$VDatum->format('Y')." AND oznaka='$ekn' ORDER BY zapst DESC LIMIT 0,1";
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                $VZapSt=$R["zapst"]+1;
            }else{
                $VZapSt=1;
            }
        }
        /*
        if (strlen($_POST["rezervacija"]) > 0){
            $VRezervacija=intval($_POST["rezervacija"]);
        }else{
        */
            $VRezervacija=1;
        //}
        
        $VVlozil=$_POST["vlozil"];
        if ($VVlozil==""){
            $VVlozil=$_POST["vlozil1"];
        }
        $VStVloge=$_POST["stvloge"];
        $VDatumVloge=$_POST["datumvloge"];
        $VZadeva=$_POST["zadeva"];
        if (mb_strlen($VZadeva,$encoding) > 200){
            $VZadeva=mb_substr($VZadeva,0,200,$encoding);
        }
        $VPriloge=$_POST["priloge"];
        if (mb_strlen($VPriloge,$encoding) > 200){
            $VPriloge=mb_substr($VPriloge,0,200,$encoding);
        }
        $VReferenca=$_POST["referenca"];
        $VResitev=$_POST["resitev"];
        if (mb_strlen($VResitev,$encoding) > 200){
            $VResitev=mb_substr($VResitev,0,200,$encoding);
        }
        $VDatumResitve=$_POST["datumresitve"];
        $VDatumVlozitveArhiv=$_POST["datumvlozitvearhiv"];
        $VRoki=$_POST["roki"];
        $VArhPripombe=$_POST["arhpripombe"];
        
        $Indx=0;
        while ($Indx < $VRezervacija){
            $SQL = "SELECT id FROM tabdelovodnik WHERE leto=".$Danes->format('Y')." AND oznaka='$ekn' AND ZapSt=".$VZapSt." AND ref='$ref' AND doc=$doc";
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                if (strlen($ref) > 0){
                    die ("<h2>Zapis z oznako: $ekn-$VZapSt/".$Danes->format('Y')."-$ref-$doc že obstaja. NI vpisa!</h2>");
                }else{
                    die ("<h2>Zapis z oznako: $ekn-$VZapSt/".$Danes->format('Y')."-$doc že obstaja. NI vpisa!</h2>");
                }
            }else{
                $SQL = "INSERT INTO tabdelovodnik (leto,oznaka,ref,doc,ZapSt,DatumPrejema,Vlozil,StVloge,DatumVloge,Zadeva,Priloge,Referenca,Resitev,DatumResitve,DatumVlozitveArhiv,Roki,ArhPripombe,vpisal,cas)";
                $SQL = $SQL." VALUES (".$VDatum->format('Y').",'$ekn','$ref',$doc,".$VZapSt.",'".$VDatumPrejema."','".$VVlozil."','".$VStVloge."','".$VDatumVloge."','".$VZadeva."','".$VPriloge."','".$VReferenca."','".$VResitev."','".$VDatumResitve."','".$VDatumVlozitveArhiv."','".$VRoki."','".$VArhPripombe."','".$VUporabnik."','".$Danes->format('Y-m-d H:i:s')."')";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu v delovodnik!<br />$SQL<br />");
                }
            }
            $Indx=$Indx+1;
            $VZapSt=$VZapSt+1;
        }
                
        header ("Location: delovodnik.php?id=1");
        break;
    case "3": // 'popravljanje
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');

        if ($VZapis > 0){
            $SQL = "SELECT * FROM tabdelovodnik WHERE id=".$VZapis;
            $result = mysqli_query($link,$SQL);
            
            if ($R = mysqli_fetch_array($result)){
                echo "<h2>Popravljanje/dopolnjevanje delovodnika</h2>";
                echo "<form name='Delovodnik' method=post action='delovodnik.php'>";
                echo "<table border=1>";
                echo "<tr><th>Zap. št.</th><th>Prišlo<br />datum</th><th>Vložil</th><th>Št. in<br />datum<br />vloge</th><th>Predmet<br />(zadeva)</th><tr>";
                echo "<tr>";
                echo "<td><input id='ekn' name='ekn' type='text' size='6' value='".$R["oznaka"]."'>-<input id='zap_st' name='zapst' type='text' size='6' value='".$R["ZapSt"]."'>/".$R["Leto"]."-<input id='ref' name='ref' type='text' size='10' value='".$R["ref"]."'>-<input id='doc' name='doc' type='text' size='4' value='".$R["doc"]."'></td>";
                //echo "<td>".$R["ZapSt"]."/".$R["Leto"]."</td>";
                echo "<td><input name='datumprejema' type='text' size='8' value='".$R["DatumPrejema"]."'></td>";
                echo "<td><input name='vlozil' type='text' size='40' value='".$R["Vlozil"]."'></td>";
                echo "<td><input name='stvloge' type='text' size='8' value='".$R["StVloge"]."'><br />";
                echo "<input name='datumvloge' type='text' size='8' value='".$R["DatumVloge"]."'></td>";
                echo "<td><textarea name='zadeva' cols='40' rows='3'>".$R["Zadeva"]."</textarea></td>";
                echo "</tr>";
                echo "</table><br />";
                echo "<table border=1>";
                echo "<tr><th>Priloge<br />vrednost</th><th>Ref.</th><th>Rešitev</th><th>Datum<br />rešitve</th><th>Datum<br />vložitve<br />v arhiv</th><th>Roki<br />in poslovne<br />pripombe</th><th>Arhivske<br />pripombe</th></tr>";
                echo "<tr>";
                echo "<td><input name='priloge' type='text' size='8' value='".$R["Priloge"]."'></td>";
                echo "<td><input name='referenca' type='text' size='8' value='".$R["Referenca"]."'></td>";
                echo "<td><textarea name='resitev' cols='40' rows='3'>".$R["Resitev"]."</textarea></td>";
                echo "<td><input name='datumresitve' type='text' size='8' value='".$R["DatumResitve"]."'></td>";
                echo "<td><input name='datumvlozitvearhiv' type='text' size='8' value='".$R["DatumVlozitveArhiv"]."'></td>";
                echo "<td><input name='roki' type='text' size='8' value='".$R["Roki"]."'></td>";
                echo "<td><input name='arhpripombe' type='text' size='8' value='".$R["ArhPripombe"]."'></td>";
                echo "</tr>";
                echo "</table><br />";
                echo "<input name='id' type='hidden' value='4'>";
                echo "<input name='zapis' type='hidden' value='".$VZapis."'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
        }
        echo "</body>";
        echo "</html>";
        break;
    case "4": //vpis popravkov
        $ekn=$_POST["ekn"];
        $ref=$_POST["ref"];
        $doc=$_POST["doc"];
        $zapst=$_POST["zapst"];
        $VDatumPrejema=$_POST["datumprejema"];
        $VVlozil=$_POST["vlozil"];
        $VStVloge=$_POST["stvloge"];
        $VDatumVloge=$_POST["datumvloge"];
        $VZadeva=$_POST["zadeva"];
        $VPriloge=$_POST["priloge"];
        $VReferenca=$_POST["referenca"];
        $VResitev=$_POST["resitev"];
        $VDatumResitve=$_POST["datumresitve"];
        $VDatumVlozitveArhiv=$_POST["datumvlozitvearhiv"];
        $VRoki=$_POST["roki"];
        $VArhPripombe=$_POST["arhpripombe"];
        
        $SQL = "SELECT leto FROM tabdelovodnik WHERE id=$VZapis";
        $result = mysqli_query($link,$SQL);
        $leto=$Danes->format('Y');
        if (mysqli_num_rows($result) > 0){
            $leto=$R["leto"];
        }
        
        $SQL = "SELECT id FROM tabdelovodnik WHERE oznaka='$ekn' AND ref='$ref' AND doc=$doc AND zapst=$zapst AND leto=$leto AND id <> $VZapis";
        $result = mysqli_query($link,$SQL);
        if (mysqli_num_rows($result) > 0){
            die("Ta zapis že obstaja, ne morem prepisati!<br />");
        }else{
            $SQL = "UPDATE tabdelovodnik SET ";
            $SQL =$SQL . "oznaka='".$ekn."',";
            $SQL =$SQL . "ref='".$ref."',";
            $SQL =$SQL . "doc='".$doc."',";
            $SQL =$SQL . "zapst='".$zapst."',";
            $SQL =$SQL . "DatumPrejema='".$VDatumPrejema."',";
            $SQL =$SQL . "Vlozil='".$VVlozil."',";
            $SQL =$SQL . "StVloge='".$VStVloge."',";
            $SQL =$SQL . "DatumVloge='".$VDatumVloge."',";
            $SQL =$SQL . "Zadeva='".$VZadeva."',";
            $SQL =$SQL . "Priloge='".$VPriloge."',";
            $SQL =$SQL . "Referenca='".$VReferenca."',";
            $SQL =$SQL . "Resitev='".$VResitev."',";
            $SQL =$SQL . "DatumResitve='".$VDatumResitve."',";
            $SQL =$SQL . "DatumVlozitveArhiv='".$VDatumVlozitveArhiv."',";
            $SQL =$SQL . "Roki='".$VRoki."',";
            $SQL =$SQL . "ArhPripombe='".$VArhPripombe."',";
            $SQL =$SQL . "vpisal='".$VUporabnik."',";
            $SQL =$SQL . "cas='".$Danes->format('Y-m-d H:i:s')."' ";
            $SQL =$SQL . "WHERE id=".$VZapis;
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri popravljanju delovodnika!<br />$SQL<br />");
            }
        }
        header ("Location: delovodnik.php?id=1");
        break;
    case "5": //izpis rubrik na določen dan (iz koledarja)
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');

        $VDatum=$_GET["datum"];
        $SQL = "SELECT * FROM tabdelovodnik WHERE DatumPrejema='".$VDatum."' OR DatumVloge='".$VDatum."' ORDER BY ZapSt";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izpis delovodnika - ".$VDatum."</h2>";
        echo "<br /><table border=1>";
        echo "<tr><th>Zap. št.</th><th>Prišlo<br />datum</th><th>Vložil</th><th>Št. in<br />datum<br />vloge</th><th>Predmet<br />(zadeva)</th><th>Popravi</th><tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
            if (strlen($R["ref"]) > 0){
                echo $R["ref"]."-";
            }
            echo $R["doc"]."</td>";
            echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
            echo "<td>".$R["Vlozil"]."&nbsp;</td>";
            echo "<td>".$R["StVloge"]."&nbsp;<br />";
            echo $R["DatumVloge"]."&nbsp;</td>";
            echo "<td><textarea cols='40' rows='2'>".$R["Zadeva"]."&nbsp;</textarea></td>";
            echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
            echo "</tr>";
        }
        echo "</table><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y'))."'>Aktualni letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y')-1)."'>Pretekli letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=1'>Na vnos delovodnika</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "6": //splošno iskanje
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
//        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        $SQL = "SELECT * FROM tabdelovodnik WHERE ";
        $SQL = $SQL . "vlozil LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR zadeva LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR oznaka LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR ref LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR priloge LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR referenca LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR resitev LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR roki LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR ArhPripombe LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " OR ZapSt LIKE '%".$_POST["iskanje"]."%'";
        $SQL = $SQL . " ORDER BY ZapSt";
        $result = mysqli_query($link,$SQL);
        
        echo "<h2>Izpis delovodnika - ".$_POST["iskanje"]."</h2>";
        echo "<br /><table border=1>";
        echo "<tr><th>Zap. št.</th><th>Prišlo<br />datum</th><th>Vložil</th><th>Št. in<br />datum<br />vloge</th><th>Predmet<br />(zadeva)</th><th>Popravi</th><tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
            if (strlen($R["ref"]) > 0){
                echo $R["ref"]."-";
            }
            echo $R["doc"]."</td>";
            //echo "<td align=center>".$R["ZapSt"]."</td>";
            echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
            echo "<td>".$R["Vlozil"]."&nbsp;</td>";
            echo "<td>".$R["StVloge"]."&nbsp;<br />";
            echo $R["DatumVloge"]."&nbsp;</td>";
            echo "<td><textarea cols='40' rows='2'>".$R["Zadeva"]."&nbsp;</textarea></td>";
            echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
            echo "</tr>";
        }
        echo "</table><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y'))."'>Aktualni letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y')-1)."'>Pretekli letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=1'>Na vnos delovodnika</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "7": //mesečni izpis
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
//        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

        $VMesec=$_GET["mesec"];
        
        $SQL = "SELECT * FROM tabdelovodnik WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt";
        $result = mysqli_query($link,$SQL);

        echo "<h2>Izpis delovodnika - ".MonthName($VMesec)."</h2>";
        echo "<br /><table border=1>";
        echo "<tr><th>Zap. št.</th><th>Prišlo<br />datum</th><th>Vložil</th><th>Št. in<br />datum<br />vloge</th><th>Predmet<br />(zadeva)</th><th>Popravi</th><tr>";
        while ($R = mysqli_fetch_array($result)){
            if (isDate($R["DatumPrejema"])){
                $Datum=new DateTime(isDate($R["DatumPrejema"]));
                if ($Datum->format('n')==$VMesec){
                    echo "<tr>";
                    //echo "<td align=center>".$R["ZapSt"]."</td>";
                    echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
                    if (strlen($R["ref"]) > 0){
                        echo $R["ref"]."-";
                    }
                    echo $R["doc"]."</td>";
                    echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
                    echo "<td>".$R["Vlozil"]."&nbsp;</td>";
                    echo "<td>".$R["StVloge"]."&nbsp;<br />";
                    echo $R["DatumVloge"]."&nbsp;</td>";
                    echo "<td><textarea cols='40' rows='2'>".$R["Zadeva"]."&nbsp;</textarea></td>";
                    echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
                    echo "</tr>";
                }else{
                    if (isDate($R["DatumPrejema"])){
                        $Datum=new DateTime(isDate($R["DatumVloge"]));
                        if ($Datum->format('n')==$VMesec){
                            echo "<tr>";
                            //echo "<td align=center>".$R["ZapSt"]."</td>";
                            echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
                            if (strlen($R["ref"]) > 0){
                                echo $R["ref"]."-";
                            }
                            echo $R["doc"]."</td>";
                            echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
                            echo "<td>".$R["Vlozil"]."&nbsp;</td>";
                            echo "<td>".$R["StVloge"]."&nbsp;<br />";
                            echo $R["DatumVloge"]."&nbsp;</td>";
                            echo "<td><textarea cols='40' rows='2'>".$R["Zadeva"]."&nbsp;</textarea></td>";
                            echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
                            echo "</tr>";
                        }
                    }
                }
            }else{
               if (isDate($R["DatumPrejema"])){
                    $Datum=new DateTime(isDate($R["DatumVloge"]));
                    if ($Datum->format('n')==$VMesec){
                        echo "<tr>";
                        //echo "<td align=center>".$R["ZapSt"]."</td>";
                        echo "<td align=center>".$R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-";
                        if (strlen($R["ref"]) > 0){
                            echo $R["ref"]."-";
                        }
                        echo $R["doc"]."</td>";
                        echo "<td>".$R["DatumPrejema"]."&nbsp;</td>";
                        echo "<td>".$R["Vlozil"]."&nbsp;</td>";
                        echo "<td>".$R["StVloge"]."&nbsp;<br />";
                        echo $R["DatumVloge"]."&nbsp;</td>";
                        echo "<td><textarea cols='40' rows='2'>".$R["Zadeva"]."&nbsp;</textarea></td>";
                        echo "<td><a href='delovodnik.php?id=3&zapis=".$R["id"]."'>Popravi</a></td>";
                        echo "</tr>";
                    }
                }
            }
        }
        echo "</table><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y'))."'>Aktualni letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=9&leto=".($Danes->format('Y')-1)."'>Pretekli letni koledar</a><br />";
        echo "<a href='delovodnik.php?id=1'>Na vnos delovodnika</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "8": //delovodnik PDF
        if (isset($_SESSION["DayToPrint"])){
            $PrintDay = $_SESSION["DayToPrint"];
        }else{
            $PrintDay = $Danes->format('j. n. Y');
        }
        $_SESSION["DayToPrint"]=$PrintDay;

        $SQL = "SELECT * FROM tabsola";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
            $VSolaKraj=$R["Kraj"];
            $VRavnatelj=$R["Ravnatelj"];
            $TipSole=$R["TipSole"];
            $RavnateljID=$R["ravnatelj_ID"];
        }else{
            $VSola=" ";
            $VRavnatelj=" ";
            $RavnateljID=0;
            $VSolaNaslov="";
            $VSolaKraj="";
            $TipSole=0;
        }

        $SQL = "SELECT spol FROM tabucitelji WHERE idUcitelj=".$RavnateljID;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $SpolRavnatelj=$R["spol"];
        }else{
            $SpolRavnatelj="M";
        }

        $pdf = new FPDF();

        //$pdf->AddFont('EAN_b','','EAN_b.php');
        $pdf->AddFont('arial_CE','','arial_CE.php');
        $pdf->AddFont('arialbd_CE','','arialbd_CE.php');

            $FontSize=10;
            $FontSizeG=7;
            $YPoz[0]=210-195;
            $YPoz[1]=210-183;
            $YPoz[2]=210-167;
            $YPoz[3]=210-151;
            $YPoz[4]=210-135;
            $YPoz[5]=210-119;
            $YPoz[6]=210-103;
            $YPoz[7]=210-87;
            $YPoz[8]=210-71;
            $YPoz[9]=210-55;
            $YPoz[10]=210-39;
            $YPoz[11]=210-23;
            $YPozDiff=4.5;
            $XPoz[0]=15;
            $XPoz[1]=25;
            $XPoz[2]=40;
            $XPoz[3]=95;
            $XPoz[4]=107;
            $XPoz[5]=165;
            $XPoz[6]=180;
            $XPoz[7]=195;
            $XPoz[8]=227;
            $XPoz[9]=241;
            $XPoz[10]=255;
            $XPoz[11]=274;
            $XPoz[12]=287;
            
            $SQL = "SELECT * FROM tabdelovodnik WHERE leto=".$VLeto;
            $SQL = $SQL . " ORDER BY cas,id";
            $result = mysqli_query($link,$SQL);
            
            $StZapisov=mysqli_num_rows($result);
            
            $IndxPN=0;
            $Zapis=0;
            while ($R = mysqli_fetch_array($result)){
                $Zapis=$Zapis+1;
                if ($Zapis % 10 == 1){ //'naredi novo stran
                    $IndxPN=$IndxPN+1;
                    $pdf->AddPage("L","A4");

                    for ($Indx=0;$Indx <= 11;$Indx++){
                        $pdf->Line($XPoz[0], $YPoz[$Indx], $XPoz[12], $YPoz[$Indx]);
                    }
                    for ($Indx=0;$Indx <= 12;$Indx++){
                        $pdf->Line($XPoz[$Indx], $YPoz[0], $XPoz[$Indx], $YPoz[11]);
                    }

                    $pdf->SetFont('arial_CE','',$FontSizeG);
                    $txt=ToWin($IndxPN.". stran");
                    $pdf->SetXY($XPoz[0],$YPoz[0]-6);
                    $pdf->Cell(0,0,$txt,0,2,"L");
                    
                    $txt=ToWin("Del. št.\nZap. št.");
                    $pdf->SetXY($XPoz[0],$YPoz[0]+3);
                    $pdf->MultiCell($XPoz[1]-$XPoz[0],3,$txt,0,"L");
                    
                    $txt=ToWin("Prišlo\ndatum");
                    $pdf->SetXY($XPoz[1],$YPoz[0]+3);
                    $pdf->MultiCell($XPoz[2]-$XPoz[1],3,$txt,0,"C");
                    
                    $txt=ToWin("Vložil");
                    $pdf->SetXY($XPoz[2],$YPoz[0]+4);
                    $pdf->MultiCell($XPoz[3]-$XPoz[2],3,$txt,0,"C");
                    
                    $txt=ToWin("Št. in\ndatum\nvloge");
                    $pdf->SetXY($XPoz[3],$YPoz[0]+1);
                    $pdf->MultiCell($XPoz[4]-$XPoz[3],3,$txt,0,"C");
                    
                    $txt=ToWin("Predmet\nzadeva");
                    $pdf->SetXY($XPoz[4],$YPoz[0]+3);
                    $pdf->MultiCell($XPoz[5]-$XPoz[4],3,$txt,0,"C");
                    
                    $txt=ToWin("Ref.");
                    $pdf->SetXY($XPoz[6],$YPoz[0]+3);
                    $pdf->MultiCell($XPoz[7]-$XPoz[6],3,$txt,0,"C");
                    
                    $txt=ToWin("Rešitev");
                    $pdf->SetXY($XPoz[7],$YPoz[0]+4);
                    $pdf->MultiCell($XPoz[8]-$XPoz[7],3,$txt,0,"C");

                    $txt=ToWin("Datum\nrešitve");
                    $pdf->SetXY($XPoz[8],$YPoz[0]+4);
                    $pdf->MultiCell($XPoz[9]-$XPoz[8],3,$txt,0,"C");
                    
                    $txt=ToWin("Datum\nvložitve\nv arhiv");
                    $pdf->SetXY($XPoz[9],$YPoz[0]+1);
                    $pdf->MultiCell($XPoz[10]-$XPoz[9],3,$txt,0,"C");
                    
                    $txt=ToWin("Roki\nin poslovne\npripombe");
                    $pdf->SetXY($XPoz[10],$YPoz[0]+1);
                    $pdf->MultiCell($XPoz[11]-$XPoz[10],3,$txt,0,"C");

                    $txt=ToWin("Arhivske\npripombe");
                    $pdf->SetXY($XPoz[11],$YPoz[0]+3);
                    $pdf->MultiCell($XPoz[12]-$XPoz[11],3,$txt,0,"C");
                } 

                $pdf->SetFont('arial_CE','',6);
                if (strlen($R["oznaka"]) > 0){
                    if (strlen($R["ref"]) > 0){
                        $txt=ToWin($R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-".$R["ref"]."-".$R["doc"]);
                    }else{
                        $txt=ToWin($R["oznaka"]."-".$R["ZapSt"]."/".$R["Leto"]."-".$R["doc"]);
                    }
                }else{
                    $txt=ToWin($R["ZapSt"]);
                }
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[0],$YPoz[10]+3);
                }else{
                    $pdf->SetXY($XPoz[0],$YPoz[$Zapis % 10]+3);
                }
                $pdf->MultiCell($XPoz[1]-$XPoz[0],3,$txt,0,"C");
                
                
                $pdf->SetFont('arial_CE','',$FontSizeG);
                $txt=ToWin($R["DatumPrejema"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[1]+1,$YPoz[10]+6);
                }else{
                    $pdf->SetXY($XPoz[1]+1,$YPoz[$Zapis % 10]+6);
                }
                $pdf->Cell($XPoz[2]-$XPoz[1],0,$txt,0,2,"C");
                
                $txt=ToWin($R["Vlozil"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[2]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[2]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[3]-$XPoz[2],4,$txt,0,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeG-1);
                $txt=ToWin($R["StVloge"]."\n".$R["DatumVloge"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[3]+1,$YPoz[10]+3);
                }else{
                    $pdf->SetXY($XPoz[3]+1,$YPoz[$Zapis % 10]+3);
                }
                $pdf->MultiCell($XPoz[4]-$XPoz[3],0,$txt,0,"C");
                
                $pdf->SetFont('arial_CE','',$FontSizeG);
                $txt=ToWin($R["Zadeva"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[4]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[4]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[5]-$XPoz[4],4,$txt,0,"L");
                
                
                $txt=ToWin($R["Priloge"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[5]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[5]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[6]-$XPoz[5],4,$txt,0,"L");
                
                $txt=ToWin($R["Referenca"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[6]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[6]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[7]-$XPoz[6],4,$txt,0,"L");
                
                $pdf->SetFont('arial_CE','',5);
                $txt=ToWin($R["Resitev"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[7]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[7]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[8]-$XPoz[7],4,$txt,0,"L");
                
                $pdf->SetFont('arial_CE','',$FontSizeG);
                $txt=ToWin($R["DatumResitve"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[8]+1,$YPoz[10]+3);
                }else{
                    $pdf->SetXY($XPoz[8]+1,$YPoz[$Zapis % 10]+3);
                }
                $pdf->Cell($XPoz[9]-$XPoz[8],0,$txt,0,2,"C");
                
                $txt=ToWin($R["DatumVlozitveArhiv"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[9]+1,$YPoz[10]+3);
                }else{
                    $pdf->SetXY($XPoz[9]+1,$YPoz[$Zapis % 10]+3);
                }
                $pdf->Cell($XPoz[10]-$XPoz[9],0,$txt,0,2,"C");
                
                $txt=ToWin($R["Roki"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[10]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[10]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[11]-$XPoz[10],4,$txt,0,"L");
                
                $txt=ToWin($R["ArhPripombe"]);
                if ($Zapis % 10 == 0){
                    $pdf->SetXY($XPoz[11]+1,$YPoz[10]+1);
                }else{
                    $pdf->SetXY($XPoz[11]+1,$YPoz[$Zapis % 10]+1);
                }
                $pdf->MultiCell($XPoz[12]-$XPoz[11],4,$txt,0,"L");
            }    
            
        $pdf->Output("delovodnik.pdf","D");
        break;
    case "9": //izpis koledarja
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        //        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        $ActualYear=$VLeto;
        for ($VLeto=$ActualYear;$VLeto <= intval($Danes->format('Y'));$VLeto++){
            $SQL = "SELECT * FROM tabpraznik WHERE leto=".$VLeto." ORDER BY leto,mesec,dan";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            $ProstiDnevi=0;
            while ($R = mysqli_fetch_array($result)){
                //$Datum=new DateTime($R["datum"]);
                $Praznik[$Indx][0]=new DateTime($R["datum"]);
                $Praznik[$Indx][1]=$R["kat"];
                if ($Praznik[$Indx][1]==1){
                    $ProstiDnevi=$ProstiDnevi+1;
                }
                $Indx=$Indx+1;
            }
            $StPraznikov=$Indx-1;

            if ($VLeto % 4 == 0 ) {
                $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
            }else{
                $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
            }

            $SQL = "SELECT * FROM tabdelovodnik WHERE leto=".$VLeto." ORDER BY ZapSt";
            $result = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Datum=new DateTime(isDate($R["DatumPrejema"]));
                $Zapisi[$Indx][0]=$Datum->format('Y-m-d');
                $Datum=new DateTime(isDate($R["DatumVloge"]));
                $Zapisi[$Indx][1]=$Datum->format('Y-m-d');
                $Indx=$Indx+1;
            }
            $StZapisov=$Indx-1;
            
            echo "<h2>Koledar za leto ".$VLeto."</h2>";
            echo "<table border=1>";
            echo "<tr><th></th>";
            for ($Indx=1;$Indx <= 31;$Indx++){
                echo "<th>".$Indx."</th>";
            }
            echo "</tr>";
            for ($Indx=1;$Indx <= 12;$Indx++){
                echo "<tr><td align=center><a href='delovodnik.php?id=7&mesec=".$Indx."'>".$Indx."</a></td>";
                for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                    
                    $Datum=new Datetime($VLeto."-".$Indx."-".$Indx1);
                    switch ($Datum->format('w')){
                        case 0:
                        case 6:
                            /*
                            if (CheckDelovodnik($Datum->format('Y-m-d'))){
                                echo "<td bgcolor=lightsalmon><a href='delovodnik.php?id=5&datum=".$Datum->format('j.n.Y')."'>D</a></td>";
                            }else{
                                echo "<td bgcolor=lightsalmon>&nbsp;</td>";
                            }
                            */
                            $SQL = "SELECT id FROM tabdelovodnik WHERE datumprejema='".$Indx1.".".$Indx.".".$VLeto."' OR datumvloge='".$Indx1.".".$Indx.".".$VLeto."'";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                echo "<td bgcolor=lightsalmon><a href='delovodnik.php?id=5&datum=".$Indx1.".".$Indx.".".$VLeto."'>D</a></td>";
                            }else{
                                echo "<td bgcolor=lightsalmon>&nbsp;</td>";
                            }
                            break;
                        default:
                            switch (CheckPraznik($Datum)){
                                case 0: // 'delovnik
                                    /*
                                    if (CheckDelovodnik($Datum->format('Y-m-d'))){
                                        echo "<td><a href='delovodnik.php?id=5&datum=".$Datum->format('j.n.Y')."'>D</a></td>";
                                    }else{
                                        echo "<td>&nbsp;</td>";
                                    }
                                    */
                                    $SQL = "SELECT id FROM tabdelovodnik WHERE datumprejema='".$Indx1.".".$Indx.".".$VLeto."' OR datumvloge='".$Indx1.".".$Indx.".".$VLeto."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        echo "<td><a href='delovodnik.php?id=5&datum=".$Indx1.".".$Indx.".".$VLeto."'>D</a></td>";
                                    }else{
                                        echo "<td>&nbsp;</td>";
                                    }
                                    break;
                                case 1: // 'praznik
                                    echo "<td bgcolor=lightgreen>&nbsp;</td>";
                                    break;
                                case 2: // 'prost dan za učitelje
                                    /*
                                    if (CheckDelovodnik($Datum->format('Y-m-d'))){
                                        echo "<td bgcolor=lightblue><a href='delovodnik.php?id=5&datum=".$Datum->format('j.n.Y')."'>D</a></td>";
                                    }else{
                                        echo "<td bgcolor=lightblue>&nbsp;</td>";
                                    }
                                    */
                                    $SQL = "SELECT id FROM tabdelovodnik WHERE datumprejema='".$Indx1.".".$Indx.".".$VLeto."' OR datumvloge='".$Indx1.".".$Indx.".".$VLeto."'";
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        echo "<td bgcolor=lightblue><a href='delovodnik.php?id=5&datum=".$Indx1.".".$Indx.".".$VLeto."'>D</a></td>";
                                    }else{
                                        echo "<td bgcolor=lightblue>&nbsp;</td>";
                                    }
                                    
                            }
                    }
                }
                echo "</tr>";
            }
            echo "</table><br />";
        }
        echo "<a href='delovodnik.php?id=1'>Na vnos delovodnika</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "10": //obrazec za kreiranje množičnih evidenčnih številk
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        echo "<br />";
        $tip="";
        if (isset($_POST["tip"])){
            $tip=$_POST["tip"];
        }else{
            if (isset($_GET["tip"])){
                $tip=$_GET["tip"];
            }
        }
        switch ($tip){
            case "1":
                $skupina=$_POST["skupina"];
                switch ($skupina){
                    case "1": //vsi učenci
                        echo "<form name='evstevilke' method='post' action='delovodnik.php'>";
                        echo "Izberite dokument:<br />";
                        echo "<input name='doc' type='radio' value='1' checked='checked'>Potrdilo o šolanju<br />";
                        echo "<input name='doc' type='radio' value='2' >Polletno obvestilo o ocenah<br />";
                        echo "<input name='doc' type='radio' value='3'>Obvestilo o zaključnih ocenah<br />";
                        echo "<input name='doc' type='radio' value='4'>Spričevalo o končanem razredu (1.-8.r)<br />";
                        echo "<input name='doc' type='radio' value='5'>Zaključno spričevalo (9.r)<br />";
                        echo "<input name='doc' type='radio' value='6'>Obvestilo o dosežkih pri NPZ<br />";
                        echo "EKN oznaka: <input name='evstev' type='text' value='60300' size='10'><br />";
                        echo "Datum: <input name='datum' type='text' value='".$Danes->format('d.m.Y')."' size='10'><br />";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "<input name='tip' type='hidden' value='2'>";
                        echo "<input name='id' type='hidden' value='10'>";
                        echo "</form>";
                        break;
                    case "2": //določeni razredi
                        echo "<form name='evstevilke' method='post' action='delovodnik.php'>";
                        echo "Izberite dokument:<br />";
                        echo "<input name='doc' type='radio' value='1' checked='checked'>Potrdilo o šolanju<br />";
                        echo "<input name='doc' type='radio' value='2' >Polletno obvestilo o ocenah<br />";
                        echo "<input name='doc' type='radio' value='3'>Obvestilo o zaključnih ocenah<br />";
                        echo "<input name='doc' type='radio' value='4'>Spričevalo o končanem razredu (1.-8.r)<br />";
                        echo "<input name='doc' type='radio' value='5'>Zaključno spričevalo (9.r)<br />";
                        echo "<input name='doc' type='radio' value='6'>Obvestilo o dosežkih pri NPZ<br />";
                        echo "EKN oznaka: <input name='evstev' type='text' value='60300' size='10'><br />";
                        echo "Datum: <input name='datum' type='text' value='".$Danes->format('d.m.Y')."' size='10'><br />";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "<input name='tip' type='hidden' value='3'>";
                        echo "<input name='id' type='hidden' value='10'>";

                        echo "<select name='razredi[]' multiple size='5'>";                        
                        $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat ";
                        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
                        $SQL .= " WHERE tabrazdat.leto=".$VLetoSol." AND tabrazdat.razred >= 0 ";
                        $SQL .= " ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($VecSol){
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                            }else{
                                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                            }
                        }
                        echo "</select><br />";
                        echo "</form>";
                        break;
                    case "3": //določeni učenci
                        echo "<form name='evstevilke' method='post' action='delovodnik.php'>";
                        echo "Izberite dokument:<br />";
                        echo "<input name='doc' type='radio' value='1' checked='checked'>Potrdilo o šolanju<br />";
                        echo "<input name='doc' type='radio' value='2' >Polletno obvestilo o ocenah<br />";
                        echo "<input name='doc' type='radio' value='3'>Obvestilo o zaključnih ocenah<br />";
                        echo "<input name='doc' type='radio' value='4'>Spričevalo o končanem razredu (1.-8.r)<br />";
                        echo "<input name='doc' type='radio' value='5'>Zaključno spričevalo (9.r)<br />";
                        echo "<input name='doc' type='radio' value='6'>Obvestilo o dosežkih pri NPZ<br />";
                        echo "EKN oznaka: <input name='evstev' type='text' value='60300' size='10'><br />";
                        echo "Datum: <input name='datum' type='text' value='".$Danes->format('d.m.Y')."' size='10'><br />";
                        echo "<input name='submit' type='submit' value='Pošlji'><br />";
                        echo "<input name='tip' type='hidden' value='4'>";
                        echo "<input name='id' type='hidden' value='10'>";
                        echo "<select name='ucenci[]' multiple size='15'>";                        
                        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
                        $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                        $SQL .= " WHERE leto=".$VLetoSol;
                        $SQL .= " ORDER BY tabucenci.priimek,tabucenci.ime";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            echo "<option value='".$R["iducenec"]."'>".$R["priimek"]."  ".$R["ime"].", ".$R["razred"].". ".$R["paralelka"]."</option>";
                        }
                        echo "</select><br />";
                        echo "</form>";
                        break;
                    case "4": //določeni zaposleni
                        echo "<form name='evstevilke' method='post' action='delovodnik.php'>";
                        echo "Izberite dokument:<br />";
                        echo "<input name='doc' type='radio' value='1' checked='checked'>Odločbe o dopustih<br />";
                        echo "<input name='doc' type='radio' value='2'>Letne ocene delavcev<br />";
                        echo "<input name='doc' type='radio' value='3'>Obvestilo o napredovanju<br />";
                        echo "<input name='doc' type='radio' value='4'>Drugo <input name='drugo' type='text' value='' size='40'><br /><br />";
                        echo "EKN oznaka: <input name='evstev' type='text' value='100' size='10'>";
                        echo "Datum: <input name='datum' type='text' value='".$Danes->format('d.m.Y')."' size='10'><br /><br />";
                        echo "<input name='vse' type='button' value='Označi vse' onclick='OznaciVse(this.form)'><input name='brisi' type='button' value='Briši vse' onclick='BrisiVse(this.form)'><input name='submit' type='submit' value='Pošlji'><br />";
                        echo "<input name='tip' type='hidden' value='5'>";
                        echo "<input name='id' type='hidden' value='10'>";
                        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji ";
                        $SQL .= " WHERE status > 0";
                        $SQL .= " ORDER BY priimek,ime";
                        $result = mysqli_query($link,$SQL);
                        $i=1;
                        while ($R = mysqli_fetch_array($result)){
                            echo "<input name='cbuc_$i' type='checkbox'><input name='imeuc_$i' type='hidden' value='".$R["iducitelj"]."'>".$R["priimek"]."  ".$R["ime"]."<br />";
                            $i += 1;
                        }
                        $i -= 1;
                        echo "<input name='stdelavcev' type='hidden' value='$i'>";
                        echo "<br />";
                        echo "</form>";
                ?>
                        <script language="JavaScript">

                        function OznaciStolpec(obr,n){
                            var vrstica=obr.elements['dan_'+n]
                            
                            if (vrstica != null) {
                                for (i=0; i < vrstica.length; i++) {
                                    if (vrstica[i].checked){
                                        vrstica[i].checked=false;
                                    }else{
                                        vrstica[i].checked=true;
                                    }
                                }
                            }
                        }
                        function OznaciVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                if (form.elements[i].type=="checkbox"){
                                    form.elements[i].checked=true;
                                }
                            }
                        }
                        function BrisiVse(form){
                            for (i=1; i < form.elements.length; i++) {
                                if (form.elements[i].type=="checkbox"){
                                    form.elements[i].checked=false;
                                }
                            }
                        }
                        </script>
                <?php
                        break;
                }
                break;
            case "2": //vsi učenci
                $evstev=$_POST["evstev"];
                $doc=$_POST["doc"];
                if (isDate($_POST["datum"])){
                    $datum=new DateTime(isDate($_POST["datum"]));
                }else{
                    $datum=new DateTime($Danes->format('Y-m-d'));
                }
                
                $zapst=1;
                $SQL = "SELECT zapst FROM tabdelovodnik WHERE oznaka='$evstev' AND leto=".$datum->format('Y')." ORDER BY zapst DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $zapst=$R["zapst"]+1;
                    }
                }
                
                $dovoljeno=true;
                if ($Danes->format('n') < 9){
                    if ($Danes->format('Y')-$VLetoSol > 1){
                        $dovoljeno=false;
                    }
                }else{
                    if ($Danes->format('Y')-$VLetoSol > 0){
                        $dovoljeno=false;
                    }
                }
                if ($dovoljeno){
                    switch ($doc){
                        case "2":
                        case "3":
                        case "4":
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabrazdat.razred > 0 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        case "5":   //zaključno spričevalo da le devetarjem
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabrazdat.razred > 8 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        default:
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    }
                    $result = mysqli_query($link,$SQL);
                    $i=1;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenec[$i][0]=$R["iducenec"];
                        $ucenec[$i][1]=$R["ime"]." ".$R["priimek"];
                        $ucenec[$i][2]=$R["razred"].". ".$R["oznaka"];
                        $i += 1;
                    }
                    $stUcencev=$i-1;
                    for ($i=1;$i <= $stUcencev;$i++){
                        $SQL = "SELECT dokument,datum FROM tabevstevilkeu WHERE dokument=$doc AND leto=$VLetoSol AND iducenec=".$ucenec[$i][0];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "Podatki za ".$ucenec[$i][1].", ".$ucenec[$i][2]." so bili vpisani že: ".$R["datum"]." ($doc)<br />";
                        }else{
                            $SQL = "INSERT INTO tabevstevilkeu (iducenec,leto,evstev,datum,dokument) VALUES (";
                            $SQL .= $ucenec[$i][0].",";
                            $SQL .= $VLetoSol.",";
                            $SQL .= "'".$evstev."-".$zapst."/".$datum->format('Y')."-1',";
                            $SQL .= "'".$datum->format('Y-m-d')."',";
                            $SQL .= $doc;
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }

                            switch ($doc){
                                case "3": //obvestilo o ocenah
                                case "4":  //spričevalo za razred
                                case "5":  //zaključno spričevalo
                                    $SQL = "UPDATE tabrazred SET evidst='".$evstev."-".$zapst."/".$datum->format('Y')."-1',datumizdaje='".$datum->format('j.n.Y')."' WHERE iducenec=".$ucenec[$i][0]." AND leto=$VLetoSol";
                                    if (!($result = mysqli_query($link,$SQL))){
                                        die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                                    }
                                    break;
                            }
                            
                            $SQL = "INSERT INTO tabdelovodnik (oznaka,ref,doc,zapst,leto,datumprejema,vlozil,stvloge,datumvloge,zadeva,priloge,referenca,resitev,datumresitve,datumvlozitvearhiv,roki,arhpripombe,vpisal,cas) VALUES (";
                            $SQL .= "'".$evstev."',";
                            $SQL .= "'',";
                            $SQL .= "1,";
                            $SQL .= $zapst.",";
                            $SQL .= $datum->format('Y').",";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'tajništvo',";
                            $SQL .= "'',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            switch ($doc){
                                case "1":
                                    $SQL .= "'Potrdilo o šolanju - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "2":
                                    $SQL .= "'Polletno obvestilo o ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "3":
                                    $SQL .= "'Obvestilo o zaključnih ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "4":
                                    $SQL .= "'Spričevalo o končanem razredu - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "5":
                                    $SQL .= "'Zaključno spričevalo - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "6":
                                    $SQL .= "'Obvestilo o dosežkih pri NPZ - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                            }
                            $SQL .= "'',";
                            $SQL .= "'',";
                            $SQL .= "'".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'T',";
                            $SQL .= "'',";
                            $SQL .= "'$VUporabnik',";
                            $SQL .= "'".$Danes->format('Y-m-d H:i:s')."'";
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }else{
                                echo "Ev. št. za ".$ucenec[$i][1].", ".$ucenec[$i][2]." je vpisana ($doc)!<br />";
                            }
                            $zapst += 1;
                        }
                    }
                }else{
                    echo "Vpis za preteklo šolsko leto ni več možen!<br />";
                }
                break;
            case "3": //izbrani razredi
                $evstev=$_POST["evstev"];
                $doc=$_POST["doc"];
                if (isDate($_POST["datum"])){
                    $datum=new DateTime(isDate($_POST["datum"]));
                }else{
                    $datum=new DateTime($Danes->format('Y-m-d'));
                }
                $razredi=Arr2Str($_POST["razredi"]);
                $zapst=1;
                $SQL = "SELECT zapst FROM tabdelovodnik WHERE oznaka='$evstev' AND leto=".$datum->format('Y')." ORDER BY zapst DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $zapst=$R["zapst"]+1;
                    }
                }
                
                $dovoljeno=true;
                if ($Danes->format('n') < 9){
                    if ($Danes->format('Y')-$VLetoSol > 1){
                        $dovoljeno=false;
                    }
                }else{
                    if ($Danes->format('Y')-$VLetoSol > 0){
                        $dovoljeno=false;
                    }
                }
                if ($dovoljeno){
                    switch ($doc){
                        case "4":
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabrazdat.id IN (".$razredi.") AND tabrazdat.razred < 9 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        case "5":   //zaključno spričevalo da le devetarjem
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabrazdat.id IN (".$razredi.") AND tabrazdat.razred > 8 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        default:
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabrazdat.id IN (".$razredi.") ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    }
                    $result = mysqli_query($link,$SQL);
                    $i=1;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenec[$i][0]=$R["iducenec"];
                        $ucenec[$i][1]=$R["ime"]." ".$R["priimek"];
                        $ucenec[$i][2]=$R["razred"].". ".$R["oznaka"];
                        $i += 1;
                    }
                    $stUcencev=$i-1;
                    for ($i=1;$i <= $stUcencev;$i++){
                        $SQL = "SELECT dokument,datum FROM tabevstevilkeu WHERE dokument=$doc AND leto=$VLetoSol AND iducenec=".$ucenec[$i][0];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "Podatki za ".$ucenec[$i][1].", ".$ucenec[$i][2]." so bili vpisani že: ".$R["datum"]." ($doc)<br />";
                        }else{
                            $SQL = "INSERT INTO tabevstevilkeu (iducenec,leto,evstev,datum,dokument) VALUES (";
                            $SQL .= $ucenec[$i][0].",";
                            $SQL .= $VLetoSol.",";
                            $SQL .= "'".$evstev."-".$zapst."/".$datum->format('Y')."-1',";
                            $SQL .= "'".$datum->format('Y-m-d')."',";
                            $SQL .= $doc;
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }

                            switch ($doc){
                                case "4":  //spričevalo za razred
                                case "5":  //zaključno spričevalo
                                    $SQL = "UPDATE tabrazred SET evidst='".$evstev."-".$zapst."/".$datum->format('Y')."-1',datumizdaje='".$datum->format('j.n.Y')."' WHERE iducenec=".$ucenec[$i][0]." AND leto=$VLetoSol";
                                    if (!($result = mysqli_query($link,$SQL))){
                                        die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                                    }
                                    break;
                            }
                            
                            $SQL = "INSERT INTO tabdelovodnik (oznaka,ref,doc,zapst,leto,datumprejema,vlozil,stvloge,datumvloge,zadeva,priloge,referenca,resitev,datumresitve,datumvlozitvearhiv,roki,arhpripombe,vpisal,cas) VALUES (";
                            $SQL .= "'".$evstev."',";
                            $SQL .= "'',";
                            $SQL .= "1,";
                            $SQL .= $zapst.",";
                            $SQL .= $datum->format('Y').",";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'tajništvo',";
                            $SQL .= "'',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            switch ($doc){
                                case "1":
                                    $SQL .= "'Potrdilo o šolanju - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "2":
                                    $SQL .= "'Polletno obvestilo o ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "3":
                                    $SQL .= "'Obvestilo o zaključnih ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "4":
                                    $SQL .= "'Spričevalo o končanem razredu - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "5":
                                    $SQL .= "'Zaključno spričevalo - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "6":
                                    $SQL .= "'Obvestilo o dosežkih pri NPZ - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                            }
                            $SQL .= "'',";
                            $SQL .= "'',";
                            $SQL .= "'".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'T',";
                            $SQL .= "'',";
                            $SQL .= "'$VUporabnik',";
                            $SQL .= "'".$Danes->format('Y-m-d H:i:s')."'";
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }else{
                                echo "Ev. št. za ".$ucenec[$i][1].", ".$ucenec[$i][2]." je vpisana ($doc)!<br />";
                            }
                            $zapst += 1;
                        }
                    }
                }else{
                    echo "Vpis za preteklo šolsko leto ni več možen!<br />";
                }
                break;
            case "4": //izbrani učenci
                $evstev=$_POST["evstev"];
                $doc=$_POST["doc"];
                if (isDate($_POST["datum"])){
                    $datum=new DateTime(isDate($_POST["datum"]));
                }else{
                    $datum=new DateTime($Danes->format('Y-m-d'));
                }
                $ucenci=Arr2Str($_POST["ucenci"]);
                $zapst=1;
                $SQL = "SELECT zapst FROM tabdelovodnik WHERE oznaka='$evstev' AND leto=".$datum->format('Y')." ORDER BY zapst DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $zapst=$R["zapst"]+1;
                    }
                }
                
                $dovoljeno=true;
                if ($Danes->format('n') < 9){
                    if ($Danes->format('Y')-$VLetoSol > 1){
                        $dovoljeno=false;
                    }
                }else{
                    if ($Danes->format('Y')-$VLetoSol > 0){
                        $dovoljeno=false;
                    }
                }
                if ($dovoljeno){
                    switch ($doc){
                        case "4":
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabucenci.iducenec IN (".$ucenci.") AND tabrazdat.razred > 0 AND tabrazdat.razred < 9 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        case "5":   //zaključno spričevalo da le devetarjem
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabucenci.iducenec IN (".$ucenci.") AND tabrazdat.razred > 8 ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                            break;
                        default:
                            $SQL = "SELECT tabrazred.iducenec,tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime FROM (tabrazred ";
                            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
                            $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec ";
                            $SQL .= "WHERE tabrazdat.leto=$VLetoSol AND tabucenci.iducenec IN (".$ucenci.") ORDER BY tabrazdat.razred,tabrazdat.oznaka,tabucenci.priimek,tabucenci.ime";
                    }
                    $result = mysqli_query($link,$SQL);
                    $i=1;
                    while ($R = mysqli_fetch_array($result)){
                        $ucenec[$i][0]=$R["iducenec"];
                        $ucenec[$i][1]=$R["ime"]." ".$R["priimek"];
                        $ucenec[$i][2]=$R["razred"].". ".$R["oznaka"];
                        $i += 1;
                    }
                    $stUcencev=$i-1;
                    for ($i=1;$i <= $stUcencev;$i++){
                        $SQL = "SELECT dokument,datum FROM tabevstevilkeu WHERE dokument=$doc AND leto=$VLetoSol AND iducenec=".$ucenec[$i][0];
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "Podatki za ".$ucenec[$i][1].", ".$ucenec[$i][2]." so bili vpisani že: ".$R["datum"]." ($doc)<br />";
                        }else{
                            $SQL = "INSERT INTO tabevstevilkeu (iducenec,leto,evstev,datum,dokument) VALUES (";
                            $SQL .= $ucenec[$i][0].",";
                            $SQL .= $VLetoSol.",";
                            $SQL .= "'".$evstev."-".$zapst."/".$datum->format('Y')."-1',";
                            $SQL .= "'".$datum->format('Y-m-d')."',";
                            $SQL .= $doc;
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }

                            switch ($doc){
                                case "4":  //spričevalo za razred
                                case "5":  //zaključno spričevalo
                                    $SQL = "UPDATE tabrazred SET evidst='".$evstev."-".$zapst."/".$datum->format('Y')."-1',datumizdaje='".$datum->format('j.n.Y')."' WHERE iducenec=".$ucenec[$i][0]." AND leto=$VLetoSol";
                                    if (!($result = mysqli_query($link,$SQL))){
                                        die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                                    }
                                    break;
                            }
                            
                            $SQL = "INSERT INTO tabdelovodnik (oznaka,ref,doc,zapst,leto,datumprejema,vlozil,stvloge,datumvloge,zadeva,priloge,referenca,resitev,datumresitve,datumvlozitvearhiv,roki,arhpripombe,vpisal,cas) VALUES (";
                            $SQL .= "'".$evstev."',";
                            $SQL .= "'',";
                            $SQL .= "1,";
                            $SQL .= $zapst.",";
                            $SQL .= $datum->format('Y').",";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'tajništvo',";
                            $SQL .= "'',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            switch ($doc){
                                case "1":
                                    $SQL .= "'Potrdilo o šolanju - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "2":
                                    $SQL .= "'Polletno obvestilo o ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "3":
                                    $SQL .= "'Obvestilo o zaključnih ocenah - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "4":
                                    $SQL .= "'Spričevalo o končanem razredu - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "5":
                                    $SQL .= "'Zaključno spričevalo - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                                case "6":
                                    $SQL .= "'Obvestilo o dosežkih pri NPZ - ".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                                    break;
                            }
                            $SQL .= "'',";
                            $SQL .= "'',";
                            $SQL .= "'".$ucenec[$i][1].", ".$ucenec[$i][2]."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'".$datum->format('j.n.Y')."',";
                            $SQL .= "'T',";
                            $SQL .= "'',";
                            $SQL .= "'$VUporabnik',";
                            $SQL .= "'".$Danes->format('Y-m-d H:i:s')."'";
                            $SQL .= ")";
                            if (!($result = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                            }else{
                                echo "Ev. št. za ".$ucenec[$i][1].", ".$ucenec[$i][2]." je vpisana ($doc)!<br />";
                            }
                            $zapst += 1;
                        }
                    }
                }else{
                    echo "Vpis za preteklo šolsko leto ni več možen!<br />";
                }
                break;
            case "5": //izbrani delavci
                $evstev=$_POST["evstev"];
                $doc=$_POST["doc"];
                if (isDate($_POST["datum"])){
                    $datum=new DateTime(isDate($_POST["datum"]));
                }else{
                    $datum=new DateTime($Danes->format('Y-m-d'));
                }
                $zapst=1;
                $SQL = "SELECT zapst FROM tabdelovodnik WHERE oznaka='$evstev' AND leto=".$datum->format('Y')." ORDER BY zapst DESC LIMIT 0,1";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    if ($R = mysqli_fetch_array($result)){
                        $zapst=$R["zapst"]+1;
                    }
                }
                
                $delavci="";
                for ($i=1;$i <= intval($_POST["stdelavcev"]);$i++){
                    if (isset($_POST["cbuc_$i"])){
                        if (strlen($delavci) > 0){
                            $delavci .= ",".$_POST["imeuc_$i"];
                        }else{
                            $delavci .= $_POST["imeuc_$i"];
                        }
                    }
                }
                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji ";
                $SQL .= "WHERE iducitelj IN (".$delavci.") ORDER BY priimek,ime";
                $result = mysqli_query($link,$SQL);
                $i=1;
                while ($R = mysqli_fetch_array($result)){
                    $ucenec[$i][0]=$R["iducitelj"];
                    $ucenec[$i][1]=$R["ime"]." ".$R["priimek"];
                    $i += 1;
                }
                $stDelavcev=$i-1;
                for ($i=1;$i <= $stDelavcev;$i++){
                    $SQL = "SELECT dokument FROM tabevstevilked WHERE dokument=$doc AND leto=$VLeto AND iducitelj=".$ucenec[$i][0];
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        echo "Podatki za ".$ucenec[$i][1]." so bili vpisani že: ".$R["datum"]." ($doc)<br />";
                    }else{
                        $SQL = "INSERT INTO tabevstevilked (iducitelj,leto,evstev,datum,dokument) VALUES (";
                        $SQL .= $ucenec[$i][0].",";
                        $SQL .= $VLeto.",";
                        $SQL .= "'".$evstev."-".$zapst."/".$datum->format('Y')."-1',";
                        $SQL .= "'".$datum->format('Y-m-d')."',";
                        $SQL .= $doc;
                        $SQL .= ")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                        }

                        $SQL = "INSERT INTO tabdelovodnik (oznaka,ref,doc,zapst,leto,datumprejema,vlozil,stvloge,datumvloge,zadeva,priloge,referenca,resitev,datumresitve,datumvlozitvearhiv,roki,arhpripombe,vpisal,cas) VALUES (";
                        $SQL .= "'".$evstev."',";
                        $SQL .= "'',";
                        $SQL .= "1,";
                        $SQL .= $zapst.",";
                        $SQL .= $datum->format('Y').",";
                        $SQL .= "'".$datum->format('j.n.Y')."',";
                        $SQL .= "'tajništvo',";
                        $SQL .= "'',";
                        $SQL .= "'".$datum->format('j.n.Y')."',";
                        switch ($doc){
                            case "1":
                                $SQL .= "'Odločba o dopustu - ".$ucenec[$i][1]."',";
                                break;
                            case "2":
                                $SQL .= "'Letna ocena delavca - ".$ucenec[$i][1]."',";
                                break;
                            case "3":
                                $SQL .= "'Obvestilo o napredovanju - ".$ucenec[$i][1]."',";
                                break;
                            case "4":
                                $SQL .= "'".$_POST["drugo"]." - ".$ucenec[$i][1]."',";
                                break;
                        }
                        $SQL .= "'',";
                        $SQL .= "'',";
                        $SQL .= "'".$ucenec[$i][1]."',";
                        $SQL .= "'".$datum->format('j.n.Y')."',";
                        $SQL .= "'".$datum->format('j.n.Y')."',";
                        $SQL .= "'10',";
                        $SQL .= "'',";
                        $SQL .= "'$VUporabnik',";
                        $SQL .= "'".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL .= ")";
                        if (!($result = mysqli_query($link,$SQL))){
                            die("Napaka pri vpisu ev. številk!<br />$SQL <br />");
                        }else{
                            echo "Ev. št. za ".$ucenec[$i][1]." je vpisana ($doc)!<br />";
                        }
                        $zapst += 1;
                    }
                }
                break;
            default:
                echo "<br />";
                echo "<form name='evstevilke' method='post' action='delovodnik.php'>";
                echo "Izberite vnos evidenčnih številk skupinam ali posameznikom:<br />";
                echo "<input name='skupina' type='radio' value='1' checked='checked'>Vsi učenci<br />";
                echo "<input name='skupina' type='radio' value='2'>Določeni razredi<br />";
                echo "<input name='skupina' type='radio' value='3'>Določeni učenci<br />";
                echo "<input name='skupina' type='radio' value='4'>Določeni zaposleni<br />";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "<input name='tip' type='hidden' value='1'>";
                echo "<input name='id' type='hidden' value='10'>";
                echo "</form>";
        }
        echo "<a href='delovodnik.php?id=1'>Na vnos delovodnika</a><br />";
        echo "</body>";
        echo "</html>";
        break;
    case "11":
        echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
        echo "<meta http-equiv='pragma' content='no-cache' > ";
        echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
        echo "<title>Delovodnik";
        echo "</title>";
        echo "<style type='text/css'>";
        echo ".break { page-break-before: always; }";
        echo "input.groovybutton";
        echo "{";
        echo "   font-size:8px;";
        echo "   font-weight:bold;";
        echo "   width:18px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";
        include('menu_func.inc');
        include ('menu.inc');
        echo "<br />";
        $SQL = "SELECT tabucenci.priimek,tabucenci.ime,tabrazdat.razred,tabrazdat.oznaka,tabevstevilkeu.evstev,tabevstevilkeu.datum,tabevstevilkeu.dokument FROM ((tabevstevilkeu ";
        $SQL .= "INNER JOIN tabucenci ON tabevstevilkeu.iducenec=tabucenci.iducenec) ";
        $SQL .= "INNER JOIN tabrazred ON tabevstevilkeu.iducenec=tabrazred.iducenec)";
        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
        $SQL .= "WHERE tabrazred.leto=$VLetoSol AND tabevstevilkeu.leto=$VLetoSol ";
        $SQL .= "ORDER BY tabevstevilkeu.id";
        $result = mysqli_query($link,$SQL);
        $i=1;
        echo "<table>";
        echo "<tr><th>Ev. štev.</th><th>datum</th><th>Ime</th><th>dokument</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["evstev"]."</td>";
            $datum=new DateTime($R["datum"]);
            echo "<td>".$datum->format('j.n.Y')."</td>";
            echo "<td>".$R["ime"]." ".$R["priimek"].", ".$R["razred"].". ".$R["oznaka"]."</td>";
            switch ($R["dokument"]){
                case "1":
                    echo "<td>Potrdilo o šolanju</td>";
                    break;
                case "2":
                    echo "<td>Polletno obvestilo o ocenah</td>";
                    break;
                case "3":
                    echo "<td>Obvestilo o zaključnih ocenah</td>";
                    break;
                case "4":
                    echo "<td>Spričevalo o končanem razredu</td>";
                    break;
                case "5":
                    echo "<td>Zaključno spričevalo</td>";
                    break;
                case "6":
                    echo "<td>Obvestilo o dosežkih pri NPZ</td>";
                    break;
            }
            echo "</tr>";
        }
        echo "</table><br />";
        echo "<br />";
        $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabevstevilked.evstev,tabevstevilked.datum,tabevstevilked.dokument FROM (tabevstevilked ";
        $SQL .= "INNER JOIN tabucitelji ON tabevstevilked.iducitelj=tabucitelji.iducitelj) ";
        $SQL .= "WHERE tabevstevilked.leto=$VLeto ";
        $SQL .= "ORDER BY tabevstevilked.id";
        $result = mysqli_query($link,$SQL);
        $i=1;
        echo "<table>";
        echo "<tr><th>Ev. štev.</th><th>datum</th><th>Ime</th><th>dokument</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$R["evstev"]."</td>";
            $datum=new DateTime($R["datum"]);
            echo "<td>".$datum->format('j.n.Y')."</td>";
            echo "<td>".$R["ime"]." ".$R["priimek"]."</td>";
            switch ($R["dokument"]){
                case "1":
                    echo "<td>Odločba o dopustu</td>";
                    break;
                case "2":
                    echo "<td>Letna ocena delavca</td>";
                    break;
            }
            echo "</tr>";
        }
        echo "</table><br />";
        echo "</body>";
        echo "</html>";
        break;
}

?>