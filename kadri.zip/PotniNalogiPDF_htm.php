<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<title>Potni nalog
</title>
<style type="text/css">
TABLE
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 0px;
    BACKGROUND-COLOR: white;
    border-spacing: 2;
}
TABLE.obracun
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 1px;
    BACKGROUND-COLOR: white;
    border-spacing: 0;
    border-collapse: collapse
}
TABLE.sivina
{
    FONT-SIZE: 12pt;
    FONT-FAMILY: Verdana;
    BORDER: 1px;
    BACKGROUND-COLOR: lightgrey;
    border-spacing: 0;
    border-collapse: collapse
}
TD
{
    BORDER: black solid 0px;
    border-spacing: 0;
}
TD.obracun
{
    BORDER: black solid 1px;
    border-spacing: 0;
    border-collapse: collapse
}
TD.sivina
{
    BORDER: black solid 0px;
    border-spacing: 0;
    border-collapse: collapse
}
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
/*
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VNaslov=$R["Naslov"];
    $VPosta=$R["Posta"]." ".$R["Kraj"];
    $VRavnatelj=$R["Ravnatelj"];
    $VKraj=$R["Kraj"];
}else{
    $VSola=" ";
    $VNaslov=" ";
    $VPosta=" ";
    $VRavnatelj=" ";
    $VKraj=" ";
}

if (isset($_GET["spisek"])){
    $VSpisek=$_GET["spisek"];
}else{
    $VSpisek="";
}
if (isset($_POST["StZapisov"])){
    $StZapisov=$_POST["StZapisov"];
}else{
    $StZapisov=0;
}

if ($VSpisek == ""){
    for ($Indx=1;$Indx <= $StZapisov;$Indx++){
        if (isset($_POST["pn".$Indx])){
            if (strlen($VSpisek)==0){
                $VSpisek=$_POST["idpn".$Indx];
            }else{
                $VSpisek=$VSpisek.",".$_POST["idpn".$Indx];
            }
        }
    }
}

$SQL = "SELECT * FROM TabPotniNalog ";
$SQL = $SQL . "WHERE TabpotniNalog.id IN (".$VSpisek.") ";
$SQL = $SQL . " ORDER BY ZapSt";
$result = mysqli_query($link,$SQL);

$IndxPN=0;
while ($R = mysqli_fetch_array($result)){
    $IndxPN=$IndxPN+1;
    $oUcitelj=new RUcitelj();
    $oUcitelj->PreberiSeGlavno($R["idUcitelj"],$VLeto,$VLeto);
    if ($IndxPN > 1){
        echo "<p class='break'></p>";
    }
    echo "<table border='0' width='1000'>";
    echo "<tr>";
    echo "<td><a href='prijava.php'><img src='logo.gif' width='200' border='0'></a></td>";
    echo "<td width='350'><span style='font-size:large;font-weight:bold'>".$VSola."<br />".$VNaslov."<br />".$VPosta."</span></td>";
    $Datum=new DateTime($R["Datum"]);
    echo "<td class='obracun' width='450'><span style='font-size:x-large;font-weight:bold'>NALOG<br />za službeno potovanje<br />Št. ".$R["ZapSt"]."<br />Datum: ".$Datum->format('d.m.Y')."</span></td>";
    echo "</tr>";
    echo "</table>";

    echo "<table border='0'>";
    echo "    <tr>";
    echo "        <td width='250'>Odrejam, da odpotuje</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Na delovnem mestu</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$oUcitelj->getDelMesto()."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Stanujoč</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>dne</td>";
    $Datum=new DateTime($R["DanOdhoda"]." ".$R["UraOdhoda"]);
    echo "        <td width='250' colspan='2' style='font-size:medium;font-weight:bold'>".$Datum->format('d.m.Y')."</td>";
    echo "        <td width='250'>ob <span style='font-size:medium;font-weight:bold'>".$Datum->format('H:i')."</span> uri</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>po nalogu</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$R["Odlocba"]."</td>";
    echo "    </tr>";
    echo "    <tr>   ";
    echo "        <td width='250'>v/na</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$R["Kam"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>z nalogo</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$R["Naloga"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Potovanje bo trajalo do</td>";
    $Datum=new DateTime($R["DanPrihoda"]);
    echo "        <td colspan='2' style='font-size:medium;font-weight:bold'>".$Datum->format('d.m.Y')."</td>";
    echo "        <td width='250'>to je <span style='font-size:medium;font-weight:bold'>".$R["Dni"]."</span> dni</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Odobravam uporabo (avtomobila, letala, itd...)</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$R["PrevSredstvo"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Potne stroške plača</td>";
    echo "        <td colspan='3' style='font-size:medium;font-weight:bold'>".$R["Placnik"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Višina dnevnice EUR</td>";
    echo "        <td width='250' style='font-size:medium;font-weight:bold'><b>".$R["Dnevnica"]."</b></td>";
    echo "        <td width='250'>Posebni dodatki EUR</td>";
    echo "        <td width='250' style='font-size:medium;font-weight:bold'><b>".$R["Dodatki"]."</b></td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td colspan='2'>Odobravam izplačilo predujma v znesku EUR</td>";
    echo "        <td colspan='2' style='font-size:medium;font-weight:bold'>".$R["Predujem"]."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250' height='50'>&nbsp;</td>";
    echo "        <td width='250'>&nbsp;</td>";
    echo "        <td width='250'>M.P.</td>";
    echo "        <td width='250'><span style='font-size:medium;font-weight:bold'>".$R["Odredbodajalec"]."</span><br /><span style='font-size:x-small'>Podpis odredbodajalca</span></td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td colspan='4' height='60'>&nbsp;</td>";
    echo "    </tr>";
    echo "</table>";

    echo "<table class='obracun' width='500'>";
    echo "    <tr>";
    echo "        <td class='obracun'><span style='font-size:xx-large;font-weight:bold'>OBRAČUN <br />potnih stroškov</span></td>";
    echo "    </tr>";
    echo "</table>";
    echo "<table>";
    echo "    <tr>";
    echo "        <td width='250'>Ime in priimek predlagatelja</td>";
    echo "        <td width='750' style='font-size:medium;font-weight:bold'>".$oUcitelj->getIme()." ".$oUcitelj->getPriimek()."</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>Prebivališče</td>";
    echo "        <td width='750' style='font-size:medium;font-weight:bold'>".$oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj()."</td>";
    echo "    </tr>";
    echo "</table>";
    echo "<table class='sivina'>";
    echo "    <tr>";
    echo "        <td class='sivina' width='250'>Datum odhoda</td>";
    if (isset($R["DanOdhodaObr"])){
        $Datum=new DateTime($R["DanOdhodaObr"]." ".$R["UraOdhodaObr"]);
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>".$Datum->format('d.m.Y')." ob ".$Datum->format('H:i')."</span></td>";
    }else{
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>______________ ob _______________</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td class='sivina' width='250'>Datum vrnitve</td>";
    if (isset($R["DanPrihodaObr"])){
        $Datum=new DateTime($R["DanPrihodaObr"]." ".$R["UraPrihodaObr"]);
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>".$Datum->format('d.m.Y')." ob ".$Datum->format('H:i')."</span></td>";
    }else{
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>______________ ob _______________</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td class='sivina' width='250'>Odsotnost:</td>";
    if (isset($R["DanOdhodaObr"])){
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>".$R["DniObr"]." dni, ".$R["UrObr"]." ur, ".$R["MinObr"]." min.</span></td>";
    }else{
        echo "        <td class='sivina' width='750'><span style='font-size:medium;font-weight:bold'>___________ dni, ___________ ur, __________ min.</span></td>";
    }
    echo "    </tr>";
    echo "</table>";
    
    if (isset($R["Dnevnic"])){
        $Dnevnic=$R["Dnevnic"];
    }else{
        $Dnevnic=0;
    }
    if (isset($R["Dnevnica"])){
        $Dnevnica=$R["Dnevnica"];
    }else{
        $Dnevnica=0;
    }
    if (isset($R["ProcentZnizanja"])){
        $ProcentZnizanja=$R["ProcentZnizanja"];
    }else{
        $ProcentZnizanja=0;
    }
    if (isset($R["ZnizanjeOd"])){
        $ZnizanjeOd=$R["ZnizanjeOd"];
    }else{
        $ZnizanjeOd=0;
    }
    if (isset($R["PrevStroski1"])){
        $PrevStroski1=$R["PrevStroski1"];
    }else{
        $PrevStroski1=0;
    }
    if (isset($R["PrevStroski2"])){
        $PrevStroski2=$R["PrevStroski2"];
    }else{
        $PrevStroski2=0;
    }
    if (isset($R["PrevStroski3"])){
        $PrevStroski3=$R["PrevStroski3"];
    }else{
        $PrevStroski3=0;
    }
    if (isset($R["PrevStroski4"])){
        $PrevStroski4=$R["PrevStroski4"];
    }else{
        $PrevStroski4=0;
    }
    if (isset($R["DrugiStroski1"])){
        $DrugiStroski1=$R["DrugiStroski1"];
    }else{
        $DrugiStroski1=0;
    }
    if (isset($R["DrugiStroski2"])){
        $DrugiStroski2=$R["DrugiStroski2"];
    }else{
        $DrugiStroski2=0;
    }
    if (isset($R["PrevStroskiTxt1"])){
        $PrevStroskiTxt1=$R["PrevStroskiTxt1"];
    }else{
        $PrevStroskiTxt1="";
    }
    if (isset($R["PrevStroskiTxt2"])){
        $PrevStroskiTxt2=$R["PrevStroskiTxt2"];
    }else{
        $PrevStroskiTxt2="";
    }
    if (isset($R["PrevStroskiTxt3"])){
        $PrevStroskiTxt3=$R["PrevStroskiTxt3"];
    }else{
        $PrevStroskiTxt3="";
    }
    if (isset($R["PrevStroskiTxt4"])){
        $PrevStroskiTxt4=$R["PrevStroskiTxt4"];
    }else{
        $PrevStroskiTxt4="";
    }
    if (isset($R["DrugiStroskiTxt1"])){
        $DrugiStroskiTxt1=$R["DrugiStroskiTxt1"];
    }else{
        $DrugiStroskiTxt1="";
    }
    if (isset($R["DrugiStroskiTxt2"])){
        $DrugiStroskiTxt2=$R["DrugiStroskiTxt2"];
    }else{
        $DrugiStroskiTxt2="";
    }
    if (isset($R["Priloge"])){
        $Priloge=$R["Priloge"];
    }else{
        $Priloge="";
    }
    if (isset($R["Predujem"])){
        $Predujem=$R["Predujem"];
    }else{
        $Predujem=0;
    }
    if (isset($R["ZnizanjeOd"])){
        $ZnizanjeOd=$R["ZnizanjeOd"];
    }else{
        $ZnizanjeOd=0;
    }
    if (isset($R["ProcentZnizanja"])){
        $ProcentZnizanja=$R["ProcentZnizanja"];
    }else{
        $ProcentZnizanja=0;
    }
    if (isset($R["OdobrenoIzpl"])){
        $OdobrenoIzpl=$R["OdobrenoIzpl"];
    }else{
        $OdobrenoIzpl=0;
    }
    if (isset($R["Placnik"])){
        $Placnik=$R["Placnik"];
    }else{
        $Placnik="";
    }
    $Znesek[1]=$Dnevnic*$Dnevnica;
    $Znesek[2]=$ProcentZnizanja/100*$ZnizanjeOd;
    $Znesek[3]=$Znesek[1]+$Znesek[2];
    $Znesek[4]=$Znesek[3]+$PrevStroski1+$PrevStroski2+$PrevStroski3+$PrevStroski4+$DrugiStroski1+$DrugiStroski2;
    $Znesek[5]=$Znesek[4]-$Predujem;
    
    echo "<table class='obracun'>";
    echo "    <tr>";
    if ($Dnevnic > 0){
        echo "        <td class='obracun' width='750'>Število dnevnic: ".$Dnevnic." po ".$Dnevnica." EUR</td>";
    }else{
        echo "        <td class='obracun' width='750'>Število dnevnic: __________ po ____________ EUR</td>";
    }
    if ($Znesek[1] > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Znesek[1],2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($ProcentZnizanja != 0){
        echo "        <td class='obracun' width='750'>".$ProcentZnizanja." % zvišanja/nižanja dnevnic od EUR ".$ZnizanjeOd."</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Znesek[2],2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='750'>&nbsp;</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td class='obracun' width='750' align='right'>Skupaj</td>";
    if ($Znesek[3] > 0){
        echo "       <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Znesek[3],2)."</span></td>";
    }else{
        echo "       <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
        
    echo "    <tr>";
    if ($PrevStroskiTxt1 != ""){
        echo "        <td class='obracun' width='750'>Prevozni stroški ".$PrevStroskiTxt1."</td>";
    }else{
        echo "        <td class='obracun' width='750'>Prevozni stroški</td>";
    }
    if ($PrevStroski1 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($PrevStroski1,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($PrevStroskiTxt2 != ""){
        echo "        <td class='obracun' width='750'>".$PrevStroskiTxt2."</td>";
    }else{
        echo "        <td class='obracun' width='750'>&nbsp;</td>";
    }
    if ($PrevStroski2 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($PrevStroski2,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($PrevStroskiTxt3 != ""){
        echo "        <td class='obracun' width='750'>".$PrevStroskiTxt3."</td>";
    }else{
        echo "        <td class='obracun' width='750'>&nbsp;</td>";
    }
    if ($PrevStroski3 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($PrevStroski3,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($PrevStroskiTxt4 != ""){
        echo "        <td class='obracun' width='750'>".$PrevStroskiTxt4."</td>";
    }else{
        echo "        <td class='obracun' width='750' align='center'></td>";
    }
    if ($PrevStroski4 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($PrevStroski4,2)."</span></td>";
    }else{
        echo "       <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
        
    echo "    <tr>";
    if ($DrugiStroskiTxt1 != ""){
        echo "        <td class='obracun' width='750'>Drugi stroški: ".$DrugiStroskiTxt1."</td>";
    }else{
        echo "        <td class='obracun' width='750'>Drugi stroški</td>";
    }
    if ($DrugiStroski1 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($DrugiStroski1,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($DrugiStroskiTxt2 != ""){
        echo "        <td class='obracun' width='750'>".$DrugiStroskiTxt2."</td>";
    }else{
        echo "        <td class='obracun' width='750'>&nbsp;</td>";
    }
    if ($DrugiStroski2 > 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($DrugiStroski2,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td class='obracun' width='750' align='right'>Skupaj</td>";
    if ($Znesek[4] != 0){
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Znesek[4],2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
        
    echo "    <tr>";
    if ($Predujem > 0){
        $Datum=new DateTime($R["Datum"]);
        echo "        <td class='obracun' width='750'>Predujem prejet dne <b>".$Datum->format('d.m.Y')."</b> v znesku</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Predujem,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='750'>Predujem prejet dne <b>&nbsp</b> v znesku</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>&nbsp;</span></td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    if ($Znesek[5] >= 0){
        echo "        <td class='obracun' width='750' align='right'>Ostane za izplačilo EUR</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($Znesek[5],2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='750' align='right'>Ostane za vračilo EUR</td>";
        echo "        <td class='obracun' width='250' align='right'><span style='font-size:medium;font-weight:bold'>".number_format(abs($Znesek[5]),2)."</span></td>";
    }
    echo "    </tr>";
        
    echo "    <tr>";
    if (strlen($Priloge) > 0){
        echo "       <td class='obracun' colspan='2'>Priloge: ".$Priloge."</td>";
    }else{
        echo "       <td class='obracun' colspan='2'>Priloge</td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td class='obracun' width='750' height='60' valign='bottom'>V ________________, dne _________________</td>";
    echo "        <td class='obracun' width='250' align='right' valign='bottom'>_______________________<br/><span style='font-size:x-small;'>Predlagatelj računa</span></td>";
    echo "    </tr>";
    echo "</table>";
    echo "<table>";
    echo "    <tr>";
    echo "        <td colspan='3'>Račun pregledal in odobril izplačilo EUR</td>";
    if ($OdobrenoIzpl > 0){
        echo "        <td class='obracun' width='250' height='60' align='right'><span style='font-size:medium;font-weight:bold'>".number_format($OdobrenoIzpl,2)."</span></td>";
    }else{
        echo "        <td class='obracun' width='250' height='60'>&nbsp;</td>";
    }
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250'>v breme</td>";
    echo "        <td colspan='2'><span style='font-size:medium;font-weight:bold'>".$Placnik."</span></td>";
    echo "        <td width='250'>&nbsp;</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250' height='60'>________________<br /><span style='font-size:x-small;'>Likvidator</span></td>";
    echo "        <td width='240'>________________<br /><span style='font-size:x-small;'>Odredbodajalec</span></td>";
    echo "        <td width='250' align='right'>Izplačano EUR</td>";
    echo "        <td class='obracun' width='250'>&nbsp;</td>";
    echo "    </tr>";
    echo "    <tr>";
    echo "        <td width='250' height='60'>________________ M.P.<br /><span style='font-size:x-small;'>Za blagajno (žig in podpis)</span></td>";
    echo "        <td colspan='2' align='center'>_________________<br /><span style='font-size:x-small;'>datum</span></td>";
    echo "        <td width='250'>_____________________<br /><span style='font-size:x-small;'>Podpis prejemnika</span></td>";
    echo "    </tr>";
    echo "</table>";
    
}

?>