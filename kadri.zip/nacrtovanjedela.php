<?php
require ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Načrtovanje dela
</title>
</head>
<body>
<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
//    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
//echo "<a href='IzborUcitelja.php'>Izbor učitelja</a><br />";
echo "<br />";

if (!CheckDostop("VnosSist",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = 0;
        }
    }
    switch ($Vid){
        case "1": //izpis predmetnika
            echo "<h2>Predmetnik osnovne šole za šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";
            $SQL = "SELECT * FROM tabpredmetnik ";
            $SQL .= "WHERE leto=$VLeto AND tip=0 ORDER BY razred,vrstnired"; //običajna šola
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $predmetnik[$R["razred"]][$R["predmet"]] = $R["ur"];
            }
            for ($i=1;$i <= 9;$i++){
                $stur[$i]=0;
                $stpredmetov[$i]=0;
            }
            echo "<table>";
            echo "<tr><th>Predmeti</th><th colspan='9'>Število ur na teden</th></tr>";
            echo "<tr><th>&nbsp;</th>";
            for ($i=1;$i <= 9;$i++){
                echo "<th>$i</th>";
            }
            echo "</tr>";
            echo "<tr><th colspan='10'>A - Obvezni program</th></tr>";
            echo "<tr><td>Slovenščina</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["SLJ9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["SLJ9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["SLJ9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Matematika</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["MAT9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["MAT9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["MAT9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";

            echo "<tr><td>Angleščina</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["TJA9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["TJA9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["TJA9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Likovna umetnost</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["LUM9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["LUM9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["LUM9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Glasbena umetnost</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["GUM9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["GUM9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["GUM9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Družba</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["DRU9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["DRU9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["DRU9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Geografija</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["GEO9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["GEO9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["GEO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Zgodovina</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["ZGO9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["ZGO9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["ZGO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Domovinska in drž.<br />kultura in etika</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["DKE9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["DKE9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["DKE9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Spoznavanje okolja</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["SPO9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["SPO9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["SPO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Fizika</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["FIZ9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["FIZ9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["ZGO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Kemija</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["KEM9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["KEM9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["KEM9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Biologija</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["BIO9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["BIO9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["BIO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Naravoslovje</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["NAR9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["NAR9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["NAR9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Naravoslovje in tehnika</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["NIT9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["NIT9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["NIT9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Tehnika in tehnologija</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["TIT9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["TIT9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["TIT9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Gospodinjstvo</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["GOS9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["GOS9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["GOS9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Šport</td>";
            for ($i=1;$i <= 9;$i++){
                if (isset($predmetnik[$i]["ŠPO9o"])){
                    echo "<td align='center'>".$predmetnik[$i]["ŠPO9o"]."</td>";
                    $stur[$i] += $predmetnik[$i]["ŠPO9o"];
                    $stpredmetov[$i]++;
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }
            echo "</tr>";
            
            echo "<tr><td>Izbirni predmeti</td>";
            for ($i=1;$i <= 6;$i++){
                echo "<td>&nbsp;</td>";
            }
            for ($i=7;$i <= 9;$i++){
                echo "<td align='center'>2/3</td>";
                $stur[$i] += 2;
                $stpredmetov[$i]++;
            }
            echo "</tr>";
            
            echo "<tr><td>Neobvezni izbirni predmeti</td>";
            if ($VLeto == 2014){
                echo "<td align='center'>&nbsp;</td><td align='center'>&nbsp;</td><td align='center'>&nbsp;</td>";
                echo "<td align='center'>0/1/2</td><td align='center'>&nbsp;</td><td align='center'>&nbsp;</td>";
                echo "<td align='center'>0/2</td><td align='center'>&nbsp;</td><td align='center'>&nbsp;</td>";
            }
            if ($VLeto == 2015){
                echo "<td align='center'>0/2</td><td align='center'>&nbsp;</td><td align='center'>&nbsp;</td>";
                echo "<td align='center'>0/1/2</td><td align='center'>0/1/2</td><td align='center'>&nbsp;</td>";
                echo "<td align='center'>0/2</td><td align='center'>0/2</td><td align='center'>&nbsp;</td>";
            }
            if ($VLeto == 2016){
                echo "<td>0/2</td><td>0/2</td><td>&nbsp;</td>";
                echo "<td>0/1/2</td><td>0/1/2</td><td>0/1/2</td>";
                echo "<td>0/2</td><td>0/2</td><td>0/2</td>";
            }
            if ($VLeto >= 2017){
                echo "<td align='center'>0/2</td><td align='center'>0/2</td><td align='center'>0/2</td>";
                echo "<td align='center'>0/1/2</td><td align='center'>0/1/2</td><td align='center'>0/1/2</td>";
                echo "<td align='center'>0/2</td><td align='center'>0/2</td><td align='center'>0/2</td>";
            }
            echo "</tr>";

            echo "<tr><td>Oddelčna skupnost</td>";
            echo "<td align='center'>&nbsp;</td><td align='center'>&nbsp;</td><td align='center'>&nbsp;</td>";
            echo "<td align='center'>0.5</td><td align='center'>0.5</td><td align='center'>0.5</td>";
            echo "<td align='center'>0.5</td><td align='center'>0.5</td><td align='center'>0.5</td>";
            echo "</tr>";
            
            echo "<tr><td>Število predmetov</td>";
            if ($VLeto == 2014){
                echo "<td align='center'>".$stpredmetov[1]."</td><td align='center'>".$stpredmetov[2]."</td><td align='center'>".$stpredmetov[3]."</td>";
                echo "<td align='center'>".$stpredmetov[4]."-".($stpredmetov[4]+1)."</td><td align='center'>".$stpredmetov[5]."</td><td align='center'>".$stpredmetov[6]."</td>";
                echo "<td align='center'>".$stpredmetov[7]."-".($stpredmetov[7]+3)."</td><td align='center'>".$stpredmetov[8]."-".($stpredmetov[8]+2)."</td><td align='center'>".$stpredmetov[9]."-".($stpredmetov[9]+2)."</td>";
            }
            if ($VLeto == 2015){
                echo "<td align='center'>".$stpredmetov[1]."-".($stpredmetov[1]+1)."</td><td align='center'>".$stpredmetov[2]."</td><td align='center'>".$stpredmetov[3]."</td>";
                echo "<td align='center'>".$stpredmetov[4]."-".($stpredmetov[4]+1)."</td><td align='center'>".$stpredmetov[5]."-".($stpredmetov[5]+1)."</td><td align='center'>".$stpredmetov[6]."</td>";
                echo "<td align='center'>".$stpredmetov[7]."-".($stpredmetov[7]+3)."</td><td align='center'>".$stpredmetov[8]."-".($stpredmetov[8]+3)."</td><td align='center'>".$stpredmetov[9]."-".($stpredmetov[9]+2)."</td>";
            }
            if ($VLeto == 2016){
                echo "<td align='center'>".$stpredmetov[1]."-".($stpredmetov[1]+1)."</td><td align='center'>".$stpredmetov[2]."-".($stpredmetov[2]+1)."</td><td align='center'>".$stpredmetov[3]."</td>";
                echo "<td align='center'>".$stpredmetov[4]."-".($stpredmetov[4]+1)."</td><td align='center'>".$stpredmetov[5]."-".($stpredmetov[5]+1)."</td><td align='center'>".$stpredmetov[6]."-".($stpredmetov[6]+1)."</td>";
                echo "<td align='center'>".$stpredmetov[7]."-".($stpredmetov[7]+3)."</td><td align='center'>".$stpredmetov[8]."-".($stpredmetov[8]+3)."</td><td align='center'>".$stpredmetov[9]."-".($stpredmetov[9]+3)."</td>";
            }
            if ($VLeto >= 2017){
                echo "<td align='center'>".$stpredmetov[1]."-".($stpredmetov[1]+1)."</td><td align='center'>".$stpredmetov[2]."-".($stpredmetov[2]+1)."</td><td align='center'>".$stpredmetov[3]."-".($stpredmetov[3]+1)."</td>";
                echo "<td align='center'>".$stpredmetov[4]."-".($stpredmetov[4]+1)."</td><td align='center'>".$stpredmetov[5]."-".($stpredmetov[5]+1)."</td><td align='center'>".$stpredmetov[6]."-".($stpredmetov[6]+1)."</td>";
                echo "<td align='center'>".$stpredmetov[7]."-".($stpredmetov[7]+3)."</td><td align='center'>".$stpredmetov[8]."-".($stpredmetov[8]+3)."</td><td align='center'>".$stpredmetov[9]."-".($stpredmetov[9]+3)."</td>";
            }
            echo "</tr>";
            echo "<tr><td>Število ur tedensko</td>";
            if ($VLeto == 2014){
                echo "<td align='center'>".$stur[1]."</td><td align='center'>".$stur[2]."</td><td align='center'>".$stur[3]."</td>";
                echo "<td align='center'>".$stur[4]."-".($stur[4]+2)."</td><td align='center'>".$stur[5]."</td><td align='center'>".$stur[6]."</td>";
                echo "<td align='center'>".$stur[7]."-".($stur[7]+3)."</td><td align='center'>".$stur[8]."-".($stur[8]+2)."</td><td align='center'>".$stur[9]."-".($stur[9]+2)."</td>";
            }
            if ($VLeto == 2015){
                echo "<td align='center'>".$stur[1]."-".($stur[1]+2)."</td><td align='center'>".$stur[2]."</td><td align='center'>".$stur[3]."</td>";
                echo "<td align='center'>".$stur[4]."-".($stur[4]+2)."</td><td align='center'>".$stur[5]."-".($stur[5]+2)."</td><td align='center'>".$stur[6]."</td>";
                echo "<td align='center'>".$stur[7]."-".($stur[7]+3)."</td><td align='center'>".$stur[8]."-".($stur[8]+3)."</td><td align='center'>".$stur[9]."-".($stur[9]+2)."</td>";
            }
            if ($VLeto == 2016){
                echo "<td align='center'>".$stur[1]."-".($stur[1]+2)."</td><td align='center'>".$stur[2]."-".($stur[2]+2)."</td><td align='center'>".$stur[3]."</td>";
                echo "<td align='center'>".$stur[4]."-".($stur[4]+2)."</td><td align='center'>".$stur[5]."-".($stur[5]+2)."</td><td align='center'>".$stur[6]."-".($stur[6]+2)."</td>";
                echo "<td align='center'>".$stur[7]."-".($stur[7]+3)."</td><td align='center'>".$stur[8]."-".($stur[8]+3)."</td><td align='center'>".$stur[9]."-".($stur[9]+3)."</td>";
            }
            if ($VLeto >= 2017){
                echo "<td align='center'>".$stur[1]."-".($stur[1]+2)."</td><td align='center'>".$stur[2]."-".($stur[2]+2)."</td><td align='center'>".$stur[3]."-".($stur[3]+2)."</td>";
                echo "<td align='center'>".$stur[4]."-".($stur[4]+2)."</td><td align='center'>".$stur[5]."-".($stur[5]+2)."</td><td align='center'>".$stur[6]."-".($stur[6]+2)."</td>";
                echo "<td align='center'>".$stur[7]."-".($stur[7]+3)."</td><td align='center'>".$stur[8]."-".($stur[8]+3)."</td><td align='center'>".$stur[9]."-".($stur[9]+3)."</td>";
            }
            echo "</tr>";

            echo "<tr><td>Št. tednov pouka</td>";
            echo "<td align='center'>35</td><td align='center'>35</td><td align='center'>35</td>";
            echo "<td align='center'>35</td><td align='center'>35</td><td align='center'>35</td>";
            echo "<td align='center'>35</td><td align='center'>35</td><td align='center'>32</td>";
            echo "</tr>";

            echo "<tr><th colspan='10'>Dnevi dejavnosti</th></tr>";
            echo "<tr><td>Kulturni dnevi</td>";
            echo "<td align='center'>4</td><td align='center'>4</td><td align='center'>4</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "</tr>";
            echo "<tr><td>Naravoslovni dnevi</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "</tr>";
            echo "<tr><td>Tehniški dnevi</td>";
            echo "<td align='center'>3</td><td align='center'>3</td><td align='center'>3</td>";
            echo "<td align='center'>4</td><td align='center'>4</td><td align='center'>4</td>";
            echo "<td align='center'>4</td><td align='center'>4</td><td align='center'>4</td>";
            echo "</tr>";
            echo "<tr><td>Športni dnevi</td>";
            echo "<td align='center'>5</td><td align='center'>5</td><td align='center'>5</td>";
            echo "<td align='center'>5</td><td align='center'>5</td><td align='center'>5</td>";
            echo "<td align='center'>5</td><td align='center'>5</td><td align='center'>5</td>";
            echo "</tr>";
            
            echo "<tr><th colspan='10'>B - razširjeni program</th></tr>";
            echo "<tr><td>Učna pomoč</td>";
            for ($i=1;$i <= 9;$i++){
                echo "<td align='center'>0.5</td>";
            }
            echo "</tr>";
            echo "<tr><td>Dod. in dop. pouk</td>";
            for ($i=1;$i <= 9;$i++){
                echo "<td align='center'>1</td>";
            }
            echo "</tr>";
            echo "<tr><td>Interesne dej.</td>";
            for ($i=1;$i <= 9;$i++){
                echo "<td align='center'>2</td>";
            }
            echo "</tr>";
            echo "<tr><th colspan='10'>Podaljšano bivanje, jutranje varstvo, šola v naravi.</th></tr>";
            
            echo "</table><br /><br />";
            
            //normativi
            $SQL = "SELECT id FROM tabrazdat WHERE leto=$VLeto AND razred > 0";
            $result = mysqli_query($link,$SQL);
            $strazr=mysqli_num_rows($result);
            if ($strazr > 0){
                echo "<h3>Sistemizirana delovna mesta in število skupin</h3>";
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabrazred.razred > 0";
                $result = mysqli_query($link,$SQL);
                $stucencev=mysqli_num_rows($result);
                //echo "Število učencev: ".$stucencev."<br />";
                
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabrazred.razred > 6";
                $result = mysqli_query($link,$SQL);
                $stucencev79=mysqli_num_rows($result);
                //echo "Število učencev 7.-9.r: ".$stucencev79."<br />";
                
                $SQL = "SELECT id FROM tabrazdat WHERE leto=$VLeto AND razred > 0";
                $result = mysqli_query($link,$SQL);
                $stoddelkov=mysqli_num_rows($result);
                //echo "Število oddelkov: ".$stoddelkov."<br />";
                
                //svetovalni delavci
                echo "<i>";
                if ($stoddelkov/20 > 0.25){
                    echo "Svetovalni delavec: ".round($stoddelkov/20,2)."<br />";
                }else{
                    echo "Svetovalni delavec: 0.25<br />";
                }
                //dodatni strokovni delavec za delo z učenci Romi
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabucenci.rom=1";
                $result = mysqli_query($link,$SQL);
                $stromov=mysqli_num_rows($result);
                if ($stromov >= 4 && $stromov <=8 ){
                    echo "Strokovni delavec za delo z Romi: 0.10<br />";
                }
                if ($stromov >= 9 && $stromov <=13 ){
                    echo "Strokovni delavec za delo z Romi: 0.25<br />";
                }
                if ($stromov >= 14 && $stromov <=19 ){
                    echo "Strokovni delavec za delo z Romi: 0.50<br />";
                }
                if ($stromov >= 20 && $stromov <=26 ){
                    echo "Strokovni delavec za delo z Romi: 0.75<br />";
                }
                if ($stromov >= 27 && $stromov <=34 ){
                    echo "Strokovni delavec za delo z Romi: 1.00<br />";
                }
                if ($stromov >= 35 && $stromov <=44 ){
                    echo "Strokovni delavec za delo z Romi: 1.50<br />";
                }
                if ($stromov >= 45 ){
                    echo "Strokovni delavec za delo z Romi: 2.00<br />";
                }
                //echo "<br />";
                //knjižničar
                if ($stoddelkov >= 20){
                    if ($stucencev > 650){
                        echo "Knjižničar: 1.50<br />";
                    }else{
                        echo "Knjižničar: 1.00<br />";
                    }
                }else{
                    if ($stoddelkov/20 < 0.25){
                        echo "Knjižničar: 0.25<br />";
                    }else{
                        echo "Knjižničar: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                //roid
                if ($stoddelkov <= 8){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.20<br />";
                }
                if ($stoddelkov >= 9 && $stoddelkov <= 12){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.25<br />";
                }
                if ($stoddelkov >= 13 && $stoddelkov <= 16){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.30<br />";
                }
                if ($stoddelkov >= 17 && $stoddelkov <= 20){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.35<br />";
                }
                if ($stoddelkov >= 21 && $stoddelkov <= 24){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.45<br />";
                }
                if ($stoddelkov >= 25 && $stoddelkov <= 28){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.55<br />";
                }
                if ($stoddelkov >= 29 && $stoddelkov <= 32){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.65<br />";
                }
                if ($stoddelkov >= 33 && $stoddelkov <= 36){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.75<br />";
                }
                if ($stoddelkov >= 37 && $stoddelkov <= 45){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.90<br />";
                }
                if ($stoddelkov >= 46){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 1.00<br />";
                }
                //organizator prehrane
                echo "Organizator šolske prehrane: ".round($stucencev/4200,2)."<br />";
                
                //laborant
                $SQL = "SELECT id,razred FROM tabrazdat WHERE leto=$VLeto AND razred >= 6";
                $result = mysqli_query($link,$SQL);
                $strazredov[6]=0;
                $strazredov[7]=0;
                $strazredov[8]=0;
                $strazredov[9]=0;
                while ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT count(iducenec) AS ucencev FROM tabrazred WHERE idrazred=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["ucencev"] > 15){
                            $strazredov[intval($R["razred"])] += 1;
                        }
                    }
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='NAR9o' AND leto=$VLeto AND razred=6";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $nar6=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='NAR9o' AND leto=$VLeto AND razred=7";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $nar7=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='FIZ9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $fiz8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='FIZ9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $fiz9=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='KEM9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $kem8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='KEM9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $kem9=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='BIO9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $bio8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='BIO9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $bio9=$R["ur"];
                }
                echo "Laborant: ".round(0.25*(($nar6*$strazredov[6])+($nar7*$strazredov[7])+($bio8*$strazredov[8])+($bio9*$strazredov[9])+($kem8*$strazredov[8])+($kem9*$strazredov[9])+($fiz8*$strazredov[8])+($fiz9*$strazredov[9])))." ur<br />";
                
                //računovodja
                if ($stoddelkov >= 20){
                    echo "Računovodja: 1.00<br />";
                }else{
                    if ($stoddelkov/20 <= 0.25){
                        echo "Računovodja: 0.25<br />";
                    }else{
                        echo "Računovodja: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                
                //poslovni sekretar
                if ($stoddelkov >= 20){
                    echo "Poslovni sekretar: 1.00<br />";
                }else{
                    if ($stoddelkov/20 <= 0.25){
                        echo "Poslovni sekretar: 0.25<br />";
                    }else{
                        echo "Poslovni sekretar: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                if ($stoddelkov >= 30 && $stoddelkov <= 39){
                    echo "Dodatno za računovodsko-administrativna dela: 0.50<br />";
                }
                if ($stoddelkov >= 40 && $stoddelkov <= 49){
                    echo "Dodatno za računovodsko-administrativna dela: 1.00<br />";
                }
                if ($stoddelkov >= 50){
                    echo "Dodatno za računovodsko-administrativna dela: 1.50<br />";
                }
                
                //hišnik
                if ($stoddelkov <= 7){
                    echo "Hišnik: 0.50<br />";
                }
                if ($stoddelkov >= 8 && $stoddelkov <= 11){
                    echo "Hišnik: 0.60<br />";
                }
                if ($stoddelkov >= 12 && $stoddelkov <= 15){
                    echo "Hišnik: 0.80<br />";
                }
                if ($stoddelkov >= 16 && $stoddelkov <= 29){
                    echo "Hišnik: 1.00<br />";
                }
                if ($stoddelkov >= 30 && $stoddelkov <= 44){
                    echo "Hišnik: 1.50<br />";
                }
                if ($stoddelkov >= 45){
                    echo "Hišnik: 2.00<br />";
                }
                echo "Za podružnice se sistemizira dodatno 0.10 hišnika.<br />";
                
                // kuhar
                if ($stucencev/400 <= 0.25){
                    echo "Kuhar: 0.25<br />";
                }else{
                    echo "Kuhar: ".round($stucencev/400,2)."<br />";
                }
                echo "</i><br />";
                //število skupin izbirnih predmetov
                echo "Število učencev: ".$stucencev."<br />";
                echo "Število učencev 7.-9.r: ".$stucencev79."<br />";
                echo "Število oddelkov: ".$stoddelkov."<br />";
                
                $SQL = "SELECT id FROM tabrazdat WHERE leto=$VLeto AND razred > 6";
                $result = mysqli_query($link,$SQL);
                $strazredov79=mysqli_num_rows($result);
                echo "Število razredov 7-9: ".$strazredov79."<br />";
                if ($VLeto==2014){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 7 AND razred <= 7";
                }
                if ($VLeto==2015){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 7 AND razred <= 8";
                }
                if ($VLeto >= 2016){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 7 AND razred <= 9";
                }
                $result = mysqli_query($link,$SQL);
                $stucencev79a=mysqli_num_rows($result);
                echo "Število učencev 7-9 (za NIP): ".$stucencev79a."<br />";

                if ($VLeto==2014){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 4 AND razred <= 4";
                }
                if ($VLeto==2015){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 4 AND razred <= 5";
                }
                if ($VLeto >= 2016){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 4 AND razred <= 6";
                }
                $result = mysqli_query($link,$SQL);
                $stucencev46=mysqli_num_rows($result);
                echo "Število učencev 4-6: ".$stucencev46."<br />";

                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 1 AND razred <= 3";
                $result = mysqli_query($link,$SQL);
                $stucencev13=mysqli_num_rows($result);
                echo "Število učencev 1-3: ".$stucencev13.", PB skupin: ".round($stucencev13/28,2)."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred >= 4 AND razred <= 5";
                $result = mysqli_query($link,$SQL);
                $stucencev45=mysqli_num_rows($result);
                $SQL = "SELECT tabrazred.razred,tabopb.* FROM tabrazred ";
                $SQL .= "LEFT JOIN tabopb ON tabrazred.iducenec=tabopb.iducenec ";
                $SQL .= "WHERE tabrazred.leto=$VLeto AND tabopb.leto=$VLeto AND (tabrazred.razred IN (4,5) AND ";
                $SQL .= "(pb1 OR pb2 OR pb3 OR pb4 OR pb5 OR pb6 OR pb7 OR pb8 OR pb9 OR pb10 OR pb11 OR pb12 OR pb13 OR pb14 OR pb15)) ";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    $stucencev45=mysqli_num_rows($result);
                }
                echo "Število učencev 4-5: ".$stucencev45.", PB skupin: ".round($stucencev45/28,2)."<br />";
                
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=1";
                $result = mysqli_query($link,$SQL);
                $stucencev1=mysqli_num_rows($result);
                echo "Število učencev 1r: ".$stucencev1."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=2";
                $result = mysqli_query($link,$SQL);
                $stucencev2=mysqli_num_rows($result);
                echo "Število učencev 2r: ".$stucencev2."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=3";
                $result = mysqli_query($link,$SQL);
                $stucencev3=mysqli_num_rows($result);
                echo "Število učencev 3r: ".$stucencev3."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=4";
                $result = mysqli_query($link,$SQL);
                $stucencev4=mysqli_num_rows($result);
                echo "Število učencev 4r: ".$stucencev4."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=5";
                $result = mysqli_query($link,$SQL);
                $stucencev5=mysqli_num_rows($result);
                echo "Število učencev 5r: ".$stucencev5."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=6";
                $result = mysqli_query($link,$SQL);
                $stucencev6=mysqli_num_rows($result);
                echo "Število učencev 6r: ".$stucencev6."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=7";
                $result = mysqli_query($link,$SQL);
                $stucencev7=mysqli_num_rows($result);
                echo "Število učencev 7r: ".$stucencev7."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                $stucencev8=mysqli_num_rows($result);
                echo "Število učencev 8r: ".$stucencev8."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                $stucencev9=mysqli_num_rows($result);
                echo "Število učencev 9r: ".$stucencev9."<br />";
                
                echo "Skupin izbirnih predmetov: ".round($stucencev79/23+2*$strazredov79,2)."<br />";
                echo "Skupin neobveznih izbirnih predmetov 7-9r: ".round($stucencev79a/24,2)."<br />";
                echo "Skupin neobveznih izbirnih predmetov 4-6r: ".round($stucencev46/24,2)."<br />";
                if ($stucencev6 <= 16){
                    echo "Število skupin v 6. razredih: 1<br />";
                }
                if ($stucencev6 >= 17 && $stucencev6 <= 32){
                    echo "Število skupin v 6. razredih: 2<br />";
                }
                if ($stucencev6 >= 33 && $stucencev6 <= 48){
                    echo "Število skupin v 6. razredih: 3<br />";
                }
                if ($stucencev6 >= 49 && $stucencev6 <= 64){
                    echo "Število skupin v 6. razredih: 4<br />";
                }
                if ($stucencev6 >= 65 && $stucencev6 <= 80){
                    echo "Število skupin v 6. razredih: 5<br />";
                }
                if ($stucencev6 >= 81 && $stucencev6 <= 96){
                    echo "Število skupin v 6. razredih: 6<br />";
                }
                if ($stucencev6 >= 97 && $stucencev6 <= 112){
                    echo "Število skupin v 6. razredih: 7<br />";
                }
                if ($stucencev6 >= 113 && $stucencev6 <= 128){
                    echo "Število skupin v 6. razredih: 8<br />";
                }
                if ($stucencev6 >= 129){
                    echo "Število skupin v 6. razredih: 9<br />";
                }
                if ($stucencev7 <= 16){
                    echo "Število skupin v 7. razredih: 1<br />";
                }
                if ($stucencev7 >= 17 && $stucencev7 <= 32){
                    echo "Število skupin v 7. razredih: 2<br />";
                }
                if ($stucencev7 >= 33 && $stucencev7 <= 48){
                    echo "Število skupin v 7. razredih: 3<br />";
                }
                if ($stucencev7 >= 49 && $stucencev7 <= 64){
                    echo "Število skupin v 7. razredih: 4<br />";
                }
                if ($stucencev7 >= 65 && $stucencev7 <= 80){
                    echo "Število skupin v 7. razredih: 5<br />";
                }
                if ($stucencev7 >= 81 && $stucencev7 <= 96){
                    echo "Število skupin v 7. razredih: 6<br />";
                }
                if ($stucencev7 >= 97 && $stucencev7 <= 112){
                    echo "Število skupin v 7. razredih: 7<br />";
                }
                if ($stucencev7 >= 113 && $stucencev7 <= 128){
                    echo "Število skupin v 7. razredih: 8<br />";
                }
                if ($stucencev7 >= 129){
                    echo "Število skupin v 7. razredih: 9<br />";
                }
                if ($stucencev8 <= 16){
                    echo "Število skupin v 8. razredih: 1<br />";
                }
                if ($stucencev8 >= 17 && $stucencev8 <= 32){
                    echo "Število skupin v 8. razredih: 2<br />";
                }
                if ($stucencev8 >= 33 && $stucencev8 <= 48){
                    echo "Število skupin v 8. razredih: 3<br />";
                }
                if ($stucencev8 >= 49 && $stucencev8 <= 64){
                    echo "Število skupin v 8. razredih: 4<br />";
                }
                if ($stucencev8 >= 65 && $stucencev8 <= 80){
                    echo "Število skupin v 8. razredih: 5<br />";
                }
                if ($stucencev8 >= 81 && $stucencev8 <= 96){
                    echo "Število skupin v 8. razredih: 6<br />";
                }
                if ($stucencev8 >= 97 && $stucencev8 <= 112){
                    echo "Število skupin v 8. razredih: 7<br />";
                }
                if ($stucencev8 >= 113 && $stucencev8 <= 128){
                    echo "Število skupin v 8. razredih: 8<br />";
                }
                if ($stucencev8 >= 129){
                    echo "Število skupin v 8. razredih: 9<br />";
                }
                if ($stucencev9 <= 16){
                    echo "Število skupin v 9. razredih: 1<br />";
                }
                if ($stucencev9 >= 17 && $stucencev9 <= 32){
                    echo "Število skupin v 9. razredih: 2<br />";
                }
                if ($stucencev9 >= 33 && $stucencev9 <= 48){
                    echo "Število skupin v 9. razredih: 3<br />";
                }
                if ($stucencev9 >= 49 && $stucencev9 <= 64){
                    echo "Število skupin v 9. razredih: 4<br />";
                }
                if ($stucencev9 >= 65 && $stucencev9 <= 80){
                    echo "Število skupin v 9. razredih: 5<br />";
                }
                if ($stucencev9 >= 81 && $stucencev9 <= 96){
                    echo "Število skupin v 9. razredih: 6<br />";
                }
                if ($stucencev9 >= 97 && $stucencev9 <= 112){
                    echo "Število skupin v 9. razredih: 7<br />";
                }
                if ($stucencev9 >= 113 && $stucencev9 <= 128){
                    echo "Število skupin v 9. razredih: 8<br />";
                }
                if ($stucencev9 >= 129){
                    echo "Število skupin v 9. razredih: 9<br />";
                }
            }else{
                echo "<h3>Sistemizirana delovna mesta in število skupin (na osnovi podatkov ŠL ".($VLeto-1)."/".$VLeto.")</h3>";
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".($VLeto-1)." AND tabrazred.razred < 9";
                $result = mysqli_query($link,$SQL);
                $stucencev=mysqli_num_rows($result);
                //echo "Število učencev: ".$stucencev."<br />";
                
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".($VLeto-1)." AND tabrazred.razred > 5 AND tabrazred.razred < 9";
                $result = mysqli_query($link,$SQL);
                $stucencev79=mysqli_num_rows($result);
                //echo "Število učencev 7-9r: ".$stucencev79."<br />";
                
                $SQL = "SELECT id FROM tabrazdat WHERE leto=".($VLeto-1)." AND razred < 9";
                $result = mysqli_query($link,$SQL);
                $stoddelkov=mysqli_num_rows($result);
                //echo "Število oddelkov: ".$stoddelkov."<br />";
                echo "<i>";
                //svetovalni delavci
                if ($stoddelkov/20 > 0.25){
                    echo "Svetovalni delavec: ".round($stoddelkov/20,2)."<br />";
                }else{
                    echo "Svetovalni delavec: 0.25<br />";
                }
                //dodatni strokovni delavec za delo z učenci Romi
                $SQL = "SELECT tabucenci.priimek FROM tabucenci ";
                $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".($VLeto-1)." AND tabucenci.rom=1";
                $result = mysqli_query($link,$SQL);
                $stromov=mysqli_num_rows($result);
                if ($stromov >= 4 && $stromov <=8 ){
                    echo "Strokovni delavec za delo z Romi: 0.10<br />";
                }
                if ($stromov >= 9 && $stromov <=13 ){
                    echo "Strokovni delavec za delo z Romi: 0.25<br />";
                }
                if ($stromov >= 14 && $stromov <=19 ){
                    echo "Strokovni delavec za delo z Romi: 0.50<br />";
                }
                if ($stromov >= 20 && $stromov <=26 ){
                    echo "Strokovni delavec za delo z Romi: 0.75<br />";
                }
                if ($stromov >= 27 && $stromov <=34 ){
                    echo "Strokovni delavec za delo z Romi: 1.00<br />";
                }
                if ($stromov >= 35 && $stromov <=44 ){
                    echo "Strokovni delavec za delo z Romi: 1.50<br />";
                }
                if ($stromov >= 45 ){
                    echo "Strokovni delavec za delo z Romi: 2.00<br />";
                }
                //echo "<br />";
                //knjižničar
                if ($stoddelkov >= 20){
                    if ($stucencev > 650){
                        echo "Knjižničar: 1.50<br />";
                    }else{
                        echo "Knjižničar: 1.00<br />";
                    }
                }else{
                    if ($stoddelkov/20 < 0.25){
                        echo "Knjižničar: 0.25<br />";
                    }else{
                        echo "Knjižničar: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                //roid
                if ($stoddelkov <= 8){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.20<br />";
                }
                if ($stoddelkov >= 9 && $stoddelkov <= 12){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.25<br />";
                }
                if ($stoddelkov >= 13 && $stoddelkov <= 16){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.30<br />";
                }
                if ($stoddelkov >= 17 && $stoddelkov <= 20){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.35<br />";
                }
                if ($stoddelkov >= 21 && $stoddelkov <= 24){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.45<br />";
                }
                if ($stoddelkov >= 25 && $stoddelkov <= 28){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.55<br />";
                }
                if ($stoddelkov >= 29 && $stoddelkov <= 32){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.65<br />";
                }
                if ($stoddelkov >= 33 && $stoddelkov <= 36){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.75<br />";
                }
                if ($stoddelkov >= 37 && $stoddelkov <= 45){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 0.90<br />";
                }
                if ($stoddelkov >= 46){
                    echo "Računalnikar - organizator informacijskih dejavnosti: 1.00<br />";
                }
                //organizator prehrane
                echo "Organizator šolske prehrane: ".round($stucencev/4200,2)."<br />";
                
                //laborant
                $SQL = "SELECT id,razred FROM tabrazdat WHERE leto=".($VLeto-1)." AND razred >= 5 AND razred < 9";
                $result = mysqli_query($link,$SQL);
                $strazredov[6]=0;
                $strazredov[7]=0;
                $strazredov[8]=0;
                $strazredov[9]=0;
                while ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT count(iducenec) AS ucencev FROM tabrazred WHERE idrazred=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    if ($R1 = mysqli_fetch_array($result1)){
                        if ($R1["ucencev"] > 15){
                            $strazredov[intval($R["razred"]+1)] += 1;
                        }
                    }
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='NAR9o' AND leto=$VLeto AND razred=6";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $nar6=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='NAR9o' AND leto=$VLeto AND razred=7";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $nar7=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='FIZ9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $fiz8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='FIZ9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $fiz9=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='KEM9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $kem8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='KEM9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $kem9=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='BIO9o' AND leto=$VLeto AND razred=8";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $bio8=$R["ur"];
                }
                $SQL = "SELECT ur FROM tabpredmetnik WHERE predmet='BIO9o' AND leto=$VLeto AND razred=9";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $bio9=$R["ur"];
                }
                echo "Laborant: ".round(0.25*(($nar6*$strazredov[6])+($nar7*$strazredov[7])+($bio8*$strazredov[8])+($bio9*$strazredov[9])+($kem8*$strazredov[8])+($kem9*$strazredov[9])+($fiz8*$strazredov[8])+($fiz9*$strazredov[9])))." ur<br />";
                
                //računovodja
                if ($stoddelkov >= 20){
                    echo "Računovodja: 1.00<br />";
                }else{
                    if ($stoddelkov/20 <= 0.25){
                        echo "Računovodja: 0.25<br />";
                    }else{
                        echo "Računovodja: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                
                //poslovni sekretar
                if ($stoddelkov >= 20){
                    echo "Poslovni sekretar: 1.00<br />";
                }else{
                    if ($stoddelkov/20 <= 0.25){
                        echo "Poslovni sekretar: 0.25<br />";
                    }else{
                        echo "Poslovni sekretar: ".round($stoddelkov/20,2)."<br />";
                    }
                }
                if ($stoddelkov >= 30 && $stoddelkov <= 39){
                    echo "Dodatno za računovodsko-administrativna dela: 0.50<br />";
                }
                if ($stoddelkov >= 40 && $stoddelkov <= 49){
                    echo "Dodatno za računovodsko-administrativna dela: 1.00<br />";
                }
                if ($stoddelkov >= 50){
                    echo "Dodatno za računovodsko-administrativna dela: 1.50<br />";
                }
                
                //hišnik
                if ($stoddelkov <= 7){
                    echo "Hišnik: 0.50<br />";
                }
                if ($stoddelkov >= 8 && $stoddelkov <= 11){
                    echo "Hišnik: 0.60<br />";
                }
                if ($stoddelkov >= 12 && $stoddelkov <= 15){
                    echo "Hišnik: 0.80<br />";
                }
                if ($stoddelkov >= 16 && $stoddelkov <= 29){
                    echo "Hišnik: 1.00<br />";
                }
                if ($stoddelkov >= 30 && $stoddelkov <= 44){
                    echo "Hišnik: 1.50<br />";
                }
                if ($stoddelkov >= 45){
                    echo "Hišnik: 2.00<br />";
                }
                echo "Za podružnice se sistemizira dodatno 0.10 hišnika.<br />";
                
                // kuhar
                if ($stucencev/400 <= 0.25){
                    echo "Kuhar: 0.25<br />";
                }else{
                    echo "Kuhar: ".round($stucencev/400,2)."<br />";
                }
                echo "</i><br />";
                //število skupin izbirnih predmetov
                echo "Število učencev: ".$stucencev."<br />";
                echo "Število učencev 7-9r: ".$stucencev79."<br />";
                echo "Število oddelkov: ".$stoddelkov."<br />";
                
                $SQL = "SELECT id FROM tabrazdat WHERE leto=".($VLeto-1)." AND razred > 5 AND razred < 9";
                $result = mysqli_query($link,$SQL);
                $strazredov79=mysqli_num_rows($result);
                echo "Število razredov 7-9r: ".$strazredov79."<br />";
                
                if ($VLeto == 2015){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 6 AND razred <= 7";
                }
                if ($VLeto >= 2016){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 6 AND razred <= 8";
                }
                $result = mysqli_query($link,$SQL);
                $stucencev79a=mysqli_num_rows($result);
                echo "Število učencev 7-9r (za NIP): ".$stucencev79a."<br />";

                if ($VLeto == 2015){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 3 AND razred <= 4";
                }
                if ($VLeto >= 2016){
                    $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 3 AND razred <= 5";
                }
                $result = mysqli_query($link,$SQL);
                $stucencev46=mysqli_num_rows($result);
                echo "Število učencev 4-6r: ".$stucencev46."<br />";
                
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 0 AND razred <= 2";
                $result = mysqli_query($link,$SQL);
                $stucencev13=mysqli_num_rows($result);
                echo "Število učencev 1-3: ".$stucencev13.", PB skupin: ".round($stucencev13/28,2)."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred >= 3 AND razred <= 4";
                $result = mysqli_query($link,$SQL);
                $stucencev45=mysqli_num_rows($result);
                /*
                $SQL = "SELECT tabrazred.razred,tabopb.* FROM tabrazred ";
                $SQL .= "LEFT JOIN tabopb ON tabrazred.iducenec=tabopb.iducenec ";
                $SQL .= "WHERE tabrazred.leto=".($VLeto)." AND tabopb.leto=".($VLeto)." AND (tabrazred.razred IN (4,5) AND ";
                $SQL .= "(pb1 OR pb2 OR pb3 OR pb4 OR pb5 OR pb6 OR pb7 OR pb8 OR pb9 OR pb10 OR pb11 OR pb12 OR pb13 OR pb14 OR pb15)) ";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    $stucencev45=mysqli_num_rows($result);
                }
                */
                echo "Število učencev 4-5: ".$stucencev45.", PB skupin: ".round($stucencev45/28,2)."<br />";
                
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=0";
                $result = mysqli_query($link,$SQL);
                $stucencev1=mysqli_num_rows($result);
                echo "Število učencev 1r: ".$stucencev1."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=1";
                $result = mysqli_query($link,$SQL);
                $stucencev2=mysqli_num_rows($result);
                echo "Število učencev 2r: ".$stucencev2."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=2";
                $result = mysqli_query($link,$SQL);
                $stucencev3=mysqli_num_rows($result);
                echo "Število učencev 3r: ".$stucencev3."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=3";
                $result = mysqli_query($link,$SQL);
                $stucencev4=mysqli_num_rows($result);
                echo "Število učencev 4r: ".$stucencev4."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=4";
                $result = mysqli_query($link,$SQL);
                $stucencev5=mysqli_num_rows($result);
                echo "Število učencev 5r: ".$stucencev5."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=5";
                $result = mysqli_query($link,$SQL);
                $stucencev6=mysqli_num_rows($result);
                echo "Število učencev 6r: ".$stucencev6."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=6";
                $result = mysqli_query($link,$SQL);
                $stucencev7=mysqli_num_rows($result);
                echo "Število učencev 7r: ".$stucencev7."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=7";
                $result = mysqli_query($link,$SQL);
                $stucencev8=mysqli_num_rows($result);
                echo "Število učencev 8r: ".$stucencev8."<br />";
                $SQL = "SELECT id FROM tabrazred WHERE leto=".($VLeto-1)." AND razred=8";
                $result = mysqli_query($link,$SQL);
                $stucencev9=mysqli_num_rows($result);
                echo "Število učencev 9r: ".$stucencev9."<br />";
                
                echo "Skupin izbirnih predmetov: ".round($stucencev79/23+2*$strazredov79,2)."<br />";
                echo "Skupin neobveznih izbirnih predmetov 7-9r: ".round($stucencev79a/24,2)."<br />";
                echo "Skupin neobveznih izbirnih predmetov 4-6r: ".round($stucencev46/24,2)."<br />";
                if ($stucencev6 <= 16){
                    echo "Število skupin v 6. razredih: 1<br />";
                }
                if ($stucencev6 >= 17 && $stucencev6 <= 32){
                    echo "Število skupin v 6. razredih: 2<br />";
                }
                if ($stucencev6 >= 33 && $stucencev6 <= 48){
                    echo "Število skupin v 6. razredih: 3<br />";
                }
                if ($stucencev6 >= 49 && $stucencev6 <= 64){
                    echo "Število skupin v 6. razredih: 4<br />";
                }
                if ($stucencev6 >= 65 && $stucencev6 <= 80){
                    echo "Število skupin v 6. razredih: 5<br />";
                }
                if ($stucencev6 >= 81 && $stucencev6 <= 96){
                    echo "Število skupin v 6. razredih: 6<br />";
                }
                if ($stucencev6 >= 97 && $stucencev6 <= 112){
                    echo "Število skupin v 6. razredih: 7<br />";
                }
                if ($stucencev6 >= 113 && $stucencev6 <= 128){
                    echo "Število skupin v 6. razredih: 8<br />";
                }
                if ($stucencev6 >= 129){
                    echo "Število skupin v 6. razredih: 9<br />";
                }
                if ($stucencev7 <= 16){
                    echo "Število skupin v 7. razredih: 1<br />";
                }
                if ($stucencev7 >= 17 && $stucencev7 <= 32){
                    echo "Število skupin v 7. razredih: 2<br />";
                }
                if ($stucencev7 >= 33 && $stucencev7 <= 48){
                    echo "Število skupin v 7. razredih: 3<br />";
                }
                if ($stucencev7 >= 49 && $stucencev7 <= 64){
                    echo "Število skupin v 7. razredih: 4<br />";
                }
                if ($stucencev7 >= 65 && $stucencev7 <= 80){
                    echo "Število skupin v 7. razredih: 5<br />";
                }
                if ($stucencev7 >= 81 && $stucencev7 <= 96){
                    echo "Število skupin v 7. razredih: 6<br />";
                }
                if ($stucencev7 >= 97 && $stucencev7 <= 112){
                    echo "Število skupin v 7. razredih: 7<br />";
                }
                if ($stucencev7 >= 113 && $stucencev7 <= 128){
                    echo "Število skupin v 7. razredih: 8<br />";
                }
                if ($stucencev7 >= 129){
                    echo "Število skupin v 7. razredih: 9<br />";
                }
                if ($stucencev8 <= 16){
                    echo "Število skupin v 8. razredih: 1<br />";
                }
                if ($stucencev8 >= 17 && $stucencev8 <= 32){
                    echo "Število skupin v 8. razredih: 2<br />";
                }
                if ($stucencev8 >= 33 && $stucencev8 <= 48){
                    echo "Število skupin v 8. razredih: 3<br />";
                }
                if ($stucencev8 >= 49 && $stucencev8 <= 64){
                    echo "Število skupin v 8. razredih: 4<br />";
                }
                if ($stucencev8 >= 65 && $stucencev8 <= 80){
                    echo "Število skupin v 8. razredih: 5<br />";
                }
                if ($stucencev8 >= 81 && $stucencev8 <= 96){
                    echo "Število skupin v 8. razredih: 6<br />";
                }
                if ($stucencev8 >= 97 && $stucencev8 <= 112){
                    echo "Število skupin v 8. razredih: 7<br />";
                }
                if ($stucencev8 >= 113 && $stucencev8 <= 128){
                    echo "Število skupin v 8. razredih: 8<br />";
                }
                if ($stucencev8 >= 129){
                    echo "Število skupin v 8. razredih: 9<br />";
                }
                if ($stucencev9 <= 16){
                    echo "Število skupin v 9. razredih: 1<br />";
                }
                if ($stucencev9 >= 17 && $stucencev9 <= 32){
                    echo "Število skupin v 9. razredih: 2<br />";
                }
                if ($stucencev9 >= 33 && $stucencev9 <= 48){
                    echo "Število skupin v 9. razredih: 3<br />";
                }
                if ($stucencev9 >= 49 && $stucencev9 <= 64){
                    echo "Število skupin v 9. razredih: 4<br />";
                }
                if ($stucencev9 >= 65 && $stucencev9 <= 80){
                    echo "Število skupin v 9. razredih: 5<br />";
                }
                if ($stucencev9 >= 81 && $stucencev9 <= 96){
                    echo "Število skupin v 9. razredih: 6<br />";
                }
                if ($stucencev9 >= 97 && $stucencev9 <= 112){
                    echo "Število skupin v 9. razredih: 7<br />";
                }
                if ($stucencev9 >= 113 && $stucencev9 <= 128){
                    echo "Število skupin v 9. razredih: 8<br />";
                }
                if ($stucencev9 >= 129){
                    echo "Število skupin v 9. razredih: 9<br />";
                }
            }
            echo "<br />";
            echo "<a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".($VLeto)."</a> | ".$VLeto."/".($VLeto+1)." | <a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            echo "<a href='nacrtovanjedela.php?id=2&solskoleto=$VLeto'>Prenesi podatke v naslednje šolsko leto</a><br />";
            echo "<a href='nacrtovanjedela.php?id=3&solskoleto=$VLeto'>Briši podatke za trenutno šolsko leto</a><br />";
            break;
        case "2": //prenos preteklih podatkov v naslednje šolsko leto
            $SQL = "SELECT * FROM tabpredmetnik WHERE leto=$VLeto";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $SQL = "SELECT * FROM tabpredmetnik WHERE leto=".($VLeto+1)." AND predmet='".$R["predmet"]."' AND razred=".$R["razred"]." AND tip=".$R["tip"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    $SQL = "UPDATE tabpredmetnik SET ur=".$R["ur"]." WHERE id=".$R1["id"];
                }else{
                    $SQL = "INSERT INTO tabpredmetnik (leto,predmet,razred,tip,ur,vrstnired) VALUES (".($R["leto"]+1).",'".$R["predmet"]."',".$R["razred"].",".$R["tip"].",".$R["ur"].",".$R["vrstnired"].")";
                }
                if (!($result2 = mysqli_query($link,$SQL))){
                    die("Napaka pri prepisovanju predmetnika!<br />$SQL<br />");
                }
            }
            echo "Podatki so prepisani!<br />";
            echo "<a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".($VLeto)."</a> | ".$VLeto."/".($VLeto+1)." | <a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            break;
        case "3": //brisanje predmetnika za določeno leto
            if ($VLeto != 2014){
                $SQL = "DELETE FROM tabpredmetnik WHERE leto=$VLeto";
                if (!($result2 = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju podatkov iz predmetnika!<br />$SQL<br />");
                }else{
                    echo "Podatki so pobrisani!<br />";
                }
            }else{
                echo "Teh podatkov ni dovoljeno brisati, obrnite se na administratorja!<br />";
            }
            echo "<a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".($VLeto)."</a> | ".$VLeto."/".($VLeto+1)." | <a href='nacrtovanjedela.php?id=1&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            break;
        case "4": //izpis razreda s predmeti in učitelji za aktualno in preteklo leto
            $VRazred=$_GET["razred"];
            $VRazred1=0;
            $VParalelka="";
            $VIdSola=1;
            
            //podatki za aktualni razred
            $SQL = "SELECT razred,oznaka,idsola FROM tabrazdat WHERE id=$VRazred";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
                $VIdSola=$R["idsola"];
            }
            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabpredmeti.predmetidmss,tabucenje.predmet,tabucenje.leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabucenje.idrazred=$VRazred AND tabpredmeti.prioriteta=0 AND tabrazdat.idsola=".$VIdSola;
            $SQL .= " ORDER BY tabpredmeti.vrstnired";
            $result = mysqli_query($link,$SQL);
            $StPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$StPredmetov][0]=$R["predmet"];
                $Predmeti[$StPredmetov][1]=$R["oznaka"];
                $Predmeti[$StPredmetov][2]=$R["predmetidmss"];
                $StPredmetov=$StPredmetov+1;
            }
            
            //predmetnik - vsi predmeti za aktualni razred
            $SQL = "SELECT tabpredmeti.id,tabpredmeti.oznaka,tabpredmetnik.ur,tabpredmetnik.predmet FROM tabpredmeti ";
            $SQL .= "INNER JOIN tabpredmetnik ON tabpredmeti.predmetidmss=tabpredmetnik.predmet ";
            $SQL .= "WHERE tabpredmetnik.leto=$VLeto AND tabpredmetnik.razred=$VRazred1 ";
            $SQL .= "ORDER BY tabpredmetnik.vrstnired";
            $result = mysqli_query($link,$SQL);
            $StPredmetovPredm=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmetnik[$StPredmetovPredm][0]=$R["id"];
                $Predmetnik[$StPredmetovPredm][1]=$R["oznaka"];
                $Predmetnik[$StPredmetovPredm][2]=$R["predmet"];
                $Predmetnik[$StPredmetovPredm][3]=$R["ur"];
                $StPredmetovPredm++;
            }

            //podatki za lanskoletni razred
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".($VLeto-1)." AND razred=".($VRazred1-1)." AND oznaka='".$VParalelka."' AND idsola=$VIdSola";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VStariRazred1=$R["razred"];
                $VStaraParalelka=$R["oznaka"];
                $VStariRazred=$R["id"];
            }
            
            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabpredmeti.predmetidmss,tabucenje.predmet,tabucenje.leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".($VLeto-1)." AND tabucenje.idrazred=$VStariRazred AND tabpredmeti.prioriteta=0 AND tabrazdat.idsola=".$VIdSola;
            $SQL .= " ORDER BY tabpredmeti.vrstnired";
            $result = mysqli_query($link,$SQL);

            $StStarihPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $StariPredmeti[$StStarihPredmetov][0]=$R["predmet"];
                $StariPredmeti[$StStarihPredmetov][1]=$R["oznaka"];
                $StariPredmeti[$StStarihPredmetov][2]=$R["predmetidmss"];
                $StStarihPredmetov++;
            }
            
            for ($Indx=0;$Indx <= 50;$Indx++){
                $RazredDat[$Indx][0]="";
                $RazredDat[$Indx][1]="";
                for ($Indx0=2;$Indx0 <= 200;$Indx0++){
                    $RazredDat[$Indx][$Indx0]=0;
                    $RazredDatNeoc[$Indx][$Indx0]=0;
                }
            }

            echo "Redni predmeti $VRazred1. $VParalelka<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan>";
            echo "<th>Predmet</th><th>".($VLeto-1)."/".$VLeto."</th><th>".$VLeto."/".($VLeto+1)."</th></tr>";
            echo "<tr><th>Razrednik</th>";
            //razrednik - stari
            $Razrednik="";
            $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM (tabucitelji ";
            $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
            $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
            $SQL .= "WHERE tabucenje.leto=".($VLeto-1)." AND tabucenje.idrazred=$VStariRazred AND tabpredmeti.kodamss='RU'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $Razrednik=$R["ime"]." ".$R["priimek"];
            }
            echo "<td>$Razrednik</td>";
            //razrednik - novi
            $Razrednik="";
            $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime FROM (tabucitelji ";
            $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
            $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabucenje.idrazred=$VRazred AND tabpredmeti.kodamss='RU'";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $Razrednik=$R["ime"]." ".$R["priimek"];
                $iducitelj=$R["iducitelj"];
            }
            if (strlen($Razrednik) > 0){
                $SQL = "SELECT id FROM tabpredmeti WHERE kodamss='RU'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<td><a href='Predmeti.php?ucitelj=$iducitelj&dodanpredmet=".$R["id"]."&dodanrazred=$VRazred&dodaneure=0.5&idsola=".$VIdSola."'>$Razrednik</a></td>";
                }
            }else{
                echo "<td>";
                $SQL = "SELECT id FROM tabpredmeti WHERE kodamss='RU'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    echo "<a href='Predmeti.php?dodanpredmet=".$R["id"]."&dodanrazred=$VRazred&dodaneure=0.5&idsola=".$VIdSola."'>+</a><br />";
                }
                echo "</td>";
            }
            echo "</tr>";
            
            for ($Indx=0;$Indx < $StPredmetovPredm;$Indx++){
                //predmet in ure
                echo "<tr><td>".$Predmetnik[$Indx][1]." (".round($Predmetnik[$Indx][3],2).")</td>";
                echo "<td>";
                //učitelj in ure - preteklo leto
                $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                $SQL .= "WHERE tabucenje.idrazred=$VStariRazred AND tabucenje.predmet=".$Predmetnik[$Indx][0]." ORDER BY tabucenje.realizirano";
                $result = mysqli_query($link,$SQL);
                //izpis izvedbe (učitelj, ur)
                while ($R = mysqli_fetch_array($result)){
                    if ($R["realizirano"] > 0){
                        echo $R["realizirano"].". ".$R["uciteljuntis"]." ".round($R["planirano"],2)."<br />";
                    }else{
                        echo $R["uciteljuntis"]." ".round($R["planirano"],2)."<br />";
                    }
                }
                echo "</td><td>";
                //učitelj in ure - aktualno leto
                $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                $SQL .= "WHERE tabucenje.idrazred=$VRazred AND tabucenje.predmet=".$Predmetnik[$Indx][0]." ORDER BY tabucenje.realizirano";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) == 0){
                    echo "<a href='Predmeti.php?dodanpredmet=".$Predmetnik[$Indx][0]."&dodanrazred=$VRazred&dodaneure=".round($Predmetnik[$Indx][3],2)."&idsola=".$VIdSola."'>+</a><br />";
                }
                //izpis izvedbe (učitelj, ur)
                while ($R = mysqli_fetch_array($result)){
                    if ($R["realizirano"] > 0){
                        echo $R["realizirano"].". <a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                    }else{
                        echo "<a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                    }
                }
                echo "</td>";
                
                echo "</tr>";
            }

            echo "</table><br />";
            break;
        default:
            $sola=array();
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                $sola[$i][0]=$R["id"];
                $sola[$i][1]=$R["solakratko"];
                $i += 1;
            }
            $StSol=$i-1;
                
            for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
                echo "<h2>".$sola[$IndxSola][1]."</h2>";           
                $SQL = "SELECT id,razred,oznaka,osemdevet FROM tabrazdat ";
                $SQL .= "WHERE leto=".$VLeto." AND razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY razred,oznaka";
                $result = mysqli_query($link,$SQL);

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $Razredi[$Indx][0] = $R["razred"];
                    $Razredi[$Indx][1] = $R["oznaka"];
                    $Razredi[$Indx][2] = $R["osemdevet"];
                    $Razredi[$Indx][3] = $R["id"];
                    $Indx=$Indx+1;
                }
                $StRazredov=$Indx;

                //predmetnik - vsi predmeti za aktualni razred
                $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.oznaka,tabpredmetnik.predmet FROM tabpredmeti ";
                $SQL .= "INNER JOIN tabpredmetnik ON tabpredmeti.predmetidmss=tabpredmetnik.predmet ";
                $SQL .= "WHERE tabpredmetnik.leto=$VLeto ";
                $SQL .= "ORDER BY tabpredmetnik.vrstnired";
                $result = mysqli_query($link,$SQL);
                $StPredmetovPredm=0;
                while ($R = mysqli_fetch_array($result)){
                    $PredmetnikVsi[$StPredmetovPredm][0]=$R["id"];
                    $PredmetnikVsi[$StPredmetovPredm][1]=$R["oznaka"];
                    $PredmetnikVsi[$StPredmetovPredm][2]=$R["predmet"];
                    //$Predmetnik[$StPredmetovPredm][3]=$R["ur"];
                    $StPredmetovPredm++;
                }
                
                //vneseni predmeti v sistemizacijo
                $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabpredmeti.predmetidmss,tabucenje.predmet,tabucenje.leto FROM ";
                $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  tabpredmeti.prioriteta=0 AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabpredmeti.vrstnired";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["predmet"];
                    $Predmeti[$StPredmetov][1]=$R["oznaka"];
                    $Predmeti[$StPredmetov][2]=$R["predmetidmss"];
                    $StPredmetov=$StPredmetov+1;
                }

                for ($Indx=0;$Indx <= 50;$Indx++){
                    $RazredDat[$Indx][0]="";
                    $RazredDat[$Indx][1]="";
                    for ($Indx0=2;$Indx0 <= 200;$Indx0++){
                        $RazredDat[$Indx][$Indx0]=0;
                        $RazredDatNeoc[$Indx][$Indx0]=0;
                    }
                }

                echo "Redni predmeti ".$VLeto."/".($VLeto+1)."<br />";
                echo "<a href='nacrtovanjedela.php?solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | <a href='nacrtovanjedela.php?solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
                echo "<table border=1 cellspacing=0>";
                echo "<tr bgcolor=lightcyan>";
                echo "<th>Razred</th><th>Razrednik</th><th>Učencev</th>";
                for ($Indx=0;$Indx < $StPredmetovPredm;$Indx++){
                    echo "<th>".$PredmetnikVsi[$Indx][1]."</th>";
                }
                echo "</tr>";

                for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                    echo "<tr>";
                    $VRazred1=$Razredi[$IndxRazred][0];
                    $VParalelka=$Razredi[$IndxRazred][1];
                    $VRazred=$Razredi[$IndxRazred][3];

                    //prebere predmetnik
                    $SQL = "SELECT * FROM tabpredmetnik WHERE leto=$VLeto AND razred=$VRazred1 ORDER BY vrstnired";
                    $result = mysqli_query($link,$SQL);
                    $n=0;
                    while ($R = mysqli_fetch_array($result)){
                        $n++;
                        $predmetnik[$n][0]=$R["predmet"];
                        $predmetnik[$n][1]=$R["ur"];
                    }

                    echo "<td><a href='nacrtovanjedela.php?id=4&razred=$VRazred'>".$VRazred1.". ".$VParalelka."</a></td>";
                    //razrednik
                    $Razrednik="";
                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM (tabucitelji ";
                    $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
                    $SQL .= "WHERE tabucenje.leto=$VLeto AND tabucenje.idrazred=$VRazred AND tabpredmeti.kodamss='RU'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Razrednik=$R["ime"]." ".$R["priimek"];
                    }
                    echo "<td>$Razrednik</td>";
                    //število učencev
                    $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=$VRazred";
                    $result = mysqli_query($link,$SQL);
                    $StUcencev=mysqli_num_rows($result);
                    echo "<td>$StUcencev</td>";

                    //izpis izvajalcev po predmetih (na osnovi predmetnika)
                    for ($i=0;$i < $StPredmetovPredm;$i++){
                        $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                        $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                        $SQL .= "WHERE tabucenje.idrazred=$VRazred AND tabucenje.predmet=".$PredmetnikVsi[$i][0]." ORDER BY tabucenje.realizirano";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<td valign='top' ";
                            for ($j=1;$j <= $n;$j++){
                                if ($predmetnik[$j][0] == $PredmetnikVsi[$i][2]){
                                    echo "bgcolor='lightyellow'";
                                    break;
                                }
                            }
                            echo ">";                                
                        }else{
                            $obstaja=false;
                            for ($j=1;$j <= $n;$j++){
                                if ($predmetnik[$j][0] == $PredmetnikVsi[$i][2]){
                                    $obstaja=true;
                                    break;
                                }
                            }
                            if ($obstaja){
                                echo "<td valign='top' bgcolor='lightyellow'>";
                            }else{
                                echo "<td valign='top' bgcolor='lightgrey'>";
                            }
                        }
                        //izpiše ure iz predmetnika
                        for ($j=1;$j <= $n;$j++){
                            if ($predmetnik[$j][0] == $PredmetnikVsi[$i][2]){
                                echo "<span style='color:blue;font-weight:bold'>".round($predmetnik[$j][1],2)."</span> <a href='Predmeti.php?solskoleto=$VLeto&dodanpredmet=".$PredmetnikVsi[$i][0]."&dodanrazred=$VRazred&dodaneure=".round($predmetnik[$j][1],2)."&idsola=".$sola[$IndxSola][0]."'>+</a><br />";
                                break;
                            }
                        }
                        
                        //izpis izvedbe (učitelj, ur)
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["realizirano"] > 0){
                                echo $R["realizirano"].". <a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }else{
                                echo "<a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }
                        }
                        echo "</td>";
                    }

                    /*
                    //izpis izvajalcev po predmetih
                    for ($i=0;$i < $StPredmetov;$i++){
                        $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                        $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                        $SQL .= "WHERE tabucenje.idrazred=$VRazred AND tabucenje.predmet=".$Predmeti[$i][0]." ORDER BY tabucenje.realizirano";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<td valign='top' ";
                            for ($j=1;$j <= $n;$j++){
                                if ($predmetnik[$j][0] == $Predmeti[$i][2]){
                                    echo "bgcolor='lightyellow'";
                                    break;
                                }
                            }
                            echo ">";                                
                        }else{
                            $obstaja=false;
                            for ($j=1;$j <= $n;$j++){
                                if ($predmetnik[$j][0] == $Predmeti[$i][2]){
                                    $obstaja=true;
                                    break;
                                }
                            }
                            if ($obstaja){
                                echo "<td valign='top' bgcolor='lightyellow'>";
                            }else{
                                echo "<td valign='top' bgcolor='lightgrey'>";
                            }
                        }
                        //izpiše ure iz predmetnika
                        for ($j=1;$j <= $n;$j++){
                            if ($predmetnik[$j][0] == $Predmeti[$i][2]){
                                echo "<span style='color:blue;font-weight:bold'>".round($predmetnik[$j][1],2)."</span> <a href='Predmeti.php?dodanpredmet=".$Predmeti[$i][0]."&dodanrazred=$VRazred&dodaneure=".round($predmetnik[$j][1],2)."&idsola=".$sola[$IndxSola][0]."'>+</a><br />";
                                break;
                            }
                        }
                        
                        //izpis izvedbe (učitelj, ur)
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["realizirano"] > 0){
                                echo $R["realizirano"].". <a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }else{
                                echo "<a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                    */
                }
                echo "</table><br />";

                //predmetnik - vsi izbirni predmeti na osnovi nabora
                $SQL = "SELECT tabnaborizb.*,tabpredmeti.oznaka,tabpredmeti.predmetidmss FROM tabnaborizb ";
                $SQL .= "INNER JOIN tabpredmeti ON tabnaborizb.predmet=tabpredmeti.id ";
                $SQL .= "WHERE tabnaborizb.leto=$VLeto AND tabnaborizb.izbran=true AND tabnaborizb.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabpredmeti.vrstnired,tabpredmeti.oznaka";
                $result = mysqli_query($link,$SQL);
                $StPredmetovPredm=0;
                while ($R = mysqli_fetch_array($result)){
                    $PredmetnikVsi[$StPredmetovPredm][0]=$R["predmet"];
                    $PredmetnikVsi[$StPredmetovPredm][1]=$R["oznaka"];
                    $PredmetnikVsi[$StPredmetovPredm][2]=$R["predmetidmss"];
                    //$Predmetnik[$StPredmetovPredm][3]=$R["ur"];
                    $StPredmetovPredm++;
                }
                
                //izbirni predmeti
                $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.leto FROM ";
                $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  tabpredmeti.prioriteta=1 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabpredmeti.vrstnired,tabpredmeti.oznaka";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["predmet"];
                    $Predmeti[$StPredmetov][1]=$R["oznaka"];
                    $StPredmetov=$StPredmetov+1;
                }
                
                echo "Izbirni predmeti ".$VLeto."/".($VLeto+1)."<br />";
                echo "<table border=1 cellspacing=0>";
                echo "<tr bgcolor=lightcyan>";
                echo "<th>Razred</th><th>Razrednik</th><th>Učencev</th>";
                for ($Indx=0;$Indx < $StPredmetovPredm;$Indx++){
                    echo "<th>".$PredmetnikVsi[$Indx][1]."</th>";
                }
                echo "</tr>";

                for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                    echo "<tr>";
                    $VRazred1=$Razredi[$IndxRazred][0];
                    $VParalelka=$Razredi[$IndxRazred][1];
                    $VRazred=$Razredi[$IndxRazred][3];
                    echo "<td>".$VRazred1.". ".$VParalelka."</td>";
                    
                    //izbirni predmeti
                    $SQL = "SELECT * FROM tabnaborizb WHERE leto=$VLeto AND izbran=true AND idsola=".$sola[$IndxSola][0];
                    $result = mysqli_query($link,$SQL);
                    $n=0;
                    while ($R = mysqli_fetch_array($result)){
                        $n++;
                        $izbirni[$n][0]=$R["predmet"];
                        $izbirni[$n][1]=$R["r1"];
                        $izbirni[$n][2]=$R["r2"];
                        $izbirni[$n][3]=$R["r3"];
                        $izbirni[$n][4]=$R["r4"];
                        $izbirni[$n][5]=$R["r5"];
                        $izbirni[$n][6]=$R["r6"];
                        $izbirni[$n][7]=$R["r7"];
                        $izbirni[$n][8]=$R["r8"];
                        $izbirni[$n][9]=$R["r9"];
                        $izbirni[$n][10]=$R["ur"];
                    }
                    $StIzbirnih=$n;
                    
                    //razrednik
                    $Razrednik="";
                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM (tabucitelji ";
                    $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
                    $SQL .= "WHERE tabucenje.leto=$VLeto AND tabucenje.idrazred=$VRazred AND tabpredmeti.kodamss='RU'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Razrednik=$R["ime"]." ".$R["priimek"];
                    }
                    echo "<td>$Razrednik</td>";
                    //število učencev
                    $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=$VRazred";
                    $result = mysqli_query($link,$SQL);
                    $StUcencev=mysqli_num_rows($result);
                    echo "<td>$StUcencev</td>";
                    //izpis izvajalcev po predmetih
                    for ($i=0;$i < $StPredmetovPredm;$i++){
                        $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                        $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                        $SQL .= "WHERE tabucenje.idrazred=$VRazred AND tabucenje.predmet=".$PredmetnikVsi[$i][0]." ORDER BY tabucenje.realizirano";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<td valign='top'>";
                        }else{
                            echo "<td valign='top' bgcolor='lightgrey'>";
                        }
                        //izpiše ure iz predmetnika
                        for ($j=1;$j <= $StIzbirnih;$j++){
                            if (($izbirni[$j][0] == $PredmetnikVsi[$i][0]) && $izbirni[$j][$VRazred1]){
                                echo "<span style='color:blue;font-weight:bold'>".round($izbirni[$j][10],2)."</span> <a href='Predmeti.php?solskoleto=$VLeto&dodanpredmet=".$PredmetnikVsi[$i][0]."&dodanrazred=$VRazred&dodaneure=".round($izbirni[$j][10],2)."&idsola=".$sola[$IndxSola][0]."'>+</a><br />";
                                break;
                            }
                        }
                        
                        //izpis izvedbe (učitelj, ur)
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["realizirano"] > 0){
                                echo $R["realizirano"].". <a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."<br />";
                            }else{
                                echo "<a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";

                //ostale dejavnosti
                //predmetnik - vsi izbirni predmeti na osnovi nabora
                $SQL = "SELECT tabpredmeti.id,tabpredmeti.oznaka,tabpredmeti.predmetidmss FROM tabpredmeti ";
                $SQL .= "WHERE prioriteta=3 ";
                $SQL .= " ORDER BY tabpredmeti.vrstnired,tabpredmeti.oznaka";
                $result = mysqli_query($link,$SQL);
                $StPredmetovPredm=0;
                while ($R = mysqli_fetch_array($result)){
                    $PredmetnikVsi[$StPredmetovPredm][0]=$R["id"];
                    $PredmetnikVsi[$StPredmetovPredm][1]=$R["oznaka"];
                    $PredmetnikVsi[$StPredmetovPredm][2]=$R["predmetidmss"];
                    //$Predmetnik[$StPredmetovPredm][3]=$R["ur"];
                    $StPredmetovPredm++;
                }

                $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.leto FROM ";
                $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  tabpredmeti.prioriteta=3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabpredmeti.vrstnired,tabpredmeti.oznaka";
                $result = mysqli_query($link,$SQL);

                $StPredmetov=0;
                while ($R = mysqli_fetch_array($result)){
                    $Predmeti[$StPredmetov][0]=$R["predmet"];
                    $Predmeti[$StPredmetov][1]=$R["oznaka"];
                    $StPredmetov=$StPredmetov+1;
                }
                
                echo "Ostalo ".$VLeto."/".($VLeto+1)."<br />";
                echo "<table border=1 cellspacing=0>";
                echo "<tr bgcolor=lightcyan>";
                echo "<th>Razred</th><th>Razrednik</th><th>Učencev</th>";
                for ($Indx=0;$Indx < $StPredmetovPredm;$Indx++){
                    echo "<th>".$PredmetnikVsi[$Indx][1]."</th>";
                }
                echo "</tr>";

                for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                    echo "<tr>";
                    $VRazred1=$Razredi[$IndxRazred][0];
                    $VParalelka=$Razredi[$IndxRazred][1];
                    $VRazred=$Razredi[$IndxRazred][3];
                    echo "<td>".$VRazred1.". ".$VParalelka."</td>";
                    //razrednik
                    $Razrednik="";
                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime FROM (tabucitelji ";
                    $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                    $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
                    $SQL .= "WHERE tabucenje.leto=$VLeto AND tabucenje.idrazred=$VRazred AND tabpredmeti.kodamss='RU'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $Razrednik=$R["ime"]." ".$R["priimek"];
                    }
                    echo "<td>$Razrednik</td>";
                    //število učencev
                    $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=$VRazred";
                    $result = mysqli_query($link,$SQL);
                    $StUcencev=mysqli_num_rows($result);
                    echo "<td>$StUcencev</td>";
                    //izpis izvajalcev po predmetih
                    for ($i=0;$i < $StPredmetovPredm;$i++){
                        $SQL = "SELECT tabuntisucitelj.uciteljuntis,tabucenje.id,tabucenje.realizirano,tabucenje.planirano FROM (tabucenje ";
                        $SQL .= "INNER JOIN tabuntisucitelj ON tabucenje.iducitelj=tabuntisucitelj.iducitelj) ";
                        $SQL .= "WHERE tabucenje.idrazred=$VRazred AND tabucenje.predmet=".$PredmetnikVsi[$i][0]." ORDER BY tabucenje.realizirano";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<td valign='top'>";
                        }else{
                            echo "<td valign='top' bgcolor='lightgrey'>";
                        }
                        echo "<a href='Predmeti.php?solskoleto=$VLeto&dodanpredmet=".$PredmetnikVsi[$i][0]."&dodanrazred=$VRazred&idsola=".$sola[$IndxSola][0]."'>+</a><br />";

                        //izpis izvedbe (učitelj, ur)
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["realizirano"] > 0){
                                echo $R["realizirano"].". <a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."<br />";
                            }else{
                                echo "<a href='Predmeti.php?id=3&id1=".$R["id"]."'>".$R["uciteljuntis"]." ".round($R["planirano"],2)."</a><br />";
                            }
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
            }
    }
}	
?>

</body>
</html>
