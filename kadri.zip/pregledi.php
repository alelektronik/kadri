<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
require('fpdf.php');

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";

$Danes=new DateTime("now");
$ActualMonth = $Danes->format('m');
$ActualYear = $Danes->format('Y');
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$ImeMes=array("jan","feb","mar","apr","maj","jun","jul","avg","sep","okt","nov","dec");

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}
function Faktor($x){
    switch ($x){
        case 1:
            return 4;
        case 2:
            return 4.2;
        case 3:
            return 4.4;
        case 4:
            return 4.8;
        case 5:
            return 5.2;
        case 6:
            return 5.2;
        case 7:
            return 5.8;
        case 8:
            return 6;
        case 9:
            return 6;
    }
}
function Arr2Str($a){
    $s="";
    if (count($a) > 0){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }
    return $s;
}
function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}
function PovpOc($x){
    $avg=0;
    $n=0;
    for ($Indx=0;$Indx < strlen($x);$Indx++){
        if (is_numeric(substr($x,$Indx,1))){
            $n=$n+1;
            $avg=$avg+substr($x,$Indx,1);
        }
    }
    return $avg;
}

function NOc($x){
    $n=0;
    for ($Indx=0;$Indx < strlen($x);$Indx++){
        if (is_numeric(substr($x,$Indx,1))){
            $n=$n+1;
        }
    }
    return $n;
}

function NegOc($x){
    $n=0;
    for ($Indx=0;$Indx < strlen($x);$Indx++){
        if (is_numeric(substr($x,$Indx,1))){
            if (substr($x,$Indx,1)=="1"){
                $n=$n+1;
            }
        }
    }
    return $n;
}
function Povprecje($idUcenec,$razred){
    global $link,$VLeto;
    
    if ($razred < 4){
        $Povprecje=5;
    }else{
        $SQL = "SELECT ocenakoncna FROM tabocene INNER JOIN TabPredmeti ON tabocene.idPredmet=TabPredmeti.id WHERE idUcenec=".$idUcenec." AND TabPredmeti.prioriteta=0 AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        
        $i=0;
        $vsota=0;
        $nez=false;
        while ($R = mysqli_fetch_array($result)){
            if (is_numeric($R["ocenakoncna"])){
                $vsota=$vsota+intval($R["ocenakoncna"]);
                if ($R["ocenakoncna"]==1){ 
                    $nez=true;
                }
                $i=$i+1;
            }
        }
        if ($i > 0){
            if ($nez){
                $Povprecje=1;
            }else{
                $Povprecje=($vsota/$i);
            }
        }else{
            $Povprecje=0;
        }
    }
    return $Povprecje;
}

function displayverticalgraph($strtitle,$strytitle,$strxtitle,$avalues,$alabels){
    /*
    '************************************************************************
    '           user customizeable values for different formats
    '            of the graph
    '             FREEWARE!!
    '    Just tell me if you are going to use it - info@cool.co.za
    '************************************************************************
    */
    $GRAPH_HEIGHT     = 300; //              'set up the graph height
    $GRAPH_WIDTH     = 400; //           'set up the graph width
    $GRAPH_SPACING     = 1;    
    $GRAPH_BORDER     = 0; //             'if you would like to see the borders to align things differently    
    $GRAPH_BARS     = 10; //             'loops through different colored bars e.g. 2 bars = gold,blue,gold,blue
    $USELOWVALUE     = FALSE; //         'this uses the low value of the array as the value of origin (default = 0)
    $SHOWLABELS     = TRUE; //          'set this to toggle whether or not the labels are shown
    $L_LABEL_SEPARATOR = " "; //            ' |Label
    $R_LABEL_SEPARATOR = " "; //            ' Label|
    $LABELSIZE     = -4; //            
    $GRAPHBORDERSIZE     = 1; //
    $INTIMGBORDER     = 1; //               'border around the bars
    $ALT_TEXT        = 3; //            'Changes the format of the alternate text of the bar image
    /*                        '1 = Labels ,2 = Values , 3 = Labels + Values , 4 = Percent

    '************************************************************************
    'array of different bars to loop through
    'you can change the order of these 
    'Count = 10 
    '"dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple"
    'cut and paste from here and insert into the agraph_bars array below Make sure the 
    'number specified in the const GRAPH_BARS is the same as or less than that in the array 
    ' 7 graph_bars <= 7 elements in array
    '************************************************************************
    */
    $agraph_bars = array("dark_green","red","gold","blue","pink","light_blue","light_gold","orange","green","purple");

    $intmax = 0;

    $ZgMeja=0;
    for ($i=0;$i < count($alabels);$i++){
        if (strlen($alabels[$i]) > 0){
            $ZgMeja=$ZgMeja+1;
        }
    }
    $ZgMeja=$ZgMeja-1;
    //'find the maximum value of the values array
    for ($i = 0;$i <= $ZgMeja;$i++){
        if ($intmax < $avalues[$i]){
            $intmax = $avalues[$i]; 
        }
    }
    if ($USELOWVALUE){
        $intmin = $avalues[0];
        for ($i = 0;$i <= $ZgMeja;$i++){
            if  ($intmin > $avalues[$i]){
                $intmin = $avalues[$i]; 
            }
        }
    }
    //'establish the graph multiplier
    if ($intmax==0) $intmax=1;
    $graphmultiplier = round($GRAPH_HEIGHT-100/$intmax);

    if ($ZgMeja+1==0){
        $imgwidth=16;
    }else{
        $imgwidth = round(300/($ZgMeja+1));
    }
    if ($imgwidth > 16) $imgwidth = 16;

    echo "<table class='graf' border ='".$GRAPH_BORDER."' width='".$GRAPH_WIDTH."' height='".$GRAPH_HEIGHT."'>";
        echo "<tr class='graf'>";
            echo "<td class='graf' rowspan='3' valign='middle'>".$strytitle."</td>";
            echo "<td class='graf' colspan='".($ZgMeja+2)."' height='50' align='center'><h4>".$strtitle."</h4></td>";
        echo "</tr>";
        $count = 0;
        echo "<tr class='graf'>";
            echo "<td class='graf'>";
                echo "<table class='graf' border='".$GRAPH_BORDER."' cellpadding = '0' cellspacing = '".$GRAPH_SPACING."'>";
                    echo "<tr class='graf'>";
                        echo "<TD class='graf' height='100%'>";
                            echo "<table class='graf' border='".$GRAPH_BORDER."' height='100%'>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='top' align='right'>".number_format($intmax,2)."</td>";
                                echo "</tr>";
                                echo "<tr class='graf'>";
                                    echo "<td class='graf' height='50%' valign='bottom' align='right'>";
                                     
                                    if ($USELOWVALUE){
                                        echo number_format($intmin,2);
                                    }else{
                                        echo "0";
                                    }
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                        echo "</td>";
                        echo "<td class='graf' valign='bottom' align='right'><img src='leftbord.gif' width='2' height='".($graphmultiplier+8)."'></td>";
                        
                    //    echo "<td class='graf' ><table class='graf' border=".$GRAPH_BORDER." height='100%'>";
                    //    echo "<tr>";
                                     
                        //             '*******************MAIN PART OF THE CHART************************************
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            $strgraph = $agraph_bars[$count];
                            if ($ALT_TEXT == 1){
                                $stralt = $alabels[$i];
                            }else{
                                if ($ALT_TEXT == 2){
                                    $stralt = $avalues[$i];
                                }else{
                                    if ($ALT_TEXT == 3){
                                        $stralt = $alabels[$i] ." - "  .$avalues[$i];
                                    }else{
                                        if ($ALT_TEXT == 4){
                                            $stralt = round($avalues[$i] /$intmax  *100,2) ."%";
                                        }
                                    }
                                }
                            }

                            if ($USELOWVALUE){
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round(($avalues[$i]-$intmin)/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            }else{
                                echo "<td class='graf' valign='bottom' align='center'>".$avalues[$i]."<br />";
                                echo "<img src='".$strgraph.".gif' height='".round($avalues[$i]/$intmax*$graphmultiplier,0)."' width='".$imgwidth."' alt='".$stralt."' border='".$INTIMGBORDER."'></td>";
                            } 
                                
                            if ($count == $GRAPH_BARS-1){
                                $count = 0;
                            }else{
                                $count = $count + 1;
                            }        
                        }
                    //    echo "</tr></table></td>";          
                        //            'write out the border at the bottom of the bars also leave a blank cell for spacing on the right
                        echo "<td class='graf' width='50'>&nbsp;</td>";
                    echo "</tr>";
                    echo "<tr class='graf'>";
                        echo "<td class='graf' width='8'>&nbsp;</td>";
                        echo "<td class='graf'>&nbsp;</td>";
                        echo "<td class='graf' colspan='" .($ZgMeja+1) ."' valign='top'>"."<img src='botbord.gif' width='100%' height='2'></td>";
                    echo "</tr>";
                    if ($SHOWLABELS){
                        echo "<tr class='graf'>";
                            echo "<th class='graf' width='8' height='1'>&nbsp;</th>";
                            echo "<th class='graf'>&nbsp;</th>";
                        for ($i = 0;$i <= $ZgMeja;$i++){
                            echo "<th class='graf' valign='top' align='center' width='".$imgwidth."'><font size='".$LABELSIZE."'>".$L_LABEL_SEPARATOR.$alabels[$i].$R_LABEL_SEPARATOR."</font></th>";
                        }
                        echo "</tr>";
                    }
                    echo "<tr class='graf'><td class='graf' colspan='".($ZgMeja+3)."' height='50' align='center'>".$strxtitle."</td>";
                    echo "</tr>";
                echo "</table>";
            echo "</td>";
        echo "</tr>";
        echo "<tr class='graf'>";
            echo "<td class='graf'></td>";
        echo"</tr>";
    echo "</table>";
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $Ucitelj=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    $VUporabnikIme=$R["Ime"]  . " " . $R["Priimek"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
if (!CheckDostop("StatUc",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["idd"])){
    $VSelect = $_POST["idd"];
}else{
    if (isset($_GET["idd"])){
        $VSelect=$_GET["idd"];
    }else{
        $VSelect = 0;
    }
}
if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}
if (isset($_POST["razred"])){
    $VRazred = $_POST["razred"];
}else{
    if (isset($_GET["razred"])){
        $VRazred=$_GET["razred"];
    }else{
        $VRazred = 0;
    }
}
if (isset($_POST["stucencev"])){
    $SteviloUcencev = $_POST["stucencev"];
}else{
    if (isset($_GET["stucencev"])){
        $SteviloUcencev=$_GET["stucencev"];
    }else{
        $SteviloUcencev = 0;
    }
}
echo "<html>";
echo "<head>";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
echo "<meta http-equiv='pragma' content='no-cache' > ";
echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
echo "<title>Vnosi in spiski";
echo "</title>";
echo "<style type='text/css'>";
echo ".break { page-break-before: always; }";
echo "input.groovybutton";
echo "{";
echo "   font-size:8px;";
echo "   font-weight:bold;";
echo "   width:18px;";
echo "}";
echo "</style>";
echo "</head>";
echo "<body>";
//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

switch ($VSelect){
    case "100": //učenci in razredniki
        if ($VecSol > 0){
            $SQL = "SELECT id,solakratko FROM tabsola";
            $result = mysqli_query($link,$SQL);
            $i=1;
            $sole=array();
            while ($R = mysqli_fetch_array($result)){
                $sole[$i][0]=$R["id"];
                $sole[$i][1]=$R["solakratko"];
                $i += 1;
            }
            $StSol=$i-1;
            for ($i=1;$i <= $StSol;$i++){
                echo "<h2>Razredi in razredniki za šolsko leto ".$VLeto."/".($VLeto+1)." - ".$sole[$i][1]."</h2>";

                $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
                $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabucenje.predmet=50 AND tabrazdat.idsola=".$sole[$i][0];
                $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);

                if (mysqli_num_rows($result) > 0){
                    //'Izpis v obliki spiska - zacetek -----------------------------------------------------------------------------------------------------------------------------------
                    $IndxRazrednik=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Razredniki[$IndxRazrednik][0]=$R["priimek"].", ".$R["ime"];
                        $Razredniki[$IndxRazrednik][1]=$R["razred"] . ". " . $R["oznaka"];
                        $Razredniki[$IndxRazrednik][2]=$R["razred"];
                        $Razredniki[$IndxRazrednik][3]=$R["oznaka"];
                        $Razredniki[$IndxRazrednik][5]=$R["id"];
                        $Razredniki[$IndxRazrednik][4]=$R["iducitelj"];
                        $Razredniki[$IndxRazrednik][6]="&nbsp";
                        $CountD[$IndxRazrednik]=0;
                        $CountF[$IndxRazrednik]=0;
                        $IndxRazrednik=$IndxRazrednik+1;
                    }

                    //ugotovi nadomestne razrednike
                    $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
                    $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                    $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sole[$i][0]." AND tabucenje.predmet=61";
                    $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                            if ($R["id"]==$Razredniki[$Indx][5]){
                                $Razredniki[$Indx][6]=$R["priimek"].", ".$R["ime"];
                            }
                        }
                    }

                    for ($Indx= 0;$Indx < $IndxRazrednik;$Indx++){
                        $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabucenci.spol,COUNT(tabucenci.spol) AS stuc,tabrazred.leto ";
                        $SQL = $SQL ."FROM ((tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                        $SQL = $SQL ."INNER JOIN tabucitelji ON tabrazred.iducitelj=tabucitelji.iducitelj) ";
                        $SQL = $SQL ."INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL = $SQL ."GROUP BY tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabucenci.spol,tabrazred.leto ";
                        $SQL = $SQL ."HAVING tabrazred.leto=".$VLeto." AND tabrazdat.id=".$Razredniki[$Indx][5];
                        $SQL = $SQL ." ORDER BY tabucenci.spol";
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            if ($R["spol"]=="M"){
                                $CountF[$Indx]=$R["stuc"];
                            }
                            if ($R["spol"]=="F"){
                                $CountD[$Indx]=$R["stuc"];
                            }
                        }
                    }

                    echo "<table border=1 cellspacing=0 cellpadding=5>";
                    echo "<tr bgcolor=lightcyan><th>Št.</th><th>Razred</th><th>Skupaj</th><th>Učencev</th><th>Učenk</th><th>Razrednik</th><th>Nadomestni<br />razrednik</th></tr>";
                    $Skupaj[0]=0;
                    $Skupaj[1]=0;
                    $Skupaj[2]=0;
                    $ColorChange=true;
                    $RazredCompare=$Razredniki[0][2];
                    for($Indx=0;$Indx < 10;$Indx++){
                        $SkupajR[$Indx][0]=0;
                        $SkupajR[$Indx][1]=0;
                        $SkupajR[$Indx][2]=0;
                    }
                    for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                        if ($RazredCompare != $Razredniki[$Indx][2]){
                            echo "<tr bgcolor=lightgreen>";
                            echo "<td>&nbsp;</td>";
                            echo "<td>&nbsp;</td>";
                            echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
                            echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
                            echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
                            echo "<td>&nbsp;</td>";
                            echo "<td>&nbsp;</td>";
                            echo "</tr>";
                            $RazredCompare=$Razredniki[$Indx][2];
                            $SkupajR[$RazredCompare][0]=0;
                            $SkupajR[$RazredCompare][1]=0;
                            $SkupajR[$RazredCompare][2]=0;
                        }
                        if ($ColorChange){
                            echo "<tr bgcolor=lightyellow>";
                        }else{
                            echo "<tr bgcolor=#FFFFCC>";
                        }
                        $ColorChange=!$ColorChange;
                        $SkupajR[$RazredCompare][0]=$SkupajR[$RazredCompare][0]+$CountD[$Indx]+$CountF[$Indx];
                        $SkupajR[$RazredCompare][1]=$SkupajR[$RazredCompare][1]+$CountF[$Indx];
                        $SkupajR[$RazredCompare][2]=$SkupajR[$RazredCompare][2]+$CountD[$Indx];
                        
                        echo "<td>".($Indx+1)."</td>";
                        echo "<td>".$Razredniki[$Indx][1]."</td>";
                        echo "<td align=center>".($CountF[$Indx]+$CountD[$Indx])."</td>";
                        echo "<td align=center>".$CountF[$Indx]."</td>";
                        echo "<td align=center>".$CountD[$Indx]."</td>";
                        echo "<td>".$Razredniki[$Indx][0]."</td>";
                        echo "<td>".$Razredniki[$Indx][6]."</td>";
                        echo "</tr>";
                        $Skupaj[1]=$Skupaj[1]+$CountF[$Indx];
                        $Skupaj[2]=$Skupaj[2]+$CountD[$Indx];
                        $Skupaj[0]=$Skupaj[0]+$CountF[$Indx]+$CountD[$Indx];
                    }

                    echo "<tr bgcolor=lightgreen>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
                    echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                    echo "</tr>";

                    echo "<tr bgcolor=lightgrey>";
                    echo "<td>Skupaj</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td align=center>".$Skupaj[0]."</td>";
                    echo "<td align=center>".$Skupaj[1]."</td>";
                    echo "<td align=center>".$Skupaj[2]."</td>";
                    echo "<td>&nbsp;</td>";
                    echo "<td>&nbsp;</td>";
                    echo "</tr>";

                    echo "</table>";
                }

                echo "<br />";
            }
            
        }else{
            echo "<h2>Razredi in razredniki za šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";

            $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
            $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
            $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabucenje.predmet=50";
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);

            if (mysqli_num_rows($result) > 0){
                //'Izpis v obliki spiska - zacetek -----------------------------------------------------------------------------------------------------------------------------------
                $IndxRazrednik=0;
                while ($R = mysqli_fetch_array($result)){
                    $Razredniki[$IndxRazrednik][0]=$R["priimek"].", ".$R["ime"];
                    $Razredniki[$IndxRazrednik][1]=$R["razred"] . ". " . $R["oznaka"];
                    $Razredniki[$IndxRazrednik][2]=$R["razred"];
                    $Razredniki[$IndxRazrednik][3]=$R["oznaka"];
                    $Razredniki[$IndxRazrednik][5]=$R["id"];
                    $Razredniki[$IndxRazrednik][4]=$R["iducitelj"];
                    $Razredniki[$IndxRazrednik][6]="&nbsp";
                    $CountD[$IndxRazrednik]=0;
                    $CountF[$IndxRazrednik]=0;
                    $IndxRazrednik=$IndxRazrednik+1;
                }

                //ugotovi nadomestne razrednike
                $SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tabucitelji.iducitelj,tabrazdat.* FROM "  ;
                $SQL = $SQL ."((tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) INNER JOIN tabucitelji ON tabucenje.IdUcitelj=tabucitelji.IdUcitelj) " ;
                $SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
                $SQL = $SQL ." WHERE tabrazdat.leto=".$VLeto." AND tabucenje.predmet=61";
                $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                        if ($R["id"]==$Razredniki[$Indx][5]){
                            $Razredniki[$Indx][6]=$R["priimek"].", ".$R["ime"];
                        }
                    }
                }

                for ($Indx= 0;$Indx < $IndxRazrednik;$Indx++){
                    /*
                    $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabucenci.spol,COUNT(tabucenci.spol) AS stuc,tabrazred.leto ";
                    $SQL = $SQL ."FROM ((tabrazred INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                    $SQL = $SQL ."INNER JOIN tabucitelji ON tabrazred.iducitelj=tabucitelji.iducitelj) ";
                    $SQL = $SQL ."INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                    $SQL = $SQL ."GROUP BY tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabucenci.spol,tabrazred.leto ";
                    $SQL = $SQL ."HAVING tabrazred.leto=".$VLeto." AND tabrazdat.id=".$Razredniki[$Indx][5];
                    $SQL = $SQL ." ORDER BY tabucenci.spol";
                    */
                    $SQL = "SELECT tabucenci.spol FROM (tabrazred ";
                    $SQL .= "INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec) ";
                    $SQL .= " WHERE tabrazred.leto=".$VLeto." AND tabrazred.iducitelj=".$Razredniki[$Indx]["4"];
                    $result = mysqli_query($link,$SQL);
                    $CountF[$Indx]=0;
                    $CountD[$Indx]=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["spol"]=="M"){
                            $CountF[$Indx] += 1; // $R["stuc"];
                        }
                        if ($R["spol"]=="F"){
                            $CountD[$Indx] += 1; //$R["stuc"];
                        }
                    }
                }

                echo "<table border=1 cellspacing=0 cellpadding=5>";
                echo "<tr bgcolor=lightcyan><th>Št.</th><th>Razred</th><th>Skupaj</th><th>Učencev</th><th>Učenk</th><th>Razrednik</th><th>Nadomestni<br />razrednik</th></tr>";
                $Skupaj[0]=0;
                $Skupaj[1]=0;
                $Skupaj[2]=0;
                $ColorChange=true;
                $RazredCompare=$Razredniki[0][2];
                $SkupajR[0][0]=0;
                $SkupajR[0][1]=0;
                $SkupajR[0][2]=0;
                $SkupajR[1][0]=0;
                $SkupajR[1][1]=0;
                $SkupajR[1][2]=0;
                for ($Indx=0;$Indx < $IndxRazrednik;$Indx++){
                    if ($RazredCompare != $Razredniki[$Indx][2]){
                        echo "<tr bgcolor=lightgreen>";
                        echo "<td>&nbsp;</td>";
                        echo "<td>&nbsp;</td>";
                        echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
                        echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
                        echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
                        echo "<td>&nbsp;</td>";
                        echo "<td>&nbsp;</td>";
                        echo "</tr>";
                        $RazredCompare=$Razredniki[$Indx][2];
                        $SkupajR[$RazredCompare][0]=0;
                        $SkupajR[$RazredCompare][1]=0;
                        $SkupajR[$RazredCompare][2]=0;
                    }
                    if ($ColorChange){
                        echo "<tr bgcolor=lightyellow>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC>";
                    }
                    $ColorChange=!$ColorChange;
                    $SkupajR[$RazredCompare][0]=$SkupajR[$RazredCompare][0]+$CountD[$Indx]+$CountF[$Indx];
                    $SkupajR[$RazredCompare][1]=$SkupajR[$RazredCompare][1]+$CountF[$Indx];
                    $SkupajR[$RazredCompare][2]=$SkupajR[$RazredCompare][2]+$CountD[$Indx];
                    
                    echo "<td>".($Indx+1)."</td>";
                    echo "<td>".$Razredniki[$Indx][1]."</td>";
                    echo "<td align=center>".($CountF[$Indx]+$CountD[$Indx])."</td>";
                    echo "<td align=center>".$CountF[$Indx]."</td>";
                    echo "<td align=center>".$CountD[$Indx]."</td>";
                    echo "<td>".$Razredniki[$Indx][0]."</td>";
                    echo "<td>".$Razredniki[$Indx][6]."</td>";
                    echo "</tr>";
                    $Skupaj[1]=$Skupaj[1]+$CountF[$Indx];
                    $Skupaj[2]=$Skupaj[2]+$CountD[$Indx];
                    $Skupaj[0]=$Skupaj[0]+$CountF[$Indx]+$CountD[$Indx];
                }

                echo "<tr bgcolor=lightgreen>";
                echo "<td>&nbsp;</td>";
                echo "<td>&nbsp;</td>";
                echo "<td align=center>".$SkupajR[$RazredCompare][0]."</td>";
                echo "<td align=center>".$SkupajR[$RazredCompare][1]."</td>";
                echo "<td align=center>".$SkupajR[$RazredCompare][2]."</td>";
                echo "<td>&nbsp;</td>";
                echo "<td>&nbsp;</td>";
                echo "</tr>";

                echo "<tr bgcolor=lightgrey>";
                echo "<td>Skupaj</td>";
                echo "<td>&nbsp;</td>";
                echo "<td align=center>".$Skupaj[0]."</td>";
                echo "<td align=center>".$Skupaj[1]."</td>";
                echo "<td align=center>".$Skupaj[2]."</td>";
                echo "<td>&nbsp;</td>";
                echo "<td>&nbsp;</td>";
                echo "</tr>";

                echo "</table>";
            }

            echo "<br />";
        }
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        break;
    case "200": //oddelki učenci - za statistiko
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            $SQL = "SELECT tabrazred.napredovanje,tabucenci.spol,tabrazdat.razred,tabrazdat.oznaka FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);
            
        //Vrste oddelkov in učenci v njih - začetek
            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 4;$j++){
                    $CountOddelki1[$i][$j]=0;
                    $CountUcenci1[$i][$j]=0;
                }
            }
        
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["oznaka"];
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                            $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                            $CountOddelki1[2][1]=$CountOddelki1[2][1]+1;
                            $CountOddelki1[2][3]=$CountOddelki1[2][3]+1;
                            $StrRazred=$StrRazred1;
                        }
                        $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                        $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                        $CountUcenci1[2][2]=$CountUcenci1[2][2]+1;
                        $CountUcenci1[2][4]=$CountUcenci1[2][4]+1;
                        break;
                    case 7:
                    case 8:
                    case 9:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                            $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                            $CountOddelki1[3][1]=$CountOddelki1[3][1]+1;
                            $CountOddelki1[3][3]=$CountOddelki1[3][3]+1;
                            $StrRazred=$StrRazred1;
                        }
                        $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                        $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                        $CountUcenci1[3][2]=$CountUcenci1[3][2]+1;
                        $CountUcenci1[3][4]=$CountUcenci1[3][4]+1;
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj (2+3)";
            $Rubrike14[2]="1.-6. razred";
            $Rubrike14[3]="7.-9. razred";
            echo "<b>1. Vrste oddelkov in učenci v njih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>ODDELKI</th><th>Št.</th><th>Skupaj</th><th></th><th>Čisti (nekombinirani)</th><th></th><th>kombinirani</th>";
            echo "<tr><td align=center></td><td></td><td align=center>Oddelki (3+5)</td><td align=center>Učenci (4+6)</td><td align=center>oddelki</td><td align=center>učenci</td><td align=center>oddelki</td><td align=center>učenci</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$CountOddelki1[$Indx][1]."</td><td align=center>".$CountUcenci1[$Indx][2]."</td><td align=center>".$CountOddelki1[$Indx][3]."</td><td align=center>".$CountUcenci1[$Indx][4]."</td><td></td><td></td></tr>";
            }
            echo "</table><br />";
        //Vrste oddelkov in učenci v njih - konec    

        //Učenci po razredih v programu 9-letne OŠ - začetek    
            $result = mysqli_query($link,$SQL);
            $StrRazred="";
            $Indx=0;
            for ($i=1;$i <= 20;$i++){
                for ($j=1;$j <= 10;$j++){
                    $CountOddelki3[$i][$j]=0;
                    $CountUcenci3[$i][$j]=0;
                }
            }
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["oznaka"];
                switch ($R["razred"]){
                    case 1:
                        if ($StrRazred != $StrRazred1){  //'oddelki
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1; //'vsi
                            $CountOddelki3[3][1]=$CountOddelki3[3][1]+1; // 'prvi razredi
                            $StrRazred=$StrRazred1;
                        }
                        
                        switch ($R["napredovanje"]){
                            case 0: // 'napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[4][3]=$CountUcenci3[4][3]+1; //učenke - 1. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[4][2]=$CountUcenci3[4][2]+1; //učenke - 1. razred - skupaj
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[4][9]=$CountUcenci3[4][9]+1; // učenke - opisno - 1. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[3][3]=$CountUcenci3[3][3]+1; //vsi - 1. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[3][2]=$CountUcenci3[3][2]+1; //vsi - 1. razred - skupaj
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                                $CountUcenci3[3][9]=$CountUcenci3[3][9]+1; //vsi - opisno - 1. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["Spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[4][3]=$CountUcenci3[4][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[4][2]=$CountUcenci3[4][2]+1;
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                                    $CountUcenci3[4][9]=$CountUcenci3[4][9]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[3][3]=$CountUcenci3[3][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[3][2]=$CountUcenci3[3][2]+1;
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                                $CountUcenci3[3][9]=$CountUcenci3[3][9]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["Spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[4][10]=$CountUcenci3[4][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[3][10]=$CountUcenci3[3][10]+1;
                                if ($R["Spol"]=="F"){
                                    $CountUcenci3[4][2]=$CountUcenci3[4][2]+1;
                                }
                                $CountUcenci3[3][2]=$CountUcenci3[3][2]+1;
                        }
                        break;
                    case 2:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[5][1]=$CountOddelki3[5][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[6][3]=$CountUcenci3[6][3]+1; //učenke - 2. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[6][2]=$CountUcenci3[6][2]+1; //učenke - 2. razred - skupaj
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[6][9]=$CountUcenci3[6][9]+1; // učenke - opisno - 2. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[5][3]=$CountUcenci3[5][3]+1; //vsi - 2. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[5][2]=$CountUcenci3[5][2]+1; //vsi - 2. razred - skupaj
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                                $CountUcenci3[5][9]=$CountUcenci3[5][9]+1; //vsi - opisno - 2. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[6][3]=$CountUcenci3[6][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[6][2]=$CountUcenci3[6][2]+1;
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                                    $CountUcenci3[6][9]=$CountUcenci3[6][9]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[5][3]=$CountUcenci3[5][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[5][2]=$CountUcenci3[5][2]+1;
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                                $CountUcenci3[5][9]=$CountUcenci3[5][9]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[6][10]=$CountUcenci3[6][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[5][10]=$CountUcenci3[5][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[6][2]=$CountUcenci3[6][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[5][2]=$CountUcenci3[5][2]+1;
                        }
                        break;
                    case 3:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[7][1]=$CountOddelki3[7][1]+1;
                            $StrRazred=$StrRazred1;
                        }
                        
                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[8][3]=$CountUcenci3[8][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[8][2]=$CountUcenci3[8][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[8][9]=$CountUcenci3[8][9]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[7][3]=$CountUcenci3[7][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[7][2]=$CountUcenci3[7][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1; //vsi - opisno - skupaj
                                $CountUcenci3[7][9]=$CountUcenci3[7][9]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[8][3]=$CountUcenci3[8][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[8][2]=$CountUcenci3[8][2]+1;
                                    $CountUcenci3[2][9]=$CountUcenci3[2][9]+1; //ocenjeni opisno
                                    $CountUcenci3[8][9]=$CountUcenci3[8][9]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[7][3]=$CountUcenci3[7][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[7][2]=$CountUcenci3[7][2]+1;
                                $CountUcenci3[1][9]=$CountUcenci3[1][9]+1;
                                $CountUcenci3[7][9]=$CountUcenci3[7][9]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[8][10]=$CountUcenci3[8][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[7][10]=$CountUcenci3[7][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[8][2]=$CountUcenci3[8][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[7][2]=$CountUcenci3[7][2]+1;
                        }
                        break;
                    case 4:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[9][1]=$CountOddelki3[9][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[10][3]=$CountUcenci3[10][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[10][2]=$CountUcenci3[10][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[10][4]=$CountUcenci3[10][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[9][3]=$CountUcenci3[9][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[9][2]=$CountUcenci3[9][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[9][4]=$CountUcenci3[9][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[10][3]=$CountUcenci3[10][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[10][2]=$CountUcenci3[10][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[10][4]=$CountUcenci3[10][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[9][3]=$CountUcenci3[9][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[9][2]=$CountUcenci3[9][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[9][4]=$CountUcenci3[9][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[10][10]=$CountUcenci3[10][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[9][10]=$CountUcenci3[9][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[10][2]=$CountUcenci3[10][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[9][2]=$CountUcenci3[9][2]+1;
                        }
                        break;
                    case 5:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[11][1]=$CountOddelki3[11][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[12][3]=$CountUcenci3[12][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[12][2]=$CountUcenci3[12][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[12][4]=$CountUcenci3[12][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[11][3]=$CountUcenci3[11][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[11][2]=$CountUcenci3[11][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[11][4]=$CountUcenci3[11][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[12][3]=$CountUcenci3[12][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[12][2]=$CountUcenci3[12][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[12][4]=$CountUcenci3[12][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[11][3]=$CountUcenci3[11][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[11][2]=$CountUcenci3[11][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[11][4]=$CountUcenci3[11][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[12][10]=$CountUcenci3[12][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[11][10]=$CountUcenci3[11][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[12][2]=$CountUcenci3[12][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[11][2]=$CountUcenci3[11][2]+1;
                        }
                        break;
                    case 6:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[13][1]=$CountOddelki3[13][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[14][3]=$CountUcenci3[14][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[14][2]=$CountUcenci3[14][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[14][4]=$CountUcenci3[14][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[13][3]=$CountUcenci3[13][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[13][2]=$CountUcenci3[13][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[13][4]=$CountUcenci3[13][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[14][3]=$CountUcenci3[14][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[14][2]=$CountUcenci3[14][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[14][4]=$CountUcenci3[14][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[13][3]=$CountUcenci3[13][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[13][2]=$CountUcenci3[13][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[13][4]=$CountUcenci3[13][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[14][10]=$CountUcenci3[14][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[13][10]=$CountUcenci3[13][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[14][2]=$CountUcenci3[14][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[13][2]=$CountUcenci3[13][2]+1;
                        }
                        break;
                    case 7:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[15][1]=$CountOddelki3[15][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[16][3]=$CountUcenci3[16][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[16][2]=$CountUcenci3[16][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[16][4]=$CountUcenci3[16][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[15][3]=$CountUcenci3[15][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[15][2]=$CountUcenci3[15][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[15][4]=$CountUcenci3[15][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[16][3]=$CountUcenci3[16][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[16][2]=$CountUcenci3[16][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[16][4]=$CountUcenci3[16][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[15][3]=$CountUcenci3[15][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[15][2]=$CountUcenci3[15][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[15][4]=$CountUcenci3[15][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[16][10]=$CountUcenci3[16][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[15][10]=$CountUcenci3[15][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[16][2]=$CountUcenci3[16][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[15][2]=$CountUcenci3[15][2]+1;
                        }
                        break;
                    case 8:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[17][1]=$CountOddelki3[17][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[18][3]=$CountUcenci3[18][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[18][2]=$CountUcenci3[18][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[18][4]=$CountUcenci3[18][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[17][3]=$CountUcenci3[17][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[17][2]=$CountUcenci3[17][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[17][4]=$CountUcenci3[17][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[18][3]=$CountUcenci3[18][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[18][2]=$CountUcenci3[18][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[18][4]=$CountUcenci3[18][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[17][3]=$CountUcenci3[17][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[17][2]=$CountUcenci3[17][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[17][4]=$CountUcenci3[17][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[18][10]=$CountUcenci3[18][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[17][10]=$CountUcenci3[17][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[18][2]=$CountUcenci3[18][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[17][2]=$CountUcenci3[17][2]+1;
                        }
                        break;
                    case 9:
                        if ($StrRazred != $StrRazred1){
                            $CountOddelki3[1][1]=$CountOddelki3[1][1]+1;
                            $CountOddelki3[19][1]=$CountOddelki3[19][1]+1;
                            $StrRazred=$StrRazred1;
                        }

                        switch ($R["napredovanje"]){
                            case 0: //napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1; //učenke - skupaj
                                    $CountUcenci3[20][3]=$CountUcenci3[20][3]+1; //učenke - 3. razred - izdelali skupaj
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; //učenke - skupaj
                                    $CountUcenci3[20][2]=$CountUcenci3[20][2]+1; //učenke - 3. razred - skupaj
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; // učenke - opisno - skupaj
                                    $CountUcenci3[20][4]=$CountUcenci3[20][4]+1; // učenke - opisno - 3. razred
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1; //vsi - izdelali - skupaj
                                $CountUcenci3[19][3]=$CountUcenci3[19][3]+1; //vsi - 3. razred - izdelali skupaj
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1; //vsi - skupaj
                                $CountUcenci3[19][2]=$CountUcenci3[19][2]+1; //vsi - 3. razred - skupaj
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1; //vsi - opisno - skupaj
                                $CountUcenci3[19][4]=$CountUcenci3[19][4]+1; //vsi - opisno - 3. razred
                                break;
                            case 1: //napreduje z negativno
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                                    $CountUcenci3[20][3]=$CountUcenci3[20][3]+1;
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1; 
                                    $CountUcenci3[20][2]=$CountUcenci3[20][2]+1;
                                    $CountUcenci3[2][4]=$CountUcenci3[2][4]+1; //ocenjeni opisno
                                    $CountUcenci3[20][4]=$CountUcenci3[20][4]+1;
                                }
                                $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                                $CountUcenci3[19][3]=$CountUcenci3[19][3]+1;
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[19][2]=$CountUcenci3[19][2]+1;
                                $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                                $CountUcenci3[19][4]=$CountUcenci3[19][4]+1;
                                break;
                            case 2: //ne napreduje
                                if ($R["spol"]=="F"){
                                    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[2][10]=$CountUcenci3[2][10]+1;
                                    $CountUcenci3[20][10]=$CountUcenci3[19][10]+1;
                                }
                                $CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[1][10]=$CountUcenci3[1][10]+1;
                                $CountUcenci3[19][10]=$CountUcenci3[19][10]+1;
                                if ($R["spol"]=="F"){
                                //    $CountUcenci3[2][2]=$CountUcenci3[2][2]+1;
                                    $CountUcenci3[20][2]=$CountUcenci3[20][2]+1;
                                }
                                //$CountUcenci3[1][2]=$CountUcenci3[1][2]+1;
                                $CountUcenci3[19][2]=$CountUcenci3[19][2]+1;
                        }
                    }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj - Vsi";
            $Rubrike14[2]="Skupaj - učenke";
            $Rubrike14[3]="1. razred - vsi";
            $Rubrike14[4]="učenke";
            $Rubrike14[5]="2. razred - vsi";
            $Rubrike14[6]="učenke";
            $Rubrike14[7]="3. razred - vsi";
            $Rubrike14[8]="učenke";
            $Rubrike14[9]="4. razred - vsi";
            $Rubrike14[10]="učenke";
            $Rubrike14[11]="5. razred - vsi";
            $Rubrike14[12]="učenke";
            $Rubrike14[13]="6. razred - vsi";
            $Rubrike14[14]="učenke";
            $Rubrike14[15]="7. razred - vsi";
            $Rubrike14[16]="učenke";
            $Rubrike14[17]="8. razred - vsi";
            $Rubrike14[18]="učenke";
            $Rubrike14[19]="9. razred - vsi";
            $Rubrike14[20]="učenke";
            echo "<b>2. Učenci po razredih in uspehu ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>RAZREDI</th><th>Št.</th><th>Število čistih oddelkov</th><th>Učenci - skupaj<br />v čistih in <br />kombiniranih oddelkih)<br /> (3+5)</th><th>Napredujejo</th><th></th><th>Ne napredujejo</th>";
            echo "<tr><td align=center></td><td></td><td align=center></td><td align=center></td><td align=center>skupaj</td><td align=center>od tega z negativno oceno</td><td></td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
            for ($Indx=1;$Indx <= 20;$Indx++){
                echo "<tr><td align='right'>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountOddelki3[$Indx][1]."</td>"; //oddelki
                echo "<td align=center>".$CountUcenci3[$Indx][2]."</td>"; //vsi učenci
                echo "<td align=center>".$CountUcenci3[$Indx][3]."</td>"; //izdelali razred - skupaj
                echo "<td align=center>".$CountUcenci3[$Indx][8]."</td>"; //zadostni z negativno
                echo "<td align=center>".$CountUcenci3[$Indx][10]."</td>"; //niso izdelali
                echo "</tr>";
            }
            echo "</table><br />";
        //Učenci po razredih v programu 9-letne OŠ - konec

        //Učenci zaključnega razreda s popravnim izpitom - začetek    
            $SQL = "SELECT tabrazdat.idsola,tabocene.leto,tabocene.iducenec,tabocene.popravni,count(tabocene.popravni) as stpopravcev,tabrazred.razred,tabrazred.uspeh FROM ";
            $SQL = $SQL . "(tabocene INNER JOIN tabrazred ON tabocene.IdUcenec=tabrazred.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "GROUP BY tabrazdat.idsola,tabocene.leto,tabrazred.Razred,tabrazred.uspeh,tabocene.IdUcenec,tabocene.Popravni ";
            $SQL = $SQL . "HAVING tabocene.leto=".$VLeto." AND tabocene.Popravni=1 AND tabrazred.Razred=9"." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $result = mysqli_query($link,$SQL);
            $Indx=0;
            for ($i=1;$i <= 2;$i++){
                for ($j=1;$j <= 6;$j++){
                    $CountUcenci5[$i][$j]=0;
                }
            }
            while ($R = mysqli_fetch_array($result)){
                switch ($R["stpopravcev"]){
                    case 1:
                        $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                        $CountUcenci5[2][2]=$CountUcenci5[2][2]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                        }
                        break;
                    case 2:
                        $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                        $CountUcenci5[2][3]=$CountUcenci5[2][3]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                        }
                        break;
                    case 3:
                        $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                        $CountUcenci5[2][4]=$CountUcenci5[2][4]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                        }
                        break;
                    default:
                        $CountUcenci5[2][1]=$CountUcenci5[2][1]+1;
                        $CountUcenci5[2][5]=$CountUcenci5[2][5]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci5[2][6]=$CountUcenci5[2][6]+1;
                        }
                }
                $Indx=$Indx+1;
            }
            $Rubrike14[1]=" ";
            $Rubrike14[2]="Skupaj";
            echo "<b>4. Učenci zaključnega razreda s popravnim izpitom ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th></th><th>Št.</th><th>Imajo popravni izpit</th><th></th><th></th><th></th><th></th><th>Opravili popravni izpit</th>";
            echo "<tr><td align=center></td><td></td><td align=center>Skupaj (2 do 5)</td><td align=center>Iz 1 predmeta</td><td align=center>Iz 2 predmetov</td><td align=center>Iz 3 predmetov</td><td align=center>Iz 4 ali več predmetov</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
            for ($Indx=2;$Indx <= 2;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".($Indx-1)."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci5[$Indx][6]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
            
        //Učenci zaključnega razreda s popravnim izpitom - konec
            
        //Učenci s posebnimi potrebami - začetek    
            $SQL = "SELECT tabrazred.uspeh,tabucenci.idposebnepotrebe,tabrazdat.razred FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL ." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 18;$i++){
                for ($j=1;$j <= 10;$j++){
                    $CountUcenci7[$i][$j]=0;
                }
            }
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["razred"]){
                    case 1:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][2]=$CountUcenci7[2][2]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][2]=$CountUcenci7[1][2]+1;
                            }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][2]=$CountUcenci7[4][2]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][2]=$CountUcenci7[3][2]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][2]=$CountUcenci7[6][2]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][2]=$CountUcenci7[5][2]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][2]=$CountUcenci7[8][2]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][2]=$CountUcenci7[7][2]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][2]=$CountUcenci7[10][2]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][2]=$CountUcenci7[9][2]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][2]=$CountUcenci7[12][2]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][2]=$CountUcenci7[11][2]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][2]=$CountUcenci7[14][2]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][2]=$CountUcenci7[13][2]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][2]=$CountUcenci7[16][2]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][2]=$CountUcenci7[15][2]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][2]=$CountUcenci7[18][2]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][2]=$CountUcenci7[17][2]+1;
                            }
                        break;
                    case 2:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][3]=$CountUcenci7[2][3]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][3]=$CountUcenci7[1][3]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][3]=$CountUcenci7[4][3]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][3]=$CountUcenci7[3][3]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][3]=$CountUcenci7[6][3]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][3]=$CountUcenci7[5][3]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][3]=$CountUcenci7[8][3]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][3]=$CountUcenci7[7][3]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][3]=$CountUcenci7[10][3]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][3]=$CountUcenci7[9][3]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][3]=$CountUcenci7[12][3]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][3]=$CountUcenci7[11][3]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][3]=$CountUcenci7[14][3]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][3]=$CountUcenci7[13][3]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][3]=$CountUcenci7[16][3]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][3]=$CountUcenci7[15][3]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][3]=$CountUcenci7[18][3]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][3]=$CountUcenci7[17][3]+1;
                        }
                        break;
                    case 3:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][4]=$CountUcenci7[2][4]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][4]=$CountUcenci7[1][4]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][4]=$CountUcenci7[4][4]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][4]=$CountUcenci7[3][4]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][4]=$CountUcenci7[6][4]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][4]=$CountUcenci7[5][4]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][4]=$CountUcenci7[8][4]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][4]=$CountUcenci7[7][4]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][4]=$CountUcenci7[10][4]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][4]=$CountUcenci7[9][4]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][4]=$CountUcenci7[12][4]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][4]=$CountUcenci7[11][4]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][4]=$CountUcenci7[14][4]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][4]=$CountUcenci7[13][4]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][4]=$CountUcenci7[16][4]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][4]=$CountUcenci7[15][4]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][4]=$CountUcenci7[18][4]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][4]=$CountUcenci7[17][4]+1;
                        }
                        break;
                    case 4:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][5]=$CountUcenci7[2][5]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][5]=$CountUcenci7[1][5]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][5]=$CountUcenci7[4][5]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][5]=$CountUcenci7[3][5]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][5]=$CountUcenci7[6][5]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][5]=$CountUcenci7[5][5]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][5]=$CountUcenci7[8][5]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][5]=$CountUcenci7[7][5]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][5]=$CountUcenci7[10][5]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][5]=$CountUcenci7[9][5]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][5]=$CountUcenci7[12][5]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][5]=$CountUcenci7[11][5]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][5]=$CountUcenci7[14][5]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][5]=$CountUcenci7[13][5]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][5]=$CountUcenci7[16][5]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][5]=$CountUcenci7[15][5]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][5]=$CountUcenci7[18][5]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][5]=$CountUcenci7[17][5]+1;
                        }
                        break;
                    case 5:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][6]=$CountUcenci7[2][6]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][6]=$CountUcenci7[1][6]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][6]=$CountUcenci7[4][6]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][6]=$CountUcenci7[3][6]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][6]=$CountUcenci7[6][6]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][6]=$CountUcenci7[5][6]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][6]=$CountUcenci7[8][6]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][6]=$CountUcenci7[7][6]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][6]=$CountUcenci7[10][6]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][6]=$CountUcenci7[9][6]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][6]=$CountUcenci7[12][6]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][6]=$CountUcenci7[11][6]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][6]=$CountUcenci7[14][6]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][6]=$CountUcenci7[13][6]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][6]=$CountUcenci7[16][6]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][6]=$CountUcenci7[15][6]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][6]=$CountUcenci7[18][6]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][6]=$CountUcenci7[17][6]+1;
                        }
                        break;
                    case 6:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][7]=$CountUcenci7[2][7]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][7]=$CountUcenci7[1][7]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][7]=$CountUcenci7[4][7]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][7]=$CountUcenci7[3][7]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][7]=$CountUcenci7[6][7]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][7]=$CountUcenci7[5][7]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][7]=$CountUcenci7[8][7]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][7]=$CountUcenci7[7][7]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][7]=$CountUcenci7[10][7]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][7]=$CountUcenci7[9][7]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][7]=$CountUcenci7[12][7]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][7]=$CountUcenci7[11][7]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][7]=$CountUcenci7[14][7]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][7]=$CountUcenci7[13][7]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][7]=$CountUcenci7[16][7]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][7]=$CountUcenci7[15][7]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][7]=$CountUcenci7[18][7]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][7]=$CountUcenci7[17][7]+1;
                        }
                        break;
                    case 7:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][8]=$CountUcenci7[2][8]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][8]=$CountUcenci7[1][8]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][8]=$CountUcenci7[4][8]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][8]=$CountUcenci7[3][8]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][8]=$CountUcenci7[6][8]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][8]=$CountUcenci7[5][8]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][8]=$CountUcenci7[8][8]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][8]=$CountUcenci7[7][8]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][8]=$CountUcenci7[10][8]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][8]=$CountUcenci7[9][8]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][8]=$CountUcenci7[12][8]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][8]=$CountUcenci7[11][8]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][8]=$CountUcenci7[14][8]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][8]=$CountUcenci7[13][8]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][8]=$CountUcenci7[16][8]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][8]=$CountUcenci7[15][8]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][8]=$CountUcenci7[18][8]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][8]=$CountUcenci7[17][8]+1;
                        }
                        break;
                    case 8:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][9]=$CountUcenci7[2][9]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][9]=$CountUcenci7[1][9]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][9]=$CountUcenci7[4][9]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][9]=$CountUcenci7[3][9]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][9]=$CountUcenci7[6][9]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][9]=$CountUcenci7[5][9]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][9]=$CountUcenci7[8][9]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][9]=$CountUcenci7[7][9]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][9]=$CountUcenci7[10][9]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][9]=$CountUcenci7[9][9]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][9]=$CountUcenci7[12][9]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][9]=$CountUcenci7[11][9]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][9]=$CountUcenci7[14][9]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][9]=$CountUcenci7[13][9]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][9]=$CountUcenci7[16][9]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][9]=$CountUcenci7[15][9]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][9]=$CountUcenci7[18][9]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][9]=$CountUcenci7[17][9]+1;
                        }
                        break;
                    case 9:
                        if ($R["idposebnepotrebe"] > 1){
                            if ($R["uspeh"] > 1){
                                $CountUcenci7[2][1]=$CountUcenci7[2][1]+1;
                                $CountUcenci7[2][10]=$CountUcenci7[2][10]+1;
                            }
                            $CountUcenci7[1][1]=$CountUcenci7[1][1]+1;
                            $CountUcenci7[1][10]=$CountUcenci7[1][10]+1;
                        }
                        switch ($R["idposebnepotrebe"]){
                            case 2:    //slepi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[4][1]=$CountUcenci7[4][1]+1;
                                    $CountUcenci7[4][10]=$CountUcenci7[4][10]+1;
                                }
                                $CountUcenci7[3][1]=$CountUcenci7[3][1]+1;
                                $CountUcenci7[3][10]=$CountUcenci7[3][10]+1;
                                break;
                            case 3:    //gluhi
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[6][1]=$CountUcenci7[6][1]+1;
                                    $CountUcenci7[6][10]=$CountUcenci7[6][10]+1;
                                }
                                $CountUcenci7[5][1]=$CountUcenci7[5][1]+1;
                                $CountUcenci7[5][10]=$CountUcenci7[5][10]+1;
                                break;
                            case 4:    //govorne motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[8][1]=$CountUcenci7[8][1]+1;
                                    $CountUcenci7[8][10]=$CountUcenci7[8][10]+1;
                                }
                                $CountUcenci7[7][1]=$CountUcenci7[7][1]+1;
                                $CountUcenci7[7][10]=$CountUcenci7[7][10]+1;
                                break;
                            case 5:    //vedenjske motnje
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[10][1]=$CountUcenci7[10][1]+1;
                                    $CountUcenci7[10][10]=$CountUcenci7[10][10]+1;
                                }
                                $CountUcenci7[9][1]=$CountUcenci7[9][1]+1;
                                $CountUcenci7[9][10]=$CountUcenci7[9][10]+1;
                                break;
                            case 6:    //gibalno ovirani
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[12][1]=$CountUcenci7[12][1]+1;
                                    $CountUcenci7[12][10]=$CountUcenci7[12][10]+1;
                                }
                                $CountUcenci7[11][1]=$CountUcenci7[11][1]+1;
                                $CountUcenci7[11][10]=$CountUcenci7[11][10]+1;
                                break;
                            case 7:    //dolgotrajno bolni
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[14][1]=$CountUcenci7[14][1]+1;
                                    $CountUcenci7[14][10]=$CountUcenci7[14][10]+1;
                                }
                                $CountUcenci7[13][1]=$CountUcenci7[13][1]+1;
                                $CountUcenci7[13][10]=$CountUcenci7[13][10]+1;
                                break;
                            case 8:    //primanjkljaj
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[16][1]=$CountUcenci7[16][1]+1;
                                    $CountUcenci7[16][10]=$CountUcenci7[16][10]+1;
                                }
                                $CountUcenci7[15][1]=$CountUcenci7[15][1]+1;
                                $CountUcenci7[15][10]=$CountUcenci7[15][10]+1;
                                break;
                            case 9:    //mejne intelektualne sposobnosti
                                if ($R["uspeh"] > 1){
                                    $CountUcenci7[18][1]=$CountUcenci7[18][1]+1;
                                    $CountUcenci7[18][10]=$CountUcenci7[18][10]+1;
                                }
                                $CountUcenci7[17][1]=$CountUcenci7[17][1]+1;
                                $CountUcenci7[17][10]=$CountUcenci7[17][10]+1;
                        }
                    }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj - vsi";
            $Rubrike14[2]="napredujejo";
            $Rubrike14[3]="Slepi in slabovidni - vsi";
            $Rubrike14[4]="napredujejo";
            $Rubrike14[5]="Gluhi in naglušni - vsi";
            $Rubrike14[6]="napredujejo";
            $Rubrike14[7]="Otroci z govorno-jezikovnimi motnjami - vsi";
            $Rubrike14[8]="napredujejo";
            $Rubrike14[9]="Otroci s čustvenimi in vedenjskimi motnjami - vsi";
            $Rubrike14[10]="napredujejo";
            $Rubrike14[11]="Gibalno ovirani otroci - vsi";
            $Rubrike14[12]="napredujejo";
            $Rubrike14[13]="Dolgotrajno bolni otroci - vsi";
            $Rubrike14[14]="napredujejo";
            $Rubrike14[15]="Otroci s primanjkljaji na posameznih področjih - vsi";
            $Rubrike14[16]="napredujejo";
            $Rubrike14[17]="Otroci z mejnimi intelektualnimi sposobnostmi - vsi";
            $Rubrike14[18]="napredujejo";
            echo "<b>6. Učenci s posebnimi potrebami, ki so vključeni v prilagojeno izvajanje z dodatno strokovno pomočjo v redne oddelke programov 8-letne in 9-letne OŠ ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>UČENCI GLEDE NA VRSTO MOTNJE</th><th>Št.</th><th>Skupaj (2-10)</th><th>1. razred<th>2. razred</th><th>3. razred</th><th>4. razred</th><th>5. razred</th><th>6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td></tr>";
            for ($Indx=1;$Indx <= 18;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][6]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][7]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][8]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][9]."</td>";
                echo "<td align=center>".$CountUcenci7[$Indx][10]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //Učenci s posebnimi potrebami - konec

        //Učenci, ki so obiskovali šolo deveto leto, po razredih  - začetek    
            $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja = 9 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 6;$j++){
                    $CountUcenci9[$i][$j]=0;
                }
            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                        $CountUcenci9[1][3]=$CountUcenci9[1][3]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                            $CountUcenci9[2][3]=$CountUcenci9[2][3]+1;
                        }else{
                            $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                            $CountUcenci9[3][3]=$CountUcenci9[3][3]+1;
                        }
                        break;
                    case 7:
                        $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                        $CountUcenci9[1][4]=$CountUcenci9[1][4]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                            $CountUcenci9[2][4]=$CountUcenci9[2][4]+1;
                        }else{
                            $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                            $CountUcenci9[3][4]=$CountUcenci9[3][4]+1;
                        }
                        break;
                    case 8:
                        $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                        $CountUcenci9[1][5]=$CountUcenci9[1][5]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                            $CountUcenci9[2][5]=$CountUcenci9[2][5]+1;
                        }else{
                            $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                            $CountUcenci9[3][5]=$CountUcenci9[3][5]+1;
                        }
                        break;
                    case 9:
                        $CountUcenci9[1][1]=$CountUcenci9[1][1]+1;
                        $CountUcenci9[1][6]=$CountUcenci9[1][6]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci9[2][1]=$CountUcenci9[2][1]+1;
                            $CountUcenci9[2][6]=$CountUcenci9[2][6]+1;
                        }else{
                            $CountUcenci9[3][1]=$CountUcenci9[3][1]+1;
                            $CountUcenci9[3][6]=$CountUcenci9[3][6]+1;
                        }
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
            $Rubrike14[2]="napredujejo";
            $Rubrike14[3]="ne napredujejo";
            $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
            echo "<b>7. Učenci, ki so obiskovali šolo devet let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci9[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci9[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci9[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci9[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci9[$Indx][6]."</td>";
                echo "</tr>";
            }
            echo "<tr><td>".$Rubrike14[4]."</td>";
            echo "<td align='center'>4</td>";
            echo "<td align=center>".$CountUcenci9[3][1]."</td>";
            echo "<td align=center>".$CountUcenci9[3][3]."</td>";
            echo "<td align=center>".$CountUcenci9[3][4]."</td>";
            echo "<td align=center>".$CountUcenci9[3][5]."</td>";
            echo "<td align=center>".$CountUcenci9[3][6]."</td>";
            echo "</tr>";
            echo "</table><br />";
        //Učenci, ki so obiskovali šolo deveto leto, po razredih - konec

        //Učenci, ki so obiskovali šolo deseto leto, po razredih  - začetek    
            $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja=10 ";
            $SQL = $SQL . "ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 6;$j++){
                    $CountUcenci10[$i][$j]=0;
                }
            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                        $CountUcenci10[1][3]=$CountUcenci10[1][3]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                            $CountUcenci10[2][3]=$CountUcenci10[2][3]+1;
                        }else{
                            $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                            $CountUcenci10[3][3]=$CountUcenci10[3][3]+1;
                        }
                        break;
                    case 7:
                        $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                        $CountUcenci10[1][4]=$CountUcenci10[1][4]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                            $CountUcenci10[2][4]=$CountUcenci10[2][4]+1;
                        }else{
                            $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                            $CountUcenci10[3][4]=$CountUcenci10[3][4]+1;
                        }
                        break;
                    case 8:
                        $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                        $CountUcenci10[1][5]=$CountUcenci10[1][5]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                            $CountUcenci10[2][5]=$CountUcenci10[2][5]+1;
                        }else{
                            $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                            $CountUcenci10[3][5]=$CountUcenci10[3][5]+1;
                        }
                        break;
                    case 9:
                        $CountUcenci10[1][1]=$CountUcenci10[1][1]+1;
                        $CountUcenci10[1][6]=$CountUcenci10[1][6]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci10[2][1]=$CountUcenci10[2][1]+1;
                            $CountUcenci10[2][6]=$CountUcenci10[2][6]+1;
                        }else{
                            $CountUcenci10[3][1]=$CountUcenci10[3][1]+1;
                            $CountUcenci10[3][6]=$CountUcenci10[3][6]+1;
                        }
                    }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
            $Rubrike14[2]="napredujejo";
            $Rubrike14[3]="ne napredujejo";
            $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
            echo "<b>8. Učenci, ki so obiskovali šolo deset let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci10[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci10[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci10[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci10[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci10[$Indx][6]."</td>";
                echo "</tr>";
            }
            echo "<tr><td>".$Rubrike14[4]."</td>";
            echo "<td align=center>4</td>";
            echo "<td align=center>".$CountUcenci10[3][1]."</td>";
            echo "<td align=center>".$CountUcenci10[3][3]."</td>";
            echo "<td align=center>".$CountUcenci10[3][4]."</td>";
            echo "<td align=center>".$CountUcenci10[3][5]."</td>";
            echo "<td align=center>".$CountUcenci10[3][6]."</td>";
            echo "</tr>";
            echo "</table><br />";
        //Učenci, ki so obiskovali šolo deseto leto, po razredih - konec

        //Učenci, ki so obiskovali šolo enajsto leto, po razredih  - začetek    
            $SQL = "SELECT tabrazred.uspeh,tabrazdat.razred FROM ";
            $SQL = $SQL . "(tabrazred INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND LetoSolanja=11"." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 6;$j++){
                    $CountUcenci8[$i][$j]=0;
                }
            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
               switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                        $CountUcenci8[1][3]=$CountUcenci8[1][3]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                            $CountUcenci8[2][3]=$CountUcenci8[2][3]+1;
                        }else{
                            $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                            $CountUcenci8[3][3]=$CountUcenci8[3][3]+1;
                        }
                        break;
                    case 7:
                        $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                        $CountUcenci8[1][4]=$CountUcenci8[1][4]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                            $CountUcenci8[2][4]=$CountUcenci8[2][4]+1;
                        }else{
                            $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                            $CountUcenci8[3][4]=$CountUcenci8[3][4]+1;
                        }
                        break;
                    case 8:
                        $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                        $CountUcenci8[1][5]=$CountUcenci8[1][5]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                            $CountUcenci8[2][5]=$CountUcenci8[2][5]+1;
                        }else{
                            $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                            $CountUcenci8[3][5]=$CountUcenci8[3][5]+1;
                        }
                        break;
                    case 9:
                        $CountUcenci8[1][1]=$CountUcenci8[1][1]+1;
                        $CountUcenci8[1][6]=$CountUcenci8[1][6]+1;
                        if ($R["uspeh"] > 1){
                            $CountUcenci8[2][1]=$CountUcenci8[2][1]+1;
                            $CountUcenci8[2][6]=$CountUcenci8[2][6]+1;
                        }else{
                            $CountUcenci8[3][1]=$CountUcenci8[3][1]+1;
                            $CountUcenci8[3][6]=$CountUcenci8[3][6]+1;
                        }
                    }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj (Vrstica 01=02+03)";
            $Rubrike14[2]="napredujejo";
            $Rubrike14[3]="ne napredujejo";
            $Rubrike14[4]="Zaključili osnovnošolsko izobraževanje BREZ končane osnovne šole";
            echo "<b>9. Učenci, ki so obiskovali šolo enajst let, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>UČENCI</th><th>Št.</th><th>Skupaj (2-5)</th><th>od 1. do 6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci8[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci8[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci8[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci8[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci8[$Indx][6]."</td>";
                echo "</tr>";
            }
            echo "<tr><td>".$Rubrike14[4]."</td>";
            echo "<td align=center>4</td>";
            echo "<td align=center>".$CountUcenci8[3][1]."</td>";
            echo "<td align=center>".$CountUcenci8[3][3]."</td>";
            echo "<td align=center>".$CountUcenci8[3][4]."</td>";
            echo "<td align=center>".$CountUcenci8[3][5]."</td>";
            echo "<td align=center>".$CountUcenci8[3][6]."</td>";
            echo "</tr>";
            echo "</table><br />";
        //Učenci, ki so obiskovali šolo enajsto leto, po razredih - konec

        //Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika - začetek    
            $SQL = "SELECT DISTINCT tabucenje.razred,tabpredmeti.kodamss,tabrazred.iducenec FROM (((tabucenje ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabucenje.idrazred=tabrazred.idrazred) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id) ";
            $SQL = $SQL . "INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec) ";
            $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabpredmeti.kodamss IN ('TJA','TJN')"." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazred.razred,tabrazred.paralelka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 4;$i++){
                for ($j=1;$j <= 10;$j++){
                    $CountUcenci12[$i][$j]=0;
                }
            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["kodamss"])){
                    switch ($R["razred"]){
                        case 1:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[4][2]=$CountUcenci12[4][2]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[2][2]=$CountUcenci12[2][2]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                    $CountUcenci12[3][2]=$CountUcenci12[3][2]+1;
                            }
                            break;
                        case 2:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[4][3]=$CountUcenci12[4][3]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[2][3]=$CountUcenci12[2][3]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                    $CountUcenci12[3][3]=$CountUcenci12[3][3]+1;
                            }
                            break;
                        case 3:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[4][4]=$CountUcenci12[4][4]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[2][4]=$CountUcenci12[2][4]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                                    $CountUcenci12[3][4]=$CountUcenci12[3][4]+1;
                            }
                            break;
                        case 4:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[4][5]=$CountUcenci12[4][5]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[2][5]=$CountUcenci12[2][5]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                                    $CountUcenci12[3][5]=$CountUcenci12[3][5]+1;
                            }
                            break;
                        case 5:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[4][6]=$CountUcenci12[4][6]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[2][6]=$CountUcenci12[2][6]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][6]=$CountUcenci12[1][6]+1;
                                    $CountUcenci12[3][6]=$CountUcenci12[3][6]+1;
                            }
                            break;
                        case 6:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[4][7]=$CountUcenci12[4][7]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[2][7]=$CountUcenci12[2][7]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][7]=$CountUcenci12[1][7]+1;
                                    $CountUcenci12[3][7]=$CountUcenci12[3][7]+1;
                            }
                            break;
                        case 7:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[4][8]=$CountUcenci12[4][8]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[2][8]=$CountUcenci12[2][8]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][8]=$CountUcenci12[1][8]+1;
                                    $CountUcenci12[3][8]=$CountUcenci12[3][8]+1;
                            }
                            break;
                        case 8:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[4][9]=$CountUcenci12[4][9]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[2][9]=$CountUcenci12[2][9]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][9]=$CountUcenci12[1][9]+1;
                                    $CountUcenci12[3][9]=$CountUcenci12[3][9]+1;
                            }
                            break;
                        case 9:
                            switch ($R["kodamss"]){
                                /*
                                case 16: //SLO
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[4][1]=$CountUcenci12[4][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[4][10]=$CountUcenci12[4][10]+1;
                                    break;
                                */
                                case "TJA": //TJA
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[2][1]=$CountUcenci12[2][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[2][10]=$CountUcenci12[2][10]+1;
                                    break;
                                case "TJN": //NEM
                                    $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                    $CountUcenci12[3][1]=$CountUcenci12[3][1]+1;
                                    $CountUcenci12[1][10]=$CountUcenci12[1][10]+1;
                                    $CountUcenci12[3][10]=$CountUcenci12[3][10]+1;
                            }
                    }
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="1. tuji jezik";
            $Rubrike14[2]="Angleščina";
            $Rubrike14[3]="Nemščina";
            $Rubrike14[4]="Slovenščina kot jezik okolja";
            $Rubrike14[5]="Italijanščina kot jezik okolja";
            $Rubrike14[6]="Madžarščina kot jezik okolja";
            $Rubrike14[7]="Skupaj jeziki okolja";
            echo "<b>11. Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>JEZIKI</th><th>Št.</th><th>Skupaj (2-10)</th><th>1. razred</th><th>2. razred</th><th>3. razred</th><th>4. razred</th><th>5. razred</th><th>6. razred</th><th>7. razred</th><th>8. razred</th><th>9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td></tr>";

            echo "<tr><td>".$Rubrike14[1]."</td>";
            echo "<td align=center>1</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";
            for ($Indx=2;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][6]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][7]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][8]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][9]."</td>";
                echo "<td align=center>".$CountUcenci12[$Indx][10]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //Učenci, ki se učijo tuje jezike in jezike okolja v okviru predmetnika - konec

        //Učenci, ki se učijo v 9-letni osnovni šoli tuji jezik kot izbirni predmet - začetek    
            $SQL = "SELECT tabizbirni.izbirni,tabucenci.priimek,tabucenci.ime,tabrazred.razred,tabpredmeti.kodamss FROM ";
            $SQL = $SQL . "(((tabpredmeti INNER JOIN tabizbirni ON tabpredmeti.Id=tabizbirni.Izbirni) ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabizbirni.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabizbirni.Ucenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabpredmeti.Prioriteta=1 AND tabizbirni.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL ." AND tabpredmeti.KodaMSS IN ('FI1','FI2','FI3','NI1','NI2','NI3','ŠI1','ŠI2','ŠI3','LI1','LI2','LI3','HI1','HI2','HI3','II1','II2','II3','IF2','IN2','IM2','IH2','IA2','INA','INN')";
            $SQL = $SQL . " ORDER BY tabrazred.Razred,tabrazred.Paralelka,tabucenci.Priimek,tabucenci.Ime";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 8;$i++){
                for ($j=1;$j <= 8;$j++){
                    $CountUcenci13[$i][$j]=0;
                }
            }
            $UcenecIzbirni="";
            $Indx=1;
            $Indx1=1;
            while ($R = mysqli_fetch_array($result)){
                if (isset($R["kodamss"])){
                    if ($UcenecIzbirni == $R["priimek"]." ".$R["ime"]){
                        $Ucenci[$Indx][$Indx1]=$R["kodamss"];
                        $Indx1=$Indx1+1;
                    }else{
                        $Ucenci[$Indx][0]=$R["razred"];
                        $Ucenci[$Indx][$Indx1]=$R["kodamss"];
                        $Indx=$Indx+1;
                        $Indx1=1;
                        $UcenecIzbirni = $R["priimek"]." ".$R["ime"];
                    }
                }
            }
            $Ucencev=$Indx-1;
            
            for ($Indx=1;$Indx <= $Ucencev;$Indx++){
                $Drugi=false;
                switch ($Ucenci[$Indx][0]){
                case 7:
                    switch ($Ucenci[$Indx][1]){
                    case "IF2":
                    case "FI1":
                    case "FI2":
                    case "FI3": //FI1][FI2][FI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                        $Drugi=True;
                        break;
                    case "LI1":
                    case "LI2":
                    case "LI3": //LI1][LI2][LI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                        $Drugi=True;
                        break;
                    case "II1":
                    case "II2":
                    case "II3": //italijanščina
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                        $Drugi=True;
                        break;
                    case "IH2":
                    case "HI1":
                    case "HI2":
                    case "HI3": //HI1][HI2][HI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                        $Drugi=True;
                        break;
                    case "NI1":
                    case "NI2":
                    case "NI3":
                    case "IN2":
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                        $Drugi=True;
                        break;
                    case "ŠI1":
                    case "ŠI2":
                    case "ŠI3": //ŠI1
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                        $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                        $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                        $Drugi=True;
                    }

                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[3][5]=$CountUcenci13[3][5]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[7][5]=$CountUcenci13[7][5]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[4][5]=$CountUcenci13[4][5]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[8][5]=$CountUcenci13[8][5]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[5][5]=$CountUcenci13[5][5]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[6][5]=$CountUcenci13[6][5]+1;
                            }
                        }

                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[3][2]=$CountUcenci13[3][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[3][5]=$CountUcenci13[3][5]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[7][2]=$CountUcenci13[7][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[7][5]=$CountUcenci13[7][5]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[4][2]=$CountUcenci13[4][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[4][5]=$CountUcenci13[4][5]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[8][2]=$CountUcenci13[8][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[8][5]=$CountUcenci13[8][5]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[5][2]=$CountUcenci13[5][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[5][5]=$CountUcenci13[5][5]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][2]=$CountUcenci13[1][2]+1;
                                $CountUcenci13[6][2]=$CountUcenci13[6][2]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][5]=$CountUcenci13[1][5]+1;
                                $CountUcenci13[6][5]=$CountUcenci13[6][5]+1;
                            }
                        }
                    }
                    break;
                case 8:
                    switch ($Ucenci[$Indx][1]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                            $Drugi=True;
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                            $Drugi=True;
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                            $Drugi=True;
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                            $Drugi=True;
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                            $Drugi=True;
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                            $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                            $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                            $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                            $Drugi=True;
                        }
                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[3][6]=$CountUcenci13[3][6]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[7][6]=$CountUcenci13[7][6]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[4][6]=$CountUcenci13[4][6]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[8][6]=$CountUcenci13[8][6]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[5][6]=$CountUcenci13[5][6]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[6][6]=$CountUcenci13[6][6]+1;
                            }
                        }
                    }
                    if (isset($Ucenci[$Indx][3])){
                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[3][3]=$CountUcenci13[3][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[3][6]=$CountUcenci13[3][6]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[7][3]=$CountUcenci13[7][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[7][6]=$CountUcenci13[7][6]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[4][3]=$CountUcenci13[4][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[4][6]=$CountUcenci13[4][6]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[8][3]=$CountUcenci13[8][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[8][6]=$CountUcenci13[8][6]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[5][3]=$CountUcenci13[5][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[5][6]=$CountUcenci13[5][6]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][3]=$CountUcenci13[1][3]+1;
                                $CountUcenci13[6][3]=$CountUcenci13[6][3]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][6]=$CountUcenci13[1][6]+1;
                                $CountUcenci13[6][6]=$CountUcenci13[6][6]+1;
                            }
                        }
                    }
                    break;
                case 9:
                    switch ($Ucenci[$Indx][1]){
                    case "IF2":
                    case "FI1":
                    case "FI2":
                    case "FI3": //FI1][FI2][FI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                        $Drugi=True;
                        break;
                    case "LI1":
                    case "LI2":
                    case "LI3": //LI1][LI2][LI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                        $Drugi=True;
                        break;
                    case "II1":
                    case "II2":
                    case "II3": //italijanščina
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                        $Drugi=True;
                        break;
                    case "IH2":
                    case "HI1":
                    case "HI2":
                    case "HI3": //HI1][HI2][HI3
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                        $Drugi=True;
                        break;
                    case "NI1":
                    case "NI2":
                    case "NI3":
                    case "IN2":
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                        $Drugi=True;
                        break;
                    case "ŠI1":
                    case "ŠI2":
                    case "ŠI3": //SI1
                        $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                        $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                        $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                        $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                        $Drugi=True;
                    }
                    if (isset($Ucenci[$Indx][2])){
                        switch ($Ucenci[$Indx][2]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[3][7]=$CountUcenci13[3][7]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[7][7]=$CountUcenci13[7][7]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[4][7]=$CountUcenci13[4][7]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[8][7]=$CountUcenci13[8][7]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[5][7]=$CountUcenci13[5][7]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[6][7]=$CountUcenci13[6][7]+1;
                            }
                        }
                    }
                    if (isset($Ucenci[$Indx][3])){
                        switch ($Ucenci[$Indx][3]){
                        case "IF2":
                        case "FI1":
                        case "FI2":
                        case "FI3": //FI1][FI2][FI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[3][4]=$CountUcenci13[3][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[3][1]=$CountUcenci13[3][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[3][7]=$CountUcenci13[3][7]+1;
                            }
                            break;
                        case "LI1":
                        case "LI2":
                        case "LI3": //LI1][LI2][LI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[7][4]=$CountUcenci13[7][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[7][1]=$CountUcenci13[7][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[7][7]=$CountUcenci13[7][7]+1;
                            }
                            break;
                        case "II1":
                        case "II2":
                        case "II3": //italijanščina
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[4][4]=$CountUcenci13[4][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[4][1]=$CountUcenci13[4][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[4][7]=$CountUcenci13[4][7]+1;
                            }
                            break;
                        case "IH2":
                        case "HI1":
                        case "HI2":
                        case "HI3": //HI1][HI2][HI3
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[8][4]=$CountUcenci13[8][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[8][1]=$CountUcenci13[8][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[8][7]=$CountUcenci13[8][7]+1;
                            }
                            break;
                        case "NI1":
                        case "NI2":
                        case "NI3":
                        case "IN2":
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[5][4]=$CountUcenci13[5][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[5][1]=$CountUcenci13[5][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[5][7]=$CountUcenci13[5][7]+1;
                            }
                            break;
                        case "ŠI1":
                        case "ŠI2":
                        case "ŠI3": //SI1
                            if (!$Drugi){
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][4]=$CountUcenci13[1][4]+1;
                                $CountUcenci13[6][4]=$CountUcenci13[6][4]+1;
                                $Drugi=True;
                            }else{
                                $CountUcenci13[1][1]=$CountUcenci13[1][1]+1;
                                $CountUcenci13[6][1]=$CountUcenci13[6][1]+1;
                                $CountUcenci13[1][7]=$CountUcenci13[1][7]+1;
                                $CountUcenci13[6][7]=$CountUcenci13[6][7]+1;
                            }
                        }
                    }
                }
            }
            
            $Rubrike14[1]="Angleški jezik";
            $Rubrike14[2]="Francoski jezik";
            $Rubrike14[3]="Italijanski jezik";
            $Rubrike14[4]="Nemški jezik";
            $Rubrike14[5]="Španski jezik";
            $Rubrike14[6]="Latinski jezik";
            $Rubrike14[7]="Hrvaški jezik";
            $Rubrike14[8]="Drug tuj jezik";
            echo "<b>12. Učenci, ki se učijo tuji jezik kot izbirni predmet ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>JEZIKI</th><th>Št.</th><th>Skupaj (2-7)</th><th>Kot 2. tuji jezik</th><th></th><th></th><th>Kot 3. tuji jezik</th>";
            echo "<tr><td></td><td></td><td></td><td>7. razred</td><td>8. razred</td><td>9. razred</td><td>7. razred</td><td>8. razred</td><td>9. razred</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td></tr>";
            for ($Indx=2;$Indx <= 8;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx-1]."</td>";
                echo "<td align=center>".($Indx-1)."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][3]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][4]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][5]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][6]."</td>";
                echo "<td align=center>".$CountUcenci13[$Indx][7]."</td>";
                echo "</tr>";
            }
            echo "<tr><td>".$Rubrike14[8]."</td>";
            echo "<td align=center>8</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "<td>&nbsp;</td>";
            echo "</tr>";
            echo "</table><br />";
        //Učenci, ki se učijo v 9-letni osnovni šoli tuji jezik kot izbirni predmet - konec

        //Učenci pri dopolnilnem in dodatnem pouku po razredih - začetek    
            $SQL = "SELECT tabdodpouk.pomoc,tabrazred.razred FROM ";
            $SQL = $SQL . "((tabdodpouk INNER JOIN tabucenci ON tabdodpouk.idUcenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabdodpouk.IdUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabrazred.leto=".$VLeto." AND tabdodpouk.leto=".$VLeto." AND tabdodpouk.pomoc IN (3,4)"." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazred.Razred,tabrazred.Paralelka";
            $result = mysqli_query($link,$SQL);

            for ($i=1;$i <= 1;$i++){
                for ($j=1;$j <= 5;$j++){
                    $CountUcenci12[$i][$j]=0;
                }
            }
            while ($R = mysqli_fetch_array($result)){
                switch ($R["razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        switch ($R["pomoc"]){
                            case 4: // 'dop
                                $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                $CountUcenci12[1][2]=$CountUcenci12[1][2]+1;
                                break;
                            case 3: // 'dod
                                $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                $CountUcenci12[1][4]=$CountUcenci12[1][4]+1;
                        }
                        break;
                    case 7:
                    case 8:
                    case 9:
                        switch ($R["pomoc"]){
                            case 4: // 'dop
                                $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                $CountUcenci12[1][3]=$CountUcenci12[1][3]+1;
                                break;
                            case 3: // 'dod
                                $CountUcenci12[1][1]=$CountUcenci12[1][1]+1;
                                $CountUcenci12[1][5]=$CountUcenci12[1][5]+1;
                        }
                }
                $Indx=$Indx+1;
            }
            
            $Rubrike14[1]="Skupaj";
            echo "<b>14. Učenci pri dopolnilnem in dodatnem pouku, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<tr><th>UČENCI, VKLJUČENI V<br />DOP. IN DOD. POUK</th><th>Št.</th><th>Skupaj (2-5)</th><th>Dopolnilni pouk</th><th></th><th>Dodatni pouk</th><th></th></tr>";
            echo "<tr><td></td><td></td><td></td><td>1.-6. razred</td><td>7.-9. razred</td><td>1.-6. razred</td><td>7.-9. razred</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td></tr>";
            echo "<tr><td>".$Rubrike14[1]."</td>";
            echo "<td align=center>1</td>";
            echo "<td align=center>".$CountUcenci13[1][1]."</td>";
            echo "<td align=center>".$CountUcenci13[1][2]."</td>";
            echo "<td align=center>".$CountUcenci13[1][3]."</td>";
            echo "<td align=center>".$CountUcenci13[1][4]."</td>";
            echo "<td align=center>".$CountUcenci13[1][5]."</td>";
            echo "</tr>";
            echo "</table><br />";
            //Učenci pri dopolnilnem in dodatnem pouku po razredih - konec
        }
        echo "</body>";
        echo "</html>";
        break;
    case "210": //oddelki in učenci v novem ŠL - za statistiko
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabrazred.ponavljalec,tabucenci.spol,tabucenci.letoroj,tabucenci.bivanje FROM (tabrazred ";
            $SQL .= "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,paralelka";
            $result = mysqli_query($link,$SQL);
            
        //Vrste oddelkov in učenci v njih - začetek

            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 6;$j++){
                    $CountOddelki1[$i][$j]=0;
                    $CountUcenci1[$i][$j]=0;
                }
            }
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["paralelka"];
                switch ($R["razred"]){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                    if ($StrRazred != $StrRazred1){
                        $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                        $CountOddelki1[1][4]=$CountOddelki1[1][4]+1;
                        $CountOddelki1[2][1]=$CountOddelki1[2][1]+1;
                        $CountOddelki1[2][4]=$CountOddelki1[2][4]+1;
                        $StrRazred=$StrRazred1;
                    }
                    $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                    $CountUcenci1[1][5]=$CountUcenci1[1][5]+1;
                    $CountUcenci1[2][2]=$CountUcenci1[2][2]+1;
                    $CountUcenci1[2][5]=$CountUcenci1[2][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci1[1][3]=$CountUcenci1[1][3]+1;
                        $CountUcenci1[1][6]=$CountUcenci1[1][6]+1;
                        $CountUcenci1[2][3]=$CountUcenci1[2][3]+1;
                        $CountUcenci1[2][6]=$CountUcenci1[2][6]+1;
                    }
                    break;
                case 7:
                case 8:
                case 9:
                    if ($StrRazred != $StrRazred1){
                        $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                        $CountOddelki1[1][4]=$CountOddelki1[1][4]+1;
                        $CountOddelki1[3][1]=$CountOddelki1[3][1]+1;
                        $CountOddelki1[3][4]=$CountOddelki1[3][4]+1;
                        $StrRazred=$StrRazred1;
                    }
                    $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                    $CountUcenci1[1][5]=$CountUcenci1[1][5]+1;
                    $CountUcenci1[3][2]=$CountUcenci1[3][2]+1;
                    $CountUcenci1[3][5]=$CountUcenci1[3][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci1[1][3]=$CountUcenci1[1][3]+1;
                        $CountUcenci1[1][6]=$CountUcenci1[1][6]+1;
                        $CountUcenci1[3][3]=$CountUcenci1[3][3]+1;
                        $CountUcenci1[3][6]=$CountUcenci1[3][6]+1;
                    }
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj";
            $Rubrike14[2]="1.-6. razred";
            $Rubrike14[3]="7.-9. razred";
            echo "<b>51. Vrste oddelkov in učenci v njih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>ODDELKI</th><th>Št.</th><th>Vsi</th><th></th><th></th><th>Čisti oddelki</th><th></th><th></th><th>Kombinirani oddelki</th>";
            echo "<tr><td align=center></td><td></td><td align=center>Oddelki (4+7)</td><td align=center>Učenci (5+8)</td><td align=center>od tega učenke (6+9)</td><td align=center>oddelki</td><td align=center>učenci</td><td align=center>od tega učenke</td><td align=center>oddelki</td><td align=center>učenci</td><td align=center>od tega učenke</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$CountOddelki1[$Indx][1]."</td><td align=center>".$CountUcenci1[$Indx][2]."</td><td align=center>".$CountUcenci1[$Indx][3]."</td><td align=center>".$CountOddelki1[$Indx][4]."</td><td align=center>".$CountUcenci1[$Indx][5]."</td><td align=center>".$CountUcenci1[$Indx][6]."</td><td></td><td></td></tr>";
            }
            echo "</table><br />";
        //Vrste oddelkov in učenci v njih - konec    

        //Učenci po letu rojstva in razredih, v programu 9-letne OŠ - začetek
            for ($Indx=1;$Indx <= 11;$Indx++){
                $LetaRoj[$Indx]=$VLeto-5-$Indx;
            }
            for ($i=1;$i <= 20;$i++){
                for ($j=1;$j <= 14;$j++){
                    $CountUcenci2[$i][$j]=0;
                }
            }
            $StrRazred="";
            $Indx=0;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["paralelka"];
                $CountUcenci2[1][1]=$CountUcenci2[1][1]+1;
                if ($R["spol"]=="F"){
                    $CountUcenci2[2][1]=$CountUcenci2[2][1]+1;
                }
                switch ($R["letoroj"]){
                case $LetaRoj[1]:
                case ($LetaRoj[1]+1):
                    $CountUcenci2[1][2]=$CountUcenci2[1][2]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][2]=$CountUcenci2[2][2]+1;
                    }
                    break;
                case $LetaRoj[2]:
                    $CountUcenci2[1][3]=$CountUcenci2[1][3]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][3]=$CountUcenci2[2][3]+1;
                    }
                    break;
                case $LetaRoj[3]:
                    $CountUcenci2[1][4]=$CountUcenci2[1][4]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][4]=$CountUcenci2[2][4]+1;
                    }
                    break;
                case $LetaRoj[4]:
                    $CountUcenci2[1][5]=$CountUcenci2[1][5]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][5]=$CountUcenci2[2][5]+1;
                    }
                    break;
                case $LetaRoj[5]:
                    $CountUcenci2[1][6]=$CountUcenci2[1][6]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][6]=$CountUcenci2[2][6]+1;
                    }
                    break;
                case $LetaRoj[6]:
                    $CountUcenci2[1][7]=$CountUcenci2[1][7]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][7]=$CountUcenci2[2][7]+1;
                    }
                    break;
                case $LetaRoj[7]:
                    $CountUcenci2[1][8]=$CountUcenci2[1][8]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][8]=$CountUcenci2[2][8]+1;
                    }
                    break;
                case $LetaRoj[8]:
                    $CountUcenci2[1][9]=$CountUcenci2[1][9]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][9]=$CountUcenci2[2][9]+1;
                    }
                    break;
                case $LetaRoj[9]:
                    $CountUcenci2[1][10]=$CountUcenci2[1][10]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][10]=$CountUcenci2[2][10]+1;
                    }
                    break;
                case $LetaRoj[10]:
                    $CountUcenci2[1][11]=$CountUcenci2[1][11]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][11]=$CountUcenci2[2][11]+1;
                    }
                    break;
                default:
                    $CountUcenci2[1][12]=$CountUcenci2[1][12]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[2][12]=$CountUcenci2[2][12]+1;
                    }
                }
                
                switch ($R["razred"]){
                    case 1:
                        $CountUcenci2[3][1]=$CountUcenci2[3][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[4][1]=$CountUcenci2[4][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[3][2]=$CountUcenci2[3][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][2]=$CountUcenci2[4][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[3][3]=$CountUcenci2[3][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][3]=$CountUcenci2[4][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[3][4]=$CountUcenci2[3][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][4]=$CountUcenci2[4][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[3][5]=$CountUcenci2[3][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][5]=$CountUcenci2[4][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[3][6]=$CountUcenci2[3][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][6]=$CountUcenci2[4][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[3][7]=$CountUcenci2[3][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][7]=$CountUcenci2[4][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[3][8]=$CountUcenci2[3][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][8]=$CountUcenci2[4][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[3][9]=$CountUcenci2[3][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][9]=$CountUcenci2[4][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[3][10]=$CountUcenci2[3][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][10]=$CountUcenci2[4][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[3][11]=$CountUcenci2[3][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][11]=$CountUcenci2[4][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[3][12]=$CountUcenci2[3][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[4][12]=$CountUcenci2[4][12]+1;
                            }
                        }
                        break;
                    case 2:
                        $CountUcenci2[5][1]=$CountUcenci2[5][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[6][1]=$CountUcenci2[6][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[5][2]=$CountUcenci2[5][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][2]=$CountUcenci2[6][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[5][3]=$CountUcenci2[5][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][3]=$CountUcenci2[6][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[5][4]=$CountUcenci2[5][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][4]=$CountUcenci2[6][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[5][5]=$CountUcenci2[5][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][5]=$CountUcenci2[6][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[5][6]=$CountUcenci2[5][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][6]=$CountUcenci2[6][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[5][7]=$CountUcenci2[5][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][7]=$CountUcenci2[6][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[5][8]=$CountUcenci2[5][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][8]=$CountUcenci2[6][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[5][9]=$CountUcenci2[5][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][9]=$CountUcenci2[6][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[5][10]=$CountUcenci2[5][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][10]=$CountUcenci2[6][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[5][11]=$CountUcenci2[5][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][11]=$CountUcenci2[6][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[5][12]=$CountUcenci2[5][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[6][12]=$CountUcenci2[6][12]+1;
                            }
                        }
                        break;
                    case 3:
                        $CountUcenci2[7][1]=$CountUcenci2[7][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[8][1]=$CountUcenci2[8][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[7][2]=$CountUcenci2[7][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][2]=$CountUcenci2[8][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[7][3]=$CountUcenci2[7][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][3]=$CountUcenci2[8][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[7][4]=$CountUcenci2[7][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][4]=$CountUcenci2[8][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[7][5]=$CountUcenci2[7][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][5]=$CountUcenci2[8][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[7][6]=$CountUcenci2[7][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][6]=$CountUcenci2[8][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[7][7]=$CountUcenci2[7][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][7]=$CountUcenci2[8][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[7][8]=$CountUcenci2[7][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][8]=$CountUcenci2[8][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[7][9]=$CountUcenci2[7][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][9]=$CountUcenci2[8][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[7][10]=$CountUcenci2[7][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][10]=$CountUcenci2[8][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[7][11]=$CountUcenci2[7][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][11]=$CountUcenci2[8][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[7][12]=$CountUcenci2[7][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[8][12]=$CountUcenci2[8][12]+1;
                            }
                        }
                        break;
                    case 4:
                        $CountUcenci2[9][1]=$CountUcenci2[9][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[10][1]=$CountUcenci2[10][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case $LetaRoj[1]+1:
                            $CountUcenci2[9][2]=$CountUcenci2[9][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][2]=$CountUcenci2[10][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[9][3]=$CountUcenci2[9][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][3]=$CountUcenci2[10][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[9][4]=$CountUcenci2[9][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][4]=$CountUcenci2[10][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[9][5]=$CountUcenci2[9][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][5]=$CountUcenci2[10][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[9][6]=$CountUcenci2[9][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][6]=$CountUcenci2[10][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[9][7]=$CountUcenci2[9][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][7]=$CountUcenci2[10][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[9][8]=$CountUcenci2[9][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][8]=$CountUcenci2[10][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[9][9]=$CountUcenci2[9][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][9]=$CountUcenci2[10][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[9][10]=$CountUcenci2[9][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][10]=$CountUcenci2[10][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[9][11]=$CountUcenci2[9][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][11]=$CountUcenci2[10][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[9][12]=$CountUcenci2[9][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[10][12]=$CountUcenci2[10][12]+1;
                            }
                        }
                        break;
                    case 5:
                        $CountUcenci2[11][1]=$CountUcenci2[11][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[12][1]=$CountUcenci2[12][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case $LetaRoj[1]+1:
                            $CountUcenci2[11][2]=$CountUcenci2[11][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][2]=$CountUcenci2[12][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[11][3]=$CountUcenci2[11][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][3]=$CountUcenci2[12][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[11][4]=$CountUcenci2[11][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][4]=$CountUcenci2[12][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[11][5]=$CountUcenci2[11][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][5]=$CountUcenci2[12][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[11][6]=$CountUcenci2[11][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][6]=$CountUcenci2[12][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[11][7]=$CountUcenci2[11][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][7]=$CountUcenci2[12][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[11][8]=$CountUcenci2[11][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][8]=$CountUcenci2[12][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[11][9]=$CountUcenci2[11][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][9]=$CountUcenci2[12][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[11][10]=$CountUcenci2[11][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][10]=$CountUcenci2[12][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[11][11]=$CountUcenci2[11][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][11]=$CountUcenci2[12][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[11][12]=$CountUcenci2[11][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[12][12]=$CountUcenci2[12][12]+1;
                            }
                        }
                        break;
                    case 6:
                        $CountUcenci2[13][1]=$CountUcenci2[13][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[14][1]=$CountUcenci2[14][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[13][2]=$CountUcenci2[13][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][2]=$CountUcenci2[14][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[13][3]=$CountUcenci2[13][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][3]=$CountUcenci2[14][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[13][4]=$CountUcenci2[13][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][4]=$CountUcenci2[14][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[13][5]=$CountUcenci2[13][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][5]=$CountUcenci2[14][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[13][6]=$CountUcenci2[13][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][6]=$CountUcenci2[14][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[13][7]=$CountUcenci2[13][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][7]=$CountUcenci2[14][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[13][8]=$CountUcenci2[13][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][8]=$CountUcenci2[14][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[13][9]=$CountUcenci2[13][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][9]=$CountUcenci2[14][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[13][10]=$CountUcenci2[13][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][10]=$CountUcenci2[14][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[13][11]=$CountUcenci2[13][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][11]=$CountUcenci2[14][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[13][12]=$CountUcenci2[13][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[14][12]=$CountUcenci2[14][12]+1;
                            }
                        }
                        break;
                    case 7:
                        $CountUcenci2[15][1]=$CountUcenci2[15][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[16][1]=$CountUcenci2[16][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[15][2]=$CountUcenci2[15][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][2]=$CountUcenci2[16][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[15][3]=$CountUcenci2[15][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][3]=$CountUcenci2[16][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[15][4]=$CountUcenci2[15][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][4]=$CountUcenci2[16][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[15][5]=$CountUcenci2[15][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][5]=$CountUcenci2[16][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[15][6]=$CountUcenci2[15][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][6]=$CountUcenci2[16][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[15][7]=$CountUcenci2[15][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][7]=$CountUcenci2[16][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[15][8]=$CountUcenci2[15][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][8]=$CountUcenci2[16][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[15][9]=$CountUcenci2[15][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][9]=$CountUcenci2[16][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[15][10]=$CountUcenci2[15][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][10]=$CountUcenci2[16][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:


                            $CountUcenci2[15][11]=$CountUcenci2[15][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][11]=$CountUcenci2[16][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[15][12]=$CountUcenci2[15][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[16][12]=$CountUcenci2[16][12]+1;
                            }
                        }
                        break;
                    case 8:
                        $CountUcenci2[17][1]=$CountUcenci2[17][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[18][1]=$CountUcenci2[18][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1):
                            $CountUcenci2[17][2]=$CountUcenci2[17][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][2]=$CountUcenci2[18][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[17][3]=$CountUcenci2[17][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][3]=$CountUcenci2[18][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[17][4]=$CountUcenci2[17][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][4]=$CountUcenci2[18][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[17][5]=$CountUcenci2[17][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][5]=$CountUcenci2[18][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[17][6]=$CountUcenci2[17][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][6]=$CountUcenci2[18][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[17][7]=$CountUcenci2[17][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][7]=$CountUcenci2[18][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[17][8]=$CountUcenci2[17][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][8]=$CountUcenci2[18][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[17][9]=$CountUcenci2[17][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][9]=$CountUcenci2[18][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[17][10]=$CountUcenci2[17][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][10]=$CountUcenci2[18][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[17][11]=$CountUcenci2[17][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][11]=$CountUcenci2[18][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[17][12]=$CountUcenci2[17][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[18][12]=$CountUcenci2[18][12]+1;
                            }
                        }
                        break;
                    case 9:
                        $CountUcenci2[19][1]=$CountUcenci2[19][1]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci2[20][1]=$CountUcenci2[20][1]+1;
                        }
                        switch ($R["letoroj"]){
                        case $LetaRoj[1]:
                        case ($LetaRoj[1]+1);
                            $CountUcenci2[19][2]=$CountUcenci2[19][2]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][2]=$CountUcenci2[20][2]+1;
                            }
                            break;
                        case $LetaRoj[2]:
                            $CountUcenci2[19][3]=$CountUcenci2[19][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][3]=$CountUcenci2[20][3]+1;
                            }
                            break;
                        case $LetaRoj[3]:
                            $CountUcenci2[19][4]=$CountUcenci2[19][4]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][4]=$CountUcenci2[20][4]+1;
                            }
                            break;
                        case $LetaRoj[4]:
                            $CountUcenci2[19][5]=$CountUcenci2[19][5]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][5]=$CountUcenci2[20][5]+1;
                            }
                            break;
                        case $LetaRoj[5]:
                            $CountUcenci2[19][6]=$CountUcenci2[19][6]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][6]=$CountUcenci2[20][6]+1;
                            }
                            break;
                        case $LetaRoj[6]:
                            $CountUcenci2[19][7]=$CountUcenci2[19][7]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][7]=$CountUcenci2[20][7]+1;
                            }
                            break;
                        case $LetaRoj[7]:
                            $CountUcenci2[19][8]=$CountUcenci2[19][8]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][8]=$CountUcenci2[20][8]+1;
                            }
                            break;
                        case $LetaRoj[8]:
                            $CountUcenci2[19][9]=$CountUcenci2[19][9]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][9]=$CountUcenci2[20][9]+1;
                            }
                            break;
                        case $LetaRoj[9]:
                            $CountUcenci2[19][10]=$CountUcenci2[19][10]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][10]=$CountUcenci2[20][10]+1;
                            }
                            break;
                        case $LetaRoj[10]:
                            $CountUcenci2[19][11]=$CountUcenci2[19][11]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][11]=$CountUcenci2[20][11]+1;
                            }
                            break;
                        default:
                            $CountUcenci2[19][12]=$CountUcenci2[19][12]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci2[20][12]=$CountUcenci2[20][12]+1;
                            }
                        }
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="učenke";
            $Rubrike14[3]="1. razred - vsi";
            $Rubrike14[4]="učenke";
            $Rubrike14[5]="2. razred - vsi";
            $Rubrike14[6]="učenke";
            $Rubrike14[7]="3. razred - vsi";
            $Rubrike14[8]="učenke";
            $Rubrike14[9]="4. razred - vsi";
            $Rubrike14[10]="učenke";
            $Rubrike14[11]="5. razred - vsi";
            $Rubrike14[12]="učenke";
            $Rubrike14[13]="6. razred - vsi";
            $Rubrike14[14]="učenke";
            $Rubrike14[15]="7. razred - vsi";
            $Rubrike14[16]="učenke";
            $Rubrike14[17]="8. razred - vsi";
            $Rubrike14[18]="učenke";
            $Rubrike14[19]="9. razred - vsi";
            $Rubrike14[20]="učenke";
            echo "<b>52. Učenci po letu rojstva in razredih, v programu 9-letne OŠ ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>RAZREDI</th><th>Št.</th><th>Učenci rojeni leta</th>";
            echo "<tr><td align=center></td><td></td><td align=center>Skupaj (2 do 12)</td>";
            for ($Indx=1;$Indx <= 11;$Indx++){
                if ($Indx==1){
                    echo "<td>".$LetaRoj[$Indx]." in kasneje</td>";
                }
                if ($Indx==11){
                    echo "<td>".$LetaRoj[$Indx]." in prej</td>";
                }
                if (($Indx > 1) && ($Indx < 11)){
                    echo "<td>".$LetaRoj[$Indx]."</td>";
                }
            }
            echo "</tr>";
            echo "<tr><td align=center>a</td><td></td>";
            for ($Indx=1;$Indx <= 12;$Indx++){
                echo "<td align=center>".$Indx."</td>";
            }
            echo "</tr>";
            for ($Indx=1;$Indx <= 20;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
                for ($Indx0=1;$Indx0 <= 12;$Indx0++){
                    echo "<td align=center>".$CountUcenci2[$Indx][$Indx0]."</td>";
                }
                echo "</tr>";
            }
            echo "</table><br />";
        //Učenci po letu rojstva in razredih, v programu 9-letne OŠ - konec    

        //Učenci, ki ponavljajo razred, po spolu in razredih - začetek
            for ($i=1;$i <= 10;$i++){
                for ($j=1;$j <= 4;$j++){
                    $CountUcenci3[$i][$j]=0;
                }
            }
            $result = mysqli_query($link,$SQL);
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["paralelka"];
                    if ($R["ponavljalec"] > 0){
                        $CountUcenci3[1][3]=$CountUcenci3[1][3]+1;
                        if ($R["spol"]=="F"){
                            $CountUcenci3[1][4]=$CountUcenci3[1][4]+1;
                        }
                    }
                    switch ($R["razred"]){
                    case 1:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[2][3]=$CountUcenci3[2][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[2][4]=$CountUcenci3[2][4]+1;
                            }
                        }
                        break;
                    case 2:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[3][3]=$CountUcenci3[3][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[3][4]=$CountUcenci3[3][4]+1;
                            }
                        }
                        break;
                    case 3:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[4][3]=$CountUcenci3[4][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[4][4]=$CountUcenci3[4][4]+1;
                            }
                        }
                        break;
                    case 4:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[5][3]=$CountUcenci3[5][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[5][4]=$CountUcenci3[5][4]+1;
                            }
                        }
                        break;
                    case 5:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[6][3]=$CountUcenci3[6][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[6][4]=$CountUcenci3[6][4]+1;
                            }
                        }
                        break;
                    case 6:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[7][3]=$CountUcenci3[7][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[7][4]=$CountUcenci3[7][4]+1;
                            }
                        }
                        break;
                    case 7:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[8][3]=$CountUcenci3[8][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[8][4]=$CountUcenci3[8][4]+1;
                            }
                        }
                        break;
                    case 8:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[9][3]=$CountUcenci3[9][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[9][4]=$CountUcenci3[9][4]+1;
                            }
                        }
                        break;
                    case 9:
                        if ($R["ponavljalec"] > 0){
                            $CountUcenci3[10][3]=$CountUcenci3[10][3]+1;
                            if ($R["spol"]=="F"){
                                $CountUcenci3[10][4]=$CountUcenci3[10][4]+1;
                            }
                        }
                    }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="1. razred";
            $Rubrike14[3]="2. razred";
            $Rubrike14[4]="3. razred";
            $Rubrike14[5]="4. razred";
            $Rubrike14[6]="5. razred";
            $Rubrike14[7]="6. razred";
            $Rubrike14[8]="7. razred";
            $Rubrike14[9]="8. razred";
            $Rubrike14[10]="9. razred";
            echo "<b>53. Učenci, ki ponavljajo razred, po spolu in razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>RAZREDI</th><th>Št.</th><th>9-letna OŠ</th>";
            echo "<tr><td align=center></td><td></td><td align=center>ponavljajo, skupaj</td><td align=center>od tega učenke</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td></tr>";
            for ($Indx=1;$Indx <= 10;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
                for ($Indx0=3;$Indx0 <= 4;$Indx0++){
                    echo "<td align=center>".$CountUcenci3[$Indx][$Indx0]."</td>";
                }
                echo "</tr>";
            }
            echo "</table><br />";

        //Učenci, ki ponavljajo razred, po spolu in razredih - konec    

        //Učenci po kraju bivanja, po razredih - začetek
            $result = mysqli_query($link,$SQL);
            $StrRazred="";
            for ($Indx=1;$Indx <= 5;$Indx++){
                for ($Indx0=1;$Indx0 <= 3;$Indx0++){
                    $CountUcenci4[$Indx][$Indx0]=0;
                }




            }
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"];
                switch ($R["bivanje"]){
                    case 0:
                    case 4:
                    case 8:
                    case 9: //    'doma
                        switch ($R["razred"]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                $CountUcenci4[2][2]=$CountUcenci4[2][2]+1;
                                break;
                            default:
                                $CountUcenci4[2][3]=$CountUcenci4[2][3]+1;
                        }
                        break;
                    case 1:
                    case 3: //    'pri sorodnikih
                        switch ($R["razred"]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                $CountUcenci4[3][2]=$CountUcenci4[3][2]+1;
                                break;
                            default:
                                $CountUcenci4[3][3]=$CountUcenci4[3][3]+1;
                        }
                        break;
                    case 6: //    'v domovih za učence
                        switch ($R["razred"]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                $CountUcenci4[4][2]=$CountUcenci4[4][2]+1;
                                break;
                            default:
                                $CountUcenci4[4][3]=$CountUcenci4[4][3]+1;
                        }
                        break;
                    default:  //  'drugje
                        switch ($R["razred"]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                $CountUcenci4[5][2]=$CountUcenci4[5][2]+1;
                                break;
                            default:
                                $CountUcenci4[5][3]=$CountUcenci4[5][3]+1;
                        }
                }
                $Indx=$Indx+1;
            }
            for ($Indx=2;$Indx <= 5;$Indx++){
                for ($Indx0=2;$Indx0 <= 3;$Indx0++){
                    $CountUcenci4[$Indx][1]=$CountUcenci4[$Indx][1]+$CountUcenci4[$Indx][$Indx0];
                }
                $CountUcenci4[1][2]=$CountUcenci4[1][2]+$CountUcenci4[$Indx][2];
                $CountUcenci4[1][3]=$CountUcenci4[1][3]+$CountUcenci4[$Indx][3];
            }
            $CountUcenci4[1][1]=$CountUcenci4[1][2]+$CountUcenci4[1][3];
            
            $Rubrike14[1]="Skupaj";
            $Rubrike14[2]="Doma";
            $Rubrike14[3]="Pri sorodnikih";
            $Rubrike14[4]="V domovih za učence";
            $Rubrike14[5]="Drugod (npr. rejniške družine)";
            echo "<b>54. Učenci po kraju bivanja, po razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>KRAJ BIVANJA</th><th>Št.</th><th>SKUPAJ (2+3)</th><th>1.-6. razred</th><th>7.-9. razred</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td>";
            for ($Indx=1;$Indx <= 5;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
                for ($Indx0=1;$Indx0 <= 3;$Indx0++){
                    echo "<td align=center>".$CountUcenci4[$Indx][$Indx0]."</td>";
                }
                echo "</tr>";
            }
            echo "</table><br />";
        }
    //Učenci po kraju bivanja, po razredih - konec    
        break;
    case "220": //stat oddelki učenci
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            $SQL = "SELECT tabrazred.razred,tabrazred.paralelka,tabucenci.spol,tabucenci.idposebnepotrebe FROM (tabrazred ";
            $SQL .= "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,paralelka";
            $result = mysqli_query($link,$SQL);

        //Vrste oddelkov in učenci v njih - začetek

            for ($i=1;$i <= 3;$i++){
                for ($j=1;$j <= 4;$j++){
                    $CountOddelki1[$i][$j]=0;
                    $CountUcenci1[$i][$j]=0;
                }
            }
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].$R["paralelka"];
                switch ($R["razred"]){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                    if ($StrRazred != $StrRazred1){
                        $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                        $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                        $CountOddelki1[2][1]=$CountOddelki1[2][1]+1;
                        $CountOddelki1[2][3]=$CountOddelki1[2][3]+1;
                        $StrRazred=$StrRazred1;
                    }
                    $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                    $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                    $CountUcenci1[2][2]=$CountUcenci1[2][2]+1;
                    $CountUcenci1[2][4]=$CountUcenci1[2][4]+1;
                    break;
                case 7:
                case 8:
                case 9:
                    if ($StrRazred != $StrRazred1){
                        $CountOddelki1[1][1]=$CountOddelki1[1][1]+1;
                        $CountOddelki1[1][3]=$CountOddelki1[1][3]+1;
                        $CountOddelki1[3][1]=$CountOddelki1[3][1]+1;
                        $CountOddelki1[3][3]=$CountOddelki1[3][3]+1;
                        $StrRazred=$StrRazred1;
                    }
                    $CountUcenci1[1][2]=$CountUcenci1[1][2]+1;
                    $CountUcenci1[1][4]=$CountUcenci1[1][4]+1;
                    $CountUcenci1[3][2]=$CountUcenci1[3][2]+1;
                    $CountUcenci1[3][4]=$CountUcenci1[3][4]+1;
                }
                $Indx=$Indx+1;
            }

            $Rubrike14[1]="Skupaj (2+3)";
            $Rubrike14[2]="1.-6. razred programa 9-letne OŠ";
            $Rubrike14[3]="7.-9. razred programa 9-letne OŠ";
            echo "<b>1. Vrste oddelkov in učenci v njih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>ODDELKI</th><th>Št.</th><th>Skupaj</th><th></th>";
            echo "<tr><td align=center></td><td></td><td align=center>Oddelki</td><td align=center>Učenci</td></tr>";
            for ($Indx=1;$Indx <= 3;$Indx++){
                echo "<tr>";
                echo "<td>".$Rubrike14[$Indx]."</td>";
                echo "<td align=center>".$Indx."</td>";
                echo "<td align=center>".$CountOddelki1[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci1[$Indx][2]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //Vrste oddelkov in učenci v njih - konec    

        //Učenci po razredih v programu 9-letne OŠ - začetek
            for ($Indx=0;$Indx <= 36;$Indx++){
                $StrOddelek[$Indx]="";
                $CountUcenci2[$Indx][1]=0;
                $CountUcenci2[$Indx][2]=0;
                $CountUcenci2[$Indx][3]=0;
            }
            $result = mysqli_query($link,$SQL);
            $StrRazred="";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $StrRazred1=$R["razred"].". ".$R["paralelka"];
                if ($StrRazred1!=$StrRazred){
                    $Indx=$Indx+1;
                    $StrRazred=$StrRazred1;
                    $StrOddelek[$Indx]=$StrRazred1;
                    $CountUcenci2[$Indx][1]=$CountUcenci2[$Indx][1]+1;
                    $CountUcenci2[0][1]=$CountUcenci2[0][1]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[$Indx][2]=$CountUcenci2[$Indx][2]+1;
                        $CountUcenci2[0][2]=$CountUcenci2[0][2]+1;
                    }
                    if ($R["idposebnepotrebe"] > 1){
                        $CountUcenci2[$Indx][3]=$CountUcenci2[$Indx][3]+1;
                        $CountUcenci2[0][3]=$CountUcenci2[0][3]+1;
                    }
                }else{
                    $CountUcenci2[$Indx][1]=$CountUcenci2[$Indx][1]+1;
                    $CountUcenci2[0][1]=$CountUcenci2[0][1]+1;
                    if ($R["spol"]=="F"){
                        $CountUcenci2[$Indx][2]=$CountUcenci2[$Indx][2]+1;
                        $CountUcenci2[0][2]=$CountUcenci2[0][2]+1;
                    }
                    if ($R["idposebnepotrebe"] > 1){
                        $CountUcenci2[$Indx][3]=$CountUcenci2[$Indx][3]+1;
                        $CountUcenci2[0][3]=$CountUcenci2[0][3]+1;
                    }
                }
            }

            echo "<b>Učenci po razredih 9-letne OŠ ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>RAZRED</th><th>Skupaj</th><th>Od tega deklic</th><th>Od tega s posebnimi potrebami</th>";
            for ($Indx=1;$Indx <= 36;$Indx++){
                if (strlen($StrOddelek[$Indx]) > 0){
                echo "<tr>";
                echo "<td align=center>".$StrOddelek[$Indx]."</td>";
                echo "<td align=center>".$CountUcenci2[$Indx][1]."</td>";
                echo "<td align=center>".$CountUcenci2[$Indx][2]."</td>";
                echo "<td align=center>".$CountUcenci2[$Indx][3]."</td>";
                echo "</tr>";
                }
            }
                echo "<tr>";
                echo "<td align=center>Skupaj</td>";
                echo "<td align=center>".$CountUcenci2[0][1]."</td>";
                echo "<td align=center>".$CountUcenci2[0][2]."</td>";
                echo "<td align=center>".$CountUcenci2[0][3]."</td>";
                echo "</tr>";

            echo "</table><br />";
        }
        //Učenci po razredih v programu 9-letne OŠ - konec
    
        //število učencev po šolskih okoliših
        echo "<h3>Učenci šolskih okolišev na naši šoli</h3>";
        $SQL = "SELECT tabucenci.solskiokolis,count(tabucenci.solskiokolis) AS okolis,tabrazred.leto FROM tabucenci ";
        $SQL .= "INNER JOIN tabrazred ON tabucenci.iducenec=tabrazred.iducenec ";
        $SQL .= "GROUP BY tabrazred.leto,tabucenci.solskiokolis HAVING tabrazred.leto=".$VLeto;
        $result = mysqli_query($link,$SQL);
        echo "<table border='1'>";
        echo "<tr><th>Šola</th><th>Število učencev</th></tr>";
        while ($R = mysqli_fetch_array($result)){
            if (isset($R["solskiokolis"])){
                echo "<tr>";
                if ($R["solskiokolis"] == ""){
                    echo "<td>Lastni okoliš</td>";
                }else{
                    echo "<td>".$R["solskiokolis"]."</td>";
                }
                echo "<td align='center'>".$R["okolis"]."</td>";
                echo "</tr>";
            }
        }
        echo "</table>";
        break;
    case "300": //stat odsotnosti
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h3>Odsotnost na nivoju šole - ".$VLeto."/".($VLeto+1)."</h3>";
            echo "Opravičene ure<br />";
            $SQL = "SELECT tabrazdat.idsola,tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.opraviceno) AS countn FROM (tabprisotnost ";
            $SQL .= "INNER JOIN tabrazred ON tabprisotnost.iducenec=tabrazred.iducenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL .= "GROUP BY tabrazdat.idsola,tabprisotnost.leto,tabprisotnost.mesec ";
            //$SQL .= "HAVING leto=".$VLeto;
            $SQL .= "WHERE tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $result = mysqli_query($link,$SQL);

            $VSum=0;
            for ($Indx=0;$Indx <= 11;$Indx++){
                if ($Indx < 8){
                    $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                }else{
                    $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                }
                $aMonthValues[$Indx]=0;
            }

            while ($R = mysqli_fetch_array($result)){
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Opravičena odsotnost - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);

            echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";

            echo "<br />Neopravičene ure<br />";

            $SQL = "SELECT leto,mesec,sum(neopraviceno) AS countn FROM tabprisotnost GROUP BY leto,mesec HAVING leto=".$VLeto;
            $result = mysqli_query($link,$SQL);

            for ($Indx=0;$Indx <= 11;$Indx++){
                if ($Indx < 8){
                    $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                }else{
                    $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                }
                $aMonthValues[$Indx]=0;
            }

            $VSum=0;
            while ($R = mysqli_fetch_array($result)){
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Neopravičena odsotnost - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);

            echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";

            echo "<h3>Odsotnost na nivoju razredov - ".$VLeto."/".($VLeto+1)."</h3>";
            echo "Opravičene ure<br />";
            $SQL = "SELECT tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.opraviceno) AS countn,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola FROM ";
            $SQL = $SQL . "(tabprisotnost INNER JOIN tabrazred ON tabprisotnost.idUcenec=tabrazred.idUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "GROUP BY tabprisotnost.leto,tabprisotnost.mesec,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola ";
            $SQL .= "HAVING tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY razred,paralelka";
            $result = mysqli_query($link,$SQL);

            $VSum=0;
            $RazredComp="";
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp != $R["razred"].". ".strtolower($R["paralelka"])){
                    if (strlen($RazredComp) > 0){
                        displayverticalgraph ("Opravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
                        echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";
                    }
                    echo "<br />";
                    $RazredComp=$R["razred"].". ".strtolower($R["paralelka"]);
                    
                    for ($Indx=0;$Indx <= 11;$Indx++){
                        if ($Indx < 8){
                            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                        }else{
                            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                        }
                        $aMonthValues[$Indx]=0;
                    }
                    $VSum=0;
                }
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Opravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
            echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";

            echo "<br />Neopravičene ure<br />";

            $SQL = "SELECT tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.neopraviceno) AS countn,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabrazdat.idsola FROM ";
            $SQL = $SQL . "(tabprisotnost INNER JOIN tabrazred ON tabprisotnost.idUcenec=tabrazred.idUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "GROUP BY tabprisotnost.leto,tabprisotnost.mesec,tabrazred.leto,tabrazred.razred,tabrazred.paralelka ";
            $SQL .= "HAVING tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY razred,paralelka";
            $result = mysqli_query($link,$SQL);

            $VSum=0;
            $RazredComp="";
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp != $R["razred"].". ".strtolower($R["paralelka"])){
                    if (strlen($RazredComp) > 0){
                        displayverticalgraph ("Neopravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
                        echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";
                    }
                    echo "<br />";
                    $RazredComp=$R["razred"].". ".strtolower($R["paralelka"]);
                    
                    for ($Indx=0;$Indx <= 11;$Indx++){
                        if ($Indx < 8){
                            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                        }else{
                            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                        }
                        $aMonthValues[$Indx]=0;
                    }
                    $VSum=0;
                }
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Neopravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
            echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";
    /*
            echo "<h3>Odsotnost na nivoju učencev - ".$VLeto."/".($VLeto+1)."</h3>";
            echo "Opravičene ure<br />";
            $SQL = "SELECT tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.opraviceno) AS countn,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabucenci.idUcenec,tabucenci.priimek,tabucenci.ime FROM ";
            $SQL = $SQL . "(tabprisotnost INNER JOIN tabrazred ON tabprisotnost.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . " INNER JOIN tabucenci ON tabprisotnost.idUcenec=tabucenci.idUcenec ";
            $SQL = $SQL . "GROUP BY tabprisotnost.leto,tabprisotnost.mesec,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabucenci.idUcenec,tabucenci.priimek,tabucenci.ime HAVING tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime";
            $result = mysqli_query($link,$SQL);

            $RazredComp="";
            $VSum=0;
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp != $R["razred"].". ".strtolower($R["paralelka"])." - ".$R["priimek"]." ".$R["ime"]){
                    if (strlen($RazredComp) > 0){
                        displayverticalgraph ("Opravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
                        echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";
                    }
                    $RazredComp=$R["razred"].". ".strtolower($R["paralelka"])." - ".$R["priimek"]." ".$R["ime"];
                    for ($Indx=0;$Indx <= 11;$Indx++){
                        if ($Indx < 8){
                            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                        }else{
                            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                        }
                        $aMonthValues[$Indx]=0;
                    }
                    $VSum=0;
                }
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Opravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
            echo "Skupaj opravičene odsotnosti: ".$VSum." ur<br />";

            echo "<br />Neopravičene ure<br />";

            $SQL = "SELECT tabprisotnost.leto,tabprisotnost.mesec,sum(tabprisotnost.neopraviceno) AS countn,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabucenci.idUcenec,tabucenci.priimek,tabucenci.ime FROM ";
            $SQL = $SQL . "(tabprisotnost INNER JOIN tabrazred ON tabprisotnost.idUcenec=tabrazred.idUcenec) ";
            $SQL = $SQL . " INNER JOIN tabucenci ON tabprisotnost.idUcenec=tabucenci.idUcenec ";
            $SQL = $SQL . "GROUP BY tabprisotnost.leto,tabprisotnost.mesec,tabrazred.leto,tabrazred.razred,tabrazred.paralelka,tabucenci.idUcenec,tabucenci.priimek,tabucenci.ime HAVING tabprisotnost.leto=".$VLeto." AND tabrazred.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY razred,paralelka,priimek,ime";
            $result = mysqli_query($link,$SQL);

            $RazredComp="";
            $VSum=0;
            while ($R = mysqli_fetch_array($result)){
                if ($RazredComp != $R["razred"].". ".strtolower($R["paralelka"])." - ".$R["priimek"]." ".$R["ime"]){
                    if (strlen($RazredComp) > 0){
                        displayverticalgraph ("Neopravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
                        echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";
                    }
                    $RazredComp=$R["razred"].". ".strtolower($R["paralelka"])." - ".$R["priimek"]." ".$R["ime"];
                    for ($Indx=0;$Indx <= 11;$Indx++){
                        if ($Indx < 8){
                            $aMonthNames[$Indx+4]=$ImeMes[$Indx];
                        }else{
                            $aMonthNames[$Indx-8]=$ImeMes[$Indx];
                        }
                        $aMonthValues[$Indx]=0;
                    }
                    $VSum=0;
                }
                $VSum=$VSum+$R["countn"];
                if ($R["mesec"] < 8){
                    $aMonthValues[$R["mesec"]+3]=$R["countn"];
                }else{
                    $aMonthValues[$R["mesec"]-9]=$R["countn"];
                }
            }
            displayverticalgraph ("Neopravičena odsotnost ".$RazredComp." - ".$VLeto."/".($VLeto+1)." ","Ur","Mesec",$aMonthValues,$aMonthNames);
            echo "Skupaj neopravičene odsotnosti: ".$VSum." ur<br />";
    */        
        }
        break;
    case "400": //vzgojni ukrepi
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
    
            echo "<h2>Vzgojni ukrepi ".$VLeto."/".($VLeto+1)."</h2>";

            for ($Indx=0;$Indx <= 50;$Indx++){
                $razred[$Indx]="";
                for ($Indx0=0;$Indx0 <= 8;$Indx0++){
                    $VzgUkrepi[$Indx][$Indx0]=0;
                }
            }

            $SQL = "SELECT * FROM tabrazdat ";
            $SQL .= "WHERE leto=".$VLeto." AND razred > 0 AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,oznaka";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $razred[$Indx]=$R["razred"].". ".$R["oznaka"];
                $Indx=$Indx+1;
            }

            $SQL = "SELECT tabvzgukrepi.idukrep,tabrazred.razred,tabrazred.paralelka FROM (tabvzgukrepi ";
            $SQL .= "INNER JOIN tabrazred ON tabvzgukrepi.IdUcenec=tabrazred.IdUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabvzgukrepi.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY tabrazred.Razred,tabrazred.Paralelka";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 50;$Indx++){
                    if ($razred[$Indx]==$R["razred"].". ".$R["paralelka"]){
                        switch ($R["idukrep"]){
                            case 1:
                                $VzgUkrepi[$Indx][1]=$VzgUkrepi[$Indx][1]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][1]=$VzgUkrepi[0][1]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                                break;
                            case 2:
                                $VzgUkrepi[$Indx][2]=$VzgUkrepi[$Indx][2]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][2]=$VzgUkrepi[0][2]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                                break;
                            case 3:
                                $VzgUkrepi[$Indx][3]=$VzgUkrepi[$Indx][3]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][3]=$VzgUkrepi[0][3]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                                break;
                            case 4:
                                $VzgUkrepi[$Indx][4]=$VzgUkrepi[$Indx][4]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][4]=$VzgUkrepi[0][4]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                                break;
                            case 5:
                                $VzgUkrepi[$Indx][5]=$VzgUkrepi[$Indx][5]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][5]=$VzgUkrepi[0][5]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                                break;
                            case 6:
                                $VzgUkrepi[$Indx][6]=$VzgUkrepi[$Indx][6]+1;
                                $VzgUkrepi[$Indx][0]=$VzgUkrepi[$Indx][0]+1;
                                $VzgUkrepi[0][6]=$VzgUkrepi[0][6]+1;
                                $VzgUkrepi[0][0]=$VzgUkrepi[0][0]+1;
                        }
                    }
                }
            }

            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=cyan><th>Razred</th><th>I.</th><th>II.</th><th>III.</th><th>Skupaj</th></tr>";
            $i1=0;
            for ($Indx=1;$Indx <= 50;$Indx++){
                if (strlen($razred[$Indx]) > 0){
                    echo "<tr bgcolor='lightyellow'>";
                    echo "<td align=center bgcolor=khaki>".$razred[$Indx]."</td>";
                    echo "<td align=center>".$VzgUkrepi[$Indx][1]."</td>";
                    echo "<td align=center>".$VzgUkrepi[$Indx][2]."</td>";
                    echo "<td align=center>".$VzgUkrepi[$Indx][3]."</td>";
                    echo "<td align=center>".$VzgUkrepi[$Indx][0]."</td>";
                    echo "</tr>";
                    $aMonthValues[$i1]=$VzgUkrepi[$Indx][0];
                    $aMonthNames[$i1]=$razred[$Indx];
                    $i1=$i1+1;
                }
            }
            echo "<tr bgcolor='lightgreen'>";
            echo "<td align=center>Skupaj</td>";
            echo "<td align=center>".$VzgUkrepi[0][1]."</td>";
            echo "<td align=center>".$VzgUkrepi[0][2]."</td>";
            echo "<td align=center>".$VzgUkrepi[0][3]."</td>";
            echo "<td align=center>".$VzgUkrepi[0][0]."</td>";
            echo "</tr>";
            echo "</table><br />";

            if ($i1 > 0){
                displayverticalgraph ("Izrečeni vzgojni ukrepi - ".$VLeto."/".($VLeto+1)." ","Število","Razred",$aMonthValues,$aMonthNames);
            }
        }
        break;
    case "500": //stat pos ocen
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h2>Statistika ocen ".$VLeto."/".($VLeto+1)." 1. polletje</h2>";

            $SQL = "SELECT razred,oznaka FROM tabrazdat ";
            $SQL .= "WHERE leto=".$VLeto." AND razred >= 3 "." AND idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,oznaka";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Razred[$Indx][0]=$R["razred"];
                $Razred[$Indx][1]=$R["oznaka"];
                $Indx=$Indx+1;
            }
            $StRazredov=$Indx-1;
            $Razred[$StRazredov+1][0]=0;

            $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.oznaka,tabpredmeti.opis,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet FROM ";
            $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.id=tabucenje.predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND prioriteta IN (0,1) AND tabucenje.razred >= 3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY VrstniRed";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Predmet[$Indx][0]=$R["id"];
                $Predmet[$Indx][1]=$R["oznaka"];
                $Predmet[$Indx][2]=$R["opis"];
                $Predmet[$Indx][3]=$R["vrstnired"];
                $Predmet[$Indx][4]=$R["prioriteta"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
            for ($i=3;$i <= 9;$i++){
                for ($j=1;$j <= 8;$j++){
                    for ($k=1;$k <= $StPredmetov;$k++){
                        for ($l=0;$l <= 2;$l++){
                            $CountAvg[$i][$j][$k][$l]=0;
                        }
                    }
                }
            }
            $SQL = "SELECT tabocene.*,tabrazred.* FROM ";
            $SQL = $SQL . "(tabocene INNER JOIN tabrazred ON tabocene.idUcenec=tabrazred.idUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.razred >= 3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazred.razred,paralelka";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                switch (strtolower($R["Paralelka"])){
                    case "a":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][1][$Indx][1]=$CountAvg[intval($R["Razred"])][1][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][1][$Indx][0]=$CountAvg[intval($R["Razred"])][1][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][1][$Indx][2]=$CountAvg[intval($R["Razred"])][1][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "b":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][2][$Indx][1]=$CountAvg[intval($R["Razred"])][2][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][2][$Indx][0]=$CountAvg[intval($R["Razred"])][2][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][2][$Indx][2]=$CountAvg[intval($R["Razred"])][2][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "c":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][3][$Indx][1]=$CountAvg[intval($R["Razred"])][3][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][3][$Indx][0]=$CountAvg[intval($R["Razred"])][3][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][3][$Indx][2]=$CountAvg[intval($R["Razred"])][3][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "d":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][4][$Indx][1]=$CountAvg[intval($R["Razred"])][4][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][4][$Indx][0]=$CountAvg[intval($R["Razred"])][4][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][4][$Indx][2]=$CountAvg[intval($R["Razred"])][4][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "e":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][5][$Indx][1]=$CountAvg[intval($R["Razred"])][5][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][5][$Indx][0]=$CountAvg[intval($R["Razred"])][5][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][5][$Indx][2]=$CountAvg[intval($R["Razred"])][5][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "f":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][6][$Indx][1]=$CountAvg[intval($R["Razred"])][6][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][6][$Indx][0]=$CountAvg[intval($R["Razred"])][6][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][6][$Indx][2]=$CountAvg[intval($R["Razred"])][6][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "g":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][7][$Indx][1]=$CountAvg[intval($R["Razred"])][7][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][7][$Indx][0]=$CountAvg[intval($R["Razred"])][7][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][7][$Indx][2]=$CountAvg[intval($R["Razred"])][7][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    default:
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][8][$Indx][1]=$CountAvg[intval($R["Razred"])][8][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][8][$Indx][0]=$CountAvg[intval($R["Razred"])][8][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][8][$Indx][2]=$CountAvg[intval($R["Razred"])][8][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                }
            }

            echo "<table border=1>";
            echo "<tr><th>Razred</th><th>Predmet</th><th>Ocen</th><th>Povprečje</th><th>Negativnih</th></tr>";
            for ($Indx=3;$Indx <= 9;$Indx++){
                for ($i1=1;$i1 <= 8;$i1++){
                    for ($i2=1;$i2 <= $StPredmetov;$i2++){
                        if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                            echo "<tr>";
                            echo "<td>".$Indx.". ".chr(96+$i1)."</td>";
                            echo "<td>".$Predmet[$i2][1]."</td>";
                            echo "<td align=center>".$CountAvg[$Indx][$i1][$i2][0]."</td>";
                            echo "<td align=center>".number_format($CountAvg[$Indx][$i1][$i2][1]/$CountAvg[$Indx][$i1][$i2][0],2)."</td>";
                            echo "<td align=center>".$CountAvg[$Indx][$i1][$i2][2]."</td>";
                            echo "</tr>";
                        }
                    }
                }
            }
            echo "</table>";

            for ($Indx=0;$Indx <= 200;$Indx++){
                $Sume[$Indx][0]=0;
                $Sume[$Indx][1]=0;
                $Sume[$Indx][2]=0;
                $Sume[$Indx][3]=0;
                $Sume[$Indx][4]=0;
                $Sume[$Indx][5]=0;
            }

            for ($Indx=3;$Indx <= 6;$Indx++){
                for ($i1=1;$i1 <= 8;$i1++){
                    for ($i2=1;$i2 <= $StPredmetov;$i2++){
                        for ($i3=1;$i3 <= $StRazredov;$i3++){
                            if ($Razred[$i3][0]==$Indx){
                                if (($Razred[$i3][1]==chr(64+$i1)) or ($Razred[$i3][1]==chr(96+$i1)) ){
                                    if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                                        $Sume[$i3][0]=$Sume[$i3][0]+$CountAvg[$Indx][$i1][$i2][0]; //    'razred
                                        $Sume[$i3][1]=$Sume[$i3][1]+$CountAvg[$Indx][$i1][$i2][1];
                                    }
                                }
                                if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                                    $Sume[$Indx][2]=$Sume[$Indx][2]+$CountAvg[$Indx][$i1][$i2][0]; //    'paralelka
                                    $Sume[$Indx][3]=$Sume[$Indx][3]+$CountAvg[$Indx][$i1][$i2][1];
                                }
                            }
                        }
                        $Sume[4][4]=$Sume[4][4]+$CountAvg[$Indx][$i1][$i2][0]; //    'triada
                        $Sume[4][5]=$Sume[4][5]+$CountAvg[$Indx][$i1][$i2][1];
                    }
                }
            }

            for ($Indx=7;$Indx <= 9;$Indx++){
                for ($i1=1;$i1 <= 8;$i1++){
                    for ($i2=1;$i2 <= $StPredmetov;$i2++){
                        for ($i3=1;$i3 <= $StRazredov;$i3++){
                            if ($Razred[$i3][0]==$Indx){
                                if (($Razred[$i3][1]==chr(64+$i1)) or ($Razred[$i3][1]==chr(96+$i1))){
                                    if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                                        $Sume[$i3][0]=$Sume[$i3][0]+$CountAvg[$Indx][$i1][$i2][0];   // 'razred
                                        $Sume[$i3][1]=$Sume[$i3][1]+$CountAvg[$Indx][$i1][$i2][1];
                                    }
                                }
                                if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                                    $Sume[$Indx][2]=$Sume[$Indx][2]+$CountAvg[$Indx][$i1][$i2][0];  //  'paralelka
                                    $Sume[$Indx][3]=$Sume[$Indx][3]+$CountAvg[$Indx][$i1][$i2][1];
                                }
                            }
                        }
                        $Sume[7][4]=$Sume[7][4]+$CountAvg[$Indx][$i1][$i2][0]; //   'triada
                        $Sume[7][5]=$Sume[7][5]+$CountAvg[$Indx][$i1][$i2][1];
                    }
                }
            }

            for ($Indx=0;$Indx <= 100;$Indx++){
                $aMonthValues[$Indx]=0;    
                $aMonthNames[$Indx]="";
            }
            $Indx=1;
            $i1=0;
            for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                if ($Razred[$Indx][0] < 7){
                    if ($Sume[$Indx][0] > 0){
                        $aMonthValues[$i1]=number_format($Sume[$Indx][1]/$Sume[$Indx][0],2);
                    }else{
                        $aMonthValues[$i1]=0;
                    }
                    $aMonthNames[$i1]=$Razred[$Indx][0].".".strtolower($Razred[$Indx][1]);
                    $i1=$i1+1;
                    if ($Razred[$Indx+1][0] != $Razred[$Indx][0]){
                        if ($Sume[$Razred[$Indx][0]][2] > 0){
                            $aMonthValues[$i1]=number_format($Sume[$Razred[$Indx][0]][3]/$Sume[$Razred[$Indx][0]][2],2);
                        }else{
                            $aMonthValues[$i1]=0;
                        }
                        $aMonthNames[$i1]=$Razred[$Indx][0].".r skupaj";
                        $i1=$i1+1;
                        
                        if ($Razred[$Indx][0]==6){
                            if ($Sume[4][4] > 0){
                                $aMonthValues[$i1]=number_format($Sume[4][5]/$Sume[4][4],2);
                            }else{
                                $aMonthValues[$i1]=0;
                            }
                            $aMonthNames[$i1]="2. triada skupaj";
                            $i1=$i1+1;
                        }
                    }
                }
            }
            displayverticalgraph ("Statistika ocen za 2. triado - ".$VLeto."/".($VLeto+1)." 1. polletje","Povprečje","Razred",$aMonthValues,$aMonthNames);

            for ($Indx=0;$Indx <= 100;$Indx++){
                $aMonthValues[$Indx]=0;
                $aMonthNames[$Indx]="";
            }
            $Indx=1;
            $i1=0;
            for ($Indx=1;$Indx <= $StRazredov;$Indx++){ 
                if ($Razred[$Indx][0] > 6){
                    if ($Sume[$Indx][0] > 0){
                        $aMonthValues[$i1]=number_format($Sume[$Indx][1]/$Sume[$Indx][0],2);
                    }else{
                        $aMonthValues[$i1]=0;
                    }
                    $aMonthNames[$i1]=$Razred[$Indx][0].".".strtolower($Razred[$Indx][1]);
                    $i1=$i1+1;
                    if ($Razred[$Indx+1][0] != $Razred[$Indx][0]){
                        if ($Sume[$Razred[$Indx][0]][2] > 0){
                            $aMonthValues[$i1]=number_format($Sume[$Razred[$Indx][0]][3]/$Sume[$Razred[$Indx][0]][2],2);
                        }else{
                            $aMonthValues[$i1]=0;
                        }
                        $aMonthNames[$i1]=$Razred[$Indx][0].".r skupaj";
                        $i1=$i1+1;
                        
                        if ($Razred[$Indx][0]==9){
                            if ($Sume[7][4] > 0){
                                $aMonthValues[$i1]=number_format($Sume[7][5]/$Sume[7][4],2);
                            }else{
                                $aMonthValues[$i1]=0;
                            }
                            $aMonthNames[$i1]="3. triada skupaj";
                            $i1=$i1+1;
                        }
                    }
                }
            }
            displayverticalgraph ("Statistika ocen za 3. triado - ".$VLeto."/".($VLeto+1)." 1. polletje","Povprečje","Razred",$aMonthValues,$aMonthNames);

            //'negativne in povprečne ocene po predmetih
            for ($Indx=0;$Indx <= 200;$Indx++){
                $Sume[$Indx][0]=0;
                $Sume[$Indx][1]=0;
                $Sume[$Indx][2]=0;
                $Sume[$Indx][3]=0;
                $Sume[$Indx][4]=0;
                $Sume[$Indx][5]=0;
            }
            for ($Indx=3;$Indx <= 9;$Indx++){
                for ($i1=1;$i1 <= 8;$i1++){
                    for ($i2=1;$i2 <= $StPredmetov;$i2++){
                        $Sume[$i2][0]=$Sume[$i2][0]+$CountAvg[$Indx][$i1][$i2][0];  //  'št ocen
                        $Sume[$i2][1]=$Sume[$i2][1]+$CountAvg[$Indx][$i1][$i2][1];  //  'suma za povprečje
                        $Sume[$i2][2]=$Sume[$i2][2]+$CountAvg[$Indx][$i1][$i2][2];  //  'negativne
                    }
                }
            }


            for ($Indx=0;$Indx <= 100;$Indx++){
                $aMonthValues[$Indx]=0;
                $aMonthNames[$Indx]="";
            }
            $Indx=1;
            $i1=0;
            for ($Indx=1;$Indx <= $StPredmetov;$Indx++){ 
                if ($Predmet[$Indx][4] == 0){
                    if ($Sume[$Indx][2] > 0){
                        $aMonthValues[$Indx-1]=$Sume[$Indx][2];
                    }else{
                        $aMonthValues[$Indx-1]=0;
                    }
                    $aMonthNames[$Indx-1]=$Predmet[$Indx][1];
                }
            }
            displayverticalgraph ("Število negativnih ocen po predmetih - ".$VLeto."/".($VLeto+1)." 1. polletje","Negativne ocene","Predmeti",$aMonthValues,$aMonthNames);

            for ($Indx=0;$Indx <= 100;$Indx++){
                $aMonthValues[$Indx]=0;
                $aMonthNames[$Indx]="";
            }
            $Indx=1;
            $i1=0;
            for ($Indx=1;$Indx <= $StPredmetov;$Indx++){ 
                if ($Predmet[$Indx][4] == 0){
                    if ($Sume[$Indx][0] > 0){
                        $aMonthValues[$i1]=number_format($Sume[$Indx][1]/$Sume[$Indx][0],2);
                    }else{
                        $aMonthValues[$i1]=0;
                    }
                    $aMonthNames[$i1]=$Predmet[$Indx][1];
                    $i1=$i1+1;
                }
            }
            displayverticalgraph ("Povprečne ocene pri predmetih - ".$VLeto."/".($VLeto+1)." 1. polletje","Ocena","Predmeti",$aMonthValues,$aMonthNames);

            for ($Indx=0;$Indx <= 100;$Indx++){
                $aMonthValues[$Indx]=0;
                $aMonthNames[$Indx]="";
            }
            $Indx=1;
            $i1=0;
            for ($Indx=1;$Indx <= $StPredmetov;$Indx++){ 
                if ($Predmet[$Indx][4] == 1){
                    if ($Sume[$Indx][0] > 0){
                        $aMonthValues[$i1]=number_format($Sume[$Indx][1]/$Sume[$Indx][0],2);
                    }else{
                        $aMonthValues[$i1]=0;
                    }
                    $aMonthNames[$i1]=$Predmet[$Indx][1];
                    $i1=$i1+1;
                }
            }
            displayverticalgraph ("Povprečne ocene pri izbirnih predmetih - ".$VLeto."/".($VLeto+1)." 1. polletje","Ocena","Predmeti",$aMonthValues,$aMonthNames);
        }
        break;
    case "510": //stat pos ocen razred
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h2>Statistika ocen ".$VLeto."/".($VLeto+1)." 1. polletje</h2>";

            $SQL = "SELECT DISTINCT tabrazred.razred,tabrazred.paralelka FROM tabrazred ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazred.razred >= 3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY tabrazred.razred,paralelka";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Razred[$Indx][0]=$R["razred"];
                $Razred[$Indx][1]=$R["paralelka"];
                $Indx=$Indx+1;
            }
            $StRazredov=$Indx-1;

            $SQL = "SELECT DISTINCT tabpredmeti.id,tabpredmeti.oznaka,tabpredmeti.opis,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet FROM ";
            $SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.id=tabucenje.predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabucenje.leto=".$VLeto." AND prioriteta IN (0,1) AND tabucenje.razred >= 3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY VrstniRed";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $Predmet[$Indx][0]=$R["id"];
                $Predmet[$Indx][1]=$R["oznaka"];
                $Predmet[$Indx][2]=$R["opis"];
                $Predmet[$Indx][3]=$R["vrstnired"];
                $Predmet[$Indx][4]=$R["prioriteta"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
            for ($i=3;$i <= 9;$i++){
                for ($j=1;$j <= 8;$j++){
                    for ($k=1;$k <= $StPredmetov;$k++){
                        for ($l=0;$l <= 2;$l++){
                            $CountAvg[$i][$j][$k][$l]=0;
                        }
                    }
                }
            }
     
            $SQL = "SELECT tabocene.*,tabrazred.* FROM ";
            $SQL = $SQL . "(tabocene INNER JOIN tabrazred ON tabocene.idUcenec=tabrazred.idUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL . "WHERE tabocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabrazred.razred >= 3 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL . " ORDER BY tabrazred.razred,paralelka";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                switch (strtolower($R["Paralelka"])){
                    case "a":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][1][$Indx][1]=$CountAvg[intval($R["Razred"])][1][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][1][$Indx][0]=$CountAvg[intval($R["Razred"])][1][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][1][$Indx][2]=$CountAvg[intval($R["Razred"])][1][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "b":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][2][$Indx][1]=$CountAvg[intval($R["Razred"])][2][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][2][$Indx][0]=$CountAvg[intval($R["Razred"])][2][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][2][$Indx][2]=$CountAvg[intval($R["Razred"])][2][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "c":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][3][$Indx][1]=$CountAvg[intval($R["Razred"])][3][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][3][$Indx][0]=$CountAvg[intval($R["Razred"])][3][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][3][$Indx][2]=$CountAvg[intval($R["Razred"])][3][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "d":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][4][$Indx][1]=$CountAvg[intval($R["Razred"])][4][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][4][$Indx][0]=$CountAvg[intval($R["Razred"])][4][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][4][$Indx][2]=$CountAvg[intval($R["Razred"])][4][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "e":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][5][$Indx][1]=$CountAvg[intval($R["Razred"])][5][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][5][$Indx][0]=$CountAvg[intval($R["Razred"])][5][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][5][$Indx][2]=$CountAvg[intval($R["Razred"])][5][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "f":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][6][$Indx][1]=$CountAvg[intval($R["Razred"])][6][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][6][$Indx][0]=$CountAvg[intval($R["Razred"])][6][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][6][$Indx][2]=$CountAvg[intval($R["Razred"])][6][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    case "g":
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][7][$Indx][1]=$CountAvg[intval($R["Razred"])][7][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][7][$Indx][0]=$CountAvg[intval($R["Razred"])][7][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][7][$Indx][2]=$CountAvg[intval($R["Razred"])][7][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                        break;
                    default:
                        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
                            if ($R["IdPredmet"]==$Predmet[$Indx][0]){
                                $CountAvg[intval($R["Razred"])][8][$Indx][1]=$CountAvg[intval($R["Razred"])][8][$Indx][1]+PovpOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][8][$Indx][0]=$CountAvg[intval($R["Razred"])][8][$Indx][0]+NOc($R["OcenaS1P"].$R["OcenaS1U"]);
                                $CountAvg[intval($R["Razred"])][8][$Indx][2]=$CountAvg[intval($R["Razred"])][8][$Indx][2]+NegOc($R["OcenaS1P"].$R["OcenaS1U"]);
                            }
                        }
                }
            }

            for ($Indx=3;$Indx <= 9;$Indx++){
                for ($i1=1;$i1 <= 8;$i1++){
                    $razred_obstaja=false;
                    for ($i4=1;$i4 <= $StRazredov;$i4++){
                        if (($Razred[$i4][0]==$Indx) && (($Razred[$i4][1]==chr(64+$i1)) or ($Razred[$i4][1]==chr(96+$i1)))){
                            $razred_obstaja=true;
                            break;
                        }
                    }
                    if ($razred_obstaja){
                        echo "<h2>".$Indx.". ".chr(96+$i1)."</h2>";
                        echo "<table border=1>";
                        echo "<tr><th>Razred</th><th>Predmet</th><th>Ocen</th><th>Povprečje</th><th>Negativnih</th></tr>";
                        for ($i2=1;$i2 <= $StPredmetov;$i2++){
                            if ($CountAvg[$Indx][$i1][$i2][0] > 0){
                                echo "<tr>";
                                echo "<td>".$Indx.". ".chr(96+$i1)."</td>";
                                echo "<td>".$Predmet[$i2][1]."</td>";
                                echo "<td align=center>".$CountAvg[$Indx][$i1][$i2][0]."</td>";
                                echo "<td align=center>".number_format($CountAvg[$Indx][$i1][$i2][1]/$CountAvg[$Indx][$i1][$i2][0],2)."</td>";
                                echo "<td align=center>".$CountAvg[$Indx][$i1][$i2][2]."</td>";
                                echo "</tr>";
                            }
                        }
                        echo "</table><br />";
                        
                        for ($i3=0;$i3 <= 100;$i3++){
                            $aMonthValues[$i3]=0;
                            $aMonthNames[$i3]="";
                        }
                        $Indx0=1;
                        $i0=0;
                        for ($Indx0=1;$Indx0 <= $StPredmetov;$Indx0++){
                            if ($Predmet[$Indx0][4] == 0){
                                if ($CountAvg[$Indx][$i1][$Indx0][0] > 0){
                                    $aMonthValues[$i0]=number_format($CountAvg[$Indx][$i1][$Indx0][1]/$CountAvg[$Indx][$i1][$Indx0][0],2);
                                    $aMonthNames[$i0]=$Predmet[$Indx0][1];
                                    $i0=$i0+1;
                                }
                            }
                        }
                        if ($i0 > 0){
                            displayverticalgraph ("Povprečne ocene pri predmetih - ".$VLeto."/".($VLeto+1)." 1. polletje","Ocena","Predmeti",$aMonthValues,$aMonthNames);
                        }
                        
                        for ($i3=0;$i3 <= 100;$i3++){
                            $aMonthValues[$i3]=0;
                            $aMonthNames[$i3]="";
                        }
                        $Indx0=1;
                        $i0=0;
                        for ($Indx0=1;$Indx0 <= $StPredmetov;$Indx0++){
                            if ($Predmet[$Indx0][4] == 0){
                                if ($CountAvg[$Indx][$i1][$Indx0][0] > 0){
                                    $aMonthValues[$i0]=$CountAvg[$Indx][$i1][$Indx0][2];
                                    $aMonthNames[$i0]=$Predmet[$Indx0][1];
                                    $i0=$i0+1;
                                }
                            }
                        }
                        if ($i0 > 0){
                            displayverticalgraph ("Število negativnih ocen pri predmetih - ".$VLeto."/".($VLeto+1)." 1. polletje","Ocena","Predmeti",$aMonthValues,$aMonthNames);
                        }
                    }
                }
            }
        }
        break;
    case "520": //izpis uspeha razredi
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h2>Uspeh po razredih - ".$VLeto."/".($VLeto+1)."</h2>";

            if ($VLeto < 2008){
                $SQL = "SELECT tabrazred.uspeh,tabrazred.napredovanje,tabrazdat.razred,tabrazdat.oznaka FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto;
                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);

                for ($Indx = 0;$Indx <= 100;$Indx++){
                    for ($i1=0;$i1 <= 10;$i1++){
                        $CountUsp[$Indx][$i1]=0;
                    }
                }

                $Indx=1;
                if ($R = mysqli_fetch_array($result)){
                    $RazredComp=$R["razred"].". ".$R["oznaka"];
                }

                echo "<table border=1>";
                echo "<tr><th>Razred</th><th>Učencev</th><th>4.51-5.00</th><th>3.51-4.50</th><th>2.51-3.50</th><th>1.51-2.50</th><th>Nezadostni</th><th>Napredujejo</th><th>Napredujejo<br />z nezadostno</th><th>Ne napredujejo</th></tr>";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    if ($RazredComp != $R["razred"].". ".$R["oznaka"]){
                        if (intval(substr($RazredComp,0,1)) < 4){
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][1]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][2]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][3]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][4]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][5]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][7]."</td>";
                            echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                            echo "</tr>";
                        }
                        $Indx=$Indx+1;
                        $RazredComp=$R["razred"].". ".$R["oznaka"];
                        
                        $CountUsp[$Indx][0]=$CountUsp[$Indx][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        switch ($R["uspeh"]){
                            case 5:
                                $CountUsp[$Indx][1]=$CountUsp[$Indx][1]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][1]=$CountUsp[0][1]+1;
                                }
                                break;
                            case 4:
                                $CountUsp[$Indx][2]=$CountUsp[$Indx][2]+1;
                                $CountUsp[0][2]=$CountUsp[0][2]+1;
                                break;
                            case 3:
                                $CountUsp[$Indx][3]=$CountUsp[$Indx][3]+1;
                                $CountUsp[0][3]=$CountUsp[0][3]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][4]=$CountUsp[$Indx][4]+1;
                                $CountUsp[0][4]=$CountUsp[0][4]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][5]=$CountUsp[$Indx][5]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][5]=$CountUsp[0][5]+1;
                                }
                        }
                        switch ($R["napredovanje"]){
                            case 0:
                                $CountUsp[$Indx][6]=$CountUsp[$Indx][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][7]=$CountUsp[$Indx][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][8]=$CountUsp[$Indx][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }else{
                        $CountUsp[$Indx][0]=$CountUsp[$Indx][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        switch ($R["uspeh"]){
                            case 5:
                                $CountUsp[$Indx][1]=$CountUsp[$Indx][1]+1;
                                if ($R["tabrazdat.razred"] > 3){
                                    $CountUsp[0][1]=$CountUsp[0][1]+1;
                                }
                                break;
                            case 4:
                                $CountUsp[$Indx][2]=$CountUsp[$Indx][2]+1;
                                $CountUsp[0][2]=$CountUsp[0][2]+1;
                                break;
                            case 3:
                                $CountUsp[$Indx][3]=$CountUsp[$Indx][3]+1;
                                $CountUsp[0][3]=$CountUsp[0][3]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][4]=$CountUsp[$Indx][4]+1;
                                $CountUsp[0][4]=$CountUsp[0][4]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][5]=$CountUsp[$Indx][5]+1;
                                if ($R["razred"] > 3){
                                    $CountUsp[0][5]=$CountUsp[0][5]+1;
                                }
                        }
                        switch ($R["napredovanje"]){
                            case 0:
                                $CountUsp[$Indx][6]=$CountUsp[$Indx][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$Indx][7]=$CountUsp[$Indx][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$Indx][8]=$CountUsp[$Indx][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }
                }
                echo "<tr>";
                echo "<td>".$RazredComp."</td>";
                echo "<td align=center>".$CountUsp[$Indx][0]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][1]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][2]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][3]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][4]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][5]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][6]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][7]."</td>";
                echo "<td align=center>".$CountUsp[$Indx][8]."</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>Skupaj</td>";
                echo "<td align=center>".$CountUsp[0][0]."</td>";
                echo "<td align=center>".$CountUsp[0][1]."</td>";
                echo "<td align=center>".$CountUsp[0][2]."</td>";
                echo "<td align=center>".$CountUsp[0][3]."</td>";
                echo "<td align=center>".$CountUsp[0][4]."</td>";
                echo "<td align=center>".$CountUsp[0][5]."</td>";
                echo "<td align=center>".$CountUsp[0][6]."</td>";
                echo "<td align=center>".$CountUsp[0][7]."</td>";
                echo "<td align=center>".$CountUsp[0][8]."</td>";
                echo "</tr>";

                echo "</table>";
            }else{ // >= 2008
                $SQL = "SELECT tabrazred.iducenec,tabrazred.napredovanje,tabrazred.id,tabrazdat.razred,tabrazdat.oznaka FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND tabrazdat.razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL = $SQL . " ORDER BY tabrazdat.razred,tabrazdat.oznaka";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Ucenec[$Indx][0]=$R["iducenec"];
                    $Ucenec[$Indx][1]=$R["razred"].". ".$R["oznaka"];
                    $Ucenec[$Indx][2]=$R["napredovanje"];
                    $Ucenec[$Indx][4]=$R["razred"];
                    $Ucenec[$Indx][5]=$R["id"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx-1;
                
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    $Ucenec[$Indx][3]=Povprecje($Ucenec[$Indx][0],$Ucenec[$Indx][4]);
                    $SQL = "UPDATE tabrazred SET uspeh='".$Ucenec[$Indx][3]."' WHERE id=".$Ucenec[$Indx][5];
                    $result = mysqli_query($link,$SQL);
                }
                for ($Indx = 0;$Indx <= 100;$Indx++){
                    for ($i1=0;$i1 <= 10;$i1++){
                        $CountUsp[$Indx][$i1]=0;
                    }
                }

                $i1=1;
                $RazredComp=$Ucenec[1][1];

                echo "<table border=1>";
                echo "<tr><th>Razred</th><th>Učencev</th><th>4.6-5.0</th><th>3.6-4.5</th><th>2.6-3.5</th><th>1.6-2.5</th><th>Nezadostni</th><th>Napredujejo</th><th>Napredujejo<br />z nezadostno</th><th>Ne napredujejo</th><th>% uspeha</th></tr>";
                for ($Indx=1;$Indx <= $StUcencev;$Indx++){
                    if ($RazredComp != $Ucenec[$Indx][1]){
                        if (intval(substr($RazredComp,0,1)) < 3){
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                            echo "<td></td>";
                            echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                            if ($CountUsp[$i1][0] > 0){
                                echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>".$RazredComp."</td>";
                            echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][1]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][2]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][3]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][4]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][5]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][7]."</td>";
                            echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                            if ($CountUsp[$i1][0] > 0){
                                echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                            echo "</tr>";
                        }
                        $RazredComp=$Ucenec[$Indx][1];
                        $i1=$i1+1;
                        $CountUsp[$i1][0]=$CountUsp[$i1][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        if ($Ucenec[$Indx][3] >= 4.6){
                            $CountUsp[$i1][1]=$CountUsp[$i1][1]+1;
                            if ($Ucenec[$Indx][4] > 3){    
                                $CountUsp[0][1]=$CountUsp[0][1]+1;
                            }
                        }
                        if (($Ucenec[$Indx][3] >= 3.6) && ($Ucenec[$Indx][3] < 4.6)){
                            $CountUsp[$i1][2]=$CountUsp[$i1][2]+1;
                            $CountUsp[0][2]=$CountUsp[0][2]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 2.6) && ($Ucenec[$Indx][3] < 3.6)){
                            $CountUsp[$i1][3]=$CountUsp[$i1][3]+1;
                            $CountUsp[0][3]=$CountUsp[0][3]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 1.6) && ($Ucenec[$Indx][3] < 2.6)){
                            $CountUsp[$i1][4]=$CountUsp[$i1][4]+1;
                            $CountUsp[0][4]=$CountUsp[0][4]+1;
                        }
                        if ($Ucenec[$Indx][3] < 1.6){
                            $CountUsp[$i1][5]=$CountUsp[$i1][5]+1;
                            if ($Ucenec[$Indx][4] > 3){ 
                                $CountUsp[0][5]=$CountUsp[0][5]+1;
                            }
                        }
                        
                        switch ($Ucenec[$Indx][2]){
                            case 0:
                                $CountUsp[$i1][6]=$CountUsp[$i1][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$i1][7]=$CountUsp[$i1][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$i1][8]=$CountUsp[$i1][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }else{
                        $CountUsp[$i1][0]=$CountUsp[$i1][0]+1;
                        $CountUsp[0][0]=$CountUsp[0][0]+1;
                        if ($Ucenec[$Indx][3] >= 4.6){
                            $CountUsp[$i1][1]=$CountUsp[$i1][1]+1;
                            if ($Ucenec[$Indx][4] > 3){    
                                $CountUsp[0][1]=$CountUsp[0][1]+1;
                            }
                        }
                        if (($Ucenec[$Indx][3] >= 3.6) && ($Ucenec[$Indx][3] < 4.6)){
                            $CountUsp[$i1][2]=$CountUsp[$i1][2]+1;
                            $CountUsp[0][2]=$CountUsp[0][2]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 2.6) && ($Ucenec[$Indx][3] < 3.6)){
                            $CountUsp[$i1][3]=$CountUsp[$i1][3]+1;
                            $CountUsp[0][3]=$CountUsp[0][3]+1;
                        }
                        if (($Ucenec[$Indx][3] >= 1.6) && ($Ucenec[$Indx][3] < 2.6)){
                            $CountUsp[$i1][4]=$CountUsp[$i1][4]+1;
                            $CountUsp[0][4]=$CountUsp[0][4]+1;
                        }
                        if ($Ucenec[$Indx][3] < 1.6){
                            $CountUsp[$i1][5]=$CountUsp[$i1][5]+1;
                            if ($Ucenec[$Indx][4] > 3){ 
                                $CountUsp[0][5]=$CountUsp[0][5]+1;
                            }
                        }
                        switch ($Ucenec[$Indx][2]){
                            case 0:
                                $CountUsp[$i1][6]=$CountUsp[$i1][6]+1;
                                $CountUsp[0][6]=$CountUsp[0][6]+1;
                                break;
                            case 1:
                                $CountUsp[$i1][7]=$CountUsp[$i1][7]+1;
                                $CountUsp[0][7]=$CountUsp[0][7]+1;
                                break;
                            case 2:
                                $CountUsp[$i1][8]=$CountUsp[$i1][8]+1;
                                $CountUsp[0][8]=$CountUsp[0][8]+1;
                        }
                    }
                }
                echo "<tr>";
                echo "<td>".$RazredComp."</td>";
                echo "<td align=center>".$CountUsp[$i1][0]."</td>";
                echo "<td align=center>".$CountUsp[$i1][1]."</td>";
                echo "<td align=center>".$CountUsp[$i1][2]."</td>";
                echo "<td align=center>".$CountUsp[$i1][3]."</td>";
                echo "<td align=center>".$CountUsp[$i1][4]."</td>";
                echo "<td align=center>".$CountUsp[$i1][5]."</td>";
                echo "<td align=center>".$CountUsp[$i1][6]."</td>";
                echo "<td align=center>".$CountUsp[$i1][7]."</td>";
                echo "<td align=center>".$CountUsp[$i1][8]."</td>";
                if ($CountUsp[$i1][0] > 0){
                    echo "<td align='right'>".number_format($CountUsp[$i1][6]/$CountUsp[$i1][0]*100,2)."%</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                echo "<tr>";
                echo "<td>Skupaj</td>";
                echo "<td align=center>".$CountUsp[0][0]."</td>";
                echo "<td align=center>".$CountUsp[0][1]."</td>";
                echo "<td align=center>".$CountUsp[0][2]."</td>";
                echo "<td align=center>".$CountUsp[0][3]."</td>";
                echo "<td align=center>".$CountUsp[0][4]."</td>";
                echo "<td align=center>".$CountUsp[0][5]."</td>";
                echo "<td align=center>".$CountUsp[0][6]."</td>";
                echo "<td align=center>".$CountUsp[0][7]."</td>";
                echo "<td align=center>".$CountUsp[0][8]."</td>";
                if ($CountUsp[0][0] > 0){
                    echo "<td align='right'>".number_format($CountUsp[0][6]/$CountUsp[0][0]*100,2)."%</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";

                echo "</table>";

            }
        }
        break;
    case "530": //stat ocene
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h2>Statistika zaključnih ocen ".$VLeto."/".($VLeto+1)."</h2>";

            for ($Indx=0;$Indx <= 50;$Indx++){
                $Razred[$Indx]="";
            }
            $SQL = "SELECT id,oznaka,prioriteta,vrstnired FROM tabpredmeti ";
            $SQL .= "WHERE Prioriteta IN (0,1) ";
            $SQL .= " ORDER BY VrstniRed,id";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmet[$Indx][0]=$R["id"];
                $Predmet[$Indx][1]=$R["oznaka"];
                $Predmet[$Indx][2]=$R["prioriteta"];
                $Predmet[$Indx][3]=$R["vrstnired"];
                $Indx=$Indx+1;
            }
            //$StPredmetov=$Indx-1;
            $SQL = "SELECT id FROM tabpredmeti ORDER BY id DESC LIMIT 0,1";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $StPredmetov=$R["id"];
            }
            for ($Indx=0;$Indx <= $StPredmetov;$Indx++){
                for ($Indx0=0;$Indx0 <= 6;$Indx0++){
                    $Ocena[$Indx][$Indx0]=0;
                }
            }
            
            $SQL = "SELECT tabocene.ocenakoncna,tabocene.idpredmet FROM ";
            $SQL = $SQL."((tabocene INNER JOIN tabpredmeti ON tabocene.IdPredmet=tabpredmeti.Id) ";
            $SQL .= "INNER JOIN tabrazred ON tabocene.iducenec=tabrazred.iducenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL = $SQL."WHERE tabocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabpredmeti.Prioriteta IN (0,1) "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL = $SQL." ORDER BY tabpredmeti.id";
            $result = mysqli_query($link,$SQL);

            $Indx0=1;
            while ($R = mysqli_fetch_array($result)){
                switch ($R["ocenakoncna"]){
                    case "5":
                        $Ocena[$R["idpredmet"]][5]=$Ocena[$R["idpredmet"]][5]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "4":
                        $Ocena[$R["idpredmet"]][4]=$Ocena[$R["idpredmet"]][4]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "3":
                        $Ocena[$R["idpredmet"]][3]=$Ocena[$R["idpredmet"]][3]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "2":
                        $Ocena[$R["idpredmet"]][2]=$Ocena[$R["idpredmet"]][2]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "1":
                    case "Ni opravil":
                        $Ocena[$R["idpredmet"]][1]=$Ocena[$R["idpredmet"]][1]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "ZU":
                        $Ocena[$R["idpredmet"]][5]=$Ocena[$R["idpredmet"]][5]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "U":
                        $Ocena[$R["idpredmet"]][4]=$Ocena[$R["idpredmet"]][4]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "MU":
                        $Ocena[$R["idpredmet"]][2]=$Ocena[$R["idpredmet"]][2]+1;
                        $Ocena[$R["idpredmet"]][0]=$Ocena[$R["idpredmet"]][0]+1;
                        break;
                    case "Opravil":
                        $Ocena[$R["idpredmet"]][6]=$Ocena[$R["idpredmet"]][6]+1;
                }
                $Indx0=$Indx0+1;
            }

            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=cyan><th>Predmet</th><th>5</th><th>4</th><th>3</th><th>2</th><th>NMS</th><th>Skupaj</th><th>Povprečje</th></tr>";
            $i1=0;
            for ($Indx=0;$Indx <= $StPredmetov;$Indx++){
                if (isset($Predmet[$Indx][0]) && ($Ocena[$Predmet[$Indx][0]][0] > 0)){
                    echo "<tr bgcolor=lightyellow>";
                    echo "<td bgcolor=khaki>".$Predmet[$Indx][1]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][5]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][4]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][3]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][2]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][1]."</td>";
                    echo "<td align=right>".$Ocena[$Predmet[$Indx][0]][0]."</td>";
                    if ($Ocena[$Predmet[$Indx][0]][0] > 0){
                        echo "<td align=right>".number_format(($Ocena[$Predmet[$Indx][0]][5]*5+$Ocena[$Predmet[$Indx][0]][4]*4+$Ocena[$Predmet[$Indx][0]][3]*3+$Ocena[$Predmet[$Indx][0]][2]*2+$Ocena[$Predmet[$Indx][0]][1])/$Ocena[$Predmet[$Indx][0]][0],2)."</td>";
                    }else{
                        echo "<td>&nbsp;</td>";
                    }
                    echo "</tr>";
                    $aMonthValues[$i1]=number_format(($Ocena[$Predmet[$Indx][0]][5]*5+$Ocena[$Predmet[$Indx][0]][4]*4+$Ocena[$Predmet[$Indx][0]][3]*3+$Ocena[$Predmet[$Indx][0]][2]*2+$Ocena[$Predmet[$Indx][0]][1])/$Ocena[$Predmet[$Indx][0]][0],2);
                    $aMonthNames[$i1]=$Predmet[$Indx][1];
                    $i1=$i1+1;
                }
            }
            echo "</table><br />";
            if ($i1 > 0){
                displayverticalgraph ("Povprečje zaključnih ocen - ".$VLeto."/".($VLeto+1)." ","Ocena","Predmeti",$aMonthValues,$aMonthNames);
            }
        }
        break;
    case "540": //stat ocene razredi
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            echo "<h2>Statistika ocen ".$VLeto."/".($VLeto+1)."</h2>";

            $SQL = "SELECT id FROM tabpredmeti ORDER BY id DESC LIMIT 0,1";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $StPredmetov=$R["id"];
            }
            for ($Indx=0;$Indx <= 50;$Indx++){
                $Razred[$Indx][0]="";
                $Razred[$Indx][1]=0;
            }
            for ($Indx=0;$Indx <= 50;$Indx++){
                for ($Indx0=0;$Indx0 <= $StPredmetov;$Indx0++){
                    for ($Indx1=1;$Indx1 <= 2;$Indx1++){
                        $Ocena[$Indx][$Indx0][$Indx1]=0;
                    }
                }
            }
            $SQL = "SELECT id,oznaka,prioriteta,vrstnired FROM tabpredmeti WHERE Prioriteta IN (0,1) ORDER BY VrstniRed,Id";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmet[$Indx][0]=$R["id"];
                $Predmet[$Indx][1]=$R["oznaka"];
                $Predmet[$Indx][2]=$R["prioriteta"];
                $Predmet[$Indx][3]=$R["vrstnired"];
                $Indx=$Indx+1;
            }
            
            $SQL = "SELECT tabocene.ocenakoncna,tabocene.idpredmet,tabrazred.razred,tabrazred.paralelka FROM ";
            $SQL =$SQL."((tabocene INNER JOIN tabpredmeti ON tabocene.IdPredmet=tabpredmeti.Id) ";
            $SQL =$SQL."INNER JOIN tabrazred ON tabocene.IdUcenec=tabrazred.IdUcenec) ";
            $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
            $SQL =$SQL."WHERE tabocene.leto=".$VLeto." AND tabrazred.leto=".$VLeto." AND tabpredmeti.Prioriteta IN (0,1) "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL =$SQL." ORDER BY tabrazred.Razred,tabrazred.Paralelka";
            $result = mysqli_query($link,$SQL);

            $VRazred="";
            $Indx=0;    //stevec razredov
            while ($R = mysqli_fetch_array($result)){
                $VStrRazred=$R["razred"].". ".$R["paralelka"];
                if ($VStrRazred != $VRazred){
                    $Indx=$Indx+1;
                    $Razred[$Indx][0]=$VStrRazred;
                    $Razred[$Indx][1]=$R["razred"];
                    $VRazred=$VStrRazred;
                }
                switch ($R["ocenakoncna"]){
                case "5":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+5;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "4":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+4;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "3":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+3;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "2":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+2;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "1":
                case "Ni opravil":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+1;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "ZU":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+5;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "U":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+4;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "MU":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+2;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                    break;
                case "Opravil":
                    $Ocena[$Indx][intval($R["idpredmet"])][1]=$Ocena[$Indx][intval($R["idpredmet"])][1]+5;
                    $Ocena[$Indx][intval($R["idpredmet"])][2]=$Ocena[$Indx][intval($R["idpredmet"])][2]+1;
                }
            }
            $StRazredov=$Indx;

            for ($Indx=1;$Indx <= $StRazredov;$Indx++){
                if ($Razred[$Indx][1] > 3){
                    echo "<h2>".$Razred[$Indx][0]."</h2>";
                    echo "<table border=1 cellspacing=0>";
                    echo "<tr bgcolor=cyan><td>".$Razred[$Indx][0]."</td><td>Predmet</td><td>Povprečje</td><td>Učencev</td>";
                    $i1=0;
                    for ($Indx0=0;$Indx0 <= $StPredmetov;$Indx0++){
                        if (isset($Predmet[$Indx0][0])){
                            if ($Ocena[$Indx][$Predmet[$Indx0][0]][2] > 0){
                                echo "<tr bgcolor=lightyellow><td></td>";
                                echo "<td bgcolor=khaki>".$Predmet[$Indx0][1]."</td>";
                                echo "<td align=right>".number_format($Ocena[$Indx][$Predmet[$Indx0][0]][1]/$Ocena[$Indx][$Predmet[$Indx0][0]][2],2)."</td>";
                                echo "<td align=center>".$Ocena[$Indx][$Predmet[$Indx0][0]][2]."</td>";
                                echo "</tr>";
                                $aMonthValues[$i1]=number_format($Ocena[$Indx][$Predmet[$Indx0][0]][1]/$Ocena[$Indx][$Predmet[$Indx0][0]][2],2);
                                $aMonthNames[$i1]=$Predmet[$Indx0][1];
                                $i1=$i1+1;
                            }
                        }
                    }
                    echo "</table><br />";
                    if ($i1 > 0){
                        displayverticalgraph ("Povprečje zaključnih ocen - ".$VLeto."/".($VLeto+1)." ","Ocena","Predmeti",$aMonthValues,$aMonthNames);
                    }
                    
                }
            }
        }
        break;
    case "600": //zlati odličnjaki
        //'inicializacija VUcenec
        for ($i=0;$i <= 1000;$i++){
            $VUcenec[$i][0][0]=0;
            $VUcenec[$i][0][1]="";
            $VUcenec[$i][0][2]="";
            $VUcenec[$i][0][2]=0;
            
            for ($j=1;$j <= 9;$j++){
                $VUcenec[$i][$j][1]=0;
                $VUcenec[$i][$j][2]=0;
                $VUcenec[$i][$j][3]=0;
            }
        }

        $SQL = "SELECT tabucenci.iducenec,tabucenci.priimek,tabucenci.ime,tabucenci.emso,tabucenci.konsolanja, tabrazred.uspeh, tabrazdat.razred,tabrazdat.oznaka,tabrazdat.leto,tabsola.solakratko FROM ((tabucenci ";
        $SQL = $SQL . "INNER JOIN tabrazred ON tabucenci.idUcenec=tabrazred.idUcenec) ";
        $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id) ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL = $SQL . "WHERE tabrazred.uspeh > 4.5 AND tabrazdat.razred > 0 ";
        $SQL = $SQL . " ORDER BY priimek,ime,tabrazdat.leto DESC";
        $result = mysqli_query($link,$SQL);

        $VComp=0;
        for ($i=1;$i <= 9;$i++){
            $StOdlicnihAktualno[$i]=0;
        }

        echo "<h1>Učenci z odličnim uspehom (povprečja nad 4.5)</h1>";
        echo "<table border = '1' cellspacing='0'>";
        if ($VecSol > 0){
            echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='300'>Razred</th><th width='20'>Uspeh</th></tr>";
        }else{
            echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='20'>Razred</th><th width='20'>Uspeh</th></tr>";
        }
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            if ($R["iducenec"] != $VComp){
                $VKonSolanja=$R["konsolanja"];
                if (strlen($R["konsolanja"]) > 0){
                    $Datum=new DateTime(isDate($R["konsolanja"]));
                }
                if (isDate($VKonSolanja)){
                    if ($Datum->format('Y') == $VLeto+1){
                        //'če je leto konca šolanja aktualno šolsko leto (starejših ne izpisuje)
                    
                        //'podatki za novega učenca
                        $Indx=$Indx+1;
                        $VComp = $R["iducenec"];
                        
                        //'podatki o učencu
                        $VUcenec[$Indx][0][0] = $R["iducenec"];
                        $VUcenec[$Indx][0][1] = $R["priimek"]." ".$R["ime"];
                        $VUcenec[$Indx][0][2] = $R["emso"];
                        //'podatki o letniku
                        $VUcenec[$Indx][intval($R["razred"])][1] = $R["leto"];
                        if ($VecSol > 0){
                            $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"]." - ".$R["solakratko"];
                        }else{
                            $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"];
                        }
                        $VUcenec[$Indx][intval($R["razred"])][3] = number_format($R["uspeh"],2);

                        //'izpis vrstice s podatki
                        echo "<tr>";
                        echo "<td><a href='ucenec_pregled.php?ucenec=".$VUcenec[$Indx][0][0]."'><b>".$VUcenec[$Indx][0][1]."</b></a></td>";
                        echo "<td>".$VUcenec[$Indx][intval($R["razred"])][1]."/".($VUcenec[$Indx][intval($R["razred"])][1]+1)."</td>";
                        echo "<td>".$VUcenec[$Indx][intval($R["razred"])][2]."</td>";
                        echo "<td>".$VUcenec[$Indx][intval($R["razred"])][3]."</td>";
                        echo "</tr>";
                        
                        if ($VUcenec[$Indx][intval($R["razred"])][1]==$VLeto){
                            $StOdlicnihAktualno[intval($R["razred"])]=$StOdlicnihAktualno[intval($R["razred"])]+1;
                        }
                    }
                }else{
                    //'podatki za novega učenca
                    $Indx=$Indx+1;
                    $VComp = $R["iducenec"];
                    
                    //'podatki o učencu
                    $VUcenec[$Indx][0][0] = $R["iducenec"];
                    $VUcenec[$Indx][0][1] = $R["priimek"]." ".$R["ime"];
                    $VUcenec[$Indx][0][2] = $R["emso"];
                    //'podatki o letniku
                    $VUcenec[$Indx][intval($R["razred"])][1] = $R["leto"];
                    if ($VecSol > 0){
                        $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"]." - ".$R["solakratko"];
                    }else{
                        $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"];
                    }
                    $VUcenec[$Indx][intval($R["razred"])][3] = number_format($R["uspeh"],2);

                    //'izpis vrstice s podatki
                    echo "<tr>";
                    echo "<td><a href='ucenec_pregled.php?ucenec=".$VUcenec[$Indx][0][0]."'><b>".$VUcenec[$Indx][0][1]."</b></a></td>";
                    echo "<td>".$VUcenec[$Indx][intval($R["razred"])][1]."/".($VUcenec[$Indx][intval($R["razred"])][1]+1)."</td>";
                    echo "<td>".$VUcenec[$Indx][intval($R["razred"])][2]."</td>";
                    echo "<td>".$VUcenec[$Indx][intval($R["razred"])][3]."</td>";
                    echo "</tr>";
                    
                    if ($VUcenec[$Indx][intval($R["razred"])][1]==$VLeto){
                        $StOdlicnihAktualno[intval($R["razred"])]=$StOdlicnihAktualno[intval($R["razred"])]+1;
                    }
                }
            }else{
                //'podatki o letniku
                $VUcenec[$Indx][intval($R["razred"])][1] = $R["leto"];
                if ($VecSol > 0){
                    $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"]." - ".$R["solakratko"];
                }else{
                    $VUcenec[$Indx][intval($R["razred"])][2] = intval($R["razred"]).". ".$R["oznaka"];
                }
                $VUcenec[$Indx][intval($R["razred"])][3] = number_format($R["uspeh"],2);

                //'izpis vrstice s podatki
                echo "<tr>";
                echo "<td>&nbsp;</td>";
                echo "<td>".$VUcenec[$Indx][intval($R["razred"])][1]."/".($VUcenec[$Indx][intval($R["razred"])][1]+1)."</td>";
                echo "<td>".$VUcenec[$Indx][intval($R["razred"])][2]."</td>";
                echo "<td>".$VUcenec[$Indx][intval($R["razred"])][3]."</td>";
                echo "</tr>";
                
                if ($VUcenec[$Indx][intval($R["razred"])][1]==$VLeto){
                    $StOdlicnihAktualno[intval($R["razred"])]=$StOdlicnihAktualno[intval($R["razred"])]+1;
                }
            }
        }
        $VStUcencev=$Indx;
        echo "</table><br />";

        $VZapLetaMax=0;
        for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
            $NiUstrezen=true;
            $VZaporednaLeta=0;
            $i=9;
            while ($NiUstrezen){
                if ($VUcenec[$Indx][$i][1] != 0){
                    $VZaporednaLeta=$VZaporednaLeta+1;
                }else{
                    $NiUstrezen=false;
                }
                $i=$i-1;
                if ($i < 1){
                    $NiUstrezen=false;
                }
            } 
            $VUcenec[$Indx][0][3]=$VZaporednaLeta;
            if ($VZaporednaLeta > $VZapLetaMax){
                $VZapLetaMax=$VZaporednaLeta;
            }
        }
        $ZadnjeLeto=true;
        //če za aktualno leto še ni vnesenih ocen
        if ($VZapLetaMax == 0){
            $ZadnjeLeto=false;
            for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                $NiUstrezen=true;
                $VZaporednaLeta=0;
                $i=8;
                while ($NiUstrezen){
                    if ($VUcenec[$Indx][$i][1] != 0){
                        $VZaporednaLeta=$VZaporednaLeta+1;
                    }else{
                        $NiUstrezen=false;
                    }
                    $i=$i-1;
                    if ($i < 1){
                        $NiUstrezen=false;
                    }
                } 
                $VUcenec[$Indx][0][3]=$VZaporednaLeta;
                if ($VZaporednaLeta > $VZapLetaMax){
                    $VZapLetaMax=$VZaporednaLeta;
                }
            }
        }
        
        if ($ZadnjeLeto){
            echo "<h1>Aktualno število odličnih (povprečje nad 4.5)</h1>";
            echo "<table border='0' cellspacing='0'>";
            echo "<tr><th width='20'>Razred</th><th width='20'>Število</th></tr>";
            $j=0;
            for ($i=1;$i <= 9;$i++){
                echo "<tr><td>".$i."</td><td>".$StOdlicnihAktualno[$i]."</td></tr>";
                $j=$j+$StOdlicnihAktualno[$i];
            }
            echo "<tr><td>Skupaj</td><td>".$j."</td></tr>";
            echo "</table><br />";

            //'spisek odličnih za aktualno šolsko leto
            echo "<h1>Aktualni spisek odličnih 3.-9. razredi (povprečje nad 4.5)</h1>";
            echo "<table border='0' cellspacing='0'>";
            if ($VecSol > 0){
                echo "<tr><th width='20'>Št</th><th width='250'>Ime</th><th width='300'>Razred</th><th width='20'>Povprečje</th></tr>";
            }else{
                echo "<tr><th width='20'>Št</th><th width='250'>Ime</th><th width='20'>Razred</th><th width='20'>Povprečje</th></tr>";
            }
            $j=0;
            for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                for ($i=3;$i <= 9;$i++){
                    if ($VUcenec[$Indx][$i][1]==$VLeto){
                        $j=$j+1;
                        echo "<tr>";
                        echo "<td>".$j."</td>";
                        echo "<td>".$VUcenec[$Indx][0][1]."</td>";
                        echo "<td>".$VUcenec[$Indx][$i][2]."</td>";
                        echo "<td>".number_format($VUcenec[$Indx][$i][3],2)."</td>";
                        echo "</tr>";
                    }
                }
            }
            echo "</table><br />";

            //'spisek odličnih za aktualno šolsko leto s samimi peticami
            echo "<h1>Aktualni spisek odličnih s samimi peticami 3.-9. razredi (povprečje 5)</h1>";
            echo "<table border='0' cellspacing='0'>";
            if ($VecSol > 0){
                echo "<tr><th width='20'>Št</th><th width='250'>Ime</th><th width='300'>Razred</th><th width='20'>Povprečje</th></tr>";
            }else{
                echo "<tr><th width='20'>Št</th><th width='250'>Ime</th><th width='20'>Razred</th><th width='20'>Povprečje</th></tr>";
            }
            $j=0;
            for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                for ($i=3;$i <= 9;$i++){
                    if (($VUcenec[$Indx][$i][1]==$VLeto) && ($VUcenec[$Indx][$i][3] > 4.99)){
                        $j=$j+1;
                        echo "<tr>";
                        echo "<td>".$j."</td>";
                        echo "<td>".$VUcenec[$Indx][0][1]."</td>";
                        echo "<td>".$VUcenec[$Indx][$i][2]."</td>";
                        echo "<td>".number_format($VUcenec[$Indx][$i][3],2)."</td>";
                        echo "</tr>";
                    }
                }
            }
            echo "</table><br />";
        }
        if ($ZadnjeLeto){
            echo "<h1>Zlati odličnjaki (povprečje vsa leta šolanja nad 4.5)</h1>";
            echo "<h3>Opozorilo:</h3><p>Navedeni so le učenci z vsemi podatki. Preverite učence, ki so prehajali med šolami!</p>";
            echo "Upošteva se uspeh v zadnjih ".$VZapLetaMax." letih.<br />";
            echo "<table border='0' cellspacing='0'>";
            if ($VecSol > 0){
                echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='300'>Razred</th><th width='20'>Uspeh</th></tr>";
            }else{
                echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='20'>Razred</th><th width='20'>Uspeh</th></tr>";
            }
            for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                if ($VUcenec[$Indx][0][3]==$VZapLetaMax){
                    //'izpis vrstice s podatki
                    echo "<tr>";
                    echo "<td><b>".$VUcenec[$Indx][0][1]."</b></td>";
                    echo "<td>".$VUcenec[$Indx][9][1]."/".($VUcenec[$Indx][9][1]+1)."</td>";
                    echo "<td>".$VUcenec[$Indx][9][2]."</td>";
                    echo "<td>".$VUcenec[$Indx][9][3]."</td>";
                    echo "</tr>";
                }
            }
            echo "</table><br />";
        }else{
            echo "<h1>Zlati odličnjaki (povprečje vsa leta šolanja nad 4.5) - brez uspeha v 9. razredu</h1>";
            echo "<h3>Opozorilo:</h3><p>Navedeni so le učenci z vsemi podatki. Preverite učence, ki so prehajali med šolami!</p>";
            echo "Upošteva se uspeh v zadnjih ".$VZapLetaMax." letih.<br />";
            echo "<table border='0' cellspacing='0'>";
            if ($VecSol > 0){
                echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='300'>Razred</th><th width='20'>Uspeh</th></tr>";
            }else{
                echo "<tr><th width='250'>Učenec</th><th width='30'>ŠL</th><th width='20'>Razred</th><th width='20'>Uspeh</th></tr>";
            }
            for ($Indx=1;$Indx <= $VStUcencev;$Indx++){
                if ($VUcenec[$Indx][0][3]==$VZapLetaMax){
                    //'izpis vrstice s podatki
                    echo "<tr>";
                    echo "<td><b>".$VUcenec[$Indx][0][1]."</b></td>";
                    echo "<td>".$VUcenec[$Indx][9][1]."/".($VUcenec[$Indx][9][1]+1)."</td>";
                    echo "<td>".$VUcenec[$Indx][9][2]."</td>";
                    echo "<td>".$VUcenec[$Indx][9][3]."</td>";
                    echo "</tr>";
                }
            }
            echo "</table><br />";
        }
        break;
    case "700": //poročilo o uspehu - 1. polletje
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            $SQL = "SELECT id,razred,oznaka,osemdevet FROM tabrazdat ";
            $SQL .= "WHERE leto=".$VLeto." AND razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,oznaka";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Razredi[$Indx][0] = $R["razred"];
                $Razredi[$Indx][1] = $R["oznaka"];
                $Razredi[$Indx][2] = $R["osemdevet"];
                $Razredi[$Indx][3] = $R["id"];
                $Indx=$Indx+1;
            }
            $StRazredov=$Indx;

            $_SESSION["solskoleto"] = $VLeto;

            $UcneUreVse[0]=0;
            $UcneUreVse[1]=0;
            $UcneUreVse[2]=0;
            $UcneUreVse[3]=0;

            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  Prioriteta IN (0,2) "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            $StPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$StPredmetov][0]=$R["predmet"];
                $Predmeti[$StPredmetov][1]=$R["oznaka"];
                $StPredmetov=$StPredmetov+1;
            }

            for ($Indx=0;$Indx <= 50;$Indx++){
                $RazredDat[$Indx][0]="";
                $RazredDat[$Indx][1]="";
                for ($Indx0=2;$Indx0 <= 200;$Indx0++){
                    $RazredDat[$Indx][$Indx0]=0;
                    $RazredDatNeoc[$Indx][$Indx0]=0;
                }
            }

            echo "<h2>Poročilo o uspehu v 1. polletju</h2>";
            echo "Redni predmeti ".$VLeto."/".($VLeto+1)."<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan>";
            echo "<th>Razred</th><th>Razrednik</th><th>Realizacija</th><th>Učencev</th><th>Neg./Neoc.</th><th>Uspeh</th>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<th>".$Predmeti[$Indx][1]."</th>";
            }
            echo "<th>Neg.</th><th>Neoc.</th>";
            echo "</tr>";

            for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                $VRazred1=$Razredi[$IndxRazred][0];
                $VParalelka=$Razredi[$IndxRazred][1];
                $VRazred=$Razredi[$IndxRazred][3];
                
                $SQL = "SELECT tabucenci.datroj,tabucenci.iducenec,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucitelji.iducitelj,tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, tabrazred.idvzgojitelj,tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM ";
                $SQL .= "((tabvzgojitelji INNER JOIN ";
                $SQL .= "(tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                $SQL .= "INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL .= "WHERE idRazred=" . $VRazred." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $RazredDat[$IndxRazred][0]=$VRazred1.". ".$VParalelka;

                if ($R = mysqli_fetch_array($result)){
                    $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
                    $IdUcitelj=$R["iducitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj=$R["idvzgojitelj"];

                }
                $RazredDat[$IndxRazred][1]=$Ucitelj;

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci[$Indx][0]=$R["iducenec"];
                    $Ucenci[$Indx][1]=$R["upriimek"].", ".$R["uime"];
                    $Ucenci[$Indx][2]=$VRazred1.$VParalelka;
                    $Ucenci[$Indx][3]=$R["datroj"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                //Realizacija ur
                $SQL = "SELECT tabrealizacija.*,tabpredmeti.* FROM ";
                $SQL = $SQL . "(tabrealizacija INNER JOIN tabpredmeti ON tabrealizacija.Predmet=tabpredmeti.Id) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrealizacija.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrealizacija.Razred=".$VRazred1." AND paralelka='".$VParalelka."' AND prioriteta IN (0,2) AND tabrealizacija.leto=".$VLeto." "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL = $SQL . " ORDER BY VrstniRed";
                $result = mysqli_query($link,$SQL);

                $UcneUre[0]=0;
                $UcneUre[1]=0;
                $UcneUre[2]=0;
                $UcneUre[3]=0;

                for ($Indx=0;$Indx <= 200;$Indx++){
                    $UcneUrePredmeti[$Indx][0]=0;
                    $UcneUrePredmeti[$Indx][1]=0;
                    $UcneUrePredmeti[$Indx][2]=0;
                    $UcneUrePredmeti[$Indx][3]=0;
                    $UcneUrePredmeti[$Indx][4]=0;
                    $UcneUrePredmeti[$Indx][5]=0;
                }

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
                    $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
                    $UcneUre[2]=$UcneUre[2]+$R["Plan"];
                    $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
                    $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
                    $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
                    $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
                    $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
                    $UcneUrePredmeti[$Indx][4]=$R["Plan"];
                    $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
                    $Indx=$Indx+1;
                }
                $StPredmetovUcneUre=$Indx;

                $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
                $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
                $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
                $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

                if ($UcneUre[0] > 0){
                    $RazredDat[$IndxRazred][2]=$UcneUre[1]/$UcneUre[0];
                }

                //skupna statistika razreda po spolu - zacetek
                $SQL = "SELECT tabucenci.spol FROM ";
                $SQL .= "(tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL .= "WHERE tabrazred.idrazred=".$VRazred." AND tabrazred.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabrazred.Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);
                
                $StUcencevM=0;
                $StUcencevW=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["spol"]=="M"){
                        $StUcencevM=$StUcencevM+1;
                    }else{
                        $StUcencevW=$StUcencevW+1;
                    }
                }
                
                $SQL = "SELECT tabucenci.iducenec,tabucenci.spol,tabocene.ocenakoncna,tabocene.ocenapolletna,tabocene.neocenjen,tabocene.idpredmet FROM ";
                $SQL .= "((tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) ";
                $SQL .= "INNER JOIN tabocene ON tabucenci.IdUcenec=tabocene.IdUcenec) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                $SQL .= "WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL .= " ORDER BY tabrazred.Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);

                $StUcencevWNeg=0;
                $StUcencevMNeg=0;
                $StUcencevWNegPol=0;
                $StUcencevMNegPol=0;
                $StUcencevWNeoc=0;
                $StUcencevMNeoc=0;
                if ($R = mysqli_fetch_array($result)){
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenakoncna"] == "1") or ($R["ocenakoncna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeg=$StUcencevMNeg+1;
                                }else{
                                    $StUcencevWNeg=$StUcencevWNeg+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenapolletna"] == "1") or ($R["ocenapolletna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNegPol=$StUcencevMNegPol+1;
                                }else{
                                    $StUcencevWNegPol=$StUcencevWNegPol+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["neocenjen"] == 1){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeoc=$StUcencevMNeoc+1;
                                }else{
                                    $StUcencevWNeoc=$StUcencevWNeoc+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }
                }
                //skupna statistika razreda po spolu - konec

                //negativne ocene učencev pri predmetih-zacetek
                $IndxUcN=0;
                $IndxUcNP=0;
                $IndxNeoc=0;
                
                for ($Indx=0;$Indx <= 200;$Indx++){
                    $PredmetNegativno[$Indx]=0;
                    $PredmetNegativnoPol[$Indx]=0;
                    $PredmetNeocenjen[$Indx]=0;
                }
                for ($Indx=0;$Indx <= 30;$Indx++){
                    $UcenciNegativni[$Indx][0]=0;
                    $UcenciNegativni[$Indx][1]=0;
                    $UcenciNegativni[$Indx][2]=0;
                    $UcenciNegativniPol[$Indx][0]=0;
                    $UcenciNegativniPol[$Indx][1]=0;
                    $UcenciNegativniPol[$Indx][2]=0;
                    $UcenciNezadostni[$Indx]=0;
                    $UcenciNezadostniPol[$Indx]=0;
                }

                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    $UcenciNezadostni[$IndxUc]=0;
                    $UcenciNezadostniPol[$IndxUc]=0;
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][4]="";
                        $Ocene[$Indx1][5]="";
                    }

                    $SQL = "SELECT  idpredmet,ocenakoncna,ocenapolletna,neocenjen FROM tabocene WHERE IdUcenec=".$Ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["idpredmet"]==$Predmeti[$Indx1][0]){
                                $Ocene[$Indx1][4]=$R["ocenakoncna"];
                                $Ocene[$Indx1][5]=$R["ocenapolletna"];
                                $Neocenjen[$Indx1]=$R["neocenjen"];
                                if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
                                    $PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
                                    $UcenciNegativni[$IndxUcN][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativni[$IndxUcN][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
                                    $IndxUcN=$IndxUcN+1;
                                    $UcenciNezadostni[$IndxUc]=1;
                                }
                                if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
                                    $PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
                                    $UcenciNegativniPol[$IndxUcNP][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativniPol[$IndxUcNP][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
                                    $IndxUcNP=$IndxUcNP+1;
                                    $UcenciNezadostniPol[$IndxUc]=1;
                                }
                                if ($Neocenjen[$Indx1]==1){
                                    $PredmetNeocenjen[$Indx1]=$PredmetNeocenjen[$Indx1]+1;
                                    $UcenciNeocenjeni[$IndxNeoc][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNeocenjeni[$IndxNeoc][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                                    $IndxNeoc=$IndxNeoc+1;
                                }
                                
                            }
                        }
                        $Indx=$Indx+1;
                    }
                }

                $Nezadostnih=0;
                $NezadostnihPol=0;
                for ($Indx=0;$Indx < $StUcencev;$Indx++){
                    $Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
                    $NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
                }
                
                if ($StUcencev > 0){
                    $RazredDat[$IndxRazred][3]=$StUcencev;
                    $RazredDat[$IndxRazred][4]=$StUcencevMNegPol+$StUcencevWNegPol;
                    if ($StUcencev > 0){
                        $RazredDat[$IndxRazred][5]=($StUcencevM+$StUcencevW-$StUcencevMNegPol-$StUcencevWNegPol)/$StUcencev;
                    }else{
                        $RazredDat[$IndxRazred][5]=0;
                    }
                    $RazredDatNeoc[$IndxRazred][4]=$StUcencevMNeoc+$StUcencevWNeoc;
                    
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        $RazredDat[$IndxRazred][6+$Indx]=$PredmetNegativnoPol[$Indx];
                        $RazredDatNeoc[$IndxRazred][6+$Indx]=$PredmetNeocenjen[$Indx];
                    }
                    $RazredDat[$IndxRazred][6+$StPredmetov]=0;
                    $RazredDatNeoc[$IndxRazred][6+$StPredmetov]=0;
                    //negativne ocene učencev pri predmetih-konec

                    echo "<tr bgcolor=lightyellow>";
                    echo "<td>".$RazredDat[$IndxRazred][0]."</td>"; // 'razred
                    echo "<td>".$RazredDat[$IndxRazred][1]."</td>"; // 'razrednik
                    echo "<td align=right>".number_format($RazredDat[$IndxRazred][2]*100,0)."%</td>"; // 'realizacija
                    echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>"; //'učencev
                    echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>"; // 'Negativni/neocenjeni
                    echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>"; // 'uspeh
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>"; // 'negativni/neocenjeni pri prdmetu
                        $RazredDat[$IndxRazred][$StPredmetov+6]=$RazredDat[$IndxRazred][$StPredmetov+6]+$RazredDat[$IndxRazred][$Indx+6];
                        $RazredDatNeoc[$IndxRazred][$StPredmetov+6]=$RazredDatNeoc[$IndxRazred][$StPredmetov+6]+$RazredDatNeoc[$IndxRazred][$Indx+6];
                    }
                    echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>"; // 'negativne skupaj
                    echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>"; // 'neocenjeni skupaj
                    echo "</tr>";
                }
            }

            //'izpiše še vsote po stolpcih
            $IndxRazred=$StRazredov;
            for ($Indx0=3;$Indx0 <= $StPredmetov+6;$Indx0++){
                $RazredDat[$StRazredov][$Indx0]=0;
                $RazredDatNeoc[$StRazredov][$Indx0]=0;
                for ($Indx=0;$Indx < $StRazredov;$Indx++){
                    $RazredDat[$StRazredov][$Indx0]=$RazredDat[$StRazredov][$Indx0]+$RazredDat[$Indx][$Indx0];
                    $RazredDatNeoc[$StRazredov][$Indx0]=$RazredDatNeoc[$StRazredov][$Indx0]+$RazredDatNeoc[$Indx][$Indx0];
                }
            }
            echo "<tr bgcolor=lightgreen>";
            echo "<td></td>";
            echo "<td>Skupaj</td>";
            If ($UcneUreVse[0] > 0){
                echo "<td align=right>".number_format(($UcneUreVse[1]/$UcneUreVse[0])*100,2)."%</td>";
            }else{
                echo "<td></td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>";
            echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>";
            echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){


                echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>";
            echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>";
            echo "</tr>";

            echo "</table><br />";

            //'izbirni predmeti
            $UcneUreVse[0]=0;
            $UcneUreVse[1]=0;
            $UcneUreVse[2]=0;
            $UcneUreVse[3]=0;

            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  (Prioriteta=1) "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            $StPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$StPredmetov][0]=$R["predmet"];
                $Predmeti[$StPredmetov][1]=$R["oznaka"];
                $StPredmetov=$StPredmetov+1;
            }

            for ($Indx=0;$Indx <= 50;$Indx++){
                $RazredDat[$Indx][0]="";
                $RazredDat[$Indx][1]="";
                for ($Indx0=2;$Indx <= 200;$Indx++){
                    $RazredDat[$Indx][$Indx0]=0;
                    $RazredDatNeoc[$Indx][$Indx0]=0;
                }
            }

            echo "Izbirni predmeti ".$VLeto."/".($VLeto+1)."<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan>";
            echo "<th>Razred</th><th>Razrednik</th><th>Realizacija</th><th>Učencev</th><th>Neg./Neoc.</th><th>Uspeh</th>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<th>".$Predmeti[$Indx][1]."</th>";
            }
            echo "<th>Neg.</th><th>Neoc.</th>";
            echo "</tr>";

            for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                $VRazred1=$Razredi[$IndxRazred][0];
                $VParalelka=$Razredi[$IndxRazred][1];
                $VRazred=$Razredi[$IndxRazred][3];
                
                $SQL = "SELECT tabucenci.datroj,tabucenci.iducenec,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucitelji.iducitelj,tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, tabrazred.idvzgojitelj,tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM (tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec WHERE idRazred=" . $VRazred." AND tabrazred.leto=".$VLeto." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $RazredDat[$IndxRazred][0]=$VRazred1.". ".$VParalelka;

                if ($R = mysqli_fetch_array($result)){
                    $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
                    $IdUcitelj=$R["iducitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj=$R["idvzgojitelj"];

                }
                $RazredDat[$IndxRazred][1]=$Ucitelj;

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci[$Indx][0]=$R["iducenec"];
                    $Ucenci[$Indx][1]=$R["upriimek"].", ".$R["uime"];
                    $Ucenci[$Indx][2]=$VRazred1.$VParalelka;
                    $Ucenci[$Indx][3]=$R["datroj"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                //Realizacija ur
                $SQL = "SELECT tabrealizacija.*,tabpredmeti.* FROM ";
                $SQL = $SQL . "(tabrealizacija INNER JOIN tabpredmeti ON tabrealizacija.Predmet=tabpredmeti.Id) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrealizacija.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrealizacija.Razred=".$VRazred1." AND paralelka='".$VParalelka."' AND prioriteta IN (0,2) AND tabrealizacija.leto=".$VLeto." "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL = $SQL . " ORDER BY VrstniRed";
                $result = mysqli_query($link,$SQL);

                $UcneUre[0]=0;
                $UcneUre[1]=0;
                $UcneUre[2]=0;
                $UcneUre[3]=0;

                for ($Indx=0;$Indx <= 200;$Indx++){
                    $UcneUrePredmeti[$Indx][0]=0;
                    $UcneUrePredmeti[$Indx][1]=0;
                    $UcneUrePredmeti[$Indx][2]=0;
                    $UcneUrePredmeti[$Indx][3]=0;
                    $UcneUrePredmeti[$Indx][4]=0;
                    $UcneUrePredmeti[$Indx][5]=0;
                }

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
                    $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
                    $UcneUre[2]=$UcneUre[2]+$R["Plan"];
                    $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
                    $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
                    $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
                    $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
                    $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
                    $UcneUrePredmeti[$Indx][4]=$R["Plan"];
                    $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
                    $Indx=$Indx+1;
                }
                $StPredmetovUcneUre=$Indx;

                $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
                $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
                $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
                $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

                if ($UcneUre[0] > 0){
                    $RazredDat[$IndxRazred][2]=$UcneUre[1]/$UcneUre[0];
                }

                //skupna statistika razreda po spolu - zacetek
                $SQL = "SELECT tabucenci.spol FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);
                
                $StUcencevM=0;
                $StUcencevW=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["spol"]=="M"){
                        $StUcencevM=$StUcencevM+1;
                    }else{
                        $StUcencevW=$StUcencevW+1;
                    }
                }
                
                $SQL = "SELECT tabucenci.iducenec,tabucenci.spol,tabocene.ocenakoncna,tabocene.ocenapolletna,tabocene.neocenjen,tabocene.idpredmet FROM (tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) INNER JOIN tabocene ON tabucenci.IdUcenec=tabocene.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);

                $StUcencevWNeg=0;
                $StUcencevMNeg=0;
                $StUcencevWNegPol=0;
                $StUcencevMNegPol=0;
                $StUcencevWNeoc=0;
                $StUcencevMNeoc=0;
                if ($R = mysqli_fetch_array($result)){
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenakoncna"] == "1") or ($R["ocenakoncna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeg=$StUcencevMNeg+1;
                                }else{
                                    $StUcencevWNeg=$StUcencevWNeg+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenapolletna"] == "1") or ($R["ocenapolletna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNegPol=$StUcencevMNegPol+1;
                                }else{
                                    $StUcencevWNegPol=$StUcencevWNegPol+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["neocenjen"] == 1){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeoc=$StUcencevMNeoc+1;
                                }else{
                                    $StUcencevWNeoc=$StUcencevWNeoc+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }
                }
                //skupna statistika razreda po spolu - konec

                //negativne ocene učencev pri predmetih-zacetek
                $IndxUcN=0;
                $IndxUcNP=0;
                $IndxNeoc=0;
                
                for ($Indx=0;$Indx <= 200;$Indx++){
                    $PredmetNegativno[$Indx]=0;
                    $PredmetNegativnoPol[$Indx]=0;
                    $PredmetNeocenjen[$Indx]=0;
                }
                for ($Indx=0;$Indx <= 30;$Indx++){
                    $UcenciNegativni[$Indx][0]=0;
                    $UcenciNegativni[$Indx][1]=0;
                    $UcenciNegativni[$Indx][2]=0;
                    $UcenciNegativniPol[$Indx][0]=0;
                    $UcenciNegativniPol[$Indx][1]=0;
                    $UcenciNegativniPol[$Indx][2]=0;
                    $UcenciNezadostni[$Indx]=0;
                    $UcenciNezadostniPol[$Indx]=0;
                }

                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    $UcenciNezadostni[$IndxUc]=0;
                    $UcenciNezadostniPol[$IndxUc]=0;
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][4]="";
                        $Ocene[$Indx1][5]="";
                    }

                    $SQL = "SELECT  idpredmet,ocenakoncna,ocenapolletna,neocenjen FROM tabocene WHERE IdUcenec=".$Ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["idpredmet"]==$Predmeti[$Indx1][0]){
                                $Ocene[$Indx1][4]=$R["ocenakoncna"];
                                $Ocene[$Indx1][5]=$R["ocenapolletna"];
                                $Neocenjen[$Indx1]=$R["neocenjen"];
                                if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
                                    $PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
                                    $UcenciNegativni[$IndxUcN][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativni[$IndxUcN][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
                                    $IndxUcN=$IndxUcN+1;
                                    $UcenciNezadostni[$IndxUc]=1;
                                }
                                if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
                                    $PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
                                    $UcenciNegativniPol[$IndxUcNP][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativniPol[$IndxUcNP][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
                                    $IndxUcNP=$IndxUcNP+1;
                                    $UcenciNezadostniPol[$IndxUc]=1;
                                }
                                if ($Neocenjen[$Indx1]==1){
                                    $PredmetNeocenjen[$Indx1]=$PredmetNeocenjen[$Indx1]+1;
                                    $UcenciNeocenjeni[$IndxNeoc][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNeocenjeni[$IndxNeoc][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                                    $IndxNeoc=$IndxNeoc+1;
                                }
                                
                            }
                        }
                        $Indx=$Indx+1;
                    }
                }

                $Nezadostnih=0;
                $NezadostnihPol=0;
                for ($Indx=0;$Indx < $StUcencev;$Indx++){
                    $Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
                    $NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
                }
                
                if ($StUcencev > 0){
                    $RazredDat[$IndxRazred][3]=$StUcencev;
                    $RazredDat[$IndxRazred][4]=$StUcencevMNegPol+$StUcencevWNegPol;
                    if ($StUcencev > 0){
                        $RazredDat[$IndxRazred][5]=($StUcencevM+$StUcencevW-$StUcencevMNegPol-$StUcencevWNegPol)/$StUcencev;
                    }else{
                        $RazredDat[$IndxRazred][5]=0;
                    }
                    $RazredDatNeoc[$IndxRazred][4]=$StUcencevMNeoc+$StUcencevWNeoc;
                    
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        $RazredDat[$IndxRazred][6+$Indx]=$PredmetNegativnoPol[$Indx];
                        $RazredDatNeoc[$IndxRazred][6+$Indx]=$PredmetNeocenjen[$Indx];
                    }
                    //negativne ocene učencev pri predmetih-konec

                    echo "<tr bgcolor=lightyellow>";
                    echo "<td>".$RazredDat[$IndxRazred][0]."</td>"; // 'razred
                    echo "<td>".$RazredDat[$IndxRazred][1]."</td>"; // 'razrednik
                    echo "<td align=right>".number_format($RazredDat[$IndxRazred][2]*100,0)."%</td>"; // 'realizacija
                    echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>"; //'učencev
                    echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>"; // 'Negativni/neocenjeni
                    echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>"; // 'uspeh
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>"; // 'negativni/neocenjeni pri prdmetu
                        $RazredDat[$IndxRazred][$StPredmetov+6]=$RazredDat[$IndxRazred][$StPredmetov+6]+$RazredDat[$IndxRazred][$Indx+6];
                        $RazredDatNeoc[$IndxRazred][$StPredmetov+6]=$RazredDatNeoc[$IndxRazred][$StPredmetov+6]+$RazredDatNeoc[$IndxRazred][$Indx+6];
                    }
                    echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>"; // 'negativne skupaj
                    echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>"; // 'neocenjeni skupaj
                    echo "</tr>";
                }
            }

            //'izpiše še vsote po stolpcih
            $IndxRazred=$StRazredov;
            for ($Indx0=3;$Indx0 <= $StPredmetov+6;$Indx0++){
                $RazredDat[$StRazredov][$Indx0]=0;
                $RazredDatNeoc[$StRazredov][$Indx0]=0;
                for ($Indx=0;$Indx < $StRazredov;$Indx++){
                    $RazredDat[$StRazredov][$Indx0]=$RazredDat[$StRazredov][$Indx0]+$RazredDat[$Indx][$Indx0];
                    $RazredDatNeoc[$StRazredov][$Indx0]=$RazredDatNeoc[$StRazredov][$Indx0]+$RazredDatNeoc[$Indx][$Indx0];
                }
            }
            echo "<tr bgcolor=lightgreen>";
            echo "<td></td>";
            echo "<td>Skupaj</td>";
            If ($UcneUreVse[0] > 0){
                echo "<td align=right>".number_format(($UcneUreVse[1]/$UcneUreVse[0])*100,2)."%</td>";
            }else{
                echo "<td></td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>";
            echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>";
            echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>";
            echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>";
            echo "</tr>";

            echo "</table><br />";
            echo "<br /><a href='IzpisRealizacij.php?id=1'>Realizacije po predmetih in skupaj</a><br />";
        }
        break;
    case "710": //poročilo o uspehu - celoletno
        $sola=array();
        $SQL = "SELECT id,solakratko FROM tabsola";
        $result = mysqli_query($link,$SQL);
        $i=1;
        while ($R = mysqli_fetch_array($result)){
            $sola[$i][0]=$R["id"];
            $sola[$i][1]=$R["solakratko"];
            $i += 1;
        }
        $StSol=$i-1;
            
        for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 
            echo "<h2>".$sola[$IndxSola][1]."</h2>";           
            $SQL = "SELECT id,razred,oznaka,osemdevet FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY razred,oznaka";
            $result = mysqli_query($link,$SQL);

            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $Razredi[$Indx][0] = $R["razred"];
                $Razredi[$Indx][1] = $R["oznaka"];
                $Razredi[$Indx][2] = $R["osemdevet"];
                $Razredi[$Indx][3] = $R["id"];
                $Indx=$Indx+1;
            }
            $StRazredov=$Indx;

            $_SESSION["solskoleto"] = $VLeto;

            $UcneUreVse[0]=0;
            $UcneUreVse[1]=0;
            $UcneUreVse[2]=0;
            $UcneUreVse[3]=0;

            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  Prioriteta IN (0,2) ";
            $SQL .= " ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            $StPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$StPredmetov][0]=$R["predmet"];
                $Predmeti[$StPredmetov][1]=$R["oznaka"];
                $StPredmetov=$StPredmetov+1;
            }

            for ($Indx=0;$Indx <= 50;$Indx++){
                $RazredDat[$Indx][0]="";
                $RazredDat[$Indx][1]="";
                for ($Indx0=2;$Indx0 <= 200;$Indx0++){
                    $RazredDat[$Indx][$Indx0]=0;
                    $RazredDatNeoc[$Indx][$Indx0]=0;
                }
            }

            echo "<h2>Poročilo o končnem uspehu</h2>";
            echo "Redni predmeti ".$VLeto."/".($VLeto+1)."<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan>";
            echo "<th>Razred</th><th>Razrednik</th><th>Realizacija</th><th>Učencev</th><th>Neg./Neoc.</th><th>Uspeh</th>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<th>".$Predmeti[$Indx][1]."</th>";
            }
            echo "<th>Neg.</th><th>Neoc.</th>";
            echo "</tr>";

            for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                $VRazred1=$Razredi[$IndxRazred][0];
                $VParalelka=$Razredi[$IndxRazred][1];
                $VRazred=$Razredi[$IndxRazred][3];
                
                $SQL = "SELECT tabucenci.datroj,tabucenci.iducenec,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucitelji.iducitelj,tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, tabrazred.idvzgojitelj,tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM (tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec WHERE idRazred=" . $VRazred." AND tabrazred.leto=".$VLeto." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $RazredDat[$IndxRazred][0]=$VRazred1.". ".$VParalelka;

                if ($R = mysqli_fetch_array($result)){
                    $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
                    $IdUcitelj=$R["iducitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj=$R["idvzgojitelj"];

                }
                $RazredDat[$IndxRazred][1]=$Ucitelj;

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci[$Indx][0]=$R["iducenec"];
                    $Ucenci[$Indx][1]=$R["upriimek"].", ".$R["uime"];
                    $Ucenci[$Indx][2]=$VRazred1.$VParalelka;
                    $Ucenci[$Indx][3]=$R["datroj"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                //Realizacija ur
                $SQL = "SELECT tabrealizacija.*,tabpredmeti.* FROM ";
                $SQL = $SQL . "(tabrealizacija INNER JOIN tabpredmeti ON tabrealizacija.Predmet=tabpredmeti.Id) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrealizacija.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrealizacija.Razred=".$VRazred1." AND paralelka='".$VParalelka."' AND prioriteta IN (0,2) AND tabrealizacija.leto=".$VLeto." "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL = $SQL . " ORDER BY VrstniRed";
                $result = mysqli_query($link,$SQL);

                $UcneUre[0]=0;
                $UcneUre[1]=0;
                $UcneUre[2]=0;
                $UcneUre[3]=0;

                for ($Indx=0;$Indx <= 200;$Indx++){
                    $UcneUrePredmeti[$Indx][0]=0;
                    $UcneUrePredmeti[$Indx][1]=0;
                    $UcneUrePredmeti[$Indx][2]=0;
                    $UcneUrePredmeti[$Indx][3]=0;
                    $UcneUrePredmeti[$Indx][4]=0;
                    $UcneUrePredmeti[$Indx][5]=0;
                }

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
                    $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
                    $UcneUre[2]=$UcneUre[2]+$R["Plan"];
                    $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
                    $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
                    $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
                    $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
                    $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
                    $UcneUrePredmeti[$Indx][4]=$R["Plan"];
                    $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
                    $Indx=$Indx+1;
                }
                $StPredmetovUcneUre=$Indx;

                $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
                $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
                $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
                $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

                if ($UcneUre[2] > 0){
                    $RazredDat[$IndxRazred][2]=$UcneUre[3]/$UcneUre[2];
                }

                //skupna statistika razreda po spolu - zacetek
                $SQL = "SELECT tabucenci.spol FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);
                
                $StUcencevM=0;
                $StUcencevW=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["spol"]=="M"){
                        $StUcencevM=$StUcencevM+1;
                    }else{
                        $StUcencevW=$StUcencevW+1;
                    }
                }
                
                $SQL = "SELECT tabucenci.iducenec,tabucenci.spol,tabocene.ocenakoncna,tabocene.ocenapolletna,tabocene.neocenjen,tabocene.idpredmet FROM (tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) INNER JOIN tabocene ON tabucenci.IdUcenec=tabocene.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);

                $StUcencevWNeg=0;
                $StUcencevMNeg=0;
                $StUcencevWNegPol=0;
                $StUcencevMNegPol=0;
                $StUcencevWNeoc=0;
                $StUcencevMNeoc=0;
                if ($R = mysqli_fetch_array($result)){
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenakoncna"] == "1") or ($R["ocenakoncna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeg=$StUcencevMNeg+1;
                                }else{
                                    $StUcencevWNeg=$StUcencevWNeg+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenapolletna"] == "1") or ($R["ocenapolletna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNegPol=$StUcencevMNegPol+1;
                                }else{
                                    $StUcencevWNegPol=$StUcencevWNegPol+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["neocenjen"] == 1){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeoc=$StUcencevMNeoc+1;
                                }else{
                                    $StUcencevWNeoc=$StUcencevWNeoc+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }
                }
                //skupna statistika razreda po spolu - konec

                //negativne ocene učencev pri predmetih-zacetek
                $IndxUcN=0;
                $IndxUcNP=0;
                $IndxNeoc=0;
                
                for ($Indx=0;$Indx <= 200;$Indx++){
                    $PredmetNegativno[$Indx]=0;
                    $PredmetNegativnoPol[$Indx]=0;
                    $PredmetNeocenjen[$Indx]=0;
                }
                for ($Indx=0;$Indx <= 30;$Indx++){
                    $UcenciNegativni[$Indx][0]=0;
                    $UcenciNegativni[$Indx][1]=0;
                    $UcenciNegativni[$Indx][2]=0;
                    $UcenciNegativniPol[$Indx][0]=0;
                    $UcenciNegativniPol[$Indx][1]=0;
                    $UcenciNegativniPol[$Indx][2]=0;
                    $UcenciNezadostni[$Indx]=0;
                    $UcenciNezadostniPol[$Indx]=0;
                }

                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    $UcenciNezadostni[$IndxUc]=0;
                    $UcenciNezadostniPol[$IndxUc]=0;
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][4]="";
                        $Ocene[$Indx1][5]="";
                    }

                    $SQL = "SELECT  idpredmet,ocenakoncna,ocenapolletna,neocenjen FROM tabocene WHERE IdUcenec=".$Ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["idpredmet"]==$Predmeti[$Indx1][0]){
                                $Ocene[$Indx1][4]=$R["ocenakoncna"];
                                $Ocene[$Indx1][5]=$R["ocenapolletna"];
                                $Neocenjen[$Indx1]=$R["neocenjen"];
                                if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
                                    $PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
                                    $UcenciNegativni[$IndxUcN][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativni[$IndxUcN][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
                                    $IndxUcN=$IndxUcN+1;
                                    $UcenciNezadostni[$IndxUc]=1;
                                }
                                if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
                                    $PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
                                    $UcenciNegativniPol[$IndxUcNP][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativniPol[$IndxUcNP][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
                                    $IndxUcNP=$IndxUcNP+1;
                                    $UcenciNezadostniPol[$IndxUc]=1;
                                }
                                if ($Neocenjen[$Indx1]==1){
                                    $PredmetNeocenjen[$Indx1]=$PredmetNeocenjen[$Indx1]+1;
                                    $UcenciNeocenjeni[$IndxNeoc][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNeocenjeni[$IndxNeoc][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                                    $IndxNeoc=$IndxNeoc+1;
                                }
                                
                            }
                        }
                        $Indx=$Indx+1;
                    }
                }

                $Nezadostnih=0;
                $NezadostnihPol=0;
                for ($Indx=0;$Indx < $StUcencev;$Indx++){
                    $Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
                    $NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
                }
                
                if ($StUcencev > 0){
                    $RazredDat[$IndxRazred][3]=$StUcencev;
                    $RazredDat[$IndxRazred][4]=$StUcencevMNeg+$StUcencevWNeg;
                    if ($StUcencev > 0){
                        $RazredDat[$IndxRazred][5]=($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)/$StUcencev;
                    }else{
                        $RazredDat[$IndxRazred][5]=0;
                    }
                    $RazredDatNeoc[$IndxRazred][4]=$StUcencevMNeoc+$StUcencevWNeoc;
                    
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        $RazredDat[$IndxRazred][6+$Indx]=$PredmetNegativno[$Indx];
                        $RazredDatNeoc[$IndxRazred][6+$Indx]=$PredmetNeocenjen[$Indx];
                    }
                    //negativne ocene učencev pri predmetih-konec

                    echo "<tr bgcolor=lightyellow>";
                    echo "<td>".$RazredDat[$IndxRazred][0]."</td>"; // 'razred
                    echo "<td>".$RazredDat[$IndxRazred][1]."</td>"; // 'razrednik
                    echo "<td align=right>".number_format($RazredDat[$IndxRazred][2]*100,0)."%</td>"; // 'realizacija
                    echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>"; //'učencev
                    echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>"; // 'Negativni/neocenjeni
                    echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>"; // 'uspeh
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>"; // 'negativni/neocenjeni pri prdmetu
                        $RazredDat[$IndxRazred][$StPredmetov+6]=$RazredDat[$IndxRazred][$StPredmetov+6]+$RazredDat[$IndxRazred][$Indx+6];
                        $RazredDatNeoc[$IndxRazred][$StPredmetov+6]=$RazredDatNeoc[$IndxRazred][$StPredmetov+6]+$RazredDatNeoc[$IndxRazred][$Indx+6];
                    }
                    echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>"; // 'negativne skupaj
                    echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>"; // 'neocenjeni skupaj
                    echo "</tr>";
                }
            }

            //'izpiše še vsote po stolpcih
            $IndxRazred=$StRazredov;
            for ($Indx0=3;$Indx0 <= $StPredmetov+6;$Indx0++){
                $RazredDat[$StRazredov][$Indx0]=0;
                $RazredDatNeoc[$StRazredov][$Indx0]=0;
                for ($Indx=0;$Indx < $StRazredov;$Indx++){
                    $RazredDat[$StRazredov][$Indx0]=$RazredDat[$StRazredov][$Indx0]+$RazredDat[$Indx][$Indx0];
                    $RazredDatNeoc[$StRazredov][$Indx0]=$RazredDatNeoc[$StRazredov][$Indx0]+$RazredDatNeoc[$Indx][$Indx0];
                }
            }
            echo "<tr bgcolor=lightgreen>";
            echo "<td></td>";
            echo "<td>Skupaj</td>";
            If ($UcneUreVse[2] > 0){
                echo "<td align=right>".number_format(($UcneUreVse[3]/$UcneUreVse[2])*100,2)."%</td>";
            }else{
                echo "<td></td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>";
            echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>";
            echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>";
            echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>";
            echo "</tr>";

            echo "</table><br />";

            //'izbirni predmeti
            $UcneUreVse[0]=0;
            $UcneUreVse[1]=0;
            $UcneUreVse[2]=0;
            $UcneUreVse[3]=0;

            $SQL = "SELECT DISTINCT tabpredmeti.oznaka,tabpredmeti.prioriteta,tabpredmeti.vrstnired,tabucenje.predmet,tabucenje.Leto FROM ";
            $SQL .= "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND  (Prioriteta=1) "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
            $SQL .= " ORDER BY tabpredmeti.VrstniRed";
            $result = mysqli_query($link,$SQL);

            $StPredmetov=0;
            while ($R = mysqli_fetch_array($result)){
                $Predmeti[$StPredmetov][0]=$R["predmet"];
                $Predmeti[$StPredmetov][1]=$R["oznaka"];
                $StPredmetov=$StPredmetov+1;
            }

            for ($Indx=0;$Indx <= 50;$Indx++){
                $RazredDat[$Indx][0]="";
                $RazredDat[$Indx][1]="";
                for ($Indx0=2;$Indx <= 200;$Indx++){
                    $RazredDat[$Indx][$Indx0]=0;
                    $RazredDatNeoc[$Indx][$Indx0]=0;
                }
            }

            echo "Izbirni predmeti ".$VLeto."/".($VLeto+1)."<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan>";
            echo "<th>Razred</th><th>Razrednik</th><th>Realizacija</th><th>Učencev</th><th>Neg./Neoc.</th><th>Uspeh</th>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<th>".$Predmeti[$Indx][1]."</th>";
            }
            echo "<th>Neg.</th><th>Neoc.</th>";
            echo "</tr>";

            for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
                $VRazred1=$Razredi[$IndxRazred][0];
                $VParalelka=$Razredi[$IndxRazred][1];
                $VRazred=$Razredi[$IndxRazred][3];
                
                $SQL = "SELECT tabucenci.datroj,tabucenci.iducenec,tabucenci.priimek AS upriimek,tabucenci.ime AS uime,tabucitelji.iducitelj,tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, tabrazred.idvzgojitelj,tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime FROM (tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec WHERE idRazred=" . $VRazred." AND tabrazred.leto=".$VLeto." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                $result = mysqli_query($link,$SQL);

                $RazredDat[$IndxRazred][0]=$VRazred1.". ".$VParalelka;

                if ($R = mysqli_fetch_array($result)){
                    $Ucitelj = $R["ucpriimek"]  . ", " . $R["ucime"];
                    $IdUcitelj=$R["iducitelj"];
                    $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                    $IdVzgojitelj=$R["idvzgojitelj"];

                }
                $RazredDat[$IndxRazred][1]=$Ucitelj;

                $Indx=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    $Ucenci[$Indx][0]=$R["iducenec"];
                    $Ucenci[$Indx][1]=$R["upriimek"].", ".$R["uime"];
                    $Ucenci[$Indx][2]=$VRazred1.$VParalelka;
                    $Ucenci[$Indx][3]=$R["datroj"];
                    $Indx=$Indx+1;
                }
                $StUcencev=$Indx;

                //Realizacija ur
                $SQL = "SELECT tabrealizacija.*,tabpredmeti.* FROM ";
                $SQL = $SQL . "(tabrealizacija INNER JOIN tabpredmeti ON tabrealizacija.Predmet=tabpredmeti.Id) ";
                $SQL .= "INNER JOIN tabrazdat ON tabrealizacija.idrazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrealizacija.Razred=".$VRazred1." AND paralelka='".$VParalelka."' AND prioriteta IN (0,2) AND tabrealizacija.leto=".$VLeto." "." AND tabrazdat.idsola=".$sola[$IndxSola][0];
                $SQL = $SQL . " ORDER BY VrstniRed";
                $result = mysqli_query($link,$SQL);

                $UcneUre[0]=0;
                $UcneUre[1]=0;
                $UcneUre[2]=0;
                $UcneUre[3]=0;

                for ($Indx=0;$Indx <= 200;$Indx++){
                    $UcneUrePredmeti[$Indx][0]=0;
                    $UcneUrePredmeti[$Indx][1]=0;
                    $UcneUrePredmeti[$Indx][2]=0;
                    $UcneUrePredmeti[$Indx][3]=0;
                    $UcneUrePredmeti[$Indx][4]=0;
                    $UcneUrePredmeti[$Indx][5]=0;
                }

                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
                    $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
                    $UcneUre[2]=$UcneUre[2]+$R["Plan"];
                    $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
                    $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
                    $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
                    $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
                    $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
                    $UcneUrePredmeti[$Indx][4]=$R["Plan"];
                    $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
                    $Indx=$Indx+1;
                }
                $StPredmetovUcneUre=$Indx;

                $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
                $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
                $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
                $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

                if ($UcneUre[2] > 0){
                    $RazredDat[$IndxRazred][2]=$UcneUre[3]/$UcneUre[2];
                }

                //skupna statistika razreda po spolu - zacetek
                $SQL = "SELECT tabucenci.spol FROM tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);
                
                $StUcencevM=0;
                $StUcencevW=0;
                while ($R = mysqli_fetch_array($result)){
                    if ($R["spol"]=="M"){
                        $StUcencevM=$StUcencevM+1;
                    }else{
                        $StUcencevW=$StUcencevW+1;
                    }
                }
                
                $SQL = "SELECT tabucenci.iducenec,tabucenci.spol,tabocene.ocenakoncna,tabocene.ocenapolletna,tabocene.neocenjen,tabocene.idpredmet FROM (tabucenci INNER JOIN tabrazred ON tabucenci.IdUcenec=tabrazred.IdUcenec) INNER JOIN tabocene ON tabucenci.IdUcenec=tabocene.IdUcenec WHERE idRazred=".$VRazred." AND tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." ORDER BY Razred,Paralelka,Priimek,Ime";
                $result = mysqli_query($link,$SQL);

                $StUcencevWNeg=0;
                $StUcencevMNeg=0;
                $StUcencevWNegPol=0;
                $StUcencevMNegPol=0;
                $StUcencevWNeoc=0;
                $StUcencevMNeoc=0;
                if ($R = mysqli_fetch_array($result)){
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenakoncna"] == "1") or ($R["ocenakoncna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeg=$StUcencevMNeg+1;
                                }else{
                                    $StUcencevWNeg=$StUcencevWNeg+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if (($R["ocenapolletna"] == "1") or ($R["ocenapolletna"] == "Ni opravil")){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNegPol=$StUcencevMNegPol+1;
                                }else{
                                    $StUcencevWNegPol=$StUcencevWNegPol+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }

                    $result = mysqli_query($link,$SQL);
                    $UcenecComp=0;
                    while ($R = mysqli_fetch_array($result)){
                        if ($R["neocenjen"] == 1){
                            if ($R["iducenec"]!=$UcenecComp){
                                if ($R["spol"]=="M"){
                                    $StUcencevMNeoc=$StUcencevMNeoc+1;
                                }else{
                                    $StUcencevWNeoc=$StUcencevWNeoc+1;
                                }
                                $UcenecComp=$R["iducenec"];
                            }
                        }
                    }
                }
                //skupna statistika razreda po spolu - konec

                //negativne ocene učencev pri predmetih-zacetek
                $IndxUcN=0;
                $IndxUcNP=0;
                $IndxNeoc=0;
                
                for ($Indx=0;$Indx <= 200;$Indx++){
                    $PredmetNegativno[$Indx]=0;
                    $PredmetNegativnoPol[$Indx]=0;
                    $PredmetNeocenjen[$Indx]=0;
                }
                for ($Indx=0;$Indx <= 30;$Indx++){
                    $UcenciNegativni[$Indx][0]=0;
                    $UcenciNegativni[$Indx][1]=0;
                    $UcenciNegativni[$Indx][2]=0;
                    $UcenciNegativniPol[$Indx][0]=0;
                    $UcenciNegativniPol[$Indx][1]=0;
                    $UcenciNegativniPol[$Indx][2]=0;
                    $UcenciNezadostni[$Indx]=0;
                    $UcenciNezadostniPol[$Indx]=0;
                }

                for ($IndxUc=0;$IndxUc < $StUcencev;$IndxUc++){
                    $UcenciNezadostni[$IndxUc]=0;
                    $UcenciNezadostniPol[$IndxUc]=0;
                    for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                        $Ocene[$Indx1][4]="";
                        $Ocene[$Indx1][5]="";
                    }

                    $SQL = "SELECT  idpredmet,ocenakoncna,ocenapolletna,neocenjen FROM tabocene WHERE IdUcenec=".$Ucenci[$IndxUc][0]." AND leto=".$VLeto;
                    $result = mysqli_query($link,$SQL);
                    $Indx=0;
                    while ($R = mysqli_fetch_array($result)){
                        for ($Indx1= 0;$Indx1 < $StPredmetov;$Indx1++){
                            if ($R["idpredmet"]==$Predmeti[$Indx1][0]){
                                $Ocene[$Indx1][4]=$R["ocenakoncna"];
                                $Ocene[$Indx1][5]=$R["ocenapolletna"];
                                $Neocenjen[$Indx1]=$R["neocenjen"];
                                if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
                                    $PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
                                    $UcenciNegativni[$IndxUcN][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativni[$IndxUcN][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
                                    $IndxUcN=$IndxUcN+1;
                                    $UcenciNezadostni[$IndxUc]=1;
                                }
                                if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
                                    $PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
                                    $UcenciNegativniPol[$IndxUcNP][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNegativniPol[$IndxUcNP][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
                                    $IndxUcNP=$IndxUcNP+1;
                                    $UcenciNezadostniPol[$IndxUc]=1;
                                }
                                if ($Neocenjen[$Indx1]==1){
                                    $PredmetNeocenjen[$Indx1]=$PredmetNeocenjen[$Indx1]+1;
                                    $UcenciNeocenjeni[$IndxNeoc][0]=$Ucenci[$IndxUc][0];
                                    $UcenciNeocenjeni[$IndxNeoc][1]=$Ucenci[$IndxUc][1];
                                    $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                                    $IndxNeoc=$IndxNeoc+1;
                                }
                                
                            }
                        }
                        $Indx=$Indx+1;
                    }
                }

                $Nezadostnih=0;
                $NezadostnihPol=0;
                for ($Indx=0;$Indx < $StUcencev;$Indx++){
                    $Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
                    $NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
                }
                
                if ($StUcencev > 0){
                    $RazredDat[$IndxRazred][3]=$StUcencev;
                    $RazredDat[$IndxRazred][4]=$StUcencevMNeg+$StUcencevWNeg;
                    if ($StUcencev > 0){
                        $RazredDat[$IndxRazred][5]=($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)/$StUcencev;
                    }else{
                        $RazredDat[$IndxRazred][5]=0;
                    }
                    $RazredDatNeoc[$IndxRazred][4]=$StUcencevMNeoc+$StUcencevWNeoc;
                    
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        $RazredDat[$IndxRazred][6+$Indx]=$PredmetNegativno[$Indx];
                        $RazredDatNeoc[$IndxRazred][6+$Indx]=$PredmetNeocenjen[$Indx];
                    }
                    $RazredDat[$IndxRazred][6+$StPredmetov]=$PredmetNegativno[$Indx];
                    $RazredDatNeoc[$IndxRazred][6+$StPredmetov]=$PredmetNeocenjen[$Indx];
                    //negativne ocene učencev pri predmetih-konec

                    echo "<tr bgcolor=lightyellow>";
                    echo "<td>".$RazredDat[$IndxRazred][0]."</td>"; // 'razred
                    echo "<td>".$RazredDat[$IndxRazred][1]."</td>"; // 'razrednik
                    echo "<td align=right>".number_format($RazredDat[$IndxRazred][2]*100,0)."%</td>"; // 'realizacija
                    echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>"; //'učencev
                    echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>"; // 'Negativni/neocenjeni
                    echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>"; // 'uspeh
                    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                        echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>"; // 'negativni/neocenjeni pri prdmetu
                        $RazredDat[$IndxRazred][$StPredmetov+6]=$RazredDat[$IndxRazred][$StPredmetov+6]+$RazredDat[$IndxRazred][$Indx+6];
                        $RazredDatNeoc[$IndxRazred][$StPredmetov+6]=$RazredDatNeoc[$IndxRazred][$StPredmetov+6]+$RazredDatNeoc[$IndxRazred][$Indx+6];
                    }
                    echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>"; // 'negativne skupaj
                    echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>"; // 'neocenjeni skupaj
                    echo "</tr>";
                }
            }

            //'izpiše še vsote po stolpcih
            $IndxRazred=$StRazredov;
            for ($Indx0=3;$Indx0 <= $StPredmetov+6;$Indx0++){
                $RazredDat[$StRazredov][$Indx0]=0;
                $RazredDatNeoc[$StRazredov][$Indx0]=0;
                for ($Indx=0;$Indx < $StRazredov;$Indx++){
                    $RazredDat[$StRazredov][$Indx0]=$RazredDat[$StRazredov][$Indx0]+$RazredDat[$Indx][$Indx0];
                    $RazredDatNeoc[$StRazredov][$Indx0]=$RazredDatNeoc[$StRazredov][$Indx0]+$RazredDatNeoc[$Indx][$Indx0];
                }
            }
            echo "<tr bgcolor=lightgreen>";
            echo "<td></td>";
            echo "<td>Skupaj</td>";
            If ($UcneUreVse[2] > 0){
                echo "<td align=right>".number_format(($UcneUreVse[3]/$UcneUreVse[2])*100,2)."%</td>";
            }else{
                echo "<td></td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][3]."</td>";
            echo "<td align=center>".$RazredDat[$IndxRazred][4]."/".$RazredDatNeoc[$IndxRazred][4]."</td>";
            echo "<td align=right>".number_format(($RazredDat[$IndxRazred][3]-$RazredDat[$IndxRazred][4])/$RazredDat[$IndxRazred][3]*100,0)."%</td>";
            for ($Indx=0;$Indx < $StPredmetov;$Indx++){
                echo "<td align=center>".$RazredDat[$IndxRazred][$Indx+6]."/".$RazredDatNeoc[$IndxRazred][$Indx+6]."</td>";
            }
            echo "<td align=center>".$RazredDat[$IndxRazred][$StPredmetov+6]."</td>";
            echo "<td align=center>".$RazredDatNeoc[$IndxRazred][$StPredmetov+6]."</td>";
            echo "</tr>";

            echo "</table><br />";
            echo "<br /><a href='IzpisRealizacij.php?id=1'>Realizacije po predmetih in skupaj</a><br />";
        }
        break;
}
echo "</body>";
echo "</html>";
