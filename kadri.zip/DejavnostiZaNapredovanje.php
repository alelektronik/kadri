<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vnos dejavnosti učiteljev za napredovanje
</title>
<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>
</head>
<body>

<?php

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $IdUcitelj=$R["iducitelj"];
    $VUporabnikId=$IdUcitelj;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
/*
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VSola=$R["SolaKratko"];
	$VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
	$VRavnatelj=$R["Ravnatelj"];
	$VKrajSola=$R["Kraj"];
	$TipSole=$R["TipSole"];
}else{
	$VSola=" ";
	$VRavnatelj=" ";
}

switch ($Vid){
	case "1": //'vpis podatkov
		$Ucitelj=$_POST["ucitelj"];
		$VDejavnost=$_POST["dejavnost"];
		$VDatumOd=$_POST["datumOd"];
		if (!isDate($VDatumOd)) {
            $VDatumOd=$Danes->format('d.m.Y');
        }
		$VDatumDo=$_POST["datumDo"];
		if (!isDate($VDatumDo)){
            $VDatumDo=$Danes->format('d.m.Y');
        }
		$VPotrdilo=$_POST["potrdilo"];
		$VZavod=$_POST["zavod"];
		$VPravilnik=$_POST["pravilnik"];
		$VOpombe=$_POST["opombe"];
		
		$SQL = "SELECT TabDodatneDejavnosti.*,tabucitelji.priimek,tabucitelji.ime FROM TabDodatneDejavnosti INNER JOIN tabucitelji ON TabDodatneDejavnosti.idUcitelj=tabucitelji.idUcitelj ";
		$SQL = $SQL . " WHERE leto=".$VLeto;
		$SQL = $SQL ." AND TabDodatneDejavnosti.idUcitelj=".$Ucitelj;
		$SQL = $SQL ." AND dejavnost='".$VDejavnost."'";
		$SQL = $SQL ." AND potrdilo='".$VPotrdilo."'";
		$SQL = $SQL ." AND DatumOd='".$VDatumOd."'";
		$SQL = $SQL ." AND DatumDo='".$VDatumDo."'";
		$SQL = $SQL ." AND zavod='".$VZavod."'";
		$SQL = $SQL ." AND pravilnik=".$VPravilnik;
		$SQL = $SQL ." AND opombe='".$VOpombe."'";
		
//'		echo $SQL."<br>"
		$result = mysqli_query($link,$SQL);
		
		if ($R = mysqli_fetch_array($result)){
			echo "<h2>Podatki so bili že vpisani!</h2>";
		}else{
			$SQL="INSERT INTO TabDodatneDejavnosti (leto,idUcitelj,dejavnost,potrdilo,DatumOd,DatumDo,zavod,pravilnik,opombe,vpisal,cas) ";
			$SQL = $SQL . "VALUES (";
			$SQL = $SQL .$VLeto.",".$Ucitelj.",";
			$SQL = $SQL ."'".$VDejavnost."',";
			$SQL = $SQL ."'".$VPotrdilo."',";
			$SQL = $SQL ."'".$VDatumOd."',";
			$SQL = $SQL ."'".$VDatumDo."',";
			$SQL = $SQL ."'".$VZavod."',";
			$SQL = $SQL .$VPravilnik.",";
			$SQL = $SQL ."'".$VOpombe."',";
			$SQL = $SQL ."'".$VUporabnik."',";
			$SQL = $SQL ."'".$Danes->format('Y-m-d H:i:s')."'";
			$SQL = $SQL .")";
			$result = mysqli_query($link,$SQL);

			echo "<h2>Podatki so vpisani!</h2>";
		}
        break;
	case "2":  //'obrazec za popravljanje
//'		echo request("popravi")."<br>"
		$SQL = "SELECT * FROM TabDodatneDejavnosti WHERE id=".$_GET["popravi"];
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$Ucitelj=$R["idUcitelj"];
			$VDejavnost=$R["dejavnost"];
			$VPotrdilo=$R["potrdilo"];
			$VDatumOd=$R["DatumOd"];
			$VDatumDo=$R["DatumDo"];
			$VZavod=$R["zavod"];
			$VPravilnik=$R["pravilnik"];
			$VOpombe=$R["opombe"];
			$VIdIzobrazevanje=$R["id"];
		}
		echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='DejavnostiZaNapredovanje.php'>";
		echo "<table border=1 cellspacing=0>";
		echo "<tr>";
		echo "<th>Leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";
		echo "<tr><th>Ime</th><td><select name='ucitelj'>";

		$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
		$result = mysqli_query($link,$SQL);
		while ($R = mysqli_fetch_array($result)){
			if ($Ucitelj==$R["iducitelj"]){
				echo "<option value=".$R["iducitelj"]." selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
			}else{
				if ($VLevel > 1){
					echo "<option value=".$R["iducitelj"].">".$R["priimek"]." ".$R["ime"]."</option>";
				}
			}
		}
		echo "</select></td></tr>";

		echo "<tr><th>Potrdilo</th><td><input name='potrdilo' type='text' size='80' value='".$VPotrdilo."'></td></tr>";
		echo "<tr><th>Dejavnost</th><td><input name='dejavnost' type='text' size='80' value='".$VDejavnost."'></td></tr>";
		echo "<tr><th>Zavod</th><td><input name='zavod' type='text' size='80' value='".$VZavod."'></td></tr>";
		echo "<tr><th>Datum od (DD.MM.LLLL)</th><td><input name='datumOd' type='text' size='10' value='".$VDatumOd."'></td></tr>";
		echo "<tr><th>Datum do (DD.MM.LLLL)</th><td><input name='datumDo' type='text' size='10' value='".$VDatumDo."'></td></tr>";
		echo "<tr><th>Po pravilniku</th><td><select name='pravilnik'><option value='0'>&nbsp;</option>";
		$SQL = "SELECT * FROM TabKriterijiZaNapredovanje";
		$result = mysqli_query($link,$SQL);
		while ($R = mysqli_fetch_array($result)){
			if ($R["ID"]==$VPravilnik) {
				echo "<option value='".$R["ID"]."' selected='selected'>".$R["clen"]." ".$R["razdelek"]." ".$R["alineja"]." - ".$R["tock"]." t ".substr($R["vsebina"],0,70)." ...</option>";
			}else{
				echo "<option value='".$R["ID"]."'>".$R["clen"]." ".$R["razdelek"]." ".$R["alineja"]." - ".$R["tock"]." t ".substr($R["vsebina"],0,70)." ...</option>";
			}
        }
		
		echo "</select></td></tr>";
		echo "<tr><th>Opombe</th><td><textarea name='opombe' cols='70' rows='6'>".$VOpombe."</textarea></td></tr>";

		echo "</table>";
		echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
		echo "<input name='id' type='hidden' value='4'>";
		echo "<input name='idizobrazevanje' type='hidden' value='".$VIdIzobrazevanje."'>";
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form>";
        break;
	case "3":   //'briši
		$SQL = "SELECT * FROM TabDodatneDejavnosti WHERE id=".$_GET["brisi"];
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			if ((($VLevel < 2) && ($IdUcitelj==$R["idUcitelj"])) or ($VLevel > 1)) {
				$SQL = "DELETE FROM TabDodatneDejavnosti WHERE id=".$_GET["brisi"];
				$result = mysqli_query($link,$SQL);
			}else{
				echo "Nimate pooblastil za brisanje teh podatkov!<br />";
			}
		}
        break;
	case "4":  //'popravi
		$Ucitelj=$_POST["ucitelj"];
		$VDejavnost=$_POST["dejavnost"];
		$VPotrdilo=$_POST["potrdilo"];
		$VDatumOd=$_POST["datumOd"];
		if (!isDate($VDatumOd)){
            $VDatumOd=$Danes->format('d.m.Y');
        }
		$VDatumDo=$_POST["datumDo"];
		if (!isDate($VDatumDo)){
            $VDatumDo=$Danes->format('d.m.Y');
        }
		$VZavod=$_POST["zavod"];
		$VPravilnik=$_POST["pravilnik"];
		$VOpombe=$_POST["opombe"];
		
		$SQL="UPDATE TabDodatneDejavnosti SET ";
		$SQL = $SQL . "idUcitelj=".$Ucitelj.",";
		$SQL = $SQL . "dejavnost='".$VDejavnost."',";
		$SQL = $SQL . "potrdilo='".$VPotrdilo."',";
		$SQL = $SQL . "datumOd='".$VDatumOd."',";
		$SQL = $SQL . "datumDo='".$VDatumDo."',";
		$SQL = $SQL . "zavod='".$VZavod."',";
		$SQL = $SQL . "pravilnik=".$VPravilnik.",";
		$SQL = $SQL . "opombe='".$VOpombe."',";
		$SQL = $SQL . "vpisal='".$VUporabnik."'";
		$SQL = $SQL . ",cas='".$Danes->format('Y-m-d H:i:s')."'";
		$SQL = $SQL ." WHERE id=".$_POST["idizobrazevanje"];
		$result = mysqli_query($link,$SQL);
        break;
	case "6":   //'izpis na obrazec
		$VZapisov=$_POST["zapisov"];
		for ($indx=1;$indx <= $VZapisov;$indx++){
			if (isset($_POST["print_".$indx])) {
			}
		}
        break;
	case "8": 	//'skupinski vpis
		for ($indx=1;$indx <= $_POST["Zapisov"];$indx++){
			if (isset($_POST["udel_".$indx] )){
				$Ucitelj=$_POST["uc_".$indx];
				$VDejavnost=$_POST["dejavnost"];
				$VDatumOd=$_POST["datumOd"];
				if (!isDate($VDatumOd) ){ 
                    $VDatumOd=$Danes->format('d.m.Y');
                }
				$VDatumDo=$_POST["datumDo"];
                if (!isDate($VDatumDo)){
                    $VDatumDo=$Danes->format('d.m.Y');
                }
				$VPotrdilo=$_POST["potrdilo"];
				$VZavod=$_POST["zavod"];
				$VPravilnik=$_POST["pravilnik"];
				$VOpombe=$_POST["opombe"];
				
				$SQL = "SELECT TabDodatneDejavnosti.*,tabucitelji.priimek,tabucitelji.ime FROM TabDodatneDejavnosti INNER JOIN tabucitelji ON TabDodatneDejavnosti.idUcitelj=tabucitelji.idUcitelj ";
				$SQL = $SQL . " WHERE leto=".$VLeto;
				$SQL = $SQL ." AND TabDodatneDejavnosti.idUcitelj=".$Ucitelj;
				$SQL = $SQL ." AND dejavnost='".$VDejavnost."'";
				$SQL = $SQL ." AND potrdilo='".$VPotrdilo."'";
				$SQL = $SQL ." AND DatumOd='".$VDatumOd."'";
				$SQL = $SQL ." AND DatumDo='".$VDatumDo."'";
				$SQL = $SQL ." AND zavod='".$VZavod."'";
				$SQL = $SQL ." AND pravilnik=".$VPravilnik;
				$SQL = $SQL ." AND opombe='".$VOpombe."'";
				
				$result = mysqli_query($link,$SQL);
				
				if ($R = mysqli_fetch_array($result)){
					echo "Podatki so bili že vpisani!<br />";
				}else{
					$SQL="INSERT INTO TabDodatneDejavnosti (leto,idUcitelj,dejavnost,potrdilo,DatumOd,DatumDo,zavod,pravilnik,opombe,vpisal,cas) ";
					$SQL = $SQL . "VALUES (";
					$SQL = $SQL .$VLeto.",".$Ucitelj.",";
					$SQL = $SQL ."'".$VDejavnost."',";
					$SQL = $SQL ."'".$VPotrdilo."',";
					$SQL = $SQL ."'".$VDatumOd."',";
					$SQL = $SQL ."'".$VDatumDo."',";
					$SQL = $SQL ."'".$VZavod."',";
					$SQL = $SQL .$VPravilnik.",";
					$SQL = $SQL ."'".$VOpombe."',";
					$SQL = $SQL ."'".$VUporabnik."',";
					$SQL = $SQL ."'".$Danes->format('Y-m-d H:i:s')."'";
					$SQL = $SQL .")";
					$result = mysqli_query($link,$SQL);

					echo "Podatki so vpisani (".$Ucitelj.")!<br />";
				}
			}
		}
		echo "<h3><a href='DejavnostiZaNapredovanje.php'>Nazaj na vnos dodatnih dejavnosti</a></h3>";
}

switch ($Vid){
	case "2":
    case "5":
    case "8":
		echo "<br />";
        break;
	default:
		echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='DejavnostiZaNapredovanje.php'>";
		echo "<h2>Dodatne dejavnosti delavcev</h2>";
		echo "<table border=1 cellspacing=0>";
//'	echo "<th>Leto</th><th>Ime</th><th>Izobra?evanje</th><th>Izvajalec</th><th>Kraj</th><th>Naslov</th><th>Datum od</th><th>Datum do</th><th>Trajanje</th><th>To?ke</th><th>Kotizacija EUR</th><th>Ostali<br>stro?ki EUR</th><th>Priporo?am</th><th>Poro?ilo</th><th>Popravi</th><th>Bri?i</th>"
		echo "<tr>";
		echo "<th>Šolsko leto</th><td>".$VLeto."/".($VLeto+1)."</td></tr>";
		echo "<tr><th>Ime</th>";
		if ($Vid=="7" ){
			echo "<td>Odkljukaj spodaj!</td></tr>";
		}else{
			echo "<td><select name='ucitelj'>";
			echo "<option value='0'>Ni izbran</option>";

			$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
			$result = mysqli_query($link,$SQL);
			while ($R = mysqli_fetch_array($result)){
				if ($R["iducitelj"]==$IdUcitelj){
					echo "<option value='".$R["iducitelj"]."' selected='selected'>".$R["priimek"]." ".$R["ime"]."</option>";
				}else{
					if ($VLevel > 1 ){
						echo "<option value='".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</option>";
					}
				}
			}
			echo "</select></td></tr>";
		}

		echo "<tr><th>Potrdilo</th><td><input name='potrdilo' type='text' size='80' value='Potrdilo o strokovni dejavnosti'></td></tr>";
		echo "<tr><th>Dejavnost</th><td><input name='dejavnost' type='text' size='80'></td></tr>";
		echo "<tr><th>Zavod</th><td><input name='zavod' type='text' size='80' value='".$VSola.", ".$VSolaNaslov."'></td></tr>";
		echo "<tr><th>Datum od (DD.MM.LLLL)</th><td><input name='datumOd' type='text' size='10'></td></tr>";
		echo "<tr><th>Datum do (DD.MM.LLLL)</th><td><input name='datumDo' type='text' size='10'></td></tr>";
		echo "<tr><th>Po pravilniku</th><td><select name='pravilnik'><option value='0'>&nbsp;</option>";
		$SQL = "SELECT * FROM TabKriterijiZaNapredovanje";
		$result = mysqli_query($link,$SQL);
		while ($R = mysqli_fetch_array($result)){
			echo "<option value='".$R["ID"]."'>".$R["clen"]." ".$R["razdelek"]." ".$R["alineja"]." - ".$R["tock"]." t ".substr($R["vsebina"],0,70)." ...</option>";
		}
		
		echo "</select></td></tr>";
		echo "<tr><th>Opombe</th><td><textarea name='opombe' cols='70' rows='6'></textarea></td></tr>";
		echo "</table><br />";

		if ($Vid=="7" ){
			echo "<table border='1' cellspacing='0'>";
			echo "<tr><th>Delavec</th><th>Udeležba</th><tr>";

			$SQL = "SELECT * FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
			$result = mysqli_query($link,$SQL);
			$indx=1;
			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				echo "<td><input type='hidden' name='uc_".$indx."' value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
				echo "<td><input type='checkbox' name='udel_".$indx."'></td>";
				echo "</tr>";
				$indx=$indx+1;
			}
			echo "</table>";
		}
		
		echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
		if ($Vid == "7" ){
			echo "<input name='Zapisov' type='hidden' value='".($indx-1)."'>";
			echo "<input name='id' type='hidden' value='8'>";
			echo "<input name='submit' type='submit' value='Pošlji'>";
		}else{
			echo "<input name='id' type='hidden' value='1'>";
			echo "<input name='submit' type='submit' value='Pošlji'>";
		}
		echo "</form>";
		echo "<br />";
		
		if ($VLevel > 1 ){
			echo "<h3><a href='DejavnostiZaNapredovanje.php?id=7'>Vnos skupinskega izobraževanja v organizaciji naše šole</a></h3>";
		}
		echo "<a href='http://predpisi.sviz.si/vzgoja-in-izobrazevanje/splosno/pravilnik-o-napredovanju-zaposlenih-v-vzgoji-in-izobrazevanju-v-nazive/index.php' target='_blank'>Pravilnik o napredovanju v nazive</a><br />";
		
		if ($Vid == "7" ){
		}else{
			echo "<h2>Spisek vnesenih dejavnosti</h2>";
            if ($VLevel > 1){
                echo "<a href='DejavnostiZaNapredovanje.php?solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".($VLeto)."</a> | <a href='DejavnostiZaNapredovanje.php?solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            }
			echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='PotrdilaUciteljRTF.php'>";
			echo "<table border=1 cellspacing=0>";
			echo "<tr bgcolor='lightcyan'><th>Leto</th><th>Ime</th><th>Potrdilo</th><th>Dejavnost</th><th>od</th><th>do</th><th>Zavod</th><th>Pravilnik</th><th>vsebina</th><th>Opombe</th><th>Popravi</th><th>Briši</th><th>Natisni</th></tr>";
			$SQL = "SELECT TabDodatneDejavnosti.*,tabucitelji.*,TabKriterijiZaNapredovanje.*,TabDodatneDejavnosti.Id AS did FROM ";
			$SQL = $SQL . "(TabDodatneDejavnosti INNER JOIN tabucitelji ON TabDodatneDejavnosti.IdUcitelj=tabucitelji.IdUcitelj) ";
			$SQL = $SQL . "INNER JOIN TabKriterijiZaNapredovanje ON TabDodatneDejavnosti.pravilnik=TabKriterijiZaNapredovanje.id ";
			if ($VLevel > 1 ){
				$SQL = $SQL . "WHERE TabDodatneDejavnosti.leto =".$VLeto;
			}else{
				$SQL = $SQL . "WHERE TabDodatneDejavnosti.idUcitelj=".$IdUcitelj;
			}
			$SQL = $SQL . " ORDER BY tabucitelji.priimek,tabucitelji.ime,TabDodatneDejavnosti.leto,TabKriterijiZaNapredovanje.id";
			$result = mysqli_query($link,$SQL);

			$indx=1;
			while ($R = mysqli_fetch_array($result)){
				echo "<tr bgcolor='lightyellow'>";
				echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
				echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
				echo "<td>".$R["potrdilo"]."</td>";
				echo "<td>".$R["dejavnost"]."</td>";
				echo "<td>".$R["DatumOd"]."</td>";
				echo "<td>".$R["DatumDo"]."</td>";
				echo "<td>".$R["zavod"]."</td>";
				echo "<td>".$R["clen"]." ".$R["razdelek"]." ".$R["alineja"]." - ".$R["tock"]."t</td>";
				echo "<td>".$R["vsebina"]."</td>";
				echo "<td>".$R["opombe"]."</td>";
				echo "<td><a href='DejavnostiZaNapredovanje.php?id=2&popravi=".$R["did"]."'>Popravi</a></td>";
				echo "<td><a href='DejavnostiZaNapredovanje.php?id=3&brisi=".$R["did"]."'>Briši</a></td>";
				echo "<td><input name='iz_".$indx."' type='hidden' value='".$R["did"]."'><input name='print_".$indx."' type='checkbox'></td>";
				echo "</tr>";
				$indx = $indx+1;
			}
			echo "</table>";

			echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
			echo "<input name='zapisov' type='hidden' value='".($indx-1)."'>";
			echo "<input name='id' type='hidden' value='6'>";
			echo "<input name='submit' type='submit' value='Natisni'>&nbsp;<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'>&nbsp;<input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
			echo "<input name='submit' type='submit' value='Spisek'>";
			echo "</form>";
		}
}
?>

</body>
</html>
