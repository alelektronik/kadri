<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis učitelja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = 0;
        }
    }
}
$_SESSION["leto"] = $VLeto;
$_SESSION["ucitelj"]=$Ucitelj;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
    case "1":
        $StPredmetov=$_POST["StPredmetov"];
        for ($Indx=1;$Indx <= $StPredmetov;$Indx++){
            $VPredmeti[$Indx][0]=$_POST["predmet".$Indx];
            $VPredmeti[$Indx][1]=$_POST["razred".$Indx];
            $VPredmeti[$Indx][2]=$_POST["paralelka".$Indx];
            $Realizacija[$Indx][0]=$_POST["PlanPol".$Indx];
            $Realizacija[$Indx][0]=str_replace(",",".",$Realizacija[$Indx][0]);
            if (is_numeric($Realizacija[$Indx][0])){
                $Realizacija[$Indx][0]=str_replace(",",".",$Realizacija[$Indx][0]);
            }else{
                $Realizacija[$Indx][0]=0;
            }
            $Realizacija[$Indx][1]=$_POST["RealizacijaPol".$Indx];
                $Realizacija[$Indx][1]=str_replace(",",".",$Realizacija[$Indx][1]);
            if (is_numeric($Realizacija[$Indx][1])){
                $Realizacija[$Indx][1]=str_replace(",",".",$Realizacija[$Indx][1]);
            }else{
                $Realizacija[$Indx][1]=0;
            }
            $Realizacija[$Indx][2]=$_POST["Plan".$Indx];
                $Realizacija[$Indx][2]=str_replace(",",".",$Realizacija[$Indx][2]);
            if (is_numeric($Realizacija[$Indx][2])){
                $Realizacija[$Indx][2]=str_replace(",",".",$Realizacija[$Indx][2]);
            }else{
                $Realizacija[$Indx][2]=0;
            }
            $Realizacija[$Indx][3]=$_POST["Realizacija".$Indx];
                $Realizacija[$Indx][3]=str_replace(",",".",$Realizacija[$Indx][3]);
            if (is_numeric($Realizacija[$Indx][3])){
                $Realizacija[$Indx][3]=str_replace(",",".",$Realizacija[$Indx][3]);
            }else{
                $Realizacija[$Indx][3]=0;
            }
            $Realizacija[$Indx][4]=$_POST["PlanNL".$Indx];
                $Realizacija[$Indx][4]=str_replace(",",".",$Realizacija[$Indx][4]);
            if (is_numeric($Realizacija[$Indx][4])){
                $Realizacija[$Indx][4]=str_replace(",",".",$Realizacija[$Indx][4]);
            }else{
                $Realizacija[$Indx][4]=0;
            }
            $Realizacija[$Indx][5]=$_POST["RealizacijaNL".$Indx];
                $Realizacija[$Indx][5]=str_replace(",",".",$Realizacija[$Indx][5]);
            if (is_numeric($Realizacija[$Indx][5])){
                $Realizacija[$Indx][5]=str_replace(",",".",$Realizacija[$Indx][5]);
            }else{
                $Realizacija[$Indx][5]=0;
            }
            $Realizacija[$Indx][9]=$_POST["Plan3_".$Indx];
                $Realizacija[$Indx][9]=str_replace(",",".",$Realizacija[$Indx][9]);
            if (is_numeric($Realizacija[$Indx][9])){
                $Realizacija[$Indx][9]=str_replace(",",".",$Realizacija[$Indx][9]);
            }else{
                $Realizacija[$Indx][9]=0;
            }
            $Realizacija[$Indx][10]=$_POST["Realizacija3_".$Indx];
                $Realizacija[$Indx][10]=str_replace(",",".",$Realizacija[$Indx][10]);
            if (is_numeric($Realizacija[$Indx][10])){
                $Realizacija[$Indx][10]=str_replace(",",".",$Realizacija[$Indx][10]);
            }else{
                $Realizacija[$Indx][10]=0;
            }
            $Realizacija[$Indx][6]=$_POST["referenca".$Indx];
            $Realizacija[$Indx][7]=$_POST["ucenje".$Indx];
        }

        for ($Indx1=1;$Indx1 <= $StPredmetov;$Indx1++){
            if ($VPredmeti[$Indx1][0] > 0){
                $SQL = "SELECT TabRealizacija.* FROM ";
                $SQL = $SQL . "TabRealizacija ";
                $SQL = $SQL . "WHERE ucenje=".$Realizacija[$Indx1][7];
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT * FROM tabrazdat WHERE razred=".$VPredmeti[$Indx1][1]." AND oznaka='".$VPredmeti[$Indx1][2]."' AND leto=".$VLeto;
                    $result1 = mysqli_query($link,$SQL);
                    
                    if ($R1 = mysqli_fetch_array($result1)){
                        $VRazred=$R1["id"];
                    }
                    
                    if ($VPredmeti[$Indx1][2] != ""){
                        $SQL = "UPDATE TabRealizacija SET PlanNL=".$Realizacija[$Indx1][4].",RealizacijaNL=".$Realizacija[$Indx1][5];
                        $SQL = $SQL .",PlanPol=".$Realizacija[$Indx1][0].",RealizacijaPol=".$Realizacija[$Indx1][1];
                        $SQL = $SQL .",Plan3=".$Realizacija[$Indx1][9].",Realizacija3=".$Realizacija[$Indx1][10];
                        $SQL = $SQL .",Plan=".$Realizacija[$Indx1][2].",Realizacija=".$Realizacija[$Indx1][3];
                        $SQL = $SQL .", razred=".$VPredmeti[$Indx1][1];
                        $SQL = $SQL .", paralelka='".$VPredmeti[$Indx1][2]."'";
                        $SQL = $SQL .", idRazred=".$VRazred;
                        $SQL = $SQL .",referenca=".$Realizacija[$Indx1][6].",ucenje=".$Realizacija[$Indx1][7].",Vpisal='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["Id"];
                    }else{
                        $SQL = "UPDATE TabRealizacija SET PlanNL=".$Realizacija[$Indx1][4].",RealizacijaNL=".$Realizacija[$Indx1][5];
                        $SQL = $SQL .",PlanPol=".$Realizacija[$Indx1][0].",RealizacijaPol=".$Realizacija[$Indx1][1];
                        $SQL = $SQL .",Plan3=".$Realizacija[$Indx1][9].",Realizacija3=".$Realizacija[$Indx1][10];
                        $SQL = $SQL .",Plan=".$Realizacija[$Indx1][2].",Realizacija=".$Realizacija[$Indx1][3];
                        $SQL = $SQL .", razred=".$VPredmeti[$Indx1][1];
                        $SQL = $SQL .",referenca=".$Realizacija[$Indx1][6].",ucenje=".$Realizacija[$Indx1][7].",Vpisal='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."'";
                        $SQL = $SQL . " WHERE id=".$R["Id"];
                    }
                }else{
                    $SQL = "SELECT * FROM tabrazdat WHERE id=".$VPredmeti[$Indx1][1];
                    $result = mysqli_query($link,$SQL);
                    
                    if ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["razred"];
                        $VParalelka=$R["oznaka"];
                        $VRazred=$R["id"];
                    }
                    if ($VPredmeti[$Indx1][2] != ""){
                        $SQL = "INSERT INTO TabRealizacija (Leto,Predmet,PlanNL,RealizacijaNL,PlanPol,RealizacijaPol,Plan3,Realizacija3,Plan,Realizacija,Razred,Paralelka,Vpisal,Datum,referenca,ucenje,idRazred) ";
                        $SQL = $SQL . "values (" . $VLeto . "," . $VPredmeti[$Indx1][0] . "," . $Realizacija[$Indx1][4] . "," . $Realizacija[$Indx1][5] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][0] . "," . $Realizacija[$Indx1][1] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][9] . "," . $Realizacija[$Indx1][10] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][2] . "," . $Realizacija[$Indx1][3] . "," ;
                        $SQL = $SQL . $VPredmeti[$Indx1][1] . ",'" . $VPredmeti[$Indx1][2] . "','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "',".$Realizacija[$Indx1][6].",".$Realizacija[$Indx1][7].",".$VRazred.")";
                    }else{    
                        $SQL = "INSERT INTO TabRealizacija (Leto,Predmet,PlanNL,RealizacijaNL,PlanPol,RealizacijaPol,Plan3,Realizacija3,Plan,Realizacija,Razred,Paralelka,Vpisal,Datum,referenca,ucenje,idRazred) ";
                        $SQL = $SQL . "values (" . $VLeto . "," . $VPredmeti[$Indx1][0] . "," . $Realizacija[$Indx1][4] . "," . $Realizacija[$Indx1][5] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][0] . "," . $Realizacija[$Indx1][1] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][9] . "," . $Realizacija[$Indx1][10] . "," ;
                        $SQL = $SQL . $Realizacija[$Indx1][2] . "," . $Realizacija[$Indx1][3] . "," ;
                        $SQL = $SQL . $VPredmeti[$Indx1][1] . ",'" . $VPredmeti[$Indx1][2] . "','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "',".$Realizacija[$Indx1][6].",".$Realizacija[$Indx1][7].",0)";
                    }    
                }

                if (!($result = mysqli_query($link,$SQL))){
                    echo "Napaka pri vpisu!<br />";
                }
            }
        }

        if ($Opravila==1){
            $SQL = "SELECT tabdeldogodek.id FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='Realizacija' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$Indx]=$R["id"];
                $Indx=$Indx+1;
            }
            $StDogodkov=$Indx-1;

            for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                $result = mysqli_query($link,$SQL);
            }
        }
}

if ($VLevel > 1){    
    $SQL = "SELECT DISTINCT tabucenje.leto,tabucenje.idUcitelj AS uidUcitelj,tabucitelji.* FROM tabucenje INNER JOIN tabucitelji ON tabucenje.idUcitelj=tabucitelji.idUcitelj WHERE leto=".$VLeto." ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        $VUcitelj[$Indx][1]=$R["uidUcitelj"];
        $VUcitelj[$Indx][2]=$R["Priimek"]." ".$R["Ime"];
        $Indx=$Indx+1;
    }
    $StUciteljev=$Indx-1;

    echo "<form accept-charset='utf-8' name='rezultati' method='post' action='VnosRealizacijeInd.php'>";
    echo "<h2>Izberite učitelja za vnos realizacije</h2><br />";
    echo "<table border=0>";
    echo "<tr>";
    echo "<td>";
    echo "Šolsko leto: <select name='solskoleto'>";
    echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
    echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . $VLeto . "</option>";
    echo "<option value='" .  ($VLeto-2)  . "'>" . ($VLeto -2) . "/"  . ($VLeto-1) . "</option>";
    echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
    echo "</select>";
    echo "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>";
    echo "<select name='ucitelj'>";
    for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
        if ($VLevel > 1){
            if ($VUcitelj[$Indx][1]==$Ucitelj){
                echo "<option value='".$VUcitelj[$Indx][1]."' selected='selected'>".$VUcitelj[$Indx][2]."</option>";
            }else{
                echo "<option value='".$VUcitelj[$Indx][1]."'>".$VUcitelj[$Indx][2]."</option>";
            }
        }else{
            if ($VUcitelj[$Indx][1]==$UciteljComp){
                echo "<option value='".$VUcitelj[$Indx][1]."' selected>".$VUcitelj[$Indx][2]."</option>";
            }
        }
    }
    echo "</select>";
    echo "</td>";
    echo "</tr>";
    echo "</table>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</form>";
}
echo "<h2>Priporočilo: poročila si najprej napišite v Word-u nato pa prilepite v ustrezna okenca.</h2>";
echo "<h3>Po prihodu na stran pritisnite tipko pošlji vsaj v naslednjih 30 minutah.</h3>";

$SQL = "SELECT tabpredmeti.*,tabucenje.*,tabucenje.id AS uid FROM ";
$SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet) ";
$SQL = $SQL . "WHERE tabucenje.idUcitelj=".$Ucitelj." AND tabucenje.leto=".$VLeto." AND Prioriteta < 4 ORDER BY tabpredmeti.VrstniRed";
$result = mysqli_query($link,$SQL);

$StPredmetov=0;
while ($R = mysqli_fetch_array($result)){
    $StPredmetov=$StPredmetov+1;
	$Predmeti[$StPredmetov][0]=$R["uid"];
	$Predmeti[$StPredmetov][1]=$R["Oznaka"]." - ".$R["Opis"]." ".$R["Razred"].". ".$R["Paralelka"]." (".$R["uid"].")";
	$Predmeti[$StPredmetov][2]=$R["Predmet"];
	$Predmeti[$StPredmetov][3]=$R["Razred"];
	$Predmeti[$StPredmetov][4]=$R["Paralelka"];
	$Predmeti[$StPredmetov][5]=$R["uid"];
}

//'response.write "<br><a href='VnosPosebniDnevi.asp'>Vnos kulturnih, naravoslovnih, tehni?kih in ?portnih dni</a>"

echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='VnosRealizacijeInd.php'>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
echo "<input name='level' type='hidden' value='".$VLevel."'>";
echo "<input name='ucitelj' type='hidden' value='".$Ucitelj."'>";

echo "<table border=1 cellspacing=0>";
echo "<th>Predmet</th><th>Kol.leto<br>Plan</th><th>Kol.leto<br>Realizirano</th><th>Kol.leto<br>%</th><th>Polletje<br>Plan</th><th>Polletje<br>Realizirano</th><th>Polletje<br>%</th><th>25. teden<br>Plan</th><th>25. teden<br>Realizirano</th><th>25. teden<br>%</th><th>Leto<br>Plan</th><th>Leto<br>Realizirano</th><th>Leto<br>%</th>";

for ($ip=1;$ip <= $StPredmetov;$ip++ ){
	echo "<tr><td><input name=predmet".$ip." type=hidden value=".$Predmeti[$ip][2].">".$Predmeti[$ip][1]."</td>";
	$Realizacija[$ip][0]="0";
	$Realizacija[$ip][1]="0";
	$Realizacija[$ip][2]="0";
	$Realizacija[$ip][3]="0";
	$Realizacija[$ip][4]="0";
	$Realizacija[$ip][5]="0";
	$Realizacija[$ip][9]="0";
	$Realizacija[$ip][10]="0";
	$Realizacija[$ip][7]=$Predmeti[$ip][5];
	$Realizacija[$ip][6]=$Ucitelj;

	$SQL = "SELECT tabucenje.* FROM tabucenje WHERE tabucenje.id=".$Predmeti[$ip][0];
	$result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
		$Realizacija[$ip][0]=$R["Planirano"]*18;
		$Realizacija[$ip][4]=$R["Planirano"]*14; 
		if ($R["Razred"] < 9 ){
			$Realizacija[$ip][2]=$R["Planirano"]*35;
		}else{
			$Realizacija[$ip][2]=$R["Planirano"]*32;
		}
		$Realizacija[$ip][9]=$R["Planirano"]*25;
	}
	
//'	$SQL = "SELECT  TabRealizacija.* FROM TabRealizacija WHERE referenca=".$Ucitelj. " AND predmet=".$Predmeti[$ip,2)." AND Razred=".$Predmeti[$ip,3)." AND paralelka='".$Predmeti[$ip,4)."'"
	$SQL = "SELECT  TabRealizacija.* FROM TabRealizacija WHERE ucenje=".$Predmeti[$ip][5];
	$result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
		$Realizacija[$ip][0]=$R["PlanPol"];
		$Realizacija[$ip][1]=$R["RealizacijaPol"];
		$Realizacija[$ip][2]=$R["Plan"];
		$Realizacija[$ip][3]=$R["Realizacija"];
 		$Realizacija[$ip][4]=$R["PlanNL"];
		$Realizacija[$ip][5]=$R["RealizacijaNL"];
		if (is_numeric($R["Plan3"]) ){
			$Realizacija[$ip][9]=$R["Plan3"];
		}
		$Realizacija[$ip][10]=$R["Realizacija3"];
		$Realizacija[$ip][6]=$R["Referenca"];
		if (!is_numeric($R["Referenca"]) ){ 
            $Realizacija[$ip][6]=$Ucitelj;
        }
		if (!is_numeric($R["Ucenje"]) ){
			$Realizacija[$ip][7]=$Predmeti[$ip][5];
		}else{
			$Realizacija[$ip][7]=$R["Ucenje"];
		}
	}

	echo "<td><input name='PlanNL".$ip."' type='text' value='".$Realizacija[$ip][4]."' size='5'></td><td><input name='RealizacijaNL".$ip."' type='text' value='".$Realizacija[$ip][5]."' size='5'></td>";
	if ($Realizacija[$ip][4] > 0 ){
		echo "<td>".number_format(($Realizacija[$ip][5]/$Realizacija[$ip][4])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='PlanPol".$ip."' type='text' value='".$Realizacija[$ip][0]."' size='5'></td><td><input name='RealizacijaPol".$ip."' type='text' value='".$Realizacija[$ip][1]."' size='5'></td>";
	if ($Realizacija[$ip][0] > 0 ){
        echo "<td>".number_format(($Realizacija[$ip][1]/$Realizacija[$ip][0])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='Plan3_".$ip."' type='text' value='".$Realizacija[$ip][9]."' size='5'></td><td><input name='Realizacija3_".$ip."' type='text' value='".$Realizacija[$ip][10]."' size='5'></td>";
	if (($Realizacija[$ip][9] > 0) && ($Realizacija[$ip][10]) >= 0 ){
        echo "<td>".number_format(($Realizacija[$ip][10]/$Realizacija[$ip][9])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	echo "<td><input name='Plan".$ip."' type='text' value='".$Realizacija[$ip][2]."' size='5'></td><td><input name='Realizacija".$ip."' type='text' value='".$Realizacija[$ip][3]."' size='5'>";
	echo "<input name='razred".$ip."' type='hidden' value='".$Predmeti[$ip][3]."'>";
	echo "<input name='paralelka".$ip."' type='hidden' value='".$Predmeti[$ip][4]."'>";
	echo "<input name='referenca".$ip."' type='hidden' value='".$Realizacija[$ip][6]."'>";
	echo "<input name='ucenje".$ip."' type='hidden' value='".$Realizacija[$ip][7]."'>";
	echo "</td>";
	if ($Realizacija[$ip][2] > 0 ){
        echo "<td>".number_format(($Realizacija[$ip][3]/$Realizacija[$ip][2])*100,2)."%</td>";
	}else{
		echo "<td>-</td>";
	}
	
	echo "</tr>";
	
}

echo "</table>";
echo "<input name='StPredmetov' type='hidden' value='".$StPredmetov."'>";
echo "<input name='submit' type='submit' value='Pošlji realizacijo'>";
echo "</form>";

?>

</body>
</html>
