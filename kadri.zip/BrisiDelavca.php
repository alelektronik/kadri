<?php
require('const.php');
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Popravljanje podatkov o delavcih
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$out=false;
if ($VUporabnik != "admin") {
    $out=true;
    header("Location: nepooblascen.htm");
}else{
    $SQL = "SELECT uporabnik FROM tabucitelji WHERE idUcitelj=".$_POST["idUcitelj"];
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
	    if ($R["uporabnik"] == "admin") {
            $out=true;
            header("Location: nepooblascen.htm");
        }
    }
    if (isset($_POST["potrditev"])){
        if (!$out){
            $SQL = "DELETE FROM tabucitelji WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br>Delavec je bil izbrisan iz tabele tabucitelji!<br />";

            $SQL = "DELETE FROM tabvzgojitelji WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabVzgojitelji!<br />";

            $SQL = "DELETE FROM tabdeldogodek WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabDelDogodek!<br />";

            $SQL = "DELETE FROM tabdodatnedejavnosti WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabDodatneDejavnosti!<br />";

            $SQL = "DELETE FROM tabdopust WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabDopust!<br />";

            $SQL = "DELETE FROM tabdostop WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabDostop!<br />";

            $SQL = "DELETE FROM tabizjave WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabIzjave!<br />";

            $SQL = "DELETE FROM tabizobrazevanje WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabIzobrazevanje!<br />";

            $SQL = "DELETE FROM tabkljucdelavec WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabKljucDelavec!<br />";

            $SQL = "DELETE FROM tabkoefdela WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabKoefDela!<br />";

            $SQL = "DELETE FROM tabkontakti WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabKontakti!<br />";

            $SQL = "DELETE FROM tabkrajsidelovnik WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabKrajsiDelovnik!<br />";

            $SQL = "DELETE FROM tabopbucitelji WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabOPBUcitelji!<br />";

            $SQL = "DELETE FROM tabpogodbe WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabPogodbe!<br />";

            $SQL = "DELETE FROM tabpotninalog WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabPotniNalog!<br />";

            $SQL = "DELETE FROM tabpozvarnost WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabPozVarnost!<br />";

            $SQL = "DELETE FROM tabpregleddelan WHERE Ucitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabPregledDelaN!<br />";

            $SQL = "DELETE FROM tabracunovodstvo WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabRacunovodstvo!<br />";

            $SQL = "DELETE FROM tabrazred WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabRazred!<br />";

            $SQL = "DELETE FROM tabrazrednikpor WHERE razrednik=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabRazrednikPor!<br />";

            $SQL = "DELETE FROM tabrazrednikpork WHERE razrednik=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabRazrednikPorK!<br />";

            $SQL = "DELETE FROM tabregistracije WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabRegistracije!<br />";

            $SQL = "DELETE FROM taburnik WHERE Ucitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabUrnik!<br />";

            $SQL = "DELETE FROM tabvarstvodelo WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabVarstvoDelo!<br />";

            $SQL = "DELETE FROM tabvodjeaktivov WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabVodjeAktivov!<br />";

            $SQL = "DELETE FROM tabzascsr WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabZascSr!<br />";

            $SQL = "DELETE FROM tabzdrpregledi WHERE idUcitelj=".$_POST["idUcitelj"];
            $result = mysqli_query($link,$SQL);
            echo "<br />Delavec je bil izbrisan iz tabele TabZdrPregledi!<br />";
        }
    }else{
        echo "<br />";
        if (isset($_POST["obrazec"])){
            echo "<h2>Delavec ni bil izbrisan!</h2>";
        }else{
            $ucitelj = $_POST["idUcitelj"];
            $SQL = "SELECT priimek,ime,spol FROM tabucitelji WHERE iducitelj=$ucitelj";
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                echo "<form accept-charset='utf-8' name='brisi' method='post' action='BrisiDelavca.php'>";
                echo "<input name='potrditev' type='checkbox'>";
                if ($R["spol"] == "M"){
                    echo " Delavec: ".$R["ime"]." ".$R["priimek"]." bo dokončno odstranjen iz baze (nepovratno)! ";
                }else{
                    echo " Delavka: ".$R["ime"]." ".$R["priimek"]." bo dokončno odstranjena iz baze (nepovratno)! ";
                }
                echo "<input name='idUcitelj' type='hidden' value='$ucitelj'>";
                echo "<input name='obrazec' type='hidden' value='1'>";
                echo "<input name='submit' type='submit' value='Pošlji'>";
                echo "</form>";
            }
        }
    }
}
?>

</body>
</html>
