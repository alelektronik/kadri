<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Urnik
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            //dateFormat:"%Y%m%d",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2012,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            //dateFormat:"%Y%m%d",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2012,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUrnik",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
    case "1":  //vpis
        $Ucitelj=$_POST["ucitelj"];
        $VPredmet=$_POST["predmet"];
        $VNivo=$_POST["nivo"];
        $VRazred=$_POST["razred"];
        $VParalelka="";
        $VDevetletka=$_POST["vrstaos"];
        $VDan=$_POST["danvtednu"];
        $VUra=$_POST["ura"];
        $VProstor1=$_POST["prostor"];
        $od=$_POST["od"];
        if (isDate($od)){
            $Datum=new DateTime(isDate($od));
        }else{
            $Datum=new DateTime($Danes->format('Y-m-d'));
        }
        $od=$Datum->format('Ymd');
        $do=$_POST["do"];
        if (isDate($do)){
            $Datum=new DateTime(isDate($do));
        }else{
            $Datum=new DateTime($Danes->format('Y-m-d'));
        }
        $do=$Datum->format('Ymd');
                
        $_SESSION["UciteljSelect"]=$Ucitelj;
        $_SESSION["PredmetSelect"]=$VPredmet;
        $_SESSION["IzvedbaSelect"]=$VNivo;
        $_SESSION["RazredSelect"]=$VRazred;
        $_SESSION["ParalelkaSelect"]=$VParalelka;
        $_SESSION["DevetletkaSelect"]=$VDevetletka;
        $_SESSION["DanSelect"]=$VDan;
        $_SESSION["UraSelect"]=$VUra;
        $_SESSION["ProstorSelect"]=$VProstor1;
        $_SESSION["odSelect"]=$od;
        $_SESSION["doSelect"]=$do;

        if ($VRazred > 0){
            $SQL = "SELECT * FROM tabrazdat WHERE id=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
                $VRazred=$R["id"];
            }else{
                $VRazred1=$VRazred;
                $VParalelka="";
                $VRazred=0;
            }
        }else{
            $VRazred1=Abs($VRazred);
            $VParalelka="";
            $VRazred=0;
        }

        $SQL = "INSERT INTO taburnik (leto,ucitelj,predmet,nivo,razred,paralelka,vrstaos,DanVTednu,Ura,Prostor,idRazred,od,do) ";
        $SQL = $SQL . "VALUES (".$VLeto.",".$Ucitelj.",".$VPredmet.",".$VNivo.",".$VRazred1.",'".$VParalelka."',".$VDevetletka.",".$VDan.",".$VUra.",".$VProstor1.",".$VRazred.",".$od.",".$do.")";
        if (!($result = mysqli_query($link,$SQL))){
            die("Napaka pri vpisu v urnik!<br />$SQL<br />");
        }
        break;
    case "2":  //brisanje
        $SQL = "DELETE FROM taburnik WHERE id=".$_GET["zapis"];
        $result = mysqli_query($link,$SQL);
        break;
    case "3":  //popravi
        if (isset($_POST["zapis"])){
            $VUrnik=$_POST["zapis"];
        }else{
            $VUrnik=$_GET["zapis"];
        }
        $SQL = "SELECT taburnik.* FROM ((taburnik ";
        $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor ";
        $SQL = $SQL . "WHERE taburnik.id=".$VUrnik;
        $result = mysqli_query($link,$SQL);

        if ($R = mysqli_fetch_array($result)){
            $UciteljSelect=$R["Ucitelj"];
            $PredmetSelect=$R["Predmet"];
            $IzvedbaSelect=$R["Nivo"];
            $RazredSelect=$R["Razred"];
            $RazredSelect1=$R["idRazred"];
            $ParalelkaSelect=$R["Paralelka"];
            $DevetletkaSelect=$R["VrstaOS"];
            $DanSelect=$R["DanVTednu"];
            $UraSelect=$R["Ura"];
            $ProstorSelect=$R["Prostor"];
            $od=$R["od"];
            $do=$R["do"];
        }

        if ($RazredSelect1 > 0){
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE id=".$RazredSelect1;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
                $VRazred=$R["id"];
            }else{
                $VRazred1=$RazredSelect;
                $VParalelka=$ParalelkaSelect;
                $VRazred=0;
            }
        }else{
            $VRazred1=$RazredSelect;
            $VParalelka=$ParalelkaSelect;
            $VRazred=0;
        }

        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        //echo "<br />" & SQL & "<br />"
        $result = mysqli_query($link,$SQL);
            $Indx1=0;
            while ($R = mysqli_fetch_array($result)){
                $VUcitelji[$Indx1][0] = $R["iducitelj"];
                $VUcitelji[$Indx1][1] = $R["priimek"];
                $VUcitelji[$Indx1][2] = $R["ime"];
                $Indx1=$Indx1+1;
            }
            $StUciteljev=$Indx1-1;

            $SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VPredmeti[$Indx][0] = $R["id"];
                $VPredmeti[$Indx][1] = $R["oznaka"];
                $VPredmeti[$Indx][2] = $R["opis"];
                $VPredmeti[$Indx][3] = $R["prioriteta"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
            
            $SQL = "SELECT idprostor,stevilka,oznaka,opis FROM tabprostor  ORDER BY IdProstor";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VProstor[$Indx][0] = $R["idprostor"];
                $VProstor[$Indx][1] = $R["stevilka"];
                $VProstor[$Indx][2] = $R["oznaka"];
                $VProstor[$Indx][3] = $R["opis"];
                $Indx=$Indx+1;
            }
            $StProstorov=$Indx-1;

            $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL .= "WHERE leto=".$VLeto;
            $SQL .=" ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VRazredi[$Indx][0]=$R["id"];
                $VRazredi[$Indx][1]=$R["razred"];
                $VRazredi[$Indx][2]=$R["oznaka"];
                $VRazredi[$Indx][3]=$R["solakratko"];
                $Indx=$Indx+1;
            }
            $VStRazredov=$Indx-1;
            
            echo "<h2>Vpis urnika - ".$VLeto."/".($VLeto+1)."</h2>";
            echo "<form  name='Urnik' method=post action='VnosUrnika.php'>";
            echo "<input type=hidden name='zapis' value=".$VUrnik.">";
            echo "<input type=hidden name='id' value='3a'>";
            echo "<table border='1'>";
            echo "<th>Leto</th><th>Velja od</th><th>Velja do</th>";
            echo "<tr>";
            echo "<td><select name='leto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected='selected' value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select></td>";

            $Datum=new DateTime(substr($od,0,4)."-".substr($od,4,2)."-".substr($od,6,2));
            echo "<td><input name='od' type='text' size='8' id='dat01' value='".$Datum->format('d.m.Y')."'></td>";
            $Datum=new DateTime(substr($do,0,4)."-".substr($do,4,2)."-".substr($do,6,2));
            echo "<td><input name='do' type='text' size='8' id='dat02' value='".$Datum->format('d.m.Y')."'></td>";

            //echo "<td><input name='od' type='text' size='8' id='dat01' value='".$od."'></td>";
            //echo "<td><input name='do' type='text' size='8' id='dat02' value='".$do."'></td>";
            echo "</tr></table><br />";
            
            echo "<table border='1'>";
            echo "<th>Učitelj</th><th>Predmet</th><th>Izvedba</th>";
            echo "<tr>";
            echo "<td><select name='ucitelj'>";
            for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
                if ($VUcitelji[$Indx2][0]==$UciteljSelect){
                    echo "<option value='" . $VUcitelji[$Indx2][0] . "' selected='selected'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
                }else{
                    echo "<option value='" . $VUcitelji[$Indx2][0] . "'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='predmet'>";
            for ($Indx1=0;$Indx1 <= $StPredmetov;$Indx1++){
                if ($VPredmeti[$Indx1][0]==$PredmetSelect){
                    echo "<option value='" . $VPredmeti[$Indx1][0] . "' selected='selected'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
                }else{
                    echo "<option value='" . $VPredmeti[$Indx1][0] . "'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='nivo'>";
            if ($IzvedbaSelect==0){
                echo "<option value=0 selected='selected'>Samostojen predmet</option>";
            }else{
                echo "<option value=0>Samostojen predmet</option>";
            }
            if ($IzvedbaSelect==1){
                echo "<option value=1 selected='selected'>1. skupina</option>";
            }else{
                echo "<option value=1>1. skupina</option>";
            }
            if ($IzvedbaSelect==2){
                echo "<option value=2 selected='selected'>2. skupina</option>";
            }else{
                echo "<option value=2>2. skupina</option>";
            }
            if ($IzvedbaSelect==3){
                echo "<option value=3 selected='selected'>3. skupina</option>";
            }else{
                echo "<option value=3>3. skupina</option>";
            }
            if ($IzvedbaSelect==4){
                echo "<option value=4 selected='selected'>Izbirni</option>";
            }else{
                echo "<option value=4>Izbirni</option>";
            }
            if ($IzvedbaSelect==5){
                echo "<option value=5 selected='selected'>Podaljšano bivanje</option>";
            }else{
                echo "<option value=5>Podaljšano bivanje</option>";
            }
            if ($IzvedbaSelect==6){
                echo "<option value=6 selected='selected'>Druge dejavnosti</option>";
            }else{
                echo "<option value=6>Druge dejavnosti</option>";
            }
            if ($IzvedbaSelect==7){
                echo "<option value=7 selected='selected'>4. skupina</option>";
            }else{
                echo "<option value=7>4. skupina</option>";
            }
            if ($IzvedbaSelect==8){
                echo "<option value=8 selected='selected'>5. skupina</option>";
            }else{
                echo "<option value=8>5. skupina</option>";
            }
            if ($IzvedbaSelect==9){
                echo "<option value=9 selected='selected'>6. skupina</option>";
            }else{
                echo "<option value=9>6. skupina</option>";
            }
            echo "</select></td>";

            echo "</tr></table><br />";
            echo "<table border=1>";
            echo "<th>Razred</th>";
            echo "<tr>";

            echo "<td><select name='razred'>";
            for ($Indx1=0;$Indx1 <= 9;$Indx1++){
                if ($Indx1==$VRazred1){
                    echo "<option value='".(-$Indx1)."' selected='selected'>".$Indx1.".</option>";
                }else{
                    echo "<option value='".(-$Indx1)."'>".$Indx1.".</option>";
                }
            }
            for ($Indx1=0;$Indx1 <= $VStRazredov;$Indx1++){
                if ($VecSol > 0){
                    if ($VRazredi[$Indx1][0]==$VRazred){
                        echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
                    }else{
                        echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
                    }
                }else{
                    if ($VRazredi[$Indx1][0]==$VRazred){
                        echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                    }else{
                        echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                    }
                }
            }
            echo "</select>";
            echo "<input name='vrstaos' type='hidden' value='9'></td>";

            echo "</tr></table><br />";
            echo "<table border=1>";
            echo "<th>Dan</th><th>Ura</th><th>Prostor</th>";
            echo "</tr>";
            echo "<td><select name='danvtednu'>";
            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
                if ($Indx1==$DanSelect){
                    echo "<option value='".$Indx1."' selected='selected'>".Int2Dan($Indx1)."</option>";
                }else{
                    echo "<option value='".$Indx1."'>".Int2Dan($Indx1)."</option>";
                }
            }
            echo"</select></td>";
            echo "<td><select name='ura'>";
            for ($Indx=0;$Indx <= 12;$Indx++){
                if ($Indx==$UraSelect){
                    echo "<option selected='selected'>".$Indx."</option>";
                }else{
                    echo "<option>".$Indx."</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='prostor'>";
            for ($Indx=0;$Indx <= $StProstorov;$Indx++){
                if ($VProstor[$Indx][0]==$ProstorSelect){
                    echo "<option value=" . $VProstor[$Indx][0] . " selected='selected'>" . $VProstor[$Indx][1]." - ".$VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
                }else{
                    echo "<option value=" . $VProstor[$Indx][0] . ">" . $VProstor[$Indx][1]." - ". $VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
                }
            }
            echo "</select></td>";
            echo "</tr></table>";
            echo "<input name='submit' type='submit' value='Pošlji'>";

            echo "<br /><hr><br />";
        break;
    case "3a":  //update
        $Ucitelj=$_POST["ucitelj"];
        $VPredmet=$_POST["predmet"];
        $VNivo=$_POST["nivo"];
        $VRazred=$_POST["razred"];
        $VParalelka="";
        $VDevetletka=$_POST["vrstaos"];
        $VDan=$_POST["danvtednu"];
        $VUra=$_POST["ura"];
        $VProstor1=$_POST["prostor"];
        $VUrnik=$_POST["zapis"];
        $od=$_POST["od"];
        if (isDate($od)){
            $Datum=new DateTime(isDate($od));
        }else{
            $Datum=new DateTime($Danes->format('Y-m-d'));
        }
        $od=$Datum->format('Ymd');
        $do=$_POST["do"];
        if (isDate($do)){
            $Datum=new DateTime(isDate($do));
        }else{
            $Datum=new DateTime($Danes->format('Y-m-d'));
        }
        $do=$Datum->format('Ymd');

        $_SESSION["UciteljSelect"]=$Ucitelj;
        $_SESSION["PredmetSelect"]=$VPredmet;
        $_SESSION["IzvedbaSelect"]=$VNivo;
        $_SESSION["RazredSelect"]=$VRazred;
        $_SESSION["ParalelkaSelect"]=$VParalelka;
        $_SESSION["DevetletkaSelect"]=$VDevetletka;
        $_SESSION["DanSelect"]=$VDan;
        $_SESSION["UraSelect"]=$VUra;
        $_SESSION["ProstorSelect"]=$VProstor1;
        $_SESSION["odSelect"]=$od;
        $_SESSION["doSelect"]=$do;

        if ($VRazred > 0){
            $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE id=".$VRazred;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VRazred1=$R["razred"];
                $VParalelka=$R["oznaka"];
                $VRazred=$R["id"];
            }else{
                $VRazred1=$VRazred;
                $VParalelka="";
                $VRazred=0;
            }
        }else{
            $VRazred1=Abs($VRazred);
            $VParalelka="";
            $VRazred=0;
        }

        $SQL = "UPDATE taburnik SET ucitelj=".$Ucitelj.",predmet=".$VPredmet.",nivo=".$VNivo.",razred=".$VRazred1.",paralelka='".$VParalelka."',vrstaos=".$VDevetletka.",DanVTednu=".$VDan.",ura=".$VUra.",prostor=".$VProstor1.",idRazred=".$VRazred.",od=".$od.",do=".$do." WHERE id=".$VUrnik;
        if (!$result = mysqli_query($link,$SQL)){
            echo "Napaka pri vpisu popravka!<br />";
        }
        break;
    case "4":  //za določen dan (izbor)
        $SQL = "SELECT od,do FROM taburnik ";
        $SQL = $SQL . " ORDER BY id DESC LIMIT 0,1";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $odSelect=$R["od"];
            $doSelect=$R["do"];
        }else{
            $Datum=new DateTime($VLeto."-09.01");
            $odSelect=intval($Datum->format('Ymd'));
            $Datum=new DateTime(($VLeto+1)."-06.25");
            $doSelect=intval($Datum->format('Ymd'));
        }
        if (isset($_GET["ucitelj"])){
            $UciteljSelect=$_GET["ucitelj"];
        }
        if (isset($_SESSION["PredmetSelect"])){
            $PredmetSelect=$_SESSION["PredmetSelect"];
        }
        if (isset($_SESSION["IzvedbaSelect"])){
            $IzvedbaSelect=$_SESSION["IzvedbaSelect"];
        }
        if (isset($_SESSION["RazredSelect"])){
            $RazredSelect=$_SESSION["RazredSelect"];
        }
        if (isset($_SESSION["ParalelkaSelect"])){
            $ParalelkaSelect=$_SESSION["ParalelkaSelect"];
        }
        if (isset($_SESSION["DevetletkaSelect"])){
            $DevetletkaSelect=$_SESSION["DevetletkaSelect"];
        }
        if (isset($_GET["dan"])){
            $DanSelect=$_GET["dan"];
        }
        if (isset($_GET["ura"])){
            $UraSelect=$_GET["ura"];
        }
        if (isset($_SESSION["ProstorSelect"])){
            $ProstorSelect=$_SESSION["ProstorSelect"];
        }
        if (isset($_SESSION["odSelect"])){
            $odSelect=$_SESSION["odSelect"];
        }
        if (isset($_SESSION["doSelect"])){
            $doSelect=$_SESSION["doSelect"];
        }

        $SQL = "SELECT id,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        //echo "<br />" & SQL & "<br />"
        $result = mysqli_query($link,$SQL);
            $Indx1=0;
            while ($R = mysqli_fetch_array($result)){
                $VUcitelji[$Indx1][0] = $R["id"];
                $VUcitelji[$Indx1][1] = $R["priimek"];
                $VUcitelji[$Indx1][2] = $R["ime"];
                $Indx1=$Indx1+1;
            }
            $StUciteljev=$Indx1-1;

            $SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VPredmeti[$Indx][0] = $R["id"];
                $VPredmeti[$Indx][1] = $R["oznaka"];
                $VPredmeti[$Indx][2] = $R["opis"];
                $VPredmeti[$Indx][3] = $R["prioriteta"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;
            
            $SQL = "SELECT idprostor,stevilka,oznaka,opis FROM tabprostor  ORDER BY IdProstor";
            $result = mysqli_query($link,$SQL);
            
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VProstor[$Indx][0] = $R["idprostor"];
                $VProstor[$Indx][1] = $R["stevilka"];
                $VProstor[$Indx][2] = $R["oznaka"];
                $VProstor[$Indx][3] = $R["opis"];
                $Indx=$Indx+1;
            }
            $StProstorov=$Indx-1;

            $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat ";
            $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
            $SQL .= "WHERE leto=".$VLeto;
            $SQL .=" ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
            $result = mysqli_query($link,$SQL);
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                $VRazredi[$Indx][0]=$R["id"];
                $VRazredi[$Indx][1]=$R["razred"];
                $VRazredi[$Indx][2]=$R["oznaka"];
                $VRazredi[$Indx][3]=$R["solakratko"];
                $Indx=$Indx+1;
            }
            $VStRazredov=$Indx-1;

            echo "<a name=top></a>";
            echo "<h2>Vpis urnika - ".$VLeto."/".($VLeto+1)."</h2>";
            echo "<form  name='Urnik' method=post action='VnosUrnika.php'>";
            echo "<input name='id' type='hidden' value='1'>";
            echo "<table border='1'>";
            echo "<th>Leto</th><th>Velja od</th><th>Velja do</th>";
            echo "<tr>";
            echo "<td><select name='leto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected='selected' value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select></td>";

            $Datum=new DateTime(substr($odSelect,0,4)."-".substr($odSelect,4,2)."-".substr($odSelect,6,2));
            echo "<td><input name='od' type='text' size='8' id='dat01' value='".$Datum->format('d.m.Y')."'></td>";
            $Datum=new DateTime(substr($doSelect,0,4)."-".substr($doSelect,4,2)."-".substr($doSelect,6,2));
            echo "<td><input name='do' type='text' size='8' id='dat02' value='".$Datum->format('d.m.Y')."'></td>";

            //echo "<td><input name='od' type='text' size='8' id='dat01' value='".$odSelect."'></td>";
            //echo "<td><input name='do' type='text' size='8' id='dat02' value='".$doSelect."'></td>";
            echo "</tr></table><br />";

            echo "<table border='1'>";
            echo "<th>Učitelj</th><th>Predmet</th><th>Izvedba</th>";
            echo "<tr>";
            echo "<td><select name='ucitelj'>";
            for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
                if ($VUcitelji[$Indx2][0]==$UciteljSelect){
                    echo "<option value='" . $VUcitelji[$Indx2][0] . "' selected='selected'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
                }else{
                    echo "<option value='" . $VUcitelji[$Indx2][0] . "'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='predmet'>";
            for ($Indx1=0;$Indx1 <= $StPredmetov;$Indx1++){
                if ($VPredmeti[$Indx1][0]==$PredmetSelect){
                    echo "<option value='" . $VPredmeti[$Indx1][0] . "' selected='selected'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
                }else{
                    echo "<option value='" . $VPredmeti[$Indx1][0] . "'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='nivo'>";
            if ($IzvedbaSelect==0){
                echo "<option value=0 selected='selected'>Samostojen predmet</option>";
            }else{
                echo "<option value=0>Samostojen predmet</option>";
            }
            if ($IzvedbaSelect==1){
                echo "<option value=1 selected='selected'>1. skupina</option>";
            }else{
                echo "<option value=1>1. skupina</option>";
            }
            if ($IzvedbaSelect==2){
                echo "<option value=2 selected='selected'>2. skupina</option>";
            }else{
                echo "<option value=2>2. skupina</option>";
            }
            if ($IzvedbaSelect==3){
                echo "<option value=3 selected='selected'>3. skupina</option>";
            }else{
                echo "<option value=3>3. skupina</option>";
            }
            if ($IzvedbaSelect==4){
                echo "<option value=4 selected='selected'>Izbirni</option>";
            }else{
                echo "<option value=4>Izbirni</option>";
            }
            if ($IzvedbaSelect==5){
                echo "<option value=5 selected='selected'>Podaljšano bivanje</option>";
            }else{
                echo "<option value=5>Podaljšano bivanje</option>";
            }
            if ($IzvedbaSelect==6){
                echo "<option value=6 selected='selected'>Druge dejavnosti</option>";
            }else{
                echo "<option value=6>Druge dejavnosti</option>";
            }
            if ($IzvedbaSelect==7){
                echo "<option value=7 selected='selected'>4. skupina</option>";
            }else{
                echo "<option value=7>4. skupina</option>";
            }
            if ($IzvedbaSelect==8){
                echo "<option value=8 selected='selected'>5. skupina</option>";
            }else{
                echo "<option value=8>5. skupina</option>";
            }
            if ($IzvedbaSelect==9){
                echo "<option value=9 selected='selected'>6. skupina</option>";
            }else{
                echo "<option value=9>6. skupina</option>";
            }
            echo "</select></td>";
            
            echo "</tr></table><br />";
            echo "<table border=1>";
            echo "<th>Razred</th>";
            echo "<tr>";
            
            echo "<td><select name='razred'>";
            for ($Indx1=0;$Indx1 <= 9;$Indx1++){
                if ($Indx1==$VRazred1){
                    echo "<option value='".(-$Indx1)."' selected='selected'>".$Indx1.".</option>";
                }else{
                    echo "<option value='".(-$Indx1)."'>".$Indx1.".</option>";
                }
            }
            for ($Indx1=0;$Indx1 <= $VStRazredov;$Indx1++){
                if ($VecSol > 0){
                    if ($VRazredi[$Indx1][0]==$VRazred){
                        echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
                    }else{
                        echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
                    }
                }else{
                    if ($VRazredi[$Indx1][0]==$VRazred){
                        echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                    }else{
                        echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                    }
                }
            }
            echo "</select>";
            echo "<input name='vrstaos' type='hidden' value='9'></td>";

            echo "</tr></table><br />";
            echo "<table border=1>";
            echo "<th>Dan</th><th>Ura</th><th>Prostor</th>";
            echo "</tr>";
            echo "<td><select name='danvtednu'>";
            for ($Indx1=1;$Indx1 <= 5;$Indx1++){
                if ($Indx1==$DanSelect){
                    echo "<option value='".$Indx1."' selected='selected'>".Int2Dan($Indx1)."</option>";
                }else{
                    echo "<option value='".$Indx1."'>".Int2Dan($Indx1)."</option>";
                }
            }
            echo"</select></td>";
            echo "<td><select name='ura'>";
            for ($Indx=0;$Indx <= 12;$Indx++){
                if ($Indx==$UraSelect){
                    echo "<option selected='selected'>".$Indx."</option>";
                }else{
                    echo "<option>".$Indx."</option>";
                }
            }
            echo "</select></td>";
            echo "<td><select name='prostor'>";
            for ($Indx=0;$Indx <= $StProstorov;$Indx++){
                if ($VProstor[$Indx][0]==$ProstorSelect){
                    echo "<option value=" . $VProstor[$Indx][0] . " selected='selected'>" . $VProstor[$Indx][1]." - ".$VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
                }else{
                    echo "<option value=" . $VProstor[$Indx][0] . ">" . $VProstor[$Indx][1]." - ". $VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
                }
            }
            echo "</select></td>";
            echo "</tr></table>";
            echo "<input name='submit' type='submit' value='Pošlji'>";

            echo "<br /><hr><br />";
}

switch ($Vid){
    case "3":  //ne izpiše, v načinu popravljanja
    case "4":
        break;
    default:
        $SQL = "SELECT od,do FROM taburnik ORDER BY id DESC LIMIT 0,1";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $odSelect=$R["od"];
            $doSelect=$R["do"];
        }else{
            $Datum=new DateTime($VLeto."-09-01");
            $odSelect=intval($Datum->format('Ymd'));
            $Datum=new DateTime(($VLeto+1)."-06-25");
            $doSelect=intval($Datum->format('Ymd'));
        }
        
        if (isset($_SESSION["UciteljSelect"])){
            $UciteljSelect=$_SESSION["UciteljSelect"];
        }
        if (isset($_SESSION["PredmetSelect"])){
            $PredmetSelect=$_SESSION["PredmetSelect"];
        }
        if (isset($_SESSION["IzvedbaSelect"])){
            $IzvedbaSelect=$_SESSION["IzvedbaSelect"];
        }
        if (isset($_SESSION["RazredSelect"])){
            $RazredSelect=$_SESSION["RazredSelect"];
        }
        if (isset($_SESSION["ParalelkaSelect"])){
            $ParalelkaSelect=$_SESSION["ParalelkaSelect"];
        }
        if (isset($_SESSION["DevetletkaSelect"])){
            $DevetletkaSelect=$_SESSION["DevetletkaSelect"];
        }
        if (isset($_SESSION["DanSelect"])){
            $DanSelect=$_SESSION["DanSelect"];
        }
        if (isset($_SESSION["UraSelect"])){
            $UraSelect=$_SESSION["UraSelect"];
        }
        if (isset($_SESSION["ProstorSelect"])){
            $ProstorSelect=$_SESSION["ProstorSelect"];
        }
        if (isset($_SESSION["doSelect"])){
            $doSelect=$_SESSION["doSelect"];
        }
        if (isset($_SESSION["odSelect"])){
            $odSelect=$_SESSION["odSelect"];
        }

        //'Izpis osebnih podatkov
        $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
        //'echo "<br />" & $SQL & "<br />"
        $result = mysqli_query($link,$SQL);
        $Indx1=0;
        while ($R = mysqli_fetch_array($result)){
            $VUcitelji[$Indx1][0] = $R["iducitelj"];
            $VUcitelji[$Indx1][1] = $R["priimek"];
            $VUcitelji[$Indx1][2] = $R["ime"];
            $Indx1=$Indx1+1;
        }
        $StUciteljev=$Indx1-1;

        $SQL = "SELECT id,oznaka,opis,prioriteta FROM tabpredmeti  ORDER BY Opis";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            $VPredmeti[$Indx][0] = $R["id"];
            $VPredmeti[$Indx][1] = $R["oznaka"];
            $VPredmeti[$Indx][2] = $R["opis"];
            $VPredmeti[$Indx][3] = $R["prioriteta"];
            $Indx=$Indx+1;
        }
        $StPredmetov=$Indx-1;
        
        $SQL = "SELECT idprostor,stevilka,oznaka,opis FROM tabprostor  ORDER BY IdProstor";
        $result = mysqli_query($link,$SQL);
        
        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            //$IdProstor=intval($R["IdProstor"]);
            $VProstor[$Indx][0] = $R["idprostor"];
            $VProstor[$Indx][1] = $R["stevilka"];
            $VProstor[$Indx][2] = $R["oznaka"];
            $VProstor[$Indx][3] = $R["opis"];
            $Indx=$Indx+1;
        }
        $StProstorov=$Indx-1;
        
	    $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabsola.solakratko FROM tabrazdat ";
        $SQL .= "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
        $SQL .= "WHERE leto=".$VLeto;
        $SQL .=" ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka";
	    $result = mysqli_query($link,$SQL);
	    $Indx=0;
	    while ($R = mysqli_fetch_array($result)){
		    $VRazredi[$Indx][0]=$R["id"];
		    $VRazredi[$Indx][1]=$R["razred"];
		    $VRazredi[$Indx][2]=$R["oznaka"];
            $VRazredi[$Indx][3]=$R["solakratko"];
		    $Indx=$Indx+1;
	    }
	    $VStRazredov=$Indx-1;
	    
	    echo "<a name=top></a>";
	    echo "<h2>Vpis urnika - ".$VLeto."/".($VLeto+1)."</h2>";
	    echo "<form accept-charset='utf-8'  name='Urnik' method='post' action='VnosUrnika.php'>";
        echo "<input name='id' type='hidden' value='1'>";
	    echo "<table border='1'>";
	    echo "<th>Leto</th><th>Velja od</th><th>Velja do</th>";
	    echo "<tr>";
	    echo "<td><select name='leto'><option value=".($VLeto-1).">".($VLeto-1)."/".$VLeto."</option><option selected='selected' value=".$VLeto.">".$VLeto."/".($VLeto+1)."</option><option value=".($VLeto+1).">".($VLeto+1)."/".($VLeto+2)."</option></select></td>";
        $Datum=new DateTime(substr($odSelect,0,4)."-".substr($odSelect,4,2)."-".substr($odSelect,6,2));
        echo "<td><input name='od' type='text' size='8' id='dat01' value='".$Datum->format('d.m.Y')."'></td>";
        $Datum=new DateTime(substr($doSelect,0,4)."-".substr($doSelect,4,2)."-".substr($doSelect,6,2));
        echo "<td><input name='do' type='text' size='8' id='dat02' value='".$Datum->format('d.m.Y')."'></td>";
        echo "</tr></table><br />";
        echo "<table border='1'>";
        echo "<th>Učitelj</th><th>Predmet</th><th>Izvedba</th>";
        echo "<tr>";
	    echo "<td><select name='ucitelj'>";
	    for ($Indx2=0;$Indx2 <= $StUciteljev+1;$Indx2++){
		    if ($VUcitelji[$Indx2][0]==$UciteljSelect){
			    echo "<option value=" . $VUcitelji[$Indx2][0] . " selected='selected'>" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
		    }else{
			    echo "<option value=" . $VUcitelji[$Indx2][0] . ">" . $VUcitelji[$Indx2][1] . " " . $VUcitelji[$Indx2][2] . "</option>";
		    }
	    }
	    echo "</select></td>";
	    echo "<td><select name='predmet'>";
	    for ($Indx1=0;$Indx1 <= $StPredmetov;$Indx1++){
		    if ($VPredmeti[$Indx1][0]==$PredmetSelect){
			    echo "<option value=" . $VPredmeti[$Indx1][0] . " selected='selected'>" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
		    }else{
			    echo "<option value=" . $VPredmeti[$Indx1][0] . ">" . $VPredmeti[$Indx1][2] . "  (" . $VPredmeti[$Indx1][1] . ")</option>";
		    }
	    }
	    echo "</select></td>";
	    echo "<td><select name='nivo'>";
        if ($IzvedbaSelect==0){
			echo "<option value=0 selected='selected'>Samostojen predmet</option>";
        }else{
            echo "<option value=0>Samostojen predmet</option>";
        }
        if ($IzvedbaSelect==1){
			echo "<option value=1 selected='selected'>1. skupina</option>";
        }else{
            echo "<option value=1>1. skupina</option>";
        }
        if ($IzvedbaSelect==2){
			echo "<option value=2 selected='selected'>2. skupina</option>";
        }else{
            echo "<option value=2>2. skupina</option>";
        }
        if ($IzvedbaSelect==3){
			echo "<option value=3 selected='selected'>3. skupina</option>";
        }else{
            echo "<option value=3>3. skupina</option>";
        }
        if ($IzvedbaSelect==4){
			echo "<option value=4 selected='selected'>Izbirni</option>";
        }else{
            echo "<option value=4>Izbirni</option>";
        }
        if ($IzvedbaSelect==5){
			echo "<option value=5 selected='selected'>Podaljšano bivanje</option>";
        }else{
            echo "<option value=5>Podaljšano bivanje</option>";
        }
        if ($IzvedbaSelect==6){
			echo "<option value=6 selected='selected'>Druge dejavnosti</option>";
        }else{
            echo "<option value=6>Druge dejavnosti</option>";
        }
        if ($IzvedbaSelect==7){
			echo "<option value=7 selected='selected'>4. skupina</option>";
        }else{
            echo "<option value=7>4. skupina</option>";
        }
        if ($IzvedbaSelect==8){
			echo "<option value=8 selected='selected'>5. skupina</option>";
        }else{
            echo "<option value=8>5. skupina</option>";
        }
        if ($IzvedbaSelect==9){
			echo "<option value=9 selected='selected'>6. skupina</option>";
        }else{
            echo "<option value=9>6. skupina</option>";
        }
	    echo "</select></td>";
	    
	    echo "</tr></table><br />";
	    echo "<table border=1>";
	    echo "<th>Razred</th>";
	    echo "<tr>";
	    
	    echo "<td><select name='razred'>";
	    for ($Indx1=0;$Indx1 <= $VStRazredov;$Indx1++){
            if ($VecSol > 0){
		        if ($VRazredi[$Indx1][0]==$RazredSelect){
			        echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
		        }else{
			        echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]." - ".$VRazredi[$Indx1][3]."</option>";
		        }
            }else{
                if ($VRazredi[$Indx1][0]==$RazredSelect){
                    echo "<option value='".$VRazredi[$Indx1][0]."' selected='selected'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                }else{
                    echo "<option value='".$VRazredi[$Indx1][0]."'>".$VRazredi[$Indx1][1].". ".$VRazredi[$Indx1][2]."</option>";
                }
            }
	    }
	    for ($Indx1=0;$Indx1 <= 9;$Indx1++){
		    if ($Indx1==$RazredSelect){
			    echo "<option value='".(-$Indx1)."' selected='selected'>".$Indx1.".</option>";
		    }else{
			    echo "<option value='".(-$Indx1)."'>".$Indx1.".</option>";
		    }
	    }
	    echo "</select>";
	    echo "<input name='vrstaos' type='hidden' value='9'></td>";
	    
	    echo "</tr></table><br />";
	    echo "<table border=1>";
	    echo "<th>Dan</th><th>Ura</th><th>Prostor</th>";
	    echo "</tr>";
	    
	    echo "<td><select name='danvtednu'>";
	    for ($Indx1=1;$Indx1 <= 5;$Indx1++){
		    if ($Indx1==$DanSelect){
			    echo "<option value='".$Indx1."' selected='selected'>".Int2Dan($Indx1)."</option>";
		    }else{
			    echo "<option value='".$Indx1."'>".Int2Dan($Indx1)."</option>";
		    }
	    }
	    echo"</select></td>";
	    echo "<td><select name='ura'>";
	    for ($Indx=0;$Indx <= 12;$Indx++){
		    if ($Indx==$UraSelect){
			    echo "<option selected='selected'>".$Indx."</option>";
		    }else{
			    echo "<option>".$Indx."</option>";
		    }
	    }
	    echo "</select></td>";
	    echo "<td><select name='prostor'>";
	    for ($Indx=0;$Indx <= $StProstorov;$Indx++){
		    if ($VProstor[$Indx][0]==$ProstorSelect){
			    echo "<option value=" . $VProstor[$Indx][0] . " selected='selected'>" . $VProstor[$Indx][1]." - ".$VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
		    }else{
			    echo "<option value=" . $VProstor[$Indx][0] . ">" . $VProstor[$Indx][1]." - ". $VProstor[$Indx][2] . "  (" . $VProstor[$Indx][3] . ")</option>";
		    }
	    }
	    echo "</select></td>";
	    echo "</tr></table>";
	    echo "<input name='submit' type='submit' value='Pošlji'>";

	    echo "<br /><hr><br />";

        for ($Indx2=0;$Indx2 <= $StUciteljev+1;$Indx2++){
	        $Obremenitev[$Indx2]=0;
	        for ($Indx=0;$Indx <= 5;$Indx++){
		        for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			        $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
		        }
	        }
        }

        $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,tabrazdat.idsola,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,taburnik.id AS uid,tabpredmeti.oznaka AS poznaka FROM (((taburnik "; 
        $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) ";
        $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
        $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor) ";
        //$SQL .= "INNER JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
        $SQL .= "LEFT JOIN tabrazdat ON taburnik.idrazred=tabrazdat.id ";
        $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od='".$odSelect."' ORDER BY tabucitelji.Priimek,tabucitelji.Ime,taburnik.DanVTednu,taburnik.Ura";
        $result = mysqli_query($link,$SQL);

        //inicializacija urnika učitelja - vse prazno
        for ($Indx2=0;$Indx2 <= $StUciteljev+1;$Indx2++){
	        $Obremenitev[$Indx2]=0;
	        for ($Indx=0;$Indx <= 5;$Indx++){
		        for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			        $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
		        }
	        }
        }

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
	        $IzbraniUcitelj=$StUciteljev+1;
	        for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
		        if ($R["iducitelj"]==$VUcitelji[$Indx2][0]){
			        $IzbraniUcitelj=$Indx2;
		        }
	        }
	        switch ($R["nivo"]){
		        case 1:
                case 2:
                case 3:
                    if ($VecSol > 0){
			            $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></a></td></tr>";
                    }else{
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></a></td></tr>";
                    }
                    break;
		        case 7:
                case 8:
                case 9:
                    if ($VecSol > 0){
			            $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></a></td></tr>";
                    }else{
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"].($R["nivo"]-3)."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></a></td></tr>";
                    }
                    break;
                case 4:
                    if ($VecSol > 0){
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></a></td></tr>";
                    }else{
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></a></td></tr>";
                    }
                    break;
		        default:
                    if ($VecSol > 0){
			            $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"].$R["idsola"]."</font></a></td></tr>";
                    }else{
                        $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr><td><a href='VnosUrnika.php?id=2&zapis=".$R["uid"]."&ucitelj=".$R["iducitelj"]."'><font color='darkblue'>".$R["poznaka"]."</font></a></td><td><font color='red'>".$R["stevilka"]."</font></td><td><a href='VnosUrnika.php?id=3&zapis=".$R["uid"]."'><font color='magenta'>".$R["razred"].$R["paralelka"]."</font></a></td></tr>";
                    }
	        }
	        $Indx=$Indx+1;
        }

        for ($Indx2=0;$Indx2 <= $StUciteljev+1;$Indx2++){
	        for ($Indx=0;$Indx <= 5;$Indx++){
		        for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			        if ($UrnikUcitelj[$Indx2][$Indx][$Indx0] != ""){
				        $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
			        }
		        }
	        }
        }

        echo "<p>";
        echo "Klik na povezavo na uri pri učitelju gre na vnos za tistega učitelja za izbrano uro.<br />";
        echo "Klik na oznako predmeta pobriše ta zapis v urniku.<br />";
        echo "Klik na oznako razreda gre v popravljanje tega zapisa.<br />";
        echo "</p>";

        echo "<br /><h2>Urnik po učiteljih (".$VLeto."/".($VLeto+1)."):</h2>";
        echo "<table border=1 cellspacing='0' bgcolor='lightyellow'>";
        $ColorChange=true;
        for ($Indx=0;$Indx <= $StUciteljev;$Indx++){
	        if ($Obremenitev[$Indx] > 0){
		        echo "<tr bgcolor='cyan'><td><a name=".$VUcitelji[$Indx][0]."></a><b>".$VUcitelji[$Indx][1].", ".$VUcitelji[$Indx][2]."</b></td>";
		        echo "<td>".$Obremenitev[$Indx]."</td>";
		        for ($Indx2=1;$Indx2 <= 5;$Indx2++){
			        echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
		        }
		        echo "</tr>";
		        for ($Indx2=0;$Indx2 <= 12;$Indx2++){
			        if ($ColorChange){
				        echo "<tr bgcolor='lightyellow'>";
			        }else{
				        echo "<tr bgcolor='#FFFFCC'>";
			        }
			        echo "<td></td><td><a href='VnosUrnika.php?id=4&ucitelj=".$VUcitelji[$Indx][0]."&dan=1&ura=".$Indx2."'>".$Indx2."</a></td>";
			        for ($Indx1=1;$Indx1 <= 5;$Indx1++){
				        if ($UrnikUcitelj[$Indx][$Indx1][$Indx2] != ""){
					        echo "<td valign='top'>";
					        echo "<table>";
					        echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
					        echo "</table>";
					        echo "</td>";
				        }else{
					        echo "<td>&nbsp;</td>";
				        }
			        }
			        echo "</tr>";
		        }
		        $ColorChange=!$ColorChange;
	        }
        }

        echo "</table>";
}

echo "<a href='Urnik.php'>Urnik - razne variante</a><br />";
//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
?>

</body>
</html>
