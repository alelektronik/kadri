<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prisotnost
</title>
</head>
<body>

<?php
$Danes=new DateTime("now");
$VLeto=$Danes->format('Y');
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid = 0;
    }
}

echo "<form accept-charset='utf-8' name='rezultati' method='post' action='PrihodDelavcev.php'>";
echo "<h2>Vpis prihoda/odhoda</h2><br>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>";
echo "        Delavec:<select name='delavec'>";
echo "        <option value='0'>Ni izbrano</option>";

$SQL = "SELECT kadrovi.priimime,kadrovi.emso FROM kadrovi INNER JOIN tabucitelji ON kadrovi.emso=tabucitelji.iducitelj WHERE tabucitelji.status > 0 ORDER BY priimime";
$result = mysqli_query($link,$SQL);

while ($R = mysqli_fetch_array($result)){
    if (strlen($R["priimime"]) > 0) {
        echo "<option value=".$R["emso"].">".$R["priimime"]."</option>";
    }
}

echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "</table>";
echo "<table border=0>";
echo "<tr>";
echo "    <td>Datum:</td>";
echo "    <td>";
echo "        Dan:<select name='dan'>";
echo "<option selected>" . $Danes->format('j') . "</option>";
for ($Indx=1;$Indx <= 31;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Mesec:<select name='mesec'>";
echo "<option selected>" . $Danes->format('n') . "</option>";
for ($Indx=1;$Indx <= 12;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Leto: <select name='leto'>";
echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "</option>";
echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "</option>";
echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "</option>";
echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "<tr>";
echo "    <td>Čas:</td>";
echo "    <td>";
echo "        Ura:<select name='ura'>";
echo "<option selected>" . $Danes->format('H') . "</option>";
for ($Indx=0;$Indx <= 23;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Minuta:<select name='minuta'>";
echo "<option selected>" . $Danes->format('i') . "</option>";
for ($Indx=0;$Indx <= 59;$Indx++){
    echo "<option>".$Indx."</option>";
}
echo "        </select>";
echo "    </td>";
echo "    <td>";
echo "        Tip: <select name='tip'>";
echo "<option value='1001' selected>Prihod</option>";
echo "<option value='3001'>Odhod z dela</option>";
echo "        </select>";
echo "    </td>";
echo "</tr>";
echo "</table>";

echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>";

$SQL = "SELECT kadrovi.priimime,tabprihodi.id,tabprihodi.danpr,tabprihodi.mesecpr,tabprihodi.letopr,tabprihodi.uraprih,tabprihodi.minprih,tabprihodi.vrstaprih,tabprihodi.danodh,tabprihodi.mesecodh,tabprihodi.letodh,tabprihodi.uraodh,tabprihodi.minodh FROM tabprihodi ";
$SQL = $SQL . "INNER JOIN kadrovi ON tabprihodi.sifra=kadrovi.stdelavca WHERE tabprihodi.letopr >='".($Danes->format('Y')-1)."' OR tabprihodi.letodh >='".($Danes->format('Y')-1)."' ORDER BY tabprihodi.id DESC";
$result = mysqli_query($link,$SQL);

echo "<table border=1>";
echo "<tr>";
echo "<th>Ime</th>";
echo "<th>Datum</th>";
echo "<th>Čas</th>";
echo "<th>Prihod</th>";
echo "<th>Odhod</th>";
echo "<th>Briši</th>";
echo "</tr>";

while ($R = mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>".$R["priimime"]."</td>";
    if ($R["letopr"] > 0 ){
        echo "<td align='right'>".$R["danpr"].".".$R["mesecpr"].".".$R["letopr"]."</td>";
        echo "<td align='right'>".$R["uraprih"].":".LeadZero($R["minprih"])."</td>";
        echo "<td>".$R["vrstaprih"]."</td><td>&nbsp;</td>";
    }else{
        echo "<td align='right'>".$R["danodh"].".".$R["mesecodh"].".".$R["letodh"]."</td>";
        echo "<td align='right'>".$R["uraodh"].":".LeadZero($R["minodh"])."</td>";
        echo "<td>&nbsp;</td><td>".$R["vrstaprih"]."</td>";
    }
    echo "<td><a href='brisiPrihodDel.php?id=".$R["id"]."'>Briši</a></td>";
    echo "</tr>";
}
echo "</table>";
?>

</body>
</html>
