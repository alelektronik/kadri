<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pedagoško poročilo
</title>
</head>
<body>

<?php
function ToOPB($x){
    switch ($x){
        case 52:
            return "OPB";
        case 78:
            return "PB01";
        case 79:
            return "PB02";
        case 80:
            return "PB03";
        case 81:
            return "PB04";
        case 82:
            return "PB05";
        case 83:
            return "PB06";
        case 84:
            return "PB07";
        case 85:
            return "PB08";
        case 86:
            return "PB09";
        case 87:
            return "PB10";
        case 88:
            return "PB11";
        case 89:
            return "PB12";
        case 90:
            return "PB13";
        case 91:
            return "PB14";
        default:
            return "---";
    }
}

$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}
if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $VIdUporabnik=$R["IdUcitelj"];
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = $UciteljComp;
        }
    }
}

if (!CheckDostop("PreglPoroc",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$VFile="PorocilaRazrednikov.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    $txt=str_replace(chr(226).chr(128).chr(147),"\\'2d",$txt);
    return $txt;
}

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VRavnatelj=$R["Ravnatelj"];
    $VKraj=$R["Kraj"];
    $VNaslov=$R["Naslov"];
    $VPosta=$R["Posta"]." ".$VKraj;
}else{
    $VSola=" ";
    $VRavnatelj=" ";
    $VKraj=" ";
    $VNaslov=" ";
    $VPosta=" ";
}

$SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." AND razred > 0 ORDER BY idsola,razred,oznaka";
$result = mysqli_query($link,$SQL);

$Indx=0;
while ($R = mysqli_fetch_array($result)){
    $Razredi[$Indx][0] = $R["razred"];
    $Razredi[$Indx][1] = $R["oznaka"];
    $Razredi[$Indx][2] = $R["id"];
    $Razredi[$Indx][3] = $R["idsola"];
    $Indx=$Indx+1;
}
$StRazredov=$Indx;

$_SESSION["leto"] = $VLeto;

$UcneUreVse[0]=0;
$UcneUreVse[1]=0;
$UcneUreVse[2]=0;
$UcneUreVse[3]=0;

fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1\\deff1\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\f1\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604020202020204}Arial;}{\\f35\\fswiss\\fcharset0\\fprq2{\\*\\panose 020b0a04020102020204}Arial Black;}{\\f453\\froman\\fcharset0\\fprq2 Times New Roman;}{\\f452\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}"."\n");
fwrite ($fh,"{\\f454\\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f455\\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f456\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f457\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}"."\n");
fwrite ($fh,"{\\f458\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f459\\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f463\\fswiss\\fcharset0\\fprq2 Arial;}{\\f462\\fswiss\\fcharset204\\fprq2 Arial Cyr;}{\\f464\\fswiss\\fcharset161\\fprq2 Arial Greek;}"."\n");
fwrite ($fh,"{\\f465\\fswiss\\fcharset162\\fprq2 Arial Tur;}{\\f466\\fswiss\\fcharset177\\fprq2 Arial (Hebrew);}{\\f467\\fswiss\\fcharset178\\fprq2 Arial (Arabic);}{\\f468\\fswiss\\fcharset186\\fprq2 Arial Baltic;}{\\f469\\fswiss\\fcharset163\\fprq2 Arial (Vietnamese);}}"."\n");
fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;"."\n");
fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red137\\green119\\blue186;}{\\stylesheet{\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{\\s1\\qj \\li0\\ri0\\sb240\\sa120\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\b\\shad\\f35\\fs36\\lang1033\\langfe1033\\kerning28\\cgrid\\langnp1033\\langfenp1033 \\sbasedon0 \\snext0 \\styrsid14375190 heading 1;}{\\s2\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar"."\n");
fwrite ($fh,"\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 \\sautoupd \\styrsid4161200 heading 2;}{\\s3\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\aspalpha\\aspnum\\faauto\\outlinelevel2\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\b\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon0 \\snext0 heading 3;}{\\*\\cs10 \\additive \\ssemihidden Default Paragraph Font;}{\\*"."\n");
fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\snext11 \\ssemihidden Normal Table;}{\\s15\\qc \\li0\\ri0\\sb60\\sa60\\sl-140\\slmult0"."\n");
fwrite ($fh,"\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\b\\f1\\fs14\\lang1024\\langfe1024\\cgrid\\noproof\\langnp1060\\langfenp1060 \\sbasedon0 \\snext15 Mesto;}{\\*\\cs16 \\additive \\b\\i\\f1\\fs24\\lang1060\\langfe1033\\langnp1060\\langfenp1033 \\sbasedon10 "."\n");
fwrite ($fh,"Naslov 2 Znak Znak Znak Znak Znak;}{\\s17\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\shad\\f35\\fs28\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext17 \\styrsid2692378 Slog Arial Black 24 pt Sen\\'e8eno Na sredini Polje: (Enojen Samo...;}{\\s18\\qc \\li0\\ri0\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\f35\\fs48\\lang2057\\langfe1033\\cgrid\\langnp2057\\langfenp1033 \\sbasedon0 \\snext18 \\styrsid14375190 "."\n");
fwrite ($fh,"Slog Arial Black 24 pt modra Sen\\'e8eno Na sredini Polje: (Enoje...;}{\\s19\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 "."\n");
fwrite ($fh,"\\aspalpha\\aspnum\\faauto\\outlinelevel1\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\i\\shad\\f1\\fs28\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon2 \\snext19 \\styrsid14375190 Slog Naslov 2 + rde\\'e8a;}{"."\n");
fwrite ($fh,"\\s20\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 "."\n");
fwrite ($fh,"\\b\\shad\\f35\\fs28\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 \\sbasedon1 \\snext20 \\sautoupd \\styrsid2692378 Slog1;}{\\s21\\ql \\li0\\ri0\\sb240\\sa60\\keepn\\widctlpar\\brdrt\\brdrs\\brdrw10\\brsp20 \\brdrl\\brdrs\\brdrw10\\brsp80 \\brdrb"."\n");
fwrite ($fh,"\\brdrs\\brdrw10\\brsp20 \\brdrr\\brdrs\\brdrw10\\brsp80 \\aspalpha\\aspnum\\faauto\\outlinelevel0\\adjustright\\rin0\\lin0\\rtlgutter\\itap0 \\cbpat17 \\shad\\caps\\f1\\fs24\\lang1060\\langfe1033\\kerning28\\cgrid\\langnp1060\\langfenp1033 "."\n");
fwrite ($fh,"\\sbasedon1 \\snext21 \\sautoupd \\styrsid2692378 Slog Naslov 1,Naslov 1 Znak Znak Znak Znak + Arial 12 pt Ne Krep...;}{\\s22\\ql \\li0\\ri0\\sb100\\sa100\\sbauto1\\saauto1\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
fwrite ($fh,"\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\sbasedon0 \\snext22 \\styrsid5715400 Normal (Web);}{\\*\\ts23\\tsrowd\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\sbasedon11 \\snext23 \\styrsid5715400 Table Grid;}}{\\*\\latentstyles\\lsdstimax156\\lsdlockeddef0}{\\*\\listtable"."\n");
fwrite ($fh,"{\\list\\listtemplateid-1051832236{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow1\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 }{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2"."\n");
fwrite ($fh,"\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s2}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s3}{\\listlevel"."\n");
fwrite ($fh,"\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0"."\n");
fwrite ($fh,"{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0"."\n");
fwrite ($fh,"\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}"."\n");
fwrite ($fh,"{\\listlevel\\levelnfc255\\levelnfcn255\\leveljc0\\leveljcn0\\levelfollow2\\levelstartat1\\levelspace0\\levelindent0{\\leveltext\\'00;}{\\levelnumbers;}\\fbias0 \\s0}{\\listname ;}\\listid327027276}}{\\*\\listoverridetable{\\listoverride\\listid327027276"."\n");
fwrite ($fh,"\\listoverridecount0\\ls1}}{\\*\\pgptbl {\\pgp\\ipgp0\\itap0\\li0\\ri0\\sb0\\sa0}}{\\*\\rsidtbl \\rsid882357\\rsid2692378\\rsid4161200\\rsid5715400\\rsid6759903\\rsid10756800\\rsid14375190\\rsid15216063\\rsid15866154}{\\*\\generator Microsoft Word 11.0.5604;}{\\info"."\n");
fwrite ($fh,"{\\title }{\\creatim\\yr2009\\mo2\\dy27\\hr7\\min33}{\\revtim\\yr2009\\mo2\\dy27\\hr7\\min52}{\\version2}"."\n");
fwrite ($fh,"{\\vern24689}}\\margl567\\margr567\\margt567\\margb567 \\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\hyphcaps0\\formshade\\horzdoc\\dgmargin\\dghspace187\\dgvspace127\\dghorigin1701\\dgvorigin1984"."\n");
fwrite ($fh,"\\dghshow0\\dgvshow2\\jexpand\\viewkind4\\viewscale150\\pgbrdrhead\\pgbrdrfoot\\bdrrlswsix\\nolnhtadjtbl\\nojkernpunct\\rsidroot5715400 \\fet0\\sectd \\linex0\\headery709\\footery709\\colsx708\\sectlinegrid254\\sectdefaultcl\\sftnbj {\\*\\pnseclvl1"."\n");
fwrite ($fh,"\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5"."\n");
fwrite ($fh,"\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang "."\n");
fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}\\pard\\plain "."\n");

$YDif=6;
$Stran=0;
for ($IndxRazred=0;$IndxRazred < $StRazredov;$IndxRazred++){
    $VRazred=$Razredi[$IndxRazred][0];
    $VParalelka=$Razredi[$IndxRazred][1];
    $IdRazred=$Razredi[$IndxRazred][2];
    $IdSola=$Razredi[$IndxRazred][3];
    
    $SQL = "SELECT TabRazred.*, tabucitelji.Priimek AS ucpriimek, tabucitelji.Ime AS ucime, TabVzgojitelji.Priimek AS vpriimek, TabVzgojitelji.Ime AS vime, TabUcenci.* FROM ";
    $SQL = $SQL . "(TabVzgojitelji INNER JOIN (TabRazred INNER JOIN tabucitelji ON TabRazred.IdUcitelj=tabucitelji.IdUcitelj) ON TabVzgojitelji.IdUcitelj=TabRazred.IdVzgojitelj) ";
    $SQL = $SQL . "INNER JOIN TabUcenci ON TabRazred.IdUcenec=TabUcenci.IdUcenec ";
    $SQL = $SQL . "WHERE IdRazred=" . $IdRazred ." ORDER BY TabUcenci.Priimek, TabUcenci.Ime";
    $result = mysqli_query($link,$SQL);

    fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 "."\n");
    fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
    fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("Celoletno pedagoško poročilo ")."}{\\insrsid10756800 \\par }"."\n");
    if ($VecSol > 0){
        $SQL1="SELECT solakratko FROM tabsola WHERE id=".$IdSola;
        $result1 = mysqli_query($link,$SQL1);
        if ($R1 = mysqli_fetch_array($result1)){
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Šolsko leto ")."}{\\b\\insrsid5715400\\charrsid5715400 ".$VLeto."/".($VLeto+1)."}{\\insrsid5715400\\charrsid5715400 , Razred: }{\\b\\insrsid5715400\\charrsid5715400 ".$VRazred.". ".ToRTF(strtolower($VParalelka)." - ".$R1["solakratko"])."}{\\insrsid10756800 \\par }"."\n");
        }else{
            fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Šolsko leto ")."}{\\b\\insrsid5715400\\charrsid5715400 ".$VLeto."/".($VLeto+1)."}{\\insrsid5715400\\charrsid5715400 , Razred: }{\\b\\insrsid5715400\\charrsid5715400 ".$VRazred.". ".ToRTF(strtolower($VParalelka))."}{\\insrsid10756800 \\par }"."\n");
        }
    }else{
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Šolsko leto ")."}{\\b\\insrsid5715400\\charrsid5715400 ".$VLeto."/".($VLeto+1)."}{\\insrsid5715400\\charrsid5715400 , Razred: }{\\b\\insrsid5715400\\charrsid5715400 ".$VRazred.". ".ToRTF(strtolower($VParalelka))."}{\\insrsid10756800 \\par }"."\n");
    }

    if ($R = mysqli_fetch_array($result)){
        $Ucitelj = $R["ucpriimek"]  . " " . $R["ucime"];
        $IdUcitelj=$R["IdUcitelj"];
        $Vzgojitelj = $R["vpriimek"]  . " " . $R["vime"];
        $IdVzgojitelj=$R["IdVzgojitelj"];

        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Razrednik/-čarka:")." }{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF($Ucitelj)."}{\\insrsid10756800 \\par }"."\n");
        switch ($VRazred){
            case 1:
                fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Drugi/-a učitelj/-ica:")." }{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF($Vzgojitelj)."}{\\insrsid10756800 \\par \\par }"."\n");
                break;
            case 2:
            case 3:
            case 4:
            case 5:
                fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Učitelj/-ica PB:")." }{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF($Vzgojitelj)."}{\\insrsid10756800 \\par \\par }"."\n");
                break;
            default:
                fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
        }
    }

    $Indx=0;
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        $ucenci[$Indx][0]=$R["IdUcenec"];
        $ucenci[$Indx][1]=$R["Priimek"]." ".$R["Ime"];
        $ucenci[$Indx][2]=$VRazred.$VParalelka;
        $ucenci[$Indx][3]=$R["DatRoj"];
        $Indx=$Indx+1;
    }
    $StUcencev=$Indx;

    //Realizacija ur
    $SQL = "SELECT TabRealizacija.*,tabpredmeti.* FROM ";
    $SQL = $SQL . "(TabRealizacija INNER JOIN tabpredmeti ON TabRealizacija.Predmet=tabpredmeti.Id) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON TabRealizacija.IdRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE IdRazred=".$IdRazred;
    $SQL = $SQL ." ORDER BY VrstniRed";
    $result = mysqli_query($link,$SQL);

    $UcneUre[0]=0;
    $UcneUre[1]=0;
    $UcneUre[2]=0;
    $UcneUre[3]=0;

    for ($Indx=0;$Indx <= 100;$Indx++){
        $UcneUrePredmeti[$Indx][0]=0;
        $UcneUrePredmeti[$Indx][1]=0;
        $UcneUrePredmeti[$Indx][2]=0;
        $UcneUrePredmeti[$Indx][3]=0;
        $UcneUrePredmeti[$Indx][4]=0;
        $UcneUrePredmeti[$Indx][5]=0;
        $Predmeti[$Indx][0]=0;
        $Predmeti[$Indx][1]=0;
    }

    $Indx=0;
    
    while ($R = mysqli_fetch_array($result)){
        $UcneUre[0]=$UcneUre[0]+$R["PlanPol"];
        $UcneUre[1]=$UcneUre[1]+$R["RealizacijaPol"];
        $UcneUre[2]=$UcneUre[2]+$R["Plan"];
        $UcneUre[3]=$UcneUre[3]+$R["Realizacija"];
        $UcneUrePredmeti[$Indx][0]=$R["Predmet"];
        $UcneUrePredmeti[$Indx][1]=$R["Oznaka"];
        $UcneUrePredmeti[$Indx][2]=$R["PlanPol"];
        $UcneUrePredmeti[$Indx][3]=$R["RealizacijaPol"];
        $UcneUrePredmeti[$Indx][4]=$R["Plan"];
        $UcneUrePredmeti[$Indx][5]=$R["Realizacija"];
        $Indx=$Indx+1;
    }
    $StPredmetovUcneUre=$Indx;

    $UcneUreVse[0]=$UcneUreVse[0]+$UcneUre[0];
    $UcneUreVse[1]=$UcneUreVse[1]+$UcneUre[1];
    $UcneUreVse[2]=$UcneUreVse[2]+$UcneUre[2];
    $UcneUreVse[3]=$UcneUreVse[3]+$UcneUre[3];

    if ($UcneUre[2] > 0){
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF("Realizacija u\\'e8nih ur: ")."}{\\b\\insrsid5715400\\charrsid5715400 ".number_format($UcneUre[3]/$UcneUre[2]*100,2)." %}{\\insrsid10756800 \\par }"."\n");
    }

    //'skupna statistika razreda po spolu - zacetek

    $SQL = "SELECT TabUcenci.* FROM ";
    $SQL = $SQL . "(TabUcenci INNER JOIN TabRazred ON TabUcenci.IdUcenec=TabRazred.IdUcenec) ";
    $SQL = $SQL . "INNER JOIN tabrazdat ON TabRazred.IdRazred=tabrazdat.id ";
    $SQL = $SQL . "WHERE IdRazred=".$IdRazred;
    $SQL = $SQL ." ORDER BY tabrazdat.Razred,oznaka,Priimek,Ime";
    $result = mysqli_query($link,$SQL);
    
    $StUcencevM=0;
    $StUcencevW=0;
    while ($R = mysqli_fetch_array($result)){
        if ($R["Spol"]=="M") {
            $StUcencevM=$StUcencevM+1;
        }else{
            $StUcencevW=$StUcencevW+1;
        }
    }
    
    $SQL = "SELECT TabUcenci.*,TabRazred.*,TabOcene.* FROM (TabUcenci INNER JOIN TabRazred ON TabUcenci.IdUcenec=TabRazred.IdUcenec) INNER JOIN TabOcene ON TabUcenci.IdUcenec=TabOcene.IdUcenec WHERE IdRazred=".$IdRazred." ORDER BY Razred,Paralelka,Priimek,Ime";
    $result = mysqli_query($link,$SQL);

    $StUcencevMNeg=0;
    $StUcencevWNeg=0;
    $StUcencevMNegPol=0;
    $StUcencevWNegPol=0;
    
    if (mysqli_num_rows($result) > 0){
        while ($R = mysqli_fetch_array($result)){
            if (($R["OcenaKoncna"] == "1") or ($R["OcenaKoncna"] == "Ni opravil")){
                if ($R["Spol"]=="M"){
                    $StUcencevMNeg=$StUcencevMNeg+1;
                }else{
                    $StUcencevWNeg=$StUcencevWNeg+1;
                }
            }
            if (($R["OcenaPolletna"] == "1") or ($R["OcenaPolletna"] == "Ni opravil")){
                if ($R["Spol"]=="M"){
                    $StUcencevMNegPol=$StUcencevMNegPol+1;
                }else{
                    $StUcencevWNegPol=$StUcencevWNegPol+1;
                }
            }
        }
    }
    //'skupna statistika razreda po spolu - konec

//    'negativne ocene učencev pri predmetih-zacetek

    $SQL = "SELECT DISTINCT tabpredmeti.Oznaka,tabpredmeti.Prioriteta,tabpredmeti.VrstniRed,";
    $SQL = $SQL . "tabucenje.Predmet,tabucenje.Razred,tabucenje.Paralelka,tabucenje.Leto ";
    $SQL = $SQL . "FROM tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id=tabucenje.Predmet ";
    $SQL = $SQL . "WHERE idRazred=".$IdRazred." AND  Prioriteta< 3 ";
    $SQL = $SQL . "ORDER BY tabpredmeti.VrstniRed";
    $result = mysqli_query($link,$SQL);

    $StPredmetov=0;

    while ($R = mysqli_fetch_array($result)){
        $Predmeti[$StPredmetov][0]=$R["Predmet"];
        $Predmeti[$StPredmetov][1]=$R["Oznaka"];
        $StPredmetov=$StPredmetov+1;
    }


    $IndxUcN=0;
    $IndxUcNP=0;
    $IndxNeoc=0;

    for ($Indx=0;$Indx <= 50;$Indx++){
        $PredmetNegativno[$Indx]=0;
        $PredmetNegativnoPol[$Indx]=0;
    }
    for ($Indx=0;$Indx <= 30;$Indx++){
        $UcenciNegativni[$Indx][0]=0;
        $UcenciNegativni[$Indx][1]=0;
        $UcenciNegativni[$Indx][2]=0;
        $UcenciNegativniPol[$Indx][0]=0;
        $UcenciNegativniPol[$Indx][1]=0;
        $UcenciNegativniPol[$Indx][2]=0;
        $UcenciNezadostni[$Indx]=0;
        $UcenciNezadostniPol[$Indx]=0;
    }

    for ($IndxUc=0;$IndxUc <= ($StUcencev-1);$IndxUc++){
        $UcenciNezadostni[$IndxUc]=0;
        $UcenciNezadostniPol[$IndxUc]=0;
        for ($Indx1= 0;$Indx <= ($StPredmetov-1);$Indx++){
            $Ocene[$Indx1][4]="";
            $Ocene[$Indx1][5]="";
            $Neocenjen[$Indx1]=0;
        }

        $SQL = "SELECT  * FROM TabOcene WHERE IdUcenec=".$ucenci[$IndxUc][0]." AND leto=".$VLeto;
        $result = mysqli_query($link,$SQL);

        $Indx=0;
        while ($R = mysqli_fetch_array($result)){
            for ($Indx1=0;$Indx1 <= ($StPredmetov-1);$Indx1++){
                if ($R["IdPredmet"]==$Predmeti[$Indx1][0]){
                    $Ocene[$Indx1][4]=$R["OcenaKoncna"];
                    $Ocene[$Indx1][5]=$R["OcenaPolletna"];
                    $Neocenjen[$Indx1]=$R["Neocenjen"];
                    if (($Ocene[$Indx1][4]=="1") or ($Ocene[$Indx1][4]=="Ni opravil")){
                        $PredmetNegativno[$Indx1]=$PredmetNegativno[$Indx1]+1;
                        $UcenciNegativni[$IndxUcN][0]=$ucenci[$IndxUc][0];
                        $UcenciNegativni[$IndxUcN][1]=$ucenci[$IndxUc][1];
                        $UcenciNegativni[$IndxUcN][2]=$Predmeti[$Indx1][1];
                        $IndxUcN=$IndxUcN+1;
                        $UcenciNezadostni[$IndxUc]=1;
                    }
                    if (($Ocene[$Indx1][5]=="1") or ($Ocene[$Indx1][5]=="Ni opravil")){
                        $PredmetNegativnoPol[$Indx1]=$PredmetNegativnoPol[$Indx1]+1;
                        $UcenciNegativniPol[$IndxUcNP][0]=$ucenci[$IndxUc][0];
                        $UcenciNegativniPol[$IndxUcNP][1]=$ucenci[$IndxUc][1];
                        $UcenciNegativniPol[$IndxUcNP][2]=$Predmeti[$Indx1][1];
                        $IndxUcNP=$IndxUcNP+1;
                        $UcenciNezadostniPol[$IndxUc]=1;
                    }
                    if ($Neocenjen[$Indx1]==1) {
                        $UcenciNeocenjeni[$IndxNeoc][0]=$ucenci[$IndxUc][0];
                        $UcenciNeocenjeni[$IndxNeoc][1]=$ucenci[$IndxUc][1];
                        $UcenciNeocenjeni[$IndxNeoc][2]=$Predmeti[$Indx1][1];
                        $IndxNeoc=$IndxNeoc+1;
                    }
                    
                }
            }
            $Indx=$Indx+1;
        }
    }

    $Nezadostnih=0;
    $NezadostnihPol=0;
    for ($Indx=0;$Indx <= ($StUcencev-1);$Indx++){
        $Nezadostnih=$Nezadostnih+$UcenciNezadostni[$Indx];
        $NezadostnihPol=$NezadostnihPol+$UcenciNezadostniPol[$Indx];
    }

    //'začetek tabele za uspeh
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Uspeh: }{\\b\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencev-$Nezadostnih)/$StUcencev*100,2)."%}{\\insrsid10756800 \\par \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Celoletni uspeh \\par }"."\n");
    fwrite ($fh,"\\trowd \\irow0\\irowband0\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\pard");

    //'izpis vsebine tabele
    fwrite ($fh,"\\plain \\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\b\\fs16\\insrsid5715400\\charrsid5715400 Razred\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 U\\'e8enci\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 \\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 U\\'e8enke\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 \\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 Skupaj\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\b\\fs16\\insrsid5715400\\charrsid5715400 \\cell }\\pard"."\n");
    
    //'nova vrstica - grafika
    fwrite ($fh,"\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\b\\fs16\\insrsid5715400\\charrsid5715400 \\trowd "."\n");
    fwrite ($fh,"\\irow0\\irowband0\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\row }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 \\~ \\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 \\'8at.\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 %\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 \\'8at.\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 %\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 \\'8at.\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 %\\cell }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 \\trowd "."\n");
    fwrite ($fh,"\\irow1\\irowband1\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\row }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 v razredu\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".$StUcencevM."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format($StUcencevM/$StUcencev*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".$StUcencevW."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format($StUcencevW/($StUcencev)*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevM+$StUcencevW)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevM+$StUcencevW)/$StUcencev*100,2)."%\\cell }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 \\trowd "."\n");
    fwrite ($fh,"\\irow2\\irowband2\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\row }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 pozitivnih\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevM-$StUcencevMNeg)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevM-$StUcencevMNeg)/($StUcencev)*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevW-$StUcencevWNeg)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevW-$StUcencevWNeg)/($StUcencev)*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevM+$StUcencevW-$StUcencevMNeg-$StUcencevWNeg)/$StUcencev*100,2)."%\\cell }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 \\trowd "."\n");
    fwrite ($fh,"\\irow3\\irowband3\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\row }\\pard"."\n");
    
    fwrite ($fh,"\\plain \\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 negativnih\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".$StUcencevMNeg."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevMNeg)/($StUcencev)*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevWNeg)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevWNeg)/($StUcencev)*100,2)."%\\cell }\\pard "."\n");
    fwrite ($fh,"\\qc \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".($StUcencevMNeg+$StUcencevWNeg)."\\cell }\\pard "."\n");
    fwrite ($fh,"\\qr \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid14315515\\yts23 {\\fs16\\insrsid5715400\\charrsid5715400 ".number_format(($StUcencevMNeg+$StUcencevWNeg)/$StUcencev*100,2)."%\\cell }\\pard"."\n");
    
    //'zaključek tabele za uspeh
    fwrite ($fh,"\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 "."\n");
    fwrite ($fh,"\\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\fs16\\insrsid5715400\\charrsid5715400 "."\n");
    fwrite ($fh,"\\trowd \\irow4\\irowband4\\lastrow \\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth947\\clshdrawnil \\cellx839\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth749\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx1588\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx2359\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth808\\clshdrawnil \\cellx3167\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx3938\\clvertalt\\clbrdrt"."\n");
    fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth771\\clshdrawnil \\cellx4709\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth901\\clshdrawnil \\cellx5610\\row }\\pard \\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 {\\insrsid10756800 \\par \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 \\'8atevilo negativnih u\\'e8encev pri predmetih (u\\'e8enci, ki niso dosegli minimalnega znanja)\\par }"."\n");
    for ($Indx=0;$Indx < $StPredmetov;$Indx++){
        if ($PredmetNegativnoPol[$Indx] > 0 ){
            fwrite ($fh,"{\\insrsid5715400 ".$Indx.".\\tab ".ToRTF($Predmeti[$Indx][1])."\\tab ".$PredmetNegativno[$Indx]."\\par }"."\n");
        }
    }
    fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 U\\'e8enci z negativnimi ocenami (prevladujejo negativne ocene)\\par }"."\n");
    for ($Indx=0;$Indx < $IndxUcNP;$Indx++){
        fwrite ($fh,"{\\insrsid5715400 ".($Indx+1).".\\tab ".ToRTF($UcenciNegativni[$Indx][1])."\\tab ".ToRTF($UcenciNegativni[$Indx][2]." ")."\\par }"."\n");
    }
    fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Neocenjeni u\\'e8enci\\par }"."\n");
    for ($Indx=0;$Indx < $IndxNeoc;$Indx++){
        fwrite ($fh,"{\\insrsid5715400 ".($Indx+1).".\\tab ".$UcenciNeocenjeni[$Indx][1]."\\tab ".$UcenciNeocenjeni[$Indx][2]."\\par }"."\n");
    }
    fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
    If ($UcneUre[2] > 0 ){
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Realizacija u\\'e8nih ur: ".number_format(($UcneUre[3]/$UcneUre[2])*100,2)." %\\par }"."\n");
        for ($Indx=0;$Indx < $StPredmetovUcneUre;$Indx++){
            if ($UcneUrePredmeti[$Indx][4] > 0 ){
                fwrite ($fh,"{\\insrsid5715400 ".($Indx+1).". \\tab ".ToRTF($UcneUrePredmeti[$Indx][1])."\\tab ".$UcneUrePredmeti[$Indx][5]." ur=".number_format(($UcneUrePredmeti[$Indx][5]/$UcneUrePredmeti[$Indx][4])*100,2)."%\\par }"."\n");
            }else{
                fwrite ($fh,"{\\insrsid5715400 ".($Indx+1).". \\tab ".ToRTF($UcneUrePredmeti[$Indx][1])."\\tab ".$UcneUrePredmeti[$Indx][5]." ur\\par }"."\n");
            }
        }
    }
    fwrite ($fh,"{\\insrsid10756800 \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Izre\\'e8eni vzgojni ukrepi: \\par }"."\n");
    $Indx2=0;
    for ($Indx1 = 0;$Indx1 < $StUcencev;$Indx1++){
        if ($ucenci[$Indx1][0] > 0 ){
            $SQL = "SELECT TabVzgUkrepi.*, TabOpomini.Opis FROM TabOpomini INNER JOIN TabVzgUkrepi ON TabOpomini.IdUkrep = TabVzgUkrepi.IdUkrep WHERE TabVzgUkrepi.idUkrep < 7 AND TabVzgUkrepi.IdUcenec=" .$ucenci[$Indx1][0] . " AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $Indx2=$Indx2+1;
                fwrite ($fh,"{\\insrsid5715400 ".$Indx2.".\\tab ".ToRTF($ucenci[$Indx1][1])."\\tab ".ToRTF($R["Opis"]." ")."}{\\insrsid10756800 \par }"."\n");
            }
        }
    }    
    fwrite ($fh,"{\\insrsid5715400 \\par }"."\n");
    fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 Dnevi dejavnosti:\\par }"."\n");

    //'Izpis dnevov dejavnosti-začetek
    $SQL = "SELECT TabOstaleDej.*, TabAktivnosti.* FROM TabOstaleDej INNER JOIN TabAktivnosti ON TabOstaleDej.IdAktivnost=TabAktivnosti.IdAktivnost WHERE IdRazred=".$IdRazred." ORDER BY TabAktivnosti.IdAktivnost";
    $result = mysqli_query($link,$SQL);

    fwrite ($fh,"\\trowd \\irow0\\irowband0\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth482\\clshdrawnil \\cellx374\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil "."\n");
    fwrite ($fh,"\\cellx2057\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2992\\clshdrawnil \\cellx5049\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1309\\clshdrawnil \\cellx6358\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil \\cellx8041\\clvertalt"."\n");
    fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth935\\clshdrawnil \\cellx8976\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2162\\clshdrawnil \\cellx11138\\pard\\plain "."\n");
    fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {\\b\\fs16\\insrsid5715400\\charrsid5715400 \\'8at.\\cell Aktivnost\\cell Opis\\cell Datum\\cell Kraj\\cell Trajanje\\cell Vodja\\cell }\\pard\\plain "."\n");
    fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");

    $Indx=0;
    while ($R = mysqli_fetch_array($result)){
        fwrite ($fh,"{\\b\\fs16\\insrsid5715400\\charrsid5715400 \\trowd \\irow".$Indx."\\irowband".$Indx."\\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh"."\n");
        fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt\\clbrdrt"."\n");
        fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth482\\clshdrawnil \\cellx374\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
        fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil \\cellx2057\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2992\\clshdrawnil \\cellx5049\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
        fwrite ($fh,"\\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1309\\clshdrawnil \\cellx6358\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
        fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil \\cellx8041\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth935\\clshdrawnil \\cellx8976\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
        fwrite ($fh,"\\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2162\\clshdrawnil \\cellx11138\\row }\\pard\\plain "."\n");
        fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid10756800\\yts23 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        if ($R["cena"] > 0){
            fwrite ($fh,"{\\fs16\\insrsid5715400\\charrsid5715400 ".($Indx+1)."\\cell ".ToRTF($R["Opis"]." ")."\\cell ".ToRTF($R["Vsebina"]." ")." (cena: ".$R["cena"]." EUR)"."\\cell ".ToRTF($R["Datum"]." ")."\\cell ".ToRTF($R["Kraj"]." ")."\\cell ".ToRTF($R["Trajanje"]." ")."\\cell ".ToRTF($R["Vodja"]." ")."\\cell }\\pard\\plain "."\n");
        }else{
            fwrite ($fh,"{\\fs16\\insrsid5715400\\charrsid5715400 ".($Indx+1)."\\cell ".ToRTF($R["Opis"]." ")."\\cell ".ToRTF($R["Vsebina"]." ")."\\cell ".ToRTF($R["Datum"]." ")."\\cell ".ToRTF($R["Kraj"]." ")."\\cell ".ToRTF($R["Trajanje"]." ")."\\cell ".ToRTF($R["Vodja"]." ")."\\cell }\\pard\\plain "."\n");
        }
        fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\f1\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 "."\n");
        $Indx = $Indx+1;
    }
    //'spodnja vrstica
    fwrite ($fh,"{\\fs16\\insrsid5715400\\charrsid5715400 \\trowd \\irow".$Indx."\\irowband".$Indx."\\lastrow \\ts23\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkborder\\tbllkshading\\tbllkfont\\tbllkcolor\\tbllkbestfit\\tbllkhdrrows\\tbllkhdrcols \\clvertalt"."\n");
    fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth482\\clshdrawnil \\cellx374\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil \\cellx2057\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2992\\clshdrawnil \\cellx5049\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1309\\clshdrawnil \\cellx6358\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth1683\\clshdrawnil \\cellx8041\\clvertalt\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth935\\clshdrawnil \\cellx8976\\clvertalt\\clbrdrt\\brdrs\\brdrw10 "."\n");
    fwrite ($fh,"\\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2162\\clshdrawnil \\cellx11138\\row }\\pard "."\n");
    fwrite ($fh,"\\qj \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid10756800 {\\insrsid10756800 \\par }"."\n");

    //'Izpis dnevov dejavnosti-konec

        //'Izpis komentarja razrednika (polletno) - zacetek
    $SQL = "SELECT TabRazrednikPor.*,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Spol FROM TabRazrednikPor INNER JOIN tabucitelji ON TabRazrednikPor.Razrednik=tabucitelji.IdUcitelj WHERE IdRazred=".$IdRazred;
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        if ($R["Spol"]=="M" ){
            fwrite ($fh,"{\\b\\insrsid5715400\\charrsid10756800 Polletno poro\\'e8ilo u\\'e8itelja - ".ToRTF($R["Ime"]." ".$R["Priimek"])."\\par }"."\n");
        }else{
            fwrite ($fh,"{\\b\\insrsid5715400\\charrsid10756800 Polletno poro\\'e8ilo u\\'e8iteljice - ".ToRTF($R["Ime"]." ".$R["Priimek"])."\\par }"."\n");
        }
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");

        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Uspeh oddelka in rezultati u\'e8no vzgojnega dela}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Komentar"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Sestanki oddel\'e8nega u\'e8iteljskega (razrednega, celotnega u\'e8iteljskega zbora)}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        //echo  ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Komentar"]))."<br />";
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["UcnoVzgDelo"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Vzgojna problematika in socialna klima oddelka}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["VzgUkrepi"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Priporo\'e8ila, razmi\'9aljanja za naslednje leto}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid5715400 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Priporocila"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        
        //fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("Analiza pedagoškega dela v učnih skupinah")."}{\\insrsid5715400\\charrsid5715400 : \\par }"."\n");
        //fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Uspehi"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Mnenje \'9aolske svetovalne slu\'9ebe in oddel\'e8nega u\'e8iteljskega zbora}{\\insrsid5715400\\charrsid5715400 : \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Pohvale"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");
        
        /*
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Drugo}{\\insrsid5715400\\charrsid5715400 : \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Uspehi"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");
        */
    }
    //'Izpis komentarja razrednika - konec

    //'Izpis komentarja razrednika (končno) - zacetek
    $SQL = "SELECT TabRazrednikPorK.*,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Spol FROM TabRazrednikPorK INNER JOIN tabucitelji ON TabRazrednikPorK.Razrednik=tabucitelji.IdUcitelj WHERE IdRazred=".$IdRazred;
    $result = mysqli_query($link,$SQL);

    while ($R = mysqli_fetch_array($result)){
        if ($R["Spol"]=="M" ){
            fwrite ($fh,"{\\b\\insrsid5715400\\charrsid10756800 Kon\\'e8no poro\\'e8ilo u\\'e8itelja - ".ToRTF($R["Ime"]." ".$R["Priimek"])."\\par }"."\n");
        }else{
            fwrite ($fh,"{\\b\\insrsid5715400\\charrsid10756800 Kon\\'e8no poro\\'e8ilo u\\'e8iteljice - ".ToRTF($R["Ime"]." ".$R["Priimek"])."\\par }"."\n");
        }
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");

        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Uspeh oddelka in rezultati u\'e8no vzgojnega dela}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Komentar"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Sestanki oddel\'e8nega u\'e8iteljskega (razrednega, celotnega u\'e8iteljskega zbora)}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        //echo  ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Komentar"]))."<br />";
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["UcnoVzgDelo"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Vzgojna problematika in socialna klima oddelka}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid10756800 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["VzgUkrepi"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Priporo\'e8ila, razmi\'9aljanja za naslednje leto}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid5715400 \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Priporocila"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        
        //fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 ".ToRTF("Analiza pedagoškega dela v učnih skupinah")."}{\\insrsid5715400\\charrsid5715400 : }{\\insrsid5715400 \\par }"."\n");
        //fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Uspehi"]))."}{\\insrsid10756800 \\par \\par }"."\n");

        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Mnenje \'9aolske svetovalne slu\'9ebe in oddel\'e8nega u\'e8iteljskega zbora}{\\insrsid5715400\\charrsid5715400 : \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Pohvale"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");
        
        /*
        fwrite ($fh,"{\\b\\insrsid5715400\\charrsid5715400 Drugo}{\\insrsid5715400\\charrsid5715400 : \\par }"."\n");
        fwrite ($fh,"{\\insrsid5715400\\charrsid5715400 ".ToRTF(str_replace(chr(13).chr(10),"\\par ",$R["Uspehi"]))."}{\\insrsid10756800 \\par \\par }"."\n");
        fwrite ($fh,"{\\b\\insrsid10756800 \\par }"."\n");
        */
    }
    //'Izpis komentarja razrednika - konec
    fwrite ($fh,"{\\insrsid16406371 \\page }    "."\n");
}
fwrite ($fh," }"."\n");
fclose($fh);

echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri poročila razrednikov</a></h2>";
?>
</body>
</html>

