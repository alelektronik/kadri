<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Podatki o delavcih
</title>
</head>
<body>

<?php

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    return $txt;
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$VFile="PodatkiODelavcih.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti log datoteke!");

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VSola=$R["Sola"];
	$VSolaNaslov=$R["Naslov"].", ".$R["Kraj"];
	$VSolaKraj=$R["Kraj"];
	$VRavnatelj=$R["Ravnatelj"];
}else{
	$VSola=" ";
	$VRavnatelj=" ";
}

fwrite ($fh,"{\\rtf1\\ansi\\ansicpg1250\\uc1\\deff0\\stshfdbch0\\stshfloch0\\stshfhich0\\stshfbi0\\deflang1060\\deflangfe1060{\\fonttbl{\\f0\\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}"."\n");
fwrite ($fh,"{\\f36\\fswiss\\fcharset238\\fprq2{\\*\\panose 020b0604030504040204}Tahoma;}{\\f39\\froman\\fcharset0\\fprq2 Times New Roman;}{\\f38\\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\f40\\froman\\fcharset161\\fprq2 Times New Roman Greek;}"."\n");
fwrite ($fh,"{\\f41\\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f42\\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f43\\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\f44\\froman\\fcharset186\\fprq2 Times New Roman Baltic;}"."\n");
fwrite ($fh,"{\\f45\\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f399\\fswiss\\fcharset0\\fprq2 Tahoma;}{\\f398\\fswiss\\fcharset204\\fprq2 Tahoma Cyr;}{\\f400\\fswiss\\fcharset161\\fprq2 Tahoma Greek;}{\\f401\\fswiss\\fcharset162\\fprq2 Tahoma Tur;}"."\n");
fwrite ($fh,"{\\f402\\fswiss\\fcharset177\\fprq2 Tahoma (Hebrew);}{\\f403\\fswiss\\fcharset178\\fprq2 Tahoma (Arabic);}{\\f404\\fswiss\\fcharset186\\fprq2 Tahoma Baltic;}{\\f405\\fswiss\\fcharset163\\fprq2 Tahoma (Vietnamese);}{\\f406\\fswiss\\fcharset222\\fprq2 Tahoma (Thai);}}"."\n");
fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;"."\n");
fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red255\\green255\\blue255;}"."\n");

$SQL = "SELECT * FROM tabucitelji WHERE status IN (1,2,3,4,5,6) ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);
$Indx=1;
while ($R = mysqli_fetch_array($result)){
	$VDelavci[$Indx]=$R["IdUcitelj"];
	$Indx=$Indx+1;
}
$StDelavcev=$Indx-1;

for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
	$ucitelj=$VDelavci[$Indx];
	
	$SQL = "SELECT tabucitelji.* FROM tabucitelji ";
	$SQL = $SQL . "WHERE tabucitelji.IdUcitelj =" . $ucitelj;
	//Response.Write "<br>" & $SQL & "<br>"
	$result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
		$VObcina=$R["Obcina"];
		$VDrzava=$R["Drzava"];
		$VObcinaZac=$R["ObcinaZac"];
		$VDrzavaZac=$R["DrzavaZac"];
	}

	$SQL = "SELECT * FROM TabSifreObcin WHERE sifra='".$VObcina."'";
	$result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		$VObcina=$R["sifra"]." - ".$R["obcina"];
	}
	$SQL = "SELECT * FROM TabSifreObcin WHERE sifra='".$VObcinaZac."'";
	$result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		$VObcinaZac=$R["sifra"]." - ".$R["obcina"];
	}
	$SQL = "SELECT * FROM TabSifrantDrzav WHERE sifra='".$VDrzava."'";
	$result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		$VDrzava=$R["sifra"]." - ".$R["drzava"];
	}
	$SQL = "SELECT * FROM TabSifrantDrzav WHERE sifra='".$VDrzavaZac."'";
	$result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
		$VDrzavaZac=$R["sifra"]." - ".$R["drzava"];
	}

    $SQL = "SELECT tabpogodbe.*,tabucitelji.Priimek,tabucitelji.Ime,tabucitelji.Spol,tabucitelji.DatRoj,tabucitelji.KrajRoj,tabucitelji.DrzavaRoj,tabucitelji.drzavljanstvo,tabucitelji.Status,";
    $SQL = $SQL . "tabucitelji.Invalid,tabucitelji.EMSO,tabucitelji.Davcna,tabucitelji.Naslov,tabucitelji.Posta,tabucitelji.Kraj,tabucitelji.NaslovZac,tabucitelji.PostaZac,tabucitelji.KrajZac,";
    $SQL = $SQL . "tabucitelji.KatInvalid,tabucitelji.DelnoUpokojen,tabucitelji.IzobOpis,";
    $SQL = $SQL . " TabDelo.SkupinaDela, TabDelo.OpisDela, TabVzgDelo.VzgojnoDelo,TabIzobrazba.Opis FROM ";
	$SQL = $SQL . "(((tabpogodbe INNER JOIN tabucitelji ON tabpogodbe.idUcitelj=tabucitelji.idUcitelj) ";
	$SQL = $SQL . "INNER JOIN TabDelo ON tabucitelji.IdDelo=TabDelo.IdDelo) ";
	$SQL = $SQL . "INNER JOIN TabVzgDelo ON tabucitelji.IdVzgojnoDelo=TabVzgDelo.IdVzgojnoDelo) ";
    $SQL = $SQL . "INNER JOIN TabIzobrazba ON tabucitelji.Izobrazba=TabIzobrazba.idIzobrazba ";
	$SQL = $SQL . "WHERE tabucitelji.IdUcitelj =" . $ucitelj;
	//Response.Write "<br>" & $SQL & "<br>"
	$result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
		fwrite ($fh,"{\\stylesheet{\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 "."\n");
		fwrite ($fh,"\\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 \\snext0 Normal;}{\\*\\cs10 \\additive \\ssemihidden Default Paragraph Font;}{\\*"."\n");
		fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\snext11 \\ssemihidden Normal Table;}{\\*\\ts15\\tsrowd\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tscellwidthfts0\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\fs20\\lang1024\\langfe1024\\cgrid\\langnp1024\\langfenp1024 \\sbasedon11 \\snext15 \\styrsid8656143 Table Grid;}}{\\*\\latentstyles\\lsdstimax156\\lsdlockeddef0}{\\*\\rsidtbl \\rsid132144"."\n");
		fwrite ($fh,"\\rsid878009\\rsid1058823\\rsid1272524\\rsid1661594\\rsid3016234\\rsid5464865\\rsid6569264\\rsid6707932\\rsid7017005\\rsid7169444\\rsid8656143\\rsid8801156\\rsid9136726\\rsid10317843\\rsid10514662\\rsid10623545\\rsid13371522\\rsid16283048\\rsid16394438\\rsid16731475}"."\n");
		fwrite ($fh,"\\paperw11906\\paperh16838\\margl1417\\margr1417\\margt719\\margb719 "."\n");
		fwrite ($fh,"\\deftab708\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dgmargin\\dghspace180\\dgvspace180\\dghorigin1417\\dgvorigin719\\dghshow1\\dgvshow1"."\n");
		fwrite ($fh,"\\jexpand\\viewkind1\\viewscale95\\pgbrdrhead\\pgbrdrfoot\\splytwnine\\ftnlytwnine\\htmautsp\\nolnhtadjtbl\\useltbaln\\alntblind\\lytcalctblwd\\lyttblrtgr\\lnbrkrule\\nobrkwrptbl\\snaptogridincell\\allowfieldendsel\\wrppunct\\asianbrkrule\\nojkernpunct\\rsidroot10623545 \\fet0"."\n");
		fwrite ($fh,"\\sectd \\linex0\\headery708\\footery708\\colsx708\\endnhere\\sectlinegrid360\\sectdefaultcl\\sectrsid16731475\\sftnbj {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3"."\n");
		fwrite ($fh,"\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}"."\n");
		fwrite ($fh,"{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}\\trowd \\irow0\\irowband0"."\n");
		fwrite ($fh,"\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard\\plain \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\fs24\\lang1060\\langfe1060\\cgrid\\langnp1060\\langfenp1060 {"."\n");
		fwrite ($fh,"\\b\\f36\\insrsid8656143\\charrsid7017005 ");
		if ($R["Spol"]=="M"){
			fwrite ($fh,"PODATKI O DELAVCU\\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid8656143\\charrsid8656143 "."\n");
		}else{
			fwrite ($fh,"PODATKI O DELAVKI\\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid8656143\\charrsid8656143 "."\n");
		}
		fwrite ($fh,"\\trowd \\irow0\\irowband0\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow1\\irowband1\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 "."\n");
		fwrite ($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1058823\\charrsid8656143 \\cell }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1058823\\charrsid8656143 \\trowd \\irow1\\irowband1\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow2\\irowband2\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth7068\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1058823\\charrsid7169444 Ime in priimek:\\cell }"."\n");

		fwrite ($fh,"{\\b\\f36\\fs28\\insrsid1058823\\charrsid16283048 " .ToRTF($R["Ime"]  . " " . $R["Priimek"]) . "\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow2\\irowband2\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth7068\\clshdrawnil \\cellx9228\\row }\\trowd \\irow3\\irowband3\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3256\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1674\\clshdrawnil \\cellx7090\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2138\\clshdrawnil \\cellx9228"."\n");
		fwrite ($fh,"\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Datum rojstva:\\cell }"."\n");
		$Datum=new DateTime($R["DatRoj"]);
		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".$Datum->format('d.m.Y')."\\cell }\\pard");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid1272524 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Kraj rojstva: \\cell }");

		fwrite ($fh,"\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
		fwrite ($fh,"\\f36\\insrsid9136726\\charrsid16283048 ".ToRTF($R["KrajRoj"])."\\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow3\\irowband3\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3256\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1674\\clshdrawnil \\cellx7090\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2138\\clshdrawnil \\cellx9228\\row }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Dr\\'9eava rojstva:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".ToRTF($R["DrzavaRoj"])."\\cell }\\pard");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid1272524 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Dr\\'9eavljanstvo:\\cell }");
		fwrite ($fh,"\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
		fwrite ($fh,"\\f36\\insrsid9136726\\charrsid16283048 ".ToRTF($R["drzavljanstvo"])."\\cell }"."\n");

		fwrite ($fh,"\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow4\\irowband4\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3256\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1674\\clshdrawnil \\cellx7090\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth2138\\clshdrawnil \\cellx9228\\row "."\n");
		fwrite ($fh,"}\\trowd \\irow5\\irowband5\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth7068\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 EM\\'8aO:\\cell }"."\n");

		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".$R["EMSO"]."\\cell }\\pard"."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow5\\irowband5\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth7068\\clshdrawnil \\cellx9228\\row }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Dav\\'e8na \\'9atevilka:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".$R["Davcna"]."\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow6\\irowband6\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol "."\n");
		fwrite ($fh,"\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth7068\\clshdrawnil \\cellx9228\\row }\\trowd \\irow7\\irowband7\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3445\\clshdrawnil \\cellx3337\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5891\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1661594\\charrsid7169444 Naslov stalnega prebivali\\'9a\\'e8a:\\cell }"."\n");

		fwrite ($fh,"{\\f36\\insrsid1661594\\charrsid16283048 ".ToRTF($R["Naslov"].", ".$R["Posta"]." ".$R["Kraj"].", ".$VObcina.", ".$VDrzava)."\\cell }\\pard "."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1661594\\charrsid8656143 \\trowd \\irow7\\irowband7\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3445\\clshdrawnil \\cellx3337\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5891\\clshdrawnil \\cellx9228\\row }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1661594\\charrsid7169444 Naslov za\\'e8asnega prebivali\\'9a\\'e8a:\\cell }"."\n");
		
		if (strlen($R["NaslovZac"]) > 0){
			fwrite ($fh,"{\\f36\\insrsid1661594\\charrsid16283048 ".ToRTF($R["NaslovZac"].", ".$R["PostaZac"]." ".$R["KrajZac"].", ".$VObcinaZac.", ".$VDrzavaZac)."\\cell }\\pard "."\n");
		}else{
			fwrite ($fh,"{\\f36\\insrsid1661594\\charrsid16283048 \\cell }\\pard "."\n");
		}

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1661594\\charrsid8656143 \\trowd \\irow8\\irowband8\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3445\\clshdrawnil \\cellx3337\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5891\\clshdrawnil \\cellx9228\\row }\\trowd \\irow9\\irowband9"."\n");
		fwrite ($fh,"\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx2880\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2536\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2715\\clshdrawnil \\cellx8131\\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1097\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 "."\n");
		fwrite ($fh,"Invalidnost:\\cell }"."\n");
		
		if ($R["Invalid"]){
			fwrite ($fh,"{\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 DA\\cell }{\\f36\\fs20\\insrsid9136726\\charrsid7169444 NE\\cell }"."\n");
		}else{
			fwrite ($fh,"{\\f36\\fs20\\insrsid9136726\\charrsid7169444 DA\\cell }{\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 NE\\cell }"."\n");
		}
		
		fwrite ($fh,"{\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Kategorija invalidnosti:\\cell }{\\f36\\insrsid9136726\\charrsid16283048 ".$R["KatInvalid"]."\\cell }\\pard "."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow9\\irowband9\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx2880\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2536\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2715\\clshdrawnil \\cellx8131\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1097\\clshdrawnil \\cellx9228\\row "."\n");
		fwrite ($fh,"}\\trowd \\irow10\\irowband10\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx2880\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth6348\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1661594\\charrsid7169444 Delna upokojitev:"."\n");
		fwrite ($fh,"\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\fs20\\insrsid1661594\\charrsid7169444 \\cell ".$R["DelnoUpokojen"]."\\cell }\\pard "."\n");

//'		Response.Write "Izobrazba:<b> " & $R["Izobrazba") & " - " & $R["IzobOpis") & "</b><br>"

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow10\\irowband10\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2268\\clshdrawnil \\cellx2160\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx2880\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth6348\\clshdrawnil \\cellx9228\\row }\\trowd \\irow11\\irowband11\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw30 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
		fwrite ($fh,"\\f36\\insrsid1058823\\charrsid8656143 \\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1058823\\charrsid8656143 \\trowd \\irow11\\irowband11\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw30 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow12\\irowband12\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\insrsid7017005\\charrsid7017005 "."\n");
		fwrite ($fh,"PODATKI O SKLENJENI POGODBI O ZAPOSLITVI ".$R["StPogodbe"]);
		fwrite ($fh,"\\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7017005\\charrsid8656143 \\trowd \\irow12\\irowband12\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow13\\irowband13\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 "."\n");
		fwrite ($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1058823\\charrsid8656143 \\cell }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1058823\\charrsid8656143 \\trowd \\irow13\\irowband13\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow14\\irowband14\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Datum sklenitve pogodbe:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".$R["DatumPogodbe"]."\\cell }\\pard "."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid9136726\\charrsid8656143 \\trowd \\irow14\\irowband14\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow15\\irowband15\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 Datum nastopa dela:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".$R["DatumStart"]."\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid9136726\\charrsid8656143 \\trowd \\irow15\\irowband15\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow16\\irowband16\\ts15\\trgaph70\\trrh483\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvmgf\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth3812\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 "."\n");
		fwrite ($fh,"Vrsta sklenjene pogodbe: \\cell }"."\n");
		switch ($R["Status"]){
			case 1:
            case 2:
				fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid7169444 DOLO\\'c8EN \\'c8AS\\cell}{\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 NEDOLO\\'c8EN \\'c8AS}"."\n");
                break;
			case 3:
            case 4:
            case 5:
            case 6:
				fwrite ($fh,"{\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 DOLO\\'c8EN \\'c8AS\\cell}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 NEDOLO\\'c8EN \\'c8AS}"."\n");
                break;
			case 0:
				fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid7169444 DOLO\\'c8EN \\'c8AS\\cell}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 NEDOLO\\'c8EN \\'c8AS}"."\n");
                break;
			case 10:
				fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid7169444 DOLO\\'c8EN \\'c8AS\\cell}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 NEDOLO\\'c8EN \\'c8AS}"."\n");
		}
		
		fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid16731475 \\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {"."\n");
		fwrite ($fh,"\\f36\\insrsid16731475\\charrsid8656143 \\trowd \\irow16\\irowband16\\ts15\\trgaph70\\trrh483\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvmgf\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth3812\\clshdrawnil \\cellx9228\\row }\\trowd \\irow17\\irowband17\\ts15\\trgaph70\\trrh482\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvmrg\\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth3812\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 \\cell }"."\n");

		if ($R["PolniDelCas"]=="Da"){
			fwrite ($fh,"{\\b\\f36\\fs20\\insrsid16731475 POLNI \\'c8AS}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 \\cell }{\\f36\\fs20\\insrsid16731475 SKRAJ\\'8aANI \\'c8AS}"."\n");
		}else{
			fwrite ($fh,"{\\f36\\fs20\\insrsid16731475 POLNI \\'c8AS}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 \\cell }{\\b\\f36\\fs20\\insrsid16731475 SKRAJ\\'8aANI \\'c8AS}"."\n");
		}
		
		fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid7169444 \\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid16731475\\charrsid8656143 \\trowd \\irow17\\irowband17\\ts15\\trgaph70\\trrh482\\trleft-108\\trbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvmrg\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth3812\\clshdrawnil \\cellx9228\\row }\\trowd \\irow18\\irowband18\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid7169444 Razlog sklenitve pogodbe"."\n");
		fwrite ($fh,"\\par }{\\b\\f36\\fs20\\insrsid9136726\\charrsid7169444 za dolo\\'e8en \\'e8as:\\cell }"."\n");

		fwrite ($fh,"{\\f36\\insrsid9136726\\charrsid16283048 ".ToRTF($R["RazlogDolCas"])."\\cell }\\pard "."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid9136726\\charrsid8656143 "."\n");
		fwrite ($fh,"\\trowd \\irow18\\irowband18\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow19\\irowband19"."\n");
		fwrite ($fh,"\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1964\\clshdrawnil \\cellx7380\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth751\\clshdrawnil \\cellx8131\\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1097\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 "."\n");
		fwrite ($fh,"{\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 Delovni \\'e8as (ur na teden):\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid7169444\\charrsid16283048 ".$R["UrTeden"]."\\cell }");
		
		if ($R["Izmensko"]){
			fwrite ($fh,"{\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 Izmensko delo:\\cell }{\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 DA\\cell }{\\f36\\fs20\\insrsid7169444\\charrsid7169444 NE\\cell }\\pard "."\n");
		}else{
			fwrite ($fh,"{\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 Izmensko delo:\\cell }{\\f36\\fs20\\insrsid7169444\\charrsid7169444 DA\\cell }{\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 NE\\cell }\\pard "."\n");
		}

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow19\\irowband19\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth2176\\clshdrawnil \\cellx5416\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth1964\\clshdrawnil \\cellx7380\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth751\\clshdrawnil \\cellx8131\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth1097\\clshdrawnil \\cellx9228\\row "."\n");
		fwrite ($fh,"}\\trowd \\irow20\\irowband20\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid7169444\\charrsid7169444 Kraj delovnega mesta:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid7169444\\charrsid16283048 " . ToRTF($R["KrajDela"]) . "\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid7169444\\charrsid8656143 \\trowd \\irow20\\irowband20\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow21\\irowband21\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx3960\\clvertalc\\clbrdrt\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5268\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 Konkuren\\'e8"."\n");
		fwrite ($fh,"na klavzula:\\cell }"."\n");

		if ($R["KonkKlavz"]){
			fwrite ($fh,"{\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 DA\\cell}{\\f36\\fs20\\insrsid16731475\\charrsid7169444 NE\\cell }\\pard "."\n");
		}else{
			fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid7169444 DA\\cell}{\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 NE\\cell }\\pard "."\n");
		}
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid16731475\\charrsid8656143 "."\n");
		fwrite ($fh,"\\trowd \\irow21\\irowband21\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth720\\clshdrawnil \\cellx3960\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5268\\clshdrawnil \\cellx9228\\row }\\trowd \\irow22\\irowband22\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil "."\n");
		fwrite ($fh,"\\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 Poklic:\\cell }"."\n");

		fwrite ($fh,"{\\f36\\fs20\\insrsid16731475\\charrsid16283048 ".ToRTF($R["Opis"] . " - " .$R["IzobOpis"])."\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid16731475\\charrsid8656143 \\trowd \\irow22\\irowband22\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 Potr. strok. usposobljenost:\\cell }"."\n");

		if ($R["IzobUstr"]== 0){
			fwrite ($fh,"{\\f36\\insrsid16731475\\charrsid16283048 ".ToRTF($R["PotrStrokUsp"])." - ustrezna\\cell }\\pard "."\n");
		}else{
			fwrite ($fh,"{\\f36\\insrsid16731475\\charrsid16283048 ".ToRTF($R["PotrStrokUsp"])." - neustrezna\\cell }\\pard "."\n");
		}
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid16731475\\charrsid8656143 \\trowd \\irow23\\irowband23\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr"."\n");
		fwrite ($fh,"\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow24\\irowband24"."\n");
		fwrite ($fh,"\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid16731475\\charrsid7169444 Naziv delovnega mesta:\\cell }"."\n");

		fwrite ($fh,"{\\f36\\insrsid16731475\\charrsid16283048 " . ToRTF($R["NazivDelMesta"]) . "\\cell }\\pard "."\n");

		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid16731475\\charrsid8656143 \\trowd \\irow24\\irowband24\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3348\\clshdrawnil \\cellx3240\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth5988\\clshdrawnil \\cellx9228\\row }\\trowd \\irow25\\irowband25\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw30 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid878009\\charrsid8656143 \\cell }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid878009\\charrsid8656143 \\trowd \\irow25\\irowband25\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw30 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow26\\irowband26\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\insrsid878009\\charrsid878009 PODATKI O PRENEHANJU POGODBE O ZAPOSLITVI"."\n");
		fwrite ($fh,"\\cell }\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid878009\\charrsid8656143 \\trowd \\irow26\\irowband26\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrs\\brdrw30 \\clbrdrb\\brdrs\\brdrw30 \\clbrdrr\\brdrs\\brdrw30 \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow27\\irowband27\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw30 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\pard \\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid878009\\charrsid8656143 \\cell }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid878009\\charrsid8656143 \\trowd \\irow27\\irowband27\\ts15\\trgaph70\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt"."\n");
		fwrite ($fh,"\\brdrs\\brdrw30 \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth9336\\clshdrawnil \\cellx9228\\row }\\trowd \\irow28\\irowband28\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone "."\n");
		fwrite ($fh,"\\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3168\\clshdrawnil \\cellx3060\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth6168\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1661594\\charrsid7169444 Datum prenehanja pogodbe:\\cell }"."\n");
		
//'		response.write "<h2>Podatki o prenehanju pogodbe o zaposlitvi</h2>"
		fwrite ($fh,"{\\f36\\insrsid1661594\\charrsid16283048 ".$R["DatumEnd"]."\\cell }\\pard "."\n");
		
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1661594\\charrsid8656143 \\trowd \\irow28\\irowband28\\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrnone \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3168\\clshdrawnil \\cellx3060\\clvertalc\\clbrdrt\\brdrs\\brdrw10 \\clbrdrl\\brdrnone \\clbrdrb\\brdrnone \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth6168\\clshdrawnil \\cellx9228\\row }\\trowd \\irow29\\irowband29\\lastrow \\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3168\\clshdrawnil \\cellx3060\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 \\cltxlrtb\\clftsWidth3\\clwWidth6168\\clshdrawnil \\cellx9228\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\b\\f36\\fs20\\insrsid1661594\\charrsid7169444 Na\\'e8in prenehanja pogodbe:\\cell }"."\n");
		
		fwrite ($fh,"{\\f36\\insrsid1661594\\charrsid16283048 ".ToRTF($R["NacinPrenehanja"])."\\cell }\\pard "."\n");
		fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\intbl\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 {\\f36\\insrsid1661594\\charrsid8656143 \\trowd \\irow29\\irowband29\\lastrow \\ts15\\trgaph70\\trrh567\\trleft-108\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr"."\n");
		fwrite ($fh,"\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 \\trftsWidth3\\trwWidth9336\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tbllkhdrrows\\tbllklastrow\\tbllkhdrcols\\tbllklastcol \\clvertalc"."\n");
		fwrite ($fh,"\\clbrdrt\\brdrnone \\clbrdrl\\brdrs\\brdrw10 \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrnone \\cltxlrtb\\clftsWidth3\\clwWidth3168\\clshdrawnil \\cellx3060\\clvertalc\\clbrdrt\\brdrnone \\clbrdrl\\brdrnone \\clbrdrb\\brdrs\\brdrw10 \\clbrdrr\\brdrs\\brdrw10 "."\n");
		fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth6168\\clshdrawnil \\cellx9228\\row }\\pard \\ql \\li0\\ri0\\widctlpar\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\f36\\insrsid6707932\\charrsid8656143 "."\n");
		fwrite ($fh,"\\par }"."\n");
		fwrite ($fh,"{\\page}"."\n");
	}
}

fwrite ($fh,"}"."\n");

echo "<h2><a href='dato/".$VFile."' target='_blank'>Odpri podatke o delavcih (Word - RTF)</a></h2>";
?>

</body>
</html>