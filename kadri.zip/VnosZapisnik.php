<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj5.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Zapisniki
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat03",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
        new JsDatePick({
            useMode:2,
            target:"dat04",
            dateFormat:"%d.%m.%Y",
            yearsRange:[1940,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat05",
            dateFormat:"%d.%m.%Y",
            
            yearsRange:[1940,2080],
            limitToToday:true
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

if (isset($_POST["vpis"])){
    $VVpis=$_POST["vpis"];
}else{
    if (isset($_GET["vpis"])){
        $VVpis=$_GET["vpis"];
    }else{
        $VVpis="";
    }
}
switch ($VVpis){
    case "5":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    if ($VLevel >= 0 ){
        if ($VVpis != "5" ){
            //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
            echo "<table border='1' cellspacing='0'>";
            echo "<tr><th>Poročila, ki jih vpisujete na ločenih naslovih</th></tr>";
            echo "<tr><td><a href='VnosIzobrazevanje.php'>Vnos najave in poročila o sodelovanju na izobraževalnih seminarjih</a></td></tr>";
            echo "<tr><td><a href='PedPorocilo.php'>Vnos pedagoškega poročila (razrednik, učitelji, PB, svetovalna)</a></td></tr>";
            echo "<tr><td><a href='IzborAktiviPorocilo.php?id=1a'>Vnos letnega poročila aktiva - vodje aktivov</a></td></tr>";
            echo "<tr><td><a href='IzborAktiviPorocilo.php?id=1b'>Vnos načrtov dela aktiva za naslednje ŠL - vodje aktivov</a></td></tr>";
            echo "<tr><td><a href='tekmovanjakrozki.php?id=101'>Vnos poročila s tekmovanj v znanju - vodje/mentorji tekmovanj</a></td></tr>";
            echo "<tr><td><a href='tekmovanjakrozki.php?id=201'>Vnos letnega poročila za interesno dejavnost - mentorji interesnih dej.</a></td></tr>";
            echo "<tr><td><a href='tekmovanjakrozki.php?id=301'>Vnos poročila s šolskih športnih tekmovanj - mentorji na tekmovanju</a></td></tr>";
            echo "<tr><td><a href='tekmovanjakrozki.php?id=401'>Natečaji</a></td></tr>";
            echo "<tr><td><a href='Projekti.php'>Projekti</a></td></tr>";
            echo "<tr><td><a href='Prakse.php'>Študentske prakse</a></td></tr>";
            echo "</table><br />";
        }
        $Ucitelj=$R["Ime"]  . " " . $R["Priimek"];
        $IdUcitelj=$R["IdUcitelj"];
    }else{
        header ("Location: nepooblascen.htm");
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
switch ($VVpis){
	case "2": //popravljanje zapisa
		$SQL = "SELECT TabZapisnik.*,tabzapisniktip.tip as ttip FROM TabZapisnik INNER JOIN tabzapisniktip ON TabZapisnik.tip=tabzapisniktip.id WHERE TabZapisnik.id=".$Vid;
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			$VLeto = $R["leto"];
			$VVsebina = $R["vsebina"];
			$VNaslov = $R["Naslov"];
			$VDatum = $R["Datum"];
			$VTip = $R["ttip"];
			$VTipID = $R["tip"];
			$VAvtor = $R["avtor"];
			$VEvidSt = $R["datoteka"];
            if (isset($R["zaupno"])){
                if ($R["zaupno"]){
                    $zaupno = "true";
                }else{
                    $zaupno="false";
                }
            }else{
                $zaupno="false";
            }
		}
        break;
    case "2b": //vpis novega zapisnika
        if (isset($_POST["vsebina"])){
            $VVsebina = $_POST["vsebina"];
        }else{
            $VVsebina = "";
        }
        if (isset($_POST["naslov"])){
            $VNaslov = $_POST["naslov"];
        }else{
            $VNaslov="";
        }
        $VVsebina = str_replace("'","",$VVsebina);
        $VVsebina = str_replace(chr(34),"",$VVsebina);
        $VVsebina = str_replace("<","",$VVsebina);
        $VVsebina = str_replace(">","",$VVsebina);
        if (isset($_POST["datum"])){
            $VDatum = $_POST["datum"];
        }else{
            $VDatum = $Danes->format('d.m.Y');
        }
        $VTipID = $_POST["tip"];
        if (isset($_POST["avtor"])){
            $VAvtor = $_POST["avtor"];
        }else{
            $VAvtor = $Ucitelj;
        }
        if (isset($_POST["EvidSt"])){
            $VEvidSt = $_POST["EvidSt"];
            if (substr($VEvidSt,0,4)=="6007"){
                $SQL = "SELECT id,datoteka FROM tabzapisnik WHERE datoteka='".$VEvidSt."'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $SQL = "SELECT id,datoteka FROM tabzapisnik WHERE leto=".$Danes->format('Y')." ORDER BY id";
                    $result1 = mysqli_query($link,$SQL);
                    $i=1;
                    while ($R1 = mysqli_fetch_array($result1)){
                        if (strlen($R1["datoteka"]) > 0){
                            $i += 1;
                        }
                    }
                    $VEvidSt="6007-".$i."/".$Danes->format('Y');
                }
            }
        }else{
            $SQL = "SELECT id,datoteka FROM tabzapisnik WHERE leto=".$Danes->format('Y')." ORDER BY id";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                if (strlen($R["datoteka"]) > 0){
                    $i += 1;
                }
            }
            $VEvidSt="6007-".$i."/".$Danes->format('Y');
        }
        if (isset($_POST["zaupno"])){
            $zaupno="true";
        }else{
            $zaupno="false";
        }
        $SQL = "INSERT INTO TabZapisnik (leto,naslov,tip,datum,avtor,vsebina,cas,vpisal,datoteka,zaupno) VALUES (".$VLeto.",'".$VNaslov."',".$VTipID.",'".$VDatum."','".$VAvtor."','".$VVsebina."','".$Danes->format('Y-m-d H:i:s')."','".$VUporabnik."','".$VEvidSt."',$zaupno)";
        if (!($result = mysqli_query($link,$SQL))){
            echo "<h2>Težave z vpisom - podatki NISO vpisani!</h2>";
        }
        
        if ($Opravila==1){
            $SQL = "SELECT * FROM tabzapisniktip WHERE id=".$VTipID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VTipNaslov=$R["tip"];
            }
            
            $SQL = "SELECT tabdogodek.*,tabdeldogodek.* FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='".$VTipNaslov."' AND leto=".$VLeto." AND idUcitelj=".$IdUcitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);
            
            $indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$indx]=$R["id"];
                $indx=$indx+1;
            }
            $StDogodkov=$indx-1;

            for ($indx=1;$indx <= $StDogodkov;$indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('d.m.Y')."' WHERE id=".$VDogodki[$indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        
        $Vid="";
        $VVsebina = "";
        $VNaslov = "";
        $VDatum = "";
        $VTip = "Poročilo - drugo";
        $VTipID = 15;
        $VAvtor = $Ucitelj;
        $VEvidSt = "";
        $zaupno = "true";
        break;
	case "1":
		$Vid="";
		$VVsebina = "";
		$VNaslov = "";
		$VDatum = "";
		$VTip = "Poročilo - drugo";
		$VTipID = 15;
		$VAvtor = $Ucitelj;
		$VEvidSt = "";
        $zaupno="true";
        break;
	case "3": //vpis popravka
        if (isset($_POST["vsebina"])){
		    $VVsebina = $_POST["vsebina"];
        }else{
            $VVsebina = "";
        }
        if (isset($_POST["naslov"])){
		    $VNaslov = $_POST["naslov"];
        }else{
            $VNaslov="";
        }
		$VVsebina = str_replace("'","",$VVsebina);
		$VVsebina = str_replace(chr(34),"",$VVsebina);
        $VVsebina = str_replace("<","",$VVsebina);
        $VVsebina = str_replace(">","",$VVsebina);
        if (isset($_POST["datum"])){
		    $VDatum = $_POST["datum"];
        }else{
            $VDatum = $Danes->format('d.m.Y');
        }
	    $VTipID = $_POST["tip"];
        if (isset($_POST["avtor"])){
		    $VAvtor = $_POST["avtor"];
        }else{
            $VAvtor = $Ucitelj;
        }
        if (isset($_POST["EvidSt"])){
		    $VEvidSt = $_POST["EvidSt"];
        }else{
            $VEvidSt = "";
        }
        if (isset($_POST["zaupno"])){
            $zaupno="true";
        }else{
            $zaupno="false";
        }
        
		$SQL = "SELECT * FROM TabZapisnik WHERE id=".$Vid;
		$result = mysqli_query($link,$SQL);
		
		if ($R = mysqli_fetch_array($result)){
			if ($VLevel < 2 ){
				if ($R["vpisal"] != $VUporabnik ){
					echo "<h2>Nimate pravic za popravljanje!</h2>";
				}else{
                    if ($R["zaupno"] && ($zaupno=="false")){
                        $SQL = "UPDATE TabZapisnik SET avtor='".$VAvtor."',datum='".$VDatum."',tip=".$VTipID.",naslov='".$VNaslov."', vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."', datoteka='".$VEvidSt."' WHERE id=".$Vid;
                    }else{
					    $SQL = "UPDATE TabZapisnik SET avtor='".$VAvtor."',datum='".$VDatum."',tip=".$VTipID.",naslov='".$VNaslov."', vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."', datoteka='".$VEvidSt."',zaupno=$zaupno WHERE id=".$Vid;
                    }
				}
			}else{
				$SQL = "UPDATE TabZapisnik SET avtor='".$VAvtor."',datum='".$VDatum."',tip=".$VTipID.",naslov='".$VNaslov."', vsebina='".$VVsebina."',cas='".$Danes->format('Y-m-d H:i:s')."', vpisal='".$VUporabnik."', datoteka='".$VEvidSt."',zaupno=$zaupno WHERE id=".$Vid;
			}
		}
		if (!($result = mysqli_query($link,$SQL))){
            echo "<h2>Težave z vpisom - popravek ni vpisan!</h2>";
        }
        
        if ($Opravila==1){
            $SQL = "SELECT * FROM tabzapisniktip WHERE id=".$VTipID;
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
                $VTipNaslov=$R["tip"];
            }
            
            $SQL = "SELECT tabdogodek.*,tabdeldogodek.* FROM ";
            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
            $SQL = $SQL . "WHERE tabdogodek.Dogodek='".$VTipNaslov."' AND leto=".$VLeto." AND idUcitelj=".$IdUcitelj." AND opravljeno=false";
            $result = mysqli_query($link,$SQL);
            
            $indx=1;
            while ($R = mysqli_fetch_array($result)){
                $VDogodki[$indx]=$R["id"];
                $indx=$indx+1;
            }
            $StDogodkov=$indx-1;

            for ($indx=1;$indx <= $StDogodkov;$indx++){
                $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('Y-m-d')."' WHERE id=".$VDogodki[$indx];
                $result = mysqli_query($link,$SQL);
            }
        }
        
		$Vid="";
		$VVsebina = "";
		$VNaslov = "";
		$VDatum = "";
		$VTip = "Poročilo - drugo";
		$VTipID = 15;
		$VAvtor = $Ucitelj;
		$VEvidSt = "";
        $zaupno = "true";
        break;
	case "4":  //brisanje zapisa
		$SQL = "SELECT * FROM TabZapisnik WHERE id=".$Vid;
		$result = mysqli_query($link,$SQL);
		
		if ($R = mysqli_fetch_array($result)){
			if ($VLevel < 2 ){
				if (($R["vpisal"] != $VUporabnik) or ($R["Arhiv"]==true) ){
					echo "<h2>Nimate pravic za brisanje!</h2>";
				}else{
					$SQL = "DELETE FROM TabZapisnik WHERE id=".$Vid;
				}
			}else{
				$SQL = "DELETE FROM TabZapisnik WHERE id=".$Vid;
			}
		}
        if (!($result = mysqli_query($link,$SQL))){
            echo "<h2>Težave z brisanjem - podatki niso zbrisani!</h2>";
        }
        $Vid="";
        $VVsebina = "";
        $VNaslov = "";
        $VDatum = "";
        $VTip = "Poročilo - drugo";
        $VTipID = 15;
        $VAvtor = $Ucitelj;
        $VEvidSt = "";
        break;
	case "5": //izpis poročila
		$SQL = "SELECT * FROM tabsola";
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VSola=$R["Sola"];
			$VNaslovSole=$R["Naslov"];
			$VKraj=$R["Kraj"];
		}else{
			$VSola=" ";
			$VNaslov=" ";
			$VKraj=" ";
		}
		
		$SQL = "SELECT TabZapisnik.*,tabzapisniktip.tip as ttip FROM TabZapisnik INNER JOIN tabzapisniktip ON TabZapisnik.tip=tabzapisniktip.id WHERE TabZapisnik.id=".$Vid;
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			$VLeto = $R["leto"];
			$VVsebina = $R["vsebina"];
			$VNaslov = $R["Naslov"];
			$VDatum = $R["Datum"];
			$VTip = $R["ttip"];
			$VTipID = $R["tip"];
			$VAvtor = $R["avtor"];
			$VEvidSt = $R["datoteka"];
            if ($R["zaupno"]){
                $zaupno="true";
            }else{
                $zaupno="false";
            }
		}
		
        if ($VLevel < 2 ){
            if ($R["vpisal"] != $VUporabnik ){
                if ($zaupno == "true"){
                    echo "Nimate pravice do ogleda!<br />";
                }else{
                    echo "<table border='0' width='700'>";
                    echo "<tr><td width=250><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
                    echo "</table>";
                    echo "<table border='0' width='700'>";
                    echo "<tr><td><h3>Datum: ".$VDatum."<br />Evid. št.: ".$VEvidSt."</h3></td>";
                    if ($zaupno=="true"){
                        echo "<td>ZAUPNO!</td>";
                    }
                    echo "</tr>";
                    echo "<tr><td><h3>Zadeva: ".$VNaslov."</h3></td></tr>";
                    /*
                    if (strlen($VFile) >0){
                        echo "<tr><td><font size=3>Za ogled poročila kliknite na spodnjo povezavo:<br />";
                        echo "<a href='dato/".$VFile."'>".$VFile."</a><br /><br /></font></td></tr>";
                    }
                    */
                    echo "<tr><td><font size='3'>".str_replace("\n","<br />",$VVsebina)."</font></td></tr>";
                    echo "<tr><td><h3>Zapisal/-a: ".$VAvtor."</h3></td></tr>";
                    echo "</table><br />";
                }
            }else{
                echo "<table border='0' width='700'>";
                echo "<tr><td width=250><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
                echo "</table>";
                echo "<table border='0' width='700'>";
                echo "<tr><td><h3>Datum: ".$VDatum."<br />Evid. št.: ".$VEvidSt."</h3></td>";
                if ($zaupno=="true"){
                    echo "<td>ZAUPNO!</td>";
                }
                echo "</tr>";
                echo "<tr><td><h3>Zadeva: ".$VNaslov."</h3></td></tr>";
                /*
                if (strlen($VFile) >0){
                    echo "<tr><td><font size=3>Za ogled poročila kliknite na spodnjo povezavo:<br />";
                    echo "<a href='dato/".$VFile."'>".$VFile."</a><br /><br /></font></td></tr>";
                }
                */
                echo "<tr><td><font size='3'>".str_replace("\n","<br />",$VVsebina)."</font></td></tr>";
                echo "<tr><td><h3>Zapisal/-a: ".$VAvtor."</h3></td></tr>";
                echo "</table><br />";
            }
        }else{
		    echo "<table border='0' width='700'>";
		    echo "<tr><td width=250><img src='logo1.gif' height=150></td><td align=center><h2>".$VSola."<br />".$VNaslovSole.", ".$VKraj."</h2></td></tr>";
		    echo "</table>";
		    echo "<table border='0' width='700'>";
            echo "<tr><td><h3>Datum: ".$VDatum."<br />Evid. št.: ".$VEvidSt."</h3></td>";
            if ($zaupno=="true"){
                echo "<td>ZAUPNO!</td>";
            }
            echo "</tr>";
		    echo "<tr><td><h3>Zadeva: ".$VNaslov."</h3></td></tr>";
            /*
		    if (strlen($VFile) >0){
			    echo "<tr><td><font size=3>Za ogled poročila kliknite na spodnjo povezavo:<br />";
			    echo "<a href='dato/".$VFile."'>".$VFile."</a><br /><br /></font></td></tr>";
		    }
            */
		    echo "<tr><td><font size='3'>".str_replace("\n","<br />",$VVsebina)."</font></td></tr>";
		    echo "<tr><td><h3>Zapisal/-a: ".$VAvtor."</h3></td></tr>";
		    echo "</table><br />";
        }
        break;
	case "6": //nastavi kljukice pri arhiviranih zapisnikih in poročilih
        if (isset($_POST["StZapisov"])){
		    $VStZapisov=$_POST["StZapisov"];
        }else{
            $VStZapisov=0;
        }
		
		for ($indx=1;$indx <= $VStZapisov;$indx++){
            $VZapis=$_POST["zapis".$indx];
            if (isset($_POST["pisno".$indx])){
				$SQL = "UPDATE TabZapisnik SET arhiv=true WHERE id=".$VZapis;
			}else{
				$SQL = "UPDATE TabZapisnik SET arhiv=false WHERE id=".$VZapis;
			}
			if (!($result = mysqli_query($link,$SQL))){
                echo "<h2>Težave z vpisom - podatki niso popravljeni</h2>";
            }
		}
        for ($indx=1;$indx <= $VStZapisov;$indx++){
            $VZapis=$_POST["zapis".$indx];
            if (isset($_POST["zaupno".$indx])){
                $SQL = "UPDATE TabZapisnik SET zaupno=true WHERE id=".$VZapis;
            }else{
                $SQL = "UPDATE TabZapisnik SET zaupno=false WHERE id=".$VZapis;
            }
            if (!($result = mysqli_query($link,$SQL))){
                echo "<h2>Težave z vpisom - podatki niso popravljeni</h2>$SQL <br />";
            }
        }
        $VVsebina = "";
        $VNaslov = "";
        $VDatum = "";
        $VTip = "Poročilo - drugo";
        $VTipID = 15;
        $VAvtor = $Ucitelj;
        $VEvidSt = "";
        $zaupno = "true";
        break;
	case "7":  //izpis iskanja
		echo "<form name='Iskanje' method=post action='VnosZapisnik.php'>";
		echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
		echo "<input name='vpis' type='hidden' value='7'>";
		echo "<input name='submit' type='submit' value='Išči'>";
		echo "</form>";
		
		echo "<h2>Spisek poročil/zapisnikov - ".$_POST["iskanje"]."</h2>";
		echo "<form name='arhiv' method='post' action='VnosZapisnik.php'>";
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Tip</th><th>Datum</th><th>Evid. št.</th><th>Avtor</th><th>Naslov</th><th>Poslano</th><th>Popravi</th><th>Briši</th><th>Oddano<br />natisnjeno</th><td>Zaupno</td></tr>";

		$SQL = "SELECT TabZapisnik.*,tabzapisniktip.tip as ttip FROM TabZapisnik INNER JOIN tabzapisniktip ON TabZapisnik.tip=tabzapisniktip.id WHERE ";
		$SQL = $SQL . "leto=".$VLeto." AND (";
		$SQL = $SQL . "tabzapisniktip.tip LIKE '%".$_POST["iskanje"]."%'";
		$SQL = $SQL . " OR TabZapisnik.avtor LIKE '%".$_POST["iskanje"]."%'";
		$SQL = $SQL . " OR TabZapisnik.datoteka LIKE '%".$_POST["iskanje"]."%'";
		$SQL = $SQL . " OR TabZapisnik.naslov LIKE '%".$_POST["iskanje"]."%')";
		$SQL = $SQL . " ORDER BY tabzapisniktip.tip,TabZapisnik.avtor";
		$result = mysqli_query($link,$SQL);

		$Indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$Indx."</td>";
			echo "<td>".$R["ttip"]."</td>";
			echo "<td align='right'>".$R["Datum"]."</td>";
			echo "<td>".$R["datoteka"]."</td>";
			echo "<td>".$R["avtor"]."</td>";
			echo "<td><a href='VnosZapisnik.php?vpis=5&id=".$R["id"]."' target='_blank'>".$R["Naslov"]."</a></td>";
            $Datum=new DateTime($R["cas"]);
			echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
			echo "<td><a href='VnosZapisnik.php?vpis=2&id=".$R["id"]."'>Popravi</a></td>";
			echo "<td><a href='VnosZapisnik.php?vpis=4&id=".$R["id"]."'>Briši</a></td>";
			if ($R["Arhiv"]){
				echo "<td><input name='zapis".$Indx."' type='hidden' value='".$R["id"]."'><input name='pisno".$Indx."' type='checkbox' checked='checked'></td>";
			}else{
				echo "<td><input name='zapis".$Indx."' type='hidden' value='".$R["id"]."'><input name='pisno".$Indx."' type='checkbox'></td>";
			}
            if ($R["zaupno"]){
                echo "<td><input name='zaupno".$Indx."' type='checkbox' checked='checked'></td>";
            }else{
                echo "<td><input name='zaupno".$Indx."' type='checkbox'></td>";
            }
			echo "</tr>";
			$Indx=$Indx+1;
		}
		echo "</table><br />";
		echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
		if ($VLevel > 1 ){
			echo "<input name='vpis' type='hidden' value='6'>";
			echo "<input name='submit' type='submit' value='Pošlji prejeto pisno'>";
		}
		echo "</form><br />";
        break;
	default:
        $VVsebina = "";
        $VNaslov = "";
        $VDatum = "";
        $VTip = "Poročilo - drugo";
        $VTipID = 15;
        $VAvtor = $Ucitelj;
        $VEvidSt = "";
        $zaupno = "true";
}

switch ($VVpis){
	case "5":
    case "7":
		echo "<br />";
        break;
	default:
	 	echo "<h2>Vnos zapisnika/poročila</h2>";
        echo "<form name='form_vnos' method='post' action='VnosZapisnik.php'>";
		/*
        echo "<form name='form_vnos' method='post' ENCTYPE='multipart/form-data' action='VpisZapisnik.php'>";
		echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
		echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
		echo "<input name='level' type='hidden' value='".$VLevel."'>";
        */
		echo "<table border='0'><tr>";

		echo "<td>Šolsko leto:</td><td><a href='VnosZapisnik.php?solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> ".$VLeto."/".($VLeto+1)." <a href='VnosZapisnik.php?solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a></td></tr>";
		echo "<tr><input type=hidden name='solskoleto' value='".$VLeto."'>";
		echo "<td>Tip:</td><td><select name='tip' onchange='javascript: tip_show(this.value)'>";

		$SQL = "SELECT * FROM tabzapisniktip ORDER BY tip";
		$result = mysqli_query($link,$SQL);

		while ($R = mysqli_fetch_array($result)){
			if ($VTipID==$R["id"] ){
				echo "<option value='".$R["id"]."' selected>".$R["tip"]."</option>";
			}else{
				echo "<option value='".$R["id"]."'>".$R["tip"]."</option>";
			}
		}
		echo "</select></td></tr>";
		echo "<tr><td>Naslov:</td><td><input name='naslov' type='text' size='40' value='".$VNaslov."'></td></tr>";
		echo "<tr><td>Datum:</td><td><input name='datum' type='text' size='10' value='".$VDatum."' id='dat01'></td></tr>";
        if (strlen($VEvidSt) > 0){
		    echo "<tr><td>Evid. št.:</td><td><input name='EvidSt' type='text' size='20' value='".$VEvidSt."'></td></tr>";
        }else{
            $VEvidSt="";
            /*
            $SQL = "SELECT id,datoteka FROM tabzapisnik WHERE leto=".$Danes->format('Y')." ORDER BY id";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                if (strlen($R["datoteka"]) > 0){
                    $i += 1;
                }
            }
            $VEvidSt="6007-".$i."/".$Danes->format('Y');
            */
            echo "<tr><td>Evid. št.:</td><td><input name='EvidSt' type='text' size='20' value='".$VEvidSt."'></td></tr>";
        }
		echo "<tr><td>Avtor:</td><td><input name='avtor' type='text' size='25' value='".$VAvtor."'></td></tr>";
        if ($zaupno == "true"){
            echo "<tr><td>Zaupno:</td><td><input name='zaupno' type='checkbox' checked='checked'></td></tr>";
        }else{
            echo "<tr><td>Zaupno:</td><td><input name='zaupno' type='checkbox'></td></tr>";
        }            
		echo "<input name='Povezava' type='hidden' value='/'>";
		echo "</table>";

		echo "<br /><b>Vsebina</b> (zgolj besedilo, brez urejanja (krepko,ležeče, ...) in tabel). <font color='red'>Besedilo ne sme vsebovati narekovajev (dvojnih in enojnih)!</font><br />";
		
		echo "<textarea id='txt1' name='vsebina' cols='80' rows='20'>".$VVsebina."</textarea><br />";
		if ($Vid != "" ){
			echo "<input type='hidden' name='vpis' value='3'>"; //'popravi
			echo "<input type='hidden' name='id' value='".$Vid."'>"; //'popravi
		}else{
			echo "<input type='hidden' name='vpis' value='2b'>"; //'nov vpis
		}
		echo "<input name='submit' type='submit' value='Pošlji'>";
		echo "</form><br /><br />";

		echo "<form name='Iskanje' method=post action='VnosZapisnik.php'>";
		echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
		echo "<input name='vpis' type='hidden' value='7'>";
		echo "<input name='submit' type='submit' value='Išči'>";
		echo "</form>";
		
		echo "<h2>Spisek poročil/zapisnikov</h2>";
		echo "<form name='arhiv' method='post' action='VnosZapisnik.php'>";
		echo "<table border=1>";
		echo "<tr><th>Št.</th><th>Tip</th><th>Datum</th><th>Evid. št.</th><th>Avtor</th><th>Naslov</th><th>Poslano</th><th width=30><img src='img/m_edit1.gif'></th><th width=30><img src='img/m_delete.gif'></th><th>Oddano<br />natisnjeno</th><th>Zaupno</th></tr>";

		$SQL = "SELECT TabZapisnik.*,tabzapisniktip.tip as ttip FROM TabZapisnik INNER JOIN tabzapisniktip ON TabZapisnik.tip=tabzapisniktip.id WHERE leto=".$VLeto." ORDER BY tabzapisniktip.tip,TabZapisnik.avtor";
		$result = mysqli_query($link,$SQL);

		$Indx=1;
        $color=true;
		while ($R = mysqli_fetch_array($result)){
            if ($color){
                echo "<tr bgcolor='lightgrey'>";
            }else{
                echo "<tr>";
            }
            $color=!$color;
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["ttip"]."</td>";
            echo "<td align='right'>".$R["Datum"]."</td>";
            echo "<td>".$R["datoteka"]."</td>";
            echo "<td>".$R["avtor"]."</td>";
            echo "<td><a href='VnosZapisnik.php?vpis=5&id=".$R["id"]."' target='_blank'>".$R["Naslov"]."</a></td>";
            $Datum=new DateTime($R["cas"]);
            echo "<td align=right>".$Datum->format('d.m.Y')."</td>";
            echo "<td align=center><a href='VnosZapisnik.php?vpis=2&id=".$R["id"]."'><img src='img/m_edit1.gif' border='0' alt='Vnesi/Popravi'></a></td>";
            echo "<td align=center><a href='VnosZapisnik.php?vpis=4&id=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
            if ($R["Arhiv"]){
                echo "<td align='center'><input name='zapis".$Indx."' type='hidden' value='".$R["id"]."'><input name='pisno".$Indx."' type='checkbox' checked></td>";
            }else{
                echo "<td align='center'><input name='zapis".$Indx."' type='hidden' value='".$R["id"]."'><input name='pisno".$Indx."' type='checkbox'></td>";
            }
            if ($R["zaupno"]){
                echo "<td align='center'><input name='zaupno".$Indx."' type='checkbox' checked></td>";
            }else{
                echo "<td align='center'><input name='zaupno".$Indx."' type='checkbox'></td>";
            }
			echo "</tr>";
			$Indx=$Indx+1;
		}
		echo "</table><br />";
		echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
		if ($VLevel > 1 ){
			echo "<input name='vpis' type='hidden' value='6'>";
			echo "<input name='submit' type='submit' value='Pošlji prejeto pisno'>";
		}
		echo "</form><br />";
}

?>
<script language="Javascript">
<!--
//-----------------------------------------------zamenjava tipov objekta glede na izbrano vrsto objekta

vrste_arr= new Array(20);
vrste_arr['1']='Aktiv: \n\nPrisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n' ;
vrste_arr['2']='Delovna skupina: \n\nPrisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['3']='Oddelek: \n\nPrisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['4']='Razred: \n\nPrisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['5']='Razred/skupina: \n\nPredmet: \n\nUčitelj: \n\nUspeh v kontrolni nalogi, ki se ponavlja:\n\nRazlogi za ponovitev:\n\n';
vrste_arr['6']='Prisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nKonferenca je bila zaključena ob:\n\n';
vrste_arr['7']='Nivojska skupina: \n\nPrisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['8']='';
vrste_arr['9']='Vrsta natečaja (literarni, glasbeni, likovni...)\n\nKdo je razpisal natečaj:\n\nVključeni učenci:\n\nVključeni učitelji:\n\nMorebitni dosežki:\n\n';
vrste_arr['10']='Datum prireditve:\n\nčas prireditve (od do):\n\nNaslov prireditve (npr. novoletna prireditev / oddelčna prireditev)\n\nOrganizator:\n\nKomu je bila namenjena (staršem in učencem cele šole / staršem oddelka / učencem cele šole):\n\nMorebitne posebnosti, sporočila, mnenja:\n\n';
vrste_arr['11']='Naslov športnega dneva: \n\nRazredi: \n\nVodja: \n\nSpremljevalci: \n\nPotek dejavnosti:\n\nPosebnosti:\n\nPedagoški zaključki:\n\nŠportni dan je bil zaključen ob:\n\n';
vrste_arr['12']='Naslov kulturnega dneva: \n\nRazredi: \n\nVodja: \n\nSpremljevalci: \n\nPotek dejavnosti:\n\nPosebnosti:\n\nPedagoški zaključki:\n\nKulturni dan je bil zaključen ob:\n\n';
vrste_arr['13']='Naslov naravoslovnega dneva: \n\nRazredi: \n\nVodja: \n\nSpremljevalci: \n\nPotek dejavnosti:\n\nPosebnosti:\n\nPedagoški zaključki:\n\nNaravoslovni dan je bil zaključen ob:\n\n';
vrste_arr['14']='Naslov tehničnega dneva: \n\nRazredi: \n\nVodja: \n\nSpremljevalci: \n\nPotek dejavnosti:\n\nPosebnosti:\n\nPedagoški zaključki:\n\nTehniški dan je bil zaključen ob:\n\n';
vrste_arr['15']='';
vrste_arr['16']='Prisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['17']='Tema izobraževanja: \n\nCiljna skupina: \n\nUdeleženci: \n\nKratek opis predavane vsebine:\n\nPosebnosti:\n\nIzobraževanje je bilo zaključeno ob:\n\n';
vrste_arr['18']='Prisotni: \n\nOdsotni: \n\nDnevni red:\n\nRazprava k točkam dnevnega reda:\n\nSklepi:\n\nPosebnosti:\n\nSestanek je bil zaključen ob:\n\n';
vrste_arr['19']='Plavalna:\n\nZačetno stanje plavalcev\n\nKončno stanje plavalcev\n\nZimska:\n\nZačetno stanje smučarjev:\n\nKončno stanje smučarjev:\n\nVodja:\n\nUčitelji spremljevalci:\n\n';
vrste_arr['20']='Projekt je mednarodni/državni/šolski\n\nKdo je razpisal projekt:\n\nVključeni učenci (vsaj število po razredih)\n\nVodja projekta:\n\nVključeni učitelji\n\nKratek opis projekta:\n\nTrajanje projekta:\n\nS projektom bomo nadaljevali / bomo zaključili\n\n';
vrste_arr['21']='Datum:\n\nMentor:\n\nIme in priimek učenca (učencev), ki je (so) naredil(i) raziskovalno nalogo:\n\nRazred, oddelek:\n\nnaslov raziskovalne naloge:\n\nPodročje:\n\nMorebitni dosežki:\n\n';
vrste_arr['22']='';

function tip_show(sifra_vrsta) {
//	document.form_vnos.avtor.value='Novi avtor';
    var l;
    l = document.getElementById('txt1').value;
    if (l.length < 300){
	    document.getElementById('txt1').value=vrste_arr[sifra_vrsta];
    }
}
//-->
</script>

</body>
</html>
