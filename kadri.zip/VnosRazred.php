<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Vnos razredov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";

    if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{
        if (isset($_POST["id"])){
            $Vid=$_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid="";
            }
        }
        if (isset($_POST["zapis"])){
            $Vzapis=$_POST["zapis"];
        }else{
            if (isset($_GET["zapis"])){
                $Vzapis=$_GET["zapis"];
            }else{
                $Vzapis="";
            }
        }

        switch ($Vid){
	        case "1": // 'vpis podatkov
		        $VRazred=$_POST["razred"];
		        $VParalelka=$_POST["paralelka"];
		        $VProstor=$_POST["prostor"];
                $VIdSola=$_POST["idsola"];
		        $SQL = "SELECT * FROM tabrazdat WHERE razred=".$VRazred." AND oznaka='".$VParalelka."' AND idsola=".$VIdSola." AND leto=".$VLeto;
		        $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
			        echo "<h1>Ta razred je že vpisan!</h1>";
		        }else{
			        $SQL = "INSERT INTO tabrazdat (leto,razred,oznaka,prostor,osemdevet,idsola) VALUES (";
			        $SQL = $SQL . $VLeto;
			        $SQL = $SQL . ",".$VRazred;
			        $SQL = $SQL . ",'".$VParalelka."'";
			        $SQL = $SQL . ",".$VProstor;
			        $SQL = $SQL . ",9";
                    $SQL = $SQL . ",".$VIdSola;
			        $SQL = $SQL . ")";
			        if ($result = mysqli_query($link,$SQL)){
				        echo "Nov razred je vpisan!<br />";
			        }else{
				        echo "Težave pri vpisu: ".$SQL."<br />";
			        }
		        }
                break;
	        case "2": // 'brisanje
		        echo "Z brisanjem razreda boste odstranili tudi vse podatke, ki se nanašajo na ta razred:<br />";
		        echo "- podatke o učencih v tem razredu za to šolsko leto<br />";
		        echo "- podatke o dnevih dejavnosti in taborih<br />";
		        echo "- podatke o sodelovanju s starši<br />";
		        echo "- podatke o nadomeščanjih<br />";
		        echo "- podatke o vpisanih preverjanjih znanja<br />";
		        echo "- podatke o polletnih in letnih poročilih razrednikov<br />";
		        echo "- podatke o realizaciji<br />";
		        echo "- podatke o sistematizaciji<br />";
		        echo "- podatke v urniku<br />";
		        echo "<br />";
		        echo "<h2>Mogoče želite le popraviti podatke? (<a href='VnosRazred.php?id=3&zapis=".$Vzapis."'>popravi</a>)</h2>";
		        echo "<h1><a href='VnosRazred.php?id=2a&zapis=".$Vzapis."'>Dokončno zbriši razred</a> (Bili ste opozorjeni!)</h1>";
                break;
	        case "2a": //dokončno brisanje razreda
		        $SQL = "DELETE FROM tabrazdat WHERE id=".$Vzapis;
		        if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
		            echo "Razred je zbrisan!<br />";
                }

                $SQL = "DELETE FROM tabrazred WHERE idrazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Razred je zbrisan!<br />";
                }

		        $SQL = "DELETE FROM TabOstaleDej WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Dnevi dejavnosti so zbrisani!<br />";
                }
		        
		        $SQL = "DELETE FROM TabGUDatum WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Sodelovanje s starši je zbrisano!<br />";
                }

		        $SQL = "DELETE FROM TabNadomescanja WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Nadomeščanja so zbrisana!<br />";
                }

		        $SQL = "DELETE FROM TabPreverjanje WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Datumi preverjanj so zbrisani!<br />";
                }
		        
		        $SQL = "DELETE FROM TabRazrednikPor WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Polletno poročilo je zbrisano!<br />";
                }
		        
		        $SQL = "DELETE FROM TabRazrednikPorK WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Končno poročilo je zbrisano!<br />";
                }
		        
		        $SQL = "DELETE FROM TabRealizacija WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Realizacija za razred je zbrisana!<br />";
                }
		        
		        $SQL = "DELETE FROM TabTaborData WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Podatki o taboru so zbrisani!<br />";
                }
		        
		        $SQL = "DELETE FROM tabucenje WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Podatki v sistemizaciji so zbrisani!<br />";
                }
		        
		        $SQL = "DELETE FROM taburnik WHERE idRazred=".$Vzapis;
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri brisanju!<br />$SQL<br />");
                }else{
                    echo "Podatki v urniku so zbrisani!<br />";
                }
                break;
	        case "3": // 'popravi
		        $SQL = "SELECT tabrazdat.*,tabprostor.Oznaka AS poznaka,tabprostor.StMiz,tabprostor.IdProstor,tabprostor.Opis FROM ";
		        $SQL = $SQL . "tabrazdat INNER JOIN tabprostor ON tabrazdat.Prostor=tabprostor.IdProstor ";
		        $SQL = $SQL . "WHERE tabrazdat.id=".$Vzapis;
		        $result = mysqli_query($link,$SQL);
		        
                if ($R = mysqli_fetch_array($result)){
			        echo "<h2>Popravljanje razrednih podatkov</h2>";
			        echo "<table>";
			        echo "<tr>";
			        echo "<th>Leto</th>";
			        echo "<th>Razred</th>";
			        echo "<th>Paralelka</th>";
			        echo "<th>Matična učilnica</th>";
                    echo "<th>Šola/podružnica/program</th>";
			        echo "<th>Popravi</th>";
			        echo "</tr>";

			        echo "<tr>";
			        echo "<td>";
			        echo "<form name='razredi' method='post' action='VnosRazred.php'>";
			        echo $R["leto"]."/".($R["leto"]+1)."</td>";
			        echo "<td>";
			        echo "<select name='razred' type='text'>";
			        for ($indx=0;$indx <= 9;$indx++){
				        if ($R["razred"]==$indx){
					        echo "<option value='".$indx."' selected='selected'>".$indx."</option>";
				        }else{
					        echo "<option value='".$indx."'>".$indx."</option>";
				        }
			        }
			        echo "</select>";
			        echo "</td>";
			        echo "<td><input type='text' name='paralelka' size='5' value='".$R["oznaka"]."'></td>";
			        echo "<td>";
			        $VProstor=$R["prostor"];
                    
			        echo "<select name='prostor'>";
			        $SQL = "SELECT * FROM tabprostor WHERE StMiz > 10";
			        $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
				        if ($VProstor==$R1["IdProstor"]){
					        echo "<option value='".$R1["IdProstor"]."' selected='selected'>".$R1["Oznaka"]." (".$R1["Stevilka"].") - ".$R1["Opis"]."</option>";
				        }else{
					        echo "<option value='".$R1["IdProstor"]."'>".$R1["Oznaka"]." (".$R1["Stevilka"].") - ".$R1["Opis"]."</option>";
				        }
			        }
			        echo "</select>";
			        echo "</td>";
                    
                    //izbira šole/podružnice/programa
                    $VIdSola=$R["idsola"];
                    echo "<td>";
                    echo "<select name='idsola'>";
                    $SQL = "SELECT tabsola.id,tabsola.solakratko,tabsola.naslov,tabprogram.opis FROM tabsola INNER JOIN tabprogram ON tabsola.program=tabprogram.sifra ORDER BY id";
                    $result1 = mysqli_query($link,$SQL);
                    while ($R1 = mysqli_fetch_array($result1)){
                        if ($VIdSola == $R1["id"]){
                            echo "<option value='".$R1["id"]."' selected='selected'>".$R1["solakratko"].", ".$R1["naslov"]." (".$R1["opis"].")</option>";
                        }else{
                            echo "<option value='".$R1["id"]."'>".$R["solakratko"].", ".$R1["naslov"]." (".$R1["opis"].")</option>";
                        }
                    }
                    echo "</select>";
                    echo "</td>";
                    
			        echo "<td><input type='hidden' name='id' value='4'><input name='zapis' type='hidden' value='".$Vzapis."'><input type='submit' name='submit' value='Popravi'></form></td>";
			        echo "</tr>";
			        echo "</table>";
		        }else{
			        echo "<h1>Zapis ne obstaja!</h1>";
		        }
	            break;
	        case "4": // 'vpis popravka
		        $VRazred=$_POST["razred"];
		        $VParalelka=$_POST["paralelka"];
		        $VProstor=$_POST["prostor"];
                $VIdSola=$_POST["idsola"];
		        $SQL = "SELECT * FROM tabrazdat WHERE razred=".$VRazred." AND oznaka='".$VParalelka."' AND idsola=".$VIdSola." AND leto=".$VLeto;
		        $result = mysqli_query($link,$SQL);
	            if ($R = mysqli_fetch_array($result)){
    		        if ($Vzapis != $R["id"]){
				        echo "<h1>Ta razred je že vpisan drugje!</h1>";
			        }else{
				        $SQL = "UPDATE tabrazdat SET ";
				        $SQL = $SQL . "prostor=".$VProstor;
				        $SQL = $SQL . " WHERE id=".$Vzapis;
				        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabrazdat) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabrazdat) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabRazred SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabrazred) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabrazred) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabOstaleDej SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabostaledej) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabostaledej) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabGUDatum SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabgudatum) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabgudatum) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabNadomescanja SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabnadomescanja) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabnadomescanja) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabPreverjanje SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabpreverjanje) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabpreverjanje) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabRazrednikPor SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabrazrednikpor) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabrazrednikpor) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabRazrednikPorK SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabrazrednikpork) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabrazrednikpork) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabRealizacija SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabrealizacija) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabrealizacija) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE TabTaborData SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabtabordata) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabtabordata) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE tabucenje SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (tabucenje) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (tabucenje) - NI popravljeno!<br />";
                        }
				        
				        $SQL = "UPDATE taburnik SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                        if ($result = mysqli_query($link,$SQL)){
                            echo "Podatki o razredu (taburnik) so popravljeni.<br />";
                        }else{
                            echo "Težave pri vpisu (taburnik) - NI popravljeno!<br />";
                        }
				        
				        //echo "<h1>Podatki so spremenjeni!</h1>";
			        }
		        }else{
			        $SQL = "UPDATE tabrazdat SET ";
			        $SQL = $SQL . "razred=".$VRazred;
			        $SQL = $SQL . ",oznaka='".$VParalelka."'";
			        $SQL = $SQL . ",prostor=".$VProstor;
			        $SQL = $SQL . " WHERE id=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabrazdat) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabrazdat) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabRazred SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabrazred) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabrazred) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabOstaleDej SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabostaledej) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabostaledej) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabGUDatum SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabgudatum) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabgudatum) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabNadomescanja SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabnadomescanja) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabnadomescanja) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabPreverjanje SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabpreverjanje) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabpreverjanje) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabRazrednikPor SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabrazrednikpor) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabrazrednikpor) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabRazrednikPorK SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabrazrednikpork) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabrazrednikpork) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabRealizacija SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabrealizacija) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabrealizacija) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE TabTaborData SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabtabordata) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabtabordata) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE tabucenje SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (tabucenje) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (tabucenje) - NI popravljeno!<br />";
                    }
                    
                    $SQL = "UPDATE taburnik SET razred=".$VRazred.",paralelka='".$VParalelka."' WHERE idRazred=".$Vzapis;
                    if ($result = mysqli_query($link,$SQL)){
                        echo "Podatki o razredu (taburnik) so popravljeni.<br />";
                    }else{
                        echo "Težave pri vpisu (taburnik) - NI popravljeno!<br />";
                    }
		        }
        }

        if (($Vid=="1") or ($Vid=="4") or ($Vid=="")){
	        echo "<h2>Vnos razredov</h2>";
	        echo "<table>";
	        echo "<tr>";
	        echo "<th>Leto</th>";
	        echo "<th>Razred</th>";
	        echo "<th>Paralelka</th>";
	        echo "<th>Matična učilnica</th>";
            echo "<th>Šola/podružnica/program</th>";
	        echo "<th>Briši</th>";
	        echo "<th>Popravi</th>";
	        echo "<th>Učenci</th>";
	        echo "</tr>";

	        echo "<tr>";
	        echo "<td>";
	        echo "<form name='razredi' method='post' action='VnosRazred.php'>";
	        echo $VLeto."/".($VLeto+1)."</td>";
	        echo "<td>";
	        echo "<select name='razred' type='text'>";
	        for ($indx=0;$indx<= 9;$indx++){
		        echo "<option value='".$indx."'>".$indx."</option>";
	        }
	        echo "</select>";
	        echo "</td>";
	        echo "<td><input type='text' name='paralelka' size='5'></td>";
	        echo "<td>";
	        echo "<select name='prostor'>";
	        $SQL = "SELECT * FROM tabprostor WHERE StMiz > 2";
            echo "<option value='0'>Nedoločen</option>";
	        $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
	            echo "<option value='".$R["IdProstor"]."'>".$R["Oznaka"]." (".$R["Stevilka"].") - ".$R["Opis"]."</option>";
	        }
	        echo "</select>";
	        echo "</td>";
            //izbira šole/podružnice/programa
            echo "<td>";
            echo "<select name='idsola'>";
            $SQL = "SELECT tabsola.id,tabsola.solakratko,tabsola.naslov,tabprogram.opis FROM tabsola INNER JOIN tabprogram ON tabsola.program=tabprogram.sifra ORDER BY id";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["solakratko"].", ".$R["naslov"]." (".$R["opis"].")</option>";
            }
            echo "</select>";
            echo "</td>";

	        echo "<td>&nbsp;</td>";
	        echo "<td><input type='hidden' name='id' value='1'><input type='submit' name='submit' value='Dodaj'></form></td>";
	        echo "</tr>";

	        $SQL = "SELECT tabrazdat.*,tabprostor.oznaka AS poznaka,tabprostor.Stevilka,tabprostor.Opis,tabsola.solakratko FROM ";
	        $SQL = $SQL . "(tabrazdat INNER JOIN tabprostor ON tabrazdat.Prostor=tabprostor.idProstor) ";
            $SQL = $SQL . "INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id ";
	        $SQL = $SQL . "WHERE leto=".$VLeto." ORDER BY tabrazdat.razred,tabrazdat.oznaka";
	        $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
		        echo "<tr>";
		        echo "<th>".$R["leto"]."/".($R["leto"]+1)."</th>";
		        echo "<th>".$R["razred"]."</th>";
		        echo "<th>".$R["oznaka"]."</th>";
		        echo "<th>".$R["poznaka"]." (".$R["Stevilka"].") - ".$R["Opis"]."</th>";
                echo "<th>".$R["solakratko"]."</th>";
		        echo "<th><a href='VnosRazred.php?id=2&zapis=".$R["id"]."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></th>";
		        echo "<th><a href='VnosRazred.php?id=3&zapis=".$R["id"]."'><img src='img/m_edit1.gif' border='0' alt='Vnesi/Popravi'></a></th>";
		        echo "<th><a href='izpisrazreda.php?solskoleto=".$VLeto."&razred=".$R["id"]."'><img src='img/m_group.gif' border='0' alt='Poglej učence'></a></th>";
		        echo "</tr>";
	        }

	        echo "</table><br />";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>
</body>
</html>
