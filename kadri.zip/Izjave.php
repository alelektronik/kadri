<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}

if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izjave
</title>
</head>
<body>
<?php

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (isset($_POST["ucitelj"])){
    $Ucitelj = $_POST["ucitelj"];
}else{
    if (isset($_GET["ucitelj"])){
        $Ucitelj = $_GET["ucitelj"];
    }else{
        if (isset($_SESSION["ucitelj"])){ 
            $Ucitelj = $_SESSION["ucitelj"];
        }else{
            $Ucitelj = $UciteljComp;
        }
    }
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$VFile="VarovanjePodatkov.rtf";
$MyFile = "dato".$FileSep.$VFile;
$fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");

function ToRTF($txt){
    $txt=str_replace("Č","\\'c8",$txt);
    $txt=str_replace("č","\\'e8",$txt);
    $txt=str_replace("Š","\\'8a",$txt);
    $txt=str_replace("š","\\'9a",$txt);
    $txt=str_replace("Ž","\\'8e",$txt);
    $txt=str_replace("ž","\\'9e",$txt);
    $txt=str_replace("Ć","\\'c6",$txt);
    $txt=str_replace("ć","\\'e6",$txt);
    $txt=str_replace("Đ","\\'d0",$txt);
    $txt=str_replace("đ","\\'f0",$txt);
    $txt=str_replace("é","\\'e9",$txt);
    $txt=str_replace("É","\\'c9",$txt);
    $txt=str_replace("ö","\\'f6",$txt);
    $txt=str_replace("Ö","\\'d6",$txt);
    $txt=str_replace(chr(226).chr(128).chr(147),"\\'2d",$txt);
    return $txt;
}
$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VRavnatelj=$R["Ravnatelj"];
    $VKraj=$R["Kraj"];
    $VKrajSola=$R["Kraj"];
    $VNaslov=$R["Naslov"];
    $VPosta=$R["Posta"]." ".$VKraj;
}else{
    $VSola=" ";
    $VRavnatelj=" ";
    $VKraj=" ";
    $VNaslov=" ";
    $VPosta=" ";
}
if (isset($_POST["submit"])){
    if ($_POST["submit"]=="Izjava"){
        $VIzjava=true;
    }else{
        $VIzjava=false;
    }
}else{
    $VIzjava=false;
}
if ($VIzjava){
    $StZapisov=$_POST["StZapisov"];

    fwrite ($fh,"{\\rtf1\\adeflang1025\\ansi\\ansicpg1250\\uc1\\adeff31507\\deff0\\stshfdbch31506\\stshfloch31506\\stshfhich31506\\stshfbi31507\\deflang1060\\deflangfe1060\\themelang1060\\themelangfe0\\themelangcs0{\\fonttbl{\\f0\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f34\\fbidi \\froman\\fcharset1\\fprq2{\\*\\panose 02040503050406030204}Cambria Math;}");
    fwrite ($fh,"{\\f37\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}{\\flomajor\\f31500\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}");
    fwrite ($fh,"{\\fdbmajor\\f31501\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fhimajor\\f31502\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02040503050406030204}Cambria;}");
    fwrite ($fh,"{\\fbimajor\\f31503\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\flominor\\f31504\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}");
    fwrite ($fh,"{\\fdbminor\\f31505\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\fhiminor\\f31506\\fbidi \\fswiss\\fcharset238\\fprq2{\\*\\panose 020f0502020204030204}Calibri;}");
    fwrite ($fh,"{\\fbiminor\\f31507\\fbidi \\froman\\fcharset238\\fprq2{\\*\\panose 02020603050405020304}Times New Roman;}{\\f41\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\f40\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
    fwrite ($fh,"{\\f42\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\f43\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\f44\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\f45\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
    fwrite ($fh,"{\\f46\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\f47\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\f411\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}{\\f410\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}");
    fwrite ($fh,"{\\f412\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\f413\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}{\\f416\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}{\\f417\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}");
    fwrite ($fh,"{\\flomajor\\f31510\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flomajor\\f31509\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\flomajor\\f31511\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}");
    fwrite ($fh,"{\\flomajor\\f31512\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flomajor\\f31513\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\flomajor\\f31514\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
    fwrite ($fh,"{\\flomajor\\f31515\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flomajor\\f31516\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fdbmajor\\f31520\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}");
    fwrite ($fh,"{\\fdbmajor\\f31519\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbmajor\\f31521\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fdbmajor\\f31522\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}");
    fwrite ($fh,"{\\fdbmajor\\f31523\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbmajor\\f31524\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fdbmajor\\f31525\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}");
    fwrite ($fh,"{\\fdbmajor\\f31526\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhimajor\\f31530\\fbidi \\froman\\fcharset0\\fprq2 Cambria;}{\\fhimajor\\f31529\\fbidi \\froman\\fcharset204\\fprq2 Cambria Cyr;}");
    fwrite ($fh,"{\\fhimajor\\f31531\\fbidi \\froman\\fcharset161\\fprq2 Cambria Greek;}{\\fhimajor\\f31532\\fbidi \\froman\\fcharset162\\fprq2 Cambria Tur;}{\\fhimajor\\f31535\\fbidi \\froman\\fcharset186\\fprq2 Cambria Baltic;}");
    fwrite ($fh,"{\\fhimajor\\f31536\\fbidi \\froman\\fcharset163\\fprq2 Cambria (Vietnamese);}{\\fbimajor\\f31540\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fbimajor\\f31539\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
    fwrite ($fh,"{\\fbimajor\\f31541\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbimajor\\f31542\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fbimajor\\f31543\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}");
    fwrite ($fh,"{\\fbimajor\\f31544\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbimajor\\f31545\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fbimajor\\f31546\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}");
    fwrite ($fh,"{\\flominor\\f31550\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\flominor\\f31549\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\flominor\\f31551\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}");
    fwrite ($fh,"{\\flominor\\f31552\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\flominor\\f31553\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\flominor\\f31554\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}");
    fwrite ($fh,"{\\flominor\\f31555\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\flominor\\f31556\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fdbminor\\f31560\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}");
    fwrite ($fh,"{\\fdbminor\\f31559\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}{\\fdbminor\\f31561\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fdbminor\\f31562\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}");
    fwrite ($fh,"{\\fdbminor\\f31563\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}{\\fdbminor\\f31564\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fdbminor\\f31565\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}");
    fwrite ($fh,"{\\fdbminor\\f31566\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}{\\fhiminor\\f31570\\fbidi \\fswiss\\fcharset0\\fprq2 Calibri;}{\\fhiminor\\f31569\\fbidi \\fswiss\\fcharset204\\fprq2 Calibri Cyr;}");
    fwrite ($fh,"{\\fhiminor\\f31571\\fbidi \\fswiss\\fcharset161\\fprq2 Calibri Greek;}{\\fhiminor\\f31572\\fbidi \\fswiss\\fcharset162\\fprq2 Calibri Tur;}{\\fhiminor\\f31575\\fbidi \\fswiss\\fcharset186\\fprq2 Calibri Baltic;}");
    fwrite ($fh,"{\\fhiminor\\f31576\\fbidi \\fswiss\\fcharset163\\fprq2 Calibri (Vietnamese);}{\\fbiminor\\f31580\\fbidi \\froman\\fcharset0\\fprq2 Times New Roman;}{\\fbiminor\\f31579\\fbidi \\froman\\fcharset204\\fprq2 Times New Roman Cyr;}");
    fwrite ($fh,"{\\fbiminor\\f31581\\fbidi \\froman\\fcharset161\\fprq2 Times New Roman Greek;}{\\fbiminor\\f31582\\fbidi \\froman\\fcharset162\\fprq2 Times New Roman Tur;}{\\fbiminor\\f31583\\fbidi \\froman\\fcharset177\\fprq2 Times New Roman (Hebrew);}");
    fwrite ($fh,"{\\fbiminor\\f31584\\fbidi \\froman\\fcharset178\\fprq2 Times New Roman (Arabic);}{\\fbiminor\\f31585\\fbidi \\froman\\fcharset186\\fprq2 Times New Roman Baltic;}{\\fbiminor\\f31586\\fbidi \\froman\\fcharset163\\fprq2 Times New Roman (Vietnamese);}}");
    fwrite ($fh,"{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;");
    fwrite ($fh,"\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;\\red0\\green112\\blue192;}{\\*\\defchp \\f31506\\fs22\\lang1060\\langfe1033\\langfenp1033 }{\\*\\defpap \\ql \\li0\\ri0\\sa200\\sl276\\slmult1");
    fwrite ($fh,"\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 }\\noqfpromote {\\stylesheet{\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 ");
    fwrite ($fh,"\\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\snext0 \\sqformat \\spriority0 \\styrsid84957 Normal;}{\\*\\cs10 \\additive \\ssemihidden \\sunhideused \\spriority1 Default Paragraph Font;}{\\*");
    fwrite ($fh,"\\ts11\\tsrowd\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblind0\\tblindtype3\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv \\ql \\li0\\ri0\\sa200\\sl276\\slmult1");
    fwrite ($fh,"\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\snext11 \\ssemihidden \\sunhideused Normal Table;}{\\*\\ts15\\tsrowd");
    fwrite ($fh,"\\trbrdrt\\brdrs\\brdrw10 \\trbrdrl\\brdrs\\brdrw10 \\trbrdrb\\brdrs\\brdrw10 \\trbrdrr\\brdrs\\brdrw10 \\trbrdrh\\brdrs\\brdrw10 \\trbrdrv\\brdrs\\brdrw10 ");
    fwrite ($fh,"\\trftsWidthB3\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblind0\\tblindtype3\\tsvertalt\\tsbrdrt\\tsbrdrl\\tsbrdrb\\tsbrdrr\\tsbrdrdgl\\tsbrdrdgr\\tsbrdrh\\tsbrdrv ");
    fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 \\sbasedon11 \\snext15 \\spriority59 \\styrsid8614247 ");
    fwrite ($fh,"Table Grid;}}{\\*\\rsidtbl \\rsid84957\\rsid284499\\rsid8614247}{\\mmathPr\\mmathFont34\\mbrkBin0\\mbrkBinSub0\\msmallFrac0\\mdispDef1\\mlMargin0\\mrMargin0\\mdefJc1\\mwrapIndent1440\\mintLim0\\mnaryLim1}{\\info");
    fwrite ($fh,"{\\creatim\\yr2013\\mo7\\dy8\\hr11\\min18}{\\revtim\\yr2013\\mo7\\dy8\\hr11\\min28}{\\version1}{\\edmins10}{\\nofpages1}{\\nofwords66}{\\nofchars382}{\\nofcharsws447}{\\vern49275}}{\\*\\xmlnstbl {\\xmlns1 http://schemas.microsoft.com/office/word/2003/wordml}}");
    fwrite ($fh,"\\paperw11906\\paperh16838\\margl1417\\margr1417\\margt1417\\margb1417\\gutter0\\ltrsect ");
    fwrite ($fh,"\\deftab708\\widowctrl\\ftnbj\\aenddoc\\hyphhotz425\\trackmoves0\\trackformatting1\\donotembedsysfont1\\relyonvml0\\donotembedlingdata0\\grfdocevents0\\validatexml1\\showplaceholdtext0\\ignoremixedcontent0\\saveinvalidxml0");
    fwrite ($fh,"\\showxmlerrors1\\noxlattoyen\\expshrtn\\noultrlspc\\dntblnsbdb\\nospaceforul\\formshade\\horzdoc\\dgmargin\\dghspace180\\dgvspace180\\dghorigin1417\\dgvorigin1417\\dghshow1\\dgvshow1");
    fwrite ($fh,"\\jexpand\\viewkind1\\viewscale150\\pgbrdrhead\\pgbrdrfoot\\splytwnine\\ftnlytwnine\\htmautsp\\nolnhtadjtbl\\useltbaln\\alntblind\\lytcalctblwd\\lyttblrtgr\\lnbrkrule\\nobrkwrptbl\\snaptogridincell\\allowfieldendsel\\wrppunct");
    fwrite ($fh,"\\asianbrkrule\\rsidroot8614247\\newtblstyruls\\nogrowautofit\\usenormstyforlist\\noindnmbrts\\felnbrelev\\nocxsptable\\indrlsweleven\\noafcnsttbl\\afelev\\utinl\\hwelev\\spltpgpar\\notcvasp\\notbrkcnstfrctbl\\notvatxbx\\krnprsnet\\cachedcolbal \\nouicompat \\fet0");
    fwrite ($fh,"{\\*\\wgrffmtfilter 2450}\\nofeaturethrottle1\\ilfomacatclnup0\\ltrpar \\sectd \\ltrsect\\linex0\\headery708\\footery708\\colsx708\\endnhere\\sectlinegrid360\\sectdefaultcl\\sftnbj {\\*\\pnseclvl1\\pnucrm\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl2");
    fwrite ($fh,"\\pnucltr\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl3\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxta .}}{\\*\\pnseclvl4\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxta )}}{\\*\\pnseclvl5\\pndec\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl6");
    fwrite ($fh,"\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl7\\pnlcrm\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl8\\pnlcltr\\pnstart1\\pnindent720\\pnhang {\\pntxtb (}{\\pntxta )}}{\\*\\pnseclvl9\\pnlcrm\\pnstart1\\pnindent720\\pnhang ");
    fwrite ($fh,"{\\pntxtb (}{\\pntxta )}}");

    for ($IndxZapis=1;$IndxZapis <= $StZapisov;$IndxZapis++){
        if (isset($_POST["prevzemnica_".$IndxZapis])){
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($_POST["ucitelj_".$IndxZapis],$Danes->format('Y'),$VLeto);
            $SQL = "SELECT TabIzjave.*,tabucitelji.* FROM TabIzjave ";
            $SQL = $SQL . "INNER JOIN tabucitelji ON TabIzjave.idUcitelj=tabucitelji.idUcitelj ";
            $SQL = $SQL . "WHERE TabIzjave.idUcitelj=".$_POST["ucitelj_".$IndxZapis];
            $SQL = $SQL . " ORDER BY tabucitelji.priimek,tabucitelji.ime";
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $VZavod = "";   // 'zavod
                $VObdobje = $oUcitelj->getDelMesto();
                $VMentor = $R["Ime"]." ".$R["Priimek"];
                $VKraj = $VKrajSola.", ".$Danes->format('d.m.Y');
                $VPriznanje = "";  //  'potrdilo
                $VLine1 = "Podpisani:";
                if ($R["Spol"]=="M"){
                    $VLine2 = "Rojen:";
                    $VLine3 = "Stanujoč:";
                    $VLine5 = "";
                }else{
                    $VLine2 = "Rojena:";
                    $VLine3 = "Stanujoča:";
                    $VLine5 = "";
                }
                $VNasl=$R["Naslov"].", ".$R["Kraj"];
                
                $VLine4 = "Na delovnem mestu";
                $VLine6 = "";
                $VLine7 = "";
                $VDejavnost = "Izjavljam";
                $VPotrdilo = "IZJAVA O VAROVANJU PODATKOV";
                $VOpombe = "";
                $VClen = "";
                $VDatRoj=new DateTime(isDate($R["DatRoj"]));
                if ($R["Spol"]=="M"){
                    $VVsebina=ToRTF("da sem seznanjen, da je po določilih Kazenskega zakonika RS kakršnokoli dajanje podatkov iz baz podatkov, ki jih na šoli uporabljamo za zbiranje podatkov in vodenje evidenc v skladu z zakonodajo, nepooblaščenim osebam kaznivo dejanje izdajanja zaupnih podatkov.");
                }else{
                    $VVsebina=ToRTF("da sem seznanjena, da je po določilih Kazenskega zakonika RS kakršnokoli dajanje podatkov iz baz podatkov, ki jih na šoli uporabljamo za zbiranje podatkov in vodenje evidenc v skladu z zakonodajo, nepooblaščenim osebam kaznivo dejanje izdajanja zaupnih podatkov.");
                }
                if (isDate($R["DatVarPod"])){
                    $VDatVarPod=$R["DatVarPod"];
                }else{
                    $VDatVarPod=$Danes->format('d.m.Y');
                }
                
                fwrite ($fh,"\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 ");
                fwrite ($fh,"\\af31507 \\ltrch\\fcs0 \\insrsid8614247 ".ToRTF($VSola)."}{\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid284499 ");
                fwrite ($fh,"\\par }{\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ".ToRTF($VNaslov));
                fwrite ($fh,"\\par ".ToRTF($VPosta));
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ".$VDatVarPod);
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8614247 {\\rtlch\\fcs1 \\af31507\\afs36 \\ltrch\\fcs0 \\b\\fs36\\cf17\\insrsid8614247\\charrsid8614247 ".ToRTF($VPotrdilo));
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par \\ltrrow}\\trowd \\irow0\\irowband0\\ltrrow\\ts15\\trgaph70\\trleft-108\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid8614247\\tbllkhdrrows\\tbllkhdrcols\\tbllknocolband\\tblind0\\tblindtype3 ");
                fwrite ($fh,"\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2802\\clshdrawnil \\cellx2694\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl ");
                fwrite ($fh,"\\cltxlrtb\\clftsWidth3\\clwWidth6410\\clshdrawnil \\cellx9104\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sb120\\sa120\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8614247\\yts15 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 ");
                fwrite ($fh,"\\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 ".$VLine1."}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247 :}{\\rtlch\\fcs1 \\af31507\\afs28 ");
                fwrite ($fh,"\\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\cell }{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\b\\fs28\\insrsid8614247\\charrsid8614247 ".ToRTF($VMentor)."\\cell }\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sa200\\sl276\\slmult1");
                fwrite ($fh,"\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 ");
                fwrite ($fh,"\\fs28\\insrsid8614247\\charrsid8614247 \\trowd \\irow0\\irowband0\\ltrrow");
                fwrite ($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid8614247\\tbllkhdrrows\\tbllkhdrcols\\tbllknocolband\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl");
                fwrite ($fh,"\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2802\\clshdrawnil \\cellx2694\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth6410\\clshdrawnil \\cellx9104\\row \\ltrrow");
                fwrite ($fh,"}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sb120\\sa120\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8614247\\yts15 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {");
                fwrite ($fh,"\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 ".$VLine2."}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\cell }{\\rtlch\\fcs1 ");
                fwrite ($fh,"\\af31507\\afs28 \\ltrch\\fcs0 \\b\\fs28\\insrsid8614247\\charrsid8614247 ".$VDatRoj->format('d.m.Y')."\\cell }\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sa200\\sl276\\slmult1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 ");
                fwrite ($fh,"\\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\trowd \\irow1\\irowband1\\ltrrow");
                fwrite ($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid8614247\\tbllkhdrrows\\tbllkhdrcols\\tbllknocolband\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl");
                fwrite ($fh,"\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2802\\clshdrawnil \\cellx2694\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth6410\\clshdrawnil \\cellx9104\\row \\ltrrow");
                fwrite ($fh,"}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sb120\\sa120\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8614247\\yts15 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {");
                fwrite ($fh,"\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 ".ToRTF($VLine3)."}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247 :}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\cell }{\\rtlch\\fcs1 ");
                fwrite ($fh,"\\af31507\\afs28 \\ltrch\\fcs0 \\b\\fs28\\insrsid8614247\\charrsid8614247 ".ToRTF($VNasl)."\\cell }\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sa200\\sl276\\slmult1");
                fwrite ($fh,"\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 ");
                fwrite ($fh,"\\fs28\\insrsid8614247\\charrsid8614247 \\trowd \\irow2\\irowband2\\ltrrow");
                fwrite ($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid8614247\\tbllkhdrrows\\tbllkhdrcols\\tbllknocolband\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl");
                fwrite ($fh,"\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2802\\clshdrawnil \\cellx2694\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth6410\\clshdrawnil \\cellx9104\\row \\ltrrow");
                fwrite ($fh,"}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sb120\\sa120\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\pararsid8614247\\yts15 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs22\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {");
                fwrite ($fh,"\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 ".ToRTF($VLine4)."}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247 :}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\cell }{\\rtlch\\fcs1 ");
                fwrite ($fh,"\\af31507\\afs28 \\ltrch\\fcs0 \\b\\fs28\\insrsid8614247\\charrsid8614247 ".ToRTF($VObdobje)."}{\\rtlch\\fcs1 \\af31507\\afs28 \\ltrch\\fcs0 \\b\\fs28\\insrsid8614247\\charrsid8614247 \\cell ");
                fwrite ($fh,"}\\pard\\plain \\ltrpar\\ql \\li0\\ri0\\sa200\\sl276\\slmult1\\widctlpar\\intbl\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0 \\rtlch\\fcs1 \\af31507\\afs22\\alang1025 \\ltrch\\fcs0 \\f31506\\fs24\\lang1060\\langfe1033\\cgrid\\langnp1060\\langfenp1033 {\\rtlch\\fcs1 ");
                fwrite ($fh,"\\af31507\\afs28 \\ltrch\\fcs0 \\fs28\\insrsid8614247\\charrsid8614247 \\trowd \\irow3\\irowband3\\lastrow \\ltrrow");
                fwrite ($fh,"\\ts15\\trgaph70\\trleft-108\\trftsWidth1\\trftsWidthB3\\trftsWidthA3\\trautofit1\\trpaddl108\\trpaddr108\\trpaddfl3\\trpaddft3\\trpaddfb3\\trpaddfr3\\tblrsid8614247\\tbllkhdrrows\\tbllkhdrcols\\tbllknocolband\\tblind0\\tblindtype3 \\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl");
                fwrite ($fh,"\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth2802\\clshdrawnil \\cellx2694\\clvertalt\\clbrdrt\\brdrtbl \\clbrdrl\\brdrtbl \\clbrdrb\\brdrtbl \\clbrdrr\\brdrtbl \\cltxlrtb\\clftsWidth3\\clwWidth6410\\clshdrawnil \\cellx9104\\row }\\pard \\ltrpar");
                fwrite ($fh,"\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8614247 {\\rtlch\\fcs1 \\af31507\\afs32 \\ltrch\\fcs0 \\fs32\\insrsid8614247\\charrsid8614247 ".ToRTF($VLine5));
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ");
                fwrite ($fh,"\\par }\\pard \\ltrpar\\qc \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8614247 {\\rtlch\\fcs1 \\af31507\\afs36 \\ltrch\\fcs0 \\b\\fs36\\cf6\\insrsid8614247\\charrsid8614247 ".ToRTF($VDejavnost));
                fwrite ($fh,"\\par }\\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0 {\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ".ToRTF($VClen));
                fwrite ($fh,"\\par ".ToRTF($VVsebina));
                fwrite ($fh,"\\par ".ToRTF($VOpombe));
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par ");
                fwrite ($fh,"\\par }");
//                fwrite ($fh,"\\par \\tab ".ToRTF($VKraj));
                fwrite ($fh,"\\par \\pard \\ltrpar\\ql \\li0\\ri0\\widctlpar\\tx5954\\wrapdefault\\aspalpha\\aspnum\\faauto\\adjustright\\rin0\\lin0\\itap0\\pararsid8614247 {\\rtlch\\fcs1 \\af31507 \\ltrch\\fcs0 \\insrsid8614247 ");
                fwrite ($fh,"\\par \\tab Podpis:");
                fwrite ($fh,"\\par \\tab ".ToRTF($VMentor));
                fwrite ($fh,"\\par ".ToRTF("Vročeno:"));
                fwrite ($fh,"\\par ".ToRTF("- osebno"));
                fwrite ($fh,"\\par ".ToRTF("- arhiv šole"));
                fwrite ($fh,"\\par }{ \\page }");
            }
        }
    }
    fwrite ($fh,"{\\*\\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a");
    fwrite ($fh,"9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad");
    fwrite ($fh,"5689811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6");
    fwrite ($fh,"b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0");
    fwrite ($fh,"0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6");
    fwrite ($fh,"a7e7c0000000360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f");
    fwrite ($fh,"c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b6309512");
    fwrite ($fh,"0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462");
    fwrite ($fh,"a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865");
    fwrite ($fh,"6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b");
    fwrite ($fh,"4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b");
    fwrite ($fh,"4757e8d3f729e245eb2b260a0238fd010000ffff0300504b0304140006000800000021008c12afcaae060000a91b0000160000007468656d652f7468656d652f");
    fwrite ($fh,"7468656d65312e786d6cec594d6f1b4518be23f11f467b6f6327761a4775aad8b11b48d346b15bd4e37877bc3bcdecce6a669cd437d41e9190100571a012370e");
    fwrite ($fh,"08a8d44a5ccaaf09144191fa1778676677bd13af49d24650417d48bcb3cffbfd31ef8caf5ebb1f33744884a43c697bf5cb350f91c4e7014dc2b6777bd8bfb4e6");
    fwrite ($fh,"21a9701260c613d2f6a6447ad736de7fef2a5e5711890902fa44aee3b6172995ae2f2d491f96b1bccc5392c0bb31173156f028c2a540e023e01bb3a5e55a6d75");
    fwrite ($fh,"29c634f1508263607b6b3ca63ee1871829a0f63672f63d06321225f582cfc440332719cd1e955824161c1cd435444e659709748859db0351013f1a92fbca430c");
    fwrite ($fh,"4b052fda5ecd7cbca58dab4b783d23626a016d89ae6f3e195d46101c2c1b99221c1542ebfd46ebca56c1df00989ac7f57abd6eaf5ef03300ecfb60aad5a5ccb3");
    fwrite ($fh,"d15fab77729e2590fd3acfbb5b6bd61a2ebec47f654ee756a7d369b6325d2c5303b25f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8e257e7f0");
    fwrite ($fh,"fd2badd5868b37a088d1e4600ead03daef67dc0bc898b3ed4af81ac0d76a197c86826c28d24b8b18f3442d4cb618dfe3a20f088d6458d104a9694ac6d8874cee");
    fwrite ($fh,"e2782428d612f03a817c2eded8255fce2d696148fa82a6aaed7d9862a88a19d5abe7dfbf7afe141d3f7876fce0a7e3870f8f1ffc68193954db3809cb542fbffd");
    fwrite ($fh,"eccfc71fa33f9e7ef3f2d117d57859c6fffac327bffcfc793510ea67a6ce8b2f9ffcf6ecc98baf3efdfdbb4715f04d814765f890c644a29be408edf3180c335e");
    fwrite ($fh,"71352723713e8a61846999623309254eb09652c1bfa722077d738a59161d478f0e713d784740ffa8025e9fdc73141e4462a26885e49d287680bb9cb30e17955e");
    fwrite ($fh,"d8d1b24a6e1e4e92b05ab8989471fb181f56c9eee2c4896f6f9242e7ccd3d231bc1b1147cd3d86138543921085f43b7e40488575772975fcba4b7dc1251f2b74");
    fwrite ($fh,"97a20ea6952e19d291934d33a26d1a435ca6553643bc1ddfecde411dceaaacde22872e12aa02b30ae58784396ebc8e270ac7552c8738666587dfc02aaa527230");
    fwrite ($fh,"157e19d7930a221d12c6512f205256d1dc12606f29e83b185a5665d877d934769142d1832a9e3730e765e4163fe846384eabb0039a4465ec07f2005214a33dae");
    fwrite ($fh,"aae0bbdcad10fd0c71c0c9c270dfa1c409f7e9dde0360d1d956609a2df4c44452caf13eee4ef60cac6989856035ddde9d5314dfeae71330a9ddb4ab8b8c60dad");
    fwrite ($fh,"f2c5d78f2bf47e5b5bf626ec5e5535b37da2512fc29d6ccf5d2e02faf677e72d3c49f60814c4fc16f5ae39bf6bcede7fbe392faae78b6fc9b32e0c0d5acf2276");
    fwrite ($fh,"d2367377bc78ec1e53c6066acac80d69266f099b4fd087454d688e9da43887a5117cd5a50c121c5c28b0a14182ab8fa88a06114e616aaf7b9a492833d6a14429");
    fwrite ($fh,"97705c34cb95bc351e267f650f9b4d7d0cb1ad4362b5cb03bbbca297f3d346c1c668159a336d2e68453338abb0952b1953b0ed7584d5b55267965637aa99aee8");
    fwrite ($fh,"482b4cd62e36e7727079611a2c16de84a906c12c045e5e8583bf160da71dcc48a0fd6e639487c544e1224324231c902c46daeef918d54d90f25c993344db6193");
    fwrite ($fh,"411f1d4ff15a495a4bb37d0369670952595c6381b83c7a6f12a53c836751026e27cb9125e5e264093a6a7bade672d3433e4edbde180ecaf0354e21ea520f9298");
    fwrite ($fh,"8570e3e42b61d3fed46236553e8b662b37cc2d823a5c7e58bfcf19ecf4815448b585656453c3bcca5280255a92d57fb9096ebd28032abad1d9b458598364f8d7");
    fwrite ($fh,"b4003fbaa125e331f15539d8a515ed3bfb98b5523e51440ca2e0088dd844ec6308bf4e55b027a012ee3b4c47d00f703ba7bd6d5eb9cd392bbaf29d98c1d975cc");
    fwrite ($fh,"d20867ed5697685ec9166e1a52a183792aa907b655ea6e8c3bbf29a6e42fc894721affcf4cd1fb095c3fac043a023edc0f0b8c74a5b43d2e54c4a10ba511f5fb");
    fwrite ($fh,"022607d33b205be086175e4352c12db5f92fc8a1fe6f6bcef230650da748b54f432428ec472a1284ec415b32d9770ab37ab67759962c636432aaa4ae4cadda23");
    fwrite ($fh,"7248d850f7c055bdb77b28825437dd246b03067732ffdce7ac8246a11e72caf5e674b262efb535f04f4f3eb698c128b70f9b8126f77fa162311ecc76554b6fc8");
    fwrite ($fh,"f3bdb76c887e311bb31a795580b0d256d0cacafe355538e7566b3bd69cc5cbcd5c3988e2bcc5b0580c44295c2221fd07f63f2a7c464c1aeb0d75c8f7a1b722f8");
    fwrite ($fh,"f9423383b481acbe64070fa41ba45d1cc1e064176d326956d6b5d9e8a4bd966fd6173ce916724f385b6b7696789fd3d9c570e68a736af1229d9d79d8f1b55d5b");
    fwrite ($fh,"e86a88ecc91285a5717e92318131bf95957fcce2a37b10e82df8d160c29434c904bf54090c33f4c0d40114bf95684837fe020000ffff0300504b030414000600");
    fwrite ($fh,"0800000021000dd1909fb60000001b010000270000007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d");
    fwrite ($fh,"0ac2301484f78277086f6fd3ba109126dd88d0add40384e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec");
    fwrite ($fh,"8e4052164e89d93b64b060828e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524");
    fwrite ($fh,"bd62107bd5001996509affb3fd381a89672f1f165dfe514173d9850528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000");
    fwrite ($fh,"002100e9de0fbfff0000001c0200001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d00140006000800");
    fwrite ($fh,"00002100a5d6a7e7c0000000360100000b00000000000000000000000000300100005f72656c732f2e72656c73504b01022d00140006000800000021006b7996");
    fwrite ($fh,"16830000008a0000001c00000000000000000000000000190200007468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d00140006");
    fwrite ($fh,"000800000021008c12afcaae060000a91b00001600000000000000000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d");
    fwrite ($fh,"00140006000800000021000dd1909fb60000001b0100002700000000000000000000000000b80900007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000b30a00000000}");
    fwrite ($fh,"{\\*\\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d");
    fwrite ($fh,"617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169");
    fwrite ($fh,"6e22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363");
    fwrite ($fh,"656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}");
    fwrite ($fh,"{\\*\\latentstyles\\lsdstimax267\\lsdlockeddef0\\lsdsemihiddendef1\\lsdunhideuseddef1\\lsdqformatdef0\\lsdprioritydef99{\\lsdlockedexcept \\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority0 \\lsdlocked0 Normal;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 1;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 2;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 3;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 4;");
    fwrite ($fh,"\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 5;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 6;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 7;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 8;\\lsdqformat1 \\lsdpriority9 \\lsdlocked0 heading 9;");
    fwrite ($fh,"\\lsdpriority39 \\lsdlocked0 toc 1;\\lsdpriority39 \\lsdlocked0 toc 2;\\lsdpriority39 \\lsdlocked0 toc 3;\\lsdpriority39 \\lsdlocked0 toc 4;\\lsdpriority39 \\lsdlocked0 toc 5;\\lsdpriority39 \\lsdlocked0 toc 6;\\lsdpriority39 \\lsdlocked0 toc 7;");
    fwrite ($fh,"\\lsdpriority39 \\lsdlocked0 toc 8;\\lsdpriority39 \\lsdlocked0 toc 9;\\lsdqformat1 \\lsdpriority35 \\lsdlocked0 caption;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority10 \\lsdlocked0 Title;\\lsdpriority1 \\lsdlocked0 Default Paragraph Font;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority11 \\lsdlocked0 Subtitle;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority22 \\lsdlocked0 Strong;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority20 \\lsdlocked0 Emphasis;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority59 \\lsdlocked0 Table Grid;\\lsdunhideused0 \\lsdlocked0 Placeholder Text;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority1 \\lsdlocked0 No Spacing;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 1;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 1;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 1;\\lsdunhideused0 \\lsdlocked0 Revision;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority34 \\lsdlocked0 List Paragraph;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority29 \\lsdlocked0 Quote;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority30 \\lsdlocked0 Intense Quote;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 1;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 1;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 1;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 2;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 2;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 3;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 3;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 3;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 3;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 3;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 3;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 4;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 4;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 4;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 4;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 4;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 5;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 5;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 5;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 5;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 5;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 5;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority60 \\lsdlocked0 Light Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority61 \\lsdlocked0 Light List Accent 6;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority62 \\lsdlocked0 Light Grid Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority63 \\lsdlocked0 Medium Shading 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority64 \\lsdlocked0 Medium Shading 2 Accent 6;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority65 \\lsdlocked0 Medium List 1 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority66 \\lsdlocked0 Medium List 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority67 \\lsdlocked0 Medium Grid 1 Accent 6;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority68 \\lsdlocked0 Medium Grid 2 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority69 \\lsdlocked0 Medium Grid 3 Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority70 \\lsdlocked0 Dark List Accent 6;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority71 \\lsdlocked0 Colorful Shading Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority72 \\lsdlocked0 Colorful List Accent 6;\\lsdsemihidden0 \\lsdunhideused0 \\lsdpriority73 \\lsdlocked0 Colorful Grid Accent 6;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority19 \\lsdlocked0 Subtle Emphasis;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority21 \\lsdlocked0 Intense Emphasis;");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority31 \\lsdlocked0 Subtle Reference;\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority32 \\lsdlocked0 Intense Reference; ");
    fwrite ($fh,"\\lsdsemihidden0 \\lsdunhideused0 \\lsdqformat1 \\lsdpriority33 \\lsdlocked0 Book Title;\\lsdpriority37 \\lsdlocked0 Bibliography;\\lsdqformat1 \\lsdpriority39 \\lsdlocked0 TOC Heading;}}{\\*\\datastore 010500000200000018000000");
    fwrite ($fh,"4d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000");
    fwrite ($fh,"d0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"fffffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    fwrite ($fh,"ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072007900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e500000000000000000000000070d4");
    fwrite ($fh,"9c92bd7bce01feffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000");
    fwrite ($fh,"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000");
    fwrite ($fh,"000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff000000000000000000000000000000000000000000000000");
    fwrite ($fh,"0000000000000000000000000000000000000000000000000105000000000000}");
    fwrite ($fh,"}");
    fclose($fh);
		
    echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Odpri izjave</a></h2>";
		
}else{
	switch ($Vid){
		case "1":
			for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
				$SQL = "SELECT * FROM TabIzjave WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
				$result = mysqli_query($link,$SQL);
				
				if ($R = mysqli_fetch_array($result)){
					$SQL = "UPDATE TabIzjave SET ";

					if (isset($_POST["VarPod_".$Indx])){
						$SQL = $SQL . "VarPod=true,";
					}else{
						$SQL = $SQL . "VarPod=false,";
					}
					$SQL = $SQL . "DatVarPod='".$_POST["DatVarPod_".$Indx]."'";
					$SQL = $SQL . " WHERE idUcitelj=".$_POST["ucitelj_".$Indx];
				}else{
					$SQL = "INSERT INTO TabIzjave (idUcitelj,";
					$SQL = $SQL . "VarPod,DatVarPod";
					$SQL = $SQL . ") VALUES (".$_POST["ucitelj_".$Indx].",";

					if (isset($_POST["VarPod_".$Indx])){
						$SQL = $SQL . "true,";
					}else{
						$SQL = $SQL . "false,";
					}
					$SQL = $SQL . "'".$_POST["DatVarPod_".$Indx]."'";
					
					$SQL = $SQL . ")";
				}
				$result = mysqli_query($link,$SQL);
			}
	}
	$SQL = "SELECT tabucitelji.*, TabStatus.Status,TabIzjave.* FROM ";
	$SQL = $SQL . "(tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus) ";
	$SQL = $SQL . "LEFT JOIN TabIzjave ON tabucitelji.idUcitelj=TabIzjave.idUcitelj ";
	$SQL = $SQL . "WHERE tabucitelji.Status > 0 ";
	$SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
	$result = mysqli_query($link,$SQL);

	$Indx=1;

	echo "<h2>Pregled izjav</h2>";
	echo "Pri izjavah se da kljukico pri ustrezni izjavi. V naslednjem oknu se vpiše datum izjave.<br />";
	echo "<form accept-charset='utf-8' name='form_Izjave' method=post action='Izjave.php'>";
	echo "<input name='submit' type='submit' value='Pošlji'>";
	echo "<input name='submit' type='submit' value='Izjava'>";
	echo "<table border=1 cellspacing=0>";
	echo "<tr bgcolor=lightcyan><th>Št.</th><th>Delavec</th>";
	echo "<th>Izpis<br />izjave</th>";
	echo "<th>Varovanje<br>podatkov</th>";
	echo "</tr>";
	$ColorChange=true;

	while ($R = mysqli_fetch_array($result)){
		if ($ColorChange){
			echo "<tr bgcolor=lightyellow>";
		}else{
			echo "<tr bgcolor=#FFFFCC>";
		}
		$ColorChange=!$ColorChange;
		echo "<td>".$Indx."</td>";
		echo "<td><input name='ucitelj_".$Indx."' type='hidden' value='".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</td>";
		echo "<td align=center><input name='prevzemnica_".$Indx."' type='checkbox'></td>";
		if ($R["VarPod"]){
			if (!isDate($R["DatVarPod"])){
				echo "<td bgcolor=lightsalmon>";
			}else{
				echo "<td>";
			}
			echo "<input name='VarPod_".$Indx."' type='checkbox' checked>";
		}else{
			echo "<td><input name='VarPod_".$Indx."' type='checkbox'>";
		}
		echo "<input name='DatVarPod_".$Indx."' type='text' value='".$R["DatVarPod"]."' size='8'>";
		echo "</td>";
		
		echo "</tr>";
		$Indx=$Indx+1;
	}
	echo "</table>";
	echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
	echo "<input name='id' type='hidden' value='1'>";
	echo "<input name='submit' type='submit' value='Pošlji'>";
	echo "</form>";
}
?>
</body>
</html>

