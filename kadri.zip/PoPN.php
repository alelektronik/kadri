<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Odsotnost po potnih nalogih
</title>
</head>
<body>

<?php

function ImeMeseca($m){
    switch ($m){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$Obdelava=$Vid;

switch ($Obdelava){
	case "5":
        if (!CheckDostop("DelKontr",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }

		echo "<form accept-charset='utf-8' name='obracun' method='post' action='PoPN.php'>";
		if (isset($_POST["letoPN"])){
            $letoPN=$_POST["letoPN"];
        }else{
			$letoPN=$Danes->format('Y');
		}
		if (isset($_POST["mesecPN"])){
            $MesecPN=$_POST["mesecPN"];
        }else{    
			$MesecPN=$Danes->format('n');
        }
		echo "Izberi leto in mesec: <select name='letoPN'>";
		if ($Danes->format('Y')==$letoPN) {
			echo "<option selected>".$Danes->format('Y')."</option>";
			echo "<option>".($Danes->format('Y')-1)."</option>";
		}else{
            echo "<option>".$Danes->format('Y')."</option>";
            echo "<option selected>".($Danes->format('Y')-1)."</option>";
		}
		echo "</select>";
		echo "<select name='mesecPN'>";
		for ($Indx=1;$Indx <= 12;$Indx++){
			if ($MesecPN==$Indx){
				echo "<option selected>".$Indx."</option>";
			}else{
				echo "<option>".$Indx."</option>";
			}
		}
		echo "</select>";
		echo "<input name='id' type='hidden' value='5'>";
		echo "<input name='submit' type='submit' value='Izberi'><br />";
		echo "</form>";

		echo "<h2>Spisek potnih nalogov za ".ImeMeseca($MesecPN)." ".$letoPN."</h2>";
		
		$SQL = "SELECT TabPotniNalog.*,tabucitelji.*,TabVzgDelo.* FROM ";
		$SQL = $SQL . "(TabPotniNalog INNER JOIN tabucitelji ON TabPotniNalog.idUcitelj=tabucitelji.idUcitelj) ";
		$SQL = $SQL . "INNER JOIN TabVzgDelo ON tabucitelji.idVzgojnoDelo=TabVzgDelo.idVzgojnoDelo ";
		$SQL = $SQL . "WHERE year(DanOdhoda)=".$letoPN." AND month(DanOdhoda)=".$MesecPN;
		$SQL = $SQL . " ORDER BY Priimek,Ime";
		$result = mysqli_query($link,$SQL);
		
		$Indx=1;
		while ($R = mysqli_fetch_array($result)){
			$Odsotnost[$Indx][0]=$R["IdUcitelj"];
            $Datum=new DateTime($R["Datum"]);
			$Odsotnost[$Indx][1]=$Datum->format('j.n.Y');
			$Odsotnost[$Indx][2]=$R["ZapSt"];
			$Odsotnost[$Indx][3]=$R["Priimek"]." ".$R["Ime"];
			$Odsotnost[$Indx][4]=$R["Kam"];
			$Odsotnost[$Indx][5]=$R["Naloga"];
			$Odsotnost[$Indx][6]=$R["DanOdhodaObr"];
			$Odsotnost[$Indx][7]=$R["UraOdhodaObr"];
			$Odsotnost[$Indx][8]=$R["DanPrihodaObr"];
			$Odsotnost[$Indx][9]=$R["UraPrihodaObr"];
			$Odsotnost[$Indx][10]=$R["DniObr"];
			$Odsotnost[$Indx][11]=$R["UrObr"];
			$Odsotnost[$Indx][12]=$R["MinObr"];
				
			$Indx=$Indx+1;
		}
		$StZapisov=$Indx-1;
		
		echo "<br /><table border='1'>";
		echo "<tr><th>Št.</th><th>Datum izdaje</th><th>Zap.št</th><th>Ime</th><th>Kam</th><th>Naloga</th><th>Od</th><th>Do</th><th>dni/ur/min</th><th>Vnosi v mesečni<br>pregled dela</th></tr>";
		for ($Indx=1;$Indx <= $StZapisov;$Indx++){
			echo "<tr>";
			echo "<td align=center>".$Indx."</td>";
			echo "<td align=right>".$Odsotnost[$Indx][1]."</td>";
			echo "<td align=center>".$Odsotnost[$Indx][2]."</td>";
			echo "<td>".$Odsotnost[$Indx][3]."</td>";
			echo "<td>".$Odsotnost[$Indx][4]."</td>";
			echo "<td>".$Odsotnost[$Indx][5]."</td>";
			echo "<td>".$Odsotnost[$Indx][6]."<br>".$Odsotnost[$Indx][7]."</td>";
			echo "<td>".$Odsotnost[$Indx][8]."<br>".$Odsotnost[$Indx][9]."</td>";
			echo "<td align=center>".$Odsotnost[$Indx][10]."/".$Odsotnost[$Indx][11]."/".$Odsotnost[$Indx][12]."</td>";
			echo "<td>";
			$SQL = "SELECT tabpregleddelan.*,TabDoprinos.*,tabpregleddelan.Leto AS pleto FROM tabpregleddelan ";
			$SQL = $SQL . " INNER JOIN TabDoprinos ON tabpregleddelan.rubrika=TabDoprinos.idDoprinos ";
			$SQL = $SQL . "WHERE Ucitelj=".$Odsotnost[$Indx][0]." AND tabpregleddelan.leto=".$letoPN." AND mesec=".$MesecPN." ORDER BY dan";
//'			echo $SQL."<br>"
			$result = mysqli_query($link,$SQL);
			
			while ($R = mysqli_fetch_array($result)){
				if ($R["Dan"].".".$R["Mesec"].".".$R["pleto"]==$Odsotnost[$Indx][1]){
                    echo "<font color=red>";
                }
				echo $R["Dan"].".".$R["Mesec"].".".$R["pleto"].", ".$R["OblikaDelaKratko"].", ";
				switch ($R["koeficient"]){
					case 1:
                    case 1.5:
                    case 1.3:
						echo $R["Enot"]/$R["uramin"]*$R["koeficient"]." DU, ";
                        break;
					case 0:
                    case 8:
						echo $R["Enot"]." dan, ";
				}
				echo $R["Komentar"]."<br />";
				if ($R["Dan"].".".$R["Mesec"].".".$R["pleto"]==$Odsotnost[$Indx][1]){
                    echo "</font>";
                }
			}
			echo "</td>";
			echo "</tr>";
		}
		echo "</table><br />";
}

if (!CheckDostop("DelKontr",$VUporabnik) ) {
	echo "<a href='VnosPotniNalogi.php?id=5'>Na spisek potnih nalogov</a><br />";
}else{
	echo "<a href='VnosPotniNalogi.php?id=9'>Spisek mojih potnih nalogov</a>";
}

//echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
?>


</body>
</html>
