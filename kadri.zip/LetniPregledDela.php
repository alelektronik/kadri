<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Letni pregled dela
</title>
<style type="text/css">
.break { page-break-before: always; }
</style>
</head>
<body>

<?php
function CheckDoprinosRubrika($d,$r){
    global $Doprinosi,$StDoprinosov;
    $Suma=0;
    for ($Indx=1;$Indx <= $StDoprinosov;$Indx++){
        if (($Doprinosi[$Indx][0]->format('Y-m-d')==$d->format('Y-m-d')) && ($Doprinosi[$Indx][1]==$r)){
            $Suma=$Suma+$Doprinosi[$Indx][7];
        }
    }
    return $Suma;
}

function ImeMeseca($m){
    switch ($m){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}


$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
    if (isset($_POST["idUcitelj"])){
        $ucitelj=$_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj=$_GET["idUcitelj"];
        }else{
            $ucitelj=0;
        }
    }
    $Vid="";
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }
    
    switch ($Vid){
        case "1":
            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                $ucitelji[$i][0]=$R["iducitelj"];
                $ucitelji[$i][1]=$R["priimek"]." ".$R["ime"];
                $i += 1;
            }
            $stUciteljev=$i-1;
            echo "<br />";
            $VLetoPregled=PreberiLeto("leto");
            echo "<a href='LetniPregledDela.php?id=1&leto=".($VLetoPregled-1)."'>".($VLetoPregled-1)."</a> | $VLetoPregled | <a href='LetniPregledDela.php?id=1&leto=".($VLetoPregled+1)."'>".($VLetoPregled+1)."</a><br />";
            echo "<table border='1'>";
            echo "<tr bgcolor='lightcyan'><th>Ime</th>";
            $SQL = "SELECT iddoprinos,oblikadela,oblikadelakratko,oblikadelaoznaka,addsub,uramin,koeficient FROM tabdoprinos WHERE aktivno > 0 ORDER BY sortiranje";
            $result = mysqli_query($link,$SQL);
            $i=1;
            while ($R = mysqli_fetch_array($result)){
                $rubrika[$i][0]=$R["iddoprinos"];
                $rubrika[$i][1]=$R["oblikadela"];
                $rubrika[$i][2]=$R["oblikadelakratko"];
                $rubrika[$i][3]=$R["oblikadelaoznaka"];
                $rubrika[$i][4]=$R["addsub"];
                $rubrika[$i][5]=$R["uramin"];
                $rubrika[$i][6]=$R["koeficient"];
                $rubrika[$i][8]=0;
                echo "<th>".$R["oblikadelakratko"]."</th>";
                $i += 1;
            }
            $stRubrik=$i-1;
            echo "</tr>";
            for ($i=1;$i <= $stUciteljev;$i++){
                /*
                for($j=1;$j <= $stRubrik;$j++){
                    $SQL = "SELECT enot FROM tabpregleddelan WHERE rubrika=".$rubrika[$j][0]." AND enotpotrjeno=TRUE AND ucitelj=".$ucitelji[$i][0]." AND leto=".$VLetoPregled;
                    $result = mysqli_query($link,$SQL);
                    $rubrika[$j][7]=0;
                    while ($R = mysqli_fetch_array($result)){
                        $rubrika[$j][7] += $R["enot"];
                    }
                }
                */
                for ($j=1;$j <= $stRubrik;$j++){
                    $rubrika[$j][7]=0;
                }
                $SQL = "SELECT enot,rubrika FROM tabpregleddelan WHERE enotpotrjeno=TRUE AND ucitelj=".$ucitelji[$i][0]." AND leto=".$VLetoPregled." ORDER BY rubrika";
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
                    for ($j=1;$j <= $stRubrik;$j++){
                        if ($rubrika[$j][0]==$R["rubrika"]){
                            $rubrika[$j][7] += $R["enot"];
                            break;
                        }
                    }
                }

                echo "<tr>";
                echo "<td>".$ucitelji[$i][1]."</td>";
                for($j=1;$j <= $stRubrik;$j++){
                    if ($rubrika[$j][6] > 0){
                        $kum=$rubrika[$j][7]/$rubrika[$j][5]*$rubrika[$j][6];
                    }else{
                        $kum=$rubrika[$j][7];
                    }
                    $rubrika[$j][8] += $kum ;
                    if ($rubrika[$j][4] == "add"){
                        echo "<td align='right'>".str_replace(".",",",round($kum,1))."</td>";
                    }else{
                        echo "<td align='right'>-".str_replace(".",",",round($kum,1))."</td>";
                    }
                }
                echo "</tr>";
            }
            echo "<tr bgcolor='lightgrey'>";
            echo "<td>Skupaj</td>";
            for($j=1;$j <= $stRubrik;$j++){
                if ($rubrika[$j][4] == "add"){
                    echo "<td align='right'>".str_replace(".",",",round($rubrika[$j][8],1))."</td>";
                }else{
                    echo "<td align='right'>-".str_replace(".",",",round($rubrika[$j][8],1))."</td>";
                }
            }
            echo "</tr>";
            echo "</table><br />";
            break;
        default:
            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
            $result = mysqli_query($link,$SQL);

            $indx=1;
            while ($R = mysqli_fetch_array($result)){
	            $ucitelji[$indx][0]=$R["iducitelj"];
	            $ucitelji[$indx][1]=$R["priimek"]." ".$R["ime"];
	            $indx=$indx+1;
            }
            $StUciteljev=$indx-1;
            echo "<br />";
            echo $VLeto."/".($VLeto+1)."<br />";
            echo "<table border=1 cellspacing=0>";
            echo "<tr bgcolor=lightcyan><th>Učitelj</th><th></th><th>9</th><th></th><th>10</th><th></th><th>11</th><th></th><th>12</th><th></th><th>1</th><th></th><th>2</th><th></th><th>3</th><th></th><th>4</th><th></th><th>5</th><th></th><th>6</th><th></th><th>7</th><th></th><th>8</th><th></th><th>Skupaj</th><th></th><th></th></tr>";
            echo "<tr bgcolor=lightcyan><th></th><th></th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>N</th><th>D</th><th>Sk</th></tr>";
            for ($indx=1;$indx <= $StUciteljev;$indx++){
                for ($MesObr=0;$MesObr <= 12;$MesObr++){
                    for ($i=1;$i <= 10;$i++){
                        $Doprinosi[$MesObr][$i]=0;
                    }
                }
	            $SQL = "SELECT tabpregleddelan.datum,tabpregleddelan.leto,tabpregleddelan.mesec,tabpregleddelan.enot,tabpregleddelan.rubrika,tabdoprinos.addsub,tabdoprinos.uramin,tabdoprinos.koeficient FROM ";
	            $SQL = $SQL . "tabpregleddelan INNER JOIN tabdoprinos ON tabpregleddelan.rubrika=tabdoprinos.idDoprinos ";
                $SQL = $SQL . "WHERE (tabpregleddelan.leto=".$VLeto." OR tabpregleddelan.leto=".($VLeto+1).") AND Ucitelj=".$ucitelji[$indx][0];
	            $result = mysqli_query($link,$SQL);
	            
	            while ($R = mysqli_fetch_array($result)){
                    switch ($R["rubrika"]){
                        case 5:
                        case 9:
                        case 10:
                        case 11:
                        case 29:
                        case 30:
                            if (($R["leto"]==$VLeto) && ($R["mesec"] > 8)){
			                    switch ($R["addsub"]){
				                    case "add":
					                    $Doprinosi[$R["mesec"]][1]=$Doprinosi[$R["mesec"]][1]+$R["enot"]/$R["uramin"]*$R["koeficient"];
                                        break;
				                    case "sub":
					                    $Doprinosi[$R["mesec"]][2]=$Doprinosi[$R["mesec"]][2]-$R["enot"]/$R["uramin"]*$R["koeficient"];
			                    }
                                $Doprinosi[$R["mesec"]][3]=$Doprinosi[$R["mesec"]][1]+$Doprinosi[$R["mesec"]][2]; //'skupni mesečni doprinos
                            }
                            if (($R["leto"]==$VLeto+1) && ($R["mesec"] < 9)){
                                switch ($R["addsub"]){
                                    case "add":
                                        $Doprinosi[$R["mesec"]][1]=$Doprinosi[$R["mesec"]][1]+$R["enot"]/$R["uramin"]*$R["koeficient"];
                                        break;
                                    case "sub":
                                        $Doprinosi[$R["mesec"]][2]=$Doprinosi[$R["mesec"]][2]-$R["enot"]/$R["uramin"]*$R["koeficient"];
                                }
                                $Doprinosi[$R["mesec"]][3]=$Doprinosi[$R["mesec"]][1]+$Doprinosi[$R["mesec"]][2]; //'skupni mesečni doprinos
                            }
                            break;
                        default:
                            if (($R["leto"]==$VLeto) && ($R["mesec"] > 8)){
                                $Datum=new DateTime($R["datum"]);
                                if ($Datum->format('d.m.Y') != "01.01.".($VLeto+1) ){
                                    switch ($R["addsub"]){
                                        case "add":
                                            $Doprinosi[$R["mesec"]][4]=$Doprinosi[$R["mesec"]][4]+$R["enot"]/$R["uramin"]*$R["koeficient"];
                                            break;
                                        case "sub":
                                            $Doprinosi[$R["mesec"]][5]=$Doprinosi[$R["mesec"]][5]-$R["enot"]/$R["uramin"]*$R["koeficient"];
                                    }
                                }
                            }
                            if (($R["leto"]==$VLeto+1) && ($R["mesec"] < 9)){
                                $Datum=new DateTime($R["datum"]);
                                if ($Datum->format('d.m.Y') != "01.01.".($VLeto+1) ){
                                    switch ($R["addsub"]){
                                        case "add":
                                            $Doprinosi[$R["mesec"]][4]=$Doprinosi[$R["mesec"]][4]+$R["enot"]/$R["uramin"]*$R["koeficient"];
                                            break;
                                        case "sub":
                                            $Doprinosi[$R["mesec"]][5]=$Doprinosi[$R["mesec"]][5]-$R["enot"]/$R["uramin"]*$R["koeficient"];
                                    }
                                }
                            }
                            $Doprinosi[$R["mesec"]][6]=$Doprinosi[$R["mesec"]][4]+$Doprinosi[$R["mesec"]][5]; // 'skupni mesečni doprinos
                    }
	            }
                //'skupaj
                for ($i=1;$i <= 12;$i++){
                    $Doprinosi[0][1]=$Doprinosi[0][1]+$Doprinosi[$i][1]; //'nadomeščanja +
                    $Doprinosi[0][2]=$Doprinosi[0][2]+$Doprinosi[$i][2]; //'nadomeščanja -
                    $Doprinosi[0][3]=$Doprinosi[0][3]+$Doprinosi[$i][3]; //'nadomeščanja skupaj
                    $Doprinosi[0][4]=$Doprinosi[0][4]+$Doprinosi[$i][4]; //'drugo +
                    $Doprinosi[0][5]=$Doprinosi[0][5]+$Doprinosi[$i][5]; //'drugo -
                    $Doprinosi[0][6]=$Doprinosi[0][6]+$Doprinosi[$i][6]; //'drugo skupaj
                }
	            //'vrstica s + vrednostmi
	            echo "<tr bgcolor=lightgreen>";
	            echo "<td>".$ucitelji[$indx][1]."</td><td>+</td>";
	            for ($i=9;$i <= 12;$i++){
		            echo "<td align=right>".number_format($Doprinosi[$i][1],2)."</td>";
		            echo "<td align=right>".number_format($Doprinosi[$i][4],2)."</td>";
	            }
	            for ($i=1;$i <= 8;$i++){
                    echo "<td align=right>".number_format($Doprinosi[$i][1],2)."</td>";
                    echo "<td align=right>".number_format($Doprinosi[$i][4],2)."</td>";
	            }
                echo "<td align=right>".number_format($Doprinosi[0][1],2)."</td>";
                echo "<td align=right>".number_format($Doprinosi[0][4],2)."</td>";
	            echo "</tr>";
	            //'vrstica z - vrednostmi
	            echo "<tr bgcolor=khaki>";
	            echo "<td></td><td>-</td>";
                for ($i=9;$i <= 12;$i++){
                    echo "<td align=right>".number_format($Doprinosi[$i][2],2)."</td>";
                    echo "<td align=right>".number_format($Doprinosi[$i][5],2)."</td>";
                }
                for ($i=1;$i <= 8;$i++){
                    echo "<td align=right>".number_format($Doprinosi[$i][2],2)."</td>";
                    echo "<td align=right>".number_format($Doprinosi[$i][5],2)."</td>";
	            }
                echo "<td align=right>".number_format($Doprinosi[0][2],2)."</td>";
                echo "<td align=right>".number_format($Doprinosi[0][5],2)."</td>";
	            echo "</tr>";
	            //'vrstica s skupnimi vrednostmi
	            echo "<tr bgcolor=lightgrey>";
	            echo "<td></td><td>Sk</td>";
                for ($i=9;$i <= 12;$i++){
                    echo "<td align=right>".number_format($Doprinosi[$i][3],2)."</td>";
                    echo "<td align=right>".number_format($Doprinosi[$i][6],2)."</td>";
                }
                for ($i=1;$i <= 8;$i++){
                    echo "<td align=right>".number_format($Doprinosi[$i][3],2)."</td>";
                    echo "<td align=right>".number_format($Doprinosi[$i][6],2)."</td>";
	            }
                echo "<td align=right>".number_format($Doprinosi[0][3],2)."</td>";
                echo "<td align=right>".number_format($Doprinosi[0][6],2)."</td>";
                echo "<td align=right>".number_format($Doprinosi[0][3]+$Doprinosi[0][6],2)."</td>";
	            echo "</tr>";
            }
            echo "</table><br />";
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

?>

</body>
</html>
