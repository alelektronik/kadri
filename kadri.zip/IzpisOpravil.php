<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Opravila
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("drugo2",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

function Vsebuje($a,$s){
    $x=split(",",$s);
    return (in_array($a,$x));
}

switch ($Vid){
	case "1":
		$SQL = "SELECT tabdeldogodek.*,tabdogodek.* FROM ";
		$SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
		$SQL = $SQL . "WHERE tabdeldogodek.id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			$SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$R["porocilaDo"]."' WHERE id=".$_GET["zapis"];
			$result = mysqli_query($link,$SQL);
		}
        break;
	case "2":
		$SQL = "SELECT tabdeldogodek.*,tabdogodek.* FROM ";
		$SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
		$SQL = $SQL . "WHERE tabdeldogodek.id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);

		if ($R = mysqli_fetch_array($result)){
			$SQL = "UPDATE tabdeldogodek SET opravljeno=false,datum='' WHERE id=".$_GET["zapis"];
			$result = mysqli_query($link,$SQL);
		}
}

echo "Leto: <a href='IzpisOpravil.php?leto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | ".$VLeto."/".($VLeto+1)." | <a href='IzpisOpravil.php?leto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
echo "<h2>Opravila in roki</h2>";
$SQL = "SELECT tabdeldogodek.*,tabdogodek.*,tabucitelji.Priimek,tabucitelji.Ime,tabdeldogodek.datum AS ddatum,tabdeldogodek.id AS did FROM ";
$SQL = $SQL . "(tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id) ";
$SQL = $SQL . "INNER JOIN tabucitelji ON tabdeldogodek.idUcitelj=tabucitelji.idUcitelj ";
$SQL = $SQL . "WHERE tabdogodek.leto=".$VLeto." ";
$SQL = $SQL . "ORDER BY priimek,ime,year(porocilaDo),month(porocilaDo),day(porocilaDo)";
$result = mysqli_query($link,$SQL);

$Ucitelj="";
while ($R = mysqli_fetch_array($result)){
		if ($Ucitelj != $R["Priimek"]." ".$R["Ime"]){
			if ($Ucitelj != ""){
				echo "</table><br />";
			}
			echo "<h3>".$R["Priimek"]." ".$R["Ime"]."</h3>";
			$Ucitelj=$R["Priimek"]." ".$R["Ime"];
			echo "<table border=1 cellspacing=0>";
			echo "<tr bgcolor=lightcyan><th width=250>Opravilo</th><th width=70>Rok</th><th width=70>Opravljeno</th><th>Dodeli status<br />opravljeno</th></tr>";
		}
		if ($R["opravljeno"]){
            $Datum=new DateTime(isDate($R["ddatum"]));
            $porocilaDo=new DateTime(isDate($R["porocilaDo"]));
            $Interval=$Datum->diff($porocilaDo);
			if ($Interval->invert > 0){
				echo "<tr bgcolor='lightyellow'>";
			}else{
				echo "<tr bgcolor='lightgreen'>";
			}
		}else{
			echo "<tr bgcolor='red'>";
		}
//'		echo "<td>".$R["priimek")." ".$R["ime")."</td>"
		echo "<td>".$R["Dogodek"]."</td>";
		echo "<td>".$R["porocilaDo"]."</td>";
		echo "<td>".$R["ddatum"]."</td>";
		if (!$R["opravljeno"]){
			echo "<td bgcolor='khaki'><a href='IzpisOpravil.php?leto=".$VLeto."&id=1&zapis=".$R["did"]."'>Popravi</a></td>";
		}else{
			echo "<td bgcolor='khaki'><a href='IzpisOpravil.php?leto=".$VLeto."&id=2&zapis=".$R["did"]."'>Popravi</a></td>";
		}
}
echo "</table><br />";

?>
<br />

</body>
</html>
