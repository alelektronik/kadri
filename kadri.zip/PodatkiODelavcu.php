<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Podatki o delavcu
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("DelKontr",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br />";
}    
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$ucitelj = $Vid;

echo "Leto: ".$VLeto."/".($VLeto+1)."<br />";

$_SESSION["leto"]=$VLeto;
$_SESSION["solskoleto"]=$VLeto;
$_SESSION["letopregled"]=$VLetoPregled;
	
$_SESSION["Ucitelj"] = $ucitelj;
$_SESSION["UciteljPredmet"]=$ucitelj;

$SQL = "SELECT * FROM tabucitelji ";
$SQL = $SQL ."WHERE tabucitelji.IdUcitelj =" . $ucitelj ;
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VObcina=$R["Obcina"];
	$VDrzava=$R["Drzava"];
	$VObcinaZac=$R["ObcinaZac"];
	$VDrzavaZac=$R["DrzavaZac"];
}

$SQL = "SELECT * FROM TabSifreObcin WHERE sifra='".$VObcina."'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VObcina=$R["sifra"]." - ".$R["obcina"];
}
$SQL = "SELECT * FROM TabSifreObcin WHERE sifra='".$VObcinaZac."'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VObcinaZac=$R["sifra"]." - ".$R["obcina"];
}
$SQL = "SELECT * FROM TabSifrantDrzav WHERE sifra='".$VDrzava."'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VDrzava=$R["sifra"]." - ".$R["drzava"];
}
$SQL = "SELECT * FROM TabSifrantDrzav WHERE sifra='".$VDrzavaZac."'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
	$VDrzavaZac=$R["sifra"]." - ".$R["drzava"];
}

$SQL = "SELECT tabucitelji.*,TabIzobrazba.Opis FROM tabucitelji INNER JOIN TabIzobrazba ON tabucitelji.Izobrazba=TabIzobrazba.idIzobrazba ";
$SQL = $SQL ."WHERE tabucitelji.IdUcitelj =" . $ucitelj;
$result = mysqli_query($link,$SQL);

if ($R = mysqli_fetch_array($result)){
	if ($R["Spol"]=="M"){
		echo "<h2>Podatki o delavcu</h2>";
	}else{
		echo "<h2>Podatki o delavki</h2>";
	}
	if ($VLevel > 1){
		echo "Ime in priimek: <a href='PopraviUcitelja.php?idUcitelj=".$ucitelj."'><b>" . $R["Ime"]  . " " . $R["Priimek"] . "</b></a><br />";
	}else{
		echo "Ime in priimek: <b>" . $R["Ime"]  . " " . $R["Priimek"] . "</b><br />";
	}
    $Datum = new DateTime($R["DatRoj"]);
	echo "Datum rojstva: <b>".$Datum->format('d.m.Y')."</b>, kraj rojstva: <b>".$R["KrajRoj"]."</b>, država rojstva: <b>".$R["DrzavaRoj"]."</b><br />";
	echo "Državljanstvo: <b>".$R["drzavljanstvo"]."</b><br />";
	echo "EMŠO: <b>".$R["EMSO"]."</b>, davčna številka: <b>".$R["Davcna"]."</b><br />";
	echo "Naslov stalnega prebivališča: <b>".$R["Naslov"]."</b><br />";
	echo "Poštna številka: <b>".$R["Posta"]."</b>, kraj: <b>".$R["Kraj"]."</b>, občina: <b>".$VObcina."</b>, država: <b>".$VDrzava."</b><br />";
	if (strlen($R["NaslovZac"] > 0)){
		echo "Naslov začasnega prebivališča: <b>".$R["NaslovZac"]."</b><br />";
		echo "Poštna številka: <b>".$R["PostaZac"]."</b>, kraj: <b>".$R["KrajZac"]."</b>, občina: <b>".$VObcinaZac."</b>, država: <b>".$VDrzavaZac."</b><br />";
	}

	if ($R["Invalid"]){
		echo "Invalidnost: <b>DA</b>    Kategorija invalidnosti: <b>".$R["KatInvalid"]."</b><br />";
	}else{
		echo "Invalidnost: <b>NE</b><br />";
	}
	
	echo "Delna upokojitev: <b>".$R["DelnoUpokojen"]."</b><br />";
	echo "Izobrazba:<b> " . $R["Opis"] . " - " . $R["IzobOpis"] . "</b><br />";
	switch ($R["Status"]){
		case 1:
        case 2:
			echo "Vrsta sklenjene pogodbe: <b>Nedoločen čas</b><br />";
            break;
		case 4:
        case 5:
			echo "Vrsta sklenjene pogodbe: <b>Določen čas</b><br />";
            break;
		case 3:
			echo "Vrsta sklenjene pogodbe: <b>Določen čas - pripravnik</b><br />";
            break;
		case 6:
			echo "Vrsta sklenjene pogodbe: <b>Določen čas - volunterski pripravnik</b><br />";
            break;
		case 0:
			echo "Vrsta sklenjene pogodbe: <b>Ni več zaposlen</b><br />";
            break;
		case 10:
			echo "Vrsta sklenjene pogodbe: <b>Dopolnjuje delo z druge šole</b><br />";
	}
}

echo "<h2>Podatki o sklenjenih pogodbah o zaposlitvi</h2>";

$SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$ucitelj;
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
	echo "<h3>Številka pogodbe: <b>".$R["StPogodbe"]."</b></h3>";
	echo "Datum sklenitve pogodbe: <b>".$R["DatumPogodbe"]."</b><br />";
	echo "Datum nastopa dela: <b>".$R["DatumStart"]."</b><br />";
	
	if ($R["PolniDelCas"]=="Da"){
		echo "Delovni čas: <b>Polni čas</b><br />";
	}else{
		echo "Delovni čas: <b>Skrajšani čas</b><br />";
	}
	echo "Razlog sklenitve pogodbe za določen čas: <b>".$R["RazlogDolCas"]."</b><br />";
	if ($R["Izmensko"]){
		echo "Delovni čas (ur na teden): <b>".$R["UrTeden"]."</b>, Izmensko delo: <b>DA</b><br />";
	}else{
		echo "Delovni čas (ur na teden): <b>".$R["UrTeden"]."</b>, Izmensko delo: <b>NE</b><br />";
	}
	
	echo "Kraj delovnega mesta: <b>" . $R["KrajDela"] . "</b><br />";
	if ($R["KonkKlavz"]){
		echo "Konkurenčna klavzula: <b>DA</b><br />";
	}else{
		echo "Konkurenčna klavzula: <b>NE</b><br />";
	}
	
	if ($R["IzobUstr"]== 0){
		echo "Potrebna strokovna usposobljenost: <b>".$R["PotrStrokUsp"]." - ustrezna</b><br />";
	}else{
		echo "Potrebna strokovna usposobljenost: <b>".$R["PotrStrokUsp"]." - neustrezna</b><br />";
	}
	echo "Naziv delovnega mesta: <b>" . $R["NazivDelMesta"] . "</b><br />";

	if ($R["DopDelo"]){
		echo "Dopolnilno delo pri drugem delodajalcu: <b>DA</b><br />";
		if (strlen($R["Delodaj1"] > 0)){
			echo "Delodajalec 1: <b>".$R["Delodaj1"]."</b>, matična številka: <b>".$R["Delodaj1mat"]."</b><br />";
			echo "Delodajalec 1 naslov: <b>".$R["Delodaj1naslov"]."</b><br />";
		}
		if (strlen($R["Delodaj2"] > 0)){
			echo "Delodajalec 2: <b>".$R["Delodaj2"]."</b>, matična številka: <b>".$R["Delodaj2mat"]."</b><br />";
			echo "Delodajalec 2 naslov: <b>".$R["Delodaj2naslov"]."</b><br />";
		}
		if (strlen($R["Delodaj3"] > 0)){
			echo "Delodajalec 3: <b>".$R["Delodaj3"]."</b>, matična številka: <b>".$R["Delodaj3mat"]."</b><br />";
			echo "Delodajalec 3 naslov: <b>".$R["Delodaj3naslov"]."</b><br />";
		}
	}else{
		echo "Dopolnilno delo pri drugem delodajalcu: <b>NE</b><br />";
	}
	
	echo "<h3>Podatki o prenehanju pogodbe o zaposlitvi</h3>";
	echo "Datum prenehanja pogodbe: <b>".$R["DatumEnd"]."</b><br />";
	echo "Način prenehanja pogodbe: <b>".$R["NacinPrenehanja"]."</b><br />";
    echo "<hr>";
}	
?>
<br>

</body>
</html>
