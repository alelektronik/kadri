<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<?php
function LeadZero($x){
    if (strlen($x) < 2){
        $x="0".$x;
    }
    return $x;
}

function NoLeadZero($x){
    /*
    while (strpos($x,"0") == 0){
        $x=substr($x,1,(strlen($x)-1));
    }
    */
    return trim($x);
}
Function EAN8($BarTextIn){
    //' Initialize input and output strings
    $BarTextOut = "";
    $BarTextIn = trim($BarTextIn);

    //' Throw away non-numeric data
    $TempString = "";
    For ($II = 0;$II < strlen($BarTextIn);$II++){
        if (is_numeric(substr($BarTextIn, $II, 1)) ){ 
            $TempString = $TempString . substr($BarTextIn, $II, 1);
        }
    }

    //' Better be 7 digits long, or error it
    while (strlen($TempString) < 7 ){ 
        $TempString = "0".$TempString;
    }

    If (strlen($TempString) > 7 ){ 
        $TempString = substr($TempString,0,7);
    }
    //' Now calculate checksum and character map left and right sides
    $Sum = 0;
    $WorkL = "";
    $WorkR = "";
    For ($II = 0;$II < 7;$II++){
        If (($II % 2) == 0 ){
            $Sum = $Sum + (3 * substr($TempString, $II, 1));
        }else{
            $Sum = $Sum + substr($TempString, $II, 1);
        }

        If ($II < 4 ){
            $WorkL = $WorkL . Chr(ord(substr($TempString, $II, 1)) + 17);
        }else{
            $WorkR = $WorkR . substr($TempString, $II, 1);
        }
    }

    //' Build actual checksum character
    $CheckSumValue = 10 - ($Sum % 10);
    If ($CheckSumValue == 10 ){ 
        $CheckSumValue = 0;
    }
    $CheckSum = Chr(48 + $CheckSumValue);
    return $CheckSum;
    
    //' Build working bar code string
    $BarCodeOut = "[" . $WorkL . "|" . $WorkR . $CheckSum . "] ";

    return $BarCodeOut;
}

$naprej=false;
if (isset($_GET["uporabnik"])){
    $VDelavec=$_GET["uporabnik"];
    if ((strlen($VDelavec) > 4)&&(strlen($VDelavec) <= 8)) {
        $str_del=substr($VDelavec,0,(strlen($VDelavec)-1));
        $str_delc=substr($VDelavec,strlen($VDelavec)-1,1);
        if ($str_delc == EAN8($str_del)){
            $VDelavec=NoLeadZero(substr($VDelavec,0,(strlen($VDelavec)-1)));
            $VDelavec=intval($VDelavec)-2000;
        }else{
            $VDelavec="-";
        }
    }else{
        $VDelavec="-";
    }
    $VUporabnik="";
    if ($VDelavec != "-"){
        $SQL = "SELECT uporabnik FROM tabucitelji WHERE iducitelj=".$VDelavec;
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $VUporabnik=$R["uporabnik"];
            $naprej=true;
        }
    }
}

if (isset($_GET["nadom"]) && $naprej){
    $SQL = "SELECT * FROM tabnadomescanja WHERE id=".$_GET["nadom"];
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        if ($VDelavec == $R["ucitelj2"]){ //če je koda delavca pravilna
            $DanObracuna=new DateTime(isDate($R["datumNad"]));
            $VLeto=$DanObracuna->format('Y');
            $VMesec=$DanObracuna->format('n');
            /*
            if (strlen($_GET["uporabnik"]) > 0){
                $VUporabnik=$_GET["uporabnik"];
            }else{
                $SQL = "SELECT uporabnik FROM tabucitelji WHERE iducitelj=".$R["ucitelj2"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    $VUporabnik=$R1["uporabnik"];
                }else{
                    $VUporabnik="Ni izbran";
                }
            }
            */
            $Datum=new DateTime($DanObracuna->format('Y-m-d'));

            $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
            $result1 = mysqli_query($link,$SQL);

            $Indx=1;
            while ($R1 = mysqli_fetch_array($result1)){
                $ucitelj[$Indx][0]=$R1["iducitelj"];
                $ucitelj[$Indx][1]=$R1["priimek"]." ".$R1["ime"];
                $ucitelj[$Indx][2]=true;
                $Indx=$Indx+1;
            }
            $ucitelj[$Indx][0]=-1;
            $ucitelj[$Indx][1]="Anglisti";
            $ucitelj[$Indx][2]=true;
            $Indx=$Indx+1;
            $ucitelj[$Indx][0]=-2;
            $ucitelj[$Indx][1]="Slavisti";
            $ucitelj[$Indx][2]=true;
            $Indx=$Indx+1;
            $ucitelj[$Indx][0]=-3;
            $ucitelj[$Indx][1]="Matematiki";
            $ucitelj[$Indx][2]=true;
            $Indx=$Indx+1;
            $ucitelj[$Indx][0]=0;
            $ucitelj[$Indx][1]="Ni izbran";
            $ucitelj[$Indx][2]=false;
            $StUciteljev=$Indx;

            if ($VMesec > 8){
                $SQL = "SELECT * FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
            }else{
                $SQL = "SELECT * FROM tabrazdat WHERE leto=".($VLeto-1)." ORDER BY razred,oznaka";
            }    
            $result1 = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R1 = mysqli_fetch_array($result1)){
                $razred[$Indx][0]=$R1["razred"].". ".$R1["oznaka"];
                $razred[$Indx][1]=$R1["id"];
                $Indx=$Indx+1;
            }
            $StRazredov=$Indx-1;

            $SQL = "SELECT * FROM tabprostor";
            $result1 = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R1 = mysqli_fetch_array($result1)){
                $Prostor[$Indx][0]=$R1["IdProstor"];
                $Prostor[$Indx][1]=$R1["Opis"];
                $Prostor[$Indx][2]=true;
                $VProstor[$R1["IdProstor"]][0] = $R1["IdProstor"];
                $VProstor[$R1["IdProstor"]][1] = $R1["Stevilka"];
                $VProstor[$R1["IdProstor"]][2] = $R1["Oznaka"];
                $VProstor[$R1["IdProstor"]][3] = $R1["Opis"];
                $Indx=$Indx+1;
            }
            $Prostor[$Indx][0]=-1;
            $Prostor[$Indx][1]="Isti prostor";
            $Prostor[$Indx][2]=false;
            $StProstorov=$Indx;
            $VStProstorov=$Indx-1;

            $SQL = "SELECT * FROM tabpredmeti ORDER BY oznaka";
            $result1 = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R1 = mysqli_fetch_array($result1)){
                $Predmet[$Indx][0]=$R1["Id"];
                $Predmet[$Indx][1]=$R1["Oznaka"];
                $Indx=$Indx+1;
            }
            $StPredmetov=$Indx-1;

            $SQL = "SELECT * FROM TabNadomOblika";
            $result1 = mysqli_query($link,$SQL);
            $Indx=1;
            while ($R1 = mysqli_fetch_array($result1)){
                $Nadomescanje[$Indx][0]=$R1["id"];
                $Nadomescanje[$Indx][1]=$R1["nadomescanje"];
                $Indx=$Indx+1;
            }
            $StNadomescanj=$Indx-1;
            
            if (intval($Datum->format('Ymd'))-intval($Danes->format('Ymd')) >= 0){
                if ($R["potrjeno"]){
                    $SQL = "UPDATE tabnadomescanja SET potrjeno=false WHERE id=".$R["id"];
                    if (!($result1 = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu!<br />$SQL <br />");
                    }
                    
                    //pobriše iz pregledov dela
                    $SQL = "SELECT TabNadomescanja.*,tabpredmeti.* FROM TabNadomescanja INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id WHERE TabNadomescanja.id=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    
                    if ($R1 = mysqli_fetch_array($result1)){
                        $Prenos[0]=$R1["ucitelj2"];
                        $Prenos[1]=$R1["predmet"];
                        $Prenos[2]=$R1["Oznaka"];
                        $Prenos[3]=$R1["datumNad"];
                        $Prenos[4]=$R1["ura"];
                        for ($i1=1;$i1 <= $StUciteljev;$i1++){
                            if ($ucitelj[$i1][0]==$R1["ucitelj2"] ){
                                $Prenos[5]=$ucitelj[$i1][1];
                                break;
                            }
                        }
                        $Prenos[6]=$R1["razred"].$R1["paralelka"];
                        $SQL = "SELECT * FROM tabpregleddelan WHERE leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j')." AND ucitelj=".$Prenos[0]." AND komentar LIKE '%".$Prenos[4].". ura ".$Prenos[2]."%'";
                        $result1 = mysqli_query($link,$SQL);
                        if ($R1 = mysqli_fetch_array($result1)){
                            //echo "Učitelj/ica ".$Prenos[5]." ima že vpisano nadomeščanje ".$Prenos[3]." - ".$Prenos[4].". ura ".$Prenos[2]."<br />";
                            $zevpisano=true;
                            $SQL = "DELETE FROM tabpregleddelan WHERE id=".$R1["id"];
                            if (!($result1 = mysqli_query($link,$SQL))){
                                die("Napaka pri brisanju!<br />$SQL <br />");
                            }
                        }
                    }
                }else{
                    $SQL = "UPDATE tabnadomescanja SET potrjeno=true WHERE id=".$R["id"];
                    if (!($result1 = mysqli_query($link,$SQL))){
                        die("Napaka pri vpisu!<br />$SQL <br />");
                    }
                    
                    //vpiše med preglede dela
                    $SQL = "SELECT TabNadomescanja.*,tabpredmeti.* FROM TabNadomescanja INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id WHERE TabNadomescanja.id=".$R["id"];
                    $result1 = mysqli_query($link,$SQL);
                    
                    if ($R1 = mysqli_fetch_array($result1)){
                        $Prenos[0]=$R1["ucitelj2"];
                        $Prenos[1]=$R1["predmet"];
                        $Prenos[2]=$R1["Oznaka"];
                        $Prenos[3]=$R1["datumNad"];
                        $Prenos[4]=$R1["ura"];
                        for ($i1=1;$i1 <= $StUciteljev;$i1++){
                            if ($ucitelj[$i1][0]==$R1["ucitelj2"] ){
                                $Prenos[5]=$ucitelj[$i1][1];
                                break;
                            }
                        }
                        $Prenos[6]=$R1["razred"].$R1["paralelka"];
                        $SQL = "SELECT * FROM tabpregleddelan WHERE leto=".$Datum->format('Y')." AND mesec=".$Datum->format('n')." AND dan=".$Datum->format('j')." AND ucitelj=".$Prenos[0]." AND komentar LIKE '%".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."%'";
                        $result2 = mysqli_query($link,$SQL);
                        $zevpisano=false;
                        if ($R2 = mysqli_fetch_array($result2)){
                            //echo "Učitelj/ica ".$Prenos[5]." ima že vpisano nadomeščanje ".$Prenos[3]." - ".$Prenos[4].". ura ".$Prenos[2]."<br />";
                            $zevpisano=true;
                        }else{
                            $SQL = "INSERT INTO tabpregleddelan (";
                            $SQL = $SQL ."datum,leto,mesec,dan,rubrika,enot,komentar,EnotPotrjeno,DatVnosa,ucitelj,Vpisal,potrdil,cas";
                            $SQL = $SQL .") VALUES (";
                            $SQL = $SQL ."'".$Datum->format('Y-m-d')."',".$Datum->format('Y').",".$Datum->format('n').",".$Datum->format('j').",";
                            switch ($R1["oblika"]){
                                case 1:
                                    switch ($Prenos[1]){
                                        case 52:
                                        case 78:
                                        case 79:
                                        case 80:
                                        case 81:
                                        case 82:
                                        case 83:
                                        case 84:
                                        case 85:
                                        case 86:
                                        case 87:
                                        case 88:
                                        case 89:
                                        case 90:
                                        case 91: // 'OPB
                                            $SQL = $SQL . "10,50,";
                                            break;
                                        default: //    'pedagoške ure
                                            $SQL = $SQL . "9,1,";
                                    }
                                    break;
                                case 2: //združeno. nadzor
                                case 3:
                                    $SQL = $SQL . "25,0.5,";
                            }
                            $SQL = $SQL ."'".$Prenos[4].". ura ".$Prenos[2]." ".$Prenos[6]."',false,'".$Danes->format('Y-m-d H:i:s')."',".$Prenos[0].",'".$VUporabnik."','','".$Danes->format('Y-m-d H:i:s')."'";
                            $SQL = $SQL .")";
                            if (!($result2 = mysqli_query($link,$SQL))){
                                die("Napaka pri vpisu!<br />$SQL<br />");
                            }
                            
                            //echo "Učitelj/ica ".$Prenos[5]." ima dodano novo nadomeščanje ".$Prenos[3]." - ".$Prenos[4].". ura ".$Prenos[2]."<br />";
                        }
                    }
                }
            }else{
                echo "<h3>Časovno okno za popravljanje podatkov je zaprto!</h3>";
            }
            $SQL = "SELECT TabNadomescanja.*,TabNadomOblika.nadomescanje,tabpredmeti.oznaka FROM ";
            $SQL = $SQL . "(TabNadomescanja INNER JOIN TabNadomOblika ON TabNadomescanja.oblika=TabNadomOblika.id) ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON TabNadomescanja.predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE datumNad ='".$DanObracuna->format('d.m.Y')."'";
            $SQL = $SQL . " ORDER BY razred,paralelka,ura";
            $result = mysqli_query($link,$SQL);
            
            //izpis nadomeščanj
            echo "<table border=1 cellspacing=0>";
            echo "<tr>";
            echo "<th>Št.</th>";
            echo "<th>Datum</th>";
            echo "<th>Razred</th>";
            echo "<th>Ura</th>";
            echo "<th>Predmet</th>";
            echo "<th>Prostor</th>";
            echo "<th>Odsotni učitelj</th>";
            echo "<th>Nadomestni učitelj</th>";
            echo "<th>Nadomestni prostor</th>";
            echo "<th>Dejavnost</th>";
            echo "<th>Učitelj<br />potrdil</th>";
            echo "</tr>";
            
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($R["potrjeno"]){
                    echo "<tr bgcolor='lightgreen'>";
                }else{
                    echo "<tr>";
                }
                echo "<td align=center><br />".$Indx."<br /><br /></td>";
                echo "<td>".$R["datumNad"]."</td>";
                echo "<td align=center>".$R["razred"].". ".$R["paralelka"]."</td>";
                echo "<td align=center>".$R["ura"]."</td>";
                echo "<td>".$R["oznaka"]."</td>";
                $p=false;
                for ($i1=1;$i1 <= $StProstorov;$i1++){
                    if ($Prostor[$i1][0]==$R["prostor1"] ){
                        echo "<td>".$Prostor[$i1][1]."</td>";
                        $p=true;
                        break;
                    }
                }
                if (!$p){
                    echo "<td>&nbsp;</td>";
                }
                $p=false;
                for ($i1=1;$i1 <= $StUciteljev;$i1++){
                    if ($ucitelj[$i1][0]==$R["ucitelj1"] ){
                        echo "<td>".$ucitelj[$i1][1]."</td>";
                        $p=true;
                        break;
                    }
                }
                if (!$p){
                    echo "<td>&nbsp;</td>";
                }
                $p=false;
                for ($i1=1;$i1 <= $StUciteljev;$i1++){
                    if ($ucitelj[$i1][0]==$R["ucitelj2"] ){
                        echo "<td>".$ucitelj[$i1][1]."</td>";
                        $p=true;
                        break;
                    }
                }
                if (!$p){
                    echo "<td>&nbsp;</td>";
                }
                $p=false;
                for ($i1=1;$i1 <= $StProstorov;$i1++){
                    if ($Prostor[$i1][0]==$R["prostor2"] ){
                        echo "<td>".$Prostor[$i1][1]."</td>";
                        $p=true;
                        break;
                    }
                }
                if (!$p){
                    echo "<td>&nbsp;</td>";
                }
                echo "<td>".$R["nadomescanje"]."</td>";
                
                echo "<td align='center'>";
                //echo "<input name='pid_".$Indx."' type='hidden' value='".$R["id"]."'>";
                if (intval($R["ucitelj2"]) > 0){
                    if ($R["potrjeno"]){
                        echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' checked='checked' onchange='potrditevNadomescanja(".$R["id"].")'>";
                    }else{
                        echo "<input id='potrditev_".$R["id"]."' name='p_".$R["id"]."' type='checkbox' onchange='potrditevNadomescanja(".$R["id"].")'>";
                    }
                }
                echo "</td>";
                
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
        }
    }
}else{
    echo "<h2>Napačna koda!</h2>";
}
mysqli_close($link);
?>
