<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Požarna varnost
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
	case "1":   //popravljanje in dodajanje zapisa
		for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
			if (isset($_POST["PozVarnost".$Indx]) ){
                if (isset($_POST["PeriodaPV".$Indx])){
				    $PeriodaPV=$_POST["PeriodaPV".$Indx];
                }else{
					$PeriodaPV=4;
				}
				$SQL = "UPDATE tabucitelji SET PeriodaPV=".$PeriodaPV.", PozVarnost='".$_POST["PozVarnost".$Indx]."' WHERE idUcitelj=".$_POST["ucitelj".$Indx];
				$result = mysqli_query($link,$SQL);
				
				$SQL = "SELECT * FROM TabPozVarnost WHERE idUcitelj=".$_POST["ucitelj".$Indx]." AND datum='".$_POST["PozVarnost".$Indx]."'";
				$result = mysqli_query($link,$SQL);
				
				if ($R = mysqli_fetch_array($result)){
					$PeriodaPV=$PeriodaPV;
				}else{
					$SQL = "INSERT INTO TabPozVarnost (idUcitelj,datum) VALUES (".$_POST["ucitelj".$Indx].",'".$_POST["PozVarnost".$Indx]."')";
					$result = mysqli_query($link,$SQL);
				}
			}
		}
        break;
	case "2":
		$SQL = "SELECT tabucitelji.*,TabPozVarnost.* FROM tabucitelji INNER JOIN TabPozVarnost ON tabucitelji.idUcitelj=TabPozVarnost.idUcitelj ";
		$SQL = $SQL . "WHERE tabucitelji.idUcitelj=".$_GET["delavec"];
		$result = mysqli_query($link,$SQL);
		
		echo "<br><table border='1'>";
		echo "<tr><th>Št.</th><th>Ime</th><th>Izpit požarne varnosti</th></tr>";
		$Indx=1;
		while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$Indx."</td>";
			echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
			echo "<td align='right'>".$R["datum"]."</td>";
			echo "</tr>";
			$Indx=$Indx+1;
		}
		echo "</table><br />";
        break;
    case "3":
        $SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
        $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
        $SQL = $SQL . "WHERE (tabucitelji.Status > 0 AND tabucitelji.Status < 10) ";
        $SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
        //echo "<br>" & $SQL & "<br>"
        $result = mysqli_query($link,$SQL);

        $Indx=1;

        echo "<h2>Pregled delavcev z opravljenimi izpiti iz požarne varnosti</h2>";
        echo "<table border=1 cellspacing='0'>";
        echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
        echo "<th>Star</th>";
        echo "<th>Opis dela</th><th>Ponavljanje<br />pregledov (let)</th><th>Zadnji izpit<br />pož. varnost</th>";
        echo "</tr>";
        $ColorChange=true;

        while ($R = mysqli_fetch_array($result)){
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
            if ($ColorChange ){
                if (!isDate($oUcitelj->getPozVarnost()) ){
                    echo "<tr bgcolor='lightsalmon'>";
                }else{
                    if (! is_numeric($oUcitelj->getPeriodaPV()) ){
                        $PeriodaPV=4;
                    }else{
                        $PeriodaPV=$oUcitelj->getPeriodaPV();
                    }
                    $Datum=new DateTime(isDate($oUcitelj->getPozVarnost()));
                    $Interval=$Datum->diff($Danes);
                    if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*365)){
                        echo "<tr bgcolor='lightsalmon'>";
                    }else{
                        echo "<tr bgcolor='lightyellow'>";
                    }
                }
            }else{
                if (!isDate($oUcitelj->getPozVarnost()) ){
                    echo "<tr bgcolor='lightsalmon'>";
                }else{
                    if (! is_numeric($oUcitelj->getPeriodaPV()) ){
                        $PeriodaPV=4;
                    }else{
                        $PeriodaPV=$oUcitelj->getPeriodaPV();
                    }
                    $Datum=new DateTime(isDate($oUcitelj->getPozVarnost()));
                    $Interval=$Datum->diff($Danes);
                    if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*365)){
                        echo "<tr bgcolor='lightsalmon'>";
                    }else{
                        echo "<tr bgcolor=#FFFFCC>";
                    }
                }
            }
            $ColorChange=!$ColorChange;
            echo "<td>".$Indx."</td>";
            echo "<td>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</td>";
            echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
            echo "<td>";
            echo "<b>".$oUcitelj->getDelMesto()."</b>";
            echo "&nbsp;</td>";
            echo "<td align='center'>".$oUcitelj->getPeriodaPV()."</td>";
            echo "<td align='right'>".$oUcitelj->getPozVarnost()."</td>";
            echo "</tr>";
            $oUcitelj=null;
            $Indx=$Indx+1;
        }
        echo "</table><br />";
        break;
}
$SQL = "SELECT tabucitelji.*, TabStatus.Status FROM ";
$SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
$SQL = $SQL . "WHERE (tabucitelji.Status > 0 AND tabucitelji.Status < 10) ";
$SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
//echo "<br>" & $SQL & "<br>"
$result = mysqli_query($link,$SQL);

$Indx=1;

echo "<h2>Pregled delavcev z opravljenimi izpiti iz požarne varnosti</h2>";
echo "<form name='form_PozVarnost' method=post action='PozarnaVarnost.php'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "<table border=1 cellspacing='0'>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
echo "<th>Star</th>";
echo "<th>Opis dela</th><th>Ponavljanje<br>pregledov (let)</th><th>Zadnji izpit<br>pož. varnost</th>";
echo "</tr>";
$ColorChange=true;

while ($R = mysqli_fetch_array($result)){
	$oUcitelj=new RUcitelj();
	$oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$VLetoPregled,$VLeto);
	if ($ColorChange ){
		if (!isDate($oUcitelj->getPozVarnost()) ){
			echo "<tr bgcolor='lightsalmon'>";
		}else{
			if (! is_numeric($oUcitelj->getPeriodaPV()) ){
				$PeriodaPV=4;
			}else{
				$PeriodaPV=$oUcitelj->getPeriodaPV();
			}
            $Datum=new DateTime(isDate($oUcitelj->getPozVarnost()));
            $Interval=$Datum->diff($Danes);
			if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*365)){
				echo "<tr bgcolor='lightsalmon'>";
			}else{
				echo "<tr bgcolor='lightyellow'>";
			}
		}
	}else{
        if (!isDate($oUcitelj->getPozVarnost()) ){
            echo "<tr bgcolor='lightsalmon'>";
        }else{
            if (! is_numeric($oUcitelj->getPeriodaPV()) ){
                $PeriodaPV=4;
            }else{
                $PeriodaPV=$oUcitelj->getPeriodaPV();
            }
            $Datum=new DateTime(isDate($oUcitelj->getPozVarnost()));
            $Interval=$Datum->diff($Danes);
            if (($Interval->invert == 0) && ($Interval->days > $PeriodaPV*365)){
                echo "<tr bgcolor='lightsalmon'>";
            }else{
                echo "<tr bgcolor=#FFFFCC>";
            }
        }
	}
	$ColorChange=!$ColorChange;
	echo "<td>".$Indx."</td>";
	echo "<td><input name='ucitelj".$Indx."' type='hidden' value='".$oUcitelj->getIdUcitelj()."'><a href='PozarnaVarnost.php?id=2&delavec=".$oUcitelj->getIdUcitelj()."'>".$oUcitelj->getPriimek().", ".$oUcitelj->getIme()."</a></td>";
	echo "<td align=center>".($VLeto+1-$oUcitelj->getDatRoj()->format('Y'))."</td>";
	echo "<td>";
	echo "<b>".$oUcitelj->getDelMesto()."</b>";
	echo "&nbsp;</td>";
	echo "<td><input name='PeriodaPV".$Indx."' type='text' value='".$oUcitelj->getPeriodaPV()."' size='3'></td>";
	echo "<td><input name='PozVarnost".$Indx."' type='text' value='".$oUcitelj->getPozVarnost()."' size='8'></td>";
	echo "</tr>";
	$oUcitelj=null;
	$Indx=$Indx+1;
}
echo "</table>";
echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form><br />";
echo "<a href='PozarnaVarnost.php?id=3'>Izpis primeren za Excel</a><br />";
?>

</body>
</html>
