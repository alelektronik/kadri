<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
/*
if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
*/
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSola=$R["Sola"];
    $VNaslov=$R["Naslov"];
    $VPosta=$R["Posta"]." ".$R["Kraj"];
    $VRavnatelj=$R["Ravnatelj"];
    $VKraj=$R["Kraj"];
}else{
    $VSola=" ";
    $VNaslov=" ";
    $VPosta=" ";
    $VRavnatelj=" ";
    $VKraj=" ";
}

if (isset($_GET["spisek"])){
    $VSpisek=$_GET["spisek"];
}else{
    $VSpisek="";
}
if (isset($_POST["StZapisov"])){
    $StZapisov=$_POST["StZapisov"];
}else{
    $StZapisov=0;
}

if ($VSpisek == ""){
    for ($Indx=1;$Indx <= $StZapisov;$Indx++){
        if (isset($_POST["pn".$Indx])){
            if (strlen($VSpisek)==0){
                $VSpisek=$_POST["idpn".$Indx];
            }else{
                $VSpisek=$VSpisek.",".$_POST["idpn".$Indx];
            }
        }
    }
}

$SQL = "SELECT * FROM TabPotniNalog ";
$SQL = $SQL . "WHERE TabpotniNalog.id IN (".$VSpisek.") ";
$SQL = $SQL . " ORDER BY ZapSt";
$result = mysqli_query($link,$SQL);

$pdf = new FPDF();

//$pdf->AddFont('EAN_b','','EAN_b.php');
$pdf->AddFont('arial_CE','','arial_CE.php');
$pdf->AddFont('arialbd_CE','','arialbd_CE.php');
$pdf->SetAutoPageBreak(0);

$XPoz[1]=12;
$XPoz[2]=42;
$XPoz[3]=63;
$XPoz[4]=103;
$XPoz[5]=158;
$XPoz[6]=200;

$IndxPN=0;
while ($R = mysqli_fetch_array($result)){
    $IndxPN=$IndxPN+1;
    $oUcitelj=new RUcitelj();
    $oUcitelj->PreberiSeGlavno($R["idUcitelj"],$VLeto,$VLeto);
    
    $pdf->AddPage("P","A4");

    $VStorno=mb_strpos($R["Odredbodajalec"],"TORNO",0,$encoding);
    if ($VStorno > 0){
        $pdf->Image("img/stornirano.jpg",1,1,210);
    }

    $pdf->Image("logo1.gif",$XPoz[1],10,30);

    $pdf->SetFont('arialbd_CE','',10);
    $txt=ToWin($VSola."\n".$VNaslov."\n".$VPosta);
    $pdf->SetXY($XPoz[2],10);
    $pdf->MultiCell($XPoz[4]-$XPoz[2]+20,5,$txt,0,"L");
    
    $Datum=new DateTime($R["Datum"]);
    
    $pdf->SetFont('arialbd_CE','',14);
    $txt=ToWin("NALOG\nza službeno potovanje\nŠt.: ".$R["ZapSt"]."\nDatum: ".$Datum->format('d.m.Y'));
    $pdf->SetXY($XPoz[4]+20,10);
    $pdf->MultiCell($XPoz[6]-$XPoz[4],5,$txt,0,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Odrejam, da odpotuje");
    $pdf->SetXY($XPoz[1],44);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($oUcitelj->getIme()." ".$oUcitelj->getPriimek());
    $pdf->SetXY($XPoz[3],44);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Na delovnem mestu");
    $pdf->SetXY($XPoz[1],47);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($oUcitelj->getDelMesto());
    $pdf->SetXY($XPoz[3],47);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Stanujoč");
    $pdf->SetXY($XPoz[1],51);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj());
    $pdf->SetXY($XPoz[3],51);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $Datum=new DateTime($R["DanOdhoda"]." ".$R["UraOdhoda"]);
   
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("dne");
    $pdf->SetXY($XPoz[1],57);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($Datum->format('d.m.Y')." ob ".$Datum->format('H:i')." uri");
    $pdf->SetXY($XPoz[3],57);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("po nalogu");
    $pdf->SetXY($XPoz[1],62);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["Odlocba"]);
    $pdf->SetXY($XPoz[3],62);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("v/na");
    $pdf->SetXY($XPoz[1],65);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["Kam"]);
    $pdf->SetXY($XPoz[3],65);
    $pdf->MultiCell(0,3,$txt,0,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("z nalogo");
    $pdf->SetXY($XPoz[1],75);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["Naloga"]);
    $pdf->SetXY($XPoz[3],75);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $Datum=new DateTime($R["DanPrihoda"]);

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Potovanje bo trajalo do");
    $pdf->SetXY($XPoz[1],84);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($Datum->format('d.m.Y'));
    $pdf->SetXY($XPoz[3],84);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("to je ".$R["Dni"]." dni");
    $pdf->SetXY($XPoz[5],84);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Odobravam uporabo (avtomobila, letala, itd...)");
    $pdf->SetXY($XPoz[1],89);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["PrevSredstvo"]);
    $pdf->SetXY($XPoz[4],89);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Potne stroške plača");
    $pdf->SetXY($XPoz[1],98);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["Placnik"]);
    $pdf->SetXY($XPoz[3],98);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Višina dnevnice EUR");
    $pdf->SetXY($XPoz[1],102);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin(number_format($R["Dnevnica"],2));
    $pdf->SetXY($XPoz[3],102);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Posebni dodatki EUR");
    $pdf->SetXY($XPoz[4],102);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin(number_format($R["Dodatki"],2));
    $pdf->SetXY($XPoz[5],102);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Odobravam izplačilo predujma v znesku EUR");
    $pdf->SetXY($XPoz[1],107);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin(number_format($R["Predujem"],2));
    $pdf->SetXY($XPoz[4],107);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($R["Odredbodajalec"]);
    $pdf->SetXY($XPoz[5],116);
    $pdf->Cell(0,0,$txt,0,2,"L");
    
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("M.P.");
    $pdf->SetXY($XPoz[4],120);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("Podpis odredbodajalca");
    $pdf->SetXY($XPoz[5],120);
    $pdf->Cell(0,0,$txt,0,2,"L");

    //obračun potnih stroškov
    
    $pdf->SetFont('arialbd_CE','',14);
    $txt=ToWin("OBRAČUN\npotnih stroškov");
    $pdf->SetXY($XPoz[1],142);
    $pdf->MultiCell($XPoz[4]-$XPoz[1],5,$txt,0,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Ime in priimek predlagatelja");
    $pdf->SetXY($XPoz[1],157);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($oUcitelj->getIme()." ".$oUcitelj->getPriimek());
    $pdf->SetXY($XPoz[3],157);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Prebivališče");
    $pdf->SetXY($XPoz[1],160);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($oUcitelj->getNaslov().", ".$oUcitelj->getPosta()." ".$oUcitelj->getKraj());
    $pdf->SetXY($XPoz[3],160);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt="\nDatum odhoda ";
    if (isset($R["DanOdhodaObr"])){
        $Datum=new DateTime($R["DanOdhodaObr"]." ".$R["UraOdhodaObr"]);
        $txt=$txt.$Datum->format('d.m.Y')." ob ".$Datum->format('H:i')." uri\n";
    }else{
        $txt=$txt."______________ ob _______________ uri\n";
    }
    $txt=$txt."\nDatum vrnitve  ";
    if (isset($R["DanPrihodaObr"])){
        $Datum=new DateTime($R["DanPrihodaObr"]." ".$R["UraPrihodaObr"]);
       $txt=$txt.$Datum->format('d.m.Y')." ob ".$Datum->format('H:i')." uri\n\n";
    }else{
        $txt=$txt."______________ ob _______________ uri\n\n";
    }
    $txt=$txt."Odsotnost: ";
    if (isset($R["DanOdhodaObr"])){
        $Datum=new DateTime($R["DanPrihodaObr"]." ".$R["UraPrihodaObr"]);
       $txt=$txt.$R["DniObr"]." dni, ".$R["UrObr"]." ur, ".$R["MinObr"];
    }else{
        $txt=$txt."___________ dni, ___________ ur, __________ min.";
    }
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],164);
    $pdf->SetFillColor(195,195,195);
    $pdf->MultiCell($XPoz[5]-$XPoz[1],3,$txt,1,"L",true);

    
    if (isset($R["Dnevnic"])){
        $Dnevnic=$R["Dnevnic"];
    }else{
        $Dnevnic=0;
    }
    if (isset($R["Dnevnica"])){
        $Dnevnica=$R["Dnevnica"];
    }else{
        $Dnevnica=0;
    }
    if (isset($R["ProcentZnizanja"])){
        $ProcentZnizanja=$R["ProcentZnizanja"];
    }else{
        $ProcentZnizanja=0;
    }
    if (isset($R["ZnizanjeOd"])){
        $ZnizanjeOd=$R["ZnizanjeOd"];
    }else{
        $ZnizanjeOd=0;
    }
    if (isset($R["PrevStroski1"])){
        $PrevStroski1=$R["PrevStroski1"];
    }else{
        $PrevStroski1=0;
    }
    if (isset($R["PrevStroski2"])){
        $PrevStroski2=$R["PrevStroski2"];
    }else{
        $PrevStroski2=0;
    }
    if (isset($R["PrevStroski3"])){
        $PrevStroski3=$R["PrevStroski3"];
    }else{
        $PrevStroski3=0;
    }
    if (isset($R["PrevStroski4"])){
        $PrevStroski4=$R["PrevStroski4"];
    }else{
        $PrevStroski4=0;
    }
    if (isset($R["DrugiStroski1"])){
        $DrugiStroski1=$R["DrugiStroski1"];
    }else{
        $DrugiStroski1=0;
    }
    if (isset($R["DrugiStroski2"])){
        $DrugiStroski2=$R["DrugiStroski2"];
    }else{
        $DrugiStroski2=0;
    }
    if (isset($R["PrevStroskiTxt1"])){
        $PrevStroskiTxt1=$R["PrevStroskiTxt1"];
    }else{
        $PrevStroskiTxt1="";
    }
    if (isset($R["PrevStroskiTxt2"])){
        $PrevStroskiTxt2=$R["PrevStroskiTxt2"];
    }else{
        $PrevStroskiTxt2="";
    }
    if (isset($R["PrevStroskiTxt3"])){
        $PrevStroskiTxt3=$R["PrevStroskiTxt3"];
    }else{
        $PrevStroskiTxt3="";
    }
    if (isset($R["PrevStroskiTxt4"])){
        $PrevStroskiTxt4=$R["PrevStroskiTxt4"];
    }else{
        $PrevStroskiTxt4="";
    }
    if (isset($R["DrugiStroskiTxt1"])){
        $DrugiStroskiTxt1=$R["DrugiStroskiTxt1"];
    }else{
        $DrugiStroskiTxt1="";
    }
    if (isset($R["DrugiStroskiTxt2"])){
        $DrugiStroskiTxt2=$R["DrugiStroskiTxt2"];
    }else{
        $DrugiStroskiTxt2="";
    }
    if (isset($R["Priloge"])){
        $Priloge=$R["Priloge"];
    }else{
        $Priloge="";
    }
    if (isset($R["Predujem"])){
        $Predujem=$R["Predujem"];
    }else{
        $Predujem=0;
    }
/*
    if (isset($R["ZnizanjeOd"])){
        $ZnizanjeOd=$R["ZnizanjeOd"];
    }else{
        $ZnizanjeOd=0;
    }
    if (isset($R["ProcentZnizanja"])){
        $ProcentZnizanja=$R["ProcentZnizanja"];
    }else{
        $ProcentZnizanja=0;
    }
*/
    if (isset($R["OdobrenoIzpl"])){
        $OdobrenoIzpl=$R["OdobrenoIzpl"];
    }else{
        $OdobrenoIzpl=0;
    }
    if (isset($R["Placnik"])){
        $Placnik=$R["Placnik"];
    }else{
        $Placnik="";
    }
    $Znesek[1]=$Dnevnic*$Dnevnica;
    $Znesek[2]=$ProcentZnizanja/100*$ZnizanjeOd;
    $Znesek[3]=$Znesek[1]+$Znesek[2];
    $Znesek[4]=$Znesek[3]+$PrevStroski1+$PrevStroski2+$PrevStroski3+$PrevStroski4+$DrugiStroski1+$DrugiStroski2;
    $Znesek[5]=$Znesek[4]-$Predujem;
    
    if ($Dnevnic > 0){
        $txt="Število dnevnic: ".$Dnevnic." po ".$Dnevnica." EUR";
    }else{
        $txt="Število dnevnic: __________ po ____________ EUR";
    }

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],184);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"L");

    if ($Znesek[1] > 0){
        $txt=number_format($Znesek[1],2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,184);
    $pdf->MultiCell(20,4.5,$txt,1,"R");
    
    if ($ProcentZnizanja != 0){
        $txt=$ProcentZnizanja." % zvišanja/znižanja dnevnic od EUR ".$ZnizanjeOd;
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],188.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"L");

    if ($ProcentZnizanja != 0){
        $txt=number_format($Znesek[2],2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,188.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");
    
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Skupaj");
    $pdf->SetXY($XPoz[1],193);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");
    
    if ($Znesek[3] > 0){
        $txt=number_format($Znesek[3],2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,193);
    $pdf->MultiCell(20,4.5,$txt,1,"R");
    
    if ($PrevStroskiTxt1 != ""){
        $txt="Prevozni stroški ".$PrevStroskiTxt1;
    }else{
        $txt="Prevozni stroški";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],197.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"L");

    if ($PrevStroski1 > 0){
        $txt=number_format($PrevStroski1,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,197.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($PrevStroskiTxt2 != ""){
        $txt=$PrevStroskiTxt2;
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],202);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");

    if ($PrevStroski2 > 0){
        $txt=number_format($PrevStroski2,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,202);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($PrevStroskiTxt3 != ""){
        $txt=$PrevStroskiTxt3;
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],206.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");

    if ($PrevStroski3 > 0){
        $txt=number_format($PrevStroski3,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,206.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($PrevStroskiTxt4 != ""){
        $txt=$PrevStroskiTxt4;
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],211);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");

    if ($PrevStroski4 > 0){
        $txt=number_format($PrevStroski4,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,211);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($DrugiStroskiTxt1 != ""){
        $txt="Drugi stroški ".$DrugiStroskiTxt1;
    }else{
        $txt="Drugi stroški";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],215.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"L");

    if ($DrugiStroski1 > 0){
        $txt=number_format($DrugiStroski1,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,215.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($DrugiStroskiTxt2 != ""){
        $txt=$DrugiStroskiTxt2;
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],220);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");

    if ($DrugiStroski2 > 0){
        $txt=number_format($DrugiStroski2,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $pdf->SetXY($XPoz[5]-20,220);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Skupaj");
    $pdf->SetXY($XPoz[1],224.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");
    
    if ($Znesek[3] > 0){
        $txt=number_format($Znesek[4],2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $pdf->SetXY($XPoz[5]-20,224.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");
    
    if ($Predujem > 0){
        $txt="Predujem prejet dne ".$Datum->format('d.m.Y')." v znesku";
    }else{
        $txt="Predujem prejet dne _______________ v znesku ";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],229);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"L");

    if ($Predujem > 0){
        $txt=number_format($Predujem,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $pdf->SetXY($XPoz[5]-20,229);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    if ($Predujem >= 0){
        $txt="Ostane za izplačilo EUR";
    }else{
        $txt="Ostane za vračilo EUR";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],233.5);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,1,"R");

    if ($Predujem > 0){
        $txt=number_format($Znesek[5],2);
    }else{
        $txt=number_format(abs($Znesek[5]),2);
    }
    $pdf->SetFont('arialbd_CE','',8);
    $pdf->SetXY($XPoz[5]-20,233.5);
    $pdf->MultiCell(20,4.5,$txt,1,"R");


    if (strlen($Priloge) > 0){
        $txt="Priloge: ".$Priloge;
    }else{
        $txt="Priloge";
    }
    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[1],239);
    $pdf->MultiCell($XPoz[5]-$XPoz[1],4.5,$txt,1,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("V _________________________, dne _________________");
    $pdf->SetXY($XPoz[1],247);
    $pdf->MultiCell($XPoz[5]-$XPoz[1],3,$txt,0,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("_______________________\nPredlagatelj računa");
    $pdf->SetXY($XPoz[1],248);
    $pdf->MultiCell($XPoz[5]-$XPoz[1],3,$txt,0,"R");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Račun pregledal in odobril izplačilo EUR");
    $pdf->SetXY($XPoz[1],260);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,0,"L");

    if ($OdobrenoIzpl > 0){
        $txt=number_format($OdobrenoIzpl,2);
    }else{
        $txt=" ";
    }
    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($txt);
    $pdf->SetXY($XPoz[5]-20,260);
    $pdf->MultiCell(20,4.5,$txt,1,"R");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("v breme");
    $pdf->SetXY($XPoz[1],265);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin($Placnik);
    $pdf->SetXY($XPoz[3],265);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("______________________");
    $pdf->SetXY($XPoz[1],270);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("______________________");
    $pdf->SetXY($XPoz[3],270);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("Izplačano EUR");
    $pdf->SetXY($XPoz[1],269);
    $pdf->MultiCell($XPoz[5]-20-$XPoz[1],4.5,$txt,0,"R");

    $pdf->SetFont('arialbd_CE','',8);
    $txt=ToWin(" ");
    $pdf->SetXY($XPoz[5]-20,269);
    $pdf->MultiCell(20,4.5,$txt,1,"R");
    
    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("Likvidator");
    $pdf->SetXY($XPoz[1],273);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("Odredbodajalec");
    $pdf->SetXY($XPoz[3],273);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("____________________  M.P.");
    $pdf->SetXY($XPoz[1],278);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("_____________________");
    $pdf->SetXY($XPoz[3],278);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',8);
    $txt=ToWin("_____________________");
    $pdf->SetXY($XPoz[5],278);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("Za blagajno (žig in podpis)");
    $pdf->SetXY($XPoz[1],283);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("datum");
    $pdf->SetXY($XPoz[3],283);
    $pdf->Cell(0,0,$txt,0,2,"L");

    $pdf->SetFont('arial_CE','',6);
    $txt=ToWin("Podpis prejemnika");
    $pdf->SetXY($XPoz[5],283);
    $pdf->Cell(0,0,$txt,0,2,"L");
    
}
$pdf->Output("PotniNalogi.pdf","D");

?>