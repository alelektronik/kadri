<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Aktivi
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
/*    if ($Vid != "5"){
        echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
        echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    }
*/
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');
if (!CheckDostop("VnosAktivi",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}else{
        

    if (isset($_POST["ucitelj"])){
        $Ucitelj = $_POST["ucitelj"];
    }else{
        if (isset($_GET["ucitelj"])){
            $Ucitelj = $_GET["ucitelj"];
        }else{
            if (isset($_SESSION["ucitelj"])){ 
                $Ucitelj = $_SESSION["ucitelj"];
            }else{
                $Ucitelj = 0;
            }
        }
    }

    switch ($Vid){
        case "1a": //poročilo
            echo "Leto: <a href='IzborAktiviPorocilo.php?id=1a&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | ".$VLeto."/".($VLeto+1)." | <a href='IzborAktiviPorocilo.php?id=1a&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktivPorocilo.id AS pid FROM TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id WHERE leto=".$VLeto." OR leto=".($VLeto+1);
            $result = mysqli_query($link,$SQL);

            echo "<h2>Izbor poročila aktiva</h2>";
            echo "<table border=1 cellspacing=0>";
            echo "<tr><th>Št.</th><th>Leto</th><th>Aktiv</th><th>Čas vnosa</th><th>Popravi</th><th>Poglej</th>";
            if ($VLevel > 1 ){
                echo "<th>Briši</th>";
            }
            echo "</tr>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$Indx."</td>";
            echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
            echo "<td>".$R["aaktiv"]."</td>";
            echo "<td>".$R["datum"]."</td>";
            echo "<td><a href='IzborAktiviPorocilo.php?id=2a&zapis=".$R["pid"]."'>Popravi</a></td>";
            echo "<td><a href='IzborAktiviPorocilo.php?id=3a&zapis=".$R["pid"]."'>Poglej</a></td>";
            if ($VLevel > 1 ){
	            echo "<td><a href='IzborAktiviPorocilo.php?id=4a&zapis=".$R["pid"]."'>Briši</a></td>";
            }
            echo "</tr>";
            $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<a href='IzborAktiviPorocilo.php?id=0a'>Dodaj novo poročilo</a><br />";

            if ($VLevel > 1 ){
            echo "<br /><a href='IzborAktiviPorocilo.php?id=5a&solskoleto=".$VLeto."'>Pregled vseh poročil</a><br />";
            echo "<br /><a href='IzborAktiviPorocilo.php?id=6a&solskoleto=".$VLeto."'>Pregled vseh poročil po rubrikah</a><br />";
            }
            break;
        case "1b": //plan
            echo "Leto: <a href='IzborAktiviPorocilo.php?id=1b&solskoleto=".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</a> | ".$VLeto."/".($VLeto+1)." | <a href='IzborAktiviPorocilo.php?id=1b&solskoleto=".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</a><br />";
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktivPlan.id AS pid FROM TabAktivPlan INNER JOIN TabAktiv ON TabAktivPlan.aktiv=TabAktiv.id WHERE leto=".($VLeto+1);
            $result = mysqli_query($link,$SQL);

            echo "<h2>Izbor načrta aktiva</h2>";
            echo "<table border=1 cellspacing=0>";
            echo "<tr><th>Št.</th><th>Leto</th><th>Aktiv</th><th>Čas vnosa</th><th>Popravi</th><th>Poglej</th>";
            if ($VLevel > 1 ){
                echo "<th>Briši</th>";
            }
            echo "</tr>";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$Indx."</td>";
                echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
                echo "<td>".$R["aaktiv"]."</td>";
                echo "<td>".$R["datum"]."</td>";
                echo "<td><a href='IzborAktiviPorocilo.php?id=2b&zapis=".$R["pid"]."'>Popravi</a></td>";
                echo "<td><a href='IzborAktiviPorocilo.php?id=3b&zapis=".$R["pid"]."'>Poglej</a></td>";
                if ($VLevel > 1 ){
                    echo "<td><a href='IzborAktiviPorocilo.php?id=4b&zapis=".$R["pid"]."'>Briši</a></td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
            }
            echo "</table><br />";
            echo "<a href='IzborAktiviPorocilo.php?id=0b'>Dodaj nov načrt</a><br />";
            echo "<a href='IzborAktiviPorocilo.php?id=1b&solskoleto=".($VLeto-1)."'>Pregled načrtov preteklega leta</a><br />";

            if ($VLevel > 1 ){
                echo "<br />Pregled vseh načrtov: <a href='IzborAktiviPorocilo.php?id=5b&solskoleto=".$VLeto."'>".$VLeto."</a> <a href='IzborAktiviPorocilo.php?id=5b&solskoleto=".($VLeto+1)."'>".($VLeto+1)."</a><br />";
                echo "<br />Pregled vseh načrtov po rubrikah: <a href='IzborAktiviPorocilo.php?id=6b&solskoleto=".$VLeto."'>".$VLeto."</a> <a href='IzborAktiviPorocilo.php?id=6b&solskoleto=".($VLeto+1)."'>".($VLeto+1)."</a><br />";
            }
            break;
        
        case "2a": //popravi poročilo
            $zapis=$_GET["zapis"];
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id WHERE TabAktivPorocilo.id=".$zapis;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];
            }

            echo "<h2>Poročilo aktiva za šolsko leto:</h2>";
            echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='IzborAktiviPorocilo.php'>";
            echo "<input name='id' type='hidden' value='2a1'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";

            echo "<table border=0><tr>";
            
            echo "<td>Šolsko leto:</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
            echo "<input type=hidden name=solskoleto value='".$VLeto."'>";
            echo "<td>Aktiv:</td><td>".$Vaktiv."</td></tr>";
            echo "<input type=hidden name=aktiv value='".$VAktivId."'>";
            echo "</table>";
            
            echo "<b>Velja za naslednje razrede:</b><br />";
            for ($Indx=1;$Indx <= 9;$Indx++){
                if ($VRazred[$Indx]==1 ){
                    echo "<input name='razred".$Indx."' type='checkbox' checked>".$Indx.". razred<br />";
                }else{
                    echo "<input name='razred".$Indx."' type='checkbox'>".$Indx.". razred<br />";
                }
            }

            echo "<br /><b>Program dela</b><br />";
            echo "<textarea name='programDela' cols='80' rows='10'>".$VprogramDela."</textarea><br />";

            echo "<br /><a href='IzborRazredaDejavnosti.php'>Vnos dnevov dejavnosti</a><br /><br />";
            echo "Dnevi dejavnosti<br />";
            echo "<textarea name='dneviDejavnosti' cols='80' rows='10'>".$VdneviDejavnosti."</textarea><br />";

            echo "Dopolnilni in dodatni pouk<br />";
            echo "<textarea name='dopolnilniPouk' cols='80' rows='10'>".$VdopolnilniPouk."</textarea><br />";

            echo "Individualni pouk<br />";
            echo "<textarea name='individualniPouk' cols='80' rows='10'>".$VindividualniPouk."</textarea><br />";

            echo "Interesne dejavnosti<br />";
            echo "<textarea name='interesneDejavnosti' cols='80' rows='10'>".$VinteresneDejavnosti."</textarea><br />";

            echo "Roditeljski sestanki<br />";
            echo "<textarea name='roditeljskiSestanki' cols='80' rows='10'>".$VroditeljskiSestanki."</textarea><br />";

            echo "Delo v študijski skupini<br />";
            echo "<textarea name='studijskaSkupina' cols='80' rows='10'>".$VstudijskaSkupina."</textarea><br />";

            echo "Izobraževanje<br />";
            echo "<textarea name='izobrazevanje' cols='80' rows='10'>".$Vizobrazevanje."</textarea><br />";

            echo "Projekti<br />";
            echo "<textarea name='projekti' cols='80' rows='10'>".$Vprojekti."</textarea><br />";

            echo "Drugo ...<br />";
            echo "<textarea name='drugo' cols='80' rows='10'>".$Vdrugo."</textarea><br />";

            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            break;
        case "2a1": //vpis popravka
            for ($Indx=1;$Indx <= 9;$Indx++){
                if (isset($_POST["razred".$Indx])){
                    $VRazred[$Indx]=1;
                }else{
                    $VRazred[$Indx]=0;
                }
            }
            $VLeto = $_POST["solskoleto"];
            $Vaktiv = $_POST["aktiv"];
            $VprogramDela = $_POST["programDela"];
            $VdneviDejavnosti = $_POST["dneviDejavnosti"];
            $VdopolnilniPouk = $_POST["dopolnilniPouk"];
            $VindividualniPouk = $_POST["individualniPouk"];
            $VinteresneDejavnosti = $_POST["interesneDejavnosti"];
            $VroditeljskiSestanki = $_POST["roditeljskiSestanki"];
            $VstudijskaSkupina = $_POST["studijskaSkupina"];
            $Vizobrazevanje = $_POST["izobrazevanje"];
            $Vprojekti = $_POST["projekti"];
            $Vdrugo = $_POST["drugo"];

            $SQL = "SELECT * FROM TabAktivPorocilo WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $SQL = "UPDATE TabAktivPorocilo SET leto=".$VLeto.",razred1=".$VRazred[1].",razred2=".$VRazred[2].",razred3=".$VRazred[3].",razred4=".$VRazred[4].",razred5=".$VRazred[5].",razred6=".$VRazred[6].",razred7=".$VRazred[7].",razred8=".$VRazred[8].",razred9=".$VRazred[9];
                $SQL = $SQL .",programDela='".$VprogramDela."',dneviDejavnosti='".$VdneviDejavnosti."',dopolnilniPouk='".$VdopolnilniPouk."',individualniPouk='".$VindividualniPouk."',interesneDejavnosti='".$VinteresneDejavnosti."',roditeljskiSestanki='".$VroditeljskiSestanki."',studijskaSkupina='".$VstudijskaSkupina."',izobrazevanje='".$Vizobrazevanje."',projekti='".$Vprojekti."',drugo='".$Vdrugo."'";
                $SQL = $SQL .",avtor='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."' WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            }else{
                $SQL = "INSERT INTO TabAktivPorocilo (Leto,aktiv,razred1,razred2,razred3,razred4,razred5,razred6,razred7,razred8,razred9,";
                $SQL = $SQL . "programDela,dneviDejavnosti,dopolnilniPouk,individualniPouk,interesneDejavnosti,roditeljskiSestanki,studijskaSkupina,izobrazevanje,projekti,drugo,avtor,Datum)";
                $SQL = $SQL . " values (" . $VLeto . "," .$Vaktiv . "," . $VRazred[1] . "," . $VRazred[2] . "," . $VRazred[3] . "," . $VRazred[4] . "," . $VRazred[5] . "," . $VRazred[6] . "," . $VRazred[7] . "," . $VRazred[8] . "," . $VRazred[9];
                $SQL = $SQL . ",'".$VprogramDela."','".$VdneviDejavnosti."','".$VdopolnilniPouk."','".$VindividualniPouk."','".$VinteresneDejavnosti."','".$VroditeljskiSestanki."','".$VstudijskaSkupina."','".$Vizobrazevanje."','".$Vprojekti."','".$Vdrugo."','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "')";
            }

                $result = mysqli_query($link,$SQL);
                echo "Poročilo aktiva je bilo uspešno popravljeno oz. dodano!<br />";
            break;
        case "3a": //poglej poročilo
            $zapis=$_GET["zapis"];
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id WHERE TabAktivPorocilo.id=".$zapis;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];
            }

            echo "<h2>Poročilo dela aktiva</h2>";
            echo "<b>".$Vaktiv."</b>, ".$VLeto."/".($VLeto+1)."<br />";
            
            echo "<b>Velja za naslednje razrede:</b> ";
            for ($Indx=1;$Indx <= 9;$Indx++){
                if ($VRazred[$Indx]==1 ){
                    echo $Indx."&nbsp;";
                }
            }
            echo "<br />";
            
            echo "<br /><b>Program dela</b><br />";
            echo str_replace("\n","<br />",$VprogramDela)."<br />";

            echo "<br /><b>Dnevi dejavnosti</b><br />";
            echo str_replace("\n","<br />",$VdneviDejavnosti)."<br />";

            echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
            echo str_replace("\n","<br />",$VdopolnilniPouk)."<br />";

            echo "<br /><b>Individualni pouk</b><br />";
            echo str_replace("\n","<br />",$VindividualniPouk)."<br />";

            echo "<br /><b>Interesne dejavnosti</b><br />";
            echo str_replace("\n","<br />",$VinteresneDejavnosti)."<br />";

            echo "<br /><b>Roditeljski sestanki</b><br />";
            echo str_replace("\n","<br />",$VroditeljskiSestanki)."<br />";

            echo "<br /><b>Delo v študijski skupini</b><br />";
            echo str_replace("\n","<br />",$VstudijskaSkupina)."<br />";

            echo "<br /><b>Izobraževanje</b><br />";
            echo str_replace("\n","<br />",$Vizobrazevanje)."<br />";

            echo "<br /><b>Projekti</b><br />";
            echo str_replace("\n","<br />",$Vprojekti)."<br />";

            echo "<br /><b>Drugo ...</b><br />";
            echo str_replace("\n","<br />",$Vdrugo)."<br />";
            break;    
        case "4a": //briši poročilo
            $SQL = "DELETE FROM TabAktivPorocilo WHERE id=".$_GET["zapis"];
            $result = mysqli_query($link,$SQL);

            Header("Location: IzborAktiviPorocilo.php?id=1a");
            break;
        case "5a":  //vsa poročila
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id WHERE TabAktivPorocilo.leto=".$VLeto." ORDER BY TabAktiv.id";
            $result = mysqli_query($link,$SQL);

            echo "<h2>Poročila dela aktivov</h2>";

            while ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];

                echo "<b>".$Vaktiv."</b>, ".$VLeto."/".($VLeto+1)."<br />";
                
                echo "<b>Velja za naslednje razrede:</b> ";
                for ($Indx=1;$Indx <= 9;$Indx++){
                    if ($VRazred[$Indx]==1 ){
                        echo $Indx."&nbsp;";
                    }
                }
                echo "<br />";
                
                echo "<br /><b>Program dela</b><br />";
                echo str_replace("\n","<br />",$VprogramDela)."<br />";

                echo "<br /><b>Dnevi dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VdneviDejavnosti)."<br />";

                echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
                echo str_replace("\n","<br />",$VdopolnilniPouk)."<br />";

                echo "<br /><b>Individualni pouk</b><br />";
                echo str_replace("\n","<br />",$VindividualniPouk)."<br />";

                echo "<br /><b>Interesne dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VinteresneDejavnosti)."<br />";

                echo "<br /><b>Roditeljski sestanki</b><br />";
                echo str_replace("\n","<br />",$VroditeljskiSestanki)."<br />";

                echo "<br /><b>Delo v študijski skupini</b><br />";
                echo str_replace("\n","<br />",$VstudijskaSkupina)."<br />";

                echo "<br /><b>Izobraževanje</b><br />";
                echo str_replace("\n","<br />",$Vizobrazevanje)."<br />";

                echo "<br /><b>Projekti</b><br />";
                echo str_replace("\n","<br />",$Vprojekti)."<br />";

                echo "<br /><b>Drugo ...</b><br />";
                echo str_replace("\n","<br />",$Vdrugo)."<br />";

                echo "<br /><hr>";
            }
            break;
                
        case "6a":  //poročila po rubrikah
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPorocilo INNER JOIN TabAktiv ON TabAktivPorocilo.aktiv=TabAktiv.id WHERE TabAktivPorocilo.leto=".$VLeto." ORDER BY TabAktiv.id";
            $result = mysqli_query($link,$SQL);

            echo "<h2>Poročila dela aktivov združena po rubrikah</h2>";

            $IAktiv=1;

            while ($R = mysqli_fetch_array($result)){
                $Vaktiv[$IAktiv] = $R["aaktiv"]." ";
                $VAktivId[$IAktiv] = $R["aid"]." ";
                $VprogramDela[$IAktiv] = $R["programDela"]." ";
                $VdneviDejavnosti[$IAktiv] = $R["dneviDejavnosti"]." ";
                $VdopolnilniPouk[$IAktiv] = $R["dopolnilniPouk"]." ";
                $individualniPouk[$IAktiv] = $R["individualniPouk"]." ";
                $VinteresneDejavnosti[$IAktiv] = $R["interesneDejavnosti"]." ";
                $VroditeljskiSestanki[$IAktiv] = $R["roditeljskiSestanki"]." ";
                $VstudijskaSkupina[$IAktiv] = $R["studijskaSkupina"]." ";
                $Vizobrazevanje[$IAktiv] = $R["izobrazevanje"]." ";
                $Vprojekti[$IAktiv] = $R["projekti"]." ";
                $Vdrugo[$IAktiv] = $R["drugo"]." ";

                $IAktiv=$IAktiv+1;
            }
            $IAktiv=$IAktiv-1;

            echo "<h2>Šolsko leto: </td><td>".$VLeto."/".($VLeto+1)."</h2>";

            echo "<br /><b>Program dela</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VprogramDela[$Indx])."<br /><br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Dnevi dejavnosti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VdneviDejavnosti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VdopolnilniPouk[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Individualni pouk</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VindividualniPouk[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Interesne dejavnosti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VinteresneDejavnosti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Roditeljski sestanki</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VroditeljskiSestanki[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Delo v študijski skupini</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VstudijskaSkupina[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Izobraževanje</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vizobrazevanje[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Projekti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vprojekti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Drugo ...</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vdrugo[$Indx])."<br />";
            }
            echo "<br /><hr>";
            break;
        case "2b": //popravi načrt
            $zapis=$_GET["zapis"];
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPlan INNER JOIN TabAktiv ON TabAktivPlan.aktiv=TabAktiv.id WHERE TabAktivPlan.id=".$zapis;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];
            }

            echo "<h2>Poročilo aktiva za šolsko leto:</h2>";
            echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='IzborAktiviPorocilo.php'>";
            echo "<input name='id' type='hidden' value='2b1'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";

            echo "<table border=0><tr>";
            
            echo "<td>Šolsko leto:</td><td>".$VLeto."/".($VLeto+1)."</td></tr>";
            echo "<input type=hidden name=solskoleto value='".$VLeto."'>";
            echo "<td>Aktiv:</td><td>".$Vaktiv."</td></tr>";
            echo "<input type=hidden name=aktiv value='".$VAktivId."'>";
            echo "</table>";
            
            echo "<b>Velja za naslednje razrede:</b><br />";
            for ($Indx=1;$Indx <= 9;$Indx++){
                if ($VRazred[$Indx]==1 ){
                    echo "<input name='razred".$Indx."' type='checkbox' checked>".$Indx.". razred<br />";
                }else{
                    echo "<input name='razred".$Indx."' type='checkbox'>".$Indx.". razred<br />";
                }
            }

            echo "<br /><b>Program dela</b><br />";
            echo "<textarea name='programDela' cols='80' rows='10'>".$VprogramDela."</textarea><br />";

            echo "<br /><a href='IzborRazredaDejavnosti.php'>Vnos dnevov dejavnosti</a><br /><br />";
            echo "Dnevi dejavnosti<br />";
            echo "<textarea name='dneviDejavnosti' cols='80' rows='10'>".$VdneviDejavnosti."</textarea><br />";

            echo "Dopolnilni in dodatni pouk<br />";
            echo "<textarea name='dopolnilniPouk' cols='80' rows='10'>".$VdopolnilniPouk."</textarea><br />";

            echo "Individualni pouk<br />";
            echo "<textarea name='individualniPouk' cols='80' rows='10'>".$VindividualniPouk."</textarea><br />";

            echo "Interesne dejavnosti<br />";
            echo "<textarea name='interesneDejavnosti' cols='80' rows='10'>".$VinteresneDejavnosti."</textarea><br />";

            echo "Roditeljski sestanki<br />";
            echo "<textarea name='roditeljskiSestanki' cols='80' rows='10'>".$VroditeljskiSestanki."</textarea><br />";

            echo "Delo v študijski skupini<br />";
            echo "<textarea name='studijskaSkupina' cols='80' rows='10'>".$VstudijskaSkupina."</textarea><br />";

            echo "Izobraževanje<br />";
            echo "<textarea name='izobrazevanje' cols='80' rows='10'>".$Vizobrazevanje."</textarea><br />";

            echo "Projekti<br />";
            echo "<textarea name='projekti' cols='80' rows='10'>".$Vprojekti."</textarea><br />";

            echo "Drugo ...<br />";
            echo "<textarea name='drugo' cols='80' rows='10'>".$Vdrugo."</textarea><br />";

            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
			break;
        case "2b1": //vpis popravka poročila
            for ($Indx=1;$Indx <= 9;$Indx++){
                if (isset($_POST["razred".$Indx])){
                    $VRazred[$Indx]=1;
                }else{
                    $VRazred[$Indx]=0;
                }
            }
            $VLeto = $_POST["solskoleto"];
            $Vaktiv = $_POST["aktiv"];
            $VprogramDela = $_POST["programDela"];
            $VdneviDejavnosti = $_POST["dneviDejavnosti"];
            $VdopolnilniPouk = $_POST["dopolnilniPouk"];
            $VindividualniPouk = $_POST["individualniPouk"];
            $VinteresneDejavnosti = $_POST["interesneDejavnosti"];
            $VroditeljskiSestanki = $_POST["roditeljskiSestanki"];
            $VstudijskaSkupina = $_POST["studijskaSkupina"];
            $Vizobrazevanje = $_POST["izobrazevanje"];
            $Vprojekti = $_POST["projekti"];
            $Vdrugo = $_POST["drugo"];

            $SQL = "SELECT * FROM TabAktivPlan WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                $SQL = "UPDATE TabAktivPlan SET leto=".$VLeto.",razred1=".$VRazred[1].",razred2=".$VRazred[2].",razred3=".$VRazred[3].",razred4=".$VRazred[4].",razred5=".$VRazred[5].",razred6=".$VRazred[6].",razred7=".$VRazred[7].",razred8=".$VRazred[8].",razred9=".$VRazred[9];
                $SQL = $SQL .",programDela='".$VprogramDela."',dneviDejavnosti='".$VdneviDejavnosti."',dopolnilniPouk='".$VdopolnilniPouk."',individualniPouk='".$VindividualniPouk."',interesneDejavnosti='".$VinteresneDejavnosti."',roditeljskiSestanki='".$VroditeljskiSestanki."',studijskaSkupina='".$VstudijskaSkupina."',izobrazevanje='".$Vizobrazevanje."',projekti='".$Vprojekti."',drugo='".$Vdrugo."'";
                $SQL = $SQL .",avtor='".$VUporabnik."',Datum='".$Danes->format('Y-m-d H:i:s')."' WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            }else{
                $SQL = "INSERT INTO TabAktivPlan (Leto,aktiv,razred1,razred2,razred3,razred4,razred5,razred6,razred7,razred8,razred9,";
                $SQL = $SQL . "programDela,dneviDejavnosti,dopolnilniPouk,individualniPouk,interesneDejavnosti,roditeljskiSestanki,studijskaSkupina,izobrazevanje,projekti,drugo,avtor,Datum)";
                $SQL = $SQL . " values (" . $VLeto . "," .$Vaktiv . "," . $VRazred[1] . "," . $VRazred[2] . "," . $VRazred[3] . "," . $VRazred[4] . "," . $VRazred[5] . "," . $VRazred[6] . "," . $VRazred[7] . "," . $VRazred[8] . "," . $VRazred[9];
                $SQL = $SQL . ",'".$VprogramDela."','".$VdneviDejavnosti."','".$VdopolnilniPouk."','".$VindividualniPouk."','".$VinteresneDejavnosti."','".$VroditeljskiSestanki."','".$VstudijskaSkupina."','".$Vizobrazevanje."','".$Vprojekti."','".$Vdrugo."','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "')";
            }

                $result = mysqli_query($link,$SQL);
                echo "Načrt aktiva je bil uspešno popravljen oz. dodan!<br />";
                
            if ($Opravila==1 ){
                $SQL = "SELECT tabdeldogodek.id FROM ";
                $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                $SQL = $SQL . "WHERE tabdogodek.Dogodek='Program aktiva za naslednje šolsko leto' AND leto=".($VLeto-1)." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                $result = mysqli_query($link,$SQL);

                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $VDogodki[$Indx]=$R["id"];
                    $Indx=$Indx+1;
                }
                $StDogodkov=$Indx-1;

                for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                    $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                    $result = mysqli_query($link,$SQL);
                }
            }
            break;
        case "3b": //poglej načrt
     
            $zapis=$_GET["zapis"];
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPlan INNER JOIN TabAktiv ON TabAktivPlan.aktiv=TabAktiv.id WHERE TabAktivPlan.id=".$zapis;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];
            }

            echo "<h2>Načrt dela aktiva</h2>";
            echo "<b>".$Vaktiv."</b>, ".$VLeto."/".($VLeto+1)."<br />";
            
            echo "<b>Velja za naslednje razrede:</b> ";
            for ($Indx=1;$Indx <= 9;$Indx++){
                if ($VRazred[$Indx]==1 ){
                    echo $Indx."&nbsp;";
                }
            }
            echo "<br />";
            
            echo "<br /><b>Program dela</b><br />";
            echo str_replace("\n","<br />",$VprogramDela)."<br />";

            echo "<br /><b>Dnevi dejavnosti</b><br />";
            echo str_replace("\n","<br />",$VdneviDejavnosti)."<br />";

            echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
            echo str_replace("\n","<br />",$VdopolnilniPouk)."<br />";

            echo "<br /><b>Individualni pouk</b><br />";
            echo str_replace("\n","<br />",$VindividualniPouk)."<br />";

            echo "<br /><b>Interesne dejavnosti</b><br />";
            echo str_replace("\n","<br />",$VinteresneDejavnosti)."<br />";

            echo "<br /><b>Roditeljski sestanki</b><br />";
            echo str_replace("\n","<br />",$VroditeljskiSestanki)."<br />";

            echo "<br /><b>Delo v študijski skupini</b><br />";
            echo str_replace("\n","<br />",$VstudijskaSkupina)."<br />";

            echo "<br /><b>Izobraževanje</b><br />";
            echo str_replace("\n","<br />",$Vizobrazevanje)."<br />";

            echo "<br /><b>Projekti</b><br />";
            echo str_replace("\n","<br />",$Vprojekti)."<br />";

            echo "<br /><b>Drugo ...</b><br />";
            echo str_replace("\n","<br />",$Vdrugo)."<br />";
            break;    
        case "4b": //briši načrt
            $SQL = "DELETE FROM TabAktivPlan WHERE id=".$_GET["zapis"];
            $result = mysqli_query($link,$SQL);

            header ("Location: IzborAktiviPorocilo.php?id=1b");
            break;
        case "5b":  //vsi načrti
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPlan INNER JOIN TabAktiv ON TabAktivPlan.aktiv=TabAktiv.id WHERE TabAktivPlan.leto=".$VLeto." ORDER BY TabAktiv.id";
            $result = mysqli_query($link,$SQL);

            echo "<h2>Načrti dela aktivov</h2>";

            while ($R = mysqli_fetch_array($result)){
                for ($Indx=1;$Indx <= 9;$Indx++){
                    $VRazred[$Indx]=$R["razred".$Indx];
                }

                $VLeto = $R["leto"];
                $Vaktiv = $R["aaktiv"];
                $VAktivId = $R["aid"];
                $VprogramDela = $R["programDela"];
                $VdneviDejavnosti = $R["dneviDejavnosti"];
                $VdopolnilniPouk = $R["dopolnilniPouk"];
                $VindividualniPouk = $R["individualniPouk"];
                $VinteresneDejavnosti = $R["interesneDejavnosti"];
                $VroditeljskiSestanki = $R["roditeljskiSestanki"];
                $VstudijskaSkupina = $R["studijskaSkupina"];
                $Vizobrazevanje = $R["izobrazevanje"];
                $Vprojekti = $R["projekti"];
                $Vdrugo = $R["drugo"];

                echo "<b>".$Vaktiv."</b>, ".$VLeto."/".($VLeto+1)."<br />";
                
                echo "<b>Velja za naslednje razrede:</b> ";
                for ($Indx=1;$Indx <= 9;$Indx++){
                    if ($VRazred[$Indx]==1 ){
                        echo $Indx."&nbsp;";
                    }
                }
                echo "<br />";
                
                echo "<br /><b>Program dela</b><br />";
                echo str_replace("\n","<br />",$VprogramDela)."<br />";

                echo "<br /><b>Dnevi dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VdneviDejavnosti)."<br />";

                echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
                echo str_replace("\n","<br />",$VdopolnilniPouk)."<br />";

                echo "<br /><b>Individualni pouk</b><br />";
                echo str_replace("\n","<br />",$VindividualniPouk)."<br />";

                echo "<br /><b>Interesne dejavnosti</b><br />";
                echo str_replace("\n","<br />",$VinteresneDejavnosti)."<br />";

                echo "<br /><b>Roditeljski sestanki</b><br />";
                echo str_replace("\n","<br />",$VroditeljskiSestanki)."<br />";

                echo "<br /><b>Delo v študijski skupini</b><br />";
                echo str_replace("\n","<br />",$VstudijskaSkupina)."<br />";

                echo "<br /><b>Izobraževanje</b><br />";
                echo str_replace("\n","<br />",$Vizobrazevanje)."<br />";

                echo "<br /><b>Projekti</b><br />";
                echo str_replace("\n","<br />",$Vprojekti)."<br />";

                echo "<br /><b>Drugo ...</b><br />";
                echo str_replace("\n","<br />",$Vdrugo)."<br />";

                echo "<br /><hr>";
            }
            break;
        
        case "6b":  //načrti po rubrikah
            $SQL = "SELECT *,TabAktiv.aktiv AS aaktiv,TabAktiv.id AS aid FROM TabAktivPlan INNER JOIN TabAktiv ON TabAktivPlan.aktiv=TabAktiv.id WHERE TabAktivPlan.leto=".$VLeto." ORDER BY TabAktiv.id";
            $result = mysqli_query($link,$SQL);

            echo "<h2>Načrti dela aktivov združeni po rubrikah</h2>";

            $IAktiv=1;

            while ($R = mysqli_fetch_array($result)){
                $Vaktiv[$IAktiv] = $R["aaktiv"]." ";
                $VAktivId[$IAktiv] = $R["aid"]." ";
                $VprogramDela[$IAktiv] = $R["programDela"]." ";
                $VdneviDejavnosti[$IAktiv] = $R["dneviDejavnosti"]." ";
                $VdopolnilniPouk[$IAktiv] = $R["dopolnilniPouk"]." ";
                $individualniPouk[$IAktiv] = $R["individualniPouk"]." ";
                $VinteresneDejavnosti[$IAktiv] = $R["interesneDejavnosti"]." ";
                $VroditeljskiSestanki[$IAktiv] = $R["roditeljskiSestanki"]." ";
                $VstudijskaSkupina[$IAktiv] = $R["studijskaSkupina"]." ";
                $Vizobrazevanje[$IAktiv] = $R["izobrazevanje"]." ";
                $Vprojekti[$IAktiv] = $R["projekti"]." ";
                $Vdrugo[$IAktiv] = $R["drugo"]." ";

                $IAktiv=$IAktiv+1;
            }
            $IAktiv=$IAktiv-1;

            echo "<h2>Šolsko leto: ".$VLeto."/".($VLeto+1)."</h2>";

            echo "<br /><b>Program dela</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VprogramDela[$Indx])."<br /><br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Dnevi dejavnosti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VdneviDejavnosti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Dopolnilni in dodatni pouk</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VdopolnilniPouk[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Individualni pouk</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VindividualniPouk[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Interesne dejavnosti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VinteresneDejavnosti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Roditeljski sestanki</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VroditeljskiSestanki[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Delo v študijski skupini</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$VstudijskaSkupina[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Izobraževanje</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vizobrazevanje[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Projekti</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vprojekti[$Indx])."<br />";
            }
            echo "<br /><hr>";
            echo "<br /><b>Drugo ...</b><br />";
            for ($Indx=1;$Indx <= $IAktiv;$Indx++){
                echo "<br /><b>".$Vaktiv[$Indx]."</b><br />";
                echo str_replace("\n","<br />",$Vdrugo[$Indx])."<br />";
            }
            echo "<br /><hr>";
            break;

        case "0a": //vnos poročila
            echo "<h2>Poročilo aktiva za šolsko leto:</h2>";
            echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='IzborAktiviPorocilo.php'>";
            echo "<input name='id' type='hidden' value='0a1'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";

            echo "<table border=0><tr>";
            
            echo "<td>Šolsko leto:</td><td><select name='solskoleto'>";
            echo "<option value='".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</option>";
            echo "<option value='".$VLeto."' selected>".$VLeto."/".($VLeto+1)."</option>";
            echo "</select></td></tr>";
            echo "<td>Aktiv:</td><td><select name='aktiv'>";
            
            $SQL = "SELECT TabAktiv.* FROM TabAktiv ORDER BY orderlevel";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["Aktiv"]."</option>";
            }
            echo "</select></td></tr>";
            echo "</table>";
            
            echo "<b>Velja za naslednje razrede:</b><br>";
            for ($Indx=1;$Indx <= 9;$Indx++){
                echo "<input name='razred".$Indx."' type=checkbox >".$Indx.". razred<br />";
            }

            echo "<br /><b>Program dela</b><br />";
            echo "<textarea name='programDela' cols='80' rows='10'></textarea><br />";

            echo "<br /><a href='IzborRazredaDejavnosti.php'>Vnos dnevov dejavnosti</a><br /><br />";
            echo "Dnevi dejavnosti<br />";
            echo "<textarea name='dneviDejavnosti' cols='80' rows='10'></textarea><br />";

            echo "Dopolnilni in dodatni pouk<br />";
            echo "<textarea name='dopolnilniPouk' cols='80' rows='10'></textarea><br />";

            echo "Individualni pouk<br />";
            echo "<textarea name='individualniPouk' cols='80' rows='10'></textarea><br />";

            echo "Interesne dejavnosti<br />";
            echo "<textarea name='interesneDejavnosti' cols='80' rows='10'></textarea><br />";

            echo "Roditeljski sestanki<br />";
            echo "<textarea name='roditeljskiSestanki' cols='80' rows='10'></textarea><br />";

            echo "Delo v študijski skupini<br />";
            echo "<textarea name='studijskaSkupina' cols='80' rows='10'></textarea><br />";

            echo "Izobraževanje<br />";
            echo "<textarea name='izobrazevanje' cols='80' rows='10'></textarea><br />";

            echo "Projekti<br />";
            echo "<textarea name='projekti' cols='80' rows='10'></textarea><br />";

            echo "Drugo ...<br />";
            echo "<textarea name='drugo' cols='80' rows='10'></textarea><br />";

            echo "<input name='submit' type='submit' value='Pošlji poročilo'>";
            echo "</form>";
            break;
        case "0a1": //vpis poročila
            for ($Indx=1;$Indx <= 9;$Indx++){
                if (isset($_POST["razred".$Indx])){
                    $VRazred[$Indx]=1;
                }else{
                    $VRazred[$Indx]=0;
                }
            }

            $VLeto = $_POST["solskoleto"];
            $Vaktiv = $_POST["aktiv"];
            $VprogramDela = $_POST["programDela"];
            $VdneviDejavnosti = $_POST["dneviDejavnosti"];
            $VdopolnilniPouk = $_POST["dopolnilniPouk"];
            $VindividualniPouk = $_POST["individualniPouk"];
            $VinteresneDejavnosti = $_POST["interesneDejavnosti"];
            $VroditeljskiSestanki = $_POST["roditeljskiSestanki"];
            $VstudijskaSkupina = $_POST["studijskaSkupina"];
            $Vizobrazevanje = $_POST["izobrazevanje"];
            $Vprojekti = $_POST["projekti"];
            $Vdrugo = $_POST["drugo"];

            $SQL = "SELECT id FROM TabAktivPorocilo WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "To poročilo aktiva že obstaja. Lahko ga popravite tule:<br />";
                echo "<a href='IzborAktiviPorocilo.php?id=2a&zapis=".$R["id"]."'>Popravi poročilo aktiva</a><br />";
            }else{
                $SQL = "INSERT INTO TabAktivPorocilo (Leto,aktiv,razred1,razred2,razred3,razred4,razred5,razred6,razred7,razred8,razred9,";
                $SQL = $SQL . "programDela,dneviDejavnosti,dopolnilniPouk,individualniPouk,interesneDejavnosti,roditeljskiSestanki,studijskaSkupina,izobrazevanje,projekti,drugo,avtor,Datum)";
                $SQL = $SQL . " values (" . $VLeto . "," . $Vaktiv . "," . $VRazred[1] . "," . $VRazred[2] . "," . $VRazred[3] . "," . $VRazred[4] . "," . $VRazred[5] . "," . $VRazred[6] . "," . $VRazred[7] . "," . $VRazred[8] . "," . $VRazred[9];
                $SQL = $SQL . ",'".$VprogramDela."','".$VdneviDejavnosti."','".$VdopolnilniPouk."','".$VindividualniPouk."','".$VinteresneDejavnosti."','".$VroditeljskiSestanki."','".$VstudijskaSkupina."','".$Vizobrazevanje."','".$Vprojekti."','".$Vdrugo."','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "')";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri dodajanju zapisa!<br />$SQL <br />");
                }else{
                    echo "Poročilo aktiva je bilo uspešno dodano!<br />";
                }
                
                if ($Opravila==1) {
                    $SQL = "SELECT tabdeldogodek.id FROM ";
                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Letno poročilo aktiva' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VDogodki[$Indx]=$R["id"];
                        $Indx=$Indx+1;
                    }
                    $StDogodkov=$Indx-1;

                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }

            break;
        case "0b": //načrt aktiva
            echo "<h2>Načrt dela aktiva za šolsko leto:</h2>";
            echo "<form accept-charset='utf-8' name='form_realizacija' method=post action='IzborAktiviPorocilo.php'>";
            echo "<input name='id' type='hidden' value='0b1'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='level' type='hidden' value='".$VLevel."'>";
            
            echo "<table border=0><tr>";
            
            echo "<td>Šolsko leto:</td><td><select name='solskoleto'>";
            echo "<option value='".($VLeto+1)."' selected>".($VLeto+1)."/".($VLeto+2)."</option>";
            echo "<option value='".$VLeto."'>".$VLeto."/".($VLeto+1)."</option>";
            echo "</select></td></tr>";
            echo "<td>Aktiv:</td><td><select name='aktiv'>";
            
            $SQL = "SELECT TabAktiv.* FROM TabAktiv ORDER BY orderlevel";
            $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["Aktiv"]."</option>";
            }
            echo "</select></td></tr>";
            echo "</table>";
            
            echo "<b>Velja za naslednje razrede:</b><br />";
            for ($Indx=1;$Indx <= 9;$Indx++){
                echo "<input name='razred".$Indx."' type=checkbox >".$Indx.". razred<br />";
            }

            echo "<br /><b>Program dela</b><br />";
            echo "<textarea name='programDela' cols='80' rows='10'></textarea><br />";

            echo "<br /><a href='IzborRazredaDejavnosti.php'>Vnos dnevov dejavnosti</a><br /><br />";
            echo "Dnevi dejavnosti<br />";
            echo "<textarea name='dneviDejavnosti' cols='80' rows='10'></textarea><br />";

            echo "Dopolnilni in dodatni pouk<br />";
            echo "<textarea name='dopolnilniPouk' cols='80' rows='10'></textarea><br />";

            echo "Individualni pouk<br />";
            echo "<textarea name='individualniPouk' cols='80' rows='10'></textarea><br />";

            echo "Interesne dejavnosti<br />";
            echo "<textarea name='interesneDejavnosti' cols='80' rows='10'></textarea><br />";

            echo "Roditeljski sestanki<br />";
            echo "<textarea name='roditeljskiSestanki' cols='80' rows='10'></textarea><br />";

            echo "Delo v študijski skupini<br />";
            echo "<textarea name='studijskaSkupina' cols='80' rows='10'></textarea><br />";

            echo "Izobraževanje<br />";
            echo "<textarea name='izobrazevanje' cols='80' rows='10'></textarea><br />";

            echo "Projekti<br />";
            echo "<textarea name='projekti' cols='80' rows='10'></textarea><br />";

            echo "Drugo ...<br />";
            echo "<textarea name='drugo' cols='80' rows='10'></textarea><br />";

            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";

            break;
        case "0b1": //vpis načrta
            for ($Indx=1;$Indx <= 9;$Indx++){
                if (isset($_POST["razred".$Indx])){
                    $VRazred[$Indx]=1;
                }else{
                    $VRazred[$Indx]=0;
                }
            }

            $VLeto = $_POST["solskoleto"];
            $Vaktiv = $_POST["aktiv"];
            $VprogramDela = $_POST["programDela"];
            $VdneviDejavnosti = $_POST["dneviDejavnosti"];
            $VdopolnilniPouk = $_POST["dopolnilniPouk"];
            $VindividualniPouk = $_POST["individualniPouk"];
            $VinteresneDejavnosti = $_POST["interesneDejavnosti"];
            $VroditeljskiSestanki = $_POST["roditeljskiSestanki"];
            $VstudijskaSkupina = $_POST["studijskaSkupina"];
            $Vizobrazevanje = $_POST["izobrazevanje"];
            $Vprojekti = $_POST["projekti"];
            $Vdrugo = $_POST["drugo"];

            $SQL = "SELECT id FROM TabAktivPlan WHERE leto=".$VLeto." AND aktiv=".$Vaktiv;
            $result = mysqli_query($link,$SQL);

            if ($R = mysqli_fetch_array($result)){
                echo "Ta načrt aktiva že obstaja. Lahko ga popravite tule:<br />";
                echo "<a href='IzborAktivPorocilo.php?id=2a&zapis=".$R["id"]."'>Popravi načrt aktiva</a><br />";
            }else{
                $SQL = "INSERT INTO TabAktivPlan (Leto,aktiv,razred1,razred2,razred3,razred4,razred5,razred6,razred7,razred8,razred9,";
                $SQL = $SQL . "programDela,dneviDejavnosti,dopolnilniPouk,individualniPouk,interesneDejavnosti,roditeljskiSestanki,studijskaSkupina,izobrazevanje,projekti,drugo,avtor,Datum)";
                $SQL = $SQL . " values (" . $VLeto . "," . $Vaktiv . "," . $VRazred[1] . "," . $VRazred[2] . "," . $VRazred[3] . "," . $VRazred[4] . "," . $VRazred[5] . "," . $VRazred[6] . "," . $VRazred[7] . "," . $VRazred[8] . "," . $VRazred[9];
                $SQL = $SQL . ",'".$VprogramDela."','".$VdneviDejavnosti."','".$VdopolnilniPouk."','".$VindividualniPouk."','".$VinteresneDejavnosti."','".$VroditeljskiSestanki."','".$VstudijskaSkupina."','".$Vizobrazevanje."','".$Vprojekti."','".$Vdrugo."','" . $VUporabnik . "','" . $Danes->format('Y-m-d H:i:s') . "')";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri dodajanju zapisa!<br />$SQL <br />");
                }else{
                    echo "Načrt aktiva je bil uspešno dodan!<br />";
                }
                
                if ($Opravila==1) {
                    $SQL = "SELECT tabdeldogodek.id FROM ";
                    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
                    $SQL = $SQL . "WHERE tabdogodek.Dogodek='Letno poročilo aktiva' AND leto=".$VLeto." AND idUcitelj=".$Ucitelj." AND opravljeno=false";
                    $result = mysqli_query($link,$SQL);

                    $Indx=1;
                    while ($R = mysqli_fetch_array($result)){
                        $VDogodki[$Indx]=$R["id"];
                        $Indx=$Indx+1;
                    }
                    $StDogodkov=$Indx-1;

                    for ($Indx=1;$Indx <= $StDogodkov;$Indx++){
                        $SQL = "UPDATE tabdeldogodek SET opravljeno=true,datum='".$Danes->format('j.n.Y')."' WHERE id=".$VDogodki[$Indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }
            }
    }    
}
?>

<a href="IzborAktiviPorocilo.php?id=1a">Na spisek poročil</a><br />
<a href="IzborAktiviPorocilo.php?id=1b">Na spisek načrtov</a><br />
</body>
</html>
