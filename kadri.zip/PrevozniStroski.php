<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Prevozni stroški
</title>
<style type="text/css"> 
     input.r{ 
     text-align:right; 
     } 
</style></head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
	case "1":
//'		response.write "Zapisov "&request("StZapisov")&"<br>"
		for ($Indx=1;$Indx <= $_POST["StZapisov"];$Indx++){
			$Zacasno=str_replace(",",".",$_POST["Prevoz".$Indx]);
			if (is_numeric($Zacasno)){
				$SQL = "UPDATE tabucitelji SET Prevoz=".$Zacasno." WHERE idUcitelj=".$_POST["ucitelj".$Indx];
//'				response.write $SQL&"<br>"
				$result = mysqli_query($link,$SQL);
			}
		}
        echo "Vpisano<br />";
}
$SQL = "SELECT tabucitelji.* FROM tabucitelji ";
$SQL = $SQL . "WHERE tabucitelji.Status > 0 ";
$SQL = $SQL . "ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
//Response.Write "<br>" & $SQL & "<br>"
$result = mysqli_query($link,$SQL);

$Indx=1;

echo "<h2>Vpis prevoznih stroškov na delo</h2>";
echo "<form name='form_zdrpregledi' method='post' action='PrevozniStroski.php'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "<table border='1' cellspacing='0'>";
echo "<tr bgcolor=lightcyan><th></th><th>Priimek, Ime</th>";
echo "<th>Znesek</th>";
echo "</tr>";

while ($R = mysqli_fetch_array($result)){
	echo "<tr>";
	echo "<td>".$Indx."</td>";
	echo "<td><input name='ucitelj".$Indx."' type='hidden' value='".$R["IdUcitelj"]."'><a href='PopraviUcitelja.php?id=".$R["IdUcitelj"]."'>".$R["Priimek"].", ".$R["Ime"]."</a></td>";
	echo "<td><input class='r' name='Prevoz".$Indx."' type='text' value='".number_format($R["Prevoz"],2,',','')."' size='8'></td>";
	echo "</tr>";
	$Indx=$Indx+1;
}
echo "</table>";
echo "<input name='StZapisov' type='hidden' value='".($Indx-1)."'>";
echo "<input name='id' type='hidden' value='1'>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>"

?>

</body>
</html>
