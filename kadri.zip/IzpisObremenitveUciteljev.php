<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("DelPregl",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

$SQL = "SELECT tabucitelji.* FROM tabucitelji WHERE izobrazba > 5 ORDER BY Priimek,Ime"; 
$result = mysqli_query($link,$SQL);

$Indx=0;
while ($R = mysqli_fetch_array($result)){
	$ucitelj[$Indx][0]=$R["IdUcitelj"];
	$ucitelj[$Indx][1]=$R["Priimek"]  . ", " . $R["Ime"];
	$Indx=$Indx+1;
}
$StUciteljev=$Indx-1;

echo "<h2>Razporeditve učiteljev za šolsko leto ".$VLeto."/".($VLeto+1)."</h2>";

$IndxRazrednik=0;
for ($IndxUc=0;$IndxUc <= $StUciteljev;$IndxUc++){
	$SQL = "SELECT tabucenje.*, tabpredmeti.Oznaka AS poznaka, tabpredmeti.Opis AS popis,tabrazdat.*,tabrazdat.Razred AS rrazred FROM ";
	$SQL = $SQL . "(tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet) ";
	$SQL = $SQL . "INNER JOIN tabrazdat ON tabucenje.idRazred=tabrazdat.id ";
	$SQL = $SQL . "WHERE iducitelj=" . $ucitelj[$IndxUc][0] ." AND tabrazdat.leto=".$VLeto." AND tabucenje.leto=".$VLeto;
	$SQL = $SQL . " ORDER BY  tabpredmeti.VrstniRed,tabrazdat.Razred,tabrazdat.oznaka";
	$result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
		echo "Ime: <b>".$ucitelj[$IndxUc][1]."</b><br />";
		echo "<table border=1>";
		echo "<th width=180>Predmet</th><th width=45>Razred</th><th width=45>Plan ur</th><th width=100>Posebnosti</th>";
	}
	$SkupajUre=0;
	$BZdruzevanje=false;
	$BZdruzevanje1=false;

	for ($Indx=0;$Indx <= 10;$Indx++){
		$izbirni[$Indx]=0;
	}

	$StIzbirni=0;

	$Indx=1;
    while ($R = mysqli_fetch_array($result)){
		if ($R["Predmet"]==50 ){
			echo "<tr><td><font color='red'>" . $R["poznaka"] ." - " . $R["popis"] ."</font></td><td align='right'>" . $R["rrazred"] . ". " . $R["oznaka"] . "</td><td align='right'>" . $R["Planirano"] ."</td>";
			$Razredniki[$IndxRazrednik][0]=$ucitelj[$IndxUc][1];
			$Razredniki[$IndxRazrednik][1]=$R["rrazred"] . ". " . $R["oznaka"];
			$IndxRazrednik=$IndxRazrednik+1;
		}else{
			echo "<tr><td>" . $R["poznaka"] ." - " . $R["popis"] ."</td><td align='right'>" . $R["rrazred"] . ". " . $R["oznaka"]. "</td><td align='right'>" . $R["Planirano"] ."</td>";
		}
		if ($R["Zdruzeno"] == 1 ){
			echo "<td>Združevanje/nivoji</td>";
			$BZdruzevanje= !$BZdruzevanje;
			if ($BZdruzevanje == true ){
				$SkupajUre=$SkupajUre-$R["Planirano"];
		 	}
		}
		if ($R["Zdruzeno"]== 2 ){
			echo "<td>Izbirne vsebine</td>";
			$StIzbirni=0;
			while ($StIzbirni < 10 ){
				if ($izbirni[$StIzbirni]==$R["Predmet"] ){
					$SkupajUre=$SkupajUre-$R["Planirano"];
					break;
				}
				$StIzbirni=$StIzbirni+1;
			}
			if ($StIzbirni==10 ){
				$StIzbirni=0;
				while ($StIzbirni < 10 ){
					if ($izbirni[$StIzbirni]==0 ){
						$izbirni[$StIzbirni]=$R["Predmet"];
						break;
					}
					$StIzbirni=$StIzbirni+1;
				}
			}
		}
		if ($R["Zdruzeno"]== 0 ){
			echo "<td></td>";
		}
		
		echo "</tr>";
		$SkupajUre=$SkupajUre+$R["Planirano"];
		$Indx=$Indx+1;
	}
	if ($Indx > 1 ){
		echo "<tr><td>Skupaj ur</td><td></td><td align='right'><b>" . $SkupajUre . "</b></td><td></td></tr>";
		echo "</table><br />";
	}
}

for ($Indx = 0;$Indx <= ($IndxRazrednik-1);$Indx++){
	for ($Indx0 = 0;$Indx0 <= ($IndxRazrednik-1);$Indx0++){
		if ($Indx <> $Indx0 ){
			if ($Razredniki[$Indx][1] < $Razredniki[$Indx0][1] ){
				$Razredniki[$IndxRazrednik][0]=$Razredniki[$Indx][0];
				$Razredniki[$Indx][0]=$Razredniki[$Indx0][0];
				$Razredniki[$Indx0][0]=$Razredniki[$IndxRazrednik][0];
				$Razredniki[$IndxRazrednik][1]=$Razredniki[$Indx][1];
				$Razredniki[$Indx][1]=$Razredniki[$Indx0][1];
				$Razredniki[$Indx0][1]=$Razredniki[$IndxRazrednik][1];
			}
		}
	}
}
echo "Razredniki: <br />";
for ($Indx=0;$Indx <= ($IndxRazrednik-1);$Indx++){
	echo $Razredniki[$Indx][1]." - ".$Razredniki[$Indx][0]."<br />";
}

?>
<br />
<a href="pravilnik.htm">Pravilnik</a><br />

</body>
</html>
