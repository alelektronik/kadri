<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Statistike
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];


$RazsirjenVnos=true;

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["iducitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
    $n=$VLevel;
    include('menu_func.inc');
    include ('menu.inc');

    if (!CheckDostop("StatDel",$VUporabnik) ) {
        echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
    }

    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }

    if (isset($_POST["idUcitelj"])){
        $ucitelj = $_POST["idUcitelj"];
    }else{
        if (isset($_GET["idUcitelj"])){
            $ucitelj = $_GET["idUcitelj"];
        }else{
            if (isset($_SESSION["idUcitelj"])){ 
                $ucitelj = $_SESSION["idUcitelj"];
            }else{
                $ucitelj = 0;
            }
        }
    }

    echo "<form accept-charset='utf-8' name='casVsi' method=post action='DelovnoRazmerje.php'>";
    echo "Šolsko leto: ";
    echo "<select name='solskoleto'>";
    echo "<option value='" .  $VLeto  . "' selected>" . $VLeto."/".($VLeto+1) ."</option>";
    echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1)."/".($VLeto) ."</option>";
    echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1)."/".($VLeto+2) ."</option>";
    echo "</select>";
    echo "<input name='id' type='hidden' value='1'>";
    echo "<input name='submit' type='submit' value='Izberi'>";
    echo "</form><br />";
    /*
    $sola=array();
    $SQL = "SELECT id,solakratko FROM tabsola";
    $result = mysqli_query($link,$SQL);
    $i=1;
    while ($R = mysqli_fetch_array($result)){
        $sola[$i][0]=$R["id"];
        $sola[$i][1]=$R["solakratko"];
        $i += 1;
    }
    $StSol=$i-1;
        
    for($IndxSola=1;$IndxSola <= $StSol;$IndxSola++){ 

        echo "<h2>".$sola[$IndxSola][1]."</h2>";           
    */
        //inicializacija polj
        for ($i=0;$i <= 14;$i++){
            for($j=0;$j <= 14;$j++){
                $Count16[$i][$j]=0;
                $Count17[$i][$j]=0;
                $Count18[$i][$j]=0;
                $Count19[$i][$j]=0;
                $Count20[$i][$j]=0;
            }
        }
        for ($i=0;$i <= 400;$i++){
            for($j=0;$j <= 14;$j++){
                $DelPog[$i][$j]="";
                $Delavec[$i][$j]="";
            }
        }

        $SQL = "SELECT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabucitelji.letoroj,tabucitelji.izobrazba,tabucitelji.spol, TabStatus.status FROM ";
        $SQL = $SQL . "tabucitelji INNER JOIN TabStatus ON tabucitelji.Status=TabStatus.IdStatus ";
        //$SQL = $SQL . "WHERE tabucitelji.Status IN (1,2,3,4,5,6)";
        $SQL = $SQL . "WHERE tabucitelji.Status < 10 ";
        $SQL = $SQL . " ORDER BY tabucitelji.Priimek, tabucitelji.Ime";
        $result = mysqli_query($link,$SQL);

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
            $Delavec[$Indx][0]=$R["iducitelj"];
            $Delavec[$Indx][1]=$R["priimek"]." ".$R["ime"];
            $Delavec[$Indx][2]=$R["letoroj"];
            $Delavec[$Indx][3]=$R["izobrazba"];
            $Delavec[$Indx][7]=$R["status"];
            $Delavec[$Indx][11]=$R["spol"];
            $Indx=$Indx+1;
        }
        $StDelavcev=$Indx-1;

        echo "Število delavcev ".$StDelavcev."<br />";

        $DatumPreveri=new DateTime(($VLeto+1)."-06-30");
        echo "<h2>Statistika zaposlenih na ".$DatumPreveri->format('d.m.Y')."</h2>";
        for ($Indx=1;$Indx <= $StDelavcev;$Indx++){
            //'gleda glavne pogodbe (z večjim deležem, če so enaki, vzame prvega)
            $SQL = "SELECT * FROM tabpogodbe WHERE idUcitelj=".$Delavec[$Indx][0]." ORDER BY UrTeden DESC";
            $result = mysqli_query($link,$SQL);
            $i2=1;
            while ($R = mysqli_fetch_array($result)){
                if (isDate($R["DatumStart"]) ){
                    $Datum=new DateTime(isDate($R["DatumStart"]));
                    $DelPog[$i2][2]=$Datum->format('d.m.Y');
                }else{
                    //$DelPog[$i2][2]=$DatumPreveri->format('d.m.Y');
                    //če nima vpisanega začetka pogodbe, ga vzame kot, da je to danes
                    $DelPog[$i2][2]=$Danes->format('d.m.Y');
                }
                if (isDate($R["DatumEnd"])) {
                    $Datum=new DateTime(isDate($R["DatumEnd"]));
                    $DelPog[$i2][3]=$Datum->format('d.m.Y');
                }else{
                    $DelPog[$i2][3]=$DatumPreveri->format('d.m.Y');
                }
                $DatumStart=new DateTime(isDate($DelPog[$i2][2]));
                $DatumEnd=new DateTime(isDate($DelPog[$i2][3]));
                $Interval1=$DatumStart->diff($DatumPreveri);
                $Interval2=$DatumEnd->diff($DatumPreveri);
                if (($Interval1->invert == 0) && (($Interval2->invert > 0) or (($Interval2->invert ==0) && ($Interval2->days==0)))){
                    $DelPog[$i2][1]=1;
                    $DelPog[$i2][0]=$R["UrTeden"];
                    
        //'                $DelPog[$i2][4]=$R["SkupinaDela"]
        //'                $DelPog[$i2][5]=$R["OpisDela"]
        //'                $DelPog[$i2][6]=$R["VzgojnoDelo"]
                    $DelPog[$i2][8]=$R["DelovniCas"];
                    $DelPog[$i2][9]=$DelPog[$i2][2];
                    $DelPog[$i2][10]=$DelPog[$i2][3];
                    $DelPog[$i2][12]=$R["IdDelo"];
                    $DelPog[$i2][13]=$R["IzobUstr"];
                }else{
                    $i2=$i2-1;
                }
                $i2=$i2+1;
            }
            $StDelPogodba=$i2-1;
            
            if ($StDelPogodba > 0 ){
        //'        $Delavec[$Indx,4)=$DelPog[1,4)    'SkupinaDela
        //'        $Delavec[$Indx,5)=$DelPog[1,5)    'OpisDela
        //'        $Delavec[$Indx,6)=$DelPog[1,6)    'VzgojnoDelo
                $Delavec[$Indx][8]=$DelPog[1][8];    //'DelovniCas
                $Delavec[$Indx][9]=$DelPog[1][9];    //'DatumStart
                $Delavec[$Indx][10]=$DelPog[1][10];    //'DatumEnd
                $Delavec[$Indx][12]=$DelPog[1][12];    //'IdDelo
                $Delavec[$Indx][13]=$DelPog[1][13];    //'IzobUstr
            }
            
            //'pogleda ure, ki jih delavci učijo v določenih razredih - redne in izbirne predmete
            $SQL = "SELECT tabucenje.*,tabpredmeti.* FROM tabucenje ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE leto=".$VLeto." AND idUcitelj=".$Delavec[$Indx][0]." AND prioriteta IN (0,1)";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                switch ($R["Razred"]){
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        $Count16[3][4]=$Count16[3][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count16[4][4]=$Count16[4][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        }
                        break;
                    case 7:
                    case 8:
                    case 9:
                        $Count16[5][4]=$Count16[5][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count16[6][4]=$Count16[6][4]+$R["Planirano"]/$ObremenitevUcitelj;
                        }
                }
            }
            
            //'pogleda ure, ki jih delavci učijo v določenih razredih - OPB
            $SQL = "SELECT tabucenje.*,tabpredmeti.* FROM tabucenje ";
            $SQL = $SQL . "INNER JOIN tabpredmeti ON tabucenje.Predmet=tabpredmeti.id ";
            $SQL = $SQL . "WHERE leto=".$VLeto." AND idUcitelj=".$Delavec[$Indx][0]." AND oznaka IN ('OPB','PB01','PB02','PB03','PB04','PB05','PB06','PB07','PB08','PB09','PB10','PB11','PB12','PB13','PB14')";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $Count16[7][4]=$Count16[7][4]+$R["Planirano"]/$ObremenitevPB;
                if ($Delavec[$Indx][11]=="F" ){
                    $Count16[8][4]=$Count16[8][4]+$R["Planirano"]/$ObremenitevPB;
                }
            }
            
        //'    VDelovniCas=$Delavec[$Indx,8)  '1-krajši
        /*    VZacDela=$Delavec[$Indx,9)
            if VZacDela ="" ){
                VZacDela=Danes
            }
            VKonecDela=$Delavec[$Indx,10)
            if VKonecDela="" ){
                VkonecDela="31.12.".$VLeto+1
            }
        */    
            if ($StDelPogodba > 0 ){
                //'i1=i1+1
                switch ($Delavec[$Indx][12]){  //iddelo
                    case 1:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[4][1]=$Count16[4][1]+1;
                                $Count16[4][3]=$Count16[4][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[3][1]=$Count16[3][1]+1;
                            $Count16[3][3]=$Count16[3][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[4][1]=$Count16[4][1]+1;
                                $Count16[4][2]=$Count16[4][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[3][1]=$Count16[3][1]+1;
                            $Count16[3][2]=$Count16[3][2]+1;
                        }
                        break;
                    case 2:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[6][1]=$Count16[6][1]+1;
                                $Count16[6][3]=$Count16[6][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[5][1]=$Count16[5][1]+1;
                            $Count16[5][3]=$Count16[5][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[6][1]=$Count16[6][1]+1;
                                $Count16[6][2]=$Count16[6][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[5][1]=$Count16[5][1]+1;
                            $Count16[5][2]=$Count16[5][2]+1;
                        }
                        break;
                    case 3:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[8][1]=$Count16[8][1]+1;
                                $Count16[8][3]=$Count16[8][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[7][1]=$Count16[7][1]+1;
                            $Count16[7][3]=$Count16[7][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[8][1]=$Count16[8][1]+1;
                                $Count16[8][2]=$Count16[8][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[7][1]=$Count16[7][1]+1;
                            $Count16[7][2]=$Count16[7][2]+1;
                        }
                        break;
                    case 4:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[10][1]=$Count16[10][1]+1;
                                $Count16[10][3]=$Count16[10][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[9][1]=$Count16[9][1]+1;
                            $Count16[9][3]=$Count16[9][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[10][1]=$Count16[10][1]+1;
                                $Count16[10][2]=$Count16[10][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[9][1]=$Count16[9][1]+1;
                            $Count16[9][2]=$Count16[9][2]+1;
                        }
                        break;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[12][1]=$Count16[12][1]+1;
                                $Count16[12][3]=$Count16[12][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[11][1]=$Count16[11][1]+1;
                            $Count16[11][3]=$Count16[11][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[12][1]=$Count16[12][1]+1;
                                $Count16[12][2]=$Count16[12][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[11][1]=$Count16[11][1]+1;
                            $Count16[11][2]=$Count16[11][2]+1;
                        }
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        if ($Delavec[$Indx][8]==1 ){
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][3]=$Count16[2][3]+1;
                                $Count16[14][1]=$Count16[14][1]+1;
                                $Count16[14][3]=$Count16[14][3]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][3]=$Count16[1][3]+1;
                            $Count16[13][1]=$Count16[13][1]+1;
                            $Count16[13][3]=$Count16[13][3]+1;
                        }else{
                            if ($Delavec[$Indx][11]=="F" ){
                                $Count16[2][1]=$Count16[2][1]+1;
                                $Count16[2][2]=$Count16[2][2]+1;
                                $Count16[14][1]=$Count16[14][1]+1;
                                $Count16[14][2]=$Count16[14][2]+1;
                            }
                            $Count16[1][1]=$Count16[1][1]+1;
                            $Count16[1][2]=$Count16[1][2]+1;
                            $Count16[13][1]=$Count16[13][1]+1;
                            $Count16[13][2]=$Count16[13][2]+1;
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 1:  // učitelj I in II triada
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    //}
                                    break;
                                case 5: //srednja
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][3]=$Count17[4][3]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                                    */
                                    break;
                                case 6: //višja
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][4]=$Count17[4][4]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                                    break;
                                default: //visoka
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][6]=$Count17[4][6]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[4][5]=$Count17[4][5]+1;
                                        $Count17[4][2]=$Count17[4][2]+1;
                                        $Count17[4][1]=$Count17[4][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){    //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                //}
                                break;
                            case 5: //srednja
                                //if ($Delavec[$Indx][13]==1 ){   //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][3]=$Count17[3][3]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                                */
                                break;
                            case 6: //višja
                                if ($Delavec[$Indx][13]==1 ){  //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][4]=$Count17[3][4]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                                break;
                            default: //visoka
                                if ($Delavec[$Indx][13]==1 ){  //neustrezna izobrazba
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][6]=$Count17[3][6]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[3][5]=$Count17[3][5]+1;
                                    $Count17[3][2]=$Count17[3][2]+1;
                                    $Count17[3][1]=$Count17[3][1]+1;
                                }
                        }
                        break;
                    case 2:  //učitelj III. triada
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][3]=$Count17[6][3]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][4]=$Count17[6][4]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][6]=$Count17[6][6]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[6][5]=$Count17[6][5]+1;
                                    $Count17[6][2]=$Count17[6][2]+1;
                                    $Count17[6][1]=$Count17[6][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            //if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            //}
                            break;
                        case 5:
                            //if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                                /*
                            }else{
                                $Count17[1][3]=$Count17[1][3]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][3]=$Count17[5][3]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                            */
                            break;
                        case 6:
                            if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }else{
                                $Count17[1][4]=$Count17[1][4]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][4]=$Count17[5][4]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                            break;
                        default:
                            if ($Delavec[$Indx][13]==1 ){
                                $Count17[1][6]=$Count17[1][6]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][6]=$Count17[5][6]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }else{
                                $Count17[1][5]=$Count17[1][5]+1;
                                $Count17[1][2]=$Count17[1][2]+1;
                                $Count17[1][1]=$Count17[1][1]+1;
                                $Count17[5][5]=$Count17[5][5]+1;
                                $Count17[5][2]=$Count17[5][2]+1;
                                $Count17[5][1]=$Count17[5][1]+1;
                            }
                        }
                        break;
                    case 3: //PB
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][3]=$Count17[8][3]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][4]=$Count17[8][4]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][6]=$Count17[8][6]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[8][5]=$Count17[8][5]+1;
                                    $Count17[8][2]=$Count17[8][2]+1;
                                    $Count17[8][1]=$Count17[8][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][3]=$Count17[7][3]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][4]=$Count17[7][4]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                                break;
                            case 7:
                            case 8:
                            case 9:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][6]=$Count17[7][6]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[7][5]=$Count17[7][5]+1;
                                    $Count17[7][2]=$Count17[7][2]+1;
                                    $Count17[7][1]=$Count17[7][1]+1;
                                }
                        }
                        break;
                    case 4:  //vodstveni
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][3]=$Count17[10][3]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][4]=$Count17[10][4]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][6]=$Count17[10][6]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[10][5]=$Count17[10][5]+1;
                                    $Count17[10][2]=$Count17[10][2]+1;
                                    $Count17[10][1]=$Count17[10][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][3]=$Count17[9][3]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][4]=$Count17[9][4]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][6]=$Count17[9][6]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[9][5]=$Count17[9][5]+1;
                                    $Count17[9][2]=$Count17[9][2]+1;
                                    $Count17[9][1]=$Count17[9][1]+1;
                                }
                        }
                        break;
                    case 5: //pedagog
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 6: //psiholog
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 7: //socialni del.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 8: //specialni ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 9: //soc. ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][3]=$Count17[12][3]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][4]=$Count17[12][4]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][6]=$Count17[12][6]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[12][5]=$Count17[12][5]+1;
                                        $Count17[12][2]=$Count17[12][2]+1;
                                        $Count17[12][1]=$Count17[12][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 10: //drugi
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                    /*
                                }else{
                                    $Count17[2][3]=$Count17[2][3]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][3]=$Count17[12][3]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }else{
                                    $Count17[2][4]=$Count17[2][4]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][4]=$Count17[12][4]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[2][6]=$Count17[2][6]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][6]=$Count17[12][6]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }else{
                                    $Count17[2][5]=$Count17[2][5]+1;
                                    $Count17[2][2]=$Count17[2][2]+1;
                                    $Count17[2][1]=$Count17[2][1]+1;
                                    $Count17[12][5]=$Count17[12][5]+1;
                                    $Count17[12][2]=$Count17[12][2]+1;
                                    $Count17[12][1]=$Count17[12][1]+1;
                                }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][3]=$Count17[11][3]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][4]=$Count17[11][4]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][6]=$Count17[11][6]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[11][5]=$Count17[11][5]+1;
                                    $Count17[11][2]=$Count17[11][2]+1;
                                    $Count17[11][1]=$Count17[11][1]+1;
                                }
                        }
                        break;
                    case 11: //mob. spec. ped.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    breka;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 12: //knjiž.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 13: //ROID
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 14: //org. prehrana
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                        break;
                    case 15: //drugi strok. del.
                        if ($Delavec[$Indx][11]=="F" ){
                            switch ($Delavec[$Indx][3]){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                     //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    //}
                                    break;
                                case 5:
                                    //if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                        /*
                                    }else{
                                        $Count17[2][3]=$Count17[2][3]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][3]=$Count17[14][3]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    */
                                    break;
                                case 6:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][4]=$Count17[2][4]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][4]=$Count17[14][4]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                                    break;
                                default:
                                    if ($Delavec[$Indx][13]==1 ){
                                        $Count17[2][6]=$Count17[2][6]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][6]=$Count17[14][6]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }else{
                                        $Count17[2][5]=$Count17[2][5]+1;
                                        $Count17[2][2]=$Count17[2][2]+1;
                                        $Count17[2][1]=$Count17[2][1]+1;
                                        $Count17[14][5]=$Count17[14][5]+1;
                                        $Count17[14][2]=$Count17[14][2]+1;
                                        $Count17[14][1]=$Count17[14][1]+1;
                                    }
                            }
                        }
                        switch ($Delavec[$Indx][3]){
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                 //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                //}
                                break;
                            case 5:
                                //if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                    /*
                                }else{
                                    $Count17[1][3]=$Count17[1][3]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][3]=$Count17[13][3]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                */
                                break;
                            case 6:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][4]=$Count17[1][4]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][4]=$Count17[13][4]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                                break;
                            default:
                                if ($Delavec[$Indx][13]==1 ){
                                    $Count17[1][6]=$Count17[1][6]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][6]=$Count17[13][6]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }else{
                                    $Count17[1][5]=$Count17[1][5]+1;
                                    $Count17[1][2]=$Count17[1][2]+1;
                                    $Count17[1][1]=$Count17[1][1]+1;
                                    $Count17[13][5]=$Count17[13][5]+1;
                                    $Count17[13][2]=$Count17[13][2]+1;
                                    $Count17[13][1]=$Count17[13][1]+1;
                                }
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 5:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][2]=$Count18[2][2]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][2]=$Count18[1][2]+1;
                        break;
                    case 6:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][3]=$Count18[2][3]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][3]=$Count18[1][3]+1;
                        break;
                    case 7:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][4]=$Count18[2][4]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][4]=$Count18[1][4]+1;
                        break;
                    case 8:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][5]=$Count18[2][5]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][5]=$Count18[1][5]+1;
                        break;
                    case 9:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][6]=$Count18[2][6]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][6]=$Count18[1][6]+1;
                        break;
                    case 10:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][1]=$Count18[2][1]+1;
                            $Count18[2][7]=$Count18[2][7]+1;
                        }
                        $Count18[1][1]=$Count18[1][1]+1;
                        $Count18[1][7]=$Count18[1][7]+1;
                        break;
                    case 11:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][9]=$Count18[2][9]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][9]=$Count18[1][9]+1;
                        break;
                    case 12:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][10]=$Count18[2][10]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][10]=$Count18[1][10]+1;
                        break;
                    case 13:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][11]=$Count18[2][11]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][11]=$Count18[1][11]+1;
                        break;
                    case 14:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][12]=$Count18[2][12]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][12]=$Count18[1][12]+1;
                        break;
                    case 15:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count18[2][8]=$Count18[2][8]+1;
                            $Count18[2][13]=$Count18[2][13]+1;
                        }
                        $Count18[1][8]=$Count18[1][8]+1;
                        $Count18[1][13]=$Count18[1][13]+1;
                }
                
                switch ($Delavec[$Indx][12]){
                    case 1:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][2]=$Count19[4][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][2]=$Count19[3][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][3]=$Count19[4][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][3]=$Count19[3][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][4]=$Count19[4][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][4]=$Count19[3][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][5]=$Count19[4][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][5]=$Count19[3][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][6]=$Count19[4][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][6]=$Count19[3][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][7]=$Count19[4][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][7]=$Count19[3][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][8]=$Count19[4][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][8]=$Count19[3][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][9]=$Count19[4][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][9]=$Count19[3][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][10]=$Count19[4][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][10]=$Count19[3][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[4][1]=$Count19[4][1]+1;
                                    $Count19[4][11]=$Count19[4][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[3][1]=$Count19[3][1]+1;
                                $Count19[3][11]=$Count19[3][11]+1;
                        }
                        break;
                    case 2:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][2]=$Count19[6][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][2]=$Count19[5][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][3]=$Count19[6][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][3]=$Count19[5][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][4]=$Count19[6][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][4]=$Count19[5][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][5]=$Count19[6][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][5]=$Count19[5][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][6]=$Count19[6][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][6]=$Count19[5][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][7]=$Count19[6][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][7]=$Count19[5][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][8]=$Count19[6][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][8]=$Count19[5][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][9]=$Count19[6][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][9]=$Count19[5][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][10]=$Count19[6][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][10]=$Count19[5][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[6][1]=$Count19[6][1]+1;
                                    $Count19[6][11]=$Count19[6][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[5][1]=$Count19[5][1]+1;
                                $Count19[5][11]=$Count19[5][11]+1;
                        }
                        break;
                    case 3:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][2]=$Count19[8][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][2]=$Count19[7][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][3]=$Count19[8][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][3]=$Count19[7][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][4]=$Count19[8][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][4]=$Count19[7][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][5]=$Count19[8][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][5]=$Count19[7][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][6]=$Count19[8][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][6]=$Count19[7][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][7]=$Count19[8][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][7]=$Count19[7][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][8]=$Count19[8][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][8]=$Count19[7][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][9]=$Count19[8][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][9]=$Count19[7][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][10]=$Count19[8][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][10]=$Count19[7][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[8][1]=$Count19[8][1]+1;
                                    $Count19[8][11]=$Count19[8][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[7][1]=$Count19[7][1]+1;
                                $Count19[7][11]=$Count19[7][11]+1;
                        }
                        break;
                    case 4:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][2]=$Count19[10][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][2]=$Count19[9][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][3]=$Count19[10][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][3]=$Count19[9][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][4]=$Count19[10][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][4]=$Count19[9][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][5]=$Count19[10][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][5]=$Count19[9][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][6]=$Count19[10][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][6]=$Count19[9][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][7]=$Count19[10][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][7]=$Count19[9][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][8]=$Count19[10][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][8]=$Count19[9][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][9]=$Count19[10][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][9]=$Count19[9][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][10]=$Count19[10][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][10]=$Count19[9][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[10][1]=$Count19[10][1]+1;
                                    $Count19[10][11]=$Count19[10][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[9][1]=$Count19[9][1]+1;
                                $Count19[9][11]=$Count19[9][11]+1;
                        }
                        break;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][2]=$Count19[12][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][2]=$Count19[11][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][3]=$Count19[12][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][3]=$Count19[11][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][4]=$Count19[12][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][4]=$Count19[11][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][5]=$Count19[12][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][5]=$Count19[11][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][6]=$Count19[12][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][6]=$Count19[11][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][7]=$Count19[12][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][7]=$Count19[11][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][8]=$Count19[12][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][8]=$Count19[11][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][9]=$Count19[12][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][9]=$Count19[11][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][10]=$Count19[12][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][10]=$Count19[11][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[12][1]=$Count19[12][1]+1;
                                    $Count19[12][11]=$Count19[12][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[11][1]=$Count19[11][1]+1;
                                $Count19[11][11]=$Count19[11][11]+1;
                        }
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        switch ($VLeto-$Delavec[$Indx][2]){
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][2]=$Count19[2][2]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][2]=$Count19[14][2]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][2]=$Count19[1][2]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][2]=$Count19[13][2]+1;
                                break;
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][3]=$Count19[2][3]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][3]=$Count19[14][3]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][3]=$Count19[1][3]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][3]=$Count19[13][3]+1;
                                break;
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][4]=$Count19[2][4]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][4]=$Count19[14][4]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][4]=$Count19[1][4]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][4]=$Count19[13][4]+1;
                                break;
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][5]=$Count19[2][5]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][5]=$Count19[14][5]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][5]=$Count19[1][5]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][5]=$Count19[13][5]+1;
                                break;
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][6]=$Count19[2][6]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][6]=$Count19[14][6]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][6]=$Count19[1][6]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][6]=$Count19[13][6]+1;
                                break;
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][7]=$Count19[2][7]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][7]=$Count19[14][7]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][7]=$Count19[1][7]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][7]=$Count19[13][7]+1;
                                break;
                            case 50:
                            case 51:
                            case 52:
                            case 53:
                            case 54:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][8]=$Count19[2][8]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][8]=$Count19[14][8]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][8]=$Count19[1][8]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][8]=$Count19[13][8]+1;
                                break;
                            case 55:
                            case 56:
                            case 57:
                            case 58:
                            case 59:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][9]=$Count19[2][9]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][9]=$Count19[14][9]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][9]=$Count19[1][9]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][9]=$Count19[13][9]+1;
                                break;
                            case 60:
                            case 61:
                            case 62:
                            case 63:
                            case 64:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][10]=$Count19[2][10]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][10]=$Count19[14][10]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][10]=$Count19[1][10]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][10]=$Count19[13][10]+1;
                                break;
                            default:
                                if ($Delavec[$Indx][11]=="F" ){
                                    $Count19[2][1]=$Count19[2][1]+1;
                                    $Count19[2][11]=$Count19[2][11]+1;
                                    $Count19[14][1]=$Count19[14][1]+1;
                                    $Count19[14][11]=$Count19[14][11]+1;
                                }
                                $Count19[1][1]=$Count19[1][1]+1;
                                $Count19[1][11]=$Count19[1][11]+1;
                                $Count19[13][1]=$Count19[13][1]+1;
                                $Count19[13][11]=$Count19[13][11]+1;
                        }
                }
                
                switch ($Delavec[$Indx][12]){
                    case 16:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][4]=$Count20[1][4]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][3]=$Count20[1][3]+1;
                        break;
                    case 17:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][6]=$Count20[1][6]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][5]=$Count20[1][5]+1;
                        break;
                    case 18:
                        if ($Delavec[$Indx][11]=="F" ){
                            $Count20[1][2]=$Count20[1][2]+1;
                            $Count20[1][8]=$Count20[1][8]+1;
                        }
                        $Count20[1][1]=$Count20[1][1]+1;
                        $Count20[1][7]=$Count20[1][7]+1;
                }
            }
        }

            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="od tega ženske";
            $Rubrike14[3]="Učitelji v I. in II. triadi 9-letne OŠ";
            $Rubrike14[4]="od tega ženske";
            $Rubrike14[5]="Učitelji v III. triadi 9-letne OŠ";
            $Rubrike14[6]="od tega ženske";
            $Rubrike14[7]="Učitelji v oddelkih PB - vsi";
            $Rubrike14[8]="od tega ženske";
            $Rubrike14[9]="Vodstveni delavci - vsi";
            $Rubrike14[10]="od tega ženske";
            $Rubrike14[11]="Svetovalni delavci - vsi";
            $Rubrike14[12]="od tega ženske";
            $Rubrike14[13]="Drugi strokovni delavci - vsi";
            $Rubrike14[14]="od tega ženske";
            echo "<b>15. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po delovnem razmerju ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Skupaj</th><th>Polni delovni čas</th><th>Krajši delovni čas</th><th>Ekvivalent polnega delovnega časa</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                if ($Count16[$Indx][4] > 0 ){
                    echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count16[$Indx][1]."</td><td align=center>".$Count16[$Indx][2]."</td><td align=center>".$Count16[$Indx][3]."</td><td align=center>".number_format($Count16[$Indx][4],1)."</td></tr>";
                }else{
                    echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count16[$Indx][1]."</td><td align=center>".$Count16[$Indx][2]."</td><td align=center>".$Count16[$Indx][3]."</td><td align=center>".$Count16[$Indx][4]."</td></tr>";
                }    
            }
            echo "</table><br />";

            
            echo "<b>16. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po izobrazbi ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Skupaj (2+6)</th><th>Skupaj (3+4+5)</th><th>S srednjo izobrazbo</th><th>Z višjo</th><th>Z visoko</th><th>Z neustrezno</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count17[$Indx][1]."</td><td align=center>".$Count17[$Indx][2]."</td><td align=center>".$Count17[$Indx][3]."</td><td align=center>".$Count17[$Indx][4]."</td><td align=center>".$Count17[$Indx][5]."</td><td align=center>".$Count17[$Indx][6]."</td></tr>";
            }
            echo "</table><br />";

        //'Svetovalni in drugi strokovni delavec - zacetek

            echo "<b>17. Svetovalni in drugi strokovni delavci ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Vsi (2-7)</th><th>pedagog</th><th>psiholog</th><th>socialni delavec</th><th>specialni pedagog</th><th>socialni pedagog</th><th>drugi</th><th>Vsi (9-13)</th><th>mobilni specialni pedagog</th><th>knjižničar</th><th>organizator informacijske dejavnosti</th><th>organizator prehrane</th><th>drugi</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td><td align=center>11</td><td align=center>12</td><td align=center>13</td></tr>";
            for ($Indx=1;$Indx <= 2;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count18[$Indx][1]."</td><td align=center>".$Count18[$Indx][2]."</td><td align=center>".$Count18[$Indx][3]."</td><td align=center>".$Count18[$Indx][4]."</td>";
                echo "<td align=center>".$Count18[$Indx][5]."</td>";
                echo "<td align=center>".$Count18[$Indx][6]."</td>";
                echo "<td align=center>".$Count18[$Indx][7]."</td>";
                echo "<td align=center>".$Count18[$Indx][8]."</td>";
                echo "<td align=center>".$Count18[$Indx][9]."</td>";
                echo "<td align=center>".$Count18[$Indx][10]."</td>";
                echo "<td align=center>".$Count18[$Indx][11]."</td>";
                echo "<td align=center>".$Count18[$Indx][12]."</td>";
                echo "<td align=center>".$Count18[$Indx][13]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
        //'Svetovalni in drugi strokovni delavci - konec    
            
            $Rubrike14[1]="Vsi";
            $Rubrike14[2]="od tega ženske";
            $Rubrike14[3]="Učitelji v I. in II. triadi 9-letne OŠ";
            $Rubrike14[4]="od tega ženske";
            $Rubrike14[5]="Učitelji v III. triadi 9-letne OŠ";
            $Rubrike14[6]="od tega ženske";
            $Rubrike14[7]="Učitelji v oddelkih PB - vsi";
            $Rubrike14[8]="od tega ženske";
            $Rubrike14[9]="Vodstveni delavci - vsi";
            $Rubrike14[10]="od tega ženske";
            $Rubrike14[11]="Svetovalni delavci - vsi";
            $Rubrike14[12]="od tega ženske";
            $Rubrike14[13]="Drugi strokovni delavci - vsi";
            $Rubrike14[14]="od tega ženske";
            echo "<b>18. Učitelji, vodstveni, svetovalni in drugi strokovni delavci po starostnih razredih ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Učitelji, vodstveni, svetovalni in drugi strokovni delavci</th><th>Št.</th><th>Vsi [2-11]</th><th>Mlajši od 25 let</th><th>25-29 let</th><th>30-34 let</th><th>35-39 let</th><th>40-44 let</th><th>45-49 let</th><th>50-54 let</th><th>55-59 let</th><th>60-64 let</th><th>65 let in starejši</th>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td><td align=center>9</td><td align=center>10</td><td align=center>11</td></tr>";
            for ($Indx=1;$Indx <= 14;$Indx++){
                echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td><td align=center>".$Count19[$Indx][1]."</td><td align=center>".$Count19[$Indx][2]."</td><td align=center>".$Count19[$Indx][3]."</td><td align=center>".$Count19[$Indx][4]."</td><td align=center>".$Count19[$Indx][5]."</td><td align=center>".$Count19[$Indx][6]."</td><td align=center>".$Count19[$Indx][7]."</td><td align=center>".$Count19[$Indx][8]."</td><td align=center>".$Count19[$Indx][9]."</td><td align=center>".$Count19[$Indx][10]."</td><td align=center>".$Count19[$Indx][11]."</td></tr>";
            }
            echo "</table><br />";

        //'Drugi svetovalni delavci - zacetek

            echo "<b>19. Drugi zaposleni delavci ".$VLeto."/".($VLeto+1)."</b><br />";
            echo "<table border=1>";
            echo "<th>Drugi zaposleni</th><th>Št.</th><th>Vsi (3+5+7)</th><th>Ženske (4+6+8)</th><th>Administrativni in računovodski delavci</th><th></th><th>Tehnični delavci</th><th></th><th>Drugi delavci</th><th></th>";
            echo "<tr><td align=center></td><td></td><td align=center></td><td align=center></td><td align=center>skupaj</td><td align=center>ženske</td><td align=center>skupaj</td><td align=center>ženske</td><td align=center>skupaj</td><td align=center>ženske</td></tr>";
            echo "<tr><td align=center>a</td><td></td><td align=center>1</td><td align=center>2</td><td align=center>3</td><td align=center>4</td><td align=center>5</td><td align=center>6</td><td align=center>7</td><td align=center>8</td></tr>";
            $Indx=1;
            echo "<tr><td>".$Rubrike14[$Indx]."</td><td align=center>".$Indx."</td>";
            echo "<td align=center>".$Count20[$Indx][1]."</td>";
            echo "<td align=center>".$Count20[$Indx][2]."</td>";
            echo "<td align=center>".$Count20[$Indx][3]."</td>";
            echo "<td align=center>".$Count20[$Indx][4]."</td>";
            echo "<td align=center>".$Count20[$Indx][5]."</td>";
            echo "<td align=center>".$Count20[$Indx][6]."</td>";
            echo "<td align=center>".$Count20[$Indx][7]."</td>";
            echo "<td align=center>".$Count20[$Indx][8]."</td>";
            echo "</tr>";
            echo "</table><br />";
                //'Drugi zaposleni delavci - konec    
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

//}
?>

</body>
</html>
