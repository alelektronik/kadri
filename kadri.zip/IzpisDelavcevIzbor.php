<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis dopustov
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("PreglZbirn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

if (isset($_POST["StPolj"])){
    $StPolj=$_POST["StPolj"];
}else{
    $StPolj=28;
}

for ($Indx=1;$Indx <= $StPolj;$Indx++){
    if (isset($_POST["polje".$Indx])){
	    $polje[$Indx]=$_POST["polje".$Indx];
    }
}


//'izpis učiteljev
if (isset($polje[25])){
    //'izpis vseh
	$SQL = "SELECT tabucitelji.*, TabStatus.*,TabIzobrazba.Opis ";
	if (isset($polje[27])){
		$SQL = $SQL . ",TabDopust.* ";
	}
	$SQL = $SQL . "FROM ((tabucitelji ";
	$SQL = $SQL . "INNER JOIN TabStatus ON tabucitelji.status=TabStatus.idStatus) ";
	$SQL = $SQL . "INNER JOIN TabIzobrazba ON tabucitelji.izobrazba=TabIzobrazba.idIzobrazba) ";
	if (isset($polje[27])){
		$SQL = $SQL . "INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj ";
	}
	if (isset($polje[26])){
		$SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6)) ";
	}else{
		$SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6,10))";
	}
	if (isset($polje[27])){
		$SQL = $SQL . " AND (leto = ".$Danes->format('Y').")";
	}
	if (isset($polje[12])){
		switch ($_POST["kriterij_izobr"]){
			case "1": //'>i
				$SQL = $SQL . " AND (Izobrazba > ".$_POST["izobrazba"].")";
                break;
			case "2": // '<
				$SQL = $SQL . " AND (Izobrazba < ".$_POST["izobrazba"].")";
                break;
			case "3": // '=
				$SQL = $SQL . " AND (Izobrazba = ".$_POST["izobrazba"].")";
		}
	}
	if (isset($polje[20])){
		switch ($_POST["kriterij_naziv"]){
			case "0": // 'enak
				switch ($_POST["naziv"]){
					case "0": // 'vsi
						$SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) " ;
                        break;
					case "1": // 'brez
						$SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "2": // 'mentor
						$SQL = $SQL . " AND ((mentor <> '') AND (svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "3": // 'svetovalec
						$SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik = '')) ";
                        break;
					case "4": // 'svetnik
						$SQL = $SQL . " AND (svetnik <> '') ";
				}
                break;
			case "1": // 'večji
				switch ($_POST["naziv"]){
					case "0": // 'vsi
						$SQL = $SQL . " AND (mentor <> '' OR svetovalec <> '' OR svetnik <> '') ";
                        break;
					case "1": // 'brez
						$SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) ";
                        break;
					case "2": // 'mentor
						$SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik <> '')) ";
                        break;
					case "3": // 'svetovalec
						$SQL = $SQL . " AND ((svetnik <> '')) ";
                        break;
					case "4": // 'svetnik
						$SQL = $SQL . " AND (svetnik <> '') ";
				}
			case "2": // 'manjši
				switch ($_POST["naziv"]){
					case "0": // 'vsi
						$SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "1": // 'brez
						$SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "2": // 'mentor
						$SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "3": // 'svetovalec
						$SQL = $SQL . " AND ((svetovalec = '') AND (svetnik = '')) ";
                        break;
					case "4": // 'svetnik
						$SQL = $SQL . " AND (svetnik = '') ";
				}
		}
	}
	$SQL = $SQL . " ORDER BY priimek,ime";

	$result = mysqli_query($link,$SQL);

	echo "<h2>Seznam učiteljev: " .$Danes->format('d.m.Y')."</h2>" ;

	echo "<table border='1' cellspacing='0' cellpadding='4'>";
	echo "<tr bgcolor='lightcyan'>";
	echo "<th>Št.</th>";
	if (isset($polje[2])){ 
        echo "<th>Priimek</th><th>ime</th>";
    }
	if (isset($polje[9])){ 
        echo "<th>Spol</th>";
    }
	if (isset($polje[3])){ 
        echo "<th>Datum rojstva</th>";
    }
	if (isset($polje[28])){ 
        echo "<th>Kraj rojstva</th>";
    }
	if (isset($polje[11])){ 
        echo "<th>EMŠO</th>";
    }
	if (isset($polje[4])){ 
        echo "<th>Naslov</th>";
    }
	if (isset($polje[5])){ 
        echo "<th>Pošta</th>";
    }
	if (isset($polje[6])){ 
        echo "<th>Kraj</th>";
    }
	if (isset($polje[12])){ 
        echo "<th>Stopnja izobr.</th><th>Izobrazba</th>";
    }
	if (isset($polje[14])){ 
        echo "<th>Delo</th>";
    }
	if (isset($polje[17])){ 
        echo "<th>Datum začetka dela</th>";
    }
	if (isset($polje[18])){ 
        echo "<th>Datum zaključka dela</th>";
    }
	if (isset($polje[19])){ 
        echo "<th>Status</th>";
    }
	if (isset($polje[20])){ 
        echo "<th>Naziv</th>";
    }
	if (isset($polje[21])){ 
        echo "<th>Prevoz</th>";
    }
	if (isset($polje[23])){ 
        echo "<th>Starejši</th>";
    }
	if (isset($polje[24])){ 
        echo "<th>Doječa mati</th>";
    }
	if (isset($polje[22])){ 
        echo "<th>Dostop</th>";
    }
	if (isset($polje[27])){ 
        echo "<th>Dopust<br>stari</th><th>Dopust</th><th>Dopust<br>skupaj</th>";
    }
	if (isset($polje[13])){ 
        echo "<th>Podpis</th>";
    }
	echo "</tr>";

	$Indx=1;
	while ($R = mysqli_fetch_array($result)){
	//		echo "<tr><td></td></tr>"
        $oUcitelj=new RUcitelj();
        $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$Danes->format('Y'),$VLeto);
        
		if ($R["Spol"]=="M"){
			echo "<tr bgcolor='lightyellow'>";
		}else{
			echo "<tr bgcolor=#FFFFCC>";
		}
		echo "<td bgcolor='lightgrey' align='right'>" . $Indx ."</td>";
		if (isset($polje[2])){ 
            echo "<td>" . $R["Priimek"] . "</td><td>" . $R["Ime"] . "</td>";
        }
		if (isset($polje[9])){ 
            echo "<td>" . $R["Spol"]. "</td>";
        }
		if (isset($polje[3])){ 
            $Datum=new DateTime($R["DatRoj"]);
            echo "<td align='right'>" .$Datum->format('d.m.Y'). "</td>";
        }
		if (isset($polje[28])){ 
            echo "<td>" . $R["KrajRoj"]. "</td>";
        }
		if (isset($polje[11])){ 
            echo "<td>" . $R["EMSO"]. "</td>";
        }
		if (isset($polje[4])){ 
            echo "<td>". $R["Naslov"] ."</td>";
        }
		if (isset($polje[5])){ 
            echo "<td>". $R["Posta"] ."</td>";
        }
		if (isset($polje[6])){ 
            echo "<td>". $R["Kraj"] ."</td>";
        }
		if (isset($polje[12])){ 
            echo "<td align=center>". $R["Opis"]."</td><td>".$R["IzobOpis"] ."</td>";
        }

		$VLetoPregled=$Danes->format('Y');

		if (isset($polje[14])){ 
			echo "<td>". $oUcitelj->getDelMesto() ."</td>";
		}
		if (isset($polje[17])){ 
            echo "<td>". $Danes->format('d.m.Y') ."</td>";
        }
		if (isset($polje[18])){ 
            echo "<td>/</td>";
        }
		if (isset($polje[19])){ 
            echo "<td>". $oUcitelj->getStatusDelavca() ."</td>";
        }
		if (isset($polje[20])){ 
			if (isset($R["Svetnik"]) && (strlen($R["Svetnik"]) > 0)){
				echo "<td>Svetnik: ". $R["Svetnik"] ."</td>";
			}else{
				if (isset($R["Svetovalec"]) && (strlen($R["Svetovalec"]) > 0)){
					echo "<td>Svetovalec: ". $R["Svetovalec"] ."</td>";
				}else{
					if (isset($R["Mentor"]) && strlen($R["Mentor"]) > 0){
						echo "<td>Mentor: ". $R["Mentor"] ."</td>";
					}else{
						if (isset($R["StrokIzpit"]) && strlen($R["StrokIzpit"]) > 0){
							echo "<td>Strokovni izpit: ". $R["StrokIzpit"] ."</td>";
						}else{
							echo "<td>&nbsp;</td>";
						}
					}
				}
			}
		}
		if (isset($polje[21])){ 
            echo "<td>".$R["Prevoz"]."</td>";
        }
		
		if (isset($polje[23])){
			if ($R["Starejsi"]){
				echo "<td><input type='checkbox' checked></td>";
			}else{
				echo "<td><input type='checkbox'></td>";
			}
		}
		if (isset($polje[24])){
			if ($R["DojecaMati"]){
				echo "<td><input type='checkbox' checked></td>";
			}else{
				echo "<td><input type='checkbox'></td>";
			}
		}
		
		if (isset($polje[22])){ 
            echo "<td>".$R["NivoDostopa"]."</td>";
        }
		if (isset($polje[27])){
			echo "<td>".$oUcitelj->getDopustStari()."</td>";
			echo "<td>".$oUcitelj->getDopust()."</td>";
			echo "<td>".($oUcitelj->getDopustStari()+$oUcitelj->getDopust())."</td>";
		}
		if (isset($polje[13])){ 
            echo "<td>&nbsp;</td>";
        }
		echo "</tr>";
		$Indx=$Indx+1;
        $oUcitelj=null;
	}
	echo "</table>";
}else{
	if (isset($polje[1])){   
        //'seznam učiteljev
        $SQL = "SELECT tabucitelji.*, TabStatus.*,TabIzobrazba.Opis ";
        if (isset($polje[27])){
            $SQL = $SQL . ",TabDopust.* ";
        }
        $SQL = $SQL . "FROM ((tabucitelji ";
        $SQL = $SQL . "INNER JOIN TabStatus ON tabucitelji.status=TabStatus.idStatus) ";
        $SQL = $SQL . "INNER JOIN TabIzobrazba ON tabucitelji.izobrazba=TabIzobrazba.idIzobrazba) ";
        if (isset($polje[27])){
            $SQL = $SQL . "INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj ";
        }
        if (isset($polje[26])){
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6)) ";
        }else{
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6,10))";
        }
        if (isset($polje[27])){
            $SQL = $SQL . " AND (leto = ".$Danes->format('Y').")";
        }
        if (isset($polje[12])){
            switch ($_POST["kriterij_izobr"]){
                case "1": //'>i
                    $SQL = $SQL . " AND (Izobrazba > ".$_POST["izobrazba"].")";
                    break;
                case "2": // '<
                    $SQL = $SQL . " AND (Izobrazba < ".$_POST["izobrazba"].")";
                    break;
                case "3": // '=
                    $SQL = $SQL . " AND (Izobrazba = ".$_POST["izobrazba"].")";
            }
        }
        if (isset($polje[20])){
            switch ($_POST["kriterij_naziv"]){
                case "0": // 'enak
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) " ;
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor <> '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                    break;
                case "1": // 'večji
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND (mentor <> '' OR svetovalec <> '' OR svetnik <> '') ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik <> '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetnik <> '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                case "2": // 'manjši
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik = '') ";
                    }
            }
        }
        $SQL = $SQL . " ORDER BY priimek,ime";

        $result = mysqli_query($link,$SQL);

        echo "<h2>Seznam učiteljev: " .$Danes->format('d.m.Y')."</h2>" ;

        echo "<table border='1' cellspacing='0' cellpadding='4'>";
        echo "<tr bgcolor='lightcyan'>";
        echo "<th>Št.</th>";
        if (isset($polje[2])){ 
            echo "<th>Priimek</th><th>ime</th>";
        }
        if (isset($polje[9])){ 
            echo "<th>Spol</th>";
        }
        if (isset($polje[3])){ 
            echo "<th>Datum rojstva</th>";
        }
        if (isset($polje[28])){ 
            echo "<th>Kraj rojstva</th>";
        }
        if (isset($polje[11])){ 
            echo "<th>EMŠO</th>";
        }
        if (isset($polje[4])){ 
            echo "<th>Naslov</th>";
        }
        if (isset($polje[5])){ 
            echo "<th>Pošta</th>";
        }
        if (isset($polje[6])){ 
            echo "<th>Kraj</th>";
        }
        if (isset($polje[12])){ 
            echo "<th>Stopnja izobr.</th><th>Izobrazba</th>";
        }
        if (isset($polje[14])){ 
            echo "<th>Delo</th>";
        }
        if (isset($polje[17])){ 
            echo "<th>Datum začetka dela</th>";
        }
        if (isset($polje[18])){ 
            echo "<th>Datum zaključka dela</th>";
        }
        if (isset($polje[19])){ 
            echo "<th>Status</th>";
        }
        if (isset($polje[20])){ 
            echo "<th>Naziv</th>";
        }
        if (isset($polje[21])){ 
            echo "<th>Prevoz</th>";
        }
        if (isset($polje[23])){ 
            echo "<th>Starejši</th>";
        }
        if (isset($polje[24])){ 
            echo "<th>Doječa mati</th>";
        }
        if (isset($polje[22])){ 
            echo "<th>Dostop</th>";
        }
        if (isset($polje[27])){ 
            echo "<th>Dopust<br>stari</th><th>Dopust</th><th>Dopust<br>skupaj</th>";
        }
        if (isset($polje[13])){ 
            echo "<th>Podpis</th>";
        }
        echo "</tr>";

	    $Indx=1;
	    while ($R = mysqli_fetch_array($result)){
	    //'		echo "<tr><td></td></tr>"
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$Danes->format('Y'),$VLeto);
	    
            $astr=explode(",",$oUcitelj->getIdVzgojnoDelo());
            $ustrezen=false;
			for ($i=0;$i < count($astr);$i++){
				switch ($astr[$i]){
					case 1:
                    case 2:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 13:
                    case 14:
                    case 17:
                    case 19:
						$ustrezen=true;
				}
            }
			
			if ($ustrezen){
                if ($R["Spol"]=="M"){
                    echo "<tr bgcolor='lightyellow'>";
                }else{
                    echo "<tr bgcolor=#FFFFCC>";
                }
                echo "<td bgcolor='lightgrey' align='right'>" . $Indx ."</td>";
                if (isset($polje[2])){ 
                    echo "<td>" . $R["Priimek"] . "</td><td>" . $R["Ime"] . "</td>";
                }
                if (isset($polje[9])){ 
                    echo "<td>" . $R["Spol"]. "</td>";
                }
                if (isset($polje[3])){ 
                    $Datum=new DateTime($R["DatRoj"]);
                    echo "<td align='right'>" .$Datum->format('d.m.Y'). "</td>";
                }
                if (isset($polje[28])){ 
                    echo "<td>" . $R["KrajRoj"]. "</td>";
                }
                if (isset($polje[11])){ 
                    echo "<td>" . $R["EMSO"]. "</td>";
                }
                if (isset($polje[4])){ 
                    echo "<td>". $R["Naslov"] ."</td>";
                }
                if (isset($polje[5])){ 
                    echo "<td>". $R["Posta"] ."</td>";
                }
                if (isset($polje[6])){ 
                    echo "<td>". $R["Kraj"] ."</td>";
                }
                if (isset($polje[12])){ 
                    echo "<td align=center>". $R["Opis"]."</td><td>".$R["IzobOpis"] ."</td>";
                }

                $VLetoPregled=$Danes->format('Y');

                if (isset($polje[14])){ 
                    echo "<td>". $oUcitelj->getDelMesto() ."</td>";
                }
                if (isset($polje[17])){ 
                    echo "<td>". $Danes->format('d.m.Y') ."</td>";
                }
                if (isset($polje[18])){ 
                    echo "<td>/</td>";
                }
                if (isset($polje[19])){ 
                    echo "<td>". $oUcitelj->getStatusDelavca() ."</td>";
                }
                if (isset($polje[20])){ 
                    if (strlen($R["Svetnik"]) > 0){
                        echo "<td>Svetnik: ". $R["Svetnik"] ."</td>";
                    }else{
                        if (strlen($R["Svetovalec"]) > 0){
                            echo "<td>Svetovalec: ". $R["Svetovalec"] ."</td>";
                        }else{
                            if (strlen($R["mentor"]) > 0){
                                echo "<td>Mentor: ". $R["Mentor"] ."</td>";
                            }else{
                                if (strlen($R["StrokIzpit"]) > 0){
                                    echo "<td>Strokovni izpit: ". $R["StrokIzpit"] ."</td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                }
                            }
                        }
                    }
                }
                if (isset($polje[21])){ 
                    echo "<td>".$R["Prevoz"]."</td>";
                }
                
                if (isset($polje[23])){
                    if ($R["Starejsi"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                if (isset($polje[24])){
                    if ($R["DojecaMati"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                
                if (isset($polje[22])){ 
                    echo "<td>".$R["NivoDostopa"]."</td>";
                }
                if (isset($polje[27])){
                    echo "<td>".$oUcitelj->getDopustStari()."</td>";
                    echo "<td>".$oUcitelj->getDopust()."</td>";
                    echo "<td>".($oUcitelj->getDopustStari()+$oUcitelj->getDopust())."</td>";
                }
                if (isset($polje[13])){ 
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
                $oUcitelj=null;
            }
        }
	    echo "</table>";
	}

//	'izpis svetovalnih in strokovnih delavcev
	if (isset($polje[7])){
        $SQL = "SELECT tabucitelji.*, TabStatus.*,TabIzobrazba.Opis ";
        if (isset($polje[27])){
            $SQL = $SQL . ",TabDopust.* ";
        }
        $SQL = $SQL . "FROM ((tabucitelji ";
        $SQL = $SQL . "INNER JOIN TabStatus ON tabucitelji.status=TabStatus.idStatus) ";
        $SQL = $SQL . "INNER JOIN TabIzobrazba ON tabucitelji.izobrazba=TabIzobrazba.idIzobrazba) ";
        if (isset($polje[27])){
            $SQL = $SQL . "INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj ";
        }
        if (isset($polje[26])){
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6)) ";
        }else{
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6,10))";
        }
        if (isset($polje[27])){
            $SQL = $SQL . " AND (leto = ".$Danes->format('Y').")";
        }
        if (isset($polje[12])){
            switch ($_POST["kriterij_izobr"]){
                case "1": //'>i
                    $SQL = $SQL . " AND (Izobrazba > ".$_POST["izobrazba"].")";
                    break;
                case "2": // '<
                    $SQL = $SQL . " AND (Izobrazba < ".$_POST["izobrazba"].")";
                    break;
                case "3": // '=
                    $SQL = $SQL . " AND (Izobrazba = ".$_POST["izobrazba"].")";
            }
        }
        if (isset($polje[20])){
            switch ($_POST["kriterij_naziv"]){
                case "0": // 'enak
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) " ;
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor <> '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                    break;
                case "1": // 'večji
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND (mentor <> '' OR svetovalec <> '' OR svetnik <> '') ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik <> '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetnik <> '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                case "2": // 'manjši
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik = '') ";
                    }
            }
        }
        $SQL = $SQL . " ORDER BY priimek,ime";

        $result = mysqli_query($link,$SQL);

        echo "<h2>Seznam svetovalnih delavcev: " .$Danes->format('d.m.Y')."</h2>" ;

        echo "<table border='1' cellspacing='0' cellpadding='4'>";
        echo "<tr bgcolor='lightcyan'>";
        echo "<th>Št.</th>";
        if (isset($polje[2])){ 
            echo "<th>Priimek</th><th>ime</th>";
        }
        if (isset($polje[9])){ 
            echo "<th>Spol</th>";
        }
        if (isset($polje[3])){ 
            echo "<th>Datum rojstva</th>";
        }
        if (isset($polje[28])){ 
            echo "<th>Kraj rojstva</th>";
        }
        if (isset($polje[11])){ 
            echo "<th>EMŠO</th>";
        }
        if (isset($polje[4])){ 
            echo "<th>Naslov</th>";
        }
        if (isset($polje[5])){ 
            echo "<th>Pošta</th>";
        }
        if (isset($polje[6])){ 
            echo "<th>Kraj</th>";
        }
        if (isset($polje[12])){ 
            echo "<th>Stopnja izobr.</th><th>Izobrazba</th>";
        }
        if (isset($polje[14])){ 
            echo "<th>Delo</th>";
        }
        if (isset($polje[17])){ 
            echo "<th>Datum začetka dela</th>";
        }
        if (isset($polje[18])){ 
            echo "<th>Datum zaključka dela</th>";
        }
        if (isset($polje[19])){ 
            echo "<th>Status</th>";
        }
        if (isset($polje[20])){ 
            echo "<th>Naziv</th>";
        }
        if (isset($polje[21])){ 
            echo "<th>Prevoz</th>";
        }
        if (isset($polje[23])){ 
            echo "<th>Starejši</th>";
        }
        if (isset($polje[24])){ 
            echo "<th>Doječa mati</th>";
        }
        if (isset($polje[22])){ 
            echo "<th>Dostop</th>";
        }
        if (isset($polje[27])){ 
            echo "<th>Dopust<br>stari</th><th>Dopust</th><th>Dopust<br>skupaj</th>";
        }
        if (isset($polje[13])){ 
            echo "<th>Podpis</th>";
        }
        echo "</tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
        //'        echo "<tr><td></td></tr>"
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$Danes->format('Y'),$VLeto);
        
            $astr=explode(",",$oUcitelj->getIdDelo());
            $ustrezen=false;
            for ($i=0;$i < count($astr);$i++){
                switch ($astr[$i]){
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        $ustrezen=true;
                }
            }
            
            if ($ustrezen){
                if ($R["Spol"]=="M"){
                    echo "<tr bgcolor='lightyellow'>";
                }else{
                    echo "<tr bgcolor=#FFFFCC>";
                }
                echo "<td bgcolor='lightgrey' align='right'>" . $Indx ."</td>";
                if (isset($polje[2])){ 
                    echo "<td>" . $R["Priimek"] . "</td><td>" . $R["Ime"] . "</td>";
                }
                if (isset($polje[9])){ 
                    echo "<td>" . $R["Spol"]. "</td>";
                }
                if (isset($polje[3])){ 
                    $Datum=new DateTime($R["DatRoj"]);
                    echo "<td align='right'>" .$Datum->format('d.m.Y'). "</td>";
                }
                if (isset($polje[28])){ 
                    echo "<td>" . $R["KrajRoj"]. "</td>";
                }
                if (isset($polje[11])){ 
                    echo "<td>" . $R["EMSO"]. "</td>";
                }
                if (isset($polje[4])){ 
                    echo "<td>". $R["Naslov"] ."</td>";
                }
                if (isset($polje[5])){ 
                    echo "<td>". $R["Posta"] ."</td>";
                }
                if (isset($polje[6])){ 
                    echo "<td>". $R["Kraj"] ."</td>";
                }
                if (isset($polje[12])){ 
                    echo "<td align=center>". $R["Opis"]."</td><td>".$R["IzobOpis"] ."</td>";
                }

                $VLetoPregled=$Danes->format('Y');

                if (isset($polje[14])){ 
                    echo "<td>". $oUcitelj->getDelMesto() ."</td>";
                }
                if (isset($polje[17])){ 
                    echo "<td>". $Danes->format('d.m.Y') ."</td>";
                }
                if (isset($polje[18])){ 
                    echo "<td>/</td>";
                }
                if (isset($polje[19])){ 
                    echo "<td>". $oUcitelj->getStatusDelavca() ."</td>";
                }
                if (isset($polje[20])){ 
                    if (strlen($R["Svetnik"]) > 0){
                        echo "<td>Svetnik: ". $R["Svetnik"] ."</td>";
                    }else{
                        if (strlen($R["Svetovalec"]) > 0){
                            echo "<td>Svetovalec: ". $R["Svetovalec"] ."</td>";
                        }else{
                            if (strlen($R["mentor"]) > 0){
                                echo "<td>Mentor: ". $R["Mentor"] ."</td>";
                            }else{
                                if (strlen($R["StrokIzpit"]) > 0){
                                    echo "<td>Strokovni izpit: ". $R["StrokIzpit"] ."</td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                }
                            }
                        }
                    }
                }
                if (isset($polje[21])){ 
                    echo "<td>".$R["Prevoz"]."</td>";
                }
                
                if (isset($polje[23])){
                    if ($R["Starejsi"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                if (isset($polje[24])){
                    if ($R["DojecaMati"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                
                if (isset($polje[22])){ 
                    echo "<td>".$R["NivoDostopa"]."</td>";
                }
                if (isset($polje[27])){
                    echo "<td>".$oUcitelj->getDopustStari()."</td>";
                    echo "<td>".$oUcitelj->getDopust()."</td>";
                    echo "<td>".($oUcitelj->getDopustStari()+$oUcitelj->getDopust())."</td>";
                }
                if (isset($polje[13])){ 
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
                $oUcitelj=null;
            }
        }
        echo "</table>";
    }

	//'izpis tehničnega kadra
	if (isset($polje[8])){
        $SQL = "SELECT tabucitelji.*, TabStatus.*,TabIzobrazba.Opis ";
        if (isset($polje[27])){
            $SQL = $SQL . ",TabDopust.* ";
        }
        $SQL = $SQL . "FROM ((tabucitelji ";
        $SQL = $SQL . "INNER JOIN TabStatus ON tabucitelji.status=TabStatus.idStatus) ";
        $SQL = $SQL . "INNER JOIN TabIzobrazba ON tabucitelji.izobrazba=TabIzobrazba.idIzobrazba) ";
        if (isset($polje[27])){
            $SQL = $SQL . "INNER JOIN TabDopust ON tabucitelji.idUcitelj=TabDopust.idUcitelj ";
        }
        if (isset($polje[26])){
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6)) ";
        }else{
            $SQL = $SQL . "WHERE (tabucitelji.status IN (1,2,3,4,5,6,10))";
        }
        if (isset($polje[27])){
            $SQL = $SQL . " AND (leto = ".$Danes->format('Y').")";
        }
        if (isset($polje[12])){
            switch ($_POST["kriterij_izobr"]){
                case "1": //'>i
                    $SQL = $SQL . " AND (Izobrazba > ".$_POST["izobrazba"].")";
                    break;
                case "2": // '<
                    $SQL = $SQL . " AND (Izobrazba < ".$_POST["izobrazba"].")";
                    break;
                case "3": // '=
                    $SQL = $SQL . " AND (Izobrazba = ".$_POST["izobrazba"].")";
            }
        }
        if (isset($polje[20])){
            switch ($_POST["kriterij_naziv"]){
                case "0": // 'enak
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) " ;
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor <> '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                    break;
                case "1": // 'večji
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND (mentor <> '' OR svetovalec <> '' OR svetnik <> '') ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor <> '') OR (svetovalec <> '') OR (svetnik <> '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((svetovalec <> '') AND (svetnik <> '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetnik <> '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik <> '') ";
                    }
                case "2": // 'manjši
                    switch ($_POST["naziv"]){
                        case "0": // 'vsi
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "1": // 'brez
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "2": // 'mentor
                            $SQL = $SQL . " AND ((mentor = '') AND (svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "3": // 'svetovalec
                            $SQL = $SQL . " AND ((svetovalec = '') AND (svetnik = '')) ";
                            break;
                        case "4": // 'svetnik
                            $SQL = $SQL . " AND (svetnik = '') ";
                    }
            }
        }
        $SQL = $SQL . " ORDER BY priimek,ime";

        $result = mysqli_query($link,$SQL);

        echo "<h2>Seznam tehničnega kadra: " .$Danes->format('d.m.Y')."</h2>" ;

        echo "<table border='1' cellspacing='0' cellpadding='4'>";
        echo "<tr bgcolor='lightcyan'>";
        echo "<th>Št.</th>";
        if (isset($polje[2])){ 
            echo "<th>Priimek</th><th>ime</th>";
        }
        if (isset($polje[9])){ 
            echo "<th>Spol</th>";
        }
        if (isset($polje[3])){ 
            echo "<th>Datum rojstva</th>";
        }
        if (isset($polje[28])){ 
            echo "<th>Kraj rojstva</th>";
        }
        if (isset($polje[11])){ 
            echo "<th>EMŠO</th>";
        }
        if (isset($polje[4])){ 
            echo "<th>Naslov</th>";
        }
        if (isset($polje[5])){ 
            echo "<th>Pošta</th>";
        }
        if (isset($polje[6])){ 
            echo "<th>Kraj</th>";
        }
        if (isset($polje[12])){ 
            echo "<th>Stopnja izobr.</th><th>Izobrazba</th>";
        }
        if (isset($polje[14])){ 
            echo "<th>Delo</th>";
        }
        if (isset($polje[17])){ 
            echo "<th>Datum začetka dela</th>";
        }
        if (isset($polje[18])){ 
            echo "<th>Datum zaključka dela</th>";
        }
        if (isset($polje[19])){ 
            echo "<th>Status</th>";
        }
        if (isset($polje[20])){ 
            echo "<th>Naziv</th>";
        }
        if (isset($polje[21])){ 
            echo "<th>Prevoz</th>";
        }
        if (isset($polje[23])){ 
            echo "<th>Starejši</th>";
        }
        if (isset($polje[24])){ 
            echo "<th>Doječa mati</th>";
        }
        if (isset($polje[22])){ 
            echo "<th>Dostop</th>";
        }
        if (isset($polje[27])){ 
            echo "<th>Dopust<br>stari</th><th>Dopust</th><th>Dopust<br>skupaj</th>";
        }
        if (isset($polje[13])){ 
            echo "<th>Podpis</th>";
        }
        echo "</tr>";

        $Indx=1;
        while ($R = mysqli_fetch_array($result)){
        //'        echo "<tr><td></td></tr>"
            $oUcitelj=new RUcitelj();
            $oUcitelj->PreberiSeGlavno($R["IdUcitelj"],$Danes->format('Y'),$VLeto);
        
            $astr=explode(",",$oUcitelj->getIdDelo());
            $ustrezen=false;
            for ($i=0;$i < count($astr);$i++){
                switch ($astr[$i]){
                    case 16:
                    case 17:
                    case 18:
                        $ustrezen=true;
                }
            }
            
            if ($ustrezen){
                if ($R["Spol"]=="M"){
                    echo "<tr bgcolor='lightyellow'>";
                }else{
                    echo "<tr bgcolor=#FFFFCC>";
                }
                echo "<td bgcolor='lightgrey' align='right'>" . $Indx ."</td>";
                if (isset($polje[2])){ 
                    echo "<td>" . $R["Priimek"] . "</td><td>" . $R["Ime"] . "</td>";
                }
                if (isset($polje[9])){ 
                    echo "<td>" . $R["Spol"]. "</td>";
                }
                if (isset($polje[3])){ 
                    $Datum=new DateTime($R["DatRoj"]);
                    echo "<td align='right'>" .$Datum->format('d.m.Y'). "</td>";
                }
                if (isset($polje[28])){ 
                    echo "<td>" . $R["KrajRoj"]. "</td>";
                }
                if (isset($polje[11])){ 
                    echo "<td>" . $R["EMSO"]. "</td>";
                }
                if (isset($polje[4])){ 
                    echo "<td>". $R["Naslov"] ."</td>";
                }
                if (isset($polje[5])){ 
                    echo "<td>". $R["Posta"] ."</td>";
                }
                if (isset($polje[6])){ 
                    echo "<td>". $R["Kraj"] ."</td>";
                }
                if (isset($polje[12])){ 
                    echo "<td align=center>". $R["Opis"]."</td><td>".$R["IzobOpis"] ."</td>";
                }

                $VLetoPregled=$Danes->format('Y');

                if (isset($polje[14])){ 
                    echo "<td>". $oUcitelj->getDelMesto() ."</td>";
                }
                if (isset($polje[17])){ 
                    echo "<td>". $Danes->format('d.m.Y') ."</td>";
                }
                if (isset($polje[18])){ 
                    echo "<td>/</td>";
                }
                if (isset($polje[19])){ 
                    echo "<td>". $oUcitelj->getStatusDelavca() ."</td>";
                }
                if (isset($polje[20])){ 
                    if (strlen($R["Svetnik"]) > 0){
                        echo "<td>Svetnik: ". $R["Svetnik"] ."</td>";
                    }else{
                        if (strlen($R["Svetovalec"]) > 0){
                            echo "<td>Svetovalec: ". $R["Svetovalec"] ."</td>";
                        }else{
                            if (strlen($R["mentor"]) > 0){
                                echo "<td>Mentor: ". $R["Mentor"] ."</td>";
                            }else{
                                if (strlen($R["StrokIzpit"]) > 0){
                                    echo "<td>Strokovni izpit: ". $R["StrokIzpit"] ."</td>";
                                }else{
                                    echo "<td>&nbsp;</td>";
                                }
                            }
                        }
                    }
                }
                if (isset($polje[21])){ 
                    echo "<td>".$R["Prevoz"]."</td>";
                }
                
                if (isset($polje[23])){
                    if ($R["Starejsi"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                if (isset($polje[24])){
                    if ($R["DojecaMati"]){
                        echo "<td><input type='checkbox' checked></td>";
                    }else{
                        echo "<td><input type='checkbox'></td>";
                    }
                }
                
                if (isset($polje[22])){ 
                    echo "<td>".$R["NivoDostopa"]."</td>";
                }
                if (isset($polje[27])){
                    echo "<td>".$oUcitelj->getDopustStari()."</td>";
                    echo "<td>".$oUcitelj->getDopust()."</td>";
                    echo "<td>".($oUcitelj->getDopustStari()+$oUcitelj->getDopust())."</td>";
                }
                if (isset($polje[13])){ 
                    echo "<td>&nbsp;</td>";
                }
                echo "</tr>";
                $Indx=$Indx+1;
                $oUcitelj=null;
            }
        }
        echo "</table>";
    }
}

//'echo "<a href='izborrazredaizbor.php'>Izbor razreda</a><br>"
//'echo "<a href='prijava.php'>Glavni meni</a><br>"
?>

</body>
</html>
