<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Šolski predmeti in dejavnosti
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Predmeti",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
    case "2":
    case "4":
        break;
    default:
        $n=$VLevel;
        include('menu_func.inc');
        include ('menu.inc');
}
switch ($Vid) {
	case "1": // 'vnos predmetov in dejavnosti

		$SQL = "SELECT * FROM tabpredmeti ORDER BY prioriteta,opis,oznaka";
		$result = mysqli_query($link,$SQL);
		
		echo "<h2>Vnos predmetov in dejavnosti</h2>";
		echo "<form name='Predmeti' method='post' action='VnosPredmetov.php'>";
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Predmet</th><th>Oznaka</th><th>Tip</th><th>Vrstni red<br>izpisa</th><th>Koda MIZŠ</th><th>Šifra MIZŠ</th><th>Opis MIZŠ</th></tr>";
		
		echo "<tr>";
		echo "<td>&nbsp;</td>";
		echo "<td><input name='opis' type='text' size='50'></td>";
		echo "<td><input name='oznaka' type='text' size='5'></td>";
		echo "<td><select name='prioriteta'>";
		echo "<option value='0'>redni predmet</option>";
		echo "<option value='1'>izbirni predmet</option>";
		echo "<option value='3'>drugo</option>";
		echo "<option value='4'>delo</option>";
		echo "</select></td>";
		echo "<td><input name='VrstniRed' type='text' size='4'></td>";
        echo "<td><input name='kodamss' type='text' size='4'></td>";
        echo "<td><input name='siframss' type='text' size='4'></td>";
        echo "<td><input name='opismss' type='text' size='40'></td>";
		echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
		echo "</tr>";

		$indx=1;
        while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td>".$R["Opis"]."</td>";
			echo "<td>".$R["Oznaka"]."</td>";
			switch ($R["Prioriteta"]){
				case 0:
					echo "<td>redni predmet</td>";
                    break;
				case 1:
					echo "<td>izbirni predmet</td>";
                    break;
				case 2:
					echo "<td>redni predmet - osemletka</td>";
                    break;
				case 3:
					echo "<td>drugo</td>";
                    break;
				case 4:
					echo "<td>delo</td>";
			}
			echo "<td>".$R["VrstniRed"]."</td>";
            echo "<td>".$R["KodaMSS"]."</td>";
            echo "<td>".$R["SifraMSS"]."</td>";
            echo "<td>".$R["OpisMSS"]."</td>";
			echo "<td><a href='VnosPredmetov.php?id=3&zapis=".$R["Id"]."'>Popravi</a></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='id' type='hidden' value='2'>";
		echo "</form>";
        break;
	case "2": // 'vpis zapisa
		$VrstniRed=$_POST["VrstniRed"];
		if (!is_numeric($VrstniRed)){
			$VrstniRed=100;
		}
		
		$SQL = "SELECT * FROM tabpredmeti WHERE Opis='".$_POST["opis"]."' AND oznaka='".$_POST["oznaka"]."'";
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			echo "Ta predmet že obstaja!<br />";
            echo "<br /><a href='VnosPredmetov.php?id=1'>Na vnos predmetov</a><br />";
		}else{
			$SQL = "INSERT INTO tabpredmeti (oznaka,opis,prioriteta,VrstniRed,KodaMSS,SifraMSS,OpisMSS) VALUES ";
            $SQL .= "('".$_POST["oznaka"]."','".$_POST["opis"]."',".$_POST["prioriteta"].",".$VrstniRed.",'".$_POST["kodamss"]."','".$_POST["siframss"]."','".$_POST["opismss"]."')";
            if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu! <br />$SQL <br />");
            }
            header ("Location: VnosPredmetov.php?id=1");
		}
        break;
	case "3":   //popravljanje predmeta
		$SQL = "SELECT * FROM tabpredmeti WHERE id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			echo "<h2>Vnos predmetov in dejavnosti</h2>";
			echo "<form name='Predmeti' method='post' action='VnosPredmetov.php'>";
			echo "<table border='1'>";
			echo "<tr><th>Št.</th><th>Predmet</th><th>Oznaka</th><th>Tip</th><th>Vrstni red<br>izpisa</th><th>Koda MIZŠ</th><th>Šifra MIZŠ</th><th>Opis MIZŠ</th></tr>";
			
			echo "<tr>";
			echo "<td>&nbsp;</td>";
			echo "<td><input name='opis' type='text' size='50' value='".$R["Opis"]."'></td>";
			echo "<td><input name='oznaka' type='text' size='5' value='".$R["Oznaka"]."'></td>";
			echo "<td><select name='prioriteta'>";
			if ($R["Prioriteta"]==0){
				echo "<option value='0' selected>redni predmet</option>";
			}else{
				echo "<option value='0'>redni predmet</option>";
			}
			if ($R["Prioriteta"]==1){
				echo "<option value='1' selected>izbirni predmet</option>";
			}else{
				echo "<option value='1'>izbirni predmet</option>";
			}
			if ($R["Prioriteta"]==2){
				echo "<option value='2' selected>redni predmet - osemletka</option>";
			}else{
				echo "<option value='2'>redni predmet - osemletka</option>";
			}
			if ($R["Prioriteta"]==3){
				echo "<option value='3' selected>drugo</option>";
			}else{
				echo "<option value='3'>drugo</option>";
			}
			if ($R["Prioriteta"]==4){
				echo "<option value='4' selected>delo</option>";
			}else{
				echo "<option value='4'>delo</option>";
			}
			echo "</select></td>";
			echo "<td><input name='VrstniRed' type='text' size='4' value='".$R["VrstniRed"]."'></td>";
            echo "<td><input name='kodamss' type='text' size='4' value='".$R["KodaMSS"]."'></td>";
            echo "<td><input name='siframss' type='text' size='4' value='".$R["SifraMSS"]."'></td>";
            echo "<td><input name='opismss' type='text' size='40' value='".$R["OpisMSS"]."'></td>";
			echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
			echo "</tr>";
			echo "</table>";
			echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
			echo "<input name='id' type='hidden' value='4'>";
			echo "</form>";
		}
		break;
	case "4":  //vpis popravka
		$VrstniRed=$_POST["VrstniRed"];
		if (!is_numeric($VrstniRed)){
			$VrstniRed=100;
		}
		
		$SQL = "SELECT * FROM tabpredmeti WHERE id=".$_POST["zapis"];
		$result = mysqli_query($link,$SQL);
		
        if ($R = mysqli_fetch_array($result)){
			$SQL = "UPDATE tabpredmeti SET opis='".$_POST["opis"]."',oznaka='".$_POST["oznaka"]."',prioriteta=".$_POST["prioriteta"];
            $SQL .= ",VrstniRed=".$VrstniRed.",KodaMSS='".$_POST["kodamss"]."',SifraMSS='".$_POST["siframss"]."',OpisMSS='".$_POST["opismss"]."' WHERE id=".$R["Id"];
			if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri vpisu! <br />$SQL <br />");
            }
		}
		
		header ("Location: VnosPredmetov.php?id=1");
}

?>

</body>
</html>
