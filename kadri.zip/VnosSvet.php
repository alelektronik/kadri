<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    if (isset($_POST["Uporabnik"])){
        $VUporabnik = $_POST["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    if (isset($_POST["Geslo"])){
        $VGeslo = $_POST["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    if (isset($_POST["Level"])){
        $VLevel = $_POST["Level"];
    }else{
        $VLevel="";
    }
}

if (isset($_SESSION["posx"])) {
    $KorX=$_SESSION["posx"];
}else{
    $KorX=0;
}
if (isset($_SESSION["posy"])){
    $KorY=$_SESSION["posy"];
}else{
    $KorY=0;
}
if (isset($_SESSION["DayToPrint"])){
    $PrintDay=$_SESSION["DayToPrint"];
}else{
    $PrintDay=$Danes->format('j.n.Y');
}
if (isset($_SESSION["RefStFix"])){
    $RefStFix = $_SESSION["RefStFix"];
}else{
    $RefStFix = "";
}
if (isset($_SESSION["RefStVar"])){
    $RefStVar = $_SESSION["RefStVar"];
}else{
    $RefStVar = "";
}
if (isset($_SESSION["KorOpombe"])){
    $KorOpombe = $_SESSION["KorOpombe"];
}else{
    $KorOpombe = "";
}

$RazsirjenVnos=true;

if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $IdUcitelj=$R["IdUcitelj"];
    $VUporabnikId=$R["IdUcitelj"];
    $ImeUcitelja=$R["Priimek"]." ".$R["Ime"];
    //echo "<a href='prijava.php'>Nazaj na glavni meni</a><br />";
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

	echo "<html>";
	echo "<head>";
	echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
	switch ($Vid){
		case "5":
		case "6":
			echo "<link rel='stylesheet' type='text/css' href='osmj2.css'> ";
			break;
		default:
			echo "<link rel='stylesheet' type='text/css' href='osmj.css'> ";
	}
	echo "<title>Svet staršev in svet šole";
	echo "</title>";
	echo "</head>";
	echo "<body>";

	switch ($Vid){
		case "2":
		case "3":
		case "4":
		case "7":
			break;
		default:
			$n=$VLevel;
			include('menu_func.inc');
			include ('menu.inc');
	}

	switch ($Vid){
		case "1": //popravi zapis
			$SQL = "SELECT * FROM TabSvet WHERE id=".$_GET["zapis"];
			$result = mysqli_query($link,$SQL);
			
			if ($R = mysqli_fetch_array($result)){
				echo "<table border=1 cellspacing=0>";
				echo "<tr><th>Ime</th><th>Priimek</th><th>Naslov</th><th>Pošta</th><th>Opomba</th><th>Funkcija</th><th>Telefon</th><th>e-mail</th><th>Začetek mandata</th><th>Svet staršev</th><th>Svet šole</th><th>Popravi</th><th>Briši</th></tr>";
				echo "<form accept-charset='utf-8' name='svet' method='post' action='VnosSvet.php'>";
				echo "<tr>";
				echo "<td><input name='ime' type='text' size='20' value='".$R["Ime"]."'></td>";
				echo "<td><input name='priimek' type='text' size='20' value='".$R["Priimek"]."'></td>";
				echo "<td><input name='naslov' type='text' size='20' value='".$R["Naslov"]."'></td>";
				echo "<td><input name='posta' type='text' size='20' value='".$R["Posta"]."'></td>";
				echo "<td><input name='opomba' type='text' size='20' value='".$R["Opomba"]."'></td>";
				switch ($R["Funkcija"]){
					case 0:
						echo "<td><select name='funkcija'>";
						echo "<option value='0' selected> </option>";
						echo "<option value='1'>MOL</option>";
						echo "<option value='2'>Starši</option>";
						echo "<option value='3'>Zaposleni</option>";
						echo "<option value='4'>MŠŠ</option>";
						break;
					case 1:
						echo "<td><select name='funkcija'>";
						echo "<option value='0'> </option>";
						echo "<option value='1' selected>MOL</option>";
						echo "<option value='2'>Starši</option>";
						echo "<option value='3'>Zaposleni</option>";
						echo "<option value='4'>MŠŠ</option>";
						break;
					case 2:
						echo "<td><select name='funkcija'>";
						echo "<option value='0'> </option>";
						echo "<option value='1'>MOL</option>";
						echo "<option value='2' selected>Starši</option>";
						echo "<option value='3'>Zaposleni</option>";
						echo "<option value='4'>MŠŠ</option>";
						break;
					case 3:
						echo "<td><select name='funkcija'>";
						echo "<option value='0'> </option>";
						echo "<option value='1'>MOL</option>";
						echo "<option value='2'>Starši</option>";
						echo "<option value='3' selected>Zaposleni</option>";
						echo "<option value='4'>MŠŠ</option>";
						break;
					case 4:
						echo "<td><select name='funkcija'>";
						echo "<option value='0'> </option>";
						echo "<option value='1'>MOL</option>";
						echo "<option value='2'>Starši</option>";
						echo "<option value='3'>Zaposleni</option>";
						echo "<option value='4' selected>MŠŠ</option>";
						break;
				}
				echo "</select></td>";
				echo "<td><input name='telefon' type='text' size='20' value='".$R["Telefon"]."'></td>";
				echo "<td><input name='email' type='text' size='20' value='".$R["Email"]."'></td>";
				echo "<td><input name='ZacMandata' type='text' size='8' value='".$R["ZacMandata"]."'></td>";
				if ($R["SvetStarsev"] ){
					echo "<td><input name='SvetStarsev' type='checkbox' checked></td>";
				}else{
					echo "<td><input name='SvetStarsev' type='checkbox'></td>";
				}
				if ($R["SvetSole"] ){
					echo "<td><input name='SvetSole' type='checkbox' checked></td>";
				}else{
					echo "<td><input name='SvetSole' type='checkbox'></td>";
				}
				echo "<td>&nbsp;</td>";
				echo "<td><input type='hidden' name='id' value='3'><input type='hidden' name='zapis' value='".$R["id"]."'><input name='submit' type='submit' value='Pošlji'></td>";
				echo "</tr>";
				echo "</table>";
				echo "</form>";
			}
			break;
		case "2":   //vpis novih članov
			$SQL = "INSERT INTO TabSvet (ime,priimek,naslov,posta,opomba,funkcija,telefon,email,ZacMandata,SvetStarsev,SvetSole) VALUES ";
			$SQL = $SQL . "(";
			$SQL = $SQL . "'".$_POST["ime"]."',";
			$SQL = $SQL . "'".$_POST["priimek"]."',";
			$SQL = $SQL . "'".$_POST["naslov"]."',";
			$SQL = $SQL . "'".$_POST["posta"]."',";
			$SQL = $SQL . "'".$_POST["opomba"]."',";
			$SQL = $SQL . $_POST["funkcija"].",";
			$SQL = $SQL . "'".$_POST["telefon"]."',";
			$SQL = $SQL . "'".$_POST["email"]."',";
			$SQL = $SQL . "'".$_POST["ZacMandata"]."',";
			if (isset($_POST["SvetStarsev"])){
				$SQL = $SQL . "true,";
			}else{
				$SQL = $SQL . "false,";
			}
			if (isset($_POST["SvetSole"])){
				$SQL = $SQL . "true";
			}else{
				$SQL = $SQL . "false";
			}
			$SQL = $SQL . ")";
			$result = mysqli_query($link,$SQL);
			
			header("Location: VnosSvet.php");
			break;
		case "3": //vpis popravkov
			$SQL = "UPDATE TabSvet SET ";
			$SQL = $SQL . "ime='".$_POST["ime"]."',";
			$SQL = $SQL . "priimek='".$_POST["priimek"]."',";
			$SQL = $SQL . "naslov='".$_POST["naslov"]."',";
			$SQL = $SQL . "posta='".$_POST["posta"]."',";
			$SQL = $SQL . "opomba='".$_POST["opomba"]."',";
			$SQL = $SQL . "funkcija=".$_POST["funkcija"].",";
			$SQL = $SQL . "telefon='".$_POST["telefon"]."',";
			$SQL = $SQL . "email='".$_POST["email"]."',";
			$SQL = $SQL . "Zacmandata='".$_POST["ZacMandata"]."',";
			if (isset($_POST["SvetStarsev"])){
				$SQL = $SQL . "SvetStarsev=true,";
			}else{
				$SQL = $SQL . "SvetStarsev=false,";
			}
			if (isset($_POST["SvetSole"])){
				$SQL = $SQL . "SvetSole=true";
			}else{
				$SQL = $SQL . "SvetSole=false";
			}
			$SQL = $SQL . " WHERE id=".$_POST["zapis"];
			$result = mysqli_query($link,$SQL);
			
			header("Location: VnosSvet.php");
			break;
		case "4": //brisanje zapisa
			$SQL = "DELETE FROM TabSvet WHERE id=".$_GET["zapis"];
			$result = mysqli_query($link,$SQL);
			
			header("Location: VnosSvet.php");
			break;
		case "5":  //  'izpis sveta staršev
			echo "<h2>Svet staršev</h2>";
			$SQL = "SELECT * FROM TabSvet WHERE SvetStarsev=true ORDER BY funkcija,ime";
			$result = mysqli_query($link,$SQL);
			echo "<table border=1 cellspacing=0>";
			echo "<tr><th>Ime</th><th>Priimek</th><th>Naslov</th><th>Pošta</th><th>Opomba</th><th>Funkcija</th><th>Telefon</th><th>e-mail</th><th>Začetek<br>mandata</th></tr>";
			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				echo "<td>".$R["Ime"]."</td>";
				echo "<td>".$R["Priimek"]."</td>";
				echo "<td>".$R["Naslov"]."</td>";
				echo "<td>".$R["Posta"]."</td>";
				echo "<td>".$R["Opomba"]."</td>";
				switch ($R["Funkcija"]){
					case 0:
						echo "<td>&nbsp;</td>";
						break;
					case 1:
						echo "<td>MOL</td>";
						break;
					case 2:
						echo "<td>Starši</td>";
						break;
					case 3:
						echo "<td>Zaposleni</td>";
						break;
					case 4:
						echo "<td>MŠŠ</td>";
				}
				echo "<td>".$R["Telefon"]."</td>";
				echo "<td><a href='mailto:".$R["Email"]."'>".$R["Email"]."</a></td>";
				echo "<td>".$R["ZacMandata"]."</td>";
				echo "</tr>";
			}
			echo "</table><br />";
			break;
		case "6":   // 'izpis sveta šole
			echo "<h2>Svet šole</h2>";
			$SQL = "SELECT * FROM TabSvet WHERE SvetSole=true ORDER BY funkcija,ime";
			$result = mysqli_query($link,$SQL);
			echo "<table border=1 cellspacing=0>";
			echo "<tr><th>Ime</th><th>Priimek</th><th>Naslov</th><th>Pošta</th><th>Opomba</th><th>Funkcija</th><th>Telefon</th><th>e-mail</th><th>Začetek<br />mandata</th></tr>";
			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				echo "<td>".$R["Ime"]."</td>";
				echo "<td>".$R["Priimek"]."</td>";
				echo "<td>".$R["Naslov"]."</td>";
				echo "<td>".$R["Posta"]."</td>";
				echo "<td>".$R["Opomba"]."</td>";
				switch ($R["Funkcija"]){
					case 0:
						echo "<td>&nbsp;</td>";
						break;
					case 1:
						echo "<td>MOL</td>";
						break;
					case 2:
						echo "<td>Starši</td>";
						break;
					case 3:
						echo "<td>Zaposleni</td>";
						break;
					case 4:
						echo "<td>MŠŠ</td>";
				}
				echo "<td>".$R["Telefon"]."</td>";
				echo "<td><a href='mailto:".$R["Email"]."'>".$R["Email"]."</a></td>";
				echo "<td>".$R["ZacMandata"]."</td>";
				echo "</tr>";
			}
			echo "</table><br />";
			break;
		case "7": // 'uvoz predstavnikov staršev v svet šole
			//'najprej pobriše stare predstavnike sveta staršev
			$SQL = "DELETE FROM TabSvet WHERE SvetStarsev=true AND SvetSole=false";
			$result = mysqli_query($link,$SQL);
			
			$SQL = "SELECT tabsvetstarsev.svet,";
			$SQL = $SQL . "tabucenci.oce,tabucenci.ocenaslov,tabucenci.ocekontakt,tabucenci.ocegsm,tabucenci.ocesluzba,tabucenci.oceemail,";
			$SQL = $SQL . "tabucenci.mati,tabucenci.matinaslov,tabucenci.matikontakt,tabucenci.matigsm,tabucenci.matisluzba,tabucenci.matiemail,";
			$SQL = $SQL . "tabucenci.skrbniki,tabucenci.skrbnikinaslov,tabucenci.skrbnikikontakt,tabucenci.skrbnikiemail,";
			$SQL = $SQL . "tabrazred.razred,tabrazred.paralelka FROM (TabSvetStarsev ";
			$SQL = $SQL . "INNER JOIN TabUcenci ON TabSvetStarsev.idUcenec=TabUcenci.idUcenec) ";
			$SQL = $SQL . "INNER JOIN TabRazred ON TabSvetStarsev.idUcenec=TabRazred.idUcenec ";
			$SQL = $SQL . "WHERE TabSvetStarsev.leto=".$VLeto." AND TabRazred.leto=".$VLeto." AND TabSvetStarsev.status=1";
			$result = mysqli_query($link,$SQL);
			while ($R = mysqli_fetch_array($result)){
				switch ($R["svet"]){
					case 1: // 'oče
						$SQL = "INSERT INTO TabSvet (ime,naslov,Opomba,funkcija,telefon,email,ZacMandata,KonMandata,SvetStarsev,SvetSole) VALUES (";
						$SQL = $SQL . "'".$R["oce"]."',"; //'ime
						$SQL = $SQL . "'".$R["ocenaslov"]."',"; // 'priimek
						$SQL = $SQL . "'".$R["razred"].". ".$R["paralelka"]."',"; // 'opomba
						$SQL = $SQL . "2,"; // 'funkcija
						$SQL = $SQL . "'".$R["ocekontakt"].",".$R["ocegsm"].",".$R["ocesluzba"]."',"; // 'kontakt
						$SQL = $SQL . "'".$R["oceemail"]."',"; // 'email
						$SQL = $SQL . "'1.9.".$VLeto."',"; // 'ZacMandata
						$SQL = $SQL . "'31.8.".($VLeto+1)."',"; // 'KonMandata
						$SQL = $SQL ."true,false)";
						$result1 = mysqli_query($link,$SQL);
						break;
					case 2: // 'mati
						$SQL = "INSERT INTO TabSvet (ime,naslov,Opomba,funkcija,telefon,email,ZacMandata,KonMandata,SvetStarsev,SvetSole) VALUES (";
						$SQL = $SQL . "'".$R["mati"]."',"; // 'ime
						$SQL = $SQL . "'".$R["matinaslov"]."',"; // 'priimek
						$SQL = $SQL . "'".$R["razred"].". ".$R["paralelka"]."',"; // 'opomba
						$SQL = $SQL . "2,"; // 'funkcija
						$SQL = $SQL . "'".$R["matikontakt"].",".$R["matigsm"].",".$R["matisluzba"]."',"; // 'kontakt
						$SQL = $SQL . "'".$R["matiemail"]."',"; // 'email
						$SQL = $SQL . "'1.9.".$VLeto."',"; // 'ZacMandata
						$SQL = $SQL . "'31.8.".($VLeto+1)."',"; // 'KonMandata
						$SQL = $SQL ."true,false)";
						$result1 = mysqli_query($link,$SQL);
						break;
					case 3: // 'skrbnik
						$SQL = "INSERT INTO TabSvet (ime,naslov,Opomba,funkcija,telefon,email,ZacMandata,KonMandata,SvetStarsev,SvetSole) VALUES (";
						$SQL = $SQL . "'".$R["skrbniki"]."',"; // 'ime
						$SQL = $SQL . "'".$R["skrbnikinaslov"]."',"; // 'priimek
						$SQL = $SQL . "'".$R["razred"].". ".$R["paralelka"]."',"; // 'opomba
						$SQL = $SQL . "2,"; // 'funkcija
						$SQL = $SQL . "'".$R["skrbnikikontakt"]."',"; // 'kontakt
						$SQL = $SQL . "'".$R["skrbnikiemail"]."',"; // 'email
						$SQL = $SQL . "'1.9.".$VLeto."',"; // 'ZacMandata
						$SQL = $SQL . "'31.8.".($VLeto+1)."',"; // 'KonMandata
						$SQL = $SQL ."true,false)";
						$result1 = mysqli_query($link,$SQL);
				}
			}
			header("Location: VnosSvet.php");
		default:
			echo "<h2>Svet staršev in svet šole</h2>";
			$SQL = "SELECT * FROM TabSvet ORDER BY opomba,funkcija,ime";
			$result = mysqli_query($link,$SQL);

			echo "<table border=1 cellspacing=0>";
			echo "<tr><th>Ime</th><th>Priimek</th><th>Naslov</th><th>Pošta</th><th>Opomba</th><th>Funkcija</th><th>Telefon</th><th>e-mail</th><th>Začetek<br />mandata</th><th>Svet<br />staršev</th><th>Svet<br />šole</th><th>Popravi</th><th>Briši</th></tr>";

			while ($R = mysqli_fetch_array($result)){
				echo "<tr>";
				echo "<td>".$R["Ime"]."</td>";
				echo "<td>".$R["Priimek"]."</td>";
				echo "<td>".$R["Naslov"]."</td>";
				echo "<td>".$R["Posta"]."</td>";
				echo "<td>".$R["Opomba"]."</td>";
				switch ($R["Funkcija"]){
					case 0:
						echo "<td>&nbsp;</td>";
						break;
					case 1:
						echo "<td>MOL</td>";
						break;
					case 2:
						echo "<td>Starši</td>";
						break;
					case 3:
						echo "<td>Zaposleni</td>";
						break;
					case 4:
						echo "<td>MŠŠ</td>";
				}
				echo "<td>".$R["Telefon"]."</td>";
				echo "<td>".$R["Email"]."</td>";
				echo "<td>".$R["ZacMandata"]."</td>";
				if ($R["SvetStarsev"] ){
					echo "<td><input type='checkbox' checked></td>";
				}else{
					echo "<td><input type='checkbox'></td>";
				}
				if ($R["SvetSole"] ){
					echo "<td><input type='checkbox' checked></td>";
				}else{
					echo "<td><input type='checkbox'></td>";
				}
				echo "<td><a href='VnosSvet.php?id=1&zapis=".$R["id"]."'>Popravi</td>";
				echo "<td><a href='VnosSvet.php?id=4&zapis=".$R["id"]."'>Briši</td>";
				echo "</tr>";
			}
			echo "<form accept-charset='utf-8' name='svet' method='post' action='VnosSvet.php'>";
			echo "<tr>";
			echo "<td><input name='ime' type='text' size='20'></td>";
			echo "<td><input name='priimek' type='text' size='20'></td>";
			echo "<td><input name='naslov' type='text' size='20'></td>";
			echo "<td><input name='posta' type='text' size='15'></td>";
			echo "<td><input name='opomba' type='text' size='10'></td>";
			echo "<td><select name='funkcija'>";
			echo "<option value='0' selected> </option>";
			echo "<option value='1'>MOL</option>";
			echo "<option value='2'>Starši</option>";
			echo "<option value='3'>Zaposleni</option>";
			echo "<option value='4'>MŠŠ</option>";
			echo "</select></td>";
			echo "<td><input name='telefon' type='text' size='10'></td>";
			echo "<td><input name='email' type='text' size='20'></td>";
			echo "<td><input name='ZacMandata' type='text' size='8'></td>";
			echo "<td><input name='SvetStarsev' type='checkbox'></td>";
			echo "<td><input name='SvetSole' type='checkbox'></td>";
			echo "<td>&nbsp;</td>";
			echo "<td><input type='hidden' name='id' value='2'><input name='submit' type='submit' value='Pošlji'></td>";
			echo "</tr>";
			echo "</table>";
			echo "</form>";
	}

	echo "<a href='VnosSvet.php?id=7'>Uvoz predstavnikov v svet staršev</a><br />";
	echo "<a href='VnosSvet.php?id=5'>Izpis sveta staršev</a><br />";
	echo "<a href='VnosSvet.php?id=6'>Izpis sveta šole</a><br />";
	echo "<a href='VnosSvet.php'>Izpis vseh in vnos</a><br />";
}
?>

</body>
</html>
