<?php
session_start();
setlocale (LC_ALL, 'sl_SI.UTF-8');

//true - vklop in false - izklop sporočil o napakah
$DEBUGGING = True;
$TRACECOUNT = 0;
 
if($DEBUGGING){
    error_reporting(E_ALL);
    ini_set('display_errors', True);
}else{
    //ini_set('display_errors', false);
    
    // Turn off all error reporting
    error_reporting(0);

    // Report simple running errors
    //error_reporting(E_ERROR | E_WARNING | E_PARSE);

    // Reporting E_NOTICE can be good too (to report uninitialized
    // variables or catch variable name misspellings ...)
    //error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

    // Report all errors except E_NOTICE
    // This is the default value set in php.ini
    //error_reporting(E_ALL ^ E_NOTICE);

    // Report all PHP errors (see changelog)
    //error_reporting(E_ALL);

    // Report all PHP errors
    //error_reporting(-1);

    // Same as error_reporting(E_ALL);
    //ini_set('error_reporting', E_ALL);
} 
function trace($message){
 
    global $DEBUGGING;
    global $TRACECOUNT;
    if($DEBUGGING)
    {
        echo '<hr />;'.$TRACECOUNT++.'<code>'.$message.'</code><hr />';
    }
}
 
function tarr($arr)
{
    global $DEBUGGING; 
    global $TRACECOUNT; 
    if($DEBUGGING) 
    { 
        echo '<hr />'.$TRACECOUNT++.'<code>'; 
        print_r($arr); 
        echo '</code><hr />'; 
    } 
} 
//----------sporočila o napakah

$filename = "nastavitve.php";
if (file_exists($filename)) {
    //osnovne nastavitve obstajajo, vrne se na prijavo
    header("Location: index.php");
} else {
    //gre v nastavljanje osnovnih nastavitev
    echo "<html>";
    echo "<head>";
    echo "<title>Kadri in učenci</title>";
    echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
    //echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"osmp3.css\">"; 
    echo "<meta name=\"robots\" content=\"noindex,nofollow\">";
    echo "</head>";
    echo "<body bgcolor=\"#FFFFFF\" text=\"#000000\">";

    if (isset($_POST["id"])){
        //vpiše nastavitve
        if ($_POST["id"] == "1"){
            $myFile = "nastavitve.php";
            $fh = fopen($myFile,'w') or die("Ne morem odpreti datoteke!");
            
            fwrite ($fh,"<?php\n\n");
            $stringData= "//podatki za dostop do baze podatkov"."\n";
            fwrite ($fh,$stringData);

            if (isset($_POST["dbk_host"])){
                $stringData= "\$dbk_host=\"".$_POST["dbk_host"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$dbk_host=\"127.0.0.1\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["dbk_user"])){
                $stringData= "\$dbk_user=\"".$_POST["dbk_user"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$dbk_user=\"kuser\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["dbk_pass"])){
                $stringData= "\$dbk_pass=\"".$_POST["dbk_pass"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$dbk_pass=\"kSQLgeslo\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["dbk_base"])){
                $stringData= "\$dbk_base=\"".$_POST["dbk_base"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$dbk_base=\"sola\"".";\n";
                fwrite ($fh,$stringData);
            }

            $stringData= "//1 - izklop modula učencev, 0 - aplikacija z obdelavo učencev (default=0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["SamoKadri"])){
                $stringData= "\$SamoKadri=".$_POST["SamoKadri"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$SamoKadri=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//1 - vklop modula eDnevnik, 0 - izklop (default=1)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["eDnevnik"])){
                $stringData= "\$eDnevnik=".$_POST["eDnevnik"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$eDnevnik=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//0 - izključen modul za rezervacijo prostorov, 1 - vključen"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["RezervacijaProstorov"])){
                $stringData= "\$RezervacijaProstorov=".$_POST["RezervacijaProstorov"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$RezervacijaProstorov=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//1 - vklop modula za evidentiranje prisotnosti, 0 - izklop (default=1)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["EvidencaPrisotnosti"])){
                $stringData= "\$EvidencaPrisotnosti=".$_POST["EvidencaPrisotnosti"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$EvidencaPrisotnosti=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//1-vklop modula za pošiljanje delovnih opravil delovcem, 0-izklop modula  (default=1)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["Opravila"])){
                $stringData= "\$Opravila=".$_POST["Opravila"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$Opravila=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//1 - vklop modula za evidenco prehrano, 0 - izklop (default=0) - ni modula v PHP, le v ASP"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["EvidencaPrehrane"])){
                $stringData= "\$EvidencaPrehrane=".$_POST["EvidencaPrehrane"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$EvidencaPrehrane=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//Zaščitna sredstva: 0 - običajen prikaz, 1 - za OŠ Bežigrad"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["ZascSre"])){
                $stringData= "\$ZascSre=".$_POST["ZascSre"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$ZascSre=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//Prikaz neizpolnjenih podatkov: 0 - ni prikaza, 1 - je prikaz"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["Semafor"])){
                $stringData= "\$Semafor=".$_POST["Semafor"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$Semafor=1".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["SemaforPrehrana"])){
                $stringData= "\$SemaforPrehrana=".$_POST["SemaforPrehrana"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$SemaforPrehrana=1".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["SemaforRealizacija"])){
                $stringData= "\$SemaforRealizacija=".$_POST["SemaforRealizacija"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$SemaforRealizacija=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//število ur za obračun - po letih 2000+pozicija v polju"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["DelovniDan"])){
                if ($_POST["DelovniDan"] == "1"){
                    $stringData= "\$DelovniDan=array(8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8)".";\n";
                }else{
                    $stringData= "\$DelovniDan=array(7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5, 7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5, 7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5,7.5)".";\n";
                }
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$DelovniDan=array(8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,8,8)".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//Če je baza z več šolami (podružnicami) -> 1, baza z eno šolo -> 0"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["VecSol"])){
                $stringData= "\$VecSol=".$_POST["VecSol"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$VecSol=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//Število neobveznih izbirnih predmetov, ki jih učenci lahko izbirajo"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["StNeobveznihIzbirnih"])){
                $stringData= "\$StNeobveznihIzbirnih=".$_POST["StNeobveznihIzbirnih"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$StNeobveznihIzbirnih=1".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//število dni tolerance za vpis doprinosov delavcev (default=0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["RazlikaDniVpis"])){
                $stringData= "\$RazlikaDniVpis=".$_POST["RazlikaDniVpis"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$RazlikaDniVpis=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//'0-izpiše DU v spisku rubrik, 1-ne izpiše (default=0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["izpisDU"])){
                $stringData= "\$izpisDU=".$_POST["izpisDU"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$izpisDU=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//Upoštevanje Du: 0 - ne poračunava, 1 - poračunava  (default = 0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["ObracunajDu"])){
                $stringData= "\$ObracunajDu=".$_POST["ObracunajDu"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$ObracunajDu=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//'0-izpiše Jesenski in pomladni del, 1-ne izpiše jesenski in pomladni del (default=0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["IzpisSezon"])){
                $stringData= "\$IzpisSezon=".$_POST["IzpisSezon"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$IzpisSezon=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//0-izpiše podatke o porodniških le ob prvem vstopu, 1-stalno izpisuje podatke o porodniških (default=0)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["IzpisPorodniske"])){
                $stringData= "\$IzpisPorodniske=".$_POST["IzpisPorodniske"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$IzpisPorodniske=0".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email policije za sprejemanje obvestil s šole (default=\"\")"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["EmailPolicija"])){
                $stringData= "\$EmailPolicija=\"".$_POST["EmailPolicija"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$EmailPolicija=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (strlen($_POST["EmailPolicija"]) > 0){
                $stringData= "\$ObvestiloPolicije=true;\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$ObvestiloPolicije=false;\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email, ki se kaže kot pošiljatelj, pri splošnih sporočilih delavcem (default=\"\")"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["EmailRavnatelj"])){
                $stringData= "\$EmailRavnatelj=\"".$_POST["EmailRavnatelj"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$EmailRavnatelj=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//število ur za izračun polne obveze učitelja (default=22)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["ObremenitevUcitelj"])){
                $stringData= "\$ObremenitevUcitelj=".$_POST["ObremenitevUcitelj"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$ObremenitevUcitelj=22".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//število ur za izračun polne obveze PB učitelja (default=25)"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["ObremenitevPB"])){
                $stringData= "\$ObremenitevPB=".$_POST["ObremenitevPB"].";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$ObremenitevPB=25".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email 1"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["mail_host1"])){
                $stringData= "\$mail_host1=\"".$_POST["mail_host1"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_host1=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_user1"])){
                $stringData= "\$mail_user1=\"".$_POST["mail_user1"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_user1=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_pass1"])){
                $stringData= "\$mail_pass1=\"".$_POST["mail_pass1"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_pass1=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email 2"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["mail_host2"])){
                $stringData= "\$mail_host2=\"".$_POST["mail_host2"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_host2=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_user2"])){
                $stringData= "\$mail_user2=\"".$_POST["mail_user2"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_user2=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_pass2"])){
                $stringData= "\$mail_pass2=\"".$_POST["mail_pass2"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_pass2=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email 3"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["mail_host3"])){
                $stringData= "\$mail_host3=\"".$_POST["mail_host3"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_host3=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_user3"])){
                $stringData= "\$mail_user3=\"".$_POST["mail_user3"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_user3=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_pass3"])){
                $stringData= "\$mail_pass3=\"".$_POST["mail_pass3"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_pass3=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            
            $stringData= "//email 4"."\n";
            fwrite ($fh,$stringData);
            if (isset($_POST["mail_host4"])){
                $stringData= "\$mail_host4=\"".$_POST["mail_host4"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_host4=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_user4"])){
                $stringData= "\$mail_user4=\"".$_POST["mail_user4"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_user4=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            if (isset($_POST["mail_pass4"])){
                $stringData= "\$mail_pass4=\"".$_POST["mail_pass4"]."\";\n";
                fwrite ($fh,$stringData);
            }else{
                $stringData= "\$mail_pass4=\"\"".";\n";
                fwrite ($fh,$stringData);
            }
            
            fwrite ($fh,"\n");
            fwrite ($fh,"?>\n");
            fclose($fh);
            
            echo "<h2>Nastavitve so vpisane!</h2>";
            echo "<a href='index.php'>Na prvo prijavo</a><br />";
        }
    }else{
        //obrazec za nastavitve
        echo "<h2>Nastavitve dostopa in modulov za aplikacijo Kadri in učenci</h2>";
        echo "<p>Pred tem zagonom ste morali na strežnik:<br />";
        echo " - skopirati vsebino spletne strani na osnovno spletno mapo<br />";
        echo " - nastaviti osnovne dostope in konfiguracije (zagon skripte: kadri_setup.sh)<br />";
        echo " </p>";
        echo "<form name='prijava' method='post' action='setup.php'>";
        echo "<input name='id' type='hidden' value='1'>";
        echo "<table border='0'>";
        //administrator
        echo "<tr><th colspan='2'>Administratorski dostop</th></tr>";
        echo "<tr><td>Administratorsko uporabniško ime</td><td>admin</td></tr>";
        echo "<tr><td>Administratorsko geslo<br /><small>spremenite ob prvi prijavi</small></td><td>adminkadri</td></tr>";
        //podatkovna baza
        echo "<tr><th colspan='2'>Dostop do podatkovne baze</th></tr>";
        echo "<tr><td>naslov strežnika (host)</td><td><input name='dbk_host' type='text' value='127.0.0.1'></td></tr>";
        echo "<tr><td>uporabnik za bazo (user)</td><td><input name='dbk_user' type='text' value='kuser'></td></tr>";
        echo "<tr><td>geslo za uporabnika za bazo (password)</td><td><input name='dbk_pass' type='text' value='kSQLgeslo'></td></tr>";
        echo "<tr><td>ime podatkovne baze (database)</td><td><input name='dbk_base' type='text' value='sola'></td></tr>";
        //moduli
        echo "<tr><th colspan='2'>Programski moduli</th></tr>";
        //Kadri in učenci
        echo "<tr><td>Modul učencev</td><td><select name='SamoKadri'>";
        echo "<option value='0' selected='selected'>Kadri in učenci</option>";
        echo "<option value='1'>Samo kadrovski del</option>";
        echo "</td></tr>";
        //eDnevnik
        echo "<tr><td>eDnevnik</td><td><select name='eDnevnik'>";
        echo "<option value='1' selected='selected'>Uporaba eDnevnika</option>";
        echo "<option value='0'>brez eDnevnika</option>";
        echo "</td></tr>";
        //Rezervacija prostorov
        echo "<tr><td>Rezervacija prostorov</td><td><select name='RezervacijaProstorov'>";
        echo "<option value='1' selected='selected'>Vključen modul rezervacij prostorov</option>";
        echo "<option value='0'>Izključen modul rezervacij prostorov</option>";
        echo "</td></tr>";
        //Evidenca prisotnosti
        echo "<tr><td>Evidenca prisotnosti</td><td><select name='EvidencaPrisotnosti'>";
        echo "<option value='1' selected='selected'>Vključen modul evidence prisotnosti na delu</option>";
        echo "<option value='0'>Izključen modul prisotnosti na delu</option>";
        echo "</td></tr>";
        //Modul opravil
        echo "<tr><td>Modul opravil</td><td><select name='Opravila'>";
        echo "<option value='1' selected='selected'>Vključen modul pošiljanja delovnih opravil delavcem</option>";
        echo "<option value='0'>Izključen modul pošiljanja opravil delavcem</option>";
        echo "</td></tr>";
        //Evidenca prehrane
        echo "<inpur name='EvidencaPrehrane' type='hidden' value='0'>"; //ni v php
        //Zaščitna sredstva
        echo "<inpur name='ZascSre' type='hidden' value='0'>"; //ni v php
        
        //nastavitve lastnosti prikazov
        echo "<tr><th colspan='2'>Nastavitve prikazov</th></tr>";
        //Prikaz neipolnjenosti podatkov - semafor
        echo "<tr><td>Prikaz neizpolnjenosti podatkov - semafor</td><td><select name='Semafor'>";
        echo "<option value='1' selected='selected'>Vključen semafor</option>";
        echo "<option value='0'>Izključen semafor</option>";
        echo "</td></tr>";
        //Prikaz neipolnjenosti podatkov - semafor prehrane
        echo "<tr><td>Prikaz neizpolnjenosti podatkov o prehrani - semafor prehrane</td><td><select name='SemaforPrehrana'>";
        echo "<option value='1' selected='selected'>Vključen semafor prehrane</option>";
        echo "<option value='0'>Izključen semafor prehrane</option>";
        echo "</td></tr>";
        //Prikaz neipolnjenosti podatkov - semafor realzacije
        echo "<tr><td>Prikaz neizpolnjenosti podatkov o realizaciji ur - semafor realizacije</td><td><select name='SemaforRealizacija'>";
        echo "<option value='1' selected='selected'>Vključen semafor realizacije</option>";
        echo "<option value='0'>Izključen semafor realizacije</option>";
        echo "</td></tr>";
        //Dolžina delovnega dne
        echo "<tr><td>Število ur za obračun delovne obveze in doprinosa</td><td><select name='DelovniDan'>";
        echo "<option value='1' selected='selected'>8 ur</option>";
        echo "<option value='0'>7,5 ur (brez malice)</option>";
        echo "</td></tr>";
        //Podružnice
        echo "<tr><td>Podružnice</td><td><select name='VecSol'>";
        echo "<option value='0' selected='selected'>Šola brez podružnic</option>";
        echo "<option value='1'>Šola s podružnicami</option>";
        echo "</td></tr>";
        //Število NIP
        echo "<tr><td>Število neobveznih izbirnih predmetov na učenca</td><td><select name='StNeobveznihIzbirnih'>";
        echo "<option value='1' selected='selected'>samo 1 predmet</option>";
        echo "<option value='2'>2 predmeta (?)</option>";
        echo "</td></tr>";
        //Število dni zamude za vpis doprinosov po zadnjem dnevu v mesecu
        echo "<tr><td>Število dni zamude za vpis doprinosov po zadnjem dnevu v mesecu</td><td>";
        echo "<input name='RazlikaDniVpis' type='text' value='0'>";
        echo "</td></tr>";
        //Izpis DU
        echo "<tr><td>Izpis DU (delovnih ur) v spisku rubrik </td><td><select name='izpisDU'>";
        echo "<option value='0' selected='selected'>Izpisuje DU v spisku rubrik</option>";
        echo "<option value='1'>Ne izpisuje DU v spisku rubrik</option>";
        echo "</td></tr>";
        //obračunaj Du
        echo "<tr><td>Upoštevanje Du (koriščenje ur)</td><td><select name='ObracunajDu'>";
        echo "<option value='0' selected='selected'>Rezervacije Du pokaže le s +/- koriščenih dni</option>";
        echo "<option value='1'>Sproti obračunava koriščenje rezervacij Du (zavajujoče ob začetku leta)</option>";
        echo "</td></tr>";
        //Izpis potrebnih ur za jesenski/pomladni del
        echo "<tr><td>Izpis potrebnih ur za jesenski in pomladni del</td><td><select name='IzpisSezon'>";
        echo "<option value='0' selected='selected'>Izpisuje ure po sezonah</option>";
        echo "<option value='1'>Ne izpisuje ur po sezonah</option>";
        echo "</td></tr>";
        //Izpis podatkov o porodniških odsotnostih
        echo "<tr><td>Izpis popodatkov o porodniških odsotnostih</td><td><select name='IzpisPorodniske'>";
        echo "<option value='0' selected='selected'>Izpis porodniških le ob prvem vstopu</option>";
        echo "<option value='1'>Vsakokraten izpis porodniških</option>";
        echo "</td></tr>";
        //email policijske postaje
        echo "<tr><td>Podatki o prevozih učencev naj se pošiljajo avtomatsko na email policijske postaje</td><td>";
        echo "<input name='EmailPolicija' type='text' value=''>";
        echo "</td></tr>";
        //email ravnatelj
        echo "<tr><td>email pošiljatelja sporočil delavcem</td><td>";
        echo "<input name='EmailRavnatelj' type='text' value=''>";
        echo "</td></tr>";
        //obremenitev učiteljev
        echo "<tr><td>Tedenska obremenitev učiteljev</td><td>";
        echo "<input name='ObremenitevUcitelj' type='text' value='22'>";
        echo "</td></tr>";
        //obremenitev učiteljev PB
        echo "<tr><td>Tedenska obremenitev učiteljev PB</td><td>";
        echo "<input name='ObremenitevPB' type='text' value='25'>";
        echo "</td></tr>";
        
        //eMail račun 1
        echo "<tr><th colspan='2'>e-mail račun (imeti mora SSL avtentikacijo na portu 465)<br /><small>več računov je za pošijanje večjih količin mailov (omejitev 500/uro)</small></th></tr>";
        echo "<tr><td>SMTP strežnik 1</td><td>";
        echo "<input name='mail_host1' type='text' value='mail.arnes.si'>";
        echo "</td></tr>";
        echo "<tr><td>uporabnik 1</td><td>";
        echo "<input name='mail_user1' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>geslo 1</td><td>";
        echo "<input name='mail_pass1' type='text' value=''>";
        echo "</td></tr>";

        echo "<tr><td>SMTP strežnik 2</td><td>";
        echo "<input name='mail_host2' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>uporabnik 2</td><td>";
        echo "<input name='mail_user2' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>geslo 2</td><td>";
        echo "<input name='mail_pass2' type='text' value=''>";
        echo "</td></tr>";

        echo "<tr><td>SMTP strežnik 3</td><td>";
        echo "<input name='mail_host3' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>uporabnik 3</td><td>";
        echo "<input name='mail_user3' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>geslo 3</td><td>";
        echo "<input name='mail_pass3' type='text' value=''>";
        echo "</td></tr>";

        echo "<tr><td>SMTP strežnik 4</td><td>";
        echo "<input name='mail_host4' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>uporabnik 4</td><td>";
        echo "<input name='mail_user4' type='text' value=''>";
        echo "</td></tr>";
        echo "<tr><td>geslo 4</td><td>";
        echo "<input name='mail_pass4' type='text' value=''>";
        echo "</td></tr>";
        
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
    }

    echo "</body>";
    echo "</html>";
}

  
?>
