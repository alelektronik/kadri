<?php
require ('const.php');
include ('iskanje.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Pregled dela
</title>
</head>
<body>
<a href="prijava.asp">Nazaj na glavni meni</a><br>
<?php
if (isset($_SESSION["Ucitelj"])){
    $ucitelj = $_SESSION["Ucitelj"];
}else{
    $ucitelj = 0;
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id = $_GET["id"];
    }else{
        $id = "";
    }
}

$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

$VLeto=PreberiLeto("leto");

if (isset($_POST["mesec"])){
    $VMesec=$_POST["mesec"];
}else{
    $VMesec="";
}
if (isset($_POST["spisek"])){
    $Vspisek=$_POST["spisek"];
}else{
    $Vspisek="";
}
echo "Leto: ".$VLeto."<br>";

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
  	echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
	$VUcitelj=$R["IdUcitelj"];
}else{
 	echo "Nimate potrebnih pooblastil za ogled strani!";
	header("Location: nepooblascen.htm");
}

if (CheckDostop("DelKontr",$VUporabnik) or ($VUcitelj == $ucitelj) or CheckDostop("drugo1",$VUporabnik)) {
	if (CheckDostop("DelKontr",$VUporabnik) or CheckDostop("drugo1",$VUporabnik)) {
        switch ($_POST["submit"]){
            case "Briši":
                for ($indx=1;$indx <= $_POST["StRubrik"];$indx++){
                    if (isset($_POST["br_".$indx])){
		                $SQL = "DELETE FROM tabpregleddelan WHERE Id =" . $_POST["brisi_".$indx];
                        $result = mysqli_query($link,$SQL);
                    }
                }
                break;
            case "Potrdi":
                if (CheckDostop("drugo1",$VUporabnik)){
                    for ($indx=1;$indx <= $_POST["StRubrik"];$indx++){
                        if ($_POST["potrjeno_".$indx] == "on"){
                            $SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=true,potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["potrdi_".$indx];
                        }else{
                            $SQL = "UPDATE tabpregleddelan SET EnotPotrjeno=false,potrdil='".$VUporabnik."',cas='".$Danes->format('Y-m-d H:i:s')."' WHERE id=".$_POST["potrdi_".$indx];
                        }
                        $result = mysqli_query($link,$SQL);
                    }
                }
                break;
            default: //prejme parametre preko GET
                $SQL = "DELETE FROM tabpregleddelan WHERE Id =" . $id;
                $result = mysqli_query($link,$SQL);
        }
	}else{
        switch ($_POST["submit"]){
            case "Briši":
                for ($indx=1;$indx <= $_POST["StRubrik"];$indx++){
                    if (isset($_POST["br_".$indx])){
                        $SQL = "DELETE FROM tabpregleddelan WHERE Id =" . $_POST["brisi_".$indx] ." AND mesec=".$ActualMonth;
                        $result = mysqli_query($link,$SQL);
                    }
                }
                break;
        }
	}
}

$_SESSION["Ucitelj"]=$ucitelj;

if (isset($_GET["back"])){
    $back=$GET["back"];
}else{
    if (isset($_POST["back"])){
        $back=$_POST["back"];
    }else{
        $back="";
    }
}
switch ($back) {
    case "potrjevanje":
	    header("Location: PotrjevanjeRubrikPDN.php?leto=".$VLeto."&mesec=".$VMesec."&spisek=".$Vspisek);
        break;
    case "zadnji":
        header("Location: ZadnjiVpisi.php");
        break;
    default:
	    header("Location: IzpisUcitelja.php?idUcitelj=".$ucitelj);
}

?>
</body>
</html>
