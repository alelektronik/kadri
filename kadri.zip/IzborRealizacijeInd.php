<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Izpis učitelja
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br>";
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    echo "<a href='IzborUcitelja.php'>Nazaj na izbiro delavca</a><br>";
}

$SQL = "SELECT DISTINCT tabucenje.leto,tabucenje.idUcitelj AS uidUcitelj,tabucitelji.* FROM tabucenje INNER JOIN tabucitelji ON tabucenje.idUcitelj=tabucitelji.idUcitelj WHERE leto=".$VLeto." ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
while ($R = mysqli_fetch_array($result)){
	$VUcitelj[$Indx][1]=$R["uidUcitelj"];
	$VUcitelj[$Indx][2]=$R["Priimek"]." ".$R["Ime"];
	$Indx=$Indx+1;
}
$StUciteljev=$Indx-1;

echo "<form accept-charset='utf-8' name='rezultati' method='post' action='VnosRealizacijeInd.php'>";
echo "<h2>Izberite učitelja za vnos realizacije</h2><br />";
echo "<table border=0>";
echo "<tr>";
echo "<td>";
echo "Šolsko leto: <select name='solskoleto'>";
echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . $VLeto . "</option>";
echo "<option value='" .  ($VLeto-2)  . "'>" . ($VLeto -2) . "/"  . ($VLeto-1) . "</option>";
echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
echo "</select>";
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "<select name='ucitelj'>";
for ($Indx=1;$Indx <= $StUciteljev;$Indx++){
	if ($VLevel > 1){
		echo "<option value='".$VUcitelj[$Indx][1]."'>".$VUcitelj[$Indx][2]."</option>";
	}else{
		if ($VUcitelj[$Indx][1]==$UciteljComp){
			echo "<option value='".$VUcitelj[$Indx][1]."' selected>".$VUcitelj[$Indx][2]."</option>";
		}
	}
}
echo "</select>";
echo "</td>";
echo "</tr>";
echo "</table>";
echo "<input name='submit' type='submit' value='Pošlji'>";
echo "</form>";
?>
</body>
</html>
