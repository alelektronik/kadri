<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Razred
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

function Arr2Str($a){
    $s="";
    if (count($a) > 0){
        for ($i=0;$i < count($a);$i++){
            if (strlen($s) == 0){
                $s=$a[$i];
            }else{
                $s=$s.",".$a[$i];
            }
        }
    }
    return $s;
}
function vsebuje($s,$x){
    $a=explode(",",$x);
    for ($i=0;$i < count($a);$i++){
        if ($s == trim($a[$i])){
            return true;
        }
    }
    return false;
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VIdRazrednik=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
    if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
        header("Location: nepooblascen.htm");
    }else{

        if (isset($_POST["id"])){
            $Vid = $_POST["id"];
        }else{
            if (isset($_GET["id"])){
                $Vid=$_GET["id"];
            }else{
                $Vid = "";
            }
        }
        switch ($Vid){
            case "1":
                break;
            default:
                $n=$VLevel;
                include('menu_func.inc');
                include ('menu.inc');
        }
            
        $StPolj=45;
        switch ($Vid){
            case "1": //izpis izbranih rubrik
                //VLeto = Request("SolskoLeto")
                $VDevetletka = $_POST["vrstaos"];
                $VRazred = $_POST["razred"];
                $StR=count($VRazred);
                $VRazred = Arr2Str($VRazred);
                if (vsebuje("0",$VRazred)){
                    $VRazred="0";
                    $StR=1;
                }
                //$VParalelka = $_POST["paralelka"];
                for ($Indx=1;$Indx <= $StPolj;$Indx++){
                    if (isset($_POST["polje".$Indx])){
                        $Polje[$Indx]=true;
                    }else{
                        $Polje[$Indx]=false;
                    }
                }

                $_SESSION["leto"] = $VLeto;
                $StFantje=0;
                $StDekleta=0;
                if ($Polje[10]){ //razvrščanje po spolu
                    $SQL = "SELECT tabrazred.*,tabrazred.razred AS rrazred, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime,tabucitelji.spol AS uspol, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime,tabvzgojitelji.spol AS vspol";
                    $SQL = $SQL . ", tabucenci.*,tabucenci.spol AS ucspol,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.iducenec AS uciducenec,tabbivanje.bivanje AS bbivanje,tabposebnepotrebe.*,tabrazdat.*,tabrazdat.leto AS rleto FROM ";
                    $SQL = $SQL."((((tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                    $SQL = $SQL."INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL."INNER JOIN tabbivanje ON tabucenci.Bivanje=tabbivanje.idBivanje) ";
                    $SQL = $SQL."INNER JOIN tabposebnepotrebe ON tabucenci.idPosebnePotrebe=tabposebnepotrebe.idPosebnePotrebe) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    if ($VRazred=="0" ){
                        $SQL = $SQL."WHERE tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto." ";  
                    }else{
                        //$SQL = $SQL."WHERE idRazred=" . $VRazred ." AND tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto." ";
                        $SQL = $SQL."WHERE idRazred IN (" . $VRazred .") AND tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto." ";
                    }
                    if (isset($_POST["porazredih"])){
                        $SQL = $SQL ." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.Spol DESC,tabucenci.Priimek, tabucenci.Ime";
                    }else{
                        $SQL = $SQL ." ORDER BY tabucenci.Spol DESC,tabucenci.Priimek, tabucenci.Ime";
                    }
                }else{
                    $SQL = "SELECT tabrazred.*,tabrazred.razred AS rrazred, tabucitelji.Priimek AS upriimek, tabucitelji.Ime AS uime,tabucitelji.spol AS uspol, tabvzgojitelji.Priimek AS vpriimek, tabvzgojitelji.Ime AS vime,tabvzgojitelji.spol AS vspol";
                    $SQL = $SQL . ", tabucenci.*,tabucenci.spol AS ucspol,tabucenci.priimek AS ucpriimek,tabucenci.ime AS ucime,tabucenci.iducenec AS uciducenec,tabbivanje.bivanje AS bbivanje,tabposebnepotrebe.*,tabrazdat.*,tabrazdat.leto AS rleto FROM ";
                    $SQL = $SQL. "(((((tabrazred INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id)";
                    $SQL = $SQL. " INNER JOIN tabucenci ON tabrazred.iducenec=tabucenci.iducenec)";
                    $SQL = $SQL. " INNER JOIN tabucitelji ON tabrazred.iducitelj=tabucitelji.iducitelj)";
                    $SQL = $SQL. " INNER JOIN tabvzgojitelji ON tabrazred.idvzgojitelj=tabvzgojitelji.iducitelj)";
                    $SQL = $SQL. " INNER JOIN tabbivanje ON tabucenci.Bivanje=tabbivanje.idBivanje) ";
                    $SQL = $SQL. " INNER JOIN tabposebnepotrebe ON tabucenci.idPosebnePotrebe=tabposebnepotrebe.idPosebnePotrebe ";
                    /*
                    $SQL = $SQL."((((tabvzgojitelji INNER JOIN (tabrazred INNER JOIN tabucitelji ON tabrazred.IdUcitelj=tabucitelji.IdUcitelj) ON tabvzgojitelji.IdUcitelj=tabrazred.IdVzgojitelj) ";
                    $SQL = $SQL."INNER JOIN tabucenci ON tabrazred.IdUcenec=tabucenci.IdUcenec) ";
                    $SQL = $SQL."INNER JOIN tabbivanje ON tabucenci.Bivanje=tabbivanje.idBivanje) ";
                    $SQL = $SQL."INNER JOIN tabposebnepotrebe ON tabucenci.idPosebnePotrebe=tabposebnepotrebe.idPosebnePotrebe) ";
                    $SQL = $SQL . "INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                    */
                    if ($VRazred=="0" ){
                        $SQL = $SQL."WHERE tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto. " "  ;
                    }else{
                        //$SQL = $SQL."WHERE idRazred=" . $VRazred ." AND tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto. " ";
                        $SQL = $SQL."WHERE idRazred IN (" . $VRazred .") AND tabrazdat.leto=" . $VLeto . " AND tabrazred.leto=".$VLeto. " ";
                    }
                    if (isset($_POST["porazredih"])){
                        $SQL = $SQL." ORDER BY tabrazdat.idsola,tabrazdat.razred,tabrazdat.oznaka,tabucenci.Priimek, tabucenci.Ime";
                    }else{
                        $SQL = $SQL." ORDER BY tabucenci.Priimek, tabucenci.Ime";
                    }
                }
                $result = mysqli_query($link,$SQL);
                $VParalelka="";
                $IdUcitelj=0;
                $IdVzgojitelj=0;
                
                if (isset($_POST["dato"])){
                    $VFile="ucenci_$VRazred.csv";
                    $MyFile = "dato".$FileSep.$VFile;
                    $fh = fopen($MyFile,'w') or die("Ne morem odpreti datoteke!");
                    
                    fwrite ($fh,"Št.;");
                    if ($VRazred == "0" or $StR > 1){
                        fwrite ($fh,"N;");
                    }
                    if ($Polje[1]){ fwrite ($fh,"Mat. list;");}
                    if ($Polje[31]){ fwrite ($fh,"Mat. knjiga;");}
                    if ($Polje[2]){ 
                        fwrite ($fh,"Priimek;Ime;");
                        if ($VRazred=="0" or $StR > 1){
                            fwrite ($fh,"Razred;");
                        }
                    }
                    if ($Polje[9]){ fwrite ($fh,"Spol;");}
                    if ($Polje[3]){ fwrite ($fh,"Datum rojstva;");}
                    if ($Polje[29]){ fwrite ($fh,"Kraj rojstva;");}
                    if ($Polje[30]){ fwrite ($fh,"Država rojstva;");}
                    if ($Polje[11]){ fwrite ($fh,"EMŠO;");}
                    if ($Polje[4]){ fwrite ($fh,"Naslov;");}
                    if ($Polje[5]){ fwrite ($fh,"Pošta;");}
                    if ($Polje[6]){ fwrite ($fh,"Kraj;");}
                    if ($Polje[41]){ fwrite ($fh,"Zač. naslov;");}
                    if ($Polje[42]){ fwrite ($fh,"Zač. pošta;");}
                    if ($Polje[43]){ fwrite ($fh,"Zač. kraj;");}
                    if ($Polje[36]){ fwrite ($fh,"Šolski okoliš;");}
                    if ($Polje[37]){ fwrite ($fh,"Telefon doma;");}
                    if ($Polje[7]){ fwrite ($fh,"Oče;");}
                    if ($Polje[13]){ fwrite ($fh,"Očetov naslov;");}
                    if ($Polje[44]){ fwrite ($fh,"Očetov zač. naslov;");}
                    if ($Polje[14]){ fwrite ($fh,"Očetov telefon;");}
                    if ($Polje[32]){ fwrite ($fh,"Očetov e-mail;");}
                    if ($Polje[8]){ fwrite ($fh,"Mati;");}
                    if ($Polje[15]){ fwrite ($fh,"Materin naslov;");}
                    if ($Polje[45]){ fwrite ($fh,"Materin zač. naslov;");}
                    if ($Polje[16]){ fwrite ($fh,"Materin telefon;");}
                    if ($Polje[33]){ fwrite ($fh,"Materin e-mail;");}
                    if ($Polje[23]){ fwrite ($fh,"Skrbnik;");}
                    if ($Polje[24]){ fwrite ($fh,"Skrbnikov naslov;");}
                    if ($Polje[25]){ fwrite ($fh,"Skrbnikov telefon;");}
                    if ($Polje[34]){ fwrite ($fh,"Skrbnikov e-mail;");}
                    if ($Polje[26]){ fwrite ($fh,"Plačnik;");}
                    if ($Polje[27]){ fwrite ($fh,"Plačnikov naslov;");}
                    if ($Polje[28]){ fwrite ($fh,"Plačnikov telefon;");}
                    if ($Polje[12]){ fwrite ($fh,"Evidenčna št.;");}
                    if ($Polje[17]){ fwrite ($fh,"Bivanje;");}
                    if ($Polje[18]){ fwrite ($fh,"Rom;");}
                    if ($Polje[19]){ fwrite ($fh,"Posebne potrebe;");}
                    if ($Polje[20]){ fwrite ($fh,"Državljanstvo;");}
                    if ($Polje[38]){ fwrite ($fh,"ID v Kadrih;");}
                    if ($Polje[39]){ fwrite ($fh,"Slika;");}
                    if ($Polje[40]){ fwrite ($fh,"Razrednik;");}
                    if ($Polje[22]){ fwrite ($fh,"Opombe;");}
                    if ($Polje[21]){ fwrite ($fh,"Podpis;");}
                    if (strlen($_POST["dejavnost"]) > 0 ){ fwrite ($fh,"Prisotnost;");}
                    fwrite ($fh,"\n");

                    $Indx=1;
                    $result = mysqli_query($link,$SQL);
                    $r="";
                    $ir=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Razrednik = $R["uime"]." ".$R["upriimek"];
                        fwrite ($fh,"$Indx;");
                        if ($Polje[1]){ fwrite ($fh,$R["MaticniList"] . ";");}
                        if ($Polje[31]){ fwrite ($fh,$R["MaticnaKnjiga"] . ";");}
                        if ($Polje[2]){ 
                            if ($VRazred == "0"  or $StR > 1){
                                if ($R["rrazred"].". ".$R["oznaka"] == $r){
                                    $ir += 1;
                                }else{
                                    $ir = 1;
                                    $r=$R["rrazred"].". ".$R["oznaka"];
                                }
                                fwrite ($fh,"$ir;");
                                //if ($VLevel > 1 ){
                                //    echo "<td><a href='ucenec.php?id=3&ucenec=".$R["uciducenec"]."'>" . $R["ucpriimek"] . "</td><td>" . $R["ucime"] ."</a></td>";
                                //}else{
                                    fwrite ($fh,$R["ucpriimek"] . ";" . $R["ucime"].";");
                                //}
                                fwrite ($fh,$R["rrazred"].". ".$R["oznaka"]);
                                if ($VecSol > 0){
                                    fwrite ($fh," (".$R["idsola"].")");
                                }
                            }else{
                                fwrite ($fh,$R["ucpriimek"] . ";" . $R["ucime"]);
                            }
                            fwrite ($fh,";");
                        }
                        
                        if ($Polje[9]){ 
                            if ($R["ucspol"]=="M" ){
                                fwrite ($fh,$R["ucspol"]. ";");
                            }else{
                                fwrite ($fh,"Ž;");
                            }
                        }
                        if ($Polje[3]){ 
                            $Datum=new DateTime(isDate($R["DatRoj"]));
                            fwrite ($fh,$Datum->format('d.m.Y') . ";");
                        }
                        if ($Polje[29]){ fwrite ($fh,$R["KrajRoj"] .";");}
                        if ($Polje[30]){ fwrite ($fh,$R["DrzavaRoj"] .";");}
                        if ($Polje[11]){ fwrite ($fh,$R["emso"] . ";");}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["NaslovZac"]) && (strlen($R["NaslovZac"]) > 0)){
                                if ($Polje[4]){ fwrite ($fh,$R["NaslovZac"] .";");}
                                if ($Polje[5]){ fwrite ($fh,$R["PostaZac"] .";");}
                                if ($Polje[6]){ fwrite ($fh,$R["KrajZac"] .";");}
                            }else{
                                if ($Polje[4]){ fwrite ($fh,$R["Naslov"] .";");}
                                if ($Polje[5]){ fwrite ($fh,$R["Posta"] .";");}
                                if ($Polje[6]){ fwrite ($fh,$R["Kraj"] .";");}
                            }
                        }else{
                            if ($Polje[4]){ fwrite ($fh,$R["Naslov"] .";");}
                            if ($Polje[5]){ fwrite ($fh,$R["Posta"] .";");}
                            if ($Polje[6]){ fwrite ($fh,$R["Kraj"] .";");}
                        }
                        if ($Polje[41]){ fwrite ($fh,$R["NaslovZac"] .";");}
                        if ($Polje[42]){ 
                            if ($R["PostaZac"] > 0){
                                fwrite ($fh,$R["PostaZac"] .";");
                            }else{
                                fwrite ($fh,";");
                            }
                        }
                        if ($Polje[43]){ fwrite ($fh,$R["KrajZac"] .";");}
                        
                        if ($Polje[36]){ fwrite ($fh,$R["SolskiOkolis"] .";");}
                        if ($Polje[37]){ fwrite ($fh,$R["TelefonDoma"] .";");}
                        if ($Polje[7]){ fwrite ($fh,$R["oce"] .";");}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["ocezacnasl"]) && (strlen($R["ocezacnasl"]) > 0)){
                                if ($Polje[13]){ fwrite ($fh,$R["ocezacnasl"] .";");}
                            }else{
                                if ($Polje[13]){ fwrite ($fh,$R["ocenaslov"] .";");}
                            }
                        }else{
                            if ($Polje[13]){ fwrite ($fh,$R["ocenaslov"] .";");}
                        }
                        if ($Polje[44]){ fwrite ($fh,$R["ocezacnasl"] .";");}
                        if ($Polje[14]){ fwrite ($fh,$R["ocekontakt"] .", GSM: ".$R["oceGSM"] .", služba: ".$R["oceSluzba"] .";");}
                        if ($Polje[32]){ 
                            fwrite ($fh,$R["oceemail"] .";");
                        }
                        if ($Polje[8]){ fwrite ($fh,$R["mati"] .";");}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["matizacnasl"]) && (strlen($R["matizacnasl"]) > 0)){
                                if ($Polje[15]){ fwrite ($fh,$R["matizacnasl"] .";");}
                            }else{
                                if ($Polje[15]){ fwrite ($fh,$R["matinaslov"] .";");}
                            }
                        }else{
                            if ($Polje[15]){ fwrite ($fh,$R["matinaslov"] .";");}
                        }
                        if ($Polje[45]){ fwrite ($fh,$R["matizacnasl"] .";");}
                        if ($Polje[16]){ fwrite ($fh,$R["matikontakt"] .", GSM: ".$R["matiGSM"] .", služba: ".$R["matiSluzba"] .";");}
                        if ($Polje[33]){ 
                            fwrite ($fh,$R["matiemail"] .";");
                        }
                        if ($Polje[23]){ fwrite ($fh,$R["Skrbniki"] .";");}
                        if ($Polje[24]){ fwrite ($fh,$R["SkrbnikiNaslov"] .";");}
                        if ($Polje[25]){ fwrite ($fh,$R["SkrbnikiKontakt"] .";");}
                        if ($Polje[34]){ 
                            fwrite ($fh,$R["SkrbnikiEmail"] .";");
                        }
                        if ($Polje[26]){ fwrite ($fh,$R["Placnik"] .";");}
                        if ($Polje[27]){ fwrite ($fh,$R["PlacnikNaslov"] .";");}
                        if ($Polje[28]){ fwrite ($fh,$R["PlacnikKontakt"] .";");}
                        if ($Polje[12]){ fwrite ($fh,$R["EvidSt"] .";");}
                        if ($Polje[17]){ fwrite ($fh,$R["bbivanje"] .";");}
                        if ($Polje[18]){ fwrite ($fh,$R["Rom"] .";");}
                        if ($Polje[19]){ fwrite ($fh,$R["OpisPosebnePotrebe"] .";");}
                        if ($Polje[20]){ fwrite ($fh,$R["Drzavljanstvo"] .";");}
                        if ($Polje[38]){ fwrite ($fh,$R["uciducenec"] .";");}
                        if ($Polje[39]){ 
                            if (file_exists($R["slika"])){
                                fwrite ($fh,$R["slika"] .";");
                            }else{
                                fwrite ($fh,";");
                            }
                        }
                        if ($Polje[40]){ fwrite ($fh,$Razrednik .";");}
                        if ($Polje[22]){ fwrite ($fh,$R["Opombe"] .";");}
                        if ($Polje[21]){ fwrite ($fh,";");}
                        if (strlen($_POST["dejavnost"]) > 0){ fwrite ($fh,";");}
                        fwrite ($fh,"\n");
                        $Indx=$Indx+1;
                    }

                    fclose($fh);
                    echo "<h2><a href='dato".$FileSep.$VFile."' target='_blank'>Prenesi CSV datoteko učencev</a></h2>";
                }else{

                    echo "Šolsko leto: " . $VLeto . "/" . ($VLeto+1)."<br>";

                    if ($R = mysqli_fetch_array($result)){
                        $VRazred1=$R["rrazred"];
                        $VParalelka=$R["oznaka"];
                        if (strlen($_POST["dejavnost"]) > 0){
                            echo "<h2>".$_POST["dejavnost"]."</h2>";
                            if ($VRazred != "0" && $StR==1){
                                echo "<h3>Razred: " . $VRazred1 . ". " . $VParalelka ."</h3>";
                            }
                        }else{
                            if ($VRazred != "0" && $StR==1 ){
                                echo "<h2>Razred: " . $VRazred1 . ". " . $VParalelka ."</h2>";
                            }
                        }
                        $Ucitelj = $R["upriimek"]  . ", " . $R["uime"];
                        $Razrednik = $R["uime"]." ".$R["upriimek"];
                        $IdUcitelj=$R["IdUcitelj"];
                        $Vzgojitelj = $R["vpriimek"]  . ", " . $R["vime"];
                        $IdVzgojitelj=$R["IdVzgojitelj"];
                        if ($StR == 1 && $VRazred != "0"){
                            if ($R["uspol"]=="M" ){
                                echo "<h3>Razrednik: " . $Ucitelj . "<br>";
                            }else{
                                echo "<h3>Razredničarka: " . $Ucitelj . "<br>";
                            }
                            switch ( $VRazred1){
                                case 1:
                                    if ($R["vspol"]=="M" ){
                                        echo "Drugi učitelj: " . $Vzgojitelj . "</h3>";
                                    }else{
                                        echo "Druga učiteljica: " . $Vzgojitelj . "</h3>";
                                    }
                                    break;
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                    if ($R["vspol"]=="M" ){
                                        echo "Učitelj PB: " . $Vzgojitelj . "</h3>";
                                    }else{
                                        echo "Učiteljica PB: " . $Vzgojitelj . "</h3>";
                                    }
                                    break;
                                default:    
                                    echo "</h3>";
                            }
                        }
                    }

                    echo "<table border=1 cellspacing=0 cellpadding=4>";
                    echo "<tr bgcolor=lightcyan>";
                    echo "<th>Št.</th>";
                    if ($VRazred == "0" or $StR > 1){
                        echo "<th>N</th>";
                    }
                    if ($Polje[1]){ echo "<th>Mat. list</th>";}
                    if ($Polje[31]){ echo "<th>Mat. knjiga</th>";}
                    if ($Polje[2]){ 
                        echo "<th>Priimek</th><th>Ime</th>";
                        if ($VRazred=="0" or $StR > 1){
                            echo "<th>Razred</th>";
                        }
                    }
                    if ($Polje[9]){ echo "<th>Spol</th>";}
                    if ($Polje[3]){ echo "<th>Datum rojstva</th>";}
                    if ($Polje[29]){ echo "<th>Kraj rojstva</th>";}
                    if ($Polje[30]){ echo "<th>Država rojstva</th>";}
                    if ($Polje[11]){ echo "<th>EMŠO</th>";}
                    if ($Polje[4]){ echo "<th>Naslov</th>";}
                    if ($Polje[5]){ echo "<th>Pošta</th>";}
                    if ($Polje[6]){ echo "<th>Kraj</th>";}
                    if ($Polje[41]){ echo "<th>Zač. naslov</th>";}
                    if ($Polje[42]){ echo "<th>Zač. pošta</th>";}
                    if ($Polje[43]){ echo "<th>Zač. kraj</th>";}
                    if ($Polje[36]){ echo "<th>Šolski okoliš</th>";}
                    if ($Polje[37]){ echo "<th>Telefon doma</th>";}
                    if ($Polje[7]){ echo "<th>Oče</th>";}
                    if ($Polje[13]){ echo "<th>Očetov naslov</th>";}
                    if ($Polje[44]){ echo "<th>Očetov zač. naslov</th>";}
                    if ($Polje[14]){ echo "<th>Očetov telefon</th>";}
                    if ($Polje[32]){ echo "<th>Očetov e-mail</th>";}
                    if ($Polje[8]){ echo "<th>Mati</th>";}
                    if ($Polje[15]){ echo "<th>Materin naslov</th>";}
                    if ($Polje[45]){ echo "<th>Materin zač. naslov</th>";}
                    if ($Polje[16]){ echo "<th>Materin telefon</th>";}
                    if ($Polje[33]){ echo "<th>Materin e-mail</th>";}
                    if ($Polje[23]){ echo "<th>Skrbnik</th>";}
                    if ($Polje[24]){ echo "<th>Skrbnikov naslov</th>";}
                    if ($Polje[25]){ echo "<th>Skrbnikov telefon</th>";}
                    if ($Polje[34]){ echo "<th>Skrbnikov e-mail</th>";}
                    if ($Polje[26]){ echo "<th>Plačnik</th>";}
                    if ($Polje[27]){ echo "<th>Plačnikov naslov</th>";}
                    if ($Polje[28]){ echo "<th>Plačnikov telefon</th>";}
                    if ($Polje[12]){ echo "<th>Evidenčna št.</th>";}
                    if ($Polje[17]){ echo "<th>Bivanje</th>";}
                    if ($Polje[18]){ echo "<th>Rom</th>";}
                    if ($Polje[19]){ echo "<th>Posebne potrebe</th>";}
                    if ($Polje[20]){ echo "<th>Državljanstvo</th>";}
                    if ($Polje[38]){ echo "<th>ID v Kadrih</th>";}
                    if ($Polje[39]){ echo "<th>Slika</th>";}
                    if ($Polje[40]){ echo "<th>Razrednik</th>";}
                    if ($Polje[22]){ echo "<th>Opombe</th>";}
                    if ($Polje[21]){ echo "<th>Podpis</th>";}
                    if (strlen($_POST["dejavnost"]) > 0 ){ echo "<th>Prisotnost</th>";}
                    echo "</tr>";

                    $Indx=1;
                    $result = mysqli_query($link,$SQL);
                    $r="";
                    $ir=0;
                    while ($R = mysqli_fetch_array($result)){
                        $Razrednik = $R["uime"]." ".$R["upriimek"];
                        if ($R["ucspol"]=="M" ){
                            $StFantje=$StFantje+1;
                            echo "<tr bgcolor=lightyellow>";
                        }else{
                            $StDekleta=$StDekleta+1;
                            echo "<tr bgcolor=#FFFFCC>";
                        }
                        echo "<td bgcolor=lightgrey align=right>" . $Indx ."</td>";
                        if ($Polje[1]){ echo "<td>" . $R["MaticniList"] . "</td>";}
                        if ($Polje[31]){ echo "<td>" . $R["MaticnaKnjiga"] . "</td>";}
                        if ($Polje[2]){ 
                            if ($VRazred == "0"  or $StR > 1){
                                if ($R["rrazred"].". ".$R["oznaka"] == $r){
                                    $ir += 1;
                                }else{
                                    $ir = 1;
                                    $r=$R["rrazred"].". ".$R["oznaka"];
                                }
                                echo "<td align='center'>".$ir."</td>";
                                //if ($VLevel > 1 ){
                                //    echo "<td><a href='ucenec.php?id=3&ucenec=".$R["uciducenec"]."'>" . $R["ucpriimek"] . "</td><td>" . $R["ucime"] ."</a></td>";
                                //}else{
                                    echo "<td>" . $R["ucpriimek"] . "</td><td>" . $R["ucime"]."</td>";
                                //}
                                echo "<td>".$R["rrazred"].". ".$R["oznaka"];
                                if ($VecSol > 0){
                                    echo " (".$R["idsola"].")";
                                }
                            }else{
                                echo "<td>" . $R["ucpriimek"] . "</td><td>" . $R["ucime"];
                            }
                            echo "</td>";
                        }
                        
                        if ($Polje[9]){ 
                            if ($R["ucspol"]=="M" ){
                                echo "<td>" . $R["ucspol"]. "</td>";
                            }else{
                                echo "<td>Ž</td>";
                            }
                        }
                        if ($Polje[3]){ 
                            $Datum=new DateTime(isDate($R["DatRoj"]));
                            echo "<td align='right'>" . $Datum->format('d.m.Y') . "</td>";
                        }
                        if ($Polje[29]){ echo "<td>". $R["KrajRoj"] ."</td>";}
                        if ($Polje[30]){ echo "<td>". $R["DrzavaRoj"] ."</td>";}
                        if ($Polje[11]){ echo "<td>" . $R["emso"] . "</td>";}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["NaslovZac"]) && (strlen($R["NaslovZac"]) > 0)){
                                if ($Polje[4]){ echo "<td><font color='red'>". $R["NaslovZac"] ."</font></td>";}
                                if ($Polje[5]){ echo "<td><font color='red'>". $R["PostaZac"] ."</font></td>";}
                                if ($Polje[6]){ echo "<td><font color='red'>". $R["KrajZac"] ."</font></td>";}
                            }else{
                                if ($Polje[4]){ echo "<td>". $R["Naslov"] ."</td>";}
                                if ($Polje[5]){ echo "<td>". $R["Posta"] ."</td>";}
                                if ($Polje[6]){ echo "<td>". $R["Kraj"] ."</td>";}
                            }
                        }else{
                            if ($Polje[4]){ echo "<td>". $R["Naslov"] ."</td>";}
                            if ($Polje[5]){ echo "<td>". $R["Posta"] ."</td>";}
                            if ($Polje[6]){ echo "<td>". $R["Kraj"] ."</td>";}
                        }
                        if ($Polje[41]){ echo "<td>". $R["NaslovZac"] ."</td>";}
                        if ($Polje[42]){ 
                            if ($R["PostaZac"] > 0){
                                echo "<td>". $R["PostaZac"] ."</td>";
                            }else{
                                echo "<td></td>";
                            }
                        }
                        if ($Polje[43]){ echo "<td>". $R["KrajZac"] ."</td>";}
                        
                        if ($Polje[36]){ echo "<td>". $R["SolskiOkolis"] ."</td>";}
                        if ($Polje[37]){ echo "<td>". $R["TelefonDoma"] ."</td>";}
                        if ($Polje[7]){ echo "<td>". $R["oce"] ."</td>";}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["ocezacnasl"]) && (strlen($R["ocezacnasl"]) > 0)){
                                if ($Polje[13]){ echo "<td><font color='red'>". $R["ocezacnasl"] ."</font></td>";}
                            }else{
                                if ($Polje[13]){ echo "<td>". $R["ocenaslov"] ."</td>";}
                            }
                        }else{
                            if ($Polje[13]){ echo "<td>". $R["ocenaslov"] ."</td>";}
                        }
                        if ($Polje[44]){ echo "<td>". $R["ocezacnasl"] ."</td>";}
                        if ($Polje[14]){ echo "<td>". $R["ocekontakt"] .", GSM: ".$R["oceGSM"] .", služba: ".$R["oceSluzba"] ."</td>";}
                        if ($Polje[32]){ 
                            echo "<td><a href='mailto:".$R["oceemail"] ."'>". $R["oceemail"] ."</a></td>";
                        }
                        if ($Polje[8]){ echo "<td>". $R["mati"] ."</td>";}
                        if ($Polje[35]){    //'ali naj izpiše začasno prebivališče, če obstaja
                            if (isset($R["matizacnasl"]) && (strlen($R["matizacnasl"]) > 0)){
                                if ($Polje[15]){ echo "<td><font color='red'>". $R["matizacnasl"] ."</font></td>";}
                            }else{
                                if ($Polje[15]){ echo "<td>". $R["matinaslov"] ."</td>";}
                            }
                        }else{
                            if ($Polje[15]){ echo "<td>". $R["matinaslov"] ."</td>";}
                        }
                        if ($Polje[45]){ echo "<td>". $R["matizacnasl"] ."</td>";}
                        if ($Polje[16]){ echo "<td>". $R["matikontakt"] .", GSM: ".$R["matiGSM"] .", služba: ".$R["matiSluzba"] ."</td>";}
                        if ($Polje[33]){ 
                            echo "<td><a href='mailto:".$R["matiemail"] ."'>". $R["matiemail"] ."</td>";
                        }
                        if ($Polje[23]){ echo "<td>". $R["Skrbniki"] ."</td>";}
                        if ($Polje[24]){ echo "<td>". $R["SkrbnikiNaslov"] ."</td>";}
                        if ($Polje[25]){ echo "<td>". $R["SkrbnikiKontakt"] ."</td>";}
                        if ($Polje[34]){ 
                            echo "<td><a href='mailto:".$R["SkrbnikiEmail"] ."'>". $R["SkrbnikiEmail"] ."</td>";
                        }
                        if ($Polje[26]){ echo "<td>". $R["Placnik"] ."</td>";}
                        if ($Polje[27]){ echo "<td>". $R["PlacnikNaslov"] ."</td>";}
                        if ($Polje[28]){ echo "<td>". $R["PlacnikKontakt"] ."</td>";}
                        if ($Polje[12]){ echo "<td>". $R["EvidSt"] ."</td>";}
                        if ($Polje[17]){ echo "<td>". $R["bbivanje"] ."</td>";}
                        if ($Polje[18]){ echo "<td>". $R["Rom"] ."</td>";}
                        if ($Polje[19]){ echo "<td>". $R["OpisPosebnePotrebe"] ."</td>";}
                        if ($Polje[20]){ echo "<td>". $R["Drzavljanstvo"] ."</td>";}
                        if ($Polje[38]){ echo "<td>". $R["uciducenec"] ."</td>";}
                        if ($Polje[39]){ 
                            if (file_exists($R["slika"])){
                                echo "<td><img src='". $R["slika"] ."' width='100'></td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                        }
                        if ($Polje[40]){ echo "<td>". $Razrednik ."</td>";}
                        if ($Polje[22]){ echo "<td>". $R["Opombe"] ."</td>";}
                        if ($Polje[21]){ echo "<td>&nbsp;</td>";}
                        if (strlen($_POST["dejavnost"]) > 0){ echo "<td><input type='checkbox'></td>";}
                        echo "</tr>";
                        $Indx=$Indx+1;
                    }

                    echo "</table>";
                    echo "<br>Fantov: ".$StFantje.", Deklet: ".$StDekleta;
                }
                $_SESSION["leto"]=$VLeto;
                if ($StR == 1){
                    $_SESSION["razred"]=$VRazred;
                }
                $_SESSION["paralelka"]=$VParalelka;
                $_SESSION["devetletka"]=$VDevetletka;
                $_SESSION["ucitelj"]=$IdUcitelj;
                $_SESSION["vzgojitelj"]=$IdVzgojitelj;
                break;
            default:
                $SQL = "SELECT tabrazdat.* FROM ";
                $SQL = $SQL . "tabrazred INNER JOIN tabrazdat ON tabrazred.idRazred=tabrazdat.id ";
                $SQL = $SQL . "WHERE tabrazdat.leto=".$VLeto." AND idUcitelj=".$VIdRazrednik;
                $result = mysqli_query($link,$SQL);

                if ($R = mysqli_fetch_array($result)){
                    $VIdRazred=$R["id"];
                }else{
                    $VIdRazred=0;
                }
                echo "<form name='rezultati' method='post' action='izborrazredaizbor.php'>";
                echo "<input name='id' type='hidden' value='1'>";
                echo "<h2>Izberite razred</h2><br>";
                echo "<table border=0>";
                echo "<tr>";
                echo "    <td>";
                echo "        Šolsko leto: ".$VLeto."/".($VLeto+1)."<input type='hidden' name='leto' value='".$VLeto."'>";
                /*        echo "        Šolsko leto: <select name='leto'>";
                echo "<option value='" .  $VLeto  . "' selected>" . $VLeto . "/"  . ($VLeto+1) . "</option>";
                echo "<option value='" .  ($VLeto-1)  . "'>" . ($VLeto -1) . "/"  . ($VLeto) . "</option>";
                echo "<option value='" .  ($VLeto +1) . "'>" . ($VLeto +1) . "/"  . ($VLeto+2) . "</option>";
                echo "        </select>";*/
                echo "    </td>";
                echo "</tr>";
                if ($VLeto < 2008 ){
                    echo "<tr>";
                    echo "<td>";
                    echo "8-/9-letka:<select name='vrstaos'>";
                    echo "<option value='9' selected>devetletka</option>";
                    echo "<option value='8'>osemletka</option>";
                    echo "</select>";
                    echo "</td>";
                    echo "</tr>";
                }else{
                    echo "<input name='vrstaos' type='hidden' value='9'>";
                }

                echo "<tr>";
                //echo "<td>Razred:<select name='razred'>";
                echo "<td>Razred: <br /><select name='razred[]' multiple='multiple' size='6'>";
                if ($VecSol > 0){
                    $SQL = "SELECT tabrazdat.id,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.idsola,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." ORDER BY tabrazdat.idsola,razred,oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($VIdRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
                        }
                    }
                }else{
                    $SQL = "SELECT id,razred,oznaka FROM tabrazdat WHERE leto=".$VLeto." ORDER BY razred,oznaka";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
                        if ($VIdRazred==$R["id"] ){
                            echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }else{
                            echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
                        }
                    }
                }
                echo "<option value='0'>Vsi</option>";
                echo "</select><br />(S Ctrl+klik lahko izberete več razredov)<br /><input name='porazredih' type='checkbox' > Razvrsti po razredih";
                echo "</td>";
                echo "</tr>";
                
                echo "<tr><td><b>Izberi polja za izpis:</b></td></tr>";
                echo "<tr>";
                echo "<td><input name='polje1' type='checkbox' >Mat. številka</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje31' type='checkbox' >Mat. knjiga</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje2' type='checkbox' checked>Priimek in ime</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje9' type='checkbox' >Spol</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje3' type='checkbox' >Datum rojstva</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje29' type='checkbox' >Kraj rojstva</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje30' type='checkbox' >Država rojstva</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje4' type='checkbox' >Naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje5' type='checkbox' >Pošta</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje6' type='checkbox' >Kraj</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje35' type='checkbox' >Izpiši začasno bivališče namesto stalnega (če je vpisano)</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje41' type='checkbox' >Zač. naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje42' type='checkbox' >Zač. pošta</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje43' type='checkbox' >Zač. kraj</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje37' type='checkbox' >Telefon doma</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje7' type='checkbox' >Oče</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje13' type='checkbox' >Očetov naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje44' type='checkbox' >Očetov zač. naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje14' type='checkbox' >Očetov kontaktni telefon</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje32' type='checkbox' >Očetov e-mail</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje8' type='checkbox' >Mati</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje15' type='checkbox' >Materin naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje45' type='checkbox' >Materin zač. naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje16' type='checkbox' >Materin kontaktni telefon</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje33' type='checkbox' >Materin e-mail</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje23' type='checkbox' >Skrbnik</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje24' type='checkbox' >Skrbnikov naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje25' type='checkbox' >Skrbnikov kontaktni telefon</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje34' type='checkbox' >Skrbnikov e-mail</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje26' type='checkbox' >Plačnik</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje27' type='checkbox' >Plačnikov naslov</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje28' type='checkbox' >Plačnikov kontaktni telefon</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje11' type='checkbox' >EMŠO</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje12' type='checkbox' >Evidenčna št.</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje17' type='checkbox' >Bivanje (pri starših, pri mami, pri očetu, ...)</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje18' type='checkbox' >Rom</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje19' type='checkbox' >Posebne potrebe</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje20' type='checkbox' >Državljanstvo</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje22' type='checkbox' >Opombe</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje36' type='checkbox' >Šolski okoliš</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje38' type='checkbox' >ID številka v Kadrih</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje39' type='checkbox' >Slika</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje40' type='checkbox' >Razrednik</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje21' type='checkbox' >Podpis (prazno polje)</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='dejavnost' type='text' size='40'>Dejavnost (naslov izpisa + kljukice za prisotnost)</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='polje10' type='checkbox' >Razvrščanje po spolu</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td><input name='dato' type='checkbox' >Pripravi CSV datoteko</td>";
                echo "</tr>";
                echo "<tr>";
                echo "    <td>";
                echo "        <input name='submit' type='submit' value='Pošlji'>";
                echo "    </td>";
                echo "</tr>";
                echo "</table>";
                echo "</form>";
        }
    }
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
?>    
</body>
</html>
