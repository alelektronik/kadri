<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Pregled dela
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
        new JsDatePick({
            useMode:2,
            target:"dat02",
            dateFormat:"%d.%m.%Y",
            yearsRange:[2000,2080],
            limitToToday:false
        });
    };
</script>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}
if (isset($_POST["iducitelj"])){
    $ucitelj=$_POST["iducitelj"];
}else{
    if (isset($_GET["iducitelj"])){
        $ucitelj=$_GET["iducitelj"];
    }else{
        if (isset($_SESSION["iducitelj"])){
            $ucitelj=$_SESSION["iducitelj"];
        }else{
            $ucitelj=0;
        }
    }
}

//echo "Leto: ".$VLeto."<br />";
//require("FormPDNVsi.php");

if (strlen($Vid) > 0){
    $SQL = "SELECT * FROM tabpregleddelan WHERE id=".$Vid;
    $result = mysqli_query($link,$SQL);
    
    if ($R = mysqli_fetch_array($result)){
        $VPregledLeto=$R["Leto"];
        $VMesec=$R["Mesec"];
        $VDan=$R["Dan"];
        $VRubrika=$R["Rubrika"];
        $VMKomentar=$R["Komentar"];
        $Vcas=$R["Enot"];
        $VEnotPotrjeno=$R["EnotPotrjeno"];
    }else{
        if (isset($_POST["leto"])){
            $VPregledLeto=$_POST["leto"];
        }else{
            $VPregledLeto=$Danes->format('Y');
        }
        if (isset($_POST["mesec"])){
            $VMesec=$_POST["mesec"];
        }else{
            $VMesec=$Danes->format('n');
        }
        if (isset($_POST["dan"])){
            $VDan=$_POST["dan"];
        }else{
            $VDan=$Danes->format('j');
        }
        if (isset($_POST["rubrika"])){
            $VRubrika=$_POST["rubrika"];
        }else{
            $VRubrika=9;
        }
        if (isset($_POST["MKomentar"])){
            $VMKomentar=$_POST["MKomentar"];
        }else{
            $VMKomentar="";
        }
        $VEnotPotrjeno=false;
        if (isset($_POST["cas"])){
            $Vcas=$_POST["cas"];
        }else{
            $Vcas="";
        }
    }
}else{
    if (isset($_POST["leto"])){
        $VPregledLeto=$_POST["leto"];
    }else{
        $VPregledLeto=$Danes->format('Y');
    }
    if (isset($_POST["mesec"])){
        $VMesec=$_POST["mesec"];
    }else{
        $VMesec=$Danes->format('n');
    }
    if (isset($_POST["dan"])){
        $VDan=$_POST["dan"];
    }else{
        $VDan=$Danes->format('j');
    }
    if (isset($_POST["rubrika"])){
        $VRubrika=$_POST["rubrika"];
    }else{
        $VRubrika=9;
    }
    if (isset($_POST["MKomentar"])){
        $VMKomentar=$_POST["MKomentar"];
    }else{
        $VMKomentar="";
    }
    if (isset($_POST["cas"])){
        $Vcas=$_POST["cas"];
    }else{
        $Vcas="";
    }
    $VEnotPotrjeno=false;
}

$elementov=0;
$SQL = "SELECT * FROM TabDoprinos ORDER BY sortiranje DESC";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $elementov=$R["sortiranje"];
}
switch ($VLevel){
    case 2:
    case 3:
        $SQL = "SELECT * FROM TabDoprinos ORDER BY sortiranje ";
        break;
    case 0:
    case 1:
        $SQL = "SELECT * FROM TabDoprinos WHERE aktivno < 2 ORDER BY sortiranje ";
}
$result = mysqli_query($link,$SQL);
while ($R = mysqli_fetch_array($result)){
    $AktivnaRubrika[$R["sortiranje"]][0]=$R["idDoprinos"];
    $AktivnaRubrika[$R["sortiranje"]][1]=$R["OblikaDelaKratko"];
    $AktivnaRubrika[$R["sortiranje"]][2]=$R["OblikaDela"];
    $AktivnaRubrika[$R["sortiranje"]][3]=$R["aktivno"];
    $AktivnaRubrika[$R["sortiranje"]][4]=$R["uramin"];
    $AktivnaRubrika[$R["sortiranje"]][5]=$R["koeficient"];
    $AktivnaRubrika[$R["sortiranje"]][6]=$R["addsub"];
    $AktivnaRubrika[$R["sortiranje"]][7]=$R["spremenljivka"];
    if ($AktivnaRubrika[$R["sortiranje"]][0]==$VRubrika){
        $VSRubrika=$AktivnaRubrika[$R["sortiranje"]][2];
    }
}

if (($VLevel < 2) && $VEnotPotrjeno){
    echo "<h2>Potrjenih podatkov ne morete popravljati!</h2>";
}else{
    echo "<br><form name='PregledDela' method=post action='VpisPDNVsi.php'>";

    echo "<table border='1'>";
    echo "<tr><td>Datum</td><td>";
    /*
    echo " Dan: <select name='dan'>";
    echo "<option selected>".$VDan."</option>";
    for ($Indx=1;$Indx <= 31;$Indx++){
        echo "<option>".$Indx."</option>";
    }
    echo "</select>";
    echo " Mesec: <select name='mesec'><option selected>". $VMesec ."</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option></select>";
    echo "Leto: <select name='leto'><option selected>". $VPregledLeto ."</option><option>". ($VPregledLeto-1) ."</option><option>". ($VPregledLeto+1) ."</option></select>";
    */
    $DatumOd=new DateTime($VLetoPregled."-".$VMesec."-".$VDan);
    echo "<input name='datod' type='text' size='10' value='".$DatumOd->format('d.m.Y')."' id='dat01'>";
    echo "</td></tr>";
    echo "<tr><td>Rubrika</td><td>";
    echo "<select name='rubrika'>";
    echo "<option selected value='".$VRubrika."'>".$VSRubrika."</option>";
    for ($Indx=1;$Indx <= $elementov;$Indx++){
        if (isset($AktivnaRubrika[$Indx][3])){
            if ($AktivnaRubrika[$Indx][3] > 0){
                if ($AktivnaRubrika[$Indx][4] > 1){
                    echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (min)</option>";
                }else{
                    switch ($AktivnaRubrika[$Indx][5]){
                        case 0:
                        case 4:
                        case 8:
                            if ($AktivnaRubrika[$Indx][3] != 19){
                                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (dni)</option>";
                            }else{
                                echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (%)</option>";
                            }
                            break;
                        default:
                            echo "<option value='".$AktivnaRubrika[$Indx][0]."'>".$AktivnaRubrika[$Indx][2]." (ur)</option>";
                    }
                }
            }
        }
    }
    echo "</tr>";
    if ($VLevel < 2){
        echo "<tr><td>Enot (ur/min/dni/%):</td><td><input name='cas' type='text' size='5' value='". $Vcas ."'> Enot NE pišite (so privzete iz rubrike). Lahko pišete z decimalkami (npr. 2,33).</td></tr>";
    }else{
        echo "<tr><td>Enot (ur/min/dni/%):</td><td><input name='cas' type='text' size='5' value='". $Vcas ."'>";
        /*
        echo " do Dan: <select name='danK'>";
        echo "<option selected>1</option>";
        for ($Indx=1;$Indx <= 31;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
        echo " Mesec: <select name='mesecK'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            echo "<option>".$Indx."</option>";
        }
        echo "</select>";
        echo "Leto: <select name='letoK'><option selected>". $VPregledLeto ."</option><option>".($VPregledLeto-1) ."</option><option>". ($VPregledLeto+1) ."</option></select><br />";
        */
        $DatumDo=new DateTime(($VLetoPregled-1)."-1-1");
        echo " do datuma: <input name='datdo' type='text' size='10' value='".$DatumDo->format('d.m.Y')."' id='dat02'>";
        echo "<br />";
        echo "Za vnos <b>dnevnih</b> rubrik <b>do datuma</b> pustite število enot prazno in izberite ustrezen datum.<br />";
        echo "Za vnos <b>urnih in minutnih</b> rubrik <b>do datuma</b> mora biti končni datum večji od začetnega.";
        echo "</td></tr>";
    }
    echo "<tr>";
    echo "<td>Moj komentar <br>(čim krajši - do 50 znakov)</td>";
    echo "<td><textarea name='MKomentar' cols='65' rows='3'>". $VMKomentar ."</textarea>";
    echo "<input type='hidden' name='id' value='". $Vid ."'></td>";
    echo "</tr>";
    if ($VLevel > 1){
        if ($VEnotPotrjeno){
            echo "<tr><td><input name='EnotPotrjeno' type='checkbox' checked> Potrjen vnos</td></tr>";
        }else{
            echo "<tr><td><input name='EnotPotrjeno' type='checkbox'> Potrjen vnos</td></tr>";
        }
    }
    echo "</table><br />";

    echo "<table border='1'>";
    echo "<tr><th>Št.</th><th>Učitelj</th><th>Sprememba</th></tr>";
    $SQL = "SELECT * FROM tabucitelji WHERE Status > 0 ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);

    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>".$Indx."</td>";
        echo "<td><input type='hidden' name='uc".$Indx."' value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</td>";
        echo "<td><input type='checkbox' name='sprem".$Indx."'></td>";
        echo "</tr>";
        $Indx=$Indx+1;
    }
    echo "</table><br />";
    echo "<input type='hidden' name='StUciteljev' value='".($Indx-1)."'>";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "<input name='gumb' type='button' value='Označi vse' onClick='OznaciVse(this.form)'>";
    echo "<input name='gumbreset' type='button' value='Briši vse' onClick='BrisiVse(this.form)'><br />";
    echo "</form><br />";
}

?>

<a href="pravilnik.htm">Pravilnik</a><br>
<script language="JavaScript">
function OznaciVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=true;
    }
}
function BrisiVse(form){
    for (i=1; i < form.elements.length; i++) {
        form.elements[i].checked=false;
    }
}
</script>

</body>
</html>
