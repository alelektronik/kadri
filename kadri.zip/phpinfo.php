<?php
     echo phpinfo();
?>