<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" >
<title>Naročilnice
</title>
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
    window.onload = function(){
        var Danes = new Date();
        new JsDatePick({
            useMode:2,
            target:"dat01",
            dateFormat:"%j.%n.%Y",
            yearsRange:[1940,2080],
            limitToToday:true
        });
    };
</script>
</head>
<body>

<?php
function ImeMeseca($m){
    switch ($m){
        case 1:
            return "januar";
        case 2:
            return "februar";
        case 3:
            return "marec";
        case 4:
            return "april";
        case 5:
            return "maj";
        case 6:
            return "junij";
        case 7:
            return "julij";
        case 8:
            return "avgust";
        case 9:
            return "september";
        case 10:
            return "oktober";
        case 11:
            return "november";
        case 12:
            return "december";
    }
}

$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Tajn",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{
        
    if (isset($_POST["id"])){
        $Vid=$_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid="";
        }
    }
    function CheckNarocilnica($d){
        global $StZapisov,$Zapisi;
	    for ($Indx=1;$Indx <= $StZapisov;$Indx++){
		    if ($Zapisi[$Indx][0]->format('Y-m-d')==$d->format('Y-m-d')){
			    return true;
		    }
	    }
        return false;
    }

    $Obdelava=$Vid;
    $SQL = "SELECT * FROM tabsola";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $VSola=$R["SolaKratko"];
        $VSolaNaslov=$R["Naslov"];
        $VSolaKraj=$R["Kraj"];
        $VSolaPosta=$R["Posta"];
        $VRavnatelj=$R["Ravnatelj"];
        $IDRavnatelj=$R["ravnatelj_ID"];
        $VDavcna=$R["ddv_ID"];
        $VZavezanec=$R["zavezanecDDV"];
    }else{
        $VSola="";
        $VSolaNaslov="";
        $VSolaKraj="";
        $VSolaPosta="";
        $VRavnatelj="";
        $IDRavnatelj=0;
        $VDavcna="";
        $VZavezanec="";
    }

    $SQL = "SELECT spol FROM tabucitelji WHERE iducitelj=".$IDRavnatelj;
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
        $Spol=$R["spol"];
    }else{
        $Spol="M";
    }

    switch ($Obdelava){
        case "2":
            break;
        default:
            $n=$VLevel;
            include('menu_func.inc');
            include ('menu.inc');
    }
        
    switch ($Obdelava){
	    case "1": // 'vnos naročilnice
		    $SQL = "SELECT zapst FROM tabnarocilnica WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt DESC LIMIT 0,1";
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    $VZapSt=$R["zapst"];
			    if (is_numeric($VZapSt) ){
				    $VZapSt=$VZapSt+1;
			    }else{
                    $VZapSt=1;
                }
		    }else{
			    $VZapSt=1;
		    }
		    $VZnesek=0.00;
		    
		    echo "<h2>Vnos naročilnice</h2>";
		    echo "<form name='Narocilnica' method='post' action='VnosNarocilnica.php'>";
		    echo "<table border='1' cellspacing='0'>";
		    echo "<tr><td>Zap. št.</td><td><input name='ZapSt' type='text' size='6' value='".$VZapSt."'>/".$Danes->format('Y')."</td></tr>";
		    echo "<tr><td>Izdajatelj</td><td><input name='Izdajatelj' type='text' size='50' value='".$VSola.", ".$VSolaNaslov.", ".$VSolaPosta." ".$VSolaKraj."'></td></tr>";
		    echo "<tr><td>Datum</td><td><input name='DatumIzd' type='text' size='8' value='".$Danes->format('j.n.Y')."' id='dat01'></td></tr>";
		    echo "<tr><td>Kraj</td><td><input name='Kraj' type='text' size='20' value='".$VSolaKraj."'></td></tr>";
		    echo "<tr><td>Davčna št.</td><td><input name='Davcna' type='text' size='8' value='".$VDavcna."'></td></tr>";
		    if ($VZavezanec=="DA"){
			    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox' checked></td></tr>";
		    }else{
			    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox'></td></tr>";
		    }
		    echo "<tr><td>Dobavitelj</td><td><input name='Dobavitelj' type='text' size='50'><br />";
            $SQL = "SELECT DISTINCT dobavitelj FROM tabnarocilnica WHERE leto >= ".(intval($Danes->format('Y'))-1)." ORDER BY dobavitelj";
            $result = mysqli_query($link,$SQL);
            echo "<select name='dobavitelj1'>";
            echo "<option>Ni izbran</option>";
            while ($R = mysqli_fetch_array($result)){
                echo "<option>".$R["dobavitelj"]."</option>";
            }
            echo "</select>";
            echo "</td></tr>";
            
		    echo "<tr><td>Naslovnik</td><td><input name='Naslovnik' type='text' size='50' value='".$VSola.", ".$VSolaNaslov.", ".$VSolaPosta." ".$VSolaKraj."'></td></tr>";
		    echo "<tr><td>Naročil</td><td><input name='Narocil' type='text' size='40' value='".$VRavnatelj;
            if ($Spol == "M"){
                echo ", ravnatelj";
            }else{
                echo ", ravnateljica";
            }
            echo "'></td></tr>";
		    echo "<tr><td>Naročilo</td><td><textarea name='VrstaBlaga' cols='40' rows='3'></textarea></td></tr>";
		    echo "<tr><td>Interni naročnik</td><td><input name='InterniNarocnik' type='text' size='40'></td></tr>";
		    echo "<tr><td>Okvirni znesek</td><td><input name='Znesek' type='text' size='10' value='".number_format($VZnesek,2)."'></td></tr>";
		    if ($ObvestiloPolicije==true ){
			    echo "<tr><td>Prevoz za učence<br>Sporočilo na policijo</td><td><input name='email' type='checkbox'></td></tr>";
		    }
		    echo "</table>";
		    echo "<input name='id' type='hidden' value='2'>";
		    echo "<input name='submit' type='submit' value='Pošlji'>";
		    echo "</form>";
            break;
	    case "2": // 'vpis zapisa
            if (isset($_POST["ZapSt"])){
		        $VZapSt=$_POST["ZapSt"];
		        if (strpos($VZapSt,"/") >= 0){
                    $astr=explode("/",$VZapSt);
			        $VZapSt=$astr[0];
		        }
            }else{
                $VZapSt=1;
            }
            if (isset($_POST["Izdajatelj"])){
		        $VIzdajatelj=$_POST["Izdajatelj"];
            }else{
                $VIzdajatelj="";
            }    
            if (isset($_POST["Davcna"])){
                $VDavcna=$_POST["Davcna"];
            }else{
                $VDavcna="";
            }    
		    if (isset($_POST["Zavezanec"])){
		        $VZavezanec="true";
		    }else{
			    $VZavezanec="false";
		    }
            if (isset($_POST["DatumIzd"])){
        	    $VDatumIzd=isDate($_POST["DatumIzd"]);
                if (!$VDatumIzd){
                    $VDatumIzd=$Danes->format('j.n.Y');
                }else{
                    $VDatumIzd=$_POST["DatumIzd"];
                }
            }else{
                $VDatumIzd=$Danes->format('j.n.Y');
            }
            if (isset($_POST["Kraj"])){
                $VKraj=$_POST["Kraj"];
            }else{
                $VKraj="";
            }
            if (isset($_POST["dobavitelj1"])){
                if ($_POST["dobavitelj1"] == "Ni izbran"){
                    if (isset($_POST["Dobavitelj"])){
                        $VDobavitelj=$_POST["Dobavitelj"];
                    }else{
                        $VDobavitelj="";
                    }
                }else{
                    $VDobavitelj=$_POST["dobavitelj1"];
                }
            }else{    
                if (isset($_POST["Dobavitelj"])){
                    $VDobavitelj=$_POST["Dobavitelj"];
                }else{
                    $VDobavitelj="";
                }
            }
            if (isset($_POST["Naslovnik"])){
                $VNaslovnik=$_POST["Naslovnik"];
            }else{
                $VNaslovnik="";
            }    
            if (isset($_POST["VrstaBlaga"])){
                $VVrstaBlaga=$_POST["VrstaBlaga"];
                $VVrstaBlaga=str_replace("'","",$VVrstaBlaga);
                $VVrstaBlaga=str_replace(chr(34),"",$VVrstaBlaga);
            }else{
                $VVrstaBlaga="";
            }    
            if (isset($_POST["Narocil"])){
                $VNarocil=$_POST["Narocil"];
            }else{
                $VNarocil="";
            }    
            if (isset($_POST["InterniNarocnik"])){
                $VInterniNarocnik=$_POST["InterniNarocnik"];
            }else{
                $VInterniNarocnik="";
            }    
            if (isset($_POST["Znesek"])){
                $VZnesek=str_replace(",",".",$_POST["Znesek"]);
                if (!is_numeric($VZnesek)){
                    $VZnesek=0.00;
                }
            }else{
                $VZnesek=0.00;
            }    
		    
		    $SQL = "SELECT * FROM TabNarocilnica WHERE leto=".$Danes->format('Y')." AND ZapSt=".$VZapSt;
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    echo "<h2>Zapis z Zap. št. ".$VZapSt." že obstaja. NI vpisa!</h2>";
		    }else{
			    $SQL = "INSERT INTO TabNarocilnica (leto,ZapSt,Izdajatelj,Davcna,Zavezanec,Kraj,DatumIzd,Dobavitelj,Naslovnik,Narocil,VrstaBlaga,vpisal,cas,znesek,interniNarocnik)";
			    $SQL = $SQL . " VALUES (";
                $SQL = $SQL . $Danes->format('Y');
                $SQL = $SQL .",".$VZapSt;
                $SQL = $SQL .",'".$VIzdajatelj."'";
                $SQL = $SQL .",'".$VDavcna."'";
                $SQL = $SQL .",".$VZavezanec;
                $SQL = $SQL .",'".$VKraj."'";
                $SQL = $SQL .",'".$VDatumIzd."'";
                $SQL = $SQL .",'".$VDobavitelj."'";
                $SQL = $SQL .",'".$VNaslovnik."'";
                $SQL = $SQL .",'".$VNarocil."'";
                $SQL = $SQL .",'".$VVrstaBlaga."'";
                $SQL = $SQL .",'".$VUporabnik."'";
                $SQL = $SQL .",'".$Danes->format('Y-m-d H:i:s')."'";
                $SQL = $SQL .",".$VZnesek;
                $SQL = $SQL .",'".$VInterniNarocnik."')";
			    if (!($result = mysqli_query($link,$SQL))){
                    die("Napaka pri vpisu naročilnice: ".$SQL."<br />");
                }
		    }
		    
		    if ($ObvestiloPolicije==true ){
			    if (isset($_POST["email"])){
                    require_once('class.phpmailer.php');

                    $address = $EmailPolicija;
                    
                    $mail             = new PHPMailer();

                    //$body             = file_get_contents('contents.html');
                    //$body             = eregi_replace("[\]",'',$body);

                    $mail->IsSMTP(); // telling the class to use SMTP
                    $mail->Host       = "mail.gmail.com"; // SMTP server
                    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                                               // 1 = errors and messages
                                                               // 2 = messages only
                    $mail->SMTPAuth   = true;                  // enable SMTP authentication
                    $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                    $mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
                    $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                    $mail->Username   = "mail.kadri.send@gmail.com";  // GMAIL username
                    $mail->Password   = "k4dr1S3ndm41l";            // GMAIL password

                    $mail->SetFrom("$EmailRavnatelj", "$EmailRavnatelj");

                    $mail->AddReplyTo("$EmailRavnatelj","$EmailRavnatelj");

                    $mail->Subject    = $VSola." - prevozi otrok";


                    $body="Spoštovani,\n\nNaročilo prevoza za učence:\n\n".$VDobavitelj.": \n".$VVrstaBlaga."\n\nLep pozdrav,\n\n".$VNarocil;
                    $mail->AltBody    = $body;
                    
                    $body = str_replace("\n","<br />",$body);
                    $mail->MsgHTML($body);

                    //$address = "whoto@otherdomain.com";
                    //$mail->AddAddress($address, "John Doe");

                    //$mail->AddAttachment("images/phpmailer.gif");      // attachment
                    //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
                    
                    
                    $mail->AddAddress($address, $address);
                    
    //                $body="Spoštovani,\n\nRok za vnos podatkov: ".$Vopravila[$indx][1]." je ".$Vopravila[$indx][3].".\n\n"."Lep pozdrav,\n\n".$VRavnatelj;
                    if(!$mail->Send()) {
                      echo "Napaka pri pošiljanju: " . $mail->ErrorInfo;
                    } else {
                      echo "Sporočilo poslano na: ".$address;
                    }
                    $mail=null;
			    }
		    }
		    header("Location: VnosNarocilnica.php?id=1");
            break;
	    case "3": // 'popravljanje
		    $SQL = "SELECT * FROM TabNarocilnica WHERE id=".$_GET["zapis"];
		    $result = mysqli_query($link,$SQL);
		    
		    if ($R = mysqli_fetch_array($result)){
			    echo "<h2>Popravljanje naročilnice</h2>";
			    echo "<form name='Narocilnica' method=post action='VnosNarocilnica.php'>";
			    echo "<table border='1'>";
			    echo "<tr><td>Zap. št.</td><td><input name='ZapSt' type='text' size='6' value='".$R["ZapSt"]."'>/".$R["leto"]."<input name='letoN' type='hidden' value='".$R["leto"]."'></td></tr>";
			    echo "<tr><td>Izdajatelj</td><td><input name='Izdajatelj' type='text' size='50' value='".$R["Izdajatelj"]."'></td></tr>";
                $Datum=new DateTime(isDate($R["DatumIzd"]));
                
			    echo "<tr><td>Datum</td><td><input name='DatumIzd' type='text' size='8' value='".$Datum->format('j.n.Y')."' id='dat01'></td></tr>";
			    echo "<tr><td>Kraj</td><td><input name='Kraj' type='text' size='20' value='".$R["Kraj"]."'></td></tr>";
			    echo "<tr><td>Davčna št.</td><td><input name='Davcna' type='text' size='8' value='".$R["Davcna"]."'></td></tr>";
			    if ($R["Zavezanec"] ){
				    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox' checked></td></tr>";
			    }else{
				    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox'></td></tr>";
			    }
			    echo "<tr><td>Dobavitelj</td><td><input name='Dobavitelj' type='text' size='50' value='".$R["Dobavitelj"]."'><br />";

                $SQL = "SELECT DISTINCT dobavitelj FROM tabnarocilnica WHERE leto >= ".(intval($Danes->format('Y'))-1)." ORDER BY dobavitelj";
                $result1 = mysqli_query($link,$SQL);
                echo "<select name='dobavitelj1'>";
                echo "<option>Ni izbran</option>";
                while ($R1 = mysqli_fetch_array($result1)){
                    echo "<option>".$R1["dobavitelj"]."</option>";
                }
                echo "</select>";

                echo "</td></tr>";
			    echo "<tr><td>Naslovnik</td><td><input name='Naslovnik' type='text' size='50' value='".$R["Naslovnik"]."'></td></tr>";
			    echo "<tr><td>Naročil</td><td><input name='Narocil' type='text' size='40' value='".$R["Narocil"]."'></td></tr>";
			    echo "<tr><td>Naročilo</td><td><textarea name='VrstaBlaga' cols='40' rows='3'>".$R["VrstaBlaga"]."</textarea></td></tr>";
			    echo "<tr><td>Interni naročnik</td><td><input name='InterniNarocnik' type='text' size='40' value='".$R["InterniNarocnik"]."'></td></tr>";
			    echo "<tr><td>Okvirni znesek</td><td><input name='Znesek' type='text' size='40' value='".$R["znesek"]."'></td></tr>";
			    echo "</table>";
			    echo "<input name='id' type='hidden' value='4'>";
			    echo "<input name='zapis' type='hidden' value='".$_GET["zapis"]."'>";
			    echo "<input name='submit' type='submit' value='Pošlji'>";
			    echo "</form>";
		    }
            break;
	    case "4": //vpis popravka
	        if (isset($_POST["ZapSt"])){
                $VZapSt=$_POST["ZapSt"];
                if (strpos($VZapSt,"/") >= 0){
                    $astr=explode("/",$VZapSt);
                    $VZapSt=$astr[0];
                }
            }else{
                $VZapSt=1;
            }
            if (isset($_POST["Izdajatelj"])){
                $VIzdajatelj=$_POST["Izdajatelj"];
            }else{
                $VIzdajatelj="";
            }    
            if (isset($_POST["Davcna"])){
                $VDavcna=$_POST["Davcna"];
            }else{
                $VDavcna="";
            }    
            if (isset($_POST["Zavezanec"])){
                $VZavezanec="true";
            }else{
                $VZavezanec="false";
            }
            if (isset($_POST["DatumIzd"])){
                $VDatumIzd=isDate($_POST["DatumIzd"]);
                if (!$VDatumIzd){
                    $VDatumIzd=$Danes->format('j.n.Y');
                }else{
                    $VDatumIzd=$_POST["DatumIzd"];
                }
            }else{
                $VDatumIzd=$Danes->format('j.n.Y');
            }
            if (isset($_POST["Kraj"])){
                $VKraj=$_POST["Kraj"];
            }else{
                $VKraj="";
            }    
            if (isset($_POST["dobavitelj1"])){
                if ($_POST["dobavitelj1"] == "Ni izbran"){
                    if (isset($_POST["Dobavitelj"])){
                        $VDobavitelj=$_POST["Dobavitelj"];
                    }else{
                        $VDobavitelj="";
                    }
                }else{
                    $VDobavitelj=$_POST["dobavitelj1"];
                }
            }else{    
                if (isset($_POST["Dobavitelj"])){
                    $VDobavitelj=$_POST["Dobavitelj"];
                }else{
                    $VDobavitelj="";
                }
            }
            if (isset($_POST["Naslovnik"])){
                $VNaslovnik=$_POST["Naslovnik"];
            }else{
                $VNaslovnik="";
            }    
            if (isset($_POST["VrstaBlaga"])){
                $VVrstaBlaga=$_POST["VrstaBlaga"];
                $VVrstaBlaga=str_replace("'","",$VVrstaBlaga);
                $VVrstaBlaga=str_replace(chr(34),"",$VVrstaBlaga);
            }else{
                $VVrstaBlaga="";
            }    
            if (isset($_POST["Narocil"])){
                $VNarocil=$_POST["Narocil"];
            }else{
                $VNarocil="";
            }    
            if (isset($_POST["InterniNarocnik"])){
                $VInterniNarocnik=$_POST["InterniNarocnik"];
            }else{
                $VInterniNarocnik="";
            }    
            if (isset($_POST["Znesek"])){
                $VZnesek=str_replace(",",".",$_POST["Znesek"]);
                if (!is_numeric($VZnesek)){
                    $VZnesek=0.00;
                }
            }else{
                $VZnesek=0.00;
            }    
    	    
		    $SQL = "SELECT leto FROM tabnarocilnica WHERE id=".$_POST["zapis"];
		    $result = mysqli_query($link,$SQL);
		    if ($R = mysqli_fetch_array($result)){
			    $VLeto1=$R["leto"];
		    }else{
			    $VLeto1=$VLeto;
		    }
		    
		    $SQL = "UPDATE TabNarocilnica SET ";
		    $SQL =$SQL . "leto=".$VLeto1.",";
		    $SQL =$SQL . "ZapSt=".$VZapSt.",";
		    $SQL =$SQL . "Izdajatelj='".$VIzdajatelj."',";
		    $SQL =$SQL . "Davcna='".$VDavcna."',";
		    $SQL =$SQL . "Zavezanec=".$VZavezanec.",";
		    $SQL =$SQL . "Kraj='".$VKraj."',";
		    $SQL =$SQL . "DatumIzd='".$VDatumIzd."',";
		    $SQL =$SQL . "Dobavitelj='".$VDobavitelj."',";
		    $SQL =$SQL . "Naslovnik='".$VNaslovnik."',";
		    $SQL =$SQL . "Narocil='".$VNarocil."',";
		    $SQL =$SQL . "VrstaBlaga='".$VVrstaBlaga."',";
		    $SQL =$SQL . "vpisal='".$VUporabnik."',";
		    $SQL =$SQL . "znesek=".$VZnesek.",";
		    $SQL =$SQL . "InterniNarocnik='".$VInterniNarocnik."',";
		    $SQL =$SQL . "cas='".$Danes->format('Y-m-d H:i:s')."' ";
		    $SQL =$SQL . "WHERE id=".$_POST["zapis"];
		    if (!($result = mysqli_query($link,$SQL))){
                die("Napaka pri popravku naročilnice: ".$SQL."<br />");
            }
            break;
	    case "5": //izpis naročilnic izdanih na določen datum
            $Datum=isDate($_GET["datum"]);
            if (!$Datum){
                $Datum=new DateTime("now");
            }else{
                $Datum=new DateTime($Datum);
            }    
 		    $SQL = "SELECT * FROM TabNarocilnica WHERE DatumIzd='".$Datum->format('j.n.Y')."' ORDER BY ZapSt";
		    $result = mysqli_query($link,$SQL);

		    echo "<h2>Izpis naročilnic - ".$Datum->format('d.m.Y')."</h2>";
		    echo "<br><table border='1'>";
		    echo "<tr><th>Popravi</th><th>Natisni</th><th>št.</th><th>Izdajatelj</th><th>Datum</th><th>Dobavitelj</th><th>Naročilo</th><th>Znesek</th><th>Interni<br />naročnik</th></tr>";
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td><a href='VnosNarocilnica.php?id=3&zapis=".$R["id"]."'>Popravi</a></td><td><a href='NarocilnicaPDF.php?id=".$R["id"]."'>Natisni</a></td>";
			    echo "<td>".$R["ZapSt"]."/".$R["leto"]."</td>";
			    echo "<td>".$R["Izdajatelj"]."</td>";
			    echo "<td>".$R["DatumIzd"]."</td>";
			    echo "<td>".$R["Dobavitelj"]."</td>";
			    echo "<td>".$R["VrstaBlaga"]."</td>";
			    echo "<td>".number_format($R["znesek"],2,",",".")."</td>";
			    echo "<td>".$R["InterniNarocnik"]."</td>";
			    echo "</tr>";
		    }
		    echo "</table><br />";
            break;
	    case "6": //izpis naročilnic po iskalnem kriteriju
		    $SQL = "SELECT * FROM TabNarocilnica WHERE ";
		    $SQL = $SQL . "leto=".$_POST["letoisci"]." AND (";
		    $SQL = $SQL . "VrstaBlaga LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR Izdajatelj LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR Dobavitelj LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR Naslovnik LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR Narocil LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR Naslovnik LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR ZapSt LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR znesek LIKE '%".$_POST["iskanje"]."%'";
		    $SQL = $SQL . " OR InterniNarocnik LIKE '%".$_POST["iskanje"]."%')";
		    $SQL = $SQL . " ORDER BY ZapSt";
		    $result = mysqli_query($link,$SQL);
		    
		    echo "<h2>Izpis naročilnic - kriterij iskanja: ".$_POST["letoisci"].", ".$_POST["iskanje"]."</h2>";
		    $VZnesekSum=0;
		    echo "<br><table border='1' cellspacing='0'>";
		    echo "<tr><th>Popravi</th><th>Natisni</th><th>št.</th><th>Izdajatelj</th><th>Datum</th><th>Dobavitelj</th><th>Naročilo</th><th>Znesek</th><th>Interni<br />naročnik</th></tr>";
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td><a href='VnosNarocilnica.php?id=3&zapis=".$R["id"]."'>Popravi</a></td><td><a href='NarocilnicaPDF.php?id=".$R["id"]."'>Natisni</a></td>";
			    echo "<td>".$R["ZapSt"]."/".$R["leto"]."</td>";
			    echo "<td>".$R["Izdajatelj"]."</td>";
			    echo "<td>".$R["DatumIzd"]."</td>";
			    echo "<td>".$R["Dobavitelj"]."</td>";
			    echo "<td>".$R["VrstaBlaga"]."</td>";
			    if (is_numeric($R["znesek"]) ){
				    $VZnesekSum=$VZnesekSum+$R["znesek"];
				    echo "<td align=right>".number_format($R["znesek"],2,",",".")."</td>";
			    }else{
				    echo "<td align=right>0,00</td>";
			    }
			    echo "<td>".$R["InterniNarocnik"]."</td>";
			    echo "</tr>";
		    }
		    echo "<tr><td colspan='7'>Skupaj</td><td align='right'>".number_format($VZnesekSum,2,",",".")."</td></tr>";
		    echo "</table><br />";
            break;
	    case "7": //izpis naročilnic izdanih v določenem mesecu
		    $SQL = "SELECT * FROM TabNarocilnica WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt";
		    $result = mysqli_query($link,$SQL);

		    echo "<h2>Izpis naročilnic - ".ImeMeseca($_GET["mesec"])."</h2>";
		    echo "<br><table border='1'>";
		    echo "<tr><th>Popravi</th><th>Natisni</th><th>št.</th><th>Izdajatelj</th><th>Datum</th><th>Dobavitelj</th><th>Naroilo</th><th>Znesek</th><th>Interni<br />naročnik</th></tr>";
		    while ($R = mysqli_fetch_array($result)){
                $Datum=new DateTime(isDate($R["DatumIzd"]));
			    if ($Datum->format('n')==$_GET["mesec"]){
				    echo "<tr>";
				    echo "<td><a href='VnosNarocilnica.php?id=3&zapis=".$R["id"]."'>Popravi</a></td><td><a href='NarocilnicaPDF.php?id=".$R["id"]."'>Natisni</a></td>";
				    echo "<td>".$R["ZapSt"]."/".$R["leto"]."</td>";
				    echo "<td>".$R["Izdajatelj"]."</td>";
				    echo "<td>".$R["DatumIzd"]."</td>";
				    echo "<td>".$R["Dobavitelj"]."</td>";
				    echo "<td>".$R["VrstaBlaga"]."</td>";
				    echo "<td>".number_format($R["znesek"],2,",",".")."</td>";
				    echo "<td>".$R["InterniNarocnik"]."</td>";
				    echo "</tr>";
			    }
		    }
		    echo "</table><br />";
        case "8": //popravek datumov iz Y-n-j na j.n.Y
            $SQL = "SELECT id,leto,datumizd FROM TabNarocilnica WHERE leto >=2013 ORDER BY ZapSt";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                $Datum=new DateTime(isDate($R["datumizd"]));
                if (strpos($R["datumizd"],"-") > 0){
                    $SQL = "UPDATE tabnarocilnica SET datumizd='".$Datum->format('j.n.Y')."' WHERE id=".$R["id"];
                    if (!($result1 = mysqli_query($link,$SQL))){
                        echo "Težave pri popravkih id=".$R["id"]."<br />";
                    }else{
                        echo "Popravljen id=".$R["id"]."<br />";
                    }
                }
            }
            break;
    }

    switch ($Obdelava){
	    case "1":
        case "2":
        case "4":
		    $SQL = "SELECT * FROM TabNarocilnica WHERE leto=".$Danes->format('Y')." ORDER BY ZapSt DESC LIMIT 0,10";
		    $result = mysqli_query($link,$SQL);

		    echo "<h3>Zadnje izdane naročilnice</h3>";
		    $VZnesekSum=0;
		    echo "<br><table border='1' cellspacing='1'>";
		    echo "<tr><th>Popravi</th><th>Natisni</th><th>št.</th><th>Izdajatelj</th><th>Datum</th><th>Dobavitelj</th><th>Naročilo</th><th>Znesek</th><th>Interni<br />naročnik</th></tr>";
		    while ($R = mysqli_fetch_array($result)){
			    echo "<tr>";
			    echo "<td><a href='VnosNarocilnica.php?id=3&zapis=".$R["id"]."'>Popravi</a></td><td><a href='NarocilnicaPDF.php?id=".$R["id"]."'>Natisni</a></td>";
			    echo "<td>".$R["ZapSt"]."/".$R["leto"]."</td>";
			    echo "<td>".$R["Izdajatelj"]."</td>";
			    echo "<td>".$R["DatumIzd"]."</td>";
			    echo "<td>".$R["Dobavitelj"]."</td>";
			    echo "<td>".$R["VrstaBlaga"]."</td>";
			    if (is_numeric($R["znesek"]) ){
				    echo "<td align='right'>".number_format($R["znesek"],2,",",".")."</td>";
				    $VZnesekSum=$VZnesekSum+$R["znesek"];
			    }else{
				    echo "<td align='right'>0,00</td>";
			    }
			    echo "<td>".$R["InterniNarocnik"]."</td>";
			    echo "</tr>";
		    }
		    echo "<tr><td colspan='7'>Skupaj</td><td align='right'>".number_format($VZnesekSum,2,",",".")."</td></tr>";
		    echo "</table><br>";

		    echo "<a href='VnosNarocilnica.php?id=1'>Vnos naročilnice</a><br>";

		    echo "<form name='Iskanje' method=post action='VnosNarocilnica.php'>";
		    echo "Iskalni niz: <input name='iskanje' type='text' size='30'>";
		    echo " leto:<select name='letoisci'>";
            $SQL = "SELECT DISTINCT leto FROM tabnarocilnica ORDER BY leto DESC";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($VLeto==$R["leto"]){
		            echo "<option value='".$R["leto"]."' selected='selected'>".$R["leto"]."</option>";
                }else{
		            echo "<option value='".$R["leto"]."'>".$R["leto"]."</option>";
                }
            }
		    echo "</select>";
		    echo "<input name='id' type='hidden' value='6'>";
		    echo "<input name='submit' type='submit' value='Išči'>";
		    echo "</form>";
		    
            $SolskoLeto=$VLeto;
            for ($VLeto=$SolskoLeto;$VLeto <= $ActualYear;$VLeto++){
		        $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto;
		        $result = mysqli_query($link,$SQL);
		        $Indx=1;
		        $ProstiDnevi=0;
		        while ($R = mysqli_fetch_array($result)){
			        $Praznik[$Indx][0]=new DateTime($R["datum"]);
			        $Praznik[$Indx][1]=$R["kat"];
			        if ($Praznik[$Indx][1]==1 ){
				        $ProstiDnevi=$ProstiDnevi+1;
			        }
			        $Indx=$Indx+1;
		        }
		        $StPraznikov=$Indx-1;

                if (($VLeto) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

		        $SQL = "SELECT * FROM TabNarocilnica WHERE leto=".$VLeto." ORDER BY ZapSt";
		        $result = mysqli_query($link,$SQL);
		        $Indx=1;
		        while ($R = mysqli_fetch_array($result)){
		            $Zapisi[$Indx][0]=new DateTime(isDate($R["DatumIzd"]));
			        $Indx=$Indx+1;
		        }
		        $StZapisov=$Indx-1;
		        
		        echo "<h2>Koledar za leto ".$VLeto."</h2>";
		        echo "<table border='1'>";
		        echo "<tr><th></th>";
		        for ($Indx=1;$Indx <= 31;$Indx++){
			        echo "<th>".$Indx."</th>";
		        }
		        echo "</tr>";
		        for ($Indx=1;$Indx <= 12;$Indx++){
			        echo "<tr><td align='center'><a href='VnosNarocilnica.php?id=7&mesec=".$Indx."'>".$Indx."</a></td>";
			        for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
				        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
				        switch ($Datum->format('w')+1){
					        case 1:
                            case 7:
						        echo "<td bgcolor='lightsalmon'>";
						        
						        switch (CheckPraznik($Datum)){
							        case 0: // 'delovnik
								        if (CheckNarocilnica($Datum) ){
									        echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
								        }else{
									        echo "&nbsp;";
								        }
                                        break;
							        case 1: // 'praznik
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                        break;
							        case 2: // 'prost dan za učitelje
								        if (CheckNarocilnica($Datum) ){
									        echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
								        }else{
									        echo "&nbsp;";
								        }
                                    }
						        echo "</td>";
                                break;
					        case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
		        //'				echo datum&" "&CheckPraznik(datum)&"<br>"
						        switch (CheckPraznik($Datum)){
							        case 0: // 'delovnik
								        if (CheckNarocilnica($Datum)){
									        echo "<td><a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a></td>";
								        }else{
									        echo "<td>&nbsp;</td>";
								        }
                                        break;
							        case 1: // 'praznik
								        echo "<td bgcolor=lightgreen>";
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                        echo "</td>";
                                        break;
							        case 2: // 'prost dan za učitelje
								        if (CheckNarocilnica($Datum)){
									        echo "<td bgcolor='lightblue'><a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a></td>";
								        }else{
									        echo "<td bgcolor='lightblue'>&nbsp;</td>";
								        } 
						        }
				        }
			        }
			        echo "</tr>";
		        }
		        echo "</table><br />";
            }
            $VLeto=$SolskoLeto;
            break;
	    case "5":
        case "6":
        case "7":	
		    echo "<a href='VnosNarocilnica.php?id=1'>Vnos naročilnice</a><br />";
    //'		echo "<a href='DelovodnikPDF.php?leto="&year(now)&"'>Tiskanje delovodnika (PDF)</a><br>"
            $SolskoLeto=$VLeto;
            for ($VLeto=$SolskoLeto;$VLeto <= $ActualYear;$VLeto++){
                $SQL = "SELECT * FROM TabPraznik WHERE leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                $ProstiDnevi=0;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime($R["datum"]);
                    $Praznik[$Indx][1]=$R["kat"];
                    if ($Praznik[$Indx][1]==1 ){
                        $ProstiDnevi=$ProstiDnevi+1;
                    }
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;

                if (($VLeto) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                $SQL = "SELECT * FROM TabNarocilnica WHERE leto=".$VLeto." ORDER BY ZapSt";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Zapisi[$Indx][0]=new DateTime(isDate($R["DatumIzd"]));
                    $Indx=$Indx+1;
                }
                $StZapisov=$Indx-1;
                
                echo "<h2>Koledar za leto ".$VLeto."</h2>";
                echo "<table border='1'>";
                echo "<tr><th></th>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    echo "<th>".$Indx."</th>";
                }
                echo "</tr>";
                for ($Indx=1;$Indx <= 12;$Indx++){
                    echo "<tr><td align='center'><a href='VnosNarocilnica.php?id=7&mesec=".$Indx."'>".$Indx."</a></td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLeto."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')+1){
                            case 1:
                            case 7:
                                echo "<td bgcolor='lightsalmon'>";
                                
                                switch (CheckPraznik($Datum)){
                                    case 0: // 'delovnik
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                        break;
                                    case 1: // 'praznik
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                        break;
                                    case 2: // 'prost dan za učitelje
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                    }
                                echo "</td>";
                                break;
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                //'                echo datum&" "&CheckPraznik(datum)&"<br>"
                                switch (CheckPraznik($Datum)){
                                    case 0: // 'delovnik
                                        if (CheckNarocilnica($Datum)){
                                            echo "<td><a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a></td>";
                                        }else{
                                            echo "<td>&nbsp;</td>";
                                        }
                                        break;
                                    case 1: // 'praznik
                                        echo "<td bgcolor=lightgreen>";
                                        if (CheckNarocilnica($Datum) ){
                                            echo "<a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a>";
                                        }else{
                                            echo "&nbsp;";
                                        }
                                        echo "</td>";
                                        break;
                                    case 2: // 'prost dan za učitelje
                                        if (CheckNarocilnica($Datum)){
                                            echo "<td bgcolor='lightblue'><a href='VnosNarocilnica.php?id=5&datum=".$Datum->format('j.n.Y')."'>N</a></td>";
                                        }else{
                                            echo "<td bgcolor='lightblue'>&nbsp;</td>";
                                        }
                                }
                        }
                    }
                    echo "</tr>";
                }
                echo "</table><br />";
            }
            $VLeto=$SolskoLeto;
    }
}
?>

</body>
</html>
