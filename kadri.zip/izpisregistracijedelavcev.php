<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("razredi.php");
require("iskanje.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Način registracije delovnega časa
</title>
</head>
<body>

<?php
$Danes=new DateTime("now");
$VLeto=$Danes->format('Y');
if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT iducitelj FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["iducitelj"];
    $Prijavljeni=$R["iducitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}
$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
/* iz tabprihodi nima smisla gledati, ker je sistemdat enak času prihoda ali odhoda (treba je gladati tablog)
                                                                                         
$SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,";
$SQL .= "tabprihodi.letopr,tabprihodi.mesecpr,tabprihodi.danpr,tabprihodi.uraprih,tabprihodi.minprih,tabprihodi.vrstaprih";
$SQL .= ",tabprihodi.letodh,tabprihodi.mesecodh,tabprihodi.danodh,tabprihodi.uraodh,tabprihodi.minodh,tabprihodi.sistemdat,tabprihodi.pripomba";
$SQL .= " FROM tabucitelji INNER JOIN tabprihodi ON tabucitelji.iducitelj=tabprihodi.sifra ";
$SQL .= "WHERE (year(sistemdat) = $VLeto OR year(sistemdat) = ".($VLeto-1).") AND NOT (tabprihodi.pripomba IN ('178.172.27.235','178.172.27.236','178.172.27.237'))";
$SQL .= " ORDER BY tabucitelji.priimek,tabucitelji.ime,tabprihodi.id";
$result = mysqli_query($link,$SQL);

echo "<table border='1' cellspacing='0'>";
echo "<tr><th>št</th><th>ime</th><th>prihod/odhod</th><th>vpisan čas</th><th>čas vpisa</th><th>lokacija vpisa</th><th>opomba</th></tr>";
$i=1;
while ($R = mysqli_fetch_array($result)){
        if ($R["vrstaprih"] == "1001"){
            $datum = new DateTime($R["letopr"]."-".$R["mesecpr"]."-".$R["danpr"]." ".$R["uraprih"].":".$R["minprih"].":00");
            $datumCheck = new DateTime($R["sistemdat"]);
            $interval = $datum->diff($datumCheck);
            if ($interval->y*10+$interval->m*10+$interval->d*10+$interval->h*10+$interval->i > 2){
                echo "<tr>";
                echo "<td>$i</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td>prihod</td>";
                echo "<td>".$datum->format('d.m.Y H:i')."</td>";
                echo "<td>".$datumCheck->format('d.m.Y H:i')."</td>";
                echo "<td>".$R["pripomba"]."</td>";
                if ((strpos($R["pripomba"],'178.172.27.') == 0) or (strpos($R["pripomba"],'194.249.80.') == 0) or (strpos($R["pripomba"],'95.87.140.') == 0)){
                    echo "<td>šolski rač.</td>";
                }else{
                    echo "<td>zunanji rač./iz kadrov</td>";
                }
                echo "</tr>";
                $i++;
            }else{
            }
        }else{
            $datum = new DateTime($R["letodh"]."-".$R["mesecodh"]."-".$R["danodh"]." ".$R["uraodh"].":".$R["minodh"].":00");
            $datumCheck = new DateTime($R["sistemdat"]);
            $interval = $datum->diff($datumCheck);
            
            if ($interval->y*10+$interval->m*10+$interval->d*10+$interval->h*10+$interval->i > 2){
                echo "<tr>";
                echo "<td>$i</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                echo "<td>odhod</td>";
                echo "<td>".$datum->format('d.m.Y H:i')."</td>";
                echo "<td>".$datumCheck->format('d.m.Y H:i')."</td>";
                echo "<td>".$R["pripomba"]."</td>";
                if ((strpos($R["pripomba"],'178.172.27.') == 0) or (strpos($R["pripomba"],'194.249.80.') == 0) or (strpos($R["pripomba"],'95.87.140.') == 0)){
                    echo "<td>šolski rač.</td>";
                }else{
                    echo "<td>zunanji rač./iz kadrov</td>";
                }
                echo "</tr>";
                $i++;
            }
        }
}
echo "</table>";
*/

$SQL = "SELECT * FROM tablog WHERE (stran='/VpisCasa.php' AND NOT (ip IN ('178.172.27.235','178.172.27.236','178.172.27.237','194.249.80.153')))  AND year(cas)=$VLeto";
$result = mysqli_query($link,$SQL);

while ($R = mysqli_fetch_array($result)){
    $p=unserialize($R["post"]);
    $datum=new DateTime(isDate($p["datum"])." ".$p["clock"]);
    $datumCheck=new DateTime($R["cas"]);
    $id=intval(substr($p["delavec"],1,3));
    $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE iducitelj=".$id;
    $result1 = mysqli_query($link,$SQL);
    if ($R1 = mysqli_fetch_array($result1)){
        $delavec[$id]["ime"]=$R1["priimek"]." ".$R1["ime"];
        $delavec[$id]["datum"]=$datum->format('d.m.Y H:i');
        $delavec[$id]["datumCheck"]=$datumCheck->format('d.m.Y H:i');
        $delavec[$id]["ip"]=$p["ip"];
        if (isset($p["oddaj1_x"])){
            $delavec[$id]["inout"]="prihod";
        }else{
            $delavec[$id]["inout"]="odhod";
        }
        if ((strpos($R["ip"],'78.172.27.') == 1) or (strpos($R["ip"],'94.249.80.') == 1) or (strpos($R["ip"],'5.87.140.') == 1)){
            $delavec[$id]["opomba"]="šolski rač.";
        }else{
            $delavec[$id]["opomba"]="zunanji rač./telefon";
        }
    }
}
echo "<br />";
echo "<h2>Vpisi preko evidenčne strani (tipkovnica)</h2>";
echo "<table border='1' cellspacing='0'>";
echo "<tr><th>št</th><th>ime</th><th>prihod/odhod</th><th>vpisan čas</th><th>čas vpisa</th><th>lokacija vpisa</th><th>opomba</th></tr>";
$SQL = "SELECT iducitelj FROM tabucitelji ORDER BY iducitelj DESC LIMIT 0,1";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $n=$R["iducitelj"];
    $j=1;
    for ($i=1;$i <= $n;$i++){
        if (isset($delavec[$i]["ime"])){
            echo "<tr>";
            echo "<td>$j</td>";
            echo "<td>".$delavec[$i]["ime"]."</td>";
            echo "<td>".$delavec[$i]["inout"]."</td>";
            echo "<td>".$delavec[$i]["datum"]."</td>";
            echo "<td>".$delavec[$i]["datumCheck"]."</td>";
            echo "<td>".$delavec[$i]["ip"]."</td>";
            echo "<td>".$delavec[$i]["opomba"]."</td>";
            echo "</tr>";
            $j++;
        }
    }
}
echo "</table>";

$SQL = "SELECT tabucitelji.priimek,tabucitelji.ime,tablog.* FROM tablog ";
$SQL .="INNER JOIN tabucitelji ON tablog.user=tabucitelji.uporabnik ";
$SQL .= "WHERE stran='/PrihodDelavcev.php' AND year(cas)=$VLeto AND tablog.user <> '' ";
$SQL .= "ORDER BY tabucitelji.priimek,tabucitelji.ime";
$result = mysqli_query($link,$SQL);
echo "<h2>Vpisi preko kadrov</h2>";
echo "<table border='1' cellspacing='0'>";
echo "<tr><th>št</th><th>ime</th><th>vpisano za</th><th>prihod/odhod</th><th>vpisan čas</th><th>čas vpisa</th><th>lokacija vpisa</th><th>opomba</th></tr>";
$i=1;
while ($R = mysqli_fetch_array($result)){
    $p=unserialize($R["post"]);
    if (isset($p["leto"])){
        $datum=new DateTime($p["leto"]."-".$p["mesec"]."-".$p["dan"]." ".$p["ura"].":".$p["minuta"]);
        $datumCheck=new DateTime($R["cas"]);
        $interval = $datum->diff($datumCheck);
        if ($interval->y*10+$interval->m*10+$interval->d*10+$interval->h*10+$interval->i > 2){
            echo "<tr>";
            echo "<td>$i</td>";
            echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
            $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj=".$p["delavec"];
            $result1 = mysqli_query($link,$SQL);
            if ($R1 = mysqli_fetch_array($result1)){
                if ($R["priimek"].$R["ime"] != $R1["priimek"].$R1["ime"]){
                    echo "<td>".$R1["priimek"]." ".$R1["ime"]."</td>";
                }else{
                    echo "<td>&nbsp;</td>";
                }
            }else{
                echo "<td>neznan</td>";
            }
            if ($p["tip"] == '1001'){
                echo "<td>prihod</td>";
            }else{
                echo "<td>odhod</td>";
            }
            echo "<td>".$datum->format('d.m.Y H:i')."</td>";
            echo "<td>".$datumCheck->format('d.m.Y H:i')."</td>";
            echo "<td>".$R["ip"]."</td>";
            if ((strpos($R["ip"],'78.172.27.') == 1) or (strpos($R["ip"],'94.249.80.') == 1) or (strpos($R["ip"],'5.87.140.') == 1)){
                echo "<td>šolski rač.</td>";
            }else{
                echo "<td>zunanji rač./telefon</td>";
            }
            echo "</tr>";
            $i++;
        }else{
            if (!((strpos($R["ip"],'78.172.27.') == 1) or (strpos($R["ip"],'94.249.80.') == 1) or (strpos($R["ip"],'5.87.140.') == 1))){
                echo "<tr bgcolor='lightgreen'>";
                echo "<td>$i</td>";
                echo "<td>".$R["priimek"]." ".$R["ime"]."</td>";
                $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj=".$p["delavec"];
                $result1 = mysqli_query($link,$SQL);
                if ($R1 = mysqli_fetch_array($result1)){
                    echo "<td>".$R1["priimek"]." ".$R1["ime"]."</td>";
                }else{
                    echo "<td>neznan</td>";
                }
                if ($p["tip"] == '1001'){
                    echo "<td>prihod</td>";
                }else{
                    echo "<td>odhod</td>";
                }
                echo "<td>".$datum->format('d.m.Y H:i')."</td>";
                echo "<td>".$datumCheck->format('d.m.Y H:i')."</td>";
                echo "<td>".$R["ip"]."</td>";
                echo "<td>zunanji rač./telefon</td>";
                echo "</tr>";
                $i++;
            }
        }
    }
}

?>

</body>
</html>
