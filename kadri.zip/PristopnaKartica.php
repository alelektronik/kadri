<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require('fpdf.php');

function ToWin($txt){
    //$txt=iconv("UTF-8", "ISO-8859-2//TRANSLIT", $txt);
    $txt=iconv("UTF-8", "Windows-1250//TRANSLIT", $txt);
    return $txt;
}

$Danes=new DateTime("now");

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Ucitelj=$R["IdUcitelj"];
    $Prijavljeni=$R["IdUcitelj"];
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Prisotnost",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}


$StepR[0]=20;
$StepR[1]=105;
$StepR[2]=190;
$StepD=55;

Function EAN8($BarTextIn){
    //' Initialize input and output strings
    $BarTextOut = "";
    $BarTextIn = trim($BarTextIn);

    //' Throw away non-numeric data
    $TempString = "";
    For ($II = 0;$II < strlen($BarTextIn);$II++){
        if (is_numeric(substr($BarTextIn, $II, 1)) ){ 
            $TempString = $TempString . substr($BarTextIn, $II, 1);
        }
    }

    //' Better be 7 digits long, or error it
    while (strlen($TempString) < 7 ){ 
        $TempString = "0".$TempString;
    }

    If (strlen($TempString) > 7 ){ 
        $TempString = substr($TempString,0,7);
    }
    //' Now calculate checksum and character map left and right sides
    $Sum = 0;
    $WorkL = "";
    $WorkR = "";
    For ($II = 0;$II < 7;$II++){
        If (($II % 2) == 0 ){
            $Sum = $Sum + (3 * substr($TempString, $II, 1));
        }else{
            $Sum = $Sum + substr($TempString, $II, 1);
        }

        If ($II < 4 ){
            $WorkL = $WorkL . Chr(ord(substr($TempString, $II, 1)) + 17);
        }else{
            $WorkR = $WorkR . substr($TempString, $II, 1);
        }
    }

    //' Build actual checksum character
    $CheckSumValue = 10 - ($Sum % 10);
    If ($CheckSumValue == 10 ){ 
        $CheckSumValue = 0;
    }
    $CheckSum = Chr(48 + $CheckSumValue);

    //' Build working bar code string
    $BarCodeOut = "[" . $WorkL . "|" . $WorkR . $CheckSum . "] ";

    return $BarCodeOut;
}


/*
$pdf->SetFont('EAN_b','',35);
$pdf->Write(10,'01234567');
$pdf->Output();
*/

//' Use this line when using the full version of FPDF...
$pdf = new FPDF();

//' Configure the page size, the units of measure and add a single page to the document
$pdf->AddFont('EAN_b','','EAN_b.php');
$pdf->AddFont('arial_CE','','arial_CE.php');
$pdf->AddFont('arialbd_CE','','arialbd_CE.php');
$pdf->AddPage("P","A4");

$SQL = "SELECT * FROM tabsola";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $VSolaKratko=$R["SolaKratko"];
    $VNaslov=$R["Naslov"];
    $VKraj=$R["Kraj"];
}

$SQL = "SELECT * FROM tabucitelji ";
$SQL = $SQL . "WHERE status > 0 ";
$SQL = $SQL . "ORDER BY priimek,ime";
$result = mysqli_query($link,$SQL);

$Indx=1;
$Stran=1;
$Indx1=0;

$pdf->SetDrawColor(0,0,0);
$pdf->SetLineWidth(0.2);

$pdf->Line($StepR[0], 282, $StepR[2], 282);
$pdf->Line($StepR[0], 227, $StepR[2], 227); 
$pdf->Line($StepR[0], 172, $StepR[2], 172);
$pdf->Line($StepR[0], 117, $StepR[2], 117);
$pdf->Line($StepR[0], 62, $StepR[2], 62);
$pdf->Line($StepR[0], 7, $StepR[2], 7);

$pdf->Line($StepR[0], 282, $StepR[0], 7);
$pdf->Line($StepR[1], 282, $StepR[1], 7);
$pdf->Line($StepR[2], 282, $StepR[2], 7);

//$pdf->Rect( 24, 11, 77, 47);

$pdf->Rect( $StepR[0]+4, 227+4, $StepR[2]-$StepR[1]-8, 47);
$pdf->Rect( $StepR[1]+4, 227+4, $StepR[2]-$StepR[1]-8, 47);

$pdf->Rect( $StepR[0]+4, 172+4, $StepR[2]-$StepR[1]-8, 47);
$pdf->Rect( $StepR[1]+4, 172+4, $StepR[2]-$StepR[1]-8, 47);

$pdf->Rect( $StepR[0]+4, 117+4, $StepR[2]-$StepR[1]-8, 47);
$pdf->Rect( $StepR[1]+4, 117+4, $StepR[2]-$StepR[1]-8, 47);

$pdf->Rect( $StepR[0]+4, 62+4, $StepR[2]-$StepR[1]-8, 47);
$pdf->Rect( $StepR[1]+4, 62+4, $StepR[2]-$StepR[1]-8, 47);

$pdf->Rect( $StepR[0]+4, 7+4,  $StepR[2]-$StepR[1]-8, 47);
$pdf->Rect( $StepR[1]+4, 7+4,  $StepR[2]-$StepR[1]-8, 47);


while ($R = mysqli_fetch_array($result)){
    switch ($Indx % 10){
        case 1:
        case 3:
        case 5:
        case 7:
        case 9:
            $pdf->SetFont('EAN_b','',48);
            $pdf->SetXY($StepR[0]+9, 5+1+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Write(48,EAN8($R["IdUcitelj"]+2000));
            $Indx1=$Indx1+1;
            
            $pdf->SetFont('arial_CE','',10);
            $pdf->SetXY($StepR[0]+25+8, 18+2+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Cell(55,6,ToWin($VSolaKratko),0,2);
            $pdf->MultiCell(55,4,ToWin($VNaslov.", ".$VKraj),0,"L");
            $pdf->SetFont('arialbd_CE','',10);
            $pdf->SetXY($StepR[0]+25+8, 35+2+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Cell(55,6,ToWin($R["Ime"]),0,2);
            $pdf->Cell(55,6,ToWin($R["Priimek"]));
            $Indx1=$Indx1+1; 
            break;
        case 2:
        case 4:
        case 6:
        case 8:
            $pdf->SetFont('EAN_b','',48);
            $pdf->SetXY($StepR[1]+9, 5+1+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Write(48,EAN8($R["IdUcitelj"]+2000));
            $Indx1=$Indx1+1;
            
            $pdf->SetFont('arial_CE','',10);
            $pdf->SetXY($StepR[1]+25+8, 18+2+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Cell(55,6,ToWin($VSolaKratko),0,2);
            $pdf->MultiCell(55,4,ToWin($VNaslov.", ".$VKraj),0,"L");
            $pdf->SetFont('arialbd_CE','',10);
            $pdf->SetXY($StepR[1]+25+8, 35+2+(intval((($Indx % 10)-1)/2))*55);
            $pdf->Cell(55,6,ToWin($R["Ime"]),0,2);
            $pdf->Cell(55,6,ToWin($R["Priimek"]));
            $Indx1=$Indx1+1; 
            break;
        case 0:
            $pdf->SetFont('EAN_b','',48);
            $pdf->SetXY($StepR[1]+9, 5+1+4*55);
            $pdf->Write(48,EAN8($R["IdUcitelj"]+2000));
            $Indx1=$Indx1+1;
            
            $pdf->SetFont('arial_CE','',10);
            $pdf->SetXY($StepR[1]+25+8, 18+2+4*55);
            $pdf->Cell(55,6,ToWin($VSolaKratko),0,2);
            $pdf->MultiCell(55,4,ToWin($VNaslov.", ".$VKraj),0,"L");
            $pdf->SetFont('arialbd_CE','',10);
            $pdf->SetXY($StepR[1]+25+8, 35+2+4*55);
            $pdf->Cell(55,6,ToWin($R["Ime"]),0,2);
            $pdf->Cell(55,6,ToWin($R["Priimek"]));
            $Indx1=$Indx1+1; 
    }
    if ($Indx % 10 == 0 ){
        $pdf->AddPage();
        $Stran=$Stran+1;
        $Indx1=0;
        
        $pdf->Line($StepR[0], 282, $StepR[2], 282);
        $pdf->Line($StepR[0], 227, $StepR[2], 227); 
        $pdf->Line($StepR[0], 172, $StepR[2], 172);
        $pdf->Line($StepR[0], 117, $StepR[2], 117);
        $pdf->Line($StepR[0], 62, $StepR[2], 62);
        $pdf->Line($StepR[0], 7, $StepR[2], 7);

        $pdf->Line($StepR[0], 282, $StepR[0], 7);
        $pdf->Line($StepR[1], 282, $StepR[1], 7);
        $pdf->Line($StepR[2], 282, $StepR[2], 7);

        //$pdf->Rect( 24, 11, 77, 47);

        $pdf->Rect( $StepR[0]+4, 227+4, $StepR[2]-$StepR[1]-8, 47);
        $pdf->Rect( $StepR[1]+4, 227+4, $StepR[2]-$StepR[1]-8, 47);

        $pdf->Rect( $StepR[0]+4, 172+4, $StepR[2]-$StepR[1]-8, 47);
        $pdf->Rect( $StepR[1]+4, 172+4, $StepR[2]-$StepR[1]-8, 47);

        $pdf->Rect( $StepR[0]+4, 117+4, $StepR[2]-$StepR[1]-8, 47);
        $pdf->Rect( $StepR[1]+4, 117+4, $StepR[2]-$StepR[1]-8, 47);

        $pdf->Rect( $StepR[0]+4, 62+4, $StepR[2]-$StepR[1]-8, 47);
        $pdf->Rect( $StepR[1]+4, 62+4, $StepR[2]-$StepR[1]-8, 47);

        $pdf->Rect( $StepR[0]+4, 7+4,  $StepR[2]-$StepR[1]-8, 47);
        $pdf->Rect( $StepR[1]+4, 7+4,  $StepR[2]-$StepR[1]-8, 47);
    }
    $Indx=$Indx+1;
}


$pdf->Output("PristopneKartice.pdf","D");
?>
