<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Razred
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("solskoleto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}

if (isset($_SESSION["Uporabnik"])){
    $VUporabnik = $_SESSION["Uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_SESSION["Geslo"])){
    $VGeslo = $_SESSION["Geslo"];
}else{
    $VGeslo = "";
}
if (isset($_SESSION["Level"])){
    $VLevel = $_SESSION["Level"];
}else{
    $VLevel = 0;
}

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    $VIdRazrednik=$R["IdUcitelj"];
    $VUporabnikId=$Prijavljeni;
    //echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

$n=$VLevel;
include('menu_func.inc');
include ('menu.inc');

if (!CheckDostop("VnosUcDat",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}else{

    if (isset($_POST["id"])){
        $Vid = $_POST["id"];
    }else{
        if (isset($_GET["id"])){
            $Vid=$_GET["id"];
        }else{
            $Vid = "";
        }
    }

    $SQL = "SELECT idrazred,paralelka FROM tabrazred WHERE leto=".$VLeto." AND idUcitelj=".$VIdRazrednik;
    $result = mysqli_query($link,$SQL);

    if ($R = mysqli_fetch_array($result)){
        $VidRazred=$R["idrazred"];
        $VidParalelka=$R["paralelka"];
    }else{
        if (isset($_GET["razred"])){
            $VidRazred=$_GET["razred"];
        }else{
            if (isset($_SESSION["razred"])){
                $VidRazred=$_SESSION["razred"];
            }else{
                $VidRazred=0;
                $VidParalelka="A";
            }
        }
    }
    switch ($Vid){
        case "drtekm":
            echo "<form name='izjave' method=post action='drtekmobvestilapdf.php'>";
            break;
        case "sst":
            echo "<form name='izjave' method=post action='sstobvestilapdf.php'>";
            break;
        case "prijavanpz":
            echo "<form name='obvestilanpz' method=post action='npz.php'>";
            echo "<input name='idd' type='hidden' value='500'>";
            break;
        case "obvestilanpz":
            /*
            if (isset($_SESSION["posx"])){
                $KorX = $_SESSION["posx"];
            }else{
                $KorX = 0;
            }
            if (isset($_SESSION["posy"])){
                $KorY = $_SESSION["posy"];
            }else{
                $KorY = 0;
            }
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay = $_SESSION["DayToPrint"];
            }else{
                $PrintDay = $Danes->format('j. n. Y');
            }
            if (isset($_SESSION["KorOpombe"])){
                $KorOpombe = $_SESSION["KorOpombe"];
            }else{
                $KorOpombe="";
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix=$_SESSION["RefStFix"];
            }else{
                $RefStFix="";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar=$_SESSION["RefStVar"];
            }else{
                $RefStVar=0;
            }
            */
            //Korekcija tiska
            if (isset($_POST["id1"])){
                $Vid1=$_POST["id1"];
            }else{
                $Vid1=0;
            }
            if (isset($_SESSION["posx"])) {
                $KorX=$_SESSION["posx"];
            }else{
                $KorX=0;
            }
            if (isset($_SESSION["posy"])){
                $KorY=$_SESSION["posy"];
            }else{
                $KorY=0;
            }
            if (isset($_SESSION["DayToPrint"])){
                $PrintDay=$_SESSION["DayToPrint"];
            }else{
                $PrintDay=$Danes->format('j.n.Y');
            }
            if (isset($_SESSION["RefStFix"])){
                $RefStFix = $_SESSION["RefStFix"];
            }else{
                $RefStFix = "";
            }
            if (isset($_SESSION["RefStVar"])){
                $RefStVar = $_SESSION["RefStVar"];
            }else{
                $RefStVar = "";
            }
            if (isset($_SESSION["KorOpombe"])){
                $KorOpombe = $_SESSION["KorOpombe"];
            }else{
                $KorOpombe = "";
            }
            switch ($Vid1){
                case "1":
                    $KorX=$_POST["koordinatax"];
                    $KorY=$_POST["koordinatay"];
                    if (isset($_POST["RefStFix"])){
                        $RefStFix=$_POST["RefStFix"];
                    }
                    if (isset($_POST["RefStVar"])){
                        $RefStVar=$_POST["RefStVar"];
                    }
                    if (isset($_POST["datum"])){
                        $PrintDay=$_POST["datum"];
                    }
                    if (isset($_POST["KorOpombe"])){
                        $KorOpombe=$_POST["KorOpombe"];
                    }
                    $_SESSION["posx"]=$KorX;
                    $_SESSION["posy"]=$KorY;
                    $_SESSION["RefStFix"]=$RefStFix;
                    $_SESSION["RefStVar"]=$RefStVar;
                    $_SESSION["DayToPrint"]=$PrintDay;
                    $_SESSION["KorOpombe"]=$KorOpombe;
                    echo "<h3>Nove nastavitve bodo aktivne do zaključka seanse.</h3>";
                    break;
                default:    
                    if ($KorX==""){
                        $KorX=0;
                    }
                    if ($KorY==""){
                        $KorY=0;
                    }
                    if ($PrintDay=="") {
                        $PrintDay=$Danes->format('j.n.Y');
                    }
                    $_SESSION["posx"]=$KorX;
                    $_SESSION["posy"]=$KorY;
                    $_SESSION["RefStFix"]=$RefStFix;
                    $_SESSION["RefStVar"]=$RefStVar;
                    $_SESSION["DayToPrint"]=$PrintDay;
                    $_SESSION["KorOpombe"]=$KorOpombe;
            }
                    
            echo "<form name='rezultati' method=post action='izborrazreda.php'>";
            echo "<input name='id' type='hidden' value='obvestilanpz'>";
            echo "<h3>Korekcija tiskanja</h3>";
            echo "<table border='0'>";
            echo "<tr>";
            echo "    <td>";
            echo "        izpis višje(+)/nižje(-) mm:";
            echo "        <input name='koordinatay' type='text' size='6' value='".$KorY."'>";
            echo "    </td>";
            echo "</tr>";
            echo "<tr>";
            echo "    <td>";
            echo "        izpis bolj desno(+)/levo(-) mm:";
            echo "        <input name='koordinatax' type='text' size='6' value='".$KorX."'>";
            echo "    </td>";
            echo "</tr>";
            echo "<tr>";
            
            if (strstr($PrintDay,".")) { 
                $astr=explode(".",$PrintDay);
                $Datum = new DateTime(trim($astr[2])."-".trim($astr[1])."-".trim($astr[0]));
            }else{
                $Datum  = new DateTime($Danes->format('Y-m-d'));
            }
            echo "        <td>Datum izpisa: <input name='datum' type='text' size='12' value='".$Datum->format('j.n.Y')."' id='dat_1'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "        <td>Ref. št. (fiksni del): <input name='RefStFix' type='text' size='5' value='".$RefStFix."'></td>";
            echo "</tr>";
            echo "<tr>";
            echo "        <td>Ref. št. (spremenljivi del): <input name='RefStVar' type='text' size='5'value='". $RefStVar ."'></td>";
            echo "</tr>";
            /*
            echo "<tr>";
            echo "        <td>Opombe (na spričevalo - vsem v izpisu): <input name='KorOpombe' type='text' size='40'value='". $KorOpombe ."'></td>";
            echo "</tr>";
            */
            echo "</table>";
            echo "<input name='id1' type='hidden' value='1'>";
            //echo "<input name='razred' type='hidden' value='".$VRazred."'>";
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
            // konec korekcije tiskanja
            
            echo "<form name='obvestilanpz' method=post action='npz.php'>";
            echo "<input name='idd' type='hidden' value='510'>";
            /*
            if (($KorX != 0) or ($KorY != 0) ){
                echo "<br />Zamik tiskanja je: ".$KorX." mm po širini (+ bolj desno/- bolj levo) in ".$KorY." mm po višini (+ bolj gor/- bolj dol).";
            }
            if (strlen($PrintDay) > 0) {
                echo "<br />Datum dokumenta je: ".$PrintDay;
            }
            if ((strlen($RefStFix) > 0) or ($RefStVar > 0) ){
                echo "<br />Referenčna številka (fiksni del) je: ".$RefStFix;
                echo "<br />Referenčna številka (spremenljivi del) je: ".$RefStVar;
            }
            if (strlen($KorOpombe) > 0) {
                echo "<br />Opombe (za spričevalo): ".$KorOpombe;
            }
            */
            echo "<br /><a href='tiskanje_navodilo.htm'>Navodilo za tiskanje PDF dokumentov</a><br />";
            //echo "<a href='KorekcijaTiska.php'>Korekcija izpisa tiskalnika in <b>sprememba datuma tiskanja</b></a><br /><br />";
            echo "<br /><input name='obrazec' type='checkbox' checked='checked'>Izpis na obrazec<br />";
            break;
        case "untis":
            echo "<form name='izjave' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='119'>";
            echo "<br /><input name='zaleto' type='checkbox' checked='checked'>Spiski za naslednje šolsko leto<br />";
            break;
        case "potrdilo":
            echo "<form name='izjave' method=post action='izborucenca.php'>";
            echo "<input name='idd' type='hidden' value='500'>";
            echo "<br />Evid. št. <input name='evidst' type='text' size='10'><br />";
            break;
        case "dejavnosti":
            echo "<br /><a href='posebnidnevi.php?id=6&solskoleto=".$VLeto."'>Koledar izvedenih dnevov dejavnosti</a><br>";
            echo "<a href='posebnidnevi.php?id=7&solskoleto=".$VLeto."'>Spisek izvedenih dnevov dejavnosti</a><br>";
            echo "<form name='dejavnosti' method='post' action='posebnidnevi.php'>";
            echo "<input name='id' type='hidden' value='1'>";
            break;
        case "izjave":
            echo "<form name='izjave' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='108'>";
            break;
        case "odsotnost":
            echo "<form name='odsotnost' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='120'>";
            break;
        case "uspeh":
            echo "<form name='uspeh' method=post action='vnesiocene.php'>";
            echo "<input name='id' type='hidden' value='7'>";
            break;
        case "interesne":
            echo "<form name='interesne' method=post action='krozkiobvestilapdf.php'>";
            break;
        case "interesne1":
            echo "<form name='interesne1' method=post action='krozkiobvestilartf.php'>";
            break;
        case "tabor":
            echo "<form name='tabor' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='112'>";
            break;
        case "prehrana":
            echo "<form name='prehrana' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='105'>";
            break;
        case "opb":
            echo "<form name='opb' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='103'>";
            break;
        case "dodpouk":
            echo "<form name='dodpouk' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='101'>";
            break;
        case "sppouk":
            echo "<form name='sppouk' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='101a'>";
            break;
        case "preverjanje":
            echo "<form name='preverjanje' method=post action='vnospreverjanjznanja.php'>";
            break;
        case "govorilne":
            echo "<form name='govorilne' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='122'>";
            break;
        case "vpisni":
            echo "<form name='vpisnilist' method=post action='izborucenca.php'>";
            echo "<input name='idd' type='hidden' value='300'>";
            break;
        case "malice":
            echo "<form name='malice' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='107'>";
            break;
        case "dezurni":
            echo "<form name='dezurni' method=post action='vnosdezurnihuc.php'>";
            break;
        case "plavanje":
            echo "<form name='plavanje' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='111'>";
            break;
        case "telefoni":
            echo "<form name='telefoni' method=post action='vnosispiski.php'>";
            echo "<input name='idd' type='hidden' value='110'>";
            break;
        case "svet":
            echo "<form name='svet' method='post' action='izpisrazreda.php'>";
            echo "<input name='id' type='hidden' value='5'>";
            break;
        case "opombe":
            echo "<form name='opombe' method='post' action='dnevnik.php'>";
            echo "<input name='idd' type='hidden' value='300'>";
            echo "<input name='id' type='hidden' value='5'>";
            break;
        case "odsotnosti": //po eDnevniku
            echo "<form name='opombe' method='post' action='dnevnik.php'>";
            echo "<input name='idd' type='hidden' value='200'>";
            echo "<input name='id' type='hidden' value='5'>";
            break;
        case "starsi":
            echo "<form name='starsi' method='post' action='izpisrazreda.php'>";
            echo "<input name='id' type='hidden' value='6'>";
            break;
        case "sporocila":
            echo "<form name='sporocila' method='post' action='izpisrazreda.php'>";
            echo "<input name='id' type='hidden' value='4'>";
            break;
        case "sociogram":
            echo "<form name='sociogram' method='post' action='izpisrazreda.php'>";
            echo "<input name='id' type='hidden' value='9'>";
            break;
        default:
            echo "<form name='rezultati' method='post' action='izpisrazreda.php'>";
    }
    echo "<h2>Izberite razred</h2><br>";
    echo "<table border=0>";
    echo "<tr>";
    echo "<td>";
    echo "Šolsko leto </td><td>".$VLeto."/".($VLeto+1)."<input type='hidden' name='solskoleto' value='".$VLeto."'>";
    echo "</td>";
    echo "</tr>";
    if (($Vid=="odsotnost") or ($Vid=="malice") or ($Vid=="opombe")  or ($Vid=="odsotnosti")){
        echo "<tr>";
        echo "<td>";
        echo "<font color='red'><b>Mesec:</b></font></td><td> <select name='mesec'>";
        for ($Indx=1;$Indx <= 12;$Indx++){
            if (($Indx != 7) && ($Indx != 8) ){
                if ($Indx==$Danes->format('n') ){
                    echo "<option value=".$Indx." selected>".$Indx."</option>";
                }else{
                    echo "<option value=".$Indx.">".$Indx."</option>";
                }
            }
        }
        echo "</select>";
        echo "</td>";
        echo "</tr>";
    }
    if ($VLeto < 2008 ){
        echo "<tr>";
        echo "<td>8-/9-letka:<select name='vrstaos'>";
        echo "<option value='9' selected>devetletka</option>";
        echo "<option value='8'>osemletka</option>";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
    }else{
        echo "<input name='vrstaos' type='hidden' value='9'>";
    }

    $SQL = "SELECT tabrazdat.*,tabsola.solakratko FROM tabrazdat INNER JOIN tabsola ON tabrazdat.idsola=tabsola.id WHERE leto=".$VLeto." ORDER BY idsola,razred,oznaka";
    $result = mysqli_query($link,$SQL);

    echo "<tr><td>Izberi razred</td><td><select name='razred'  onchange='this.form.submit()'>";
//    echo "<tr><td>Izberi razred</td><td><select name='razred'>";
    $Indx=1;
    while ($R = mysqli_fetch_array($result)){
        if ($VecSol > 0){
            if ($VidRazred==$R["id"] ){
                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]." - ".$R["solakratko"]."</option>";
            }
        }else{
            if ($VidRazred==$R["id"] ){
                echo "<option value='".$R["id"]."' selected='selected'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }else{
                echo "<option value='".$R["id"]."'>".$R["razred"].". ".$R["oznaka"]."</option>";
            }
        }
        $Indx=$Indx+1;
    }
    echo "<option value='0'>Vsi</option>";
    echo "</select>";

    echo "</td>";
    echo "</tr>";
    echo "</table><br />";
//    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "<input type='button' value='Pošlji' name='submitform' onclick='this.form.submit();'>";
    echo "</form>";
}
?>
</body>
</html>
