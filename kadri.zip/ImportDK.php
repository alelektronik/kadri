<?php
require ('const.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Uvoz
</title>
</head>
<body>
<a href="prijava.php">Nazaj na glavni meni</a><br>
<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$StPolj=81;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $Prijavljeni=$R["IdUcitelj"];
    echo "Pozdravljeni " . $R["Ime"] . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("ImpExNPZ",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}

if (isset($_POST["id"])){
    $id = $_POST["id"];
}else{
    if (isset($_GET["id"])){
        $id=$_GET["id"];
    }else{
        $id = 0;
    }
}

function ToWin($txt){
    $txt=str_replace("ÄŚ","Č",$txt);
    $txt=str_replace("ÄŤ","č",$txt);
    $txt=str_replace("Ĺ".chr(160),"Š",$txt);
    $txt=str_replace("Ĺˇ","š",$txt);
    $txt=str_replace("Ĺ˝","Ž",$txt);
    $txt=str_replace("Ĺľ","ž",$txt);
    $txt=str_replace("Ä†","Ć",$txt);
    $txt=str_replace("Ä‡","ć",$txt);
    $txt=str_replace("Ä".chr(144),"Đ",$txt);
    $txt=str_replace("Ä‘","đ",$txt);
    $txt=str_replace("Ă¶","ö",$txt);
    return $txt ;
}

function PreveriPolje($x){
    //'vrne index polja
    global $Polje;
    global $StPolj;
    $PreveriPolje=0;
    for ($i=1;$i <= $StPolj;$i++){
        if (strtolower($Polje[$i][1])==strtolower($x)){
            return $i;
        }
    }
}

$uploaded=false;
$allowedExts = array("txt", "csv");
$Preneseno=$_FILES["file"];
$extension = explode(".", $Preneseno["name"]);
$extension = end($extension);
$extension = strtolower($extension);
if ((($_FILES["file"]["type"] == "text/csv") || ($_FILES["file"]["type"] == "text/plain") || ($_FILES["file"]["type"] == "application/vnd.ms-excel"))
    && ($_FILES["file"]["size"] < 500000)
    && in_array($extension, $allowedExts)){
        if ($_FILES["file"]["error"] > 0){
            echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
        }else{
            echo "Upload: " . $_FILES["file"]["name"] . "<br />";
            echo "Type: " . $_FILES["file"]["type"] . "<br />";
            echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
            echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
     
            if (file_exists("dato/" . $_FILES["file"]["name"])){
                echo $_FILES["file"]["name"] . " already exists. ";
                move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                $uploaded=true;
            }else{
                move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                $uploaded=true;
            }
       }
}else{
    echo "Invalid file";
}

if ($uploaded){
    $myFile = "dato/".$_FILES["file"]["name"];
    $fh = fopen($myFile,'r') or die("Ne morem odpreti log datoteke!");
    $indx=0;
    while(!feof($fh)){
       //echo fgets($file). "<br />";
       $Vrstica[$indx]=fgets($fh);
       $indx=$indx+1;
    }
    $StVrstic=$indx-1;
    fclose($fh);
    
    //'V DatoVsebina prebere vsebino datoteke
    //DatoVsebina=ToWin(DatoVsebina)
    $brisi = array("\"","\r\n");
    $i1=0;
    $indx0=0;
    while ($indx0 <= $StVrstic){
        if (strlen($Vrstica[$indx0]) > 0){  //izpusti prazne vrstice
            $VUcitelj[$i1]=explode(";",$Vrstica[$indx0]);
            for ($i=0;$i < count($VUcitelj[$indx0]);$i++){
                $VUcitelj[$i1][$i]=str_replace($brisi,"",$VUcitelj[$i1][$i]);
            }
            $i1++;
        }
        $indx0++;
    }
    $StVrstic=$i1-1;
    
    /*
    '"Priimek";"Ime";"Dekliski";"Spol";"DatRoj";"EMSO";"Naslov";"Posta";"Kraj";"Izobrazba";"IzobOpis";"Uporabnik";"Geslo";"NivoDostopa";"Status";"PedIzobr";
    '"StrokIzpit";"Mentor";"Svetovalec";"Svetnik";"Davcna";"Obcina";"Drzava";"drzavljanstvo";"KrajRoj";"DrzavaRoj";"NaslovZac";"PostaZac";"KrajZac";
    '"ObcinaZac";"DrzavaZac";"Invalid";"KatInvalid";"DelnoUpokojen";"Starejsi";"DojecaMati";

    '"IzobUstr";"IdDelo";"IdVzgojnoDelo";"DatumStart";"DatumEnd";
    '"DopDelo";"Delodaj1";"Delodaj1mat";"Delodaj1naslov";"Delodaj2";"Delodaj2mat";"Delodaj2naslov";"Delodaj3";"Delodaj3mat";"Delodaj3naslov";
    '"DatumPogodbe";"PolniDelCas";"RazlogDolCas";"PotrStrokUsp";"NazivDelMesta";"UrTeden";"Izmensko";"KrajDela";"KonkKlavz";"NacinPrenehanja";
    '"StPogodbe";"Obremen1";"Obremen2";"Obremen3";"Obremen4";"Obremen5";

    '"DelDobaLet";"DopustNaDD";"DopustNaIz";"DopustNaOt";"DopustNaSta";"DopustNaInv";"DopustNaVod";"DopustStari";"DopustVzgoja";"DopustDelInv";"DopustPP";"Drugo";

    '"Telefon";"email"

    'vrstico razstavi na polja. Imena polj shrani in jim priredi ustrezno ime polja v TabUcitelji,TabPogodbe,TabDopust,TabKontakti
    'katera polja naj naslavlja
    */
    $Polje[1][1]="Priimek";
    $Polje[2][1]="Ime";
    $Polje[3][1]="Dekliski";
    $Polje[4][1]="Spol";
    $Polje[5][1]="DatRoj";
    $Polje[6][1]="EMSO";
    $Polje[7][1]="Naslov";
    $Polje[8][1]="Posta";
    $Polje[9][1]="Kraj";
    $Polje[10][1]="Izobrazba";
    $Polje[11][1]="IzobOpis";
    $Polje[12][1]="Uporabnik";
    $Polje[13][1]="Geslo";
    $Polje[14][1]="NivoDostopa";
    $Polje[15][1]="Status";
    $Polje[16][1]="PedIzobr";
    $Polje[17][1]="StrokIzpit";
    $Polje[18][1]="Mentor";
    $Polje[19][1]="Svetovalec";
    $Polje[20][1]="Svetnik";
    $Polje[21][1]="Davcna";
    $Polje[22][1]="Obcina";
    $Polje[23][1]="Drzava";
    $Polje[24][1]="drzavljanstvo";
    $Polje[25][1]="KrajRoj";
    $Polje[26][1]="DrzavaRoj";
    $Polje[27][1]="NaslovZac";
    $Polje[28][1]="PostaZac";
    $Polje[29][1]="KrajZac";
    $Polje[30][1]="ObcinaZac";
    $Polje[31][1]="DrzavaZac";
    $Polje[32][1]="Invalid";
    $Polje[33][1]="KatInvalid";
    $Polje[34][1]="DelnoUpokojen";
    $Polje[35][1]="Starejsi";
    $Polje[36][1]="DojecaMati";
    $Polje[37][1]="IzobUstr";
    $Polje[38][1]="IdDelo";
    $Polje[39][1]="IdVzgojnoDelo";
    $Polje[40][1]="DatumStart";
    $Polje[41][1]="DatumEnd";
    $Polje[42][1]="DopDelo";
    $Polje[43][1]="Delodaj1";
    $Polje[44][1]="Delodaj1mat";
    $Polje[45][1]="Delodaj1naslov";
    $Polje[46][1]="Delodaj2";
    $Polje[47][1]="Delodaj2mat";
    $Polje[48][1]="Delodaj2naslov";
    $Polje[49][1]="Delodaj3";
    $Polje[50][1]="Delodaj3mat";
    $Polje[51][1]="Delodaj3naslov";
    $Polje[52][1]="DatumPogodbe";
    $Polje[53][1]="PolniDelCas";
    $Polje[54][1]="RazlogDolCas";
    $Polje[55][1]="PotrStrokUsp";
    $Polje[56][1]="NazivDelMesta";
    $Polje[57][1]="UrTeden";
    $Polje[58][1]="Izmensko";
    $Polje[59][1]="KrajDela";
    $Polje[60][1]="KonkKlavz";
    $Polje[61][1]="NacinPrenehanja";
    $Polje[62][1]="StPogodbe";
    $Polje[63][1]="Obremen1";
    $Polje[64][1]="Obremen2";
    $Polje[65][1]="Obremen3";
    $Polje[66][1]="Obremen4";
    $Polje[67][1]="Obremen5";
    $Polje[68][1]="DelDobaLet";
    $Polje[69][1]="DopustNaDD";
    $Polje[70][1]="DopustNaIz";
    $Polje[71][1]="DopustNaOt";
    $Polje[72][1]="DopustNaSta";
    $Polje[73][1]="DopustNaInv";
    $Polje[74][1]="DopustNaVod";
    $Polje[75][1]="DopustStari";
    $Polje[76][1]="DopustVzgoja";
    $Polje[77][1]="DopustDelInv";
    $Polje[78][1]="DopustPP";
    $Polje[79][1]="Drugo";
    $Polje[80][1]="Telefon";
    $Polje[81][1]="email";

    //'iz katere tabele naj jemlje podatke: 0-TabUcitelji][1-TabPogodbe][2-TabDopust][3-TabKontakti
    $Polje[1][3]=0;
    $Polje[2][3]=0;
    $Polje[3][3]=0;
    $Polje[4][3]=0;
    $Polje[5][3]=0;
    $Polje[6][3]=0;
    $Polje[7][3]=0;
    $Polje[8][3]=0;
    $Polje[9][3]=0;
    $Polje[10][3]=0;
    $Polje[11][3]=0;
    $Polje[12][3]=0;
    $Polje[13][3]=0;
    $Polje[14][3]=0;
    $Polje[15][3]=0;
    $Polje[16][3]=0;
    $Polje[17][3]=0;
    $Polje[18][3]=0;
    $Polje[19][3]=0;
    $Polje[20][3]=0;
    $Polje[21][3]=0;
    $Polje[22][3]=0;
    $Polje[23][3]=0;
    $Polje[24][3]=0;
    $Polje[25][3]=0;
    $Polje[26][3]=0;
    $Polje[27][3]=0;
    $Polje[28][3]=0;
    $Polje[29][3]=0;
    $Polje[30][3]=0;
    $Polje[31][3]=0;
    $Polje[32][3]=0;
    $Polje[33][3]=0;
    $Polje[34][3]=0;
    $Polje[35][3]=0;
    $Polje[36][3]=0;
    $Polje[37][3]=1;
    $Polje[38][3]=1;
    $Polje[39][3]=1;
    $Polje[40][3]=1;
    $Polje[41][3]=1;
    $Polje[42][3]=1;
    $Polje[43][3]=1;
    $Polje[44][3]=1;
    $Polje[45][3]=1;
    $Polje[46][3]=1;
    $Polje[47][3]=1;
    $Polje[48][3]=1;
    $Polje[49][3]=1;
    $Polje[50][3]=1;
    $Polje[51][3]=1;
    $Polje[52][3]=1;
    $Polje[53][3]=1;
    $Polje[54][3]=1;
    $Polje[55][3]=1;
    $Polje[56][3]=1;
    $Polje[57][3]=1;
    $Polje[58][3]=1;
    $Polje[59][3]=1;
    $Polje[60][3]=1;
    $Polje[61][3]=1;
    $Polje[62][3]=1;
    $Polje[63][3]=1;
    $Polje[64][3]=1;
    $Polje[65][3]=1;
    $Polje[66][3]=1;
    $Polje[67][3]=1;
    $Polje[68][3]=2;
    $Polje[69][3]=2;
    $Polje[70][3]=2;
    $Polje[71][3]=2;
    $Polje[72][3]=2;
    $Polje[73][3]=2;
    $Polje[74][3]=2;
    $Polje[75][3]=2;
    $Polje[76][3]=2;
    $Polje[77][3]=2;
    $Polje[78][3]=2;
    $Polje[79][3]=2;
    $Polje[80][3]=3;
    $Polje[81][3]=3;

    //'tip polja: 0-niz][ 1-število
    $Polje[1][4]=0;
    $Polje[2][4]=0;
    $Polje[3][4]=0;
    $Polje[4][4]=0;
    $Polje[5][4]=0;
    $Polje[6][4]=0;
    $Polje[7][4]=0;
    $Polje[8][4]=1;
    $Polje[9][4]=0;
    $Polje[10][4]=1;
    $Polje[11][4]=0;
    $Polje[12][4]=0;
    $Polje[13][4]=0;
    $Polje[14][4]=1;
    $Polje[15][4]=1;
    $Polje[16][4]=0;
    $Polje[17][4]=0;
    $Polje[18][4]=0;
    $Polje[19][4]=0;
    $Polje[20][4]=0;
    $Polje[21][4]=0;
    $Polje[22][4]=1;
    $Polje[23][4]=1;
    $Polje[24][4]=0;
    $Polje[25][4]=0;
    $Polje[26][4]=0;
    $Polje[27][4]=0;
    $Polje[28][4]=1;
    $Polje[29][4]=0;
    $Polje[30][4]=1;
    $Polje[31][4]=1;
    $Polje[32][4]=1;
    $Polje[33][4]=0;
    $Polje[34][4]=0;
    $Polje[35][4]=1;
    $Polje[36][4]=1;
    $Polje[37][4]=1;
    $Polje[38][4]=1;
    $Polje[39][4]=1;
    $Polje[40][4]=0;
    $Polje[41][4]=0;
    $Polje[42][4]=1;
    $Polje[43][4]=0;
    $Polje[44][4]=0;
    $Polje[45][4]=0;
    $Polje[46][4]=0;
    $Polje[47][4]=0;
    $Polje[48][4]=0;
    $Polje[49][4]=0;
    $Polje[50][4]=0;
    $Polje[51][4]=0;
    $Polje[52][4]=0;
    $Polje[53][4]=0;
    $Polje[54][4]=0;
    $Polje[55][4]=0;
    $Polje[56][4]=0;
    $Polje[57][4]=1;
    $Polje[58][4]=1;
    $Polje[59][4]=0;
    $Polje[60][4]=1;
    $Polje[61][4]=0;
    $Polje[62][4]=0;
    $Polje[63][4]=1;
    $Polje[64][4]=1;
    $Polje[65][4]=1;
    $Polje[66][4]=1;
    $Polje[67][4]=1;
    $Polje[68][4]=1;
    $Polje[69][4]=1;
    $Polje[70][4]=1;
    $Polje[71][4]=1;
    $Polje[72][4]=1;
    $Polje[73][4]=1;
    $Polje[74][4]=1;
    $Polje[75][4]=1;
    $Polje[76][4]=1;
    $Polje[77][4]=1;
    $Polje[78][4]=1;
    $Polje[79][4]=1;
    $Polje[80][4]=0;
    $Polje[81][4]=0;

    for ($Indx=0;$Indx <= $StPolj;$Indx++){
        $Polje[$Indx][0]=0;    //'polje ne obstaja
    }
    for ($Indx=0;$Indx < count($VUcitelj[0]);$Indx++){
        $Indx0=PreveriPolje($VUcitelj[0][$Indx]);
        $Polje[$Indx0][0]=1;    //polje obstaja
        $Polje[$Indx0][2]=$Indx;  //index polja pri branju
    }

    echo "<h2>Spremembe in popravki v bazi učiteljev</h2>";
    for ($Indx=1;$Indx <= $StVrstic;$Indx++){
        //'izpiše učitelje
        //'echo VUcitelj($Indx,1)&" "&VUcitelj($Indx,2)&"<br />"
        
        //'vpis v TabUcitelji
        if ($VUcitelj[$Indx][$Polje[6][2]] != $VUcitelj[$Indx-1][$Polje[6][2]]) {
            if (strlen($VUcitelj[$Indx][$Polje[6][2]]) > 0 ){
                //'pretvori geslo
                $VUcGeslo=$VUcitelj[$Indx][$Polje[13][2]];
                //'če ni uporabniškega imena, tvori svoje s prvo črko imena in priimkom
                if (strlen($VUcitelj[$Indx][$Polje[12][2]]) == 0 ){
                    $VUcitelj[$Indx][$Polje[12][2]]=strtolower(substr($VUcitelj[$Indx][$Polje[2][2]],0,1).$VUcitelj[$Indx][$Polje[1][2]]);
                }
                //'če ni gesla, tvori svoje s prvo črko imena in priimkom (isto kot up. ime)
                if (strlen($VUcGeslo) == 0 ){
                    $VUcitelj[$Indx][$Polje[13][2]]=strtolower($VUcitelj[$Indx][$Polje[12][2]]);
                    $VUcGeslo=$VUcitelj[$Indx][$Polje[13][2]];
                }
                if (strlen($VUcGeslo) != 32 ){
                    $VUcitelj[$Indx][$Polje[13][2]]=md5($VUcitelj[$Indx][$Polje[13][2]]);
                }

                $SQL = "SELECT * FROM tabucitelji WHERE emso='".$VUcitelj[$Indx][$Polje[6][2]]."'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    //'ima učitelja
                    
                    //'update
                    $SQL = "UPDATE tabucitelji SET ";
                    $SQL = $SQL . $Polje[1][1]."='".$VUcitelj[$Indx][$Polje[1][2]]."'";
                    for ($i1 = 2;$i1 <= 36;$i1++){
                        if (strlen($VUcitelj[$Indx][$Polje[$i1][2]]) > 0 ){ 
                            if ($Polje[$i1][4] == 0 ){
                                $SQL = $SQL . ",".$Polje[$i1][1]."='".$VUcitelj[$Indx][$Polje[$i1][2]]."'";
                            }else{
                                
                                $SQL = $SQL . ",".$Polje[$i1][1]."=".str_replace(",",".",$VUcitelj[$Indx][$Polje[$i1][2]]);
                            }
                        }
                    }
                    
                    $SQL = $SQL . " WHERE id=".$R["Id"];
                }else{
                    //'insert
                    $SQL = "SELECT IdUcitelj FROM tabucitelji ORDER BY idUcitelj DESC";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $StUciteljevIndx=$R["IdUcitelj"]+1;
                    }else{
                        $StUciteljevIndx=1;
                    }
                    //datum roj prebere iz emšo
                    $DatRoj=substr($VUcitelj[$Indx][$Polje[6][2]],0,2) . "." . substr($VUcitelj[$Indx][$Polje[6][2]],2,2) . ".";
                    if (intval(substr($VUcitelj[$Indx][$Polje[6][2]],4,3)) < 900 ){
                        $DatRoj=$DatRoj."2".substr($VUcitelj[$Indx][$Polje[6][2]],4,3);
                    }else{
                        $DatRoj=$DatRoj."1".substr($VUcitelj[$Indx][$Polje[6][2]],4,3);
                    }
                    if (strlen($VUcitelj[$Indx][$Polje[5][2]]) == 0 ){
                        $VUcitelj[$Indx][$Polje[5][2]]=$DatRoj;
                    }
                    if (strlen($VUcitelj[$Indx][$Polje[10][2]]) == 0 ){
                        $VUcitelj[$Indx][$Polje[10][2]]=1;
                    }
                    
                    $SQL = "INSERT INTO tabucitelji (";
                    $SQL = $SQL . "idUcitelj,Priimek,Ime,Dekliski,Spol,DatRoj,EMSO,Naslov,Posta,Kraj,Izobrazba,IzobOpis,Uporabnik,Geslo,NivoDostopa,Status,PedIzobr,";
                    $SQL = $SQL . "StrokIzpit,Mentor,Svetovalec,Svetnik,Davcna,Obcina,Drzava,drzavljanstvo,KrajRoj,DrzavaRoj,NaslovZac,PostaZac,KrajZac,";
                    $SQL = $SQL . "ObcinaZac,DrzavaZac,Invalid,KatInvalid,DelnoUpokojen,Starejsi,DojecaMati,LetoRoj";
                    $SQL = $SQL . ") VALUES (";
                    
                    $SQL = $SQL . $StUciteljevIndx;
                    
                    for ($i1=1;$i1 <= 36;$i1++){
                        if (strlen($VUcitelj[$Indx][$Polje[$i1][2]]) > 0 ){ 
                            if ($Polje[$i1][4] == 0 ){
                                $SQL = $SQL . ",'".$VUcitelj[$Indx][$Polje[$i1][2]]."'";
                            }else{
                                $SQL = $SQL . ",".str_replace(",",".",$VUcitelj[$Indx][$Polje[$i1][2]]);
                            }
                        }else{
                            if ($Polje[$i1][4] == 0 ){
                                $SQL = $SQL . ",''";
                            }else{
                                $SQL = $SQL . ",0";
                            }
                        }
                    }
                    $Datum=new DateTime(isDate($DatRoj));
                    $SQL = $SQL . ",".$Datum->format('Y');
                    $SQL = $SQL . ")";
                }
                //'echo $SQL . "<br />"
                $result = mysqli_query($link,$SQL);
                
                //'prebere idUcitelj
                $SQL = "SELECT IdUcitelj FROM tabucitelji WHERE emso='".$VUcitelj[$Indx][$Polje[6][2]]."'";
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $VIdUcitelj=$R["IdUcitelj"];
                }
                
                //'vpis v TabPogodbe
                $SQL = "INSERT INTO tabpogodbe (idUcitelj,DelovniCas,";
                $SQL = $SQL . "IzobUstr,IdDelo,IdVzgojnoDelo,DatumStart,DatumEnd,";
                $SQL = $SQL . "DopDelo,Delodaj1,Delodaj1mat,Delodaj1naslov,Delodaj2,Delodaj2mat,Delodaj2naslov,Delodaj3,Delodaj3mat,Delodaj3naslov,";
                $SQL = $SQL . "DatumPogodbe,PolniDelCas,RazlogDolCas,PotrStrokUsp,NazivDelMesta,UrTeden,Izmensko,KrajDela,KonkKlavz,NacinPrenehanja,";
                $SQL = $SQL . "StPogodbe,Obremen1,Obremen2,Obremen3,Obremen4,Obremen5";
                $SQL = $SQL . ") VALUES (".$VIdUcitelj;
                if ($VUcitelj[$Indx][$Polje[53][2]] == "Da" ){
                    $SQL = $SQL . ",0";
                }else{
                    $SQL = $SQL . ",1";
                }
                
                for ($i1=37;$i1 <= 67;$i1++){
                    if (strlen($VUcitelj[$Indx][$Polje[$i1][2]]) > 0 ){ 
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",'".$VUcitelj[$Indx][$Polje[$i1][2]]."'";
                        }else{
                            $SQL = $SQL . ",".str_replace(",",".",$VUcitelj[$Indx][$Polje[$i1][2]]);
                        }
                    }else{
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",''";
                        }else{
                            $SQL = $SQL . ",0";
                        }
                    }
                }
                
                $SQL = $SQL . ")";
                $result = mysqli_query($link,$SQL);

                //'vpis v TabDopust
                $SQL = "INSERT INTO tabdopust (leto,idUcitelj,";
                $SQL = $SQL . "DelDobaLet,DopustNaDD,DopustNaIz,DopustNaOt,DopustNaSta,DopustNaInv,DopustNaVod,DopustStari,DopustVzgoja,DopustDelInv,DopustPP,Drugo";
                $SQL = $SQL . ") VALUES (".$Danes->format('Y').",".$VIdUcitelj;
                for ($i1=68;$i1 <= 79;$i1++){
                    if (strlen($VUcitelj[$Indx][$Polje[$i1][2]]) > 0 ){ 
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",'".$VUcitelj[$Indx][$Polje[$i1][2]]."'";
                        }else{
                            $SQL = $SQL . ",".str_replace(",",".",$VUcitelj[$Indx][$Polje[$i1][2]]);
                        }
                    }else{
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",''";
                        }else{
                            $SQL = $SQL . ",0";
                        }
                    }
                }
                $SQL = $SQL . ")";
                $result = mysqli_query($link,$SQL);
                
                //'vpis v TabKontakti
                $SQL = "INSERT INTO tabkontakti (idUcitelj,";
                $SQL = $SQL . "Telefon,email";
                $SQL = $SQL . ") VALUES (".$VIdUcitelj;
                for ($i1=80;$i1 <= 81;$i1++){
                    if (strlen($VUcitelj[$Indx][$Polje[$i1][2]]) > 0 ){ 
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",'".$VUcitelj[$Indx][$Polje[$i1][2]]."'";
                        }else{
                            $SQL = $SQL . ",".str_replace(",",".",$VUcitelj[$Indx][$Polje[$i1][2]]);
                        }
                    }else{
                        if ($Polje[$i1][4] == 0 ){
                            $SQL = $SQL . ",''";
                        }else{
                            $SQL = $SQL . ",0";
                        }
                    }
                }
                $SQL = $SQL . ")";
                $result = mysqli_query($link,$SQL);
                
                //'vpis v TabDostop
                $SQL = "INSERT INTO tabdostop (idUcitelj,";
                $SQL = $SQL . "VnosUcDat,";
                $SQL = $SQL . "UpdUc,";
                $SQL = $SQL . "Redov,";
                $SQL = $SQL . "VnosNPZ,";
                $SQL = $SQL . "ImpExNPZ,";
                $SQL = $SQL . "DelPregl,";
                $SQL = $SQL . "DelKontr,";
                $SQL = $SQL . "UpdDel,";
                $SQL = $SQL . "Tajn,";
                $SQL = $SQL . "VnosSist,";
                $SQL = $SQL . "VnosAktivi,";
                $SQL = $SQL . "VnosUrnik,";
                $SQL = $SQL . "VnosNadom,";
                $SQL = $SQL . "inventura,";
                $SQL = $SQL . "StatUc,";
                $SQL = $SQL . "StatDel,";
                $SQL = $SQL . "LetnPor,";
                $SQL = $SQL . "Prehrana,";
                $SQL = $SQL . "Prisotnost,";
                $SQL = $SQL . "NovoSL,";
                $SQL = $SQL . "ImpExUc,";
                $SQL = $SQL . "DatSola,";
                $SQL = $SQL . "Prazniki,";
                $SQL = $SQL . "Prostori,";
                $SQL = $SQL . "Predmeti,";
                $SQL = $SQL . "TabEd,";
                $SQL = $SQL . "RDU,";
                $SQL = $SQL . "PreglZbirn,";
                $SQL = $SQL . "PreglPoroc,";
                $SQL = $SQL . "PreglReal,";
                $SQL = $SQL . "drugo1,";
                $SQL = $SQL . "drugo2,";
                $SQL = $SQL . "drugo3,";
                $SQL = $SQL . "drugo4,";
                $SQL = $SQL . "drugo5,";
                $SQL = $SQL . "drugo6,";
                $SQL = $SQL . "drugo7,";
                $SQL = $SQL . "drugo8,";
                $SQL = $SQL . "drugo9";
                $SQL = $SQL . ") VALUES (".$VIdUcitelj.",";
                switch ($VUcitelj[$Indx][$Polje[14][2]]){
                    case "1":
                        $SQL = $SQL . "true,true,true,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "true,false,false,true,true,true,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                        break;
                    case "2":
                        $SQL = $SQL . "true,true,true,true,false,true,true,true,false,true,";
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true,true,";
                        $SQL = $SQL . "false,true,true,true,true,false,true,true,true,true,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                        break;
                    case "3":
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true,true,";
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true,true,";
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true,true,";
                        $SQL = $SQL . "true,true,true,true,true,true,true,true,true";
                        break;
                    default:
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false,false,";
                        $SQL = $SQL . "false,false,false,false,false,false,false,false,false";
                }
                $SQL = $SQL . ")";
                $result = mysqli_query($link,$SQL);
                
                echo $VUcitelj[$Indx][$Polje[1][2]]." ".$VUcitelj[$Indx][$Polje[2][2]].", uporabniško ime: ".$VUcitelj[$Indx][$Polje[12][2]].", geslo: ".$VUcGeslo."<br />";
            }else{
                echo "<font color='red'><b>".$VUcitelj[$Indx][$Polje[1][2]]." ".$VUcitelj[$Indx][$Polje[2][2]].", MANJKA EMŠO - delavec NI bil vpisan!</b></font><br />";
            }
        }
    }

    $SQL = "DELETE * FROM tabvzgojitelji WHERE id > 0";
    $result = mysqli_query($link,$SQL);

    $SQL = "SELECT * FROM tabucitelji ORDER BY priimek,ime";
    $result = mysqli_query($link,$SQL);
    while ($R = mysqli_fetch_array($result)){
        $SQL = "INSERT INTO tabvzgojitelji (idUcitelj,priimek,ime,spol) VALUES (".$R["IdUcitelj"].",'".$R["Priimek"]."','".$R["Ime"]."','".$R["Spol"]."')";
        $result1 = mysqli_query($link,$SQL);
    }
} 
?>

</body>
</html>
