<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Podatki o šoli
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " . $R["Ime"]  . " " . $R["Priimek"] . "<br />";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("DatSola",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}

switch ($Vid){
	case "2":
		break;
	default:
		$n=$VLevel;
		include('menu_func.inc');
		include ('menu.inc');
}
switch ($Vid){
	case "1": // 'vnos podatkov o šoli
		$SQL = "SELECT * FROM tabsola";
		$result = mysqli_query($link,$SQL);
        
        if ($VecSol == 0){
		    if ($R = mysqli_fetch_array($result)){
			    $VSolaId=$R["Id"];
                $VSola=$R["Sola"];
			    $VSolaKratko=$R["SolaKratko"];
			    $VNaslov=$R["Naslov"];
			    $VKraj=$R["Kraj"];
			    $VPosta=$R["Posta"];
			    $VRavnatelj=$R["Ravnatelj"];
			    $VUstanovaID=$R["UstanovaID"];
			    $VUstanovaIDMin=$R["UstanovaIDmin"];
			    $VObcina=$R["Obcina"];
			    $VPomocnik_ID1=$R["pomocnik_ID1"];
			    $VPomocnik_ID2=$R["pomocnik_ID2"];
			    $Vravnatelj_ID=$R["ravnatelj_ID"];
			    $VNPZSifra=$R["NPZSifra"];
			    $VTipSole=$R["TipSole"];
			    $Vemail=$R["email"];
			    $Vinternet=$R["internet"];
			    $Vddv_ID=$R["ddv_ID"];
			    $VzavezanecDDV=$R["zavezanecDDV"];
			    $Vtrr=$R["trr"];
			    $Vtelefon=$R["telefon"];
			    $Vfax=$R["fax"];
			    $zapis=$R["Id"];
                $SifraMSS=$R["SifraMSS"];
                $Program=$R["Program"];
                $MaticnaSola=$R["MaticnaSola"];
		    }

		    echo "<h2>Podatki o šoli</h2>";
		    echo "<form name='podatkiSola' method=post action='PodatkiOSoli.php'>";
		    echo "<table border='1'>";
		    echo "<tr><td>Šola (polno ime)</td><td><input name='sola' type='text' size='60' value='".$VSola."'></td></tr>";
		    echo "<tr><td>Šola (krajše)</td><td><input name='SolaKratko' type='text' size='60' value='".$VSolaKratko."'></td></tr>";
		    echo "<tr><td>Naslov</td><td><input name='naslov' type='text' size='60' value='".$VNaslov."'></td></tr>";
		    echo "<tr><td>Pošta</td><td><input name='posta' type='text' size='5' value='".$VPosta."'></td></tr>";
		    echo "<tr><td>Kraj</td><td><input name='Kraj' type='text' size='20' value='".$VKraj."'></td></tr>";
		    echo "<tr><td>Občina</td><td>";
		    echo "<select name='obcina'>";
		    $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
		    $result = mysqli_query($link,$SQL);
		    
            while ($R = mysqli_fetch_array($result)){
			    if ($R["sifra"]==$VObcina){
				    echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
			    }else{
				    echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
			    }
		    }
		    echo "</select>";
		    echo "</td></tr>";
		    echo "<tr><td>Davčna št.</td><td><input name='ddv_ID' type='text' size='8' value='".$Vddv_ID."'></td></tr>";
		    if ($VzavezanecDDV=="DA"){
			    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox' checked='checked'></td></tr>";
		    }else{
			    echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox'></td></tr>";
		    }
		    echo "<tr><td>TRR</td><td><input name='trr' type='text' size='16' value='".$Vtrr."'></td></tr>";
		    echo "<tr><td>Telefon</td><td><input name='telefon' type='text' size='15' value='".$Vtelefon."'></td></tr>";
		    echo "<tr><td>Fax</td><td><input name='fax' type='text' size='15' value='".$Vfax."'></td></tr>";
		    echo "<tr><td>e-mail</td><td><input name='email' type='text' size='40' value='".$Vemail."'></td></tr>";
		    echo "<tr><td>internet stran</td><td><input name='internet' type='text' size='40' value='".$Vinternet."'></td></tr>";
		    echo "<tr><td>Ravnatelj</td><td>";
		    echo "<select name='ravnatelj_ID'>";
		    $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
			    if ($R["IdUcitelj"]==$Vravnatelj_ID){
				    echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }else{
				    echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
                }
		    }
		    echo "</select>";
		    echo "</td></tr>";
		    echo "<tr><td>1. pomočnik</td><td>";
		    echo "<select name='pomocnik_ID1'>";
		    $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
			    if ($R["IdUcitelj"]==$VPomocnik_ID1){
				    echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }else{
				    echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }
		    }
		    echo "</select>";
		    echo "</td></tr>";
		    echo "<tr><td>2. pomočnik</td><td>";
		    echo "<select name='pomocnik_ID2'>";
		    $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
		    $result = mysqli_query($link,$SQL);

            while ($R = mysqli_fetch_array($result)){
			    if ($R["IdUcitelj"]==$VPomocnik_ID2){
				    echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }else{
				    echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
			    }
		    }
		    echo "</select>";
		    echo "</td></tr>";
		    echo "<tr><td>Št. šole (Lopolis)</td><td><input name='ustanovaID' type='text' size='5' value='".$VUstanovaID."'></td></tr>";
		    echo "<tr><td>Matična št.</td><td><input name='ustanovaIDmin' type='text' size='40' value='".$VUstanovaIDMin."'></td></tr>";
		    echo "<tr><td>NPZ šifra šole</td><td><input name='NPZSifra' type='text' size='12' value='".$VNPZSifra."'></td></tr>";
		    echo "<tr><td>Tip šole</td><td><input name='tipsole' type='text' size='20' value='".$VTipSole."'></td></tr>";
            echo "<tr><td>Šifra ministrstva</td><td><input name='SifraMSS' type='text' size='20' value='".$SifraMSS."'></td></tr>";
            echo "<tr><td>Program</td><td>";
            echo "<select name='Program'>";
            $SQL = "SELECT * FROM tabprogram";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                if ($R["sifra"]==$Program){
                    echo "<option value='".$R["sifra"]."' selected='selected'>".$R["opis"]." - ".$R["sifra"]."</option>";
                }else{
                    echo "<option value='".$R["sifra"]."'>".$R["opis"]." - ".$R["sifra"]."</option>";
                }
            }
            echo "</select>";
            echo "</td></tr>";
            echo "<tr><td>Matična šola</td><td><input name='MaticnaSola' type='text' size='20' value='".$MaticnaSola."'></td></tr>";
		    echo "</table>";
		    echo "<input name='id' type='hidden' value='2'>";
            echo "<input name='solaid' type='hidden' value='".$VSolaId."'>";
		    echo "<input name='zapis' type='hidden' value='".$zapis."'>";
		    echo "<input name='submit' type='submit' value='Popravi'>";
            echo "<input name='submit' type='submit' value='Dodaj'>";
		    echo "</form>";
        }else{
            echo "<h2>Izbor šole</h2>";
            echo "<form name='podatkiSola' method=post action='PodatkiOSoli.php'>";

            echo "<select name='solaid'>";
            $SQL = "SELECT id,solakratko,naslov,posta,kraj FROM tabsola";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<option value='".$R["id"]."'>".$R["solakratko"].", ".$R["naslov"].", ".$R["posta"]." ".$R["kraj"]."</option>";
            }
            echo "</select>";
            echo "<input name='id' type='hidden' value='3'>";
            echo "<input name='submit' type='submit' value='Pošlji'>";
            echo "</form>";
        }
        break;
	case "2": // 'vpis zapisa
        $VSolaId=$_POST["solaid"];
		$VSola=$_POST["sola"];
		$VSolaKratko=$_POST["SolaKratko"];
		$VNaslov=$_POST["naslov"];
		$VKraj=$_POST["Kraj"];
		$VPosta=$_POST["posta"];
		//$VRavnatelj=$_POST["ravnatelj"];
		$VUstanovaID=$_POST["ustanovaID"];
		if (!is_numeric($VUstanovaID)){
            $VUstanovaID=0;
        }
		$VUstanovaIDMin=$_POST["ustanovaIDmin"];
		$VObcina=$_POST["obcina"];
		$VPomocnik_ID1=$_POST["pomocnik_ID1"];
		$VPomocnik_ID2=$_POST["pomocnik_ID2"];
		$Vravnatelj_ID=$_POST["ravnatelj_ID"];
		$VNPZSifra=$_POST["NPZSifra"];
		$VTipSole=$_POST["tipsole"];
		$Vemail=$_POST["email"];
		$Vinternet=$_POST["internet"];
		$Vddv_ID=$_POST["ddv_ID"];
		$VzavezanecDDV=$_POST["Zavezanec"];
		$Vtrr=$_POST["trr"];
		$Vtelefon=$_POST["telefon"];
		$Vfax=$_POST["fax"];
		if ($VzavezanecDDV=="on"){
			$VzavezanecDDV="DA";
		}else{
			$VzavezanecDDV="NE";
		}
		$SifraMSS=$_POST["SifraMSS"];
        $Program=$_POST["Program"];
        $MaticnaSola=$_POST["MaticnaSola"];
        
		$SQL = "SELECT * FROM tabucitelji WHERE idUcitelj=".$_POST["ravnatelj_ID"];
		$result = mysqli_query($link,$SQL);
		if ($R = mysqli_fetch_array($result)){
			$VRavnatelj=$R["Ime"]." ".$R["Priimek"];
		}else{
			$VRavnatelj="";
		}
		
        if ($_POST["submit"]=="Popravi"){
		    $SQL = "UPDATE tabsola SET ";
		    $SQL = $SQL . "sola='".$VSola."',";
		    $SQL = $SQL . "solaKratko='".$VSolaKratko."',";
		    $SQL = $SQL . "Posta='".$VPosta."',";
		    $SQL = $SQL . "Kraj='".$VKraj."',";
		    $SQL = $SQL . "Naslov='".$VNaslov."',";
		    $SQL = $SQL . "Obcina='".$VObcina."',";
		    $SQL = $SQL . "UstanovaID=".$VUstanovaID.",";
		    $SQL = $SQL . "ravnatelj='".$VRavnatelj."',";
		    $SQL = $SQL . "ravnatelj_ID=".$Vravnatelj_ID.",";
		    $SQL = $SQL . "pomocnik_ID1=".$VPomocnik_ID1.",";
		    $SQL = $SQL . "pomocnik_ID2=".$VPomocnik_ID2.",";
		    $SQL = $SQL . "UstanovaIDmin='".$VUstanovaIDMin."',";
		    $SQL = $SQL . "NPZSifra='".$VNPZSifra."',";
		    $SQL = $SQL . "TipSole='".$VTipSole."',";
		    $SQL = $SQL . "email='".$Vemail."',";
		    $SQL = $SQL . "internet='".$Vinternet."',";
		    $SQL = $SQL . "ddv_ID='".$Vddv_ID."',";
		    $SQL = $SQL . "trr='".$Vtrr."',";
		    $SQL = $SQL . "zavezanecDDV='".$VzavezanecDDV."',";
		    $SQL = $SQL . "telefon='".$Vtelefon."',";
		    $SQL = $SQL . "fax='".$Vfax."', ";
            $SQL = $SQL . "SifraMSS='".$SifraMSS."', ";
            $SQL = $SQL . "Program='".$Program."', ";
            $SQL = $SQL . "MaticnaSola='".$MaticnaSola."' ";
		    $SQL = $SQL . " WHERE id=".$_POST["zapis"];
		    if (!($result = mysqli_query($link,$SQL))){
			    die ("Napaka pri vpisu: SQL=".$SQL."<br />");
		    }
        }else{
            $SQL = "INSERT INTO tabsola (sola,solakratko,posta,kraj,naslov,obcina,ustanovaid,ravnatelj,ravnatelj_id,pomocnik_id1,pomocnik_id2,ustanovaidmin,npzsifra,tipsole,email,internet,";
            $SQL .= "ddv_id,trr,zavezanecddv,telefon,fax,siframss,program,maticnasola) VALUES (";
            $SQL = $SQL . "'".$VSola."',";
            $SQL = $SQL . "'".$VSolaKratko."',";
            $SQL = $SQL . "'".$VPosta."',";
            $SQL = $SQL . "'".$VKraj."',";
            $SQL = $SQL . "'".$VNaslov."',";
            $SQL = $SQL . "'".$VObcina."',";
            $SQL = $SQL . $VUstanovaID.",";
            $SQL = $SQL . "'".$VRavnatelj."',";
            $SQL = $SQL . $Vravnatelj_ID.",";
            $SQL = $SQL . $VPomocnik_ID1.",";
            $SQL = $SQL . $VPomocnik_ID2.",";
            $SQL = $SQL . "'".$VUstanovaIDMin."',";
            $SQL = $SQL . "'".$VNPZSifra."',";
            $SQL = $SQL . "'".$VTipSole."',";
            $SQL = $SQL . "'".$Vemail."',";
            $SQL = $SQL . "'".$Vinternet."',";
            $SQL = $SQL . "'".$Vddv_ID."',";
            $SQL = $SQL . "'".$Vtrr."',";
            $SQL = $SQL . "'".$VzavezanecDDV."',";
            $SQL = $SQL . "'".$Vtelefon."',";
            $SQL = $SQL . "'".$Vfax."', ";
            $SQL = $SQL . "'".$SifraMSS."', ";
            $SQL = $SQL . "'".$Program."', ";
            $SQL = $SQL . "'".$MaticnaSola."' ";
            $SQL .= ")";
            if (!($result = mysqli_query($link,$SQL))){
                die ("Napaka pri vpisu: SQL=".$SQL."<br />");
            }
        }
		
		header ("Location: PodatkiOSoli.php?id=1");
    case "3": // 'vnos podatkov o šoli
        $SQL = "SELECT * FROM tabsola WHERE id=".$_POST["solaid"];
        $result = mysqli_query($link,$SQL);
        
        if ($R = mysqli_fetch_array($result)){
            $VSola=$R["Sola"];
            $VSolaKratko=$R["SolaKratko"];
            $VNaslov=$R["Naslov"];
            $VKraj=$R["Kraj"];
            $VPosta=$R["Posta"];
            $VRavnatelj=$R["Ravnatelj"];
            $VUstanovaID=$R["UstanovaID"];
            $VUstanovaIDMin=$R["UstanovaIDmin"];
            $VObcina=$R["Obcina"];
            $VPomocnik_ID1=$R["pomocnik_ID1"];
            $VPomocnik_ID2=$R["pomocnik_ID2"];
            $Vravnatelj_ID=$R["ravnatelj_ID"];
            $VNPZSifra=$R["NPZSifra"];
            $VTipSole=$R["TipSole"];
            $Vemail=$R["email"];
            $Vinternet=$R["internet"];
            $Vddv_ID=$R["ddv_ID"];
            $VzavezanecDDV=$R["zavezanecDDV"];
            $Vtrr=$R["trr"];
            $Vtelefon=$R["telefon"];
            $Vfax=$R["fax"];
            $zapis=$R["Id"];
            $SifraMSS=$R["SifraMSS"];
            $Program=$R["Program"];
            $MaticnaSola=$R["MaticnaSola"];
        }

        echo "<h2>Podatki o šoli</h2>";
        echo "<form name='podatkiSola' method=post action='PodatkiOSoli.php'>";
        echo "<table border='1'>";
        echo "<tr><td>Šola (polno ime)</td><td><input name='sola' type='text' size='60' value='".$VSola."'></td></tr>";
        echo "<tr><td>Šola (krajše)</td><td><input name='SolaKratko' type='text' size='60' value='".$VSolaKratko."'></td></tr>";
        echo "<tr><td>Naslov</td><td><input name='naslov' type='text' size='60' value='".$VNaslov."'></td></tr>";
        echo "<tr><td>Pošta</td><td><input name='posta' type='text' size='5' value='".$VPosta."'></td></tr>";
        echo "<tr><td>Kraj</td><td><input name='Kraj' type='text' size='20' value='".$VKraj."'></td></tr>";
        echo "<tr><td>Občina</td><td>";
        echo "<select name='obcina'>";
        $SQL = "SELECT * FROM TabSifreObcin ORDER BY obcina";
        $result = mysqli_query($link,$SQL);
        
        while ($R = mysqli_fetch_array($result)){
            if ($R["sifra"]==$VObcina){
                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["sifra"]." - ".$R["obcina"]."</option>";
            }else{
                echo "<option value='".$R["sifra"]."'>".$R["sifra"]." - ".$R["obcina"]."</option>";
            }
        }
        echo "</select>";
        echo "</td></tr>";
        echo "<tr><td>Davčna št.</td><td><input name='ddv_ID' type='text' size='8' value='".$Vddv_ID."'></td></tr>";
        if ($VzavezanecDDV=="DA"){
            echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox' checked='checked'></td></tr>";
        }else{
            echo "<tr><td>Zavezanec za DDV</td><td><input name='Zavezanec' type='checkbox'></td></tr>";
        }
        echo "<tr><td>TRR</td><td><input name='trr' type='text' size='16' value='".$Vtrr."'></td></tr>";
        echo "<tr><td>Telefon</td><td><input name='telefon' type='text' size='15' value='".$Vtelefon."'></td></tr>";
        echo "<tr><td>Fax</td><td><input name='fax' type='text' size='15' value='".$Vfax."'></td></tr>";
        echo "<tr><td>e-mail</td><td><input name='email' type='text' size='40' value='".$Vemail."'></td></tr>";
        echo "<tr><td>internet stran</td><td><input name='internet' type='text' size='40' value='".$Vinternet."'></td></tr>";
        echo "<tr><td>Ravnatelj</td><td>";
        echo "<select name='ravnatelj_ID'>";
        $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            if ($R["IdUcitelj"]==$Vravnatelj_ID){
                echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }else{
                echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }
        }
        echo "</select>";
        echo "</td></tr>";
        echo "<tr><td>1. pomočnik</td><td>";
        echo "<select name='pomocnik_ID1'>";
        $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            if ($R["IdUcitelj"]==$VPomocnik_ID1){
                echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }else{
                echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }
        }
        echo "</select>";
        echo "</td></tr>";
        echo "<tr><td>2. pomočnik</td><td>";
        echo "<select name='pomocnik_ID2'>";
        $SQL = "SELECT * FROM tabucitelji WHERE (status > 0) OR (idUcitelj=0) ORDER BY priimek,ime";
        $result = mysqli_query($link,$SQL);

        while ($R = mysqli_fetch_array($result)){
            if ($R["IdUcitelj"]==$VPomocnik_ID2){
                echo "<option value='".$R["IdUcitelj"]."' selected='selected'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }else{
                echo "<option value='".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</option>";
            }
        }
        echo "</select>";
        echo "</td></tr>";
        echo "<tr><td>Št. šole (Lopolis)</td><td><input name='ustanovaID' type='text' size='5' value='".$VUstanovaID."'></td></tr>";
        echo "<tr><td>Matična št.</td><td><input name='ustanovaIDmin' type='text' size='40' value='".$VUstanovaIDMin."'></td></tr>";
        echo "<tr><td>NPZ šifra šole</td><td><input name='NPZSifra' type='text' size='12' value='".$VNPZSifra."'></td></tr>";
        echo "<tr><td>Tip šole</td><td><input name='tipsole' type='text' size='20' value='".$VTipSole."'></td></tr>";
        echo "<tr><td>Šifra ministrstva</td><td><input name='SifraMSS' type='text' size='20' value='".$SifraMSS."'></td></tr>";
        echo "<tr><td>Program</td><td>";
        echo "<select name='Program'>";
        $SQL = "SELECT * FROM tabprogram";
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
            if ($R["sifra"]==$Program){
                echo "<option value='".$R["sifra"]."' selected='selected'>".$R["opis"]." - ".$R["sifra"]."</option>";
            }else{
                echo "<option value='".$R["sifra"]."'>".$R["opis"]." - ".$R["sifra"]."</option>";
            }
        }
        echo "</select>";
        echo "</td></tr>";
        echo "<tr><td>Matična šola</td><td><input name='MaticnaSola' type='text' size='20' value='".$MaticnaSola."'></td></tr>";
        echo "</table>";
        echo "<input name='id' type='hidden' value='2'>";
        echo "<input name='solaid' type='hidden' value='".$_POST["solaid"]."'>";
        echo "<input name='zapis' type='hidden' value='".$zapis."'>";
        echo "<input name='submit' type='submit' value='Popravi'>";
        echo "<input name='submit' type='submit' value='Dodaj'>";
        echo "</form><br />";
        echo "<a href='PodatkiOSoli.php?id=1'>Na izbor šole</a><br />";
        break;
}

?>

</body>
</html>
