<?php
/* 
Vstopni program po vpisu uporabniškega imena in gesla. Preveri pravilnost vpisa.
Vpiše uporabnika v log datoteko, vodi število prijavljenih,v primeru opravil obvešča uporabnike preko e-maila.
Uporabniku ponudi menije in osnovne podatke:
    - iskanje po učencih (AJAX izpis)
    - o izobraževanjih
    - o obvestilih
    - o urniku
Tabele, ki jih uporablja:
    tg_whos_online
    tabucitelji
    tabdogodek
    tabdeldogodek
    tabkontakti
    tabizobrazevanje
    tabpogodbe
    taburnik
    tabpredmeti
    tabprostori

Izhodni podatki:
    - povezave na druge programe preko menijev
    - odštevanje polurne seanse
    - podatki o avtorju
*/
require("const.php");
require("razredi.php");
require("iskanje.php");

if (isset($_POST["Uporabnik"])){
    $VUporabnik=$_POST["Uporabnik"];
}else{
    if (isset($_SESSION["Uporabnik"])){
        $VUporabnik=$_SESSION["Uporabnik"];
    }else{
        $VUporabnik="";
    }
}
if (isset($_POST["Geslo"])){
    $VGeslo=$_POST["Geslo"];
    if (strlen($VGeslo) > 0){
        $VGeslo=md5($VGeslo);
    }
}else{
    if (isset($_SESSION["Geslo"])){
        $VGeslo=$_SESSION["Geslo"];
    }else{
        $VGeslo="";
    }
}
if (($VGeslo=="") or ($VUporabnik=="") ) {
    header("Location: nepooblascen.htm");
    //echo "<script>window.location = 'nepooblascen.htm'</script>"; 
}else{
    /*
    if (!isset($_SESSION["Geslo"])){
        if (isset($_POST["sifra1"])){
            $Sifra1=$_POST["sifra1"];
        }else{
            header("Location: nepooblascen.htm");
        }    
        if (isset($_POST["sifra2"])){
            $Sifra2=$_POST["sifra2"];
        }else{
            header("Location: nepooblascen.htm");
        }
        $Sifra=intval($Sifra1)+intval($Sifra2);    
        if ($Sifra != 11110){
            header("Location: nepooblascen.htm");
        }    
    } 
    */   


    $VLogFile="log.txt";

    function RW($s){
        echo $s;
    }


    //'Fetch Time
    $timeout= $Danes->format('H')*3600+$Danes->format('i')*60+$Danes->format('s');
    $timestamp = $timeout+900;
    $VRemoteAddr=$_SERVER["REMOTE_ADDR"];
    $VFile=$VUporabnik;

    //'Insert User
    $SQL = "INSERT INTO tg_whos_online (timestamp1,ip1,file1) VALUES ('".$timestamp."','".$VRemoteAddr."','".$VFile."')";
    $result = mysqli_query($link,$SQL);
    //while ($R = mysqli_fetch_array($result)){

    //'Delete Users
    $SQL = "DELETE FROM tg_whos_online WHERE timestamp1 < '".$timeout."' OR timestamp1 > '".$timestamp."'";
    $result = mysqli_query($link,$SQL);

    //'Fetch Users Online
    $SQL = "SELECT DISTINCT ip1 FROM tg_whos_online";
    $result = mysqli_query($link,$SQL);
    $Index=0;
    while ($R = mysqli_fetch_array($result)){
        $Index=$Index+1;
    }
    $users = $Index;

    $SQL = "SELECT * FROM tabsola";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
	    $VSola=$R["SolaKratko"];
	    $VRavnatelj=$R["Ravnatelj"];
    }

    $_SESSION["Uporabnik"]=$VUporabnik;
    $_SESSION["Geslo"]=$VGeslo;

    $myFile = "log/log.txt";
    $fh = fopen($myFile,'a') or die("Ne morem odpreti log datoteke!");

    $stringData= $VUporabnik ."; ".$VRemoteAddr."; ".$Danes->format('Y-m-d H:i:s')."\n";
    fwrite ($fh,$stringData);
    fclose($fh);

    $SQL = "SELECT * FROM tabucitelji WHERE Uporabnik ='" . $VUporabnik . "' AND  Geslo='" . $VGeslo . "'";
    $result = mysqli_query($link,$SQL);
    if ($R = mysqli_fetch_array($result)){
	    $RazsirjenVnos=true;
	    $VUporabnikId=$R["IdUcitelj"];
        $ImeUp=$R["Ime"]." ".$R["Priimek"];
	    if ($R["Geslo"]=="" ) {
            header("Location: nepooblascen.htm");
	    }else{
	        if (($VUporabnik != $R["Uporabnik"]) or ($VGeslo != $R["Geslo"]))  {
                header("Location: nepooblascen.htm");
	        }else{
                ?>
                <html>
                <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                <meta name="Author" content=" AL ELEKTRONIK Aleš Drinovec s.p., Naklo">
                <meta http-equiv="pragma" content="no-cache" >
                <link rel="stylesheet" type="text/css" href="osmj2.css"> 
                <title>Prijava
                </title>
                <?php
                include("timerObj.js");
                include('menu_func.inc');
                ?>
                <script>
                 function showStudent(str)
                 {
                 if (str=="")
                   {
                   document.getElementById("txtHint").innerHTML="";
                   return;
                   } 
                 if (window.XMLHttpRequest)
                   {// code for IE7+, Firefox, Chrome, Opera, Safari
                   xmlhttp=new XMLHttpRequest();
                   }
                 else
                   {// code for IE6, IE5
                   xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                   }
                 xmlhttp.onreadystatechange=function()
                   {
                   if (xmlhttp.readyState==4 && xmlhttp.status==200)
                     {
                     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                     }
                   }
                 xmlhttp.open("GET","getstudent.php?ucenec="+str,true);
                 xmlhttp.send();
                 }
                 </script>
                 
                </head>
                <BODY">

                <?php
	            /*
                echo "<div style='font-size:8pt'>";
                switch ($users){
                    case 1:
                        echo $users." uporabnik na strani: ";
                        break;
                    case 2:
                        echo $users." uporabnika na strani: ";
                        break;
                    case 3:
                        echo $users." uporabniki na strani: ";
                        break;
                    case 4:
                        echo $users." uporabniki na strani: ";
                        break;
                    default:
                        echo $users." uporabnikov na strani: ";
                }
                $SQL = "SELECT DISTINCT tg_whos_online.file1,tabucitelji.ime,tabucitelji.priimek FROM tg_whos_online INNER JOIN tabucitelji ON tg_whos_online.file1=tabucitelji.uporabnik";
                $result1 = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R1 = mysqli_fetch_array($result1)){
                    if ($Indx > 1){
                        echo ", ".$R1["ime"]." ".$R1["priimek"];
                    }else{
                        echo $R1["ime"]." ".$R1["priimek"];
                    }
		            $Indx=$Indx+1;
                }
                echo "</div>";
                */
                echo "<noscript>Ta spletno mesto za pravilno delovanje zahteva omogočen javascript.<br /></noscript>";

	            $_SESSION["Level"]=$R["NivoDostopa"];
	            $n = $R["NivoDostopa"];
	            $VUporabnikId=$R["IdUcitelj"];
	            $ucitelj=$R["IdUcitelj"];
	            $VIdDelo=$R["IdDelo"];

                //šolsko leto
                $VLeto=PreberiLeto("solskoleto");
	            $_SESSION["solskoleto"]=$VLeto;
                //koledarsko leto
                if (!isset($_SESSION["leto"])){
                    $VLetoPregled=$ActualYear;
                }else{
                    $VLetoPregled=$_SESSION["leto"];
                }
                $_SESSION["leto"]=$VLetoPregled;
	            
                include ('menu.inc');
            //    include ('amiant_menu.php');
                //'Show Who's Online

                //izpis prijavnih podatkov - začetek
                echo "<table class='prijava'>";
                echo "<tr class='prijava'>";
                echo "<td class='prijava'>" . $R["Ime"]  . " " . $R["Priimek"] . "</td>";
                //echo "<h3><font color=red>Seansa se po 30 minutah neaktivnosti sama zaključi.</font></h3>";
                echo "<td class='prijava'>";
                switch ($R["NivoDostopa"]){
                    case 0:
                        //echo "Prijavljeni ste kot  <b>učitelj/delavec</b><br>";
                        echo "(delavec)";
                        break;
                    case 1:
                        //echo "Prijavljeni ste kot <b>razrednik</b><br>";
                        echo "(učitelj/razrednik)";
                        break;
                    case 2:
                        //echo "Prijavljeni ste kot <b>ravnatelj</b><br>";
                        echo "(ravnatelj)";
                        break;
                    case 3:
                        //echo "Prijavljeni ste kot <b>administrator</b><br>";
                        echo "(administrator)";
                }
                echo "</td>";
                echo "<td class='prijava'>";
	            echo "<form accept-charset='utf-8' name='rezultati' method='post' action='prijava.php'>";
	            echo "Šolsko leto:&nbsp;<select name='solskoleto' onchange='this.form.submit()'>";
	            echo "<option value='".$VLeto."' selected>".$VLeto."/".($VLeto+1)."</option>";
	            echo "<option value='".($VLeto-1)."'>".($VLeto-1)."/".$VLeto."</option>";
	            echo "<option value='".($VLeto+1)."'>".($VLeto+1)."/".($VLeto+2)."</option>";
	            echo "</select>&nbsp;";
	            //echo "<input name='submit' type='submit' value='Spremeni'>";
	            echo "</form>";
                echo "</td>";

                /*
                echo "<td class='prijava'>";
                echo "<form name='timerForm'>";
                echo "<input type='button' id='btnTimer'  value='Seansa se začenja ...' onclick='btnTimerClick(this.form)' />";
                echo "</form>";
                echo "</td>";
                */

                echo "<td class='prijava'>";
                switch ($users){
                    case 1:
                        echo $users." uporabnik na strani";
                        break;                           
                    case 2:
                        echo $users." uporabnika na strani";
                        break;
                    case 3:
                        echo $users." uporabniki na strani";
                        break;
                    case 4:
                        echo $users." uporabniki na strani";
                        break;
                    default:
                        echo $users." uporabnikov na strani";
                }
                echo "</td>";
                
                echo "</tr>";
                echo "</table>";
	            
                //prijavni podatki - konec
                
	            if (ND($n,"123") ) { 
		            //'iskanje učenca
		            //echo "<form accept-charset='utf-8' name='form_ucenec' method=post action='isciucenca.php'>";
                    echo "<form accept-charset='utf-8'>";
		            echo "Učenec <input name='ucenec' type='text' onkeyup='showStudent(this.value)'>";
		            //echo "<input name='submit' type='submit' value='Najdi'>";
		            echo "</form>";
                    
                    echo "<div id='txtHint'>&nbsp;</div>";
	            }
                
                //Opozorila ob novem letu - začetek
                if (ND($n,"23K")) { 
                    if ($Danes->format('m') == 1){
                        //dopusti
                        $SQL = "SELECT iducitelj FROM tabdopust WHERE leto=".$Danes->format('Y');
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) < 5){
                            echo "<h2><a href='IzpisDopustov.php'>Preverite prenos dopustov v novo koledarsko leto!</a></h2>";
                        }
                        
                        //prenosi doprinosov
                        $SQL = "SELECT ucitelj FROM tabpregleddelan WHERE datum='".$Danes->format('Y')."-01-01"."'";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) < 5){
                            echo "<h2><a href='IzpisPregledovDelaN.php'>Preverite prenos doprinosov v novo koledarsko leto!</a></h2>";
                        }
                    }
                }
                //Opozorila ob novem letu - konec
                
	            //hitri meni - začetek
                if ($SamoKadri==0){
                    $oUcitelj=new RUcitelj();
                    $oUcitelj->PreberiSe($VUporabnikId,$VLetoPregled,$VLeto);
                    $oUcitelj->IzracunPrisotnosti($VLetoPregled);
                    echo "<table class='hitrimeni'>";
                    echo "<tr class='hitrimeni'>";
                    $dopr=$oUcitelj->getDoprinos();
                    $realiz=$oUcitelj->getPotrjenRealiziranDoprinos();
                    $oUcitelj=null;
                    switch ($ActualMonth){
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            $razlika=($dopr-$realiz)/(11-$ActualMonth);
                            break;
                        case 7:
                        case 8:
                        case 9:
                            $razlika=($dopr-$realiz)/4;
                            break;
                        default:
                            $razlika=($dopr-$realiz)/(13-$ActualMonth);
                    }    
                    
                    if ($razlika <= 0){
                        echo "<td class='hitrimeni'><img src='img/zpika.png' width='20'>";
                    }else{
                        if ($razlika > 0 && $razlika <= 5){
                            echo "<td class='hitrimeni'><img src='img/svz_pika.png' width='20'><small>".number_format($razlika,2)." ur/mesec</small><br />";
                        }
                        if ($razlika > 5 && $razlika <= 10){
                            echo "<td class='hitrimeni'><img src='img/ypika.png' width='20'><small>".number_format($razlika,2)." ur/mesec</small><br />";
                        }
                        if ($razlika > 10 && $razlika <= 20){
                            echo "<td class='hitrimeni'><img src='img/or_pika.png' width='20'><small>".number_format($razlika,2)." ur/mesec</small><br />";
                        }
                        if ($razlika > 20){
                            echo "<td class='hitrimeni'><img src='img/rpika.png' width='20'><small>".number_format($razlika,2)." ur/mesec</small><br />";
                        }
                    }
                    echo "<a href='IzpisUcitelja.php?id1=1&idUcitelj=".$VUporabnikId."&letopregled=$VLetoPregled&leto=$VLeto'>Doprinosi</a></td>";
                    echo "<td class='hitrimeni'><a href='izpisredovalnice.php'>Redovalnica</a><br />";
                    echo "<a href='preverjanjeznanja.php?idd=1'>Termini kontrolk</a></td>";
                    echo "<td class='hitrimeni'><a href='VnosZapisnik.php'>Zapisniki<br />Poročila</a></td>";
                    echo "<td class='hitrimeni'><a href='izborrazredaizbor.php'>Spiski učencev</a><br />";
                    echo "<a href='izborrazreda.php?id=sporocila'>e-sporočila staršem</a></td>";
                    echo "<td class='hitrimeni'>";
                    echo "<a href='tekmovanjakrozki.php?id=101'>Tekm. v znanju</a><br />";
                    echo "<a href='tekmovanjakrozki.php?id=201'>Krožki</a><br />";
                    echo "<a href='tekmovanjakrozki.php?id=301'>Športna tekm.</a><br />";
                    echo "</td>";
                    echo "</tr>";
                    echo "</table>";
                }
                //hitri meni - konec
                
	            if ($Opravila==1 ) {
		            $indx=1;
		            $SQL = "SELECT * FROM tabzapisniktip";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
			            $Dogodki[$indx][0]=$R["tip"];
			            $Dogodki[$indx][1]=$R["povezava"];
			            $indx=$indx+1;
		            }
		            $SQL = "SELECT * FROM tabporocilotip";
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
			            $Dogodki[$indx][0]=$R["tip"];
			            $Dogodki[$indx][1]=$R["povezava"];
			            $indx=$indx+1;
		            }
		            $StDogodkov=$indx-1;
		            
		            $SQL = "SELECT tabdeldogodek.*,tabdogodek.*,tabdeldogodek.datum AS ddatum FROM ";
		            $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
		            $SQL = $SQL . "WHERE tabdeldogodek.IdUcitelj=".$VUporabnikId." AND leto=".$VLeto." AND tabdeldogodek.opravljeno=false ";
		            $SQL = $SQL . "ORDER BY year(porocilaDo),month(porocilaDo),day(porocilaDo)";
                    $result = mysqli_query($link,$SQL);
                    $num_rows = mysqli_num_rows($result);

                    if ($num_rows > 0){
			            echo "<h3>Spisek opravil:</h3>";
			            echo "<table border=1 cellspacing=0>";
			            echo "<tr bgcolor='lightcyan'><th>Št.</th><th>Opravilo</th><th>Rok</th><th>Opravljeno</th><th>Datum</th></tr>";
			            $indx=1;
                        while ($R = mysqli_fetch_array($result)){
				            if (isDate($R["ddatum"]) == "" ) {
					            echo "<tr bgcolor='khaki'>";
				            }else{
                                $datum1=new DateTime(isDate($R["ddatum"]));
                                $datum2=new DateTime(isDate($R["porocilaDo"]));
                                $interval=$datum1->diff($datum2);
					            if ($interval->days <= 0 ) {
						            echo "<tr bgcolor='lightyellow'>";
					            }else{
						            echo "<tr bgcolor='lightgreen'>";
					            }
				            }
				            echo "<td>".$indx."</td>";
				            if ($R["opravljeno"]==false ) {
					            for ($i1=1;$i1 <= $StDogodkov;$i1++){
						            if ($R["Dogodek"]==$Dogodki[$i1][0] ) {
							            echo "<td><a href='".$Dogodki[$i1][1]."'>".$R["Dogodek"]."</a></td>";
							            break;
						            }
					            }
				            }else{
					            echo "<td>".$R["Dogodek"]."</td>";
				            }
				            echo "<td>".$R["porocilaDo"]."</td>";
				            if ($R["opravljeno"]==true ) {
					            echo "<td align=center><input type='checkbox' checked='checked'></td>";
				            }else{
					            echo "<td align=center><input type='checkbox'></td>";
				            }
				            if (isDate($R["ddatum"]) != "") {
					            echo "<td align=right>".$datum1->format('d.m.Y')."</td>";
				            }else{
					            echo "<td>&nbsp;</td>";
				            }
				            echo "</tr>";
				            $indx=$indx+1;
			            }
			            echo "</table>";
		            }
	            }
                
                //povezava na zasedenost učilnic
                if ($RezervacijaProstorov){
            //        echo "<h3><a href='mrbs/' target='_blank'>Rezervacije prostorov in terminov za preverjanje znanja</a></h3>";
                    echo "<h3><a href='mrbs/' target='_blank'>Rezervacije prostorov</a></h3>";
                }
                // stanje izpolnjenosti podatkov - začetek
                if ($Semafor){
                    $StUcencev=0;
                    //preveri, če je razrednik in katerega razreda ter če je vodja aktiva
                    if (ND($n,"123")) { 
                        $VRazrednik="";
                        $SQL = "SELECT DISTINCT tabucitelji.spol,tabrazred.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
                        $SQL .= "INNER JOIN tabrazred ON tabucitelji.iducitelj=tabrazred.iducitelj) ";
                        $SQL .= "INNER JOIN tabrazdat ON tabrazred.idrazred=tabrazdat.id ";
                        $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabrazred.iducitelj=".$VUporabnikId;
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            //razrednik
                            if ($R = mysqli_fetch_array($result)){
                                $VRazrednik=$R["iducitelj"];
                                $VRazred=$R["id"];
                                $VSola=$R["idsola"];
                                $VRazredOznaka=$R["razred"].". ".$R["oznaka"];
                                $VRazred1=$R["razred"];
                                $SpolR=$R["spol"];
                                
                                //pogleda, če je kot razrednik vpisan tudi v sistemizaciji
                                $SQL = "SELECT DISTINCT tabucitelji.spol,tabucenje.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
                                $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                                $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.predmet=50";
                                $result = mysqli_query($link,$SQL);
                                if ($R = mysqli_fetch_array($result)){
                                    //razrednik po sistemizaciji
                                    if ($VRazrednik == $R["iducitelj"]){
                                        //preveri še razred
                                        if ($VRazred == $R["id"]){
                                            if ($SpolR == "M"){
                                                echo "Razrednik ".$VRazredOznaka."<br />";
                                            }else{
                                                echo "Razredničarka ".$VRazredOznaka."<br />";
                                            }
                                        }else{
                                            echo "V razrednih podatkih ste vpisani kot razrednik $VRazredOznaka razreda, v podatkih za sistemizacijo pa kot razrednik ".$R["razred"].". ".$R["oznaka"]." razreda!<br />Prosim, če obvestite administratorja.<br />";
                                        }
                                    }else{
                                        //različno vpisano v razrednih podatkoh in sistemizaciji
                                        echo "Za $VRazredOznaka so vpisani različni podatki o razredništvu!<br />Prosim, če obvestite administratorja.<br />";
                                    }
                                }
                            }
                        }else{
                            //ni razrednik vpisan pri podatkih o razredih
                            $SQL = "SELECT DISTINCT tabucitelji.spol,tabucenje.iducitelj,tabrazdat.razred,tabrazdat.oznaka,tabrazdat.id,tabrazdat.idsola FROM (tabucitelji ";
                            $SQL .= "INNER JOIN tabucenje ON tabucitelji.iducitelj=tabucenje.iducitelj) ";
                            $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                            $SQL .= "WHERE tabucenje.leto=".$VLeto." AND tabrazdat.leto=".$VLeto." AND tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.predmet=50";
                            $result = mysqli_query($link,$SQL);
                            if ($R = mysqli_fetch_array($result)){
                                //razrednik po sistemizaciji
                                $VRazrednik=$R["iducitelj"];
                                $VRazred=$R["id"];
                                $VSola=$R["idsola"];
                                $VRazredOznaka=$R["razred"].". ".$R["oznaka"];
                                $VRazred1=$R["razred"];
                                if ($R["spol"] == "M"){
                                    echo "Razrednik ".$VRazredOznaka."<br />";
                                }else{
                                    echo "Razredničarka ".$VRazredOznaka."<br />";
                                }
                            }
                        }
                        //preveri vodenje aktiva
                        $VAktiv="";
                        $VIdAktiv=0;
                        $SQL = "SELECT DISTINCT tabvodjeaktivov.iducitelj,tabaktiv.aktiv,tabaktiv.id FROM (tabucitelji ";
                        $SQL .= "INNER JOIN tabvodjeaktivov ON tabucitelji.iducitelj=tabvodjeaktivov.iducitelj) ";
                        $SQL .= "INNER JOIN tabaktiv ON tabvodjeaktivov.idaktiv=tabaktiv.id ";
                        $SQL .= "WHERE tabvodjeaktivov.leto=".$VLeto." AND tabvodjeaktivov.iducitelj=".$VUporabnikId;
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            $VAktiv=$R["aktiv"];
                            $VIdAktiv=$R["id"];
                            echo "Ste vodja aktiva: ".$VAktiv."<br />";
                        }
                        //preveri vodenje aktiva v naslednjem letu
                        $VAktivN="";
                        $VIdAktivN=0;
                        $SQL = "SELECT DISTINCT tabvodjeaktivov.iducitelj,tabaktiv.aktiv,tabaktiv.id FROM (tabucitelji ";
                        $SQL .= "INNER JOIN tabvodjeaktivov ON tabucitelji.iducitelj=tabvodjeaktivov.iducitelj) ";
                        $SQL .= "INNER JOIN tabaktiv ON tabvodjeaktivov.idaktiv=tabaktiv.id ";
                        $SQL .= "WHERE tabvodjeaktivov.leto=".($VLeto+1)." AND tabvodjeaktivov.iducitelj=".$VUporabnikId;
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
                            $VAktivN=$R["aktiv"];
                            $VIdAktivN=$R["id"];
                            echo "Ste vodja aktiva: ".$VAktivN."<br />";
                        }
                        
                        echo "<table class='condensed' >";
                        echo "<tr><th>Rubrika</th><th>Status</th><th>Opombe</th></tr>";
                        if ($VRazrednik > 0){
                            //razrednik
                            //pripravljeni podatki za spričevalo za določen razred
                            $NUspeh=0;
                            $NPonavljalec=0;
                            $NNapreduje=0;
                            $NRazredniIzpit=0;
                            $NNadarjen=0;
                            $NSportnik=0;
                            $NKulturnik=0;
                            $NEvid=0;
                            $NDatum=0;
                            $SQL = "SELECT uspeh,ponavljalec,napredovanje,razredniizpit,nadarjen,statussport,statuskult,evidst,datumizdaje FROM tabrazred ";
                            $SQL .= "WHERE idrazred=".$VRazred;
                            $result = mysqli_query($link,$SQL);
                            while ($R = mysqli_fetch_array($result)){
                                if (isset($R["uspeh"])){
                                    if ($R["uspeh"] > 0){
                                        $NUspeh += 1;
                                    }
                                }
                                if (isset($R["ponavljalec"])){
                                    if ($R["ponavljalec"] > 0){
                                        $NPonavljalec += 1;
                                    }
                                }
                                if (isset($R["napredovanje"])){
                                    if ($R["napredovanje"] > 0){
                                        $NNapreduje += 1;
                                    }
                                }
                                if (isset($R["razredniizpit"])){
                                    if ($R["razredniizpit"] > 0){
                                        $NRazredniIzpit += 1;
                                    }
                                }
                                if (isset($R["nadarjen"])){
                                    if ($R["nadarjen"] > 0){
                                        $NNadarjen += 1;
                                    }
                                }
                                if (isset($R["statussport"])){
                                    if ($R["statussport"] > 0){
                                        $NSportnik += 1;
                                    }
                                }
                                if (isset($R["statuskult"])){
                                    if ($R["statuskult"] > 0){
                                        $NKulturnik += 1;
                                    }
                                }
                                if (isset($R["evidst"])){
                                    if (strlen($R["evidst"]) == 0){
                                        $NEvid += 1;
                                    }
                                }else{
                                    $NEvid += 1;
                                }
                                if (isset($R["datumizdaje"])){
                                    if (strlen($R["datumizdaje"]) == 0){
                                        $NDatum += 1;
                                    }
                                }else{
                                    $NDatum += 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td><a href='vnesiocene.php?id=7&razred=".$VRazred."&solskoleto=".$VLeto."'>Podatki za spričevalo, nadarjeni, statusi</a></td>";
                            if ($NEvid > 0 or $NDatum > 0){
                                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            echo "Uspeh ima vpisano $NUspeh učencev, razred ponavlja $NPonavljalec učencev, ne napreduje oz. z nezadostno napreduje $NNapreduje učencev, razredni izpit ima $NRazredniIzpit učencev, ";
                            echo "nadarjenih je $NNadarjen učencev, status športnika ima $NSportnik učencev, status kulturnika ima $NKulturnik učencev, evidenčno številko nima vpisanih $NEvid učencev, datuma izdaje spričevala nima vpisanih $NDatum učencev.";
                            echo "</td>";
                            echo "</tr>";
                            
                            //vpisane zaključne ocene
                            switch ($ActualMonth){
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                    if ($VRazred1 < 3){
                                        //opisne ocene - preveri, če je kdo, ki nima vpisane nobene v nobeni od tabel
                                        $SQL = "SELECT iducenec FROM tabrazred WHERE iducitelj=".$VUporabnikId." AND leto=".$VLeto;
                                        $result = mysqli_query($link,$SQL);
                                        $iu=1;
                                        while ($R = mysqli_fetch_array($result)){
                                             $ucenci[$iu]=$R["iducenec"];
                                             $iu += 1;
                                        }
                                        $StUcencev=$iu-1;
                                        $NNeocenjeno=0;
                                        for ($iu=1;$iu <= $StUcencev;$iu++){
                                            //izbiranje s kljukicami
                                            $NOcen1[$iu]=0;
                                            $NOcen2[$iu]=0;
                                            $NOcen3[$iu]=0;
                                            $SQL = "SELECT iducenec FROM tabopocene WHERE leto=".$VLeto." AND iducenec=".$ucenci[$iu]." AND tip=0";
                                            $result = mysqli_query($link,$SQL);
                                            if (mysqli_num_rows($result) == 0){
                                                $NOcen1[$iu] += 1;
                                            }
                                            //ocenjevanje z ocenami ciljev
                                            $SQL = "SELECT iducenec FROM tabopocenen WHERE leto=".$VLeto." AND iducenec=".$ucenci[$iu]." AND tip=0";
                                            $result = mysqli_query($link,$SQL);
                                            if (mysqli_num_rows($result) == 0){
                                                $NOcen2[$iu] += 1;
                                            }
                                            //ročni vpisi
                                            $SQL = "SELECT ucenec,slo,mat,spo,lvz,gvz,svz FROM tabopocucenec WHERE leto=".$VLeto." AND ucenec=".$ucenci[$iu];
                                            $result = mysqli_query($link,$SQL);
                                            if ($R = mysqli_fetch_array($result)){
						                        if (isset($R["slo"])){
							                        if (strlen($R["slo"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
						                        
						                        if (isset($R["mat"])){
							                        if (strlen($R["mat"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
						                        if (isset($R["spo"])){
							                        if (strlen($R["spo"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
						                        if (isset($R["lvz"])){
							                        if (strlen($R["lvz"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
						                        if (isset($R["gvz"])){
							                        if (strlen($R["gvz"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
						                        if (isset($R["svz"])){
							                        if (strlen($R["svz"]) == 0){
								                        $NOcen3[$iu] += 1;
							                        }
						                        }else{
							                        $NOcen3[$iu] += 1;
						                        }
                                            }else{
                                                $NOcen3[$iu] += 1;
                                            }
                                            if ($NOcen1[$iu] > 0 && $NOcen2[$iu] > 0 && $NOcen3[$iu] > 0){
                                                $NNeocenjeno += 1;
                                            }
                                        }
                                        echo "<tr>";
                                        echo "<td>";
                                        echo "<a href='opisneocene.php?idd=200'>Vnos opisnih ocen (kljukice ali ročno)</a><br />";
                                        echo "<a href='opisneocenen.php?idd=200'>Vnos opisnih ocen (ocenjevanje ciljev)</a>";
                                        echo "</td>";
                                        if ($NNeocenjeno > 0){
                                            echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        }else{
                                            echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                        }
                                        echo "<td>";
                                        if ($NNeocenjeno > 0){
                                            echo "V vašem razredu je $NNeocenjeno učencev brez zaključnih ocen.";
                                        }else{
                                            echo "V vašem razredu ni učencev brez zaključnih ocen.";
                                        }                        
                                        echo "</td>";
                                        echo "</tr>";
                                    }else{
                                        //številčne ocene
                                        $NNeocenjeno=0;
                                        $NOpraviceno=0;
                                        $NNezakljuceno=0;
                                        $SQL = "SELECT tabocene.neocenjen,tabocene.ocenakoncna,tabocene.iducenec FROM tabrazred ";
                                        $SQL .= "LEFT JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec ";
                                        $SQL .= "WHERE idrazred=".$VRazred." AND tabocene.leto=".$VLeto;
                                        $result = mysqli_query($link,$SQL);
                                        while ($R = mysqli_fetch_array($result)){
                                             if (isset($R["neocenjen"])){
                                                 switch ($R["neocenjen"]){
                                                     case 1:
                                                        $NNeocenjeno += 1;
                                                        break;
                                                     case 2:
                                                        $NOpraviceno += 1;                                
                                                        break;
                                                     default:
                                                        if (isset($R["ocenakoncna"])){
                                                            if (intval($R["ocenakoncna"]) == 0){
                                                                $NNezakljuceno += 1;
                                                            }
                                                        }
                                                 }
                                             }
                                        }
                                        echo "<tr>";
                                        echo "<td><a href='izpisredovalnice.php?id=4&razred=$VRazred&solskoleto=$VLeto'>Vnos ocen v redovalnico</a></td>";
                                        if ($NNezakljuceno > 0){
                                            echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        }else{
                                            echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                        }
                                        echo "<td>";
                                        if ($NNezakljuceno > 0){
                                            echo "Neocenjenih je $NNeocenjeno učencev, ocenjevanja opravičenih je $NOpraviceno učencev, nezaključenih je $NNezakljuceno ocen v vašem razredu.";
                                        }else{
                                            echo "Vsi učenci v vašem razredu imajo zaključne ocene (neocenjenih je $NNeocenjeno učencev, ocenjevanja opravičenih je $NOpraviceno učencev).";
                                        }
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    break;
                            }
                            
                            switch ($ActualMonth){
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                    //pedagoško poročilo - polletno
                                    $Komentar="";
                                    $UcnoVzgDelo="";
                                    $Pohvale="";
                                    $VzgUkrepi="";
                                    $Uspehi="";
                                    $Priporocila="";
                                    $SQL = "SELECT id,komentar,ucnovzgdelo,pohvale,vzgukrepi,uspehi,priporocila FROM tabrazrednikpor WHERE leto=".$VLeto." AND razrednik=".$VUporabnikId." AND idrazred=".$VRazred;
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $Porocilo=true;
                                        $Komentar=mb_substr($R["komentar"],0,25,$encoding);
                                        $UcnoVzgDelo=mb_substr($R["ucnovzgdelo"],0,25,$encoding);
                                        $Pohvale=mb_substr($R["pohvale"],0,25,$encoding);
                                        $VzgUkrepi=mb_substr($R["vzgukrepi"],0,25,$encoding);
                                        $Uspehi=mb_substr($R["uspehi"],0,25,$encoding);
                                        $Priporocila=mb_substr($R["priporocila"],0,25,$encoding);
                                    }else{
                                        $Porocilo=false;
                                    }
                                    echo "<tr>";
                                    echo "<td><a href='PedPorocilo.php?id=0a'>Vnos polletnega pedagoškega poročila</a></td>";
                                    if (!$Porocilo){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if ($Komentar){
                                        echo $Komentar." ...<br />";
                                    }
                                    if ($UcnoVzgDelo){
                                        echo $UcnoVzgDelo." ...<br />";
                                    }
                                    if ($Pohvale){
                                        echo $Pohvale." ...<br />";
                                    }
                                    if ($VzgUkrepi){
                                        echo $VzgUkrepi." ...<br />";
                                    }
                                    if ($Uspehi){
                                        echo $Uspehi." ...<br />";
                                    }
                                    if ($Priporocila){
                                        echo $Priporocila." ...";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                    break;
                            }
                            
                            switch ($ActualMonth){
                                case 6:
                                case 7:
                                case 8:
                                    //pedagoško poročilo - končno
                                    $Komentar="";
                                    $UcnoVzgDelo="";
                                    $Pohvale="";
                                    $VzgUkrepi="";
                                    $Uspehi="";
                                    $Priporocila="";
                                    $SQL = "SELECT id,komentar,ucnovzgdelo,pohvale,vzgukrepi,uspehi,priporocila FROM tabrazrednikpork WHERE leto=".$VLeto." AND razrednik=".$VUporabnikId." AND idrazred=".$VRazred;
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $Porocilo=true;
                                        $Komentar=mb_substr($R["komentar"],0,25,$encoding);
                                        $UcnoVzgDelo=mb_substr($R["ucnovzgdelo"],0,25,$encoding);
                                        $Pohvale=mb_substr($R["pohvale"],0,25,$encoding);
                                        $VzgUkrepi=mb_substr($R["vzgukrepi"],0,25,$encoding);
                                        $Uspehi=mb_substr($R["uspehi"],0,25,$encoding);
                                        $Priporocila=mb_substr($R["priporocila"],0,25,$encoding);
                                    }else{
                                        $Porocilo=false;
                                    }
                                    echo "<tr>";
                                    echo "<td><a href='PedPorocilo.php?id=0b'>Vnos končnega pedagoškega poročila</a></td>";
                                    if (!$Porocilo){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if ($Komentar){
                                        echo $Komentar." ...<br />";
                                    }
                                    if ($UcnoVzgDelo){
                                        echo $UcnoVzgDelo." ...<br />";
                                    }
                                    if ($Pohvale){
                                        echo $Pohvale." ...<br />";
                                    }
                                    if ($VzgUkrepi){
                                        echo $VzgUkrepi." ...<br />";
                                    }
                                    if ($Uspehi){
                                        echo $Uspehi." ...<br />";
                                    }
                                    if ($Priporocila){
                                        echo $Priporocila." ...";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                    break;
                            }
                            
                            switch ($ActualMonth){
                                case 1:
                                case 2:
                                case 6:
                                case 7:
                                    if ($SemaforRealizacija){
                                        //razredna realizacija
                                        $SQL = "SELECT planpol,realizacijapol,plan,realizacija FROM tabrealizacija WHERE idrazred=".$VRazred;
                                        $result = mysqli_query($link,$SQL);
                                        $NiVpisa1=0;
                                        $NiVpisa2=0;
                                        while ($R = mysqli_fetch_array($result)){
                                            if (isset($R["realizacija"])){
                                                if ($R["realizacija"] == 0 && $R["plan"] > 0){
                                                    $NiVpisa2 += 1;
                                                }
                                            }else{
                                                $NiVpisa2 += 1;
                                            }
                                            if (isset($R["realizacijapol"])){
                                                if ($R["realizacijapol"] == 0 && $R["planpol"] > 0){
                                                    $NiVpisa1 += 1;
                                                }
                                            }else{
                                                $NiVpisa1 += 1;
                                            }
                                        }
                                        echo "<tr>";
                                        echo "<td>";
                                        echo "<a href='VnosRealizacije.php?razred=$VRazred'>Realizacija ur za razred</a><br />";
                                        echo "</td>";
                                        if ($NiVpisa1 > 0 or $NiVpisa2 > 0){
                                            echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        }else{
                                            echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                        }
                                        echo "<td>";
                                        if ($NiVpisa1+$NiVpisa2 > 0){
                                            echo "Manjka realizacija za $NiVpisa1 dejavnosti ob polletju in za $NiVpisa2 ob koncu leta.";
                                        }else{
                                            echo "Vpisana je vsa realizacija.";
                                        }
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    break;
                            }
                            
                            switch ($ActualMonth){
                                case 9:
                                case 10:
                                    //predstavniki v svet staršev
                                    $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
                                    $result = mysqli_query($link,$SQL);
                                    $Vpis=0;
                                    while ($R = mysqli_fetch_array($result)){
                                        $SQL = "SELECT svet FROM tabsvetstarsev WHERE iducenec=".$R["iducenec"];
                                        $result1 = mysqli_query($link,$SQL);
                                        while ($R1 = mysqli_fetch_array($result1)){
                                            $Vpis += 1;
                                        }
                                    }
                                    echo "<tr>";
                                    echo "<td>";
                                    echo "<a href='izpisrazreda.php?id=5&razred=$VRazred'>Predstavniki v svetu staršev</a><br />";
                                    echo "</td>";
                                    if ($Vpis == 0){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if ($Vpis == 0){
                                        echo "Manjkajo predstavniki v svetu staršev.";
                                    }else{
                                        echo "Predstavniki v svetu staršev so vpisani.";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                    break;
                            }
                            
                            //opb in juv
                            if ($VRazred1 < 6){
                                $SQL = "SELECT iducenec FROM tabrazred WHERE iducitelj=".$VUporabnikId." AND leto=".$VLeto;
                                $result = mysqli_query($link,$SQL);
                                $iu=1;
                                while ($R = mysqli_fetch_array($result)){
                                     $ucenci[$iu]=$R["iducenec"];
                                     $iu += 1;
                                }
                                $StUcencev=$iu-1;
                                $Nvpisano=$StUcencev;
                                for ($iu=1;$iu <= $StUcencev;$iu++){
                                    $SQL = "SELECT id FROM tabopb ";
                                    $SQL .= "WHERE iducenec=".$ucenci[$iu]." AND leto=".$VLeto;
                                    $result = mysqli_query($link,$SQL);
                                    if ($R = mysqli_fetch_array($result)){
                                        $Nvpisano -= 1;
                                    }
                                }
                                echo "<tr>";
                                echo "<td>";
                                echo "<a href='izborrazreda.php?id=opb'>Vnos učancev za OPB in JUV</a><br />";
                                echo "</td>";
                                if ($Nvpisano > 0){
                                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                }else{
                                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                }
                                echo "<td>";
                                if ($Nvpisano > 0){
                                    echo "Manjkajo podatki o OPB in JUV za $Nvpisano učencev.";
                                }else{
                                    echo "Vsi podatki o OPB in JUV so vpisani.";
                                }
                                echo "</td>";
                                echo "</tr>";
                            }
                            
                            //soglasja staršev
                            $SQL = "SELECT tabdovoljenja.id FROM tabrazred ";
                            $SQL .= "LEFT JOIN tabdovoljenja ON tabrazred.iducenec=tabdovoljenja.iducenec ";
                            $SQL .= "WHERE idrazred=".$VRazred;
                            $result = mysqli_query($link,$SQL);
                            $NiVpisa=0;
                            while ($R = mysqli_fetch_array($result)){
                                if (!isset($R["id"])){
                                    $NiVpisa += 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='vnosispiski.php?idd=108&razred=$VRazred'>Soglasja za objave in zdrav življenski slog</a><br />";
                            echo "</td>";
                            if ($NiVpisa > 0){
                                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            if ($NiVpisa){
                                echo "Manjka vpis soglasij za $NiVpisa učencev.";
                            }else{
                                echo "Vsi učenci imajo vpisana soglasja.";
                            }
                            echo "</td>";
                            echo "</tr>";
                            
                            //podatki o naročilu prehrane
                            if ($SemaforPrehrana){
                                $SQL = "SELECT tabprehrana.id FROM tabrazred ";
                                $SQL .= "LEFT JOIN tabprehrana ON tabrazred.iducenec=tabprehrana.iducenec ";
                                $SQL .= "WHERE tabrazred.idrazred=".$VRazred;
                                $result = mysqli_query($link,$SQL);
                                $NiVpisa=0;
                                while ($R = mysqli_fetch_array($result)){
                                    if (!isset($R["id"])){
                                        $NiVpisa += 1;
                                    }
                                }
                                echo "<tr>";
                                echo "<td>";
                                echo "<a href='vnosispiski.php?idd=105&razred=$VRazred'>Naročilo prehrane</a><br />";
                                echo "</td>";
                                if ($NiVpisa > 0){
                                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                }else{
                                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                }
                                echo "<td>";
                                if ($NiVpisa > 0){
                                    echo "Manjkajo podatki za $NiVpisa učencev.";
                                }else{
                                    echo "Vsi učenci imajo vpisane podatki o prehrani.";
                                }
                                echo "</td>";
                                echo "</tr>";
                                
                                //mesečni podatki o malici
                                $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
                                $result = mysqli_query($link,$SQL);
                                $iu=1;
                                while ($R = mysqli_fetch_array($result)){
                                     $ucenci[$iu]=$R["iducenec"];
                                     $iu += 1;
                                }
                                $StUcencev= $iu-1;
                                $malic[1]=$StUcencev;
                                $malic[2]=$StUcencev;
                                $malic[3]=$StUcencev;
                                $malic[4]=$StUcencev;
                                $malic[5]=$StUcencev;
                                $malic[6]=$StUcencev;
                                $malic[9]=$StUcencev;
                                $malic[10]=$StUcencev;
                                $malic[11]=$StUcencev;
                                $malic[12]=$StUcencev;
                                for ($iu=1;$iu <= $StUcencev;$iu++){
                                    $SQL = "SELECT DISTINCT tabmalica.iducenec,tabmalica.mesec,tabmalica.leto FROM tabmalica ";
                                    $SQL .= "WHERE tabmalica.iducenec=".$ucenci[$iu]." AND ((leto=".$VLeto." AND mesec > 8) OR (leto=".($VLeto+1)." AND mesec < 7))";
                                    $result = mysqli_query($link,$SQL);
                                    while ($R = mysqli_fetch_array($result)){
                                        $malic[intval($R["mesec"])] -= 1;
                                    }
                                }
                                echo "<tr>";
                                echo "<td>";
                                echo "<a href='izborrazreda.php?id=malice'>Vnos podatkov o malicah</a><br />";
                                echo "</td>";
                                if ($malic[1]+$malic[2]+$malic[3]+$malic[4]+$malic[5]+$malic[6]+$malic[9]+$malic[10]+$malic[11]+$malic[12] > 0){
                                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                }else{
                                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                }
                                echo "<td>";
                                if ($malic[1]+$malic[2]+$malic[3]+$malic[4]+$malic[5]+$malic[6]+$malic[9]+$malic[10]+$malic[11]+$malic[12] > 0){
                                    echo "Po mesecih manjkajo vpisi za št. učencev: ";
                                    if ($malic[9] > 0){
                                        echo "sep ".$malic[9].", ";
                                    }
                                    if ($malic[10] > 0){
                                        echo "okt ".$malic[10].", ";
                                    }
                                    if ($malic[11] > 0){
                                        echo "nov ".$malic[11].", ";
                                    }
                                    if ($malic[12] > 0){
                                        echo "dec ".$malic[12].", ";
                                    }
                                    if ($malic[1] > 0){
                                        echo "jan ".$malic[1].", ";
                                    }
                                    if ($malic[2] > 0){
                                        echo "feb ".$malic[2].", ";
                                    }
                                    if ($malic[3] > 0){
                                        echo "mar ".$malic[3].", ";
                                    }
                                    if ($malic[4] > 0){
                                        echo "apr ".$malic[4].", ";
                                    }
                                    if ($malic[5] > 0){
                                        echo "maj ".$malic[5].", ";
                                    }
                                    if ($malic[6] > 0){
                                        echo "jun ".$malic[6];
                                    }
                                }else{
                                    echo "Vpisani so podatki za vse učence.";
                                }
                                echo "</td>";
                                echo "</tr>";
                            }

                            //mesečni izostanki
                            /*
                            $SQL = "SELECT iducenec FROM tabrazred WHERE idrazred=".$VRazred;
                            $result = mysqli_query($link,$SQL);
                            $iu=1;
                            while ($R = mysqli_fetch_array($result)){
                                 $ucenci[$iu]=$R["iducenec"];
                                 $iu += 1;
                            }
                            $StUcencev= $iu-1;
                            */
                            $ods[1]=$StUcencev;
                            $ods[2]=$StUcencev;
                            $ods[3]=$StUcencev;
                            $ods[4]=$StUcencev;
                            $ods[5]=$StUcencev;
                            $ods[6]=$StUcencev;
                            $ods[9]=$StUcencev;
                            $ods[10]=$StUcencev;
                            $ods[11]=$StUcencev;
                            $ods[12]=$StUcencev;
                            for ($iu=1;$iu <= $StUcencev;$iu++){
                                $SQL = "SELECT iducenec,mesec,leto FROM tabprisotnost ";
                                $SQL .= "WHERE tabprisotnost.iducenec=".$ucenci[$iu]." AND leto=".$VLeto;
                                $result = mysqli_query($link,$SQL);
                                while ($R = mysqli_fetch_array($result)){
                                    $ods[intval($R["mesec"])] -= 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='izborrazreda.php?id=odsotnost'>Vnos podatkov o izostankih učencev</a><br />";
                            echo "</td>";
                            if ($ods[1]+$ods[2]+$ods[3]+$ods[4]+$ods[5]+$ods[6]+$ods[9]+$ods[10]+$ods[11]+$ods[12] > 0){
                                echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            if ($ods[1]+$ods[2]+$ods[3]+$ods[4]+$ods[5]+$ods[6]+$ods[9]+$ods[10]+$ods[11]+$ods[12] > 0){
                                echo "Po mesecih manjkajo vpisi za št. učencev: ";
                                if ($ods[9] > 0){
                                    echo "sep ".$ods[9].", ";
                                }
                                if ($ods[10] > 0){
                                    echo "okt ".$ods[10].", ";
                                }
                                if ($ods[11] > 0){
                                    echo "nov ".$ods[11].", ";
                                }
                                if ($ods[12] > 0){
                                    echo "dec ".$ods[12].", ";
                                }
                                if ($ods[1] > 0){
                                    echo "jan ".$ods[1].", ";
                                }
                                if ($ods[2] > 0){
                                    echo "feb ".$ods[2].", ";
                                }
                                if ($ods[3] > 0){
                                    echo "mar ".$ods[3].", ";
                                }
                                if ($ods[4] > 0){
                                    echo "apr ".$ods[4].", ";
                                }
                                if ($ods[5] > 0){
                                    echo "maj ".$ods[5].", ";
                                }
                                if ($ods[6] > 0){
                                    echo "jun ".$ods[6];
                                }
                            }else{
                                echo "Vpisani so vsi podatki o odsotnostih.";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        //podatki vodij aktivov
                        switch ($ActualMonth){
                            case 5:
                            case 6:
                            case 7:
                                if (strlen($VAktiv) > 0){
                                    //poročilo aktiva
                                    $SQL = "SELECT id,programdela FROM tabaktivporocilo WHERE leto=".$VLeto." AND aktiv=".$VIdAktiv;
                                    $result = mysqli_query($link,$SQL);
                                    $NiVpisa=0;
                                    $Vsebina="";
                                    if ($R = mysqli_fetch_array($result)){
                                        $NiVpisa += 1;
                                        $Vsebina=mb_substr($R["programdela"],0,25,$encoding);
                                    }

                                    echo "<tr>";
                                    echo "<td>";
                                    echo "<a href='IzborAktiviPorocilo.php?id=1a'>Vnos poročila aktiva</a><br />";
                                    echo "</td>";
                                    if ($NiVpisa == 0){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if (strlen($Vsebina) > 0){
                                        echo $Vsebina." ...";
                                    }else{
                                        echo "Ni vsebine!";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                                if (strlen($VAktiv) > 0){
                                    //načrt aktiva
                                    $SQL = "SELECT id,programdela FROM tabaktivplan WHERE leto=".($VLeto+1)." AND aktiv=".$VIdAktiv;
                                    $result = mysqli_query($link,$SQL);
                                    $NiVpisa=0;
                                    $Vsebina="";
                                    if ($R = mysqli_fetch_array($result)){
                                        $NiVpisa += 1;
                                        $Vsebina=mb_substr($R["programdela"],0,25,$encoding);
                                    }

                                    echo "<tr>";
                                    echo "<td>";
                                    echo "<a href='IzborAktiviPorocilo.php?id=1b'>Vnos načrta dela aktiva za naslednje ŠL</a><br />";
                                    echo "</td>";
                                    if ($NiVpisa == 0){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if (strlen($Vsebina) > 0){
                                        echo $Vsebina." ...";
                                    }else{
                                        echo "Ni vsebine!";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                                break;
                        }
                        
                        //podatki nerazrednikov
                        switch ($ActualMonth){
                            case 1:
                            case 2:
                                //nevpisane ocene prvega polletja
                                $StNeocenjenih=0;
                                $SQL = "SELECT tabucenje.predmet,tabucenje.idrazred,tabpredmeti.prioriteta,tabpredmeti.oznaka AS poznaka,tabrazdat.razred,tabrazdat.oznaka FROM (tabucenje ";
                                $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id) ";
                                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                                $SQL .= "WHERE tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.leto=".$VLeto." AND tabucenje.idrazred > 0 AND tabpredmeti.prioriteta IN (0,1)";
                                $result = mysqli_query($link,$SQL);
                                $NeocRazredi="";
                                while ($R = mysqli_fetch_array($result)){
                                    $StN=$StNeocenjenih;
                                    $SQL = "SELECT tabocene.ocenas1p,tabocene.ocenas1u,tabocene.iducenec FROM tabrazred ";
                                    $SQL .="INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec ";
                                    $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazred.idrazred=".$R["idrazred"]." AND tabocene.idpredmet=".$R["predmet"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        if ($R["prioriteta"] == 1){
                                            //izbirni predmet
                                            $SQL = "SELECT id FROM tabizbirni WHERE leto=".$VLeto." AND ucenec=".$R1["iducenec"]." AND izbirni=".$R["predmet"];
                                            $result2 = mysqli_query($link,$SQL);
                                            if ($R2 = mysqli_fetch_array($result2)){
                                                if (strlen($R1["ocenas1p"]) == 0 && strlen($R1["ocenas1u"]) == 0){
                                                    $StNeocenjenih += 1;
                                                }
                                            }
                                        }else{
                                            if (strlen($R1["ocenas1p"]) == 0 &&  strlen($R1["ocenas1u"]) == 0){
                                                $StNeocenjenih += 1;
                                            }
                                        }
                                    }
                                    if ($StN < $StNeocenjenih){
                                        $NeocRazredi .= "<a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>".$R["razred"].$R["oznaka"]."-".$R["poznaka"]."</a>"." ";
                                    }
                                }
                                echo "<tr>";
                                echo "<td>";
                                echo "<a href='izpisredovalnice.php'>Ocene učencev ob polletju</a><br />";
                                echo "</td>";
                                if ($StNeocenjenih > 0){
                                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                }else{
                                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                }
                                echo "<td>";
                                if ($StNeocenjenih > 0){
                                    echo "Manjka $StNeocenjenih vpisanih ocen prvega polletja pri vaših predmetih. ".$NeocRazredi;
                                }else{
                                    echo "Vsi vaši učenci imajo vpisane ocene prvega polletja.";
                                }
                                echo "</td>";
                                echo "</tr>";
                                break;
                        }
                        
                        switch ($ActualMonth){
                            case 1:
                            case 2:
                            case 6:
                            case 7:
                            case 8:
                                //nezaključene ocene
                                $StNeocenjenih=0;
                                $SQL = "SELECT tabucenje.predmet,tabucenje.idrazred,tabpredmeti.prioriteta,tabpredmeti.oznaka AS poznaka,tabrazdat.razred,tabrazdat.oznaka FROM (tabucenje ";
                                $SQL .= "INNER JOIN tabpredmeti ON tabucenje.predmet=tabpredmeti.id) ";
                                $SQL .= "INNER JOIN tabrazdat ON tabucenje.idrazred=tabrazdat.id ";
                                $SQL .= "WHERE tabucenje.iducitelj=".$VUporabnikId." AND tabucenje.leto=".$VLeto." AND tabucenje.idrazred > 0 AND tabpredmeti.prioriteta IN (0,1)";
                                $result = mysqli_query($link,$SQL);
                                $NeocRazredi="";
                                while ($R = mysqli_fetch_array($result)){
				                    $StN=$StNeocenjenih;
                                    $SQL = "SELECT tabocene.neocenjen,tabocene.ocenakoncna,tabocene.iducenec FROM tabrazred ";
                                    $SQL .="INNER JOIN tabocene ON tabrazred.iducenec=tabocene.iducenec ";
                                    $SQL .= "WHERE tabrazred.leto=".$VLeto." AND tabocene.leto=".$VLeto." AND tabrazred.idrazred=".$R["idrazred"]." AND tabocene.idpredmet=".$R["predmet"];
                                    $result1 = mysqli_query($link,$SQL);
                                    while ($R1 = mysqli_fetch_array($result1)){
                                        if ($R["prioriteta"] == 1){
                                            //izbirni predmet
                                            $SQL = "SELECT id FROM tabizbirni WHERE leto=".$VLeto." AND ucenec=".$R1["iducenec"]." AND izbirni=".$R["predmet"];
                                            $result2 = mysqli_query($link,$SQL);
                                            if ($R2 = mysqli_fetch_array($result2)){
                                                if (intval($R1["ocenakoncna"]) == 0 && $R1["neocenjen"] == 0){
                                                    $StNeocenjenih += 1;
                                                }
                                            }
                                        }else{
                                            if (intval($R1["ocenakoncna"]) == 0 &&  $R1["neocenjen"] == 0){
                                                $StNeocenjenih += 1;
                                            }
                                        }
                                    }
				                    if ($StN < $StNeocenjenih){
					                    $NeocRazredi .= "<a href='izpisredovalnice.php?id=4&razred=".$R["idrazred"]."'>".$R["razred"].$R["oznaka"]."-".$R["poznaka"]."</a>"." ";
				                    }
                                }
                                echo "<tr>";
                                echo "<td>";
                                echo "<a href='izpisredovalnice.php'>Zaključne ocene učencev</a><br />";
                                echo "</td>";
                                if ($StNeocenjenih > 0){
                                    echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                }else{
                                    echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                }
                                echo "<td>";
                                if ($StNeocenjenih > 0){
                                    echo "Manjka $StNeocenjenih zaključnih ocen pri vaših predmetih. ".$NeocRazredi;
                                }else{
                                    echo "Vsi vaši učenci imajo zaključne ocene.";
                                }
                                echo "</td>";
                                echo "</tr>";
                                break;
                        }
                        
                        //poročila o tekmovanjih v znanju
                        $Nepopoln=0;
                        $SQL = "SELECT porocilo FROM tabdrtekm WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            while ($R = mysqli_fetch_array($result)){
                                if (isset($R["porocilo"])){
                                    if (strlen($R["porocilo"]) == 0){
                                        $Nepopoln += 1;
                                    }
                                }else{
                                    $Nepopoln += 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju</a><br />";
                            echo "</td>";
                            if ($Nepopoln > 0){
                                switch ($ActualMonth){
                                    case 5:
                                    case 6:
                                    case 7:
                                    case 8:
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        break;
                                    default:
                                        echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                                }
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            if ($Nepopoln > 0){
                                echo "Vpisanih imate $Nepopoln tekmovanj brez poročil.";
                            }else{
                                echo "Vsa vaša tekmovanja vsebujejo poročila.";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju</a><br />";
                            echo "</td>";
                            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                            echo "<td>";
                            echo "Na vaše ime ni vpisanih tekmovanj v znanju.";
                            echo "</td>";
                            echo "</tr>";
                        }
                     
                        //poročila o interesnih dejavnostih
                        $Nepopoln=0;
                        $SQL = "SELECT porocilo FROM tabkrozki WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            while ($R = mysqli_fetch_array($result)){
                                if (isset($R["porocilo"])){
                                    if (strlen($R["porocilo"]) == 0){
                                        $Nepopoln += 1;
                                    }
                                }else{
                                    $Nepopoln += 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a><br />";
                            echo "</td>";
                            if ($Nepopoln > 0){
                                switch ($ActualMonth){
                                    case 5:
                                    case 6:
                                    case 7:
                                    case 8:
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        break;
                                    default:
                                        echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                                }
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            if ($Nepopoln > 0){
                                echo "Vpisanih imate $Nepopoln interesnih dejavnosti brez poročil.";
                            }else{
                                echo "Vse vaše interesne dejavnosti imajo vpisana poročila.";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a><br />";
                            echo "</td>";
                            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                            echo "<td>";
                            echo "Na vaše ime ni vpisanih interesnih dejavnosti.";
                            echo "</td>";
                            echo "</tr>";
                        }

                        //poročila o šolskih športnih tekmovanjih
                        $Nepopoln=0;
                        $SQL = "SELECT porocilo FROM tabsst WHERE mentor LIKE '%".$ImeUp."%' AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            while ($R = mysqli_fetch_array($result)){
                                if (isset($R["porocilo"])){
                                    if (strlen($R["porocilo"]) == 0){
                                        $Nepopoln += 1;
                                    }
                                }else{
                                    $Nepopoln += 1;
                                }
                            }
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=301'>Šolska športna tekmovanja</a><br />";
                            echo "</td>";
                            if ($Nepopoln > 0){
                                switch ($ActualMonth){
                                    case 5:
                                    case 6:
                                    case 7:
                                    case 8:
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                        break;
                                    default:
                                        echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                                }
                            }else{
                                echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                            }
                            echo "<td>";
                            if ($Nepopoln > 0){
                                echo "Vpisanih imate $Nepopoln šolskih športnih tekmovanj brez poročil.";
                            }else{
                                echo "Vsa vaša šolska športna tekmovanja imajo vpisana poročila.";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }else{
                            echo "<tr>";
                            echo "<td>";
                            echo "<a href='tekmovanjakrozki.php?id=301'>Šolska športna tekmovanja</a><br />";
                            echo "</td>";
                            echo "<td align='center'><img src='img/ypika.png' width='20'></td>";
                            echo "<td>";
                            echo "Na vaše ime ni vpisanih šolskih športnih tekmovanj.";
                            echo "</td>";
                            echo "</tr>";
                        }

                        switch ($ActualMonth){
                            case 1:
                            case 2:
                            case 6:
                            case 7:
                                if ($SemaforRealizacija){
                                    //realizacija po učiteljih
                                    $SQL = "SELECT tabrealizacija.planpol,tabrealizacija.realizacijapol,tabrealizacija.plan,tabrealizacija.realizacija FROM tabrealizacija ";
                                    $SQL .= "INNER JOIN tabucenje ON tabrealizacija.ucenje=tabucenje.id ";
                                    $SQL .= "WHERE tabucenje.iducitelj=".$VUporabnikId." AND tabrealizacija.leto=".$VLeto." AND tabucenje.leto=".$VLeto;
                                    $result = mysqli_query($link,$SQL);
                                    $NiVpisa1=0;
                                    $NiVpisa2=0;
                                    while ($R = mysqli_fetch_array($result)){
                                        if (isset($R["realizacija"])){
                                            if ($R["realizacija"] == 0 && $R["plan"] > 0){
                                                $NiVpisa2 += 1;
                                            }
                                        }else{
                                            $NiVpisa2 += 1;
                                        }
                                        if (isset($R["realizacijapol"])){
                                            if ($R["realizacijapol"] == 0 && $R["planpol"] > 0){
                                                $NiVpisa1 += 1;
                                            }
                                        }else{
                                            $NiVpisa1 += 1;
                                        }
                                    }
                                    echo "<tr>";
                                    echo "<td>";
                                    echo "<a href='VnosRealizacijeInd.php?ucitelj=$VUporabnikId'>Realizacija ur po učiteljih</a><br />";
                                    echo "</td>";
                                    if ($NiVpisa1 > 0 or $NiVpisa2 > 0){
                                        echo "<td align='center'><img src='img/rpika.png' width='20'></td>";
                                    }else{
                                        echo "<td align='center'><img src='img/zpika.png' width='20'></td>";
                                    }
                                    echo "<td>";
                                    if ($NiVpisa1+$NiVpisa2 > 0){
                                        echo "Manjka realizacija za $NiVpisa1 dejavnosti ob polletju in za $NiVpisa2 ob koncu leta.";
                                    }else{
                                        echo "Vse vaše dejavnosti imajo vpisano realizacijo.";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                                break;
                        }
                        echo "</table><br />";
                    }
                }
                // stanje izpolnjenosti podatkov - konec
                
                /*
	            //'obvestilo o anketah
                
	            $SQL = "SELECT * FROM tabanketa WHERE objavi=true AND YEAR(veljavnost) <= ".$Danes->format('Y');
                $result = mysqli_query($link,$SQL);
                $num_rows = mysqli_num_rows($result);

                if ($num_rows > 0){
		            echo "<br />Aktualne ankete:<br />";
                    while ($R = mysqli_fetch_array($result)){
                        $datum1= new DateTime(isDate($R["veljavnost"]));
                        $interval=$datum1->diff($Danes);
			            if ($interval->days <= 0 ) {
				            echo "<a href='VnosAnkete.php?id=4&anketa=".$R["idAnketa"]."'>".$R["naziv"]." (do ".$R["veljavnost"].")</a><br />";
			            }
		            }
	            }
	            $SQL = "SELECT * FROM tabanketa WHERE objavi=true AND YEAR(veljavnost) = ".$Danes->format('Y');
                $num_rows = mysqli_num_rows($result);

                if ($num_rows > 0){
		            echo "<br />Rezultati anket:<br />";
                    while ($R = mysqli_fetch_array($result)){
                        $datum1= new DateTime(isDate($R["veljavnost"]));
                        $interval=$datum1->diff($Danes);
			            if (($interval->days > 0) && ($interval->days < 30) ) {
				            echo "<a href='VnosAnkete.php?id=5&anketa=".$R["idAnketa"]."'>".$R["naziv"]." (".$R["veljavnost"].")</a><br />";
			            }
		            }
	            }
	            
                */
                //'obvestila
                $SQL = "SELECT TabPrejemnikiObvestil.*,tabprejemnikiobvestil.id AS pid,TabObvestila.*,tabobvestila.id AS oid,TabUcitelji.priimek,TabUcitelji.ime FROM (TabPrejemnikiObvestil ";
                $SQL = $SQL . " INNER JOIN TabObvestila ON TabPrejemnikiObvestil.idObvestilo=TabObvestila.id) ";
                $SQL = $SQL . " INNER JOIN TabUcitelji ON TabObvestila.objavil=TabUcitelji.idUcitelj ";
                $SQL = $SQL . " WHERE TabPrejemnikiObvestil.idUcitelj=".$VUporabnikId." AND TabPrejemnikiObvestil.status < 3";
                $indx=1;
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    echo "<table border='1' cellspacing='0'>";
                    echo "<tr><th>Št.</th><th>Obvestilo</th><th>Vsebina</th><th>Rok</th><th>Objavil</th><th>Datum objave</th><th>Ne kaži več</th></tr>";
                    while ($R = mysqli_fetch_array($result)){
                        echo "<tr>";
                        echo "<td align='center' valign='top'>".$indx."</td>";
                        echo "<td valign='top'>".$R["naslov"]."</td>";
                        if (strlen($R["vsebina"]) > 80){
                            echo "<td width='400'>".mb_substr($R["vsebina"],0,80,$encoding)." ... <a href='obvestila.php?id=8&zapis=".$R["oid"]."'>Več</a></td>";
                        }else{
                            echo "<td width='400'>".$R["vsebina"]."</td>";
                        }
                        echo "<td valign='top'>".$R["rok"]."</td>";
                        echo "<td valign='top'>".$R["ime"]." ".$R["priimek"]."</td>";
                        if (isDate($R["datum"])){
                            $Datum=new DateTime(isDate($R["datum"]));
                            echo "<td valign='top'>".$Datum->format('d.m.Y')."</td>";
                        }else{
                            echo "<td valign='top'></td>";
                        }
                        echo "<td valign='top'><a href='obvestila.php?id=7&zapis=".$R["pid"]."'>Ne kaži več</a></td>";
                        echo "</tr>";
                        $indx=$indx+1;
                    }
                    echo "</table><br /><a href='obvestila.php'>Dodaj obvestilo</a><br />";
                }
                
	            //'obvestilo o poteku pogodb delavcem za določen čas
	            if (CheckDostop("Tajn",$VUporabnik) ) {
		            $SQL = "SELECT tabpogodbe.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
		            $SQL = $SQL . "tabpogodbe INNER JOIN tabucitelji ON tabpogodbe.IdUcitelj=tabucitelji.IdUcitelj ";
		            $SQL = $SQL . "WHERE (status IN (4,5)) ORDER BY priimek,ime";
		            $indx=1;
                    $result = mysqli_query($link,$SQL);
                    while ($R = mysqli_fetch_array($result)){
			            if (isDate($R["DatumStart"]) == "" ) {
				            $DatumCStart=new DateTime("now");
			            }else{
				            $DatumCStart=new DateTime(isDate($R["DatumStart"]));
			            }
			            if (isDate($R["DatumEnd"]) == "" ) {
				            $DatumCEnd=new DateTime("now");
			            }else{
				            $DatumCEnd=new DateTime(isDate($R["DatumEnd"]));
			            }
			            if (($Danes->format('Y') <= $DatumCEnd->format('Y')) && ($Danes->format('Y') >= $DatumCStart->format('Y')))  {
                            $interval=$Danes->diff($DatumCEnd);
				            if (($interval->days < 45) && ($interval->invert==0) && ($interval->days > 0) ) {
                                if ($indx == 1){
                                    echo "<br><b>Delavci za določen čas z bližnjim iztekom pogodbe:</b><br>";
                                    echo "<table border='1' cellspacing='0'>";
                                    echo "<tr><th>Št.</th><th>Delavec</th><th>Datum začetka</th><th>Datum izteka pogodbe</th><th>Opomba</th></tr>";
                                }
					            echo "<tr>";
					            echo "<td>".$indx."</td>";
					            echo "<td><a href='IzpisUcitelja.php?idUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</a></td>";
            //                    echo "<td><a href='PopraviUcitelja.php?IdUcitelj=".$R["IdUcitelj"]."'>".$R["Priimek"]." ".$R["Ime"]."</a></td>";
					            echo "<td align='right'>".$R["DatumStart"]."</td>";
					            if (isDate($R["DatumEnd"]) == "" ) {
						            if (isDate($R["DatumStart"]) != "" ) {
							            $DatumCEnd=$DatumCStart->add(new DateInterval('P1Y'));
							            $DatumCEnd=$DatumCEnd->sub(new DateInterval('P1D'));
							            echo "<td>Datum ni vnesen (".$DatumCEnd->format('d.m.Y').")</td>";
						            }else{
							            echo "<td>Datum ni vnesen</td>";
						            }
					            }else{
						            echo "<td>".$DatumCEnd->format('d.m.Y')."</td>";
					            }
					            echo "<td>".$R["RazlogDolCas"]."</td>";
            //                    echo "<td>".$R["RazlogDolCas"]."</td>";
					            echo "</tr>";
					            $indx=$indx+1;
				            }
			            }
		            }
                    if ($indx > 1){
		                echo "</table>";
                    }

                //'obvestilo o porodniških
                    /*
                    if (!isset($_SESSION["Porodniska"])){
                        $_SESSION["Porodniska"] = 0;
                    }else{
                        if ($_SESSION["Porodniska"] > 0){
                        }
                    }
                    */
                //$IzpisPorodniske=1;
                /*
		            if ($_SESSION["Porodniska"] == 0 ) {
                        if ($IzpisPorodniske == 0){
                            $_SESSION["Porodniska"] += 1;
                        }else{
			                $_SESSION["Porodniska"]=0;
                        }
                        */
                        
                        $SQL = "SELECT DISTINCT tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime FROM tabucitelji ";
                        $SQL .= "INNER JOIN tabpregleddelan ON tabucitelji.iducitelj=tabpregleddelan.ucitelj ";
                        $SQL .= "WHERE leto >= ".$Danes->format('Y')." AND (rubrika=39 OR rubrika=40)";
			            //$SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
			            $indx=1;
                        $result = mysqli_query($link,$SQL);
                        while ($R = mysqli_fetch_array($result)){
				            $SQL = "SELECT leto,mesec,dan FROM tabpregleddelan WHERE leto >= ".$VLeto." AND Ucitelj=".$R["iducitelj"]." AND (rubrika=39 OR rubrika=40) ORDER BY datum DESC LIMIT 0,1";
                            $result1 = mysqli_query($link,$SQL);
                            if ($R1 = mysqli_fetch_array($result1)){
					            $DatumCEnd=new DateTime($R1["leto"]."-".$R1["mesec"]."-".$R1["dan"]);
					            //'echo DateDiff("d",day(now)&"."&month(now)&"."&year(now),DatumCEnd)&"<br />"
                                /*
                                $interval=$Danes->diff($DatumCEnd);
                                if ($interval->invert) {
                                    $days=$interval->days*(-1);
                                }else{
                                    $days=$interval->days;
                                }
                                */
                                $days=intval($DatumCEnd->format('Ymd'))-intval($Danes->format('Ymd'));
					            if ($days > -15) {
                                    if ($indx == 1){
                                        echo "<br><b>Porodniške:</b><br>";
                                        echo "<table border='1' cellspacing='0'>";
                                        echo "<tr><th>Št.</th><th>Delavec</th><th>Datum izteka porodniške, nege</th></tr>";
                                    }
						            echo "<tr>";
						            echo "<td>".$indx."</td>";
						            echo "<td><a href='IzpisUcitelja.php?idUcitelj=".$R["iducitelj"]."'>".$R["priimek"]." ".$R["ime"]."</a></td>";
						            echo "<td align='right'>".$DatumCEnd->format('d.m.Y')."</td>";
						            echo "</tr>";
						            $indx=$indx+1;
					            }
				            }
			            }
                        if ($indx > 1){
			                echo "</table>";
                        }
		            //}
	            }
	            
	            //'izpis še neodobrenih izobraževanj
	            if (ND($n,"23") ) { 
		            $SQL = "SELECT tabizobrazevanje.*,tabucitelji.Priimek,tabucitelji.Ime FROM ";
		            $SQL = $SQL."tabizobrazevanje INNER JOIN tabucitelji ON tabizobrazevanje.IdUcitelj=tabucitelji.IdUcitelj ";
		            $SQL = $SQL."WHERE tabizobrazevanje.leto=".$VLeto." AND priporocam=false";
		            $SQL = $SQL." ORDER BY priimek,ime";
                    $result = mysqli_query($link,$SQL);
                    $num_rows = mysqli_num_rows($result);

                    if ($num_rows > 0){
			            echo "<br /><b>Izobraževanja za potrditev</b><br />";
			            echo "<form accept-charset='utf-8' name='form_Izobrazevanje' method=post action='VnosIzobrazevanje.php'>";
			            echo "<table class='condensed' border='1' cellspacing='0'>";
			            echo "<tr bgcolor='lightcyan'><th>Leto</th><th>Ime</th><th>Izobraževanje</th><th>Datum od</th><th>Datum do</th><th>Kotizacija EUR</th><th>Ostali<br>stroški EUR</th><th><img src='img/m_edit1.gif'></th><th><img src='img/m_delete.gif'></th><th><img src='img/m_poglej1.gif'></th><th>Odobreno</th></tr>";
			            $indx=0;
                        while ($R = mysqli_fetch_array($result)){
				            $indx=$indx+1;
				            echo "<td>".$R["leto"]."/".($R["leto"]+1)."</td>";
				            echo "<td>".$R["Priimek"]." ".$R["Ime"]."</td>";
				            echo "<td>".$R["Izobrazevanje"]."</td>";
				            //'echo "<td>"&$R["Izvajalec"]&"</td>"
				            //'echo "<td>"&$R["tabizobrazevanje.Naslov"]&"</td>"
				            //'echo "<td>"&$R["tabizobrazevanje.Kraj"]&"</td>"
				            echo "<td>".$R["DatumOd"]."</td>";
				            echo "<td>".$R["DatumDo"]."</td>";
				            //'echo "<td>"&$R["Trajanje"]&"</td>"
				            //'echo "<td>"&$R["Tocke"]&"</td>"
				            echo "<td align='center'>".$R["Kotizacija"]."</td>";
				            echo "<td align='center'>".$R["OstStroski"]."</td>";
				            echo "<td><a href='VnosIzobrazevanje.php?id=2&popravi=".$R["id"]."&solskoleto=".$VLeto."'><img src='img/m_edit1.gif' border='0' alt='Vnesi/Popravi'></a></td>";
				            echo "<td><a href='VnosIzobrazevanje.php?id=3&brisi=".$R["id"]."&solskoleto=".$VLeto."'><img src='img/m_delete.gif' border='0' alt='Briši'></a></td>";
				            echo "<td><a href='VnosIzobrazevanje.php?id=5&poglej=".$R["id"]."&solskoleto=".$VLeto."'><img src='img/m_poglej1.gif' border='0' alt='Poglej'></a></td>";
				            echo "<td><input name='iz_".$indx."' type='hidden' value='".$R["id"]."'><input name='odobr_".$indx."' type='checkbox'></td>";
				            echo "</tr>";
			            }
			            echo "</table>";

			            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
			            echo "<input name='zapisov' type='hidden' value='".$indx."'>";
			            echo "<input name='id' type='hidden' value='6'>";
			            echo "<input name='submit' type='submit' value='Odobri'>";
			            echo "</form>";
		            }
	            }
	            
	            if (!(ND($n,"0123K")) ) {
			            RW("Nimate  uporabniških pravic!<br>Obrnite se na administratorja omrežja.<br>");
			            RW("<a href='index.htm'>Nazaj na vnos uporabniškega imena in gesla</a><br>");
	            }
	            
	            //'Tipična opravila
	            if (ND($n,"123") ) { 
		            echo "<br /><b>Tipična opravila</b>:<br /><table class='condensed' border='1'>";
		            echo "<tr><th bgcolor='lightyellow'>Začetek<br />šolskega leta</th><th bgcolor='lightgreen'>Med letom</th><th bgcolor='lightskyblue'>Ob polletju</th><th bgcolor='lightblue'>Ob koncu<br />šolskega leta</th></tr>";
		            if (ND($n,"23") ) { //'pomočnik, administrator
			            echo "<tr>";
			            //'začetek šolskega leta
			            echo "<td valign='top' bgcolor='lightyellow'>";
			            echo "Predhodna priprava podatkov<br />";
			            echo "<li><a href='VnosPraznikov.php?id=1'>Vnos praznikov in počitnic</a></li>";
			            echo "<li><a href='priprava.php?idd=500&id=1'>Vnos dni pouka po mesecih</a></li>";
			            echo "<li><a href='Prostori.php?id=1'>Prostori</a></li>";
			            echo "<li><a href='VnosRazred.php'>Vnos razredov</a></li>";
			            echo "<li><a href='priprava.php?idd=100'>Prenos učencev v novo šolsko leto</a></li>";
			            echo "<li><a href='izborrazreda.php'>Razredi in urejanje podatkov</a></li>";
			            echo "<li><a href='Predmeti.php'>Vnos predmetov in učiteljev po razredih</a></li>";
			            echo "<li><a href='Aktivi.php'>Vodje aktivov</a></li>";
			            echo "<li><a href='izbirniskupine.php?id=1'>Dodaj izbirne predmete učencem</a></li>";
                        echo "<li><a href='izbirniskupine.php?id=1a'>Dodaj neobv. izbirne predmete učencem</a></li>";
			            echo "<li><a href='izbirniskupine.php?id=10'>Dodaj nivojske predmete/skupine učencem</a></li>";
			            echo "<li><a href='VnosUrnika.php'>Vnos urnika</a></li>";
			            echo "<li><a href='priprava.php?idd=700'>Izvoz podatkov o učencih za subvencije</a></li>";
			            echo "<li><a href='priprava.php?idd=600'>Izvoz podatkov o učencih za CEUVIZ</a></li>";
			            echo "<li>Statistike</li>";
			            echo "</td>";
			            //'med letom
			            echo "<td valign='top' bgcolor='lightgreen'>";
			            echo "<li><a href='izborucenca.php?id=2'>Popravljanje podatkov o učencih</a></li>";
			            echo "<li><a href='VnosNadomescanje.php?id=1'>Vnos nadomeščanj</a></li>";
			            echo "<li><a href='IzpisPregledovDelaN.php'>Mesečni pregledi dela</a></li>";
			            echo "<li><a href='VnosDogodkov.php'>Koledar obveznosti in terminov</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=23'>Nabor izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=23a'>Nabor neobv. izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=25'>Obrazci za izbor izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=25a'>Obrazci za izbor neobv. izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=20'>Vnos izbir izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=20a'>Vnos izbir neobv. izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=26'>Izbor izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=26a'>Izbor neobv. izbirnih predmetov za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=27'>Izbrani izbirni predmeti po razredih za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=27a'>Izbrani neobv. izbirni predmeti po razredih za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=28'>Učenci po izbirnih predmetih za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=28a'>Učenci po neobv. izbirnih predmetih za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=29'>Prenos izbranih izbirnih predmetih za novo ŠL</a></li>";
                        echo "<li><a class='menuItem' href='izbirniskupine.php?id=29a'>Prenos neobv. izbranih izbirnih predmetih za novo ŠL</a></li>";
			            echo "<li></td>";
			            //'ob polletju
			            echo "<td valign='top' bgcolor='lightskyblue'>";
			            echo "<li><a href='PorociloRazrednikaPregled.php?razred=0'>Pregled pedagoških poročil</a></li>";
			            echo "<li><a href='pregledi.php?idd=700'>Poročila o uspehu</a></li>";
			            echo "<li><a href='IzpisRealizacij.php?id=1'>Izpis realizacij</a></li>";
			            echo "</td>";
			            //'ob koncu šolskega leta
			            echo "<td valign='top' bgcolor='lightblue'>";
			            echo "<li><a href='priprava.php?idd=300'>Izračun povprečja zaključnih ocen</a></li>";
			            echo "<li><a href='PorociloRazrednikaPregled.php?razred=0'>Pregled pedagoških poročil</a></li>";
			            echo "<li><a href='pregledi.php?idd=710'>Poročila o uspehu</a></li>";
			            echo "<li><a href='IzpisRealizacij.php?id=2'>Izpis realizacij</a></li>";
			            echo "<li><a href='letnoporocilo.php'>Letno poročilo</a></li>";
			            echo "<li><a href='tekmovanjakrozki.php?id=113'>Poročila o tekmovanjih v znanju</a></li>";
			            echo "</td>";
			            echo "</tr>";
		            }
		            echo "<tr>";
		            //'začetek šolskega leta
		            echo "<td valign='top' bgcolor='lightyellow'>";
		            echo "<li><a href='izborrazreda.php?id=opb'>Vnos učencev za OPB in JUV</a></li>";
		            echo "<li><a href='izborrazreda.php?id=dodpouk'>Vnos učencev za ISP, DSP, DOD, DOP</a></li>";
		            echo "<li><a href='izborrazreda.php?id=prehrana'>Vnos prehrane učencev</a></li>";
		            echo "<li><a href='izborrazreda.php?id=izjave'>Vnos soglasij staršev</a></li>";
		            //echo "<li><a href='VnosPreverjanjZnanja.php'>Vnos datumov pisnih ocenjevanj znanja</a></li>";
		            echo "<li><a href='izborrazreda.php?id=uspeh'>Vpis statusov, napredovanja, popravnih izpitov</a></li>";
		            echo "<li><a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a></li>";
		            //echo "<li><a href='VnosUcniPripomocki.php'>Učni pripomočki</a></li>";
                    echo "<li><a href='letniucninacrt.php'>Letni učni načrti</a></li>";
		            echo "</td>";
		            //'med letom
		            echo "<td valign='top' bgcolor='lightgreen'>";
                    echo "<li><a href='izborrazreda.php?id=sporocila'>e-sporočila staršem</a></li>";
                    echo "<li><a href='izborrazreda.php?id=starsi'>Komunikacija s starši</a></li>";
		            echo "<li><a href='izborrazreda.php?id=malice'>Mesečni spiski za malice</a></li>";
		            echo "<li><a href='izborrazreda.php?id=dejavnosti'>Vnos dnevov dejavnosti</a></li>";
                    echo "<li><a href='izborrazreda.php?id=tabor'>Vnos LŠN/Taborov</a></li>";
		            echo "<li><a href='izborrazreda.php?id=odsotnost'>Vnos odsotnosti</a></li>";
		            echo "<li><a href='izborrazreda.php?id=govorilne'>Sodelovanje s starši</a></li>";
                    echo "<li><a href='izborrazreda.php?id=sociogram'>Sociogram</a></li>";
		            echo "<li><a href='izborucenca.php?id=3'>Vnos vzgojnih ukrepov</a></li>";
		            //echo "<li><a href='IzborKontrolke.php'>(Vpis kontrolne naloge)</a></li>";
		            echo "<li><a href='VnosZapisnik.php'>Vnos zapisnikov in poročil</a></li>";
		            echo "<li><a href='VnosIzobrazevanje.php'>Poročila o udeležbi na izobraževalnih seminarjih</a></li>";
		            echo "<li><a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju</a></li>";
		            echo "<li><a href='tekmovanjakrozki.php?id=301'>Šolska športna tekmovanja</a></li>";
		            echo "<li><a href='tekmovanjakrozki.php?id=401'>Natečaji</a></li>";
		            echo "<li><a href='IzpisUcitelja.php?idUcitelj=" . $VUporabnikId . "'>Mesečni pregledi dela</a></li>";
		            echo "<li><a href='DejavnostiZaNapredovanje.php'>Dejavnosti za napredovanje</a></li>";
		            echo "<li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></li>";
		            echo "</td>";
		            //'ob polletju
		            echo "<td valign='top' bgcolor='lightskyblue'>";
		            echo "<li><a href='izpisredovalnice.php'>Redovalnica, uspeh, obvestila o uspehu, poročila razrednika</a></li>";
		            echo "<li><a href='IzborRealizacijeInd.php'>Vnos realizacije po učiteljih</a></li>";
		            echo "<li><a href='IzborRealizacije.php'>Vnos realizacij in dnevov dejavnosti</a></li>";
		            echo "<li><a href='PedPorocilo.php'>Vnos pedagoškega poročila</a></li>";
		            echo "<li><a href='izpisredovalnice.php'>Obvestila o uspehu za cel razred</a></li>";
		            echo "</td>";
		            //'ob koncu šolskega leta
		            echo "<td valign='top' bgcolor='lightblue'>";
		            echo "<li><a href='izpisredovalnice.php'>Redovalnica, uspeh, obvestila o uspehu, poročila razrednika</a></li>";
		            echo "<li><a href='IzborRealizacijeInd.php'>Vnos realizacije po učiteljih</a></li>";
		            echo "<li><a href='IzborRealizacije.php'>Vnos realizacij in dnevov dejavnosti</a></li>";
                    echo "<li><a href='izborrazreda.php?id=tabor'>Vnos LŠN/Taborov</a></li>";
                    echo "<li><a href='PedPorocilo.php'>Vnos pedagoškega poročila</a></li>";
		            echo "<li><a href='maticnilisti.php'>Matični listi</a></li>";
		            echo "<li><a href='izborrazreda.php?id=interesne1'>Obvestila o sodelovanju na ID in o pohvalah</a></li>";
		            echo "<li><a href='tekmovanjakrozki.php?id=501'>Ostala priznanja in pohvale</a></li>";
		            echo "<li><a href='izpisredovalnice.php'>Priprava podatkov za končno spričevalo</a></li>";
		            echo "<li><a href='izpisredovalnice.php'>Spričevala za cel razred</a></li>";
		            echo "<li><a href='izpisredovalnice.php'>Obvestila o zaključnih ocenah</a></li>";
		            echo "<li><a href='izborrazreda.php?id=plavanje'>Stopnja znanja plavanja</a></li>";
		            echo "<li><a href='IzborAktiviPorocilo.php?id=1a'>Vnos in pregled poročil aktivov</a></li>";
		            echo "<li><a href='IzborAktiviPorocilo.php?id=1b'>Vnos in pregled načrtov aktivov za naslednje ŠL</a></li>";
		            echo "</td>";
		            echo "</tr>";
		            echo "</table><br />";
	            }
	            
	            //'najpogostejše povezave
	            echo "<br><b>Najpogostejše povezave:</b><br /><table border='0'>";
	            if ($EvidencaPrisotnosti==1 ) {
		            if (ND($n,"0123K") ) { 
                        RW("<tr><td bgcolor='lightyellow'><li><a href='VpisPrihodov.php'>Evidenca prihodov/odhodov</a></td></tr>");
                    }
	            }
	            if (ND($n,"23K") ) { RW("<tr><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php'>Ogled in vnos podatkov o delavcih</a></td></tr>");}
	            if (ND($n,"01K") ) { RW("<tr><td bgcolor='aquamarine'><li><a href='IzpisUcitelja.php?idUcitelj=" . $VUporabnikId . "'>Mesečni pregledi dela</a></td></tr>");}
	            if (ND($n,"0123K") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='VnosZapisnik.php'>Vnos zapisnikov in poročil</a></td></tr>");}
	            if (ND($n,"23K") ) { RW("<tr><td bgcolor='aquamarine'><li><a href='VnosDogodkov.php'>Koledar obveznosti in terminov</a></td></tr>");}
	            if (ND($n,"0123K") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='IzborRealizacijeInd.php'>Vnos realizacije - po učiteljih</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izborrazredaizbor.php'>Spiski učencev po razredih</a></td></tr>");}
                if (ND($n,"123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=starsi'>Komunikacija s starši</a></td></tr>");}
	            if (ND($n,"123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=malice'>Mesečni spiski za malice</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izpisredovalnice.php'><b>Redovalnice</b>, uspeh, obvestilo o uspehu, poročilo razrednika</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=tabor'>Šola v naravi/Tabor</a></td></tr>");}
	            if (ND($n,"123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=dejavnosti'>Vnos dnevov dejavnosti</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=101'>Tekmovanja v znanju - vnos</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti - vnos</a></td></tr>");}
	            if (ND($n,"0123") ) { RW("<tr><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=401'>Natečaji</a></td></tr>");}
	            if (ND($n,"0123K") ) { RW("<tr><td bgcolor='aquamarine'><li><a href='DejavnostiZaNapredovanje.php'>Dejavnosti za napredovanje</a></td></tr>");}
	            if (ND($n,"0123K") ) { RW("<tr><td bgcolor='aquamarine'><li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></td></tr>");}
	            if (ND($n,"0123K") ) { RW("<tr><td bgcolor='khaki'><li><a href='KoledarLeto.php' target='new_win'>Koledarji</a></td></tr>");}
	            if (CheckDostop("Tajn",$VUporabnik) ) {
                //'		RW("<tr><td bgcolor='aquamarine'><li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></td></tr>"]
		            RW("<tr><td bgcolor='aquamarine'><li><a href='VnosPotniNalogi.php?id=5'>Spisek potnih nalogov</a></td></tr>");
		            RW("<tr><td bgcolor='aquamarine'><li><a href='VnosNarocilnica.php?id=1'>Naročilnice</a></td></tr>");
		            RW("<tr><td bgcolor='aquamarine'><li><a href='delovodnik.php?id=1'>Delovodnik</a></td></tr>");
	            }
	            RW("</table>");
	            RW("<br>");

                //'izpis urnika po uciteljih - 2
                for ($Indx2=0;$Indx2 <= 150;$Indx2++){
	                $Obremenitev[$Indx2]=0;
	                for ($Indx=0;$Indx <= 5;$Indx++){
		                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			                $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
		                }
	                }
                }

                $SQL = "SELECT iducitelj,priimek,ime FROM tabucitelji WHERE status > 0 ORDER BY priimek,ime";
                //'echo "<br>" & $SQL & "<br>"
                $Indx1=0;
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
	                $VUcitelji[$Indx1][0] = $R["iducitelj"];
	                $VUcitelji[$Indx1][1] = $R["priimek"];
	                $VUcitelji[$Indx1][2] = $R["ime"];
	                $Indx1=$Indx1+1;
                }
                $StUciteljev=$Indx1-1;
                $danurnik=intval($Danes->format('Ymd'));
                //'$SQL = "SELECT taburnik.*,tabucitelji.*,tabpredmeti.*,tabprostor.* FROM ((taburnik "
                $SQL = "SELECT taburnik.danvtednu,taburnik.ura,taburnik.nivo,taburnik.razred,taburnik.paralelka,taburnik.vrstaos,taburnik.idrazred,tabucitelji.iducitelj,tabucitelji.priimek,tabucitelji.ime,tabprostor.stevilka,tabpredmeti.Oznaka AS poznaka FROM ((taburnik "; 
                $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.IdUcitelj) ";
                $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) ";
                $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor ";
                $SQL = $SQL . "WHERE taburnik.leto=".$VLeto." AND od <= ".$danurnik." AND do >= ".$danurnik." AND tabucitelji.IdUcitelj=".$ucitelj." ORDER BY taburnik.DanVTednu,taburnik.Ura";

                for ($Indx2=0;$Indx2 <= 150;$Indx2++){
	                $Obremenitev[$Indx2]=0;
	                for ($Indx=0;$Indx <= 5;$Indx++){
		                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			                $UrnikUcitelj[$Indx2][$Indx][$Indx0]="";
		                }
	                }
                }

                $Indx=0;
                //'IzbraniUcitelj=ucitelj
                $result = mysqli_query($link,$SQL);
                while ($R = mysqli_fetch_array($result)){
	                $IzbraniUcitelj=$StUciteljev+1;
	                for ($Indx2=0;$Indx2 <= $StUciteljev;$Indx2++){
		                if ($ucitelj==$VUcitelji[$Indx2][0] ) {
			                $IzbraniUcitelj=$Indx2;
		                }
	                }
	                switch ($R["nivo"]){
		                case 1:
			                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                            break;
                        case 2:
                            $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                            break;
                        case 3:
                            $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["nivo"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
                            break;
		                default:
			                $UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]=$UrnikUcitelj[$IzbraniUcitelj][$R["danvtednu"]][$R["ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["stevilka"]."</font></td><td class='hide'><font color='magenta'>".$R["razred"].strtolower($R["paralelka"])."</font></td></tr>";
	                }
	                $Indx=$Indx+1;
                }

                for ($Indx2=0;$Indx2 <= 150;$Indx2++){
	                for ($Indx=0;$Indx <= 5;$Indx++){
		                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
			                if ($UrnikUcitelj[$Indx2][$Indx][$Indx0] <> "" ) {
				                $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
			                }
		                }
	                }
                }

                //'echo "<br>Urnik učitelja:<br>"
                echo "<table border=1 cellspacing=0 bgcolor='lightyellow'>";
                for ($Indx=0;$Indx <= 150;$Indx++){
	                if ($Obremenitev[$Indx] > 0 ) {
		                echo "<tr bgcolor='cyan'>";
		                echo "<td>".$Obremenitev[$Indx]."</td>";
		                for ($Indx2=1;$Indx2 <= 5;$Indx2++){
			                echo "<td><b>".Int2Dan($Indx2)."</b></td>";
		                }
		                echo "</tr>";
		                for ($Indx2=0;$Indx2 <= 12;$Indx2++){
			                echo "<tr><td>".$Indx2."</td>";
			                for ($Indx1=1;$Indx1 <= 5;$Indx1++){
				                if ($UrnikUcitelj[$Indx][$Indx1][$Indx2] <> "" ) {
					                echo "<td>";
					                echo "<table>";
					                echo $UrnikUcitelj[$Indx][$Indx1][$Indx2];
					                echo "</table>";
					                echo "</td>";
				                }else{
					                echo "<td>&nbsp;</td>";
				                }
			                }
			                echo "</tr>";
		                }
	                }
                }

                echo "</table><br>";
                // echo "<a href='UrnikRazrediBPDF.php' target='_blank'>Urnik razredov</a>, <a href='UrnikProstoriBPDF.php' target='_blank'>Urnik prostorov</a><br>";
                //' izpis osebnega urnika - konec
	                
                //'  **** IZPIS MENIJA ***********************************	
                if (ND($n,"123K") ) { 
	                RW("<table CELLPADDING=2 CELLSPACING=0><tr VALIGN=TOP>");
	                if (ND($n,"123K") ) {
		                RW("<td width='150' bgcolor='lightsalmon'><a href='#ucenci'><h2>Učenci</h2></a><UL><LI><a href='#ucenciSeznami'>Seznami učencev</a><LI><a href='#ucenciRedovalnica'>Redovalnica</a><LI><a href='#ucenciPorocila'>Poročila</a><LI><a href='#ucenciIzbirni'>Izbirni in nivojski pouk</a><LI><a href='#ucenciTekmovanja'>Tekmovanja in interesne dejavnosti</a><LI><a href='#ucenciNPZ'>NPZ</a><LI><a href='#ucenciDejavnosti'>Dejavnosti</a><li><a href='Izhod.php'>Izhod</a></td></UL><br>");
	                }
	                RW("<td width='150' bgcolor='limegreen'><a href='#delo'><h2>Delo</h2></a><UL><LI><a href='#deloKadri'>Kadri</a><LI><a href='#deloSistematizacija'>Sistematizacija</a><LI><a href='#deloUrnik'>Urnik</a><LI><a href='#deloTajnistvo'>Tajništvo</a></UL></td>");
	                if ($EvidencaPrisotnosti==1 ) {
		                RW("<td width='150' bgcolor='gray'><a href='#prehrana'><h2>Prehrana</h2></a></td>");
		                RW("<td width='150' bgcolor='orange'><a href='#prisotnost'><h2>Prisotnost</h2></a></td>");
	                }		
	                RW("<td width='150' bgcolor='mediumpurple'><a href='#statistike'><h2>Statistike</h2></a></td>");
	                RW("<td width='150' bgcolor='tan'><a href='#splosno'><h2>Splošno</h2></a></td></tr></table>");
                }
                if (ND($n,"0K") ) { 
	                RW("<table CELLPADDING=2 CELLSPACING=0><tr VALIGN=TOP>");
	                RW("<td width='150' bgcolor='lightsalmon'><a href='#ucenci'><h2>Učenci</h2></a><UL><LI><a href='#ucenciSeznami'>Seznami učencev</a><LI><a href='#ucenciRedovalnica'>Redovalnica</a><LI><a href='#ucenciPorocila'>Poročila</a><LI><a href='#ucenciIzbirni'>Izbirni in nivojski pouk</a><LI><a href='#ucenciTekmovanja'>Tekmovanja in interesne dejavnosti</a><LI><a href='#ucenciNPZ'>NPZ</a><LI><a href='#ucenciDejavnosti'>Dejavnosti</a><li><a href='Izhod.php'>Izhod</a></td></UL><br></td>");
	                RW("<td width='150' bgcolor='limegreen'><a href='#delo'><h2>Delo</h2></a><UL><LI><a href='#deloKadri'>Kadri</a><LI><a href='#deloSistematizacija'>Sistematizacija</a><LI><a href='#deloUrnik'>Urnik</a></UL></td>");
	                RW("<td width='150' bgcolor='tan'><a href='#splosno'><h2>Splošno</h2></a></td></tr></table>");
                }


                if (ND($n,"01K") ) { $_SESSION["IdUcitelj"]=$VUporabnikId;}

                RW("<br>");
                //'	echo "Šolsko leto: "&VLeto&"/"&VLeto+1&"<br>"
                RW("<br>Na voljo so vam naslednji podatki:<br>");

                if (ND($n,"0123K") ) { RW("<table border=0 cellspacing=0>");}

                //'  **** UČENCI *******************************************************
                if (ND($n,"0123K")) { RW("<tr bgcolor='lightsalmon'><td width='40'><a name='ucenci'><h2>Učenci</h2></td><td width='600'></td></tr>");}

                //' ** Seznami ****
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciSeznami'><h3>Seznami učencev</h3></a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php'>Pregled razredov in spreminjanje razrednih podatkov</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=untis'>Podatki o učencih za Untis</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazredaizbor.php'>Spiski učencev po razredih</a></td></tr>");}
                //if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='RazrediPDF.php'>Spiski učencev po razredih (PDF)</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborucenca.php?id=2'>Spreminjanje podatkov o učencih</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=dodpouk'>Vnos učencev za DOD in DOP pouk</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=sppouk'>Vnos učencev za ISP, DSP, ...</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=opb'>Vnos učencev za OPB in jutranje varstvo</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=prehrana'>Vnos prehrane učencev</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=malice'>Mesečni spiski za malice</a></td></tr>");}
                if (ND($n,"1")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=106'>Statistika o prehrani učencev</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=izjave'>Vnos soglasij staršev</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=prijavanpz'>Prijave na NPZ - 6. razredi</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=tabor'>Šola v naravi/Tabor</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=plavanje'>Znanje plavanja</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=dejavnosti'>Vnos dnevov dejavnosti</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=102'>Spiski učencev: ISP, DSP, DOD, DOP, OPB in JUV</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=104'>Spiski učencev: ISP, DSP, DOD, DOP, OPB in JUV (PDF)</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=114'>Spiski učencev: nadarjeni, status, tujci, vozači, bivanje,...</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=117'>Spiski učencev: nezadostni, z izpiti, ...</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=115'>Nadarjeni - potrditve</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=116'>Tujci - odločbe</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=126'>Individualni programi</a></td></tr>");}
                if (($n==1 && (($VIdDelo > 4) && ($VIdDelo < 11))) or ($n > 1) ) {	
                    if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='ucenec.php?id=1'>Vpiši novega učenca</a></td></tr>");}
                }
	            
	            //' ** Redovalnica ****
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciRedovalnica'><h3>Redovalnica</h3></a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izpisredovalnice.php'><b>Redovalnice</b>, uspeh, obvestilo o uspehu, poročilo razrednika</a></td></tr>");}
	            if (ND($n,"0")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izpisredovalnice.php'><b>Redovalnice</b></a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborucenca.php?id=3'>Vnos vzgojnih ukrepov</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=uspeh'>Vpis statusov, napredovanja, popravnih izpitov,...</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=odsotnost'>Vnos odsotnosti</a></td></tr>");}
	            //if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VnosPreverjanjZnanja.php'>Vnos datumov pisnih ocenjevanj znanja</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='maticnilisti.php'>Matični listi</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborucenca.php?id=5'>Potrdilo o izpolnjeni OŠ obveznosti</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=123'>Preveri, kdo še ni ocenjen!</a></td></tr>");}
	            //if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzborKontrolke.php'>Vpis kontrolne naloge</a></td></tr>");}
	            //if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PregledKontrolke.php'>Pregled kontrolnih nalog</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='opisneocene.php?idd=100'>Izpis opisnih ciljev in ocen za 1.-2. razred - klasično</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='opisneocene.php?idd=200'>Vnos redovalnice za 1.-2. razred - klasično</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a class='menuItem' href='opisneocenen.php?idd=100'>Opisni cilji in ocene za 1.-2. razred (ocene ciljev)</a></td></tr>");}
                if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a class='menuItem' href='opisneocenen.php?idd=200'>Vnos redovalnica za 1.-2. razred (ocene ciljev)</a></td></tr>");}
                if (ND($n,"123") ) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=starsi'>Komunikacija s starši</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=govorilne'>Sodelovanje s starši</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='vnosispiski.php?idd=124'>Učencem z vneseno zaključno oceno briši oznako neocenjen</a></td></tr>");}
	            
	            //' ** Poročila ****
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciPorocila'><h3>Poročila</h3></a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VnosZapisnik.php'>Vnos zapisnikov in poročil</a></td></tr>");}
	            //if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VnosPrimerDobreRabe.php'>Primeri dobre prakse</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VnosIzobrazevanje.php'>Vnos poročila o udeležbi na izobraževalnih seminarjih</a></td></tr>");}
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzborRealizacije.php'>Vnos realizacije in dnevov dejavnosti - po razredih</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzborRealizacijeInd.php'>Vnos realizacije - po učiteljih</a></td></tr>");}
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PedPorocilo.php'>Vnos pedagoškega poročila</a></td></tr>");}
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzborAktiviPorocilo.php?id=1a'>Vnos in pregled poročil aktivov</a></td></tr>");}
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzborAktiviPorocilo.php?id=1b'>Vnos in pregled načrtov aktivov</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PorociloRazrednikaPregled.php?razred=0'>Pedagoška poročila razrednikov (vsa - 1. polletje)</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PorocilaRazrednikovRTF1.php'>Pedagoška poročila razrednikov (vsa - 1. polletje) - RTF/Word</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PorociloRazrednikaPregled.php?razred=0'>Pedagoška poročila razrednikov (vsa - končno)</a></td></tr>");}	
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PorocilaRazrednikovRTF2.php'>Pedagoška poročila razrednikov (vsa - končno) - RTF/Word</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='pregledi.php?idd=700'>Pregled poročil o uspehu (1. obdobje) - uspeh, realizacija, negativni, neocenjeni</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='pregledi.php?idd=710'>Pregled poročila o uspehu (končno) - uspeh, realizacija, negativni, neocenjeni</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PedPorocilo.php'>Pregled poročil razrednikov po razredih</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzpisRealizacij.php?id=1'>Izpis realizacij - 1. obdobje</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='IzpisRealizacij.php?id=2'>Izpis realizacij - celoletno</a></td></tr>");}
	            
	            //' ** Izbirni ****
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciIzbirni'><h3>Izbirni in nivojski pouk</h3></a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=1'>Dodaj izbirne predmete učencem</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=23'>Nabor izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=25'>Obrazci za izbor izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=20'>Vnos izbir izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=26'>Izbor izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=27'>Izbrani izbirni predmeti po razredih za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=28'>Učenci po izbirnih predmetih za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=1a'>Dodaj neobv. izbirne predmete učencem</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=23a'>Nabor neobv. izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=25a'>Obrazci za izbor neobv. izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=20a'>Vnos izbir neobv. izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=26a'>Izbor neobv. izbirnih predmetov za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=27a'>Izbrani neobv. izbirni predmeti po razredih za novo ŠL</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=28a'>Učenci po neobv. izbirnih predmetih za novo ŠL</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=6'>Izpis izbirnih predmetov</a></td></tr>");}
                if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=6a'>Izpis izbirnih predmetov po razredih</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=9'>Izpis skupin po izbirnih predmetih (PDF)</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=7'>Izpis izbirnih predmetov - zgodovina</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=10'>Dodaj nivojske predmete učencem</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=13'>Izpis nivojskih predmetov</a></td></tr><tr><td></td>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izbirniskupine.php?id=14'>Izpis nivojskih skupin (PDF)</a></td></tr>");}
	            
	            //' ** Tekmovanja ****
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciTekmovanja'><h3>Tekmovanja in interesne dejavnosti</h3></a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=101'>Vnos rezultatov tekmovanj iz znanja</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=109'>Spisek tekmovanj iz znanja</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=112'>Dobitniki srebrnih in zlatih priznanj</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=101'>Druga tekmovanja v znanju - vnos</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='izborrazreda.php?id=interesne1'>Obvestila o sodelovanju na tekmovanjih v znanju (PDF)</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=201'>Interesne dejavnosti</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=301'>Šolska športna tekmovanja</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=401'>Natečaji</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='tekmovanjakrozki.php?id=501'>Ostala priznanja in pohvale</a></td></tr><tr><td></td>");}
	            
	            //'** NPZ ****
	            if (ND($n,"23")) { RW("<td bgcolor='wheat'><a name='ucenciNPZ'><h3>NPZ</h3></a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='npz.php?idd=100'>Vnos podatkov za NPZ</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='npz.php?idd=700'>Uvoz rezultatov NPZ</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='npz.php?idd=800'>Izvoz ocen in podatkov za NPZ in za vpis v srednje šole</a></td></tr>");}
                if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='npz.php?idd=801'>Izvoz podatkov za NPZ</a></td></tr>");}
	            
	            //'** Uvoz podatkov iz Lopolisa ****
	            if (ND($n,"3")) { RW("<tr><td></td><td bgcolor='wheat'><h3>Uvoz podatkov iz LoPolis-a</h3></td></tr>");}
	            if (ND($n,"3")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='priprava.php?idd=900&id=1'>Uvoz podatkov o učencih, razredih in izbirnih predmetih</a></td></tr>");}
	            
	            //' ** Dejavnosti ****
                //'	if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='wheat'><a name='ucenciDejavnosti'><h3>Dejavnosti</h3></a></td></tr>");}
                //'	if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='http:'www2.arnes.si/~osljmj1/informacije/dejavnosti/dejavnosti.htm'>Dejavnosti</a></td></tr>");}
	            
	            //' **** DELO *******************************************************
	            if (ND($n,"0123K")) { RW("<tr bgcolor='limegreen'><td><a name='delo'><h2>Delo</h2></td><td></td></tr>");}
	            
	            //' ** Kadri ****
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightgreen'><a name='deloKadri'><h3>Kadri</h3></a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php'>Ogled in vnos podatkov o delavcih</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PregledIzobrazevanj.php'>Pregled izobraževanj</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='DejavnostiZaNapredovanje.php'>Dejavnosti za napredovanje</a></td></tr>");}
	            if (ND($n,"01K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisUcitelja.php?idUcitelj=" . $VUporabnikId . "'>Mesečni pregledi dela</a></td></tr>");}
	            if (($n==1 && (($VIdDelo > 4) && ($VIdDelo < 11))) or ($n > 1) ) {	
		            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Kontakti.php'>Kontaktni podatki zaposlenih</a></td></tr>");}
	            }
	            if (ND($n,"01K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></td></tr>");}
	            if (ND($n,"01K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosPotniNalogi.php?id=9'>Spisek mojih potnih nalogov</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='obrazci.php'>Obrazci in dokumenti</a></td></tr>");}
                if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='letniucninacrt.php'>Letni učni načrti</a></td></tr>");}
	            //if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosUcniPripomocki.php'>Učni pripomočki</a></td></tr>");}
	            if ($NacinObracunaDoprinosa==0 ) {
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisPregledovDela.php'>Izpis vnesenih mesečnih pregledov dela</a></td></tr>");}
	            }else{
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisPregledovDelaN.php'>Izpis vnesenih mesečnih pregledov dela</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborMesecLeto.php?id=1'>Izpis mesečnih pregledov po mesecih za vse delavce</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborMesecLeto.php?id=3'>Izpis mesečnih pregledov po mesecih za vse delavce-zbirnik</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborMesecLeto.php?id=4'>Izpis mesečnih pregledov po mesecih za vse delavce-zbirnik (računovodstvo)</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='LetniPregledDela.php'>Izpis letnega pregleda dela za vse delavce</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PoPN.php?id=5'>Delo izven šolskih prostorov po potnih nalogih</a></td></tr>");}
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PotrjevanjeRubrikPDN.php'>Potrjevanje rubrik za vnesene mesečne podatke</a></td></tr>");}
	            }
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='OpisDelInNalog.pdf' target='_blank'>Opis del in nalog</a></td></tr>");}
	            //if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosOsOc.php?id=1'>Predlog redne delovne uspešnosti</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PopraviUcitelja.php?id=2'>Dodaj novega delavca</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php?id=1'>Popravi podatke o delavcu</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisUciteljev.php'>Izpis kadrov</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisUciteljevList.php'>Izpis kadrov - roj. podatki</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='DelavciNaDan.php'>Delavci zaposleni na določen dan</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisObremenitveUciteljev.php'>Izpis obremenitve kadrov</a></td></tr>");}
	            //if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosKoef.php'>Vnos koeficientov</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='ZadnjiVpisi.php'>Zadnji vpisi doprinosov</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisPotrjevalcev.php'>Kdo je potrjeval vnose in koliko</a></td></tr>");}
	            if ($Opravila==1 ) {
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisOpravil.php'>Opravljena opravila po delavcih</a></td></tr>");}
	            }
	            
	            //' **Sistemizacija ****
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightgreen'><a name='deloSistematizacija'><h3>Sistemizacija</h3></a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Sistematizacija.php'>Sistemizacija</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='SistematizacijaVrsticno.php'>Sistemizacija - tabela</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Predmeti.php'>Vnos predmetov in učiteljev po razredih</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Aktivi.php'>Vodje aktivov</a></td></tr>");}
	            
	            //' ** Urnik ****
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightgreen'><a name='deloUrnik'><h3>Urnik</h3></a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Urnik.php'>Urnik</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosUrnika.php'>Vnos urnika</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosNadomescanje.php?id=1'>Vnos nadomeščanj</a></td></tr>");}
	            if (ND($n,"01K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosNadomescanje.php?id=7'>Pregled nadomeščanj</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosDogodkov.php'>Vnos obveznosti in rokov izvedbe za delavce</a></td></tr>");}
	            
	            //' ** Tajnistvo ****
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightgreen'><a name='deloTajnistvo'><h3>Tajništvo</h3></a></td></tr>");}
	            if (($n==1 && (($VIdDelo == 16))) or ($n > 1) ) {	
		            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborMesecLeto.php?id=2'>Priprava pregledov dela za računovodstvo</a></td></tr>");}
	            }
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborDelavcevIzbor.php'>Izpisi zaposlenih</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Kontakti.php'>Kontaktni podatki zaposlenih</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='DelDoba.php'>Izračun delovne dobe</a></td></tr>");}
	            if ($RazsirjenVnos ) {
		            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PodatkiODelavcih.php'>Podatki o sklenjenih pogodbah delavcev</a></td></tr>");}
	            }
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='izborucenca.php?id=1'>Potrdilo o šolanju</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php?id=2'>Potrdilo o zaposlitvi</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='izborrazreda.php?id=potrdilo'>Potrdilo o šolanju za cel razred</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='izborucenca.php?id=4'>Potrdilo o šolanju za nove prvošolce</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PrevozniStroski.php'>Vpis prevoznih stroškov za delavce</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisDopustov.php' target='new_win'>Odločbe za dopust</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzpisPregledovDelaN.php'>Prenesi stare dopuste in višek ur preteklega leta v novo leto</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='delovodnik.php?id=1'>Delovodnik</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborPotniNalog.php'>Novi potni nalogi</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosPotniNalogi.php?id=5'>Spisek potnih nalogov</a></td></tr>");}
	            //if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='KopirajPotneNaloge.php'>Kopiranje vsebine potnega naloga</a></td></tr>");}
	            //if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='ZetoniMP.php?id=1'>Mestni promet - Urbana</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosNarocilnica.php?id=1'>Naročilnice</a></td></tr>");}
	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='ZdravniskiPregledi.php'>Zdravstveni pregledi</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='PozarnaVarnost.php'>Požarna varnost</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VarstvoPriDelu.php'>Varstvo pri delu</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='ZascOprema.php'>Zaščitna oprema</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Izjave.php'>Izjave o varovanju podatkov</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VpisPregledDelaVsi.php'>Vpis istih rubrik več delavcem</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php?id=5'>Pregled pogodbe o zaposlitvi</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='DodajPogodbo.php?id=6'>Pregled pogodb o zaposlitvi za vse delavce</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='IzborUcitelja.php?id=4'>Vnos pogodb o delu</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='DejavnostiZaNapredovanje.php'>Potrdila delavcem</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosSvet.php'>Svet staršev in svet šole</a></td></tr>");}
	            //if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosInventura.php?id=1'>Inventura</a></td></tr>");}
	            //if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='VnosDrobniInventar.php?id=1'>Drobni inventar</a></td></tr>");}
	            //if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='aquamarine'><li><a href='Kljuci.php?id=1'>Vnos ključev</a></td></tr>");}
            /*	
	            if ($EvidencaPrehrane==1 ) {
		            //' **** PREHRANA *********************************************
		            if (ND($n,"23")) { RW("<tr bgcolor='gray'><td><a name='prehrana'><h2>Prehrana</h2></td><td></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaSpisek.php'>Prehrana - spisek</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaBrisiDevete.php'>Prehrana - brisanje vseh učencev devetih razredov</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaUpdateRazred.php'>Prehrana - dodelitev višjega razred (novo šolsko leto)</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaDodajStranko.php'>Prehrana - dodaj novo stranko</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaDodajPrviR.php'>Prehrana - dodaj prve razrede</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaIzborMeseca.php'>Prehrana - mesečni pregled</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightgrey'><li><a href='PrehranaZadnjih10.php'>Prehrana - zadnjih 10</a></td></tr>");}
	            }
            */
	            if ($EvidencaPrisotnosti==1 ) {
		            //' **** PRISOTNOST  *********************************************
		            if (ND($n,"23")) { RW("<tr bgcolor='orange'><td><a name='prisotnost'><h2>Prisotnost</h2></td><td></td></tr>");}
		            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VpisPrihodov.php'>Evidenca prihodov/odhodov</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PrisotnostIzborMeseca.php?id=1'>Prisotnost - mesečni pregled</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PrisotnostIzborMeseca.php?id=2'>Prisotnost - mesečni pregled (vsi)</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PrisotnostIzborMeseca.php?id=4' target='new_win'>Odsotnost - mesečni pregled (vsi)</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PrisotnostIzborMeseca.php?id=3'>Prisotnost - ure (vsi)</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='PrisotnostDelavcaDan.php'>Prisotnost - danes</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightyellow'><li><a href='VpisOdsotnostiDelavcev.php'>Vpis odsotnosti delavcev</a></td></tr>");}
		            if (ND($n,"23")) { RW("<tr></td><td><td bgcolor='lightyellow'><li><a href='VpisPrihodaDelavcev.php'>Vpis prihodov/odhodov delavcev</a></td></tr>");}
	            }

	            
	            //' **** STATISTIKE *******************************************
	            if (ND($n,"0123K")) { RW("<tr bgcolor='mediumpurple'><td><a name='statistike'><h2>Statistike</h2></td><td></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=500'>Statistika ocen ob polletju</a></td></tr>");}
	            if (ND($n,"0123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=510'>Statistika ocen po posameznih razredih ob polletju</a></td></tr>");}

	            if (ND($n,"123K")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='DelovnoRazmerje.php'>Statistika kadrov</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=200'>Statistika oddelkov in učencev - stat. urad</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=210'>Statistika oddelkov in učencev v novem šol. letu</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=220'>Statistika oddelkov in učencev - šola</a></td></tr>");}

	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=100'>Število učencev po razredih in razredniki</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=300'>Statistika odsotnosti učencev</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=520'>Uspeh po razredih</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=400'>Vzgojni ukrepi</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=530'>Statistika zaključnih ocen</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='pregledi.php?idd=540'>Statistika zaključnih ocen po razredih</a></td></tr>");}

	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='StatZaposleni.php'>Statistika zaposlenih</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='vnosispiski.php?idd=106'>Statistika o prehrani učencev</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='vnosispiski.php?idd=113'>Statistika o šoli v naravi</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='vnosispiski.php?idd=102'>Statistika o ISP, DSP, DOD, DOP, OPB in JUV</a></td></tr>");}
	            if (ND($n,"123")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='vnosispiski.php?idd=114'>Spiski učencev: nadarjeni, status, tujci, vozači, bivanje,...</a></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='vnosispiski.php?idd=117'>Spiski učencev: nezadostni, z izpiti, ...</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='lightcyan'><li><a href='letnoporocilo.php'>Letno poročilo</a></td></tr>");}
	            
	            //' **** ADMINISTRACIJA *******************************************
	            if (ND($n,"3K")) { RW("<tr bgcolor='yellowgreen'><td><h2>Administracija</h2></td><td></td></tr>");}
	            if (ND($n,"23")) { RW("<tr><td></td><td bgcolor='springgreen'><li><a href='priprava.php?idd=100'>Prenos učencev v novo šolsko leto</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='springgreen'><li><a href='PodatkiOSoli.php?id=1'>Podatki o šoli</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='springgreen'><li><a href='VnosPraznikov.php?id=1'>Vnos praznikov in počitnic</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='springgreen'><li><a href='Prostori.php?id=1'>Prostori</a></td></tr>");}
	            if (ND($n,"23K")) { RW("<tr><td></td><td bgcolor='springgreen'><li><a href='VnosPredmetov.php?id=1'>Vnos predmetov in dejavnosti</a></td></tr>");}
	            
	            //' **** SPLO?NO ********************************************
	            if (ND($n,"0123K")) { RW("<tr bgcolor='tan'><td><a name='splosno'><h2>Splošno</h2></td><td></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='KorekcijaTiska.php' target='new_win'>Korekcija tiskanja na obrazce</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='KoledarLeto.php' target='new_win'>Koledarji</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='tiskanje_navodilo.htm' target='new_win'>Navodilo za tiskanje PDF dokumentov</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='navodilo_kadri.htm'>Navodila/Pomoč</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='SpremeniGeslo.php'>Spreminjanje gesla</a></td></tr>");}
	            if (ND($n,"0123K")) { RW("<tr><td></td><td bgcolor='khaki'><li><a href='Izhod.php'>Izhod</a></td></tr>");}
	            
	            
	            if (ND($n,"0123K")) { RW("</table>");}
            }
        }
    }else{
	    echo "Vaše uporabniško ime ali geslo je nepravilno!<br><br>";
	    //'echo "4.Geslo: "&VGeslo&" uporabnik: "&VUporabnik&"<br>"
        header("Location: nepooblascen.htm");
    }

    if (($Opravila==1 ) && ($n > 1)) {
        
        //error_reporting(E_ALL);
        error_reporting(E_STRICT);

        date_default_timezone_set('Europe/Ljubljana');

        require_once('class.phpmailer.php');
        //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded


        /*
        if(!$mail->Send()) {
          echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
          echo "Message sent!";
        }
        */
	    $SQL = "SELECT tabdeldogodek.*,tabdogodek.*,tabdeldogodek.id AS did FROM ";
	    $SQL = $SQL . "tabdeldogodek INNER JOIN tabdogodek ON tabdeldogodek.idDogodek=tabdogodek.id ";
	    $SQL = $SQL . "WHERE tabdeldogodek.opravljeno=false AND tabdogodek.leto=".$VLeto." AND ((intervencija1=false) OR (intervencija2=false))";

	    $indx=1;
        $result = mysqli_query($link,$SQL);
        while ($R = mysqli_fetch_array($result)){
    //'			echo day(now)&"."&month(now)&"."&year(now)&" "&day($R["porocilaDo"])&"."&month($R["porocilaDo"])&"."&year($R["porocilaDo"])&" - "&DateDiff("d",day(now)&"."&month(now)&"."&year(now),day($R["porocilaDo"])&"."&month($R["porocilaDo"])&"."&year($R["porocilaDo"]))&"<br>"
            $datumDo=new DateTime(isDate($R["porocilaDo"]));
            $interval=$Danes->diff($datumDo);
		    switch ($interval->days){
			    case 0: //,1,2,3
				    if ($R["intervencija1"]==false ) {
					    if ($R["intervencija2"]==false ) {
						    $Vopravila[$indx][0]=$R["did"];	//'dogodek
						    $Vopravila[$indx][1]=$R["Dogodek"];	//'opis
						    $Vopravila[$indx][2]=$R["idUcitelj"];	//'učitelj
						    $Vopravila[$indx][3]=$datumDo->format('Y-m-d');	//'datum do
						    $Vopravila[$indx][4]=3;	//'vpis zastavic
						    $indx=$indx+1;
					    }
				    }else{
					    if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('Y-m-d');    //'datum do
                            $Vopravila[$indx][4]=2;    //'vpis zastavic
                            $indx=$indx+1;
					    }
				    }
                    break;
                case 1: //,1,2,3
                    if ($R["intervencija1"]==false ) {
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=3;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }else{
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=2;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }
                    break;
                case 2: //,1,2,3
                    if ($R["intervencija1"]==false ) {
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=3;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }else{
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=2;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }
                    break;
                case 3: //,1,2,3
                    if ($R["intervencija1"]==false ) {
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=3;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }else{
                        if ($R["intervencija2"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=2;    //'vpis zastavic
                            $indx=$indx+1;
                        }
                    }
                    break;
			    default:
				    if ($R["intervencija1"]==false ) {
                            $Vopravila[$indx][0]=$R["did"];    //'dogodek
                            $Vopravila[$indx][1]=$R["Dogodek"];    //'opis
                            $Vopravila[$indx][2]=$R["idUcitelj"];    //'učitelj
                            $Vopravila[$indx][3]=$datumDo->format('j.n.Y');    //'datum do
                            $Vopravila[$indx][4]=1;    //'vpis zastavic
                            $indx=$indx+1;
				    }
		    }
	    }
	    $StDogodkov=$indx-1;
	    
        $PosiljateljFrom="mail.kadri.send@gmail.com";
        //$PosiljateljFrom=$EmailRavnatelj;
	    for ($indx=1;$indx <= $StDogodkov;$indx++){
		    $SQL = "SELECT * FROM tabkontakti WHERE IdUcitelj=".$Vopravila[$indx][2];
            $result = mysqli_query($link,$SQL);
            if ($R = mysqli_fetch_array($result)){
			    if (strpos($R["email"],"@") > 0 ) {
                    $address = $R["email"];
                    
                    $mail             = new PHPMailer();
				    $mail->CharSet='UTF-8';

                    //$body             = file_get_contents('contents.html');
                    //$body             = eregi_replace("[\]",'',$body);

                    $mail->IsSMTP(); // telling the class to use SMTP
                    /*
                    $mail->Host       = "mail.gmail.com"; // SMTP server
                    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                                               // 1 = errors and messages
                                                               // 2 = messages only
                    $mail->SMTPAuth   = true;                  // enable SMTP authentication
                    $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                    $mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
                    $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                    $mail->Username   = "mail.kadri.send@gmail.com";  // GMAIL username
                    $mail->Password   = "k4dr1S3ndm41l";            // GMAIL password
                    */

                    $mail->Host       = $mail_host1; // SMTP server
                    $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                    $mail->SMTPAuth   = true;                  // enable SMTP authentication
                    $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                    $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                    $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                    $mail->Username   = $mail_user1;  // GMAIL username
                    $mail->Password   = $mail_pass1;            // GMAIL password

                    $mail->SetFrom("$PosiljateljFrom", "$PosiljateljFrom");

                    $mail->AddReplyTo("$EmailRavnatelj","$EmailRavnatelj");

                    $mail->Subject    = "Kadri - vnos podatkov";


                    $body="Spoštovani,\n\nRok za vnos podatkov: ".$Vopravila[$indx][1]." je ".$Vopravila[$indx][3].".\n\n"."Lep pozdrav,\n\n".$VRavnatelj;
                    $mail->AltBody    = $body;
                    
                    $body = str_replace("\n","<br />",$body);
                    $mail->MsgHTML($body);

                    //$address = "whoto@otherdomain.com";
                    //$mail->AddAddress($address, "John Doe");

                    //$mail->AddAttachment("images/phpmailer.gif");      // attachment
                    //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
                    
                    
                    $mail->AddAddress($address, $address);
                    
    //                $body="Spoštovani,\n\nRok za vnos podatkov: ".$Vopravila[$indx][1]." je ".$Vopravila[$indx][3].".\n\n"."Lep pozdrav,\n\n".$VRavnatelj;
                    if(!$mail->Send()) {
                        echo "Napaka pri pošiljanju pošte: " . $mail->ErrorInfo;
                    } else {
                        echo "Sporočilo o delovnih opravilih poslano: ".$address."<br />";
                    }
                    $mail=null;
 			    }
			    switch ($Vopravila[$indx][4]){
				    case 1:
					    $SQL = "UPDATE tabdeldogodek SET intervencija1=true WHERE id=".$Vopravila[$indx][0];
                        $result1 = mysqli_query($link,$SQL);
					    break;
				    case 2:
					    $SQL = "UPDATE tabdeldogodek SET intervencija2=true WHERE id=".$Vopravila[$indx][0];
                        $result1 = mysqli_query($link,$SQL);
					    break;
				    case 3:
					    $SQL = "UPDATE tabdeldogodek SET intervencija1=true,intervencija2=true WHERE id=".$Vopravila[$indx][0];
                        $result1 = mysqli_query($link,$SQL);
					    break;
			    }
		    }
		    
	    }
    }
}
//echo "<br /><br /><small>Copyright (2006-2014) by AL ELEKTRONIK Aleš Drinovec s.p.</small>";
?>
<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank"><img alt="Creative Commons licenca" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">Kadri in učenci</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://www.alelektronik-ad.si" property="cc:attributionName" rel="cc:attributionURL" target="_blank">AL ELEKTRONIK Aleš Drinovec s.p.</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank">Creative Commons Priznanje avtorstva-Deljenje pod enakimi pogoji 4.0 International License</a>.<br />Ustvarjena na podlagi dela, dostopnega na <a xmlns:dct="http://purl.org/dc/terms/" href="http://www.alelektronik-ad.si/index.php/19-alelektronik/dejavnosti/24-kadri-in-ucenci" rel="dct:source" target="_blank">http://www.alelektronik-ad.si</a>.
<?php
echo "<br /><small>Deli programske opreme drugih avtorjev:<br />";
echo " - rezervacije prostorov: (<a href='http://mrbs.sourceforge.net/' target='_blank'>MRBS (free GPL)</a>)<br />";
echo " - pošiljanje e-mailov: <a href='http://phpmailer.worxware.com/' target='_blank'>PHP-mailer lite (GNU LESSER GENERAL PUBLIC LICENSE)</a><br />";
echo " - PDF generator: <a href='http://www.fpdf.org/' target='_blank'>FPDF library (permissive license)</a><br />";
echo " - izbira datumov: <a href='http://javascriptcalendar.org/javascript-date-picker.php' target='_blank'>JavaScriptCalendar.org (free)</a><br />";
echo " - meni: <a href='http://www.brainjar.com/' target='_blank'>BrainJar (GNU GPL)</a><br />";
echo "</small>";

?>

</body>
</html>