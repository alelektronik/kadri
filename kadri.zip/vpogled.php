<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");
require("iskanje.php");
require("ucenci.php");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmp3.css"> 
<title>Učenec
</title>
</head>
<body>

<?php                        
$VLeto=PreberiLeto("solskoleto");

function CheckEmso($s){
    if (strlen($s) != 13){
        return false;
    }
    $sum=0;
    $n=intval(substr($s,0,1))*7;
    $sum += $n;
    $n=intval(substr($s,1,1))*6;
    $sum += $n;
    $n=intval(substr($s,2,1))*5;
    $sum += $n;
    $n=intval(substr($s,3,1))*4;
    $sum += $n;
    $n=intval(substr($s,4,1))*3;
    $sum += $n;
    $n=intval(substr($s,5,1))*2;
    $sum += $n;
    $n=intval(substr($s,6,1))*7;
    $sum += $n;
    $n=intval(substr($s,7,1))*6;
    $sum += $n;
    $n=intval(substr($s,8,1))*5;
    $sum += $n;
    $n=intval(substr($s,9,1))*4;
    $sum += $n;
    $n=intval(substr($s,10,1))*3;
    $sum += $n;
    $n=intval(substr($s,11,1))*2;
    $sum += $n;
    $n=intval(substr($s,12,1));
    $o=$sum % 11;
    if ($o == 0 && $o == $n){
        return true;
    }else{
        if ((11-$o)==$n){
            return true;
        }else{
            return false;
        }
    }
}

function ToOpisnaOcena($n){
    switch($n){
        case 1:
            return "ne dosega cilja";
            break;
        case 2:
            return "minimalno dosega cilj";
            break;
        case 3:
            return "delno dosega cilj";
            break;
        case 4:
            return "večinoma dosega cilj";
            break;
        case 5:
            return "v celoti dosega cilj";
            break;
    }
    return "";
}

function ToPredmet($n){
    switch ($n){
        case 16:
            return "slovenščina";
            break;
        case 11:
            return "matematika";
            break;
        case 9:
            return "likovna umetnost";
            break;
        case 29:
            return "glasbena umetnost";
            break;
        case 49:
            return "spoznavanje okolja";
            break;
        case 20:
            return "šport";
            break;
    }
}

if (isset($_POST["uporabnik"])){
    $VUporabnik = $_POST["uporabnik"];
}else{
    $VUporabnik = "";
}
if (isset($_POST["geslo"])){
    $VGeslo = $_POST["geslo"];
}else{
    $VGeslo = "";
}

if (isset($_POST["gsubmit"])){
    //error_reporting(E_ALL);
    error_reporting(E_STRICT);

    date_default_timezone_set('Europe/Ljubljana');

    require_once('class.phpmailer.php');
    //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded
    $address="";
    $SQL = "SELECT oceemail,matiemail,geslo FROM tabucenci WHERE emso='".$VUporabnik."'";
    $result = mysqli_query($link,$SQL);

    //Izpis razrednih podatkov
    if ($R = mysqli_fetch_array($result)){
        if ($_POST["pg"] == "1"){
            if (strpos($R["oceemail"],"@") > 0 ) {
                $address=$R["oceemail"];
            }
        }
        if ($_POST["pg"] == "2"){
            if (strpos($R["matiemail"],"@") > 0 ) {
                $address=$R["matiemail"];
            }
        }
        if (strpos($address,"@") > 0 ) {
            //$address = $R["email"];
            
            $mail             = new PHPMailer();
            $mail->CharSet='UTF-8';

            //$body             = file_get_contents('contents.html');
            //$body             = eregi_replace("[\]",'',$body);
            $emailsender = "mail.kadri.send@gmail.com";
            $mail->IsSMTP(); // telling the class to use SMTP
            $mail->Host       = $mail_host1; // SMTP server
            $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                                       // 1 = errors and messages
                                                       // 2 = messages only
            $mail->SMTPAuth   = true;                  // enable SMTP authentication
            $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
            $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
            $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
            $mail->Username   = $mail_user1;  // GMAIL username
            $mail->Password   = $mail_pass1;            // GMAIL password

            $mail->SetFrom("$emailsender");

            $mail->AddReplyTo("$emailsender");

            $mail->Subject    = "Pozabljeno geslo";


            $body="Spoštovani,\n\nGeslo za vpogled je: ".$R["geslo"]."\n\nLep pozdrav,\n\nAdministrator\n\nP.S. To sporočilo je generirano avtomatsko. Na to sporočilo ne odgovarjajte!";
            $mail->AltBody    = $body;
            
            $body = str_replace("\n","<br />",$body);
            $mail->MsgHTML($body);

            //$address = "whoto@otherdomain.com";
            //$mail->AddAddress($address, "John Doe");

            //$mail->AddAttachment("images/phpmailer.gif");      // attachment
            //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
            
            
            $mail->AddAddress($address);
            
//                $body="Spoštovani,\n\nRok za vnos podatkov: ".$Vopravila[$indx][1]." je ".$Vopravila[$indx][3].".\n\n"."Lep pozdrav,\n\n".$VRavnatelj;
            if(!$mail->Send()) {
                echo "Napaka pri pošiljanju pošte: " . $mail->ErrorInfo;
            } else {
                echo "Geslo je bilo poslano na vašo registrirano e-pošto.<br />";
            }
            echo "<br />";
            $mail=null;
        }
    }else{
        echo "<h2>Napačno uporabniško ime!</h2>";
    }
    
}

$PrijavaOK=false;
if (CheckEmso($VUporabnik)){
    if (strlen($VGeslo) > 0){
        $SQL = "SELECT iducenec FROM tabucenci WHERE emso='". $VUporabnik . "' AND geslo='" . $VGeslo . "'";
        $result = mysqli_query($link,$SQL);
        if ($R = mysqli_fetch_array($result)){
            $ucenec=$R["iducenec"];
            $PrijavaOK=true;
        }else{
            //echo "Nimate potrebnih pooblastil za ogled strani!";
            $ucenec=0;
            $PrijavaOK=false;
        }
    }
}
if (!$PrijavaOK ) {
    //izpiše obrazec za vnos emšo in gesla
    echo "<form name='prijava' method='post' action='vpogled.php'>";
    echo "<div class='ozadje'>";
    echo "<label for='uporabnik'>Vnesite  uporabniško ime</label><input name='uporabnik' type='text' size='16'><br />";
    echo "<label for='geslo'>Vnesite  geslo</label><input name='geslo' type='password' size='16'><br />";
    echo "<input name='submit' type='submit' value='Pošlji'>";
    echo "</div>";
    echo "<br />";
    echo "<br />";
    echo "<div class='ozadje'>";
    echo "<b>Pozabljeno geslo</b>:<br />";
    echo "<small>(Zgoraj vpišite uporabniško ime in spodaj izberite, komu naj se pošlje)</small><br /><br />";
    echo "Geslo mi pošljite na e-mail:<br />";
    echo "<input name='pg' type='radio' checked='checked' value='1'>očeta<br />";
    echo "<input name='pg' type='radio' value='2'>matere<br />";
    echo "<input name='gsubmit' type='submit' value='Pozabil sem geslo'>";
    echo "</div>";
    echo "</form>";
    
}else{
    //izpiše podatke o učencu
    function ToTip($x){
        switch ($x){
            case 0:
                return "Končno spričevalo";
            case 1:
                return "Polletno obvestilo";
            case 2:
                return "Redovalnica 1. semester";
            case 3:
                return "Redovalnica 2. semester";
        }
    }
    function ToNivojski($x){
        switch ($x){
            case 1:
                return "MAT";
            case 2:
                return "MAT1";
            case 3:
                return "MAT2";
            case 4:
                return "MAT3";
            case 13:
                return "MAT4";
            case 14:
                return "MAT5";
            case 15:
                return "MAT6";
            case 5:
                return "SLO";
            case 6:
                return "SLO1";
            case 7:
                return "SLO2";
            case 8:
                return "SLO3";
            case 16:
                return "SLO4";
            case 17:
                return "SLO5";
            case 18:
                return "SLO6";
            case 9:
                return "TJA";
            case 10:
                return "TJA1";
            case 11:
                return "TJA2";
            case 12:
                return "TJA3";
            case 19:
                return "TJA4";
            case 20:
                return "TJA5";
            case 21:
                return "TJA6";
        }
    }

    function MonthName($x){
        switch ($x){
            case 1:
                return "januar";
            case 2:
                return "februar";
            case 3:
                return "marec";
            case 4:
                return "april";
            case 5:
                return "maj";
            case 6:
                return "junij";
            case 7:
                return "julij";
            case 8:
                return "avgust";
            case 9:
                return "september";
            case 10:
                return "oktober";
            case 11:
                return "november";
            case 12:
                return "december";
        }       
    }
    
    if ($ucenec > 0){
        $oUcenec=new RUcenec();
        $oUcenec->getUcenec($ucenec);
        
        //sprememba gesla
        if (isset($_POST["sgsubmit"])){
            if (isset($_POST["ngeslo1"])){
                if ($_POST["ngeslo1"] == $_POST["ngeslo2"] && (mb_strlen($_POST["ngeslo1"],$encoding) > 7)){
                    $SQL = "UPDATE tabucenci SET geslo='".$_POST["ngeslo1"]."' WHERE emso='".$VUporabnik."'";
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Težave s podatkovno bazo, novo geslo ni shranjeno!<br />$SQL <br />");
                    }else{
                        echo "<h2>Geslo je spremenjeno.</h2>";
                    }
                }else{
                    echo "<h2>Vnosa se ne ujemata ali pa je novo geslo prekratko!</h2>";
                }
                echo "<a href='vpogled.php'>Na ponovno prijavo</a><br />";
            }else{
                echo "<form name='spremembag' method='post' action='vpogled.php'>";
                echo "<div class='ozadje'>";
                echo "Geslo naj vsebuje vsaj 8 znakov, po možnosti velike in majhne znake ter številke.<br /><br />";
                echo "<label for='ngeslo1'>Novo geslo</label>";
                echo "<input name='ngeslo1' type='password' value=''><br />";
                echo "<label for='ngeslo2'>Ponovni vpis novega gesla</label>";
                echo "<input name='ngeslo2' type='password' value=''><br />";
                echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
                echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
                echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
                echo "<input name='sgsubmit' type='submit' value='Sprememba gesla'>";
                echo "</div>";
                echo "</form>";
            }
        }else{
            //sporočilo razredniku - začetek
            if (isset($_POST["ssubmit"])){
                //poslano je bilo sporočilo razredniku
                $txt=$_POST["vsebina"];
                //pobriše krmilne HTML znake
                $order   = array("\"", "'", ">","<",'$');
                $txt = str_replace($order,"",$txt);
                $SQL = "INSERT INTO tabsporocila (leto,datum,iducenec,posiljatelj,vsebina) VALUES (";
                $SQL .= $VLeto;
                $SQL .= ",'".$Danes->format('Y-m-d H:i:s')."'";
                $SQL .= ",".$ucenec;
                $SQL .= ",2";
                $SQL .= ",'".$txt."'";
                $SQL .= ")";
                if (!($result = mysqli_query($link,$SQL))){
                    die("Težave s podatkovno bazo, sporočilo ni shranjeno!<br />$SQL <br />");
                }else{
                    echo "<h2>Sporočilo je bilo poslano.</h2>";
                }
                //obvestilo razrednika po e-pošti
                //error_reporting(E_ALL);
                error_reporting(E_STRICT);

                date_default_timezone_set('Europe/Ljubljana');

                require_once('class.phpmailer.php');
                //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded
                $address="";
                $SQL = "SELECT tabkontakti.email FROM tabkontakti ";
                $SQL .= "INNER JOIN tabrazred ON tabkontakti.iducitelj=tabrazred.iducitelj ";
                $SQL .= "WHERE tabrazred.iducenec=".$ucenec." AND tabrazred.leto=".$VLeto;
                $result = mysqli_query($link,$SQL);
                if ($R = mysqli_fetch_array($result)){
                    $address=$R["email"];
                    if (strpos($address,"@") > 0 ) {
                        //$address = $R["email"];
                        
                        $mail             = new PHPMailer();
                        $mail->CharSet='UTF-8';

                        //$body             = file_get_contents('contents.html');
                        //$body             = eregi_replace("[\]",'',$body);
                        $emailsender = "mail.kadri.send@gmail.com";
                        $mail->IsSMTP(); // telling the class to use SMTP
                        $mail->Host       = $mail_host1; // SMTP server
                        $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                                                   // 1 = errors and messages
                                                                   // 2 = messages only
                        $mail->SMTPAuth   = true;                  // enable SMTP authentication
                        $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
                        $mail->Host       = $mail_host1;      // sets GMAIL as the SMTP server
                        $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                        $mail->Username   = $mail_user1;  // GMAIL username
                        $mail->Password   = $mail_pass1;            // GMAIL password

                        $mail->SetFrom("$emailsender");

                        $mail->AddReplyTo("$emailsender");

                        if ($oUcenec->getSpol()=="M"){
                            $mail->Subject    = "Sporočilo staršev učenca: ".$oUcenec->getIme()." ".$oUcenec->getPriimek();
                        }else{
                            $mail->Subject    = "Sporočilo staršev učenke: ".$oUcenec->getIme()." ".$oUcenec->getPriimek();
                        }

                        $body="Spoštovani,\n\nV aplikaciji Kadri je objavljeno sporočilo staršev razredniku za ";
                        if ($oUcenec->getSpol()=="M"){
                            $body .= "učenca: ";
                        }else{
                            $body .= "učenko: ";
                        }
                        $body .= $oUcenec->getIme()." ".$oUcenec->getPriimek()."\n\nVsebina:\n";
                        $body .= $txt;
                        $body .= "\n\nLep pozdrav,\n\nAdministrator\n\nP.S. To sporočilo je generirano avtomatsko. Na to sporočilo ne odgovarjajte!";
                        $mail->AltBody    = $body;
                        
                        $body = str_replace("\n","<br />",$body);
                        $mail->MsgHTML($body);

                        //$address = "whoto@otherdomain.com";
                        //$mail->AddAddress($address, "John Doe");

                        //$mail->AddAttachment("images/phpmailer.gif");      // attachment
                        //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
                        
                        
                        $mail->AddAddress($address);
                        
            //                $body="Spoštovani,\n\nRok za vnos podatkov: ".$Vopravila[$indx][1]." je ".$Vopravila[$indx][3].".\n\n"."Lep pozdrav,\n\n".$VRavnatelj;
                        if(!$mail->Send()) {
                            echo "Napaka pri pošiljanju pošte: " . $mail->ErrorInfo;
                        }
                        echo "<br />";
                        $mail=null;
                    }
                }
            }
            //sporočilo razredniku - konec
            
            echo "Šolsko leto: ".$VLeto."/".($VLeto+1)."<br />";
            //splošni podatki
            if ($oUcenec->getSpol() == "M"){
                echo "<h2>Podatki o učencu:</h2>";
            }else{
                echo "<h2>Podatki o učenki:</h2>";
            }
            echo "Ime: <b>" . $oUcenec->getPriimek()  . ", " . $oUcenec->getIme() . "</b>, Datum rojstva: <b>" . $oUcenec->getDatRoj(). "</b>, Spol: <b>" . $oUcenec->getSpol2() . "</b><br />";
            echo "Naslov:<b> " . $oUcenec->getNaslov() . ", " . $oUcenec->getPosta() . " " . $oUcenec->getKraj() . "</b><br />";
            if (strlen($oUcenec->getNaslovZac()) > 0){
                echo "Začasni naslov:<b> " . $oUcenec->getNaslovZac() . ", " . $oUcenec->getPostaZac() . " " . $oUcenec->getKrajZac() . "</b><br />";
            }
            echo "Telefon doma: <b>" . $oUcenec->getTelefonDoma(). "</b><br />";
            echo "Oče: <b>";
            if (strlen($oUcenec->getoce()) > 0){
                echo $oUcenec->getoce();
            }
            if (strlen($oUcenec->getocenaslov()) > 0){
                echo ", ".$oUcenec->getocenaslov();
            }
            if (strlen($oUcenec->getocekontakt()) > 0){
                echo ", ".$oUcenec->getocekontakt();
            }
            if (strlen($oUcenec->getoceGSM()) > 0){
                echo ", GSM: ".$oUcenec->getoceGSM();
            }
            if (strlen($oUcenec->getoceSluzba()) > 0){
                echo ", služba: ".$oUcenec->getoceSluzba();
            }
            echo "</b><br />";
            
            echo "Mati:<b> ";
            if (strlen($oUcenec->getmati()) > 0){
                echo $oUcenec->getmati();
            }
            if (strlen($oUcenec->getmatinaslov()) > 0){
                echo ", ".$oUcenec->getmatinaslov();
            }
            if (strlen($oUcenec->getmatikontakt()) > 0){
                echo ", ".$oUcenec->getmatikontakt();
            }
            if (strlen($oUcenec->getmatiGSM()) > 0){
                echo ", GSM: ".$oUcenec->getmatiGSM();
            }
            if (strlen($oUcenec->getmatiSluzba()) > 0){
                echo ", služba: ".$oUcenec->getmatiSluzba();
            }
            echo  "</b><br />";
            echo "Bivanje:<b> " . $oUcenec->getBivanjePri(). "</b><br />";

            $SQL = "SELECT leto FROM tabrazred WHERE iducenec=" . $ucenec . " AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);

            //Izpis razrednih podatkov
            if (mysqli_num_rows($result) > 0){
                echo "<br /><table>";
                echo "<tr class='head'>";
                echo "<th class='hide'>Leto</th>";
                echo "<th class='hide'>Razred</th>";
                echo "<th class='hide'>Polletni<br />uspeh</th>";
                echo "<th class='hide'>Uspeh</th>";
                echo "<th class='hide'>Status</th>";
                echo "<th class='hide'>Razr.<br />izpit</th>";
                echo "<th class='hide'>Napredovanje</th>";
                echo "<th class='hide'>Leto šolanja</th>";
                echo "<th class='hide'>Nadarjen</th>";
                echo "<th class='hide'>Športnik</th>";
                echo "<th class='hide'>Kulturnik</th>";
                echo "<th class='hide'>Učitelj</th>";
                echo "<th class='hide'>Vzgojitelj</th>";
                echo "</tr>";
                while ($R = mysqli_fetch_array($result)){
                    $Razred=$oUcenec->getRazred($R["leto"]);
                    echo "<tr class='hide'>";
                    echo "<td class='hide'>".$Razred["leto"]."/".($Razred["leto"]+1)."</td>";
                    echo "<td class='hide'>".$Razred["razred"].". ". $Razred["paralelka"]."</td>";
                    echo "<td class='hide'>".$Razred["uspehpol"]."</td>";
                    echo "<td class='hide'>".number_format($Razred["uspeh"],2)."</td>";
                    if ($Razred["ponavljalec"]==0){
                        echo "<td class='hide'>redni</td>";
                    }else{
                        echo "<td class='hide'>ponavlja</td>";
                    }
                    if ($Razred["razredniizpit"] > 0){
                        echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td class='hide'>&nbsp;</td>";
                    }
                    echo "<td class='hide'>".$Razred["napredovanje2"]."</td>";
                    echo "<td class='hide' align='center'>".$Razred["letosolanja"]."</td>";
                    if ($Razred["nadarjen"] > 0){
                        echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td class='hide'>&nbsp;</td>";
                    }
                    if ($Razred["statussport"] > 0){
                        echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td class='hide'>&nbsp;</td>";
                    }
                    if ($Razred["statuskult"]){
                        echo "<td class='hide' align='center'><input type='checkbox' checked='checked'></td>";
                    }else{
                        echo "<td class='hide'>&nbsp;</td>";
                    }
                    echo "<td class='hide'>".$Razred["razrednik"]."</td>";
                    if ($Razred["idvzgojitelj"] > 0){
                        echo "<td class='hide'>".$Razred["drugiucitelj"]."</td>";
                    }else{
                        echo "<td class='hide'>&nbsp;</td>";
                    }
                    echo "</tr>";
                } 
                echo "</table><br />";
            }

            //priprava izbirnih predmetov za redovalnico
            //inicializacija
            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $IzbraniPredmet[3]=0;
            $IzbraniPredmet[4]=0;
            
            $SQL = "SELECT tabizbirni.*,tabizbirni.id AS iid,tabucenci.*,tabpredmeti.*,tabpredmeti.id AS pid FROM (tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni WHERE tabizbirni.Ucenec=" .$ucenec . " AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            $IndxIzb=0;
            while ($R = mysqli_fetch_array($result)){
                if ($R["Leto"]== $VLeto) {
                    $IzbraniPredmet[$IndxIzb]=$R["pid"];
                    $IndxIzb=$IndxIzb+1;
                }
            } 
            
            //Izpis redovalnice
            $Indx1=0;
            if (isset($Razred["razred"])){
                if ($Razred["razred"] > 0){
                    if ($Razred["razred"] > 2 ){
                        //inicializacija predmetov
                        for ($i=0;$i <= 50;$i++){
                            $Predmeti[$i][0]=0;
                            $Predmeti[$i][1]="";
                        }
                        
                        $SQL = "SELECT DISTINCT tabpredmeti.*,tabucenje.predmet,tabucenje.razred,tabucenje.paralelka,tabucenje.leto FROM tabpredmeti ";
                        $SQL = $SQL . "INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet ";
                        $SQL = $SQL . "WHERE tabpredmeti.Prioriteta < 3 AND tabucenje.idRazred=" . $Razred["idrazred"]; 
                        $SQL = $SQL . " ORDER BY tabpredmeti.VrstniRed";
                        $result = mysqli_query($link,$SQL);

                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            if (($R["Prioriteta"]==0) or ($R["Prioriteta"]==2) ){
                                $Predmeti[$Indx][0]=$R["Id"];
                                $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                $Indx=$Indx+1;
                            }else{
                                if ($R["Id"]==$IzbraniPredmet[0] ){
                                    $Predmeti[$Indx][0]=$R["Id"];
                                    $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $Indx=$Indx+1;
                                }
                                if ($R["Id"]==$IzbraniPredmet[1] ){
                                    $Predmeti[$Indx][0]=$R["Id"];
                                    $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $Indx=$Indx+1;
                                }
                                if ($R["Id"]==$IzbraniPredmet[2] ){
                                    $Predmeti[$Indx][0]=$R["Id"];
                                    $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $Indx=$Indx+1;
                                }
                                if ($R["Id"]==$IzbraniPredmet[3] ){
                                    $Predmeti[$Indx][0]=$R["Id"];
                                    $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $Indx=$Indx+1;
                                }
                                if ($R["Id"]==$IzbraniPredmet[4] ){
                                    $Predmeti[$Indx][0]=$R["Id"];
                                    $Predmeti[$Indx][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $Indx=$Indx+1;
                                }
                            }
                        }
                        $Predmetov=$Indx;
                            
                        $SQL = "SELECT tabocene.*,tabocene.id AS oid, tabpredmeti.Id AS pid,tabpredmeti.Oznaka, tabpredmeti.Opis FROM tabpredmeti ";
                        $SQL = $SQL . "INNER JOIN tabocene ON tabocene.IdPredmet = tabpredmeti.Id ";
                        $SQL = $SQL . "WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto;
                        $result = mysqli_query($link,$SQL);
                            
                        $Indx=0;
                        while ($R = mysqli_fetch_array($result)){
                            for ($Indx1=0;$Indx1 <= 50;$Indx1++){
                                if ($R["pid"]==$Predmeti[$Indx1][0]){
                                    $OcenePredmeta[$Indx1][0]=$R["Leto"];
                                    $OcenePredmeta[$Indx1][1]=$R["Oznaka"]." - ".$R["Opis"];
                                    $OcenePredmeta[$Indx1][2]="&nbsp;".$R["OcenaS1P"];
                                    $OcenePredmeta[$Indx1][3]="&nbsp;".$R["OcenaS1U"];
                                    $OcenePredmeta[$Indx1][4]="&nbsp;".$R["OcenaS2P"];
                                    $OcenePredmeta[$Indx1][5]="&nbsp;".$R["OcenaS2U"];
                                    $OcenePredmeta[$Indx1][11]="&nbsp;".$R["OcenaPolletna"];
                                    $OcenePredmeta[$Indx1][6]="&nbsp;".$R["OcenaKoncna"];
                                    $OcenePredmeta[$Indx1][7]=$R["Neocenjen"];
                                    $OcenePredmeta[$Indx1][8]=$R["Popravni"];
                                    $OcenePredmeta[$Indx1][9]=$R["Datum"];
                                    $OcenePredmeta[$Indx1][10]=$R["oid"];
                                }
                            }
                            $Indx = $Indx+1;
                        } 
                        
                        echo "<a name='redovalnica'></a>";
                        echo "<table>";
                        echo "<tr class='head'>";
                        echo "<th class='hide'>Leto</th>";
                        echo "<th class='hide'>Predmet</th>";
                        echo "<th class='hide'>Pisne ocene</th>";
                        echo "<th class='hide'>Ustne ocene</th>";
                        echo "<th class='hide'>Polletno</th>";
                        echo "<th class='hide'>Zaključeno</th>";
                        echo "<th class='hide'>Neocenjen</th>";
                        echo "<th class='hide'>Popravni</th>";
                        echo "<th class='hide'>Datum</th>";
                        echo "</tr>";

                        for ($Indx=0;$Indx < $Predmetov;$Indx++){
                            if (!isset($OcenePredmeta[$Indx][0])){
                                echo "<tr class='hide'>";
                                echo " <td>".$VLeto."/".($VLeto+1)."</td>";
                                echo " <td>".$Predmeti[$Indx][1]."</td>";
                                echo " <td>";
                                echo "  <table class='trans' border=1 cellspacing=0>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans'></td>";
                                echo "   </tr>";
                                echo "   <tr>";
                                echo "    <td class='trans'></td>";
                                echo "   </tr>";
                                echo "  </table>";
                                echo " </td>";
                                echo " <td>";
                                echo "  <table class='trans'>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans'></td>";
                                echo "   </tr>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans'></td>";
                                echo "   </tr>";
                                echo "  </table>";
                                echo " </td>";
                                echo " <td></td>";
                                echo " <td></td>";
                                echo " <td></td>";
                                echo " <td></td>";
                                echo " <td></td>";
                            }else{
                                echo "<tr class='hide'>";
                                echo " <td class='hide'>".$OcenePredmeta[$Indx][0]."/".($OcenePredmeta[$Indx][0]+1)."</td>";
                                echo " <td class='hide'>".$OcenePredmeta[$Indx][1]."</a></td>";
                                echo " <td class='hide'>";
                                echo "  <table class='trans' width='70'>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans' width='70'><font color='blue'>".$OcenePredmeta[$Indx][2]."</font></td>";
                                echo "   </tr>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans' width='70'><font color='blue'>".$OcenePredmeta[$Indx][4]."</font></td>";
                                echo "   </tr>";
                                echo "  </table>";
                                echo " </td>";
                                echo " <td class='hide'>";
                                echo "  <table class='trans' width='70'>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans' width='70'><font color='magenta'>".$OcenePredmeta[$Indx][3]."</font></td>";
                                echo "   </tr>";
                                echo "   <tr class='trans'>";
                                echo "    <td class='trans' width='70'><font color='magenta'>".$OcenePredmeta[$Indx][5]."</font></td>";
                                echo "   </tr>";
                                echo "  </table>";
                                echo " </td>";
                                echo " <td class='hide' align='center'><font color='green'>".$OcenePredmeta[$Indx][11]."</font></td>";
                                echo " <td class='hide' align='center'><font color='red'>".$OcenePredmeta[$Indx][6]."</font></td>";
                                switch (intval($OcenePredmeta[$Indx][7])){
                                    case 0: //ocenjeno
                                        echo " <td class='hide' align='center'>&nbsp;</td>";
                                        break;
                                    case 1: //neocenjeno
                                        echo " <td class='hide' align='center'>neocenjeno</td>";
                                        break;
                                    case 2: //opravičeno
                                        echo " <td class='hide' align='center'>opravičeno</td>";
                                        break;
                                }
                                if ($OcenePredmeta[$Indx][8] > 0){
                                    echo " <td class='hide' align='center'>popravni</td>";
                                }else{
                                    echo " <td class='hide' align='center'>&nbsp;</td>";
                                }
                                echo " <td class='hide'>".$OcenePredmeta[$Indx][9]."</td>";
                            }
                        }
                        echo "</table><br />";
                        echo "<br />";
                    }
                    //opisne ocene
                    if ($Razred["razred"] < 3 ){
                        $SQL = "SELECT tabopocene.*,tabopznanje.*,tabopcilji.*,tabpredmeti.*,tabpredmeti.id AS pid FROM ((tabopocene ";
                        $SQL = $SQL . "INNER JOIN tabopznanje ON tabopocene.OpOcena=tabopznanje.IdZnanje) ";
                        $SQL = $SQL . "INNER JOIN tabopcilji ON tabopznanje.IdCilji=tabopcilji.IdCilji) ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopcilji.Predmet=tabpredmeti.Id ";
                        $SQL = $SQL . "WHERE leto=".$Razred["leto"]." AND tabopcilji.Razred=".$Razred["razred"]." AND tabopocene.IdUcenec=".$ucenec." ";
                        $SQL = $SQL . " ORDER BY tabopocene.Tip,tabopcilji.Predmet,tabopznanje.IdCilji,tabopznanje.IdZnanje";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<br /><table>";
                            echo "<tr class='head'><th class='hide'>Tip</th><th class='hide'>Leto</th><th class='hide'>Predmet</th><th class='hide'>Tema</th><th class='hide'>Znanje</th></tr>";
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr class='hide'>";
                                echo "<td class='hide'>".ToTip($R["Tip"])."</td>";
                                echo "<td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                                echo "<td class='hide'>".ToPredmet($R["pid"])."</td>";
                                //echo "<td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                                echo "<td class='hide'>".$R["OpisCilja"]."</td>";
                                echo "<td class='hide'>".$R["OpisZnanja"]."</td>";
                                echo "</tr>";
                            }
                            echo "</table><br />";
                        }
                        //ocene opisnih ciljev
                        $SQL = "SELECT tabopocenen.*,tabopznanjen.*,tabopciljin.*,tabpredmeti.*,tabpredmeti.id AS pid FROM ((tabopocenen ";
                        $SQL = $SQL . "INNER JOIN tabopznanjen ON tabopocenen.OpOcena=tabopznanjen.IdZnanje) ";
                        $SQL = $SQL . "INNER JOIN tabopciljin ON tabopznanjen.IdCilji=tabopciljin.IdCilji) ";
                        $SQL = $SQL . "INNER JOIN tabpredmeti ON tabopciljin.Predmet=tabpredmeti.Id ";
                        $SQL = $SQL . "WHERE leto=".$Razred["leto"]." AND tabopciljin.Razred=".$Razred["razred"]." AND tabopocenen.IdUcenec=".$ucenec." ";
                        $SQL = $SQL . " ORDER BY tabopocenen.Tip,tabopciljin.Predmet,tabopznanjen.IdCilji,tabopznanjen.IdZnanje";
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<br /><table border='1'>";
                            echo "<tr class='head'><th class='hide'>Tip</th><th class='hide'>Leto</th><th class='hide'>Predmet</th><th class='hide'>Tema</th><th class='hide'>Znanje</th><th class='hide'>Doseganje<br />cilja</th></tr>";
                            while ($R = mysqli_fetch_array($result)){
                                echo "<tr class='hide'>";
                                echo "<td class='hide'>".ToTip($R["Tip"])."</td>";
                                echo "<td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                                //echo "<td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td>";
                                echo "<td class='hide'>".ToPredmet($R["pid"])."</td>";
                                echo "<td class='hide'>".$R["OpisCilja"]."</td>";
                                echo "<td class='hide'>".$R["OpisZnanja"]."</td>";
                                echo "<td class='hide'>".ToOpisnaOcena($R["Ocena"])."</td>";
                                echo "</tr>";
                            }
                            echo "</table><br />";
                        }
                        
                        //ročno vpisano spričevalo
                        $SQL = "SELECT leto,slo,mat,spo,lvz,gvz,svz,nar,dru,tit,gos,rez FROM tabopocucenec WHERE leto=".$VLeto." AND ucenec=".$ucenec;
                        $result = mysqli_query($link,$SQL);
                        if (mysqli_num_rows($result) > 0){
                            echo "<br /><table border='1'>";
                            echo "<tr class='head'><th class='hide'>Predmet</th><th class='hide'>Leto</th><th class='hide'>Ocena</th></tr>";
                            while ($R = mysqli_fetch_array($result)){
                                if (strlen($R["slo"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>slovenščina</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["slo"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["mat"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>matematika</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["mat"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["spo"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>spoznavanje<br />okolja</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["spo"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["lvz"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>likovna<br />umetnost</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["lvz"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["gvz"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>glasbena<br />umetnost</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["gvz"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["svz"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>šport</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["svz"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["nar"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>naravoslovje</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["nar"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["dru"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>družboslovje</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["dru"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["tit"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>tehnika in<br />tehnologija</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["tit"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["gos"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>gospodinjstvo</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["gos"]."</td>";
                                    echo "</tr>";
                                }
                                if (strlen($R["rez"]) > 0){
                                    echo "<tr class='hide'>";
                                    echo "<td class='hide'>angleščina</td>";
                                    echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                                    echo "<td class='hide'>".$R["rez"]."</td>";
                                    echo "</tr>";
                                }
                            }
                            echo "</table><br />";
                        }
                    }
                }
            }
            
            //izostanki in opombe v eDnevniku
            if ($eDnevnik){
                $SQL = "SELECT tabopombeuc.datum,tabopombeuc.ura,tabopombeuc.opomba,tabpredmeti.oznaka,tabucitelji.priimek,tabucitelji.ime FROM (tabopombeuc ";
                $SQL .= "INNER JOIN tabpredmeti ON tabopombeuc.predmet=tabpredmeti.id) ";
                $SQL .= "INNER JOIN tabucitelji ON tabopombeuc.ucitelj=tabucitelji.iducitelj ";
                $SQL .= "WHERE tabopombeuc.iducenec=".$ucenec." AND tabopombeuc.leto=".$VLeto;
                $SQL .= " ORDER BY tabopombeuc.datum DESC";
                $result = mysqli_query($link,$SQL);
                if (mysqli_num_rows($result) > 0){
                    echo "<b>Opombe v e-dnevniku</b>:<br />";
                    echo "<textarea cols='80' rows='6'>";
                    $txt="";
                    while ($R = mysqli_fetch_array($result)){
                        $datum=new DateTime($R["datum"]);
                        $txt .= $datum->format('d.m.Y')." ".$R["ura"].". ura, ".$R["oznaka"]." (".$R["ime"]." ".$R["priimek"]."): ".$R["opomba"]."\n";
                    }
                    echo $txt;
                    echo "</textarea><br />";
                    echo "<br />";
                }
                $SQL = "SELECT tabodsotnostuc.datum,tabodsotnostuc.ura,tabodsotnostuc.opomba,tabpredmeti.oznaka,tabodsotnostuc.ucitelj FROM (tabodsotnostuc ";
                $SQL .= "INNER JOIN tabpredmeti ON tabodsotnostuc.predmet=tabpredmeti.id) ";
                $SQL .= "WHERE tabodsotnostuc.iducenec=".$ucenec." AND tabodsotnostuc.leto=".$VLeto;
                $SQL .= " ORDER BY tabodsotnostuc.datum DESC";
                $result = mysqli_query($link,$SQL);

                if (mysqli_num_rows($result) > 0){
                    echo "<b>Izostanki v e-dnevniku</b>:<br />";
                    echo "<textarea cols='80' rows='6'>";
                    $txt="";
                    
                    while ($R = mysqli_fetch_array($result)){
                        $datum=new DateTime($R["datum"]);
                        $txt .= $datum->format('d.m.Y')." ".$R["ura"].". ura, ".$R["oznaka"];
                        $txt .= " (";
                        $SQL = "SELECT priimek,ime FROM tabucitelji WHERE iducitelj IN (".$R["ucitelj"].")";
                        $result1 = mysqli_query($link,$SQL);
                        $ucitelji="";
                        while ($R1 = mysqli_fetch_array($result1)){
                            if (strlen($ucitelji) > 0){
                                $ucitelji .= ", ".$R1["ime"]." ".$R1["priimek"];
                            }else{
                                $ucitelji .= $R1["ime"]." ".$R1["priimek"];
                            }
                        }
                        $txt .= $ucitelji;
                        $txt .= ")";
                        if (isset($R["opomba"])){
                            $txt .= ": ".$R["opomba"];
                        }
                        $txt .= "\n";
                    }
                    echo $txt;
                    echo "</textarea><br />";
                    echo "<br />";
                }
            }
            
            //izostanki po mesecih
            $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto." AND mesec > 8 ORDER BY leto,mesec";
            $result = mysqli_query($link,$SQL);
            
            for ($Indx=0;$Indx <= 10;$Indx++){
                $Izostanki[$Indx][0]=0;
                $Izostanki[$Indx][1]=0;
            }

            echo "<b>Odsotnost</b>: ";
            echo "<br /><table>";
            echo "<tr class='head'>";
            echo "<th class='hide'>Šol. leto</th>";
            echo "<th class='hide'>Mesec</th>";
            echo "<th class='hide'>Opravičeno</th>";
            echo "<th class='hide'>Neopravičeno</th>";
            echo "</tr>";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                echo "<td class='hide' align=center>".$R["Mesec"]."</td>";
                echo "<td class='hide' align=center>".$R["Opraviceno"]."</td>";
                echo "<td class='hide' align=center>".$R["Neopraviceno"]."</td></tr>";
                if ($R["Mesec"] > 0 ){
                    $Izostanki[0][0]=$Izostanki[0][0]+$R["Opraviceno"];
                    $Izostanki[0][1]=$Izostanki[0][1]+$R["Neopraviceno"];
                }
                $Indx = $Indx+1;
            } 
            $SQL = "SELECT * FROM tabprisotnost WHERE IdUcenec=" .$ucenec . " AND leto=".$VLeto." AND mesec < 8 ORDER BY leto,mesec";
            $result = mysqli_query($link,$SQL);
            while ($R = mysqli_fetch_array($result)){
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                echo "<td class='hide' align=center>".$R["Mesec"]."</td>";
                echo "<td class='hide' align=center>".$R["Opraviceno"]."</td>";
                echo "<td class='hide' align=center>".$R["Neopraviceno"]."</td></tr>";
                if ($R["Mesec"] > 0 ){
                    $Izostanki[0][0]=$Izostanki[0][0]+$R["Opraviceno"];
                    $Izostanki[0][1]=$Izostanki[0][1]+$R["Neopraviceno"];
                }
                $Indx = $Indx+1;
            } 
            
            echo "<tr class='hide'><td class='hide'>Skupaj</td><td class='hide'>&nbsp;</td><td class='hide' align=center>".$Izostanki[0][0]."</td><td class='hide' align=center>".$Izostanki[0][1]."</td></tr>";
            echo "</table><br />";

            //Izpis predmetnih podatkov

            //Predmetnik
            $Razred=$oUcenec->getRazred($VLeto);
            if (count($Razred) > 0){
                $SQL = "SELECT tabucenje.*, tabucitelji.priimek, tabucitelji.ime, tabpredmeti.oznaka, tabpredmeti.opis FROM (tabpredmeti INNER JOIN tabucenje ON tabpredmeti.Id = tabucenje.Predmet)  INNER JOIN tabucitelji ON tabucitelji.iducitelj = tabucenje.iducitelj WHERE tabucenje.idrazred=" . $Razred["idrazred"] ."  ORDER BY tabucenje.predmet";
                $result = mysqli_query($link,$SQL);

                echo "<b>Predmetnik</b>";
                echo "<br /><table>";
                echo "<tr class='head'>";
                echo "<th class='hide'>Leto</th>";
                echo "<th class='hide'>Razred</th>";
                echo "<th class='hide'>Predmet</th>";
                echo "<th class='hide'>Ure</th>";
                echo "<th class='hide'>Posebnosti</th>";
                echo "<th class='hide'>Skupina</th>";
                echo "<th class='hide'>Učitelj</th>";
                echo "</tr>";
                $Indx=0;
                while ($R = mysqli_fetch_array($result)){
                    $VZdruzeno = "";
                    if ($R["Zdruzeno"] == 1 ){
                        $VZdruzeno = "Združeni/skupine";
                    }    
                    if ($R["Zdruzeno"] == 2 ){
                        $VZdruzeno = "Izbirni/skupine";
                    }    
                    echo "<tr class='hide'>";
                    echo "<td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td>";
                    echo "<td class='hide' align='center'>".$Razred["razred"].". ". $Razred["paralelka"]."</td>";
                    echo "<td class='hide'>".$R["oznaka"]." - ".$R["opis"]."</td>";
                    echo "<td class='hide'>".$R["Planirano"]."</td>";
                    echo "<td class='hide'>". $VZdruzeno ."</td>";
                    echo "<td class='hide' align='center'>".$R["Realizirano"]."</td>";
                    echo "<td class='hide'>".$R["priimek"]." " .$R["ime"]."</td>";
                    echo "</tr>";
                    $Indx = $Indx+1;
                } 
                echo "</table>";
            }
            //Urnik - zacetek

            //'izpis urnika po razredih - 2
            $Obremenitev[1]=0;
            for ($Indx=0;$Indx <= 5;$Indx++){
                for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                    $UrnikRazred[1][$Indx][$Indx0]="";
                }
            }
            $danurnik=intval($Danes->format('Ymd'));
            if (isset($Razred["razred"])){    
                $SQL = "SELECT taburnik.*,tabucitelji.*,tabpredmeti.*,tabpredmeti.oznaka AS poznaka,tabprostor.* FROM ((taburnik " ;
                $SQL = $SQL . "INNER JOIN tabucitelji ON taburnik.ucitelj=tabucitelji.idUcitelj) " ;
                $SQL = $SQL . "INNER JOIN tabpredmeti ON taburnik.Predmet=tabpredmeti.Id) " ;
                $SQL = $SQL . "INNER JOIN tabprostor ON taburnik.Prostor=tabprostor.IdProstor " ;
                $SQL = $SQL . "WHERE taburnik.idRazred=".$Razred["idrazred"]." AND od <= ".$danurnik." AND do >= ".$danurnik." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.DanVTednu,taburnik.Ura";
                //$SQL = $SQL . "WHERE taburnik.idRazred=".$Razred["idrazred"]." AND od <= ".$danurnik." ORDER BY taburnik.Razred,taburnik.Paralelka,taburnik.DanVTednu,taburnik.Ura";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    switch ($R["Nivo"]){
                        case 1:
                        case 2:
                        case 3:      //v primeru skupin izpiše še skupino
                            $UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]=$UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"].$R["Nivo"]."</font></td><td class='hide'><font color='red'>".$R["Stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["Priimek"],0,3,$encoding).mb_substr($R["Ime"],0,1,$encoding)."</font></td></tr>";
                            break;
                        default:
                            $UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]=$UrnikRazred[$Indx][$R["DanVTednu"]][$R["Ura"]]."<tr class='hide'><td class='hide'><font color='darkblue'>".$R["poznaka"]."</font></td><td class='hide'><font color='red'>".$R["Stevilka"]."</font></td><td class='hide'><font color='magenta'>".mb_substr($R["Priimek"],0,3,$encoding).mb_substr($R["Ime"],0,1,$encoding)."</font></td></tr>";
                    }
                }

                //prešteje ure v urniku
                $Indx2=1;
                for ($Indx=0;$Indx <= 5;$Indx++){
                    for ($Indx0=0;$Indx0 <= 12;$Indx0++){
                        if (strlen($UrnikRazred[$Indx2][$Indx][$Indx0]) > 0){
                            $Obremenitev[$Indx2]=$Obremenitev[$Indx2]+1;
                        }
                    }
                }

                //'echo "Obremenitev: ".Obremenitev(1)."<br />"

                $Indx=1;
                if ($Obremenitev[$Indx] > 0 ){
                    echo "<br /><h2>Urnik (".$VLeto."/".($VLeto+1)."):</h2>";
                    echo "<table border='1' cellspacing='0' bgcolor='lightyellow'>";
                    echo "<tr bgcolor='cyan'><td><b>".$Razred["razred"].". ".$Razred["paralelka"]."</b></td>";
                    echo "<td>".$Obremenitev[$Indx]."</td>";
                    for ($Indx2=1;$Indx2 <= 5;$Indx2++){
                        echo "<td align='center'><b>".Int2Dan($Indx2)."</b></td>";
                    }
                    echo "</tr>";
                    $ColorChange=true;
                    for ($Indx2=0;$Indx2 <= 12;$Indx2++){
                        $ColorChange=!$ColorChange;
                        if ($ColorChange ){
                            echo "<tr bgcolor='lightyellow'>";
                        }else{
                            echo "<tr bgcolor='#FFFFCC'>";
                        }
                        echo "<td></td><td>".$Indx2."</td>";
                        for ($Indx1=1;$Indx1 <= 5;$Indx1++){
                            if (strlen($UrnikRazred[$Indx][$Indx1][$Indx2]) > 0){
                                echo "<td valign='top'>";
                                echo "<table class='hide'>";
                                echo $UrnikRazred[$Indx][$Indx1][$Indx2];
                                echo "</table>";
                                echo "</td>";
                            }else{
                                echo "<td>&nbsp;</td>";
                            }
                        }
                        echo "</tr>";
                    }
                    echo "</table>";
                }
            }
            //Urnik - konec

            //izpis izbirnih predmetov
            //inicializacija
            $IzbraniPredmet[0]=0;
            $IzbraniPredmet[1]=0;
            $IzbraniPredmet[2]=0;
            $IzbraniPredmet[3]=0;
            $IzbraniPredmet[4]=0;
            
            $SQL = "SELECT tabizbirni.*,tabizbirni.id AS iid,tabucenci.*,tabpredmeti.*,tabpredmeti.id AS pid FROM (tabucenci INNER JOIN tabizbirni ON tabizbirni.Ucenec=tabucenci.IdUcenec) INNER JOIN tabpredmeti ON tabpredmeti.Id=tabizbirni.Izbirni WHERE tabizbirni.Ucenec=" .$ucenec . " AND leto=".$VLeto;
            $result = mysqli_query($link,$SQL);
            $IndxIzb=0;
            echo "<br /><b>Izbirni predmeti</b>: ";
            echo "<br /><table>";
            echo "<tr class='head'>";
            echo "<th class='hide'>Leto</th>";
            echo "<th class='hide'>Izbirni predmet</th>";
            echo "</tr>";
            while ($R = mysqli_fetch_array($result)){
                echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Oznaka"]." - ".$R["Opis"]."</td></tr>";        
                if ($R["Leto"]== $VLeto) {
                    $IzbraniPredmet[$IndxIzb]=$R["pid"];
                    $IndxIzb=$IndxIzb+1;
                }
            } 
            echo "</table>";

            //izpis nivojev in skupin
            echo "<a name='nivoji'></a><br />";
            echo "<b>Nivojski predmeti/skupine</b>: ";
            $SQL = "SELECT tabnivoji.*,tabnivoji.leto AS nleto,tabucenci.*,tabrazred.*,tabrazred.leto AS rleto FROM ";
            $SQL = $SQL . "((tabnivoji INNER JOIN tabucenci ON tabnivoji.Ucenec=tabucenci.IdUcenec) ";
            $SQL = $SQL . "INNER JOIN tabrazred ON tabrazred.IdUcenec=tabnivoji.Ucenec) ";
            $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." AND tabnivoji.leto = tabrazred.leto AND tabnivoji.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY tabnivoji.leto,nivoji";
            $result = mysqli_query($link,$SQL);

            echo "<table>";
            echo "<tr class='head'>";
            echo "<th class='hide'>N</th>";
            echo "<th class='hide'>Leto</th>";
            echo "<th class='hide'>Ucenec</th>";
            echo "<th class='hide'>Predmet 1</th>";
            echo "<th class='hide'>Predmet 2</th>";
            echo "<th class='hide'>Predmet 3</th>";
            echo "</tr>";
            echo "<tr class='hide'>";
            $UcenecIzbirni="";
            $Indx=1;
            while ($R = mysqli_fetch_array($result)){
                if ($UcenecIzbirni == $R["nleto"]){
                    echo "<td class='hide' align='center'>".ToNivojski($R["Nivoji"])."</td>";
                }else{
                    if ($UcenecIzbirni != "" ){
                        echo "</tr>";
                    }
                    echo "<tr class='hide'><td class='hide'>".$Indx."</td>";
                    $Indx=$Indx+1;
                    echo "<td class='hide'>".$R["rleto"]."/".($R["rleto"]+1)."</td><td class='hide'>".$R["Priimek"]." ".$R["Ime"].", ".$R["Razred"].". ".$R["Paralelka"]."</td><td class='hide' align='center'>".ToNivojski($R["Nivoji"])."</td>";
                    $UcenecIzbirni = $R["nleto"];
                }
            }

            echo "</table>";

            //vzgojni ukrepi
            $SQL = "SELECT tabvzgukrepi.*, tabopomini.Opis FROM tabopomini INNER JOIN tabvzgukrepi ON tabopomini.IdUkrep = tabvzgukrepi.IdUkrep WHERE tabvzgukrepi.IdUcenec=" .$ucenec . " AND tabvzgukrepi.leto=".$VLeto." ORDER BY tabvzgukrepi.leto DESC";
            $result = mysqli_query($link,$SQL);

            echo "<br /><b>Vzgojni ukrepi</b>: ";
            $_SESSION["iducenec"]=$ucenec;
            $_SESSION["leto"]=$VLeto;
            echo "<br /><table>";
            echo "<tr class='head'><th class='hide'>Leto</th><th class='hide'>Ukrep</th><th class='hide'>Datum izreka</th><th class='hide'>Datum</th></tr>";
            $Indx=0;
            while ($R = mysqli_fetch_array($result)){
                if ($VLevel > 1 ){
                    echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Opis"]."</td><td class='hide'>".$R["DatIzreka"]."</td><td class='hide'>".$R["Datum"]."</td></tr>";
                }else{
                    echo "<tr class='hide'><td class='hide'>".$R["Leto"]."/".($R["Leto"]+1)."</td><td class='hide'>".$R["Opis"]."</td><td class='hide'>".$R["DatIzreka"]."</td><td class='hide'>".$R["Datum"]."</td></tr>";
                }
                $Indx = $Indx+1;
            } 
            echo "</table>";

            //'učenčeve aktivnosti (interesne dejavnosti, športna tekmovanja)
            $SQL = "SELECT tabdrtekmclan.*, tabucenci.* FROM tabdrtekmclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabdrtekmclan.idUcenec=tabucenci.idUcenec ";
            $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." AND tabdrtekmclan.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY tabdrtekmclan.leto DESC";
            $result = mysqli_query($link,$SQL);

            echo "<br /><b>Tekmovanja iz znanja</b>:<br />";
            echo "<table>";
            echo "<tr class='head'><th class='hide'>šolsko leto</th><th class='hide'>tekmovanje</th><th class='hide'>datum</th><th class='hide'>stopnja</th><th class='hide'>priznanje</th><th class='hide'>mentor</th></tr>";
            while ($R = mysqli_fetch_array($result)){    
                echo "<tr class='hide'>";
                echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                echo "<td class='hide'>".$R["tekmovanje"]."</td>";
                echo "<td class='hide'>".$R["datum"]."</td>";
                echo "<td class='hide'>".$R["stopnja"]."</td>";
                echo "<td class='hide'>".$R["priznanje"]."</td>";
                echo "<td class='hide'>".$R["mentor1"]."</td>";
                echo "</tr>";
            }
            echo "</table>";

            $SQL = "SELECT tabsstclan.*, tabucenci.* FROM tabsstclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabsstclan.idUcenec=tabucenci.idUcenec ";
            $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." AND tabsstclan.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY tabsstclan.leto DESC";
            $result = mysqli_query($link,$SQL);

            echo "<br /><b>Šolska športna tekmovanja</b>:<br />";
            echo "<table>";
            echo "<tr class='head'><th class='hide'>šolsko leto</th><th class='hide'>tekmovanje</th><th class='hide'>datum</th><th class='hide'>stopnja</th><th class='hide'>priznanje</th><th class='hide'>mentor</th></tr>";
            while ($R = mysqli_fetch_array($result)){    
                echo "<tr class='hide'>";
                echo "<td class='hide'>".$R["leto"]."/".($R["leto"]+1)."</td>";
                echo "<td class='hide'>".$R["tekmovanje"]."</td>";
                echo "<td class='hide'>".$R["datum"]."</td>";
                echo "<td class='hide'>".$R["stopnja"]."</td>";
                echo "<td class='hide'>".$R["priznanje"]."</td>";
                echo "<td class='hide'>".$R["mentor1"]."</td>";
                echo "</tr>";
            }
            echo "</table>";

            //'interesne dejavnosti
            $SQL = "SELECT tabkrozekclan.*,tabkrozekclan.leto AS cleto, tabkrozki.*,tabkrozki.krozek AS kkrozek, tabucenci.* FROM (tabkrozekclan ";
            $SQL = $SQL . "INNER JOIN tabucenci ON tabkrozekclan.Ucenec=tabucenci.idUcenec) ";
            $SQL = $SQL . "INNER JOIN tabkrozki ON tabkrozekclan.krozek=tabkrozki.id ";
            $SQL = $SQL . "WHERE tabucenci.idUcenec=".$ucenec." AND tabkrozekclan.leto=".$VLeto;
            $SQL = $SQL . " ORDER BY tabkrozki.leto DESC";
            $result = mysqli_query($link,$SQL);

            echo "<br /><b>Interesne dejavnosti</b>:<br />";
            echo "<table>";
            echo "<tr class='head'><th class='hide'>šolsko leto</th><th class='hide'>dejavnost</th><th class='hide'>mentor</th></tr>";
            while ($R = mysqli_fetch_array($result)){    
                echo "<tr class='hide'>";
                echo "<td class='hide'>".$R["cleto"]."/".($R["cleto"]+1)."</td>";
                echo "<td class='hide'>".$R["kkrozek"]."</td>";
                echo "<td class='hide'>".$R["mentor"]."</td>";
                echo "</tr>";
            }
            echo "</table><br />";
                
            //'odsotnosti
            /* 
            if ($eDnevnik==1 ){
                $SQL = "SELECT * FROM tabpraznik WHERE leto IN (".$VLeto.",".($VLeto+1).") ORDER BY datum";
                $result = mysqli_query($link,$SQL);
                $Indx=1;
                while ($R = mysqli_fetch_array($result)){
                    $Praznik[$Indx][0]=new DateTime(isDate($R["datum"]));
                    $Praznik[$Indx][1]=$R["kat"];
                    $Indx=$Indx+1;
                }
                $StPraznikov=$Indx-1;
                
                if (($VLeto+1) % 4 == 0 ) {
                    $MesecDni=array(0,31,29,31,30,31,30,31,31,30,31,30,31);
                }else{
                    $MesecDni=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                }

                echo "<h3>Koledar izostankov in opomb</h3>";
                echo "<table border='1' cellspacing='0'>";
                echo "<tr><th></th>";
                for ($Indx=1;$Indx <= 31;$Indx++){
                    echo "<th width='25'>".$Indx."</th>";
                }
                echo "</tr>";
                for ($Indx=9;$Indx <= 12;$Indx++){
                    $VLetoPregled=$VLeto;
                    echo "<tr><td align='left'><b>".MonthName($Indx)."</b></td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')){
                            case 0:
                            case 6:
                            case 7: //'vikend
                                $PreveriPraznik=CheckPraznik($Datum);
                                switch ($PreveriPraznik){
                                    case 3: //'delovna sobota
                                        echo "<td align='right'>";
                                        break;
                                    default:
                                        echo "<td bgcolor='lightsalmon' align='right'>";
                                }
                                break;
                            default: // 'delovnik
                                $PreveriPraznik=CheckPraznik($Datum);
                                switch ($PreveriPraznik){
                                    case 4: // 'dela prost dan
                                        echo "<td bgcolor='khaki' align='right'>";
                                        break;
                                    case 0: // 'delovni dan
                                        echo "<td align='right'>";
                                        break;
                                    case 2: //počitnice
                                        echo "<td bgcolor='lightblue' align='right'>";
                                        break;
                                    case 1: // 'praznik
                                        echo "<td bgcolor='lightgreen' align='right'>";
                                }
                        }
                        $SQL = "SELECT * FROM tabodsotnostuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<a href='dnevnik.php?idd=200&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Iz</a>";
                        }

                        $SQL = "SELECT * FROM tabopombeuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "&nbsp;<a href='dnevnik.php?idd=300&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Op</a>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                for ($Indx=1;$Indx <= 6;$Indx++){
                    $VLetoPregled=$VLeto+1;
                    echo "<tr><td align='left'><b>".MonthName($Indx)."</b></td>";
                    for ($Indx1=1;$Indx1 <= $MesecDni[$Indx];$Indx1++){
                        $Datum=new DateTime($VLetoPregled."-".$Indx."-".$Indx1);
                        switch ($Datum->format('w')){
                            case 0:
                            case 6:
                            case 7: //'vikend
                                $PreveriPraznik=CheckPraznik($Datum);
                                switch ($PreveriPraznik){
                                    case 3: //'delovna sobota
                                        echo "<td align='right'>";
                                        break;
                                    default:
                                        echo "<td bgcolor='lightsalmon' align='right'>";
                                }
                                break;
                            default: // 'delovnik
                                $PreveriPraznik=CheckPraznik($Datum);
                                switch ($PreveriPraznik){
                                    case 4: // 'dela prost dan
                                        echo "<td bgcolor='khaki' align='right'>";
                                        break;
                                    case 0: // 'delovni dan
                                        echo "<td align='right'>";
                                        break;
                                    case 2: //počitnice
                                        echo "<td bgcolor='lightblue' align='right'>";
                                        break;
                                    case 1: // 'praznik
                                        echo "<td bgcolor='lightgreen' align='right'>";
                                }
                        }
                        $SQL = "SELECT * FROM tabodsotnostuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "<a href='dnevnik.php?idd=200&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Iz</a>";
                        }

                        $SQL = "SELECT * FROM tabopombeuc WHERE idUcenec=".$ucenec." AND year(datum)=".$Datum->format('Y')." AND month(datum)=".$Datum->format('n')." AND day(datum)=".$Datum->format('j');
                        $result = mysqli_query($link,$SQL);
                        if ($R = mysqli_fetch_array($result)){
                            echo "&nbsp;<a href='dnevnik.php?idd=300&id=3a&ucenec=".$ucenec."&dan=".$Datum->format('j')."&mesec=".$Datum->format('n')."&letoods=".$Datum->format('Y')."'>Op</a>";
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
                echo "<a href='dnevnik.php?idd=200&ucenec=".$ucenec."'>Vpis izostankov</a> <a href='dnevnik.php?idd=300&ucenec=".$ucenec."'>Vpis opomb</a><br />";
            }
            */
            
            //sporočila
            echo "<form name='sporocilo' method='post' action='vpogled.php'>";
            echo "<div class='ozadje'>";
            if ($Razred["spolr"]=="M"){
                echo "<label for='vsebina'><b>Sporočilo razredniku</b>:</label>";
            }else{
                echo "<label for='vsebina'><b>Sporočilo razredničarki</b>:</label>";
            }
            echo "<textarea name='vsebina' cols='70' rows='8'></textarea><br />";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='ssubmit' type='submit' value='Pošlji'>";
            echo "</div>";
            echo "</form>";
            
            //zgodovina sporočil
            $SQL = "SELECT datum,posiljatelj,vsebina FROM tabsporocila WHERE leto=".$VLeto." AND iducenec=".$ucenec." ORDER BY datum DESC";
            $result = mysqli_query($link,$SQL);
            $txt = "";
            while ($R = mysqli_fetch_array($result)){
                $datum=new DateTime($R["datum"]);
                if ($R["posiljatelj"] == 1){
                    $txt .= $datum->format('d.m.Y H:m:s').", razrednik -> starši:\n";
                }else{
                    $txt .= $datum->format('d.m.Y H:m:s').", starši -> razrednik:\n";
                }
                $txt .= $R["vsebina"]."\n\n";
            }
            if (strlen($txt) > 0){        
                echo "<b>Zgodovina sporočil</b>:<br />";
                echo "<textarea cols='80' rows='6'>$txt</textarea><br />";
            }
            
            
            //sprememba gesla
            echo "<form name='spremembag' method='post' action='vpogled.php'>";
            echo "<input name='geslo' type='hidden' value='".$VGeslo."'>";
            echo "<input name='uporabnik' type='hidden' value='".$VUporabnik."'>";
            echo "<input name='solskoleto' type='hidden' value='".$VLeto."'>";
            echo "<input name='sgsubmit' type='submit' value='Sprememba gesla'>";
            echo "</form>";
        }
    }    
}
?>

</body>
</html>
