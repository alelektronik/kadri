<?php
//<!-- #include VIRTUAL = '/include/adovbs.inc' -->
//<!-- #INCLUDE FILE="fileOps.inc" -->
require("const.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="pragma" content="no-cache" > 
<link rel="stylesheet" type="text/css" href="osmj.css"> 
<title>Datumi praznikov in počitnic
</title>
</head>
<body>

<?php
$VLeto=PreberiLeto("leto");
if (isset($_POST["letopregled"])){
    $VLetoPregled=$_POST["letopregled"];
}else{
    if (isset($_GET["letopregled"])){
        $VLetoPregled=$_GET["letopregled"];
    }else{
        if (isset($_SESSION["letopregled"])){
            $VLetoPregled=$_SESSION["letopregled"];
        }else{
            $VLetoPregled=$ActualYear;
        }
    }
}
$VUporabnik = $_SESSION["Uporabnik"];
$VGeslo = $_SESSION["Geslo"];
$VLevel = $_SESSION["Level"];

$RazsirjenVnos=true;

$SQL = "SELECT * FROM tabucitelji WHERE Uporabnik='". $VUporabnik . "' AND Geslo='" . $VGeslo . "'";
$result = mysqli_query($link,$SQL);
if ($R = mysqli_fetch_array($result)){
    $UciteljComp=$R["IdUcitelj"];
    $VUporabnikId=$UciteljComp;
//    echo "Pozdravljeni " .  $R["Ime"]  . " " . $R["Priimek"] . "<br>";
}else{
    echo "Nimate potrebnih pooblastil za ogled strani!";
    header("Location: nepooblascen.htm");
}

if (!CheckDostop("Prazniki",$VUporabnik) ) {
    header("Location: nepooblascen.htm");
}
if (isset($_POST["id"])){
    $Vid=$_POST["id"];
}else{
    if (isset($_GET["id"])){
        $Vid=$_GET["id"];
    }else{
        $Vid="";
    }
}
if (isset($_POST["zapis"])){
    $Vzapis=$_POST["zapis"];
}else{
    if (isset($_GET["zapis"])){
        $Vzapis=$_GET["zapis"];
    }else{
        $Vzapis="";
    }
}

switch ($Vid){
	case "2":
	case "3":
		break;
	default:
		$n=$VLevel;
		include('menu_func.inc');
		include ('menu.inc');
}
switch ($Vid){
	case "1": // 'vnos praznikov in počitnic

		$SQL = "SELECT * FROM TabPraznik WHERE leto >= ".($Danes->format('Y')-1)." ORDER BY datum DESC";
		$result = mysqli_query($link,$SQL);
		
		echo "<h2>Vnos praznikov in počitnic</h2>";
        echo "<a href='VnosPraznikov.php?id=4'>Uvoz praznikov in počitnic</a><br />";
		echo "<form name='Prazniki' method='post' action='VnosPraznikov.php'>";
		echo "<table border='1'>";
		echo "<tr><th>Št.</th><th>Datum</th><th>Opis</th><th>Tip</th><th>Briši</th></tr>";
		
		echo "<tr>";
		echo "<td>&nbsp;</td>";
		echo "<td>";
		echo "Dan: <select name='dan'>";
		for ($indx=1;$indx <= 31;$indx++){
			echo "<option>".$indx."</option>";
		}
		echo "</select>";
		echo "Mesec: <select name='mesec'>";
        for ($indx=1;$indx <= 12;$indx++){
			echo "<option>".$indx."</option>";
		}
		echo "</select>";
		echo "Leto: <select name='leto'>";
        $istart=$Danes->format('Y')-1;
        $istop=$Danes->format('Y')+3;
		for ($indx=$istart;$indx <= $istop;$indx++){
			if ($indx==$Danes->format('Y')){
				echo "<option selected>".$indx."</option>";
			}else{
				echo "<option>".$indx."</option>";
			}
		}
		echo "</select>";
		echo "</td>";
		echo "<td><input name='opis' type='text' size='30'></td>";
		echo "<td><select name='tip'>";
		echo "<option value='0'>praznik</option>";
		echo "<option value='1'>počitnice</option>";
		echo "<option value='2'>delovni dan</option>";
		echo "<option value='3'>dela prost dan</option>";
		echo "<option value='4'>počitnice-ni obveza</option>";
		echo "</select></td>";
		echo "<td><input name='submit' type='submit' value='Pošlji'></td>";
		echo "</tr>";

		$indx=1;
        while ($R = mysqli_fetch_array($result)){
			echo "<tr>";
			echo "<td>".$indx."</td>";
			echo "<td>".$R["dan"].".".$R["mesec"].".".$R["leto"]."</td>";
			echo "<td>".$R["opis"]."</td>";
			switch ($R["kat"]){
				case 0:
					echo "<td>praznik</td>";
                    break;
				case 1:
					echo "<td>počitnice</td>";
                    break;
				case 3:
					echo "<td>dela prost dan</td>";
                    break;
				case 4:
					echo "<td>počitnice-ni obveza</td>";
                    break;
				default:
					echo "<td>delovni dan</td>";
			}
			echo "<td><a href='VnosPraznikov.php?id=3&zapis=".$R["id"]."'>Briši</a></td>";
			echo "</tr>";
			$indx=$indx+1;
		}
		echo "</table>";
		echo "<input name='StDelavcev' type='hidden' value='".($indx-1)."'>";
		echo "<input name='id' type='hidden' value='2'>";
		echo "</form>";
        break;
	case "2": // 'vpis zapisa
        $Datum=new DateTime($_POST["leto"]."-".$_POST["mesec"]."-".$_POST["dan"]);
		if (isset($Datum)){
			$SQL = "SELECT * FROM TabPraznik WHERE dan=".$Datum->format("j")." AND mesec=".$Datum->format('n')." AND leto=".$Datum->format('Y');
			$result = mysqli_query($link,$SQL);
			
            if ($R = mysqli_fetch_array($result)){
				$SQL = "UPDATE TabPraznik SET opis='".$_POST["opis"]."', kat=".$_POST["tip"]." WHERE id=".$R["id"];
			}else{
				$SQL = "INSERT INTO TabPraznik (datum,dan,mesec,leto,opis,kat,trajanje) VALUES ('".$Datum->format('Y-m-d')."',".$Datum->format('j').",".$Datum->format('n').",".$Datum->format('Y').",'".$_POST["opis"]."',".$_POST["tip"].",0)";
			}
			$result = mysqli_query($link,$SQL);
		}
		
		header ("Location: VnosPraznikov.php?id=1");
        break;
	case "3": //brisanje
		$SQL = "DELETE FROM TabPraznik WHERE id=".$_GET["zapis"];
		$result = mysqli_query($link,$SQL);
		
        header ("Location: VnosPraznikov.php?id=1");
        break;
    case "4": //uvoz praznikov - obrazec za datoteko
        if (!CheckDostop("ImpExUc",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        echo "<form method='post' ENCTYPE='multipart/form-data' action='VnosPraznikov.php'>";
        echo "<input name='id' type='hidden' value='5'>";
        echo "<input name='servaddr' type='hidden' value='".$_SERVER["SERVER_ADDR"]."'>";
        echo "<h2>Uvoz podatkov o praznikih (csv)</h2>";
        echo "<table border=0><tr>";
        echo "<td>Datoteka:</td><td><input name='file' type='file' size='40'></td></tr>";
        echo "<input name='Povezava' type='hidden' value='/'>";
        echo "</table>";
        echo "<input name='submit' type='submit' value='Pošlji'>";
        echo "</form>";
        break;
    case "5":
        if (!CheckDostop("ImpExUc",$VUporabnik) ) {
            header("Location: nepooblascen.htm");
        }
        $uploaded=false;
        $allowedExts = array("txt", "csv","xml");
        $Preneseno=$_FILES["file"];
        $extension = explode(".", $Preneseno["name"]);
        $extension = end($extension);
        $extension = strtolower($extension);
        if (($_FILES["file"]["size"] < 500000) && in_array($extension, $allowedExts)){
                if ($_FILES["file"]["error"] > 0){
                    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
                }else{
                    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
                    echo "Type: " . $_FILES["file"]["type"] . "<br />";
                    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br />";
                    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
             
                    if (file_exists("dato/" . $_FILES["file"]["name"])){
                        echo $_FILES["file"]["name"] . " already exists. ";
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }else{
                        move_uploaded_file($_FILES["file"]["tmp_name"],"dato/" . $_FILES["file"]["name"]);
                        echo "Stored in: " . "dato/" . $_FILES["file"]["name"];
                        $uploaded=true;
                    }
               }
        }else{
            echo "Invalid file";
        }

        if ($uploaded){
            $myFile = "dato/".$_FILES["file"]["name"];
            $fh = fopen($myFile,'r') or die("Ne morem odpreti datoteke!");
            $VServer=$_POST["servaddr"];
            $indx=0;
            while(!feof($fh)){
               //echo fgets($file). "<br />";
               $Vrstica[$indx]=fgets($fh);
               $indx=$indx+1;
            }
            $StVrstic=$indx-1;
            fclose($fh);
            
            for ($i=0;$i < $StVrstic;$i++){
                $s=explode(";",$Vrstica[$i]);
                if ($s[0]!="id"){
                    $SQL = "SELECT id FROM tabpraznik WHERE datum='".$s[1]."'";
                    $result = mysqli_query($link,$SQL);
                    if ($R = mysqli_fetch_array($result)){
                        $SQL = "UPDATE tabpraznik SET opis='".$s[5]."',kat=".$s[6]." WHERE id=".$R["id"];
                    }else{
                        $Datum=new DateTime($s[1]);
                        $SQL = "INSERT INTO tabpraznik (datum,leto,mesec,dan,opis,kat,trajanje) VALUES (";
                        $SQL .= "'".$Datum->format('Y-m-d')."',";
                        $SQL .= $Datum->format('Y').",";
                        $SQL .= $Datum->format('n').",";
                        $SQL .= $Datum->format('j').",";
                        $SQL .= "'".$s[5]."',";
                        $SQL .= $s[6].",0";
                        $SQL .= ")";
                    }
                    if (!($result = mysqli_query($link,$SQL))){
                        die("Napaka pri uvozu v koledar!<br />$SQL<br />");
                    }else{
                        echo "Vpisano: ".$s[1]." ".$s[5]."<br />";
                    }
                }
            }
        }
        //header ("Location: VnosPraznikov.php?id=1");
}
?>

</body>
</html>
